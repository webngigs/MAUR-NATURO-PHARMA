<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-04-14 05:10:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:10:54 --> Config Class Initialized
INFO - 2024-04-14 05:10:54 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:10:54 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:10:54 --> Utf8 Class Initialized
INFO - 2024-04-14 05:10:54 --> URI Class Initialized
DEBUG - 2024-04-14 05:10:54 --> No URI present. Default controller set.
INFO - 2024-04-14 05:10:54 --> Router Class Initialized
INFO - 2024-04-14 05:10:54 --> Output Class Initialized
INFO - 2024-04-14 05:10:55 --> Security Class Initialized
DEBUG - 2024-04-14 05:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:10:55 --> Input Class Initialized
INFO - 2024-04-14 05:10:55 --> Language Class Initialized
INFO - 2024-04-14 05:10:55 --> Loader Class Initialized
INFO - 2024-04-14 05:10:55 --> Helper loaded: url_helper
INFO - 2024-04-14 05:10:55 --> Helper loaded: file_helper
INFO - 2024-04-14 05:10:55 --> Helper loaded: html_helper
INFO - 2024-04-14 05:10:55 --> Helper loaded: text_helper
INFO - 2024-04-14 05:10:55 --> Helper loaded: form_helper
INFO - 2024-04-14 05:10:55 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:10:55 --> Helper loaded: security_helper
INFO - 2024-04-14 05:10:55 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:10:55 --> Database Driver Class Initialized
INFO - 2024-04-14 05:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:10:55 --> Parser Class Initialized
INFO - 2024-04-14 05:10:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:10:55 --> Pagination Class Initialized
INFO - 2024-04-14 05:10:55 --> Form Validation Class Initialized
INFO - 2024-04-14 05:10:55 --> Controller Class Initialized
INFO - 2024-04-14 05:10:55 --> Model Class Initialized
DEBUG - 2024-04-14 05:10:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-04-14 05:10:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:10:55 --> Config Class Initialized
INFO - 2024-04-14 05:10:55 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:10:55 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:10:55 --> Utf8 Class Initialized
INFO - 2024-04-14 05:10:55 --> URI Class Initialized
INFO - 2024-04-14 05:10:55 --> Router Class Initialized
INFO - 2024-04-14 05:10:55 --> Output Class Initialized
INFO - 2024-04-14 05:10:55 --> Security Class Initialized
DEBUG - 2024-04-14 05:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:10:55 --> Input Class Initialized
INFO - 2024-04-14 05:10:55 --> Language Class Initialized
INFO - 2024-04-14 05:10:55 --> Loader Class Initialized
INFO - 2024-04-14 05:10:55 --> Helper loaded: url_helper
INFO - 2024-04-14 05:10:55 --> Helper loaded: file_helper
INFO - 2024-04-14 05:10:55 --> Helper loaded: html_helper
INFO - 2024-04-14 05:10:55 --> Helper loaded: text_helper
INFO - 2024-04-14 05:10:55 --> Helper loaded: form_helper
INFO - 2024-04-14 05:10:55 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:10:55 --> Helper loaded: security_helper
INFO - 2024-04-14 05:10:55 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:10:55 --> Database Driver Class Initialized
INFO - 2024-04-14 05:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:10:55 --> Parser Class Initialized
INFO - 2024-04-14 05:10:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:10:55 --> Pagination Class Initialized
INFO - 2024-04-14 05:10:55 --> Form Validation Class Initialized
INFO - 2024-04-14 05:10:55 --> Controller Class Initialized
INFO - 2024-04-14 05:10:55 --> Model Class Initialized
DEBUG - 2024-04-14 05:10:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:10:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-04-14 05:10:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:10:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 05:10:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 05:10:55 --> Model Class Initialized
INFO - 2024-04-14 05:10:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 05:10:55 --> Final output sent to browser
DEBUG - 2024-04-14 05:10:55 --> Total execution time: 0.0346
ERROR - 2024-04-14 05:11:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:11:06 --> Config Class Initialized
INFO - 2024-04-14 05:11:06 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:11:06 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:11:06 --> Utf8 Class Initialized
INFO - 2024-04-14 05:11:06 --> URI Class Initialized
INFO - 2024-04-14 05:11:06 --> Router Class Initialized
INFO - 2024-04-14 05:11:06 --> Output Class Initialized
INFO - 2024-04-14 05:11:06 --> Security Class Initialized
DEBUG - 2024-04-14 05:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:11:06 --> Input Class Initialized
INFO - 2024-04-14 05:11:06 --> Language Class Initialized
INFO - 2024-04-14 05:11:06 --> Loader Class Initialized
INFO - 2024-04-14 05:11:06 --> Helper loaded: url_helper
INFO - 2024-04-14 05:11:06 --> Helper loaded: file_helper
INFO - 2024-04-14 05:11:06 --> Helper loaded: html_helper
INFO - 2024-04-14 05:11:06 --> Helper loaded: text_helper
INFO - 2024-04-14 05:11:06 --> Helper loaded: form_helper
INFO - 2024-04-14 05:11:06 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:11:06 --> Helper loaded: security_helper
INFO - 2024-04-14 05:11:06 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:11:06 --> Database Driver Class Initialized
INFO - 2024-04-14 05:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:11:06 --> Parser Class Initialized
INFO - 2024-04-14 05:11:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:11:06 --> Pagination Class Initialized
INFO - 2024-04-14 05:11:06 --> Form Validation Class Initialized
INFO - 2024-04-14 05:11:06 --> Controller Class Initialized
INFO - 2024-04-14 05:11:06 --> Model Class Initialized
DEBUG - 2024-04-14 05:11:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:11:06 --> Model Class Initialized
INFO - 2024-04-14 05:11:06 --> Final output sent to browser
DEBUG - 2024-04-14 05:11:06 --> Total execution time: 0.0227
ERROR - 2024-04-14 05:11:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:11:06 --> Config Class Initialized
INFO - 2024-04-14 05:11:06 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:11:06 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:11:06 --> Utf8 Class Initialized
INFO - 2024-04-14 05:11:06 --> URI Class Initialized
DEBUG - 2024-04-14 05:11:06 --> No URI present. Default controller set.
INFO - 2024-04-14 05:11:06 --> Router Class Initialized
INFO - 2024-04-14 05:11:06 --> Output Class Initialized
INFO - 2024-04-14 05:11:06 --> Security Class Initialized
DEBUG - 2024-04-14 05:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:11:06 --> Input Class Initialized
INFO - 2024-04-14 05:11:06 --> Language Class Initialized
INFO - 2024-04-14 05:11:06 --> Loader Class Initialized
INFO - 2024-04-14 05:11:06 --> Helper loaded: url_helper
INFO - 2024-04-14 05:11:06 --> Helper loaded: file_helper
INFO - 2024-04-14 05:11:06 --> Helper loaded: html_helper
INFO - 2024-04-14 05:11:06 --> Helper loaded: text_helper
INFO - 2024-04-14 05:11:06 --> Helper loaded: form_helper
INFO - 2024-04-14 05:11:06 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:11:06 --> Helper loaded: security_helper
INFO - 2024-04-14 05:11:06 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:11:06 --> Database Driver Class Initialized
INFO - 2024-04-14 05:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:11:06 --> Parser Class Initialized
INFO - 2024-04-14 05:11:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:11:06 --> Pagination Class Initialized
INFO - 2024-04-14 05:11:06 --> Form Validation Class Initialized
INFO - 2024-04-14 05:11:06 --> Controller Class Initialized
INFO - 2024-04-14 05:11:06 --> Model Class Initialized
DEBUG - 2024-04-14 05:11:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:11:06 --> Model Class Initialized
DEBUG - 2024-04-14 05:11:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:11:06 --> Model Class Initialized
INFO - 2024-04-14 05:11:06 --> Model Class Initialized
INFO - 2024-04-14 05:11:06 --> Model Class Initialized
INFO - 2024-04-14 05:11:06 --> Model Class Initialized
DEBUG - 2024-04-14 05:11:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 05:11:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:11:06 --> Model Class Initialized
INFO - 2024-04-14 05:11:06 --> Model Class Initialized
INFO - 2024-04-14 05:11:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-14 05:11:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:11:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 05:11:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 05:11:06 --> Model Class Initialized
INFO - 2024-04-14 05:11:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-14 05:11:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-14 05:11:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 05:11:07 --> Final output sent to browser
DEBUG - 2024-04-14 05:11:07 --> Total execution time: 0.6201
ERROR - 2024-04-14 05:11:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:11:08 --> Config Class Initialized
INFO - 2024-04-14 05:11:08 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:11:08 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:11:08 --> Utf8 Class Initialized
INFO - 2024-04-14 05:11:08 --> URI Class Initialized
INFO - 2024-04-14 05:11:08 --> Router Class Initialized
INFO - 2024-04-14 05:11:08 --> Output Class Initialized
INFO - 2024-04-14 05:11:08 --> Security Class Initialized
DEBUG - 2024-04-14 05:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:11:08 --> Input Class Initialized
INFO - 2024-04-14 05:11:08 --> Language Class Initialized
INFO - 2024-04-14 05:11:08 --> Loader Class Initialized
INFO - 2024-04-14 05:11:08 --> Helper loaded: url_helper
INFO - 2024-04-14 05:11:08 --> Helper loaded: file_helper
INFO - 2024-04-14 05:11:08 --> Helper loaded: html_helper
INFO - 2024-04-14 05:11:08 --> Helper loaded: text_helper
INFO - 2024-04-14 05:11:08 --> Helper loaded: form_helper
INFO - 2024-04-14 05:11:08 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:11:08 --> Helper loaded: security_helper
INFO - 2024-04-14 05:11:08 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:11:08 --> Database Driver Class Initialized
INFO - 2024-04-14 05:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:11:08 --> Parser Class Initialized
INFO - 2024-04-14 05:11:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:11:08 --> Pagination Class Initialized
INFO - 2024-04-14 05:11:08 --> Form Validation Class Initialized
INFO - 2024-04-14 05:11:08 --> Controller Class Initialized
DEBUG - 2024-04-14 05:11:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 05:11:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:11:08 --> Model Class Initialized
INFO - 2024-04-14 05:11:08 --> Final output sent to browser
DEBUG - 2024-04-14 05:11:08 --> Total execution time: 0.0135
ERROR - 2024-04-14 05:11:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:11:24 --> Config Class Initialized
INFO - 2024-04-14 05:11:24 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:11:24 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:11:24 --> Utf8 Class Initialized
INFO - 2024-04-14 05:11:24 --> URI Class Initialized
INFO - 2024-04-14 05:11:24 --> Router Class Initialized
INFO - 2024-04-14 05:11:24 --> Output Class Initialized
INFO - 2024-04-14 05:11:24 --> Security Class Initialized
DEBUG - 2024-04-14 05:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:11:24 --> Input Class Initialized
INFO - 2024-04-14 05:11:24 --> Language Class Initialized
INFO - 2024-04-14 05:11:24 --> Loader Class Initialized
INFO - 2024-04-14 05:11:24 --> Helper loaded: url_helper
INFO - 2024-04-14 05:11:24 --> Helper loaded: file_helper
INFO - 2024-04-14 05:11:24 --> Helper loaded: html_helper
INFO - 2024-04-14 05:11:24 --> Helper loaded: text_helper
INFO - 2024-04-14 05:11:24 --> Helper loaded: form_helper
INFO - 2024-04-14 05:11:24 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:11:24 --> Helper loaded: security_helper
INFO - 2024-04-14 05:11:24 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:11:24 --> Database Driver Class Initialized
INFO - 2024-04-14 05:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:11:24 --> Parser Class Initialized
INFO - 2024-04-14 05:11:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:11:24 --> Pagination Class Initialized
INFO - 2024-04-14 05:11:24 --> Form Validation Class Initialized
INFO - 2024-04-14 05:11:24 --> Controller Class Initialized
INFO - 2024-04-14 05:11:24 --> Model Class Initialized
DEBUG - 2024-04-14 05:11:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 05:11:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:11:24 --> Model Class Initialized
DEBUG - 2024-04-14 05:11:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:11:24 --> Model Class Initialized
INFO - 2024-04-14 05:11:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-04-14 05:11:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:11:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 05:11:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 05:11:25 --> Model Class Initialized
INFO - 2024-04-14 05:11:25 --> Model Class Initialized
INFO - 2024-04-14 05:11:25 --> Model Class Initialized
INFO - 2024-04-14 05:11:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-14 05:11:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-14 05:11:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 05:11:25 --> Final output sent to browser
DEBUG - 2024-04-14 05:11:25 --> Total execution time: 0.3571
ERROR - 2024-04-14 05:11:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:11:26 --> Config Class Initialized
INFO - 2024-04-14 05:11:26 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:11:26 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:11:26 --> Utf8 Class Initialized
INFO - 2024-04-14 05:11:26 --> URI Class Initialized
INFO - 2024-04-14 05:11:26 --> Router Class Initialized
INFO - 2024-04-14 05:11:26 --> Output Class Initialized
INFO - 2024-04-14 05:11:26 --> Security Class Initialized
DEBUG - 2024-04-14 05:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:11:26 --> Input Class Initialized
INFO - 2024-04-14 05:11:26 --> Language Class Initialized
INFO - 2024-04-14 05:11:26 --> Loader Class Initialized
INFO - 2024-04-14 05:11:26 --> Helper loaded: url_helper
INFO - 2024-04-14 05:11:26 --> Helper loaded: file_helper
INFO - 2024-04-14 05:11:26 --> Helper loaded: html_helper
INFO - 2024-04-14 05:11:26 --> Helper loaded: text_helper
INFO - 2024-04-14 05:11:26 --> Helper loaded: form_helper
INFO - 2024-04-14 05:11:26 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:11:26 --> Helper loaded: security_helper
INFO - 2024-04-14 05:11:26 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:11:26 --> Database Driver Class Initialized
INFO - 2024-04-14 05:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:11:26 --> Parser Class Initialized
INFO - 2024-04-14 05:11:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:11:26 --> Pagination Class Initialized
INFO - 2024-04-14 05:11:26 --> Form Validation Class Initialized
INFO - 2024-04-14 05:11:26 --> Controller Class Initialized
INFO - 2024-04-14 05:11:26 --> Model Class Initialized
DEBUG - 2024-04-14 05:11:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 05:11:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:11:26 --> Model Class Initialized
DEBUG - 2024-04-14 05:11:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:11:26 --> Model Class Initialized
INFO - 2024-04-14 05:11:26 --> Final output sent to browser
DEBUG - 2024-04-14 05:11:26 --> Total execution time: 0.0520
ERROR - 2024-04-14 05:11:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:11:33 --> Config Class Initialized
INFO - 2024-04-14 05:11:33 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:11:33 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:11:33 --> Utf8 Class Initialized
INFO - 2024-04-14 05:11:33 --> URI Class Initialized
INFO - 2024-04-14 05:11:33 --> Router Class Initialized
INFO - 2024-04-14 05:11:33 --> Output Class Initialized
INFO - 2024-04-14 05:11:33 --> Security Class Initialized
DEBUG - 2024-04-14 05:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:11:33 --> Input Class Initialized
INFO - 2024-04-14 05:11:33 --> Language Class Initialized
INFO - 2024-04-14 05:11:33 --> Loader Class Initialized
INFO - 2024-04-14 05:11:33 --> Helper loaded: url_helper
INFO - 2024-04-14 05:11:33 --> Helper loaded: file_helper
INFO - 2024-04-14 05:11:33 --> Helper loaded: html_helper
INFO - 2024-04-14 05:11:33 --> Helper loaded: text_helper
INFO - 2024-04-14 05:11:33 --> Helper loaded: form_helper
INFO - 2024-04-14 05:11:33 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:11:33 --> Helper loaded: security_helper
INFO - 2024-04-14 05:11:33 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:11:33 --> Database Driver Class Initialized
INFO - 2024-04-14 05:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:11:33 --> Parser Class Initialized
INFO - 2024-04-14 05:11:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:11:33 --> Pagination Class Initialized
INFO - 2024-04-14 05:11:33 --> Form Validation Class Initialized
INFO - 2024-04-14 05:11:33 --> Controller Class Initialized
INFO - 2024-04-14 05:11:33 --> Model Class Initialized
DEBUG - 2024-04-14 05:11:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 05:11:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:11:33 --> Model Class Initialized
DEBUG - 2024-04-14 05:11:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:11:33 --> Model Class Initialized
INFO - 2024-04-14 05:11:33 --> Final output sent to browser
DEBUG - 2024-04-14 05:11:33 --> Total execution time: 0.0646
ERROR - 2024-04-14 05:11:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:11:34 --> Config Class Initialized
INFO - 2024-04-14 05:11:34 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:11:34 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:11:34 --> Utf8 Class Initialized
INFO - 2024-04-14 05:11:34 --> URI Class Initialized
INFO - 2024-04-14 05:11:34 --> Router Class Initialized
INFO - 2024-04-14 05:11:34 --> Output Class Initialized
INFO - 2024-04-14 05:11:34 --> Security Class Initialized
DEBUG - 2024-04-14 05:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:11:34 --> Input Class Initialized
INFO - 2024-04-14 05:11:34 --> Language Class Initialized
INFO - 2024-04-14 05:11:34 --> Loader Class Initialized
INFO - 2024-04-14 05:11:34 --> Helper loaded: url_helper
INFO - 2024-04-14 05:11:34 --> Helper loaded: file_helper
INFO - 2024-04-14 05:11:34 --> Helper loaded: html_helper
INFO - 2024-04-14 05:11:34 --> Helper loaded: text_helper
INFO - 2024-04-14 05:11:34 --> Helper loaded: form_helper
INFO - 2024-04-14 05:11:34 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:11:34 --> Helper loaded: security_helper
INFO - 2024-04-14 05:11:34 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:11:34 --> Database Driver Class Initialized
INFO - 2024-04-14 05:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:11:34 --> Parser Class Initialized
INFO - 2024-04-14 05:11:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:11:34 --> Pagination Class Initialized
INFO - 2024-04-14 05:11:34 --> Form Validation Class Initialized
INFO - 2024-04-14 05:11:34 --> Controller Class Initialized
INFO - 2024-04-14 05:11:34 --> Model Class Initialized
DEBUG - 2024-04-14 05:11:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 05:11:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:11:34 --> Model Class Initialized
DEBUG - 2024-04-14 05:11:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:11:34 --> Model Class Initialized
INFO - 2024-04-14 05:11:34 --> Final output sent to browser
DEBUG - 2024-04-14 05:11:34 --> Total execution time: 0.0612
ERROR - 2024-04-14 05:11:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:11:34 --> Config Class Initialized
INFO - 2024-04-14 05:11:34 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:11:34 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:11:34 --> Utf8 Class Initialized
INFO - 2024-04-14 05:11:34 --> URI Class Initialized
INFO - 2024-04-14 05:11:34 --> Router Class Initialized
INFO - 2024-04-14 05:11:34 --> Output Class Initialized
INFO - 2024-04-14 05:11:34 --> Security Class Initialized
DEBUG - 2024-04-14 05:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:11:34 --> Input Class Initialized
INFO - 2024-04-14 05:11:34 --> Language Class Initialized
INFO - 2024-04-14 05:11:34 --> Loader Class Initialized
INFO - 2024-04-14 05:11:34 --> Helper loaded: url_helper
INFO - 2024-04-14 05:11:34 --> Helper loaded: file_helper
INFO - 2024-04-14 05:11:34 --> Helper loaded: html_helper
INFO - 2024-04-14 05:11:34 --> Helper loaded: text_helper
INFO - 2024-04-14 05:11:34 --> Helper loaded: form_helper
INFO - 2024-04-14 05:11:34 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:11:34 --> Helper loaded: security_helper
INFO - 2024-04-14 05:11:34 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:11:34 --> Database Driver Class Initialized
INFO - 2024-04-14 05:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:11:34 --> Parser Class Initialized
INFO - 2024-04-14 05:11:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:11:34 --> Pagination Class Initialized
INFO - 2024-04-14 05:11:34 --> Form Validation Class Initialized
INFO - 2024-04-14 05:11:34 --> Controller Class Initialized
INFO - 2024-04-14 05:11:34 --> Model Class Initialized
DEBUG - 2024-04-14 05:11:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 05:11:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:11:34 --> Model Class Initialized
DEBUG - 2024-04-14 05:11:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:11:34 --> Model Class Initialized
INFO - 2024-04-14 05:11:34 --> Final output sent to browser
DEBUG - 2024-04-14 05:11:34 --> Total execution time: 0.0593
ERROR - 2024-04-14 05:12:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:12:32 --> Config Class Initialized
INFO - 2024-04-14 05:12:32 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:12:32 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:12:32 --> Utf8 Class Initialized
INFO - 2024-04-14 05:12:32 --> URI Class Initialized
INFO - 2024-04-14 05:12:32 --> Router Class Initialized
INFO - 2024-04-14 05:12:32 --> Output Class Initialized
INFO - 2024-04-14 05:12:32 --> Security Class Initialized
DEBUG - 2024-04-14 05:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:12:32 --> Input Class Initialized
INFO - 2024-04-14 05:12:32 --> Language Class Initialized
INFO - 2024-04-14 05:12:32 --> Loader Class Initialized
INFO - 2024-04-14 05:12:32 --> Helper loaded: url_helper
INFO - 2024-04-14 05:12:32 --> Helper loaded: file_helper
INFO - 2024-04-14 05:12:32 --> Helper loaded: html_helper
INFO - 2024-04-14 05:12:32 --> Helper loaded: text_helper
INFO - 2024-04-14 05:12:32 --> Helper loaded: form_helper
INFO - 2024-04-14 05:12:32 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:12:32 --> Helper loaded: security_helper
INFO - 2024-04-14 05:12:32 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:12:32 --> Database Driver Class Initialized
INFO - 2024-04-14 05:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:12:32 --> Parser Class Initialized
INFO - 2024-04-14 05:12:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:12:32 --> Pagination Class Initialized
INFO - 2024-04-14 05:12:32 --> Form Validation Class Initialized
INFO - 2024-04-14 05:12:32 --> Controller Class Initialized
INFO - 2024-04-14 05:12:32 --> Model Class Initialized
DEBUG - 2024-04-14 05:12:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 05:12:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:12:32 --> Model Class Initialized
DEBUG - 2024-04-14 05:12:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:12:32 --> Model Class Initialized
DEBUG - 2024-04-14 05:12:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:12:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-04-14 05:12:32 --> Final output sent to browser
DEBUG - 2024-04-14 05:12:32 --> Total execution time: 0.2098
ERROR - 2024-04-14 05:12:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:12:39 --> Config Class Initialized
INFO - 2024-04-14 05:12:39 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:12:39 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:12:39 --> Utf8 Class Initialized
INFO - 2024-04-14 05:12:39 --> URI Class Initialized
INFO - 2024-04-14 05:12:39 --> Router Class Initialized
INFO - 2024-04-14 05:12:39 --> Output Class Initialized
INFO - 2024-04-14 05:12:39 --> Security Class Initialized
DEBUG - 2024-04-14 05:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:12:39 --> Input Class Initialized
INFO - 2024-04-14 05:12:39 --> Language Class Initialized
INFO - 2024-04-14 05:12:39 --> Loader Class Initialized
INFO - 2024-04-14 05:12:39 --> Helper loaded: url_helper
INFO - 2024-04-14 05:12:39 --> Helper loaded: file_helper
INFO - 2024-04-14 05:12:39 --> Helper loaded: html_helper
INFO - 2024-04-14 05:12:39 --> Helper loaded: text_helper
INFO - 2024-04-14 05:12:39 --> Helper loaded: form_helper
INFO - 2024-04-14 05:12:39 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:12:39 --> Helper loaded: security_helper
INFO - 2024-04-14 05:12:39 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:12:39 --> Database Driver Class Initialized
INFO - 2024-04-14 05:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:12:39 --> Parser Class Initialized
INFO - 2024-04-14 05:12:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:12:39 --> Pagination Class Initialized
INFO - 2024-04-14 05:12:39 --> Form Validation Class Initialized
INFO - 2024-04-14 05:12:39 --> Controller Class Initialized
INFO - 2024-04-14 05:12:39 --> Model Class Initialized
DEBUG - 2024-04-14 05:12:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 05:12:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:12:39 --> Model Class Initialized
DEBUG - 2024-04-14 05:12:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:12:39 --> Model Class Initialized
DEBUG - 2024-04-14 05:12:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:12:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-04-14 05:12:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:12:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 05:12:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 05:12:39 --> Model Class Initialized
INFO - 2024-04-14 05:12:39 --> Model Class Initialized
INFO - 2024-04-14 05:12:39 --> Model Class Initialized
INFO - 2024-04-14 05:12:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-14 05:12:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-14 05:12:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 05:12:39 --> Final output sent to browser
DEBUG - 2024-04-14 05:12:39 --> Total execution time: 0.3125
ERROR - 2024-04-14 05:13:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:13:04 --> Config Class Initialized
INFO - 2024-04-14 05:13:04 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:13:04 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:13:04 --> Utf8 Class Initialized
INFO - 2024-04-14 05:13:04 --> URI Class Initialized
INFO - 2024-04-14 05:13:04 --> Router Class Initialized
INFO - 2024-04-14 05:13:04 --> Output Class Initialized
INFO - 2024-04-14 05:13:04 --> Security Class Initialized
DEBUG - 2024-04-14 05:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:13:04 --> Input Class Initialized
INFO - 2024-04-14 05:13:04 --> Language Class Initialized
INFO - 2024-04-14 05:13:04 --> Loader Class Initialized
INFO - 2024-04-14 05:13:04 --> Helper loaded: url_helper
INFO - 2024-04-14 05:13:04 --> Helper loaded: file_helper
INFO - 2024-04-14 05:13:04 --> Helper loaded: html_helper
INFO - 2024-04-14 05:13:04 --> Helper loaded: text_helper
INFO - 2024-04-14 05:13:04 --> Helper loaded: form_helper
INFO - 2024-04-14 05:13:04 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:13:04 --> Helper loaded: security_helper
INFO - 2024-04-14 05:13:04 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:13:04 --> Database Driver Class Initialized
INFO - 2024-04-14 05:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:13:04 --> Parser Class Initialized
INFO - 2024-04-14 05:13:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:13:04 --> Pagination Class Initialized
INFO - 2024-04-14 05:13:04 --> Form Validation Class Initialized
INFO - 2024-04-14 05:13:04 --> Controller Class Initialized
INFO - 2024-04-14 05:13:04 --> Model Class Initialized
DEBUG - 2024-04-14 05:13:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 05:13:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:13:04 --> Model Class Initialized
DEBUG - 2024-04-14 05:13:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:13:04 --> Model Class Initialized
INFO - 2024-04-14 05:13:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-04-14 05:13:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:13:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 05:13:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 05:13:04 --> Model Class Initialized
INFO - 2024-04-14 05:13:04 --> Model Class Initialized
INFO - 2024-04-14 05:13:04 --> Model Class Initialized
INFO - 2024-04-14 05:13:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-14 05:13:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-14 05:13:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 05:13:04 --> Final output sent to browser
DEBUG - 2024-04-14 05:13:04 --> Total execution time: 0.2977
ERROR - 2024-04-14 05:13:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:13:05 --> Config Class Initialized
INFO - 2024-04-14 05:13:05 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:13:05 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:13:05 --> Utf8 Class Initialized
INFO - 2024-04-14 05:13:05 --> URI Class Initialized
INFO - 2024-04-14 05:13:05 --> Router Class Initialized
INFO - 2024-04-14 05:13:05 --> Output Class Initialized
INFO - 2024-04-14 05:13:05 --> Security Class Initialized
DEBUG - 2024-04-14 05:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:13:05 --> Input Class Initialized
INFO - 2024-04-14 05:13:05 --> Language Class Initialized
INFO - 2024-04-14 05:13:05 --> Loader Class Initialized
INFO - 2024-04-14 05:13:05 --> Helper loaded: url_helper
INFO - 2024-04-14 05:13:05 --> Helper loaded: file_helper
INFO - 2024-04-14 05:13:05 --> Helper loaded: html_helper
INFO - 2024-04-14 05:13:05 --> Helper loaded: text_helper
INFO - 2024-04-14 05:13:05 --> Helper loaded: form_helper
INFO - 2024-04-14 05:13:05 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:13:05 --> Helper loaded: security_helper
INFO - 2024-04-14 05:13:05 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:13:05 --> Database Driver Class Initialized
INFO - 2024-04-14 05:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:13:05 --> Parser Class Initialized
INFO - 2024-04-14 05:13:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:13:05 --> Pagination Class Initialized
INFO - 2024-04-14 05:13:05 --> Form Validation Class Initialized
INFO - 2024-04-14 05:13:05 --> Controller Class Initialized
INFO - 2024-04-14 05:13:05 --> Model Class Initialized
DEBUG - 2024-04-14 05:13:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 05:13:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:13:05 --> Model Class Initialized
DEBUG - 2024-04-14 05:13:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:13:05 --> Model Class Initialized
INFO - 2024-04-14 05:13:05 --> Final output sent to browser
DEBUG - 2024-04-14 05:13:05 --> Total execution time: 0.0468
ERROR - 2024-04-14 05:13:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:13:09 --> Config Class Initialized
INFO - 2024-04-14 05:13:09 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:13:09 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:13:09 --> Utf8 Class Initialized
INFO - 2024-04-14 05:13:09 --> URI Class Initialized
INFO - 2024-04-14 05:13:09 --> Router Class Initialized
INFO - 2024-04-14 05:13:09 --> Output Class Initialized
INFO - 2024-04-14 05:13:09 --> Security Class Initialized
DEBUG - 2024-04-14 05:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:13:09 --> Input Class Initialized
INFO - 2024-04-14 05:13:09 --> Language Class Initialized
INFO - 2024-04-14 05:13:09 --> Loader Class Initialized
INFO - 2024-04-14 05:13:09 --> Helper loaded: url_helper
INFO - 2024-04-14 05:13:09 --> Helper loaded: file_helper
INFO - 2024-04-14 05:13:09 --> Helper loaded: html_helper
INFO - 2024-04-14 05:13:09 --> Helper loaded: text_helper
INFO - 2024-04-14 05:13:09 --> Helper loaded: form_helper
INFO - 2024-04-14 05:13:09 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:13:09 --> Helper loaded: security_helper
INFO - 2024-04-14 05:13:09 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:13:09 --> Database Driver Class Initialized
INFO - 2024-04-14 05:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:13:09 --> Parser Class Initialized
INFO - 2024-04-14 05:13:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:13:09 --> Pagination Class Initialized
INFO - 2024-04-14 05:13:09 --> Form Validation Class Initialized
INFO - 2024-04-14 05:13:09 --> Controller Class Initialized
INFO - 2024-04-14 05:13:09 --> Model Class Initialized
DEBUG - 2024-04-14 05:13:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 05:13:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:13:09 --> Model Class Initialized
DEBUG - 2024-04-14 05:13:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:13:09 --> Model Class Initialized
INFO - 2024-04-14 05:13:09 --> Final output sent to browser
DEBUG - 2024-04-14 05:13:09 --> Total execution time: 0.0458
ERROR - 2024-04-14 05:13:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:13:09 --> Config Class Initialized
INFO - 2024-04-14 05:13:09 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:13:09 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:13:09 --> Utf8 Class Initialized
INFO - 2024-04-14 05:13:09 --> URI Class Initialized
INFO - 2024-04-14 05:13:09 --> Router Class Initialized
INFO - 2024-04-14 05:13:09 --> Output Class Initialized
INFO - 2024-04-14 05:13:09 --> Security Class Initialized
DEBUG - 2024-04-14 05:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:13:09 --> Input Class Initialized
INFO - 2024-04-14 05:13:09 --> Language Class Initialized
INFO - 2024-04-14 05:13:09 --> Loader Class Initialized
INFO - 2024-04-14 05:13:09 --> Helper loaded: url_helper
INFO - 2024-04-14 05:13:09 --> Helper loaded: file_helper
INFO - 2024-04-14 05:13:09 --> Helper loaded: html_helper
INFO - 2024-04-14 05:13:09 --> Helper loaded: text_helper
INFO - 2024-04-14 05:13:09 --> Helper loaded: form_helper
INFO - 2024-04-14 05:13:09 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:13:09 --> Helper loaded: security_helper
INFO - 2024-04-14 05:13:09 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:13:09 --> Database Driver Class Initialized
INFO - 2024-04-14 05:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:13:09 --> Parser Class Initialized
INFO - 2024-04-14 05:13:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:13:09 --> Pagination Class Initialized
INFO - 2024-04-14 05:13:09 --> Form Validation Class Initialized
INFO - 2024-04-14 05:13:09 --> Controller Class Initialized
INFO - 2024-04-14 05:13:09 --> Model Class Initialized
DEBUG - 2024-04-14 05:13:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 05:13:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:13:09 --> Model Class Initialized
DEBUG - 2024-04-14 05:13:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:13:09 --> Model Class Initialized
INFO - 2024-04-14 05:13:09 --> Final output sent to browser
DEBUG - 2024-04-14 05:13:09 --> Total execution time: 0.0612
ERROR - 2024-04-14 05:13:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:13:10 --> Config Class Initialized
INFO - 2024-04-14 05:13:10 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:13:10 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:13:10 --> Utf8 Class Initialized
INFO - 2024-04-14 05:13:10 --> URI Class Initialized
INFO - 2024-04-14 05:13:10 --> Router Class Initialized
INFO - 2024-04-14 05:13:10 --> Output Class Initialized
INFO - 2024-04-14 05:13:10 --> Security Class Initialized
DEBUG - 2024-04-14 05:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:13:10 --> Input Class Initialized
INFO - 2024-04-14 05:13:10 --> Language Class Initialized
INFO - 2024-04-14 05:13:10 --> Loader Class Initialized
INFO - 2024-04-14 05:13:10 --> Helper loaded: url_helper
INFO - 2024-04-14 05:13:10 --> Helper loaded: file_helper
INFO - 2024-04-14 05:13:10 --> Helper loaded: html_helper
INFO - 2024-04-14 05:13:10 --> Helper loaded: text_helper
INFO - 2024-04-14 05:13:10 --> Helper loaded: form_helper
INFO - 2024-04-14 05:13:10 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:13:10 --> Helper loaded: security_helper
INFO - 2024-04-14 05:13:10 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:13:10 --> Database Driver Class Initialized
INFO - 2024-04-14 05:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:13:10 --> Parser Class Initialized
INFO - 2024-04-14 05:13:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:13:10 --> Pagination Class Initialized
INFO - 2024-04-14 05:13:10 --> Form Validation Class Initialized
INFO - 2024-04-14 05:13:10 --> Controller Class Initialized
INFO - 2024-04-14 05:13:10 --> Model Class Initialized
DEBUG - 2024-04-14 05:13:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 05:13:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:13:10 --> Model Class Initialized
DEBUG - 2024-04-14 05:13:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:13:10 --> Model Class Initialized
INFO - 2024-04-14 05:13:10 --> Final output sent to browser
DEBUG - 2024-04-14 05:13:10 --> Total execution time: 0.0598
ERROR - 2024-04-14 05:13:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:13:11 --> Config Class Initialized
INFO - 2024-04-14 05:13:11 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:13:11 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:13:11 --> Utf8 Class Initialized
INFO - 2024-04-14 05:13:11 --> URI Class Initialized
INFO - 2024-04-14 05:13:11 --> Router Class Initialized
INFO - 2024-04-14 05:13:11 --> Output Class Initialized
INFO - 2024-04-14 05:13:11 --> Security Class Initialized
DEBUG - 2024-04-14 05:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:13:11 --> Input Class Initialized
INFO - 2024-04-14 05:13:11 --> Language Class Initialized
INFO - 2024-04-14 05:13:11 --> Loader Class Initialized
INFO - 2024-04-14 05:13:11 --> Helper loaded: url_helper
INFO - 2024-04-14 05:13:11 --> Helper loaded: file_helper
INFO - 2024-04-14 05:13:11 --> Helper loaded: html_helper
INFO - 2024-04-14 05:13:11 --> Helper loaded: text_helper
INFO - 2024-04-14 05:13:11 --> Helper loaded: form_helper
INFO - 2024-04-14 05:13:11 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:13:11 --> Helper loaded: security_helper
INFO - 2024-04-14 05:13:11 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:13:11 --> Database Driver Class Initialized
INFO - 2024-04-14 05:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:13:11 --> Parser Class Initialized
INFO - 2024-04-14 05:13:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:13:11 --> Pagination Class Initialized
INFO - 2024-04-14 05:13:11 --> Form Validation Class Initialized
INFO - 2024-04-14 05:13:11 --> Controller Class Initialized
INFO - 2024-04-14 05:13:11 --> Model Class Initialized
DEBUG - 2024-04-14 05:13:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 05:13:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:13:11 --> Model Class Initialized
DEBUG - 2024-04-14 05:13:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:13:11 --> Model Class Initialized
INFO - 2024-04-14 05:13:11 --> Final output sent to browser
DEBUG - 2024-04-14 05:13:11 --> Total execution time: 0.0634
ERROR - 2024-04-14 05:13:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:13:17 --> Config Class Initialized
INFO - 2024-04-14 05:13:17 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:13:17 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:13:17 --> Utf8 Class Initialized
INFO - 2024-04-14 05:13:17 --> URI Class Initialized
DEBUG - 2024-04-14 05:13:17 --> No URI present. Default controller set.
INFO - 2024-04-14 05:13:17 --> Router Class Initialized
INFO - 2024-04-14 05:13:17 --> Output Class Initialized
INFO - 2024-04-14 05:13:17 --> Security Class Initialized
DEBUG - 2024-04-14 05:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:13:17 --> Input Class Initialized
INFO - 2024-04-14 05:13:17 --> Language Class Initialized
INFO - 2024-04-14 05:13:17 --> Loader Class Initialized
INFO - 2024-04-14 05:13:17 --> Helper loaded: url_helper
INFO - 2024-04-14 05:13:17 --> Helper loaded: file_helper
INFO - 2024-04-14 05:13:17 --> Helper loaded: html_helper
INFO - 2024-04-14 05:13:17 --> Helper loaded: text_helper
INFO - 2024-04-14 05:13:17 --> Helper loaded: form_helper
INFO - 2024-04-14 05:13:17 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:13:17 --> Helper loaded: security_helper
INFO - 2024-04-14 05:13:17 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:13:17 --> Database Driver Class Initialized
INFO - 2024-04-14 05:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:13:17 --> Parser Class Initialized
INFO - 2024-04-14 05:13:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:13:17 --> Pagination Class Initialized
INFO - 2024-04-14 05:13:17 --> Form Validation Class Initialized
INFO - 2024-04-14 05:13:17 --> Controller Class Initialized
INFO - 2024-04-14 05:13:17 --> Model Class Initialized
DEBUG - 2024-04-14 05:13:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:13:17 --> Model Class Initialized
DEBUG - 2024-04-14 05:13:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:13:17 --> Model Class Initialized
INFO - 2024-04-14 05:13:17 --> Model Class Initialized
INFO - 2024-04-14 05:13:17 --> Model Class Initialized
INFO - 2024-04-14 05:13:17 --> Model Class Initialized
DEBUG - 2024-04-14 05:13:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 05:13:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:13:17 --> Model Class Initialized
INFO - 2024-04-14 05:13:17 --> Model Class Initialized
INFO - 2024-04-14 05:13:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-14 05:13:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:13:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 05:13:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 05:13:17 --> Model Class Initialized
INFO - 2024-04-14 05:13:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-14 05:13:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-14 05:13:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 05:13:17 --> Final output sent to browser
DEBUG - 2024-04-14 05:13:17 --> Total execution time: 0.6177
ERROR - 2024-04-14 05:16:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:16:11 --> Config Class Initialized
INFO - 2024-04-14 05:16:11 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:16:11 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:16:11 --> Utf8 Class Initialized
INFO - 2024-04-14 05:16:11 --> URI Class Initialized
DEBUG - 2024-04-14 05:16:11 --> No URI present. Default controller set.
INFO - 2024-04-14 05:16:11 --> Router Class Initialized
INFO - 2024-04-14 05:16:11 --> Output Class Initialized
INFO - 2024-04-14 05:16:11 --> Security Class Initialized
DEBUG - 2024-04-14 05:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:16:11 --> Input Class Initialized
INFO - 2024-04-14 05:16:11 --> Language Class Initialized
INFO - 2024-04-14 05:16:11 --> Loader Class Initialized
INFO - 2024-04-14 05:16:11 --> Helper loaded: url_helper
INFO - 2024-04-14 05:16:11 --> Helper loaded: file_helper
INFO - 2024-04-14 05:16:11 --> Helper loaded: html_helper
INFO - 2024-04-14 05:16:11 --> Helper loaded: text_helper
INFO - 2024-04-14 05:16:11 --> Helper loaded: form_helper
INFO - 2024-04-14 05:16:11 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:16:11 --> Helper loaded: security_helper
INFO - 2024-04-14 05:16:11 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:16:11 --> Database Driver Class Initialized
INFO - 2024-04-14 05:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:16:11 --> Parser Class Initialized
INFO - 2024-04-14 05:16:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:16:11 --> Pagination Class Initialized
INFO - 2024-04-14 05:16:11 --> Form Validation Class Initialized
INFO - 2024-04-14 05:16:11 --> Controller Class Initialized
INFO - 2024-04-14 05:16:11 --> Model Class Initialized
DEBUG - 2024-04-14 05:16:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-04-14 05:16:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:16:11 --> Config Class Initialized
INFO - 2024-04-14 05:16:11 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:16:11 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:16:11 --> Utf8 Class Initialized
INFO - 2024-04-14 05:16:11 --> URI Class Initialized
INFO - 2024-04-14 05:16:11 --> Router Class Initialized
INFO - 2024-04-14 05:16:11 --> Output Class Initialized
INFO - 2024-04-14 05:16:11 --> Security Class Initialized
DEBUG - 2024-04-14 05:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:16:11 --> Input Class Initialized
INFO - 2024-04-14 05:16:11 --> Language Class Initialized
INFO - 2024-04-14 05:16:11 --> Loader Class Initialized
INFO - 2024-04-14 05:16:11 --> Helper loaded: url_helper
INFO - 2024-04-14 05:16:11 --> Helper loaded: file_helper
INFO - 2024-04-14 05:16:11 --> Helper loaded: html_helper
INFO - 2024-04-14 05:16:11 --> Helper loaded: text_helper
INFO - 2024-04-14 05:16:11 --> Helper loaded: form_helper
INFO - 2024-04-14 05:16:11 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:16:11 --> Helper loaded: security_helper
INFO - 2024-04-14 05:16:11 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:16:11 --> Database Driver Class Initialized
INFO - 2024-04-14 05:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:16:11 --> Parser Class Initialized
INFO - 2024-04-14 05:16:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:16:11 --> Pagination Class Initialized
INFO - 2024-04-14 05:16:11 --> Form Validation Class Initialized
INFO - 2024-04-14 05:16:11 --> Controller Class Initialized
INFO - 2024-04-14 05:16:11 --> Model Class Initialized
DEBUG - 2024-04-14 05:16:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:16:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-04-14 05:16:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:16:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 05:16:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 05:16:11 --> Model Class Initialized
INFO - 2024-04-14 05:16:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 05:16:11 --> Final output sent to browser
DEBUG - 2024-04-14 05:16:11 --> Total execution time: 0.0341
ERROR - 2024-04-14 05:16:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:16:17 --> Config Class Initialized
INFO - 2024-04-14 05:16:17 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:16:17 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:16:17 --> Utf8 Class Initialized
INFO - 2024-04-14 05:16:17 --> URI Class Initialized
INFO - 2024-04-14 05:16:17 --> Router Class Initialized
INFO - 2024-04-14 05:16:17 --> Output Class Initialized
INFO - 2024-04-14 05:16:17 --> Security Class Initialized
DEBUG - 2024-04-14 05:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:16:17 --> Input Class Initialized
INFO - 2024-04-14 05:16:17 --> Language Class Initialized
INFO - 2024-04-14 05:16:17 --> Loader Class Initialized
INFO - 2024-04-14 05:16:17 --> Helper loaded: url_helper
INFO - 2024-04-14 05:16:17 --> Helper loaded: file_helper
INFO - 2024-04-14 05:16:17 --> Helper loaded: html_helper
INFO - 2024-04-14 05:16:17 --> Helper loaded: text_helper
INFO - 2024-04-14 05:16:17 --> Helper loaded: form_helper
INFO - 2024-04-14 05:16:17 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:16:17 --> Helper loaded: security_helper
INFO - 2024-04-14 05:16:17 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:16:17 --> Database Driver Class Initialized
INFO - 2024-04-14 05:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:16:17 --> Parser Class Initialized
INFO - 2024-04-14 05:16:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:16:17 --> Pagination Class Initialized
INFO - 2024-04-14 05:16:17 --> Form Validation Class Initialized
INFO - 2024-04-14 05:16:17 --> Controller Class Initialized
INFO - 2024-04-14 05:16:17 --> Model Class Initialized
DEBUG - 2024-04-14 05:16:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:16:17 --> Model Class Initialized
INFO - 2024-04-14 05:16:17 --> Final output sent to browser
DEBUG - 2024-04-14 05:16:17 --> Total execution time: 0.0189
ERROR - 2024-04-14 05:16:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:16:17 --> Config Class Initialized
INFO - 2024-04-14 05:16:17 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:16:17 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:16:17 --> Utf8 Class Initialized
INFO - 2024-04-14 05:16:17 --> URI Class Initialized
DEBUG - 2024-04-14 05:16:17 --> No URI present. Default controller set.
INFO - 2024-04-14 05:16:17 --> Router Class Initialized
INFO - 2024-04-14 05:16:17 --> Output Class Initialized
INFO - 2024-04-14 05:16:17 --> Security Class Initialized
DEBUG - 2024-04-14 05:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:16:17 --> Input Class Initialized
INFO - 2024-04-14 05:16:17 --> Language Class Initialized
INFO - 2024-04-14 05:16:17 --> Loader Class Initialized
INFO - 2024-04-14 05:16:17 --> Helper loaded: url_helper
INFO - 2024-04-14 05:16:17 --> Helper loaded: file_helper
INFO - 2024-04-14 05:16:17 --> Helper loaded: html_helper
INFO - 2024-04-14 05:16:17 --> Helper loaded: text_helper
INFO - 2024-04-14 05:16:17 --> Helper loaded: form_helper
INFO - 2024-04-14 05:16:17 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:16:17 --> Helper loaded: security_helper
INFO - 2024-04-14 05:16:17 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:16:17 --> Database Driver Class Initialized
INFO - 2024-04-14 05:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:16:17 --> Parser Class Initialized
INFO - 2024-04-14 05:16:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:16:17 --> Pagination Class Initialized
INFO - 2024-04-14 05:16:17 --> Form Validation Class Initialized
INFO - 2024-04-14 05:16:17 --> Controller Class Initialized
INFO - 2024-04-14 05:16:17 --> Model Class Initialized
DEBUG - 2024-04-14 05:16:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:16:17 --> Model Class Initialized
DEBUG - 2024-04-14 05:16:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:16:17 --> Model Class Initialized
INFO - 2024-04-14 05:16:17 --> Model Class Initialized
INFO - 2024-04-14 05:16:17 --> Model Class Initialized
INFO - 2024-04-14 05:16:17 --> Model Class Initialized
DEBUG - 2024-04-14 05:16:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 05:16:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:16:17 --> Model Class Initialized
INFO - 2024-04-14 05:16:17 --> Model Class Initialized
INFO - 2024-04-14 05:16:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-14 05:16:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:16:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 05:16:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 05:16:17 --> Model Class Initialized
INFO - 2024-04-14 05:16:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-14 05:16:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-14 05:16:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 05:16:17 --> Final output sent to browser
DEBUG - 2024-04-14 05:16:17 --> Total execution time: 0.6167
ERROR - 2024-04-14 05:16:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:16:20 --> Config Class Initialized
INFO - 2024-04-14 05:16:20 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:16:20 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:16:20 --> Utf8 Class Initialized
INFO - 2024-04-14 05:16:20 --> URI Class Initialized
INFO - 2024-04-14 05:16:20 --> Router Class Initialized
INFO - 2024-04-14 05:16:20 --> Output Class Initialized
INFO - 2024-04-14 05:16:20 --> Security Class Initialized
DEBUG - 2024-04-14 05:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:16:20 --> Input Class Initialized
INFO - 2024-04-14 05:16:20 --> Language Class Initialized
INFO - 2024-04-14 05:16:20 --> Loader Class Initialized
INFO - 2024-04-14 05:16:20 --> Helper loaded: url_helper
INFO - 2024-04-14 05:16:20 --> Helper loaded: file_helper
INFO - 2024-04-14 05:16:20 --> Helper loaded: html_helper
INFO - 2024-04-14 05:16:20 --> Helper loaded: text_helper
INFO - 2024-04-14 05:16:20 --> Helper loaded: form_helper
INFO - 2024-04-14 05:16:20 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:16:20 --> Helper loaded: security_helper
INFO - 2024-04-14 05:16:20 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:16:20 --> Database Driver Class Initialized
INFO - 2024-04-14 05:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:16:20 --> Parser Class Initialized
INFO - 2024-04-14 05:16:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:16:20 --> Pagination Class Initialized
INFO - 2024-04-14 05:16:20 --> Form Validation Class Initialized
INFO - 2024-04-14 05:16:20 --> Controller Class Initialized
DEBUG - 2024-04-14 05:16:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 05:16:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:16:20 --> Model Class Initialized
INFO - 2024-04-14 05:16:20 --> Final output sent to browser
DEBUG - 2024-04-14 05:16:20 --> Total execution time: 0.0130
ERROR - 2024-04-14 05:16:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:16:26 --> Config Class Initialized
INFO - 2024-04-14 05:16:26 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:16:26 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:16:26 --> Utf8 Class Initialized
INFO - 2024-04-14 05:16:26 --> URI Class Initialized
INFO - 2024-04-14 05:16:26 --> Router Class Initialized
INFO - 2024-04-14 05:16:26 --> Output Class Initialized
INFO - 2024-04-14 05:16:26 --> Security Class Initialized
DEBUG - 2024-04-14 05:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:16:26 --> Input Class Initialized
INFO - 2024-04-14 05:16:26 --> Language Class Initialized
INFO - 2024-04-14 05:16:26 --> Loader Class Initialized
INFO - 2024-04-14 05:16:26 --> Helper loaded: url_helper
INFO - 2024-04-14 05:16:26 --> Helper loaded: file_helper
INFO - 2024-04-14 05:16:26 --> Helper loaded: html_helper
INFO - 2024-04-14 05:16:26 --> Helper loaded: text_helper
INFO - 2024-04-14 05:16:26 --> Helper loaded: form_helper
INFO - 2024-04-14 05:16:26 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:16:26 --> Helper loaded: security_helper
INFO - 2024-04-14 05:16:26 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:16:26 --> Database Driver Class Initialized
INFO - 2024-04-14 05:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:16:26 --> Parser Class Initialized
INFO - 2024-04-14 05:16:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:16:26 --> Pagination Class Initialized
INFO - 2024-04-14 05:16:26 --> Form Validation Class Initialized
INFO - 2024-04-14 05:16:26 --> Controller Class Initialized
INFO - 2024-04-14 05:16:26 --> Model Class Initialized
DEBUG - 2024-04-14 05:16:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 05:16:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:16:26 --> Model Class Initialized
DEBUG - 2024-04-14 05:16:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:16:26 --> Model Class Initialized
INFO - 2024-04-14 05:16:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-04-14 05:16:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:16:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 05:16:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 05:16:26 --> Model Class Initialized
INFO - 2024-04-14 05:16:26 --> Model Class Initialized
INFO - 2024-04-14 05:16:26 --> Model Class Initialized
INFO - 2024-04-14 05:16:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-14 05:16:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-14 05:16:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 05:16:27 --> Final output sent to browser
DEBUG - 2024-04-14 05:16:27 --> Total execution time: 0.2881
ERROR - 2024-04-14 05:16:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:16:28 --> Config Class Initialized
INFO - 2024-04-14 05:16:28 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:16:28 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:16:28 --> Utf8 Class Initialized
INFO - 2024-04-14 05:16:28 --> URI Class Initialized
INFO - 2024-04-14 05:16:28 --> Router Class Initialized
INFO - 2024-04-14 05:16:28 --> Output Class Initialized
INFO - 2024-04-14 05:16:28 --> Security Class Initialized
DEBUG - 2024-04-14 05:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:16:28 --> Input Class Initialized
INFO - 2024-04-14 05:16:28 --> Language Class Initialized
INFO - 2024-04-14 05:16:28 --> Loader Class Initialized
INFO - 2024-04-14 05:16:28 --> Helper loaded: url_helper
INFO - 2024-04-14 05:16:28 --> Helper loaded: file_helper
INFO - 2024-04-14 05:16:28 --> Helper loaded: html_helper
INFO - 2024-04-14 05:16:28 --> Helper loaded: text_helper
INFO - 2024-04-14 05:16:28 --> Helper loaded: form_helper
INFO - 2024-04-14 05:16:28 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:16:28 --> Helper loaded: security_helper
INFO - 2024-04-14 05:16:28 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:16:28 --> Database Driver Class Initialized
INFO - 2024-04-14 05:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:16:28 --> Parser Class Initialized
INFO - 2024-04-14 05:16:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:16:28 --> Pagination Class Initialized
INFO - 2024-04-14 05:16:28 --> Form Validation Class Initialized
INFO - 2024-04-14 05:16:28 --> Controller Class Initialized
INFO - 2024-04-14 05:16:28 --> Model Class Initialized
DEBUG - 2024-04-14 05:16:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 05:16:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:16:28 --> Model Class Initialized
DEBUG - 2024-04-14 05:16:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:16:28 --> Model Class Initialized
INFO - 2024-04-14 05:16:28 --> Final output sent to browser
DEBUG - 2024-04-14 05:16:28 --> Total execution time: 0.0456
ERROR - 2024-04-14 05:16:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:16:33 --> Config Class Initialized
INFO - 2024-04-14 05:16:33 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:16:33 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:16:33 --> Utf8 Class Initialized
INFO - 2024-04-14 05:16:33 --> URI Class Initialized
INFO - 2024-04-14 05:16:33 --> Router Class Initialized
INFO - 2024-04-14 05:16:33 --> Output Class Initialized
INFO - 2024-04-14 05:16:33 --> Security Class Initialized
DEBUG - 2024-04-14 05:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:16:33 --> Input Class Initialized
INFO - 2024-04-14 05:16:33 --> Language Class Initialized
INFO - 2024-04-14 05:16:33 --> Loader Class Initialized
INFO - 2024-04-14 05:16:33 --> Helper loaded: url_helper
INFO - 2024-04-14 05:16:33 --> Helper loaded: file_helper
INFO - 2024-04-14 05:16:33 --> Helper loaded: html_helper
INFO - 2024-04-14 05:16:33 --> Helper loaded: text_helper
INFO - 2024-04-14 05:16:33 --> Helper loaded: form_helper
INFO - 2024-04-14 05:16:33 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:16:33 --> Helper loaded: security_helper
INFO - 2024-04-14 05:16:33 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:16:33 --> Database Driver Class Initialized
INFO - 2024-04-14 05:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:16:33 --> Parser Class Initialized
INFO - 2024-04-14 05:16:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:16:33 --> Pagination Class Initialized
INFO - 2024-04-14 05:16:33 --> Form Validation Class Initialized
INFO - 2024-04-14 05:16:33 --> Controller Class Initialized
INFO - 2024-04-14 05:16:33 --> Model Class Initialized
DEBUG - 2024-04-14 05:16:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 05:16:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:16:33 --> Model Class Initialized
DEBUG - 2024-04-14 05:16:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:16:33 --> Model Class Initialized
INFO - 2024-04-14 05:16:33 --> Final output sent to browser
DEBUG - 2024-04-14 05:16:33 --> Total execution time: 0.0508
ERROR - 2024-04-14 05:16:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:16:34 --> Config Class Initialized
INFO - 2024-04-14 05:16:34 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:16:34 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:16:34 --> Utf8 Class Initialized
INFO - 2024-04-14 05:16:34 --> URI Class Initialized
INFO - 2024-04-14 05:16:34 --> Router Class Initialized
INFO - 2024-04-14 05:16:34 --> Output Class Initialized
INFO - 2024-04-14 05:16:34 --> Security Class Initialized
DEBUG - 2024-04-14 05:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:16:34 --> Input Class Initialized
INFO - 2024-04-14 05:16:34 --> Language Class Initialized
INFO - 2024-04-14 05:16:34 --> Loader Class Initialized
INFO - 2024-04-14 05:16:34 --> Helper loaded: url_helper
INFO - 2024-04-14 05:16:34 --> Helper loaded: file_helper
INFO - 2024-04-14 05:16:34 --> Helper loaded: html_helper
INFO - 2024-04-14 05:16:34 --> Helper loaded: text_helper
INFO - 2024-04-14 05:16:34 --> Helper loaded: form_helper
INFO - 2024-04-14 05:16:34 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:16:34 --> Helper loaded: security_helper
INFO - 2024-04-14 05:16:34 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:16:34 --> Database Driver Class Initialized
INFO - 2024-04-14 05:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:16:34 --> Parser Class Initialized
INFO - 2024-04-14 05:16:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:16:34 --> Pagination Class Initialized
INFO - 2024-04-14 05:16:34 --> Form Validation Class Initialized
INFO - 2024-04-14 05:16:34 --> Controller Class Initialized
INFO - 2024-04-14 05:16:34 --> Model Class Initialized
DEBUG - 2024-04-14 05:16:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 05:16:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:16:34 --> Model Class Initialized
DEBUG - 2024-04-14 05:16:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:16:34 --> Model Class Initialized
INFO - 2024-04-14 05:16:34 --> Final output sent to browser
DEBUG - 2024-04-14 05:16:34 --> Total execution time: 0.0712
ERROR - 2024-04-14 05:16:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:16:35 --> Config Class Initialized
INFO - 2024-04-14 05:16:35 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:16:35 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:16:35 --> Utf8 Class Initialized
INFO - 2024-04-14 05:16:35 --> URI Class Initialized
INFO - 2024-04-14 05:16:35 --> Router Class Initialized
INFO - 2024-04-14 05:16:35 --> Output Class Initialized
INFO - 2024-04-14 05:16:35 --> Security Class Initialized
DEBUG - 2024-04-14 05:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:16:35 --> Input Class Initialized
INFO - 2024-04-14 05:16:35 --> Language Class Initialized
INFO - 2024-04-14 05:16:35 --> Loader Class Initialized
INFO - 2024-04-14 05:16:35 --> Helper loaded: url_helper
INFO - 2024-04-14 05:16:35 --> Helper loaded: file_helper
INFO - 2024-04-14 05:16:35 --> Helper loaded: html_helper
INFO - 2024-04-14 05:16:35 --> Helper loaded: text_helper
INFO - 2024-04-14 05:16:35 --> Helper loaded: form_helper
INFO - 2024-04-14 05:16:35 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:16:35 --> Helper loaded: security_helper
INFO - 2024-04-14 05:16:35 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:16:35 --> Database Driver Class Initialized
INFO - 2024-04-14 05:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:16:35 --> Parser Class Initialized
INFO - 2024-04-14 05:16:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:16:35 --> Pagination Class Initialized
INFO - 2024-04-14 05:16:35 --> Form Validation Class Initialized
INFO - 2024-04-14 05:16:35 --> Controller Class Initialized
INFO - 2024-04-14 05:16:35 --> Model Class Initialized
DEBUG - 2024-04-14 05:16:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 05:16:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:16:35 --> Model Class Initialized
DEBUG - 2024-04-14 05:16:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:16:35 --> Model Class Initialized
INFO - 2024-04-14 05:16:35 --> Final output sent to browser
DEBUG - 2024-04-14 05:16:35 --> Total execution time: 0.0621
ERROR - 2024-04-14 05:16:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:16:36 --> Config Class Initialized
INFO - 2024-04-14 05:16:36 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:16:36 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:16:36 --> Utf8 Class Initialized
INFO - 2024-04-14 05:16:36 --> URI Class Initialized
INFO - 2024-04-14 05:16:36 --> Router Class Initialized
INFO - 2024-04-14 05:16:36 --> Output Class Initialized
INFO - 2024-04-14 05:16:36 --> Security Class Initialized
DEBUG - 2024-04-14 05:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:16:36 --> Input Class Initialized
INFO - 2024-04-14 05:16:36 --> Language Class Initialized
INFO - 2024-04-14 05:16:36 --> Loader Class Initialized
INFO - 2024-04-14 05:16:36 --> Helper loaded: url_helper
INFO - 2024-04-14 05:16:36 --> Helper loaded: file_helper
INFO - 2024-04-14 05:16:36 --> Helper loaded: html_helper
INFO - 2024-04-14 05:16:36 --> Helper loaded: text_helper
INFO - 2024-04-14 05:16:36 --> Helper loaded: form_helper
INFO - 2024-04-14 05:16:36 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:16:36 --> Helper loaded: security_helper
INFO - 2024-04-14 05:16:36 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:16:36 --> Database Driver Class Initialized
INFO - 2024-04-14 05:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:16:36 --> Parser Class Initialized
INFO - 2024-04-14 05:16:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:16:36 --> Pagination Class Initialized
INFO - 2024-04-14 05:16:36 --> Form Validation Class Initialized
INFO - 2024-04-14 05:16:36 --> Controller Class Initialized
INFO - 2024-04-14 05:16:36 --> Model Class Initialized
DEBUG - 2024-04-14 05:16:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 05:16:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:16:36 --> Model Class Initialized
DEBUG - 2024-04-14 05:16:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:16:36 --> Model Class Initialized
INFO - 2024-04-14 05:16:36 --> Final output sent to browser
DEBUG - 2024-04-14 05:16:36 --> Total execution time: 0.0714
ERROR - 2024-04-14 05:16:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:16:53 --> Config Class Initialized
INFO - 2024-04-14 05:16:53 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:16:53 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:16:53 --> Utf8 Class Initialized
INFO - 2024-04-14 05:16:53 --> URI Class Initialized
INFO - 2024-04-14 05:16:53 --> Router Class Initialized
INFO - 2024-04-14 05:16:53 --> Output Class Initialized
INFO - 2024-04-14 05:16:53 --> Security Class Initialized
DEBUG - 2024-04-14 05:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:16:53 --> Input Class Initialized
INFO - 2024-04-14 05:16:53 --> Language Class Initialized
INFO - 2024-04-14 05:16:53 --> Loader Class Initialized
INFO - 2024-04-14 05:16:53 --> Helper loaded: url_helper
INFO - 2024-04-14 05:16:53 --> Helper loaded: file_helper
INFO - 2024-04-14 05:16:53 --> Helper loaded: html_helper
INFO - 2024-04-14 05:16:53 --> Helper loaded: text_helper
INFO - 2024-04-14 05:16:53 --> Helper loaded: form_helper
INFO - 2024-04-14 05:16:53 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:16:53 --> Helper loaded: security_helper
INFO - 2024-04-14 05:16:53 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:16:53 --> Database Driver Class Initialized
INFO - 2024-04-14 05:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:16:53 --> Parser Class Initialized
INFO - 2024-04-14 05:16:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:16:53 --> Pagination Class Initialized
INFO - 2024-04-14 05:16:53 --> Form Validation Class Initialized
INFO - 2024-04-14 05:16:53 --> Controller Class Initialized
INFO - 2024-04-14 05:16:53 --> Model Class Initialized
DEBUG - 2024-04-14 05:16:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 05:16:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:16:53 --> Model Class Initialized
DEBUG - 2024-04-14 05:16:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:16:53 --> Model Class Initialized
INFO - 2024-04-14 05:16:53 --> Final output sent to browser
DEBUG - 2024-04-14 05:16:53 --> Total execution time: 0.0895
ERROR - 2024-04-14 05:17:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:17:09 --> Config Class Initialized
INFO - 2024-04-14 05:17:09 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:17:09 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:17:09 --> Utf8 Class Initialized
INFO - 2024-04-14 05:17:09 --> URI Class Initialized
INFO - 2024-04-14 05:17:09 --> Router Class Initialized
INFO - 2024-04-14 05:17:09 --> Output Class Initialized
INFO - 2024-04-14 05:17:09 --> Security Class Initialized
DEBUG - 2024-04-14 05:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:17:09 --> Input Class Initialized
INFO - 2024-04-14 05:17:09 --> Language Class Initialized
INFO - 2024-04-14 05:17:09 --> Loader Class Initialized
INFO - 2024-04-14 05:17:09 --> Helper loaded: url_helper
INFO - 2024-04-14 05:17:09 --> Helper loaded: file_helper
INFO - 2024-04-14 05:17:09 --> Helper loaded: html_helper
INFO - 2024-04-14 05:17:09 --> Helper loaded: text_helper
INFO - 2024-04-14 05:17:09 --> Helper loaded: form_helper
INFO - 2024-04-14 05:17:09 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:17:09 --> Helper loaded: security_helper
INFO - 2024-04-14 05:17:09 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:17:09 --> Database Driver Class Initialized
INFO - 2024-04-14 05:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:17:09 --> Parser Class Initialized
INFO - 2024-04-14 05:17:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:17:09 --> Pagination Class Initialized
INFO - 2024-04-14 05:17:09 --> Form Validation Class Initialized
INFO - 2024-04-14 05:17:09 --> Controller Class Initialized
INFO - 2024-04-14 05:17:09 --> Model Class Initialized
DEBUG - 2024-04-14 05:17:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 05:17:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:17:09 --> Model Class Initialized
DEBUG - 2024-04-14 05:17:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:17:09 --> Model Class Initialized
DEBUG - 2024-04-14 05:17:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:17:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-04-14 05:17:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:17:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 05:17:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 05:17:09 --> Model Class Initialized
INFO - 2024-04-14 05:17:09 --> Model Class Initialized
INFO - 2024-04-14 05:17:09 --> Model Class Initialized
INFO - 2024-04-14 05:17:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-14 05:17:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-14 05:17:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 05:17:10 --> Final output sent to browser
DEBUG - 2024-04-14 05:17:10 --> Total execution time: 0.3165
ERROR - 2024-04-14 05:18:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:18:00 --> Config Class Initialized
INFO - 2024-04-14 05:18:00 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:18:00 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:18:00 --> Utf8 Class Initialized
INFO - 2024-04-14 05:18:00 --> URI Class Initialized
INFO - 2024-04-14 05:18:00 --> Router Class Initialized
INFO - 2024-04-14 05:18:00 --> Output Class Initialized
INFO - 2024-04-14 05:18:00 --> Security Class Initialized
DEBUG - 2024-04-14 05:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:18:00 --> Input Class Initialized
INFO - 2024-04-14 05:18:00 --> Language Class Initialized
INFO - 2024-04-14 05:18:00 --> Loader Class Initialized
INFO - 2024-04-14 05:18:00 --> Helper loaded: url_helper
INFO - 2024-04-14 05:18:00 --> Helper loaded: file_helper
INFO - 2024-04-14 05:18:00 --> Helper loaded: html_helper
INFO - 2024-04-14 05:18:00 --> Helper loaded: text_helper
INFO - 2024-04-14 05:18:00 --> Helper loaded: form_helper
INFO - 2024-04-14 05:18:00 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:18:00 --> Helper loaded: security_helper
INFO - 2024-04-14 05:18:00 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:18:00 --> Database Driver Class Initialized
INFO - 2024-04-14 05:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:18:00 --> Parser Class Initialized
INFO - 2024-04-14 05:18:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:18:00 --> Pagination Class Initialized
INFO - 2024-04-14 05:18:00 --> Form Validation Class Initialized
INFO - 2024-04-14 05:18:00 --> Controller Class Initialized
INFO - 2024-04-14 05:18:00 --> Model Class Initialized
DEBUG - 2024-04-14 05:18:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 05:18:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:18:00 --> Model Class Initialized
DEBUG - 2024-04-14 05:18:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:18:00 --> Model Class Initialized
INFO - 2024-04-14 05:18:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-04-14 05:18:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:18:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 05:18:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 05:18:00 --> Model Class Initialized
INFO - 2024-04-14 05:18:00 --> Model Class Initialized
INFO - 2024-04-14 05:18:00 --> Model Class Initialized
INFO - 2024-04-14 05:18:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-14 05:18:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-14 05:18:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 05:18:00 --> Final output sent to browser
DEBUG - 2024-04-14 05:18:00 --> Total execution time: 0.2989
ERROR - 2024-04-14 05:18:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:18:01 --> Config Class Initialized
INFO - 2024-04-14 05:18:01 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:18:01 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:18:01 --> Utf8 Class Initialized
INFO - 2024-04-14 05:18:01 --> URI Class Initialized
INFO - 2024-04-14 05:18:01 --> Router Class Initialized
INFO - 2024-04-14 05:18:01 --> Output Class Initialized
INFO - 2024-04-14 05:18:01 --> Security Class Initialized
DEBUG - 2024-04-14 05:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:18:01 --> Input Class Initialized
INFO - 2024-04-14 05:18:01 --> Language Class Initialized
INFO - 2024-04-14 05:18:01 --> Loader Class Initialized
INFO - 2024-04-14 05:18:01 --> Helper loaded: url_helper
INFO - 2024-04-14 05:18:01 --> Helper loaded: file_helper
INFO - 2024-04-14 05:18:01 --> Helper loaded: html_helper
INFO - 2024-04-14 05:18:01 --> Helper loaded: text_helper
INFO - 2024-04-14 05:18:01 --> Helper loaded: form_helper
INFO - 2024-04-14 05:18:01 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:18:01 --> Helper loaded: security_helper
INFO - 2024-04-14 05:18:01 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:18:01 --> Database Driver Class Initialized
INFO - 2024-04-14 05:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:18:01 --> Parser Class Initialized
INFO - 2024-04-14 05:18:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:18:01 --> Pagination Class Initialized
INFO - 2024-04-14 05:18:01 --> Form Validation Class Initialized
INFO - 2024-04-14 05:18:01 --> Controller Class Initialized
INFO - 2024-04-14 05:18:01 --> Model Class Initialized
DEBUG - 2024-04-14 05:18:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 05:18:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:18:01 --> Model Class Initialized
DEBUG - 2024-04-14 05:18:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:18:01 --> Model Class Initialized
INFO - 2024-04-14 05:18:01 --> Final output sent to browser
DEBUG - 2024-04-14 05:18:01 --> Total execution time: 0.0456
ERROR - 2024-04-14 05:18:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:18:08 --> Config Class Initialized
INFO - 2024-04-14 05:18:08 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:18:08 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:18:08 --> Utf8 Class Initialized
INFO - 2024-04-14 05:18:08 --> URI Class Initialized
INFO - 2024-04-14 05:18:08 --> Router Class Initialized
INFO - 2024-04-14 05:18:08 --> Output Class Initialized
INFO - 2024-04-14 05:18:08 --> Security Class Initialized
DEBUG - 2024-04-14 05:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:18:08 --> Input Class Initialized
INFO - 2024-04-14 05:18:08 --> Language Class Initialized
INFO - 2024-04-14 05:18:08 --> Loader Class Initialized
INFO - 2024-04-14 05:18:08 --> Helper loaded: url_helper
INFO - 2024-04-14 05:18:08 --> Helper loaded: file_helper
INFO - 2024-04-14 05:18:08 --> Helper loaded: html_helper
INFO - 2024-04-14 05:18:08 --> Helper loaded: text_helper
INFO - 2024-04-14 05:18:08 --> Helper loaded: form_helper
INFO - 2024-04-14 05:18:08 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:18:08 --> Helper loaded: security_helper
INFO - 2024-04-14 05:18:08 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:18:08 --> Database Driver Class Initialized
INFO - 2024-04-14 05:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:18:08 --> Parser Class Initialized
INFO - 2024-04-14 05:18:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:18:08 --> Pagination Class Initialized
INFO - 2024-04-14 05:18:08 --> Form Validation Class Initialized
INFO - 2024-04-14 05:18:08 --> Controller Class Initialized
INFO - 2024-04-14 05:18:08 --> Model Class Initialized
DEBUG - 2024-04-14 05:18:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 05:18:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:18:08 --> Model Class Initialized
DEBUG - 2024-04-14 05:18:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:18:08 --> Model Class Initialized
INFO - 2024-04-14 05:18:08 --> Final output sent to browser
DEBUG - 2024-04-14 05:18:08 --> Total execution time: 0.0519
ERROR - 2024-04-14 05:18:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:18:08 --> Config Class Initialized
INFO - 2024-04-14 05:18:08 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:18:08 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:18:08 --> Utf8 Class Initialized
INFO - 2024-04-14 05:18:08 --> URI Class Initialized
INFO - 2024-04-14 05:18:08 --> Router Class Initialized
INFO - 2024-04-14 05:18:08 --> Output Class Initialized
INFO - 2024-04-14 05:18:08 --> Security Class Initialized
DEBUG - 2024-04-14 05:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:18:08 --> Input Class Initialized
INFO - 2024-04-14 05:18:08 --> Language Class Initialized
INFO - 2024-04-14 05:18:08 --> Loader Class Initialized
INFO - 2024-04-14 05:18:08 --> Helper loaded: url_helper
INFO - 2024-04-14 05:18:08 --> Helper loaded: file_helper
INFO - 2024-04-14 05:18:08 --> Helper loaded: html_helper
INFO - 2024-04-14 05:18:08 --> Helper loaded: text_helper
INFO - 2024-04-14 05:18:08 --> Helper loaded: form_helper
INFO - 2024-04-14 05:18:08 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:18:08 --> Helper loaded: security_helper
INFO - 2024-04-14 05:18:08 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:18:08 --> Database Driver Class Initialized
INFO - 2024-04-14 05:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:18:08 --> Parser Class Initialized
INFO - 2024-04-14 05:18:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:18:08 --> Pagination Class Initialized
INFO - 2024-04-14 05:18:08 --> Form Validation Class Initialized
INFO - 2024-04-14 05:18:08 --> Controller Class Initialized
INFO - 2024-04-14 05:18:08 --> Model Class Initialized
DEBUG - 2024-04-14 05:18:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 05:18:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:18:08 --> Model Class Initialized
DEBUG - 2024-04-14 05:18:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:18:08 --> Model Class Initialized
INFO - 2024-04-14 05:18:08 --> Final output sent to browser
DEBUG - 2024-04-14 05:18:08 --> Total execution time: 0.0593
ERROR - 2024-04-14 05:18:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:18:09 --> Config Class Initialized
INFO - 2024-04-14 05:18:09 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:18:09 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:18:09 --> Utf8 Class Initialized
INFO - 2024-04-14 05:18:09 --> URI Class Initialized
INFO - 2024-04-14 05:18:09 --> Router Class Initialized
INFO - 2024-04-14 05:18:09 --> Output Class Initialized
INFO - 2024-04-14 05:18:09 --> Security Class Initialized
DEBUG - 2024-04-14 05:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:18:09 --> Input Class Initialized
INFO - 2024-04-14 05:18:09 --> Language Class Initialized
INFO - 2024-04-14 05:18:09 --> Loader Class Initialized
INFO - 2024-04-14 05:18:09 --> Helper loaded: url_helper
INFO - 2024-04-14 05:18:09 --> Helper loaded: file_helper
INFO - 2024-04-14 05:18:09 --> Helper loaded: html_helper
INFO - 2024-04-14 05:18:09 --> Helper loaded: text_helper
INFO - 2024-04-14 05:18:09 --> Helper loaded: form_helper
INFO - 2024-04-14 05:18:09 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:18:09 --> Helper loaded: security_helper
INFO - 2024-04-14 05:18:09 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:18:09 --> Database Driver Class Initialized
INFO - 2024-04-14 05:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:18:09 --> Parser Class Initialized
INFO - 2024-04-14 05:18:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:18:09 --> Pagination Class Initialized
INFO - 2024-04-14 05:18:09 --> Form Validation Class Initialized
INFO - 2024-04-14 05:18:09 --> Controller Class Initialized
INFO - 2024-04-14 05:18:09 --> Model Class Initialized
DEBUG - 2024-04-14 05:18:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 05:18:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:18:09 --> Model Class Initialized
DEBUG - 2024-04-14 05:18:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:18:09 --> Model Class Initialized
INFO - 2024-04-14 05:18:09 --> Final output sent to browser
DEBUG - 2024-04-14 05:18:09 --> Total execution time: 0.0577
ERROR - 2024-04-14 05:18:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:18:10 --> Config Class Initialized
INFO - 2024-04-14 05:18:10 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:18:10 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:18:10 --> Utf8 Class Initialized
INFO - 2024-04-14 05:18:10 --> URI Class Initialized
INFO - 2024-04-14 05:18:10 --> Router Class Initialized
INFO - 2024-04-14 05:18:10 --> Output Class Initialized
INFO - 2024-04-14 05:18:10 --> Security Class Initialized
DEBUG - 2024-04-14 05:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:18:10 --> Input Class Initialized
INFO - 2024-04-14 05:18:10 --> Language Class Initialized
INFO - 2024-04-14 05:18:10 --> Loader Class Initialized
INFO - 2024-04-14 05:18:10 --> Helper loaded: url_helper
INFO - 2024-04-14 05:18:10 --> Helper loaded: file_helper
INFO - 2024-04-14 05:18:10 --> Helper loaded: html_helper
INFO - 2024-04-14 05:18:10 --> Helper loaded: text_helper
INFO - 2024-04-14 05:18:10 --> Helper loaded: form_helper
INFO - 2024-04-14 05:18:10 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:18:10 --> Helper loaded: security_helper
INFO - 2024-04-14 05:18:10 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:18:10 --> Database Driver Class Initialized
INFO - 2024-04-14 05:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:18:10 --> Parser Class Initialized
INFO - 2024-04-14 05:18:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:18:10 --> Pagination Class Initialized
INFO - 2024-04-14 05:18:10 --> Form Validation Class Initialized
INFO - 2024-04-14 05:18:10 --> Controller Class Initialized
INFO - 2024-04-14 05:18:10 --> Model Class Initialized
DEBUG - 2024-04-14 05:18:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 05:18:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:18:10 --> Model Class Initialized
DEBUG - 2024-04-14 05:18:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:18:10 --> Model Class Initialized
INFO - 2024-04-14 05:18:10 --> Final output sent to browser
DEBUG - 2024-04-14 05:18:10 --> Total execution time: 0.0621
ERROR - 2024-04-14 05:18:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:18:18 --> Config Class Initialized
INFO - 2024-04-14 05:18:18 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:18:18 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:18:18 --> Utf8 Class Initialized
INFO - 2024-04-14 05:18:18 --> URI Class Initialized
INFO - 2024-04-14 05:18:18 --> Router Class Initialized
INFO - 2024-04-14 05:18:18 --> Output Class Initialized
INFO - 2024-04-14 05:18:18 --> Security Class Initialized
DEBUG - 2024-04-14 05:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:18:18 --> Input Class Initialized
INFO - 2024-04-14 05:18:18 --> Language Class Initialized
INFO - 2024-04-14 05:18:18 --> Loader Class Initialized
INFO - 2024-04-14 05:18:18 --> Helper loaded: url_helper
INFO - 2024-04-14 05:18:18 --> Helper loaded: file_helper
INFO - 2024-04-14 05:18:18 --> Helper loaded: html_helper
INFO - 2024-04-14 05:18:18 --> Helper loaded: text_helper
INFO - 2024-04-14 05:18:18 --> Helper loaded: form_helper
INFO - 2024-04-14 05:18:18 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:18:18 --> Helper loaded: security_helper
INFO - 2024-04-14 05:18:18 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:18:18 --> Database Driver Class Initialized
INFO - 2024-04-14 05:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:18:18 --> Parser Class Initialized
INFO - 2024-04-14 05:18:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:18:18 --> Pagination Class Initialized
INFO - 2024-04-14 05:18:18 --> Form Validation Class Initialized
INFO - 2024-04-14 05:18:18 --> Controller Class Initialized
INFO - 2024-04-14 05:18:18 --> Model Class Initialized
DEBUG - 2024-04-14 05:18:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 05:18:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:18:18 --> Model Class Initialized
DEBUG - 2024-04-14 05:18:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:18:18 --> Model Class Initialized
DEBUG - 2024-04-14 05:18:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:18:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-04-14 05:18:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:18:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 05:18:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 05:18:18 --> Model Class Initialized
INFO - 2024-04-14 05:18:18 --> Model Class Initialized
INFO - 2024-04-14 05:18:18 --> Model Class Initialized
INFO - 2024-04-14 05:18:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-14 05:18:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-14 05:18:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 05:18:19 --> Final output sent to browser
DEBUG - 2024-04-14 05:18:19 --> Total execution time: 0.3135
ERROR - 2024-04-14 05:18:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:18:25 --> Config Class Initialized
INFO - 2024-04-14 05:18:25 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:18:25 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:18:25 --> Utf8 Class Initialized
INFO - 2024-04-14 05:18:25 --> URI Class Initialized
INFO - 2024-04-14 05:18:25 --> Router Class Initialized
INFO - 2024-04-14 05:18:25 --> Output Class Initialized
INFO - 2024-04-14 05:18:25 --> Security Class Initialized
DEBUG - 2024-04-14 05:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:18:25 --> Input Class Initialized
INFO - 2024-04-14 05:18:25 --> Language Class Initialized
INFO - 2024-04-14 05:18:25 --> Loader Class Initialized
INFO - 2024-04-14 05:18:25 --> Helper loaded: url_helper
INFO - 2024-04-14 05:18:25 --> Helper loaded: file_helper
INFO - 2024-04-14 05:18:25 --> Helper loaded: html_helper
INFO - 2024-04-14 05:18:25 --> Helper loaded: text_helper
INFO - 2024-04-14 05:18:25 --> Helper loaded: form_helper
INFO - 2024-04-14 05:18:25 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:18:25 --> Helper loaded: security_helper
INFO - 2024-04-14 05:18:25 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:18:25 --> Database Driver Class Initialized
INFO - 2024-04-14 05:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:18:25 --> Parser Class Initialized
INFO - 2024-04-14 05:18:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:18:25 --> Pagination Class Initialized
INFO - 2024-04-14 05:18:25 --> Form Validation Class Initialized
INFO - 2024-04-14 05:18:25 --> Controller Class Initialized
INFO - 2024-04-14 05:18:25 --> Model Class Initialized
DEBUG - 2024-04-14 05:18:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 05:18:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:18:25 --> Model Class Initialized
DEBUG - 2024-04-14 05:18:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:18:25 --> Model Class Initialized
INFO - 2024-04-14 05:18:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-04-14 05:18:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:18:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 05:18:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 05:18:25 --> Model Class Initialized
INFO - 2024-04-14 05:18:25 --> Model Class Initialized
INFO - 2024-04-14 05:18:25 --> Model Class Initialized
INFO - 2024-04-14 05:18:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-14 05:18:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-14 05:18:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 05:18:26 --> Final output sent to browser
DEBUG - 2024-04-14 05:18:26 --> Total execution time: 0.2866
ERROR - 2024-04-14 05:18:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:18:26 --> Config Class Initialized
INFO - 2024-04-14 05:18:26 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:18:26 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:18:26 --> Utf8 Class Initialized
INFO - 2024-04-14 05:18:26 --> URI Class Initialized
INFO - 2024-04-14 05:18:26 --> Router Class Initialized
INFO - 2024-04-14 05:18:26 --> Output Class Initialized
INFO - 2024-04-14 05:18:26 --> Security Class Initialized
DEBUG - 2024-04-14 05:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:18:26 --> Input Class Initialized
INFO - 2024-04-14 05:18:26 --> Language Class Initialized
INFO - 2024-04-14 05:18:26 --> Loader Class Initialized
INFO - 2024-04-14 05:18:26 --> Helper loaded: url_helper
INFO - 2024-04-14 05:18:26 --> Helper loaded: file_helper
INFO - 2024-04-14 05:18:26 --> Helper loaded: html_helper
INFO - 2024-04-14 05:18:26 --> Helper loaded: text_helper
INFO - 2024-04-14 05:18:26 --> Helper loaded: form_helper
INFO - 2024-04-14 05:18:26 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:18:26 --> Helper loaded: security_helper
INFO - 2024-04-14 05:18:26 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:18:26 --> Database Driver Class Initialized
INFO - 2024-04-14 05:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:18:26 --> Parser Class Initialized
INFO - 2024-04-14 05:18:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:18:26 --> Pagination Class Initialized
INFO - 2024-04-14 05:18:26 --> Form Validation Class Initialized
INFO - 2024-04-14 05:18:26 --> Controller Class Initialized
INFO - 2024-04-14 05:18:26 --> Model Class Initialized
DEBUG - 2024-04-14 05:18:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 05:18:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:18:26 --> Model Class Initialized
DEBUG - 2024-04-14 05:18:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:18:26 --> Model Class Initialized
INFO - 2024-04-14 05:18:26 --> Final output sent to browser
DEBUG - 2024-04-14 05:18:26 --> Total execution time: 0.0455
ERROR - 2024-04-14 05:18:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:18:30 --> Config Class Initialized
INFO - 2024-04-14 05:18:30 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:18:30 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:18:30 --> Utf8 Class Initialized
INFO - 2024-04-14 05:18:30 --> URI Class Initialized
INFO - 2024-04-14 05:18:30 --> Router Class Initialized
INFO - 2024-04-14 05:18:30 --> Output Class Initialized
INFO - 2024-04-14 05:18:30 --> Security Class Initialized
DEBUG - 2024-04-14 05:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:18:30 --> Input Class Initialized
INFO - 2024-04-14 05:18:30 --> Language Class Initialized
INFO - 2024-04-14 05:18:30 --> Loader Class Initialized
INFO - 2024-04-14 05:18:30 --> Helper loaded: url_helper
INFO - 2024-04-14 05:18:30 --> Helper loaded: file_helper
INFO - 2024-04-14 05:18:30 --> Helper loaded: html_helper
INFO - 2024-04-14 05:18:30 --> Helper loaded: text_helper
INFO - 2024-04-14 05:18:30 --> Helper loaded: form_helper
INFO - 2024-04-14 05:18:30 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:18:30 --> Helper loaded: security_helper
INFO - 2024-04-14 05:18:30 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:18:30 --> Database Driver Class Initialized
INFO - 2024-04-14 05:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:18:30 --> Parser Class Initialized
INFO - 2024-04-14 05:18:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:18:30 --> Pagination Class Initialized
INFO - 2024-04-14 05:18:30 --> Form Validation Class Initialized
INFO - 2024-04-14 05:18:30 --> Controller Class Initialized
INFO - 2024-04-14 05:18:30 --> Model Class Initialized
DEBUG - 2024-04-14 05:18:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 05:18:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:18:30 --> Model Class Initialized
DEBUG - 2024-04-14 05:18:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:18:30 --> Model Class Initialized
INFO - 2024-04-14 05:18:30 --> Final output sent to browser
DEBUG - 2024-04-14 05:18:30 --> Total execution time: 0.0450
ERROR - 2024-04-14 05:18:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:18:30 --> Config Class Initialized
INFO - 2024-04-14 05:18:30 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:18:30 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:18:30 --> Utf8 Class Initialized
INFO - 2024-04-14 05:18:30 --> URI Class Initialized
INFO - 2024-04-14 05:18:30 --> Router Class Initialized
INFO - 2024-04-14 05:18:30 --> Output Class Initialized
INFO - 2024-04-14 05:18:30 --> Security Class Initialized
DEBUG - 2024-04-14 05:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:18:30 --> Input Class Initialized
INFO - 2024-04-14 05:18:30 --> Language Class Initialized
INFO - 2024-04-14 05:18:30 --> Loader Class Initialized
INFO - 2024-04-14 05:18:30 --> Helper loaded: url_helper
INFO - 2024-04-14 05:18:30 --> Helper loaded: file_helper
INFO - 2024-04-14 05:18:30 --> Helper loaded: html_helper
INFO - 2024-04-14 05:18:30 --> Helper loaded: text_helper
INFO - 2024-04-14 05:18:30 --> Helper loaded: form_helper
INFO - 2024-04-14 05:18:30 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:18:30 --> Helper loaded: security_helper
INFO - 2024-04-14 05:18:30 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:18:30 --> Database Driver Class Initialized
INFO - 2024-04-14 05:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:18:31 --> Parser Class Initialized
INFO - 2024-04-14 05:18:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:18:31 --> Pagination Class Initialized
INFO - 2024-04-14 05:18:31 --> Form Validation Class Initialized
INFO - 2024-04-14 05:18:31 --> Controller Class Initialized
INFO - 2024-04-14 05:18:31 --> Model Class Initialized
DEBUG - 2024-04-14 05:18:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 05:18:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:18:31 --> Model Class Initialized
DEBUG - 2024-04-14 05:18:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:18:31 --> Model Class Initialized
INFO - 2024-04-14 05:18:31 --> Final output sent to browser
DEBUG - 2024-04-14 05:18:31 --> Total execution time: 0.0603
ERROR - 2024-04-14 05:18:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:18:31 --> Config Class Initialized
INFO - 2024-04-14 05:18:31 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:18:31 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:18:31 --> Utf8 Class Initialized
INFO - 2024-04-14 05:18:31 --> URI Class Initialized
INFO - 2024-04-14 05:18:31 --> Router Class Initialized
INFO - 2024-04-14 05:18:31 --> Output Class Initialized
INFO - 2024-04-14 05:18:31 --> Security Class Initialized
DEBUG - 2024-04-14 05:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:18:31 --> Input Class Initialized
INFO - 2024-04-14 05:18:31 --> Language Class Initialized
INFO - 2024-04-14 05:18:31 --> Loader Class Initialized
INFO - 2024-04-14 05:18:31 --> Helper loaded: url_helper
INFO - 2024-04-14 05:18:31 --> Helper loaded: file_helper
INFO - 2024-04-14 05:18:31 --> Helper loaded: html_helper
INFO - 2024-04-14 05:18:31 --> Helper loaded: text_helper
INFO - 2024-04-14 05:18:31 --> Helper loaded: form_helper
INFO - 2024-04-14 05:18:31 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:18:31 --> Helper loaded: security_helper
INFO - 2024-04-14 05:18:31 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:18:31 --> Database Driver Class Initialized
INFO - 2024-04-14 05:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:18:31 --> Parser Class Initialized
INFO - 2024-04-14 05:18:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:18:31 --> Pagination Class Initialized
INFO - 2024-04-14 05:18:31 --> Form Validation Class Initialized
INFO - 2024-04-14 05:18:31 --> Controller Class Initialized
INFO - 2024-04-14 05:18:31 --> Model Class Initialized
DEBUG - 2024-04-14 05:18:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 05:18:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:18:31 --> Model Class Initialized
DEBUG - 2024-04-14 05:18:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:18:31 --> Model Class Initialized
INFO - 2024-04-14 05:18:31 --> Final output sent to browser
DEBUG - 2024-04-14 05:18:31 --> Total execution time: 0.0557
ERROR - 2024-04-14 05:18:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:18:38 --> Config Class Initialized
INFO - 2024-04-14 05:18:38 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:18:38 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:18:38 --> Utf8 Class Initialized
INFO - 2024-04-14 05:18:38 --> URI Class Initialized
INFO - 2024-04-14 05:18:38 --> Router Class Initialized
INFO - 2024-04-14 05:18:38 --> Output Class Initialized
INFO - 2024-04-14 05:18:38 --> Security Class Initialized
DEBUG - 2024-04-14 05:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:18:38 --> Input Class Initialized
INFO - 2024-04-14 05:18:38 --> Language Class Initialized
INFO - 2024-04-14 05:18:38 --> Loader Class Initialized
INFO - 2024-04-14 05:18:38 --> Helper loaded: url_helper
INFO - 2024-04-14 05:18:38 --> Helper loaded: file_helper
INFO - 2024-04-14 05:18:38 --> Helper loaded: html_helper
INFO - 2024-04-14 05:18:38 --> Helper loaded: text_helper
INFO - 2024-04-14 05:18:38 --> Helper loaded: form_helper
INFO - 2024-04-14 05:18:38 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:18:38 --> Helper loaded: security_helper
INFO - 2024-04-14 05:18:38 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:18:38 --> Database Driver Class Initialized
INFO - 2024-04-14 05:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:18:38 --> Parser Class Initialized
INFO - 2024-04-14 05:18:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:18:38 --> Pagination Class Initialized
INFO - 2024-04-14 05:18:38 --> Form Validation Class Initialized
INFO - 2024-04-14 05:18:38 --> Controller Class Initialized
INFO - 2024-04-14 05:18:38 --> Model Class Initialized
DEBUG - 2024-04-14 05:18:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 05:18:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:18:38 --> Model Class Initialized
DEBUG - 2024-04-14 05:18:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:18:38 --> Model Class Initialized
DEBUG - 2024-04-14 05:18:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:18:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-04-14 05:18:38 --> Final output sent to browser
DEBUG - 2024-04-14 05:18:38 --> Total execution time: 0.1800
ERROR - 2024-04-14 05:18:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 05:18:39 --> Config Class Initialized
INFO - 2024-04-14 05:18:39 --> Hooks Class Initialized
DEBUG - 2024-04-14 05:18:39 --> UTF-8 Support Enabled
INFO - 2024-04-14 05:18:39 --> Utf8 Class Initialized
INFO - 2024-04-14 05:18:39 --> URI Class Initialized
INFO - 2024-04-14 05:18:39 --> Router Class Initialized
INFO - 2024-04-14 05:18:39 --> Output Class Initialized
INFO - 2024-04-14 05:18:39 --> Security Class Initialized
DEBUG - 2024-04-14 05:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 05:18:39 --> Input Class Initialized
INFO - 2024-04-14 05:18:39 --> Language Class Initialized
INFO - 2024-04-14 05:18:39 --> Loader Class Initialized
INFO - 2024-04-14 05:18:39 --> Helper loaded: url_helper
INFO - 2024-04-14 05:18:39 --> Helper loaded: file_helper
INFO - 2024-04-14 05:18:39 --> Helper loaded: html_helper
INFO - 2024-04-14 05:18:39 --> Helper loaded: text_helper
INFO - 2024-04-14 05:18:39 --> Helper loaded: form_helper
INFO - 2024-04-14 05:18:39 --> Helper loaded: lang_helper
INFO - 2024-04-14 05:18:39 --> Helper loaded: security_helper
INFO - 2024-04-14 05:18:39 --> Helper loaded: cookie_helper
INFO - 2024-04-14 05:18:39 --> Database Driver Class Initialized
INFO - 2024-04-14 05:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 05:18:39 --> Parser Class Initialized
INFO - 2024-04-14 05:18:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 05:18:39 --> Pagination Class Initialized
INFO - 2024-04-14 05:18:39 --> Form Validation Class Initialized
INFO - 2024-04-14 05:18:39 --> Controller Class Initialized
INFO - 2024-04-14 05:18:39 --> Model Class Initialized
DEBUG - 2024-04-14 05:18:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 05:18:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:18:39 --> Model Class Initialized
DEBUG - 2024-04-14 05:18:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:18:39 --> Model Class Initialized
DEBUG - 2024-04-14 05:18:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 05:18:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 05:18:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-04-14 05:18:39 --> Final output sent to browser
DEBUG - 2024-04-14 05:18:39 --> Total execution time: 0.1848
ERROR - 2024-04-14 06:52:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:52:15 --> Config Class Initialized
INFO - 2024-04-14 06:52:15 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:52:15 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:52:15 --> Utf8 Class Initialized
INFO - 2024-04-14 06:52:15 --> URI Class Initialized
DEBUG - 2024-04-14 06:52:15 --> No URI present. Default controller set.
INFO - 2024-04-14 06:52:15 --> Router Class Initialized
INFO - 2024-04-14 06:52:15 --> Output Class Initialized
INFO - 2024-04-14 06:52:15 --> Security Class Initialized
DEBUG - 2024-04-14 06:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:52:15 --> Input Class Initialized
INFO - 2024-04-14 06:52:15 --> Language Class Initialized
INFO - 2024-04-14 06:52:15 --> Loader Class Initialized
INFO - 2024-04-14 06:52:15 --> Helper loaded: url_helper
INFO - 2024-04-14 06:52:15 --> Helper loaded: file_helper
INFO - 2024-04-14 06:52:15 --> Helper loaded: html_helper
INFO - 2024-04-14 06:52:15 --> Helper loaded: text_helper
INFO - 2024-04-14 06:52:15 --> Helper loaded: form_helper
INFO - 2024-04-14 06:52:15 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:52:15 --> Helper loaded: security_helper
INFO - 2024-04-14 06:52:15 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:52:15 --> Database Driver Class Initialized
INFO - 2024-04-14 06:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:52:15 --> Parser Class Initialized
INFO - 2024-04-14 06:52:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:52:15 --> Pagination Class Initialized
INFO - 2024-04-14 06:52:15 --> Form Validation Class Initialized
INFO - 2024-04-14 06:52:15 --> Controller Class Initialized
INFO - 2024-04-14 06:52:15 --> Model Class Initialized
DEBUG - 2024-04-14 06:52:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:52:15 --> Model Class Initialized
DEBUG - 2024-04-14 06:52:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:52:15 --> Model Class Initialized
INFO - 2024-04-14 06:52:15 --> Model Class Initialized
INFO - 2024-04-14 06:52:15 --> Model Class Initialized
INFO - 2024-04-14 06:52:15 --> Model Class Initialized
DEBUG - 2024-04-14 06:52:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:52:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:52:15 --> Model Class Initialized
INFO - 2024-04-14 06:52:15 --> Model Class Initialized
INFO - 2024-04-14 06:52:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-14 06:52:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:52:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 06:52:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 06:52:15 --> Model Class Initialized
INFO - 2024-04-14 06:52:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-14 06:52:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-14 06:52:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 06:52:15 --> Final output sent to browser
DEBUG - 2024-04-14 06:52:15 --> Total execution time: 0.6196
ERROR - 2024-04-14 06:54:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:54:11 --> Config Class Initialized
INFO - 2024-04-14 06:54:11 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:54:11 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:54:11 --> Utf8 Class Initialized
INFO - 2024-04-14 06:54:11 --> URI Class Initialized
INFO - 2024-04-14 06:54:11 --> Router Class Initialized
INFO - 2024-04-14 06:54:11 --> Output Class Initialized
INFO - 2024-04-14 06:54:11 --> Security Class Initialized
DEBUG - 2024-04-14 06:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:54:11 --> Input Class Initialized
INFO - 2024-04-14 06:54:11 --> Language Class Initialized
INFO - 2024-04-14 06:54:11 --> Loader Class Initialized
INFO - 2024-04-14 06:54:11 --> Helper loaded: url_helper
INFO - 2024-04-14 06:54:11 --> Helper loaded: file_helper
INFO - 2024-04-14 06:54:11 --> Helper loaded: html_helper
INFO - 2024-04-14 06:54:11 --> Helper loaded: text_helper
INFO - 2024-04-14 06:54:11 --> Helper loaded: form_helper
INFO - 2024-04-14 06:54:11 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:54:11 --> Helper loaded: security_helper
INFO - 2024-04-14 06:54:11 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:54:11 --> Database Driver Class Initialized
INFO - 2024-04-14 06:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:54:11 --> Parser Class Initialized
INFO - 2024-04-14 06:54:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:54:11 --> Pagination Class Initialized
INFO - 2024-04-14 06:54:11 --> Form Validation Class Initialized
INFO - 2024-04-14 06:54:11 --> Controller Class Initialized
INFO - 2024-04-14 06:54:11 --> Model Class Initialized
DEBUG - 2024-04-14 06:54:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:54:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:54:11 --> Model Class Initialized
DEBUG - 2024-04-14 06:54:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:54:11 --> Model Class Initialized
INFO - 2024-04-14 06:54:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-04-14 06:54:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:54:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 06:54:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 06:54:11 --> Model Class Initialized
INFO - 2024-04-14 06:54:11 --> Model Class Initialized
INFO - 2024-04-14 06:54:11 --> Model Class Initialized
INFO - 2024-04-14 06:54:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-14 06:54:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-14 06:54:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 06:54:12 --> Final output sent to browser
DEBUG - 2024-04-14 06:54:12 --> Total execution time: 0.2866
ERROR - 2024-04-14 06:54:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:54:12 --> Config Class Initialized
INFO - 2024-04-14 06:54:12 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:54:12 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:54:12 --> Utf8 Class Initialized
INFO - 2024-04-14 06:54:12 --> URI Class Initialized
INFO - 2024-04-14 06:54:12 --> Router Class Initialized
INFO - 2024-04-14 06:54:12 --> Output Class Initialized
INFO - 2024-04-14 06:54:12 --> Security Class Initialized
DEBUG - 2024-04-14 06:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:54:12 --> Input Class Initialized
INFO - 2024-04-14 06:54:12 --> Language Class Initialized
INFO - 2024-04-14 06:54:12 --> Loader Class Initialized
INFO - 2024-04-14 06:54:12 --> Helper loaded: url_helper
INFO - 2024-04-14 06:54:12 --> Helper loaded: file_helper
INFO - 2024-04-14 06:54:12 --> Helper loaded: html_helper
INFO - 2024-04-14 06:54:12 --> Helper loaded: text_helper
INFO - 2024-04-14 06:54:12 --> Helper loaded: form_helper
INFO - 2024-04-14 06:54:12 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:54:12 --> Helper loaded: security_helper
INFO - 2024-04-14 06:54:12 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:54:12 --> Database Driver Class Initialized
INFO - 2024-04-14 06:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:54:12 --> Parser Class Initialized
INFO - 2024-04-14 06:54:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:54:12 --> Pagination Class Initialized
INFO - 2024-04-14 06:54:12 --> Form Validation Class Initialized
INFO - 2024-04-14 06:54:12 --> Controller Class Initialized
INFO - 2024-04-14 06:54:12 --> Model Class Initialized
DEBUG - 2024-04-14 06:54:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:54:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:54:12 --> Model Class Initialized
DEBUG - 2024-04-14 06:54:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:54:12 --> Model Class Initialized
INFO - 2024-04-14 06:54:12 --> Final output sent to browser
DEBUG - 2024-04-14 06:54:12 --> Total execution time: 0.0463
ERROR - 2024-04-14 06:54:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:54:15 --> Config Class Initialized
INFO - 2024-04-14 06:54:15 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:54:15 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:54:15 --> Utf8 Class Initialized
INFO - 2024-04-14 06:54:15 --> URI Class Initialized
INFO - 2024-04-14 06:54:15 --> Router Class Initialized
INFO - 2024-04-14 06:54:15 --> Output Class Initialized
INFO - 2024-04-14 06:54:15 --> Security Class Initialized
DEBUG - 2024-04-14 06:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:54:15 --> Input Class Initialized
INFO - 2024-04-14 06:54:15 --> Language Class Initialized
INFO - 2024-04-14 06:54:15 --> Loader Class Initialized
INFO - 2024-04-14 06:54:15 --> Helper loaded: url_helper
INFO - 2024-04-14 06:54:15 --> Helper loaded: file_helper
INFO - 2024-04-14 06:54:15 --> Helper loaded: html_helper
INFO - 2024-04-14 06:54:15 --> Helper loaded: text_helper
INFO - 2024-04-14 06:54:15 --> Helper loaded: form_helper
INFO - 2024-04-14 06:54:15 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:54:15 --> Helper loaded: security_helper
INFO - 2024-04-14 06:54:15 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:54:15 --> Database Driver Class Initialized
INFO - 2024-04-14 06:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:54:15 --> Parser Class Initialized
INFO - 2024-04-14 06:54:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:54:15 --> Pagination Class Initialized
INFO - 2024-04-14 06:54:15 --> Form Validation Class Initialized
INFO - 2024-04-14 06:54:15 --> Controller Class Initialized
INFO - 2024-04-14 06:54:15 --> Model Class Initialized
DEBUG - 2024-04-14 06:54:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:54:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:54:15 --> Model Class Initialized
DEBUG - 2024-04-14 06:54:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:54:15 --> Model Class Initialized
INFO - 2024-04-14 06:54:17 --> Final output sent to browser
DEBUG - 2024-04-14 06:54:17 --> Total execution time: 1.2842
ERROR - 2024-04-14 06:54:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:54:46 --> Config Class Initialized
INFO - 2024-04-14 06:54:46 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:54:46 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:54:46 --> Utf8 Class Initialized
INFO - 2024-04-14 06:54:46 --> URI Class Initialized
INFO - 2024-04-14 06:54:46 --> Router Class Initialized
INFO - 2024-04-14 06:54:46 --> Output Class Initialized
INFO - 2024-04-14 06:54:46 --> Security Class Initialized
DEBUG - 2024-04-14 06:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:54:46 --> Input Class Initialized
INFO - 2024-04-14 06:54:46 --> Language Class Initialized
INFO - 2024-04-14 06:54:46 --> Loader Class Initialized
INFO - 2024-04-14 06:54:46 --> Helper loaded: url_helper
INFO - 2024-04-14 06:54:46 --> Helper loaded: file_helper
INFO - 2024-04-14 06:54:46 --> Helper loaded: html_helper
INFO - 2024-04-14 06:54:46 --> Helper loaded: text_helper
INFO - 2024-04-14 06:54:46 --> Helper loaded: form_helper
INFO - 2024-04-14 06:54:46 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:54:46 --> Helper loaded: security_helper
INFO - 2024-04-14 06:54:46 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:54:46 --> Database Driver Class Initialized
INFO - 2024-04-14 06:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:54:46 --> Parser Class Initialized
INFO - 2024-04-14 06:54:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:54:46 --> Pagination Class Initialized
INFO - 2024-04-14 06:54:46 --> Form Validation Class Initialized
INFO - 2024-04-14 06:54:46 --> Controller Class Initialized
INFO - 2024-04-14 06:54:46 --> Model Class Initialized
DEBUG - 2024-04-14 06:54:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:54:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:54:46 --> Model Class Initialized
DEBUG - 2024-04-14 06:54:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:54:46 --> Model Class Initialized
INFO - 2024-04-14 06:54:46 --> Email Class Initialized
INFO - 2024-04-14 06:54:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html_pdf.php
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/frame_reflower.cls.php 210
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/frame_reflower.cls.php 211
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/block_frame_reflower.cls.php 726
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/inline_renderer.cls.php 138
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:54:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-04-14 06:54:46 --> Language file loaded: language/english/email_lang.php
INFO - 2024-04-14 06:54:46 --> Final output sent to browser
DEBUG - 2024-04-14 06:54:46 --> Total execution time: 0.2569
ERROR - 2024-04-14 06:54:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:54:46 --> Config Class Initialized
INFO - 2024-04-14 06:54:46 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:54:46 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:54:46 --> Utf8 Class Initialized
INFO - 2024-04-14 06:54:46 --> URI Class Initialized
INFO - 2024-04-14 06:54:46 --> Router Class Initialized
INFO - 2024-04-14 06:54:46 --> Output Class Initialized
INFO - 2024-04-14 06:54:46 --> Security Class Initialized
DEBUG - 2024-04-14 06:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:54:46 --> Input Class Initialized
INFO - 2024-04-14 06:54:46 --> Language Class Initialized
INFO - 2024-04-14 06:54:46 --> Loader Class Initialized
INFO - 2024-04-14 06:54:46 --> Helper loaded: url_helper
INFO - 2024-04-14 06:54:46 --> Helper loaded: file_helper
INFO - 2024-04-14 06:54:46 --> Helper loaded: html_helper
INFO - 2024-04-14 06:54:46 --> Helper loaded: text_helper
INFO - 2024-04-14 06:54:46 --> Helper loaded: form_helper
INFO - 2024-04-14 06:54:46 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:54:46 --> Helper loaded: security_helper
INFO - 2024-04-14 06:54:46 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:54:46 --> Database Driver Class Initialized
INFO - 2024-04-14 06:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:54:46 --> Parser Class Initialized
INFO - 2024-04-14 06:54:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:54:46 --> Pagination Class Initialized
INFO - 2024-04-14 06:54:46 --> Form Validation Class Initialized
INFO - 2024-04-14 06:54:46 --> Controller Class Initialized
INFO - 2024-04-14 06:54:46 --> Model Class Initialized
DEBUG - 2024-04-14 06:54:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:54:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:54:46 --> Model Class Initialized
DEBUG - 2024-04-14 06:54:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:54:46 --> Model Class Initialized
INFO - 2024-04-14 06:54:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html.php
DEBUG - 2024-04-14 06:54:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:54:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 06:54:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 06:54:46 --> Model Class Initialized
INFO - 2024-04-14 06:54:47 --> Model Class Initialized
INFO - 2024-04-14 06:54:47 --> Model Class Initialized
INFO - 2024-04-14 06:54:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-14 06:54:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-14 06:54:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 06:54:47 --> Final output sent to browser
DEBUG - 2024-04-14 06:54:47 --> Total execution time: 0.2826
ERROR - 2024-04-14 06:54:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:54:51 --> Config Class Initialized
INFO - 2024-04-14 06:54:51 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:54:51 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:54:51 --> Utf8 Class Initialized
INFO - 2024-04-14 06:54:51 --> URI Class Initialized
INFO - 2024-04-14 06:54:51 --> Router Class Initialized
INFO - 2024-04-14 06:54:51 --> Output Class Initialized
INFO - 2024-04-14 06:54:51 --> Security Class Initialized
DEBUG - 2024-04-14 06:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:54:51 --> Input Class Initialized
INFO - 2024-04-14 06:54:51 --> Language Class Initialized
INFO - 2024-04-14 06:54:51 --> Loader Class Initialized
INFO - 2024-04-14 06:54:51 --> Helper loaded: url_helper
INFO - 2024-04-14 06:54:51 --> Helper loaded: file_helper
INFO - 2024-04-14 06:54:51 --> Helper loaded: html_helper
INFO - 2024-04-14 06:54:51 --> Helper loaded: text_helper
INFO - 2024-04-14 06:54:51 --> Helper loaded: form_helper
INFO - 2024-04-14 06:54:51 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:54:51 --> Helper loaded: security_helper
INFO - 2024-04-14 06:54:51 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:54:51 --> Database Driver Class Initialized
INFO - 2024-04-14 06:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:54:51 --> Parser Class Initialized
INFO - 2024-04-14 06:54:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:54:51 --> Pagination Class Initialized
INFO - 2024-04-14 06:54:51 --> Form Validation Class Initialized
INFO - 2024-04-14 06:54:51 --> Controller Class Initialized
INFO - 2024-04-14 06:54:51 --> Model Class Initialized
DEBUG - 2024-04-14 06:54:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:54:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:54:51 --> Model Class Initialized
DEBUG - 2024-04-14 06:54:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:54:51 --> Model Class Initialized
INFO - 2024-04-14 06:54:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-04-14 06:54:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:54:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 06:54:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 06:54:51 --> Model Class Initialized
INFO - 2024-04-14 06:54:51 --> Model Class Initialized
INFO - 2024-04-14 06:54:51 --> Model Class Initialized
INFO - 2024-04-14 06:54:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-14 06:54:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-14 06:54:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 06:54:51 --> Final output sent to browser
DEBUG - 2024-04-14 06:54:51 --> Total execution time: 0.2693
ERROR - 2024-04-14 06:54:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:54:52 --> Config Class Initialized
INFO - 2024-04-14 06:54:52 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:54:52 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:54:52 --> Utf8 Class Initialized
INFO - 2024-04-14 06:54:52 --> URI Class Initialized
INFO - 2024-04-14 06:54:52 --> Router Class Initialized
INFO - 2024-04-14 06:54:52 --> Output Class Initialized
INFO - 2024-04-14 06:54:52 --> Security Class Initialized
DEBUG - 2024-04-14 06:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:54:52 --> Input Class Initialized
INFO - 2024-04-14 06:54:52 --> Language Class Initialized
INFO - 2024-04-14 06:54:52 --> Loader Class Initialized
INFO - 2024-04-14 06:54:52 --> Helper loaded: url_helper
INFO - 2024-04-14 06:54:52 --> Helper loaded: file_helper
INFO - 2024-04-14 06:54:52 --> Helper loaded: html_helper
INFO - 2024-04-14 06:54:52 --> Helper loaded: text_helper
INFO - 2024-04-14 06:54:52 --> Helper loaded: form_helper
INFO - 2024-04-14 06:54:52 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:54:52 --> Helper loaded: security_helper
INFO - 2024-04-14 06:54:52 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:54:52 --> Database Driver Class Initialized
INFO - 2024-04-14 06:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:54:52 --> Parser Class Initialized
INFO - 2024-04-14 06:54:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:54:52 --> Pagination Class Initialized
INFO - 2024-04-14 06:54:52 --> Form Validation Class Initialized
INFO - 2024-04-14 06:54:52 --> Controller Class Initialized
INFO - 2024-04-14 06:54:52 --> Model Class Initialized
DEBUG - 2024-04-14 06:54:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:54:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:54:52 --> Model Class Initialized
DEBUG - 2024-04-14 06:54:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:54:52 --> Model Class Initialized
INFO - 2024-04-14 06:54:52 --> Final output sent to browser
DEBUG - 2024-04-14 06:54:52 --> Total execution time: 0.0391
ERROR - 2024-04-14 06:54:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:54:54 --> Config Class Initialized
INFO - 2024-04-14 06:54:54 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:54:54 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:54:54 --> Utf8 Class Initialized
INFO - 2024-04-14 06:54:54 --> URI Class Initialized
INFO - 2024-04-14 06:54:54 --> Router Class Initialized
INFO - 2024-04-14 06:54:54 --> Output Class Initialized
INFO - 2024-04-14 06:54:54 --> Security Class Initialized
DEBUG - 2024-04-14 06:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:54:54 --> Input Class Initialized
INFO - 2024-04-14 06:54:54 --> Language Class Initialized
INFO - 2024-04-14 06:54:54 --> Loader Class Initialized
INFO - 2024-04-14 06:54:54 --> Helper loaded: url_helper
INFO - 2024-04-14 06:54:54 --> Helper loaded: file_helper
INFO - 2024-04-14 06:54:54 --> Helper loaded: html_helper
INFO - 2024-04-14 06:54:54 --> Helper loaded: text_helper
INFO - 2024-04-14 06:54:54 --> Helper loaded: form_helper
INFO - 2024-04-14 06:54:54 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:54:54 --> Helper loaded: security_helper
INFO - 2024-04-14 06:54:54 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:54:54 --> Database Driver Class Initialized
INFO - 2024-04-14 06:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:54:54 --> Parser Class Initialized
INFO - 2024-04-14 06:54:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:54:54 --> Pagination Class Initialized
INFO - 2024-04-14 06:54:54 --> Form Validation Class Initialized
INFO - 2024-04-14 06:54:54 --> Controller Class Initialized
INFO - 2024-04-14 06:54:54 --> Model Class Initialized
DEBUG - 2024-04-14 06:54:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:54:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:54:54 --> Model Class Initialized
DEBUG - 2024-04-14 06:54:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:54:54 --> Model Class Initialized
INFO - 2024-04-14 06:54:56 --> Final output sent to browser
DEBUG - 2024-04-14 06:54:56 --> Total execution time: 1.3227
ERROR - 2024-04-14 06:55:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:55:29 --> Config Class Initialized
INFO - 2024-04-14 06:55:29 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:55:29 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:55:29 --> Utf8 Class Initialized
INFO - 2024-04-14 06:55:29 --> URI Class Initialized
INFO - 2024-04-14 06:55:29 --> Router Class Initialized
INFO - 2024-04-14 06:55:29 --> Output Class Initialized
INFO - 2024-04-14 06:55:29 --> Security Class Initialized
DEBUG - 2024-04-14 06:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:55:29 --> Input Class Initialized
INFO - 2024-04-14 06:55:29 --> Language Class Initialized
INFO - 2024-04-14 06:55:29 --> Loader Class Initialized
INFO - 2024-04-14 06:55:29 --> Helper loaded: url_helper
INFO - 2024-04-14 06:55:29 --> Helper loaded: file_helper
INFO - 2024-04-14 06:55:29 --> Helper loaded: html_helper
INFO - 2024-04-14 06:55:29 --> Helper loaded: text_helper
INFO - 2024-04-14 06:55:29 --> Helper loaded: form_helper
INFO - 2024-04-14 06:55:29 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:55:29 --> Helper loaded: security_helper
INFO - 2024-04-14 06:55:29 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:55:29 --> Database Driver Class Initialized
INFO - 2024-04-14 06:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:55:29 --> Parser Class Initialized
INFO - 2024-04-14 06:55:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:55:29 --> Pagination Class Initialized
INFO - 2024-04-14 06:55:29 --> Form Validation Class Initialized
INFO - 2024-04-14 06:55:29 --> Controller Class Initialized
INFO - 2024-04-14 06:55:29 --> Model Class Initialized
DEBUG - 2024-04-14 06:55:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:55:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:55:29 --> Model Class Initialized
DEBUG - 2024-04-14 06:55:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:55:29 --> Model Class Initialized
INFO - 2024-04-14 06:55:29 --> Email Class Initialized
INFO - 2024-04-14 06:55:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html_pdf.php
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/frame_reflower.cls.php 210
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/frame_reflower.cls.php 211
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/block_frame_reflower.cls.php 726
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:29 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-04-14 06:55:29 --> Language file loaded: language/english/email_lang.php
INFO - 2024-04-14 06:55:29 --> Final output sent to browser
DEBUG - 2024-04-14 06:55:29 --> Total execution time: 0.2484
ERROR - 2024-04-14 06:55:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:55:30 --> Config Class Initialized
INFO - 2024-04-14 06:55:30 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:55:30 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:55:30 --> Utf8 Class Initialized
INFO - 2024-04-14 06:55:30 --> URI Class Initialized
INFO - 2024-04-14 06:55:30 --> Router Class Initialized
INFO - 2024-04-14 06:55:30 --> Output Class Initialized
INFO - 2024-04-14 06:55:30 --> Security Class Initialized
DEBUG - 2024-04-14 06:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:55:30 --> Input Class Initialized
INFO - 2024-04-14 06:55:30 --> Language Class Initialized
INFO - 2024-04-14 06:55:30 --> Loader Class Initialized
INFO - 2024-04-14 06:55:30 --> Helper loaded: url_helper
INFO - 2024-04-14 06:55:30 --> Helper loaded: file_helper
INFO - 2024-04-14 06:55:30 --> Helper loaded: html_helper
INFO - 2024-04-14 06:55:30 --> Helper loaded: text_helper
INFO - 2024-04-14 06:55:30 --> Helper loaded: form_helper
INFO - 2024-04-14 06:55:30 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:55:30 --> Helper loaded: security_helper
INFO - 2024-04-14 06:55:30 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:55:30 --> Database Driver Class Initialized
INFO - 2024-04-14 06:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:55:30 --> Parser Class Initialized
INFO - 2024-04-14 06:55:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:55:30 --> Pagination Class Initialized
INFO - 2024-04-14 06:55:30 --> Form Validation Class Initialized
INFO - 2024-04-14 06:55:30 --> Controller Class Initialized
INFO - 2024-04-14 06:55:30 --> Model Class Initialized
DEBUG - 2024-04-14 06:55:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:55:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:55:30 --> Model Class Initialized
DEBUG - 2024-04-14 06:55:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:55:30 --> Model Class Initialized
INFO - 2024-04-14 06:55:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html.php
DEBUG - 2024-04-14 06:55:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:55:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 06:55:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 06:55:30 --> Model Class Initialized
INFO - 2024-04-14 06:55:30 --> Model Class Initialized
INFO - 2024-04-14 06:55:30 --> Model Class Initialized
INFO - 2024-04-14 06:55:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-14 06:55:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-14 06:55:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 06:55:30 --> Final output sent to browser
DEBUG - 2024-04-14 06:55:30 --> Total execution time: 0.2902
ERROR - 2024-04-14 06:55:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:55:34 --> Config Class Initialized
INFO - 2024-04-14 06:55:34 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:55:34 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:55:34 --> Utf8 Class Initialized
INFO - 2024-04-14 06:55:34 --> URI Class Initialized
INFO - 2024-04-14 06:55:34 --> Router Class Initialized
INFO - 2024-04-14 06:55:34 --> Output Class Initialized
INFO - 2024-04-14 06:55:34 --> Security Class Initialized
DEBUG - 2024-04-14 06:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:55:34 --> Input Class Initialized
INFO - 2024-04-14 06:55:34 --> Language Class Initialized
INFO - 2024-04-14 06:55:34 --> Loader Class Initialized
INFO - 2024-04-14 06:55:34 --> Helper loaded: url_helper
INFO - 2024-04-14 06:55:34 --> Helper loaded: file_helper
INFO - 2024-04-14 06:55:34 --> Helper loaded: html_helper
INFO - 2024-04-14 06:55:34 --> Helper loaded: text_helper
INFO - 2024-04-14 06:55:34 --> Helper loaded: form_helper
INFO - 2024-04-14 06:55:34 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:55:34 --> Helper loaded: security_helper
INFO - 2024-04-14 06:55:34 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:55:34 --> Database Driver Class Initialized
INFO - 2024-04-14 06:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:55:34 --> Parser Class Initialized
INFO - 2024-04-14 06:55:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:55:34 --> Pagination Class Initialized
INFO - 2024-04-14 06:55:34 --> Form Validation Class Initialized
INFO - 2024-04-14 06:55:34 --> Controller Class Initialized
INFO - 2024-04-14 06:55:34 --> Model Class Initialized
DEBUG - 2024-04-14 06:55:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:55:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:55:34 --> Model Class Initialized
DEBUG - 2024-04-14 06:55:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:55:34 --> Model Class Initialized
INFO - 2024-04-14 06:55:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-04-14 06:55:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:55:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 06:55:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 06:55:34 --> Model Class Initialized
INFO - 2024-04-14 06:55:34 --> Model Class Initialized
INFO - 2024-04-14 06:55:34 --> Model Class Initialized
INFO - 2024-04-14 06:55:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-14 06:55:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-14 06:55:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 06:55:34 --> Final output sent to browser
DEBUG - 2024-04-14 06:55:34 --> Total execution time: 0.2736
ERROR - 2024-04-14 06:55:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:55:35 --> Config Class Initialized
INFO - 2024-04-14 06:55:35 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:55:35 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:55:35 --> Utf8 Class Initialized
INFO - 2024-04-14 06:55:35 --> URI Class Initialized
INFO - 2024-04-14 06:55:35 --> Router Class Initialized
INFO - 2024-04-14 06:55:35 --> Output Class Initialized
INFO - 2024-04-14 06:55:35 --> Security Class Initialized
DEBUG - 2024-04-14 06:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:55:35 --> Input Class Initialized
INFO - 2024-04-14 06:55:35 --> Language Class Initialized
INFO - 2024-04-14 06:55:35 --> Loader Class Initialized
INFO - 2024-04-14 06:55:35 --> Helper loaded: url_helper
INFO - 2024-04-14 06:55:35 --> Helper loaded: file_helper
INFO - 2024-04-14 06:55:35 --> Helper loaded: html_helper
INFO - 2024-04-14 06:55:35 --> Helper loaded: text_helper
INFO - 2024-04-14 06:55:35 --> Helper loaded: form_helper
INFO - 2024-04-14 06:55:35 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:55:35 --> Helper loaded: security_helper
INFO - 2024-04-14 06:55:35 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:55:35 --> Database Driver Class Initialized
INFO - 2024-04-14 06:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:55:35 --> Parser Class Initialized
INFO - 2024-04-14 06:55:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:55:35 --> Pagination Class Initialized
INFO - 2024-04-14 06:55:35 --> Form Validation Class Initialized
INFO - 2024-04-14 06:55:35 --> Controller Class Initialized
INFO - 2024-04-14 06:55:35 --> Model Class Initialized
DEBUG - 2024-04-14 06:55:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:55:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:55:35 --> Model Class Initialized
DEBUG - 2024-04-14 06:55:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:55:35 --> Model Class Initialized
INFO - 2024-04-14 06:55:35 --> Final output sent to browser
DEBUG - 2024-04-14 06:55:35 --> Total execution time: 0.0436
ERROR - 2024-04-14 06:55:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:55:37 --> Config Class Initialized
INFO - 2024-04-14 06:55:37 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:55:37 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:55:37 --> Utf8 Class Initialized
INFO - 2024-04-14 06:55:37 --> URI Class Initialized
INFO - 2024-04-14 06:55:37 --> Router Class Initialized
INFO - 2024-04-14 06:55:37 --> Output Class Initialized
INFO - 2024-04-14 06:55:37 --> Security Class Initialized
DEBUG - 2024-04-14 06:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:55:37 --> Input Class Initialized
INFO - 2024-04-14 06:55:37 --> Language Class Initialized
INFO - 2024-04-14 06:55:37 --> Loader Class Initialized
INFO - 2024-04-14 06:55:37 --> Helper loaded: url_helper
INFO - 2024-04-14 06:55:37 --> Helper loaded: file_helper
INFO - 2024-04-14 06:55:37 --> Helper loaded: html_helper
INFO - 2024-04-14 06:55:37 --> Helper loaded: text_helper
INFO - 2024-04-14 06:55:37 --> Helper loaded: form_helper
INFO - 2024-04-14 06:55:37 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:55:37 --> Helper loaded: security_helper
INFO - 2024-04-14 06:55:37 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:55:37 --> Database Driver Class Initialized
INFO - 2024-04-14 06:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:55:37 --> Parser Class Initialized
INFO - 2024-04-14 06:55:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:55:37 --> Pagination Class Initialized
INFO - 2024-04-14 06:55:37 --> Form Validation Class Initialized
INFO - 2024-04-14 06:55:37 --> Controller Class Initialized
INFO - 2024-04-14 06:55:37 --> Model Class Initialized
DEBUG - 2024-04-14 06:55:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:55:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:55:37 --> Model Class Initialized
DEBUG - 2024-04-14 06:55:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:55:37 --> Model Class Initialized
INFO - 2024-04-14 06:55:38 --> Final output sent to browser
DEBUG - 2024-04-14 06:55:38 --> Total execution time: 1.3721
ERROR - 2024-04-14 06:55:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:55:58 --> Config Class Initialized
INFO - 2024-04-14 06:55:58 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:55:58 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:55:58 --> Utf8 Class Initialized
INFO - 2024-04-14 06:55:58 --> URI Class Initialized
INFO - 2024-04-14 06:55:58 --> Router Class Initialized
INFO - 2024-04-14 06:55:58 --> Output Class Initialized
INFO - 2024-04-14 06:55:58 --> Security Class Initialized
DEBUG - 2024-04-14 06:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:55:58 --> Input Class Initialized
INFO - 2024-04-14 06:55:58 --> Language Class Initialized
INFO - 2024-04-14 06:55:58 --> Loader Class Initialized
INFO - 2024-04-14 06:55:58 --> Helper loaded: url_helper
INFO - 2024-04-14 06:55:58 --> Helper loaded: file_helper
INFO - 2024-04-14 06:55:58 --> Helper loaded: html_helper
INFO - 2024-04-14 06:55:58 --> Helper loaded: text_helper
INFO - 2024-04-14 06:55:58 --> Helper loaded: form_helper
INFO - 2024-04-14 06:55:58 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:55:58 --> Helper loaded: security_helper
INFO - 2024-04-14 06:55:58 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:55:58 --> Database Driver Class Initialized
INFO - 2024-04-14 06:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:55:58 --> Parser Class Initialized
INFO - 2024-04-14 06:55:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:55:58 --> Pagination Class Initialized
INFO - 2024-04-14 06:55:58 --> Form Validation Class Initialized
INFO - 2024-04-14 06:55:58 --> Controller Class Initialized
INFO - 2024-04-14 06:55:58 --> Model Class Initialized
DEBUG - 2024-04-14 06:55:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:55:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:55:58 --> Model Class Initialized
DEBUG - 2024-04-14 06:55:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:55:58 --> Model Class Initialized
INFO - 2024-04-14 06:55:58 --> Email Class Initialized
INFO - 2024-04-14 06:55:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html_pdf.php
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/frame_reflower.cls.php 210
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/frame_reflower.cls.php 211
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/block_frame_reflower.cls.php 726
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:55:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-04-14 06:55:58 --> Language file loaded: language/english/email_lang.php
INFO - 2024-04-14 06:55:58 --> Final output sent to browser
DEBUG - 2024-04-14 06:55:58 --> Total execution time: 0.3091
ERROR - 2024-04-14 06:55:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:55:59 --> Config Class Initialized
INFO - 2024-04-14 06:55:59 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:55:59 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:55:59 --> Utf8 Class Initialized
INFO - 2024-04-14 06:55:59 --> URI Class Initialized
INFO - 2024-04-14 06:55:59 --> Router Class Initialized
INFO - 2024-04-14 06:55:59 --> Output Class Initialized
INFO - 2024-04-14 06:55:59 --> Security Class Initialized
DEBUG - 2024-04-14 06:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:55:59 --> Input Class Initialized
INFO - 2024-04-14 06:55:59 --> Language Class Initialized
INFO - 2024-04-14 06:55:59 --> Loader Class Initialized
INFO - 2024-04-14 06:55:59 --> Helper loaded: url_helper
INFO - 2024-04-14 06:55:59 --> Helper loaded: file_helper
INFO - 2024-04-14 06:55:59 --> Helper loaded: html_helper
INFO - 2024-04-14 06:55:59 --> Helper loaded: text_helper
INFO - 2024-04-14 06:55:59 --> Helper loaded: form_helper
INFO - 2024-04-14 06:55:59 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:55:59 --> Helper loaded: security_helper
INFO - 2024-04-14 06:55:59 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:55:59 --> Database Driver Class Initialized
INFO - 2024-04-14 06:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:55:59 --> Parser Class Initialized
INFO - 2024-04-14 06:55:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:55:59 --> Pagination Class Initialized
INFO - 2024-04-14 06:55:59 --> Form Validation Class Initialized
INFO - 2024-04-14 06:55:59 --> Controller Class Initialized
INFO - 2024-04-14 06:55:59 --> Model Class Initialized
DEBUG - 2024-04-14 06:55:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:55:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:55:59 --> Model Class Initialized
DEBUG - 2024-04-14 06:55:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:55:59 --> Model Class Initialized
INFO - 2024-04-14 06:55:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html.php
DEBUG - 2024-04-14 06:55:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:55:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 06:55:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 06:55:59 --> Model Class Initialized
INFO - 2024-04-14 06:55:59 --> Model Class Initialized
INFO - 2024-04-14 06:55:59 --> Model Class Initialized
INFO - 2024-04-14 06:55:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-14 06:55:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-14 06:55:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 06:55:59 --> Final output sent to browser
DEBUG - 2024-04-14 06:55:59 --> Total execution time: 0.2882
ERROR - 2024-04-14 06:56:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:56:03 --> Config Class Initialized
INFO - 2024-04-14 06:56:03 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:56:03 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:56:03 --> Utf8 Class Initialized
INFO - 2024-04-14 06:56:03 --> URI Class Initialized
INFO - 2024-04-14 06:56:03 --> Router Class Initialized
INFO - 2024-04-14 06:56:03 --> Output Class Initialized
INFO - 2024-04-14 06:56:03 --> Security Class Initialized
DEBUG - 2024-04-14 06:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:56:03 --> Input Class Initialized
INFO - 2024-04-14 06:56:03 --> Language Class Initialized
INFO - 2024-04-14 06:56:03 --> Loader Class Initialized
INFO - 2024-04-14 06:56:03 --> Helper loaded: url_helper
INFO - 2024-04-14 06:56:03 --> Helper loaded: file_helper
INFO - 2024-04-14 06:56:03 --> Helper loaded: html_helper
INFO - 2024-04-14 06:56:03 --> Helper loaded: text_helper
INFO - 2024-04-14 06:56:03 --> Helper loaded: form_helper
INFO - 2024-04-14 06:56:03 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:56:03 --> Helper loaded: security_helper
INFO - 2024-04-14 06:56:03 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:56:03 --> Database Driver Class Initialized
INFO - 2024-04-14 06:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:56:03 --> Parser Class Initialized
INFO - 2024-04-14 06:56:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:56:03 --> Pagination Class Initialized
INFO - 2024-04-14 06:56:03 --> Form Validation Class Initialized
INFO - 2024-04-14 06:56:03 --> Controller Class Initialized
INFO - 2024-04-14 06:56:03 --> Model Class Initialized
DEBUG - 2024-04-14 06:56:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:56:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:56:03 --> Model Class Initialized
DEBUG - 2024-04-14 06:56:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:56:03 --> Model Class Initialized
INFO - 2024-04-14 06:56:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-04-14 06:56:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:56:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 06:56:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 06:56:03 --> Model Class Initialized
INFO - 2024-04-14 06:56:03 --> Model Class Initialized
INFO - 2024-04-14 06:56:03 --> Model Class Initialized
INFO - 2024-04-14 06:56:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-14 06:56:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-14 06:56:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 06:56:03 --> Final output sent to browser
DEBUG - 2024-04-14 06:56:03 --> Total execution time: 0.2943
ERROR - 2024-04-14 06:56:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:56:04 --> Config Class Initialized
INFO - 2024-04-14 06:56:04 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:56:04 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:56:04 --> Utf8 Class Initialized
INFO - 2024-04-14 06:56:04 --> URI Class Initialized
INFO - 2024-04-14 06:56:04 --> Router Class Initialized
INFO - 2024-04-14 06:56:04 --> Output Class Initialized
INFO - 2024-04-14 06:56:04 --> Security Class Initialized
DEBUG - 2024-04-14 06:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:56:04 --> Input Class Initialized
INFO - 2024-04-14 06:56:04 --> Language Class Initialized
INFO - 2024-04-14 06:56:04 --> Loader Class Initialized
INFO - 2024-04-14 06:56:04 --> Helper loaded: url_helper
INFO - 2024-04-14 06:56:04 --> Helper loaded: file_helper
INFO - 2024-04-14 06:56:04 --> Helper loaded: html_helper
INFO - 2024-04-14 06:56:04 --> Helper loaded: text_helper
INFO - 2024-04-14 06:56:04 --> Helper loaded: form_helper
INFO - 2024-04-14 06:56:04 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:56:04 --> Helper loaded: security_helper
INFO - 2024-04-14 06:56:04 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:56:04 --> Database Driver Class Initialized
INFO - 2024-04-14 06:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:56:04 --> Parser Class Initialized
INFO - 2024-04-14 06:56:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:56:04 --> Pagination Class Initialized
INFO - 2024-04-14 06:56:04 --> Form Validation Class Initialized
INFO - 2024-04-14 06:56:04 --> Controller Class Initialized
INFO - 2024-04-14 06:56:04 --> Model Class Initialized
DEBUG - 2024-04-14 06:56:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:56:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:56:04 --> Model Class Initialized
DEBUG - 2024-04-14 06:56:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:56:04 --> Model Class Initialized
INFO - 2024-04-14 06:56:04 --> Final output sent to browser
DEBUG - 2024-04-14 06:56:04 --> Total execution time: 0.0421
ERROR - 2024-04-14 06:56:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:56:07 --> Config Class Initialized
INFO - 2024-04-14 06:56:07 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:56:07 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:56:07 --> Utf8 Class Initialized
INFO - 2024-04-14 06:56:07 --> URI Class Initialized
INFO - 2024-04-14 06:56:07 --> Router Class Initialized
INFO - 2024-04-14 06:56:07 --> Output Class Initialized
INFO - 2024-04-14 06:56:07 --> Security Class Initialized
DEBUG - 2024-04-14 06:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:56:07 --> Input Class Initialized
INFO - 2024-04-14 06:56:07 --> Language Class Initialized
INFO - 2024-04-14 06:56:07 --> Loader Class Initialized
INFO - 2024-04-14 06:56:07 --> Helper loaded: url_helper
INFO - 2024-04-14 06:56:07 --> Helper loaded: file_helper
INFO - 2024-04-14 06:56:07 --> Helper loaded: html_helper
INFO - 2024-04-14 06:56:07 --> Helper loaded: text_helper
INFO - 2024-04-14 06:56:07 --> Helper loaded: form_helper
INFO - 2024-04-14 06:56:07 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:56:07 --> Helper loaded: security_helper
INFO - 2024-04-14 06:56:07 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:56:07 --> Database Driver Class Initialized
INFO - 2024-04-14 06:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:56:07 --> Parser Class Initialized
INFO - 2024-04-14 06:56:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:56:07 --> Pagination Class Initialized
INFO - 2024-04-14 06:56:07 --> Form Validation Class Initialized
INFO - 2024-04-14 06:56:07 --> Controller Class Initialized
INFO - 2024-04-14 06:56:07 --> Model Class Initialized
DEBUG - 2024-04-14 06:56:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:56:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:56:07 --> Model Class Initialized
DEBUG - 2024-04-14 06:56:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:56:07 --> Model Class Initialized
INFO - 2024-04-14 06:56:08 --> Final output sent to browser
DEBUG - 2024-04-14 06:56:08 --> Total execution time: 1.3261
ERROR - 2024-04-14 06:56:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:56:23 --> Config Class Initialized
INFO - 2024-04-14 06:56:23 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:56:23 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:56:23 --> Utf8 Class Initialized
INFO - 2024-04-14 06:56:23 --> URI Class Initialized
INFO - 2024-04-14 06:56:23 --> Router Class Initialized
INFO - 2024-04-14 06:56:23 --> Output Class Initialized
INFO - 2024-04-14 06:56:23 --> Security Class Initialized
DEBUG - 2024-04-14 06:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:56:23 --> Input Class Initialized
INFO - 2024-04-14 06:56:23 --> Language Class Initialized
INFO - 2024-04-14 06:56:23 --> Loader Class Initialized
INFO - 2024-04-14 06:56:23 --> Helper loaded: url_helper
INFO - 2024-04-14 06:56:23 --> Helper loaded: file_helper
INFO - 2024-04-14 06:56:23 --> Helper loaded: html_helper
INFO - 2024-04-14 06:56:23 --> Helper loaded: text_helper
INFO - 2024-04-14 06:56:23 --> Helper loaded: form_helper
INFO - 2024-04-14 06:56:23 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:56:23 --> Helper loaded: security_helper
INFO - 2024-04-14 06:56:23 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:56:23 --> Database Driver Class Initialized
INFO - 2024-04-14 06:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:56:23 --> Parser Class Initialized
INFO - 2024-04-14 06:56:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:56:23 --> Pagination Class Initialized
INFO - 2024-04-14 06:56:23 --> Form Validation Class Initialized
INFO - 2024-04-14 06:56:23 --> Controller Class Initialized
INFO - 2024-04-14 06:56:23 --> Model Class Initialized
DEBUG - 2024-04-14 06:56:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:56:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:56:23 --> Model Class Initialized
DEBUG - 2024-04-14 06:56:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:56:23 --> Model Class Initialized
INFO - 2024-04-14 06:56:23 --> Email Class Initialized
INFO - 2024-04-14 06:56:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html_pdf.php
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/frame_reflower.cls.php 210
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/frame_reflower.cls.php 211
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/block_frame_reflower.cls.php 726
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:56:23 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-04-14 06:56:24 --> Language file loaded: language/english/email_lang.php
INFO - 2024-04-14 06:56:24 --> Final output sent to browser
DEBUG - 2024-04-14 06:56:24 --> Total execution time: 0.2765
ERROR - 2024-04-14 06:56:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:56:24 --> Config Class Initialized
INFO - 2024-04-14 06:56:24 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:56:24 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:56:24 --> Utf8 Class Initialized
INFO - 2024-04-14 06:56:24 --> URI Class Initialized
INFO - 2024-04-14 06:56:24 --> Router Class Initialized
INFO - 2024-04-14 06:56:24 --> Output Class Initialized
INFO - 2024-04-14 06:56:24 --> Security Class Initialized
DEBUG - 2024-04-14 06:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:56:24 --> Input Class Initialized
INFO - 2024-04-14 06:56:24 --> Language Class Initialized
INFO - 2024-04-14 06:56:24 --> Loader Class Initialized
INFO - 2024-04-14 06:56:24 --> Helper loaded: url_helper
INFO - 2024-04-14 06:56:24 --> Helper loaded: file_helper
INFO - 2024-04-14 06:56:24 --> Helper loaded: html_helper
INFO - 2024-04-14 06:56:24 --> Helper loaded: text_helper
INFO - 2024-04-14 06:56:24 --> Helper loaded: form_helper
INFO - 2024-04-14 06:56:24 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:56:24 --> Helper loaded: security_helper
INFO - 2024-04-14 06:56:24 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:56:24 --> Database Driver Class Initialized
INFO - 2024-04-14 06:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:56:24 --> Parser Class Initialized
INFO - 2024-04-14 06:56:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:56:24 --> Pagination Class Initialized
INFO - 2024-04-14 06:56:24 --> Form Validation Class Initialized
INFO - 2024-04-14 06:56:24 --> Controller Class Initialized
INFO - 2024-04-14 06:56:24 --> Model Class Initialized
DEBUG - 2024-04-14 06:56:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:56:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:56:24 --> Model Class Initialized
DEBUG - 2024-04-14 06:56:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:56:24 --> Model Class Initialized
INFO - 2024-04-14 06:56:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html.php
DEBUG - 2024-04-14 06:56:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:56:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 06:56:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 06:56:24 --> Model Class Initialized
INFO - 2024-04-14 06:56:24 --> Model Class Initialized
INFO - 2024-04-14 06:56:24 --> Model Class Initialized
INFO - 2024-04-14 06:56:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-14 06:56:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-14 06:56:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 06:56:24 --> Final output sent to browser
DEBUG - 2024-04-14 06:56:24 --> Total execution time: 0.2869
ERROR - 2024-04-14 06:56:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:56:28 --> Config Class Initialized
INFO - 2024-04-14 06:56:28 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:56:28 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:56:28 --> Utf8 Class Initialized
INFO - 2024-04-14 06:56:28 --> URI Class Initialized
INFO - 2024-04-14 06:56:28 --> Router Class Initialized
INFO - 2024-04-14 06:56:28 --> Output Class Initialized
INFO - 2024-04-14 06:56:28 --> Security Class Initialized
DEBUG - 2024-04-14 06:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:56:28 --> Input Class Initialized
INFO - 2024-04-14 06:56:28 --> Language Class Initialized
INFO - 2024-04-14 06:56:28 --> Loader Class Initialized
INFO - 2024-04-14 06:56:28 --> Helper loaded: url_helper
INFO - 2024-04-14 06:56:28 --> Helper loaded: file_helper
INFO - 2024-04-14 06:56:28 --> Helper loaded: html_helper
INFO - 2024-04-14 06:56:28 --> Helper loaded: text_helper
INFO - 2024-04-14 06:56:28 --> Helper loaded: form_helper
INFO - 2024-04-14 06:56:28 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:56:28 --> Helper loaded: security_helper
INFO - 2024-04-14 06:56:28 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:56:28 --> Database Driver Class Initialized
INFO - 2024-04-14 06:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:56:28 --> Parser Class Initialized
INFO - 2024-04-14 06:56:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:56:28 --> Pagination Class Initialized
INFO - 2024-04-14 06:56:28 --> Form Validation Class Initialized
INFO - 2024-04-14 06:56:28 --> Controller Class Initialized
INFO - 2024-04-14 06:56:28 --> Model Class Initialized
DEBUG - 2024-04-14 06:56:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:56:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:56:28 --> Model Class Initialized
DEBUG - 2024-04-14 06:56:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:56:28 --> Model Class Initialized
INFO - 2024-04-14 06:56:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-04-14 06:56:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:56:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 06:56:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 06:56:29 --> Model Class Initialized
INFO - 2024-04-14 06:56:29 --> Model Class Initialized
INFO - 2024-04-14 06:56:29 --> Model Class Initialized
INFO - 2024-04-14 06:56:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-14 06:56:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-14 06:56:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 06:56:29 --> Final output sent to browser
DEBUG - 2024-04-14 06:56:29 --> Total execution time: 0.2749
ERROR - 2024-04-14 06:56:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:56:29 --> Config Class Initialized
INFO - 2024-04-14 06:56:29 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:56:29 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:56:29 --> Utf8 Class Initialized
INFO - 2024-04-14 06:56:29 --> URI Class Initialized
INFO - 2024-04-14 06:56:29 --> Router Class Initialized
INFO - 2024-04-14 06:56:29 --> Output Class Initialized
INFO - 2024-04-14 06:56:29 --> Security Class Initialized
DEBUG - 2024-04-14 06:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:56:29 --> Input Class Initialized
INFO - 2024-04-14 06:56:29 --> Language Class Initialized
INFO - 2024-04-14 06:56:29 --> Loader Class Initialized
INFO - 2024-04-14 06:56:29 --> Helper loaded: url_helper
INFO - 2024-04-14 06:56:29 --> Helper loaded: file_helper
INFO - 2024-04-14 06:56:29 --> Helper loaded: html_helper
INFO - 2024-04-14 06:56:29 --> Helper loaded: text_helper
INFO - 2024-04-14 06:56:29 --> Helper loaded: form_helper
INFO - 2024-04-14 06:56:29 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:56:29 --> Helper loaded: security_helper
INFO - 2024-04-14 06:56:29 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:56:29 --> Database Driver Class Initialized
INFO - 2024-04-14 06:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:56:29 --> Parser Class Initialized
INFO - 2024-04-14 06:56:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:56:29 --> Pagination Class Initialized
INFO - 2024-04-14 06:56:29 --> Form Validation Class Initialized
INFO - 2024-04-14 06:56:29 --> Controller Class Initialized
INFO - 2024-04-14 06:56:29 --> Model Class Initialized
DEBUG - 2024-04-14 06:56:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:56:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:56:29 --> Model Class Initialized
DEBUG - 2024-04-14 06:56:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:56:29 --> Model Class Initialized
INFO - 2024-04-14 06:56:29 --> Final output sent to browser
DEBUG - 2024-04-14 06:56:29 --> Total execution time: 0.0416
ERROR - 2024-04-14 06:56:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:56:36 --> Config Class Initialized
INFO - 2024-04-14 06:56:36 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:56:36 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:56:36 --> Utf8 Class Initialized
INFO - 2024-04-14 06:56:36 --> URI Class Initialized
INFO - 2024-04-14 06:56:36 --> Router Class Initialized
INFO - 2024-04-14 06:56:36 --> Output Class Initialized
INFO - 2024-04-14 06:56:36 --> Security Class Initialized
DEBUG - 2024-04-14 06:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:56:36 --> Input Class Initialized
INFO - 2024-04-14 06:56:36 --> Language Class Initialized
INFO - 2024-04-14 06:56:36 --> Loader Class Initialized
INFO - 2024-04-14 06:56:36 --> Helper loaded: url_helper
INFO - 2024-04-14 06:56:36 --> Helper loaded: file_helper
INFO - 2024-04-14 06:56:36 --> Helper loaded: html_helper
INFO - 2024-04-14 06:56:36 --> Helper loaded: text_helper
INFO - 2024-04-14 06:56:36 --> Helper loaded: form_helper
INFO - 2024-04-14 06:56:36 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:56:36 --> Helper loaded: security_helper
INFO - 2024-04-14 06:56:36 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:56:36 --> Database Driver Class Initialized
INFO - 2024-04-14 06:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:56:36 --> Parser Class Initialized
INFO - 2024-04-14 06:56:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:56:36 --> Pagination Class Initialized
INFO - 2024-04-14 06:56:36 --> Form Validation Class Initialized
INFO - 2024-04-14 06:56:36 --> Controller Class Initialized
INFO - 2024-04-14 06:56:36 --> Model Class Initialized
DEBUG - 2024-04-14 06:56:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:56:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:56:36 --> Model Class Initialized
DEBUG - 2024-04-14 06:56:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:56:36 --> Model Class Initialized
INFO - 2024-04-14 06:56:38 --> Final output sent to browser
DEBUG - 2024-04-14 06:56:38 --> Total execution time: 1.3005
ERROR - 2024-04-14 06:57:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:57:04 --> Config Class Initialized
INFO - 2024-04-14 06:57:04 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:57:04 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:57:04 --> Utf8 Class Initialized
INFO - 2024-04-14 06:57:04 --> URI Class Initialized
INFO - 2024-04-14 06:57:04 --> Router Class Initialized
INFO - 2024-04-14 06:57:04 --> Output Class Initialized
INFO - 2024-04-14 06:57:04 --> Security Class Initialized
DEBUG - 2024-04-14 06:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:57:04 --> Input Class Initialized
INFO - 2024-04-14 06:57:04 --> Language Class Initialized
INFO - 2024-04-14 06:57:04 --> Loader Class Initialized
INFO - 2024-04-14 06:57:04 --> Helper loaded: url_helper
INFO - 2024-04-14 06:57:04 --> Helper loaded: file_helper
INFO - 2024-04-14 06:57:04 --> Helper loaded: html_helper
INFO - 2024-04-14 06:57:04 --> Helper loaded: text_helper
INFO - 2024-04-14 06:57:04 --> Helper loaded: form_helper
INFO - 2024-04-14 06:57:04 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:57:04 --> Helper loaded: security_helper
INFO - 2024-04-14 06:57:04 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:57:04 --> Database Driver Class Initialized
INFO - 2024-04-14 06:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:57:04 --> Parser Class Initialized
INFO - 2024-04-14 06:57:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:57:04 --> Pagination Class Initialized
INFO - 2024-04-14 06:57:04 --> Form Validation Class Initialized
INFO - 2024-04-14 06:57:04 --> Controller Class Initialized
INFO - 2024-04-14 06:57:04 --> Model Class Initialized
DEBUG - 2024-04-14 06:57:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:57:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:57:04 --> Model Class Initialized
DEBUG - 2024-04-14 06:57:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:57:04 --> Model Class Initialized
INFO - 2024-04-14 06:57:04 --> Email Class Initialized
INFO - 2024-04-14 06:57:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html_pdf.php
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/frame_reflower.cls.php 210
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/frame_reflower.cls.php 211
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/block_frame_reflower.cls.php 726
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-04-14 06:57:04 --> Language file loaded: language/english/email_lang.php
INFO - 2024-04-14 06:57:04 --> Final output sent to browser
DEBUG - 2024-04-14 06:57:04 --> Total execution time: 0.2511
ERROR - 2024-04-14 06:57:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:57:05 --> Config Class Initialized
INFO - 2024-04-14 06:57:05 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:57:05 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:57:05 --> Utf8 Class Initialized
INFO - 2024-04-14 06:57:05 --> URI Class Initialized
INFO - 2024-04-14 06:57:05 --> Router Class Initialized
INFO - 2024-04-14 06:57:05 --> Output Class Initialized
INFO - 2024-04-14 06:57:05 --> Security Class Initialized
DEBUG - 2024-04-14 06:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:57:05 --> Input Class Initialized
INFO - 2024-04-14 06:57:05 --> Language Class Initialized
INFO - 2024-04-14 06:57:05 --> Loader Class Initialized
INFO - 2024-04-14 06:57:05 --> Helper loaded: url_helper
INFO - 2024-04-14 06:57:05 --> Helper loaded: file_helper
INFO - 2024-04-14 06:57:05 --> Helper loaded: html_helper
INFO - 2024-04-14 06:57:05 --> Helper loaded: text_helper
INFO - 2024-04-14 06:57:05 --> Helper loaded: form_helper
INFO - 2024-04-14 06:57:05 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:57:05 --> Helper loaded: security_helper
INFO - 2024-04-14 06:57:05 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:57:05 --> Database Driver Class Initialized
INFO - 2024-04-14 06:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:57:05 --> Parser Class Initialized
INFO - 2024-04-14 06:57:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:57:05 --> Pagination Class Initialized
INFO - 2024-04-14 06:57:05 --> Form Validation Class Initialized
INFO - 2024-04-14 06:57:05 --> Controller Class Initialized
INFO - 2024-04-14 06:57:05 --> Model Class Initialized
DEBUG - 2024-04-14 06:57:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:57:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:57:05 --> Model Class Initialized
DEBUG - 2024-04-14 06:57:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:57:05 --> Model Class Initialized
INFO - 2024-04-14 06:57:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html.php
DEBUG - 2024-04-14 06:57:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:57:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 06:57:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 06:57:05 --> Model Class Initialized
INFO - 2024-04-14 06:57:05 --> Model Class Initialized
INFO - 2024-04-14 06:57:05 --> Model Class Initialized
INFO - 2024-04-14 06:57:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-14 06:57:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-14 06:57:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 06:57:05 --> Final output sent to browser
DEBUG - 2024-04-14 06:57:05 --> Total execution time: 0.2934
ERROR - 2024-04-14 06:57:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:57:09 --> Config Class Initialized
INFO - 2024-04-14 06:57:09 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:57:09 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:57:09 --> Utf8 Class Initialized
INFO - 2024-04-14 06:57:09 --> URI Class Initialized
INFO - 2024-04-14 06:57:09 --> Router Class Initialized
INFO - 2024-04-14 06:57:09 --> Output Class Initialized
INFO - 2024-04-14 06:57:09 --> Security Class Initialized
DEBUG - 2024-04-14 06:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:57:09 --> Input Class Initialized
INFO - 2024-04-14 06:57:09 --> Language Class Initialized
INFO - 2024-04-14 06:57:09 --> Loader Class Initialized
INFO - 2024-04-14 06:57:09 --> Helper loaded: url_helper
INFO - 2024-04-14 06:57:09 --> Helper loaded: file_helper
INFO - 2024-04-14 06:57:09 --> Helper loaded: html_helper
INFO - 2024-04-14 06:57:09 --> Helper loaded: text_helper
INFO - 2024-04-14 06:57:09 --> Helper loaded: form_helper
INFO - 2024-04-14 06:57:09 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:57:09 --> Helper loaded: security_helper
INFO - 2024-04-14 06:57:09 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:57:09 --> Database Driver Class Initialized
INFO - 2024-04-14 06:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:57:09 --> Parser Class Initialized
INFO - 2024-04-14 06:57:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:57:09 --> Pagination Class Initialized
INFO - 2024-04-14 06:57:09 --> Form Validation Class Initialized
INFO - 2024-04-14 06:57:09 --> Controller Class Initialized
INFO - 2024-04-14 06:57:09 --> Model Class Initialized
DEBUG - 2024-04-14 06:57:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:57:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:57:09 --> Model Class Initialized
DEBUG - 2024-04-14 06:57:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:57:09 --> Model Class Initialized
INFO - 2024-04-14 06:57:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-04-14 06:57:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:57:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 06:57:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 06:57:09 --> Model Class Initialized
INFO - 2024-04-14 06:57:09 --> Model Class Initialized
INFO - 2024-04-14 06:57:09 --> Model Class Initialized
INFO - 2024-04-14 06:57:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-14 06:57:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-14 06:57:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 06:57:09 --> Final output sent to browser
DEBUG - 2024-04-14 06:57:09 --> Total execution time: 0.2859
ERROR - 2024-04-14 06:57:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:57:10 --> Config Class Initialized
INFO - 2024-04-14 06:57:10 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:57:10 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:57:10 --> Utf8 Class Initialized
INFO - 2024-04-14 06:57:10 --> URI Class Initialized
INFO - 2024-04-14 06:57:10 --> Router Class Initialized
INFO - 2024-04-14 06:57:10 --> Output Class Initialized
INFO - 2024-04-14 06:57:10 --> Security Class Initialized
DEBUG - 2024-04-14 06:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:57:10 --> Input Class Initialized
INFO - 2024-04-14 06:57:10 --> Language Class Initialized
INFO - 2024-04-14 06:57:10 --> Loader Class Initialized
INFO - 2024-04-14 06:57:10 --> Helper loaded: url_helper
INFO - 2024-04-14 06:57:10 --> Helper loaded: file_helper
INFO - 2024-04-14 06:57:10 --> Helper loaded: html_helper
INFO - 2024-04-14 06:57:10 --> Helper loaded: text_helper
INFO - 2024-04-14 06:57:10 --> Helper loaded: form_helper
INFO - 2024-04-14 06:57:10 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:57:10 --> Helper loaded: security_helper
INFO - 2024-04-14 06:57:10 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:57:10 --> Database Driver Class Initialized
INFO - 2024-04-14 06:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:57:10 --> Parser Class Initialized
INFO - 2024-04-14 06:57:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:57:10 --> Pagination Class Initialized
INFO - 2024-04-14 06:57:10 --> Form Validation Class Initialized
INFO - 2024-04-14 06:57:10 --> Controller Class Initialized
INFO - 2024-04-14 06:57:10 --> Model Class Initialized
DEBUG - 2024-04-14 06:57:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:57:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:57:10 --> Model Class Initialized
DEBUG - 2024-04-14 06:57:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:57:10 --> Model Class Initialized
INFO - 2024-04-14 06:57:10 --> Final output sent to browser
DEBUG - 2024-04-14 06:57:10 --> Total execution time: 0.0425
ERROR - 2024-04-14 06:57:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:57:13 --> Config Class Initialized
INFO - 2024-04-14 06:57:13 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:57:13 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:57:13 --> Utf8 Class Initialized
INFO - 2024-04-14 06:57:13 --> URI Class Initialized
INFO - 2024-04-14 06:57:13 --> Router Class Initialized
INFO - 2024-04-14 06:57:13 --> Output Class Initialized
INFO - 2024-04-14 06:57:13 --> Security Class Initialized
DEBUG - 2024-04-14 06:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:57:13 --> Input Class Initialized
INFO - 2024-04-14 06:57:13 --> Language Class Initialized
INFO - 2024-04-14 06:57:13 --> Loader Class Initialized
INFO - 2024-04-14 06:57:13 --> Helper loaded: url_helper
INFO - 2024-04-14 06:57:13 --> Helper loaded: file_helper
INFO - 2024-04-14 06:57:13 --> Helper loaded: html_helper
INFO - 2024-04-14 06:57:13 --> Helper loaded: text_helper
INFO - 2024-04-14 06:57:13 --> Helper loaded: form_helper
INFO - 2024-04-14 06:57:13 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:57:13 --> Helper loaded: security_helper
INFO - 2024-04-14 06:57:13 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:57:13 --> Database Driver Class Initialized
INFO - 2024-04-14 06:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:57:13 --> Parser Class Initialized
INFO - 2024-04-14 06:57:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:57:13 --> Pagination Class Initialized
INFO - 2024-04-14 06:57:13 --> Form Validation Class Initialized
INFO - 2024-04-14 06:57:13 --> Controller Class Initialized
INFO - 2024-04-14 06:57:13 --> Model Class Initialized
DEBUG - 2024-04-14 06:57:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:57:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:57:13 --> Model Class Initialized
DEBUG - 2024-04-14 06:57:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:57:13 --> Model Class Initialized
INFO - 2024-04-14 06:57:15 --> Final output sent to browser
DEBUG - 2024-04-14 06:57:15 --> Total execution time: 1.5990
ERROR - 2024-04-14 06:57:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:57:38 --> Config Class Initialized
INFO - 2024-04-14 06:57:38 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:57:38 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:57:38 --> Utf8 Class Initialized
INFO - 2024-04-14 06:57:38 --> URI Class Initialized
INFO - 2024-04-14 06:57:38 --> Router Class Initialized
INFO - 2024-04-14 06:57:38 --> Output Class Initialized
INFO - 2024-04-14 06:57:38 --> Security Class Initialized
DEBUG - 2024-04-14 06:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:57:38 --> Input Class Initialized
INFO - 2024-04-14 06:57:38 --> Language Class Initialized
INFO - 2024-04-14 06:57:38 --> Loader Class Initialized
INFO - 2024-04-14 06:57:38 --> Helper loaded: url_helper
INFO - 2024-04-14 06:57:38 --> Helper loaded: file_helper
INFO - 2024-04-14 06:57:38 --> Helper loaded: html_helper
INFO - 2024-04-14 06:57:38 --> Helper loaded: text_helper
INFO - 2024-04-14 06:57:38 --> Helper loaded: form_helper
INFO - 2024-04-14 06:57:38 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:57:38 --> Helper loaded: security_helper
INFO - 2024-04-14 06:57:38 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:57:38 --> Database Driver Class Initialized
INFO - 2024-04-14 06:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:57:38 --> Parser Class Initialized
INFO - 2024-04-14 06:57:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:57:38 --> Pagination Class Initialized
INFO - 2024-04-14 06:57:38 --> Form Validation Class Initialized
INFO - 2024-04-14 06:57:38 --> Controller Class Initialized
INFO - 2024-04-14 06:57:38 --> Model Class Initialized
DEBUG - 2024-04-14 06:57:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:57:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:57:38 --> Model Class Initialized
DEBUG - 2024-04-14 06:57:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:57:38 --> Model Class Initialized
INFO - 2024-04-14 06:57:38 --> Email Class Initialized
INFO - 2024-04-14 06:57:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html_pdf.php
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/frame_reflower.cls.php 210
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/frame_reflower.cls.php 211
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/block_frame_reflower.cls.php 726
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:57:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-04-14 06:57:38 --> Language file loaded: language/english/email_lang.php
INFO - 2024-04-14 06:57:38 --> Final output sent to browser
DEBUG - 2024-04-14 06:57:38 --> Total execution time: 0.2468
ERROR - 2024-04-14 06:57:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:57:38 --> Config Class Initialized
INFO - 2024-04-14 06:57:38 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:57:38 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:57:38 --> Utf8 Class Initialized
INFO - 2024-04-14 06:57:38 --> URI Class Initialized
INFO - 2024-04-14 06:57:38 --> Router Class Initialized
INFO - 2024-04-14 06:57:38 --> Output Class Initialized
INFO - 2024-04-14 06:57:38 --> Security Class Initialized
DEBUG - 2024-04-14 06:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:57:38 --> Input Class Initialized
INFO - 2024-04-14 06:57:38 --> Language Class Initialized
INFO - 2024-04-14 06:57:38 --> Loader Class Initialized
INFO - 2024-04-14 06:57:38 --> Helper loaded: url_helper
INFO - 2024-04-14 06:57:38 --> Helper loaded: file_helper
INFO - 2024-04-14 06:57:38 --> Helper loaded: html_helper
INFO - 2024-04-14 06:57:38 --> Helper loaded: text_helper
INFO - 2024-04-14 06:57:38 --> Helper loaded: form_helper
INFO - 2024-04-14 06:57:38 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:57:38 --> Helper loaded: security_helper
INFO - 2024-04-14 06:57:38 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:57:38 --> Database Driver Class Initialized
INFO - 2024-04-14 06:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:57:38 --> Parser Class Initialized
INFO - 2024-04-14 06:57:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:57:38 --> Pagination Class Initialized
INFO - 2024-04-14 06:57:38 --> Form Validation Class Initialized
INFO - 2024-04-14 06:57:38 --> Controller Class Initialized
INFO - 2024-04-14 06:57:38 --> Model Class Initialized
DEBUG - 2024-04-14 06:57:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:57:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:57:38 --> Model Class Initialized
DEBUG - 2024-04-14 06:57:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:57:38 --> Model Class Initialized
INFO - 2024-04-14 06:57:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html.php
DEBUG - 2024-04-14 06:57:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:57:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 06:57:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 06:57:38 --> Model Class Initialized
INFO - 2024-04-14 06:57:38 --> Model Class Initialized
INFO - 2024-04-14 06:57:38 --> Model Class Initialized
INFO - 2024-04-14 06:57:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-14 06:57:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-14 06:57:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 06:57:39 --> Final output sent to browser
DEBUG - 2024-04-14 06:57:39 --> Total execution time: 0.3204
ERROR - 2024-04-14 06:57:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:57:42 --> Config Class Initialized
INFO - 2024-04-14 06:57:42 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:57:42 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:57:42 --> Utf8 Class Initialized
INFO - 2024-04-14 06:57:42 --> URI Class Initialized
INFO - 2024-04-14 06:57:42 --> Router Class Initialized
INFO - 2024-04-14 06:57:42 --> Output Class Initialized
INFO - 2024-04-14 06:57:42 --> Security Class Initialized
DEBUG - 2024-04-14 06:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:57:42 --> Input Class Initialized
INFO - 2024-04-14 06:57:42 --> Language Class Initialized
INFO - 2024-04-14 06:57:42 --> Loader Class Initialized
INFO - 2024-04-14 06:57:42 --> Helper loaded: url_helper
INFO - 2024-04-14 06:57:42 --> Helper loaded: file_helper
INFO - 2024-04-14 06:57:42 --> Helper loaded: html_helper
INFO - 2024-04-14 06:57:42 --> Helper loaded: text_helper
INFO - 2024-04-14 06:57:42 --> Helper loaded: form_helper
INFO - 2024-04-14 06:57:42 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:57:42 --> Helper loaded: security_helper
INFO - 2024-04-14 06:57:42 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:57:42 --> Database Driver Class Initialized
INFO - 2024-04-14 06:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:57:42 --> Parser Class Initialized
INFO - 2024-04-14 06:57:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:57:42 --> Pagination Class Initialized
INFO - 2024-04-14 06:57:42 --> Form Validation Class Initialized
INFO - 2024-04-14 06:57:42 --> Controller Class Initialized
INFO - 2024-04-14 06:57:42 --> Model Class Initialized
DEBUG - 2024-04-14 06:57:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:57:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:57:42 --> Model Class Initialized
DEBUG - 2024-04-14 06:57:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:57:42 --> Model Class Initialized
INFO - 2024-04-14 06:57:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-04-14 06:57:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:57:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 06:57:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 06:57:42 --> Model Class Initialized
INFO - 2024-04-14 06:57:42 --> Model Class Initialized
INFO - 2024-04-14 06:57:42 --> Model Class Initialized
INFO - 2024-04-14 06:57:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-14 06:57:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-14 06:57:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 06:57:43 --> Final output sent to browser
DEBUG - 2024-04-14 06:57:43 --> Total execution time: 0.2871
ERROR - 2024-04-14 06:57:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:57:43 --> Config Class Initialized
INFO - 2024-04-14 06:57:43 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:57:43 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:57:43 --> Utf8 Class Initialized
INFO - 2024-04-14 06:57:43 --> URI Class Initialized
INFO - 2024-04-14 06:57:43 --> Router Class Initialized
INFO - 2024-04-14 06:57:43 --> Output Class Initialized
INFO - 2024-04-14 06:57:43 --> Security Class Initialized
DEBUG - 2024-04-14 06:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:57:43 --> Input Class Initialized
INFO - 2024-04-14 06:57:43 --> Language Class Initialized
INFO - 2024-04-14 06:57:43 --> Loader Class Initialized
INFO - 2024-04-14 06:57:43 --> Helper loaded: url_helper
INFO - 2024-04-14 06:57:43 --> Helper loaded: file_helper
INFO - 2024-04-14 06:57:43 --> Helper loaded: html_helper
INFO - 2024-04-14 06:57:43 --> Helper loaded: text_helper
INFO - 2024-04-14 06:57:43 --> Helper loaded: form_helper
INFO - 2024-04-14 06:57:43 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:57:43 --> Helper loaded: security_helper
INFO - 2024-04-14 06:57:43 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:57:43 --> Database Driver Class Initialized
INFO - 2024-04-14 06:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:57:43 --> Parser Class Initialized
INFO - 2024-04-14 06:57:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:57:43 --> Pagination Class Initialized
INFO - 2024-04-14 06:57:43 --> Form Validation Class Initialized
INFO - 2024-04-14 06:57:43 --> Controller Class Initialized
INFO - 2024-04-14 06:57:43 --> Model Class Initialized
DEBUG - 2024-04-14 06:57:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:57:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:57:43 --> Model Class Initialized
DEBUG - 2024-04-14 06:57:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:57:43 --> Model Class Initialized
INFO - 2024-04-14 06:57:43 --> Final output sent to browser
DEBUG - 2024-04-14 06:57:43 --> Total execution time: 0.0500
ERROR - 2024-04-14 06:57:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:57:46 --> Config Class Initialized
INFO - 2024-04-14 06:57:46 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:57:46 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:57:46 --> Utf8 Class Initialized
INFO - 2024-04-14 06:57:46 --> URI Class Initialized
INFO - 2024-04-14 06:57:46 --> Router Class Initialized
INFO - 2024-04-14 06:57:46 --> Output Class Initialized
INFO - 2024-04-14 06:57:46 --> Security Class Initialized
DEBUG - 2024-04-14 06:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:57:46 --> Input Class Initialized
INFO - 2024-04-14 06:57:46 --> Language Class Initialized
INFO - 2024-04-14 06:57:46 --> Loader Class Initialized
INFO - 2024-04-14 06:57:46 --> Helper loaded: url_helper
INFO - 2024-04-14 06:57:46 --> Helper loaded: file_helper
INFO - 2024-04-14 06:57:46 --> Helper loaded: html_helper
INFO - 2024-04-14 06:57:46 --> Helper loaded: text_helper
INFO - 2024-04-14 06:57:46 --> Helper loaded: form_helper
INFO - 2024-04-14 06:57:46 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:57:46 --> Helper loaded: security_helper
INFO - 2024-04-14 06:57:46 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:57:46 --> Database Driver Class Initialized
INFO - 2024-04-14 06:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:57:46 --> Parser Class Initialized
INFO - 2024-04-14 06:57:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:57:46 --> Pagination Class Initialized
INFO - 2024-04-14 06:57:46 --> Form Validation Class Initialized
INFO - 2024-04-14 06:57:46 --> Controller Class Initialized
INFO - 2024-04-14 06:57:46 --> Model Class Initialized
DEBUG - 2024-04-14 06:57:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:57:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:57:46 --> Model Class Initialized
DEBUG - 2024-04-14 06:57:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:57:46 --> Model Class Initialized
INFO - 2024-04-14 06:57:47 --> Final output sent to browser
DEBUG - 2024-04-14 06:57:47 --> Total execution time: 1.3623
ERROR - 2024-04-14 06:58:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:58:08 --> Config Class Initialized
INFO - 2024-04-14 06:58:08 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:58:08 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:58:08 --> Utf8 Class Initialized
INFO - 2024-04-14 06:58:08 --> URI Class Initialized
INFO - 2024-04-14 06:58:08 --> Router Class Initialized
INFO - 2024-04-14 06:58:08 --> Output Class Initialized
INFO - 2024-04-14 06:58:08 --> Security Class Initialized
DEBUG - 2024-04-14 06:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:58:08 --> Input Class Initialized
INFO - 2024-04-14 06:58:08 --> Language Class Initialized
INFO - 2024-04-14 06:58:08 --> Loader Class Initialized
INFO - 2024-04-14 06:58:08 --> Helper loaded: url_helper
INFO - 2024-04-14 06:58:08 --> Helper loaded: file_helper
INFO - 2024-04-14 06:58:08 --> Helper loaded: html_helper
INFO - 2024-04-14 06:58:08 --> Helper loaded: text_helper
INFO - 2024-04-14 06:58:08 --> Helper loaded: form_helper
INFO - 2024-04-14 06:58:08 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:58:08 --> Helper loaded: security_helper
INFO - 2024-04-14 06:58:08 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:58:08 --> Database Driver Class Initialized
INFO - 2024-04-14 06:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:58:08 --> Parser Class Initialized
INFO - 2024-04-14 06:58:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:58:08 --> Pagination Class Initialized
INFO - 2024-04-14 06:58:08 --> Form Validation Class Initialized
INFO - 2024-04-14 06:58:08 --> Controller Class Initialized
INFO - 2024-04-14 06:58:08 --> Model Class Initialized
DEBUG - 2024-04-14 06:58:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:58:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:58:08 --> Model Class Initialized
DEBUG - 2024-04-14 06:58:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:58:08 --> Model Class Initialized
INFO - 2024-04-14 06:58:08 --> Email Class Initialized
INFO - 2024-04-14 06:58:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html_pdf.php
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/frame_reflower.cls.php 210
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/frame_reflower.cls.php 211
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/block_frame_reflower.cls.php 726
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-04-14 06:58:08 --> Language file loaded: language/english/email_lang.php
INFO - 2024-04-14 06:58:08 --> Final output sent to browser
DEBUG - 2024-04-14 06:58:08 --> Total execution time: 0.2642
ERROR - 2024-04-14 06:58:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:58:09 --> Config Class Initialized
INFO - 2024-04-14 06:58:09 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:58:09 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:58:09 --> Utf8 Class Initialized
INFO - 2024-04-14 06:58:09 --> URI Class Initialized
INFO - 2024-04-14 06:58:09 --> Router Class Initialized
INFO - 2024-04-14 06:58:09 --> Output Class Initialized
INFO - 2024-04-14 06:58:09 --> Security Class Initialized
DEBUG - 2024-04-14 06:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:58:09 --> Input Class Initialized
INFO - 2024-04-14 06:58:09 --> Language Class Initialized
INFO - 2024-04-14 06:58:09 --> Loader Class Initialized
INFO - 2024-04-14 06:58:09 --> Helper loaded: url_helper
INFO - 2024-04-14 06:58:09 --> Helper loaded: file_helper
INFO - 2024-04-14 06:58:09 --> Helper loaded: html_helper
INFO - 2024-04-14 06:58:09 --> Helper loaded: text_helper
INFO - 2024-04-14 06:58:09 --> Helper loaded: form_helper
INFO - 2024-04-14 06:58:09 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:58:09 --> Helper loaded: security_helper
INFO - 2024-04-14 06:58:09 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:58:09 --> Database Driver Class Initialized
INFO - 2024-04-14 06:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:58:09 --> Parser Class Initialized
INFO - 2024-04-14 06:58:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:58:09 --> Pagination Class Initialized
INFO - 2024-04-14 06:58:09 --> Form Validation Class Initialized
INFO - 2024-04-14 06:58:09 --> Controller Class Initialized
INFO - 2024-04-14 06:58:09 --> Model Class Initialized
DEBUG - 2024-04-14 06:58:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:58:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:58:09 --> Model Class Initialized
DEBUG - 2024-04-14 06:58:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:58:09 --> Model Class Initialized
INFO - 2024-04-14 06:58:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html.php
DEBUG - 2024-04-14 06:58:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:58:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 06:58:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 06:58:09 --> Model Class Initialized
INFO - 2024-04-14 06:58:09 --> Model Class Initialized
INFO - 2024-04-14 06:58:09 --> Model Class Initialized
INFO - 2024-04-14 06:58:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-14 06:58:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-14 06:58:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 06:58:09 --> Final output sent to browser
DEBUG - 2024-04-14 06:58:09 --> Total execution time: 0.3012
ERROR - 2024-04-14 06:58:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:58:13 --> Config Class Initialized
INFO - 2024-04-14 06:58:13 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:58:13 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:58:13 --> Utf8 Class Initialized
INFO - 2024-04-14 06:58:13 --> URI Class Initialized
INFO - 2024-04-14 06:58:13 --> Router Class Initialized
INFO - 2024-04-14 06:58:13 --> Output Class Initialized
INFO - 2024-04-14 06:58:13 --> Security Class Initialized
DEBUG - 2024-04-14 06:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:58:13 --> Input Class Initialized
INFO - 2024-04-14 06:58:13 --> Language Class Initialized
INFO - 2024-04-14 06:58:13 --> Loader Class Initialized
INFO - 2024-04-14 06:58:13 --> Helper loaded: url_helper
INFO - 2024-04-14 06:58:13 --> Helper loaded: file_helper
INFO - 2024-04-14 06:58:13 --> Helper loaded: html_helper
INFO - 2024-04-14 06:58:13 --> Helper loaded: text_helper
INFO - 2024-04-14 06:58:13 --> Helper loaded: form_helper
INFO - 2024-04-14 06:58:13 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:58:13 --> Helper loaded: security_helper
INFO - 2024-04-14 06:58:13 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:58:13 --> Database Driver Class Initialized
INFO - 2024-04-14 06:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:58:13 --> Parser Class Initialized
INFO - 2024-04-14 06:58:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:58:13 --> Pagination Class Initialized
INFO - 2024-04-14 06:58:13 --> Form Validation Class Initialized
INFO - 2024-04-14 06:58:13 --> Controller Class Initialized
INFO - 2024-04-14 06:58:13 --> Model Class Initialized
DEBUG - 2024-04-14 06:58:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:58:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:58:13 --> Model Class Initialized
DEBUG - 2024-04-14 06:58:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:58:13 --> Model Class Initialized
INFO - 2024-04-14 06:58:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-04-14 06:58:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:58:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 06:58:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 06:58:13 --> Model Class Initialized
INFO - 2024-04-14 06:58:13 --> Model Class Initialized
INFO - 2024-04-14 06:58:13 --> Model Class Initialized
INFO - 2024-04-14 06:58:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-14 06:58:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-14 06:58:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 06:58:13 --> Final output sent to browser
DEBUG - 2024-04-14 06:58:13 --> Total execution time: 0.3150
ERROR - 2024-04-14 06:58:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:58:14 --> Config Class Initialized
INFO - 2024-04-14 06:58:14 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:58:14 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:58:14 --> Utf8 Class Initialized
INFO - 2024-04-14 06:58:14 --> URI Class Initialized
INFO - 2024-04-14 06:58:14 --> Router Class Initialized
INFO - 2024-04-14 06:58:14 --> Output Class Initialized
INFO - 2024-04-14 06:58:14 --> Security Class Initialized
DEBUG - 2024-04-14 06:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:58:14 --> Input Class Initialized
INFO - 2024-04-14 06:58:14 --> Language Class Initialized
INFO - 2024-04-14 06:58:14 --> Loader Class Initialized
INFO - 2024-04-14 06:58:14 --> Helper loaded: url_helper
INFO - 2024-04-14 06:58:14 --> Helper loaded: file_helper
INFO - 2024-04-14 06:58:14 --> Helper loaded: html_helper
INFO - 2024-04-14 06:58:14 --> Helper loaded: text_helper
INFO - 2024-04-14 06:58:14 --> Helper loaded: form_helper
INFO - 2024-04-14 06:58:14 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:58:14 --> Helper loaded: security_helper
INFO - 2024-04-14 06:58:14 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:58:14 --> Database Driver Class Initialized
INFO - 2024-04-14 06:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:58:14 --> Parser Class Initialized
INFO - 2024-04-14 06:58:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:58:14 --> Pagination Class Initialized
INFO - 2024-04-14 06:58:14 --> Form Validation Class Initialized
INFO - 2024-04-14 06:58:14 --> Controller Class Initialized
INFO - 2024-04-14 06:58:14 --> Model Class Initialized
DEBUG - 2024-04-14 06:58:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:58:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:58:14 --> Model Class Initialized
DEBUG - 2024-04-14 06:58:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:58:14 --> Model Class Initialized
INFO - 2024-04-14 06:58:14 --> Final output sent to browser
DEBUG - 2024-04-14 06:58:14 --> Total execution time: 0.0523
ERROR - 2024-04-14 06:58:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:58:16 --> Config Class Initialized
INFO - 2024-04-14 06:58:16 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:58:16 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:58:16 --> Utf8 Class Initialized
INFO - 2024-04-14 06:58:16 --> URI Class Initialized
INFO - 2024-04-14 06:58:16 --> Router Class Initialized
INFO - 2024-04-14 06:58:16 --> Output Class Initialized
INFO - 2024-04-14 06:58:16 --> Security Class Initialized
DEBUG - 2024-04-14 06:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:58:16 --> Input Class Initialized
INFO - 2024-04-14 06:58:16 --> Language Class Initialized
INFO - 2024-04-14 06:58:16 --> Loader Class Initialized
INFO - 2024-04-14 06:58:16 --> Helper loaded: url_helper
INFO - 2024-04-14 06:58:16 --> Helper loaded: file_helper
INFO - 2024-04-14 06:58:16 --> Helper loaded: html_helper
INFO - 2024-04-14 06:58:16 --> Helper loaded: text_helper
INFO - 2024-04-14 06:58:16 --> Helper loaded: form_helper
INFO - 2024-04-14 06:58:16 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:58:16 --> Helper loaded: security_helper
INFO - 2024-04-14 06:58:16 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:58:16 --> Database Driver Class Initialized
INFO - 2024-04-14 06:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:58:16 --> Parser Class Initialized
INFO - 2024-04-14 06:58:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:58:16 --> Pagination Class Initialized
INFO - 2024-04-14 06:58:16 --> Form Validation Class Initialized
INFO - 2024-04-14 06:58:16 --> Controller Class Initialized
INFO - 2024-04-14 06:58:16 --> Model Class Initialized
DEBUG - 2024-04-14 06:58:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:58:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:58:16 --> Model Class Initialized
DEBUG - 2024-04-14 06:58:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:58:16 --> Model Class Initialized
INFO - 2024-04-14 06:58:17 --> Final output sent to browser
DEBUG - 2024-04-14 06:58:17 --> Total execution time: 1.3999
ERROR - 2024-04-14 06:58:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:58:59 --> Config Class Initialized
INFO - 2024-04-14 06:58:59 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:58:59 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:58:59 --> Utf8 Class Initialized
INFO - 2024-04-14 06:58:59 --> URI Class Initialized
INFO - 2024-04-14 06:58:59 --> Router Class Initialized
INFO - 2024-04-14 06:58:59 --> Output Class Initialized
INFO - 2024-04-14 06:58:59 --> Security Class Initialized
DEBUG - 2024-04-14 06:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:58:59 --> Input Class Initialized
INFO - 2024-04-14 06:58:59 --> Language Class Initialized
INFO - 2024-04-14 06:58:59 --> Loader Class Initialized
INFO - 2024-04-14 06:58:59 --> Helper loaded: url_helper
INFO - 2024-04-14 06:58:59 --> Helper loaded: file_helper
INFO - 2024-04-14 06:58:59 --> Helper loaded: html_helper
INFO - 2024-04-14 06:58:59 --> Helper loaded: text_helper
INFO - 2024-04-14 06:58:59 --> Helper loaded: form_helper
INFO - 2024-04-14 06:58:59 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:58:59 --> Helper loaded: security_helper
INFO - 2024-04-14 06:58:59 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:58:59 --> Database Driver Class Initialized
INFO - 2024-04-14 06:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:58:59 --> Parser Class Initialized
INFO - 2024-04-14 06:58:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:58:59 --> Pagination Class Initialized
INFO - 2024-04-14 06:58:59 --> Form Validation Class Initialized
INFO - 2024-04-14 06:58:59 --> Controller Class Initialized
INFO - 2024-04-14 06:58:59 --> Model Class Initialized
DEBUG - 2024-04-14 06:58:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:58:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:58:59 --> Model Class Initialized
DEBUG - 2024-04-14 06:58:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:58:59 --> Model Class Initialized
INFO - 2024-04-14 06:58:59 --> Email Class Initialized
INFO - 2024-04-14 06:58:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html_pdf.php
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/frame_reflower.cls.php 210
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/frame_reflower.cls.php 211
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/block_frame_reflower.cls.php 726
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/block_frame_reflower.cls.php 726
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:58:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-04-14 06:58:59 --> Language file loaded: language/english/email_lang.php
INFO - 2024-04-14 06:58:59 --> Final output sent to browser
DEBUG - 2024-04-14 06:58:59 --> Total execution time: 0.2903
ERROR - 2024-04-14 06:58:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:58:59 --> Config Class Initialized
INFO - 2024-04-14 06:58:59 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:58:59 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:58:59 --> Utf8 Class Initialized
INFO - 2024-04-14 06:58:59 --> URI Class Initialized
INFO - 2024-04-14 06:58:59 --> Router Class Initialized
INFO - 2024-04-14 06:58:59 --> Output Class Initialized
INFO - 2024-04-14 06:58:59 --> Security Class Initialized
DEBUG - 2024-04-14 06:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:58:59 --> Input Class Initialized
INFO - 2024-04-14 06:58:59 --> Language Class Initialized
INFO - 2024-04-14 06:58:59 --> Loader Class Initialized
INFO - 2024-04-14 06:58:59 --> Helper loaded: url_helper
INFO - 2024-04-14 06:58:59 --> Helper loaded: file_helper
INFO - 2024-04-14 06:58:59 --> Helper loaded: html_helper
INFO - 2024-04-14 06:58:59 --> Helper loaded: text_helper
INFO - 2024-04-14 06:58:59 --> Helper loaded: form_helper
INFO - 2024-04-14 06:58:59 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:58:59 --> Helper loaded: security_helper
INFO - 2024-04-14 06:58:59 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:58:59 --> Database Driver Class Initialized
INFO - 2024-04-14 06:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:58:59 --> Parser Class Initialized
INFO - 2024-04-14 06:58:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:58:59 --> Pagination Class Initialized
INFO - 2024-04-14 06:58:59 --> Form Validation Class Initialized
INFO - 2024-04-14 06:58:59 --> Controller Class Initialized
INFO - 2024-04-14 06:58:59 --> Model Class Initialized
DEBUG - 2024-04-14 06:58:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:58:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:58:59 --> Model Class Initialized
DEBUG - 2024-04-14 06:58:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:58:59 --> Model Class Initialized
INFO - 2024-04-14 06:58:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html.php
DEBUG - 2024-04-14 06:58:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:58:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 06:58:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 06:58:59 --> Model Class Initialized
INFO - 2024-04-14 06:58:59 --> Model Class Initialized
INFO - 2024-04-14 06:58:59 --> Model Class Initialized
INFO - 2024-04-14 06:59:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-14 06:59:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-14 06:59:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 06:59:00 --> Final output sent to browser
DEBUG - 2024-04-14 06:59:00 --> Total execution time: 0.3020
ERROR - 2024-04-14 06:59:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:59:03 --> Config Class Initialized
INFO - 2024-04-14 06:59:03 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:59:03 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:59:03 --> Utf8 Class Initialized
INFO - 2024-04-14 06:59:03 --> URI Class Initialized
INFO - 2024-04-14 06:59:03 --> Router Class Initialized
INFO - 2024-04-14 06:59:03 --> Output Class Initialized
INFO - 2024-04-14 06:59:03 --> Security Class Initialized
DEBUG - 2024-04-14 06:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:59:03 --> Input Class Initialized
INFO - 2024-04-14 06:59:03 --> Language Class Initialized
INFO - 2024-04-14 06:59:03 --> Loader Class Initialized
INFO - 2024-04-14 06:59:03 --> Helper loaded: url_helper
INFO - 2024-04-14 06:59:03 --> Helper loaded: file_helper
INFO - 2024-04-14 06:59:03 --> Helper loaded: html_helper
INFO - 2024-04-14 06:59:03 --> Helper loaded: text_helper
INFO - 2024-04-14 06:59:03 --> Helper loaded: form_helper
INFO - 2024-04-14 06:59:03 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:59:03 --> Helper loaded: security_helper
INFO - 2024-04-14 06:59:03 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:59:03 --> Database Driver Class Initialized
INFO - 2024-04-14 06:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:59:03 --> Parser Class Initialized
INFO - 2024-04-14 06:59:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:59:03 --> Pagination Class Initialized
INFO - 2024-04-14 06:59:03 --> Form Validation Class Initialized
INFO - 2024-04-14 06:59:03 --> Controller Class Initialized
INFO - 2024-04-14 06:59:03 --> Model Class Initialized
DEBUG - 2024-04-14 06:59:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:59:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:59:03 --> Model Class Initialized
DEBUG - 2024-04-14 06:59:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:59:03 --> Model Class Initialized
INFO - 2024-04-14 06:59:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-04-14 06:59:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:59:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 06:59:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 06:59:03 --> Model Class Initialized
INFO - 2024-04-14 06:59:03 --> Model Class Initialized
INFO - 2024-04-14 06:59:03 --> Model Class Initialized
INFO - 2024-04-14 06:59:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-14 06:59:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-14 06:59:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 06:59:03 --> Final output sent to browser
DEBUG - 2024-04-14 06:59:03 --> Total execution time: 0.3123
ERROR - 2024-04-14 06:59:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:59:05 --> Config Class Initialized
INFO - 2024-04-14 06:59:05 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:59:05 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:59:05 --> Utf8 Class Initialized
INFO - 2024-04-14 06:59:05 --> URI Class Initialized
INFO - 2024-04-14 06:59:05 --> Router Class Initialized
INFO - 2024-04-14 06:59:05 --> Output Class Initialized
INFO - 2024-04-14 06:59:05 --> Security Class Initialized
DEBUG - 2024-04-14 06:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:59:05 --> Input Class Initialized
INFO - 2024-04-14 06:59:05 --> Language Class Initialized
INFO - 2024-04-14 06:59:05 --> Loader Class Initialized
INFO - 2024-04-14 06:59:05 --> Helper loaded: url_helper
INFO - 2024-04-14 06:59:05 --> Helper loaded: file_helper
INFO - 2024-04-14 06:59:05 --> Helper loaded: html_helper
INFO - 2024-04-14 06:59:05 --> Helper loaded: text_helper
INFO - 2024-04-14 06:59:05 --> Helper loaded: form_helper
INFO - 2024-04-14 06:59:05 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:59:05 --> Helper loaded: security_helper
INFO - 2024-04-14 06:59:05 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:59:05 --> Database Driver Class Initialized
INFO - 2024-04-14 06:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:59:05 --> Parser Class Initialized
INFO - 2024-04-14 06:59:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:59:05 --> Pagination Class Initialized
INFO - 2024-04-14 06:59:05 --> Form Validation Class Initialized
INFO - 2024-04-14 06:59:05 --> Controller Class Initialized
INFO - 2024-04-14 06:59:05 --> Model Class Initialized
DEBUG - 2024-04-14 06:59:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:59:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:59:05 --> Model Class Initialized
DEBUG - 2024-04-14 06:59:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:59:05 --> Model Class Initialized
INFO - 2024-04-14 06:59:05 --> Final output sent to browser
DEBUG - 2024-04-14 06:59:05 --> Total execution time: 0.0406
ERROR - 2024-04-14 06:59:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:59:07 --> Config Class Initialized
INFO - 2024-04-14 06:59:07 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:59:07 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:59:07 --> Utf8 Class Initialized
INFO - 2024-04-14 06:59:07 --> URI Class Initialized
INFO - 2024-04-14 06:59:07 --> Router Class Initialized
INFO - 2024-04-14 06:59:07 --> Output Class Initialized
INFO - 2024-04-14 06:59:07 --> Security Class Initialized
DEBUG - 2024-04-14 06:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:59:07 --> Input Class Initialized
INFO - 2024-04-14 06:59:07 --> Language Class Initialized
INFO - 2024-04-14 06:59:07 --> Loader Class Initialized
INFO - 2024-04-14 06:59:07 --> Helper loaded: url_helper
INFO - 2024-04-14 06:59:07 --> Helper loaded: file_helper
INFO - 2024-04-14 06:59:07 --> Helper loaded: html_helper
INFO - 2024-04-14 06:59:07 --> Helper loaded: text_helper
INFO - 2024-04-14 06:59:07 --> Helper loaded: form_helper
INFO - 2024-04-14 06:59:07 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:59:07 --> Helper loaded: security_helper
INFO - 2024-04-14 06:59:07 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:59:07 --> Database Driver Class Initialized
INFO - 2024-04-14 06:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:59:07 --> Parser Class Initialized
INFO - 2024-04-14 06:59:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:59:07 --> Pagination Class Initialized
INFO - 2024-04-14 06:59:07 --> Form Validation Class Initialized
INFO - 2024-04-14 06:59:07 --> Controller Class Initialized
INFO - 2024-04-14 06:59:07 --> Model Class Initialized
DEBUG - 2024-04-14 06:59:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:59:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:59:07 --> Model Class Initialized
DEBUG - 2024-04-14 06:59:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:59:07 --> Model Class Initialized
INFO - 2024-04-14 06:59:08 --> Final output sent to browser
DEBUG - 2024-04-14 06:59:08 --> Total execution time: 1.3234
ERROR - 2024-04-14 06:59:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:59:44 --> Config Class Initialized
INFO - 2024-04-14 06:59:44 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:59:44 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:59:44 --> Utf8 Class Initialized
INFO - 2024-04-14 06:59:44 --> URI Class Initialized
INFO - 2024-04-14 06:59:44 --> Router Class Initialized
INFO - 2024-04-14 06:59:44 --> Output Class Initialized
INFO - 2024-04-14 06:59:44 --> Security Class Initialized
DEBUG - 2024-04-14 06:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:59:44 --> Input Class Initialized
INFO - 2024-04-14 06:59:44 --> Language Class Initialized
INFO - 2024-04-14 06:59:44 --> Loader Class Initialized
INFO - 2024-04-14 06:59:44 --> Helper loaded: url_helper
INFO - 2024-04-14 06:59:44 --> Helper loaded: file_helper
INFO - 2024-04-14 06:59:44 --> Helper loaded: html_helper
INFO - 2024-04-14 06:59:44 --> Helper loaded: text_helper
INFO - 2024-04-14 06:59:44 --> Helper loaded: form_helper
INFO - 2024-04-14 06:59:44 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:59:44 --> Helper loaded: security_helper
INFO - 2024-04-14 06:59:44 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:59:44 --> Database Driver Class Initialized
INFO - 2024-04-14 06:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:59:44 --> Parser Class Initialized
INFO - 2024-04-14 06:59:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:59:44 --> Pagination Class Initialized
INFO - 2024-04-14 06:59:44 --> Form Validation Class Initialized
INFO - 2024-04-14 06:59:44 --> Controller Class Initialized
INFO - 2024-04-14 06:59:44 --> Model Class Initialized
DEBUG - 2024-04-14 06:59:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:59:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:59:44 --> Model Class Initialized
DEBUG - 2024-04-14 06:59:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:59:44 --> Model Class Initialized
INFO - 2024-04-14 06:59:44 --> Email Class Initialized
INFO - 2024-04-14 06:59:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html_pdf.php
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/frame_reflower.cls.php 210
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/frame_reflower.cls.php 211
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/block_frame_reflower.cls.php 726
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 06:59:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-04-14 06:59:45 --> Language file loaded: language/english/email_lang.php
INFO - 2024-04-14 06:59:45 --> Final output sent to browser
DEBUG - 2024-04-14 06:59:45 --> Total execution time: 0.2341
ERROR - 2024-04-14 06:59:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:59:45 --> Config Class Initialized
INFO - 2024-04-14 06:59:45 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:59:45 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:59:45 --> Utf8 Class Initialized
INFO - 2024-04-14 06:59:45 --> URI Class Initialized
INFO - 2024-04-14 06:59:45 --> Router Class Initialized
INFO - 2024-04-14 06:59:45 --> Output Class Initialized
INFO - 2024-04-14 06:59:45 --> Security Class Initialized
DEBUG - 2024-04-14 06:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:59:45 --> Input Class Initialized
INFO - 2024-04-14 06:59:45 --> Language Class Initialized
INFO - 2024-04-14 06:59:45 --> Loader Class Initialized
INFO - 2024-04-14 06:59:45 --> Helper loaded: url_helper
INFO - 2024-04-14 06:59:45 --> Helper loaded: file_helper
INFO - 2024-04-14 06:59:45 --> Helper loaded: html_helper
INFO - 2024-04-14 06:59:45 --> Helper loaded: text_helper
INFO - 2024-04-14 06:59:45 --> Helper loaded: form_helper
INFO - 2024-04-14 06:59:45 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:59:45 --> Helper loaded: security_helper
INFO - 2024-04-14 06:59:45 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:59:45 --> Database Driver Class Initialized
INFO - 2024-04-14 06:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:59:45 --> Parser Class Initialized
INFO - 2024-04-14 06:59:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:59:45 --> Pagination Class Initialized
INFO - 2024-04-14 06:59:45 --> Form Validation Class Initialized
INFO - 2024-04-14 06:59:45 --> Controller Class Initialized
INFO - 2024-04-14 06:59:45 --> Model Class Initialized
DEBUG - 2024-04-14 06:59:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:59:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:59:45 --> Model Class Initialized
DEBUG - 2024-04-14 06:59:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:59:45 --> Model Class Initialized
INFO - 2024-04-14 06:59:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html.php
DEBUG - 2024-04-14 06:59:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:59:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 06:59:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 06:59:45 --> Model Class Initialized
INFO - 2024-04-14 06:59:45 --> Model Class Initialized
INFO - 2024-04-14 06:59:45 --> Model Class Initialized
INFO - 2024-04-14 06:59:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-14 06:59:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-14 06:59:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 06:59:45 --> Final output sent to browser
DEBUG - 2024-04-14 06:59:45 --> Total execution time: 0.2896
ERROR - 2024-04-14 06:59:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:59:48 --> Config Class Initialized
INFO - 2024-04-14 06:59:48 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:59:48 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:59:48 --> Utf8 Class Initialized
INFO - 2024-04-14 06:59:48 --> URI Class Initialized
INFO - 2024-04-14 06:59:48 --> Router Class Initialized
INFO - 2024-04-14 06:59:48 --> Output Class Initialized
INFO - 2024-04-14 06:59:48 --> Security Class Initialized
DEBUG - 2024-04-14 06:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:59:48 --> Input Class Initialized
INFO - 2024-04-14 06:59:48 --> Language Class Initialized
INFO - 2024-04-14 06:59:48 --> Loader Class Initialized
INFO - 2024-04-14 06:59:48 --> Helper loaded: url_helper
INFO - 2024-04-14 06:59:48 --> Helper loaded: file_helper
INFO - 2024-04-14 06:59:48 --> Helper loaded: html_helper
INFO - 2024-04-14 06:59:48 --> Helper loaded: text_helper
INFO - 2024-04-14 06:59:48 --> Helper loaded: form_helper
INFO - 2024-04-14 06:59:48 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:59:48 --> Helper loaded: security_helper
INFO - 2024-04-14 06:59:48 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:59:48 --> Database Driver Class Initialized
INFO - 2024-04-14 06:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:59:48 --> Parser Class Initialized
INFO - 2024-04-14 06:59:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:59:48 --> Pagination Class Initialized
INFO - 2024-04-14 06:59:48 --> Form Validation Class Initialized
INFO - 2024-04-14 06:59:48 --> Controller Class Initialized
INFO - 2024-04-14 06:59:48 --> Model Class Initialized
DEBUG - 2024-04-14 06:59:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:59:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:59:48 --> Model Class Initialized
DEBUG - 2024-04-14 06:59:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:59:48 --> Model Class Initialized
INFO - 2024-04-14 06:59:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-04-14 06:59:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:59:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 06:59:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 06:59:48 --> Model Class Initialized
INFO - 2024-04-14 06:59:48 --> Model Class Initialized
INFO - 2024-04-14 06:59:48 --> Model Class Initialized
INFO - 2024-04-14 06:59:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-14 06:59:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-14 06:59:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 06:59:49 --> Final output sent to browser
DEBUG - 2024-04-14 06:59:49 --> Total execution time: 0.3159
ERROR - 2024-04-14 06:59:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:59:49 --> Config Class Initialized
INFO - 2024-04-14 06:59:49 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:59:49 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:59:49 --> Utf8 Class Initialized
INFO - 2024-04-14 06:59:49 --> URI Class Initialized
INFO - 2024-04-14 06:59:49 --> Router Class Initialized
INFO - 2024-04-14 06:59:49 --> Output Class Initialized
INFO - 2024-04-14 06:59:49 --> Security Class Initialized
DEBUG - 2024-04-14 06:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:59:49 --> Input Class Initialized
INFO - 2024-04-14 06:59:49 --> Language Class Initialized
INFO - 2024-04-14 06:59:49 --> Loader Class Initialized
INFO - 2024-04-14 06:59:49 --> Helper loaded: url_helper
INFO - 2024-04-14 06:59:49 --> Helper loaded: file_helper
INFO - 2024-04-14 06:59:49 --> Helper loaded: html_helper
INFO - 2024-04-14 06:59:49 --> Helper loaded: text_helper
INFO - 2024-04-14 06:59:49 --> Helper loaded: form_helper
INFO - 2024-04-14 06:59:49 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:59:49 --> Helper loaded: security_helper
INFO - 2024-04-14 06:59:49 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:59:49 --> Database Driver Class Initialized
INFO - 2024-04-14 06:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:59:49 --> Parser Class Initialized
INFO - 2024-04-14 06:59:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:59:49 --> Pagination Class Initialized
INFO - 2024-04-14 06:59:49 --> Form Validation Class Initialized
INFO - 2024-04-14 06:59:49 --> Controller Class Initialized
INFO - 2024-04-14 06:59:49 --> Model Class Initialized
DEBUG - 2024-04-14 06:59:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:59:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:59:49 --> Model Class Initialized
DEBUG - 2024-04-14 06:59:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:59:49 --> Model Class Initialized
INFO - 2024-04-14 06:59:49 --> Final output sent to browser
DEBUG - 2024-04-14 06:59:49 --> Total execution time: 0.0430
ERROR - 2024-04-14 06:59:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 06:59:53 --> Config Class Initialized
INFO - 2024-04-14 06:59:53 --> Hooks Class Initialized
DEBUG - 2024-04-14 06:59:53 --> UTF-8 Support Enabled
INFO - 2024-04-14 06:59:53 --> Utf8 Class Initialized
INFO - 2024-04-14 06:59:53 --> URI Class Initialized
INFO - 2024-04-14 06:59:53 --> Router Class Initialized
INFO - 2024-04-14 06:59:53 --> Output Class Initialized
INFO - 2024-04-14 06:59:53 --> Security Class Initialized
DEBUG - 2024-04-14 06:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 06:59:53 --> Input Class Initialized
INFO - 2024-04-14 06:59:53 --> Language Class Initialized
INFO - 2024-04-14 06:59:53 --> Loader Class Initialized
INFO - 2024-04-14 06:59:53 --> Helper loaded: url_helper
INFO - 2024-04-14 06:59:53 --> Helper loaded: file_helper
INFO - 2024-04-14 06:59:53 --> Helper loaded: html_helper
INFO - 2024-04-14 06:59:53 --> Helper loaded: text_helper
INFO - 2024-04-14 06:59:53 --> Helper loaded: form_helper
INFO - 2024-04-14 06:59:53 --> Helper loaded: lang_helper
INFO - 2024-04-14 06:59:53 --> Helper loaded: security_helper
INFO - 2024-04-14 06:59:53 --> Helper loaded: cookie_helper
INFO - 2024-04-14 06:59:53 --> Database Driver Class Initialized
INFO - 2024-04-14 06:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 06:59:53 --> Parser Class Initialized
INFO - 2024-04-14 06:59:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 06:59:53 --> Pagination Class Initialized
INFO - 2024-04-14 06:59:53 --> Form Validation Class Initialized
INFO - 2024-04-14 06:59:53 --> Controller Class Initialized
INFO - 2024-04-14 06:59:53 --> Model Class Initialized
DEBUG - 2024-04-14 06:59:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 06:59:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:59:53 --> Model Class Initialized
DEBUG - 2024-04-14 06:59:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 06:59:53 --> Model Class Initialized
INFO - 2024-04-14 06:59:54 --> Final output sent to browser
DEBUG - 2024-04-14 06:59:54 --> Total execution time: 1.3919
ERROR - 2024-04-14 07:00:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 07:00:15 --> Config Class Initialized
INFO - 2024-04-14 07:00:15 --> Hooks Class Initialized
DEBUG - 2024-04-14 07:00:15 --> UTF-8 Support Enabled
INFO - 2024-04-14 07:00:15 --> Utf8 Class Initialized
INFO - 2024-04-14 07:00:15 --> URI Class Initialized
INFO - 2024-04-14 07:00:15 --> Router Class Initialized
INFO - 2024-04-14 07:00:15 --> Output Class Initialized
INFO - 2024-04-14 07:00:15 --> Security Class Initialized
DEBUG - 2024-04-14 07:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 07:00:15 --> Input Class Initialized
INFO - 2024-04-14 07:00:15 --> Language Class Initialized
INFO - 2024-04-14 07:00:15 --> Loader Class Initialized
INFO - 2024-04-14 07:00:15 --> Helper loaded: url_helper
INFO - 2024-04-14 07:00:15 --> Helper loaded: file_helper
INFO - 2024-04-14 07:00:15 --> Helper loaded: html_helper
INFO - 2024-04-14 07:00:15 --> Helper loaded: text_helper
INFO - 2024-04-14 07:00:15 --> Helper loaded: form_helper
INFO - 2024-04-14 07:00:15 --> Helper loaded: lang_helper
INFO - 2024-04-14 07:00:15 --> Helper loaded: security_helper
INFO - 2024-04-14 07:00:15 --> Helper loaded: cookie_helper
INFO - 2024-04-14 07:00:15 --> Database Driver Class Initialized
INFO - 2024-04-14 07:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 07:00:15 --> Parser Class Initialized
INFO - 2024-04-14 07:00:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 07:00:15 --> Pagination Class Initialized
INFO - 2024-04-14 07:00:15 --> Form Validation Class Initialized
INFO - 2024-04-14 07:00:15 --> Controller Class Initialized
INFO - 2024-04-14 07:00:15 --> Model Class Initialized
DEBUG - 2024-04-14 07:00:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 07:00:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:00:15 --> Model Class Initialized
DEBUG - 2024-04-14 07:00:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:00:15 --> Model Class Initialized
INFO - 2024-04-14 07:00:15 --> Email Class Initialized
INFO - 2024-04-14 07:00:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html_pdf.php
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/frame_reflower.cls.php 210
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/frame_reflower.cls.php 211
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/block_frame_reflower.cls.php 726
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/block_frame_reflower.cls.php 726
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-14 07:00:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-04-14 07:00:15 --> Language file loaded: language/english/email_lang.php
INFO - 2024-04-14 07:00:16 --> Final output sent to browser
DEBUG - 2024-04-14 07:00:16 --> Total execution time: 0.2882
ERROR - 2024-04-14 07:00:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 07:00:16 --> Config Class Initialized
INFO - 2024-04-14 07:00:16 --> Hooks Class Initialized
DEBUG - 2024-04-14 07:00:16 --> UTF-8 Support Enabled
INFO - 2024-04-14 07:00:16 --> Utf8 Class Initialized
INFO - 2024-04-14 07:00:16 --> URI Class Initialized
INFO - 2024-04-14 07:00:16 --> Router Class Initialized
INFO - 2024-04-14 07:00:16 --> Output Class Initialized
INFO - 2024-04-14 07:00:16 --> Security Class Initialized
DEBUG - 2024-04-14 07:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 07:00:16 --> Input Class Initialized
INFO - 2024-04-14 07:00:16 --> Language Class Initialized
INFO - 2024-04-14 07:00:16 --> Loader Class Initialized
INFO - 2024-04-14 07:00:16 --> Helper loaded: url_helper
INFO - 2024-04-14 07:00:16 --> Helper loaded: file_helper
INFO - 2024-04-14 07:00:16 --> Helper loaded: html_helper
INFO - 2024-04-14 07:00:16 --> Helper loaded: text_helper
INFO - 2024-04-14 07:00:16 --> Helper loaded: form_helper
INFO - 2024-04-14 07:00:16 --> Helper loaded: lang_helper
INFO - 2024-04-14 07:00:16 --> Helper loaded: security_helper
INFO - 2024-04-14 07:00:16 --> Helper loaded: cookie_helper
INFO - 2024-04-14 07:00:16 --> Database Driver Class Initialized
INFO - 2024-04-14 07:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 07:00:16 --> Parser Class Initialized
INFO - 2024-04-14 07:00:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 07:00:16 --> Pagination Class Initialized
INFO - 2024-04-14 07:00:16 --> Form Validation Class Initialized
INFO - 2024-04-14 07:00:16 --> Controller Class Initialized
INFO - 2024-04-14 07:00:16 --> Model Class Initialized
DEBUG - 2024-04-14 07:00:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 07:00:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:00:16 --> Model Class Initialized
DEBUG - 2024-04-14 07:00:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:00:16 --> Model Class Initialized
INFO - 2024-04-14 07:00:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html.php
DEBUG - 2024-04-14 07:00:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:00:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 07:00:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 07:00:16 --> Model Class Initialized
INFO - 2024-04-14 07:00:16 --> Model Class Initialized
INFO - 2024-04-14 07:00:16 --> Model Class Initialized
INFO - 2024-04-14 07:00:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-14 07:00:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-14 07:00:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 07:00:16 --> Final output sent to browser
DEBUG - 2024-04-14 07:00:16 --> Total execution time: 0.3138
ERROR - 2024-04-14 07:00:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 07:00:19 --> Config Class Initialized
INFO - 2024-04-14 07:00:19 --> Hooks Class Initialized
DEBUG - 2024-04-14 07:00:19 --> UTF-8 Support Enabled
INFO - 2024-04-14 07:00:19 --> Utf8 Class Initialized
INFO - 2024-04-14 07:00:19 --> URI Class Initialized
INFO - 2024-04-14 07:00:19 --> Router Class Initialized
INFO - 2024-04-14 07:00:19 --> Output Class Initialized
INFO - 2024-04-14 07:00:19 --> Security Class Initialized
DEBUG - 2024-04-14 07:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 07:00:19 --> Input Class Initialized
INFO - 2024-04-14 07:00:19 --> Language Class Initialized
INFO - 2024-04-14 07:00:19 --> Loader Class Initialized
INFO - 2024-04-14 07:00:19 --> Helper loaded: url_helper
INFO - 2024-04-14 07:00:19 --> Helper loaded: file_helper
INFO - 2024-04-14 07:00:19 --> Helper loaded: html_helper
INFO - 2024-04-14 07:00:19 --> Helper loaded: text_helper
INFO - 2024-04-14 07:00:19 --> Helper loaded: form_helper
INFO - 2024-04-14 07:00:19 --> Helper loaded: lang_helper
INFO - 2024-04-14 07:00:19 --> Helper loaded: security_helper
INFO - 2024-04-14 07:00:19 --> Helper loaded: cookie_helper
INFO - 2024-04-14 07:00:19 --> Database Driver Class Initialized
INFO - 2024-04-14 07:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 07:00:19 --> Parser Class Initialized
INFO - 2024-04-14 07:00:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 07:00:19 --> Pagination Class Initialized
INFO - 2024-04-14 07:00:19 --> Form Validation Class Initialized
INFO - 2024-04-14 07:00:19 --> Controller Class Initialized
INFO - 2024-04-14 07:00:19 --> Model Class Initialized
DEBUG - 2024-04-14 07:00:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 07:00:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:00:19 --> Model Class Initialized
DEBUG - 2024-04-14 07:00:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:00:19 --> Model Class Initialized
INFO - 2024-04-14 07:00:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-04-14 07:00:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:00:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 07:00:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 07:00:19 --> Model Class Initialized
INFO - 2024-04-14 07:00:19 --> Model Class Initialized
INFO - 2024-04-14 07:00:19 --> Model Class Initialized
INFO - 2024-04-14 07:00:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-14 07:00:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-14 07:00:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 07:00:19 --> Final output sent to browser
DEBUG - 2024-04-14 07:00:19 --> Total execution time: 0.3001
ERROR - 2024-04-14 07:00:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 07:00:20 --> Config Class Initialized
INFO - 2024-04-14 07:00:20 --> Hooks Class Initialized
DEBUG - 2024-04-14 07:00:20 --> UTF-8 Support Enabled
INFO - 2024-04-14 07:00:20 --> Utf8 Class Initialized
INFO - 2024-04-14 07:00:20 --> URI Class Initialized
INFO - 2024-04-14 07:00:20 --> Router Class Initialized
INFO - 2024-04-14 07:00:20 --> Output Class Initialized
INFO - 2024-04-14 07:00:20 --> Security Class Initialized
DEBUG - 2024-04-14 07:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 07:00:20 --> Input Class Initialized
INFO - 2024-04-14 07:00:20 --> Language Class Initialized
INFO - 2024-04-14 07:00:20 --> Loader Class Initialized
INFO - 2024-04-14 07:00:20 --> Helper loaded: url_helper
INFO - 2024-04-14 07:00:20 --> Helper loaded: file_helper
INFO - 2024-04-14 07:00:20 --> Helper loaded: html_helper
INFO - 2024-04-14 07:00:20 --> Helper loaded: text_helper
INFO - 2024-04-14 07:00:20 --> Helper loaded: form_helper
INFO - 2024-04-14 07:00:20 --> Helper loaded: lang_helper
INFO - 2024-04-14 07:00:20 --> Helper loaded: security_helper
INFO - 2024-04-14 07:00:20 --> Helper loaded: cookie_helper
INFO - 2024-04-14 07:00:20 --> Database Driver Class Initialized
INFO - 2024-04-14 07:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 07:00:20 --> Parser Class Initialized
INFO - 2024-04-14 07:00:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 07:00:20 --> Pagination Class Initialized
INFO - 2024-04-14 07:00:20 --> Form Validation Class Initialized
INFO - 2024-04-14 07:00:20 --> Controller Class Initialized
INFO - 2024-04-14 07:00:20 --> Model Class Initialized
DEBUG - 2024-04-14 07:00:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 07:00:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:00:20 --> Model Class Initialized
DEBUG - 2024-04-14 07:00:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:00:20 --> Model Class Initialized
INFO - 2024-04-14 07:00:20 --> Final output sent to browser
DEBUG - 2024-04-14 07:00:20 --> Total execution time: 0.0422
ERROR - 2024-04-14 07:00:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 07:00:23 --> Config Class Initialized
INFO - 2024-04-14 07:00:23 --> Hooks Class Initialized
DEBUG - 2024-04-14 07:00:23 --> UTF-8 Support Enabled
INFO - 2024-04-14 07:00:23 --> Utf8 Class Initialized
INFO - 2024-04-14 07:00:23 --> URI Class Initialized
INFO - 2024-04-14 07:00:23 --> Router Class Initialized
INFO - 2024-04-14 07:00:23 --> Output Class Initialized
INFO - 2024-04-14 07:00:23 --> Security Class Initialized
DEBUG - 2024-04-14 07:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 07:00:23 --> Input Class Initialized
INFO - 2024-04-14 07:00:23 --> Language Class Initialized
INFO - 2024-04-14 07:00:23 --> Loader Class Initialized
INFO - 2024-04-14 07:00:23 --> Helper loaded: url_helper
INFO - 2024-04-14 07:00:23 --> Helper loaded: file_helper
INFO - 2024-04-14 07:00:23 --> Helper loaded: html_helper
INFO - 2024-04-14 07:00:23 --> Helper loaded: text_helper
INFO - 2024-04-14 07:00:23 --> Helper loaded: form_helper
INFO - 2024-04-14 07:00:23 --> Helper loaded: lang_helper
INFO - 2024-04-14 07:00:23 --> Helper loaded: security_helper
INFO - 2024-04-14 07:00:23 --> Helper loaded: cookie_helper
INFO - 2024-04-14 07:00:23 --> Database Driver Class Initialized
INFO - 2024-04-14 07:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 07:00:23 --> Parser Class Initialized
INFO - 2024-04-14 07:00:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 07:00:23 --> Pagination Class Initialized
INFO - 2024-04-14 07:00:23 --> Form Validation Class Initialized
INFO - 2024-04-14 07:00:23 --> Controller Class Initialized
INFO - 2024-04-14 07:00:23 --> Model Class Initialized
DEBUG - 2024-04-14 07:00:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 07:00:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:00:23 --> Model Class Initialized
DEBUG - 2024-04-14 07:00:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:00:23 --> Model Class Initialized
INFO - 2024-04-14 07:00:24 --> Final output sent to browser
DEBUG - 2024-04-14 07:00:24 --> Total execution time: 1.3248
ERROR - 2024-04-14 07:03:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 07:03:18 --> Config Class Initialized
INFO - 2024-04-14 07:03:18 --> Hooks Class Initialized
DEBUG - 2024-04-14 07:03:18 --> UTF-8 Support Enabled
INFO - 2024-04-14 07:03:18 --> Utf8 Class Initialized
INFO - 2024-04-14 07:03:18 --> URI Class Initialized
DEBUG - 2024-04-14 07:03:18 --> No URI present. Default controller set.
INFO - 2024-04-14 07:03:18 --> Router Class Initialized
INFO - 2024-04-14 07:03:18 --> Output Class Initialized
INFO - 2024-04-14 07:03:18 --> Security Class Initialized
DEBUG - 2024-04-14 07:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 07:03:18 --> Input Class Initialized
INFO - 2024-04-14 07:03:18 --> Language Class Initialized
INFO - 2024-04-14 07:03:18 --> Loader Class Initialized
INFO - 2024-04-14 07:03:18 --> Helper loaded: url_helper
INFO - 2024-04-14 07:03:18 --> Helper loaded: file_helper
INFO - 2024-04-14 07:03:18 --> Helper loaded: html_helper
INFO - 2024-04-14 07:03:18 --> Helper loaded: text_helper
INFO - 2024-04-14 07:03:18 --> Helper loaded: form_helper
INFO - 2024-04-14 07:03:18 --> Helper loaded: lang_helper
INFO - 2024-04-14 07:03:18 --> Helper loaded: security_helper
INFO - 2024-04-14 07:03:18 --> Helper loaded: cookie_helper
INFO - 2024-04-14 07:03:18 --> Database Driver Class Initialized
INFO - 2024-04-14 07:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 07:03:18 --> Parser Class Initialized
INFO - 2024-04-14 07:03:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 07:03:18 --> Pagination Class Initialized
INFO - 2024-04-14 07:03:18 --> Form Validation Class Initialized
INFO - 2024-04-14 07:03:18 --> Controller Class Initialized
INFO - 2024-04-14 07:03:18 --> Model Class Initialized
DEBUG - 2024-04-14 07:03:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:03:18 --> Model Class Initialized
DEBUG - 2024-04-14 07:03:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:03:18 --> Model Class Initialized
INFO - 2024-04-14 07:03:18 --> Model Class Initialized
INFO - 2024-04-14 07:03:18 --> Model Class Initialized
INFO - 2024-04-14 07:03:18 --> Model Class Initialized
DEBUG - 2024-04-14 07:03:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 07:03:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:03:18 --> Model Class Initialized
INFO - 2024-04-14 07:03:18 --> Model Class Initialized
INFO - 2024-04-14 07:03:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-14 07:03:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:03:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 07:03:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 07:03:18 --> Model Class Initialized
INFO - 2024-04-14 07:03:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-14 07:03:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-14 07:03:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 07:03:18 --> Final output sent to browser
DEBUG - 2024-04-14 07:03:18 --> Total execution time: 0.6149
ERROR - 2024-04-14 07:03:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 07:03:26 --> Config Class Initialized
INFO - 2024-04-14 07:03:26 --> Hooks Class Initialized
DEBUG - 2024-04-14 07:03:26 --> UTF-8 Support Enabled
INFO - 2024-04-14 07:03:26 --> Utf8 Class Initialized
INFO - 2024-04-14 07:03:26 --> URI Class Initialized
INFO - 2024-04-14 07:03:26 --> Router Class Initialized
INFO - 2024-04-14 07:03:26 --> Output Class Initialized
INFO - 2024-04-14 07:03:26 --> Security Class Initialized
DEBUG - 2024-04-14 07:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 07:03:26 --> Input Class Initialized
INFO - 2024-04-14 07:03:26 --> Language Class Initialized
INFO - 2024-04-14 07:03:26 --> Loader Class Initialized
INFO - 2024-04-14 07:03:26 --> Helper loaded: url_helper
INFO - 2024-04-14 07:03:26 --> Helper loaded: file_helper
INFO - 2024-04-14 07:03:26 --> Helper loaded: html_helper
INFO - 2024-04-14 07:03:26 --> Helper loaded: text_helper
INFO - 2024-04-14 07:03:26 --> Helper loaded: form_helper
INFO - 2024-04-14 07:03:26 --> Helper loaded: lang_helper
INFO - 2024-04-14 07:03:26 --> Helper loaded: security_helper
INFO - 2024-04-14 07:03:26 --> Helper loaded: cookie_helper
INFO - 2024-04-14 07:03:26 --> Database Driver Class Initialized
INFO - 2024-04-14 07:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 07:03:26 --> Parser Class Initialized
INFO - 2024-04-14 07:03:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 07:03:26 --> Pagination Class Initialized
INFO - 2024-04-14 07:03:26 --> Form Validation Class Initialized
INFO - 2024-04-14 07:03:26 --> Controller Class Initialized
INFO - 2024-04-14 07:03:26 --> Model Class Initialized
DEBUG - 2024-04-14 07:03:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 07:03:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:03:26 --> Model Class Initialized
DEBUG - 2024-04-14 07:03:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:03:26 --> Model Class Initialized
INFO - 2024-04-14 07:03:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-04-14 07:03:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:03:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 07:03:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 07:03:26 --> Model Class Initialized
INFO - 2024-04-14 07:03:26 --> Model Class Initialized
INFO - 2024-04-14 07:03:26 --> Model Class Initialized
INFO - 2024-04-14 07:03:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-14 07:03:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-14 07:03:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 07:03:26 --> Final output sent to browser
DEBUG - 2024-04-14 07:03:26 --> Total execution time: 0.3119
ERROR - 2024-04-14 07:03:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 07:03:27 --> Config Class Initialized
INFO - 2024-04-14 07:03:27 --> Hooks Class Initialized
DEBUG - 2024-04-14 07:03:27 --> UTF-8 Support Enabled
INFO - 2024-04-14 07:03:27 --> Utf8 Class Initialized
INFO - 2024-04-14 07:03:27 --> URI Class Initialized
INFO - 2024-04-14 07:03:27 --> Router Class Initialized
INFO - 2024-04-14 07:03:27 --> Output Class Initialized
INFO - 2024-04-14 07:03:27 --> Security Class Initialized
DEBUG - 2024-04-14 07:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 07:03:27 --> Input Class Initialized
INFO - 2024-04-14 07:03:27 --> Language Class Initialized
INFO - 2024-04-14 07:03:27 --> Loader Class Initialized
INFO - 2024-04-14 07:03:27 --> Helper loaded: url_helper
INFO - 2024-04-14 07:03:27 --> Helper loaded: file_helper
INFO - 2024-04-14 07:03:27 --> Helper loaded: html_helper
INFO - 2024-04-14 07:03:27 --> Helper loaded: text_helper
INFO - 2024-04-14 07:03:27 --> Helper loaded: form_helper
INFO - 2024-04-14 07:03:27 --> Helper loaded: lang_helper
INFO - 2024-04-14 07:03:27 --> Helper loaded: security_helper
INFO - 2024-04-14 07:03:27 --> Helper loaded: cookie_helper
INFO - 2024-04-14 07:03:27 --> Database Driver Class Initialized
INFO - 2024-04-14 07:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 07:03:27 --> Parser Class Initialized
INFO - 2024-04-14 07:03:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 07:03:27 --> Pagination Class Initialized
INFO - 2024-04-14 07:03:27 --> Form Validation Class Initialized
INFO - 2024-04-14 07:03:27 --> Controller Class Initialized
INFO - 2024-04-14 07:03:27 --> Model Class Initialized
DEBUG - 2024-04-14 07:03:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 07:03:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:03:27 --> Model Class Initialized
DEBUG - 2024-04-14 07:03:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:03:27 --> Model Class Initialized
INFO - 2024-04-14 07:03:27 --> Final output sent to browser
DEBUG - 2024-04-14 07:03:27 --> Total execution time: 0.0417
ERROR - 2024-04-14 07:03:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 07:03:48 --> Config Class Initialized
INFO - 2024-04-14 07:03:48 --> Hooks Class Initialized
DEBUG - 2024-04-14 07:03:48 --> UTF-8 Support Enabled
INFO - 2024-04-14 07:03:48 --> Utf8 Class Initialized
INFO - 2024-04-14 07:03:48 --> URI Class Initialized
INFO - 2024-04-14 07:03:48 --> Router Class Initialized
INFO - 2024-04-14 07:03:48 --> Output Class Initialized
INFO - 2024-04-14 07:03:48 --> Security Class Initialized
DEBUG - 2024-04-14 07:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 07:03:48 --> Input Class Initialized
INFO - 2024-04-14 07:03:48 --> Language Class Initialized
INFO - 2024-04-14 07:03:48 --> Loader Class Initialized
INFO - 2024-04-14 07:03:48 --> Helper loaded: url_helper
INFO - 2024-04-14 07:03:48 --> Helper loaded: file_helper
INFO - 2024-04-14 07:03:48 --> Helper loaded: html_helper
INFO - 2024-04-14 07:03:48 --> Helper loaded: text_helper
INFO - 2024-04-14 07:03:48 --> Helper loaded: form_helper
INFO - 2024-04-14 07:03:48 --> Helper loaded: lang_helper
INFO - 2024-04-14 07:03:48 --> Helper loaded: security_helper
INFO - 2024-04-14 07:03:48 --> Helper loaded: cookie_helper
INFO - 2024-04-14 07:03:48 --> Database Driver Class Initialized
INFO - 2024-04-14 07:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 07:03:48 --> Parser Class Initialized
INFO - 2024-04-14 07:03:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 07:03:48 --> Pagination Class Initialized
INFO - 2024-04-14 07:03:48 --> Form Validation Class Initialized
INFO - 2024-04-14 07:03:48 --> Controller Class Initialized
INFO - 2024-04-14 07:03:48 --> Model Class Initialized
DEBUG - 2024-04-14 07:03:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 07:03:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:03:48 --> Model Class Initialized
DEBUG - 2024-04-14 07:03:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:03:48 --> Model Class Initialized
DEBUG - 2024-04-14 07:03:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:03:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-04-14 07:03:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:03:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 07:03:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 07:03:48 --> Model Class Initialized
INFO - 2024-04-14 07:03:48 --> Model Class Initialized
INFO - 2024-04-14 07:03:48 --> Model Class Initialized
INFO - 2024-04-14 07:03:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-14 07:03:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-14 07:03:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 07:03:48 --> Final output sent to browser
DEBUG - 2024-04-14 07:03:48 --> Total execution time: 0.2825
ERROR - 2024-04-14 07:04:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 07:04:34 --> Config Class Initialized
INFO - 2024-04-14 07:04:34 --> Hooks Class Initialized
DEBUG - 2024-04-14 07:04:34 --> UTF-8 Support Enabled
INFO - 2024-04-14 07:04:34 --> Utf8 Class Initialized
INFO - 2024-04-14 07:04:34 --> URI Class Initialized
DEBUG - 2024-04-14 07:04:34 --> No URI present. Default controller set.
INFO - 2024-04-14 07:04:34 --> Router Class Initialized
INFO - 2024-04-14 07:04:34 --> Output Class Initialized
INFO - 2024-04-14 07:04:34 --> Security Class Initialized
DEBUG - 2024-04-14 07:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 07:04:34 --> Input Class Initialized
INFO - 2024-04-14 07:04:34 --> Language Class Initialized
INFO - 2024-04-14 07:04:34 --> Loader Class Initialized
INFO - 2024-04-14 07:04:34 --> Helper loaded: url_helper
INFO - 2024-04-14 07:04:34 --> Helper loaded: file_helper
INFO - 2024-04-14 07:04:34 --> Helper loaded: html_helper
INFO - 2024-04-14 07:04:34 --> Helper loaded: text_helper
INFO - 2024-04-14 07:04:34 --> Helper loaded: form_helper
INFO - 2024-04-14 07:04:34 --> Helper loaded: lang_helper
INFO - 2024-04-14 07:04:34 --> Helper loaded: security_helper
INFO - 2024-04-14 07:04:34 --> Helper loaded: cookie_helper
INFO - 2024-04-14 07:04:34 --> Database Driver Class Initialized
INFO - 2024-04-14 07:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 07:04:34 --> Parser Class Initialized
INFO - 2024-04-14 07:04:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 07:04:34 --> Pagination Class Initialized
INFO - 2024-04-14 07:04:34 --> Form Validation Class Initialized
INFO - 2024-04-14 07:04:34 --> Controller Class Initialized
INFO - 2024-04-14 07:04:34 --> Model Class Initialized
DEBUG - 2024-04-14 07:04:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:04:34 --> Model Class Initialized
DEBUG - 2024-04-14 07:04:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:04:34 --> Model Class Initialized
INFO - 2024-04-14 07:04:34 --> Model Class Initialized
INFO - 2024-04-14 07:04:34 --> Model Class Initialized
INFO - 2024-04-14 07:04:34 --> Model Class Initialized
DEBUG - 2024-04-14 07:04:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 07:04:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:04:34 --> Model Class Initialized
INFO - 2024-04-14 07:04:34 --> Model Class Initialized
INFO - 2024-04-14 07:04:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-14 07:04:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:04:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 07:04:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 07:04:34 --> Model Class Initialized
INFO - 2024-04-14 07:04:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-14 07:04:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-14 07:04:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 07:04:35 --> Final output sent to browser
DEBUG - 2024-04-14 07:04:35 --> Total execution time: 0.6124
ERROR - 2024-04-14 07:04:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 07:04:40 --> Config Class Initialized
INFO - 2024-04-14 07:04:40 --> Hooks Class Initialized
DEBUG - 2024-04-14 07:04:40 --> UTF-8 Support Enabled
INFO - 2024-04-14 07:04:40 --> Utf8 Class Initialized
INFO - 2024-04-14 07:04:40 --> URI Class Initialized
INFO - 2024-04-14 07:04:40 --> Router Class Initialized
INFO - 2024-04-14 07:04:40 --> Output Class Initialized
INFO - 2024-04-14 07:04:40 --> Security Class Initialized
DEBUG - 2024-04-14 07:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 07:04:40 --> Input Class Initialized
INFO - 2024-04-14 07:04:40 --> Language Class Initialized
INFO - 2024-04-14 07:04:40 --> Loader Class Initialized
INFO - 2024-04-14 07:04:40 --> Helper loaded: url_helper
INFO - 2024-04-14 07:04:40 --> Helper loaded: file_helper
INFO - 2024-04-14 07:04:40 --> Helper loaded: html_helper
INFO - 2024-04-14 07:04:40 --> Helper loaded: text_helper
INFO - 2024-04-14 07:04:40 --> Helper loaded: form_helper
INFO - 2024-04-14 07:04:40 --> Helper loaded: lang_helper
INFO - 2024-04-14 07:04:40 --> Helper loaded: security_helper
INFO - 2024-04-14 07:04:40 --> Helper loaded: cookie_helper
INFO - 2024-04-14 07:04:40 --> Database Driver Class Initialized
INFO - 2024-04-14 07:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 07:04:40 --> Parser Class Initialized
INFO - 2024-04-14 07:04:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 07:04:40 --> Pagination Class Initialized
INFO - 2024-04-14 07:04:40 --> Form Validation Class Initialized
INFO - 2024-04-14 07:04:40 --> Controller Class Initialized
INFO - 2024-04-14 07:04:40 --> Model Class Initialized
DEBUG - 2024-04-14 07:04:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 07:04:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:04:40 --> Model Class Initialized
DEBUG - 2024-04-14 07:04:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:04:40 --> Model Class Initialized
INFO - 2024-04-14 07:04:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-04-14 07:04:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:04:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 07:04:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 07:04:40 --> Model Class Initialized
INFO - 2024-04-14 07:04:40 --> Model Class Initialized
INFO - 2024-04-14 07:04:40 --> Model Class Initialized
INFO - 2024-04-14 07:04:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-14 07:04:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-14 07:04:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 07:04:40 --> Final output sent to browser
DEBUG - 2024-04-14 07:04:40 --> Total execution time: 0.2849
ERROR - 2024-04-14 07:04:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 07:04:41 --> Config Class Initialized
INFO - 2024-04-14 07:04:41 --> Hooks Class Initialized
DEBUG - 2024-04-14 07:04:41 --> UTF-8 Support Enabled
INFO - 2024-04-14 07:04:41 --> Utf8 Class Initialized
INFO - 2024-04-14 07:04:41 --> URI Class Initialized
INFO - 2024-04-14 07:04:41 --> Router Class Initialized
INFO - 2024-04-14 07:04:41 --> Output Class Initialized
INFO - 2024-04-14 07:04:41 --> Security Class Initialized
DEBUG - 2024-04-14 07:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 07:04:41 --> Input Class Initialized
INFO - 2024-04-14 07:04:41 --> Language Class Initialized
INFO - 2024-04-14 07:04:41 --> Loader Class Initialized
INFO - 2024-04-14 07:04:41 --> Helper loaded: url_helper
INFO - 2024-04-14 07:04:41 --> Helper loaded: file_helper
INFO - 2024-04-14 07:04:41 --> Helper loaded: html_helper
INFO - 2024-04-14 07:04:41 --> Helper loaded: text_helper
INFO - 2024-04-14 07:04:41 --> Helper loaded: form_helper
INFO - 2024-04-14 07:04:41 --> Helper loaded: lang_helper
INFO - 2024-04-14 07:04:41 --> Helper loaded: security_helper
INFO - 2024-04-14 07:04:41 --> Helper loaded: cookie_helper
INFO - 2024-04-14 07:04:41 --> Database Driver Class Initialized
INFO - 2024-04-14 07:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 07:04:41 --> Parser Class Initialized
INFO - 2024-04-14 07:04:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 07:04:41 --> Pagination Class Initialized
INFO - 2024-04-14 07:04:41 --> Form Validation Class Initialized
INFO - 2024-04-14 07:04:41 --> Controller Class Initialized
INFO - 2024-04-14 07:04:41 --> Model Class Initialized
DEBUG - 2024-04-14 07:04:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 07:04:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:04:41 --> Model Class Initialized
DEBUG - 2024-04-14 07:04:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:04:41 --> Model Class Initialized
INFO - 2024-04-14 07:04:41 --> Final output sent to browser
DEBUG - 2024-04-14 07:04:41 --> Total execution time: 0.0437
ERROR - 2024-04-14 07:04:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 07:04:44 --> Config Class Initialized
INFO - 2024-04-14 07:04:44 --> Hooks Class Initialized
DEBUG - 2024-04-14 07:04:44 --> UTF-8 Support Enabled
INFO - 2024-04-14 07:04:44 --> Utf8 Class Initialized
INFO - 2024-04-14 07:04:44 --> URI Class Initialized
INFO - 2024-04-14 07:04:44 --> Router Class Initialized
INFO - 2024-04-14 07:04:44 --> Output Class Initialized
INFO - 2024-04-14 07:04:44 --> Security Class Initialized
DEBUG - 2024-04-14 07:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 07:04:44 --> Input Class Initialized
INFO - 2024-04-14 07:04:44 --> Language Class Initialized
INFO - 2024-04-14 07:04:44 --> Loader Class Initialized
INFO - 2024-04-14 07:04:44 --> Helper loaded: url_helper
INFO - 2024-04-14 07:04:44 --> Helper loaded: file_helper
INFO - 2024-04-14 07:04:44 --> Helper loaded: html_helper
INFO - 2024-04-14 07:04:44 --> Helper loaded: text_helper
INFO - 2024-04-14 07:04:44 --> Helper loaded: form_helper
INFO - 2024-04-14 07:04:44 --> Helper loaded: lang_helper
INFO - 2024-04-14 07:04:44 --> Helper loaded: security_helper
INFO - 2024-04-14 07:04:44 --> Helper loaded: cookie_helper
INFO - 2024-04-14 07:04:44 --> Database Driver Class Initialized
INFO - 2024-04-14 07:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 07:04:44 --> Parser Class Initialized
INFO - 2024-04-14 07:04:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 07:04:44 --> Pagination Class Initialized
INFO - 2024-04-14 07:04:44 --> Form Validation Class Initialized
INFO - 2024-04-14 07:04:44 --> Controller Class Initialized
INFO - 2024-04-14 07:04:44 --> Model Class Initialized
DEBUG - 2024-04-14 07:04:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 07:04:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:04:44 --> Model Class Initialized
DEBUG - 2024-04-14 07:04:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:04:44 --> Model Class Initialized
INFO - 2024-04-14 07:04:45 --> Final output sent to browser
DEBUG - 2024-04-14 07:04:45 --> Total execution time: 1.2363
ERROR - 2024-04-14 07:05:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 07:05:02 --> Config Class Initialized
INFO - 2024-04-14 07:05:02 --> Hooks Class Initialized
DEBUG - 2024-04-14 07:05:02 --> UTF-8 Support Enabled
INFO - 2024-04-14 07:05:02 --> Utf8 Class Initialized
INFO - 2024-04-14 07:05:02 --> URI Class Initialized
DEBUG - 2024-04-14 07:05:02 --> No URI present. Default controller set.
INFO - 2024-04-14 07:05:02 --> Router Class Initialized
INFO - 2024-04-14 07:05:02 --> Output Class Initialized
INFO - 2024-04-14 07:05:02 --> Security Class Initialized
DEBUG - 2024-04-14 07:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 07:05:02 --> Input Class Initialized
INFO - 2024-04-14 07:05:02 --> Language Class Initialized
INFO - 2024-04-14 07:05:02 --> Loader Class Initialized
INFO - 2024-04-14 07:05:02 --> Helper loaded: url_helper
INFO - 2024-04-14 07:05:02 --> Helper loaded: file_helper
INFO - 2024-04-14 07:05:02 --> Helper loaded: html_helper
INFO - 2024-04-14 07:05:02 --> Helper loaded: text_helper
INFO - 2024-04-14 07:05:02 --> Helper loaded: form_helper
INFO - 2024-04-14 07:05:02 --> Helper loaded: lang_helper
INFO - 2024-04-14 07:05:02 --> Helper loaded: security_helper
INFO - 2024-04-14 07:05:02 --> Helper loaded: cookie_helper
INFO - 2024-04-14 07:05:02 --> Database Driver Class Initialized
INFO - 2024-04-14 07:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 07:05:02 --> Parser Class Initialized
INFO - 2024-04-14 07:05:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 07:05:02 --> Pagination Class Initialized
INFO - 2024-04-14 07:05:02 --> Form Validation Class Initialized
INFO - 2024-04-14 07:05:02 --> Controller Class Initialized
INFO - 2024-04-14 07:05:02 --> Model Class Initialized
DEBUG - 2024-04-14 07:05:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:05:02 --> Model Class Initialized
DEBUG - 2024-04-14 07:05:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:05:02 --> Model Class Initialized
INFO - 2024-04-14 07:05:02 --> Model Class Initialized
INFO - 2024-04-14 07:05:02 --> Model Class Initialized
INFO - 2024-04-14 07:05:02 --> Model Class Initialized
DEBUG - 2024-04-14 07:05:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 07:05:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:05:02 --> Model Class Initialized
INFO - 2024-04-14 07:05:02 --> Model Class Initialized
INFO - 2024-04-14 07:05:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-14 07:05:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:05:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 07:05:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 07:05:02 --> Model Class Initialized
INFO - 2024-04-14 07:05:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-14 07:05:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-14 07:05:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 07:05:02 --> Final output sent to browser
DEBUG - 2024-04-14 07:05:02 --> Total execution time: 0.7142
ERROR - 2024-04-14 07:08:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 07:08:14 --> Config Class Initialized
INFO - 2024-04-14 07:08:14 --> Hooks Class Initialized
DEBUG - 2024-04-14 07:08:14 --> UTF-8 Support Enabled
INFO - 2024-04-14 07:08:14 --> Utf8 Class Initialized
INFO - 2024-04-14 07:08:14 --> URI Class Initialized
DEBUG - 2024-04-14 07:08:14 --> No URI present. Default controller set.
INFO - 2024-04-14 07:08:14 --> Router Class Initialized
INFO - 2024-04-14 07:08:14 --> Output Class Initialized
INFO - 2024-04-14 07:08:14 --> Security Class Initialized
DEBUG - 2024-04-14 07:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 07:08:14 --> Input Class Initialized
INFO - 2024-04-14 07:08:14 --> Language Class Initialized
INFO - 2024-04-14 07:08:14 --> Loader Class Initialized
INFO - 2024-04-14 07:08:14 --> Helper loaded: url_helper
INFO - 2024-04-14 07:08:14 --> Helper loaded: file_helper
INFO - 2024-04-14 07:08:14 --> Helper loaded: html_helper
INFO - 2024-04-14 07:08:14 --> Helper loaded: text_helper
INFO - 2024-04-14 07:08:14 --> Helper loaded: form_helper
INFO - 2024-04-14 07:08:14 --> Helper loaded: lang_helper
INFO - 2024-04-14 07:08:14 --> Helper loaded: security_helper
INFO - 2024-04-14 07:08:14 --> Helper loaded: cookie_helper
INFO - 2024-04-14 07:08:14 --> Database Driver Class Initialized
INFO - 2024-04-14 07:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 07:08:14 --> Parser Class Initialized
INFO - 2024-04-14 07:08:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 07:08:14 --> Pagination Class Initialized
INFO - 2024-04-14 07:08:14 --> Form Validation Class Initialized
INFO - 2024-04-14 07:08:14 --> Controller Class Initialized
INFO - 2024-04-14 07:08:14 --> Model Class Initialized
DEBUG - 2024-04-14 07:08:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:08:14 --> Model Class Initialized
DEBUG - 2024-04-14 07:08:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:08:14 --> Model Class Initialized
INFO - 2024-04-14 07:08:14 --> Model Class Initialized
INFO - 2024-04-14 07:08:14 --> Model Class Initialized
INFO - 2024-04-14 07:08:14 --> Model Class Initialized
DEBUG - 2024-04-14 07:08:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 07:08:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:08:14 --> Model Class Initialized
INFO - 2024-04-14 07:08:14 --> Model Class Initialized
INFO - 2024-04-14 07:08:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-14 07:08:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:08:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 07:08:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 07:08:14 --> Model Class Initialized
INFO - 2024-04-14 07:08:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-14 07:08:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-14 07:08:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 07:08:14 --> Final output sent to browser
DEBUG - 2024-04-14 07:08:14 --> Total execution time: 0.6036
ERROR - 2024-04-14 07:44:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 07:44:24 --> Config Class Initialized
INFO - 2024-04-14 07:44:24 --> Hooks Class Initialized
DEBUG - 2024-04-14 07:44:24 --> UTF-8 Support Enabled
INFO - 2024-04-14 07:44:24 --> Utf8 Class Initialized
INFO - 2024-04-14 07:44:24 --> URI Class Initialized
DEBUG - 2024-04-14 07:44:24 --> No URI present. Default controller set.
INFO - 2024-04-14 07:44:24 --> Router Class Initialized
INFO - 2024-04-14 07:44:24 --> Output Class Initialized
INFO - 2024-04-14 07:44:24 --> Security Class Initialized
DEBUG - 2024-04-14 07:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 07:44:24 --> Input Class Initialized
INFO - 2024-04-14 07:44:24 --> Language Class Initialized
INFO - 2024-04-14 07:44:24 --> Loader Class Initialized
INFO - 2024-04-14 07:44:24 --> Helper loaded: url_helper
INFO - 2024-04-14 07:44:24 --> Helper loaded: file_helper
INFO - 2024-04-14 07:44:24 --> Helper loaded: html_helper
INFO - 2024-04-14 07:44:24 --> Helper loaded: text_helper
INFO - 2024-04-14 07:44:24 --> Helper loaded: form_helper
INFO - 2024-04-14 07:44:24 --> Helper loaded: lang_helper
INFO - 2024-04-14 07:44:24 --> Helper loaded: security_helper
INFO - 2024-04-14 07:44:24 --> Helper loaded: cookie_helper
INFO - 2024-04-14 07:44:24 --> Database Driver Class Initialized
INFO - 2024-04-14 07:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 07:44:24 --> Parser Class Initialized
INFO - 2024-04-14 07:44:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 07:44:24 --> Pagination Class Initialized
INFO - 2024-04-14 07:44:24 --> Form Validation Class Initialized
INFO - 2024-04-14 07:44:24 --> Controller Class Initialized
INFO - 2024-04-14 07:44:24 --> Model Class Initialized
DEBUG - 2024-04-14 07:44:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:44:24 --> Model Class Initialized
DEBUG - 2024-04-14 07:44:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:44:24 --> Model Class Initialized
INFO - 2024-04-14 07:44:24 --> Model Class Initialized
INFO - 2024-04-14 07:44:24 --> Model Class Initialized
INFO - 2024-04-14 07:44:24 --> Model Class Initialized
DEBUG - 2024-04-14 07:44:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 07:44:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:44:24 --> Model Class Initialized
INFO - 2024-04-14 07:44:24 --> Model Class Initialized
INFO - 2024-04-14 07:44:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-14 07:44:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:44:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 07:44:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 07:44:24 --> Model Class Initialized
INFO - 2024-04-14 07:44:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-14 07:44:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-14 07:44:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 07:44:24 --> Final output sent to browser
DEBUG - 2024-04-14 07:44:24 --> Total execution time: 0.6318
ERROR - 2024-04-14 07:44:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 07:44:45 --> Config Class Initialized
INFO - 2024-04-14 07:44:45 --> Hooks Class Initialized
DEBUG - 2024-04-14 07:44:45 --> UTF-8 Support Enabled
INFO - 2024-04-14 07:44:45 --> Utf8 Class Initialized
INFO - 2024-04-14 07:44:45 --> URI Class Initialized
DEBUG - 2024-04-14 07:44:45 --> No URI present. Default controller set.
INFO - 2024-04-14 07:44:45 --> Router Class Initialized
INFO - 2024-04-14 07:44:45 --> Output Class Initialized
INFO - 2024-04-14 07:44:45 --> Security Class Initialized
DEBUG - 2024-04-14 07:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 07:44:45 --> Input Class Initialized
INFO - 2024-04-14 07:44:45 --> Language Class Initialized
INFO - 2024-04-14 07:44:45 --> Loader Class Initialized
INFO - 2024-04-14 07:44:45 --> Helper loaded: url_helper
INFO - 2024-04-14 07:44:45 --> Helper loaded: file_helper
INFO - 2024-04-14 07:44:45 --> Helper loaded: html_helper
INFO - 2024-04-14 07:44:45 --> Helper loaded: text_helper
INFO - 2024-04-14 07:44:45 --> Helper loaded: form_helper
INFO - 2024-04-14 07:44:45 --> Helper loaded: lang_helper
INFO - 2024-04-14 07:44:45 --> Helper loaded: security_helper
INFO - 2024-04-14 07:44:45 --> Helper loaded: cookie_helper
INFO - 2024-04-14 07:44:45 --> Database Driver Class Initialized
INFO - 2024-04-14 07:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 07:44:45 --> Parser Class Initialized
INFO - 2024-04-14 07:44:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 07:44:45 --> Pagination Class Initialized
INFO - 2024-04-14 07:44:45 --> Form Validation Class Initialized
INFO - 2024-04-14 07:44:45 --> Controller Class Initialized
INFO - 2024-04-14 07:44:45 --> Model Class Initialized
DEBUG - 2024-04-14 07:44:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-04-14 07:44:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 07:44:46 --> Config Class Initialized
INFO - 2024-04-14 07:44:46 --> Hooks Class Initialized
DEBUG - 2024-04-14 07:44:46 --> UTF-8 Support Enabled
INFO - 2024-04-14 07:44:46 --> Utf8 Class Initialized
INFO - 2024-04-14 07:44:46 --> URI Class Initialized
INFO - 2024-04-14 07:44:46 --> Router Class Initialized
INFO - 2024-04-14 07:44:46 --> Output Class Initialized
INFO - 2024-04-14 07:44:46 --> Security Class Initialized
DEBUG - 2024-04-14 07:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 07:44:46 --> Input Class Initialized
INFO - 2024-04-14 07:44:46 --> Language Class Initialized
INFO - 2024-04-14 07:44:46 --> Loader Class Initialized
INFO - 2024-04-14 07:44:46 --> Helper loaded: url_helper
INFO - 2024-04-14 07:44:46 --> Helper loaded: file_helper
INFO - 2024-04-14 07:44:46 --> Helper loaded: html_helper
INFO - 2024-04-14 07:44:46 --> Helper loaded: text_helper
INFO - 2024-04-14 07:44:46 --> Helper loaded: form_helper
INFO - 2024-04-14 07:44:46 --> Helper loaded: lang_helper
INFO - 2024-04-14 07:44:46 --> Helper loaded: security_helper
INFO - 2024-04-14 07:44:46 --> Helper loaded: cookie_helper
INFO - 2024-04-14 07:44:46 --> Database Driver Class Initialized
INFO - 2024-04-14 07:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 07:44:46 --> Parser Class Initialized
INFO - 2024-04-14 07:44:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 07:44:46 --> Pagination Class Initialized
INFO - 2024-04-14 07:44:46 --> Form Validation Class Initialized
INFO - 2024-04-14 07:44:46 --> Controller Class Initialized
INFO - 2024-04-14 07:44:46 --> Model Class Initialized
DEBUG - 2024-04-14 07:44:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:44:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-04-14 07:44:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 07:44:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 07:44:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 07:44:46 --> Model Class Initialized
INFO - 2024-04-14 07:44:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 07:44:46 --> Final output sent to browser
DEBUG - 2024-04-14 07:44:46 --> Total execution time: 0.0316
ERROR - 2024-04-14 07:44:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 07:44:46 --> Config Class Initialized
INFO - 2024-04-14 07:44:46 --> Hooks Class Initialized
DEBUG - 2024-04-14 07:44:46 --> UTF-8 Support Enabled
INFO - 2024-04-14 07:44:46 --> Utf8 Class Initialized
INFO - 2024-04-14 07:44:46 --> URI Class Initialized
INFO - 2024-04-14 07:44:46 --> Router Class Initialized
INFO - 2024-04-14 07:44:46 --> Output Class Initialized
INFO - 2024-04-14 07:44:46 --> Security Class Initialized
DEBUG - 2024-04-14 07:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 07:44:46 --> Input Class Initialized
INFO - 2024-04-14 07:44:46 --> Language Class Initialized
ERROR - 2024-04-14 07:44:46 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2024-04-14 07:44:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 07:44:47 --> Config Class Initialized
INFO - 2024-04-14 07:44:47 --> Hooks Class Initialized
DEBUG - 2024-04-14 07:44:47 --> UTF-8 Support Enabled
INFO - 2024-04-14 07:44:47 --> Utf8 Class Initialized
INFO - 2024-04-14 07:44:47 --> URI Class Initialized
INFO - 2024-04-14 07:44:47 --> Router Class Initialized
INFO - 2024-04-14 07:44:47 --> Output Class Initialized
INFO - 2024-04-14 07:44:47 --> Security Class Initialized
DEBUG - 2024-04-14 07:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 07:44:47 --> Input Class Initialized
INFO - 2024-04-14 07:44:47 --> Language Class Initialized
ERROR - 2024-04-14 07:44:47 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2024-04-14 11:38:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 11:38:14 --> Config Class Initialized
INFO - 2024-04-14 11:38:14 --> Hooks Class Initialized
DEBUG - 2024-04-14 11:38:14 --> UTF-8 Support Enabled
INFO - 2024-04-14 11:38:14 --> Utf8 Class Initialized
INFO - 2024-04-14 11:38:14 --> URI Class Initialized
INFO - 2024-04-14 11:38:14 --> Router Class Initialized
INFO - 2024-04-14 11:38:14 --> Output Class Initialized
INFO - 2024-04-14 11:38:14 --> Security Class Initialized
DEBUG - 2024-04-14 11:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 11:38:14 --> Input Class Initialized
INFO - 2024-04-14 11:38:14 --> Language Class Initialized
ERROR - 2024-04-14 11:38:14 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-04-14 13:42:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 13:42:59 --> Config Class Initialized
INFO - 2024-04-14 13:42:59 --> Hooks Class Initialized
DEBUG - 2024-04-14 13:42:59 --> UTF-8 Support Enabled
INFO - 2024-04-14 13:42:59 --> Utf8 Class Initialized
INFO - 2024-04-14 13:42:59 --> URI Class Initialized
DEBUG - 2024-04-14 13:42:59 --> No URI present. Default controller set.
INFO - 2024-04-14 13:42:59 --> Router Class Initialized
INFO - 2024-04-14 13:42:59 --> Output Class Initialized
INFO - 2024-04-14 13:42:59 --> Security Class Initialized
DEBUG - 2024-04-14 13:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 13:42:59 --> Input Class Initialized
INFO - 2024-04-14 13:42:59 --> Language Class Initialized
INFO - 2024-04-14 13:42:59 --> Loader Class Initialized
INFO - 2024-04-14 13:42:59 --> Helper loaded: url_helper
INFO - 2024-04-14 13:42:59 --> Helper loaded: file_helper
INFO - 2024-04-14 13:42:59 --> Helper loaded: html_helper
INFO - 2024-04-14 13:42:59 --> Helper loaded: text_helper
INFO - 2024-04-14 13:42:59 --> Helper loaded: form_helper
INFO - 2024-04-14 13:42:59 --> Helper loaded: lang_helper
INFO - 2024-04-14 13:42:59 --> Helper loaded: security_helper
INFO - 2024-04-14 13:42:59 --> Helper loaded: cookie_helper
INFO - 2024-04-14 13:42:59 --> Database Driver Class Initialized
INFO - 2024-04-14 13:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 13:42:59 --> Parser Class Initialized
INFO - 2024-04-14 13:42:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 13:42:59 --> Pagination Class Initialized
INFO - 2024-04-14 13:42:59 --> Form Validation Class Initialized
INFO - 2024-04-14 13:42:59 --> Controller Class Initialized
INFO - 2024-04-14 13:42:59 --> Model Class Initialized
DEBUG - 2024-04-14 13:42:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-04-14 14:37:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 14:37:52 --> Config Class Initialized
INFO - 2024-04-14 14:37:52 --> Hooks Class Initialized
DEBUG - 2024-04-14 14:37:52 --> UTF-8 Support Enabled
INFO - 2024-04-14 14:37:52 --> Utf8 Class Initialized
INFO - 2024-04-14 14:37:52 --> URI Class Initialized
DEBUG - 2024-04-14 14:37:52 --> No URI present. Default controller set.
INFO - 2024-04-14 14:37:52 --> Router Class Initialized
INFO - 2024-04-14 14:37:52 --> Output Class Initialized
INFO - 2024-04-14 14:37:52 --> Security Class Initialized
DEBUG - 2024-04-14 14:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 14:37:52 --> Input Class Initialized
INFO - 2024-04-14 14:37:52 --> Language Class Initialized
INFO - 2024-04-14 14:37:52 --> Loader Class Initialized
INFO - 2024-04-14 14:37:52 --> Helper loaded: url_helper
INFO - 2024-04-14 14:37:52 --> Helper loaded: file_helper
INFO - 2024-04-14 14:37:52 --> Helper loaded: html_helper
INFO - 2024-04-14 14:37:52 --> Helper loaded: text_helper
INFO - 2024-04-14 14:37:52 --> Helper loaded: form_helper
INFO - 2024-04-14 14:37:52 --> Helper loaded: lang_helper
INFO - 2024-04-14 14:37:52 --> Helper loaded: security_helper
INFO - 2024-04-14 14:37:52 --> Helper loaded: cookie_helper
INFO - 2024-04-14 14:37:52 --> Database Driver Class Initialized
INFO - 2024-04-14 14:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 14:37:52 --> Parser Class Initialized
INFO - 2024-04-14 14:37:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 14:37:52 --> Pagination Class Initialized
INFO - 2024-04-14 14:37:52 --> Form Validation Class Initialized
INFO - 2024-04-14 14:37:52 --> Controller Class Initialized
INFO - 2024-04-14 14:37:52 --> Model Class Initialized
DEBUG - 2024-04-14 14:37:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-04-14 14:37:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 14:37:52 --> Config Class Initialized
INFO - 2024-04-14 14:37:52 --> Hooks Class Initialized
DEBUG - 2024-04-14 14:37:52 --> UTF-8 Support Enabled
INFO - 2024-04-14 14:37:52 --> Utf8 Class Initialized
INFO - 2024-04-14 14:37:52 --> URI Class Initialized
INFO - 2024-04-14 14:37:52 --> Router Class Initialized
INFO - 2024-04-14 14:37:52 --> Output Class Initialized
INFO - 2024-04-14 14:37:52 --> Security Class Initialized
DEBUG - 2024-04-14 14:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 14:37:52 --> Input Class Initialized
INFO - 2024-04-14 14:37:52 --> Language Class Initialized
INFO - 2024-04-14 14:37:52 --> Loader Class Initialized
INFO - 2024-04-14 14:37:52 --> Helper loaded: url_helper
INFO - 2024-04-14 14:37:52 --> Helper loaded: file_helper
INFO - 2024-04-14 14:37:52 --> Helper loaded: html_helper
INFO - 2024-04-14 14:37:52 --> Helper loaded: text_helper
INFO - 2024-04-14 14:37:52 --> Helper loaded: form_helper
INFO - 2024-04-14 14:37:52 --> Helper loaded: lang_helper
INFO - 2024-04-14 14:37:52 --> Helper loaded: security_helper
INFO - 2024-04-14 14:37:52 --> Helper loaded: cookie_helper
INFO - 2024-04-14 14:37:52 --> Database Driver Class Initialized
INFO - 2024-04-14 14:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 14:37:52 --> Parser Class Initialized
INFO - 2024-04-14 14:37:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 14:37:52 --> Pagination Class Initialized
INFO - 2024-04-14 14:37:52 --> Form Validation Class Initialized
INFO - 2024-04-14 14:37:52 --> Controller Class Initialized
INFO - 2024-04-14 14:37:52 --> Model Class Initialized
DEBUG - 2024-04-14 14:37:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 14:37:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-04-14 14:37:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 14:37:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 14:37:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 14:37:52 --> Model Class Initialized
INFO - 2024-04-14 14:37:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 14:37:52 --> Final output sent to browser
DEBUG - 2024-04-14 14:37:52 --> Total execution time: 0.0337
ERROR - 2024-04-14 14:38:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 14:38:05 --> Config Class Initialized
INFO - 2024-04-14 14:38:05 --> Hooks Class Initialized
DEBUG - 2024-04-14 14:38:05 --> UTF-8 Support Enabled
INFO - 2024-04-14 14:38:05 --> Utf8 Class Initialized
INFO - 2024-04-14 14:38:05 --> URI Class Initialized
INFO - 2024-04-14 14:38:05 --> Router Class Initialized
INFO - 2024-04-14 14:38:05 --> Output Class Initialized
INFO - 2024-04-14 14:38:05 --> Security Class Initialized
DEBUG - 2024-04-14 14:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 14:38:05 --> Input Class Initialized
INFO - 2024-04-14 14:38:05 --> Language Class Initialized
INFO - 2024-04-14 14:38:05 --> Loader Class Initialized
INFO - 2024-04-14 14:38:05 --> Helper loaded: url_helper
INFO - 2024-04-14 14:38:05 --> Helper loaded: file_helper
INFO - 2024-04-14 14:38:05 --> Helper loaded: html_helper
INFO - 2024-04-14 14:38:05 --> Helper loaded: text_helper
INFO - 2024-04-14 14:38:05 --> Helper loaded: form_helper
INFO - 2024-04-14 14:38:05 --> Helper loaded: lang_helper
INFO - 2024-04-14 14:38:05 --> Helper loaded: security_helper
INFO - 2024-04-14 14:38:05 --> Helper loaded: cookie_helper
INFO - 2024-04-14 14:38:05 --> Database Driver Class Initialized
INFO - 2024-04-14 14:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 14:38:05 --> Parser Class Initialized
INFO - 2024-04-14 14:38:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 14:38:05 --> Pagination Class Initialized
INFO - 2024-04-14 14:38:05 --> Form Validation Class Initialized
INFO - 2024-04-14 14:38:05 --> Controller Class Initialized
INFO - 2024-04-14 14:38:05 --> Model Class Initialized
DEBUG - 2024-04-14 14:38:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 14:38:05 --> Model Class Initialized
INFO - 2024-04-14 14:38:05 --> Final output sent to browser
DEBUG - 2024-04-14 14:38:05 --> Total execution time: 0.0213
ERROR - 2024-04-14 14:38:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 14:38:05 --> Config Class Initialized
INFO - 2024-04-14 14:38:05 --> Hooks Class Initialized
DEBUG - 2024-04-14 14:38:05 --> UTF-8 Support Enabled
INFO - 2024-04-14 14:38:05 --> Utf8 Class Initialized
INFO - 2024-04-14 14:38:05 --> URI Class Initialized
DEBUG - 2024-04-14 14:38:05 --> No URI present. Default controller set.
INFO - 2024-04-14 14:38:05 --> Router Class Initialized
INFO - 2024-04-14 14:38:05 --> Output Class Initialized
INFO - 2024-04-14 14:38:05 --> Security Class Initialized
DEBUG - 2024-04-14 14:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 14:38:05 --> Input Class Initialized
INFO - 2024-04-14 14:38:05 --> Language Class Initialized
INFO - 2024-04-14 14:38:05 --> Loader Class Initialized
INFO - 2024-04-14 14:38:05 --> Helper loaded: url_helper
INFO - 2024-04-14 14:38:05 --> Helper loaded: file_helper
INFO - 2024-04-14 14:38:05 --> Helper loaded: html_helper
INFO - 2024-04-14 14:38:05 --> Helper loaded: text_helper
INFO - 2024-04-14 14:38:05 --> Helper loaded: form_helper
INFO - 2024-04-14 14:38:05 --> Helper loaded: lang_helper
INFO - 2024-04-14 14:38:05 --> Helper loaded: security_helper
INFO - 2024-04-14 14:38:05 --> Helper loaded: cookie_helper
INFO - 2024-04-14 14:38:05 --> Database Driver Class Initialized
INFO - 2024-04-14 14:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 14:38:05 --> Parser Class Initialized
INFO - 2024-04-14 14:38:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 14:38:05 --> Pagination Class Initialized
INFO - 2024-04-14 14:38:05 --> Form Validation Class Initialized
INFO - 2024-04-14 14:38:05 --> Controller Class Initialized
INFO - 2024-04-14 14:38:05 --> Model Class Initialized
DEBUG - 2024-04-14 14:38:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 14:38:05 --> Model Class Initialized
DEBUG - 2024-04-14 14:38:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 14:38:05 --> Model Class Initialized
INFO - 2024-04-14 14:38:05 --> Model Class Initialized
INFO - 2024-04-14 14:38:06 --> Model Class Initialized
INFO - 2024-04-14 14:38:06 --> Model Class Initialized
DEBUG - 2024-04-14 14:38:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 14:38:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 14:38:06 --> Model Class Initialized
INFO - 2024-04-14 14:38:06 --> Model Class Initialized
INFO - 2024-04-14 14:38:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-14 14:38:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 14:38:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 14:38:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 14:38:06 --> Model Class Initialized
INFO - 2024-04-14 14:38:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-14 14:38:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-14 14:38:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 14:38:06 --> Final output sent to browser
DEBUG - 2024-04-14 14:38:06 --> Total execution time: 0.6148
ERROR - 2024-04-14 14:38:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 14:38:07 --> Config Class Initialized
INFO - 2024-04-14 14:38:07 --> Hooks Class Initialized
DEBUG - 2024-04-14 14:38:07 --> UTF-8 Support Enabled
INFO - 2024-04-14 14:38:07 --> Utf8 Class Initialized
INFO - 2024-04-14 14:38:07 --> URI Class Initialized
INFO - 2024-04-14 14:38:07 --> Router Class Initialized
INFO - 2024-04-14 14:38:07 --> Output Class Initialized
INFO - 2024-04-14 14:38:07 --> Security Class Initialized
DEBUG - 2024-04-14 14:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 14:38:07 --> Input Class Initialized
INFO - 2024-04-14 14:38:07 --> Language Class Initialized
INFO - 2024-04-14 14:38:07 --> Loader Class Initialized
INFO - 2024-04-14 14:38:07 --> Helper loaded: url_helper
INFO - 2024-04-14 14:38:07 --> Helper loaded: file_helper
INFO - 2024-04-14 14:38:07 --> Helper loaded: html_helper
INFO - 2024-04-14 14:38:07 --> Helper loaded: text_helper
INFO - 2024-04-14 14:38:07 --> Helper loaded: form_helper
INFO - 2024-04-14 14:38:07 --> Helper loaded: lang_helper
INFO - 2024-04-14 14:38:07 --> Helper loaded: security_helper
INFO - 2024-04-14 14:38:07 --> Helper loaded: cookie_helper
INFO - 2024-04-14 14:38:07 --> Database Driver Class Initialized
INFO - 2024-04-14 14:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 14:38:07 --> Parser Class Initialized
INFO - 2024-04-14 14:38:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 14:38:07 --> Pagination Class Initialized
INFO - 2024-04-14 14:38:07 --> Form Validation Class Initialized
INFO - 2024-04-14 14:38:07 --> Controller Class Initialized
DEBUG - 2024-04-14 14:38:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 14:38:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 14:38:07 --> Model Class Initialized
INFO - 2024-04-14 14:38:07 --> Final output sent to browser
DEBUG - 2024-04-14 14:38:07 --> Total execution time: 0.0132
ERROR - 2024-04-14 14:39:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 14:39:04 --> Config Class Initialized
INFO - 2024-04-14 14:39:04 --> Hooks Class Initialized
DEBUG - 2024-04-14 14:39:04 --> UTF-8 Support Enabled
INFO - 2024-04-14 14:39:04 --> Utf8 Class Initialized
INFO - 2024-04-14 14:39:04 --> URI Class Initialized
INFO - 2024-04-14 14:39:04 --> Router Class Initialized
INFO - 2024-04-14 14:39:04 --> Output Class Initialized
INFO - 2024-04-14 14:39:04 --> Security Class Initialized
DEBUG - 2024-04-14 14:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 14:39:04 --> Input Class Initialized
INFO - 2024-04-14 14:39:04 --> Language Class Initialized
INFO - 2024-04-14 14:39:04 --> Loader Class Initialized
INFO - 2024-04-14 14:39:04 --> Helper loaded: url_helper
INFO - 2024-04-14 14:39:04 --> Helper loaded: file_helper
INFO - 2024-04-14 14:39:04 --> Helper loaded: html_helper
INFO - 2024-04-14 14:39:04 --> Helper loaded: text_helper
INFO - 2024-04-14 14:39:04 --> Helper loaded: form_helper
INFO - 2024-04-14 14:39:04 --> Helper loaded: lang_helper
INFO - 2024-04-14 14:39:04 --> Helper loaded: security_helper
INFO - 2024-04-14 14:39:04 --> Helper loaded: cookie_helper
INFO - 2024-04-14 14:39:04 --> Database Driver Class Initialized
INFO - 2024-04-14 14:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 14:39:04 --> Parser Class Initialized
INFO - 2024-04-14 14:39:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 14:39:04 --> Pagination Class Initialized
INFO - 2024-04-14 14:39:04 --> Form Validation Class Initialized
INFO - 2024-04-14 14:39:04 --> Controller Class Initialized
INFO - 2024-04-14 14:39:04 --> Model Class Initialized
DEBUG - 2024-04-14 14:39:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 14:39:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 14:39:04 --> Model Class Initialized
DEBUG - 2024-04-14 14:39:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 14:39:04 --> Model Class Initialized
INFO - 2024-04-14 14:39:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-04-14 14:39:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-14 14:39:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-14 14:39:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-14 14:39:04 --> Model Class Initialized
INFO - 2024-04-14 14:39:04 --> Model Class Initialized
INFO - 2024-04-14 14:39:04 --> Model Class Initialized
INFO - 2024-04-14 14:39:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-14 14:39:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-14 14:39:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-14 14:39:05 --> Final output sent to browser
DEBUG - 2024-04-14 14:39:05 --> Total execution time: 0.3016
ERROR - 2024-04-14 14:39:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 14:39:06 --> Config Class Initialized
INFO - 2024-04-14 14:39:06 --> Hooks Class Initialized
DEBUG - 2024-04-14 14:39:06 --> UTF-8 Support Enabled
INFO - 2024-04-14 14:39:06 --> Utf8 Class Initialized
INFO - 2024-04-14 14:39:06 --> URI Class Initialized
INFO - 2024-04-14 14:39:06 --> Router Class Initialized
INFO - 2024-04-14 14:39:06 --> Output Class Initialized
INFO - 2024-04-14 14:39:06 --> Security Class Initialized
DEBUG - 2024-04-14 14:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 14:39:06 --> Input Class Initialized
INFO - 2024-04-14 14:39:06 --> Language Class Initialized
INFO - 2024-04-14 14:39:06 --> Loader Class Initialized
INFO - 2024-04-14 14:39:06 --> Helper loaded: url_helper
INFO - 2024-04-14 14:39:06 --> Helper loaded: file_helper
INFO - 2024-04-14 14:39:06 --> Helper loaded: html_helper
INFO - 2024-04-14 14:39:06 --> Helper loaded: text_helper
INFO - 2024-04-14 14:39:06 --> Helper loaded: form_helper
INFO - 2024-04-14 14:39:06 --> Helper loaded: lang_helper
INFO - 2024-04-14 14:39:06 --> Helper loaded: security_helper
INFO - 2024-04-14 14:39:06 --> Helper loaded: cookie_helper
INFO - 2024-04-14 14:39:06 --> Database Driver Class Initialized
INFO - 2024-04-14 14:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-14 14:39:06 --> Parser Class Initialized
INFO - 2024-04-14 14:39:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-14 14:39:06 --> Pagination Class Initialized
INFO - 2024-04-14 14:39:06 --> Form Validation Class Initialized
INFO - 2024-04-14 14:39:06 --> Controller Class Initialized
INFO - 2024-04-14 14:39:06 --> Model Class Initialized
DEBUG - 2024-04-14 14:39:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-14 14:39:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 14:39:06 --> Model Class Initialized
DEBUG - 2024-04-14 14:39:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-14 14:39:06 --> Model Class Initialized
INFO - 2024-04-14 14:39:06 --> Final output sent to browser
DEBUG - 2024-04-14 14:39:06 --> Total execution time: 0.0483
ERROR - 2024-04-14 17:08:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-14 17:08:16 --> Config Class Initialized
INFO - 2024-04-14 17:08:16 --> Hooks Class Initialized
DEBUG - 2024-04-14 17:08:16 --> UTF-8 Support Enabled
INFO - 2024-04-14 17:08:16 --> Utf8 Class Initialized
INFO - 2024-04-14 17:08:16 --> URI Class Initialized
INFO - 2024-04-14 17:08:16 --> Router Class Initialized
INFO - 2024-04-14 17:08:16 --> Output Class Initialized
INFO - 2024-04-14 17:08:16 --> Security Class Initialized
DEBUG - 2024-04-14 17:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-14 17:08:16 --> Input Class Initialized
INFO - 2024-04-14 17:08:16 --> Language Class Initialized
ERROR - 2024-04-14 17:08:16 --> 404 Page Not Found: Well-known/assetlinks.json
