<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-26 17:51:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-26 17:51:18 --> Config Class Initialized
INFO - 2023-06-26 17:51:18 --> Hooks Class Initialized
DEBUG - 2023-06-26 17:51:18 --> UTF-8 Support Enabled
INFO - 2023-06-26 17:51:18 --> Utf8 Class Initialized
INFO - 2023-06-26 17:51:18 --> URI Class Initialized
DEBUG - 2023-06-26 17:51:18 --> No URI present. Default controller set.
INFO - 2023-06-26 17:51:18 --> Router Class Initialized
INFO - 2023-06-26 17:51:18 --> Output Class Initialized
INFO - 2023-06-26 17:51:18 --> Security Class Initialized
DEBUG - 2023-06-26 17:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 17:51:18 --> Input Class Initialized
INFO - 2023-06-26 17:51:18 --> Language Class Initialized
INFO - 2023-06-26 17:51:18 --> Loader Class Initialized
INFO - 2023-06-26 17:51:18 --> Helper loaded: url_helper
INFO - 2023-06-26 17:51:18 --> Helper loaded: file_helper
INFO - 2023-06-26 17:51:18 --> Helper loaded: html_helper
INFO - 2023-06-26 17:51:18 --> Helper loaded: text_helper
INFO - 2023-06-26 17:51:18 --> Helper loaded: form_helper
INFO - 2023-06-26 17:51:18 --> Helper loaded: lang_helper
INFO - 2023-06-26 17:51:18 --> Helper loaded: security_helper
INFO - 2023-06-26 17:51:18 --> Helper loaded: cookie_helper
INFO - 2023-06-26 17:51:18 --> Database Driver Class Initialized
INFO - 2023-06-26 17:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 17:51:18 --> Parser Class Initialized
INFO - 2023-06-26 17:51:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-26 17:51:18 --> Pagination Class Initialized
INFO - 2023-06-26 17:51:18 --> Form Validation Class Initialized
INFO - 2023-06-26 17:51:18 --> Controller Class Initialized
INFO - 2023-06-26 17:51:18 --> Model Class Initialized
DEBUG - 2023-06-26 17:51:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-26 17:51:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-26 17:51:19 --> Config Class Initialized
INFO - 2023-06-26 17:51:19 --> Hooks Class Initialized
DEBUG - 2023-06-26 17:51:19 --> UTF-8 Support Enabled
INFO - 2023-06-26 17:51:19 --> Utf8 Class Initialized
INFO - 2023-06-26 17:51:19 --> URI Class Initialized
INFO - 2023-06-26 17:51:19 --> Router Class Initialized
INFO - 2023-06-26 17:51:19 --> Output Class Initialized
INFO - 2023-06-26 17:51:19 --> Security Class Initialized
DEBUG - 2023-06-26 17:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 17:51:19 --> Input Class Initialized
INFO - 2023-06-26 17:51:19 --> Language Class Initialized
INFO - 2023-06-26 17:51:19 --> Loader Class Initialized
INFO - 2023-06-26 17:51:19 --> Helper loaded: url_helper
INFO - 2023-06-26 17:51:19 --> Helper loaded: file_helper
INFO - 2023-06-26 17:51:19 --> Helper loaded: html_helper
INFO - 2023-06-26 17:51:19 --> Helper loaded: text_helper
INFO - 2023-06-26 17:51:19 --> Helper loaded: form_helper
INFO - 2023-06-26 17:51:19 --> Helper loaded: lang_helper
INFO - 2023-06-26 17:51:19 --> Helper loaded: security_helper
INFO - 2023-06-26 17:51:19 --> Helper loaded: cookie_helper
INFO - 2023-06-26 17:51:19 --> Database Driver Class Initialized
INFO - 2023-06-26 17:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 17:51:19 --> Parser Class Initialized
INFO - 2023-06-26 17:51:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-26 17:51:19 --> Pagination Class Initialized
INFO - 2023-06-26 17:51:19 --> Form Validation Class Initialized
INFO - 2023-06-26 17:51:19 --> Controller Class Initialized
INFO - 2023-06-26 17:51:19 --> Model Class Initialized
DEBUG - 2023-06-26 17:51:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:51:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-26 17:51:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:51:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-26 17:51:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-26 17:51:19 --> Model Class Initialized
INFO - 2023-06-26 17:51:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-26 17:51:19 --> Final output sent to browser
DEBUG - 2023-06-26 17:51:19 --> Total execution time: 0.0300
ERROR - 2023-06-26 17:51:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-26 17:51:24 --> Config Class Initialized
INFO - 2023-06-26 17:51:24 --> Hooks Class Initialized
DEBUG - 2023-06-26 17:51:24 --> UTF-8 Support Enabled
INFO - 2023-06-26 17:51:24 --> Utf8 Class Initialized
INFO - 2023-06-26 17:51:24 --> URI Class Initialized
INFO - 2023-06-26 17:51:24 --> Router Class Initialized
INFO - 2023-06-26 17:51:24 --> Output Class Initialized
INFO - 2023-06-26 17:51:24 --> Security Class Initialized
DEBUG - 2023-06-26 17:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 17:51:24 --> Input Class Initialized
INFO - 2023-06-26 17:51:24 --> Language Class Initialized
INFO - 2023-06-26 17:51:24 --> Loader Class Initialized
INFO - 2023-06-26 17:51:24 --> Helper loaded: url_helper
INFO - 2023-06-26 17:51:24 --> Helper loaded: file_helper
INFO - 2023-06-26 17:51:24 --> Helper loaded: html_helper
INFO - 2023-06-26 17:51:24 --> Helper loaded: text_helper
INFO - 2023-06-26 17:51:24 --> Helper loaded: form_helper
INFO - 2023-06-26 17:51:24 --> Helper loaded: lang_helper
INFO - 2023-06-26 17:51:24 --> Helper loaded: security_helper
INFO - 2023-06-26 17:51:24 --> Helper loaded: cookie_helper
INFO - 2023-06-26 17:51:24 --> Database Driver Class Initialized
INFO - 2023-06-26 17:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 17:51:24 --> Parser Class Initialized
INFO - 2023-06-26 17:51:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-26 17:51:24 --> Pagination Class Initialized
INFO - 2023-06-26 17:51:24 --> Form Validation Class Initialized
INFO - 2023-06-26 17:51:24 --> Controller Class Initialized
INFO - 2023-06-26 17:51:24 --> Model Class Initialized
DEBUG - 2023-06-26 17:51:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:51:24 --> Model Class Initialized
INFO - 2023-06-26 17:51:24 --> Final output sent to browser
DEBUG - 2023-06-26 17:51:24 --> Total execution time: 0.0188
ERROR - 2023-06-26 17:51:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-26 17:51:24 --> Config Class Initialized
INFO - 2023-06-26 17:51:24 --> Hooks Class Initialized
DEBUG - 2023-06-26 17:51:24 --> UTF-8 Support Enabled
INFO - 2023-06-26 17:51:24 --> Utf8 Class Initialized
INFO - 2023-06-26 17:51:24 --> URI Class Initialized
DEBUG - 2023-06-26 17:51:24 --> No URI present. Default controller set.
INFO - 2023-06-26 17:51:24 --> Router Class Initialized
INFO - 2023-06-26 17:51:24 --> Output Class Initialized
INFO - 2023-06-26 17:51:24 --> Security Class Initialized
DEBUG - 2023-06-26 17:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 17:51:24 --> Input Class Initialized
INFO - 2023-06-26 17:51:24 --> Language Class Initialized
INFO - 2023-06-26 17:51:24 --> Loader Class Initialized
INFO - 2023-06-26 17:51:24 --> Helper loaded: url_helper
INFO - 2023-06-26 17:51:24 --> Helper loaded: file_helper
INFO - 2023-06-26 17:51:24 --> Helper loaded: html_helper
INFO - 2023-06-26 17:51:24 --> Helper loaded: text_helper
INFO - 2023-06-26 17:51:24 --> Helper loaded: form_helper
INFO - 2023-06-26 17:51:24 --> Helper loaded: lang_helper
INFO - 2023-06-26 17:51:24 --> Helper loaded: security_helper
INFO - 2023-06-26 17:51:24 --> Helper loaded: cookie_helper
INFO - 2023-06-26 17:51:24 --> Database Driver Class Initialized
INFO - 2023-06-26 17:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 17:51:24 --> Parser Class Initialized
INFO - 2023-06-26 17:51:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-26 17:51:24 --> Pagination Class Initialized
INFO - 2023-06-26 17:51:24 --> Form Validation Class Initialized
INFO - 2023-06-26 17:51:24 --> Controller Class Initialized
INFO - 2023-06-26 17:51:24 --> Model Class Initialized
DEBUG - 2023-06-26 17:51:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:51:24 --> Model Class Initialized
DEBUG - 2023-06-26 17:51:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:51:24 --> Model Class Initialized
INFO - 2023-06-26 17:51:24 --> Model Class Initialized
INFO - 2023-06-26 17:51:24 --> Model Class Initialized
INFO - 2023-06-26 17:51:24 --> Model Class Initialized
DEBUG - 2023-06-26 17:51:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 17:51:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:51:24 --> Model Class Initialized
INFO - 2023-06-26 17:51:24 --> Model Class Initialized
INFO - 2023-06-26 17:51:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-26 17:51:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:51:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-26 17:51:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-26 17:51:24 --> Model Class Initialized
INFO - 2023-06-26 17:51:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-26 17:51:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-26 17:51:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-26 17:51:24 --> Final output sent to browser
DEBUG - 2023-06-26 17:51:24 --> Total execution time: 0.0957
ERROR - 2023-06-26 17:51:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-26 17:51:38 --> Config Class Initialized
INFO - 2023-06-26 17:51:38 --> Hooks Class Initialized
DEBUG - 2023-06-26 17:51:38 --> UTF-8 Support Enabled
INFO - 2023-06-26 17:51:38 --> Utf8 Class Initialized
INFO - 2023-06-26 17:51:38 --> URI Class Initialized
INFO - 2023-06-26 17:51:38 --> Router Class Initialized
INFO - 2023-06-26 17:51:38 --> Output Class Initialized
INFO - 2023-06-26 17:51:38 --> Security Class Initialized
DEBUG - 2023-06-26 17:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 17:51:38 --> Input Class Initialized
INFO - 2023-06-26 17:51:38 --> Language Class Initialized
INFO - 2023-06-26 17:51:38 --> Loader Class Initialized
INFO - 2023-06-26 17:51:38 --> Helper loaded: url_helper
INFO - 2023-06-26 17:51:38 --> Helper loaded: file_helper
INFO - 2023-06-26 17:51:38 --> Helper loaded: html_helper
INFO - 2023-06-26 17:51:38 --> Helper loaded: text_helper
INFO - 2023-06-26 17:51:38 --> Helper loaded: form_helper
INFO - 2023-06-26 17:51:38 --> Helper loaded: lang_helper
INFO - 2023-06-26 17:51:38 --> Helper loaded: security_helper
INFO - 2023-06-26 17:51:38 --> Helper loaded: cookie_helper
INFO - 2023-06-26 17:51:38 --> Database Driver Class Initialized
INFO - 2023-06-26 17:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 17:51:38 --> Parser Class Initialized
INFO - 2023-06-26 17:51:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-26 17:51:38 --> Pagination Class Initialized
INFO - 2023-06-26 17:51:38 --> Form Validation Class Initialized
INFO - 2023-06-26 17:51:38 --> Controller Class Initialized
INFO - 2023-06-26 17:51:38 --> Model Class Initialized
DEBUG - 2023-06-26 17:51:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 17:51:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:51:38 --> Model Class Initialized
INFO - 2023-06-26 17:51:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-06-26 17:51:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:51:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-26 17:51:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-26 17:51:38 --> Model Class Initialized
INFO - 2023-06-26 17:51:38 --> Model Class Initialized
INFO - 2023-06-26 17:51:38 --> Model Class Initialized
INFO - 2023-06-26 17:51:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-26 17:51:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-26 17:51:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-26 17:51:38 --> Final output sent to browser
DEBUG - 2023-06-26 17:51:38 --> Total execution time: 0.0659
ERROR - 2023-06-26 17:51:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-26 17:51:39 --> Config Class Initialized
INFO - 2023-06-26 17:51:39 --> Hooks Class Initialized
DEBUG - 2023-06-26 17:51:39 --> UTF-8 Support Enabled
INFO - 2023-06-26 17:51:39 --> Utf8 Class Initialized
INFO - 2023-06-26 17:51:39 --> URI Class Initialized
INFO - 2023-06-26 17:51:39 --> Router Class Initialized
INFO - 2023-06-26 17:51:39 --> Output Class Initialized
INFO - 2023-06-26 17:51:39 --> Security Class Initialized
DEBUG - 2023-06-26 17:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 17:51:39 --> Input Class Initialized
INFO - 2023-06-26 17:51:39 --> Language Class Initialized
INFO - 2023-06-26 17:51:39 --> Loader Class Initialized
INFO - 2023-06-26 17:51:39 --> Helper loaded: url_helper
INFO - 2023-06-26 17:51:39 --> Helper loaded: file_helper
INFO - 2023-06-26 17:51:39 --> Helper loaded: html_helper
INFO - 2023-06-26 17:51:39 --> Helper loaded: text_helper
INFO - 2023-06-26 17:51:39 --> Helper loaded: form_helper
INFO - 2023-06-26 17:51:39 --> Helper loaded: lang_helper
INFO - 2023-06-26 17:51:39 --> Helper loaded: security_helper
INFO - 2023-06-26 17:51:39 --> Helper loaded: cookie_helper
INFO - 2023-06-26 17:51:39 --> Database Driver Class Initialized
INFO - 2023-06-26 17:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 17:51:39 --> Parser Class Initialized
INFO - 2023-06-26 17:51:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-26 17:51:39 --> Pagination Class Initialized
INFO - 2023-06-26 17:51:39 --> Form Validation Class Initialized
INFO - 2023-06-26 17:51:39 --> Controller Class Initialized
INFO - 2023-06-26 17:51:39 --> Model Class Initialized
DEBUG - 2023-06-26 17:51:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 17:51:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:51:39 --> Model Class Initialized
INFO - 2023-06-26 17:51:39 --> Final output sent to browser
DEBUG - 2023-06-26 17:51:39 --> Total execution time: 0.0264
ERROR - 2023-06-26 17:51:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-26 17:51:44 --> Config Class Initialized
INFO - 2023-06-26 17:51:44 --> Hooks Class Initialized
DEBUG - 2023-06-26 17:51:44 --> UTF-8 Support Enabled
INFO - 2023-06-26 17:51:44 --> Utf8 Class Initialized
INFO - 2023-06-26 17:51:44 --> URI Class Initialized
INFO - 2023-06-26 17:51:44 --> Router Class Initialized
INFO - 2023-06-26 17:51:44 --> Output Class Initialized
INFO - 2023-06-26 17:51:44 --> Security Class Initialized
DEBUG - 2023-06-26 17:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 17:51:44 --> Input Class Initialized
INFO - 2023-06-26 17:51:44 --> Language Class Initialized
INFO - 2023-06-26 17:51:44 --> Loader Class Initialized
INFO - 2023-06-26 17:51:44 --> Helper loaded: url_helper
INFO - 2023-06-26 17:51:44 --> Helper loaded: file_helper
INFO - 2023-06-26 17:51:44 --> Helper loaded: html_helper
INFO - 2023-06-26 17:51:44 --> Helper loaded: text_helper
INFO - 2023-06-26 17:51:44 --> Helper loaded: form_helper
INFO - 2023-06-26 17:51:44 --> Helper loaded: lang_helper
INFO - 2023-06-26 17:51:44 --> Helper loaded: security_helper
INFO - 2023-06-26 17:51:44 --> Helper loaded: cookie_helper
INFO - 2023-06-26 17:51:44 --> Database Driver Class Initialized
INFO - 2023-06-26 17:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 17:51:44 --> Parser Class Initialized
INFO - 2023-06-26 17:51:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-26 17:51:44 --> Pagination Class Initialized
INFO - 2023-06-26 17:51:44 --> Form Validation Class Initialized
INFO - 2023-06-26 17:51:44 --> Controller Class Initialized
INFO - 2023-06-26 17:51:44 --> Model Class Initialized
DEBUG - 2023-06-26 17:51:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 17:51:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:51:44 --> Model Class Initialized
INFO - 2023-06-26 17:51:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-06-26 17:51:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:51:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-26 17:51:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-26 17:51:44 --> Model Class Initialized
INFO - 2023-06-26 17:51:44 --> Model Class Initialized
INFO - 2023-06-26 17:51:44 --> Model Class Initialized
INFO - 2023-06-26 17:51:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-26 17:51:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-26 17:51:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-26 17:51:44 --> Final output sent to browser
DEBUG - 2023-06-26 17:51:44 --> Total execution time: 0.0585
ERROR - 2023-06-26 17:51:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-26 17:51:45 --> Config Class Initialized
INFO - 2023-06-26 17:51:45 --> Hooks Class Initialized
DEBUG - 2023-06-26 17:51:45 --> UTF-8 Support Enabled
INFO - 2023-06-26 17:51:45 --> Utf8 Class Initialized
INFO - 2023-06-26 17:51:45 --> URI Class Initialized
INFO - 2023-06-26 17:51:45 --> Router Class Initialized
INFO - 2023-06-26 17:51:45 --> Output Class Initialized
INFO - 2023-06-26 17:51:45 --> Security Class Initialized
DEBUG - 2023-06-26 17:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 17:51:45 --> Input Class Initialized
INFO - 2023-06-26 17:51:45 --> Language Class Initialized
INFO - 2023-06-26 17:51:45 --> Loader Class Initialized
INFO - 2023-06-26 17:51:45 --> Helper loaded: url_helper
INFO - 2023-06-26 17:51:45 --> Helper loaded: file_helper
INFO - 2023-06-26 17:51:45 --> Helper loaded: html_helper
INFO - 2023-06-26 17:51:45 --> Helper loaded: text_helper
INFO - 2023-06-26 17:51:45 --> Helper loaded: form_helper
INFO - 2023-06-26 17:51:45 --> Helper loaded: lang_helper
INFO - 2023-06-26 17:51:45 --> Helper loaded: security_helper
INFO - 2023-06-26 17:51:45 --> Helper loaded: cookie_helper
INFO - 2023-06-26 17:51:45 --> Database Driver Class Initialized
INFO - 2023-06-26 17:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 17:51:45 --> Parser Class Initialized
INFO - 2023-06-26 17:51:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-26 17:51:45 --> Pagination Class Initialized
INFO - 2023-06-26 17:51:45 --> Form Validation Class Initialized
INFO - 2023-06-26 17:51:45 --> Controller Class Initialized
INFO - 2023-06-26 17:51:45 --> Model Class Initialized
DEBUG - 2023-06-26 17:51:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 17:51:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:51:45 --> Model Class Initialized
INFO - 2023-06-26 17:51:45 --> Final output sent to browser
DEBUG - 2023-06-26 17:51:45 --> Total execution time: 0.0254
ERROR - 2023-06-26 17:51:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-26 17:51:50 --> Config Class Initialized
INFO - 2023-06-26 17:51:50 --> Hooks Class Initialized
DEBUG - 2023-06-26 17:51:50 --> UTF-8 Support Enabled
INFO - 2023-06-26 17:51:50 --> Utf8 Class Initialized
INFO - 2023-06-26 17:51:50 --> URI Class Initialized
INFO - 2023-06-26 17:51:50 --> Router Class Initialized
INFO - 2023-06-26 17:51:50 --> Output Class Initialized
INFO - 2023-06-26 17:51:50 --> Security Class Initialized
DEBUG - 2023-06-26 17:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 17:51:50 --> Input Class Initialized
INFO - 2023-06-26 17:51:50 --> Language Class Initialized
INFO - 2023-06-26 17:51:50 --> Loader Class Initialized
INFO - 2023-06-26 17:51:50 --> Helper loaded: url_helper
INFO - 2023-06-26 17:51:50 --> Helper loaded: file_helper
INFO - 2023-06-26 17:51:50 --> Helper loaded: html_helper
INFO - 2023-06-26 17:51:50 --> Helper loaded: text_helper
INFO - 2023-06-26 17:51:50 --> Helper loaded: form_helper
INFO - 2023-06-26 17:51:50 --> Helper loaded: lang_helper
INFO - 2023-06-26 17:51:50 --> Helper loaded: security_helper
INFO - 2023-06-26 17:51:50 --> Helper loaded: cookie_helper
INFO - 2023-06-26 17:51:50 --> Database Driver Class Initialized
INFO - 2023-06-26 17:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 17:51:50 --> Parser Class Initialized
INFO - 2023-06-26 17:51:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-26 17:51:50 --> Pagination Class Initialized
INFO - 2023-06-26 17:51:50 --> Form Validation Class Initialized
INFO - 2023-06-26 17:51:50 --> Controller Class Initialized
INFO - 2023-06-26 17:51:50 --> Model Class Initialized
DEBUG - 2023-06-26 17:51:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 17:51:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:51:50 --> Model Class Initialized
INFO - 2023-06-26 17:51:50 --> Final output sent to browser
DEBUG - 2023-06-26 17:51:50 --> Total execution time: 0.0259
ERROR - 2023-06-26 17:52:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-26 17:52:17 --> Config Class Initialized
INFO - 2023-06-26 17:52:17 --> Hooks Class Initialized
DEBUG - 2023-06-26 17:52:17 --> UTF-8 Support Enabled
INFO - 2023-06-26 17:52:17 --> Utf8 Class Initialized
INFO - 2023-06-26 17:52:17 --> URI Class Initialized
INFO - 2023-06-26 17:52:17 --> Router Class Initialized
INFO - 2023-06-26 17:52:17 --> Output Class Initialized
INFO - 2023-06-26 17:52:17 --> Security Class Initialized
DEBUG - 2023-06-26 17:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 17:52:17 --> Input Class Initialized
INFO - 2023-06-26 17:52:17 --> Language Class Initialized
INFO - 2023-06-26 17:52:17 --> Loader Class Initialized
INFO - 2023-06-26 17:52:17 --> Helper loaded: url_helper
INFO - 2023-06-26 17:52:17 --> Helper loaded: file_helper
INFO - 2023-06-26 17:52:17 --> Helper loaded: html_helper
INFO - 2023-06-26 17:52:17 --> Helper loaded: text_helper
INFO - 2023-06-26 17:52:17 --> Helper loaded: form_helper
INFO - 2023-06-26 17:52:17 --> Helper loaded: lang_helper
INFO - 2023-06-26 17:52:17 --> Helper loaded: security_helper
INFO - 2023-06-26 17:52:17 --> Helper loaded: cookie_helper
INFO - 2023-06-26 17:52:17 --> Database Driver Class Initialized
INFO - 2023-06-26 17:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 17:52:17 --> Parser Class Initialized
INFO - 2023-06-26 17:52:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-26 17:52:17 --> Pagination Class Initialized
INFO - 2023-06-26 17:52:17 --> Form Validation Class Initialized
INFO - 2023-06-26 17:52:17 --> Controller Class Initialized
DEBUG - 2023-06-26 17:52:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 17:52:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:52:17 --> Model Class Initialized
DEBUG - 2023-06-26 17:52:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:52:17 --> Model Class Initialized
DEBUG - 2023-06-26 17:52:17 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:52:17 --> Model Class Initialized
INFO - 2023-06-26 17:52:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-06-26 17:52:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:52:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-26 17:52:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-26 17:52:17 --> Model Class Initialized
INFO - 2023-06-26 17:52:17 --> Model Class Initialized
INFO - 2023-06-26 17:52:17 --> Model Class Initialized
INFO - 2023-06-26 17:52:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-26 17:52:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-26 17:52:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-26 17:52:17 --> Final output sent to browser
DEBUG - 2023-06-26 17:52:17 --> Total execution time: 0.0656
ERROR - 2023-06-26 17:52:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-26 17:52:18 --> Config Class Initialized
INFO - 2023-06-26 17:52:18 --> Hooks Class Initialized
DEBUG - 2023-06-26 17:52:18 --> UTF-8 Support Enabled
INFO - 2023-06-26 17:52:18 --> Utf8 Class Initialized
INFO - 2023-06-26 17:52:18 --> URI Class Initialized
INFO - 2023-06-26 17:52:18 --> Router Class Initialized
INFO - 2023-06-26 17:52:18 --> Output Class Initialized
INFO - 2023-06-26 17:52:18 --> Security Class Initialized
DEBUG - 2023-06-26 17:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 17:52:18 --> Input Class Initialized
INFO - 2023-06-26 17:52:18 --> Language Class Initialized
INFO - 2023-06-26 17:52:18 --> Loader Class Initialized
INFO - 2023-06-26 17:52:18 --> Helper loaded: url_helper
INFO - 2023-06-26 17:52:18 --> Helper loaded: file_helper
INFO - 2023-06-26 17:52:18 --> Helper loaded: html_helper
INFO - 2023-06-26 17:52:18 --> Helper loaded: text_helper
INFO - 2023-06-26 17:52:18 --> Helper loaded: form_helper
INFO - 2023-06-26 17:52:18 --> Helper loaded: lang_helper
INFO - 2023-06-26 17:52:18 --> Helper loaded: security_helper
INFO - 2023-06-26 17:52:18 --> Helper loaded: cookie_helper
INFO - 2023-06-26 17:52:18 --> Database Driver Class Initialized
INFO - 2023-06-26 17:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 17:52:18 --> Parser Class Initialized
INFO - 2023-06-26 17:52:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-26 17:52:18 --> Pagination Class Initialized
INFO - 2023-06-26 17:52:18 --> Form Validation Class Initialized
INFO - 2023-06-26 17:52:18 --> Controller Class Initialized
DEBUG - 2023-06-26 17:52:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 17:52:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:52:18 --> Model Class Initialized
DEBUG - 2023-06-26 17:52:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:52:18 --> Model Class Initialized
INFO - 2023-06-26 17:52:18 --> Final output sent to browser
DEBUG - 2023-06-26 17:52:18 --> Total execution time: 0.0231
ERROR - 2023-06-26 17:52:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-26 17:52:23 --> Config Class Initialized
INFO - 2023-06-26 17:52:23 --> Hooks Class Initialized
DEBUG - 2023-06-26 17:52:23 --> UTF-8 Support Enabled
INFO - 2023-06-26 17:52:23 --> Utf8 Class Initialized
INFO - 2023-06-26 17:52:23 --> URI Class Initialized
INFO - 2023-06-26 17:52:23 --> Router Class Initialized
INFO - 2023-06-26 17:52:23 --> Output Class Initialized
INFO - 2023-06-26 17:52:23 --> Security Class Initialized
DEBUG - 2023-06-26 17:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 17:52:23 --> Input Class Initialized
INFO - 2023-06-26 17:52:23 --> Language Class Initialized
INFO - 2023-06-26 17:52:23 --> Loader Class Initialized
INFO - 2023-06-26 17:52:23 --> Helper loaded: url_helper
INFO - 2023-06-26 17:52:23 --> Helper loaded: file_helper
INFO - 2023-06-26 17:52:23 --> Helper loaded: html_helper
INFO - 2023-06-26 17:52:23 --> Helper loaded: text_helper
INFO - 2023-06-26 17:52:23 --> Helper loaded: form_helper
INFO - 2023-06-26 17:52:23 --> Helper loaded: lang_helper
INFO - 2023-06-26 17:52:23 --> Helper loaded: security_helper
INFO - 2023-06-26 17:52:23 --> Helper loaded: cookie_helper
INFO - 2023-06-26 17:52:23 --> Database Driver Class Initialized
INFO - 2023-06-26 17:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 17:52:23 --> Parser Class Initialized
INFO - 2023-06-26 17:52:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-26 17:52:23 --> Pagination Class Initialized
INFO - 2023-06-26 17:52:23 --> Form Validation Class Initialized
INFO - 2023-06-26 17:52:23 --> Controller Class Initialized
DEBUG - 2023-06-26 17:52:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 17:52:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:52:23 --> Model Class Initialized
DEBUG - 2023-06-26 17:52:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:52:23 --> Model Class Initialized
INFO - 2023-06-26 17:52:23 --> Final output sent to browser
DEBUG - 2023-06-26 17:52:23 --> Total execution time: 0.0304
ERROR - 2023-06-26 17:52:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-26 17:52:43 --> Config Class Initialized
INFO - 2023-06-26 17:52:43 --> Hooks Class Initialized
DEBUG - 2023-06-26 17:52:43 --> UTF-8 Support Enabled
INFO - 2023-06-26 17:52:43 --> Utf8 Class Initialized
INFO - 2023-06-26 17:52:43 --> URI Class Initialized
INFO - 2023-06-26 17:52:43 --> Router Class Initialized
INFO - 2023-06-26 17:52:43 --> Output Class Initialized
INFO - 2023-06-26 17:52:43 --> Security Class Initialized
DEBUG - 2023-06-26 17:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 17:52:43 --> Input Class Initialized
INFO - 2023-06-26 17:52:43 --> Language Class Initialized
INFO - 2023-06-26 17:52:43 --> Loader Class Initialized
INFO - 2023-06-26 17:52:43 --> Helper loaded: url_helper
INFO - 2023-06-26 17:52:43 --> Helper loaded: file_helper
INFO - 2023-06-26 17:52:43 --> Helper loaded: html_helper
INFO - 2023-06-26 17:52:43 --> Helper loaded: text_helper
INFO - 2023-06-26 17:52:43 --> Helper loaded: form_helper
INFO - 2023-06-26 17:52:43 --> Helper loaded: lang_helper
INFO - 2023-06-26 17:52:43 --> Helper loaded: security_helper
INFO - 2023-06-26 17:52:43 --> Helper loaded: cookie_helper
INFO - 2023-06-26 17:52:43 --> Database Driver Class Initialized
INFO - 2023-06-26 17:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 17:52:43 --> Parser Class Initialized
INFO - 2023-06-26 17:52:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-26 17:52:43 --> Pagination Class Initialized
INFO - 2023-06-26 17:52:43 --> Form Validation Class Initialized
INFO - 2023-06-26 17:52:43 --> Controller Class Initialized
INFO - 2023-06-26 17:52:43 --> Model Class Initialized
DEBUG - 2023-06-26 17:52:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 17:52:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:52:43 --> Model Class Initialized
DEBUG - 2023-06-26 17:52:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:52:43 --> Model Class Initialized
INFO - 2023-06-26 17:52:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-26 17:52:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:52:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-26 17:52:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-26 17:52:43 --> Model Class Initialized
INFO - 2023-06-26 17:52:43 --> Model Class Initialized
INFO - 2023-06-26 17:52:43 --> Model Class Initialized
INFO - 2023-06-26 17:52:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-26 17:52:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-26 17:52:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-26 17:52:44 --> Final output sent to browser
DEBUG - 2023-06-26 17:52:44 --> Total execution time: 0.0701
ERROR - 2023-06-26 17:52:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-26 17:52:44 --> Config Class Initialized
INFO - 2023-06-26 17:52:44 --> Hooks Class Initialized
DEBUG - 2023-06-26 17:52:44 --> UTF-8 Support Enabled
INFO - 2023-06-26 17:52:44 --> Utf8 Class Initialized
INFO - 2023-06-26 17:52:44 --> URI Class Initialized
INFO - 2023-06-26 17:52:44 --> Router Class Initialized
INFO - 2023-06-26 17:52:44 --> Output Class Initialized
INFO - 2023-06-26 17:52:44 --> Security Class Initialized
DEBUG - 2023-06-26 17:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 17:52:44 --> Input Class Initialized
INFO - 2023-06-26 17:52:44 --> Language Class Initialized
INFO - 2023-06-26 17:52:44 --> Loader Class Initialized
INFO - 2023-06-26 17:52:44 --> Helper loaded: url_helper
INFO - 2023-06-26 17:52:44 --> Helper loaded: file_helper
INFO - 2023-06-26 17:52:44 --> Helper loaded: html_helper
INFO - 2023-06-26 17:52:44 --> Helper loaded: text_helper
INFO - 2023-06-26 17:52:44 --> Helper loaded: form_helper
INFO - 2023-06-26 17:52:44 --> Helper loaded: lang_helper
INFO - 2023-06-26 17:52:44 --> Helper loaded: security_helper
INFO - 2023-06-26 17:52:44 --> Helper loaded: cookie_helper
INFO - 2023-06-26 17:52:44 --> Database Driver Class Initialized
INFO - 2023-06-26 17:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 17:52:44 --> Parser Class Initialized
INFO - 2023-06-26 17:52:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-26 17:52:44 --> Pagination Class Initialized
INFO - 2023-06-26 17:52:44 --> Form Validation Class Initialized
INFO - 2023-06-26 17:52:44 --> Controller Class Initialized
INFO - 2023-06-26 17:52:44 --> Model Class Initialized
DEBUG - 2023-06-26 17:52:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 17:52:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:52:44 --> Model Class Initialized
DEBUG - 2023-06-26 17:52:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:52:44 --> Model Class Initialized
INFO - 2023-06-26 17:52:44 --> Final output sent to browser
DEBUG - 2023-06-26 17:52:44 --> Total execution time: 0.0364
ERROR - 2023-06-26 17:52:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-26 17:52:50 --> Config Class Initialized
INFO - 2023-06-26 17:52:50 --> Hooks Class Initialized
DEBUG - 2023-06-26 17:52:50 --> UTF-8 Support Enabled
INFO - 2023-06-26 17:52:50 --> Utf8 Class Initialized
INFO - 2023-06-26 17:52:50 --> URI Class Initialized
INFO - 2023-06-26 17:52:50 --> Router Class Initialized
INFO - 2023-06-26 17:52:50 --> Output Class Initialized
INFO - 2023-06-26 17:52:50 --> Security Class Initialized
DEBUG - 2023-06-26 17:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 17:52:50 --> Input Class Initialized
INFO - 2023-06-26 17:52:50 --> Language Class Initialized
INFO - 2023-06-26 17:52:50 --> Loader Class Initialized
INFO - 2023-06-26 17:52:50 --> Helper loaded: url_helper
INFO - 2023-06-26 17:52:50 --> Helper loaded: file_helper
INFO - 2023-06-26 17:52:50 --> Helper loaded: html_helper
INFO - 2023-06-26 17:52:50 --> Helper loaded: text_helper
INFO - 2023-06-26 17:52:50 --> Helper loaded: form_helper
INFO - 2023-06-26 17:52:50 --> Helper loaded: lang_helper
INFO - 2023-06-26 17:52:50 --> Helper loaded: security_helper
INFO - 2023-06-26 17:52:50 --> Helper loaded: cookie_helper
INFO - 2023-06-26 17:52:50 --> Database Driver Class Initialized
INFO - 2023-06-26 17:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 17:52:50 --> Parser Class Initialized
INFO - 2023-06-26 17:52:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-26 17:52:50 --> Pagination Class Initialized
INFO - 2023-06-26 17:52:50 --> Form Validation Class Initialized
INFO - 2023-06-26 17:52:50 --> Controller Class Initialized
INFO - 2023-06-26 17:52:50 --> Model Class Initialized
DEBUG - 2023-06-26 17:52:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 17:52:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:52:50 --> Model Class Initialized
DEBUG - 2023-06-26 17:52:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:52:50 --> Model Class Initialized
INFO - 2023-06-26 17:52:50 --> Final output sent to browser
DEBUG - 2023-06-26 17:52:50 --> Total execution time: 0.1187
ERROR - 2023-06-26 17:54:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-26 17:54:47 --> Config Class Initialized
INFO - 2023-06-26 17:54:47 --> Hooks Class Initialized
DEBUG - 2023-06-26 17:54:47 --> UTF-8 Support Enabled
INFO - 2023-06-26 17:54:47 --> Utf8 Class Initialized
INFO - 2023-06-26 17:54:47 --> URI Class Initialized
DEBUG - 2023-06-26 17:54:47 --> No URI present. Default controller set.
INFO - 2023-06-26 17:54:47 --> Router Class Initialized
INFO - 2023-06-26 17:54:47 --> Output Class Initialized
INFO - 2023-06-26 17:54:47 --> Security Class Initialized
DEBUG - 2023-06-26 17:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 17:54:47 --> Input Class Initialized
INFO - 2023-06-26 17:54:47 --> Language Class Initialized
INFO - 2023-06-26 17:54:47 --> Loader Class Initialized
INFO - 2023-06-26 17:54:47 --> Helper loaded: url_helper
INFO - 2023-06-26 17:54:47 --> Helper loaded: file_helper
INFO - 2023-06-26 17:54:47 --> Helper loaded: html_helper
INFO - 2023-06-26 17:54:47 --> Helper loaded: text_helper
INFO - 2023-06-26 17:54:47 --> Helper loaded: form_helper
INFO - 2023-06-26 17:54:47 --> Helper loaded: lang_helper
INFO - 2023-06-26 17:54:47 --> Helper loaded: security_helper
INFO - 2023-06-26 17:54:47 --> Helper loaded: cookie_helper
INFO - 2023-06-26 17:54:47 --> Database Driver Class Initialized
INFO - 2023-06-26 17:54:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 17:54:47 --> Parser Class Initialized
INFO - 2023-06-26 17:54:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-26 17:54:47 --> Pagination Class Initialized
INFO - 2023-06-26 17:54:47 --> Form Validation Class Initialized
INFO - 2023-06-26 17:54:47 --> Controller Class Initialized
INFO - 2023-06-26 17:54:47 --> Model Class Initialized
DEBUG - 2023-06-26 17:54:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:54:47 --> Model Class Initialized
DEBUG - 2023-06-26 17:54:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:54:47 --> Model Class Initialized
INFO - 2023-06-26 17:54:47 --> Model Class Initialized
INFO - 2023-06-26 17:54:47 --> Model Class Initialized
INFO - 2023-06-26 17:54:47 --> Model Class Initialized
DEBUG - 2023-06-26 17:54:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 17:54:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:54:47 --> Model Class Initialized
INFO - 2023-06-26 17:54:47 --> Model Class Initialized
INFO - 2023-06-26 17:54:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-26 17:54:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:54:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-26 17:54:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-26 17:54:47 --> Model Class Initialized
INFO - 2023-06-26 17:54:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-26 17:54:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-26 17:54:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-26 17:54:47 --> Final output sent to browser
DEBUG - 2023-06-26 17:54:47 --> Total execution time: 0.0806
ERROR - 2023-06-26 17:57:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-26 17:57:12 --> Config Class Initialized
INFO - 2023-06-26 17:57:12 --> Hooks Class Initialized
DEBUG - 2023-06-26 17:57:12 --> UTF-8 Support Enabled
INFO - 2023-06-26 17:57:12 --> Utf8 Class Initialized
INFO - 2023-06-26 17:57:12 --> URI Class Initialized
INFO - 2023-06-26 17:57:12 --> Router Class Initialized
INFO - 2023-06-26 17:57:12 --> Output Class Initialized
INFO - 2023-06-26 17:57:12 --> Security Class Initialized
DEBUG - 2023-06-26 17:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 17:57:12 --> Input Class Initialized
INFO - 2023-06-26 17:57:12 --> Language Class Initialized
INFO - 2023-06-26 17:57:12 --> Loader Class Initialized
INFO - 2023-06-26 17:57:12 --> Helper loaded: url_helper
INFO - 2023-06-26 17:57:12 --> Helper loaded: file_helper
INFO - 2023-06-26 17:57:12 --> Helper loaded: html_helper
INFO - 2023-06-26 17:57:12 --> Helper loaded: text_helper
INFO - 2023-06-26 17:57:12 --> Helper loaded: form_helper
INFO - 2023-06-26 17:57:12 --> Helper loaded: lang_helper
INFO - 2023-06-26 17:57:12 --> Helper loaded: security_helper
INFO - 2023-06-26 17:57:12 --> Helper loaded: cookie_helper
INFO - 2023-06-26 17:57:12 --> Database Driver Class Initialized
INFO - 2023-06-26 17:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 17:57:12 --> Parser Class Initialized
INFO - 2023-06-26 17:57:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-26 17:57:12 --> Pagination Class Initialized
INFO - 2023-06-26 17:57:12 --> Form Validation Class Initialized
INFO - 2023-06-26 17:57:12 --> Controller Class Initialized
DEBUG - 2023-06-26 17:57:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 17:57:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:57:12 --> Model Class Initialized
DEBUG - 2023-06-26 17:57:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 17:57:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 17:57:12 --> Ltarget class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:57:12 --> Model Class Initialized
DEBUG - 2023-06-26 17:57:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 17:57:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:57:12 --> Model Class Initialized
DEBUG - 2023-06-26 17:57:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:57:12 --> Model Class Initialized
INFO - 2023-06-26 17:57:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/target/target.php
DEBUG - 2023-06-26 17:57:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:57:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-26 17:57:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-26 17:57:12 --> Model Class Initialized
INFO - 2023-06-26 17:57:12 --> Model Class Initialized
INFO - 2023-06-26 17:57:12 --> Model Class Initialized
INFO - 2023-06-26 17:57:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-26 17:57:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-26 17:57:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-26 17:57:12 --> Final output sent to browser
DEBUG - 2023-06-26 17:57:12 --> Total execution time: 0.0743
ERROR - 2023-06-26 17:57:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-26 17:57:13 --> Config Class Initialized
INFO - 2023-06-26 17:57:13 --> Hooks Class Initialized
DEBUG - 2023-06-26 17:57:13 --> UTF-8 Support Enabled
INFO - 2023-06-26 17:57:13 --> Utf8 Class Initialized
INFO - 2023-06-26 17:57:13 --> URI Class Initialized
INFO - 2023-06-26 17:57:13 --> Router Class Initialized
INFO - 2023-06-26 17:57:13 --> Output Class Initialized
INFO - 2023-06-26 17:57:13 --> Security Class Initialized
DEBUG - 2023-06-26 17:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 17:57:13 --> Input Class Initialized
INFO - 2023-06-26 17:57:13 --> Language Class Initialized
INFO - 2023-06-26 17:57:13 --> Loader Class Initialized
INFO - 2023-06-26 17:57:13 --> Helper loaded: url_helper
INFO - 2023-06-26 17:57:13 --> Helper loaded: file_helper
INFO - 2023-06-26 17:57:13 --> Helper loaded: html_helper
INFO - 2023-06-26 17:57:13 --> Helper loaded: text_helper
INFO - 2023-06-26 17:57:13 --> Helper loaded: form_helper
INFO - 2023-06-26 17:57:13 --> Helper loaded: lang_helper
INFO - 2023-06-26 17:57:13 --> Helper loaded: security_helper
INFO - 2023-06-26 17:57:13 --> Helper loaded: cookie_helper
INFO - 2023-06-26 17:57:13 --> Database Driver Class Initialized
INFO - 2023-06-26 17:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 17:57:13 --> Parser Class Initialized
INFO - 2023-06-26 17:57:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-26 17:57:13 --> Pagination Class Initialized
INFO - 2023-06-26 17:57:13 --> Form Validation Class Initialized
INFO - 2023-06-26 17:57:13 --> Controller Class Initialized
DEBUG - 2023-06-26 17:57:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 17:57:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:57:13 --> Model Class Initialized
DEBUG - 2023-06-26 17:57:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 17:57:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:57:13 --> Model Class Initialized
DEBUG - 2023-06-26 17:57:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 17:57:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:57:13 --> Model Class Initialized
DEBUG - 2023-06-26 17:57:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:57:13 --> Model Class Initialized
INFO - 2023-06-26 17:57:13 --> Final output sent to browser
DEBUG - 2023-06-26 17:57:13 --> Total execution time: 0.0208
ERROR - 2023-06-26 17:57:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-26 17:57:31 --> Config Class Initialized
INFO - 2023-06-26 17:57:31 --> Hooks Class Initialized
DEBUG - 2023-06-26 17:57:31 --> UTF-8 Support Enabled
INFO - 2023-06-26 17:57:31 --> Utf8 Class Initialized
INFO - 2023-06-26 17:57:31 --> URI Class Initialized
INFO - 2023-06-26 17:57:31 --> Router Class Initialized
INFO - 2023-06-26 17:57:31 --> Output Class Initialized
INFO - 2023-06-26 17:57:31 --> Security Class Initialized
DEBUG - 2023-06-26 17:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 17:57:31 --> Input Class Initialized
INFO - 2023-06-26 17:57:31 --> Language Class Initialized
INFO - 2023-06-26 17:57:31 --> Loader Class Initialized
INFO - 2023-06-26 17:57:31 --> Helper loaded: url_helper
INFO - 2023-06-26 17:57:31 --> Helper loaded: file_helper
INFO - 2023-06-26 17:57:31 --> Helper loaded: html_helper
INFO - 2023-06-26 17:57:31 --> Helper loaded: text_helper
INFO - 2023-06-26 17:57:31 --> Helper loaded: form_helper
INFO - 2023-06-26 17:57:31 --> Helper loaded: lang_helper
INFO - 2023-06-26 17:57:31 --> Helper loaded: security_helper
INFO - 2023-06-26 17:57:31 --> Helper loaded: cookie_helper
INFO - 2023-06-26 17:57:31 --> Database Driver Class Initialized
INFO - 2023-06-26 17:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 17:57:31 --> Parser Class Initialized
INFO - 2023-06-26 17:57:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-26 17:57:31 --> Pagination Class Initialized
INFO - 2023-06-26 17:57:31 --> Form Validation Class Initialized
INFO - 2023-06-26 17:57:31 --> Controller Class Initialized
INFO - 2023-06-26 17:57:31 --> Model Class Initialized
DEBUG - 2023-06-26 17:57:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 17:57:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:57:31 --> Model Class Initialized
DEBUG - 2023-06-26 17:57:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:57:31 --> Model Class Initialized
INFO - 2023-06-26 17:57:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-06-26 17:57:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:57:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-26 17:57:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-26 17:57:31 --> Model Class Initialized
INFO - 2023-06-26 17:57:31 --> Model Class Initialized
INFO - 2023-06-26 17:57:31 --> Model Class Initialized
INFO - 2023-06-26 17:57:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-26 17:57:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-26 17:57:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-26 17:57:31 --> Final output sent to browser
DEBUG - 2023-06-26 17:57:31 --> Total execution time: 0.0761
ERROR - 2023-06-26 17:57:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-26 17:57:32 --> Config Class Initialized
INFO - 2023-06-26 17:57:32 --> Hooks Class Initialized
DEBUG - 2023-06-26 17:57:32 --> UTF-8 Support Enabled
INFO - 2023-06-26 17:57:32 --> Utf8 Class Initialized
INFO - 2023-06-26 17:57:32 --> URI Class Initialized
INFO - 2023-06-26 17:57:32 --> Router Class Initialized
INFO - 2023-06-26 17:57:32 --> Output Class Initialized
INFO - 2023-06-26 17:57:32 --> Security Class Initialized
DEBUG - 2023-06-26 17:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 17:57:32 --> Input Class Initialized
INFO - 2023-06-26 17:57:32 --> Language Class Initialized
INFO - 2023-06-26 17:57:32 --> Loader Class Initialized
INFO - 2023-06-26 17:57:32 --> Helper loaded: url_helper
INFO - 2023-06-26 17:57:32 --> Helper loaded: file_helper
INFO - 2023-06-26 17:57:32 --> Helper loaded: html_helper
INFO - 2023-06-26 17:57:32 --> Helper loaded: text_helper
INFO - 2023-06-26 17:57:32 --> Helper loaded: form_helper
INFO - 2023-06-26 17:57:32 --> Helper loaded: lang_helper
INFO - 2023-06-26 17:57:32 --> Helper loaded: security_helper
INFO - 2023-06-26 17:57:32 --> Helper loaded: cookie_helper
INFO - 2023-06-26 17:57:32 --> Database Driver Class Initialized
INFO - 2023-06-26 17:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 17:57:32 --> Parser Class Initialized
INFO - 2023-06-26 17:57:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-26 17:57:32 --> Pagination Class Initialized
INFO - 2023-06-26 17:57:32 --> Form Validation Class Initialized
INFO - 2023-06-26 17:57:32 --> Controller Class Initialized
INFO - 2023-06-26 17:57:32 --> Model Class Initialized
DEBUG - 2023-06-26 17:57:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 17:57:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:57:32 --> Model Class Initialized
DEBUG - 2023-06-26 17:57:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:57:32 --> Model Class Initialized
INFO - 2023-06-26 17:57:32 --> Final output sent to browser
DEBUG - 2023-06-26 17:57:32 --> Total execution time: 0.0547
ERROR - 2023-06-26 17:57:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-26 17:57:37 --> Config Class Initialized
INFO - 2023-06-26 17:57:37 --> Hooks Class Initialized
DEBUG - 2023-06-26 17:57:37 --> UTF-8 Support Enabled
INFO - 2023-06-26 17:57:37 --> Utf8 Class Initialized
INFO - 2023-06-26 17:57:37 --> URI Class Initialized
INFO - 2023-06-26 17:57:37 --> Router Class Initialized
INFO - 2023-06-26 17:57:37 --> Output Class Initialized
INFO - 2023-06-26 17:57:37 --> Security Class Initialized
DEBUG - 2023-06-26 17:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 17:57:37 --> Input Class Initialized
INFO - 2023-06-26 17:57:37 --> Language Class Initialized
INFO - 2023-06-26 17:57:37 --> Loader Class Initialized
INFO - 2023-06-26 17:57:37 --> Helper loaded: url_helper
INFO - 2023-06-26 17:57:37 --> Helper loaded: file_helper
INFO - 2023-06-26 17:57:37 --> Helper loaded: html_helper
INFO - 2023-06-26 17:57:37 --> Helper loaded: text_helper
INFO - 2023-06-26 17:57:37 --> Helper loaded: form_helper
INFO - 2023-06-26 17:57:37 --> Helper loaded: lang_helper
INFO - 2023-06-26 17:57:37 --> Helper loaded: security_helper
INFO - 2023-06-26 17:57:37 --> Helper loaded: cookie_helper
INFO - 2023-06-26 17:57:37 --> Database Driver Class Initialized
INFO - 2023-06-26 17:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 17:57:37 --> Parser Class Initialized
INFO - 2023-06-26 17:57:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-26 17:57:37 --> Pagination Class Initialized
INFO - 2023-06-26 17:57:37 --> Form Validation Class Initialized
INFO - 2023-06-26 17:57:37 --> Controller Class Initialized
DEBUG - 2023-06-26 17:57:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 17:57:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:57:37 --> Model Class Initialized
DEBUG - 2023-06-26 17:57:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 17:57:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 17:57:37 --> Ltarget class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:57:37 --> Model Class Initialized
DEBUG - 2023-06-26 17:57:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 17:57:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:57:37 --> Model Class Initialized
DEBUG - 2023-06-26 17:57:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:57:37 --> Model Class Initialized
INFO - 2023-06-26 17:57:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/target/target.php
DEBUG - 2023-06-26 17:57:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:57:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-26 17:57:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-26 17:57:37 --> Model Class Initialized
INFO - 2023-06-26 17:57:37 --> Model Class Initialized
INFO - 2023-06-26 17:57:37 --> Model Class Initialized
INFO - 2023-06-26 17:57:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-26 17:57:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-26 17:57:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-26 17:57:37 --> Final output sent to browser
DEBUG - 2023-06-26 17:57:37 --> Total execution time: 0.0702
ERROR - 2023-06-26 17:57:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-26 17:57:38 --> Config Class Initialized
INFO - 2023-06-26 17:57:38 --> Hooks Class Initialized
DEBUG - 2023-06-26 17:57:38 --> UTF-8 Support Enabled
INFO - 2023-06-26 17:57:38 --> Utf8 Class Initialized
INFO - 2023-06-26 17:57:38 --> URI Class Initialized
INFO - 2023-06-26 17:57:38 --> Router Class Initialized
INFO - 2023-06-26 17:57:38 --> Output Class Initialized
INFO - 2023-06-26 17:57:38 --> Security Class Initialized
DEBUG - 2023-06-26 17:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 17:57:38 --> Input Class Initialized
INFO - 2023-06-26 17:57:38 --> Language Class Initialized
INFO - 2023-06-26 17:57:38 --> Loader Class Initialized
INFO - 2023-06-26 17:57:38 --> Helper loaded: url_helper
INFO - 2023-06-26 17:57:38 --> Helper loaded: file_helper
INFO - 2023-06-26 17:57:38 --> Helper loaded: html_helper
INFO - 2023-06-26 17:57:38 --> Helper loaded: text_helper
INFO - 2023-06-26 17:57:38 --> Helper loaded: form_helper
INFO - 2023-06-26 17:57:38 --> Helper loaded: lang_helper
INFO - 2023-06-26 17:57:38 --> Helper loaded: security_helper
INFO - 2023-06-26 17:57:38 --> Helper loaded: cookie_helper
INFO - 2023-06-26 17:57:38 --> Database Driver Class Initialized
INFO - 2023-06-26 17:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 17:57:38 --> Parser Class Initialized
INFO - 2023-06-26 17:57:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-26 17:57:38 --> Pagination Class Initialized
INFO - 2023-06-26 17:57:38 --> Form Validation Class Initialized
INFO - 2023-06-26 17:57:38 --> Controller Class Initialized
DEBUG - 2023-06-26 17:57:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 17:57:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:57:38 --> Model Class Initialized
DEBUG - 2023-06-26 17:57:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 17:57:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:57:38 --> Model Class Initialized
DEBUG - 2023-06-26 17:57:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 17:57:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:57:38 --> Model Class Initialized
DEBUG - 2023-06-26 17:57:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:57:38 --> Model Class Initialized
INFO - 2023-06-26 17:57:38 --> Final output sent to browser
DEBUG - 2023-06-26 17:57:38 --> Total execution time: 0.0198
ERROR - 2023-06-26 17:59:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-26 17:59:02 --> Config Class Initialized
INFO - 2023-06-26 17:59:02 --> Hooks Class Initialized
DEBUG - 2023-06-26 17:59:02 --> UTF-8 Support Enabled
INFO - 2023-06-26 17:59:02 --> Utf8 Class Initialized
INFO - 2023-06-26 17:59:02 --> URI Class Initialized
DEBUG - 2023-06-26 17:59:02 --> No URI present. Default controller set.
INFO - 2023-06-26 17:59:02 --> Router Class Initialized
INFO - 2023-06-26 17:59:02 --> Output Class Initialized
INFO - 2023-06-26 17:59:02 --> Security Class Initialized
DEBUG - 2023-06-26 17:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 17:59:02 --> Input Class Initialized
INFO - 2023-06-26 17:59:02 --> Language Class Initialized
INFO - 2023-06-26 17:59:02 --> Loader Class Initialized
INFO - 2023-06-26 17:59:02 --> Helper loaded: url_helper
INFO - 2023-06-26 17:59:02 --> Helper loaded: file_helper
INFO - 2023-06-26 17:59:02 --> Helper loaded: html_helper
INFO - 2023-06-26 17:59:02 --> Helper loaded: text_helper
INFO - 2023-06-26 17:59:02 --> Helper loaded: form_helper
INFO - 2023-06-26 17:59:02 --> Helper loaded: lang_helper
INFO - 2023-06-26 17:59:02 --> Helper loaded: security_helper
INFO - 2023-06-26 17:59:02 --> Helper loaded: cookie_helper
INFO - 2023-06-26 17:59:02 --> Database Driver Class Initialized
INFO - 2023-06-26 17:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 17:59:02 --> Parser Class Initialized
INFO - 2023-06-26 17:59:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-26 17:59:02 --> Pagination Class Initialized
INFO - 2023-06-26 17:59:02 --> Form Validation Class Initialized
INFO - 2023-06-26 17:59:02 --> Controller Class Initialized
INFO - 2023-06-26 17:59:02 --> Model Class Initialized
DEBUG - 2023-06-26 17:59:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:59:02 --> Model Class Initialized
DEBUG - 2023-06-26 17:59:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:59:02 --> Model Class Initialized
INFO - 2023-06-26 17:59:02 --> Model Class Initialized
INFO - 2023-06-26 17:59:02 --> Model Class Initialized
INFO - 2023-06-26 17:59:02 --> Model Class Initialized
DEBUG - 2023-06-26 17:59:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 17:59:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:59:02 --> Model Class Initialized
INFO - 2023-06-26 17:59:02 --> Model Class Initialized
INFO - 2023-06-26 17:59:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-26 17:59:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-26 17:59:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-26 17:59:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-26 17:59:02 --> Model Class Initialized
INFO - 2023-06-26 17:59:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-26 17:59:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-26 17:59:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-26 17:59:02 --> Final output sent to browser
DEBUG - 2023-06-26 17:59:02 --> Total execution time: 0.0769
ERROR - 2023-06-26 18:15:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-26 18:15:58 --> Config Class Initialized
INFO - 2023-06-26 18:15:58 --> Hooks Class Initialized
DEBUG - 2023-06-26 18:15:58 --> UTF-8 Support Enabled
INFO - 2023-06-26 18:15:58 --> Utf8 Class Initialized
INFO - 2023-06-26 18:15:58 --> URI Class Initialized
DEBUG - 2023-06-26 18:15:58 --> No URI present. Default controller set.
INFO - 2023-06-26 18:15:58 --> Router Class Initialized
INFO - 2023-06-26 18:15:58 --> Output Class Initialized
INFO - 2023-06-26 18:15:58 --> Security Class Initialized
DEBUG - 2023-06-26 18:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 18:15:58 --> Input Class Initialized
INFO - 2023-06-26 18:15:58 --> Language Class Initialized
INFO - 2023-06-26 18:15:58 --> Loader Class Initialized
INFO - 2023-06-26 18:15:58 --> Helper loaded: url_helper
INFO - 2023-06-26 18:15:58 --> Helper loaded: file_helper
INFO - 2023-06-26 18:15:58 --> Helper loaded: html_helper
INFO - 2023-06-26 18:15:58 --> Helper loaded: text_helper
INFO - 2023-06-26 18:15:58 --> Helper loaded: form_helper
INFO - 2023-06-26 18:15:58 --> Helper loaded: lang_helper
INFO - 2023-06-26 18:15:58 --> Helper loaded: security_helper
INFO - 2023-06-26 18:15:58 --> Helper loaded: cookie_helper
INFO - 2023-06-26 18:15:58 --> Database Driver Class Initialized
INFO - 2023-06-26 18:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 18:15:58 --> Parser Class Initialized
INFO - 2023-06-26 18:15:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-26 18:15:58 --> Pagination Class Initialized
INFO - 2023-06-26 18:15:58 --> Form Validation Class Initialized
INFO - 2023-06-26 18:15:58 --> Controller Class Initialized
INFO - 2023-06-26 18:15:58 --> Model Class Initialized
DEBUG - 2023-06-26 18:15:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 18:15:58 --> Model Class Initialized
DEBUG - 2023-06-26 18:15:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 18:15:58 --> Model Class Initialized
INFO - 2023-06-26 18:15:58 --> Model Class Initialized
INFO - 2023-06-26 18:15:58 --> Model Class Initialized
INFO - 2023-06-26 18:15:58 --> Model Class Initialized
DEBUG - 2023-06-26 18:15:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 18:15:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 18:15:58 --> Model Class Initialized
INFO - 2023-06-26 18:15:58 --> Model Class Initialized
INFO - 2023-06-26 18:15:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-26 18:15:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-26 18:15:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-26 18:15:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-26 18:15:58 --> Model Class Initialized
INFO - 2023-06-26 18:15:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-26 18:15:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-26 18:15:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-26 18:15:58 --> Final output sent to browser
DEBUG - 2023-06-26 18:15:58 --> Total execution time: 0.0759
ERROR - 2023-06-26 18:16:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-26 18:16:19 --> Config Class Initialized
INFO - 2023-06-26 18:16:19 --> Hooks Class Initialized
DEBUG - 2023-06-26 18:16:19 --> UTF-8 Support Enabled
INFO - 2023-06-26 18:16:19 --> Utf8 Class Initialized
INFO - 2023-06-26 18:16:19 --> URI Class Initialized
INFO - 2023-06-26 18:16:19 --> Router Class Initialized
INFO - 2023-06-26 18:16:19 --> Output Class Initialized
INFO - 2023-06-26 18:16:19 --> Security Class Initialized
DEBUG - 2023-06-26 18:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 18:16:19 --> Input Class Initialized
INFO - 2023-06-26 18:16:19 --> Language Class Initialized
INFO - 2023-06-26 18:16:19 --> Loader Class Initialized
INFO - 2023-06-26 18:16:19 --> Helper loaded: url_helper
INFO - 2023-06-26 18:16:19 --> Helper loaded: file_helper
INFO - 2023-06-26 18:16:19 --> Helper loaded: html_helper
INFO - 2023-06-26 18:16:19 --> Helper loaded: text_helper
INFO - 2023-06-26 18:16:19 --> Helper loaded: form_helper
INFO - 2023-06-26 18:16:19 --> Helper loaded: lang_helper
INFO - 2023-06-26 18:16:19 --> Helper loaded: security_helper
INFO - 2023-06-26 18:16:19 --> Helper loaded: cookie_helper
INFO - 2023-06-26 18:16:19 --> Database Driver Class Initialized
INFO - 2023-06-26 18:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 18:16:19 --> Parser Class Initialized
INFO - 2023-06-26 18:16:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-26 18:16:19 --> Pagination Class Initialized
INFO - 2023-06-26 18:16:19 --> Form Validation Class Initialized
INFO - 2023-06-26 18:16:19 --> Controller Class Initialized
INFO - 2023-06-26 18:16:19 --> Model Class Initialized
DEBUG - 2023-06-26 18:16:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 18:16:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 18:16:19 --> Model Class Initialized
DEBUG - 2023-06-26 18:16:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 18:16:19 --> Model Class Initialized
INFO - 2023-06-26 18:16:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-26 18:16:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-26 18:16:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-26 18:16:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-26 18:16:19 --> Model Class Initialized
INFO - 2023-06-26 18:16:19 --> Model Class Initialized
INFO - 2023-06-26 18:16:19 --> Model Class Initialized
INFO - 2023-06-26 18:16:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-26 18:16:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-26 18:16:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-26 18:16:19 --> Final output sent to browser
DEBUG - 2023-06-26 18:16:19 --> Total execution time: 0.0693
ERROR - 2023-06-26 18:16:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-26 18:16:20 --> Config Class Initialized
INFO - 2023-06-26 18:16:20 --> Hooks Class Initialized
DEBUG - 2023-06-26 18:16:20 --> UTF-8 Support Enabled
INFO - 2023-06-26 18:16:20 --> Utf8 Class Initialized
INFO - 2023-06-26 18:16:20 --> URI Class Initialized
INFO - 2023-06-26 18:16:20 --> Router Class Initialized
INFO - 2023-06-26 18:16:20 --> Output Class Initialized
INFO - 2023-06-26 18:16:20 --> Security Class Initialized
DEBUG - 2023-06-26 18:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 18:16:20 --> Input Class Initialized
INFO - 2023-06-26 18:16:20 --> Language Class Initialized
INFO - 2023-06-26 18:16:20 --> Loader Class Initialized
INFO - 2023-06-26 18:16:20 --> Helper loaded: url_helper
INFO - 2023-06-26 18:16:20 --> Helper loaded: file_helper
INFO - 2023-06-26 18:16:20 --> Helper loaded: html_helper
INFO - 2023-06-26 18:16:20 --> Helper loaded: text_helper
INFO - 2023-06-26 18:16:20 --> Helper loaded: form_helper
INFO - 2023-06-26 18:16:20 --> Helper loaded: lang_helper
INFO - 2023-06-26 18:16:20 --> Helper loaded: security_helper
INFO - 2023-06-26 18:16:20 --> Helper loaded: cookie_helper
INFO - 2023-06-26 18:16:20 --> Database Driver Class Initialized
INFO - 2023-06-26 18:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 18:16:20 --> Parser Class Initialized
INFO - 2023-06-26 18:16:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-26 18:16:20 --> Pagination Class Initialized
INFO - 2023-06-26 18:16:20 --> Form Validation Class Initialized
INFO - 2023-06-26 18:16:20 --> Controller Class Initialized
INFO - 2023-06-26 18:16:20 --> Model Class Initialized
DEBUG - 2023-06-26 18:16:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 18:16:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 18:16:20 --> Model Class Initialized
DEBUG - 2023-06-26 18:16:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 18:16:20 --> Model Class Initialized
INFO - 2023-06-26 18:16:20 --> Final output sent to browser
DEBUG - 2023-06-26 18:16:20 --> Total execution time: 0.0355
ERROR - 2023-06-26 18:16:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-26 18:16:23 --> Config Class Initialized
INFO - 2023-06-26 18:16:23 --> Hooks Class Initialized
DEBUG - 2023-06-26 18:16:23 --> UTF-8 Support Enabled
INFO - 2023-06-26 18:16:23 --> Utf8 Class Initialized
INFO - 2023-06-26 18:16:23 --> URI Class Initialized
INFO - 2023-06-26 18:16:23 --> Router Class Initialized
INFO - 2023-06-26 18:16:23 --> Output Class Initialized
INFO - 2023-06-26 18:16:23 --> Security Class Initialized
DEBUG - 2023-06-26 18:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 18:16:23 --> Input Class Initialized
INFO - 2023-06-26 18:16:23 --> Language Class Initialized
INFO - 2023-06-26 18:16:23 --> Loader Class Initialized
INFO - 2023-06-26 18:16:23 --> Helper loaded: url_helper
INFO - 2023-06-26 18:16:23 --> Helper loaded: file_helper
INFO - 2023-06-26 18:16:23 --> Helper loaded: html_helper
INFO - 2023-06-26 18:16:23 --> Helper loaded: text_helper
INFO - 2023-06-26 18:16:23 --> Helper loaded: form_helper
INFO - 2023-06-26 18:16:23 --> Helper loaded: lang_helper
INFO - 2023-06-26 18:16:23 --> Helper loaded: security_helper
INFO - 2023-06-26 18:16:23 --> Helper loaded: cookie_helper
INFO - 2023-06-26 18:16:23 --> Database Driver Class Initialized
INFO - 2023-06-26 18:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 18:16:23 --> Parser Class Initialized
INFO - 2023-06-26 18:16:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-26 18:16:23 --> Pagination Class Initialized
INFO - 2023-06-26 18:16:23 --> Form Validation Class Initialized
INFO - 2023-06-26 18:16:23 --> Controller Class Initialized
INFO - 2023-06-26 18:16:23 --> Model Class Initialized
DEBUG - 2023-06-26 18:16:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 18:16:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 18:16:23 --> Model Class Initialized
DEBUG - 2023-06-26 18:16:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 18:16:23 --> Model Class Initialized
INFO - 2023-06-26 18:16:23 --> Final output sent to browser
DEBUG - 2023-06-26 18:16:23 --> Total execution time: 0.1095
ERROR - 2023-06-26 18:17:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-26 18:17:04 --> Config Class Initialized
INFO - 2023-06-26 18:17:04 --> Hooks Class Initialized
DEBUG - 2023-06-26 18:17:04 --> UTF-8 Support Enabled
INFO - 2023-06-26 18:17:04 --> Utf8 Class Initialized
INFO - 2023-06-26 18:17:04 --> URI Class Initialized
INFO - 2023-06-26 18:17:04 --> Router Class Initialized
INFO - 2023-06-26 18:17:04 --> Output Class Initialized
INFO - 2023-06-26 18:17:04 --> Security Class Initialized
DEBUG - 2023-06-26 18:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 18:17:04 --> Input Class Initialized
INFO - 2023-06-26 18:17:04 --> Language Class Initialized
INFO - 2023-06-26 18:17:04 --> Loader Class Initialized
INFO - 2023-06-26 18:17:04 --> Helper loaded: url_helper
INFO - 2023-06-26 18:17:04 --> Helper loaded: file_helper
INFO - 2023-06-26 18:17:04 --> Helper loaded: html_helper
INFO - 2023-06-26 18:17:04 --> Helper loaded: text_helper
INFO - 2023-06-26 18:17:04 --> Helper loaded: form_helper
INFO - 2023-06-26 18:17:04 --> Helper loaded: lang_helper
INFO - 2023-06-26 18:17:04 --> Helper loaded: security_helper
INFO - 2023-06-26 18:17:04 --> Helper loaded: cookie_helper
INFO - 2023-06-26 18:17:04 --> Database Driver Class Initialized
INFO - 2023-06-26 18:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 18:17:04 --> Parser Class Initialized
INFO - 2023-06-26 18:17:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-26 18:17:04 --> Pagination Class Initialized
INFO - 2023-06-26 18:17:04 --> Form Validation Class Initialized
INFO - 2023-06-26 18:17:05 --> Controller Class Initialized
INFO - 2023-06-26 18:17:05 --> Model Class Initialized
DEBUG - 2023-06-26 18:17:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 18:17:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 18:17:05 --> Model Class Initialized
DEBUG - 2023-06-26 18:17:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 18:17:05 --> Model Class Initialized
DEBUG - 2023-06-26 18:17:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 18:17:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-06-26 18:17:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-26 18:17:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-26 18:17:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-26 18:17:05 --> Model Class Initialized
INFO - 2023-06-26 18:17:05 --> Model Class Initialized
INFO - 2023-06-26 18:17:05 --> Model Class Initialized
INFO - 2023-06-26 18:17:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-26 18:17:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-26 18:17:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-26 18:17:05 --> Final output sent to browser
DEBUG - 2023-06-26 18:17:05 --> Total execution time: 0.0747
ERROR - 2023-06-26 18:17:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-26 18:17:16 --> Config Class Initialized
INFO - 2023-06-26 18:17:16 --> Hooks Class Initialized
DEBUG - 2023-06-26 18:17:16 --> UTF-8 Support Enabled
INFO - 2023-06-26 18:17:16 --> Utf8 Class Initialized
INFO - 2023-06-26 18:17:16 --> URI Class Initialized
INFO - 2023-06-26 18:17:16 --> Router Class Initialized
INFO - 2023-06-26 18:17:16 --> Output Class Initialized
INFO - 2023-06-26 18:17:16 --> Security Class Initialized
DEBUG - 2023-06-26 18:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 18:17:16 --> Input Class Initialized
INFO - 2023-06-26 18:17:16 --> Language Class Initialized
INFO - 2023-06-26 18:17:16 --> Loader Class Initialized
INFO - 2023-06-26 18:17:16 --> Helper loaded: url_helper
INFO - 2023-06-26 18:17:16 --> Helper loaded: file_helper
INFO - 2023-06-26 18:17:16 --> Helper loaded: html_helper
INFO - 2023-06-26 18:17:16 --> Helper loaded: text_helper
INFO - 2023-06-26 18:17:16 --> Helper loaded: form_helper
INFO - 2023-06-26 18:17:16 --> Helper loaded: lang_helper
INFO - 2023-06-26 18:17:16 --> Helper loaded: security_helper
INFO - 2023-06-26 18:17:16 --> Helper loaded: cookie_helper
INFO - 2023-06-26 18:17:16 --> Database Driver Class Initialized
INFO - 2023-06-26 18:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 18:17:16 --> Parser Class Initialized
INFO - 2023-06-26 18:17:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-26 18:17:16 --> Pagination Class Initialized
INFO - 2023-06-26 18:17:16 --> Form Validation Class Initialized
INFO - 2023-06-26 18:17:16 --> Controller Class Initialized
INFO - 2023-06-26 18:17:16 --> Model Class Initialized
DEBUG - 2023-06-26 18:17:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 18:17:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 18:17:16 --> Model Class Initialized
DEBUG - 2023-06-26 18:17:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 18:17:16 --> Model Class Initialized
INFO - 2023-06-26 18:17:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-26 18:17:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-26 18:17:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-26 18:17:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-26 18:17:16 --> Model Class Initialized
INFO - 2023-06-26 18:17:16 --> Model Class Initialized
INFO - 2023-06-26 18:17:16 --> Model Class Initialized
INFO - 2023-06-26 18:17:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-26 18:17:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-26 18:17:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-26 18:17:16 --> Final output sent to browser
DEBUG - 2023-06-26 18:17:16 --> Total execution time: 0.0651
ERROR - 2023-06-26 18:17:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-26 18:17:17 --> Config Class Initialized
INFO - 2023-06-26 18:17:17 --> Hooks Class Initialized
DEBUG - 2023-06-26 18:17:17 --> UTF-8 Support Enabled
INFO - 2023-06-26 18:17:17 --> Utf8 Class Initialized
INFO - 2023-06-26 18:17:17 --> URI Class Initialized
INFO - 2023-06-26 18:17:17 --> Router Class Initialized
INFO - 2023-06-26 18:17:17 --> Output Class Initialized
INFO - 2023-06-26 18:17:17 --> Security Class Initialized
DEBUG - 2023-06-26 18:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 18:17:17 --> Input Class Initialized
INFO - 2023-06-26 18:17:17 --> Language Class Initialized
INFO - 2023-06-26 18:17:17 --> Loader Class Initialized
INFO - 2023-06-26 18:17:17 --> Helper loaded: url_helper
INFO - 2023-06-26 18:17:17 --> Helper loaded: file_helper
INFO - 2023-06-26 18:17:17 --> Helper loaded: html_helper
INFO - 2023-06-26 18:17:17 --> Helper loaded: text_helper
INFO - 2023-06-26 18:17:17 --> Helper loaded: form_helper
INFO - 2023-06-26 18:17:17 --> Helper loaded: lang_helper
INFO - 2023-06-26 18:17:17 --> Helper loaded: security_helper
INFO - 2023-06-26 18:17:17 --> Helper loaded: cookie_helper
INFO - 2023-06-26 18:17:17 --> Database Driver Class Initialized
INFO - 2023-06-26 18:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 18:17:17 --> Parser Class Initialized
INFO - 2023-06-26 18:17:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-26 18:17:17 --> Pagination Class Initialized
INFO - 2023-06-26 18:17:17 --> Form Validation Class Initialized
INFO - 2023-06-26 18:17:17 --> Controller Class Initialized
INFO - 2023-06-26 18:17:17 --> Model Class Initialized
DEBUG - 2023-06-26 18:17:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 18:17:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 18:17:17 --> Model Class Initialized
DEBUG - 2023-06-26 18:17:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 18:17:17 --> Model Class Initialized
INFO - 2023-06-26 18:17:17 --> Final output sent to browser
DEBUG - 2023-06-26 18:17:17 --> Total execution time: 0.0358
ERROR - 2023-06-26 18:17:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-26 18:17:20 --> Config Class Initialized
INFO - 2023-06-26 18:17:20 --> Hooks Class Initialized
DEBUG - 2023-06-26 18:17:20 --> UTF-8 Support Enabled
INFO - 2023-06-26 18:17:20 --> Utf8 Class Initialized
INFO - 2023-06-26 18:17:20 --> URI Class Initialized
INFO - 2023-06-26 18:17:20 --> Router Class Initialized
INFO - 2023-06-26 18:17:20 --> Output Class Initialized
INFO - 2023-06-26 18:17:20 --> Security Class Initialized
DEBUG - 2023-06-26 18:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 18:17:20 --> Input Class Initialized
INFO - 2023-06-26 18:17:20 --> Language Class Initialized
INFO - 2023-06-26 18:17:20 --> Loader Class Initialized
INFO - 2023-06-26 18:17:20 --> Helper loaded: url_helper
INFO - 2023-06-26 18:17:20 --> Helper loaded: file_helper
INFO - 2023-06-26 18:17:20 --> Helper loaded: html_helper
INFO - 2023-06-26 18:17:20 --> Helper loaded: text_helper
INFO - 2023-06-26 18:17:20 --> Helper loaded: form_helper
INFO - 2023-06-26 18:17:20 --> Helper loaded: lang_helper
INFO - 2023-06-26 18:17:20 --> Helper loaded: security_helper
INFO - 2023-06-26 18:17:20 --> Helper loaded: cookie_helper
INFO - 2023-06-26 18:17:20 --> Database Driver Class Initialized
INFO - 2023-06-26 18:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 18:17:20 --> Parser Class Initialized
INFO - 2023-06-26 18:17:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-26 18:17:20 --> Pagination Class Initialized
INFO - 2023-06-26 18:17:20 --> Form Validation Class Initialized
INFO - 2023-06-26 18:17:20 --> Controller Class Initialized
INFO - 2023-06-26 18:17:20 --> Model Class Initialized
DEBUG - 2023-06-26 18:17:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 18:17:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 18:17:20 --> Model Class Initialized
DEBUG - 2023-06-26 18:17:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 18:17:20 --> Model Class Initialized
INFO - 2023-06-26 18:17:20 --> Final output sent to browser
DEBUG - 2023-06-26 18:17:20 --> Total execution time: 0.1084
ERROR - 2023-06-26 18:17:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-26 18:17:47 --> Config Class Initialized
INFO - 2023-06-26 18:17:47 --> Hooks Class Initialized
DEBUG - 2023-06-26 18:17:47 --> UTF-8 Support Enabled
INFO - 2023-06-26 18:17:47 --> Utf8 Class Initialized
INFO - 2023-06-26 18:17:47 --> URI Class Initialized
INFO - 2023-06-26 18:17:47 --> Router Class Initialized
INFO - 2023-06-26 18:17:47 --> Output Class Initialized
INFO - 2023-06-26 18:17:47 --> Security Class Initialized
DEBUG - 2023-06-26 18:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 18:17:47 --> Input Class Initialized
INFO - 2023-06-26 18:17:47 --> Language Class Initialized
INFO - 2023-06-26 18:17:47 --> Loader Class Initialized
INFO - 2023-06-26 18:17:47 --> Helper loaded: url_helper
INFO - 2023-06-26 18:17:47 --> Helper loaded: file_helper
INFO - 2023-06-26 18:17:47 --> Helper loaded: html_helper
INFO - 2023-06-26 18:17:47 --> Helper loaded: text_helper
INFO - 2023-06-26 18:17:47 --> Helper loaded: form_helper
INFO - 2023-06-26 18:17:47 --> Helper loaded: lang_helper
INFO - 2023-06-26 18:17:47 --> Helper loaded: security_helper
INFO - 2023-06-26 18:17:47 --> Helper loaded: cookie_helper
INFO - 2023-06-26 18:17:47 --> Database Driver Class Initialized
INFO - 2023-06-26 18:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 18:17:47 --> Parser Class Initialized
INFO - 2023-06-26 18:17:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-26 18:17:47 --> Pagination Class Initialized
INFO - 2023-06-26 18:17:47 --> Form Validation Class Initialized
INFO - 2023-06-26 18:17:47 --> Controller Class Initialized
INFO - 2023-06-26 18:17:47 --> Model Class Initialized
DEBUG - 2023-06-26 18:17:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 18:17:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 18:17:47 --> Model Class Initialized
DEBUG - 2023-06-26 18:17:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 18:17:47 --> Model Class Initialized
DEBUG - 2023-06-26 18:17:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 18:17:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-06-26 18:17:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-26 18:17:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-26 18:17:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-26 18:17:47 --> Model Class Initialized
INFO - 2023-06-26 18:17:47 --> Model Class Initialized
INFO - 2023-06-26 18:17:47 --> Model Class Initialized
INFO - 2023-06-26 18:17:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-26 18:17:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-26 18:17:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-26 18:17:47 --> Final output sent to browser
DEBUG - 2023-06-26 18:17:47 --> Total execution time: 0.0726
ERROR - 2023-06-26 18:19:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-26 18:19:02 --> Config Class Initialized
INFO - 2023-06-26 18:19:02 --> Hooks Class Initialized
DEBUG - 2023-06-26 18:19:02 --> UTF-8 Support Enabled
INFO - 2023-06-26 18:19:02 --> Utf8 Class Initialized
INFO - 2023-06-26 18:19:02 --> URI Class Initialized
INFO - 2023-06-26 18:19:02 --> Router Class Initialized
INFO - 2023-06-26 18:19:02 --> Output Class Initialized
INFO - 2023-06-26 18:19:02 --> Security Class Initialized
DEBUG - 2023-06-26 18:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 18:19:02 --> Input Class Initialized
INFO - 2023-06-26 18:19:02 --> Language Class Initialized
INFO - 2023-06-26 18:19:02 --> Loader Class Initialized
INFO - 2023-06-26 18:19:02 --> Helper loaded: url_helper
INFO - 2023-06-26 18:19:02 --> Helper loaded: file_helper
INFO - 2023-06-26 18:19:02 --> Helper loaded: html_helper
INFO - 2023-06-26 18:19:02 --> Helper loaded: text_helper
INFO - 2023-06-26 18:19:02 --> Helper loaded: form_helper
INFO - 2023-06-26 18:19:02 --> Helper loaded: lang_helper
INFO - 2023-06-26 18:19:02 --> Helper loaded: security_helper
INFO - 2023-06-26 18:19:02 --> Helper loaded: cookie_helper
INFO - 2023-06-26 18:19:02 --> Database Driver Class Initialized
INFO - 2023-06-26 18:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 18:19:02 --> Parser Class Initialized
INFO - 2023-06-26 18:19:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-26 18:19:02 --> Pagination Class Initialized
INFO - 2023-06-26 18:19:02 --> Form Validation Class Initialized
INFO - 2023-06-26 18:19:02 --> Controller Class Initialized
INFO - 2023-06-26 18:19:02 --> Model Class Initialized
DEBUG - 2023-06-26 18:19:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 18:19:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 18:19:02 --> Model Class Initialized
INFO - 2023-06-26 18:19:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-06-26 18:19:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-26 18:19:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-26 18:19:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-26 18:19:02 --> Model Class Initialized
INFO - 2023-06-26 18:19:02 --> Model Class Initialized
INFO - 2023-06-26 18:19:02 --> Model Class Initialized
INFO - 2023-06-26 18:19:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-26 18:19:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-26 18:19:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-26 18:19:02 --> Final output sent to browser
DEBUG - 2023-06-26 18:19:02 --> Total execution time: 0.0643
ERROR - 2023-06-26 18:19:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-26 18:19:02 --> Config Class Initialized
INFO - 2023-06-26 18:19:02 --> Hooks Class Initialized
DEBUG - 2023-06-26 18:19:02 --> UTF-8 Support Enabled
INFO - 2023-06-26 18:19:02 --> Utf8 Class Initialized
INFO - 2023-06-26 18:19:02 --> URI Class Initialized
INFO - 2023-06-26 18:19:02 --> Router Class Initialized
INFO - 2023-06-26 18:19:02 --> Output Class Initialized
INFO - 2023-06-26 18:19:02 --> Security Class Initialized
DEBUG - 2023-06-26 18:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 18:19:02 --> Input Class Initialized
INFO - 2023-06-26 18:19:02 --> Language Class Initialized
INFO - 2023-06-26 18:19:02 --> Loader Class Initialized
INFO - 2023-06-26 18:19:02 --> Helper loaded: url_helper
INFO - 2023-06-26 18:19:02 --> Helper loaded: file_helper
INFO - 2023-06-26 18:19:02 --> Helper loaded: html_helper
INFO - 2023-06-26 18:19:02 --> Helper loaded: text_helper
INFO - 2023-06-26 18:19:02 --> Helper loaded: form_helper
INFO - 2023-06-26 18:19:02 --> Helper loaded: lang_helper
INFO - 2023-06-26 18:19:02 --> Helper loaded: security_helper
INFO - 2023-06-26 18:19:02 --> Helper loaded: cookie_helper
INFO - 2023-06-26 18:19:02 --> Database Driver Class Initialized
INFO - 2023-06-26 18:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 18:19:02 --> Parser Class Initialized
INFO - 2023-06-26 18:19:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-26 18:19:02 --> Pagination Class Initialized
INFO - 2023-06-26 18:19:02 --> Form Validation Class Initialized
INFO - 2023-06-26 18:19:02 --> Controller Class Initialized
INFO - 2023-06-26 18:19:02 --> Model Class Initialized
DEBUG - 2023-06-26 18:19:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 18:19:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 18:19:02 --> Model Class Initialized
INFO - 2023-06-26 18:19:02 --> Final output sent to browser
DEBUG - 2023-06-26 18:19:02 --> Total execution time: 0.0273
ERROR - 2023-06-26 18:20:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-26 18:20:50 --> Config Class Initialized
INFO - 2023-06-26 18:20:50 --> Hooks Class Initialized
DEBUG - 2023-06-26 18:20:50 --> UTF-8 Support Enabled
INFO - 2023-06-26 18:20:50 --> Utf8 Class Initialized
INFO - 2023-06-26 18:20:50 --> URI Class Initialized
DEBUG - 2023-06-26 18:20:50 --> No URI present. Default controller set.
INFO - 2023-06-26 18:20:50 --> Router Class Initialized
INFO - 2023-06-26 18:20:50 --> Output Class Initialized
INFO - 2023-06-26 18:20:50 --> Security Class Initialized
DEBUG - 2023-06-26 18:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 18:20:50 --> Input Class Initialized
INFO - 2023-06-26 18:20:50 --> Language Class Initialized
INFO - 2023-06-26 18:20:50 --> Loader Class Initialized
INFO - 2023-06-26 18:20:50 --> Helper loaded: url_helper
INFO - 2023-06-26 18:20:50 --> Helper loaded: file_helper
INFO - 2023-06-26 18:20:50 --> Helper loaded: html_helper
INFO - 2023-06-26 18:20:50 --> Helper loaded: text_helper
INFO - 2023-06-26 18:20:50 --> Helper loaded: form_helper
INFO - 2023-06-26 18:20:50 --> Helper loaded: lang_helper
INFO - 2023-06-26 18:20:50 --> Helper loaded: security_helper
INFO - 2023-06-26 18:20:50 --> Helper loaded: cookie_helper
INFO - 2023-06-26 18:20:50 --> Database Driver Class Initialized
INFO - 2023-06-26 18:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 18:20:50 --> Parser Class Initialized
INFO - 2023-06-26 18:20:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-26 18:20:50 --> Pagination Class Initialized
INFO - 2023-06-26 18:20:50 --> Form Validation Class Initialized
INFO - 2023-06-26 18:20:50 --> Controller Class Initialized
INFO - 2023-06-26 18:20:50 --> Model Class Initialized
DEBUG - 2023-06-26 18:20:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 18:20:50 --> Model Class Initialized
DEBUG - 2023-06-26 18:20:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 18:20:50 --> Model Class Initialized
INFO - 2023-06-26 18:20:50 --> Model Class Initialized
INFO - 2023-06-26 18:20:50 --> Model Class Initialized
INFO - 2023-06-26 18:20:50 --> Model Class Initialized
DEBUG - 2023-06-26 18:20:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 18:20:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 18:20:50 --> Model Class Initialized
INFO - 2023-06-26 18:20:50 --> Model Class Initialized
INFO - 2023-06-26 18:20:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-26 18:20:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-26 18:20:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-26 18:20:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-26 18:20:51 --> Model Class Initialized
INFO - 2023-06-26 18:20:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-26 18:20:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-26 18:20:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-26 18:20:51 --> Final output sent to browser
DEBUG - 2023-06-26 18:20:51 --> Total execution time: 0.0765
ERROR - 2023-06-26 18:20:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-26 18:20:58 --> Config Class Initialized
INFO - 2023-06-26 18:20:58 --> Hooks Class Initialized
DEBUG - 2023-06-26 18:20:58 --> UTF-8 Support Enabled
INFO - 2023-06-26 18:20:58 --> Utf8 Class Initialized
INFO - 2023-06-26 18:20:58 --> URI Class Initialized
INFO - 2023-06-26 18:20:58 --> Router Class Initialized
INFO - 2023-06-26 18:20:58 --> Output Class Initialized
INFO - 2023-06-26 18:20:58 --> Security Class Initialized
DEBUG - 2023-06-26 18:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 18:20:58 --> Input Class Initialized
INFO - 2023-06-26 18:20:58 --> Language Class Initialized
INFO - 2023-06-26 18:20:58 --> Loader Class Initialized
INFO - 2023-06-26 18:20:58 --> Helper loaded: url_helper
INFO - 2023-06-26 18:20:58 --> Helper loaded: file_helper
INFO - 2023-06-26 18:20:58 --> Helper loaded: html_helper
INFO - 2023-06-26 18:20:58 --> Helper loaded: text_helper
INFO - 2023-06-26 18:20:58 --> Helper loaded: form_helper
INFO - 2023-06-26 18:20:58 --> Helper loaded: lang_helper
INFO - 2023-06-26 18:20:58 --> Helper loaded: security_helper
INFO - 2023-06-26 18:20:58 --> Helper loaded: cookie_helper
INFO - 2023-06-26 18:20:58 --> Database Driver Class Initialized
INFO - 2023-06-26 18:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 18:20:58 --> Parser Class Initialized
INFO - 2023-06-26 18:20:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-26 18:20:58 --> Pagination Class Initialized
INFO - 2023-06-26 18:20:58 --> Form Validation Class Initialized
INFO - 2023-06-26 18:20:58 --> Controller Class Initialized
INFO - 2023-06-26 18:20:58 --> Model Class Initialized
DEBUG - 2023-06-26 18:20:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 18:20:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 18:20:58 --> Model Class Initialized
INFO - 2023-06-26 18:20:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-06-26 18:20:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-26 18:20:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-26 18:20:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-26 18:20:58 --> Model Class Initialized
INFO - 2023-06-26 18:20:58 --> Model Class Initialized
INFO - 2023-06-26 18:20:58 --> Model Class Initialized
INFO - 2023-06-26 18:20:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-26 18:20:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-26 18:20:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-26 18:20:58 --> Final output sent to browser
DEBUG - 2023-06-26 18:20:58 --> Total execution time: 0.0649
ERROR - 2023-06-26 18:20:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-26 18:20:58 --> Config Class Initialized
INFO - 2023-06-26 18:20:58 --> Hooks Class Initialized
DEBUG - 2023-06-26 18:20:58 --> UTF-8 Support Enabled
INFO - 2023-06-26 18:20:58 --> Utf8 Class Initialized
INFO - 2023-06-26 18:20:58 --> URI Class Initialized
INFO - 2023-06-26 18:20:58 --> Router Class Initialized
INFO - 2023-06-26 18:20:58 --> Output Class Initialized
INFO - 2023-06-26 18:20:58 --> Security Class Initialized
DEBUG - 2023-06-26 18:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 18:20:58 --> Input Class Initialized
INFO - 2023-06-26 18:20:58 --> Language Class Initialized
INFO - 2023-06-26 18:20:58 --> Loader Class Initialized
INFO - 2023-06-26 18:20:58 --> Helper loaded: url_helper
INFO - 2023-06-26 18:20:58 --> Helper loaded: file_helper
INFO - 2023-06-26 18:20:58 --> Helper loaded: html_helper
INFO - 2023-06-26 18:20:58 --> Helper loaded: text_helper
INFO - 2023-06-26 18:20:58 --> Helper loaded: form_helper
INFO - 2023-06-26 18:20:58 --> Helper loaded: lang_helper
INFO - 2023-06-26 18:20:58 --> Helper loaded: security_helper
INFO - 2023-06-26 18:20:58 --> Helper loaded: cookie_helper
INFO - 2023-06-26 18:20:58 --> Database Driver Class Initialized
INFO - 2023-06-26 18:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 18:20:58 --> Parser Class Initialized
INFO - 2023-06-26 18:20:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-26 18:20:58 --> Pagination Class Initialized
INFO - 2023-06-26 18:20:58 --> Form Validation Class Initialized
INFO - 2023-06-26 18:20:58 --> Controller Class Initialized
INFO - 2023-06-26 18:20:58 --> Model Class Initialized
DEBUG - 2023-06-26 18:20:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 18:20:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 18:20:58 --> Model Class Initialized
INFO - 2023-06-26 18:20:58 --> Final output sent to browser
DEBUG - 2023-06-26 18:20:58 --> Total execution time: 0.0257
ERROR - 2023-06-26 18:21:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-26 18:21:01 --> Config Class Initialized
INFO - 2023-06-26 18:21:01 --> Hooks Class Initialized
DEBUG - 2023-06-26 18:21:01 --> UTF-8 Support Enabled
INFO - 2023-06-26 18:21:01 --> Utf8 Class Initialized
INFO - 2023-06-26 18:21:01 --> URI Class Initialized
INFO - 2023-06-26 18:21:01 --> Router Class Initialized
INFO - 2023-06-26 18:21:01 --> Output Class Initialized
INFO - 2023-06-26 18:21:01 --> Security Class Initialized
DEBUG - 2023-06-26 18:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 18:21:01 --> Input Class Initialized
INFO - 2023-06-26 18:21:01 --> Language Class Initialized
INFO - 2023-06-26 18:21:01 --> Loader Class Initialized
INFO - 2023-06-26 18:21:01 --> Helper loaded: url_helper
INFO - 2023-06-26 18:21:01 --> Helper loaded: file_helper
INFO - 2023-06-26 18:21:01 --> Helper loaded: html_helper
INFO - 2023-06-26 18:21:01 --> Helper loaded: text_helper
INFO - 2023-06-26 18:21:01 --> Helper loaded: form_helper
INFO - 2023-06-26 18:21:01 --> Helper loaded: lang_helper
INFO - 2023-06-26 18:21:01 --> Helper loaded: security_helper
INFO - 2023-06-26 18:21:01 --> Helper loaded: cookie_helper
INFO - 2023-06-26 18:21:01 --> Database Driver Class Initialized
INFO - 2023-06-26 18:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 18:21:01 --> Parser Class Initialized
INFO - 2023-06-26 18:21:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-26 18:21:01 --> Pagination Class Initialized
INFO - 2023-06-26 18:21:01 --> Form Validation Class Initialized
INFO - 2023-06-26 18:21:01 --> Controller Class Initialized
INFO - 2023-06-26 18:21:01 --> Model Class Initialized
DEBUG - 2023-06-26 18:21:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-26 18:21:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-26 18:21:01 --> Model Class Initialized
INFO - 2023-06-26 18:21:01 --> Final output sent to browser
DEBUG - 2023-06-26 18:21:01 --> Total execution time: 0.0406
