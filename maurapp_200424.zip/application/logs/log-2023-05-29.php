<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-29 04:20:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 04:20:09 --> Config Class Initialized
INFO - 2023-05-29 04:20:09 --> Hooks Class Initialized
DEBUG - 2023-05-29 04:20:09 --> UTF-8 Support Enabled
INFO - 2023-05-29 04:20:09 --> Utf8 Class Initialized
INFO - 2023-05-29 04:20:09 --> URI Class Initialized
DEBUG - 2023-05-29 04:20:09 --> No URI present. Default controller set.
INFO - 2023-05-29 04:20:09 --> Router Class Initialized
INFO - 2023-05-29 04:20:09 --> Output Class Initialized
INFO - 2023-05-29 04:20:09 --> Security Class Initialized
DEBUG - 2023-05-29 04:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 04:20:09 --> Input Class Initialized
INFO - 2023-05-29 04:20:09 --> Language Class Initialized
INFO - 2023-05-29 04:20:09 --> Loader Class Initialized
INFO - 2023-05-29 04:20:09 --> Helper loaded: url_helper
INFO - 2023-05-29 04:20:09 --> Helper loaded: file_helper
INFO - 2023-05-29 04:20:09 --> Helper loaded: html_helper
INFO - 2023-05-29 04:20:09 --> Helper loaded: text_helper
INFO - 2023-05-29 04:20:09 --> Helper loaded: form_helper
INFO - 2023-05-29 04:20:09 --> Helper loaded: lang_helper
INFO - 2023-05-29 04:20:09 --> Helper loaded: security_helper
INFO - 2023-05-29 04:20:09 --> Helper loaded: cookie_helper
INFO - 2023-05-29 04:20:09 --> Database Driver Class Initialized
INFO - 2023-05-29 04:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 04:20:09 --> Parser Class Initialized
INFO - 2023-05-29 04:20:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 04:20:09 --> Pagination Class Initialized
INFO - 2023-05-29 04:20:09 --> Form Validation Class Initialized
INFO - 2023-05-29 04:20:09 --> Controller Class Initialized
INFO - 2023-05-29 04:20:09 --> Model Class Initialized
DEBUG - 2023-05-29 04:20:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-29 04:20:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 04:20:09 --> Config Class Initialized
INFO - 2023-05-29 04:20:09 --> Hooks Class Initialized
DEBUG - 2023-05-29 04:20:09 --> UTF-8 Support Enabled
INFO - 2023-05-29 04:20:09 --> Utf8 Class Initialized
INFO - 2023-05-29 04:20:09 --> URI Class Initialized
INFO - 2023-05-29 04:20:09 --> Router Class Initialized
INFO - 2023-05-29 04:20:09 --> Output Class Initialized
INFO - 2023-05-29 04:20:09 --> Security Class Initialized
DEBUG - 2023-05-29 04:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 04:20:09 --> Input Class Initialized
INFO - 2023-05-29 04:20:09 --> Language Class Initialized
INFO - 2023-05-29 04:20:09 --> Loader Class Initialized
INFO - 2023-05-29 04:20:09 --> Helper loaded: url_helper
INFO - 2023-05-29 04:20:09 --> Helper loaded: file_helper
INFO - 2023-05-29 04:20:09 --> Helper loaded: html_helper
INFO - 2023-05-29 04:20:09 --> Helper loaded: text_helper
INFO - 2023-05-29 04:20:09 --> Helper loaded: form_helper
INFO - 2023-05-29 04:20:09 --> Helper loaded: lang_helper
INFO - 2023-05-29 04:20:09 --> Helper loaded: security_helper
INFO - 2023-05-29 04:20:09 --> Helper loaded: cookie_helper
INFO - 2023-05-29 04:20:09 --> Database Driver Class Initialized
INFO - 2023-05-29 04:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 04:20:10 --> Parser Class Initialized
INFO - 2023-05-29 04:20:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 04:20:10 --> Pagination Class Initialized
INFO - 2023-05-29 04:20:10 --> Form Validation Class Initialized
INFO - 2023-05-29 04:20:10 --> Controller Class Initialized
INFO - 2023-05-29 04:20:10 --> Model Class Initialized
DEBUG - 2023-05-29 04:20:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 04:20:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-29 04:20:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 04:20:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 04:20:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 04:20:10 --> Model Class Initialized
INFO - 2023-05-29 04:20:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 04:20:10 --> Final output sent to browser
DEBUG - 2023-05-29 04:20:10 --> Total execution time: 0.0295
ERROR - 2023-05-29 04:20:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 04:20:29 --> Config Class Initialized
INFO - 2023-05-29 04:20:29 --> Hooks Class Initialized
DEBUG - 2023-05-29 04:20:29 --> UTF-8 Support Enabled
INFO - 2023-05-29 04:20:29 --> Utf8 Class Initialized
INFO - 2023-05-29 04:20:29 --> URI Class Initialized
INFO - 2023-05-29 04:20:29 --> Router Class Initialized
INFO - 2023-05-29 04:20:29 --> Output Class Initialized
INFO - 2023-05-29 04:20:29 --> Security Class Initialized
DEBUG - 2023-05-29 04:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 04:20:29 --> Input Class Initialized
INFO - 2023-05-29 04:20:29 --> Language Class Initialized
INFO - 2023-05-29 04:20:29 --> Loader Class Initialized
INFO - 2023-05-29 04:20:29 --> Helper loaded: url_helper
INFO - 2023-05-29 04:20:29 --> Helper loaded: file_helper
INFO - 2023-05-29 04:20:29 --> Helper loaded: html_helper
INFO - 2023-05-29 04:20:29 --> Helper loaded: text_helper
INFO - 2023-05-29 04:20:29 --> Helper loaded: form_helper
INFO - 2023-05-29 04:20:29 --> Helper loaded: lang_helper
INFO - 2023-05-29 04:20:29 --> Helper loaded: security_helper
INFO - 2023-05-29 04:20:29 --> Helper loaded: cookie_helper
INFO - 2023-05-29 04:20:29 --> Database Driver Class Initialized
INFO - 2023-05-29 04:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 04:20:29 --> Parser Class Initialized
INFO - 2023-05-29 04:20:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 04:20:29 --> Pagination Class Initialized
INFO - 2023-05-29 04:20:29 --> Form Validation Class Initialized
INFO - 2023-05-29 04:20:29 --> Controller Class Initialized
INFO - 2023-05-29 04:20:29 --> Model Class Initialized
DEBUG - 2023-05-29 04:20:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 04:20:29 --> Model Class Initialized
INFO - 2023-05-29 04:20:29 --> Final output sent to browser
DEBUG - 2023-05-29 04:20:29 --> Total execution time: 0.0186
ERROR - 2023-05-29 04:20:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 04:20:29 --> Config Class Initialized
INFO - 2023-05-29 04:20:29 --> Hooks Class Initialized
DEBUG - 2023-05-29 04:20:29 --> UTF-8 Support Enabled
INFO - 2023-05-29 04:20:29 --> Utf8 Class Initialized
INFO - 2023-05-29 04:20:29 --> URI Class Initialized
DEBUG - 2023-05-29 04:20:29 --> No URI present. Default controller set.
INFO - 2023-05-29 04:20:29 --> Router Class Initialized
INFO - 2023-05-29 04:20:29 --> Output Class Initialized
INFO - 2023-05-29 04:20:29 --> Security Class Initialized
DEBUG - 2023-05-29 04:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 04:20:29 --> Input Class Initialized
INFO - 2023-05-29 04:20:29 --> Language Class Initialized
INFO - 2023-05-29 04:20:29 --> Loader Class Initialized
INFO - 2023-05-29 04:20:29 --> Helper loaded: url_helper
INFO - 2023-05-29 04:20:29 --> Helper loaded: file_helper
INFO - 2023-05-29 04:20:29 --> Helper loaded: html_helper
INFO - 2023-05-29 04:20:29 --> Helper loaded: text_helper
INFO - 2023-05-29 04:20:29 --> Helper loaded: form_helper
INFO - 2023-05-29 04:20:29 --> Helper loaded: lang_helper
INFO - 2023-05-29 04:20:29 --> Helper loaded: security_helper
INFO - 2023-05-29 04:20:29 --> Helper loaded: cookie_helper
INFO - 2023-05-29 04:20:29 --> Database Driver Class Initialized
INFO - 2023-05-29 04:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 04:20:29 --> Parser Class Initialized
INFO - 2023-05-29 04:20:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 04:20:29 --> Pagination Class Initialized
INFO - 2023-05-29 04:20:29 --> Form Validation Class Initialized
INFO - 2023-05-29 04:20:29 --> Controller Class Initialized
INFO - 2023-05-29 04:20:29 --> Model Class Initialized
DEBUG - 2023-05-29 04:20:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 04:20:29 --> Model Class Initialized
DEBUG - 2023-05-29 04:20:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 04:20:29 --> Model Class Initialized
INFO - 2023-05-29 04:20:29 --> Model Class Initialized
INFO - 2023-05-29 04:20:29 --> Model Class Initialized
INFO - 2023-05-29 04:20:29 --> Model Class Initialized
DEBUG - 2023-05-29 04:20:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 04:20:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 04:20:29 --> Model Class Initialized
INFO - 2023-05-29 04:20:29 --> Model Class Initialized
INFO - 2023-05-29 04:20:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-29 04:20:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 04:20:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 04:20:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 04:20:29 --> Model Class Initialized
INFO - 2023-05-29 04:20:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-29 04:20:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-29 04:20:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 04:20:29 --> Final output sent to browser
DEBUG - 2023-05-29 04:20:29 --> Total execution time: 0.0783
ERROR - 2023-05-29 14:07:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 14:07:10 --> Config Class Initialized
INFO - 2023-05-29 14:07:10 --> Hooks Class Initialized
DEBUG - 2023-05-29 14:07:10 --> UTF-8 Support Enabled
INFO - 2023-05-29 14:07:10 --> Utf8 Class Initialized
INFO - 2023-05-29 14:07:10 --> URI Class Initialized
DEBUG - 2023-05-29 14:07:10 --> No URI present. Default controller set.
INFO - 2023-05-29 14:07:10 --> Router Class Initialized
INFO - 2023-05-29 14:07:10 --> Output Class Initialized
INFO - 2023-05-29 14:07:10 --> Security Class Initialized
DEBUG - 2023-05-29 14:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 14:07:10 --> Input Class Initialized
INFO - 2023-05-29 14:07:10 --> Language Class Initialized
INFO - 2023-05-29 14:07:10 --> Loader Class Initialized
INFO - 2023-05-29 14:07:10 --> Helper loaded: url_helper
INFO - 2023-05-29 14:07:10 --> Helper loaded: file_helper
INFO - 2023-05-29 14:07:10 --> Helper loaded: html_helper
INFO - 2023-05-29 14:07:10 --> Helper loaded: text_helper
INFO - 2023-05-29 14:07:10 --> Helper loaded: form_helper
INFO - 2023-05-29 14:07:10 --> Helper loaded: lang_helper
INFO - 2023-05-29 14:07:10 --> Helper loaded: security_helper
INFO - 2023-05-29 14:07:10 --> Helper loaded: cookie_helper
INFO - 2023-05-29 14:07:10 --> Database Driver Class Initialized
INFO - 2023-05-29 14:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 14:07:10 --> Parser Class Initialized
INFO - 2023-05-29 14:07:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 14:07:10 --> Pagination Class Initialized
INFO - 2023-05-29 14:07:10 --> Form Validation Class Initialized
INFO - 2023-05-29 14:07:10 --> Controller Class Initialized
INFO - 2023-05-29 14:07:10 --> Model Class Initialized
DEBUG - 2023-05-29 14:07:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-29 14:07:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 14:07:11 --> Config Class Initialized
INFO - 2023-05-29 14:07:11 --> Hooks Class Initialized
DEBUG - 2023-05-29 14:07:11 --> UTF-8 Support Enabled
INFO - 2023-05-29 14:07:11 --> Utf8 Class Initialized
INFO - 2023-05-29 14:07:11 --> URI Class Initialized
INFO - 2023-05-29 14:07:11 --> Router Class Initialized
INFO - 2023-05-29 14:07:11 --> Output Class Initialized
INFO - 2023-05-29 14:07:11 --> Security Class Initialized
DEBUG - 2023-05-29 14:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 14:07:11 --> Input Class Initialized
INFO - 2023-05-29 14:07:11 --> Language Class Initialized
INFO - 2023-05-29 14:07:11 --> Loader Class Initialized
INFO - 2023-05-29 14:07:11 --> Helper loaded: url_helper
INFO - 2023-05-29 14:07:11 --> Helper loaded: file_helper
INFO - 2023-05-29 14:07:11 --> Helper loaded: html_helper
INFO - 2023-05-29 14:07:11 --> Helper loaded: text_helper
INFO - 2023-05-29 14:07:11 --> Helper loaded: form_helper
INFO - 2023-05-29 14:07:11 --> Helper loaded: lang_helper
INFO - 2023-05-29 14:07:11 --> Helper loaded: security_helper
INFO - 2023-05-29 14:07:11 --> Helper loaded: cookie_helper
INFO - 2023-05-29 14:07:11 --> Database Driver Class Initialized
INFO - 2023-05-29 14:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 14:07:11 --> Parser Class Initialized
INFO - 2023-05-29 14:07:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 14:07:11 --> Pagination Class Initialized
INFO - 2023-05-29 14:07:11 --> Form Validation Class Initialized
INFO - 2023-05-29 14:07:11 --> Controller Class Initialized
INFO - 2023-05-29 14:07:11 --> Model Class Initialized
DEBUG - 2023-05-29 14:07:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 14:07:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-29 14:07:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 14:07:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 14:07:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 14:07:11 --> Model Class Initialized
INFO - 2023-05-29 14:07:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 14:07:11 --> Final output sent to browser
DEBUG - 2023-05-29 14:07:11 --> Total execution time: 0.0309
ERROR - 2023-05-29 14:07:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 14:07:16 --> Config Class Initialized
INFO - 2023-05-29 14:07:16 --> Hooks Class Initialized
DEBUG - 2023-05-29 14:07:16 --> UTF-8 Support Enabled
INFO - 2023-05-29 14:07:16 --> Utf8 Class Initialized
INFO - 2023-05-29 14:07:16 --> URI Class Initialized
INFO - 2023-05-29 14:07:16 --> Router Class Initialized
INFO - 2023-05-29 14:07:16 --> Output Class Initialized
INFO - 2023-05-29 14:07:16 --> Security Class Initialized
DEBUG - 2023-05-29 14:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 14:07:16 --> Input Class Initialized
INFO - 2023-05-29 14:07:16 --> Language Class Initialized
INFO - 2023-05-29 14:07:16 --> Loader Class Initialized
INFO - 2023-05-29 14:07:16 --> Helper loaded: url_helper
INFO - 2023-05-29 14:07:16 --> Helper loaded: file_helper
INFO - 2023-05-29 14:07:16 --> Helper loaded: html_helper
INFO - 2023-05-29 14:07:16 --> Helper loaded: text_helper
INFO - 2023-05-29 14:07:16 --> Helper loaded: form_helper
INFO - 2023-05-29 14:07:16 --> Helper loaded: lang_helper
INFO - 2023-05-29 14:07:16 --> Helper loaded: security_helper
INFO - 2023-05-29 14:07:16 --> Helper loaded: cookie_helper
INFO - 2023-05-29 14:07:16 --> Database Driver Class Initialized
INFO - 2023-05-29 14:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 14:07:16 --> Parser Class Initialized
INFO - 2023-05-29 14:07:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 14:07:16 --> Pagination Class Initialized
INFO - 2023-05-29 14:07:16 --> Form Validation Class Initialized
INFO - 2023-05-29 14:07:16 --> Controller Class Initialized
INFO - 2023-05-29 14:07:16 --> Model Class Initialized
DEBUG - 2023-05-29 14:07:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 14:07:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-29 14:07:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 14:07:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 14:07:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 14:07:16 --> Model Class Initialized
INFO - 2023-05-29 14:07:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 14:07:16 --> Final output sent to browser
DEBUG - 2023-05-29 14:07:16 --> Total execution time: 0.0281
ERROR - 2023-05-29 14:07:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 14:07:39 --> Config Class Initialized
INFO - 2023-05-29 14:07:39 --> Hooks Class Initialized
DEBUG - 2023-05-29 14:07:39 --> UTF-8 Support Enabled
INFO - 2023-05-29 14:07:39 --> Utf8 Class Initialized
INFO - 2023-05-29 14:07:39 --> URI Class Initialized
DEBUG - 2023-05-29 14:07:39 --> No URI present. Default controller set.
INFO - 2023-05-29 14:07:39 --> Router Class Initialized
INFO - 2023-05-29 14:07:39 --> Output Class Initialized
INFO - 2023-05-29 14:07:39 --> Security Class Initialized
DEBUG - 2023-05-29 14:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 14:07:39 --> Input Class Initialized
INFO - 2023-05-29 14:07:39 --> Language Class Initialized
INFO - 2023-05-29 14:07:39 --> Loader Class Initialized
INFO - 2023-05-29 14:07:39 --> Helper loaded: url_helper
INFO - 2023-05-29 14:07:39 --> Helper loaded: file_helper
INFO - 2023-05-29 14:07:39 --> Helper loaded: html_helper
INFO - 2023-05-29 14:07:39 --> Helper loaded: text_helper
INFO - 2023-05-29 14:07:39 --> Helper loaded: form_helper
INFO - 2023-05-29 14:07:39 --> Helper loaded: lang_helper
INFO - 2023-05-29 14:07:39 --> Helper loaded: security_helper
INFO - 2023-05-29 14:07:39 --> Helper loaded: cookie_helper
INFO - 2023-05-29 14:07:39 --> Database Driver Class Initialized
INFO - 2023-05-29 14:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 14:07:39 --> Parser Class Initialized
INFO - 2023-05-29 14:07:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 14:07:39 --> Pagination Class Initialized
INFO - 2023-05-29 14:07:39 --> Form Validation Class Initialized
INFO - 2023-05-29 14:07:39 --> Controller Class Initialized
INFO - 2023-05-29 14:07:39 --> Model Class Initialized
DEBUG - 2023-05-29 14:07:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-29 14:07:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 14:07:39 --> Config Class Initialized
INFO - 2023-05-29 14:07:39 --> Hooks Class Initialized
DEBUG - 2023-05-29 14:07:39 --> UTF-8 Support Enabled
INFO - 2023-05-29 14:07:39 --> Utf8 Class Initialized
INFO - 2023-05-29 14:07:39 --> URI Class Initialized
INFO - 2023-05-29 14:07:39 --> Router Class Initialized
INFO - 2023-05-29 14:07:39 --> Output Class Initialized
INFO - 2023-05-29 14:07:39 --> Security Class Initialized
DEBUG - 2023-05-29 14:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 14:07:39 --> Input Class Initialized
INFO - 2023-05-29 14:07:39 --> Language Class Initialized
INFO - 2023-05-29 14:07:39 --> Loader Class Initialized
INFO - 2023-05-29 14:07:39 --> Helper loaded: url_helper
INFO - 2023-05-29 14:07:39 --> Helper loaded: file_helper
INFO - 2023-05-29 14:07:39 --> Helper loaded: html_helper
INFO - 2023-05-29 14:07:39 --> Helper loaded: text_helper
INFO - 2023-05-29 14:07:39 --> Helper loaded: form_helper
INFO - 2023-05-29 14:07:39 --> Helper loaded: lang_helper
INFO - 2023-05-29 14:07:39 --> Helper loaded: security_helper
INFO - 2023-05-29 14:07:39 --> Helper loaded: cookie_helper
INFO - 2023-05-29 14:07:39 --> Database Driver Class Initialized
INFO - 2023-05-29 14:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 14:07:39 --> Parser Class Initialized
INFO - 2023-05-29 14:07:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 14:07:39 --> Pagination Class Initialized
INFO - 2023-05-29 14:07:39 --> Form Validation Class Initialized
INFO - 2023-05-29 14:07:39 --> Controller Class Initialized
INFO - 2023-05-29 14:07:39 --> Model Class Initialized
DEBUG - 2023-05-29 14:07:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 14:07:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-29 14:07:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 14:07:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 14:07:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 14:07:39 --> Model Class Initialized
INFO - 2023-05-29 14:07:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 14:07:39 --> Final output sent to browser
DEBUG - 2023-05-29 14:07:39 --> Total execution time: 0.0343
ERROR - 2023-05-29 14:08:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 14:08:02 --> Config Class Initialized
INFO - 2023-05-29 14:08:02 --> Hooks Class Initialized
DEBUG - 2023-05-29 14:08:02 --> UTF-8 Support Enabled
INFO - 2023-05-29 14:08:02 --> Utf8 Class Initialized
INFO - 2023-05-29 14:08:02 --> URI Class Initialized
INFO - 2023-05-29 14:08:02 --> Router Class Initialized
INFO - 2023-05-29 14:08:02 --> Output Class Initialized
INFO - 2023-05-29 14:08:02 --> Security Class Initialized
DEBUG - 2023-05-29 14:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 14:08:02 --> Input Class Initialized
INFO - 2023-05-29 14:08:02 --> Language Class Initialized
INFO - 2023-05-29 14:08:02 --> Loader Class Initialized
INFO - 2023-05-29 14:08:02 --> Helper loaded: url_helper
INFO - 2023-05-29 14:08:02 --> Helper loaded: file_helper
INFO - 2023-05-29 14:08:02 --> Helper loaded: html_helper
INFO - 2023-05-29 14:08:02 --> Helper loaded: text_helper
INFO - 2023-05-29 14:08:02 --> Helper loaded: form_helper
INFO - 2023-05-29 14:08:02 --> Helper loaded: lang_helper
INFO - 2023-05-29 14:08:02 --> Helper loaded: security_helper
INFO - 2023-05-29 14:08:02 --> Helper loaded: cookie_helper
INFO - 2023-05-29 14:08:02 --> Database Driver Class Initialized
INFO - 2023-05-29 14:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 14:08:02 --> Parser Class Initialized
INFO - 2023-05-29 14:08:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 14:08:02 --> Pagination Class Initialized
INFO - 2023-05-29 14:08:02 --> Form Validation Class Initialized
INFO - 2023-05-29 14:08:02 --> Controller Class Initialized
INFO - 2023-05-29 14:08:02 --> Model Class Initialized
DEBUG - 2023-05-29 14:08:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 14:08:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-29 14:08:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 14:08:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 14:08:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 14:08:02 --> Model Class Initialized
INFO - 2023-05-29 14:08:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 14:08:02 --> Final output sent to browser
DEBUG - 2023-05-29 14:08:02 --> Total execution time: 0.0304
ERROR - 2023-05-29 14:08:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 14:08:02 --> Config Class Initialized
INFO - 2023-05-29 14:08:02 --> Hooks Class Initialized
DEBUG - 2023-05-29 14:08:02 --> UTF-8 Support Enabled
INFO - 2023-05-29 14:08:02 --> Utf8 Class Initialized
INFO - 2023-05-29 14:08:02 --> URI Class Initialized
INFO - 2023-05-29 14:08:02 --> Router Class Initialized
INFO - 2023-05-29 14:08:02 --> Output Class Initialized
INFO - 2023-05-29 14:08:02 --> Security Class Initialized
DEBUG - 2023-05-29 14:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 14:08:02 --> Input Class Initialized
INFO - 2023-05-29 14:08:02 --> Language Class Initialized
INFO - 2023-05-29 14:08:02 --> Loader Class Initialized
INFO - 2023-05-29 14:08:02 --> Helper loaded: url_helper
INFO - 2023-05-29 14:08:02 --> Helper loaded: file_helper
INFO - 2023-05-29 14:08:02 --> Helper loaded: html_helper
INFO - 2023-05-29 14:08:02 --> Helper loaded: text_helper
INFO - 2023-05-29 14:08:02 --> Helper loaded: form_helper
INFO - 2023-05-29 14:08:02 --> Helper loaded: lang_helper
INFO - 2023-05-29 14:08:02 --> Helper loaded: security_helper
INFO - 2023-05-29 14:08:02 --> Helper loaded: cookie_helper
INFO - 2023-05-29 14:08:02 --> Database Driver Class Initialized
INFO - 2023-05-29 14:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 14:08:02 --> Parser Class Initialized
INFO - 2023-05-29 14:08:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 14:08:02 --> Pagination Class Initialized
INFO - 2023-05-29 14:08:02 --> Form Validation Class Initialized
INFO - 2023-05-29 14:08:02 --> Controller Class Initialized
INFO - 2023-05-29 14:08:02 --> Model Class Initialized
DEBUG - 2023-05-29 14:08:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 14:08:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-29 14:08:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 14:08:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 14:08:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 14:08:02 --> Model Class Initialized
INFO - 2023-05-29 14:08:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 14:08:02 --> Final output sent to browser
DEBUG - 2023-05-29 14:08:02 --> Total execution time: 0.0290
ERROR - 2023-05-29 14:08:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 14:08:11 --> Config Class Initialized
INFO - 2023-05-29 14:08:11 --> Hooks Class Initialized
DEBUG - 2023-05-29 14:08:11 --> UTF-8 Support Enabled
INFO - 2023-05-29 14:08:11 --> Utf8 Class Initialized
INFO - 2023-05-29 14:08:11 --> URI Class Initialized
INFO - 2023-05-29 14:08:11 --> Router Class Initialized
INFO - 2023-05-29 14:08:11 --> Output Class Initialized
INFO - 2023-05-29 14:08:11 --> Security Class Initialized
DEBUG - 2023-05-29 14:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 14:08:11 --> Input Class Initialized
INFO - 2023-05-29 14:08:11 --> Language Class Initialized
INFO - 2023-05-29 14:08:11 --> Loader Class Initialized
INFO - 2023-05-29 14:08:11 --> Helper loaded: url_helper
INFO - 2023-05-29 14:08:11 --> Helper loaded: file_helper
INFO - 2023-05-29 14:08:11 --> Helper loaded: html_helper
INFO - 2023-05-29 14:08:11 --> Helper loaded: text_helper
INFO - 2023-05-29 14:08:11 --> Helper loaded: form_helper
INFO - 2023-05-29 14:08:11 --> Helper loaded: lang_helper
INFO - 2023-05-29 14:08:11 --> Helper loaded: security_helper
INFO - 2023-05-29 14:08:11 --> Helper loaded: cookie_helper
INFO - 2023-05-29 14:08:11 --> Database Driver Class Initialized
INFO - 2023-05-29 14:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 14:08:11 --> Parser Class Initialized
INFO - 2023-05-29 14:08:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 14:08:11 --> Pagination Class Initialized
INFO - 2023-05-29 14:08:11 --> Form Validation Class Initialized
INFO - 2023-05-29 14:08:11 --> Controller Class Initialized
INFO - 2023-05-29 14:08:11 --> Model Class Initialized
DEBUG - 2023-05-29 14:08:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 14:08:11 --> Model Class Initialized
INFO - 2023-05-29 14:08:11 --> Final output sent to browser
DEBUG - 2023-05-29 14:08:11 --> Total execution time: 0.0195
ERROR - 2023-05-29 14:08:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 14:08:11 --> Config Class Initialized
INFO - 2023-05-29 14:08:11 --> Hooks Class Initialized
DEBUG - 2023-05-29 14:08:11 --> UTF-8 Support Enabled
INFO - 2023-05-29 14:08:11 --> Utf8 Class Initialized
INFO - 2023-05-29 14:08:11 --> URI Class Initialized
INFO - 2023-05-29 14:08:11 --> Router Class Initialized
INFO - 2023-05-29 14:08:11 --> Output Class Initialized
INFO - 2023-05-29 14:08:11 --> Security Class Initialized
DEBUG - 2023-05-29 14:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 14:08:11 --> Input Class Initialized
INFO - 2023-05-29 14:08:11 --> Language Class Initialized
INFO - 2023-05-29 14:08:11 --> Loader Class Initialized
INFO - 2023-05-29 14:08:11 --> Helper loaded: url_helper
INFO - 2023-05-29 14:08:11 --> Helper loaded: file_helper
INFO - 2023-05-29 14:08:11 --> Helper loaded: html_helper
INFO - 2023-05-29 14:08:11 --> Helper loaded: text_helper
INFO - 2023-05-29 14:08:11 --> Helper loaded: form_helper
INFO - 2023-05-29 14:08:11 --> Helper loaded: lang_helper
INFO - 2023-05-29 14:08:11 --> Helper loaded: security_helper
INFO - 2023-05-29 14:08:11 --> Helper loaded: cookie_helper
INFO - 2023-05-29 14:08:11 --> Database Driver Class Initialized
INFO - 2023-05-29 14:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 14:08:11 --> Parser Class Initialized
INFO - 2023-05-29 14:08:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 14:08:11 --> Pagination Class Initialized
INFO - 2023-05-29 14:08:11 --> Form Validation Class Initialized
INFO - 2023-05-29 14:08:11 --> Controller Class Initialized
INFO - 2023-05-29 14:08:11 --> Model Class Initialized
DEBUG - 2023-05-29 14:08:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 14:08:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-29 14:08:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 14:08:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 14:08:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 14:08:11 --> Model Class Initialized
INFO - 2023-05-29 14:08:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 14:08:11 --> Final output sent to browser
DEBUG - 2023-05-29 14:08:11 --> Total execution time: 0.0285
ERROR - 2023-05-29 14:13:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 14:13:59 --> Config Class Initialized
INFO - 2023-05-29 14:13:59 --> Hooks Class Initialized
DEBUG - 2023-05-29 14:13:59 --> UTF-8 Support Enabled
INFO - 2023-05-29 14:13:59 --> Utf8 Class Initialized
INFO - 2023-05-29 14:13:59 --> URI Class Initialized
DEBUG - 2023-05-29 14:13:59 --> No URI present. Default controller set.
INFO - 2023-05-29 14:13:59 --> Router Class Initialized
INFO - 2023-05-29 14:13:59 --> Output Class Initialized
INFO - 2023-05-29 14:13:59 --> Security Class Initialized
DEBUG - 2023-05-29 14:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 14:13:59 --> Input Class Initialized
INFO - 2023-05-29 14:13:59 --> Language Class Initialized
INFO - 2023-05-29 14:13:59 --> Loader Class Initialized
INFO - 2023-05-29 14:13:59 --> Helper loaded: url_helper
INFO - 2023-05-29 14:13:59 --> Helper loaded: file_helper
INFO - 2023-05-29 14:13:59 --> Helper loaded: html_helper
INFO - 2023-05-29 14:13:59 --> Helper loaded: text_helper
INFO - 2023-05-29 14:13:59 --> Helper loaded: form_helper
INFO - 2023-05-29 14:13:59 --> Helper loaded: lang_helper
INFO - 2023-05-29 14:13:59 --> Helper loaded: security_helper
INFO - 2023-05-29 14:13:59 --> Helper loaded: cookie_helper
INFO - 2023-05-29 14:13:59 --> Database Driver Class Initialized
INFO - 2023-05-29 14:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 14:13:59 --> Parser Class Initialized
INFO - 2023-05-29 14:13:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 14:13:59 --> Pagination Class Initialized
INFO - 2023-05-29 14:13:59 --> Form Validation Class Initialized
INFO - 2023-05-29 14:13:59 --> Controller Class Initialized
INFO - 2023-05-29 14:13:59 --> Model Class Initialized
DEBUG - 2023-05-29 14:13:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-29 14:14:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 14:14:00 --> Config Class Initialized
INFO - 2023-05-29 14:14:00 --> Hooks Class Initialized
DEBUG - 2023-05-29 14:14:00 --> UTF-8 Support Enabled
INFO - 2023-05-29 14:14:00 --> Utf8 Class Initialized
INFO - 2023-05-29 14:14:00 --> URI Class Initialized
INFO - 2023-05-29 14:14:00 --> Router Class Initialized
INFO - 2023-05-29 14:14:00 --> Output Class Initialized
INFO - 2023-05-29 14:14:00 --> Security Class Initialized
DEBUG - 2023-05-29 14:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 14:14:00 --> Input Class Initialized
INFO - 2023-05-29 14:14:00 --> Language Class Initialized
INFO - 2023-05-29 14:14:00 --> Loader Class Initialized
INFO - 2023-05-29 14:14:00 --> Helper loaded: url_helper
INFO - 2023-05-29 14:14:00 --> Helper loaded: file_helper
INFO - 2023-05-29 14:14:00 --> Helper loaded: html_helper
INFO - 2023-05-29 14:14:00 --> Helper loaded: text_helper
INFO - 2023-05-29 14:14:00 --> Helper loaded: form_helper
INFO - 2023-05-29 14:14:00 --> Helper loaded: lang_helper
INFO - 2023-05-29 14:14:00 --> Helper loaded: security_helper
INFO - 2023-05-29 14:14:00 --> Helper loaded: cookie_helper
INFO - 2023-05-29 14:14:00 --> Database Driver Class Initialized
INFO - 2023-05-29 14:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 14:14:00 --> Parser Class Initialized
INFO - 2023-05-29 14:14:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 14:14:00 --> Pagination Class Initialized
INFO - 2023-05-29 14:14:00 --> Form Validation Class Initialized
INFO - 2023-05-29 14:14:00 --> Controller Class Initialized
INFO - 2023-05-29 14:14:00 --> Model Class Initialized
DEBUG - 2023-05-29 14:14:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 14:14:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-29 14:14:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 14:14:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 14:14:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 14:14:00 --> Model Class Initialized
INFO - 2023-05-29 14:14:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 14:14:00 --> Final output sent to browser
DEBUG - 2023-05-29 14:14:00 --> Total execution time: 0.0334
ERROR - 2023-05-29 14:14:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 14:14:46 --> Config Class Initialized
INFO - 2023-05-29 14:14:46 --> Hooks Class Initialized
DEBUG - 2023-05-29 14:14:46 --> UTF-8 Support Enabled
INFO - 2023-05-29 14:14:46 --> Utf8 Class Initialized
INFO - 2023-05-29 14:14:46 --> URI Class Initialized
INFO - 2023-05-29 14:14:46 --> Router Class Initialized
INFO - 2023-05-29 14:14:46 --> Output Class Initialized
INFO - 2023-05-29 14:14:46 --> Security Class Initialized
DEBUG - 2023-05-29 14:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 14:14:46 --> Input Class Initialized
INFO - 2023-05-29 14:14:46 --> Language Class Initialized
INFO - 2023-05-29 14:14:46 --> Loader Class Initialized
INFO - 2023-05-29 14:14:46 --> Helper loaded: url_helper
INFO - 2023-05-29 14:14:46 --> Helper loaded: file_helper
INFO - 2023-05-29 14:14:46 --> Helper loaded: html_helper
INFO - 2023-05-29 14:14:46 --> Helper loaded: text_helper
INFO - 2023-05-29 14:14:46 --> Helper loaded: form_helper
INFO - 2023-05-29 14:14:46 --> Helper loaded: lang_helper
INFO - 2023-05-29 14:14:46 --> Helper loaded: security_helper
INFO - 2023-05-29 14:14:46 --> Helper loaded: cookie_helper
INFO - 2023-05-29 14:14:46 --> Database Driver Class Initialized
INFO - 2023-05-29 14:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 14:14:46 --> Parser Class Initialized
INFO - 2023-05-29 14:14:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 14:14:46 --> Pagination Class Initialized
INFO - 2023-05-29 14:14:46 --> Form Validation Class Initialized
INFO - 2023-05-29 14:14:46 --> Controller Class Initialized
INFO - 2023-05-29 14:14:46 --> Model Class Initialized
DEBUG - 2023-05-29 14:14:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 14:14:46 --> Model Class Initialized
INFO - 2023-05-29 14:14:46 --> Final output sent to browser
DEBUG - 2023-05-29 14:14:46 --> Total execution time: 0.0213
ERROR - 2023-05-29 14:14:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 14:14:46 --> Config Class Initialized
INFO - 2023-05-29 14:14:46 --> Hooks Class Initialized
DEBUG - 2023-05-29 14:14:46 --> UTF-8 Support Enabled
INFO - 2023-05-29 14:14:46 --> Utf8 Class Initialized
INFO - 2023-05-29 14:14:46 --> URI Class Initialized
INFO - 2023-05-29 14:14:46 --> Router Class Initialized
INFO - 2023-05-29 14:14:46 --> Output Class Initialized
INFO - 2023-05-29 14:14:46 --> Security Class Initialized
DEBUG - 2023-05-29 14:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 14:14:46 --> Input Class Initialized
INFO - 2023-05-29 14:14:46 --> Language Class Initialized
INFO - 2023-05-29 14:14:46 --> Loader Class Initialized
INFO - 2023-05-29 14:14:46 --> Helper loaded: url_helper
INFO - 2023-05-29 14:14:46 --> Helper loaded: file_helper
INFO - 2023-05-29 14:14:46 --> Helper loaded: html_helper
INFO - 2023-05-29 14:14:46 --> Helper loaded: text_helper
INFO - 2023-05-29 14:14:46 --> Helper loaded: form_helper
INFO - 2023-05-29 14:14:46 --> Helper loaded: lang_helper
INFO - 2023-05-29 14:14:46 --> Helper loaded: security_helper
INFO - 2023-05-29 14:14:46 --> Helper loaded: cookie_helper
INFO - 2023-05-29 14:14:46 --> Database Driver Class Initialized
INFO - 2023-05-29 14:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 14:14:46 --> Parser Class Initialized
INFO - 2023-05-29 14:14:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 14:14:46 --> Pagination Class Initialized
INFO - 2023-05-29 14:14:46 --> Form Validation Class Initialized
INFO - 2023-05-29 14:14:46 --> Controller Class Initialized
INFO - 2023-05-29 14:14:46 --> Model Class Initialized
DEBUG - 2023-05-29 14:14:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 14:14:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-29 14:14:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 14:14:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 14:14:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 14:14:46 --> Model Class Initialized
INFO - 2023-05-29 14:14:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 14:14:46 --> Final output sent to browser
DEBUG - 2023-05-29 14:14:46 --> Total execution time: 0.0302
ERROR - 2023-05-29 14:14:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 14:14:54 --> Config Class Initialized
INFO - 2023-05-29 14:14:54 --> Hooks Class Initialized
DEBUG - 2023-05-29 14:14:54 --> UTF-8 Support Enabled
INFO - 2023-05-29 14:14:54 --> Utf8 Class Initialized
INFO - 2023-05-29 14:14:54 --> URI Class Initialized
INFO - 2023-05-29 14:14:54 --> Router Class Initialized
INFO - 2023-05-29 14:14:54 --> Output Class Initialized
INFO - 2023-05-29 14:14:54 --> Security Class Initialized
DEBUG - 2023-05-29 14:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 14:14:54 --> Input Class Initialized
INFO - 2023-05-29 14:14:54 --> Language Class Initialized
INFO - 2023-05-29 14:14:54 --> Loader Class Initialized
INFO - 2023-05-29 14:14:54 --> Helper loaded: url_helper
INFO - 2023-05-29 14:14:54 --> Helper loaded: file_helper
INFO - 2023-05-29 14:14:54 --> Helper loaded: html_helper
INFO - 2023-05-29 14:14:54 --> Helper loaded: text_helper
INFO - 2023-05-29 14:14:54 --> Helper loaded: form_helper
INFO - 2023-05-29 14:14:54 --> Helper loaded: lang_helper
INFO - 2023-05-29 14:14:54 --> Helper loaded: security_helper
INFO - 2023-05-29 14:14:54 --> Helper loaded: cookie_helper
INFO - 2023-05-29 14:14:54 --> Database Driver Class Initialized
INFO - 2023-05-29 14:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 14:14:54 --> Parser Class Initialized
INFO - 2023-05-29 14:14:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 14:14:54 --> Pagination Class Initialized
INFO - 2023-05-29 14:14:54 --> Form Validation Class Initialized
INFO - 2023-05-29 14:14:54 --> Controller Class Initialized
INFO - 2023-05-29 14:14:54 --> Model Class Initialized
DEBUG - 2023-05-29 14:14:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 14:14:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-29 14:14:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 14:14:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 14:14:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 14:14:54 --> Model Class Initialized
INFO - 2023-05-29 14:14:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 14:14:54 --> Final output sent to browser
DEBUG - 2023-05-29 14:14:54 --> Total execution time: 0.0290
ERROR - 2023-05-29 15:52:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 15:52:44 --> Config Class Initialized
INFO - 2023-05-29 15:52:44 --> Hooks Class Initialized
DEBUG - 2023-05-29 15:52:44 --> UTF-8 Support Enabled
INFO - 2023-05-29 15:52:44 --> Utf8 Class Initialized
INFO - 2023-05-29 15:52:44 --> URI Class Initialized
DEBUG - 2023-05-29 15:52:44 --> No URI present. Default controller set.
INFO - 2023-05-29 15:52:44 --> Router Class Initialized
INFO - 2023-05-29 15:52:44 --> Output Class Initialized
INFO - 2023-05-29 15:52:44 --> Security Class Initialized
DEBUG - 2023-05-29 15:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 15:52:44 --> Input Class Initialized
INFO - 2023-05-29 15:52:44 --> Language Class Initialized
INFO - 2023-05-29 15:52:44 --> Loader Class Initialized
INFO - 2023-05-29 15:52:44 --> Helper loaded: url_helper
INFO - 2023-05-29 15:52:44 --> Helper loaded: file_helper
INFO - 2023-05-29 15:52:44 --> Helper loaded: html_helper
INFO - 2023-05-29 15:52:44 --> Helper loaded: text_helper
INFO - 2023-05-29 15:52:44 --> Helper loaded: form_helper
INFO - 2023-05-29 15:52:44 --> Helper loaded: lang_helper
INFO - 2023-05-29 15:52:44 --> Helper loaded: security_helper
INFO - 2023-05-29 15:52:44 --> Helper loaded: cookie_helper
INFO - 2023-05-29 15:52:44 --> Database Driver Class Initialized
INFO - 2023-05-29 15:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 15:52:44 --> Parser Class Initialized
INFO - 2023-05-29 15:52:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 15:52:44 --> Pagination Class Initialized
INFO - 2023-05-29 15:52:44 --> Form Validation Class Initialized
INFO - 2023-05-29 15:52:44 --> Controller Class Initialized
INFO - 2023-05-29 15:52:44 --> Model Class Initialized
DEBUG - 2023-05-29 15:52:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-29 15:52:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 15:52:45 --> Config Class Initialized
INFO - 2023-05-29 15:52:45 --> Hooks Class Initialized
DEBUG - 2023-05-29 15:52:45 --> UTF-8 Support Enabled
INFO - 2023-05-29 15:52:45 --> Utf8 Class Initialized
INFO - 2023-05-29 15:52:45 --> URI Class Initialized
INFO - 2023-05-29 15:52:45 --> Router Class Initialized
INFO - 2023-05-29 15:52:45 --> Output Class Initialized
INFO - 2023-05-29 15:52:45 --> Security Class Initialized
DEBUG - 2023-05-29 15:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 15:52:45 --> Input Class Initialized
INFO - 2023-05-29 15:52:45 --> Language Class Initialized
INFO - 2023-05-29 15:52:45 --> Loader Class Initialized
INFO - 2023-05-29 15:52:45 --> Helper loaded: url_helper
INFO - 2023-05-29 15:52:45 --> Helper loaded: file_helper
INFO - 2023-05-29 15:52:45 --> Helper loaded: html_helper
INFO - 2023-05-29 15:52:45 --> Helper loaded: text_helper
INFO - 2023-05-29 15:52:45 --> Helper loaded: form_helper
INFO - 2023-05-29 15:52:45 --> Helper loaded: lang_helper
INFO - 2023-05-29 15:52:45 --> Helper loaded: security_helper
INFO - 2023-05-29 15:52:45 --> Helper loaded: cookie_helper
INFO - 2023-05-29 15:52:45 --> Database Driver Class Initialized
INFO - 2023-05-29 15:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 15:52:45 --> Parser Class Initialized
INFO - 2023-05-29 15:52:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 15:52:45 --> Pagination Class Initialized
INFO - 2023-05-29 15:52:45 --> Form Validation Class Initialized
INFO - 2023-05-29 15:52:45 --> Controller Class Initialized
INFO - 2023-05-29 15:52:45 --> Model Class Initialized
DEBUG - 2023-05-29 15:52:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 15:52:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-29 15:52:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 15:52:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 15:52:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 15:52:45 --> Model Class Initialized
INFO - 2023-05-29 15:52:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 15:52:45 --> Final output sent to browser
DEBUG - 2023-05-29 15:52:45 --> Total execution time: 0.0298
ERROR - 2023-05-29 15:52:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 15:52:45 --> Config Class Initialized
INFO - 2023-05-29 15:52:45 --> Hooks Class Initialized
DEBUG - 2023-05-29 15:52:45 --> UTF-8 Support Enabled
INFO - 2023-05-29 15:52:45 --> Utf8 Class Initialized
INFO - 2023-05-29 15:52:45 --> URI Class Initialized
INFO - 2023-05-29 15:52:45 --> Router Class Initialized
INFO - 2023-05-29 15:52:45 --> Output Class Initialized
INFO - 2023-05-29 15:52:45 --> Security Class Initialized
DEBUG - 2023-05-29 15:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 15:52:45 --> Input Class Initialized
INFO - 2023-05-29 15:52:45 --> Language Class Initialized
ERROR - 2023-05-29 15:52:45 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2023-05-29 15:52:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 15:52:46 --> Config Class Initialized
INFO - 2023-05-29 15:52:46 --> Hooks Class Initialized
DEBUG - 2023-05-29 15:52:46 --> UTF-8 Support Enabled
INFO - 2023-05-29 15:52:46 --> Utf8 Class Initialized
INFO - 2023-05-29 15:52:46 --> URI Class Initialized
INFO - 2023-05-29 15:52:46 --> Router Class Initialized
INFO - 2023-05-29 15:52:46 --> Output Class Initialized
INFO - 2023-05-29 15:52:46 --> Security Class Initialized
DEBUG - 2023-05-29 15:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 15:52:46 --> Input Class Initialized
INFO - 2023-05-29 15:52:46 --> Language Class Initialized
ERROR - 2023-05-29 15:52:46 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2023-05-29 15:52:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 15:52:51 --> Config Class Initialized
INFO - 2023-05-29 15:52:51 --> Hooks Class Initialized
DEBUG - 2023-05-29 15:52:51 --> UTF-8 Support Enabled
INFO - 2023-05-29 15:52:51 --> Utf8 Class Initialized
INFO - 2023-05-29 15:52:51 --> URI Class Initialized
INFO - 2023-05-29 15:52:51 --> Router Class Initialized
INFO - 2023-05-29 15:52:51 --> Output Class Initialized
INFO - 2023-05-29 15:52:51 --> Security Class Initialized
DEBUG - 2023-05-29 15:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 15:52:51 --> Input Class Initialized
INFO - 2023-05-29 15:52:51 --> Language Class Initialized
INFO - 2023-05-29 15:52:51 --> Loader Class Initialized
INFO - 2023-05-29 15:52:51 --> Helper loaded: url_helper
INFO - 2023-05-29 15:52:51 --> Helper loaded: file_helper
INFO - 2023-05-29 15:52:51 --> Helper loaded: html_helper
INFO - 2023-05-29 15:52:51 --> Helper loaded: text_helper
INFO - 2023-05-29 15:52:51 --> Helper loaded: form_helper
INFO - 2023-05-29 15:52:51 --> Helper loaded: lang_helper
INFO - 2023-05-29 15:52:51 --> Helper loaded: security_helper
INFO - 2023-05-29 15:52:51 --> Helper loaded: cookie_helper
INFO - 2023-05-29 15:52:51 --> Database Driver Class Initialized
INFO - 2023-05-29 15:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 15:52:51 --> Parser Class Initialized
INFO - 2023-05-29 15:52:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 15:52:51 --> Pagination Class Initialized
INFO - 2023-05-29 15:52:51 --> Form Validation Class Initialized
INFO - 2023-05-29 15:52:51 --> Controller Class Initialized
INFO - 2023-05-29 15:52:51 --> Model Class Initialized
DEBUG - 2023-05-29 15:52:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 15:52:51 --> Model Class Initialized
INFO - 2023-05-29 15:52:51 --> Final output sent to browser
DEBUG - 2023-05-29 15:52:51 --> Total execution time: 0.0182
ERROR - 2023-05-29 15:52:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 15:52:51 --> Config Class Initialized
INFO - 2023-05-29 15:52:51 --> Hooks Class Initialized
DEBUG - 2023-05-29 15:52:51 --> UTF-8 Support Enabled
INFO - 2023-05-29 15:52:51 --> Utf8 Class Initialized
INFO - 2023-05-29 15:52:51 --> URI Class Initialized
DEBUG - 2023-05-29 15:52:51 --> No URI present. Default controller set.
INFO - 2023-05-29 15:52:51 --> Router Class Initialized
INFO - 2023-05-29 15:52:51 --> Output Class Initialized
INFO - 2023-05-29 15:52:51 --> Security Class Initialized
DEBUG - 2023-05-29 15:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 15:52:51 --> Input Class Initialized
INFO - 2023-05-29 15:52:51 --> Language Class Initialized
INFO - 2023-05-29 15:52:51 --> Loader Class Initialized
INFO - 2023-05-29 15:52:51 --> Helper loaded: url_helper
INFO - 2023-05-29 15:52:51 --> Helper loaded: file_helper
INFO - 2023-05-29 15:52:51 --> Helper loaded: html_helper
INFO - 2023-05-29 15:52:51 --> Helper loaded: text_helper
INFO - 2023-05-29 15:52:51 --> Helper loaded: form_helper
INFO - 2023-05-29 15:52:51 --> Helper loaded: lang_helper
INFO - 2023-05-29 15:52:51 --> Helper loaded: security_helper
INFO - 2023-05-29 15:52:51 --> Helper loaded: cookie_helper
INFO - 2023-05-29 15:52:51 --> Database Driver Class Initialized
INFO - 2023-05-29 15:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 15:52:51 --> Parser Class Initialized
INFO - 2023-05-29 15:52:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 15:52:51 --> Pagination Class Initialized
INFO - 2023-05-29 15:52:51 --> Form Validation Class Initialized
INFO - 2023-05-29 15:52:51 --> Controller Class Initialized
INFO - 2023-05-29 15:52:51 --> Model Class Initialized
DEBUG - 2023-05-29 15:52:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 15:52:51 --> Model Class Initialized
DEBUG - 2023-05-29 15:52:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 15:52:51 --> Model Class Initialized
INFO - 2023-05-29 15:52:51 --> Model Class Initialized
INFO - 2023-05-29 15:52:51 --> Model Class Initialized
INFO - 2023-05-29 15:52:51 --> Model Class Initialized
DEBUG - 2023-05-29 15:52:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 15:52:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 15:52:51 --> Model Class Initialized
INFO - 2023-05-29 15:52:51 --> Model Class Initialized
INFO - 2023-05-29 15:52:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-29 15:52:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 15:52:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 15:52:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 15:52:51 --> Model Class Initialized
INFO - 2023-05-29 15:52:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-29 15:52:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-29 15:52:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 15:52:51 --> Final output sent to browser
DEBUG - 2023-05-29 15:52:51 --> Total execution time: 0.0801
ERROR - 2023-05-29 15:52:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 15:52:59 --> Config Class Initialized
INFO - 2023-05-29 15:52:59 --> Hooks Class Initialized
DEBUG - 2023-05-29 15:52:59 --> UTF-8 Support Enabled
INFO - 2023-05-29 15:52:59 --> Utf8 Class Initialized
INFO - 2023-05-29 15:52:59 --> URI Class Initialized
INFO - 2023-05-29 15:52:59 --> Router Class Initialized
INFO - 2023-05-29 15:52:59 --> Output Class Initialized
INFO - 2023-05-29 15:52:59 --> Security Class Initialized
DEBUG - 2023-05-29 15:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 15:52:59 --> Input Class Initialized
INFO - 2023-05-29 15:52:59 --> Language Class Initialized
INFO - 2023-05-29 15:52:59 --> Loader Class Initialized
INFO - 2023-05-29 15:52:59 --> Helper loaded: url_helper
INFO - 2023-05-29 15:52:59 --> Helper loaded: file_helper
INFO - 2023-05-29 15:52:59 --> Helper loaded: html_helper
INFO - 2023-05-29 15:52:59 --> Helper loaded: text_helper
INFO - 2023-05-29 15:52:59 --> Helper loaded: form_helper
INFO - 2023-05-29 15:52:59 --> Helper loaded: lang_helper
INFO - 2023-05-29 15:52:59 --> Helper loaded: security_helper
INFO - 2023-05-29 15:52:59 --> Helper loaded: cookie_helper
INFO - 2023-05-29 15:52:59 --> Database Driver Class Initialized
INFO - 2023-05-29 15:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 15:52:59 --> Parser Class Initialized
INFO - 2023-05-29 15:52:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 15:52:59 --> Pagination Class Initialized
INFO - 2023-05-29 15:52:59 --> Form Validation Class Initialized
INFO - 2023-05-29 15:52:59 --> Controller Class Initialized
DEBUG - 2023-05-29 15:52:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 15:52:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 15:52:59 --> Model Class Initialized
DEBUG - 2023-05-29 15:52:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 15:52:59 --> Model Class Initialized
DEBUG - 2023-05-29 15:52:59 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-05-29 15:52:59 --> Model Class Initialized
INFO - 2023-05-29 15:52:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-05-29 15:52:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 15:52:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 15:52:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 15:52:59 --> Model Class Initialized
INFO - 2023-05-29 15:52:59 --> Model Class Initialized
INFO - 2023-05-29 15:52:59 --> Model Class Initialized
INFO - 2023-05-29 15:52:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-29 15:52:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-29 15:52:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 15:52:59 --> Final output sent to browser
DEBUG - 2023-05-29 15:52:59 --> Total execution time: 0.0788
ERROR - 2023-05-29 15:53:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 15:53:00 --> Config Class Initialized
INFO - 2023-05-29 15:53:00 --> Hooks Class Initialized
DEBUG - 2023-05-29 15:53:00 --> UTF-8 Support Enabled
INFO - 2023-05-29 15:53:00 --> Utf8 Class Initialized
INFO - 2023-05-29 15:53:00 --> URI Class Initialized
INFO - 2023-05-29 15:53:00 --> Router Class Initialized
INFO - 2023-05-29 15:53:00 --> Output Class Initialized
INFO - 2023-05-29 15:53:00 --> Security Class Initialized
DEBUG - 2023-05-29 15:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 15:53:00 --> Input Class Initialized
INFO - 2023-05-29 15:53:00 --> Language Class Initialized
INFO - 2023-05-29 15:53:00 --> Loader Class Initialized
INFO - 2023-05-29 15:53:00 --> Helper loaded: url_helper
INFO - 2023-05-29 15:53:00 --> Helper loaded: file_helper
INFO - 2023-05-29 15:53:00 --> Helper loaded: html_helper
INFO - 2023-05-29 15:53:00 --> Helper loaded: text_helper
INFO - 2023-05-29 15:53:00 --> Helper loaded: form_helper
INFO - 2023-05-29 15:53:00 --> Helper loaded: lang_helper
INFO - 2023-05-29 15:53:00 --> Helper loaded: security_helper
INFO - 2023-05-29 15:53:00 --> Helper loaded: cookie_helper
INFO - 2023-05-29 15:53:00 --> Database Driver Class Initialized
INFO - 2023-05-29 15:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 15:53:00 --> Parser Class Initialized
INFO - 2023-05-29 15:53:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 15:53:00 --> Pagination Class Initialized
INFO - 2023-05-29 15:53:00 --> Form Validation Class Initialized
INFO - 2023-05-29 15:53:00 --> Controller Class Initialized
DEBUG - 2023-05-29 15:53:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 15:53:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 15:53:00 --> Model Class Initialized
DEBUG - 2023-05-29 15:53:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 15:53:00 --> Model Class Initialized
INFO - 2023-05-29 15:53:00 --> Final output sent to browser
DEBUG - 2023-05-29 15:53:00 --> Total execution time: 0.0200
ERROR - 2023-05-29 15:53:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 15:53:07 --> Config Class Initialized
INFO - 2023-05-29 15:53:07 --> Hooks Class Initialized
DEBUG - 2023-05-29 15:53:07 --> UTF-8 Support Enabled
INFO - 2023-05-29 15:53:07 --> Utf8 Class Initialized
INFO - 2023-05-29 15:53:07 --> URI Class Initialized
INFO - 2023-05-29 15:53:07 --> Router Class Initialized
INFO - 2023-05-29 15:53:07 --> Output Class Initialized
INFO - 2023-05-29 15:53:07 --> Security Class Initialized
DEBUG - 2023-05-29 15:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 15:53:07 --> Input Class Initialized
INFO - 2023-05-29 15:53:07 --> Language Class Initialized
INFO - 2023-05-29 15:53:07 --> Loader Class Initialized
INFO - 2023-05-29 15:53:07 --> Helper loaded: url_helper
INFO - 2023-05-29 15:53:07 --> Helper loaded: file_helper
INFO - 2023-05-29 15:53:07 --> Helper loaded: html_helper
INFO - 2023-05-29 15:53:07 --> Helper loaded: text_helper
INFO - 2023-05-29 15:53:07 --> Helper loaded: form_helper
INFO - 2023-05-29 15:53:07 --> Helper loaded: lang_helper
INFO - 2023-05-29 15:53:07 --> Helper loaded: security_helper
INFO - 2023-05-29 15:53:07 --> Helper loaded: cookie_helper
INFO - 2023-05-29 15:53:07 --> Database Driver Class Initialized
INFO - 2023-05-29 15:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 15:53:07 --> Parser Class Initialized
INFO - 2023-05-29 15:53:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 15:53:07 --> Pagination Class Initialized
INFO - 2023-05-29 15:53:07 --> Form Validation Class Initialized
INFO - 2023-05-29 15:53:07 --> Controller Class Initialized
INFO - 2023-05-29 15:53:07 --> Model Class Initialized
DEBUG - 2023-05-29 15:53:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 15:53:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 15:53:07 --> Model Class Initialized
INFO - 2023-05-29 15:53:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-05-29 15:53:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 15:53:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 15:53:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 15:53:07 --> Model Class Initialized
INFO - 2023-05-29 15:53:07 --> Model Class Initialized
INFO - 2023-05-29 15:53:07 --> Model Class Initialized
INFO - 2023-05-29 15:53:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-29 15:53:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-29 15:53:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 15:53:07 --> Final output sent to browser
DEBUG - 2023-05-29 15:53:07 --> Total execution time: 0.0615
ERROR - 2023-05-29 15:53:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 15:53:08 --> Config Class Initialized
INFO - 2023-05-29 15:53:08 --> Hooks Class Initialized
DEBUG - 2023-05-29 15:53:08 --> UTF-8 Support Enabled
INFO - 2023-05-29 15:53:08 --> Utf8 Class Initialized
INFO - 2023-05-29 15:53:08 --> URI Class Initialized
INFO - 2023-05-29 15:53:08 --> Router Class Initialized
INFO - 2023-05-29 15:53:08 --> Output Class Initialized
INFO - 2023-05-29 15:53:08 --> Security Class Initialized
DEBUG - 2023-05-29 15:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 15:53:08 --> Input Class Initialized
INFO - 2023-05-29 15:53:08 --> Language Class Initialized
INFO - 2023-05-29 15:53:08 --> Loader Class Initialized
INFO - 2023-05-29 15:53:08 --> Helper loaded: url_helper
INFO - 2023-05-29 15:53:08 --> Helper loaded: file_helper
INFO - 2023-05-29 15:53:08 --> Helper loaded: html_helper
INFO - 2023-05-29 15:53:08 --> Helper loaded: text_helper
INFO - 2023-05-29 15:53:08 --> Helper loaded: form_helper
INFO - 2023-05-29 15:53:08 --> Helper loaded: lang_helper
INFO - 2023-05-29 15:53:08 --> Helper loaded: security_helper
INFO - 2023-05-29 15:53:08 --> Helper loaded: cookie_helper
INFO - 2023-05-29 15:53:08 --> Database Driver Class Initialized
INFO - 2023-05-29 15:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 15:53:08 --> Parser Class Initialized
INFO - 2023-05-29 15:53:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 15:53:08 --> Pagination Class Initialized
INFO - 2023-05-29 15:53:08 --> Form Validation Class Initialized
INFO - 2023-05-29 15:53:08 --> Controller Class Initialized
INFO - 2023-05-29 15:53:08 --> Model Class Initialized
DEBUG - 2023-05-29 15:53:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 15:53:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 15:53:08 --> Model Class Initialized
INFO - 2023-05-29 15:53:08 --> Final output sent to browser
DEBUG - 2023-05-29 15:53:08 --> Total execution time: 0.0216
ERROR - 2023-05-29 15:53:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 15:53:11 --> Config Class Initialized
INFO - 2023-05-29 15:53:11 --> Hooks Class Initialized
DEBUG - 2023-05-29 15:53:11 --> UTF-8 Support Enabled
INFO - 2023-05-29 15:53:11 --> Utf8 Class Initialized
INFO - 2023-05-29 15:53:11 --> URI Class Initialized
INFO - 2023-05-29 15:53:11 --> Router Class Initialized
INFO - 2023-05-29 15:53:11 --> Output Class Initialized
INFO - 2023-05-29 15:53:11 --> Security Class Initialized
DEBUG - 2023-05-29 15:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 15:53:11 --> Input Class Initialized
INFO - 2023-05-29 15:53:11 --> Language Class Initialized
INFO - 2023-05-29 15:53:11 --> Loader Class Initialized
INFO - 2023-05-29 15:53:11 --> Helper loaded: url_helper
INFO - 2023-05-29 15:53:11 --> Helper loaded: file_helper
INFO - 2023-05-29 15:53:11 --> Helper loaded: html_helper
INFO - 2023-05-29 15:53:11 --> Helper loaded: text_helper
INFO - 2023-05-29 15:53:11 --> Helper loaded: form_helper
INFO - 2023-05-29 15:53:11 --> Helper loaded: lang_helper
INFO - 2023-05-29 15:53:11 --> Helper loaded: security_helper
INFO - 2023-05-29 15:53:11 --> Helper loaded: cookie_helper
INFO - 2023-05-29 15:53:11 --> Database Driver Class Initialized
INFO - 2023-05-29 15:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 15:53:11 --> Parser Class Initialized
INFO - 2023-05-29 15:53:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 15:53:11 --> Pagination Class Initialized
INFO - 2023-05-29 15:53:11 --> Form Validation Class Initialized
INFO - 2023-05-29 15:53:11 --> Controller Class Initialized
INFO - 2023-05-29 15:53:11 --> Model Class Initialized
DEBUG - 2023-05-29 15:53:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 15:53:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 15:53:11 --> Model Class Initialized
INFO - 2023-05-29 15:53:11 --> Final output sent to browser
DEBUG - 2023-05-29 15:53:11 --> Total execution time: 0.0237
ERROR - 2023-05-29 16:13:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:13:50 --> Config Class Initialized
INFO - 2023-05-29 16:13:50 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:13:50 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:13:50 --> Utf8 Class Initialized
INFO - 2023-05-29 16:13:50 --> URI Class Initialized
DEBUG - 2023-05-29 16:13:50 --> No URI present. Default controller set.
INFO - 2023-05-29 16:13:50 --> Router Class Initialized
INFO - 2023-05-29 16:13:50 --> Output Class Initialized
INFO - 2023-05-29 16:13:50 --> Security Class Initialized
DEBUG - 2023-05-29 16:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:13:50 --> Input Class Initialized
INFO - 2023-05-29 16:13:50 --> Language Class Initialized
INFO - 2023-05-29 16:13:50 --> Loader Class Initialized
INFO - 2023-05-29 16:13:50 --> Helper loaded: url_helper
INFO - 2023-05-29 16:13:50 --> Helper loaded: file_helper
INFO - 2023-05-29 16:13:50 --> Helper loaded: html_helper
INFO - 2023-05-29 16:13:50 --> Helper loaded: text_helper
INFO - 2023-05-29 16:13:50 --> Helper loaded: form_helper
INFO - 2023-05-29 16:13:50 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:13:50 --> Helper loaded: security_helper
INFO - 2023-05-29 16:13:50 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:13:50 --> Database Driver Class Initialized
INFO - 2023-05-29 16:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:13:50 --> Parser Class Initialized
INFO - 2023-05-29 16:13:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:13:50 --> Pagination Class Initialized
INFO - 2023-05-29 16:13:50 --> Form Validation Class Initialized
INFO - 2023-05-29 16:13:50 --> Controller Class Initialized
INFO - 2023-05-29 16:13:50 --> Model Class Initialized
DEBUG - 2023-05-29 16:13:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-29 16:13:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:13:50 --> Config Class Initialized
INFO - 2023-05-29 16:13:50 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:13:50 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:13:50 --> Utf8 Class Initialized
INFO - 2023-05-29 16:13:50 --> URI Class Initialized
INFO - 2023-05-29 16:13:50 --> Router Class Initialized
INFO - 2023-05-29 16:13:50 --> Output Class Initialized
INFO - 2023-05-29 16:13:50 --> Security Class Initialized
DEBUG - 2023-05-29 16:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:13:50 --> Input Class Initialized
INFO - 2023-05-29 16:13:50 --> Language Class Initialized
INFO - 2023-05-29 16:13:50 --> Loader Class Initialized
INFO - 2023-05-29 16:13:50 --> Helper loaded: url_helper
INFO - 2023-05-29 16:13:50 --> Helper loaded: file_helper
INFO - 2023-05-29 16:13:50 --> Helper loaded: html_helper
INFO - 2023-05-29 16:13:50 --> Helper loaded: text_helper
INFO - 2023-05-29 16:13:50 --> Helper loaded: form_helper
INFO - 2023-05-29 16:13:50 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:13:50 --> Helper loaded: security_helper
INFO - 2023-05-29 16:13:50 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:13:50 --> Database Driver Class Initialized
INFO - 2023-05-29 16:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:13:50 --> Parser Class Initialized
INFO - 2023-05-29 16:13:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:13:50 --> Pagination Class Initialized
INFO - 2023-05-29 16:13:50 --> Form Validation Class Initialized
INFO - 2023-05-29 16:13:50 --> Controller Class Initialized
INFO - 2023-05-29 16:13:50 --> Model Class Initialized
DEBUG - 2023-05-29 16:13:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:13:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-29 16:13:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:13:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 16:13:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 16:13:50 --> Model Class Initialized
INFO - 2023-05-29 16:13:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 16:13:50 --> Final output sent to browser
DEBUG - 2023-05-29 16:13:50 --> Total execution time: 0.0293
ERROR - 2023-05-29 16:13:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:13:53 --> Config Class Initialized
INFO - 2023-05-29 16:13:53 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:13:53 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:13:53 --> Utf8 Class Initialized
INFO - 2023-05-29 16:13:53 --> URI Class Initialized
INFO - 2023-05-29 16:13:53 --> Router Class Initialized
INFO - 2023-05-29 16:13:53 --> Output Class Initialized
INFO - 2023-05-29 16:13:53 --> Security Class Initialized
DEBUG - 2023-05-29 16:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:13:53 --> Input Class Initialized
INFO - 2023-05-29 16:13:53 --> Language Class Initialized
INFO - 2023-05-29 16:13:53 --> Loader Class Initialized
INFO - 2023-05-29 16:13:53 --> Helper loaded: url_helper
INFO - 2023-05-29 16:13:53 --> Helper loaded: file_helper
INFO - 2023-05-29 16:13:53 --> Helper loaded: html_helper
INFO - 2023-05-29 16:13:53 --> Helper loaded: text_helper
INFO - 2023-05-29 16:13:53 --> Helper loaded: form_helper
INFO - 2023-05-29 16:13:53 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:13:53 --> Helper loaded: security_helper
INFO - 2023-05-29 16:13:53 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:13:53 --> Database Driver Class Initialized
INFO - 2023-05-29 16:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:13:53 --> Parser Class Initialized
INFO - 2023-05-29 16:13:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:13:53 --> Pagination Class Initialized
INFO - 2023-05-29 16:13:53 --> Form Validation Class Initialized
INFO - 2023-05-29 16:13:53 --> Controller Class Initialized
INFO - 2023-05-29 16:13:53 --> Model Class Initialized
DEBUG - 2023-05-29 16:13:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:13:53 --> Model Class Initialized
INFO - 2023-05-29 16:13:53 --> Final output sent to browser
DEBUG - 2023-05-29 16:13:53 --> Total execution time: 0.0166
ERROR - 2023-05-29 16:13:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:13:54 --> Config Class Initialized
INFO - 2023-05-29 16:13:54 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:13:54 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:13:54 --> Utf8 Class Initialized
INFO - 2023-05-29 16:13:54 --> URI Class Initialized
DEBUG - 2023-05-29 16:13:54 --> No URI present. Default controller set.
INFO - 2023-05-29 16:13:54 --> Router Class Initialized
INFO - 2023-05-29 16:13:54 --> Output Class Initialized
INFO - 2023-05-29 16:13:54 --> Security Class Initialized
DEBUG - 2023-05-29 16:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:13:54 --> Input Class Initialized
INFO - 2023-05-29 16:13:54 --> Language Class Initialized
INFO - 2023-05-29 16:13:54 --> Loader Class Initialized
INFO - 2023-05-29 16:13:54 --> Helper loaded: url_helper
INFO - 2023-05-29 16:13:54 --> Helper loaded: file_helper
INFO - 2023-05-29 16:13:54 --> Helper loaded: html_helper
INFO - 2023-05-29 16:13:54 --> Helper loaded: text_helper
INFO - 2023-05-29 16:13:54 --> Helper loaded: form_helper
INFO - 2023-05-29 16:13:54 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:13:54 --> Helper loaded: security_helper
INFO - 2023-05-29 16:13:54 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:13:54 --> Database Driver Class Initialized
INFO - 2023-05-29 16:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:13:54 --> Parser Class Initialized
INFO - 2023-05-29 16:13:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:13:54 --> Pagination Class Initialized
INFO - 2023-05-29 16:13:54 --> Form Validation Class Initialized
INFO - 2023-05-29 16:13:54 --> Controller Class Initialized
INFO - 2023-05-29 16:13:54 --> Model Class Initialized
DEBUG - 2023-05-29 16:13:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:13:54 --> Model Class Initialized
DEBUG - 2023-05-29 16:13:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:13:54 --> Model Class Initialized
INFO - 2023-05-29 16:13:54 --> Model Class Initialized
INFO - 2023-05-29 16:13:54 --> Model Class Initialized
INFO - 2023-05-29 16:13:54 --> Model Class Initialized
DEBUG - 2023-05-29 16:13:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:13:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:13:54 --> Model Class Initialized
INFO - 2023-05-29 16:13:54 --> Model Class Initialized
INFO - 2023-05-29 16:13:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-29 16:13:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:13:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 16:13:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 16:13:54 --> Model Class Initialized
INFO - 2023-05-29 16:13:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-29 16:13:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-29 16:13:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 16:13:54 --> Final output sent to browser
DEBUG - 2023-05-29 16:13:54 --> Total execution time: 0.1586
ERROR - 2023-05-29 16:13:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:13:55 --> Config Class Initialized
INFO - 2023-05-29 16:13:55 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:13:55 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:13:55 --> Utf8 Class Initialized
INFO - 2023-05-29 16:13:55 --> URI Class Initialized
INFO - 2023-05-29 16:13:55 --> Router Class Initialized
INFO - 2023-05-29 16:13:55 --> Output Class Initialized
INFO - 2023-05-29 16:13:55 --> Security Class Initialized
DEBUG - 2023-05-29 16:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:13:55 --> Input Class Initialized
INFO - 2023-05-29 16:13:55 --> Language Class Initialized
INFO - 2023-05-29 16:13:55 --> Loader Class Initialized
INFO - 2023-05-29 16:13:55 --> Helper loaded: url_helper
INFO - 2023-05-29 16:13:55 --> Helper loaded: file_helper
INFO - 2023-05-29 16:13:55 --> Helper loaded: html_helper
INFO - 2023-05-29 16:13:55 --> Helper loaded: text_helper
INFO - 2023-05-29 16:13:55 --> Helper loaded: form_helper
INFO - 2023-05-29 16:13:55 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:13:55 --> Helper loaded: security_helper
INFO - 2023-05-29 16:13:55 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:13:55 --> Database Driver Class Initialized
INFO - 2023-05-29 16:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:13:55 --> Parser Class Initialized
INFO - 2023-05-29 16:13:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:13:55 --> Pagination Class Initialized
INFO - 2023-05-29 16:13:55 --> Form Validation Class Initialized
INFO - 2023-05-29 16:13:55 --> Controller Class Initialized
DEBUG - 2023-05-29 16:13:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:13:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:13:55 --> Model Class Initialized
INFO - 2023-05-29 16:13:55 --> Final output sent to browser
DEBUG - 2023-05-29 16:13:55 --> Total execution time: 0.0130
ERROR - 2023-05-29 16:14:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:14:13 --> Config Class Initialized
INFO - 2023-05-29 16:14:13 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:14:13 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:14:13 --> Utf8 Class Initialized
INFO - 2023-05-29 16:14:13 --> URI Class Initialized
INFO - 2023-05-29 16:14:13 --> Router Class Initialized
INFO - 2023-05-29 16:14:13 --> Output Class Initialized
INFO - 2023-05-29 16:14:13 --> Security Class Initialized
DEBUG - 2023-05-29 16:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:14:13 --> Input Class Initialized
INFO - 2023-05-29 16:14:13 --> Language Class Initialized
INFO - 2023-05-29 16:14:13 --> Loader Class Initialized
INFO - 2023-05-29 16:14:13 --> Helper loaded: url_helper
INFO - 2023-05-29 16:14:13 --> Helper loaded: file_helper
INFO - 2023-05-29 16:14:13 --> Helper loaded: html_helper
INFO - 2023-05-29 16:14:13 --> Helper loaded: text_helper
INFO - 2023-05-29 16:14:13 --> Helper loaded: form_helper
INFO - 2023-05-29 16:14:13 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:14:13 --> Helper loaded: security_helper
INFO - 2023-05-29 16:14:13 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:14:13 --> Database Driver Class Initialized
INFO - 2023-05-29 16:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:14:13 --> Parser Class Initialized
INFO - 2023-05-29 16:14:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:14:13 --> Pagination Class Initialized
INFO - 2023-05-29 16:14:13 --> Form Validation Class Initialized
INFO - 2023-05-29 16:14:13 --> Controller Class Initialized
INFO - 2023-05-29 16:14:13 --> Model Class Initialized
INFO - 2023-05-29 16:14:13 --> Model Class Initialized
INFO - 2023-05-29 16:14:13 --> Model Class Initialized
INFO - 2023-05-29 16:14:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report_batch_wise.php
DEBUG - 2023-05-29 16:14:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:14:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 16:14:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 16:14:13 --> Model Class Initialized
INFO - 2023-05-29 16:14:13 --> Model Class Initialized
INFO - 2023-05-29 16:14:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-29 16:14:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-29 16:14:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 16:14:13 --> Final output sent to browser
DEBUG - 2023-05-29 16:14:13 --> Total execution time: 0.1274
ERROR - 2023-05-29 16:14:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:14:14 --> Config Class Initialized
INFO - 2023-05-29 16:14:14 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:14:14 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:14:14 --> Utf8 Class Initialized
INFO - 2023-05-29 16:14:14 --> URI Class Initialized
INFO - 2023-05-29 16:14:14 --> Router Class Initialized
INFO - 2023-05-29 16:14:14 --> Output Class Initialized
INFO - 2023-05-29 16:14:14 --> Security Class Initialized
DEBUG - 2023-05-29 16:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:14:14 --> Input Class Initialized
INFO - 2023-05-29 16:14:14 --> Language Class Initialized
INFO - 2023-05-29 16:14:14 --> Loader Class Initialized
INFO - 2023-05-29 16:14:14 --> Helper loaded: url_helper
INFO - 2023-05-29 16:14:14 --> Helper loaded: file_helper
INFO - 2023-05-29 16:14:14 --> Helper loaded: html_helper
INFO - 2023-05-29 16:14:14 --> Helper loaded: text_helper
INFO - 2023-05-29 16:14:14 --> Helper loaded: form_helper
INFO - 2023-05-29 16:14:14 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:14:14 --> Helper loaded: security_helper
INFO - 2023-05-29 16:14:14 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:14:14 --> Database Driver Class Initialized
INFO - 2023-05-29 16:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:14:14 --> Parser Class Initialized
INFO - 2023-05-29 16:14:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:14:14 --> Pagination Class Initialized
INFO - 2023-05-29 16:14:14 --> Form Validation Class Initialized
INFO - 2023-05-29 16:14:14 --> Controller Class Initialized
INFO - 2023-05-29 16:14:14 --> Model Class Initialized
INFO - 2023-05-29 16:14:14 --> Model Class Initialized
INFO - 2023-05-29 16:14:14 --> Final output sent to browser
DEBUG - 2023-05-29 16:14:14 --> Total execution time: 0.0218
ERROR - 2023-05-29 16:14:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:14:18 --> Config Class Initialized
INFO - 2023-05-29 16:14:18 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:14:18 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:14:18 --> Utf8 Class Initialized
INFO - 2023-05-29 16:14:18 --> URI Class Initialized
INFO - 2023-05-29 16:14:18 --> Router Class Initialized
INFO - 2023-05-29 16:14:18 --> Output Class Initialized
INFO - 2023-05-29 16:14:18 --> Security Class Initialized
DEBUG - 2023-05-29 16:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:14:18 --> Input Class Initialized
INFO - 2023-05-29 16:14:18 --> Language Class Initialized
INFO - 2023-05-29 16:14:18 --> Loader Class Initialized
INFO - 2023-05-29 16:14:18 --> Helper loaded: url_helper
INFO - 2023-05-29 16:14:18 --> Helper loaded: file_helper
INFO - 2023-05-29 16:14:18 --> Helper loaded: html_helper
INFO - 2023-05-29 16:14:18 --> Helper loaded: text_helper
INFO - 2023-05-29 16:14:18 --> Helper loaded: form_helper
INFO - 2023-05-29 16:14:18 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:14:18 --> Helper loaded: security_helper
INFO - 2023-05-29 16:14:18 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:14:18 --> Database Driver Class Initialized
INFO - 2023-05-29 16:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:14:18 --> Parser Class Initialized
INFO - 2023-05-29 16:14:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:14:18 --> Pagination Class Initialized
INFO - 2023-05-29 16:14:18 --> Form Validation Class Initialized
INFO - 2023-05-29 16:14:18 --> Controller Class Initialized
INFO - 2023-05-29 16:14:18 --> Model Class Initialized
INFO - 2023-05-29 16:14:18 --> Model Class Initialized
INFO - 2023-05-29 16:14:18 --> Final output sent to browser
DEBUG - 2023-05-29 16:14:18 --> Total execution time: 0.0314
ERROR - 2023-05-29 16:16:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:16:06 --> Config Class Initialized
INFO - 2023-05-29 16:16:06 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:16:06 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:16:06 --> Utf8 Class Initialized
INFO - 2023-05-29 16:16:06 --> URI Class Initialized
DEBUG - 2023-05-29 16:16:06 --> No URI present. Default controller set.
INFO - 2023-05-29 16:16:06 --> Router Class Initialized
INFO - 2023-05-29 16:16:06 --> Output Class Initialized
INFO - 2023-05-29 16:16:06 --> Security Class Initialized
DEBUG - 2023-05-29 16:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:16:06 --> Input Class Initialized
INFO - 2023-05-29 16:16:06 --> Language Class Initialized
INFO - 2023-05-29 16:16:06 --> Loader Class Initialized
INFO - 2023-05-29 16:16:06 --> Helper loaded: url_helper
INFO - 2023-05-29 16:16:06 --> Helper loaded: file_helper
INFO - 2023-05-29 16:16:06 --> Helper loaded: html_helper
INFO - 2023-05-29 16:16:06 --> Helper loaded: text_helper
INFO - 2023-05-29 16:16:06 --> Helper loaded: form_helper
INFO - 2023-05-29 16:16:06 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:16:06 --> Helper loaded: security_helper
INFO - 2023-05-29 16:16:06 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:16:06 --> Database Driver Class Initialized
INFO - 2023-05-29 16:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:16:06 --> Parser Class Initialized
INFO - 2023-05-29 16:16:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:16:06 --> Pagination Class Initialized
INFO - 2023-05-29 16:16:06 --> Form Validation Class Initialized
INFO - 2023-05-29 16:16:06 --> Controller Class Initialized
INFO - 2023-05-29 16:16:06 --> Model Class Initialized
DEBUG - 2023-05-29 16:16:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:16:06 --> Model Class Initialized
DEBUG - 2023-05-29 16:16:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:16:06 --> Model Class Initialized
INFO - 2023-05-29 16:16:06 --> Model Class Initialized
INFO - 2023-05-29 16:16:06 --> Model Class Initialized
INFO - 2023-05-29 16:16:06 --> Model Class Initialized
DEBUG - 2023-05-29 16:16:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:16:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:16:06 --> Model Class Initialized
INFO - 2023-05-29 16:16:06 --> Model Class Initialized
INFO - 2023-05-29 16:16:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-29 16:16:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:16:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 16:16:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 16:16:06 --> Model Class Initialized
INFO - 2023-05-29 16:16:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-29 16:16:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-29 16:16:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 16:16:07 --> Final output sent to browser
DEBUG - 2023-05-29 16:16:07 --> Total execution time: 0.1760
ERROR - 2023-05-29 16:16:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:16:21 --> Config Class Initialized
INFO - 2023-05-29 16:16:21 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:16:21 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:16:21 --> Utf8 Class Initialized
INFO - 2023-05-29 16:16:21 --> URI Class Initialized
INFO - 2023-05-29 16:16:21 --> Router Class Initialized
INFO - 2023-05-29 16:16:21 --> Output Class Initialized
INFO - 2023-05-29 16:16:21 --> Security Class Initialized
DEBUG - 2023-05-29 16:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:16:21 --> Input Class Initialized
INFO - 2023-05-29 16:16:21 --> Language Class Initialized
INFO - 2023-05-29 16:16:21 --> Loader Class Initialized
INFO - 2023-05-29 16:16:21 --> Helper loaded: url_helper
INFO - 2023-05-29 16:16:21 --> Helper loaded: file_helper
INFO - 2023-05-29 16:16:21 --> Helper loaded: html_helper
INFO - 2023-05-29 16:16:21 --> Helper loaded: text_helper
INFO - 2023-05-29 16:16:21 --> Helper loaded: form_helper
INFO - 2023-05-29 16:16:21 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:16:21 --> Helper loaded: security_helper
INFO - 2023-05-29 16:16:21 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:16:21 --> Database Driver Class Initialized
INFO - 2023-05-29 16:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:16:21 --> Parser Class Initialized
INFO - 2023-05-29 16:16:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:16:21 --> Pagination Class Initialized
INFO - 2023-05-29 16:16:21 --> Form Validation Class Initialized
INFO - 2023-05-29 16:16:21 --> Controller Class Initialized
INFO - 2023-05-29 16:16:21 --> Model Class Initialized
DEBUG - 2023-05-29 16:16:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:16:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:16:21 --> Model Class Initialized
DEBUG - 2023-05-29 16:16:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:16:21 --> Model Class Initialized
INFO - 2023-05-29 16:16:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-05-29 16:16:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:16:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 16:16:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 16:16:21 --> Model Class Initialized
INFO - 2023-05-29 16:16:21 --> Model Class Initialized
INFO - 2023-05-29 16:16:21 --> Model Class Initialized
INFO - 2023-05-29 16:16:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-29 16:16:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-29 16:16:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 16:16:21 --> Final output sent to browser
DEBUG - 2023-05-29 16:16:21 --> Total execution time: 0.1648
ERROR - 2023-05-29 16:16:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:16:22 --> Config Class Initialized
INFO - 2023-05-29 16:16:22 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:16:22 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:16:22 --> Utf8 Class Initialized
INFO - 2023-05-29 16:16:22 --> URI Class Initialized
INFO - 2023-05-29 16:16:22 --> Router Class Initialized
INFO - 2023-05-29 16:16:22 --> Output Class Initialized
INFO - 2023-05-29 16:16:22 --> Security Class Initialized
DEBUG - 2023-05-29 16:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:16:22 --> Input Class Initialized
INFO - 2023-05-29 16:16:22 --> Language Class Initialized
INFO - 2023-05-29 16:16:22 --> Loader Class Initialized
INFO - 2023-05-29 16:16:22 --> Helper loaded: url_helper
INFO - 2023-05-29 16:16:22 --> Helper loaded: file_helper
INFO - 2023-05-29 16:16:22 --> Helper loaded: html_helper
INFO - 2023-05-29 16:16:22 --> Helper loaded: text_helper
INFO - 2023-05-29 16:16:22 --> Helper loaded: form_helper
INFO - 2023-05-29 16:16:22 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:16:22 --> Helper loaded: security_helper
INFO - 2023-05-29 16:16:22 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:16:22 --> Database Driver Class Initialized
INFO - 2023-05-29 16:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:16:22 --> Parser Class Initialized
INFO - 2023-05-29 16:16:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:16:22 --> Pagination Class Initialized
INFO - 2023-05-29 16:16:22 --> Form Validation Class Initialized
INFO - 2023-05-29 16:16:22 --> Controller Class Initialized
INFO - 2023-05-29 16:16:22 --> Model Class Initialized
DEBUG - 2023-05-29 16:16:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:16:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:16:22 --> Model Class Initialized
DEBUG - 2023-05-29 16:16:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:16:22 --> Model Class Initialized
INFO - 2023-05-29 16:16:22 --> Final output sent to browser
DEBUG - 2023-05-29 16:16:22 --> Total execution time: 0.0573
ERROR - 2023-05-29 16:16:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:16:29 --> Config Class Initialized
INFO - 2023-05-29 16:16:29 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:16:29 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:16:29 --> Utf8 Class Initialized
INFO - 2023-05-29 16:16:29 --> URI Class Initialized
INFO - 2023-05-29 16:16:29 --> Router Class Initialized
INFO - 2023-05-29 16:16:29 --> Output Class Initialized
INFO - 2023-05-29 16:16:29 --> Security Class Initialized
DEBUG - 2023-05-29 16:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:16:29 --> Input Class Initialized
INFO - 2023-05-29 16:16:29 --> Language Class Initialized
INFO - 2023-05-29 16:16:29 --> Loader Class Initialized
INFO - 2023-05-29 16:16:29 --> Helper loaded: url_helper
INFO - 2023-05-29 16:16:29 --> Helper loaded: file_helper
INFO - 2023-05-29 16:16:29 --> Helper loaded: html_helper
INFO - 2023-05-29 16:16:29 --> Helper loaded: text_helper
INFO - 2023-05-29 16:16:29 --> Helper loaded: form_helper
INFO - 2023-05-29 16:16:29 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:16:29 --> Helper loaded: security_helper
INFO - 2023-05-29 16:16:29 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:16:29 --> Database Driver Class Initialized
INFO - 2023-05-29 16:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:16:29 --> Parser Class Initialized
INFO - 2023-05-29 16:16:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:16:29 --> Pagination Class Initialized
INFO - 2023-05-29 16:16:29 --> Form Validation Class Initialized
INFO - 2023-05-29 16:16:29 --> Controller Class Initialized
INFO - 2023-05-29 16:16:29 --> Model Class Initialized
DEBUG - 2023-05-29 16:16:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:16:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:16:29 --> Model Class Initialized
DEBUG - 2023-05-29 16:16:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:16:29 --> Model Class Initialized
INFO - 2023-05-29 16:16:29 --> Final output sent to browser
DEBUG - 2023-05-29 16:16:29 --> Total execution time: 0.0518
ERROR - 2023-05-29 16:16:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:16:34 --> Config Class Initialized
INFO - 2023-05-29 16:16:34 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:16:34 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:16:34 --> Utf8 Class Initialized
INFO - 2023-05-29 16:16:34 --> URI Class Initialized
INFO - 2023-05-29 16:16:34 --> Router Class Initialized
INFO - 2023-05-29 16:16:34 --> Output Class Initialized
INFO - 2023-05-29 16:16:34 --> Security Class Initialized
DEBUG - 2023-05-29 16:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:16:34 --> Input Class Initialized
INFO - 2023-05-29 16:16:34 --> Language Class Initialized
INFO - 2023-05-29 16:16:34 --> Loader Class Initialized
INFO - 2023-05-29 16:16:34 --> Helper loaded: url_helper
INFO - 2023-05-29 16:16:34 --> Helper loaded: file_helper
INFO - 2023-05-29 16:16:34 --> Helper loaded: html_helper
INFO - 2023-05-29 16:16:34 --> Helper loaded: text_helper
INFO - 2023-05-29 16:16:34 --> Helper loaded: form_helper
INFO - 2023-05-29 16:16:34 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:16:34 --> Helper loaded: security_helper
INFO - 2023-05-29 16:16:34 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:16:34 --> Database Driver Class Initialized
INFO - 2023-05-29 16:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:16:34 --> Parser Class Initialized
INFO - 2023-05-29 16:16:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:16:34 --> Pagination Class Initialized
INFO - 2023-05-29 16:16:34 --> Form Validation Class Initialized
INFO - 2023-05-29 16:16:34 --> Controller Class Initialized
INFO - 2023-05-29 16:16:34 --> Model Class Initialized
DEBUG - 2023-05-29 16:16:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:16:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:16:34 --> Model Class Initialized
DEBUG - 2023-05-29 16:16:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:16:34 --> Model Class Initialized
INFO - 2023-05-29 16:16:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-05-29 16:16:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:16:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 16:16:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 16:16:34 --> Model Class Initialized
INFO - 2023-05-29 16:16:34 --> Model Class Initialized
INFO - 2023-05-29 16:16:34 --> Model Class Initialized
INFO - 2023-05-29 16:16:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-29 16:16:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-29 16:16:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 16:16:34 --> Final output sent to browser
DEBUG - 2023-05-29 16:16:34 --> Total execution time: 0.1254
ERROR - 2023-05-29 16:16:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:16:35 --> Config Class Initialized
INFO - 2023-05-29 16:16:35 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:16:35 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:16:35 --> Utf8 Class Initialized
INFO - 2023-05-29 16:16:35 --> URI Class Initialized
INFO - 2023-05-29 16:16:35 --> Router Class Initialized
INFO - 2023-05-29 16:16:35 --> Output Class Initialized
INFO - 2023-05-29 16:16:35 --> Security Class Initialized
DEBUG - 2023-05-29 16:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:16:35 --> Input Class Initialized
INFO - 2023-05-29 16:16:35 --> Language Class Initialized
INFO - 2023-05-29 16:16:35 --> Loader Class Initialized
INFO - 2023-05-29 16:16:35 --> Helper loaded: url_helper
INFO - 2023-05-29 16:16:35 --> Helper loaded: file_helper
INFO - 2023-05-29 16:16:35 --> Helper loaded: html_helper
INFO - 2023-05-29 16:16:35 --> Helper loaded: text_helper
INFO - 2023-05-29 16:16:35 --> Helper loaded: form_helper
INFO - 2023-05-29 16:16:35 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:16:35 --> Helper loaded: security_helper
INFO - 2023-05-29 16:16:35 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:16:35 --> Database Driver Class Initialized
INFO - 2023-05-29 16:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:16:35 --> Parser Class Initialized
INFO - 2023-05-29 16:16:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:16:35 --> Pagination Class Initialized
INFO - 2023-05-29 16:16:35 --> Form Validation Class Initialized
INFO - 2023-05-29 16:16:35 --> Controller Class Initialized
INFO - 2023-05-29 16:16:35 --> Model Class Initialized
DEBUG - 2023-05-29 16:16:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:16:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:16:35 --> Model Class Initialized
DEBUG - 2023-05-29 16:16:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:16:35 --> Model Class Initialized
INFO - 2023-05-29 16:16:35 --> Final output sent to browser
DEBUG - 2023-05-29 16:16:35 --> Total execution time: 0.0447
ERROR - 2023-05-29 16:16:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:16:36 --> Config Class Initialized
INFO - 2023-05-29 16:16:36 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:16:36 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:16:36 --> Utf8 Class Initialized
INFO - 2023-05-29 16:16:36 --> URI Class Initialized
DEBUG - 2023-05-29 16:16:36 --> No URI present. Default controller set.
INFO - 2023-05-29 16:16:36 --> Router Class Initialized
INFO - 2023-05-29 16:16:36 --> Output Class Initialized
INFO - 2023-05-29 16:16:36 --> Security Class Initialized
DEBUG - 2023-05-29 16:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:16:36 --> Input Class Initialized
INFO - 2023-05-29 16:16:36 --> Language Class Initialized
INFO - 2023-05-29 16:16:36 --> Loader Class Initialized
INFO - 2023-05-29 16:16:36 --> Helper loaded: url_helper
INFO - 2023-05-29 16:16:36 --> Helper loaded: file_helper
INFO - 2023-05-29 16:16:36 --> Helper loaded: html_helper
INFO - 2023-05-29 16:16:36 --> Helper loaded: text_helper
INFO - 2023-05-29 16:16:36 --> Helper loaded: form_helper
INFO - 2023-05-29 16:16:36 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:16:36 --> Helper loaded: security_helper
INFO - 2023-05-29 16:16:36 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:16:36 --> Database Driver Class Initialized
INFO - 2023-05-29 16:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:16:36 --> Parser Class Initialized
INFO - 2023-05-29 16:16:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:16:36 --> Pagination Class Initialized
INFO - 2023-05-29 16:16:36 --> Form Validation Class Initialized
INFO - 2023-05-29 16:16:36 --> Controller Class Initialized
INFO - 2023-05-29 16:16:36 --> Model Class Initialized
DEBUG - 2023-05-29 16:16:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:16:36 --> Model Class Initialized
DEBUG - 2023-05-29 16:16:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:16:36 --> Model Class Initialized
INFO - 2023-05-29 16:16:36 --> Model Class Initialized
INFO - 2023-05-29 16:16:36 --> Model Class Initialized
INFO - 2023-05-29 16:16:36 --> Model Class Initialized
DEBUG - 2023-05-29 16:16:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:16:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:16:36 --> Model Class Initialized
INFO - 2023-05-29 16:16:36 --> Model Class Initialized
INFO - 2023-05-29 16:16:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-29 16:16:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:16:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 16:16:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 16:16:36 --> Model Class Initialized
INFO - 2023-05-29 16:16:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-29 16:16:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-29 16:16:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 16:16:37 --> Final output sent to browser
DEBUG - 2023-05-29 16:16:37 --> Total execution time: 0.1745
ERROR - 2023-05-29 16:16:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:16:40 --> Config Class Initialized
INFO - 2023-05-29 16:16:40 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:16:40 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:16:40 --> Utf8 Class Initialized
INFO - 2023-05-29 16:16:40 --> URI Class Initialized
DEBUG - 2023-05-29 16:16:40 --> No URI present. Default controller set.
INFO - 2023-05-29 16:16:40 --> Router Class Initialized
INFO - 2023-05-29 16:16:40 --> Output Class Initialized
INFO - 2023-05-29 16:16:40 --> Security Class Initialized
DEBUG - 2023-05-29 16:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:16:40 --> Input Class Initialized
INFO - 2023-05-29 16:16:40 --> Language Class Initialized
INFO - 2023-05-29 16:16:40 --> Loader Class Initialized
INFO - 2023-05-29 16:16:40 --> Helper loaded: url_helper
INFO - 2023-05-29 16:16:40 --> Helper loaded: file_helper
INFO - 2023-05-29 16:16:40 --> Helper loaded: html_helper
INFO - 2023-05-29 16:16:40 --> Helper loaded: text_helper
INFO - 2023-05-29 16:16:40 --> Helper loaded: form_helper
INFO - 2023-05-29 16:16:40 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:16:40 --> Helper loaded: security_helper
INFO - 2023-05-29 16:16:40 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:16:40 --> Database Driver Class Initialized
INFO - 2023-05-29 16:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:16:40 --> Parser Class Initialized
INFO - 2023-05-29 16:16:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:16:40 --> Pagination Class Initialized
INFO - 2023-05-29 16:16:40 --> Form Validation Class Initialized
INFO - 2023-05-29 16:16:40 --> Controller Class Initialized
INFO - 2023-05-29 16:16:40 --> Model Class Initialized
DEBUG - 2023-05-29 16:16:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:16:40 --> Model Class Initialized
DEBUG - 2023-05-29 16:16:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:16:40 --> Model Class Initialized
INFO - 2023-05-29 16:16:40 --> Model Class Initialized
INFO - 2023-05-29 16:16:40 --> Model Class Initialized
INFO - 2023-05-29 16:16:40 --> Model Class Initialized
DEBUG - 2023-05-29 16:16:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:16:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:16:40 --> Model Class Initialized
INFO - 2023-05-29 16:16:40 --> Model Class Initialized
INFO - 2023-05-29 16:16:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-29 16:16:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:16:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 16:16:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 16:16:40 --> Model Class Initialized
INFO - 2023-05-29 16:16:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-29 16:16:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-29 16:16:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 16:16:40 --> Final output sent to browser
DEBUG - 2023-05-29 16:16:40 --> Total execution time: 0.1913
ERROR - 2023-05-29 16:17:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:17:24 --> Config Class Initialized
INFO - 2023-05-29 16:17:24 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:17:24 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:17:24 --> Utf8 Class Initialized
INFO - 2023-05-29 16:17:24 --> URI Class Initialized
INFO - 2023-05-29 16:17:24 --> Router Class Initialized
INFO - 2023-05-29 16:17:24 --> Output Class Initialized
INFO - 2023-05-29 16:17:24 --> Security Class Initialized
DEBUG - 2023-05-29 16:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:17:24 --> Input Class Initialized
INFO - 2023-05-29 16:17:24 --> Language Class Initialized
INFO - 2023-05-29 16:17:24 --> Loader Class Initialized
INFO - 2023-05-29 16:17:24 --> Helper loaded: url_helper
INFO - 2023-05-29 16:17:24 --> Helper loaded: file_helper
INFO - 2023-05-29 16:17:24 --> Helper loaded: html_helper
INFO - 2023-05-29 16:17:24 --> Helper loaded: text_helper
INFO - 2023-05-29 16:17:24 --> Helper loaded: form_helper
INFO - 2023-05-29 16:17:24 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:17:24 --> Helper loaded: security_helper
INFO - 2023-05-29 16:17:24 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:17:24 --> Database Driver Class Initialized
INFO - 2023-05-29 16:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:17:24 --> Parser Class Initialized
INFO - 2023-05-29 16:17:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:17:24 --> Pagination Class Initialized
INFO - 2023-05-29 16:17:24 --> Form Validation Class Initialized
INFO - 2023-05-29 16:17:24 --> Controller Class Initialized
DEBUG - 2023-05-29 16:17:24 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:17:24 --> Model Class Initialized
INFO - 2023-05-29 16:17:24 --> Model Class Initialized
INFO - 2023-05-29 16:17:24 --> Model Class Initialized
INFO - 2023-05-29 16:17:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product.php
DEBUG - 2023-05-29 16:17:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:17:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 16:17:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 16:17:24 --> Model Class Initialized
INFO - 2023-05-29 16:17:24 --> Model Class Initialized
INFO - 2023-05-29 16:17:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-29 16:17:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-29 16:17:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 16:17:24 --> Final output sent to browser
DEBUG - 2023-05-29 16:17:24 --> Total execution time: 0.1309
ERROR - 2023-05-29 16:17:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:17:25 --> Config Class Initialized
INFO - 2023-05-29 16:17:25 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:17:25 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:17:25 --> Utf8 Class Initialized
INFO - 2023-05-29 16:17:25 --> URI Class Initialized
INFO - 2023-05-29 16:17:25 --> Router Class Initialized
INFO - 2023-05-29 16:17:25 --> Output Class Initialized
INFO - 2023-05-29 16:17:25 --> Security Class Initialized
DEBUG - 2023-05-29 16:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:17:25 --> Input Class Initialized
INFO - 2023-05-29 16:17:25 --> Language Class Initialized
INFO - 2023-05-29 16:17:25 --> Loader Class Initialized
INFO - 2023-05-29 16:17:25 --> Helper loaded: url_helper
INFO - 2023-05-29 16:17:25 --> Helper loaded: file_helper
INFO - 2023-05-29 16:17:25 --> Helper loaded: html_helper
INFO - 2023-05-29 16:17:25 --> Helper loaded: text_helper
INFO - 2023-05-29 16:17:25 --> Helper loaded: form_helper
INFO - 2023-05-29 16:17:25 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:17:25 --> Helper loaded: security_helper
INFO - 2023-05-29 16:17:25 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:17:25 --> Database Driver Class Initialized
INFO - 2023-05-29 16:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:17:25 --> Parser Class Initialized
INFO - 2023-05-29 16:17:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:17:25 --> Pagination Class Initialized
INFO - 2023-05-29 16:17:25 --> Form Validation Class Initialized
INFO - 2023-05-29 16:17:25 --> Controller Class Initialized
DEBUG - 2023-05-29 16:17:25 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:17:25 --> Model Class Initialized
INFO - 2023-05-29 16:17:25 --> Model Class Initialized
INFO - 2023-05-29 16:17:25 --> Final output sent to browser
DEBUG - 2023-05-29 16:17:25 --> Total execution time: 0.0417
ERROR - 2023-05-29 16:17:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:17:30 --> Config Class Initialized
INFO - 2023-05-29 16:17:30 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:17:30 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:17:30 --> Utf8 Class Initialized
INFO - 2023-05-29 16:17:30 --> URI Class Initialized
INFO - 2023-05-29 16:17:30 --> Router Class Initialized
INFO - 2023-05-29 16:17:30 --> Output Class Initialized
INFO - 2023-05-29 16:17:30 --> Security Class Initialized
DEBUG - 2023-05-29 16:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:17:30 --> Input Class Initialized
INFO - 2023-05-29 16:17:30 --> Language Class Initialized
INFO - 2023-05-29 16:17:30 --> Loader Class Initialized
INFO - 2023-05-29 16:17:30 --> Helper loaded: url_helper
INFO - 2023-05-29 16:17:30 --> Helper loaded: file_helper
INFO - 2023-05-29 16:17:30 --> Helper loaded: html_helper
INFO - 2023-05-29 16:17:30 --> Helper loaded: text_helper
INFO - 2023-05-29 16:17:30 --> Helper loaded: form_helper
INFO - 2023-05-29 16:17:30 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:17:30 --> Helper loaded: security_helper
INFO - 2023-05-29 16:17:30 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:17:30 --> Database Driver Class Initialized
INFO - 2023-05-29 16:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:17:30 --> Parser Class Initialized
INFO - 2023-05-29 16:17:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:17:30 --> Pagination Class Initialized
INFO - 2023-05-29 16:17:30 --> Form Validation Class Initialized
INFO - 2023-05-29 16:17:30 --> Controller Class Initialized
DEBUG - 2023-05-29 16:17:30 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:17:30 --> Model Class Initialized
INFO - 2023-05-29 16:17:30 --> Model Class Initialized
INFO - 2023-05-29 16:17:30 --> Final output sent to browser
DEBUG - 2023-05-29 16:17:30 --> Total execution time: 0.1109
ERROR - 2023-05-29 16:19:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:19:00 --> Config Class Initialized
INFO - 2023-05-29 16:19:00 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:19:00 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:19:00 --> Utf8 Class Initialized
INFO - 2023-05-29 16:19:00 --> URI Class Initialized
INFO - 2023-05-29 16:19:00 --> Router Class Initialized
INFO - 2023-05-29 16:19:00 --> Output Class Initialized
INFO - 2023-05-29 16:19:00 --> Security Class Initialized
DEBUG - 2023-05-29 16:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:19:00 --> Input Class Initialized
INFO - 2023-05-29 16:19:00 --> Language Class Initialized
INFO - 2023-05-29 16:19:00 --> Loader Class Initialized
INFO - 2023-05-29 16:19:00 --> Helper loaded: url_helper
INFO - 2023-05-29 16:19:00 --> Helper loaded: file_helper
INFO - 2023-05-29 16:19:00 --> Helper loaded: html_helper
INFO - 2023-05-29 16:19:00 --> Helper loaded: text_helper
INFO - 2023-05-29 16:19:00 --> Helper loaded: form_helper
INFO - 2023-05-29 16:19:00 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:19:00 --> Helper loaded: security_helper
INFO - 2023-05-29 16:19:00 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:19:00 --> Database Driver Class Initialized
INFO - 2023-05-29 16:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:19:00 --> Parser Class Initialized
INFO - 2023-05-29 16:19:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:19:00 --> Pagination Class Initialized
INFO - 2023-05-29 16:19:00 --> Form Validation Class Initialized
INFO - 2023-05-29 16:19:00 --> Controller Class Initialized
DEBUG - 2023-05-29 16:19:00 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:19:00 --> Model Class Initialized
INFO - 2023-05-29 16:19:00 --> Model Class Initialized
INFO - 2023-05-29 16:19:00 --> Model Class Initialized
INFO - 2023-05-29 16:19:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/medicine_details.php
DEBUG - 2023-05-29 16:19:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:19:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 16:19:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 16:19:00 --> Model Class Initialized
INFO - 2023-05-29 16:19:00 --> Model Class Initialized
INFO - 2023-05-29 16:19:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-29 16:19:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-29 16:19:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 16:19:00 --> Final output sent to browser
DEBUG - 2023-05-29 16:19:00 --> Total execution time: 0.1293
ERROR - 2023-05-29 16:19:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:19:11 --> Config Class Initialized
INFO - 2023-05-29 16:19:11 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:19:11 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:19:11 --> Utf8 Class Initialized
ERROR - 2023-05-29 16:19:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:19:15 --> Config Class Initialized
INFO - 2023-05-29 16:19:15 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:19:15 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:19:15 --> Utf8 Class Initialized
INFO - 2023-05-29 16:19:15 --> URI Class Initialized
INFO - 2023-05-29 16:19:15 --> Router Class Initialized
INFO - 2023-05-29 16:19:15 --> Output Class Initialized
INFO - 2023-05-29 16:19:15 --> Security Class Initialized
DEBUG - 2023-05-29 16:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:19:15 --> Input Class Initialized
INFO - 2023-05-29 16:19:15 --> Language Class Initialized
INFO - 2023-05-29 16:19:15 --> Loader Class Initialized
INFO - 2023-05-29 16:19:15 --> Helper loaded: url_helper
INFO - 2023-05-29 16:19:15 --> Helper loaded: file_helper
INFO - 2023-05-29 16:19:15 --> Helper loaded: html_helper
INFO - 2023-05-29 16:19:15 --> Helper loaded: text_helper
INFO - 2023-05-29 16:19:15 --> Helper loaded: form_helper
INFO - 2023-05-29 16:19:15 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:19:15 --> Helper loaded: security_helper
INFO - 2023-05-29 16:19:15 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:19:15 --> Database Driver Class Initialized
INFO - 2023-05-29 16:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:19:15 --> Parser Class Initialized
INFO - 2023-05-29 16:19:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:19:15 --> Pagination Class Initialized
INFO - 2023-05-29 16:19:15 --> Form Validation Class Initialized
INFO - 2023-05-29 16:19:15 --> Controller Class Initialized
DEBUG - 2023-05-29 16:19:15 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:19:15 --> Model Class Initialized
INFO - 2023-05-29 16:19:15 --> Model Class Initialized
INFO - 2023-05-29 16:19:15 --> Model Class Initialized
INFO - 2023-05-29 16:19:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/medicine_details.php
DEBUG - 2023-05-29 16:19:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:19:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 16:19:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 16:19:15 --> Model Class Initialized
INFO - 2023-05-29 16:19:15 --> Model Class Initialized
INFO - 2023-05-29 16:19:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-29 16:19:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-29 16:19:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 16:19:15 --> Final output sent to browser
DEBUG - 2023-05-29 16:19:15 --> Total execution time: 0.1456
ERROR - 2023-05-29 16:19:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:19:20 --> Config Class Initialized
INFO - 2023-05-29 16:19:20 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:19:20 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:19:20 --> Utf8 Class Initialized
INFO - 2023-05-29 16:19:20 --> URI Class Initialized
INFO - 2023-05-29 16:19:20 --> Router Class Initialized
INFO - 2023-05-29 16:19:20 --> Output Class Initialized
INFO - 2023-05-29 16:19:20 --> Security Class Initialized
DEBUG - 2023-05-29 16:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:19:20 --> Input Class Initialized
INFO - 2023-05-29 16:19:20 --> Language Class Initialized
INFO - 2023-05-29 16:19:20 --> Loader Class Initialized
INFO - 2023-05-29 16:19:20 --> Helper loaded: url_helper
INFO - 2023-05-29 16:19:20 --> Helper loaded: file_helper
INFO - 2023-05-29 16:19:20 --> Helper loaded: html_helper
INFO - 2023-05-29 16:19:20 --> Helper loaded: text_helper
INFO - 2023-05-29 16:19:20 --> Helper loaded: form_helper
INFO - 2023-05-29 16:19:20 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:19:20 --> Helper loaded: security_helper
INFO - 2023-05-29 16:19:20 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:19:20 --> Database Driver Class Initialized
INFO - 2023-05-29 16:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:19:20 --> Parser Class Initialized
INFO - 2023-05-29 16:19:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:19:20 --> Pagination Class Initialized
INFO - 2023-05-29 16:19:20 --> Form Validation Class Initialized
INFO - 2023-05-29 16:19:20 --> Controller Class Initialized
DEBUG - 2023-05-29 16:19:20 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:19:20 --> Model Class Initialized
INFO - 2023-05-29 16:19:20 --> Model Class Initialized
INFO - 2023-05-29 16:19:20 --> Model Class Initialized
ERROR - 2023-05-29 16:19:20 --> Query error: Unknown column 'c.manufacturer_id' in 'where clause' - Invalid query: SELECT `a`.*, `d`.*
FROM `product_information` `a`
LEFT JOIN `manufacturer_information` `d` ON `d`.`manufacturer_id` = `a`.`manufacturer_id`
WHERE `c`.`manufacturer_id` = '2'
GROUP BY `a`.`product_id`
ORDER BY `a`.`product_id` DESC
ERROR - 2023-05-29 16:19:20 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/powera7m/app.maurnaturo.com/application/models/Products.php 640
ERROR - 2023-05-29 16:20:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:20:04 --> Config Class Initialized
INFO - 2023-05-29 16:20:04 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:20:04 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:20:04 --> Utf8 Class Initialized
INFO - 2023-05-29 16:20:04 --> URI Class Initialized
INFO - 2023-05-29 16:20:04 --> Router Class Initialized
INFO - 2023-05-29 16:20:04 --> Output Class Initialized
INFO - 2023-05-29 16:20:04 --> Security Class Initialized
DEBUG - 2023-05-29 16:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:20:04 --> Input Class Initialized
INFO - 2023-05-29 16:20:04 --> Language Class Initialized
INFO - 2023-05-29 16:20:04 --> Loader Class Initialized
INFO - 2023-05-29 16:20:04 --> Helper loaded: url_helper
INFO - 2023-05-29 16:20:04 --> Helper loaded: file_helper
INFO - 2023-05-29 16:20:04 --> Helper loaded: html_helper
INFO - 2023-05-29 16:20:04 --> Helper loaded: text_helper
INFO - 2023-05-29 16:20:04 --> Helper loaded: form_helper
INFO - 2023-05-29 16:20:04 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:20:04 --> Helper loaded: security_helper
INFO - 2023-05-29 16:20:04 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:20:04 --> Database Driver Class Initialized
INFO - 2023-05-29 16:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:20:04 --> Parser Class Initialized
INFO - 2023-05-29 16:20:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:20:04 --> Pagination Class Initialized
INFO - 2023-05-29 16:20:04 --> Form Validation Class Initialized
INFO - 2023-05-29 16:20:04 --> Controller Class Initialized
INFO - 2023-05-29 16:20:04 --> Model Class Initialized
DEBUG - 2023-05-29 16:20:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:20:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:20:04 --> Model Class Initialized
INFO - 2023-05-29 16:20:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-05-29 16:20:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:20:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 16:20:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 16:20:04 --> Model Class Initialized
INFO - 2023-05-29 16:20:04 --> Model Class Initialized
INFO - 2023-05-29 16:20:04 --> Model Class Initialized
INFO - 2023-05-29 16:20:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-29 16:20:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-29 16:20:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 16:20:04 --> Final output sent to browser
DEBUG - 2023-05-29 16:20:04 --> Total execution time: 0.0780
ERROR - 2023-05-29 16:20:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:20:05 --> Config Class Initialized
INFO - 2023-05-29 16:20:05 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:20:05 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:20:05 --> Utf8 Class Initialized
INFO - 2023-05-29 16:20:05 --> URI Class Initialized
INFO - 2023-05-29 16:20:05 --> Router Class Initialized
INFO - 2023-05-29 16:20:05 --> Output Class Initialized
INFO - 2023-05-29 16:20:05 --> Security Class Initialized
DEBUG - 2023-05-29 16:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:20:05 --> Input Class Initialized
INFO - 2023-05-29 16:20:05 --> Language Class Initialized
INFO - 2023-05-29 16:20:05 --> Loader Class Initialized
INFO - 2023-05-29 16:20:05 --> Helper loaded: url_helper
INFO - 2023-05-29 16:20:05 --> Helper loaded: file_helper
INFO - 2023-05-29 16:20:05 --> Helper loaded: html_helper
INFO - 2023-05-29 16:20:05 --> Helper loaded: text_helper
INFO - 2023-05-29 16:20:05 --> Helper loaded: form_helper
INFO - 2023-05-29 16:20:05 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:20:05 --> Helper loaded: security_helper
INFO - 2023-05-29 16:20:05 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:20:05 --> Database Driver Class Initialized
INFO - 2023-05-29 16:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:20:05 --> Parser Class Initialized
INFO - 2023-05-29 16:20:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:20:05 --> Pagination Class Initialized
INFO - 2023-05-29 16:20:05 --> Form Validation Class Initialized
INFO - 2023-05-29 16:20:05 --> Controller Class Initialized
INFO - 2023-05-29 16:20:05 --> Model Class Initialized
DEBUG - 2023-05-29 16:20:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:20:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:20:05 --> Model Class Initialized
INFO - 2023-05-29 16:20:05 --> Final output sent to browser
DEBUG - 2023-05-29 16:20:05 --> Total execution time: 0.0286
ERROR - 2023-05-29 16:20:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:20:09 --> Config Class Initialized
INFO - 2023-05-29 16:20:09 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:20:09 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:20:09 --> Utf8 Class Initialized
INFO - 2023-05-29 16:20:09 --> URI Class Initialized
INFO - 2023-05-29 16:20:09 --> Router Class Initialized
INFO - 2023-05-29 16:20:09 --> Output Class Initialized
INFO - 2023-05-29 16:20:09 --> Security Class Initialized
DEBUG - 2023-05-29 16:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:20:09 --> Input Class Initialized
INFO - 2023-05-29 16:20:09 --> Language Class Initialized
INFO - 2023-05-29 16:20:09 --> Loader Class Initialized
INFO - 2023-05-29 16:20:09 --> Helper loaded: url_helper
INFO - 2023-05-29 16:20:09 --> Helper loaded: file_helper
INFO - 2023-05-29 16:20:09 --> Helper loaded: html_helper
INFO - 2023-05-29 16:20:09 --> Helper loaded: text_helper
INFO - 2023-05-29 16:20:09 --> Helper loaded: form_helper
INFO - 2023-05-29 16:20:09 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:20:09 --> Helper loaded: security_helper
INFO - 2023-05-29 16:20:09 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:20:09 --> Database Driver Class Initialized
INFO - 2023-05-29 16:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:20:09 --> Parser Class Initialized
INFO - 2023-05-29 16:20:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:20:09 --> Pagination Class Initialized
INFO - 2023-05-29 16:20:09 --> Form Validation Class Initialized
INFO - 2023-05-29 16:20:09 --> Controller Class Initialized
INFO - 2023-05-29 16:20:09 --> Model Class Initialized
DEBUG - 2023-05-29 16:20:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:20:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:20:09 --> Model Class Initialized
INFO - 2023-05-29 16:20:09 --> Final output sent to browser
DEBUG - 2023-05-29 16:20:09 --> Total execution time: 0.0313
ERROR - 2023-05-29 16:20:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:20:14 --> Config Class Initialized
INFO - 2023-05-29 16:20:14 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:20:14 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:20:14 --> Utf8 Class Initialized
INFO - 2023-05-29 16:20:14 --> URI Class Initialized
DEBUG - 2023-05-29 16:20:14 --> No URI present. Default controller set.
INFO - 2023-05-29 16:20:14 --> Router Class Initialized
INFO - 2023-05-29 16:20:14 --> Output Class Initialized
INFO - 2023-05-29 16:20:14 --> Security Class Initialized
DEBUG - 2023-05-29 16:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:20:14 --> Input Class Initialized
INFO - 2023-05-29 16:20:14 --> Language Class Initialized
INFO - 2023-05-29 16:20:14 --> Loader Class Initialized
INFO - 2023-05-29 16:20:14 --> Helper loaded: url_helper
INFO - 2023-05-29 16:20:14 --> Helper loaded: file_helper
INFO - 2023-05-29 16:20:14 --> Helper loaded: html_helper
INFO - 2023-05-29 16:20:14 --> Helper loaded: text_helper
INFO - 2023-05-29 16:20:14 --> Helper loaded: form_helper
INFO - 2023-05-29 16:20:14 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:20:14 --> Helper loaded: security_helper
INFO - 2023-05-29 16:20:14 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:20:14 --> Database Driver Class Initialized
INFO - 2023-05-29 16:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:20:14 --> Parser Class Initialized
INFO - 2023-05-29 16:20:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:20:14 --> Pagination Class Initialized
INFO - 2023-05-29 16:20:14 --> Form Validation Class Initialized
INFO - 2023-05-29 16:20:14 --> Controller Class Initialized
INFO - 2023-05-29 16:20:14 --> Model Class Initialized
DEBUG - 2023-05-29 16:20:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:20:14 --> Model Class Initialized
DEBUG - 2023-05-29 16:20:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:20:14 --> Model Class Initialized
INFO - 2023-05-29 16:20:14 --> Model Class Initialized
INFO - 2023-05-29 16:20:14 --> Model Class Initialized
INFO - 2023-05-29 16:20:14 --> Model Class Initialized
DEBUG - 2023-05-29 16:20:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:20:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:20:14 --> Model Class Initialized
INFO - 2023-05-29 16:20:14 --> Model Class Initialized
INFO - 2023-05-29 16:20:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-29 16:20:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:20:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 16:20:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 16:20:14 --> Model Class Initialized
INFO - 2023-05-29 16:20:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-29 16:20:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-29 16:20:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 16:20:14 --> Final output sent to browser
DEBUG - 2023-05-29 16:20:14 --> Total execution time: 0.0768
ERROR - 2023-05-29 16:20:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:20:25 --> Config Class Initialized
INFO - 2023-05-29 16:20:25 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:20:25 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:20:25 --> Utf8 Class Initialized
INFO - 2023-05-29 16:20:25 --> URI Class Initialized
INFO - 2023-05-29 16:20:25 --> Router Class Initialized
INFO - 2023-05-29 16:20:25 --> Output Class Initialized
INFO - 2023-05-29 16:20:25 --> Security Class Initialized
DEBUG - 2023-05-29 16:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:20:25 --> Input Class Initialized
INFO - 2023-05-29 16:20:25 --> Language Class Initialized
INFO - 2023-05-29 16:20:25 --> Loader Class Initialized
INFO - 2023-05-29 16:20:25 --> Helper loaded: url_helper
INFO - 2023-05-29 16:20:25 --> Helper loaded: file_helper
INFO - 2023-05-29 16:20:25 --> Helper loaded: html_helper
INFO - 2023-05-29 16:20:25 --> Helper loaded: text_helper
INFO - 2023-05-29 16:20:25 --> Helper loaded: form_helper
INFO - 2023-05-29 16:20:25 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:20:25 --> Helper loaded: security_helper
INFO - 2023-05-29 16:20:25 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:20:25 --> Database Driver Class Initialized
INFO - 2023-05-29 16:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:20:25 --> Parser Class Initialized
INFO - 2023-05-29 16:20:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:20:25 --> Pagination Class Initialized
INFO - 2023-05-29 16:20:25 --> Form Validation Class Initialized
INFO - 2023-05-29 16:20:25 --> Controller Class Initialized
INFO - 2023-05-29 16:20:25 --> Model Class Initialized
DEBUG - 2023-05-29 16:20:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:20:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:20:25 --> Model Class Initialized
DEBUG - 2023-05-29 16:20:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:20:25 --> Model Class Initialized
INFO - 2023-05-29 16:20:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-29 16:20:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:20:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 16:20:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 16:20:25 --> Model Class Initialized
INFO - 2023-05-29 16:20:25 --> Model Class Initialized
INFO - 2023-05-29 16:20:25 --> Model Class Initialized
INFO - 2023-05-29 16:20:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-29 16:20:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-29 16:20:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 16:20:25 --> Final output sent to browser
DEBUG - 2023-05-29 16:20:25 --> Total execution time: 0.0686
ERROR - 2023-05-29 16:20:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:20:26 --> Config Class Initialized
INFO - 2023-05-29 16:20:26 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:20:26 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:20:26 --> Utf8 Class Initialized
INFO - 2023-05-29 16:20:26 --> URI Class Initialized
INFO - 2023-05-29 16:20:26 --> Router Class Initialized
INFO - 2023-05-29 16:20:26 --> Output Class Initialized
INFO - 2023-05-29 16:20:26 --> Security Class Initialized
DEBUG - 2023-05-29 16:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:20:26 --> Input Class Initialized
INFO - 2023-05-29 16:20:26 --> Language Class Initialized
INFO - 2023-05-29 16:20:26 --> Loader Class Initialized
INFO - 2023-05-29 16:20:26 --> Helper loaded: url_helper
INFO - 2023-05-29 16:20:26 --> Helper loaded: file_helper
INFO - 2023-05-29 16:20:26 --> Helper loaded: html_helper
INFO - 2023-05-29 16:20:26 --> Helper loaded: text_helper
INFO - 2023-05-29 16:20:26 --> Helper loaded: form_helper
INFO - 2023-05-29 16:20:26 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:20:26 --> Helper loaded: security_helper
INFO - 2023-05-29 16:20:26 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:20:26 --> Database Driver Class Initialized
INFO - 2023-05-29 16:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:20:26 --> Parser Class Initialized
INFO - 2023-05-29 16:20:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:20:26 --> Pagination Class Initialized
INFO - 2023-05-29 16:20:26 --> Form Validation Class Initialized
INFO - 2023-05-29 16:20:26 --> Controller Class Initialized
INFO - 2023-05-29 16:20:26 --> Model Class Initialized
DEBUG - 2023-05-29 16:20:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:20:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:20:26 --> Model Class Initialized
DEBUG - 2023-05-29 16:20:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:20:26 --> Model Class Initialized
INFO - 2023-05-29 16:20:26 --> Final output sent to browser
DEBUG - 2023-05-29 16:20:26 --> Total execution time: 0.0383
ERROR - 2023-05-29 16:20:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:20:30 --> Config Class Initialized
INFO - 2023-05-29 16:20:30 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:20:30 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:20:30 --> Utf8 Class Initialized
INFO - 2023-05-29 16:20:30 --> URI Class Initialized
DEBUG - 2023-05-29 16:20:30 --> No URI present. Default controller set.
INFO - 2023-05-29 16:20:30 --> Router Class Initialized
INFO - 2023-05-29 16:20:30 --> Output Class Initialized
INFO - 2023-05-29 16:20:30 --> Security Class Initialized
DEBUG - 2023-05-29 16:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:20:30 --> Input Class Initialized
INFO - 2023-05-29 16:20:30 --> Language Class Initialized
INFO - 2023-05-29 16:20:30 --> Loader Class Initialized
INFO - 2023-05-29 16:20:30 --> Helper loaded: url_helper
INFO - 2023-05-29 16:20:30 --> Helper loaded: file_helper
INFO - 2023-05-29 16:20:30 --> Helper loaded: html_helper
INFO - 2023-05-29 16:20:30 --> Helper loaded: text_helper
INFO - 2023-05-29 16:20:30 --> Helper loaded: form_helper
INFO - 2023-05-29 16:20:30 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:20:30 --> Helper loaded: security_helper
INFO - 2023-05-29 16:20:30 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:20:30 --> Database Driver Class Initialized
INFO - 2023-05-29 16:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:20:30 --> Parser Class Initialized
INFO - 2023-05-29 16:20:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:20:30 --> Pagination Class Initialized
INFO - 2023-05-29 16:20:30 --> Form Validation Class Initialized
INFO - 2023-05-29 16:20:30 --> Controller Class Initialized
INFO - 2023-05-29 16:20:30 --> Model Class Initialized
DEBUG - 2023-05-29 16:20:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:20:30 --> Model Class Initialized
DEBUG - 2023-05-29 16:20:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:20:30 --> Model Class Initialized
INFO - 2023-05-29 16:20:30 --> Model Class Initialized
INFO - 2023-05-29 16:20:30 --> Model Class Initialized
INFO - 2023-05-29 16:20:30 --> Model Class Initialized
DEBUG - 2023-05-29 16:20:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:20:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:20:30 --> Model Class Initialized
INFO - 2023-05-29 16:20:30 --> Model Class Initialized
INFO - 2023-05-29 16:20:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-29 16:20:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:20:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 16:20:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 16:20:30 --> Model Class Initialized
INFO - 2023-05-29 16:20:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-29 16:20:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-29 16:20:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 16:20:30 --> Final output sent to browser
DEBUG - 2023-05-29 16:20:30 --> Total execution time: 0.0696
ERROR - 2023-05-29 16:20:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:20:42 --> Config Class Initialized
INFO - 2023-05-29 16:20:42 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:20:42 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:20:42 --> Utf8 Class Initialized
INFO - 2023-05-29 16:20:42 --> URI Class Initialized
INFO - 2023-05-29 16:20:42 --> Router Class Initialized
INFO - 2023-05-29 16:20:42 --> Output Class Initialized
INFO - 2023-05-29 16:20:42 --> Security Class Initialized
DEBUG - 2023-05-29 16:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:20:42 --> Input Class Initialized
INFO - 2023-05-29 16:20:42 --> Language Class Initialized
INFO - 2023-05-29 16:20:42 --> Loader Class Initialized
INFO - 2023-05-29 16:20:42 --> Helper loaded: url_helper
INFO - 2023-05-29 16:20:42 --> Helper loaded: file_helper
INFO - 2023-05-29 16:20:42 --> Helper loaded: html_helper
INFO - 2023-05-29 16:20:42 --> Helper loaded: text_helper
INFO - 2023-05-29 16:20:42 --> Helper loaded: form_helper
INFO - 2023-05-29 16:20:42 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:20:42 --> Helper loaded: security_helper
INFO - 2023-05-29 16:20:42 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:20:42 --> Database Driver Class Initialized
INFO - 2023-05-29 16:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:20:42 --> Parser Class Initialized
INFO - 2023-05-29 16:20:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:20:42 --> Pagination Class Initialized
INFO - 2023-05-29 16:20:42 --> Form Validation Class Initialized
INFO - 2023-05-29 16:20:42 --> Controller Class Initialized
INFO - 2023-05-29 16:20:42 --> Model Class Initialized
DEBUG - 2023-05-29 16:20:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:20:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:20:42 --> Model Class Initialized
INFO - 2023-05-29 16:20:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-05-29 16:20:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:20:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 16:20:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 16:20:42 --> Model Class Initialized
INFO - 2023-05-29 16:20:42 --> Model Class Initialized
INFO - 2023-05-29 16:20:42 --> Model Class Initialized
INFO - 2023-05-29 16:20:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-29 16:20:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-29 16:20:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 16:20:42 --> Final output sent to browser
DEBUG - 2023-05-29 16:20:42 --> Total execution time: 0.0661
ERROR - 2023-05-29 16:20:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:20:43 --> Config Class Initialized
INFO - 2023-05-29 16:20:43 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:20:43 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:20:43 --> Utf8 Class Initialized
INFO - 2023-05-29 16:20:43 --> URI Class Initialized
INFO - 2023-05-29 16:20:43 --> Router Class Initialized
INFO - 2023-05-29 16:20:43 --> Output Class Initialized
INFO - 2023-05-29 16:20:43 --> Security Class Initialized
DEBUG - 2023-05-29 16:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:20:43 --> Input Class Initialized
INFO - 2023-05-29 16:20:43 --> Language Class Initialized
INFO - 2023-05-29 16:20:43 --> Loader Class Initialized
INFO - 2023-05-29 16:20:43 --> Helper loaded: url_helper
INFO - 2023-05-29 16:20:43 --> Helper loaded: file_helper
INFO - 2023-05-29 16:20:43 --> Helper loaded: html_helper
INFO - 2023-05-29 16:20:43 --> Helper loaded: text_helper
INFO - 2023-05-29 16:20:43 --> Helper loaded: form_helper
INFO - 2023-05-29 16:20:43 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:20:43 --> Helper loaded: security_helper
INFO - 2023-05-29 16:20:43 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:20:43 --> Database Driver Class Initialized
INFO - 2023-05-29 16:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:20:43 --> Parser Class Initialized
INFO - 2023-05-29 16:20:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:20:43 --> Pagination Class Initialized
INFO - 2023-05-29 16:20:43 --> Form Validation Class Initialized
INFO - 2023-05-29 16:20:43 --> Controller Class Initialized
INFO - 2023-05-29 16:20:43 --> Model Class Initialized
DEBUG - 2023-05-29 16:20:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:20:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:20:43 --> Model Class Initialized
INFO - 2023-05-29 16:20:43 --> Final output sent to browser
DEBUG - 2023-05-29 16:20:43 --> Total execution time: 0.0268
ERROR - 2023-05-29 16:20:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:20:47 --> Config Class Initialized
INFO - 2023-05-29 16:20:47 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:20:47 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:20:47 --> Utf8 Class Initialized
INFO - 2023-05-29 16:20:47 --> URI Class Initialized
INFO - 2023-05-29 16:20:47 --> Router Class Initialized
INFO - 2023-05-29 16:20:47 --> Output Class Initialized
INFO - 2023-05-29 16:20:47 --> Security Class Initialized
DEBUG - 2023-05-29 16:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:20:47 --> Input Class Initialized
INFO - 2023-05-29 16:20:47 --> Language Class Initialized
INFO - 2023-05-29 16:20:47 --> Loader Class Initialized
INFO - 2023-05-29 16:20:47 --> Helper loaded: url_helper
INFO - 2023-05-29 16:20:47 --> Helper loaded: file_helper
INFO - 2023-05-29 16:20:47 --> Helper loaded: html_helper
INFO - 2023-05-29 16:20:47 --> Helper loaded: text_helper
INFO - 2023-05-29 16:20:47 --> Helper loaded: form_helper
INFO - 2023-05-29 16:20:47 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:20:47 --> Helper loaded: security_helper
INFO - 2023-05-29 16:20:47 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:20:47 --> Database Driver Class Initialized
INFO - 2023-05-29 16:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:20:47 --> Parser Class Initialized
INFO - 2023-05-29 16:20:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:20:47 --> Pagination Class Initialized
INFO - 2023-05-29 16:20:47 --> Form Validation Class Initialized
INFO - 2023-05-29 16:20:47 --> Controller Class Initialized
INFO - 2023-05-29 16:20:47 --> Model Class Initialized
DEBUG - 2023-05-29 16:20:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:20:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:20:47 --> Model Class Initialized
INFO - 2023-05-29 16:20:47 --> Final output sent to browser
DEBUG - 2023-05-29 16:20:47 --> Total execution time: 0.0213
ERROR - 2023-05-29 16:21:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:21:11 --> Config Class Initialized
INFO - 2023-05-29 16:21:11 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:21:11 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:21:11 --> Utf8 Class Initialized
INFO - 2023-05-29 16:21:11 --> URI Class Initialized
DEBUG - 2023-05-29 16:21:11 --> No URI present. Default controller set.
INFO - 2023-05-29 16:21:11 --> Router Class Initialized
INFO - 2023-05-29 16:21:11 --> Output Class Initialized
INFO - 2023-05-29 16:21:11 --> Security Class Initialized
DEBUG - 2023-05-29 16:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:21:11 --> Input Class Initialized
INFO - 2023-05-29 16:21:11 --> Language Class Initialized
INFO - 2023-05-29 16:21:11 --> Loader Class Initialized
INFO - 2023-05-29 16:21:11 --> Helper loaded: url_helper
INFO - 2023-05-29 16:21:11 --> Helper loaded: file_helper
INFO - 2023-05-29 16:21:11 --> Helper loaded: html_helper
INFO - 2023-05-29 16:21:11 --> Helper loaded: text_helper
INFO - 2023-05-29 16:21:11 --> Helper loaded: form_helper
INFO - 2023-05-29 16:21:11 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:21:11 --> Helper loaded: security_helper
INFO - 2023-05-29 16:21:11 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:21:11 --> Database Driver Class Initialized
INFO - 2023-05-29 16:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:21:11 --> Parser Class Initialized
INFO - 2023-05-29 16:21:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:21:11 --> Pagination Class Initialized
INFO - 2023-05-29 16:21:11 --> Form Validation Class Initialized
INFO - 2023-05-29 16:21:11 --> Controller Class Initialized
INFO - 2023-05-29 16:21:11 --> Model Class Initialized
DEBUG - 2023-05-29 16:21:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:21:11 --> Model Class Initialized
DEBUG - 2023-05-29 16:21:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:21:11 --> Model Class Initialized
INFO - 2023-05-29 16:21:11 --> Model Class Initialized
INFO - 2023-05-29 16:21:11 --> Model Class Initialized
INFO - 2023-05-29 16:21:11 --> Model Class Initialized
DEBUG - 2023-05-29 16:21:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:21:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:21:11 --> Model Class Initialized
INFO - 2023-05-29 16:21:11 --> Model Class Initialized
INFO - 2023-05-29 16:21:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-29 16:21:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:21:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 16:21:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 16:21:11 --> Model Class Initialized
INFO - 2023-05-29 16:21:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-29 16:21:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-29 16:21:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 16:21:11 --> Final output sent to browser
DEBUG - 2023-05-29 16:21:11 --> Total execution time: 0.1755
ERROR - 2023-05-29 16:21:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:21:20 --> Config Class Initialized
INFO - 2023-05-29 16:21:20 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:21:20 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:21:20 --> Utf8 Class Initialized
INFO - 2023-05-29 16:21:20 --> URI Class Initialized
INFO - 2023-05-29 16:21:20 --> Router Class Initialized
INFO - 2023-05-29 16:21:20 --> Output Class Initialized
INFO - 2023-05-29 16:21:20 --> Security Class Initialized
DEBUG - 2023-05-29 16:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:21:20 --> Input Class Initialized
INFO - 2023-05-29 16:21:20 --> Language Class Initialized
INFO - 2023-05-29 16:21:20 --> Loader Class Initialized
INFO - 2023-05-29 16:21:20 --> Helper loaded: url_helper
INFO - 2023-05-29 16:21:20 --> Helper loaded: file_helper
INFO - 2023-05-29 16:21:20 --> Helper loaded: html_helper
INFO - 2023-05-29 16:21:20 --> Helper loaded: text_helper
INFO - 2023-05-29 16:21:20 --> Helper loaded: form_helper
INFO - 2023-05-29 16:21:20 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:21:20 --> Helper loaded: security_helper
INFO - 2023-05-29 16:21:20 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:21:20 --> Database Driver Class Initialized
INFO - 2023-05-29 16:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:21:20 --> Parser Class Initialized
INFO - 2023-05-29 16:21:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:21:20 --> Pagination Class Initialized
INFO - 2023-05-29 16:21:20 --> Form Validation Class Initialized
INFO - 2023-05-29 16:21:20 --> Controller Class Initialized
DEBUG - 2023-05-29 16:21:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:21:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:21:20 --> Model Class Initialized
DEBUG - 2023-05-29 16:21:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:21:20 --> Model Class Initialized
DEBUG - 2023-05-29 16:21:20 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:21:20 --> Model Class Initialized
INFO - 2023-05-29 16:21:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-05-29 16:21:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:21:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 16:21:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 16:21:20 --> Model Class Initialized
INFO - 2023-05-29 16:21:20 --> Model Class Initialized
INFO - 2023-05-29 16:21:20 --> Model Class Initialized
INFO - 2023-05-29 16:21:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-29 16:21:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-29 16:21:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 16:21:20 --> Final output sent to browser
DEBUG - 2023-05-29 16:21:20 --> Total execution time: 0.1307
ERROR - 2023-05-29 16:21:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:21:21 --> Config Class Initialized
INFO - 2023-05-29 16:21:21 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:21:21 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:21:21 --> Utf8 Class Initialized
INFO - 2023-05-29 16:21:21 --> URI Class Initialized
INFO - 2023-05-29 16:21:21 --> Router Class Initialized
INFO - 2023-05-29 16:21:21 --> Output Class Initialized
INFO - 2023-05-29 16:21:21 --> Security Class Initialized
DEBUG - 2023-05-29 16:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:21:21 --> Input Class Initialized
INFO - 2023-05-29 16:21:21 --> Language Class Initialized
INFO - 2023-05-29 16:21:21 --> Loader Class Initialized
INFO - 2023-05-29 16:21:21 --> Helper loaded: url_helper
INFO - 2023-05-29 16:21:21 --> Helper loaded: file_helper
INFO - 2023-05-29 16:21:21 --> Helper loaded: html_helper
INFO - 2023-05-29 16:21:21 --> Helper loaded: text_helper
INFO - 2023-05-29 16:21:21 --> Helper loaded: form_helper
INFO - 2023-05-29 16:21:21 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:21:21 --> Helper loaded: security_helper
INFO - 2023-05-29 16:21:21 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:21:21 --> Database Driver Class Initialized
INFO - 2023-05-29 16:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:21:21 --> Parser Class Initialized
INFO - 2023-05-29 16:21:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:21:21 --> Pagination Class Initialized
INFO - 2023-05-29 16:21:21 --> Form Validation Class Initialized
INFO - 2023-05-29 16:21:21 --> Controller Class Initialized
DEBUG - 2023-05-29 16:21:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:21:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:21:21 --> Model Class Initialized
DEBUG - 2023-05-29 16:21:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:21:21 --> Model Class Initialized
INFO - 2023-05-29 16:21:21 --> Final output sent to browser
DEBUG - 2023-05-29 16:21:21 --> Total execution time: 0.0319
ERROR - 2023-05-29 16:21:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:21:25 --> Config Class Initialized
INFO - 2023-05-29 16:21:25 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:21:25 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:21:25 --> Utf8 Class Initialized
INFO - 2023-05-29 16:21:25 --> URI Class Initialized
INFO - 2023-05-29 16:21:25 --> Router Class Initialized
INFO - 2023-05-29 16:21:25 --> Output Class Initialized
INFO - 2023-05-29 16:21:25 --> Security Class Initialized
DEBUG - 2023-05-29 16:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:21:25 --> Input Class Initialized
INFO - 2023-05-29 16:21:25 --> Language Class Initialized
INFO - 2023-05-29 16:21:25 --> Loader Class Initialized
INFO - 2023-05-29 16:21:25 --> Helper loaded: url_helper
INFO - 2023-05-29 16:21:25 --> Helper loaded: file_helper
INFO - 2023-05-29 16:21:25 --> Helper loaded: html_helper
INFO - 2023-05-29 16:21:25 --> Helper loaded: text_helper
INFO - 2023-05-29 16:21:25 --> Helper loaded: form_helper
INFO - 2023-05-29 16:21:25 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:21:25 --> Helper loaded: security_helper
INFO - 2023-05-29 16:21:25 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:21:25 --> Database Driver Class Initialized
INFO - 2023-05-29 16:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:21:25 --> Parser Class Initialized
INFO - 2023-05-29 16:21:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:21:25 --> Pagination Class Initialized
INFO - 2023-05-29 16:21:25 --> Form Validation Class Initialized
INFO - 2023-05-29 16:21:25 --> Controller Class Initialized
DEBUG - 2023-05-29 16:21:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:21:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:21:25 --> Model Class Initialized
DEBUG - 2023-05-29 16:21:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:21:25 --> Model Class Initialized
INFO - 2023-05-29 16:21:25 --> Final output sent to browser
DEBUG - 2023-05-29 16:21:25 --> Total execution time: 0.0877
ERROR - 2023-05-29 16:21:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:21:37 --> Config Class Initialized
INFO - 2023-05-29 16:21:37 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:21:37 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:21:37 --> Utf8 Class Initialized
INFO - 2023-05-29 16:21:37 --> URI Class Initialized
INFO - 2023-05-29 16:21:37 --> Router Class Initialized
INFO - 2023-05-29 16:21:37 --> Output Class Initialized
INFO - 2023-05-29 16:21:37 --> Security Class Initialized
DEBUG - 2023-05-29 16:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:21:37 --> Input Class Initialized
INFO - 2023-05-29 16:21:37 --> Language Class Initialized
INFO - 2023-05-29 16:21:37 --> Loader Class Initialized
INFO - 2023-05-29 16:21:37 --> Helper loaded: url_helper
INFO - 2023-05-29 16:21:37 --> Helper loaded: file_helper
INFO - 2023-05-29 16:21:37 --> Helper loaded: html_helper
INFO - 2023-05-29 16:21:37 --> Helper loaded: text_helper
INFO - 2023-05-29 16:21:37 --> Helper loaded: form_helper
INFO - 2023-05-29 16:21:37 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:21:37 --> Helper loaded: security_helper
INFO - 2023-05-29 16:21:37 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:21:37 --> Database Driver Class Initialized
INFO - 2023-05-29 16:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:21:37 --> Parser Class Initialized
INFO - 2023-05-29 16:21:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:21:37 --> Pagination Class Initialized
INFO - 2023-05-29 16:21:37 --> Form Validation Class Initialized
INFO - 2023-05-29 16:21:37 --> Controller Class Initialized
DEBUG - 2023-05-29 16:21:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:21:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:21:37 --> Model Class Initialized
DEBUG - 2023-05-29 16:21:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:21:37 --> Model Class Initialized
INFO - 2023-05-29 16:21:37 --> Final output sent to browser
DEBUG - 2023-05-29 16:21:37 --> Total execution time: 0.0617
ERROR - 2023-05-29 16:21:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:21:50 --> Config Class Initialized
INFO - 2023-05-29 16:21:50 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:21:50 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:21:50 --> Utf8 Class Initialized
INFO - 2023-05-29 16:21:50 --> URI Class Initialized
INFO - 2023-05-29 16:21:50 --> Router Class Initialized
INFO - 2023-05-29 16:21:50 --> Output Class Initialized
INFO - 2023-05-29 16:21:50 --> Security Class Initialized
DEBUG - 2023-05-29 16:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:21:50 --> Input Class Initialized
INFO - 2023-05-29 16:21:50 --> Language Class Initialized
INFO - 2023-05-29 16:21:50 --> Loader Class Initialized
INFO - 2023-05-29 16:21:50 --> Helper loaded: url_helper
INFO - 2023-05-29 16:21:50 --> Helper loaded: file_helper
INFO - 2023-05-29 16:21:50 --> Helper loaded: html_helper
INFO - 2023-05-29 16:21:50 --> Helper loaded: text_helper
INFO - 2023-05-29 16:21:50 --> Helper loaded: form_helper
INFO - 2023-05-29 16:21:50 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:21:50 --> Helper loaded: security_helper
INFO - 2023-05-29 16:21:50 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:21:50 --> Database Driver Class Initialized
INFO - 2023-05-29 16:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:21:50 --> Parser Class Initialized
INFO - 2023-05-29 16:21:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:21:50 --> Pagination Class Initialized
INFO - 2023-05-29 16:21:50 --> Form Validation Class Initialized
INFO - 2023-05-29 16:21:50 --> Controller Class Initialized
DEBUG - 2023-05-29 16:21:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:21:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:21:50 --> Model Class Initialized
DEBUG - 2023-05-29 16:21:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:21:50 --> Model Class Initialized
INFO - 2023-05-29 16:21:50 --> Final output sent to browser
DEBUG - 2023-05-29 16:21:50 --> Total execution time: 0.0465
ERROR - 2023-05-29 16:22:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:22:42 --> Config Class Initialized
INFO - 2023-05-29 16:22:42 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:22:42 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:22:42 --> Utf8 Class Initialized
INFO - 2023-05-29 16:22:42 --> URI Class Initialized
INFO - 2023-05-29 16:22:42 --> Router Class Initialized
INFO - 2023-05-29 16:22:42 --> Output Class Initialized
INFO - 2023-05-29 16:22:42 --> Security Class Initialized
DEBUG - 2023-05-29 16:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:22:42 --> Input Class Initialized
INFO - 2023-05-29 16:22:42 --> Language Class Initialized
INFO - 2023-05-29 16:22:42 --> Loader Class Initialized
INFO - 2023-05-29 16:22:42 --> Helper loaded: url_helper
INFO - 2023-05-29 16:22:42 --> Helper loaded: file_helper
INFO - 2023-05-29 16:22:42 --> Helper loaded: html_helper
INFO - 2023-05-29 16:22:42 --> Helper loaded: text_helper
INFO - 2023-05-29 16:22:42 --> Helper loaded: form_helper
INFO - 2023-05-29 16:22:42 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:22:42 --> Helper loaded: security_helper
INFO - 2023-05-29 16:22:42 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:22:42 --> Database Driver Class Initialized
INFO - 2023-05-29 16:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:22:42 --> Parser Class Initialized
INFO - 2023-05-29 16:22:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:22:42 --> Pagination Class Initialized
INFO - 2023-05-29 16:22:42 --> Form Validation Class Initialized
INFO - 2023-05-29 16:22:42 --> Controller Class Initialized
DEBUG - 2023-05-29 16:22:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:22:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:22:42 --> Model Class Initialized
DEBUG - 2023-05-29 16:22:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:22:42 --> Model Class Initialized
INFO - 2023-05-29 16:22:42 --> Final output sent to browser
DEBUG - 2023-05-29 16:22:42 --> Total execution time: 0.0673
ERROR - 2023-05-29 16:22:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:22:57 --> Config Class Initialized
INFO - 2023-05-29 16:22:57 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:22:57 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:22:57 --> Utf8 Class Initialized
INFO - 2023-05-29 16:22:57 --> URI Class Initialized
INFO - 2023-05-29 16:22:57 --> Router Class Initialized
INFO - 2023-05-29 16:22:57 --> Output Class Initialized
INFO - 2023-05-29 16:22:57 --> Security Class Initialized
DEBUG - 2023-05-29 16:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:22:57 --> Input Class Initialized
INFO - 2023-05-29 16:22:57 --> Language Class Initialized
INFO - 2023-05-29 16:22:57 --> Loader Class Initialized
INFO - 2023-05-29 16:22:57 --> Helper loaded: url_helper
INFO - 2023-05-29 16:22:57 --> Helper loaded: file_helper
INFO - 2023-05-29 16:22:57 --> Helper loaded: html_helper
INFO - 2023-05-29 16:22:57 --> Helper loaded: text_helper
INFO - 2023-05-29 16:22:57 --> Helper loaded: form_helper
INFO - 2023-05-29 16:22:57 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:22:57 --> Helper loaded: security_helper
INFO - 2023-05-29 16:22:57 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:22:57 --> Database Driver Class Initialized
INFO - 2023-05-29 16:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:22:57 --> Parser Class Initialized
INFO - 2023-05-29 16:22:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:22:57 --> Pagination Class Initialized
INFO - 2023-05-29 16:22:57 --> Form Validation Class Initialized
INFO - 2023-05-29 16:22:57 --> Controller Class Initialized
DEBUG - 2023-05-29 16:22:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:22:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:22:57 --> Model Class Initialized
DEBUG - 2023-05-29 16:22:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:22:57 --> Model Class Initialized
INFO - 2023-05-29 16:22:57 --> Final output sent to browser
DEBUG - 2023-05-29 16:22:57 --> Total execution time: 0.0654
ERROR - 2023-05-29 16:23:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:23:07 --> Config Class Initialized
INFO - 2023-05-29 16:23:07 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:23:07 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:23:07 --> Utf8 Class Initialized
INFO - 2023-05-29 16:23:07 --> URI Class Initialized
INFO - 2023-05-29 16:23:07 --> Router Class Initialized
INFO - 2023-05-29 16:23:07 --> Output Class Initialized
INFO - 2023-05-29 16:23:07 --> Security Class Initialized
DEBUG - 2023-05-29 16:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:23:07 --> Input Class Initialized
INFO - 2023-05-29 16:23:07 --> Language Class Initialized
INFO - 2023-05-29 16:23:07 --> Loader Class Initialized
INFO - 2023-05-29 16:23:07 --> Helper loaded: url_helper
INFO - 2023-05-29 16:23:07 --> Helper loaded: file_helper
INFO - 2023-05-29 16:23:07 --> Helper loaded: html_helper
INFO - 2023-05-29 16:23:07 --> Helper loaded: text_helper
INFO - 2023-05-29 16:23:07 --> Helper loaded: form_helper
INFO - 2023-05-29 16:23:07 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:23:07 --> Helper loaded: security_helper
INFO - 2023-05-29 16:23:07 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:23:07 --> Database Driver Class Initialized
INFO - 2023-05-29 16:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:23:07 --> Parser Class Initialized
INFO - 2023-05-29 16:23:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:23:07 --> Pagination Class Initialized
INFO - 2023-05-29 16:23:07 --> Form Validation Class Initialized
INFO - 2023-05-29 16:23:07 --> Controller Class Initialized
DEBUG - 2023-05-29 16:23:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:23:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:23:07 --> Model Class Initialized
DEBUG - 2023-05-29 16:23:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:23:07 --> Model Class Initialized
INFO - 2023-05-29 16:23:07 --> Final output sent to browser
DEBUG - 2023-05-29 16:23:07 --> Total execution time: 0.0476
ERROR - 2023-05-29 16:23:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:23:09 --> Config Class Initialized
INFO - 2023-05-29 16:23:09 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:23:09 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:23:09 --> Utf8 Class Initialized
INFO - 2023-05-29 16:23:09 --> URI Class Initialized
INFO - 2023-05-29 16:23:09 --> Router Class Initialized
INFO - 2023-05-29 16:23:09 --> Output Class Initialized
INFO - 2023-05-29 16:23:09 --> Security Class Initialized
DEBUG - 2023-05-29 16:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:23:09 --> Input Class Initialized
INFO - 2023-05-29 16:23:09 --> Language Class Initialized
INFO - 2023-05-29 16:23:09 --> Loader Class Initialized
INFO - 2023-05-29 16:23:09 --> Helper loaded: url_helper
INFO - 2023-05-29 16:23:09 --> Helper loaded: file_helper
INFO - 2023-05-29 16:23:09 --> Helper loaded: html_helper
INFO - 2023-05-29 16:23:09 --> Helper loaded: text_helper
INFO - 2023-05-29 16:23:09 --> Helper loaded: form_helper
INFO - 2023-05-29 16:23:09 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:23:09 --> Helper loaded: security_helper
INFO - 2023-05-29 16:23:09 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:23:09 --> Database Driver Class Initialized
INFO - 2023-05-29 16:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:23:09 --> Parser Class Initialized
INFO - 2023-05-29 16:23:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:23:09 --> Pagination Class Initialized
INFO - 2023-05-29 16:23:09 --> Form Validation Class Initialized
INFO - 2023-05-29 16:23:09 --> Controller Class Initialized
DEBUG - 2023-05-29 16:23:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:23:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:23:09 --> Model Class Initialized
DEBUG - 2023-05-29 16:23:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:23:09 --> Model Class Initialized
INFO - 2023-05-29 16:23:09 --> Final output sent to browser
DEBUG - 2023-05-29 16:23:09 --> Total execution time: 0.0481
ERROR - 2023-05-29 16:23:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:23:17 --> Config Class Initialized
INFO - 2023-05-29 16:23:17 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:23:17 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:23:17 --> Utf8 Class Initialized
INFO - 2023-05-29 16:23:17 --> URI Class Initialized
INFO - 2023-05-29 16:23:17 --> Router Class Initialized
INFO - 2023-05-29 16:23:17 --> Output Class Initialized
INFO - 2023-05-29 16:23:17 --> Security Class Initialized
DEBUG - 2023-05-29 16:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:23:17 --> Input Class Initialized
INFO - 2023-05-29 16:23:17 --> Language Class Initialized
INFO - 2023-05-29 16:23:17 --> Loader Class Initialized
INFO - 2023-05-29 16:23:17 --> Helper loaded: url_helper
INFO - 2023-05-29 16:23:17 --> Helper loaded: file_helper
INFO - 2023-05-29 16:23:17 --> Helper loaded: html_helper
INFO - 2023-05-29 16:23:17 --> Helper loaded: text_helper
INFO - 2023-05-29 16:23:17 --> Helper loaded: form_helper
INFO - 2023-05-29 16:23:17 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:23:17 --> Helper loaded: security_helper
INFO - 2023-05-29 16:23:17 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:23:17 --> Database Driver Class Initialized
INFO - 2023-05-29 16:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:23:17 --> Parser Class Initialized
INFO - 2023-05-29 16:23:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:23:17 --> Pagination Class Initialized
INFO - 2023-05-29 16:23:17 --> Form Validation Class Initialized
INFO - 2023-05-29 16:23:17 --> Controller Class Initialized
DEBUG - 2023-05-29 16:23:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:23:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:23:17 --> Model Class Initialized
DEBUG - 2023-05-29 16:23:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:23:17 --> Model Class Initialized
INFO - 2023-05-29 16:23:17 --> Final output sent to browser
DEBUG - 2023-05-29 16:23:17 --> Total execution time: 0.0621
ERROR - 2023-05-29 16:24:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:24:41 --> Config Class Initialized
INFO - 2023-05-29 16:24:41 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:24:41 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:24:41 --> Utf8 Class Initialized
INFO - 2023-05-29 16:24:41 --> URI Class Initialized
INFO - 2023-05-29 16:24:41 --> Router Class Initialized
INFO - 2023-05-29 16:24:41 --> Output Class Initialized
INFO - 2023-05-29 16:24:41 --> Security Class Initialized
DEBUG - 2023-05-29 16:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:24:41 --> Input Class Initialized
INFO - 2023-05-29 16:24:41 --> Language Class Initialized
INFO - 2023-05-29 16:24:41 --> Loader Class Initialized
INFO - 2023-05-29 16:24:41 --> Helper loaded: url_helper
INFO - 2023-05-29 16:24:41 --> Helper loaded: file_helper
INFO - 2023-05-29 16:24:41 --> Helper loaded: html_helper
INFO - 2023-05-29 16:24:41 --> Helper loaded: text_helper
INFO - 2023-05-29 16:24:41 --> Helper loaded: form_helper
INFO - 2023-05-29 16:24:41 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:24:41 --> Helper loaded: security_helper
INFO - 2023-05-29 16:24:41 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:24:41 --> Database Driver Class Initialized
INFO - 2023-05-29 16:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:24:41 --> Parser Class Initialized
INFO - 2023-05-29 16:24:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:24:41 --> Pagination Class Initialized
INFO - 2023-05-29 16:24:41 --> Form Validation Class Initialized
INFO - 2023-05-29 16:24:41 --> Controller Class Initialized
INFO - 2023-05-29 16:24:41 --> Model Class Initialized
DEBUG - 2023-05-29 16:24:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:24:41 --> Model Class Initialized
INFO - 2023-05-29 16:24:41 --> Model Class Initialized
INFO - 2023-05-29 22:24:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/profit_product_report.php
DEBUG - 2023-05-29 22:24:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 22:24:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 22:24:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 22:24:41 --> Model Class Initialized
INFO - 2023-05-29 22:24:41 --> Model Class Initialized
INFO - 2023-05-29 22:24:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-29 22:24:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-29 22:24:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 22:24:41 --> Final output sent to browser
DEBUG - 2023-05-29 22:24:41 --> Total execution time: 0.1343
ERROR - 2023-05-29 16:24:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:24:46 --> Config Class Initialized
INFO - 2023-05-29 16:24:46 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:24:46 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:24:46 --> Utf8 Class Initialized
INFO - 2023-05-29 16:24:46 --> URI Class Initialized
INFO - 2023-05-29 16:24:46 --> Router Class Initialized
INFO - 2023-05-29 16:24:46 --> Output Class Initialized
INFO - 2023-05-29 16:24:46 --> Security Class Initialized
DEBUG - 2023-05-29 16:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:24:46 --> Input Class Initialized
INFO - 2023-05-29 16:24:46 --> Language Class Initialized
INFO - 2023-05-29 16:24:46 --> Loader Class Initialized
INFO - 2023-05-29 16:24:46 --> Helper loaded: url_helper
INFO - 2023-05-29 16:24:46 --> Helper loaded: file_helper
INFO - 2023-05-29 16:24:46 --> Helper loaded: html_helper
INFO - 2023-05-29 16:24:46 --> Helper loaded: text_helper
INFO - 2023-05-29 16:24:46 --> Helper loaded: form_helper
INFO - 2023-05-29 16:24:46 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:24:46 --> Helper loaded: security_helper
INFO - 2023-05-29 16:24:46 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:24:46 --> Database Driver Class Initialized
INFO - 2023-05-29 16:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:24:46 --> Parser Class Initialized
INFO - 2023-05-29 16:24:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:24:46 --> Pagination Class Initialized
INFO - 2023-05-29 16:24:46 --> Form Validation Class Initialized
INFO - 2023-05-29 16:24:46 --> Controller Class Initialized
INFO - 2023-05-29 16:24:46 --> Model Class Initialized
DEBUG - 2023-05-29 16:24:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:24:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:24:46 --> Model Class Initialized
DEBUG - 2023-05-29 16:24:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:24:46 --> Model Class Initialized
INFO - 2023-05-29 16:24:46 --> Final output sent to browser
DEBUG - 2023-05-29 16:24:46 --> Total execution time: 0.0185
ERROR - 2023-05-29 16:24:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:24:47 --> Config Class Initialized
INFO - 2023-05-29 16:24:47 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:24:47 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:24:47 --> Utf8 Class Initialized
INFO - 2023-05-29 16:24:47 --> URI Class Initialized
INFO - 2023-05-29 16:24:47 --> Router Class Initialized
INFO - 2023-05-29 16:24:47 --> Output Class Initialized
INFO - 2023-05-29 16:24:47 --> Security Class Initialized
DEBUG - 2023-05-29 16:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:24:47 --> Input Class Initialized
INFO - 2023-05-29 16:24:47 --> Language Class Initialized
INFO - 2023-05-29 16:24:47 --> Loader Class Initialized
INFO - 2023-05-29 16:24:47 --> Helper loaded: url_helper
INFO - 2023-05-29 16:24:47 --> Helper loaded: file_helper
INFO - 2023-05-29 16:24:47 --> Helper loaded: html_helper
INFO - 2023-05-29 16:24:47 --> Helper loaded: text_helper
INFO - 2023-05-29 16:24:47 --> Helper loaded: form_helper
INFO - 2023-05-29 16:24:47 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:24:47 --> Helper loaded: security_helper
INFO - 2023-05-29 16:24:47 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:24:47 --> Database Driver Class Initialized
INFO - 2023-05-29 16:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:24:47 --> Parser Class Initialized
INFO - 2023-05-29 16:24:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:24:47 --> Pagination Class Initialized
INFO - 2023-05-29 16:24:47 --> Form Validation Class Initialized
INFO - 2023-05-29 16:24:47 --> Controller Class Initialized
INFO - 2023-05-29 16:24:47 --> Model Class Initialized
DEBUG - 2023-05-29 16:24:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:24:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:24:47 --> Model Class Initialized
DEBUG - 2023-05-29 16:24:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:24:47 --> Model Class Initialized
INFO - 2023-05-29 16:24:47 --> Final output sent to browser
DEBUG - 2023-05-29 16:24:47 --> Total execution time: 0.0183
ERROR - 2023-05-29 16:24:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:24:47 --> Config Class Initialized
INFO - 2023-05-29 16:24:47 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:24:47 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:24:47 --> Utf8 Class Initialized
INFO - 2023-05-29 16:24:47 --> URI Class Initialized
INFO - 2023-05-29 16:24:47 --> Router Class Initialized
INFO - 2023-05-29 16:24:47 --> Output Class Initialized
INFO - 2023-05-29 16:24:47 --> Security Class Initialized
DEBUG - 2023-05-29 16:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:24:47 --> Input Class Initialized
INFO - 2023-05-29 16:24:47 --> Language Class Initialized
INFO - 2023-05-29 16:24:47 --> Loader Class Initialized
INFO - 2023-05-29 16:24:47 --> Helper loaded: url_helper
INFO - 2023-05-29 16:24:47 --> Helper loaded: file_helper
INFO - 2023-05-29 16:24:47 --> Helper loaded: html_helper
INFO - 2023-05-29 16:24:47 --> Helper loaded: text_helper
INFO - 2023-05-29 16:24:47 --> Helper loaded: form_helper
INFO - 2023-05-29 16:24:47 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:24:47 --> Helper loaded: security_helper
INFO - 2023-05-29 16:24:47 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:24:47 --> Database Driver Class Initialized
INFO - 2023-05-29 16:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:24:47 --> Parser Class Initialized
INFO - 2023-05-29 16:24:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:24:47 --> Pagination Class Initialized
INFO - 2023-05-29 16:24:47 --> Form Validation Class Initialized
INFO - 2023-05-29 16:24:47 --> Controller Class Initialized
INFO - 2023-05-29 16:24:47 --> Model Class Initialized
DEBUG - 2023-05-29 16:24:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:24:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:24:47 --> Model Class Initialized
DEBUG - 2023-05-29 16:24:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:24:47 --> Model Class Initialized
INFO - 2023-05-29 16:24:47 --> Final output sent to browser
DEBUG - 2023-05-29 16:24:47 --> Total execution time: 0.0165
ERROR - 2023-05-29 16:24:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:24:48 --> Config Class Initialized
INFO - 2023-05-29 16:24:48 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:24:48 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:24:48 --> Utf8 Class Initialized
INFO - 2023-05-29 16:24:48 --> URI Class Initialized
INFO - 2023-05-29 16:24:48 --> Router Class Initialized
INFO - 2023-05-29 16:24:48 --> Output Class Initialized
INFO - 2023-05-29 16:24:48 --> Security Class Initialized
DEBUG - 2023-05-29 16:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:24:48 --> Input Class Initialized
INFO - 2023-05-29 16:24:48 --> Language Class Initialized
INFO - 2023-05-29 16:24:48 --> Loader Class Initialized
INFO - 2023-05-29 16:24:48 --> Helper loaded: url_helper
INFO - 2023-05-29 16:24:48 --> Helper loaded: file_helper
INFO - 2023-05-29 16:24:48 --> Helper loaded: html_helper
INFO - 2023-05-29 16:24:48 --> Helper loaded: text_helper
INFO - 2023-05-29 16:24:48 --> Helper loaded: form_helper
INFO - 2023-05-29 16:24:48 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:24:48 --> Helper loaded: security_helper
INFO - 2023-05-29 16:24:48 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:24:48 --> Database Driver Class Initialized
INFO - 2023-05-29 16:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:24:48 --> Parser Class Initialized
INFO - 2023-05-29 16:24:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:24:48 --> Pagination Class Initialized
INFO - 2023-05-29 16:24:48 --> Form Validation Class Initialized
INFO - 2023-05-29 16:24:48 --> Controller Class Initialized
INFO - 2023-05-29 16:24:48 --> Model Class Initialized
DEBUG - 2023-05-29 16:24:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:24:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:24:48 --> Model Class Initialized
DEBUG - 2023-05-29 16:24:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:24:48 --> Model Class Initialized
INFO - 2023-05-29 16:24:48 --> Final output sent to browser
DEBUG - 2023-05-29 16:24:48 --> Total execution time: 0.0168
ERROR - 2023-05-29 16:24:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:24:58 --> Config Class Initialized
INFO - 2023-05-29 16:24:58 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:24:58 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:24:58 --> Utf8 Class Initialized
INFO - 2023-05-29 16:24:58 --> URI Class Initialized
INFO - 2023-05-29 16:24:58 --> Router Class Initialized
INFO - 2023-05-29 16:24:58 --> Output Class Initialized
INFO - 2023-05-29 16:24:58 --> Security Class Initialized
DEBUG - 2023-05-29 16:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:24:58 --> Input Class Initialized
INFO - 2023-05-29 16:24:58 --> Language Class Initialized
INFO - 2023-05-29 16:24:58 --> Loader Class Initialized
INFO - 2023-05-29 16:24:58 --> Helper loaded: url_helper
INFO - 2023-05-29 16:24:58 --> Helper loaded: file_helper
INFO - 2023-05-29 16:24:58 --> Helper loaded: html_helper
INFO - 2023-05-29 16:24:58 --> Helper loaded: text_helper
INFO - 2023-05-29 16:24:58 --> Helper loaded: form_helper
INFO - 2023-05-29 16:24:58 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:24:58 --> Helper loaded: security_helper
INFO - 2023-05-29 16:24:58 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:24:58 --> Database Driver Class Initialized
INFO - 2023-05-29 16:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:24:58 --> Parser Class Initialized
INFO - 2023-05-29 16:24:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:24:58 --> Pagination Class Initialized
INFO - 2023-05-29 16:24:58 --> Form Validation Class Initialized
INFO - 2023-05-29 16:24:58 --> Controller Class Initialized
INFO - 2023-05-29 16:24:58 --> Model Class Initialized
DEBUG - 2023-05-29 16:24:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:24:58 --> Model Class Initialized
INFO - 2023-05-29 16:24:58 --> Model Class Initialized
INFO - 2023-05-29 22:24:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/productwise_profit_view.php
DEBUG - 2023-05-29 22:24:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 22:24:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 22:24:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 22:24:58 --> Model Class Initialized
INFO - 2023-05-29 22:24:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-29 22:24:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-29 22:24:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 22:24:58 --> Final output sent to browser
DEBUG - 2023-05-29 22:24:58 --> Total execution time: 0.1419
ERROR - 2023-05-29 16:25:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:25:35 --> Config Class Initialized
INFO - 2023-05-29 16:25:35 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:25:35 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:25:35 --> Utf8 Class Initialized
INFO - 2023-05-29 16:25:35 --> URI Class Initialized
DEBUG - 2023-05-29 16:25:35 --> No URI present. Default controller set.
INFO - 2023-05-29 16:25:35 --> Router Class Initialized
INFO - 2023-05-29 16:25:35 --> Output Class Initialized
INFO - 2023-05-29 16:25:35 --> Security Class Initialized
DEBUG - 2023-05-29 16:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:25:35 --> Input Class Initialized
INFO - 2023-05-29 16:25:35 --> Language Class Initialized
INFO - 2023-05-29 16:25:35 --> Loader Class Initialized
INFO - 2023-05-29 16:25:35 --> Helper loaded: url_helper
INFO - 2023-05-29 16:25:35 --> Helper loaded: file_helper
INFO - 2023-05-29 16:25:35 --> Helper loaded: html_helper
INFO - 2023-05-29 16:25:35 --> Helper loaded: text_helper
INFO - 2023-05-29 16:25:35 --> Helper loaded: form_helper
INFO - 2023-05-29 16:25:35 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:25:35 --> Helper loaded: security_helper
INFO - 2023-05-29 16:25:35 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:25:35 --> Database Driver Class Initialized
INFO - 2023-05-29 16:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:25:35 --> Parser Class Initialized
INFO - 2023-05-29 16:25:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:25:35 --> Pagination Class Initialized
INFO - 2023-05-29 16:25:35 --> Form Validation Class Initialized
INFO - 2023-05-29 16:25:35 --> Controller Class Initialized
INFO - 2023-05-29 16:25:35 --> Model Class Initialized
DEBUG - 2023-05-29 16:25:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:25:35 --> Model Class Initialized
DEBUG - 2023-05-29 16:25:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:25:35 --> Model Class Initialized
INFO - 2023-05-29 16:25:35 --> Model Class Initialized
INFO - 2023-05-29 16:25:35 --> Model Class Initialized
INFO - 2023-05-29 16:25:35 --> Model Class Initialized
DEBUG - 2023-05-29 16:25:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:25:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:25:35 --> Model Class Initialized
INFO - 2023-05-29 16:25:35 --> Model Class Initialized
INFO - 2023-05-29 16:25:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-29 16:25:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:25:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 16:25:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 16:25:35 --> Model Class Initialized
INFO - 2023-05-29 16:25:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-29 16:25:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-29 16:25:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 16:25:35 --> Final output sent to browser
DEBUG - 2023-05-29 16:25:35 --> Total execution time: 0.1649
ERROR - 2023-05-29 16:25:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:25:46 --> Config Class Initialized
INFO - 2023-05-29 16:25:46 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:25:46 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:25:46 --> Utf8 Class Initialized
INFO - 2023-05-29 16:25:46 --> URI Class Initialized
DEBUG - 2023-05-29 16:25:46 --> No URI present. Default controller set.
INFO - 2023-05-29 16:25:46 --> Router Class Initialized
INFO - 2023-05-29 16:25:46 --> Output Class Initialized
INFO - 2023-05-29 16:25:46 --> Security Class Initialized
DEBUG - 2023-05-29 16:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:25:46 --> Input Class Initialized
INFO - 2023-05-29 16:25:46 --> Language Class Initialized
INFO - 2023-05-29 16:25:46 --> Loader Class Initialized
INFO - 2023-05-29 16:25:46 --> Helper loaded: url_helper
INFO - 2023-05-29 16:25:46 --> Helper loaded: file_helper
INFO - 2023-05-29 16:25:46 --> Helper loaded: html_helper
INFO - 2023-05-29 16:25:46 --> Helper loaded: text_helper
INFO - 2023-05-29 16:25:46 --> Helper loaded: form_helper
INFO - 2023-05-29 16:25:46 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:25:46 --> Helper loaded: security_helper
INFO - 2023-05-29 16:25:46 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:25:46 --> Database Driver Class Initialized
INFO - 2023-05-29 16:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:25:46 --> Parser Class Initialized
INFO - 2023-05-29 16:25:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:25:46 --> Pagination Class Initialized
INFO - 2023-05-29 16:25:46 --> Form Validation Class Initialized
INFO - 2023-05-29 16:25:46 --> Controller Class Initialized
INFO - 2023-05-29 16:25:46 --> Model Class Initialized
DEBUG - 2023-05-29 16:25:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:25:46 --> Model Class Initialized
DEBUG - 2023-05-29 16:25:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:25:46 --> Model Class Initialized
INFO - 2023-05-29 16:25:46 --> Model Class Initialized
INFO - 2023-05-29 16:25:46 --> Model Class Initialized
INFO - 2023-05-29 16:25:46 --> Model Class Initialized
DEBUG - 2023-05-29 16:25:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:25:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:25:46 --> Model Class Initialized
INFO - 2023-05-29 16:25:46 --> Model Class Initialized
INFO - 2023-05-29 16:25:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-29 16:25:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:25:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 16:25:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 16:25:46 --> Model Class Initialized
INFO - 2023-05-29 16:25:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-29 16:25:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-29 16:25:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 16:25:46 --> Final output sent to browser
DEBUG - 2023-05-29 16:25:46 --> Total execution time: 0.1686
ERROR - 2023-05-29 16:25:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:25:56 --> Config Class Initialized
INFO - 2023-05-29 16:25:56 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:25:56 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:25:56 --> Utf8 Class Initialized
INFO - 2023-05-29 16:25:56 --> URI Class Initialized
INFO - 2023-05-29 16:25:56 --> Router Class Initialized
INFO - 2023-05-29 16:25:56 --> Output Class Initialized
INFO - 2023-05-29 16:25:56 --> Security Class Initialized
DEBUG - 2023-05-29 16:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:25:56 --> Input Class Initialized
INFO - 2023-05-29 16:25:56 --> Language Class Initialized
INFO - 2023-05-29 16:25:56 --> Loader Class Initialized
INFO - 2023-05-29 16:25:56 --> Helper loaded: url_helper
INFO - 2023-05-29 16:25:56 --> Helper loaded: file_helper
INFO - 2023-05-29 16:25:56 --> Helper loaded: html_helper
INFO - 2023-05-29 16:25:56 --> Helper loaded: text_helper
INFO - 2023-05-29 16:25:56 --> Helper loaded: form_helper
INFO - 2023-05-29 16:25:56 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:25:56 --> Helper loaded: security_helper
INFO - 2023-05-29 16:25:56 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:25:56 --> Database Driver Class Initialized
INFO - 2023-05-29 16:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:25:56 --> Parser Class Initialized
INFO - 2023-05-29 16:25:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:25:56 --> Pagination Class Initialized
INFO - 2023-05-29 16:25:56 --> Form Validation Class Initialized
INFO - 2023-05-29 16:25:56 --> Controller Class Initialized
INFO - 2023-05-29 16:25:56 --> Model Class Initialized
DEBUG - 2023-05-29 16:25:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:25:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:25:56 --> Model Class Initialized
DEBUG - 2023-05-29 16:25:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:25:56 --> Model Class Initialized
INFO - 2023-05-29 16:25:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-05-29 16:25:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:25:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 16:25:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 16:25:56 --> Model Class Initialized
INFO - 2023-05-29 16:25:56 --> Model Class Initialized
INFO - 2023-05-29 16:25:56 --> Model Class Initialized
INFO - 2023-05-29 16:25:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-29 16:25:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-29 16:25:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 16:25:56 --> Final output sent to browser
DEBUG - 2023-05-29 16:25:56 --> Total execution time: 0.1272
ERROR - 2023-05-29 16:25:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:25:57 --> Config Class Initialized
INFO - 2023-05-29 16:25:57 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:25:57 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:25:57 --> Utf8 Class Initialized
INFO - 2023-05-29 16:25:57 --> URI Class Initialized
INFO - 2023-05-29 16:25:57 --> Router Class Initialized
INFO - 2023-05-29 16:25:57 --> Output Class Initialized
INFO - 2023-05-29 16:25:57 --> Security Class Initialized
DEBUG - 2023-05-29 16:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:25:57 --> Input Class Initialized
INFO - 2023-05-29 16:25:57 --> Language Class Initialized
INFO - 2023-05-29 16:25:57 --> Loader Class Initialized
INFO - 2023-05-29 16:25:57 --> Helper loaded: url_helper
INFO - 2023-05-29 16:25:57 --> Helper loaded: file_helper
INFO - 2023-05-29 16:25:57 --> Helper loaded: html_helper
INFO - 2023-05-29 16:25:57 --> Helper loaded: text_helper
INFO - 2023-05-29 16:25:57 --> Helper loaded: form_helper
INFO - 2023-05-29 16:25:57 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:25:57 --> Helper loaded: security_helper
INFO - 2023-05-29 16:25:57 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:25:57 --> Database Driver Class Initialized
INFO - 2023-05-29 16:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:25:57 --> Parser Class Initialized
INFO - 2023-05-29 16:25:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:25:57 --> Pagination Class Initialized
INFO - 2023-05-29 16:25:57 --> Form Validation Class Initialized
INFO - 2023-05-29 16:25:57 --> Controller Class Initialized
INFO - 2023-05-29 16:25:57 --> Model Class Initialized
DEBUG - 2023-05-29 16:25:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:25:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:25:57 --> Model Class Initialized
DEBUG - 2023-05-29 16:25:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:25:57 --> Model Class Initialized
INFO - 2023-05-29 16:25:57 --> Final output sent to browser
DEBUG - 2023-05-29 16:25:57 --> Total execution time: 0.0564
ERROR - 2023-05-29 16:26:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:26:01 --> Config Class Initialized
INFO - 2023-05-29 16:26:01 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:26:01 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:26:01 --> Utf8 Class Initialized
INFO - 2023-05-29 16:26:01 --> URI Class Initialized
INFO - 2023-05-29 16:26:01 --> Router Class Initialized
INFO - 2023-05-29 16:26:01 --> Output Class Initialized
INFO - 2023-05-29 16:26:01 --> Security Class Initialized
DEBUG - 2023-05-29 16:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:26:01 --> Input Class Initialized
INFO - 2023-05-29 16:26:01 --> Language Class Initialized
INFO - 2023-05-29 16:26:01 --> Loader Class Initialized
INFO - 2023-05-29 16:26:01 --> Helper loaded: url_helper
INFO - 2023-05-29 16:26:01 --> Helper loaded: file_helper
INFO - 2023-05-29 16:26:01 --> Helper loaded: html_helper
INFO - 2023-05-29 16:26:01 --> Helper loaded: text_helper
INFO - 2023-05-29 16:26:01 --> Helper loaded: form_helper
INFO - 2023-05-29 16:26:01 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:26:01 --> Helper loaded: security_helper
INFO - 2023-05-29 16:26:01 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:26:01 --> Database Driver Class Initialized
INFO - 2023-05-29 16:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:26:01 --> Parser Class Initialized
INFO - 2023-05-29 16:26:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:26:01 --> Pagination Class Initialized
INFO - 2023-05-29 16:26:01 --> Form Validation Class Initialized
INFO - 2023-05-29 16:26:01 --> Controller Class Initialized
INFO - 2023-05-29 16:26:01 --> Model Class Initialized
DEBUG - 2023-05-29 16:26:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:26:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:26:01 --> Model Class Initialized
DEBUG - 2023-05-29 16:26:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:26:01 --> Model Class Initialized
INFO - 2023-05-29 16:26:01 --> Final output sent to browser
DEBUG - 2023-05-29 16:26:01 --> Total execution time: 0.0526
ERROR - 2023-05-29 16:27:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:27:13 --> Config Class Initialized
INFO - 2023-05-29 16:27:13 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:27:13 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:27:13 --> Utf8 Class Initialized
INFO - 2023-05-29 16:27:13 --> URI Class Initialized
INFO - 2023-05-29 16:27:13 --> Router Class Initialized
INFO - 2023-05-29 16:27:13 --> Output Class Initialized
INFO - 2023-05-29 16:27:13 --> Security Class Initialized
DEBUG - 2023-05-29 16:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:27:13 --> Input Class Initialized
INFO - 2023-05-29 16:27:13 --> Language Class Initialized
INFO - 2023-05-29 16:27:13 --> Loader Class Initialized
INFO - 2023-05-29 16:27:13 --> Helper loaded: url_helper
INFO - 2023-05-29 16:27:13 --> Helper loaded: file_helper
INFO - 2023-05-29 16:27:13 --> Helper loaded: html_helper
INFO - 2023-05-29 16:27:13 --> Helper loaded: text_helper
INFO - 2023-05-29 16:27:13 --> Helper loaded: form_helper
INFO - 2023-05-29 16:27:13 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:27:13 --> Helper loaded: security_helper
INFO - 2023-05-29 16:27:13 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:27:13 --> Database Driver Class Initialized
INFO - 2023-05-29 16:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:27:13 --> Parser Class Initialized
INFO - 2023-05-29 16:27:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:27:13 --> Pagination Class Initialized
INFO - 2023-05-29 16:27:13 --> Form Validation Class Initialized
INFO - 2023-05-29 16:27:13 --> Controller Class Initialized
INFO - 2023-05-29 16:27:13 --> Model Class Initialized
DEBUG - 2023-05-29 16:27:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:27:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:27:13 --> Model Class Initialized
DEBUG - 2023-05-29 16:27:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:27:13 --> Model Class Initialized
INFO - 2023-05-29 16:27:13 --> Final output sent to browser
DEBUG - 2023-05-29 16:27:13 --> Total execution time: 0.0509
ERROR - 2023-05-29 16:27:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:27:20 --> Config Class Initialized
INFO - 2023-05-29 16:27:20 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:27:20 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:27:20 --> Utf8 Class Initialized
INFO - 2023-05-29 16:27:20 --> URI Class Initialized
INFO - 2023-05-29 16:27:20 --> Router Class Initialized
INFO - 2023-05-29 16:27:20 --> Output Class Initialized
INFO - 2023-05-29 16:27:20 --> Security Class Initialized
DEBUG - 2023-05-29 16:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:27:20 --> Input Class Initialized
INFO - 2023-05-29 16:27:20 --> Language Class Initialized
INFO - 2023-05-29 16:27:20 --> Loader Class Initialized
INFO - 2023-05-29 16:27:20 --> Helper loaded: url_helper
INFO - 2023-05-29 16:27:20 --> Helper loaded: file_helper
INFO - 2023-05-29 16:27:20 --> Helper loaded: html_helper
INFO - 2023-05-29 16:27:20 --> Helper loaded: text_helper
INFO - 2023-05-29 16:27:20 --> Helper loaded: form_helper
INFO - 2023-05-29 16:27:20 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:27:20 --> Helper loaded: security_helper
INFO - 2023-05-29 16:27:20 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:27:20 --> Database Driver Class Initialized
INFO - 2023-05-29 16:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:27:20 --> Parser Class Initialized
INFO - 2023-05-29 16:27:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:27:20 --> Pagination Class Initialized
INFO - 2023-05-29 16:27:20 --> Form Validation Class Initialized
INFO - 2023-05-29 16:27:20 --> Controller Class Initialized
INFO - 2023-05-29 16:27:20 --> Model Class Initialized
DEBUG - 2023-05-29 16:27:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:27:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:27:20 --> Model Class Initialized
DEBUG - 2023-05-29 16:27:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:27:20 --> Model Class Initialized
INFO - 2023-05-29 16:27:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-29 16:27:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:27:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 16:27:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 16:27:20 --> Model Class Initialized
INFO - 2023-05-29 16:27:20 --> Model Class Initialized
INFO - 2023-05-29 16:27:20 --> Model Class Initialized
INFO - 2023-05-29 16:27:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-29 16:27:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-29 16:27:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 16:27:21 --> Final output sent to browser
DEBUG - 2023-05-29 16:27:21 --> Total execution time: 0.1276
ERROR - 2023-05-29 16:27:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:27:21 --> Config Class Initialized
INFO - 2023-05-29 16:27:21 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:27:21 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:27:21 --> Utf8 Class Initialized
INFO - 2023-05-29 16:27:21 --> URI Class Initialized
INFO - 2023-05-29 16:27:21 --> Router Class Initialized
INFO - 2023-05-29 16:27:21 --> Output Class Initialized
INFO - 2023-05-29 16:27:21 --> Security Class Initialized
DEBUG - 2023-05-29 16:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:27:21 --> Input Class Initialized
INFO - 2023-05-29 16:27:21 --> Language Class Initialized
INFO - 2023-05-29 16:27:21 --> Loader Class Initialized
INFO - 2023-05-29 16:27:21 --> Helper loaded: url_helper
INFO - 2023-05-29 16:27:21 --> Helper loaded: file_helper
INFO - 2023-05-29 16:27:21 --> Helper loaded: html_helper
INFO - 2023-05-29 16:27:21 --> Helper loaded: text_helper
INFO - 2023-05-29 16:27:21 --> Helper loaded: form_helper
INFO - 2023-05-29 16:27:21 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:27:21 --> Helper loaded: security_helper
INFO - 2023-05-29 16:27:21 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:27:21 --> Database Driver Class Initialized
INFO - 2023-05-29 16:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:27:21 --> Parser Class Initialized
INFO - 2023-05-29 16:27:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:27:21 --> Pagination Class Initialized
INFO - 2023-05-29 16:27:21 --> Form Validation Class Initialized
INFO - 2023-05-29 16:27:21 --> Controller Class Initialized
INFO - 2023-05-29 16:27:21 --> Model Class Initialized
DEBUG - 2023-05-29 16:27:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:27:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:27:21 --> Model Class Initialized
DEBUG - 2023-05-29 16:27:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:27:21 --> Model Class Initialized
INFO - 2023-05-29 16:27:21 --> Final output sent to browser
DEBUG - 2023-05-29 16:27:21 --> Total execution time: 0.0483
ERROR - 2023-05-29 16:27:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:27:24 --> Config Class Initialized
INFO - 2023-05-29 16:27:24 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:27:24 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:27:24 --> Utf8 Class Initialized
INFO - 2023-05-29 16:27:24 --> URI Class Initialized
INFO - 2023-05-29 16:27:24 --> Router Class Initialized
INFO - 2023-05-29 16:27:24 --> Output Class Initialized
INFO - 2023-05-29 16:27:24 --> Security Class Initialized
DEBUG - 2023-05-29 16:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:27:24 --> Input Class Initialized
INFO - 2023-05-29 16:27:24 --> Language Class Initialized
INFO - 2023-05-29 16:27:24 --> Loader Class Initialized
INFO - 2023-05-29 16:27:24 --> Helper loaded: url_helper
INFO - 2023-05-29 16:27:24 --> Helper loaded: file_helper
INFO - 2023-05-29 16:27:24 --> Helper loaded: html_helper
INFO - 2023-05-29 16:27:24 --> Helper loaded: text_helper
INFO - 2023-05-29 16:27:24 --> Helper loaded: form_helper
INFO - 2023-05-29 16:27:24 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:27:24 --> Helper loaded: security_helper
INFO - 2023-05-29 16:27:24 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:27:24 --> Database Driver Class Initialized
INFO - 2023-05-29 16:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:27:24 --> Parser Class Initialized
INFO - 2023-05-29 16:27:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:27:24 --> Pagination Class Initialized
INFO - 2023-05-29 16:27:24 --> Form Validation Class Initialized
INFO - 2023-05-29 16:27:24 --> Controller Class Initialized
INFO - 2023-05-29 16:27:24 --> Model Class Initialized
DEBUG - 2023-05-29 16:27:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:27:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:27:24 --> Model Class Initialized
DEBUG - 2023-05-29 16:27:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:27:24 --> Model Class Initialized
INFO - 2023-05-29 16:27:25 --> Final output sent to browser
DEBUG - 2023-05-29 16:27:25 --> Total execution time: 0.1426
ERROR - 2023-05-29 16:57:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:57:14 --> Config Class Initialized
INFO - 2023-05-29 16:57:14 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:57:14 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:57:14 --> Utf8 Class Initialized
INFO - 2023-05-29 16:57:14 --> URI Class Initialized
DEBUG - 2023-05-29 16:57:14 --> No URI present. Default controller set.
INFO - 2023-05-29 16:57:14 --> Router Class Initialized
INFO - 2023-05-29 16:57:14 --> Output Class Initialized
INFO - 2023-05-29 16:57:14 --> Security Class Initialized
DEBUG - 2023-05-29 16:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:57:14 --> Input Class Initialized
INFO - 2023-05-29 16:57:14 --> Language Class Initialized
INFO - 2023-05-29 16:57:14 --> Loader Class Initialized
INFO - 2023-05-29 16:57:14 --> Helper loaded: url_helper
INFO - 2023-05-29 16:57:14 --> Helper loaded: file_helper
INFO - 2023-05-29 16:57:14 --> Helper loaded: html_helper
INFO - 2023-05-29 16:57:14 --> Helper loaded: text_helper
INFO - 2023-05-29 16:57:14 --> Helper loaded: form_helper
INFO - 2023-05-29 16:57:14 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:57:14 --> Helper loaded: security_helper
INFO - 2023-05-29 16:57:14 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:57:14 --> Database Driver Class Initialized
INFO - 2023-05-29 16:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:57:14 --> Parser Class Initialized
INFO - 2023-05-29 16:57:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:57:14 --> Pagination Class Initialized
INFO - 2023-05-29 16:57:14 --> Form Validation Class Initialized
INFO - 2023-05-29 16:57:14 --> Controller Class Initialized
INFO - 2023-05-29 16:57:14 --> Model Class Initialized
DEBUG - 2023-05-29 16:57:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:57:14 --> Model Class Initialized
DEBUG - 2023-05-29 16:57:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:57:14 --> Model Class Initialized
INFO - 2023-05-29 16:57:14 --> Model Class Initialized
INFO - 2023-05-29 16:57:14 --> Model Class Initialized
INFO - 2023-05-29 16:57:14 --> Model Class Initialized
DEBUG - 2023-05-29 16:57:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:57:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:57:14 --> Model Class Initialized
INFO - 2023-05-29 16:57:14 --> Model Class Initialized
INFO - 2023-05-29 16:57:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-29 16:57:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:57:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 16:57:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 16:57:14 --> Model Class Initialized
INFO - 2023-05-29 16:57:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-29 16:57:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-29 16:57:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 16:57:14 --> Final output sent to browser
DEBUG - 2023-05-29 16:57:14 --> Total execution time: 0.0777
ERROR - 2023-05-29 16:57:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:57:45 --> Config Class Initialized
INFO - 2023-05-29 16:57:45 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:57:45 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:57:45 --> Utf8 Class Initialized
INFO - 2023-05-29 16:57:45 --> URI Class Initialized
INFO - 2023-05-29 16:57:45 --> Router Class Initialized
INFO - 2023-05-29 16:57:45 --> Output Class Initialized
INFO - 2023-05-29 16:57:45 --> Security Class Initialized
DEBUG - 2023-05-29 16:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:57:45 --> Input Class Initialized
INFO - 2023-05-29 16:57:45 --> Language Class Initialized
INFO - 2023-05-29 16:57:45 --> Loader Class Initialized
INFO - 2023-05-29 16:57:45 --> Helper loaded: url_helper
INFO - 2023-05-29 16:57:45 --> Helper loaded: file_helper
INFO - 2023-05-29 16:57:45 --> Helper loaded: html_helper
INFO - 2023-05-29 16:57:45 --> Helper loaded: text_helper
INFO - 2023-05-29 16:57:45 --> Helper loaded: form_helper
INFO - 2023-05-29 16:57:45 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:57:45 --> Helper loaded: security_helper
INFO - 2023-05-29 16:57:45 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:57:45 --> Database Driver Class Initialized
INFO - 2023-05-29 16:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:57:45 --> Parser Class Initialized
INFO - 2023-05-29 16:57:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:57:45 --> Pagination Class Initialized
INFO - 2023-05-29 16:57:45 --> Form Validation Class Initialized
INFO - 2023-05-29 16:57:45 --> Controller Class Initialized
INFO - 2023-05-29 16:57:45 --> Model Class Initialized
DEBUG - 2023-05-29 16:57:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:57:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:57:45 --> Model Class Initialized
INFO - 2023-05-29 16:57:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-05-29 16:57:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:57:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 16:57:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 16:57:45 --> Model Class Initialized
INFO - 2023-05-29 16:57:45 --> Model Class Initialized
INFO - 2023-05-29 16:57:45 --> Model Class Initialized
INFO - 2023-05-29 16:57:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-29 16:57:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-29 16:57:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 16:57:45 --> Final output sent to browser
DEBUG - 2023-05-29 16:57:45 --> Total execution time: 0.0642
ERROR - 2023-05-29 16:57:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:57:46 --> Config Class Initialized
INFO - 2023-05-29 16:57:46 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:57:46 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:57:46 --> Utf8 Class Initialized
INFO - 2023-05-29 16:57:46 --> URI Class Initialized
INFO - 2023-05-29 16:57:46 --> Router Class Initialized
INFO - 2023-05-29 16:57:46 --> Output Class Initialized
INFO - 2023-05-29 16:57:46 --> Security Class Initialized
DEBUG - 2023-05-29 16:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:57:46 --> Input Class Initialized
INFO - 2023-05-29 16:57:46 --> Language Class Initialized
INFO - 2023-05-29 16:57:46 --> Loader Class Initialized
INFO - 2023-05-29 16:57:46 --> Helper loaded: url_helper
INFO - 2023-05-29 16:57:46 --> Helper loaded: file_helper
INFO - 2023-05-29 16:57:46 --> Helper loaded: html_helper
INFO - 2023-05-29 16:57:46 --> Helper loaded: text_helper
INFO - 2023-05-29 16:57:46 --> Helper loaded: form_helper
INFO - 2023-05-29 16:57:46 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:57:46 --> Helper loaded: security_helper
INFO - 2023-05-29 16:57:46 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:57:46 --> Database Driver Class Initialized
INFO - 2023-05-29 16:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:57:46 --> Parser Class Initialized
INFO - 2023-05-29 16:57:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:57:46 --> Pagination Class Initialized
INFO - 2023-05-29 16:57:46 --> Form Validation Class Initialized
INFO - 2023-05-29 16:57:46 --> Controller Class Initialized
INFO - 2023-05-29 16:57:46 --> Model Class Initialized
DEBUG - 2023-05-29 16:57:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:57:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:57:46 --> Model Class Initialized
INFO - 2023-05-29 16:57:46 --> Final output sent to browser
DEBUG - 2023-05-29 16:57:46 --> Total execution time: 0.0230
ERROR - 2023-05-29 16:57:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 16:57:49 --> Config Class Initialized
INFO - 2023-05-29 16:57:49 --> Hooks Class Initialized
DEBUG - 2023-05-29 16:57:49 --> UTF-8 Support Enabled
INFO - 2023-05-29 16:57:49 --> Utf8 Class Initialized
INFO - 2023-05-29 16:57:49 --> URI Class Initialized
INFO - 2023-05-29 16:57:49 --> Router Class Initialized
INFO - 2023-05-29 16:57:49 --> Output Class Initialized
INFO - 2023-05-29 16:57:49 --> Security Class Initialized
DEBUG - 2023-05-29 16:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 16:57:49 --> Input Class Initialized
INFO - 2023-05-29 16:57:49 --> Language Class Initialized
INFO - 2023-05-29 16:57:49 --> Loader Class Initialized
INFO - 2023-05-29 16:57:49 --> Helper loaded: url_helper
INFO - 2023-05-29 16:57:49 --> Helper loaded: file_helper
INFO - 2023-05-29 16:57:49 --> Helper loaded: html_helper
INFO - 2023-05-29 16:57:49 --> Helper loaded: text_helper
INFO - 2023-05-29 16:57:49 --> Helper loaded: form_helper
INFO - 2023-05-29 16:57:49 --> Helper loaded: lang_helper
INFO - 2023-05-29 16:57:49 --> Helper loaded: security_helper
INFO - 2023-05-29 16:57:49 --> Helper loaded: cookie_helper
INFO - 2023-05-29 16:57:49 --> Database Driver Class Initialized
INFO - 2023-05-29 16:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 16:57:49 --> Parser Class Initialized
INFO - 2023-05-29 16:57:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 16:57:49 --> Pagination Class Initialized
INFO - 2023-05-29 16:57:49 --> Form Validation Class Initialized
INFO - 2023-05-29 16:57:49 --> Controller Class Initialized
INFO - 2023-05-29 16:57:49 --> Model Class Initialized
DEBUG - 2023-05-29 16:57:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 16:57:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 16:57:49 --> Model Class Initialized
INFO - 2023-05-29 16:57:49 --> Final output sent to browser
DEBUG - 2023-05-29 16:57:49 --> Total execution time: 0.0225
ERROR - 2023-05-29 17:00:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 17:00:55 --> Config Class Initialized
INFO - 2023-05-29 17:00:55 --> Hooks Class Initialized
DEBUG - 2023-05-29 17:00:55 --> UTF-8 Support Enabled
INFO - 2023-05-29 17:00:55 --> Utf8 Class Initialized
INFO - 2023-05-29 17:00:55 --> URI Class Initialized
DEBUG - 2023-05-29 17:00:55 --> No URI present. Default controller set.
INFO - 2023-05-29 17:00:55 --> Router Class Initialized
INFO - 2023-05-29 17:00:55 --> Output Class Initialized
INFO - 2023-05-29 17:00:55 --> Security Class Initialized
DEBUG - 2023-05-29 17:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 17:00:55 --> Input Class Initialized
INFO - 2023-05-29 17:00:55 --> Language Class Initialized
INFO - 2023-05-29 17:00:55 --> Loader Class Initialized
INFO - 2023-05-29 17:00:55 --> Helper loaded: url_helper
INFO - 2023-05-29 17:00:55 --> Helper loaded: file_helper
INFO - 2023-05-29 17:00:55 --> Helper loaded: html_helper
INFO - 2023-05-29 17:00:55 --> Helper loaded: text_helper
INFO - 2023-05-29 17:00:55 --> Helper loaded: form_helper
INFO - 2023-05-29 17:00:55 --> Helper loaded: lang_helper
INFO - 2023-05-29 17:00:55 --> Helper loaded: security_helper
INFO - 2023-05-29 17:00:55 --> Helper loaded: cookie_helper
INFO - 2023-05-29 17:00:55 --> Database Driver Class Initialized
INFO - 2023-05-29 17:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 17:00:55 --> Parser Class Initialized
INFO - 2023-05-29 17:00:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 17:00:55 --> Pagination Class Initialized
INFO - 2023-05-29 17:00:55 --> Form Validation Class Initialized
INFO - 2023-05-29 17:00:55 --> Controller Class Initialized
INFO - 2023-05-29 17:00:55 --> Model Class Initialized
DEBUG - 2023-05-29 17:00:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 17:00:55 --> Model Class Initialized
DEBUG - 2023-05-29 17:00:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 17:00:55 --> Model Class Initialized
INFO - 2023-05-29 17:00:55 --> Model Class Initialized
INFO - 2023-05-29 17:00:55 --> Model Class Initialized
INFO - 2023-05-29 17:00:55 --> Model Class Initialized
DEBUG - 2023-05-29 17:00:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 17:00:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 17:00:55 --> Model Class Initialized
INFO - 2023-05-29 17:00:55 --> Model Class Initialized
INFO - 2023-05-29 17:00:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-29 17:00:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 17:00:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 17:00:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 17:00:55 --> Model Class Initialized
INFO - 2023-05-29 17:00:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-29 17:00:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-29 17:00:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 17:00:55 --> Final output sent to browser
DEBUG - 2023-05-29 17:00:55 --> Total execution time: 0.0855
ERROR - 2023-05-29 17:01:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 17:01:03 --> Config Class Initialized
INFO - 2023-05-29 17:01:03 --> Hooks Class Initialized
DEBUG - 2023-05-29 17:01:03 --> UTF-8 Support Enabled
INFO - 2023-05-29 17:01:03 --> Utf8 Class Initialized
INFO - 2023-05-29 17:01:03 --> URI Class Initialized
INFO - 2023-05-29 17:01:03 --> Router Class Initialized
INFO - 2023-05-29 17:01:03 --> Output Class Initialized
INFO - 2023-05-29 17:01:03 --> Security Class Initialized
DEBUG - 2023-05-29 17:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 17:01:03 --> Input Class Initialized
INFO - 2023-05-29 17:01:03 --> Language Class Initialized
INFO - 2023-05-29 17:01:03 --> Loader Class Initialized
INFO - 2023-05-29 17:01:03 --> Helper loaded: url_helper
INFO - 2023-05-29 17:01:03 --> Helper loaded: file_helper
INFO - 2023-05-29 17:01:03 --> Helper loaded: html_helper
INFO - 2023-05-29 17:01:03 --> Helper loaded: text_helper
INFO - 2023-05-29 17:01:03 --> Helper loaded: form_helper
INFO - 2023-05-29 17:01:03 --> Helper loaded: lang_helper
INFO - 2023-05-29 17:01:03 --> Helper loaded: security_helper
INFO - 2023-05-29 17:01:03 --> Helper loaded: cookie_helper
INFO - 2023-05-29 17:01:03 --> Database Driver Class Initialized
INFO - 2023-05-29 17:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 17:01:03 --> Parser Class Initialized
INFO - 2023-05-29 17:01:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 17:01:03 --> Pagination Class Initialized
INFO - 2023-05-29 17:01:03 --> Form Validation Class Initialized
INFO - 2023-05-29 17:01:03 --> Controller Class Initialized
INFO - 2023-05-29 17:01:03 --> Model Class Initialized
DEBUG - 2023-05-29 17:01:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 17:01:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 17:01:03 --> Model Class Initialized
DEBUG - 2023-05-29 17:01:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 17:01:03 --> Model Class Initialized
INFO - 2023-05-29 17:01:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-29 17:01:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 17:01:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 17:01:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 17:01:03 --> Model Class Initialized
INFO - 2023-05-29 17:01:03 --> Model Class Initialized
INFO - 2023-05-29 17:01:03 --> Model Class Initialized
INFO - 2023-05-29 17:01:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-29 17:01:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-29 17:01:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 17:01:03 --> Final output sent to browser
DEBUG - 2023-05-29 17:01:03 --> Total execution time: 0.0766
ERROR - 2023-05-29 17:01:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 17:01:04 --> Config Class Initialized
INFO - 2023-05-29 17:01:04 --> Hooks Class Initialized
DEBUG - 2023-05-29 17:01:04 --> UTF-8 Support Enabled
INFO - 2023-05-29 17:01:04 --> Utf8 Class Initialized
INFO - 2023-05-29 17:01:04 --> URI Class Initialized
INFO - 2023-05-29 17:01:04 --> Router Class Initialized
INFO - 2023-05-29 17:01:04 --> Output Class Initialized
INFO - 2023-05-29 17:01:04 --> Security Class Initialized
DEBUG - 2023-05-29 17:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 17:01:04 --> Input Class Initialized
INFO - 2023-05-29 17:01:04 --> Language Class Initialized
INFO - 2023-05-29 17:01:04 --> Loader Class Initialized
INFO - 2023-05-29 17:01:04 --> Helper loaded: url_helper
INFO - 2023-05-29 17:01:04 --> Helper loaded: file_helper
INFO - 2023-05-29 17:01:04 --> Helper loaded: html_helper
INFO - 2023-05-29 17:01:04 --> Helper loaded: text_helper
INFO - 2023-05-29 17:01:04 --> Helper loaded: form_helper
INFO - 2023-05-29 17:01:04 --> Helper loaded: lang_helper
INFO - 2023-05-29 17:01:04 --> Helper loaded: security_helper
INFO - 2023-05-29 17:01:04 --> Helper loaded: cookie_helper
INFO - 2023-05-29 17:01:04 --> Database Driver Class Initialized
INFO - 2023-05-29 17:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 17:01:04 --> Parser Class Initialized
INFO - 2023-05-29 17:01:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 17:01:04 --> Pagination Class Initialized
INFO - 2023-05-29 17:01:04 --> Form Validation Class Initialized
INFO - 2023-05-29 17:01:04 --> Controller Class Initialized
INFO - 2023-05-29 17:01:04 --> Model Class Initialized
DEBUG - 2023-05-29 17:01:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 17:01:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 17:01:04 --> Model Class Initialized
DEBUG - 2023-05-29 17:01:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 17:01:04 --> Model Class Initialized
INFO - 2023-05-29 17:01:04 --> Final output sent to browser
DEBUG - 2023-05-29 17:01:04 --> Total execution time: 0.0406
ERROR - 2023-05-29 17:01:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 17:01:07 --> Config Class Initialized
INFO - 2023-05-29 17:01:07 --> Hooks Class Initialized
DEBUG - 2023-05-29 17:01:07 --> UTF-8 Support Enabled
INFO - 2023-05-29 17:01:07 --> Utf8 Class Initialized
INFO - 2023-05-29 17:01:07 --> URI Class Initialized
INFO - 2023-05-29 17:01:07 --> Router Class Initialized
INFO - 2023-05-29 17:01:07 --> Output Class Initialized
INFO - 2023-05-29 17:01:07 --> Security Class Initialized
DEBUG - 2023-05-29 17:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 17:01:07 --> Input Class Initialized
INFO - 2023-05-29 17:01:07 --> Language Class Initialized
INFO - 2023-05-29 17:01:07 --> Loader Class Initialized
INFO - 2023-05-29 17:01:07 --> Helper loaded: url_helper
INFO - 2023-05-29 17:01:07 --> Helper loaded: file_helper
INFO - 2023-05-29 17:01:07 --> Helper loaded: html_helper
INFO - 2023-05-29 17:01:07 --> Helper loaded: text_helper
INFO - 2023-05-29 17:01:07 --> Helper loaded: form_helper
INFO - 2023-05-29 17:01:07 --> Helper loaded: lang_helper
INFO - 2023-05-29 17:01:07 --> Helper loaded: security_helper
INFO - 2023-05-29 17:01:07 --> Helper loaded: cookie_helper
INFO - 2023-05-29 17:01:07 --> Database Driver Class Initialized
INFO - 2023-05-29 17:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 17:01:07 --> Parser Class Initialized
INFO - 2023-05-29 17:01:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 17:01:07 --> Pagination Class Initialized
INFO - 2023-05-29 17:01:07 --> Form Validation Class Initialized
INFO - 2023-05-29 17:01:07 --> Controller Class Initialized
INFO - 2023-05-29 17:01:07 --> Model Class Initialized
DEBUG - 2023-05-29 17:01:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 17:01:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 17:01:07 --> Model Class Initialized
DEBUG - 2023-05-29 17:01:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 17:01:07 --> Model Class Initialized
INFO - 2023-05-29 17:01:07 --> Final output sent to browser
DEBUG - 2023-05-29 17:01:07 --> Total execution time: 0.0721
ERROR - 2023-05-29 17:01:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 17:01:21 --> Config Class Initialized
INFO - 2023-05-29 17:01:21 --> Hooks Class Initialized
DEBUG - 2023-05-29 17:01:21 --> UTF-8 Support Enabled
INFO - 2023-05-29 17:01:21 --> Utf8 Class Initialized
INFO - 2023-05-29 17:01:21 --> URI Class Initialized
DEBUG - 2023-05-29 17:01:21 --> No URI present. Default controller set.
INFO - 2023-05-29 17:01:21 --> Router Class Initialized
INFO - 2023-05-29 17:01:21 --> Output Class Initialized
INFO - 2023-05-29 17:01:21 --> Security Class Initialized
DEBUG - 2023-05-29 17:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 17:01:21 --> Input Class Initialized
INFO - 2023-05-29 17:01:21 --> Language Class Initialized
INFO - 2023-05-29 17:01:21 --> Loader Class Initialized
INFO - 2023-05-29 17:01:21 --> Helper loaded: url_helper
INFO - 2023-05-29 17:01:21 --> Helper loaded: file_helper
INFO - 2023-05-29 17:01:21 --> Helper loaded: html_helper
INFO - 2023-05-29 17:01:21 --> Helper loaded: text_helper
INFO - 2023-05-29 17:01:21 --> Helper loaded: form_helper
INFO - 2023-05-29 17:01:21 --> Helper loaded: lang_helper
INFO - 2023-05-29 17:01:21 --> Helper loaded: security_helper
INFO - 2023-05-29 17:01:21 --> Helper loaded: cookie_helper
INFO - 2023-05-29 17:01:21 --> Database Driver Class Initialized
INFO - 2023-05-29 17:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 17:01:21 --> Parser Class Initialized
INFO - 2023-05-29 17:01:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 17:01:21 --> Pagination Class Initialized
INFO - 2023-05-29 17:01:21 --> Form Validation Class Initialized
INFO - 2023-05-29 17:01:21 --> Controller Class Initialized
INFO - 2023-05-29 17:01:21 --> Model Class Initialized
DEBUG - 2023-05-29 17:01:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 17:01:21 --> Model Class Initialized
DEBUG - 2023-05-29 17:01:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 17:01:21 --> Model Class Initialized
INFO - 2023-05-29 17:01:21 --> Model Class Initialized
INFO - 2023-05-29 17:01:21 --> Model Class Initialized
INFO - 2023-05-29 17:01:21 --> Model Class Initialized
DEBUG - 2023-05-29 17:01:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 17:01:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 17:01:21 --> Model Class Initialized
INFO - 2023-05-29 17:01:21 --> Model Class Initialized
INFO - 2023-05-29 17:01:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-29 17:01:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 17:01:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 17:01:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 17:01:21 --> Model Class Initialized
INFO - 2023-05-29 17:01:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-29 17:01:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-29 17:01:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 17:01:21 --> Final output sent to browser
DEBUG - 2023-05-29 17:01:21 --> Total execution time: 0.0754
ERROR - 2023-05-29 17:01:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-29 17:01:22 --> Config Class Initialized
INFO - 2023-05-29 17:01:22 --> Hooks Class Initialized
DEBUG - 2023-05-29 17:01:22 --> UTF-8 Support Enabled
INFO - 2023-05-29 17:01:22 --> Utf8 Class Initialized
INFO - 2023-05-29 17:01:22 --> URI Class Initialized
DEBUG - 2023-05-29 17:01:22 --> No URI present. Default controller set.
INFO - 2023-05-29 17:01:22 --> Router Class Initialized
INFO - 2023-05-29 17:01:22 --> Output Class Initialized
INFO - 2023-05-29 17:01:22 --> Security Class Initialized
DEBUG - 2023-05-29 17:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-29 17:01:22 --> Input Class Initialized
INFO - 2023-05-29 17:01:22 --> Language Class Initialized
INFO - 2023-05-29 17:01:22 --> Loader Class Initialized
INFO - 2023-05-29 17:01:22 --> Helper loaded: url_helper
INFO - 2023-05-29 17:01:22 --> Helper loaded: file_helper
INFO - 2023-05-29 17:01:22 --> Helper loaded: html_helper
INFO - 2023-05-29 17:01:22 --> Helper loaded: text_helper
INFO - 2023-05-29 17:01:22 --> Helper loaded: form_helper
INFO - 2023-05-29 17:01:22 --> Helper loaded: lang_helper
INFO - 2023-05-29 17:01:22 --> Helper loaded: security_helper
INFO - 2023-05-29 17:01:22 --> Helper loaded: cookie_helper
INFO - 2023-05-29 17:01:22 --> Database Driver Class Initialized
INFO - 2023-05-29 17:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-29 17:01:22 --> Parser Class Initialized
INFO - 2023-05-29 17:01:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-29 17:01:22 --> Pagination Class Initialized
INFO - 2023-05-29 17:01:22 --> Form Validation Class Initialized
INFO - 2023-05-29 17:01:22 --> Controller Class Initialized
INFO - 2023-05-29 17:01:22 --> Model Class Initialized
DEBUG - 2023-05-29 17:01:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 17:01:22 --> Model Class Initialized
DEBUG - 2023-05-29 17:01:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 17:01:22 --> Model Class Initialized
INFO - 2023-05-29 17:01:22 --> Model Class Initialized
INFO - 2023-05-29 17:01:22 --> Model Class Initialized
INFO - 2023-05-29 17:01:22 --> Model Class Initialized
DEBUG - 2023-05-29 17:01:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-29 17:01:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-29 17:01:22 --> Model Class Initialized
INFO - 2023-05-29 17:01:22 --> Model Class Initialized
INFO - 2023-05-29 17:01:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-29 17:01:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-29 17:01:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-29 17:01:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-29 17:01:22 --> Model Class Initialized
INFO - 2023-05-29 17:01:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-29 17:01:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-29 17:01:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-29 17:01:22 --> Final output sent to browser
DEBUG - 2023-05-29 17:01:22 --> Total execution time: 0.0700
