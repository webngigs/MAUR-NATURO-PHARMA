<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-04-08 00:49:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-08 00:49:37 --> Config Class Initialized
INFO - 2024-04-08 00:49:37 --> Hooks Class Initialized
DEBUG - 2024-04-08 00:49:37 --> UTF-8 Support Enabled
INFO - 2024-04-08 00:49:37 --> Utf8 Class Initialized
INFO - 2024-04-08 00:49:37 --> URI Class Initialized
DEBUG - 2024-04-08 00:49:37 --> No URI present. Default controller set.
INFO - 2024-04-08 00:49:37 --> Router Class Initialized
INFO - 2024-04-08 00:49:37 --> Output Class Initialized
INFO - 2024-04-08 00:49:37 --> Security Class Initialized
DEBUG - 2024-04-08 00:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-08 00:49:37 --> Input Class Initialized
INFO - 2024-04-08 00:49:37 --> Language Class Initialized
INFO - 2024-04-08 00:49:37 --> Loader Class Initialized
INFO - 2024-04-08 00:49:37 --> Helper loaded: url_helper
INFO - 2024-04-08 00:49:37 --> Helper loaded: file_helper
INFO - 2024-04-08 00:49:37 --> Helper loaded: html_helper
INFO - 2024-04-08 00:49:37 --> Helper loaded: text_helper
INFO - 2024-04-08 00:49:37 --> Helper loaded: form_helper
INFO - 2024-04-08 00:49:37 --> Helper loaded: lang_helper
INFO - 2024-04-08 00:49:37 --> Helper loaded: security_helper
INFO - 2024-04-08 00:49:37 --> Helper loaded: cookie_helper
INFO - 2024-04-08 00:49:37 --> Database Driver Class Initialized
INFO - 2024-04-08 00:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-08 00:49:37 --> Parser Class Initialized
INFO - 2024-04-08 00:49:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-08 00:49:37 --> Pagination Class Initialized
INFO - 2024-04-08 00:49:37 --> Form Validation Class Initialized
INFO - 2024-04-08 00:49:37 --> Controller Class Initialized
INFO - 2024-04-08 00:49:37 --> Model Class Initialized
DEBUG - 2024-04-08 00:49:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-04-08 03:30:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-08 03:30:02 --> Config Class Initialized
INFO - 2024-04-08 03:30:02 --> Hooks Class Initialized
DEBUG - 2024-04-08 03:30:02 --> UTF-8 Support Enabled
INFO - 2024-04-08 03:30:02 --> Utf8 Class Initialized
INFO - 2024-04-08 03:30:02 --> URI Class Initialized
DEBUG - 2024-04-08 03:30:02 --> No URI present. Default controller set.
INFO - 2024-04-08 03:30:02 --> Router Class Initialized
INFO - 2024-04-08 03:30:02 --> Output Class Initialized
INFO - 2024-04-08 03:30:02 --> Security Class Initialized
DEBUG - 2024-04-08 03:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-08 03:30:02 --> Input Class Initialized
INFO - 2024-04-08 03:30:02 --> Language Class Initialized
INFO - 2024-04-08 03:30:02 --> Loader Class Initialized
INFO - 2024-04-08 03:30:02 --> Helper loaded: url_helper
INFO - 2024-04-08 03:30:02 --> Helper loaded: file_helper
INFO - 2024-04-08 03:30:02 --> Helper loaded: html_helper
INFO - 2024-04-08 03:30:02 --> Helper loaded: text_helper
INFO - 2024-04-08 03:30:02 --> Helper loaded: form_helper
INFO - 2024-04-08 03:30:02 --> Helper loaded: lang_helper
INFO - 2024-04-08 03:30:02 --> Helper loaded: security_helper
INFO - 2024-04-08 03:30:02 --> Helper loaded: cookie_helper
INFO - 2024-04-08 03:30:02 --> Database Driver Class Initialized
INFO - 2024-04-08 03:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-08 03:30:02 --> Parser Class Initialized
INFO - 2024-04-08 03:30:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-08 03:30:02 --> Pagination Class Initialized
INFO - 2024-04-08 03:30:02 --> Form Validation Class Initialized
INFO - 2024-04-08 03:30:02 --> Controller Class Initialized
INFO - 2024-04-08 03:30:02 --> Model Class Initialized
DEBUG - 2024-04-08 03:30:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-04-08 03:43:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-08 03:43:02 --> Config Class Initialized
INFO - 2024-04-08 03:43:02 --> Hooks Class Initialized
DEBUG - 2024-04-08 03:43:02 --> UTF-8 Support Enabled
INFO - 2024-04-08 03:43:02 --> Utf8 Class Initialized
INFO - 2024-04-08 03:43:02 --> URI Class Initialized
DEBUG - 2024-04-08 03:43:02 --> No URI present. Default controller set.
INFO - 2024-04-08 03:43:02 --> Router Class Initialized
INFO - 2024-04-08 03:43:02 --> Output Class Initialized
INFO - 2024-04-08 03:43:02 --> Security Class Initialized
DEBUG - 2024-04-08 03:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-08 03:43:02 --> Input Class Initialized
INFO - 2024-04-08 03:43:02 --> Language Class Initialized
INFO - 2024-04-08 03:43:02 --> Loader Class Initialized
INFO - 2024-04-08 03:43:02 --> Helper loaded: url_helper
INFO - 2024-04-08 03:43:02 --> Helper loaded: file_helper
INFO - 2024-04-08 03:43:02 --> Helper loaded: html_helper
INFO - 2024-04-08 03:43:02 --> Helper loaded: text_helper
INFO - 2024-04-08 03:43:02 --> Helper loaded: form_helper
INFO - 2024-04-08 03:43:02 --> Helper loaded: lang_helper
INFO - 2024-04-08 03:43:02 --> Helper loaded: security_helper
INFO - 2024-04-08 03:43:02 --> Helper loaded: cookie_helper
INFO - 2024-04-08 03:43:02 --> Database Driver Class Initialized
INFO - 2024-04-08 03:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-08 03:43:02 --> Parser Class Initialized
INFO - 2024-04-08 03:43:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-08 03:43:02 --> Pagination Class Initialized
INFO - 2024-04-08 03:43:02 --> Form Validation Class Initialized
INFO - 2024-04-08 03:43:02 --> Controller Class Initialized
INFO - 2024-04-08 03:43:02 --> Model Class Initialized
DEBUG - 2024-04-08 03:43:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-04-08 03:43:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-08 03:43:02 --> Config Class Initialized
INFO - 2024-04-08 03:43:02 --> Hooks Class Initialized
DEBUG - 2024-04-08 03:43:02 --> UTF-8 Support Enabled
INFO - 2024-04-08 03:43:02 --> Utf8 Class Initialized
INFO - 2024-04-08 03:43:02 --> URI Class Initialized
INFO - 2024-04-08 03:43:02 --> Router Class Initialized
INFO - 2024-04-08 03:43:02 --> Output Class Initialized
INFO - 2024-04-08 03:43:02 --> Security Class Initialized
DEBUG - 2024-04-08 03:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-08 03:43:02 --> Input Class Initialized
INFO - 2024-04-08 03:43:02 --> Language Class Initialized
INFO - 2024-04-08 03:43:02 --> Loader Class Initialized
INFO - 2024-04-08 03:43:02 --> Helper loaded: url_helper
INFO - 2024-04-08 03:43:02 --> Helper loaded: file_helper
INFO - 2024-04-08 03:43:02 --> Helper loaded: html_helper
INFO - 2024-04-08 03:43:02 --> Helper loaded: text_helper
INFO - 2024-04-08 03:43:02 --> Helper loaded: form_helper
INFO - 2024-04-08 03:43:02 --> Helper loaded: lang_helper
INFO - 2024-04-08 03:43:02 --> Helper loaded: security_helper
INFO - 2024-04-08 03:43:02 --> Helper loaded: cookie_helper
INFO - 2024-04-08 03:43:02 --> Database Driver Class Initialized
INFO - 2024-04-08 03:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-08 03:43:02 --> Parser Class Initialized
INFO - 2024-04-08 03:43:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-08 03:43:02 --> Pagination Class Initialized
INFO - 2024-04-08 03:43:02 --> Form Validation Class Initialized
INFO - 2024-04-08 03:43:02 --> Controller Class Initialized
INFO - 2024-04-08 03:43:02 --> Model Class Initialized
DEBUG - 2024-04-08 03:43:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-08 03:43:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-04-08 03:43:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-08 03:43:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-08 03:43:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-08 03:43:02 --> Model Class Initialized
INFO - 2024-04-08 03:43:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-08 03:43:02 --> Final output sent to browser
DEBUG - 2024-04-08 03:43:02 --> Total execution time: 0.0341
ERROR - 2024-04-08 03:43:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-08 03:43:14 --> Config Class Initialized
INFO - 2024-04-08 03:43:14 --> Hooks Class Initialized
DEBUG - 2024-04-08 03:43:14 --> UTF-8 Support Enabled
INFO - 2024-04-08 03:43:14 --> Utf8 Class Initialized
INFO - 2024-04-08 03:43:14 --> URI Class Initialized
INFO - 2024-04-08 03:43:14 --> Router Class Initialized
INFO - 2024-04-08 03:43:14 --> Output Class Initialized
INFO - 2024-04-08 03:43:14 --> Security Class Initialized
DEBUG - 2024-04-08 03:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-08 03:43:14 --> Input Class Initialized
INFO - 2024-04-08 03:43:14 --> Language Class Initialized
INFO - 2024-04-08 03:43:14 --> Loader Class Initialized
INFO - 2024-04-08 03:43:14 --> Helper loaded: url_helper
INFO - 2024-04-08 03:43:14 --> Helper loaded: file_helper
INFO - 2024-04-08 03:43:14 --> Helper loaded: html_helper
INFO - 2024-04-08 03:43:14 --> Helper loaded: text_helper
INFO - 2024-04-08 03:43:14 --> Helper loaded: form_helper
INFO - 2024-04-08 03:43:14 --> Helper loaded: lang_helper
INFO - 2024-04-08 03:43:14 --> Helper loaded: security_helper
INFO - 2024-04-08 03:43:14 --> Helper loaded: cookie_helper
INFO - 2024-04-08 03:43:14 --> Database Driver Class Initialized
INFO - 2024-04-08 03:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-08 03:43:14 --> Parser Class Initialized
INFO - 2024-04-08 03:43:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-08 03:43:14 --> Pagination Class Initialized
INFO - 2024-04-08 03:43:14 --> Form Validation Class Initialized
INFO - 2024-04-08 03:43:14 --> Controller Class Initialized
INFO - 2024-04-08 03:43:14 --> Model Class Initialized
DEBUG - 2024-04-08 03:43:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-08 03:43:15 --> Model Class Initialized
INFO - 2024-04-08 03:43:15 --> Final output sent to browser
DEBUG - 2024-04-08 03:43:15 --> Total execution time: 0.0188
ERROR - 2024-04-08 03:43:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-08 03:43:15 --> Config Class Initialized
INFO - 2024-04-08 03:43:15 --> Hooks Class Initialized
DEBUG - 2024-04-08 03:43:15 --> UTF-8 Support Enabled
INFO - 2024-04-08 03:43:15 --> Utf8 Class Initialized
INFO - 2024-04-08 03:43:15 --> URI Class Initialized
DEBUG - 2024-04-08 03:43:15 --> No URI present. Default controller set.
INFO - 2024-04-08 03:43:15 --> Router Class Initialized
INFO - 2024-04-08 03:43:15 --> Output Class Initialized
INFO - 2024-04-08 03:43:15 --> Security Class Initialized
DEBUG - 2024-04-08 03:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-08 03:43:15 --> Input Class Initialized
INFO - 2024-04-08 03:43:15 --> Language Class Initialized
INFO - 2024-04-08 03:43:15 --> Loader Class Initialized
INFO - 2024-04-08 03:43:15 --> Helper loaded: url_helper
INFO - 2024-04-08 03:43:15 --> Helper loaded: file_helper
INFO - 2024-04-08 03:43:15 --> Helper loaded: html_helper
INFO - 2024-04-08 03:43:15 --> Helper loaded: text_helper
INFO - 2024-04-08 03:43:15 --> Helper loaded: form_helper
INFO - 2024-04-08 03:43:15 --> Helper loaded: lang_helper
INFO - 2024-04-08 03:43:15 --> Helper loaded: security_helper
INFO - 2024-04-08 03:43:15 --> Helper loaded: cookie_helper
INFO - 2024-04-08 03:43:15 --> Database Driver Class Initialized
INFO - 2024-04-08 03:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-08 03:43:15 --> Parser Class Initialized
INFO - 2024-04-08 03:43:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-08 03:43:15 --> Pagination Class Initialized
INFO - 2024-04-08 03:43:15 --> Form Validation Class Initialized
INFO - 2024-04-08 03:43:15 --> Controller Class Initialized
INFO - 2024-04-08 03:43:15 --> Model Class Initialized
DEBUG - 2024-04-08 03:43:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-08 03:43:15 --> Model Class Initialized
DEBUG - 2024-04-08 03:43:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-08 03:43:15 --> Model Class Initialized
INFO - 2024-04-08 03:43:15 --> Model Class Initialized
INFO - 2024-04-08 03:43:15 --> Model Class Initialized
INFO - 2024-04-08 03:43:15 --> Model Class Initialized
DEBUG - 2024-04-08 03:43:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-08 03:43:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-08 03:43:15 --> Model Class Initialized
INFO - 2024-04-08 03:43:15 --> Model Class Initialized
INFO - 2024-04-08 03:43:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-08 03:43:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-08 03:43:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-08 03:43:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-08 03:43:15 --> Model Class Initialized
INFO - 2024-04-08 03:43:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-08 03:43:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-08 03:43:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-08 03:43:15 --> Final output sent to browser
DEBUG - 2024-04-08 03:43:15 --> Total execution time: 0.4637
ERROR - 2024-04-08 03:43:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-08 03:43:17 --> Config Class Initialized
INFO - 2024-04-08 03:43:17 --> Hooks Class Initialized
DEBUG - 2024-04-08 03:43:17 --> UTF-8 Support Enabled
INFO - 2024-04-08 03:43:17 --> Utf8 Class Initialized
INFO - 2024-04-08 03:43:17 --> URI Class Initialized
INFO - 2024-04-08 03:43:17 --> Router Class Initialized
INFO - 2024-04-08 03:43:17 --> Output Class Initialized
INFO - 2024-04-08 03:43:17 --> Security Class Initialized
DEBUG - 2024-04-08 03:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-08 03:43:17 --> Input Class Initialized
INFO - 2024-04-08 03:43:17 --> Language Class Initialized
INFO - 2024-04-08 03:43:17 --> Loader Class Initialized
INFO - 2024-04-08 03:43:17 --> Helper loaded: url_helper
INFO - 2024-04-08 03:43:17 --> Helper loaded: file_helper
INFO - 2024-04-08 03:43:17 --> Helper loaded: html_helper
INFO - 2024-04-08 03:43:17 --> Helper loaded: text_helper
INFO - 2024-04-08 03:43:17 --> Helper loaded: form_helper
INFO - 2024-04-08 03:43:17 --> Helper loaded: lang_helper
INFO - 2024-04-08 03:43:17 --> Helper loaded: security_helper
INFO - 2024-04-08 03:43:17 --> Helper loaded: cookie_helper
INFO - 2024-04-08 03:43:17 --> Database Driver Class Initialized
INFO - 2024-04-08 03:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-08 03:43:17 --> Parser Class Initialized
INFO - 2024-04-08 03:43:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-08 03:43:17 --> Pagination Class Initialized
INFO - 2024-04-08 03:43:17 --> Form Validation Class Initialized
INFO - 2024-04-08 03:43:17 --> Controller Class Initialized
DEBUG - 2024-04-08 03:43:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-08 03:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-08 03:43:17 --> Model Class Initialized
INFO - 2024-04-08 03:43:17 --> Final output sent to browser
DEBUG - 2024-04-08 03:43:17 --> Total execution time: 0.0132
ERROR - 2024-04-08 04:48:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-08 04:48:09 --> Config Class Initialized
INFO - 2024-04-08 04:48:09 --> Hooks Class Initialized
DEBUG - 2024-04-08 04:48:09 --> UTF-8 Support Enabled
INFO - 2024-04-08 04:48:09 --> Utf8 Class Initialized
INFO - 2024-04-08 04:48:09 --> URI Class Initialized
DEBUG - 2024-04-08 04:48:09 --> No URI present. Default controller set.
INFO - 2024-04-08 04:48:09 --> Router Class Initialized
INFO - 2024-04-08 04:48:09 --> Output Class Initialized
INFO - 2024-04-08 04:48:09 --> Security Class Initialized
DEBUG - 2024-04-08 04:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-08 04:48:09 --> Input Class Initialized
INFO - 2024-04-08 04:48:09 --> Language Class Initialized
INFO - 2024-04-08 04:48:09 --> Loader Class Initialized
INFO - 2024-04-08 04:48:09 --> Helper loaded: url_helper
INFO - 2024-04-08 04:48:09 --> Helper loaded: file_helper
INFO - 2024-04-08 04:48:09 --> Helper loaded: html_helper
INFO - 2024-04-08 04:48:09 --> Helper loaded: text_helper
INFO - 2024-04-08 04:48:09 --> Helper loaded: form_helper
INFO - 2024-04-08 04:48:09 --> Helper loaded: lang_helper
INFO - 2024-04-08 04:48:09 --> Helper loaded: security_helper
INFO - 2024-04-08 04:48:09 --> Helper loaded: cookie_helper
INFO - 2024-04-08 04:48:09 --> Database Driver Class Initialized
INFO - 2024-04-08 04:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-08 04:48:09 --> Parser Class Initialized
INFO - 2024-04-08 04:48:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-08 04:48:09 --> Pagination Class Initialized
INFO - 2024-04-08 04:48:09 --> Form Validation Class Initialized
INFO - 2024-04-08 04:48:09 --> Controller Class Initialized
INFO - 2024-04-08 04:48:09 --> Model Class Initialized
DEBUG - 2024-04-08 04:48:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-04-08 04:48:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-08 04:48:09 --> Config Class Initialized
INFO - 2024-04-08 04:48:09 --> Hooks Class Initialized
DEBUG - 2024-04-08 04:48:09 --> UTF-8 Support Enabled
INFO - 2024-04-08 04:48:09 --> Utf8 Class Initialized
INFO - 2024-04-08 04:48:09 --> URI Class Initialized
INFO - 2024-04-08 04:48:09 --> Router Class Initialized
INFO - 2024-04-08 04:48:09 --> Output Class Initialized
INFO - 2024-04-08 04:48:09 --> Security Class Initialized
DEBUG - 2024-04-08 04:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-08 04:48:09 --> Input Class Initialized
INFO - 2024-04-08 04:48:09 --> Language Class Initialized
INFO - 2024-04-08 04:48:09 --> Loader Class Initialized
INFO - 2024-04-08 04:48:09 --> Helper loaded: url_helper
INFO - 2024-04-08 04:48:09 --> Helper loaded: file_helper
INFO - 2024-04-08 04:48:09 --> Helper loaded: html_helper
INFO - 2024-04-08 04:48:09 --> Helper loaded: text_helper
INFO - 2024-04-08 04:48:09 --> Helper loaded: form_helper
INFO - 2024-04-08 04:48:09 --> Helper loaded: lang_helper
INFO - 2024-04-08 04:48:09 --> Helper loaded: security_helper
INFO - 2024-04-08 04:48:09 --> Helper loaded: cookie_helper
INFO - 2024-04-08 04:48:09 --> Database Driver Class Initialized
INFO - 2024-04-08 04:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-08 04:48:09 --> Parser Class Initialized
INFO - 2024-04-08 04:48:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-08 04:48:09 --> Pagination Class Initialized
INFO - 2024-04-08 04:48:09 --> Form Validation Class Initialized
INFO - 2024-04-08 04:48:09 --> Controller Class Initialized
INFO - 2024-04-08 04:48:09 --> Model Class Initialized
DEBUG - 2024-04-08 04:48:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-08 04:48:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-04-08 04:48:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-08 04:48:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-08 04:48:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-08 04:48:09 --> Model Class Initialized
INFO - 2024-04-08 04:48:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-08 04:48:09 --> Final output sent to browser
DEBUG - 2024-04-08 04:48:09 --> Total execution time: 0.0340
ERROR - 2024-04-08 07:08:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-08 07:08:05 --> Config Class Initialized
INFO - 2024-04-08 07:08:05 --> Hooks Class Initialized
DEBUG - 2024-04-08 07:08:05 --> UTF-8 Support Enabled
INFO - 2024-04-08 07:08:05 --> Utf8 Class Initialized
INFO - 2024-04-08 07:08:05 --> URI Class Initialized
DEBUG - 2024-04-08 07:08:05 --> No URI present. Default controller set.
INFO - 2024-04-08 07:08:05 --> Router Class Initialized
INFO - 2024-04-08 07:08:05 --> Output Class Initialized
INFO - 2024-04-08 07:08:05 --> Security Class Initialized
DEBUG - 2024-04-08 07:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-08 07:08:05 --> Input Class Initialized
INFO - 2024-04-08 07:08:05 --> Language Class Initialized
INFO - 2024-04-08 07:08:05 --> Loader Class Initialized
INFO - 2024-04-08 07:08:05 --> Helper loaded: url_helper
INFO - 2024-04-08 07:08:05 --> Helper loaded: file_helper
INFO - 2024-04-08 07:08:05 --> Helper loaded: html_helper
INFO - 2024-04-08 07:08:05 --> Helper loaded: text_helper
INFO - 2024-04-08 07:08:05 --> Helper loaded: form_helper
INFO - 2024-04-08 07:08:05 --> Helper loaded: lang_helper
INFO - 2024-04-08 07:08:05 --> Helper loaded: security_helper
INFO - 2024-04-08 07:08:05 --> Helper loaded: cookie_helper
INFO - 2024-04-08 07:08:05 --> Database Driver Class Initialized
INFO - 2024-04-08 07:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-08 07:08:05 --> Parser Class Initialized
INFO - 2024-04-08 07:08:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-08 07:08:05 --> Pagination Class Initialized
INFO - 2024-04-08 07:08:05 --> Form Validation Class Initialized
INFO - 2024-04-08 07:08:05 --> Controller Class Initialized
INFO - 2024-04-08 07:08:05 --> Model Class Initialized
DEBUG - 2024-04-08 07:08:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-04-08 07:08:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-08 07:08:05 --> Config Class Initialized
INFO - 2024-04-08 07:08:05 --> Hooks Class Initialized
DEBUG - 2024-04-08 07:08:05 --> UTF-8 Support Enabled
INFO - 2024-04-08 07:08:05 --> Utf8 Class Initialized
INFO - 2024-04-08 07:08:05 --> URI Class Initialized
INFO - 2024-04-08 07:08:05 --> Router Class Initialized
INFO - 2024-04-08 07:08:05 --> Output Class Initialized
INFO - 2024-04-08 07:08:05 --> Security Class Initialized
DEBUG - 2024-04-08 07:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-08 07:08:05 --> Input Class Initialized
INFO - 2024-04-08 07:08:05 --> Language Class Initialized
INFO - 2024-04-08 07:08:05 --> Loader Class Initialized
INFO - 2024-04-08 07:08:05 --> Helper loaded: url_helper
INFO - 2024-04-08 07:08:05 --> Helper loaded: file_helper
INFO - 2024-04-08 07:08:05 --> Helper loaded: html_helper
INFO - 2024-04-08 07:08:05 --> Helper loaded: text_helper
INFO - 2024-04-08 07:08:05 --> Helper loaded: form_helper
INFO - 2024-04-08 07:08:05 --> Helper loaded: lang_helper
INFO - 2024-04-08 07:08:05 --> Helper loaded: security_helper
INFO - 2024-04-08 07:08:05 --> Helper loaded: cookie_helper
INFO - 2024-04-08 07:08:06 --> Database Driver Class Initialized
INFO - 2024-04-08 07:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-08 07:08:06 --> Parser Class Initialized
INFO - 2024-04-08 07:08:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-08 07:08:06 --> Pagination Class Initialized
INFO - 2024-04-08 07:08:06 --> Form Validation Class Initialized
INFO - 2024-04-08 07:08:06 --> Controller Class Initialized
INFO - 2024-04-08 07:08:06 --> Model Class Initialized
DEBUG - 2024-04-08 07:08:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-08 07:08:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-04-08 07:08:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-08 07:08:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-08 07:08:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-08 07:08:06 --> Model Class Initialized
INFO - 2024-04-08 07:08:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-08 07:08:06 --> Final output sent to browser
DEBUG - 2024-04-08 07:08:06 --> Total execution time: 0.0409
ERROR - 2024-04-08 07:08:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-08 07:08:06 --> Config Class Initialized
INFO - 2024-04-08 07:08:06 --> Hooks Class Initialized
DEBUG - 2024-04-08 07:08:06 --> UTF-8 Support Enabled
INFO - 2024-04-08 07:08:06 --> Utf8 Class Initialized
INFO - 2024-04-08 07:08:06 --> URI Class Initialized
INFO - 2024-04-08 07:08:06 --> Router Class Initialized
INFO - 2024-04-08 07:08:06 --> Output Class Initialized
INFO - 2024-04-08 07:08:06 --> Security Class Initialized
DEBUG - 2024-04-08 07:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-08 07:08:06 --> Input Class Initialized
INFO - 2024-04-08 07:08:06 --> Language Class Initialized
ERROR - 2024-04-08 07:08:06 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2024-04-08 07:08:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-08 07:08:07 --> Config Class Initialized
INFO - 2024-04-08 07:08:07 --> Hooks Class Initialized
DEBUG - 2024-04-08 07:08:07 --> UTF-8 Support Enabled
INFO - 2024-04-08 07:08:07 --> Utf8 Class Initialized
INFO - 2024-04-08 07:08:07 --> URI Class Initialized
INFO - 2024-04-08 07:08:07 --> Router Class Initialized
INFO - 2024-04-08 07:08:07 --> Output Class Initialized
INFO - 2024-04-08 07:08:07 --> Security Class Initialized
DEBUG - 2024-04-08 07:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-08 07:08:07 --> Input Class Initialized
INFO - 2024-04-08 07:08:07 --> Language Class Initialized
ERROR - 2024-04-08 07:08:07 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2024-04-08 07:47:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-08 07:47:56 --> Config Class Initialized
INFO - 2024-04-08 07:47:56 --> Hooks Class Initialized
DEBUG - 2024-04-08 07:47:56 --> UTF-8 Support Enabled
INFO - 2024-04-08 07:47:56 --> Utf8 Class Initialized
INFO - 2024-04-08 07:47:56 --> URI Class Initialized
DEBUG - 2024-04-08 07:47:56 --> No URI present. Default controller set.
INFO - 2024-04-08 07:47:56 --> Router Class Initialized
INFO - 2024-04-08 07:47:56 --> Output Class Initialized
INFO - 2024-04-08 07:47:56 --> Security Class Initialized
DEBUG - 2024-04-08 07:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-08 07:47:56 --> Input Class Initialized
INFO - 2024-04-08 07:47:56 --> Language Class Initialized
INFO - 2024-04-08 07:47:56 --> Loader Class Initialized
INFO - 2024-04-08 07:47:56 --> Helper loaded: url_helper
INFO - 2024-04-08 07:47:56 --> Helper loaded: file_helper
INFO - 2024-04-08 07:47:56 --> Helper loaded: html_helper
INFO - 2024-04-08 07:47:56 --> Helper loaded: text_helper
INFO - 2024-04-08 07:47:56 --> Helper loaded: form_helper
INFO - 2024-04-08 07:47:56 --> Helper loaded: lang_helper
INFO - 2024-04-08 07:47:56 --> Helper loaded: security_helper
INFO - 2024-04-08 07:47:56 --> Helper loaded: cookie_helper
INFO - 2024-04-08 07:47:56 --> Database Driver Class Initialized
INFO - 2024-04-08 07:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-08 07:47:56 --> Parser Class Initialized
INFO - 2024-04-08 07:47:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-08 07:47:56 --> Pagination Class Initialized
INFO - 2024-04-08 07:47:56 --> Form Validation Class Initialized
INFO - 2024-04-08 07:47:56 --> Controller Class Initialized
INFO - 2024-04-08 07:47:56 --> Model Class Initialized
DEBUG - 2024-04-08 07:47:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-04-08 07:47:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-08 07:47:57 --> Config Class Initialized
INFO - 2024-04-08 07:47:57 --> Hooks Class Initialized
DEBUG - 2024-04-08 07:47:57 --> UTF-8 Support Enabled
INFO - 2024-04-08 07:47:57 --> Utf8 Class Initialized
INFO - 2024-04-08 07:47:57 --> URI Class Initialized
INFO - 2024-04-08 07:47:57 --> Router Class Initialized
INFO - 2024-04-08 07:47:57 --> Output Class Initialized
INFO - 2024-04-08 07:47:57 --> Security Class Initialized
DEBUG - 2024-04-08 07:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-08 07:47:57 --> Input Class Initialized
INFO - 2024-04-08 07:47:57 --> Language Class Initialized
INFO - 2024-04-08 07:47:57 --> Loader Class Initialized
INFO - 2024-04-08 07:47:57 --> Helper loaded: url_helper
INFO - 2024-04-08 07:47:57 --> Helper loaded: file_helper
INFO - 2024-04-08 07:47:57 --> Helper loaded: html_helper
INFO - 2024-04-08 07:47:57 --> Helper loaded: text_helper
INFO - 2024-04-08 07:47:57 --> Helper loaded: form_helper
INFO - 2024-04-08 07:47:57 --> Helper loaded: lang_helper
INFO - 2024-04-08 07:47:57 --> Helper loaded: security_helper
INFO - 2024-04-08 07:47:57 --> Helper loaded: cookie_helper
INFO - 2024-04-08 07:47:57 --> Database Driver Class Initialized
INFO - 2024-04-08 07:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-08 07:47:57 --> Parser Class Initialized
INFO - 2024-04-08 07:47:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-08 07:47:57 --> Pagination Class Initialized
INFO - 2024-04-08 07:47:57 --> Form Validation Class Initialized
INFO - 2024-04-08 07:47:57 --> Controller Class Initialized
INFO - 2024-04-08 07:47:57 --> Model Class Initialized
DEBUG - 2024-04-08 07:47:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-08 07:47:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-04-08 07:47:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-08 07:47:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-08 07:47:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-08 07:47:57 --> Model Class Initialized
INFO - 2024-04-08 07:47:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-08 07:47:57 --> Final output sent to browser
DEBUG - 2024-04-08 07:47:57 --> Total execution time: 0.0349
ERROR - 2024-04-08 07:48:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-08 07:48:01 --> Config Class Initialized
INFO - 2024-04-08 07:48:01 --> Hooks Class Initialized
DEBUG - 2024-04-08 07:48:01 --> UTF-8 Support Enabled
INFO - 2024-04-08 07:48:01 --> Utf8 Class Initialized
INFO - 2024-04-08 07:48:01 --> URI Class Initialized
INFO - 2024-04-08 07:48:01 --> Router Class Initialized
INFO - 2024-04-08 07:48:01 --> Output Class Initialized
INFO - 2024-04-08 07:48:01 --> Security Class Initialized
DEBUG - 2024-04-08 07:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-08 07:48:01 --> Input Class Initialized
INFO - 2024-04-08 07:48:01 --> Language Class Initialized
INFO - 2024-04-08 07:48:01 --> Loader Class Initialized
INFO - 2024-04-08 07:48:01 --> Helper loaded: url_helper
INFO - 2024-04-08 07:48:01 --> Helper loaded: file_helper
INFO - 2024-04-08 07:48:01 --> Helper loaded: html_helper
INFO - 2024-04-08 07:48:01 --> Helper loaded: text_helper
INFO - 2024-04-08 07:48:01 --> Helper loaded: form_helper
INFO - 2024-04-08 07:48:01 --> Helper loaded: lang_helper
INFO - 2024-04-08 07:48:01 --> Helper loaded: security_helper
INFO - 2024-04-08 07:48:01 --> Helper loaded: cookie_helper
INFO - 2024-04-08 07:48:01 --> Database Driver Class Initialized
INFO - 2024-04-08 07:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-08 07:48:01 --> Parser Class Initialized
INFO - 2024-04-08 07:48:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-08 07:48:01 --> Pagination Class Initialized
INFO - 2024-04-08 07:48:01 --> Form Validation Class Initialized
INFO - 2024-04-08 07:48:01 --> Controller Class Initialized
INFO - 2024-04-08 07:48:01 --> Model Class Initialized
DEBUG - 2024-04-08 07:48:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-08 07:48:01 --> Model Class Initialized
INFO - 2024-04-08 07:48:01 --> Final output sent to browser
DEBUG - 2024-04-08 07:48:01 --> Total execution time: 0.0234
ERROR - 2024-04-08 07:48:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-08 07:48:01 --> Config Class Initialized
INFO - 2024-04-08 07:48:01 --> Hooks Class Initialized
DEBUG - 2024-04-08 07:48:01 --> UTF-8 Support Enabled
INFO - 2024-04-08 07:48:01 --> Utf8 Class Initialized
INFO - 2024-04-08 07:48:01 --> URI Class Initialized
DEBUG - 2024-04-08 07:48:01 --> No URI present. Default controller set.
INFO - 2024-04-08 07:48:01 --> Router Class Initialized
INFO - 2024-04-08 07:48:01 --> Output Class Initialized
INFO - 2024-04-08 07:48:01 --> Security Class Initialized
DEBUG - 2024-04-08 07:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-08 07:48:01 --> Input Class Initialized
INFO - 2024-04-08 07:48:01 --> Language Class Initialized
INFO - 2024-04-08 07:48:01 --> Loader Class Initialized
INFO - 2024-04-08 07:48:01 --> Helper loaded: url_helper
INFO - 2024-04-08 07:48:01 --> Helper loaded: file_helper
INFO - 2024-04-08 07:48:01 --> Helper loaded: html_helper
INFO - 2024-04-08 07:48:01 --> Helper loaded: text_helper
INFO - 2024-04-08 07:48:01 --> Helper loaded: form_helper
INFO - 2024-04-08 07:48:01 --> Helper loaded: lang_helper
INFO - 2024-04-08 07:48:01 --> Helper loaded: security_helper
INFO - 2024-04-08 07:48:01 --> Helper loaded: cookie_helper
INFO - 2024-04-08 07:48:01 --> Database Driver Class Initialized
INFO - 2024-04-08 07:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-08 07:48:01 --> Parser Class Initialized
INFO - 2024-04-08 07:48:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-08 07:48:01 --> Pagination Class Initialized
INFO - 2024-04-08 07:48:01 --> Form Validation Class Initialized
INFO - 2024-04-08 07:48:01 --> Controller Class Initialized
INFO - 2024-04-08 07:48:01 --> Model Class Initialized
DEBUG - 2024-04-08 07:48:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-08 07:48:01 --> Model Class Initialized
DEBUG - 2024-04-08 07:48:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-08 07:48:01 --> Model Class Initialized
INFO - 2024-04-08 07:48:01 --> Model Class Initialized
INFO - 2024-04-08 07:48:01 --> Model Class Initialized
INFO - 2024-04-08 07:48:01 --> Model Class Initialized
DEBUG - 2024-04-08 07:48:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-08 07:48:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-08 07:48:01 --> Model Class Initialized
INFO - 2024-04-08 07:48:01 --> Model Class Initialized
INFO - 2024-04-08 07:48:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-08 07:48:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-08 07:48:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-08 07:48:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-08 07:48:02 --> Model Class Initialized
INFO - 2024-04-08 07:48:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-08 07:48:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-08 07:48:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-08 07:48:02 --> Final output sent to browser
DEBUG - 2024-04-08 07:48:02 --> Total execution time: 0.4456
ERROR - 2024-04-08 07:48:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-08 07:48:03 --> Config Class Initialized
INFO - 2024-04-08 07:48:03 --> Hooks Class Initialized
DEBUG - 2024-04-08 07:48:03 --> UTF-8 Support Enabled
INFO - 2024-04-08 07:48:03 --> Utf8 Class Initialized
INFO - 2024-04-08 07:48:03 --> URI Class Initialized
INFO - 2024-04-08 07:48:03 --> Router Class Initialized
INFO - 2024-04-08 07:48:03 --> Output Class Initialized
INFO - 2024-04-08 07:48:03 --> Security Class Initialized
DEBUG - 2024-04-08 07:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-08 07:48:03 --> Input Class Initialized
INFO - 2024-04-08 07:48:03 --> Language Class Initialized
INFO - 2024-04-08 07:48:03 --> Loader Class Initialized
INFO - 2024-04-08 07:48:03 --> Helper loaded: url_helper
INFO - 2024-04-08 07:48:03 --> Helper loaded: file_helper
INFO - 2024-04-08 07:48:03 --> Helper loaded: html_helper
INFO - 2024-04-08 07:48:03 --> Helper loaded: text_helper
INFO - 2024-04-08 07:48:03 --> Helper loaded: form_helper
INFO - 2024-04-08 07:48:03 --> Helper loaded: lang_helper
INFO - 2024-04-08 07:48:03 --> Helper loaded: security_helper
INFO - 2024-04-08 07:48:03 --> Helper loaded: cookie_helper
INFO - 2024-04-08 07:48:03 --> Database Driver Class Initialized
INFO - 2024-04-08 07:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-08 07:48:03 --> Parser Class Initialized
INFO - 2024-04-08 07:48:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-08 07:48:03 --> Pagination Class Initialized
INFO - 2024-04-08 07:48:03 --> Form Validation Class Initialized
INFO - 2024-04-08 07:48:03 --> Controller Class Initialized
DEBUG - 2024-04-08 07:48:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-08 07:48:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-08 07:48:03 --> Model Class Initialized
INFO - 2024-04-08 07:48:03 --> Final output sent to browser
DEBUG - 2024-04-08 07:48:03 --> Total execution time: 0.0187
ERROR - 2024-04-08 07:48:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-08 07:48:20 --> Config Class Initialized
INFO - 2024-04-08 07:48:20 --> Hooks Class Initialized
DEBUG - 2024-04-08 07:48:20 --> UTF-8 Support Enabled
INFO - 2024-04-08 07:48:20 --> Utf8 Class Initialized
INFO - 2024-04-08 07:48:20 --> URI Class Initialized
INFO - 2024-04-08 07:48:20 --> Router Class Initialized
INFO - 2024-04-08 07:48:20 --> Output Class Initialized
INFO - 2024-04-08 07:48:20 --> Security Class Initialized
DEBUG - 2024-04-08 07:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-08 07:48:20 --> Input Class Initialized
INFO - 2024-04-08 07:48:20 --> Language Class Initialized
INFO - 2024-04-08 07:48:20 --> Loader Class Initialized
INFO - 2024-04-08 07:48:20 --> Helper loaded: url_helper
INFO - 2024-04-08 07:48:20 --> Helper loaded: file_helper
INFO - 2024-04-08 07:48:20 --> Helper loaded: html_helper
INFO - 2024-04-08 07:48:20 --> Helper loaded: text_helper
INFO - 2024-04-08 07:48:20 --> Helper loaded: form_helper
INFO - 2024-04-08 07:48:20 --> Helper loaded: lang_helper
INFO - 2024-04-08 07:48:20 --> Helper loaded: security_helper
INFO - 2024-04-08 07:48:20 --> Helper loaded: cookie_helper
INFO - 2024-04-08 07:48:20 --> Database Driver Class Initialized
INFO - 2024-04-08 07:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-08 07:48:20 --> Parser Class Initialized
INFO - 2024-04-08 07:48:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-08 07:48:20 --> Pagination Class Initialized
INFO - 2024-04-08 07:48:20 --> Form Validation Class Initialized
INFO - 2024-04-08 07:48:20 --> Controller Class Initialized
INFO - 2024-04-08 07:48:20 --> Model Class Initialized
DEBUG - 2024-04-08 07:48:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-08 07:48:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-08 07:48:20 --> Model Class Initialized
DEBUG - 2024-04-08 07:48:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-08 07:48:20 --> Model Class Initialized
INFO - 2024-04-08 07:48:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-04-08 07:48:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-08 07:48:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-08 07:48:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-08 07:48:20 --> Model Class Initialized
INFO - 2024-04-08 07:48:20 --> Model Class Initialized
INFO - 2024-04-08 07:48:20 --> Model Class Initialized
INFO - 2024-04-08 07:48:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-08 07:48:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-08 07:48:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-08 07:48:21 --> Final output sent to browser
DEBUG - 2024-04-08 07:48:21 --> Total execution time: 0.2501
ERROR - 2024-04-08 07:48:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-08 07:48:21 --> Config Class Initialized
INFO - 2024-04-08 07:48:21 --> Hooks Class Initialized
DEBUG - 2024-04-08 07:48:21 --> UTF-8 Support Enabled
INFO - 2024-04-08 07:48:21 --> Utf8 Class Initialized
INFO - 2024-04-08 07:48:21 --> URI Class Initialized
INFO - 2024-04-08 07:48:21 --> Router Class Initialized
INFO - 2024-04-08 07:48:21 --> Output Class Initialized
INFO - 2024-04-08 07:48:21 --> Security Class Initialized
DEBUG - 2024-04-08 07:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-08 07:48:21 --> Input Class Initialized
INFO - 2024-04-08 07:48:21 --> Language Class Initialized
INFO - 2024-04-08 07:48:21 --> Loader Class Initialized
INFO - 2024-04-08 07:48:21 --> Helper loaded: url_helper
INFO - 2024-04-08 07:48:21 --> Helper loaded: file_helper
INFO - 2024-04-08 07:48:21 --> Helper loaded: html_helper
INFO - 2024-04-08 07:48:21 --> Helper loaded: text_helper
INFO - 2024-04-08 07:48:21 --> Helper loaded: form_helper
INFO - 2024-04-08 07:48:21 --> Helper loaded: lang_helper
INFO - 2024-04-08 07:48:21 --> Helper loaded: security_helper
INFO - 2024-04-08 07:48:21 --> Helper loaded: cookie_helper
INFO - 2024-04-08 07:48:21 --> Database Driver Class Initialized
INFO - 2024-04-08 07:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-08 07:48:21 --> Parser Class Initialized
INFO - 2024-04-08 07:48:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-08 07:48:21 --> Pagination Class Initialized
INFO - 2024-04-08 07:48:21 --> Form Validation Class Initialized
INFO - 2024-04-08 07:48:21 --> Controller Class Initialized
INFO - 2024-04-08 07:48:21 --> Model Class Initialized
DEBUG - 2024-04-08 07:48:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-08 07:48:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-08 07:48:21 --> Model Class Initialized
DEBUG - 2024-04-08 07:48:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-08 07:48:21 --> Model Class Initialized
INFO - 2024-04-08 07:48:21 --> Final output sent to browser
DEBUG - 2024-04-08 07:48:21 --> Total execution time: 0.0566
ERROR - 2024-04-08 07:48:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-08 07:48:27 --> Config Class Initialized
INFO - 2024-04-08 07:48:27 --> Hooks Class Initialized
DEBUG - 2024-04-08 07:48:27 --> UTF-8 Support Enabled
INFO - 2024-04-08 07:48:27 --> Utf8 Class Initialized
INFO - 2024-04-08 07:48:27 --> URI Class Initialized
INFO - 2024-04-08 07:48:27 --> Router Class Initialized
INFO - 2024-04-08 07:48:27 --> Output Class Initialized
INFO - 2024-04-08 07:48:27 --> Security Class Initialized
DEBUG - 2024-04-08 07:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-08 07:48:27 --> Input Class Initialized
INFO - 2024-04-08 07:48:27 --> Language Class Initialized
INFO - 2024-04-08 07:48:27 --> Loader Class Initialized
INFO - 2024-04-08 07:48:27 --> Helper loaded: url_helper
INFO - 2024-04-08 07:48:27 --> Helper loaded: file_helper
INFO - 2024-04-08 07:48:27 --> Helper loaded: html_helper
INFO - 2024-04-08 07:48:27 --> Helper loaded: text_helper
INFO - 2024-04-08 07:48:27 --> Helper loaded: form_helper
INFO - 2024-04-08 07:48:27 --> Helper loaded: lang_helper
INFO - 2024-04-08 07:48:27 --> Helper loaded: security_helper
INFO - 2024-04-08 07:48:27 --> Helper loaded: cookie_helper
INFO - 2024-04-08 07:48:27 --> Database Driver Class Initialized
INFO - 2024-04-08 07:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-08 07:48:27 --> Parser Class Initialized
INFO - 2024-04-08 07:48:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-08 07:48:27 --> Pagination Class Initialized
INFO - 2024-04-08 07:48:27 --> Form Validation Class Initialized
INFO - 2024-04-08 07:48:27 --> Controller Class Initialized
INFO - 2024-04-08 07:48:27 --> Model Class Initialized
DEBUG - 2024-04-08 07:48:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-08 07:48:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-08 07:48:27 --> Model Class Initialized
DEBUG - 2024-04-08 07:48:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-08 07:48:27 --> Model Class Initialized
INFO - 2024-04-08 07:48:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-04-08 07:48:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-08 07:48:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-08 07:48:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-08 07:48:27 --> Model Class Initialized
INFO - 2024-04-08 07:48:27 --> Model Class Initialized
INFO - 2024-04-08 07:48:27 --> Model Class Initialized
INFO - 2024-04-08 07:48:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-08 07:48:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-08 07:48:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-08 07:48:28 --> Final output sent to browser
DEBUG - 2024-04-08 07:48:28 --> Total execution time: 0.2293
ERROR - 2024-04-08 07:48:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-08 07:48:28 --> Config Class Initialized
INFO - 2024-04-08 07:48:28 --> Hooks Class Initialized
DEBUG - 2024-04-08 07:48:28 --> UTF-8 Support Enabled
INFO - 2024-04-08 07:48:28 --> Utf8 Class Initialized
INFO - 2024-04-08 07:48:28 --> URI Class Initialized
INFO - 2024-04-08 07:48:28 --> Router Class Initialized
INFO - 2024-04-08 07:48:28 --> Output Class Initialized
INFO - 2024-04-08 07:48:28 --> Security Class Initialized
DEBUG - 2024-04-08 07:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-08 07:48:28 --> Input Class Initialized
INFO - 2024-04-08 07:48:28 --> Language Class Initialized
INFO - 2024-04-08 07:48:28 --> Loader Class Initialized
INFO - 2024-04-08 07:48:28 --> Helper loaded: url_helper
INFO - 2024-04-08 07:48:28 --> Helper loaded: file_helper
INFO - 2024-04-08 07:48:28 --> Helper loaded: html_helper
INFO - 2024-04-08 07:48:28 --> Helper loaded: text_helper
INFO - 2024-04-08 07:48:28 --> Helper loaded: form_helper
INFO - 2024-04-08 07:48:28 --> Helper loaded: lang_helper
INFO - 2024-04-08 07:48:28 --> Helper loaded: security_helper
INFO - 2024-04-08 07:48:28 --> Helper loaded: cookie_helper
INFO - 2024-04-08 07:48:28 --> Database Driver Class Initialized
INFO - 2024-04-08 07:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-08 07:48:28 --> Parser Class Initialized
INFO - 2024-04-08 07:48:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-08 07:48:28 --> Pagination Class Initialized
INFO - 2024-04-08 07:48:28 --> Form Validation Class Initialized
INFO - 2024-04-08 07:48:28 --> Controller Class Initialized
INFO - 2024-04-08 07:48:28 --> Model Class Initialized
DEBUG - 2024-04-08 07:48:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-08 07:48:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-08 07:48:28 --> Model Class Initialized
DEBUG - 2024-04-08 07:48:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-08 07:48:28 --> Model Class Initialized
INFO - 2024-04-08 07:48:28 --> Final output sent to browser
DEBUG - 2024-04-08 07:48:28 --> Total execution time: 0.0555
ERROR - 2024-04-08 07:48:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-08 07:48:33 --> Config Class Initialized
INFO - 2024-04-08 07:48:33 --> Hooks Class Initialized
DEBUG - 2024-04-08 07:48:33 --> UTF-8 Support Enabled
INFO - 2024-04-08 07:48:33 --> Utf8 Class Initialized
INFO - 2024-04-08 07:48:33 --> URI Class Initialized
INFO - 2024-04-08 07:48:33 --> Router Class Initialized
INFO - 2024-04-08 07:48:33 --> Output Class Initialized
INFO - 2024-04-08 07:48:33 --> Security Class Initialized
DEBUG - 2024-04-08 07:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-08 07:48:33 --> Input Class Initialized
INFO - 2024-04-08 07:48:33 --> Language Class Initialized
INFO - 2024-04-08 07:48:33 --> Loader Class Initialized
INFO - 2024-04-08 07:48:33 --> Helper loaded: url_helper
INFO - 2024-04-08 07:48:33 --> Helper loaded: file_helper
INFO - 2024-04-08 07:48:33 --> Helper loaded: html_helper
INFO - 2024-04-08 07:48:33 --> Helper loaded: text_helper
INFO - 2024-04-08 07:48:33 --> Helper loaded: form_helper
INFO - 2024-04-08 07:48:33 --> Helper loaded: lang_helper
INFO - 2024-04-08 07:48:33 --> Helper loaded: security_helper
INFO - 2024-04-08 07:48:33 --> Helper loaded: cookie_helper
INFO - 2024-04-08 07:48:33 --> Database Driver Class Initialized
INFO - 2024-04-08 07:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-08 07:48:33 --> Parser Class Initialized
INFO - 2024-04-08 07:48:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-08 07:48:33 --> Pagination Class Initialized
INFO - 2024-04-08 07:48:33 --> Form Validation Class Initialized
INFO - 2024-04-08 07:48:33 --> Controller Class Initialized
INFO - 2024-04-08 07:48:33 --> Model Class Initialized
DEBUG - 2024-04-08 07:48:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-08 07:48:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-08 07:48:33 --> Model Class Initialized
DEBUG - 2024-04-08 07:48:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-08 07:48:33 --> Model Class Initialized
INFO - 2024-04-08 07:48:34 --> Final output sent to browser
DEBUG - 2024-04-08 07:48:34 --> Total execution time: 1.3463
ERROR - 2024-04-08 07:48:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-08 07:48:39 --> Config Class Initialized
INFO - 2024-04-08 07:48:39 --> Hooks Class Initialized
DEBUG - 2024-04-08 07:48:39 --> UTF-8 Support Enabled
INFO - 2024-04-08 07:48:39 --> Utf8 Class Initialized
INFO - 2024-04-08 07:48:39 --> URI Class Initialized
INFO - 2024-04-08 07:48:39 --> Router Class Initialized
INFO - 2024-04-08 07:48:39 --> Output Class Initialized
INFO - 2024-04-08 07:48:39 --> Security Class Initialized
DEBUG - 2024-04-08 07:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-08 07:48:39 --> Input Class Initialized
INFO - 2024-04-08 07:48:39 --> Language Class Initialized
INFO - 2024-04-08 07:48:39 --> Loader Class Initialized
INFO - 2024-04-08 07:48:39 --> Helper loaded: url_helper
INFO - 2024-04-08 07:48:39 --> Helper loaded: file_helper
INFO - 2024-04-08 07:48:39 --> Helper loaded: html_helper
INFO - 2024-04-08 07:48:39 --> Helper loaded: text_helper
INFO - 2024-04-08 07:48:39 --> Helper loaded: form_helper
INFO - 2024-04-08 07:48:39 --> Helper loaded: lang_helper
INFO - 2024-04-08 07:48:39 --> Helper loaded: security_helper
INFO - 2024-04-08 07:48:39 --> Helper loaded: cookie_helper
INFO - 2024-04-08 07:48:39 --> Database Driver Class Initialized
INFO - 2024-04-08 07:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-08 07:48:39 --> Parser Class Initialized
INFO - 2024-04-08 07:48:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-08 07:48:39 --> Pagination Class Initialized
INFO - 2024-04-08 07:48:39 --> Form Validation Class Initialized
INFO - 2024-04-08 07:48:39 --> Controller Class Initialized
INFO - 2024-04-08 07:48:39 --> Model Class Initialized
DEBUG - 2024-04-08 07:48:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-08 07:48:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-08 07:48:39 --> Model Class Initialized
DEBUG - 2024-04-08 07:48:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-08 07:48:39 --> Model Class Initialized
INFO - 2024-04-08 07:48:39 --> Email Class Initialized
INFO - 2024-04-08 07:48:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html_pdf.php
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/frame_reflower.cls.php 210
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/frame_reflower.cls.php 211
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/block_frame_reflower.cls.php 726
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/inline_renderer.cls.php 138
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-08 07:48:39 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-04-08 07:48:39 --> Language file loaded: language/english/email_lang.php
INFO - 2024-04-08 07:48:39 --> Final output sent to browser
DEBUG - 2024-04-08 07:48:39 --> Total execution time: 0.2469
ERROR - 2024-04-08 07:48:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-08 07:48:40 --> Config Class Initialized
INFO - 2024-04-08 07:48:40 --> Hooks Class Initialized
DEBUG - 2024-04-08 07:48:40 --> UTF-8 Support Enabled
INFO - 2024-04-08 07:48:40 --> Utf8 Class Initialized
INFO - 2024-04-08 07:48:40 --> URI Class Initialized
INFO - 2024-04-08 07:48:40 --> Router Class Initialized
INFO - 2024-04-08 07:48:40 --> Output Class Initialized
INFO - 2024-04-08 07:48:40 --> Security Class Initialized
DEBUG - 2024-04-08 07:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-08 07:48:40 --> Input Class Initialized
INFO - 2024-04-08 07:48:40 --> Language Class Initialized
INFO - 2024-04-08 07:48:40 --> Loader Class Initialized
INFO - 2024-04-08 07:48:40 --> Helper loaded: url_helper
INFO - 2024-04-08 07:48:40 --> Helper loaded: file_helper
INFO - 2024-04-08 07:48:40 --> Helper loaded: html_helper
INFO - 2024-04-08 07:48:40 --> Helper loaded: text_helper
INFO - 2024-04-08 07:48:40 --> Helper loaded: form_helper
INFO - 2024-04-08 07:48:40 --> Helper loaded: lang_helper
INFO - 2024-04-08 07:48:40 --> Helper loaded: security_helper
INFO - 2024-04-08 07:48:40 --> Helper loaded: cookie_helper
INFO - 2024-04-08 07:48:40 --> Database Driver Class Initialized
INFO - 2024-04-08 07:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-08 07:48:40 --> Parser Class Initialized
INFO - 2024-04-08 07:48:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-08 07:48:40 --> Pagination Class Initialized
INFO - 2024-04-08 07:48:40 --> Form Validation Class Initialized
INFO - 2024-04-08 07:48:40 --> Controller Class Initialized
INFO - 2024-04-08 07:48:40 --> Model Class Initialized
DEBUG - 2024-04-08 07:48:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-08 07:48:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-08 07:48:40 --> Model Class Initialized
DEBUG - 2024-04-08 07:48:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-08 07:48:40 --> Model Class Initialized
INFO - 2024-04-08 07:48:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html.php
DEBUG - 2024-04-08 07:48:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-08 07:48:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-08 07:48:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-08 07:48:40 --> Model Class Initialized
INFO - 2024-04-08 07:48:40 --> Model Class Initialized
INFO - 2024-04-08 07:48:40 --> Model Class Initialized
INFO - 2024-04-08 07:48:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-08 07:48:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-08 07:48:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-08 07:48:40 --> Final output sent to browser
DEBUG - 2024-04-08 07:48:40 --> Total execution time: 0.2292
ERROR - 2024-04-08 07:48:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-08 07:48:47 --> Config Class Initialized
INFO - 2024-04-08 07:48:47 --> Hooks Class Initialized
DEBUG - 2024-04-08 07:48:47 --> UTF-8 Support Enabled
INFO - 2024-04-08 07:48:47 --> Utf8 Class Initialized
INFO - 2024-04-08 07:48:47 --> URI Class Initialized
INFO - 2024-04-08 07:48:47 --> Router Class Initialized
INFO - 2024-04-08 07:48:47 --> Output Class Initialized
INFO - 2024-04-08 07:48:47 --> Security Class Initialized
DEBUG - 2024-04-08 07:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-08 07:48:47 --> Input Class Initialized
INFO - 2024-04-08 07:48:47 --> Language Class Initialized
INFO - 2024-04-08 07:48:47 --> Loader Class Initialized
INFO - 2024-04-08 07:48:47 --> Helper loaded: url_helper
INFO - 2024-04-08 07:48:47 --> Helper loaded: file_helper
INFO - 2024-04-08 07:48:47 --> Helper loaded: html_helper
INFO - 2024-04-08 07:48:47 --> Helper loaded: text_helper
INFO - 2024-04-08 07:48:47 --> Helper loaded: form_helper
INFO - 2024-04-08 07:48:47 --> Helper loaded: lang_helper
INFO - 2024-04-08 07:48:47 --> Helper loaded: security_helper
INFO - 2024-04-08 07:48:47 --> Helper loaded: cookie_helper
INFO - 2024-04-08 07:48:47 --> Database Driver Class Initialized
INFO - 2024-04-08 07:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-08 07:48:47 --> Parser Class Initialized
INFO - 2024-04-08 07:48:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-08 07:48:47 --> Pagination Class Initialized
INFO - 2024-04-08 07:48:47 --> Form Validation Class Initialized
INFO - 2024-04-08 07:48:47 --> Controller Class Initialized
INFO - 2024-04-08 07:48:47 --> Model Class Initialized
DEBUG - 2024-04-08 07:48:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-08 07:48:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-08 07:48:47 --> Model Class Initialized
DEBUG - 2024-04-08 07:48:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-08 07:48:47 --> Model Class Initialized
INFO - 2024-04-08 07:48:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-04-08 07:48:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-08 07:48:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-08 07:48:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-08 07:48:47 --> Model Class Initialized
INFO - 2024-04-08 07:48:47 --> Model Class Initialized
INFO - 2024-04-08 07:48:47 --> Model Class Initialized
INFO - 2024-04-08 07:48:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-08 07:48:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-08 07:48:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-08 07:48:47 --> Final output sent to browser
DEBUG - 2024-04-08 07:48:47 --> Total execution time: 0.2369
ERROR - 2024-04-08 07:48:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-08 07:48:48 --> Config Class Initialized
INFO - 2024-04-08 07:48:48 --> Hooks Class Initialized
DEBUG - 2024-04-08 07:48:48 --> UTF-8 Support Enabled
INFO - 2024-04-08 07:48:48 --> Utf8 Class Initialized
INFO - 2024-04-08 07:48:48 --> URI Class Initialized
INFO - 2024-04-08 07:48:48 --> Router Class Initialized
INFO - 2024-04-08 07:48:48 --> Output Class Initialized
INFO - 2024-04-08 07:48:48 --> Security Class Initialized
DEBUG - 2024-04-08 07:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-08 07:48:48 --> Input Class Initialized
INFO - 2024-04-08 07:48:48 --> Language Class Initialized
INFO - 2024-04-08 07:48:48 --> Loader Class Initialized
INFO - 2024-04-08 07:48:48 --> Helper loaded: url_helper
INFO - 2024-04-08 07:48:48 --> Helper loaded: file_helper
INFO - 2024-04-08 07:48:48 --> Helper loaded: html_helper
INFO - 2024-04-08 07:48:48 --> Helper loaded: text_helper
INFO - 2024-04-08 07:48:48 --> Helper loaded: form_helper
INFO - 2024-04-08 07:48:48 --> Helper loaded: lang_helper
INFO - 2024-04-08 07:48:48 --> Helper loaded: security_helper
INFO - 2024-04-08 07:48:48 --> Helper loaded: cookie_helper
INFO - 2024-04-08 07:48:48 --> Database Driver Class Initialized
INFO - 2024-04-08 07:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-08 07:48:48 --> Parser Class Initialized
INFO - 2024-04-08 07:48:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-08 07:48:48 --> Pagination Class Initialized
INFO - 2024-04-08 07:48:48 --> Form Validation Class Initialized
INFO - 2024-04-08 07:48:48 --> Controller Class Initialized
INFO - 2024-04-08 07:48:48 --> Model Class Initialized
DEBUG - 2024-04-08 07:48:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-08 07:48:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-08 07:48:48 --> Model Class Initialized
DEBUG - 2024-04-08 07:48:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-08 07:48:48 --> Model Class Initialized
INFO - 2024-04-08 07:48:48 --> Final output sent to browser
DEBUG - 2024-04-08 07:48:48 --> Total execution time: 0.0544
ERROR - 2024-04-08 09:24:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-08 09:24:49 --> Config Class Initialized
INFO - 2024-04-08 09:24:49 --> Hooks Class Initialized
DEBUG - 2024-04-08 09:24:49 --> UTF-8 Support Enabled
INFO - 2024-04-08 09:24:49 --> Utf8 Class Initialized
INFO - 2024-04-08 09:24:49 --> URI Class Initialized
DEBUG - 2024-04-08 09:24:49 --> No URI present. Default controller set.
INFO - 2024-04-08 09:24:49 --> Router Class Initialized
INFO - 2024-04-08 09:24:49 --> Output Class Initialized
INFO - 2024-04-08 09:24:49 --> Security Class Initialized
DEBUG - 2024-04-08 09:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-08 09:24:49 --> Input Class Initialized
INFO - 2024-04-08 09:24:49 --> Language Class Initialized
INFO - 2024-04-08 09:24:49 --> Loader Class Initialized
INFO - 2024-04-08 09:24:49 --> Helper loaded: url_helper
INFO - 2024-04-08 09:24:49 --> Helper loaded: file_helper
INFO - 2024-04-08 09:24:49 --> Helper loaded: html_helper
INFO - 2024-04-08 09:24:49 --> Helper loaded: text_helper
INFO - 2024-04-08 09:24:49 --> Helper loaded: form_helper
INFO - 2024-04-08 09:24:49 --> Helper loaded: lang_helper
INFO - 2024-04-08 09:24:49 --> Helper loaded: security_helper
INFO - 2024-04-08 09:24:49 --> Helper loaded: cookie_helper
INFO - 2024-04-08 09:24:49 --> Database Driver Class Initialized
INFO - 2024-04-08 09:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-08 09:24:49 --> Parser Class Initialized
INFO - 2024-04-08 09:24:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-08 09:24:49 --> Pagination Class Initialized
INFO - 2024-04-08 09:24:49 --> Form Validation Class Initialized
INFO - 2024-04-08 09:24:49 --> Controller Class Initialized
INFO - 2024-04-08 09:24:49 --> Model Class Initialized
DEBUG - 2024-04-08 09:24:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-08 09:24:49 --> Model Class Initialized
DEBUG - 2024-04-08 09:24:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-08 09:24:49 --> Model Class Initialized
INFO - 2024-04-08 09:24:49 --> Model Class Initialized
INFO - 2024-04-08 09:24:49 --> Model Class Initialized
INFO - 2024-04-08 09:24:49 --> Model Class Initialized
DEBUG - 2024-04-08 09:24:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-08 09:24:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-08 09:24:49 --> Model Class Initialized
INFO - 2024-04-08 09:24:49 --> Model Class Initialized
INFO - 2024-04-08 09:24:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-08 09:24:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-08 09:24:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-08 09:24:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-08 09:24:50 --> Model Class Initialized
INFO - 2024-04-08 09:24:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-08 09:24:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-08 09:24:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-08 09:24:50 --> Final output sent to browser
DEBUG - 2024-04-08 09:24:50 --> Total execution time: 0.4466
ERROR - 2024-04-08 09:51:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-08 09:51:20 --> Config Class Initialized
INFO - 2024-04-08 09:51:20 --> Hooks Class Initialized
DEBUG - 2024-04-08 09:51:20 --> UTF-8 Support Enabled
INFO - 2024-04-08 09:51:20 --> Utf8 Class Initialized
INFO - 2024-04-08 09:51:20 --> URI Class Initialized
INFO - 2024-04-08 09:51:20 --> Router Class Initialized
INFO - 2024-04-08 09:51:20 --> Output Class Initialized
INFO - 2024-04-08 09:51:20 --> Security Class Initialized
DEBUG - 2024-04-08 09:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-08 09:51:20 --> Input Class Initialized
INFO - 2024-04-08 09:51:20 --> Language Class Initialized
INFO - 2024-04-08 09:51:20 --> Loader Class Initialized
INFO - 2024-04-08 09:51:20 --> Helper loaded: url_helper
INFO - 2024-04-08 09:51:20 --> Helper loaded: file_helper
INFO - 2024-04-08 09:51:20 --> Helper loaded: html_helper
INFO - 2024-04-08 09:51:20 --> Helper loaded: text_helper
INFO - 2024-04-08 09:51:20 --> Helper loaded: form_helper
INFO - 2024-04-08 09:51:20 --> Helper loaded: lang_helper
INFO - 2024-04-08 09:51:20 --> Helper loaded: security_helper
INFO - 2024-04-08 09:51:20 --> Helper loaded: cookie_helper
INFO - 2024-04-08 09:51:20 --> Database Driver Class Initialized
INFO - 2024-04-08 09:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-08 09:51:21 --> Parser Class Initialized
INFO - 2024-04-08 09:51:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-08 09:51:21 --> Pagination Class Initialized
INFO - 2024-04-08 09:51:21 --> Form Validation Class Initialized
INFO - 2024-04-08 09:51:21 --> Controller Class Initialized
INFO - 2024-04-08 09:51:21 --> Model Class Initialized
DEBUG - 2024-04-08 09:51:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-08 09:51:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-08 09:51:21 --> Model Class Initialized
DEBUG - 2024-04-08 09:51:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-08 09:51:21 --> Model Class Initialized
INFO - 2024-04-08 09:51:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-04-08 09:51:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-08 09:51:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-08 09:51:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-08 09:51:21 --> Model Class Initialized
INFO - 2024-04-08 09:51:21 --> Model Class Initialized
INFO - 2024-04-08 09:51:21 --> Model Class Initialized
INFO - 2024-04-08 09:51:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-08 09:51:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-08 09:51:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-08 09:51:21 --> Final output sent to browser
DEBUG - 2024-04-08 09:51:21 --> Total execution time: 0.2356
ERROR - 2024-04-08 09:51:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-08 09:51:21 --> Config Class Initialized
INFO - 2024-04-08 09:51:21 --> Hooks Class Initialized
DEBUG - 2024-04-08 09:51:21 --> UTF-8 Support Enabled
INFO - 2024-04-08 09:51:21 --> Utf8 Class Initialized
INFO - 2024-04-08 09:51:21 --> URI Class Initialized
INFO - 2024-04-08 09:51:21 --> Router Class Initialized
INFO - 2024-04-08 09:51:21 --> Output Class Initialized
INFO - 2024-04-08 09:51:21 --> Security Class Initialized
DEBUG - 2024-04-08 09:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-08 09:51:21 --> Input Class Initialized
INFO - 2024-04-08 09:51:21 --> Language Class Initialized
INFO - 2024-04-08 09:51:21 --> Loader Class Initialized
INFO - 2024-04-08 09:51:21 --> Helper loaded: url_helper
INFO - 2024-04-08 09:51:21 --> Helper loaded: file_helper
INFO - 2024-04-08 09:51:21 --> Helper loaded: html_helper
INFO - 2024-04-08 09:51:21 --> Helper loaded: text_helper
INFO - 2024-04-08 09:51:21 --> Helper loaded: form_helper
INFO - 2024-04-08 09:51:21 --> Helper loaded: lang_helper
INFO - 2024-04-08 09:51:21 --> Helper loaded: security_helper
INFO - 2024-04-08 09:51:21 --> Helper loaded: cookie_helper
INFO - 2024-04-08 09:51:21 --> Database Driver Class Initialized
INFO - 2024-04-08 09:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-08 09:51:21 --> Parser Class Initialized
INFO - 2024-04-08 09:51:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-08 09:51:21 --> Pagination Class Initialized
INFO - 2024-04-08 09:51:21 --> Form Validation Class Initialized
INFO - 2024-04-08 09:51:21 --> Controller Class Initialized
INFO - 2024-04-08 09:51:21 --> Model Class Initialized
DEBUG - 2024-04-08 09:51:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-08 09:51:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-08 09:51:21 --> Model Class Initialized
DEBUG - 2024-04-08 09:51:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-08 09:51:21 --> Model Class Initialized
INFO - 2024-04-08 09:51:22 --> Final output sent to browser
DEBUG - 2024-04-08 09:51:22 --> Total execution time: 0.0576
ERROR - 2024-04-08 09:51:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-08 09:51:28 --> Config Class Initialized
INFO - 2024-04-08 09:51:28 --> Hooks Class Initialized
DEBUG - 2024-04-08 09:51:28 --> UTF-8 Support Enabled
INFO - 2024-04-08 09:51:28 --> Utf8 Class Initialized
INFO - 2024-04-08 09:51:28 --> URI Class Initialized
INFO - 2024-04-08 09:51:28 --> Router Class Initialized
INFO - 2024-04-08 09:51:28 --> Output Class Initialized
INFO - 2024-04-08 09:51:28 --> Security Class Initialized
DEBUG - 2024-04-08 09:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-08 09:51:28 --> Input Class Initialized
INFO - 2024-04-08 09:51:28 --> Language Class Initialized
INFO - 2024-04-08 09:51:28 --> Loader Class Initialized
INFO - 2024-04-08 09:51:28 --> Helper loaded: url_helper
INFO - 2024-04-08 09:51:28 --> Helper loaded: file_helper
INFO - 2024-04-08 09:51:28 --> Helper loaded: html_helper
INFO - 2024-04-08 09:51:28 --> Helper loaded: text_helper
INFO - 2024-04-08 09:51:28 --> Helper loaded: form_helper
INFO - 2024-04-08 09:51:28 --> Helper loaded: lang_helper
INFO - 2024-04-08 09:51:28 --> Helper loaded: security_helper
INFO - 2024-04-08 09:51:28 --> Helper loaded: cookie_helper
INFO - 2024-04-08 09:51:28 --> Database Driver Class Initialized
INFO - 2024-04-08 09:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-08 09:51:28 --> Parser Class Initialized
INFO - 2024-04-08 09:51:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-08 09:51:28 --> Pagination Class Initialized
INFO - 2024-04-08 09:51:28 --> Form Validation Class Initialized
INFO - 2024-04-08 09:51:28 --> Controller Class Initialized
INFO - 2024-04-08 09:51:28 --> Model Class Initialized
DEBUG - 2024-04-08 09:51:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-08 09:51:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-08 09:51:28 --> Model Class Initialized
DEBUG - 2024-04-08 09:51:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-08 09:51:28 --> Model Class Initialized
INFO - 2024-04-08 09:51:30 --> Final output sent to browser
DEBUG - 2024-04-08 09:51:30 --> Total execution time: 1.4650
ERROR - 2024-04-08 14:35:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-08 14:35:00 --> Config Class Initialized
INFO - 2024-04-08 14:35:00 --> Hooks Class Initialized
DEBUG - 2024-04-08 14:35:00 --> UTF-8 Support Enabled
INFO - 2024-04-08 14:35:00 --> Utf8 Class Initialized
INFO - 2024-04-08 14:35:00 --> URI Class Initialized
INFO - 2024-04-08 14:35:00 --> Router Class Initialized
INFO - 2024-04-08 14:35:00 --> Output Class Initialized
INFO - 2024-04-08 14:35:00 --> Security Class Initialized
DEBUG - 2024-04-08 14:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-08 14:35:00 --> Input Class Initialized
INFO - 2024-04-08 14:35:00 --> Language Class Initialized
ERROR - 2024-04-08 14:35:00 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-04-08 18:05:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-08 18:05:05 --> Config Class Initialized
INFO - 2024-04-08 18:05:05 --> Hooks Class Initialized
DEBUG - 2024-04-08 18:05:05 --> UTF-8 Support Enabled
INFO - 2024-04-08 18:05:05 --> Utf8 Class Initialized
INFO - 2024-04-08 18:05:05 --> URI Class Initialized
INFO - 2024-04-08 18:05:05 --> Router Class Initialized
INFO - 2024-04-08 18:05:05 --> Output Class Initialized
INFO - 2024-04-08 18:05:05 --> Security Class Initialized
DEBUG - 2024-04-08 18:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-08 18:05:05 --> Input Class Initialized
INFO - 2024-04-08 18:05:05 --> Language Class Initialized
ERROR - 2024-04-08 18:05:05 --> 404 Page Not Found: Well-known/assetlinks.json
