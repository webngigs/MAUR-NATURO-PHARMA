<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-04-06 04:33:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 04:33:32 --> Config Class Initialized
INFO - 2024-04-06 04:33:32 --> Hooks Class Initialized
DEBUG - 2024-04-06 04:33:32 --> UTF-8 Support Enabled
INFO - 2024-04-06 04:33:32 --> Utf8 Class Initialized
INFO - 2024-04-06 04:33:32 --> URI Class Initialized
DEBUG - 2024-04-06 04:33:32 --> No URI present. Default controller set.
INFO - 2024-04-06 04:33:32 --> Router Class Initialized
INFO - 2024-04-06 04:33:32 --> Output Class Initialized
INFO - 2024-04-06 04:33:32 --> Security Class Initialized
DEBUG - 2024-04-06 04:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 04:33:32 --> Input Class Initialized
INFO - 2024-04-06 04:33:32 --> Language Class Initialized
INFO - 2024-04-06 04:33:32 --> Loader Class Initialized
INFO - 2024-04-06 04:33:32 --> Helper loaded: url_helper
INFO - 2024-04-06 04:33:32 --> Helper loaded: file_helper
INFO - 2024-04-06 04:33:32 --> Helper loaded: html_helper
INFO - 2024-04-06 04:33:32 --> Helper loaded: text_helper
INFO - 2024-04-06 04:33:32 --> Helper loaded: form_helper
INFO - 2024-04-06 04:33:32 --> Helper loaded: lang_helper
INFO - 2024-04-06 04:33:32 --> Helper loaded: security_helper
INFO - 2024-04-06 04:33:32 --> Helper loaded: cookie_helper
INFO - 2024-04-06 04:33:32 --> Database Driver Class Initialized
INFO - 2024-04-06 04:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 04:33:32 --> Parser Class Initialized
INFO - 2024-04-06 04:33:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 04:33:32 --> Pagination Class Initialized
INFO - 2024-04-06 04:33:32 --> Form Validation Class Initialized
INFO - 2024-04-06 04:33:32 --> Controller Class Initialized
INFO - 2024-04-06 04:33:32 --> Model Class Initialized
DEBUG - 2024-04-06 04:33:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-04-06 05:51:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 05:51:57 --> Config Class Initialized
INFO - 2024-04-06 05:51:57 --> Hooks Class Initialized
DEBUG - 2024-04-06 05:51:57 --> UTF-8 Support Enabled
INFO - 2024-04-06 05:51:57 --> Utf8 Class Initialized
INFO - 2024-04-06 05:51:57 --> URI Class Initialized
DEBUG - 2024-04-06 05:51:57 --> No URI present. Default controller set.
INFO - 2024-04-06 05:51:57 --> Router Class Initialized
INFO - 2024-04-06 05:51:57 --> Output Class Initialized
INFO - 2024-04-06 05:51:57 --> Security Class Initialized
DEBUG - 2024-04-06 05:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 05:51:57 --> Input Class Initialized
INFO - 2024-04-06 05:51:57 --> Language Class Initialized
INFO - 2024-04-06 05:51:57 --> Loader Class Initialized
INFO - 2024-04-06 05:51:57 --> Helper loaded: url_helper
INFO - 2024-04-06 05:51:57 --> Helper loaded: file_helper
INFO - 2024-04-06 05:51:57 --> Helper loaded: html_helper
INFO - 2024-04-06 05:51:57 --> Helper loaded: text_helper
INFO - 2024-04-06 05:51:57 --> Helper loaded: form_helper
INFO - 2024-04-06 05:51:57 --> Helper loaded: lang_helper
INFO - 2024-04-06 05:51:57 --> Helper loaded: security_helper
INFO - 2024-04-06 05:51:57 --> Helper loaded: cookie_helper
INFO - 2024-04-06 05:51:57 --> Database Driver Class Initialized
INFO - 2024-04-06 05:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 05:51:57 --> Parser Class Initialized
INFO - 2024-04-06 05:51:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 05:51:57 --> Pagination Class Initialized
INFO - 2024-04-06 05:51:57 --> Form Validation Class Initialized
INFO - 2024-04-06 05:51:57 --> Controller Class Initialized
INFO - 2024-04-06 05:51:57 --> Model Class Initialized
DEBUG - 2024-04-06 05:51:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-04-06 05:51:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 05:51:57 --> Config Class Initialized
INFO - 2024-04-06 05:51:57 --> Hooks Class Initialized
DEBUG - 2024-04-06 05:51:57 --> UTF-8 Support Enabled
INFO - 2024-04-06 05:51:57 --> Utf8 Class Initialized
INFO - 2024-04-06 05:51:57 --> URI Class Initialized
INFO - 2024-04-06 05:51:57 --> Router Class Initialized
INFO - 2024-04-06 05:51:57 --> Output Class Initialized
INFO - 2024-04-06 05:51:57 --> Security Class Initialized
DEBUG - 2024-04-06 05:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 05:51:57 --> Input Class Initialized
INFO - 2024-04-06 05:51:57 --> Language Class Initialized
INFO - 2024-04-06 05:51:57 --> Loader Class Initialized
INFO - 2024-04-06 05:51:57 --> Helper loaded: url_helper
INFO - 2024-04-06 05:51:57 --> Helper loaded: file_helper
INFO - 2024-04-06 05:51:57 --> Helper loaded: html_helper
INFO - 2024-04-06 05:51:57 --> Helper loaded: text_helper
INFO - 2024-04-06 05:51:57 --> Helper loaded: form_helper
INFO - 2024-04-06 05:51:57 --> Helper loaded: lang_helper
INFO - 2024-04-06 05:51:57 --> Helper loaded: security_helper
INFO - 2024-04-06 05:51:57 --> Helper loaded: cookie_helper
INFO - 2024-04-06 05:51:57 --> Database Driver Class Initialized
INFO - 2024-04-06 05:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 05:51:57 --> Parser Class Initialized
INFO - 2024-04-06 05:51:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 05:51:57 --> Pagination Class Initialized
INFO - 2024-04-06 05:51:57 --> Form Validation Class Initialized
INFO - 2024-04-06 05:51:57 --> Controller Class Initialized
INFO - 2024-04-06 05:51:57 --> Model Class Initialized
DEBUG - 2024-04-06 05:51:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 05:51:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-04-06 05:51:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-06 05:51:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-06 05:51:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-06 05:51:57 --> Model Class Initialized
INFO - 2024-04-06 05:51:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-06 05:51:57 --> Final output sent to browser
DEBUG - 2024-04-06 05:51:57 --> Total execution time: 0.2465
ERROR - 2024-04-06 05:52:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 05:52:02 --> Config Class Initialized
INFO - 2024-04-06 05:52:02 --> Hooks Class Initialized
DEBUG - 2024-04-06 05:52:02 --> UTF-8 Support Enabled
INFO - 2024-04-06 05:52:02 --> Utf8 Class Initialized
INFO - 2024-04-06 05:52:02 --> URI Class Initialized
INFO - 2024-04-06 05:52:02 --> Router Class Initialized
INFO - 2024-04-06 05:52:02 --> Output Class Initialized
INFO - 2024-04-06 05:52:02 --> Security Class Initialized
DEBUG - 2024-04-06 05:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 05:52:02 --> Input Class Initialized
INFO - 2024-04-06 05:52:02 --> Language Class Initialized
INFO - 2024-04-06 05:52:02 --> Loader Class Initialized
INFO - 2024-04-06 05:52:02 --> Helper loaded: url_helper
INFO - 2024-04-06 05:52:02 --> Helper loaded: file_helper
INFO - 2024-04-06 05:52:02 --> Helper loaded: html_helper
INFO - 2024-04-06 05:52:02 --> Helper loaded: text_helper
INFO - 2024-04-06 05:52:02 --> Helper loaded: form_helper
INFO - 2024-04-06 05:52:02 --> Helper loaded: lang_helper
INFO - 2024-04-06 05:52:02 --> Helper loaded: security_helper
INFO - 2024-04-06 05:52:02 --> Helper loaded: cookie_helper
INFO - 2024-04-06 05:52:02 --> Database Driver Class Initialized
INFO - 2024-04-06 05:52:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 05:52:02 --> Parser Class Initialized
INFO - 2024-04-06 05:52:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 05:52:02 --> Pagination Class Initialized
INFO - 2024-04-06 05:52:02 --> Form Validation Class Initialized
INFO - 2024-04-06 05:52:02 --> Controller Class Initialized
INFO - 2024-04-06 05:52:02 --> Model Class Initialized
DEBUG - 2024-04-06 05:52:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 05:52:02 --> Model Class Initialized
INFO - 2024-04-06 05:52:02 --> Final output sent to browser
DEBUG - 2024-04-06 05:52:02 --> Total execution time: 0.0215
ERROR - 2024-04-06 05:52:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 05:52:03 --> Config Class Initialized
INFO - 2024-04-06 05:52:03 --> Hooks Class Initialized
DEBUG - 2024-04-06 05:52:03 --> UTF-8 Support Enabled
INFO - 2024-04-06 05:52:03 --> Utf8 Class Initialized
INFO - 2024-04-06 05:52:03 --> URI Class Initialized
DEBUG - 2024-04-06 05:52:03 --> No URI present. Default controller set.
INFO - 2024-04-06 05:52:03 --> Router Class Initialized
INFO - 2024-04-06 05:52:03 --> Output Class Initialized
INFO - 2024-04-06 05:52:03 --> Security Class Initialized
DEBUG - 2024-04-06 05:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 05:52:03 --> Input Class Initialized
INFO - 2024-04-06 05:52:03 --> Language Class Initialized
INFO - 2024-04-06 05:52:03 --> Loader Class Initialized
INFO - 2024-04-06 05:52:03 --> Helper loaded: url_helper
INFO - 2024-04-06 05:52:03 --> Helper loaded: file_helper
INFO - 2024-04-06 05:52:03 --> Helper loaded: html_helper
INFO - 2024-04-06 05:52:03 --> Helper loaded: text_helper
INFO - 2024-04-06 05:52:03 --> Helper loaded: form_helper
INFO - 2024-04-06 05:52:03 --> Helper loaded: lang_helper
INFO - 2024-04-06 05:52:03 --> Helper loaded: security_helper
INFO - 2024-04-06 05:52:03 --> Helper loaded: cookie_helper
INFO - 2024-04-06 05:52:03 --> Database Driver Class Initialized
INFO - 2024-04-06 05:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 05:52:03 --> Parser Class Initialized
INFO - 2024-04-06 05:52:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 05:52:03 --> Pagination Class Initialized
INFO - 2024-04-06 05:52:03 --> Form Validation Class Initialized
INFO - 2024-04-06 05:52:03 --> Controller Class Initialized
INFO - 2024-04-06 05:52:03 --> Model Class Initialized
DEBUG - 2024-04-06 05:52:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 05:52:03 --> Model Class Initialized
DEBUG - 2024-04-06 05:52:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 05:52:03 --> Model Class Initialized
INFO - 2024-04-06 05:52:03 --> Model Class Initialized
INFO - 2024-04-06 05:52:03 --> Model Class Initialized
INFO - 2024-04-06 05:52:03 --> Model Class Initialized
DEBUG - 2024-04-06 05:52:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-06 05:52:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 05:52:03 --> Model Class Initialized
INFO - 2024-04-06 05:52:03 --> Model Class Initialized
INFO - 2024-04-06 05:52:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-06 05:52:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-06 05:52:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-06 05:52:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-06 05:52:03 --> Model Class Initialized
INFO - 2024-04-06 05:52:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-06 05:52:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-06 05:52:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-06 05:52:03 --> Final output sent to browser
DEBUG - 2024-04-06 05:52:03 --> Total execution time: 0.4952
ERROR - 2024-04-06 05:52:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 05:52:04 --> Config Class Initialized
INFO - 2024-04-06 05:52:04 --> Hooks Class Initialized
DEBUG - 2024-04-06 05:52:04 --> UTF-8 Support Enabled
INFO - 2024-04-06 05:52:04 --> Utf8 Class Initialized
INFO - 2024-04-06 05:52:04 --> URI Class Initialized
INFO - 2024-04-06 05:52:04 --> Router Class Initialized
INFO - 2024-04-06 05:52:04 --> Output Class Initialized
INFO - 2024-04-06 05:52:04 --> Security Class Initialized
DEBUG - 2024-04-06 05:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 05:52:04 --> Input Class Initialized
INFO - 2024-04-06 05:52:04 --> Language Class Initialized
INFO - 2024-04-06 05:52:04 --> Loader Class Initialized
INFO - 2024-04-06 05:52:04 --> Helper loaded: url_helper
INFO - 2024-04-06 05:52:04 --> Helper loaded: file_helper
INFO - 2024-04-06 05:52:04 --> Helper loaded: html_helper
INFO - 2024-04-06 05:52:04 --> Helper loaded: text_helper
INFO - 2024-04-06 05:52:04 --> Helper loaded: form_helper
INFO - 2024-04-06 05:52:04 --> Helper loaded: lang_helper
INFO - 2024-04-06 05:52:04 --> Helper loaded: security_helper
INFO - 2024-04-06 05:52:04 --> Helper loaded: cookie_helper
INFO - 2024-04-06 05:52:04 --> Database Driver Class Initialized
INFO - 2024-04-06 05:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 05:52:04 --> Parser Class Initialized
INFO - 2024-04-06 05:52:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 05:52:04 --> Pagination Class Initialized
INFO - 2024-04-06 05:52:04 --> Form Validation Class Initialized
INFO - 2024-04-06 05:52:04 --> Controller Class Initialized
DEBUG - 2024-04-06 05:52:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-06 05:52:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 05:52:04 --> Model Class Initialized
INFO - 2024-04-06 05:52:04 --> Final output sent to browser
DEBUG - 2024-04-06 05:52:04 --> Total execution time: 0.0151
ERROR - 2024-04-06 05:52:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 05:52:08 --> Config Class Initialized
INFO - 2024-04-06 05:52:08 --> Hooks Class Initialized
DEBUG - 2024-04-06 05:52:08 --> UTF-8 Support Enabled
INFO - 2024-04-06 05:52:08 --> Utf8 Class Initialized
INFO - 2024-04-06 05:52:08 --> URI Class Initialized
INFO - 2024-04-06 05:52:08 --> Router Class Initialized
INFO - 2024-04-06 05:52:08 --> Output Class Initialized
INFO - 2024-04-06 05:52:08 --> Security Class Initialized
DEBUG - 2024-04-06 05:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 05:52:08 --> Input Class Initialized
INFO - 2024-04-06 05:52:08 --> Language Class Initialized
INFO - 2024-04-06 05:52:08 --> Loader Class Initialized
INFO - 2024-04-06 05:52:08 --> Helper loaded: url_helper
INFO - 2024-04-06 05:52:08 --> Helper loaded: file_helper
INFO - 2024-04-06 05:52:08 --> Helper loaded: html_helper
INFO - 2024-04-06 05:52:08 --> Helper loaded: text_helper
INFO - 2024-04-06 05:52:08 --> Helper loaded: form_helper
INFO - 2024-04-06 05:52:08 --> Helper loaded: lang_helper
INFO - 2024-04-06 05:52:08 --> Helper loaded: security_helper
INFO - 2024-04-06 05:52:08 --> Helper loaded: cookie_helper
INFO - 2024-04-06 05:52:08 --> Database Driver Class Initialized
INFO - 2024-04-06 05:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 05:52:08 --> Parser Class Initialized
INFO - 2024-04-06 05:52:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 05:52:08 --> Pagination Class Initialized
INFO - 2024-04-06 05:52:08 --> Form Validation Class Initialized
INFO - 2024-04-06 05:52:08 --> Controller Class Initialized
INFO - 2024-04-06 05:52:08 --> Model Class Initialized
DEBUG - 2024-04-06 05:52:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-06 05:52:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 05:52:08 --> Model Class Initialized
DEBUG - 2024-04-06 05:52:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 05:52:08 --> Model Class Initialized
INFO - 2024-04-06 05:52:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-04-06 05:52:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-06 05:52:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-06 05:52:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-06 05:52:08 --> Model Class Initialized
INFO - 2024-04-06 05:52:08 --> Model Class Initialized
INFO - 2024-04-06 05:52:08 --> Model Class Initialized
INFO - 2024-04-06 05:52:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-06 05:52:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-06 05:52:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-06 05:52:09 --> Final output sent to browser
DEBUG - 2024-04-06 05:52:09 --> Total execution time: 0.2460
ERROR - 2024-04-06 05:52:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 05:52:09 --> Config Class Initialized
INFO - 2024-04-06 05:52:09 --> Hooks Class Initialized
DEBUG - 2024-04-06 05:52:09 --> UTF-8 Support Enabled
INFO - 2024-04-06 05:52:09 --> Utf8 Class Initialized
INFO - 2024-04-06 05:52:09 --> URI Class Initialized
INFO - 2024-04-06 05:52:09 --> Router Class Initialized
INFO - 2024-04-06 05:52:09 --> Output Class Initialized
INFO - 2024-04-06 05:52:09 --> Security Class Initialized
DEBUG - 2024-04-06 05:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 05:52:09 --> Input Class Initialized
INFO - 2024-04-06 05:52:09 --> Language Class Initialized
INFO - 2024-04-06 05:52:09 --> Loader Class Initialized
INFO - 2024-04-06 05:52:09 --> Helper loaded: url_helper
INFO - 2024-04-06 05:52:09 --> Helper loaded: file_helper
INFO - 2024-04-06 05:52:09 --> Helper loaded: html_helper
INFO - 2024-04-06 05:52:09 --> Helper loaded: text_helper
INFO - 2024-04-06 05:52:09 --> Helper loaded: form_helper
INFO - 2024-04-06 05:52:09 --> Helper loaded: lang_helper
INFO - 2024-04-06 05:52:09 --> Helper loaded: security_helper
INFO - 2024-04-06 05:52:09 --> Helper loaded: cookie_helper
INFO - 2024-04-06 05:52:09 --> Database Driver Class Initialized
INFO - 2024-04-06 05:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 05:52:09 --> Parser Class Initialized
INFO - 2024-04-06 05:52:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 05:52:09 --> Pagination Class Initialized
INFO - 2024-04-06 05:52:09 --> Form Validation Class Initialized
INFO - 2024-04-06 05:52:09 --> Controller Class Initialized
INFO - 2024-04-06 05:52:09 --> Model Class Initialized
DEBUG - 2024-04-06 05:52:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-06 05:52:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 05:52:09 --> Model Class Initialized
DEBUG - 2024-04-06 05:52:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 05:52:09 --> Model Class Initialized
INFO - 2024-04-06 05:52:09 --> Final output sent to browser
DEBUG - 2024-04-06 05:52:09 --> Total execution time: 0.0638
ERROR - 2024-04-06 05:52:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 05:52:23 --> Config Class Initialized
INFO - 2024-04-06 05:52:23 --> Hooks Class Initialized
DEBUG - 2024-04-06 05:52:23 --> UTF-8 Support Enabled
INFO - 2024-04-06 05:52:23 --> Utf8 Class Initialized
INFO - 2024-04-06 05:52:23 --> URI Class Initialized
INFO - 2024-04-06 05:52:23 --> Router Class Initialized
INFO - 2024-04-06 05:52:23 --> Output Class Initialized
INFO - 2024-04-06 05:52:23 --> Security Class Initialized
DEBUG - 2024-04-06 05:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 05:52:23 --> Input Class Initialized
INFO - 2024-04-06 05:52:23 --> Language Class Initialized
INFO - 2024-04-06 05:52:23 --> Loader Class Initialized
INFO - 2024-04-06 05:52:23 --> Helper loaded: url_helper
INFO - 2024-04-06 05:52:23 --> Helper loaded: file_helper
INFO - 2024-04-06 05:52:23 --> Helper loaded: html_helper
INFO - 2024-04-06 05:52:23 --> Helper loaded: text_helper
INFO - 2024-04-06 05:52:23 --> Helper loaded: form_helper
INFO - 2024-04-06 05:52:23 --> Helper loaded: lang_helper
INFO - 2024-04-06 05:52:23 --> Helper loaded: security_helper
INFO - 2024-04-06 05:52:23 --> Helper loaded: cookie_helper
INFO - 2024-04-06 05:52:23 --> Database Driver Class Initialized
INFO - 2024-04-06 05:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 05:52:23 --> Parser Class Initialized
INFO - 2024-04-06 05:52:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 05:52:23 --> Pagination Class Initialized
INFO - 2024-04-06 05:52:23 --> Form Validation Class Initialized
INFO - 2024-04-06 05:52:23 --> Controller Class Initialized
INFO - 2024-04-06 05:52:23 --> Model Class Initialized
DEBUG - 2024-04-06 05:52:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-06 05:52:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 05:52:23 --> Model Class Initialized
DEBUG - 2024-04-06 05:52:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 05:52:23 --> Model Class Initialized
INFO - 2024-04-06 05:52:25 --> Final output sent to browser
DEBUG - 2024-04-06 05:52:25 --> Total execution time: 1.8586
ERROR - 2024-04-06 05:52:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 05:52:43 --> Config Class Initialized
INFO - 2024-04-06 05:52:43 --> Hooks Class Initialized
DEBUG - 2024-04-06 05:52:43 --> UTF-8 Support Enabled
INFO - 2024-04-06 05:52:43 --> Utf8 Class Initialized
INFO - 2024-04-06 05:52:43 --> URI Class Initialized
DEBUG - 2024-04-06 05:52:43 --> No URI present. Default controller set.
INFO - 2024-04-06 05:52:43 --> Router Class Initialized
INFO - 2024-04-06 05:52:43 --> Output Class Initialized
INFO - 2024-04-06 05:52:43 --> Security Class Initialized
DEBUG - 2024-04-06 05:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 05:52:43 --> Input Class Initialized
INFO - 2024-04-06 05:52:43 --> Language Class Initialized
INFO - 2024-04-06 05:52:43 --> Loader Class Initialized
INFO - 2024-04-06 05:52:43 --> Helper loaded: url_helper
INFO - 2024-04-06 05:52:43 --> Helper loaded: file_helper
INFO - 2024-04-06 05:52:43 --> Helper loaded: html_helper
INFO - 2024-04-06 05:52:43 --> Helper loaded: text_helper
INFO - 2024-04-06 05:52:43 --> Helper loaded: form_helper
INFO - 2024-04-06 05:52:43 --> Helper loaded: lang_helper
INFO - 2024-04-06 05:52:43 --> Helper loaded: security_helper
INFO - 2024-04-06 05:52:43 --> Helper loaded: cookie_helper
INFO - 2024-04-06 05:52:43 --> Database Driver Class Initialized
INFO - 2024-04-06 05:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 05:52:43 --> Parser Class Initialized
INFO - 2024-04-06 05:52:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 05:52:43 --> Pagination Class Initialized
INFO - 2024-04-06 05:52:43 --> Form Validation Class Initialized
INFO - 2024-04-06 05:52:43 --> Controller Class Initialized
INFO - 2024-04-06 05:52:43 --> Model Class Initialized
DEBUG - 2024-04-06 05:52:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 05:52:43 --> Model Class Initialized
DEBUG - 2024-04-06 05:52:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 05:52:43 --> Model Class Initialized
INFO - 2024-04-06 05:52:43 --> Model Class Initialized
INFO - 2024-04-06 05:52:43 --> Model Class Initialized
INFO - 2024-04-06 05:52:43 --> Model Class Initialized
DEBUG - 2024-04-06 05:52:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-06 05:52:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 05:52:43 --> Model Class Initialized
INFO - 2024-04-06 05:52:43 --> Model Class Initialized
INFO - 2024-04-06 05:52:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-06 05:52:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-06 05:52:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-06 05:52:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-06 05:52:43 --> Model Class Initialized
INFO - 2024-04-06 05:52:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-06 05:52:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-06 05:52:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-06 05:52:43 --> Final output sent to browser
DEBUG - 2024-04-06 05:52:43 --> Total execution time: 0.5010
ERROR - 2024-04-06 05:52:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 05:52:45 --> Config Class Initialized
INFO - 2024-04-06 05:52:45 --> Hooks Class Initialized
DEBUG - 2024-04-06 05:52:45 --> UTF-8 Support Enabled
INFO - 2024-04-06 05:52:45 --> Utf8 Class Initialized
INFO - 2024-04-06 05:52:45 --> URI Class Initialized
INFO - 2024-04-06 05:52:45 --> Router Class Initialized
INFO - 2024-04-06 05:52:45 --> Output Class Initialized
INFO - 2024-04-06 05:52:45 --> Security Class Initialized
DEBUG - 2024-04-06 05:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 05:52:45 --> Input Class Initialized
INFO - 2024-04-06 05:52:45 --> Language Class Initialized
INFO - 2024-04-06 05:52:45 --> Loader Class Initialized
INFO - 2024-04-06 05:52:45 --> Helper loaded: url_helper
INFO - 2024-04-06 05:52:45 --> Helper loaded: file_helper
INFO - 2024-04-06 05:52:45 --> Helper loaded: html_helper
INFO - 2024-04-06 05:52:45 --> Helper loaded: text_helper
INFO - 2024-04-06 05:52:45 --> Helper loaded: form_helper
INFO - 2024-04-06 05:52:45 --> Helper loaded: lang_helper
INFO - 2024-04-06 05:52:45 --> Helper loaded: security_helper
INFO - 2024-04-06 05:52:45 --> Helper loaded: cookie_helper
INFO - 2024-04-06 05:52:45 --> Database Driver Class Initialized
INFO - 2024-04-06 05:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 05:52:45 --> Parser Class Initialized
INFO - 2024-04-06 05:52:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 05:52:45 --> Pagination Class Initialized
INFO - 2024-04-06 05:52:45 --> Form Validation Class Initialized
INFO - 2024-04-06 05:52:45 --> Controller Class Initialized
DEBUG - 2024-04-06 05:52:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-06 05:52:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 05:52:45 --> Model Class Initialized
INFO - 2024-04-06 05:52:45 --> Model Class Initialized
DEBUG - 2024-04-06 05:52:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-06 05:52:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 05:52:45 --> Model Class Initialized
DEBUG - 2024-04-06 05:52:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 05:52:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gst/list.php
DEBUG - 2024-04-06 05:52:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-06 05:52:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-06 05:52:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-06 05:52:45 --> Model Class Initialized
INFO - 2024-04-06 05:52:45 --> Model Class Initialized
INFO - 2024-04-06 05:52:45 --> Model Class Initialized
INFO - 2024-04-06 05:52:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-06 05:52:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-06 05:52:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-06 05:52:45 --> Final output sent to browser
DEBUG - 2024-04-06 05:52:45 --> Total execution time: 0.2709
ERROR - 2024-04-06 12:06:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 12:06:38 --> Config Class Initialized
INFO - 2024-04-06 12:06:38 --> Hooks Class Initialized
DEBUG - 2024-04-06 12:06:38 --> UTF-8 Support Enabled
INFO - 2024-04-06 12:06:38 --> Utf8 Class Initialized
INFO - 2024-04-06 12:06:38 --> URI Class Initialized
INFO - 2024-04-06 12:06:38 --> Router Class Initialized
INFO - 2024-04-06 12:06:38 --> Output Class Initialized
INFO - 2024-04-06 12:06:38 --> Security Class Initialized
DEBUG - 2024-04-06 12:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 12:06:38 --> Input Class Initialized
INFO - 2024-04-06 12:06:38 --> Language Class Initialized
INFO - 2024-04-06 12:06:38 --> Loader Class Initialized
INFO - 2024-04-06 12:06:38 --> Helper loaded: url_helper
INFO - 2024-04-06 12:06:38 --> Helper loaded: file_helper
INFO - 2024-04-06 12:06:38 --> Helper loaded: html_helper
INFO - 2024-04-06 12:06:38 --> Helper loaded: text_helper
INFO - 2024-04-06 12:06:38 --> Helper loaded: form_helper
INFO - 2024-04-06 12:06:38 --> Helper loaded: lang_helper
INFO - 2024-04-06 12:06:38 --> Helper loaded: security_helper
INFO - 2024-04-06 12:06:38 --> Helper loaded: cookie_helper
INFO - 2024-04-06 12:06:38 --> Database Driver Class Initialized
INFO - 2024-04-06 12:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 12:06:38 --> Parser Class Initialized
INFO - 2024-04-06 12:06:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 12:06:38 --> Pagination Class Initialized
INFO - 2024-04-06 12:06:38 --> Form Validation Class Initialized
INFO - 2024-04-06 12:06:38 --> Controller Class Initialized
ERROR - 2024-04-06 12:06:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 12:06:39 --> Config Class Initialized
INFO - 2024-04-06 12:06:39 --> Hooks Class Initialized
DEBUG - 2024-04-06 12:06:39 --> UTF-8 Support Enabled
INFO - 2024-04-06 12:06:39 --> Utf8 Class Initialized
INFO - 2024-04-06 12:06:39 --> URI Class Initialized
INFO - 2024-04-06 12:06:39 --> Router Class Initialized
INFO - 2024-04-06 12:06:39 --> Output Class Initialized
INFO - 2024-04-06 12:06:39 --> Security Class Initialized
DEBUG - 2024-04-06 12:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 12:06:39 --> Input Class Initialized
INFO - 2024-04-06 12:06:39 --> Language Class Initialized
INFO - 2024-04-06 12:06:39 --> Loader Class Initialized
INFO - 2024-04-06 12:06:39 --> Helper loaded: url_helper
INFO - 2024-04-06 12:06:39 --> Helper loaded: file_helper
INFO - 2024-04-06 12:06:39 --> Helper loaded: html_helper
INFO - 2024-04-06 12:06:39 --> Helper loaded: text_helper
INFO - 2024-04-06 12:06:39 --> Helper loaded: form_helper
INFO - 2024-04-06 12:06:39 --> Helper loaded: lang_helper
INFO - 2024-04-06 12:06:39 --> Helper loaded: security_helper
INFO - 2024-04-06 12:06:39 --> Helper loaded: cookie_helper
INFO - 2024-04-06 12:06:39 --> Database Driver Class Initialized
INFO - 2024-04-06 12:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 12:06:39 --> Parser Class Initialized
INFO - 2024-04-06 12:06:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 12:06:39 --> Pagination Class Initialized
INFO - 2024-04-06 12:06:39 --> Form Validation Class Initialized
INFO - 2024-04-06 12:06:39 --> Controller Class Initialized
INFO - 2024-04-06 12:06:39 --> Model Class Initialized
DEBUG - 2024-04-06 12:06:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 12:06:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-04-06 12:06:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-06 12:06:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-06 12:06:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-06 12:06:39 --> Model Class Initialized
INFO - 2024-04-06 12:06:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-06 12:06:39 --> Final output sent to browser
DEBUG - 2024-04-06 12:06:39 --> Total execution time: 0.0329
ERROR - 2024-04-06 12:06:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 12:06:49 --> Config Class Initialized
INFO - 2024-04-06 12:06:49 --> Hooks Class Initialized
DEBUG - 2024-04-06 12:06:49 --> UTF-8 Support Enabled
INFO - 2024-04-06 12:06:49 --> Utf8 Class Initialized
INFO - 2024-04-06 12:06:49 --> URI Class Initialized
INFO - 2024-04-06 12:06:49 --> Router Class Initialized
INFO - 2024-04-06 12:06:49 --> Output Class Initialized
INFO - 2024-04-06 12:06:49 --> Security Class Initialized
DEBUG - 2024-04-06 12:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 12:06:49 --> Input Class Initialized
INFO - 2024-04-06 12:06:49 --> Language Class Initialized
INFO - 2024-04-06 12:06:49 --> Loader Class Initialized
INFO - 2024-04-06 12:06:49 --> Helper loaded: url_helper
INFO - 2024-04-06 12:06:49 --> Helper loaded: file_helper
INFO - 2024-04-06 12:06:49 --> Helper loaded: html_helper
INFO - 2024-04-06 12:06:49 --> Helper loaded: text_helper
INFO - 2024-04-06 12:06:49 --> Helper loaded: form_helper
INFO - 2024-04-06 12:06:49 --> Helper loaded: lang_helper
INFO - 2024-04-06 12:06:49 --> Helper loaded: security_helper
INFO - 2024-04-06 12:06:49 --> Helper loaded: cookie_helper
INFO - 2024-04-06 12:06:49 --> Database Driver Class Initialized
INFO - 2024-04-06 12:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 12:06:49 --> Parser Class Initialized
INFO - 2024-04-06 12:06:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 12:06:49 --> Pagination Class Initialized
INFO - 2024-04-06 12:06:49 --> Form Validation Class Initialized
INFO - 2024-04-06 12:06:49 --> Controller Class Initialized
INFO - 2024-04-06 12:06:49 --> Model Class Initialized
DEBUG - 2024-04-06 12:06:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 12:06:49 --> Model Class Initialized
INFO - 2024-04-06 12:06:49 --> Final output sent to browser
DEBUG - 2024-04-06 12:06:49 --> Total execution time: 0.0183
ERROR - 2024-04-06 12:06:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 12:06:50 --> Config Class Initialized
INFO - 2024-04-06 12:06:50 --> Hooks Class Initialized
DEBUG - 2024-04-06 12:06:50 --> UTF-8 Support Enabled
INFO - 2024-04-06 12:06:50 --> Utf8 Class Initialized
INFO - 2024-04-06 12:06:50 --> URI Class Initialized
DEBUG - 2024-04-06 12:06:50 --> No URI present. Default controller set.
INFO - 2024-04-06 12:06:50 --> Router Class Initialized
INFO - 2024-04-06 12:06:50 --> Output Class Initialized
INFO - 2024-04-06 12:06:50 --> Security Class Initialized
DEBUG - 2024-04-06 12:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 12:06:50 --> Input Class Initialized
INFO - 2024-04-06 12:06:50 --> Language Class Initialized
INFO - 2024-04-06 12:06:50 --> Loader Class Initialized
INFO - 2024-04-06 12:06:50 --> Helper loaded: url_helper
INFO - 2024-04-06 12:06:50 --> Helper loaded: file_helper
INFO - 2024-04-06 12:06:50 --> Helper loaded: html_helper
INFO - 2024-04-06 12:06:50 --> Helper loaded: text_helper
INFO - 2024-04-06 12:06:50 --> Helper loaded: form_helper
INFO - 2024-04-06 12:06:50 --> Helper loaded: lang_helper
INFO - 2024-04-06 12:06:50 --> Helper loaded: security_helper
INFO - 2024-04-06 12:06:50 --> Helper loaded: cookie_helper
INFO - 2024-04-06 12:06:50 --> Database Driver Class Initialized
INFO - 2024-04-06 12:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 12:06:50 --> Parser Class Initialized
INFO - 2024-04-06 12:06:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 12:06:50 --> Pagination Class Initialized
INFO - 2024-04-06 12:06:50 --> Form Validation Class Initialized
INFO - 2024-04-06 12:06:50 --> Controller Class Initialized
INFO - 2024-04-06 12:06:50 --> Model Class Initialized
DEBUG - 2024-04-06 12:06:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 12:06:50 --> Model Class Initialized
DEBUG - 2024-04-06 12:06:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 12:06:50 --> Model Class Initialized
INFO - 2024-04-06 12:06:50 --> Model Class Initialized
INFO - 2024-04-06 12:06:50 --> Model Class Initialized
INFO - 2024-04-06 12:06:50 --> Model Class Initialized
DEBUG - 2024-04-06 12:06:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-06 12:06:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 12:06:50 --> Model Class Initialized
INFO - 2024-04-06 12:06:50 --> Model Class Initialized
INFO - 2024-04-06 12:06:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-06 12:06:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-06 12:06:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-06 12:06:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-06 12:06:50 --> Model Class Initialized
INFO - 2024-04-06 12:06:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-06 12:06:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-06 12:06:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-06 12:06:50 --> Final output sent to browser
DEBUG - 2024-04-06 12:06:50 --> Total execution time: 0.4512
ERROR - 2024-04-06 12:06:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 12:06:51 --> Config Class Initialized
INFO - 2024-04-06 12:06:51 --> Hooks Class Initialized
DEBUG - 2024-04-06 12:06:51 --> UTF-8 Support Enabled
INFO - 2024-04-06 12:06:51 --> Utf8 Class Initialized
INFO - 2024-04-06 12:06:51 --> URI Class Initialized
INFO - 2024-04-06 12:06:51 --> Router Class Initialized
INFO - 2024-04-06 12:06:51 --> Output Class Initialized
INFO - 2024-04-06 12:06:51 --> Security Class Initialized
DEBUG - 2024-04-06 12:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 12:06:51 --> Input Class Initialized
INFO - 2024-04-06 12:06:51 --> Language Class Initialized
INFO - 2024-04-06 12:06:51 --> Loader Class Initialized
INFO - 2024-04-06 12:06:51 --> Helper loaded: url_helper
INFO - 2024-04-06 12:06:51 --> Helper loaded: file_helper
INFO - 2024-04-06 12:06:51 --> Helper loaded: html_helper
INFO - 2024-04-06 12:06:51 --> Helper loaded: text_helper
INFO - 2024-04-06 12:06:51 --> Helper loaded: form_helper
INFO - 2024-04-06 12:06:51 --> Helper loaded: lang_helper
INFO - 2024-04-06 12:06:51 --> Helper loaded: security_helper
INFO - 2024-04-06 12:06:51 --> Helper loaded: cookie_helper
INFO - 2024-04-06 12:06:51 --> Database Driver Class Initialized
INFO - 2024-04-06 12:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 12:06:51 --> Parser Class Initialized
INFO - 2024-04-06 12:06:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 12:06:51 --> Pagination Class Initialized
INFO - 2024-04-06 12:06:51 --> Form Validation Class Initialized
INFO - 2024-04-06 12:06:51 --> Controller Class Initialized
DEBUG - 2024-04-06 12:06:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-06 12:06:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 12:06:51 --> Model Class Initialized
INFO - 2024-04-06 12:06:51 --> Final output sent to browser
DEBUG - 2024-04-06 12:06:51 --> Total execution time: 0.0131
ERROR - 2024-04-06 12:06:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 12:06:56 --> Config Class Initialized
INFO - 2024-04-06 12:06:56 --> Hooks Class Initialized
DEBUG - 2024-04-06 12:06:56 --> UTF-8 Support Enabled
INFO - 2024-04-06 12:06:56 --> Utf8 Class Initialized
INFO - 2024-04-06 12:06:56 --> URI Class Initialized
INFO - 2024-04-06 12:06:56 --> Router Class Initialized
INFO - 2024-04-06 12:06:56 --> Output Class Initialized
INFO - 2024-04-06 12:06:56 --> Security Class Initialized
DEBUG - 2024-04-06 12:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 12:06:56 --> Input Class Initialized
INFO - 2024-04-06 12:06:56 --> Language Class Initialized
INFO - 2024-04-06 12:06:56 --> Loader Class Initialized
INFO - 2024-04-06 12:06:56 --> Helper loaded: url_helper
INFO - 2024-04-06 12:06:56 --> Helper loaded: file_helper
INFO - 2024-04-06 12:06:56 --> Helper loaded: html_helper
INFO - 2024-04-06 12:06:56 --> Helper loaded: text_helper
INFO - 2024-04-06 12:06:56 --> Helper loaded: form_helper
INFO - 2024-04-06 12:06:56 --> Helper loaded: lang_helper
INFO - 2024-04-06 12:06:56 --> Helper loaded: security_helper
INFO - 2024-04-06 12:06:56 --> Helper loaded: cookie_helper
INFO - 2024-04-06 12:06:56 --> Database Driver Class Initialized
INFO - 2024-04-06 12:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 12:06:56 --> Parser Class Initialized
INFO - 2024-04-06 12:06:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 12:06:56 --> Pagination Class Initialized
INFO - 2024-04-06 12:06:56 --> Form Validation Class Initialized
INFO - 2024-04-06 12:06:56 --> Controller Class Initialized
INFO - 2024-04-06 12:06:56 --> Model Class Initialized
DEBUG - 2024-04-06 12:06:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-06 12:06:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 12:06:56 --> Model Class Initialized
DEBUG - 2024-04-06 12:06:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 12:06:56 --> Model Class Initialized
INFO - 2024-04-06 12:06:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-04-06 12:06:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-06 12:06:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-06 12:06:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-06 12:06:56 --> Model Class Initialized
INFO - 2024-04-06 12:06:56 --> Model Class Initialized
INFO - 2024-04-06 12:06:56 --> Model Class Initialized
INFO - 2024-04-06 12:06:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-06 12:06:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-06 12:06:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-06 12:06:56 --> Final output sent to browser
DEBUG - 2024-04-06 12:06:56 --> Total execution time: 0.2160
ERROR - 2024-04-06 12:06:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 12:06:57 --> Config Class Initialized
INFO - 2024-04-06 12:06:57 --> Hooks Class Initialized
DEBUG - 2024-04-06 12:06:57 --> UTF-8 Support Enabled
INFO - 2024-04-06 12:06:57 --> Utf8 Class Initialized
INFO - 2024-04-06 12:06:57 --> URI Class Initialized
INFO - 2024-04-06 12:06:57 --> Router Class Initialized
INFO - 2024-04-06 12:06:57 --> Output Class Initialized
INFO - 2024-04-06 12:06:57 --> Security Class Initialized
DEBUG - 2024-04-06 12:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 12:06:57 --> Input Class Initialized
INFO - 2024-04-06 12:06:57 --> Language Class Initialized
INFO - 2024-04-06 12:06:57 --> Loader Class Initialized
INFO - 2024-04-06 12:06:57 --> Helper loaded: url_helper
INFO - 2024-04-06 12:06:57 --> Helper loaded: file_helper
INFO - 2024-04-06 12:06:57 --> Helper loaded: html_helper
INFO - 2024-04-06 12:06:57 --> Helper loaded: text_helper
INFO - 2024-04-06 12:06:57 --> Helper loaded: form_helper
INFO - 2024-04-06 12:06:57 --> Helper loaded: lang_helper
INFO - 2024-04-06 12:06:57 --> Helper loaded: security_helper
INFO - 2024-04-06 12:06:57 --> Helper loaded: cookie_helper
INFO - 2024-04-06 12:06:57 --> Database Driver Class Initialized
INFO - 2024-04-06 12:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 12:06:57 --> Parser Class Initialized
INFO - 2024-04-06 12:06:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 12:06:57 --> Pagination Class Initialized
INFO - 2024-04-06 12:06:57 --> Form Validation Class Initialized
INFO - 2024-04-06 12:06:57 --> Controller Class Initialized
INFO - 2024-04-06 12:06:57 --> Model Class Initialized
DEBUG - 2024-04-06 12:06:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-06 12:06:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 12:06:57 --> Model Class Initialized
DEBUG - 2024-04-06 12:06:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 12:06:57 --> Model Class Initialized
INFO - 2024-04-06 12:06:57 --> Final output sent to browser
DEBUG - 2024-04-06 12:06:57 --> Total execution time: 0.0551
ERROR - 2024-04-06 12:07:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 12:07:01 --> Config Class Initialized
INFO - 2024-04-06 12:07:01 --> Hooks Class Initialized
DEBUG - 2024-04-06 12:07:01 --> UTF-8 Support Enabled
INFO - 2024-04-06 12:07:01 --> Utf8 Class Initialized
INFO - 2024-04-06 12:07:01 --> URI Class Initialized
INFO - 2024-04-06 12:07:01 --> Router Class Initialized
INFO - 2024-04-06 12:07:01 --> Output Class Initialized
INFO - 2024-04-06 12:07:01 --> Security Class Initialized
DEBUG - 2024-04-06 12:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 12:07:01 --> Input Class Initialized
INFO - 2024-04-06 12:07:01 --> Language Class Initialized
INFO - 2024-04-06 12:07:01 --> Loader Class Initialized
INFO - 2024-04-06 12:07:01 --> Helper loaded: url_helper
INFO - 2024-04-06 12:07:01 --> Helper loaded: file_helper
INFO - 2024-04-06 12:07:01 --> Helper loaded: html_helper
INFO - 2024-04-06 12:07:01 --> Helper loaded: text_helper
INFO - 2024-04-06 12:07:01 --> Helper loaded: form_helper
INFO - 2024-04-06 12:07:01 --> Helper loaded: lang_helper
INFO - 2024-04-06 12:07:01 --> Helper loaded: security_helper
INFO - 2024-04-06 12:07:01 --> Helper loaded: cookie_helper
INFO - 2024-04-06 12:07:01 --> Database Driver Class Initialized
INFO - 2024-04-06 12:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 12:07:01 --> Parser Class Initialized
INFO - 2024-04-06 12:07:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 12:07:01 --> Pagination Class Initialized
INFO - 2024-04-06 12:07:01 --> Form Validation Class Initialized
INFO - 2024-04-06 12:07:01 --> Controller Class Initialized
INFO - 2024-04-06 12:07:01 --> Model Class Initialized
DEBUG - 2024-04-06 12:07:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-06 12:07:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 12:07:01 --> Model Class Initialized
DEBUG - 2024-04-06 12:07:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 12:07:01 --> Model Class Initialized
INFO - 2024-04-06 12:07:01 --> Final output sent to browser
DEBUG - 2024-04-06 12:07:01 --> Total execution time: 0.0604
ERROR - 2024-04-06 12:07:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 12:07:01 --> Config Class Initialized
INFO - 2024-04-06 12:07:01 --> Hooks Class Initialized
DEBUG - 2024-04-06 12:07:01 --> UTF-8 Support Enabled
INFO - 2024-04-06 12:07:01 --> Utf8 Class Initialized
INFO - 2024-04-06 12:07:01 --> URI Class Initialized
INFO - 2024-04-06 12:07:01 --> Router Class Initialized
INFO - 2024-04-06 12:07:01 --> Output Class Initialized
INFO - 2024-04-06 12:07:01 --> Security Class Initialized
DEBUG - 2024-04-06 12:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 12:07:01 --> Input Class Initialized
INFO - 2024-04-06 12:07:01 --> Language Class Initialized
INFO - 2024-04-06 12:07:01 --> Loader Class Initialized
INFO - 2024-04-06 12:07:01 --> Helper loaded: url_helper
INFO - 2024-04-06 12:07:01 --> Helper loaded: file_helper
INFO - 2024-04-06 12:07:01 --> Helper loaded: html_helper
INFO - 2024-04-06 12:07:01 --> Helper loaded: text_helper
INFO - 2024-04-06 12:07:01 --> Helper loaded: form_helper
INFO - 2024-04-06 12:07:01 --> Helper loaded: lang_helper
INFO - 2024-04-06 12:07:01 --> Helper loaded: security_helper
INFO - 2024-04-06 12:07:01 --> Helper loaded: cookie_helper
INFO - 2024-04-06 12:07:01 --> Database Driver Class Initialized
INFO - 2024-04-06 12:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 12:07:01 --> Parser Class Initialized
INFO - 2024-04-06 12:07:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 12:07:01 --> Pagination Class Initialized
INFO - 2024-04-06 12:07:01 --> Form Validation Class Initialized
INFO - 2024-04-06 12:07:01 --> Controller Class Initialized
INFO - 2024-04-06 12:07:01 --> Model Class Initialized
DEBUG - 2024-04-06 12:07:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-06 12:07:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 12:07:01 --> Model Class Initialized
DEBUG - 2024-04-06 12:07:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 12:07:01 --> Model Class Initialized
INFO - 2024-04-06 12:07:01 --> Final output sent to browser
DEBUG - 2024-04-06 12:07:01 --> Total execution time: 0.0502
ERROR - 2024-04-06 12:07:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 12:07:01 --> Config Class Initialized
INFO - 2024-04-06 12:07:01 --> Hooks Class Initialized
DEBUG - 2024-04-06 12:07:01 --> UTF-8 Support Enabled
INFO - 2024-04-06 12:07:01 --> Utf8 Class Initialized
INFO - 2024-04-06 12:07:01 --> URI Class Initialized
INFO - 2024-04-06 12:07:01 --> Router Class Initialized
INFO - 2024-04-06 12:07:01 --> Output Class Initialized
INFO - 2024-04-06 12:07:01 --> Security Class Initialized
DEBUG - 2024-04-06 12:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 12:07:01 --> Input Class Initialized
INFO - 2024-04-06 12:07:01 --> Language Class Initialized
INFO - 2024-04-06 12:07:01 --> Loader Class Initialized
INFO - 2024-04-06 12:07:01 --> Helper loaded: url_helper
INFO - 2024-04-06 12:07:01 --> Helper loaded: file_helper
INFO - 2024-04-06 12:07:01 --> Helper loaded: html_helper
INFO - 2024-04-06 12:07:01 --> Helper loaded: text_helper
INFO - 2024-04-06 12:07:01 --> Helper loaded: form_helper
INFO - 2024-04-06 12:07:01 --> Helper loaded: lang_helper
INFO - 2024-04-06 12:07:01 --> Helper loaded: security_helper
INFO - 2024-04-06 12:07:01 --> Helper loaded: cookie_helper
INFO - 2024-04-06 12:07:01 --> Database Driver Class Initialized
INFO - 2024-04-06 12:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 12:07:01 --> Parser Class Initialized
INFO - 2024-04-06 12:07:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 12:07:01 --> Pagination Class Initialized
INFO - 2024-04-06 12:07:01 --> Form Validation Class Initialized
INFO - 2024-04-06 12:07:01 --> Controller Class Initialized
INFO - 2024-04-06 12:07:01 --> Model Class Initialized
DEBUG - 2024-04-06 12:07:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-06 12:07:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 12:07:01 --> Model Class Initialized
DEBUG - 2024-04-06 12:07:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 12:07:01 --> Model Class Initialized
INFO - 2024-04-06 12:07:02 --> Final output sent to browser
DEBUG - 2024-04-06 12:07:02 --> Total execution time: 0.0441
ERROR - 2024-04-06 12:07:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 12:07:08 --> Config Class Initialized
INFO - 2024-04-06 12:07:08 --> Hooks Class Initialized
DEBUG - 2024-04-06 12:07:08 --> UTF-8 Support Enabled
INFO - 2024-04-06 12:07:08 --> Utf8 Class Initialized
INFO - 2024-04-06 12:07:08 --> URI Class Initialized
INFO - 2024-04-06 12:07:08 --> Router Class Initialized
INFO - 2024-04-06 12:07:08 --> Output Class Initialized
INFO - 2024-04-06 12:07:08 --> Security Class Initialized
DEBUG - 2024-04-06 12:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 12:07:08 --> Input Class Initialized
INFO - 2024-04-06 12:07:08 --> Language Class Initialized
INFO - 2024-04-06 12:07:08 --> Loader Class Initialized
INFO - 2024-04-06 12:07:08 --> Helper loaded: url_helper
INFO - 2024-04-06 12:07:08 --> Helper loaded: file_helper
INFO - 2024-04-06 12:07:08 --> Helper loaded: html_helper
INFO - 2024-04-06 12:07:08 --> Helper loaded: text_helper
INFO - 2024-04-06 12:07:08 --> Helper loaded: form_helper
INFO - 2024-04-06 12:07:08 --> Helper loaded: lang_helper
INFO - 2024-04-06 12:07:08 --> Helper loaded: security_helper
INFO - 2024-04-06 12:07:08 --> Helper loaded: cookie_helper
INFO - 2024-04-06 12:07:08 --> Database Driver Class Initialized
INFO - 2024-04-06 12:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 12:07:08 --> Parser Class Initialized
INFO - 2024-04-06 12:07:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 12:07:08 --> Pagination Class Initialized
INFO - 2024-04-06 12:07:08 --> Form Validation Class Initialized
INFO - 2024-04-06 12:07:08 --> Controller Class Initialized
INFO - 2024-04-06 12:07:08 --> Model Class Initialized
DEBUG - 2024-04-06 12:07:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-06 12:07:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 12:07:08 --> Model Class Initialized
DEBUG - 2024-04-06 12:07:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 12:07:08 --> Model Class Initialized
DEBUG - 2024-04-06 12:07:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 12:07:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-04-06 12:07:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-06 12:07:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-06 12:07:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-06 12:07:08 --> Model Class Initialized
INFO - 2024-04-06 12:07:08 --> Model Class Initialized
INFO - 2024-04-06 12:07:08 --> Model Class Initialized
INFO - 2024-04-06 12:07:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-06 12:07:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-06 12:07:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-06 12:07:08 --> Final output sent to browser
DEBUG - 2024-04-06 12:07:08 --> Total execution time: 0.2263
ERROR - 2024-04-06 13:45:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 13:45:17 --> Config Class Initialized
INFO - 2024-04-06 13:45:17 --> Hooks Class Initialized
DEBUG - 2024-04-06 13:45:17 --> UTF-8 Support Enabled
INFO - 2024-04-06 13:45:17 --> Utf8 Class Initialized
INFO - 2024-04-06 13:45:17 --> URI Class Initialized
DEBUG - 2024-04-06 13:45:17 --> No URI present. Default controller set.
INFO - 2024-04-06 13:45:17 --> Router Class Initialized
INFO - 2024-04-06 13:45:17 --> Output Class Initialized
INFO - 2024-04-06 13:45:17 --> Security Class Initialized
DEBUG - 2024-04-06 13:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 13:45:17 --> Input Class Initialized
INFO - 2024-04-06 13:45:17 --> Language Class Initialized
INFO - 2024-04-06 13:45:17 --> Loader Class Initialized
INFO - 2024-04-06 13:45:17 --> Helper loaded: url_helper
INFO - 2024-04-06 13:45:17 --> Helper loaded: file_helper
INFO - 2024-04-06 13:45:17 --> Helper loaded: html_helper
INFO - 2024-04-06 13:45:17 --> Helper loaded: text_helper
INFO - 2024-04-06 13:45:17 --> Helper loaded: form_helper
INFO - 2024-04-06 13:45:17 --> Helper loaded: lang_helper
INFO - 2024-04-06 13:45:17 --> Helper loaded: security_helper
INFO - 2024-04-06 13:45:17 --> Helper loaded: cookie_helper
INFO - 2024-04-06 13:45:17 --> Database Driver Class Initialized
INFO - 2024-04-06 13:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 13:45:17 --> Parser Class Initialized
INFO - 2024-04-06 13:45:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 13:45:17 --> Pagination Class Initialized
INFO - 2024-04-06 13:45:17 --> Form Validation Class Initialized
INFO - 2024-04-06 13:45:17 --> Controller Class Initialized
INFO - 2024-04-06 13:45:17 --> Model Class Initialized
DEBUG - 2024-04-06 13:45:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-04-06 13:45:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 13:45:17 --> Config Class Initialized
INFO - 2024-04-06 13:45:17 --> Hooks Class Initialized
DEBUG - 2024-04-06 13:45:17 --> UTF-8 Support Enabled
INFO - 2024-04-06 13:45:17 --> Utf8 Class Initialized
INFO - 2024-04-06 13:45:17 --> URI Class Initialized
INFO - 2024-04-06 13:45:17 --> Router Class Initialized
INFO - 2024-04-06 13:45:17 --> Output Class Initialized
INFO - 2024-04-06 13:45:17 --> Security Class Initialized
DEBUG - 2024-04-06 13:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 13:45:17 --> Input Class Initialized
INFO - 2024-04-06 13:45:17 --> Language Class Initialized
INFO - 2024-04-06 13:45:17 --> Loader Class Initialized
INFO - 2024-04-06 13:45:17 --> Helper loaded: url_helper
INFO - 2024-04-06 13:45:17 --> Helper loaded: file_helper
INFO - 2024-04-06 13:45:17 --> Helper loaded: html_helper
INFO - 2024-04-06 13:45:17 --> Helper loaded: text_helper
INFO - 2024-04-06 13:45:17 --> Helper loaded: form_helper
INFO - 2024-04-06 13:45:17 --> Helper loaded: lang_helper
INFO - 2024-04-06 13:45:17 --> Helper loaded: security_helper
INFO - 2024-04-06 13:45:17 --> Helper loaded: cookie_helper
INFO - 2024-04-06 13:45:17 --> Database Driver Class Initialized
INFO - 2024-04-06 13:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 13:45:17 --> Parser Class Initialized
INFO - 2024-04-06 13:45:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 13:45:17 --> Pagination Class Initialized
INFO - 2024-04-06 13:45:17 --> Form Validation Class Initialized
INFO - 2024-04-06 13:45:17 --> Controller Class Initialized
INFO - 2024-04-06 13:45:17 --> Model Class Initialized
DEBUG - 2024-04-06 13:45:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 13:45:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-04-06 13:45:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-06 13:45:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-06 13:45:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-06 13:45:17 --> Model Class Initialized
INFO - 2024-04-06 13:45:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-06 13:45:17 --> Final output sent to browser
DEBUG - 2024-04-06 13:45:17 --> Total execution time: 0.0318
ERROR - 2024-04-06 13:45:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 13:45:27 --> Config Class Initialized
INFO - 2024-04-06 13:45:27 --> Hooks Class Initialized
DEBUG - 2024-04-06 13:45:27 --> UTF-8 Support Enabled
INFO - 2024-04-06 13:45:27 --> Utf8 Class Initialized
INFO - 2024-04-06 13:45:27 --> URI Class Initialized
INFO - 2024-04-06 13:45:27 --> Router Class Initialized
INFO - 2024-04-06 13:45:27 --> Output Class Initialized
INFO - 2024-04-06 13:45:27 --> Security Class Initialized
DEBUG - 2024-04-06 13:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 13:45:27 --> Input Class Initialized
INFO - 2024-04-06 13:45:27 --> Language Class Initialized
INFO - 2024-04-06 13:45:27 --> Loader Class Initialized
INFO - 2024-04-06 13:45:27 --> Helper loaded: url_helper
INFO - 2024-04-06 13:45:27 --> Helper loaded: file_helper
INFO - 2024-04-06 13:45:27 --> Helper loaded: html_helper
INFO - 2024-04-06 13:45:27 --> Helper loaded: text_helper
INFO - 2024-04-06 13:45:27 --> Helper loaded: form_helper
INFO - 2024-04-06 13:45:27 --> Helper loaded: lang_helper
INFO - 2024-04-06 13:45:27 --> Helper loaded: security_helper
INFO - 2024-04-06 13:45:27 --> Helper loaded: cookie_helper
INFO - 2024-04-06 13:45:27 --> Database Driver Class Initialized
INFO - 2024-04-06 13:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 13:45:27 --> Parser Class Initialized
INFO - 2024-04-06 13:45:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 13:45:27 --> Pagination Class Initialized
INFO - 2024-04-06 13:45:27 --> Form Validation Class Initialized
INFO - 2024-04-06 13:45:27 --> Controller Class Initialized
INFO - 2024-04-06 13:45:27 --> Model Class Initialized
DEBUG - 2024-04-06 13:45:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 13:45:27 --> Model Class Initialized
INFO - 2024-04-06 13:45:27 --> Final output sent to browser
DEBUG - 2024-04-06 13:45:27 --> Total execution time: 0.0189
ERROR - 2024-04-06 13:45:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 13:45:27 --> Config Class Initialized
INFO - 2024-04-06 13:45:27 --> Hooks Class Initialized
DEBUG - 2024-04-06 13:45:27 --> UTF-8 Support Enabled
INFO - 2024-04-06 13:45:27 --> Utf8 Class Initialized
INFO - 2024-04-06 13:45:27 --> URI Class Initialized
DEBUG - 2024-04-06 13:45:27 --> No URI present. Default controller set.
INFO - 2024-04-06 13:45:27 --> Router Class Initialized
INFO - 2024-04-06 13:45:27 --> Output Class Initialized
INFO - 2024-04-06 13:45:27 --> Security Class Initialized
DEBUG - 2024-04-06 13:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 13:45:27 --> Input Class Initialized
INFO - 2024-04-06 13:45:27 --> Language Class Initialized
INFO - 2024-04-06 13:45:27 --> Loader Class Initialized
INFO - 2024-04-06 13:45:27 --> Helper loaded: url_helper
INFO - 2024-04-06 13:45:27 --> Helper loaded: file_helper
INFO - 2024-04-06 13:45:27 --> Helper loaded: html_helper
INFO - 2024-04-06 13:45:27 --> Helper loaded: text_helper
INFO - 2024-04-06 13:45:27 --> Helper loaded: form_helper
INFO - 2024-04-06 13:45:27 --> Helper loaded: lang_helper
INFO - 2024-04-06 13:45:27 --> Helper loaded: security_helper
INFO - 2024-04-06 13:45:27 --> Helper loaded: cookie_helper
INFO - 2024-04-06 13:45:27 --> Database Driver Class Initialized
INFO - 2024-04-06 13:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 13:45:27 --> Parser Class Initialized
INFO - 2024-04-06 13:45:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 13:45:27 --> Pagination Class Initialized
INFO - 2024-04-06 13:45:27 --> Form Validation Class Initialized
INFO - 2024-04-06 13:45:27 --> Controller Class Initialized
INFO - 2024-04-06 13:45:27 --> Model Class Initialized
DEBUG - 2024-04-06 13:45:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 13:45:27 --> Model Class Initialized
DEBUG - 2024-04-06 13:45:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 13:45:27 --> Model Class Initialized
INFO - 2024-04-06 13:45:27 --> Model Class Initialized
INFO - 2024-04-06 13:45:27 --> Model Class Initialized
INFO - 2024-04-06 13:45:28 --> Model Class Initialized
DEBUG - 2024-04-06 13:45:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-06 13:45:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 13:45:28 --> Model Class Initialized
INFO - 2024-04-06 13:45:28 --> Model Class Initialized
INFO - 2024-04-06 13:45:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-06 13:45:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-06 13:45:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-06 13:45:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-06 13:45:28 --> Model Class Initialized
INFO - 2024-04-06 13:45:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-06 13:45:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-06 13:45:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-06 13:45:28 --> Final output sent to browser
DEBUG - 2024-04-06 13:45:28 --> Total execution time: 0.2502
ERROR - 2024-04-06 13:45:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 13:45:34 --> Config Class Initialized
INFO - 2024-04-06 13:45:34 --> Hooks Class Initialized
DEBUG - 2024-04-06 13:45:34 --> UTF-8 Support Enabled
INFO - 2024-04-06 13:45:34 --> Utf8 Class Initialized
INFO - 2024-04-06 13:45:34 --> URI Class Initialized
INFO - 2024-04-06 13:45:34 --> Router Class Initialized
INFO - 2024-04-06 13:45:34 --> Output Class Initialized
INFO - 2024-04-06 13:45:34 --> Security Class Initialized
DEBUG - 2024-04-06 13:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 13:45:34 --> Input Class Initialized
INFO - 2024-04-06 13:45:34 --> Language Class Initialized
INFO - 2024-04-06 13:45:34 --> Loader Class Initialized
INFO - 2024-04-06 13:45:34 --> Helper loaded: url_helper
INFO - 2024-04-06 13:45:34 --> Helper loaded: file_helper
INFO - 2024-04-06 13:45:34 --> Helper loaded: html_helper
INFO - 2024-04-06 13:45:34 --> Helper loaded: text_helper
INFO - 2024-04-06 13:45:34 --> Helper loaded: form_helper
INFO - 2024-04-06 13:45:34 --> Helper loaded: lang_helper
INFO - 2024-04-06 13:45:34 --> Helper loaded: security_helper
INFO - 2024-04-06 13:45:34 --> Helper loaded: cookie_helper
INFO - 2024-04-06 13:45:34 --> Database Driver Class Initialized
INFO - 2024-04-06 13:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 13:45:34 --> Parser Class Initialized
INFO - 2024-04-06 13:45:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 13:45:34 --> Pagination Class Initialized
INFO - 2024-04-06 13:45:34 --> Form Validation Class Initialized
INFO - 2024-04-06 13:45:34 --> Controller Class Initialized
INFO - 2024-04-06 13:45:34 --> Model Class Initialized
DEBUG - 2024-04-06 13:45:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 13:45:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-04-06 13:45:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-06 13:45:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-06 13:45:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-06 13:45:34 --> Model Class Initialized
INFO - 2024-04-06 13:45:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-06 13:45:34 --> Final output sent to browser
DEBUG - 2024-04-06 13:45:34 --> Total execution time: 0.0269
ERROR - 2024-04-06 13:45:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 13:45:35 --> Config Class Initialized
INFO - 2024-04-06 13:45:35 --> Hooks Class Initialized
DEBUG - 2024-04-06 13:45:35 --> UTF-8 Support Enabled
INFO - 2024-04-06 13:45:35 --> Utf8 Class Initialized
INFO - 2024-04-06 13:45:35 --> URI Class Initialized
INFO - 2024-04-06 13:45:35 --> Router Class Initialized
INFO - 2024-04-06 13:45:35 --> Output Class Initialized
INFO - 2024-04-06 13:45:35 --> Security Class Initialized
DEBUG - 2024-04-06 13:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 13:45:35 --> Input Class Initialized
INFO - 2024-04-06 13:45:35 --> Language Class Initialized
INFO - 2024-04-06 13:45:35 --> Loader Class Initialized
INFO - 2024-04-06 13:45:35 --> Helper loaded: url_helper
INFO - 2024-04-06 13:45:35 --> Helper loaded: file_helper
INFO - 2024-04-06 13:45:35 --> Helper loaded: html_helper
INFO - 2024-04-06 13:45:35 --> Helper loaded: text_helper
INFO - 2024-04-06 13:45:35 --> Helper loaded: form_helper
INFO - 2024-04-06 13:45:35 --> Helper loaded: lang_helper
INFO - 2024-04-06 13:45:35 --> Helper loaded: security_helper
INFO - 2024-04-06 13:45:35 --> Helper loaded: cookie_helper
INFO - 2024-04-06 13:45:35 --> Database Driver Class Initialized
INFO - 2024-04-06 13:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 13:45:35 --> Parser Class Initialized
INFO - 2024-04-06 13:45:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 13:45:35 --> Pagination Class Initialized
INFO - 2024-04-06 13:45:35 --> Form Validation Class Initialized
INFO - 2024-04-06 13:45:35 --> Controller Class Initialized
INFO - 2024-04-06 13:45:35 --> Model Class Initialized
DEBUG - 2024-04-06 13:45:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 13:45:35 --> Model Class Initialized
DEBUG - 2024-04-06 13:45:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 13:45:35 --> Model Class Initialized
INFO - 2024-04-06 13:45:35 --> Model Class Initialized
INFO - 2024-04-06 13:45:35 --> Model Class Initialized
INFO - 2024-04-06 13:45:35 --> Model Class Initialized
DEBUG - 2024-04-06 13:45:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-06 13:45:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 13:45:35 --> Model Class Initialized
INFO - 2024-04-06 13:45:35 --> Model Class Initialized
INFO - 2024-04-06 13:45:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-06 13:45:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-06 13:45:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-06 13:45:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-06 13:45:35 --> Model Class Initialized
INFO - 2024-04-06 13:45:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-06 13:45:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-06 13:45:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-06 13:45:35 --> Final output sent to browser
DEBUG - 2024-04-06 13:45:35 --> Total execution time: 0.2485
ERROR - 2024-04-06 13:45:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 13:45:48 --> Config Class Initialized
INFO - 2024-04-06 13:45:48 --> Hooks Class Initialized
DEBUG - 2024-04-06 13:45:48 --> UTF-8 Support Enabled
INFO - 2024-04-06 13:45:48 --> Utf8 Class Initialized
INFO - 2024-04-06 13:45:48 --> URI Class Initialized
INFO - 2024-04-06 13:45:48 --> Router Class Initialized
INFO - 2024-04-06 13:45:48 --> Output Class Initialized
INFO - 2024-04-06 13:45:48 --> Security Class Initialized
DEBUG - 2024-04-06 13:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 13:45:48 --> Input Class Initialized
INFO - 2024-04-06 13:45:48 --> Language Class Initialized
INFO - 2024-04-06 13:45:48 --> Loader Class Initialized
INFO - 2024-04-06 13:45:48 --> Helper loaded: url_helper
INFO - 2024-04-06 13:45:48 --> Helper loaded: file_helper
INFO - 2024-04-06 13:45:48 --> Helper loaded: html_helper
INFO - 2024-04-06 13:45:48 --> Helper loaded: text_helper
INFO - 2024-04-06 13:45:48 --> Helper loaded: form_helper
INFO - 2024-04-06 13:45:48 --> Helper loaded: lang_helper
INFO - 2024-04-06 13:45:48 --> Helper loaded: security_helper
INFO - 2024-04-06 13:45:48 --> Helper loaded: cookie_helper
INFO - 2024-04-06 13:45:48 --> Database Driver Class Initialized
INFO - 2024-04-06 13:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 13:45:48 --> Parser Class Initialized
INFO - 2024-04-06 13:45:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 13:45:48 --> Pagination Class Initialized
INFO - 2024-04-06 13:45:48 --> Form Validation Class Initialized
INFO - 2024-04-06 13:45:48 --> Controller Class Initialized
DEBUG - 2024-04-06 13:45:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-06 13:45:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 13:45:48 --> Model Class Initialized
DEBUG - 2024-04-06 13:45:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 13:45:48 --> Model Class Initialized
DEBUG - 2024-04-06 13:45:48 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-04-06 13:45:48 --> Model Class Initialized
INFO - 2024-04-06 13:45:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-04-06 13:45:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-06 13:45:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-06 13:45:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-06 13:45:48 --> Model Class Initialized
INFO - 2024-04-06 13:45:48 --> Model Class Initialized
INFO - 2024-04-06 13:45:48 --> Model Class Initialized
INFO - 2024-04-06 13:45:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-06 13:45:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-06 13:45:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-06 13:45:48 --> Final output sent to browser
DEBUG - 2024-04-06 13:45:48 --> Total execution time: 0.1569
ERROR - 2024-04-06 13:45:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 13:45:49 --> Config Class Initialized
INFO - 2024-04-06 13:45:49 --> Hooks Class Initialized
DEBUG - 2024-04-06 13:45:49 --> UTF-8 Support Enabled
INFO - 2024-04-06 13:45:49 --> Utf8 Class Initialized
INFO - 2024-04-06 13:45:49 --> URI Class Initialized
INFO - 2024-04-06 13:45:49 --> Router Class Initialized
INFO - 2024-04-06 13:45:49 --> Output Class Initialized
INFO - 2024-04-06 13:45:49 --> Security Class Initialized
DEBUG - 2024-04-06 13:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 13:45:49 --> Input Class Initialized
INFO - 2024-04-06 13:45:49 --> Language Class Initialized
INFO - 2024-04-06 13:45:49 --> Loader Class Initialized
INFO - 2024-04-06 13:45:49 --> Helper loaded: url_helper
INFO - 2024-04-06 13:45:49 --> Helper loaded: file_helper
INFO - 2024-04-06 13:45:49 --> Helper loaded: html_helper
INFO - 2024-04-06 13:45:49 --> Helper loaded: text_helper
INFO - 2024-04-06 13:45:49 --> Helper loaded: form_helper
INFO - 2024-04-06 13:45:49 --> Helper loaded: lang_helper
INFO - 2024-04-06 13:45:49 --> Helper loaded: security_helper
INFO - 2024-04-06 13:45:49 --> Helper loaded: cookie_helper
INFO - 2024-04-06 13:45:49 --> Database Driver Class Initialized
INFO - 2024-04-06 13:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 13:45:49 --> Parser Class Initialized
INFO - 2024-04-06 13:45:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 13:45:49 --> Pagination Class Initialized
INFO - 2024-04-06 13:45:49 --> Form Validation Class Initialized
INFO - 2024-04-06 13:45:49 --> Controller Class Initialized
DEBUG - 2024-04-06 13:45:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-06 13:45:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 13:45:49 --> Model Class Initialized
DEBUG - 2024-04-06 13:45:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 13:45:49 --> Model Class Initialized
INFO - 2024-04-06 13:45:49 --> Final output sent to browser
DEBUG - 2024-04-06 13:45:49 --> Total execution time: 0.0221
ERROR - 2024-04-06 13:46:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 13:46:11 --> Config Class Initialized
INFO - 2024-04-06 13:46:11 --> Hooks Class Initialized
DEBUG - 2024-04-06 13:46:11 --> UTF-8 Support Enabled
INFO - 2024-04-06 13:46:11 --> Utf8 Class Initialized
INFO - 2024-04-06 13:46:11 --> URI Class Initialized
INFO - 2024-04-06 13:46:11 --> Router Class Initialized
INFO - 2024-04-06 13:46:11 --> Output Class Initialized
INFO - 2024-04-06 13:46:11 --> Security Class Initialized
DEBUG - 2024-04-06 13:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 13:46:11 --> Input Class Initialized
INFO - 2024-04-06 13:46:11 --> Language Class Initialized
INFO - 2024-04-06 13:46:11 --> Loader Class Initialized
INFO - 2024-04-06 13:46:11 --> Helper loaded: url_helper
INFO - 2024-04-06 13:46:11 --> Helper loaded: file_helper
INFO - 2024-04-06 13:46:11 --> Helper loaded: html_helper
INFO - 2024-04-06 13:46:11 --> Helper loaded: text_helper
INFO - 2024-04-06 13:46:11 --> Helper loaded: form_helper
INFO - 2024-04-06 13:46:11 --> Helper loaded: lang_helper
INFO - 2024-04-06 13:46:11 --> Helper loaded: security_helper
INFO - 2024-04-06 13:46:11 --> Helper loaded: cookie_helper
INFO - 2024-04-06 13:46:11 --> Database Driver Class Initialized
INFO - 2024-04-06 13:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 13:46:11 --> Parser Class Initialized
INFO - 2024-04-06 13:46:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 13:46:11 --> Pagination Class Initialized
INFO - 2024-04-06 13:46:11 --> Form Validation Class Initialized
INFO - 2024-04-06 13:46:11 --> Controller Class Initialized
INFO - 2024-04-06 13:46:11 --> Model Class Initialized
DEBUG - 2024-04-06 13:46:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 13:46:11 --> Model Class Initialized
DEBUG - 2024-04-06 13:46:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 13:46:11 --> Model Class Initialized
INFO - 2024-04-06 13:46:11 --> Model Class Initialized
INFO - 2024-04-06 13:46:11 --> Model Class Initialized
INFO - 2024-04-06 13:46:11 --> Model Class Initialized
DEBUG - 2024-04-06 13:46:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-06 13:46:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 13:46:11 --> Model Class Initialized
INFO - 2024-04-06 13:46:11 --> Model Class Initialized
INFO - 2024-04-06 13:46:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-06 13:46:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-06 13:46:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-06 13:46:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-06 13:46:11 --> Model Class Initialized
INFO - 2024-04-06 13:46:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-06 13:46:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-06 13:46:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-06 13:46:12 --> Final output sent to browser
DEBUG - 2024-04-06 13:46:12 --> Total execution time: 0.2560
ERROR - 2024-04-06 14:28:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 14:28:27 --> Config Class Initialized
INFO - 2024-04-06 14:28:27 --> Hooks Class Initialized
DEBUG - 2024-04-06 14:28:27 --> UTF-8 Support Enabled
INFO - 2024-04-06 14:28:27 --> Utf8 Class Initialized
INFO - 2024-04-06 14:28:27 --> URI Class Initialized
DEBUG - 2024-04-06 14:28:27 --> No URI present. Default controller set.
INFO - 2024-04-06 14:28:27 --> Router Class Initialized
INFO - 2024-04-06 14:28:27 --> Output Class Initialized
INFO - 2024-04-06 14:28:27 --> Security Class Initialized
DEBUG - 2024-04-06 14:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 14:28:27 --> Input Class Initialized
INFO - 2024-04-06 14:28:27 --> Language Class Initialized
INFO - 2024-04-06 14:28:27 --> Loader Class Initialized
INFO - 2024-04-06 14:28:27 --> Helper loaded: url_helper
INFO - 2024-04-06 14:28:27 --> Helper loaded: file_helper
INFO - 2024-04-06 14:28:27 --> Helper loaded: html_helper
INFO - 2024-04-06 14:28:27 --> Helper loaded: text_helper
INFO - 2024-04-06 14:28:27 --> Helper loaded: form_helper
INFO - 2024-04-06 14:28:27 --> Helper loaded: lang_helper
INFO - 2024-04-06 14:28:27 --> Helper loaded: security_helper
INFO - 2024-04-06 14:28:27 --> Helper loaded: cookie_helper
INFO - 2024-04-06 14:28:27 --> Database Driver Class Initialized
INFO - 2024-04-06 14:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 14:28:27 --> Parser Class Initialized
INFO - 2024-04-06 14:28:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 14:28:27 --> Pagination Class Initialized
INFO - 2024-04-06 14:28:27 --> Form Validation Class Initialized
INFO - 2024-04-06 14:28:27 --> Controller Class Initialized
INFO - 2024-04-06 14:28:27 --> Model Class Initialized
DEBUG - 2024-04-06 14:28:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-04-06 14:28:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 14:28:28 --> Config Class Initialized
INFO - 2024-04-06 14:28:28 --> Hooks Class Initialized
DEBUG - 2024-04-06 14:28:28 --> UTF-8 Support Enabled
INFO - 2024-04-06 14:28:28 --> Utf8 Class Initialized
INFO - 2024-04-06 14:28:28 --> URI Class Initialized
INFO - 2024-04-06 14:28:28 --> Router Class Initialized
INFO - 2024-04-06 14:28:28 --> Output Class Initialized
INFO - 2024-04-06 14:28:28 --> Security Class Initialized
DEBUG - 2024-04-06 14:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 14:28:28 --> Input Class Initialized
INFO - 2024-04-06 14:28:28 --> Language Class Initialized
INFO - 2024-04-06 14:28:28 --> Loader Class Initialized
INFO - 2024-04-06 14:28:28 --> Helper loaded: url_helper
INFO - 2024-04-06 14:28:28 --> Helper loaded: file_helper
INFO - 2024-04-06 14:28:28 --> Helper loaded: html_helper
INFO - 2024-04-06 14:28:28 --> Helper loaded: text_helper
INFO - 2024-04-06 14:28:28 --> Helper loaded: form_helper
INFO - 2024-04-06 14:28:28 --> Helper loaded: lang_helper
INFO - 2024-04-06 14:28:28 --> Helper loaded: security_helper
INFO - 2024-04-06 14:28:28 --> Helper loaded: cookie_helper
INFO - 2024-04-06 14:28:28 --> Database Driver Class Initialized
INFO - 2024-04-06 14:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 14:28:28 --> Parser Class Initialized
INFO - 2024-04-06 14:28:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 14:28:28 --> Pagination Class Initialized
INFO - 2024-04-06 14:28:28 --> Form Validation Class Initialized
INFO - 2024-04-06 14:28:28 --> Controller Class Initialized
INFO - 2024-04-06 14:28:28 --> Model Class Initialized
DEBUG - 2024-04-06 14:28:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 14:28:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-04-06 14:28:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-06 14:28:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-06 14:28:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-06 14:28:28 --> Model Class Initialized
INFO - 2024-04-06 14:28:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-06 14:28:28 --> Final output sent to browser
DEBUG - 2024-04-06 14:28:28 --> Total execution time: 0.0358
ERROR - 2024-04-06 14:28:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 14:28:51 --> Config Class Initialized
INFO - 2024-04-06 14:28:51 --> Hooks Class Initialized
DEBUG - 2024-04-06 14:28:51 --> UTF-8 Support Enabled
INFO - 2024-04-06 14:28:51 --> Utf8 Class Initialized
INFO - 2024-04-06 14:28:51 --> URI Class Initialized
INFO - 2024-04-06 14:28:51 --> Router Class Initialized
INFO - 2024-04-06 14:28:51 --> Output Class Initialized
INFO - 2024-04-06 14:28:51 --> Security Class Initialized
DEBUG - 2024-04-06 14:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 14:28:51 --> Input Class Initialized
INFO - 2024-04-06 14:28:51 --> Language Class Initialized
INFO - 2024-04-06 14:28:51 --> Loader Class Initialized
INFO - 2024-04-06 14:28:51 --> Helper loaded: url_helper
INFO - 2024-04-06 14:28:51 --> Helper loaded: file_helper
INFO - 2024-04-06 14:28:51 --> Helper loaded: html_helper
INFO - 2024-04-06 14:28:51 --> Helper loaded: text_helper
INFO - 2024-04-06 14:28:51 --> Helper loaded: form_helper
INFO - 2024-04-06 14:28:51 --> Helper loaded: lang_helper
INFO - 2024-04-06 14:28:51 --> Helper loaded: security_helper
INFO - 2024-04-06 14:28:51 --> Helper loaded: cookie_helper
INFO - 2024-04-06 14:28:51 --> Database Driver Class Initialized
INFO - 2024-04-06 14:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 14:28:51 --> Parser Class Initialized
INFO - 2024-04-06 14:28:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 14:28:51 --> Pagination Class Initialized
INFO - 2024-04-06 14:28:51 --> Form Validation Class Initialized
INFO - 2024-04-06 14:28:51 --> Controller Class Initialized
INFO - 2024-04-06 14:28:51 --> Model Class Initialized
DEBUG - 2024-04-06 14:28:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 14:28:51 --> Model Class Initialized
INFO - 2024-04-06 14:28:51 --> Final output sent to browser
DEBUG - 2024-04-06 14:28:51 --> Total execution time: 0.0221
ERROR - 2024-04-06 14:28:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 14:28:51 --> Config Class Initialized
INFO - 2024-04-06 14:28:51 --> Hooks Class Initialized
DEBUG - 2024-04-06 14:28:51 --> UTF-8 Support Enabled
INFO - 2024-04-06 14:28:51 --> Utf8 Class Initialized
INFO - 2024-04-06 14:28:51 --> URI Class Initialized
DEBUG - 2024-04-06 14:28:51 --> No URI present. Default controller set.
INFO - 2024-04-06 14:28:51 --> Router Class Initialized
INFO - 2024-04-06 14:28:51 --> Output Class Initialized
INFO - 2024-04-06 14:28:51 --> Security Class Initialized
DEBUG - 2024-04-06 14:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 14:28:51 --> Input Class Initialized
INFO - 2024-04-06 14:28:51 --> Language Class Initialized
INFO - 2024-04-06 14:28:51 --> Loader Class Initialized
INFO - 2024-04-06 14:28:51 --> Helper loaded: url_helper
INFO - 2024-04-06 14:28:51 --> Helper loaded: file_helper
INFO - 2024-04-06 14:28:51 --> Helper loaded: html_helper
INFO - 2024-04-06 14:28:51 --> Helper loaded: text_helper
INFO - 2024-04-06 14:28:51 --> Helper loaded: form_helper
INFO - 2024-04-06 14:28:51 --> Helper loaded: lang_helper
INFO - 2024-04-06 14:28:51 --> Helper loaded: security_helper
INFO - 2024-04-06 14:28:51 --> Helper loaded: cookie_helper
INFO - 2024-04-06 14:28:51 --> Database Driver Class Initialized
INFO - 2024-04-06 14:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 14:28:51 --> Parser Class Initialized
INFO - 2024-04-06 14:28:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 14:28:51 --> Pagination Class Initialized
INFO - 2024-04-06 14:28:51 --> Form Validation Class Initialized
INFO - 2024-04-06 14:28:51 --> Controller Class Initialized
INFO - 2024-04-06 14:28:51 --> Model Class Initialized
DEBUG - 2024-04-06 14:28:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 14:28:51 --> Model Class Initialized
DEBUG - 2024-04-06 14:28:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 14:28:51 --> Model Class Initialized
INFO - 2024-04-06 14:28:51 --> Model Class Initialized
INFO - 2024-04-06 14:28:51 --> Model Class Initialized
INFO - 2024-04-06 14:28:51 --> Model Class Initialized
DEBUG - 2024-04-06 14:28:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-06 14:28:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 14:28:51 --> Model Class Initialized
INFO - 2024-04-06 14:28:51 --> Model Class Initialized
INFO - 2024-04-06 14:28:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-06 14:28:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-06 14:28:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-06 14:28:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-06 14:28:51 --> Model Class Initialized
INFO - 2024-04-06 14:28:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-06 14:28:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-06 14:28:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-06 14:28:51 --> Final output sent to browser
DEBUG - 2024-04-06 14:28:51 --> Total execution time: 0.2519
ERROR - 2024-04-06 14:29:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 14:29:11 --> Config Class Initialized
INFO - 2024-04-06 14:29:11 --> Hooks Class Initialized
DEBUG - 2024-04-06 14:29:11 --> UTF-8 Support Enabled
INFO - 2024-04-06 14:29:11 --> Utf8 Class Initialized
INFO - 2024-04-06 14:29:11 --> URI Class Initialized
INFO - 2024-04-06 14:29:11 --> Router Class Initialized
INFO - 2024-04-06 14:29:11 --> Output Class Initialized
INFO - 2024-04-06 14:29:11 --> Security Class Initialized
DEBUG - 2024-04-06 14:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 14:29:11 --> Input Class Initialized
INFO - 2024-04-06 14:29:11 --> Language Class Initialized
INFO - 2024-04-06 14:29:11 --> Loader Class Initialized
INFO - 2024-04-06 14:29:11 --> Helper loaded: url_helper
INFO - 2024-04-06 14:29:11 --> Helper loaded: file_helper
INFO - 2024-04-06 14:29:11 --> Helper loaded: html_helper
INFO - 2024-04-06 14:29:11 --> Helper loaded: text_helper
INFO - 2024-04-06 14:29:11 --> Helper loaded: form_helper
INFO - 2024-04-06 14:29:11 --> Helper loaded: lang_helper
INFO - 2024-04-06 14:29:11 --> Helper loaded: security_helper
INFO - 2024-04-06 14:29:11 --> Helper loaded: cookie_helper
INFO - 2024-04-06 14:29:11 --> Database Driver Class Initialized
INFO - 2024-04-06 14:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 14:29:11 --> Parser Class Initialized
INFO - 2024-04-06 14:29:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 14:29:11 --> Pagination Class Initialized
INFO - 2024-04-06 14:29:11 --> Form Validation Class Initialized
INFO - 2024-04-06 14:29:11 --> Controller Class Initialized
DEBUG - 2024-04-06 14:29:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-06 14:29:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 14:29:11 --> Model Class Initialized
DEBUG - 2024-04-06 14:29:11 --> Lgift class already loaded. Second attempt ignored.
INFO - 2024-04-06 14:29:11 --> Model Class Initialized
DEBUG - 2024-04-06 14:29:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-06 14:29:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 14:29:11 --> Model Class Initialized
DEBUG - 2024-04-06 14:29:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 14:29:11 --> Model Class Initialized
INFO - 2024-04-06 14:29:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/gift.php
DEBUG - 2024-04-06 14:29:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-06 14:29:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-06 14:29:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-06 14:29:11 --> Model Class Initialized
INFO - 2024-04-06 14:29:11 --> Model Class Initialized
INFO - 2024-04-06 14:29:11 --> Model Class Initialized
INFO - 2024-04-06 14:29:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-06 14:29:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-06 14:29:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-06 14:29:11 --> Final output sent to browser
DEBUG - 2024-04-06 14:29:11 --> Total execution time: 0.1533
ERROR - 2024-04-06 14:29:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 14:29:12 --> Config Class Initialized
INFO - 2024-04-06 14:29:12 --> Hooks Class Initialized
DEBUG - 2024-04-06 14:29:12 --> UTF-8 Support Enabled
INFO - 2024-04-06 14:29:12 --> Utf8 Class Initialized
INFO - 2024-04-06 14:29:12 --> URI Class Initialized
INFO - 2024-04-06 14:29:12 --> Router Class Initialized
INFO - 2024-04-06 14:29:12 --> Output Class Initialized
INFO - 2024-04-06 14:29:12 --> Security Class Initialized
DEBUG - 2024-04-06 14:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 14:29:12 --> Input Class Initialized
INFO - 2024-04-06 14:29:12 --> Language Class Initialized
INFO - 2024-04-06 14:29:12 --> Loader Class Initialized
INFO - 2024-04-06 14:29:12 --> Helper loaded: url_helper
INFO - 2024-04-06 14:29:12 --> Helper loaded: file_helper
INFO - 2024-04-06 14:29:12 --> Helper loaded: html_helper
INFO - 2024-04-06 14:29:12 --> Helper loaded: text_helper
INFO - 2024-04-06 14:29:12 --> Helper loaded: form_helper
INFO - 2024-04-06 14:29:12 --> Helper loaded: lang_helper
INFO - 2024-04-06 14:29:12 --> Helper loaded: security_helper
INFO - 2024-04-06 14:29:12 --> Helper loaded: cookie_helper
INFO - 2024-04-06 14:29:12 --> Database Driver Class Initialized
INFO - 2024-04-06 14:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 14:29:12 --> Parser Class Initialized
INFO - 2024-04-06 14:29:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 14:29:12 --> Pagination Class Initialized
INFO - 2024-04-06 14:29:12 --> Form Validation Class Initialized
INFO - 2024-04-06 14:29:12 --> Controller Class Initialized
DEBUG - 2024-04-06 14:29:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-06 14:29:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 14:29:12 --> Model Class Initialized
INFO - 2024-04-06 14:29:12 --> Final output sent to browser
DEBUG - 2024-04-06 14:29:12 --> Total execution time: 0.0204
ERROR - 2024-04-06 14:30:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 14:30:12 --> Config Class Initialized
INFO - 2024-04-06 14:30:12 --> Hooks Class Initialized
DEBUG - 2024-04-06 14:30:12 --> UTF-8 Support Enabled
INFO - 2024-04-06 14:30:12 --> Utf8 Class Initialized
INFO - 2024-04-06 14:30:12 --> URI Class Initialized
INFO - 2024-04-06 14:30:12 --> Router Class Initialized
INFO - 2024-04-06 14:30:12 --> Output Class Initialized
INFO - 2024-04-06 14:30:12 --> Security Class Initialized
DEBUG - 2024-04-06 14:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 14:30:12 --> Input Class Initialized
INFO - 2024-04-06 14:30:12 --> Language Class Initialized
INFO - 2024-04-06 14:30:12 --> Loader Class Initialized
INFO - 2024-04-06 14:30:12 --> Helper loaded: url_helper
INFO - 2024-04-06 14:30:12 --> Helper loaded: file_helper
INFO - 2024-04-06 14:30:12 --> Helper loaded: html_helper
INFO - 2024-04-06 14:30:12 --> Helper loaded: text_helper
INFO - 2024-04-06 14:30:12 --> Helper loaded: form_helper
INFO - 2024-04-06 14:30:12 --> Helper loaded: lang_helper
INFO - 2024-04-06 14:30:12 --> Helper loaded: security_helper
INFO - 2024-04-06 14:30:12 --> Helper loaded: cookie_helper
INFO - 2024-04-06 14:30:12 --> Database Driver Class Initialized
INFO - 2024-04-06 14:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 14:30:12 --> Parser Class Initialized
INFO - 2024-04-06 14:30:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 14:30:12 --> Pagination Class Initialized
INFO - 2024-04-06 14:30:12 --> Form Validation Class Initialized
INFO - 2024-04-06 14:30:12 --> Controller Class Initialized
DEBUG - 2024-04-06 14:30:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-06 14:30:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 14:30:12 --> Model Class Initialized
INFO - 2024-04-06 14:30:12 --> Final output sent to browser
DEBUG - 2024-04-06 14:30:12 --> Total execution time: 0.0197
ERROR - 2024-04-06 14:30:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 14:30:25 --> Config Class Initialized
INFO - 2024-04-06 14:30:25 --> Hooks Class Initialized
DEBUG - 2024-04-06 14:30:25 --> UTF-8 Support Enabled
INFO - 2024-04-06 14:30:25 --> Utf8 Class Initialized
INFO - 2024-04-06 14:30:25 --> URI Class Initialized
INFO - 2024-04-06 14:30:25 --> Router Class Initialized
INFO - 2024-04-06 14:30:25 --> Output Class Initialized
INFO - 2024-04-06 14:30:25 --> Security Class Initialized
DEBUG - 2024-04-06 14:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 14:30:25 --> Input Class Initialized
INFO - 2024-04-06 14:30:25 --> Language Class Initialized
INFO - 2024-04-06 14:30:25 --> Loader Class Initialized
INFO - 2024-04-06 14:30:25 --> Helper loaded: url_helper
INFO - 2024-04-06 14:30:25 --> Helper loaded: file_helper
INFO - 2024-04-06 14:30:25 --> Helper loaded: html_helper
INFO - 2024-04-06 14:30:25 --> Helper loaded: text_helper
INFO - 2024-04-06 14:30:25 --> Helper loaded: form_helper
INFO - 2024-04-06 14:30:25 --> Helper loaded: lang_helper
INFO - 2024-04-06 14:30:25 --> Helper loaded: security_helper
INFO - 2024-04-06 14:30:25 --> Helper loaded: cookie_helper
INFO - 2024-04-06 14:30:25 --> Database Driver Class Initialized
INFO - 2024-04-06 14:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 14:30:25 --> Parser Class Initialized
INFO - 2024-04-06 14:30:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 14:30:25 --> Pagination Class Initialized
INFO - 2024-04-06 14:30:25 --> Form Validation Class Initialized
INFO - 2024-04-06 14:30:25 --> Controller Class Initialized
INFO - 2024-04-06 14:30:25 --> Model Class Initialized
INFO - 2024-04-06 14:30:25 --> Model Class Initialized
INFO - 2024-04-06 14:30:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2024-04-06 14:30:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-06 14:30:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-06 14:30:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-06 14:30:25 --> Model Class Initialized
INFO - 2024-04-06 14:30:25 --> Model Class Initialized
INFO - 2024-04-06 14:30:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-06 14:30:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-06 14:30:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-06 14:30:25 --> Final output sent to browser
DEBUG - 2024-04-06 14:30:25 --> Total execution time: 0.1650
ERROR - 2024-04-06 14:30:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 14:30:26 --> Config Class Initialized
INFO - 2024-04-06 14:30:26 --> Hooks Class Initialized
DEBUG - 2024-04-06 14:30:26 --> UTF-8 Support Enabled
INFO - 2024-04-06 14:30:26 --> Utf8 Class Initialized
INFO - 2024-04-06 14:30:26 --> URI Class Initialized
INFO - 2024-04-06 14:30:26 --> Router Class Initialized
INFO - 2024-04-06 14:30:26 --> Output Class Initialized
INFO - 2024-04-06 14:30:26 --> Security Class Initialized
DEBUG - 2024-04-06 14:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 14:30:26 --> Input Class Initialized
INFO - 2024-04-06 14:30:26 --> Language Class Initialized
INFO - 2024-04-06 14:30:26 --> Loader Class Initialized
INFO - 2024-04-06 14:30:26 --> Helper loaded: url_helper
INFO - 2024-04-06 14:30:26 --> Helper loaded: file_helper
INFO - 2024-04-06 14:30:26 --> Helper loaded: html_helper
INFO - 2024-04-06 14:30:26 --> Helper loaded: text_helper
INFO - 2024-04-06 14:30:26 --> Helper loaded: form_helper
INFO - 2024-04-06 14:30:26 --> Helper loaded: lang_helper
INFO - 2024-04-06 14:30:26 --> Helper loaded: security_helper
INFO - 2024-04-06 14:30:26 --> Helper loaded: cookie_helper
INFO - 2024-04-06 14:30:26 --> Database Driver Class Initialized
INFO - 2024-04-06 14:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 14:30:26 --> Parser Class Initialized
INFO - 2024-04-06 14:30:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 14:30:26 --> Pagination Class Initialized
INFO - 2024-04-06 14:30:26 --> Form Validation Class Initialized
INFO - 2024-04-06 14:30:26 --> Controller Class Initialized
INFO - 2024-04-06 14:30:26 --> Model Class Initialized
INFO - 2024-04-06 14:30:26 --> Model Class Initialized
INFO - 2024-04-06 14:30:26 --> Final output sent to browser
DEBUG - 2024-04-06 14:30:26 --> Total execution time: 0.0877
ERROR - 2024-04-06 14:31:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 14:31:10 --> Config Class Initialized
INFO - 2024-04-06 14:31:10 --> Hooks Class Initialized
DEBUG - 2024-04-06 14:31:10 --> UTF-8 Support Enabled
INFO - 2024-04-06 14:31:10 --> Utf8 Class Initialized
INFO - 2024-04-06 14:31:10 --> URI Class Initialized
INFO - 2024-04-06 14:31:10 --> Router Class Initialized
INFO - 2024-04-06 14:31:10 --> Output Class Initialized
INFO - 2024-04-06 14:31:10 --> Security Class Initialized
DEBUG - 2024-04-06 14:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 14:31:10 --> Input Class Initialized
INFO - 2024-04-06 14:31:10 --> Language Class Initialized
INFO - 2024-04-06 14:31:10 --> Loader Class Initialized
INFO - 2024-04-06 14:31:10 --> Helper loaded: url_helper
INFO - 2024-04-06 14:31:10 --> Helper loaded: file_helper
INFO - 2024-04-06 14:31:10 --> Helper loaded: html_helper
INFO - 2024-04-06 14:31:10 --> Helper loaded: text_helper
INFO - 2024-04-06 14:31:10 --> Helper loaded: form_helper
INFO - 2024-04-06 14:31:10 --> Helper loaded: lang_helper
INFO - 2024-04-06 14:31:10 --> Helper loaded: security_helper
INFO - 2024-04-06 14:31:10 --> Helper loaded: cookie_helper
INFO - 2024-04-06 14:31:10 --> Database Driver Class Initialized
INFO - 2024-04-06 14:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 14:31:10 --> Parser Class Initialized
INFO - 2024-04-06 14:31:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 14:31:10 --> Pagination Class Initialized
INFO - 2024-04-06 14:31:10 --> Form Validation Class Initialized
INFO - 2024-04-06 14:31:10 --> Controller Class Initialized
DEBUG - 2024-04-06 14:31:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-06 14:31:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 14:31:10 --> Model Class Initialized
DEBUG - 2024-04-06 14:31:10 --> Lgift class already loaded. Second attempt ignored.
INFO - 2024-04-06 14:31:10 --> Model Class Initialized
DEBUG - 2024-04-06 14:31:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-06 14:31:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 14:31:10 --> Model Class Initialized
DEBUG - 2024-04-06 14:31:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 14:31:10 --> Model Class Initialized
INFO - 2024-04-06 14:31:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/gift.php
DEBUG - 2024-04-06 14:31:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-06 14:31:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-06 14:31:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-06 14:31:10 --> Model Class Initialized
INFO - 2024-04-06 14:31:10 --> Model Class Initialized
INFO - 2024-04-06 14:31:10 --> Model Class Initialized
INFO - 2024-04-06 14:31:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-06 14:31:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-06 14:31:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-06 14:31:10 --> Final output sent to browser
DEBUG - 2024-04-06 14:31:10 --> Total execution time: 0.1488
ERROR - 2024-04-06 14:31:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 14:31:10 --> Config Class Initialized
INFO - 2024-04-06 14:31:10 --> Hooks Class Initialized
DEBUG - 2024-04-06 14:31:10 --> UTF-8 Support Enabled
INFO - 2024-04-06 14:31:10 --> Utf8 Class Initialized
INFO - 2024-04-06 14:31:10 --> URI Class Initialized
DEBUG - 2024-04-06 14:31:10 --> No URI present. Default controller set.
INFO - 2024-04-06 14:31:10 --> Router Class Initialized
INFO - 2024-04-06 14:31:10 --> Output Class Initialized
INFO - 2024-04-06 14:31:10 --> Security Class Initialized
DEBUG - 2024-04-06 14:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 14:31:10 --> Input Class Initialized
INFO - 2024-04-06 14:31:10 --> Language Class Initialized
INFO - 2024-04-06 14:31:10 --> Loader Class Initialized
INFO - 2024-04-06 14:31:10 --> Helper loaded: url_helper
INFO - 2024-04-06 14:31:10 --> Helper loaded: file_helper
INFO - 2024-04-06 14:31:10 --> Helper loaded: html_helper
INFO - 2024-04-06 14:31:10 --> Helper loaded: text_helper
INFO - 2024-04-06 14:31:10 --> Helper loaded: form_helper
INFO - 2024-04-06 14:31:10 --> Helper loaded: lang_helper
INFO - 2024-04-06 14:31:10 --> Helper loaded: security_helper
INFO - 2024-04-06 14:31:10 --> Helper loaded: cookie_helper
INFO - 2024-04-06 14:31:10 --> Database Driver Class Initialized
INFO - 2024-04-06 14:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 14:31:10 --> Parser Class Initialized
INFO - 2024-04-06 14:31:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 14:31:10 --> Pagination Class Initialized
INFO - 2024-04-06 14:31:10 --> Form Validation Class Initialized
INFO - 2024-04-06 14:31:10 --> Controller Class Initialized
INFO - 2024-04-06 14:31:10 --> Model Class Initialized
DEBUG - 2024-04-06 14:31:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 14:31:10 --> Model Class Initialized
DEBUG - 2024-04-06 14:31:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 14:31:10 --> Model Class Initialized
INFO - 2024-04-06 14:31:10 --> Model Class Initialized
INFO - 2024-04-06 14:31:10 --> Model Class Initialized
INFO - 2024-04-06 14:31:10 --> Model Class Initialized
DEBUG - 2024-04-06 14:31:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-06 14:31:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 14:31:10 --> Model Class Initialized
INFO - 2024-04-06 14:31:10 --> Model Class Initialized
ERROR - 2024-04-06 14:31:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 14:31:11 --> Config Class Initialized
INFO - 2024-04-06 14:31:11 --> Hooks Class Initialized
DEBUG - 2024-04-06 14:31:11 --> UTF-8 Support Enabled
INFO - 2024-04-06 14:31:11 --> Utf8 Class Initialized
INFO - 2024-04-06 14:31:11 --> URI Class Initialized
INFO - 2024-04-06 14:31:11 --> Router Class Initialized
INFO - 2024-04-06 14:31:11 --> Output Class Initialized
INFO - 2024-04-06 14:31:11 --> Security Class Initialized
DEBUG - 2024-04-06 14:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 14:31:11 --> Input Class Initialized
INFO - 2024-04-06 14:31:11 --> Language Class Initialized
INFO - 2024-04-06 14:31:11 --> Loader Class Initialized
INFO - 2024-04-06 14:31:11 --> Helper loaded: url_helper
INFO - 2024-04-06 14:31:11 --> Helper loaded: file_helper
INFO - 2024-04-06 14:31:11 --> Helper loaded: html_helper
INFO - 2024-04-06 14:31:11 --> Helper loaded: text_helper
INFO - 2024-04-06 14:31:11 --> Helper loaded: form_helper
INFO - 2024-04-06 14:31:11 --> Helper loaded: lang_helper
INFO - 2024-04-06 14:31:11 --> Helper loaded: security_helper
INFO - 2024-04-06 14:31:11 --> Helper loaded: cookie_helper
INFO - 2024-04-06 14:31:11 --> Database Driver Class Initialized
INFO - 2024-04-06 14:31:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-06 14:31:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-06 14:31:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-06 14:31:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-06 14:31:11 --> Model Class Initialized
INFO - 2024-04-06 14:31:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-06 14:31:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-06 14:31:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-06 14:31:11 --> Final output sent to browser
DEBUG - 2024-04-06 14:31:11 --> Total execution time: 0.2414
INFO - 2024-04-06 14:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 14:31:11 --> Parser Class Initialized
INFO - 2024-04-06 14:31:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 14:31:11 --> Pagination Class Initialized
INFO - 2024-04-06 14:31:11 --> Form Validation Class Initialized
INFO - 2024-04-06 14:31:11 --> Controller Class Initialized
DEBUG - 2024-04-06 14:31:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-06 14:31:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 14:31:11 --> Model Class Initialized
INFO - 2024-04-06 14:31:11 --> Final output sent to browser
DEBUG - 2024-04-06 14:31:11 --> Total execution time: 0.1749
ERROR - 2024-04-06 14:31:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 14:31:13 --> Config Class Initialized
INFO - 2024-04-06 14:31:13 --> Hooks Class Initialized
DEBUG - 2024-04-06 14:31:13 --> UTF-8 Support Enabled
INFO - 2024-04-06 14:31:13 --> Utf8 Class Initialized
INFO - 2024-04-06 14:31:13 --> URI Class Initialized
INFO - 2024-04-06 14:31:13 --> Router Class Initialized
INFO - 2024-04-06 14:31:13 --> Output Class Initialized
INFO - 2024-04-06 14:31:13 --> Security Class Initialized
DEBUG - 2024-04-06 14:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 14:31:13 --> Input Class Initialized
INFO - 2024-04-06 14:31:13 --> Language Class Initialized
INFO - 2024-04-06 14:31:13 --> Loader Class Initialized
INFO - 2024-04-06 14:31:13 --> Helper loaded: url_helper
INFO - 2024-04-06 14:31:13 --> Helper loaded: file_helper
INFO - 2024-04-06 14:31:13 --> Helper loaded: html_helper
INFO - 2024-04-06 14:31:13 --> Helper loaded: text_helper
INFO - 2024-04-06 14:31:13 --> Helper loaded: form_helper
INFO - 2024-04-06 14:31:13 --> Helper loaded: lang_helper
INFO - 2024-04-06 14:31:13 --> Helper loaded: security_helper
INFO - 2024-04-06 14:31:13 --> Helper loaded: cookie_helper
INFO - 2024-04-06 14:31:13 --> Database Driver Class Initialized
INFO - 2024-04-06 14:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 14:31:13 --> Parser Class Initialized
INFO - 2024-04-06 14:31:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 14:31:13 --> Pagination Class Initialized
INFO - 2024-04-06 14:31:13 --> Form Validation Class Initialized
INFO - 2024-04-06 14:31:13 --> Controller Class Initialized
INFO - 2024-04-06 14:31:13 --> Model Class Initialized
DEBUG - 2024-04-06 14:31:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 14:31:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-04-06 14:31:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-06 14:31:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-06 14:31:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-06 14:31:13 --> Model Class Initialized
INFO - 2024-04-06 14:31:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-06 14:31:13 --> Final output sent to browser
DEBUG - 2024-04-06 14:31:13 --> Total execution time: 0.0289
ERROR - 2024-04-06 14:31:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 14:31:13 --> Config Class Initialized
INFO - 2024-04-06 14:31:13 --> Hooks Class Initialized
DEBUG - 2024-04-06 14:31:13 --> UTF-8 Support Enabled
INFO - 2024-04-06 14:31:13 --> Utf8 Class Initialized
INFO - 2024-04-06 14:31:13 --> URI Class Initialized
INFO - 2024-04-06 14:31:13 --> Router Class Initialized
INFO - 2024-04-06 14:31:13 --> Output Class Initialized
INFO - 2024-04-06 14:31:13 --> Security Class Initialized
DEBUG - 2024-04-06 14:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 14:31:13 --> Input Class Initialized
INFO - 2024-04-06 14:31:13 --> Language Class Initialized
INFO - 2024-04-06 14:31:13 --> Loader Class Initialized
INFO - 2024-04-06 14:31:13 --> Helper loaded: url_helper
INFO - 2024-04-06 14:31:13 --> Helper loaded: file_helper
INFO - 2024-04-06 14:31:13 --> Helper loaded: html_helper
INFO - 2024-04-06 14:31:13 --> Helper loaded: text_helper
INFO - 2024-04-06 14:31:13 --> Helper loaded: form_helper
INFO - 2024-04-06 14:31:13 --> Helper loaded: lang_helper
INFO - 2024-04-06 14:31:13 --> Helper loaded: security_helper
INFO - 2024-04-06 14:31:13 --> Helper loaded: cookie_helper
INFO - 2024-04-06 14:31:13 --> Database Driver Class Initialized
INFO - 2024-04-06 14:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 14:31:13 --> Parser Class Initialized
INFO - 2024-04-06 14:31:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 14:31:13 --> Pagination Class Initialized
INFO - 2024-04-06 14:31:13 --> Form Validation Class Initialized
INFO - 2024-04-06 14:31:13 --> Controller Class Initialized
INFO - 2024-04-06 14:31:13 --> Model Class Initialized
DEBUG - 2024-04-06 14:31:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 14:31:13 --> Model Class Initialized
DEBUG - 2024-04-06 14:31:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 14:31:13 --> Model Class Initialized
INFO - 2024-04-06 14:31:13 --> Model Class Initialized
INFO - 2024-04-06 14:31:13 --> Model Class Initialized
INFO - 2024-04-06 14:31:13 --> Model Class Initialized
DEBUG - 2024-04-06 14:31:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-06 14:31:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 14:31:13 --> Model Class Initialized
INFO - 2024-04-06 14:31:13 --> Model Class Initialized
INFO - 2024-04-06 14:31:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-06 14:31:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-06 14:31:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-06 14:31:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-06 14:31:13 --> Model Class Initialized
INFO - 2024-04-06 14:31:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-06 14:31:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-06 14:31:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-06 14:31:13 --> Final output sent to browser
DEBUG - 2024-04-06 14:31:13 --> Total execution time: 0.2716
ERROR - 2024-04-06 14:31:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 14:31:25 --> Config Class Initialized
INFO - 2024-04-06 14:31:25 --> Hooks Class Initialized
DEBUG - 2024-04-06 14:31:25 --> UTF-8 Support Enabled
INFO - 2024-04-06 14:31:25 --> Utf8 Class Initialized
INFO - 2024-04-06 14:31:25 --> URI Class Initialized
INFO - 2024-04-06 14:31:25 --> Router Class Initialized
INFO - 2024-04-06 14:31:25 --> Output Class Initialized
INFO - 2024-04-06 14:31:25 --> Security Class Initialized
DEBUG - 2024-04-06 14:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 14:31:25 --> Input Class Initialized
INFO - 2024-04-06 14:31:25 --> Language Class Initialized
INFO - 2024-04-06 14:31:25 --> Loader Class Initialized
INFO - 2024-04-06 14:31:25 --> Helper loaded: url_helper
INFO - 2024-04-06 14:31:25 --> Helper loaded: file_helper
INFO - 2024-04-06 14:31:25 --> Helper loaded: html_helper
INFO - 2024-04-06 14:31:25 --> Helper loaded: text_helper
INFO - 2024-04-06 14:31:25 --> Helper loaded: form_helper
INFO - 2024-04-06 14:31:25 --> Helper loaded: lang_helper
INFO - 2024-04-06 14:31:25 --> Helper loaded: security_helper
INFO - 2024-04-06 14:31:25 --> Helper loaded: cookie_helper
INFO - 2024-04-06 14:31:25 --> Database Driver Class Initialized
INFO - 2024-04-06 14:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 14:31:25 --> Parser Class Initialized
INFO - 2024-04-06 14:31:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 14:31:25 --> Pagination Class Initialized
INFO - 2024-04-06 14:31:25 --> Form Validation Class Initialized
INFO - 2024-04-06 14:31:25 --> Controller Class Initialized
INFO - 2024-04-06 14:31:25 --> Model Class Initialized
DEBUG - 2024-04-06 14:31:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-06 14:31:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 14:31:25 --> Model Class Initialized
DEBUG - 2024-04-06 14:31:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 14:31:25 --> Model Class Initialized
INFO - 2024-04-06 14:31:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-04-06 14:31:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-06 14:31:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-06 14:31:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-06 14:31:25 --> Model Class Initialized
INFO - 2024-04-06 14:31:25 --> Model Class Initialized
INFO - 2024-04-06 14:31:25 --> Model Class Initialized
INFO - 2024-04-06 14:31:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-06 14:31:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-06 14:31:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-06 14:31:25 --> Final output sent to browser
DEBUG - 2024-04-06 14:31:25 --> Total execution time: 0.1510
ERROR - 2024-04-06 14:31:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 14:31:26 --> Config Class Initialized
INFO - 2024-04-06 14:31:26 --> Hooks Class Initialized
DEBUG - 2024-04-06 14:31:26 --> UTF-8 Support Enabled
INFO - 2024-04-06 14:31:26 --> Utf8 Class Initialized
INFO - 2024-04-06 14:31:26 --> URI Class Initialized
INFO - 2024-04-06 14:31:26 --> Router Class Initialized
INFO - 2024-04-06 14:31:26 --> Output Class Initialized
INFO - 2024-04-06 14:31:26 --> Security Class Initialized
DEBUG - 2024-04-06 14:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 14:31:26 --> Input Class Initialized
INFO - 2024-04-06 14:31:26 --> Language Class Initialized
INFO - 2024-04-06 14:31:26 --> Loader Class Initialized
INFO - 2024-04-06 14:31:26 --> Helper loaded: url_helper
INFO - 2024-04-06 14:31:26 --> Helper loaded: file_helper
INFO - 2024-04-06 14:31:26 --> Helper loaded: html_helper
INFO - 2024-04-06 14:31:26 --> Helper loaded: text_helper
INFO - 2024-04-06 14:31:26 --> Helper loaded: form_helper
INFO - 2024-04-06 14:31:26 --> Helper loaded: lang_helper
INFO - 2024-04-06 14:31:26 --> Helper loaded: security_helper
INFO - 2024-04-06 14:31:26 --> Helper loaded: cookie_helper
INFO - 2024-04-06 14:31:26 --> Database Driver Class Initialized
INFO - 2024-04-06 14:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 14:31:26 --> Parser Class Initialized
INFO - 2024-04-06 14:31:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 14:31:26 --> Pagination Class Initialized
INFO - 2024-04-06 14:31:26 --> Form Validation Class Initialized
INFO - 2024-04-06 14:31:26 --> Controller Class Initialized
INFO - 2024-04-06 14:31:26 --> Model Class Initialized
DEBUG - 2024-04-06 14:31:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-06 14:31:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 14:31:26 --> Model Class Initialized
DEBUG - 2024-04-06 14:31:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 14:31:26 --> Model Class Initialized
INFO - 2024-04-06 14:31:26 --> Final output sent to browser
DEBUG - 2024-04-06 14:31:26 --> Total execution time: 0.0289
ERROR - 2024-04-06 14:31:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 14:31:57 --> Config Class Initialized
INFO - 2024-04-06 14:31:57 --> Hooks Class Initialized
DEBUG - 2024-04-06 14:31:57 --> UTF-8 Support Enabled
INFO - 2024-04-06 14:31:57 --> Utf8 Class Initialized
INFO - 2024-04-06 14:31:57 --> URI Class Initialized
INFO - 2024-04-06 14:31:57 --> Router Class Initialized
INFO - 2024-04-06 14:31:57 --> Output Class Initialized
INFO - 2024-04-06 14:31:57 --> Security Class Initialized
DEBUG - 2024-04-06 14:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 14:31:57 --> Input Class Initialized
INFO - 2024-04-06 14:31:57 --> Language Class Initialized
INFO - 2024-04-06 14:31:57 --> Loader Class Initialized
INFO - 2024-04-06 14:31:57 --> Helper loaded: url_helper
INFO - 2024-04-06 14:31:57 --> Helper loaded: file_helper
INFO - 2024-04-06 14:31:57 --> Helper loaded: html_helper
INFO - 2024-04-06 14:31:57 --> Helper loaded: text_helper
INFO - 2024-04-06 14:31:57 --> Helper loaded: form_helper
INFO - 2024-04-06 14:31:57 --> Helper loaded: lang_helper
INFO - 2024-04-06 14:31:57 --> Helper loaded: security_helper
INFO - 2024-04-06 14:31:57 --> Helper loaded: cookie_helper
INFO - 2024-04-06 14:31:57 --> Database Driver Class Initialized
INFO - 2024-04-06 14:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-06 14:31:57 --> Parser Class Initialized
INFO - 2024-04-06 14:31:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-06 14:31:57 --> Pagination Class Initialized
INFO - 2024-04-06 14:31:57 --> Form Validation Class Initialized
INFO - 2024-04-06 14:31:57 --> Controller Class Initialized
INFO - 2024-04-06 14:31:57 --> Model Class Initialized
DEBUG - 2024-04-06 14:31:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 14:31:57 --> Model Class Initialized
DEBUG - 2024-04-06 14:31:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 14:31:57 --> Model Class Initialized
INFO - 2024-04-06 14:31:57 --> Model Class Initialized
INFO - 2024-04-06 14:31:57 --> Model Class Initialized
INFO - 2024-04-06 14:31:57 --> Model Class Initialized
DEBUG - 2024-04-06 14:31:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-06 14:31:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-06 14:31:57 --> Model Class Initialized
INFO - 2024-04-06 14:31:57 --> Model Class Initialized
INFO - 2024-04-06 14:31:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-06 14:31:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-06 14:31:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-06 14:31:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-06 14:31:57 --> Model Class Initialized
INFO - 2024-04-06 14:31:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-06 14:31:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-06 14:31:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-06 14:31:57 --> Final output sent to browser
DEBUG - 2024-04-06 14:31:57 --> Total execution time: 0.2485
ERROR - 2024-04-06 15:32:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 15:32:54 --> Config Class Initialized
INFO - 2024-04-06 15:32:54 --> Hooks Class Initialized
DEBUG - 2024-04-06 15:32:54 --> UTF-8 Support Enabled
INFO - 2024-04-06 15:32:54 --> Utf8 Class Initialized
INFO - 2024-04-06 15:32:54 --> URI Class Initialized
INFO - 2024-04-06 15:32:54 --> Router Class Initialized
INFO - 2024-04-06 15:32:54 --> Output Class Initialized
INFO - 2024-04-06 15:32:54 --> Security Class Initialized
DEBUG - 2024-04-06 15:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 15:32:54 --> Input Class Initialized
INFO - 2024-04-06 15:32:54 --> Language Class Initialized
ERROR - 2024-04-06 15:32:54 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-04-06 18:49:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-06 18:49:58 --> Config Class Initialized
INFO - 2024-04-06 18:49:58 --> Hooks Class Initialized
DEBUG - 2024-04-06 18:49:58 --> UTF-8 Support Enabled
INFO - 2024-04-06 18:49:58 --> Utf8 Class Initialized
INFO - 2024-04-06 18:49:58 --> URI Class Initialized
INFO - 2024-04-06 18:49:58 --> Router Class Initialized
INFO - 2024-04-06 18:49:58 --> Output Class Initialized
INFO - 2024-04-06 18:49:58 --> Security Class Initialized
DEBUG - 2024-04-06 18:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-06 18:49:58 --> Input Class Initialized
INFO - 2024-04-06 18:49:58 --> Language Class Initialized
ERROR - 2024-04-06 18:49:58 --> 404 Page Not Found: Well-known/assetlinks.json
