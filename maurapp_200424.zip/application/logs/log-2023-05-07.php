<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-07 11:39:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 11:39:31 --> Config Class Initialized
INFO - 2023-05-07 11:39:31 --> Hooks Class Initialized
DEBUG - 2023-05-07 11:39:31 --> UTF-8 Support Enabled
INFO - 2023-05-07 11:39:31 --> Utf8 Class Initialized
INFO - 2023-05-07 11:39:31 --> URI Class Initialized
DEBUG - 2023-05-07 11:39:31 --> No URI present. Default controller set.
INFO - 2023-05-07 11:39:31 --> Router Class Initialized
INFO - 2023-05-07 11:39:31 --> Output Class Initialized
INFO - 2023-05-07 11:39:31 --> Security Class Initialized
DEBUG - 2023-05-07 11:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 11:39:31 --> Input Class Initialized
INFO - 2023-05-07 11:39:31 --> Language Class Initialized
INFO - 2023-05-07 11:39:31 --> Loader Class Initialized
INFO - 2023-05-07 11:39:31 --> Helper loaded: url_helper
INFO - 2023-05-07 11:39:31 --> Helper loaded: file_helper
INFO - 2023-05-07 11:39:31 --> Helper loaded: html_helper
INFO - 2023-05-07 11:39:31 --> Helper loaded: text_helper
INFO - 2023-05-07 11:39:31 --> Helper loaded: form_helper
INFO - 2023-05-07 11:39:31 --> Helper loaded: lang_helper
INFO - 2023-05-07 11:39:31 --> Helper loaded: security_helper
INFO - 2023-05-07 11:39:31 --> Helper loaded: cookie_helper
INFO - 2023-05-07 11:39:31 --> Database Driver Class Initialized
INFO - 2023-05-07 11:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 11:39:31 --> Parser Class Initialized
INFO - 2023-05-07 11:39:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 11:39:31 --> Pagination Class Initialized
INFO - 2023-05-07 11:39:31 --> Form Validation Class Initialized
INFO - 2023-05-07 11:39:31 --> Controller Class Initialized
INFO - 2023-05-07 11:39:31 --> Model Class Initialized
DEBUG - 2023-05-07 11:39:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-07 11:39:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 11:39:31 --> Config Class Initialized
INFO - 2023-05-07 11:39:31 --> Hooks Class Initialized
DEBUG - 2023-05-07 11:39:31 --> UTF-8 Support Enabled
INFO - 2023-05-07 11:39:31 --> Utf8 Class Initialized
INFO - 2023-05-07 11:39:31 --> URI Class Initialized
INFO - 2023-05-07 11:39:31 --> Router Class Initialized
INFO - 2023-05-07 11:39:31 --> Output Class Initialized
INFO - 2023-05-07 11:39:31 --> Security Class Initialized
DEBUG - 2023-05-07 11:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 11:39:31 --> Input Class Initialized
INFO - 2023-05-07 11:39:31 --> Language Class Initialized
INFO - 2023-05-07 11:39:31 --> Loader Class Initialized
INFO - 2023-05-07 11:39:31 --> Helper loaded: url_helper
INFO - 2023-05-07 11:39:31 --> Helper loaded: file_helper
INFO - 2023-05-07 11:39:31 --> Helper loaded: html_helper
INFO - 2023-05-07 11:39:31 --> Helper loaded: text_helper
INFO - 2023-05-07 11:39:31 --> Helper loaded: form_helper
INFO - 2023-05-07 11:39:31 --> Helper loaded: lang_helper
INFO - 2023-05-07 11:39:31 --> Helper loaded: security_helper
INFO - 2023-05-07 11:39:31 --> Helper loaded: cookie_helper
INFO - 2023-05-07 11:39:31 --> Database Driver Class Initialized
INFO - 2023-05-07 11:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 11:39:31 --> Parser Class Initialized
INFO - 2023-05-07 11:39:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 11:39:31 --> Pagination Class Initialized
INFO - 2023-05-07 11:39:31 --> Form Validation Class Initialized
INFO - 2023-05-07 11:39:31 --> Controller Class Initialized
INFO - 2023-05-07 11:39:31 --> Model Class Initialized
DEBUG - 2023-05-07 11:39:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 11:39:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-07 11:39:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 11:39:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 11:39:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 11:39:31 --> Model Class Initialized
INFO - 2023-05-07 11:39:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 11:39:31 --> Final output sent to browser
DEBUG - 2023-05-07 11:39:31 --> Total execution time: 0.0319
ERROR - 2023-05-07 11:39:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 11:39:49 --> Config Class Initialized
INFO - 2023-05-07 11:39:49 --> Hooks Class Initialized
DEBUG - 2023-05-07 11:39:49 --> UTF-8 Support Enabled
INFO - 2023-05-07 11:39:49 --> Utf8 Class Initialized
INFO - 2023-05-07 11:39:49 --> URI Class Initialized
INFO - 2023-05-07 11:39:49 --> Router Class Initialized
INFO - 2023-05-07 11:39:49 --> Output Class Initialized
INFO - 2023-05-07 11:39:49 --> Security Class Initialized
DEBUG - 2023-05-07 11:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 11:39:49 --> Input Class Initialized
INFO - 2023-05-07 11:39:49 --> Language Class Initialized
INFO - 2023-05-07 11:39:49 --> Loader Class Initialized
INFO - 2023-05-07 11:39:49 --> Helper loaded: url_helper
INFO - 2023-05-07 11:39:49 --> Helper loaded: file_helper
INFO - 2023-05-07 11:39:49 --> Helper loaded: html_helper
INFO - 2023-05-07 11:39:49 --> Helper loaded: text_helper
INFO - 2023-05-07 11:39:49 --> Helper loaded: form_helper
INFO - 2023-05-07 11:39:49 --> Helper loaded: lang_helper
INFO - 2023-05-07 11:39:49 --> Helper loaded: security_helper
INFO - 2023-05-07 11:39:49 --> Helper loaded: cookie_helper
INFO - 2023-05-07 11:39:49 --> Database Driver Class Initialized
INFO - 2023-05-07 11:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 11:39:49 --> Parser Class Initialized
INFO - 2023-05-07 11:39:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 11:39:49 --> Pagination Class Initialized
INFO - 2023-05-07 11:39:49 --> Form Validation Class Initialized
INFO - 2023-05-07 11:39:49 --> Controller Class Initialized
INFO - 2023-05-07 11:39:49 --> Model Class Initialized
DEBUG - 2023-05-07 11:39:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 11:39:49 --> Model Class Initialized
INFO - 2023-05-07 11:39:49 --> Final output sent to browser
DEBUG - 2023-05-07 11:39:49 --> Total execution time: 0.0193
ERROR - 2023-05-07 11:39:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 11:39:50 --> Config Class Initialized
INFO - 2023-05-07 11:39:50 --> Hooks Class Initialized
DEBUG - 2023-05-07 11:39:50 --> UTF-8 Support Enabled
INFO - 2023-05-07 11:39:50 --> Utf8 Class Initialized
INFO - 2023-05-07 11:39:50 --> URI Class Initialized
INFO - 2023-05-07 11:39:50 --> Router Class Initialized
INFO - 2023-05-07 11:39:50 --> Output Class Initialized
INFO - 2023-05-07 11:39:50 --> Security Class Initialized
DEBUG - 2023-05-07 11:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 11:39:50 --> Input Class Initialized
INFO - 2023-05-07 11:39:50 --> Language Class Initialized
INFO - 2023-05-07 11:39:50 --> Loader Class Initialized
INFO - 2023-05-07 11:39:50 --> Helper loaded: url_helper
INFO - 2023-05-07 11:39:50 --> Helper loaded: file_helper
INFO - 2023-05-07 11:39:50 --> Helper loaded: html_helper
INFO - 2023-05-07 11:39:50 --> Helper loaded: text_helper
INFO - 2023-05-07 11:39:50 --> Helper loaded: form_helper
INFO - 2023-05-07 11:39:50 --> Helper loaded: lang_helper
INFO - 2023-05-07 11:39:50 --> Helper loaded: security_helper
INFO - 2023-05-07 11:39:50 --> Helper loaded: cookie_helper
INFO - 2023-05-07 11:39:50 --> Database Driver Class Initialized
INFO - 2023-05-07 11:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 11:39:50 --> Parser Class Initialized
INFO - 2023-05-07 11:39:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 11:39:50 --> Pagination Class Initialized
INFO - 2023-05-07 11:39:50 --> Form Validation Class Initialized
INFO - 2023-05-07 11:39:50 --> Controller Class Initialized
INFO - 2023-05-07 11:39:50 --> Model Class Initialized
DEBUG - 2023-05-07 11:39:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 11:39:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-07 11:39:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 11:39:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 11:39:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 11:39:50 --> Model Class Initialized
INFO - 2023-05-07 11:39:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 11:39:50 --> Final output sent to browser
DEBUG - 2023-05-07 11:39:50 --> Total execution time: 0.0306
ERROR - 2023-05-07 11:40:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 11:40:12 --> Config Class Initialized
INFO - 2023-05-07 11:40:12 --> Hooks Class Initialized
DEBUG - 2023-05-07 11:40:12 --> UTF-8 Support Enabled
INFO - 2023-05-07 11:40:12 --> Utf8 Class Initialized
INFO - 2023-05-07 11:40:12 --> URI Class Initialized
INFO - 2023-05-07 11:40:12 --> Router Class Initialized
INFO - 2023-05-07 11:40:12 --> Output Class Initialized
INFO - 2023-05-07 11:40:12 --> Security Class Initialized
DEBUG - 2023-05-07 11:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 11:40:12 --> Input Class Initialized
INFO - 2023-05-07 11:40:12 --> Language Class Initialized
INFO - 2023-05-07 11:40:12 --> Loader Class Initialized
INFO - 2023-05-07 11:40:12 --> Helper loaded: url_helper
INFO - 2023-05-07 11:40:12 --> Helper loaded: file_helper
INFO - 2023-05-07 11:40:12 --> Helper loaded: html_helper
INFO - 2023-05-07 11:40:12 --> Helper loaded: text_helper
INFO - 2023-05-07 11:40:12 --> Helper loaded: form_helper
INFO - 2023-05-07 11:40:12 --> Helper loaded: lang_helper
INFO - 2023-05-07 11:40:12 --> Helper loaded: security_helper
INFO - 2023-05-07 11:40:12 --> Helper loaded: cookie_helper
INFO - 2023-05-07 11:40:12 --> Database Driver Class Initialized
INFO - 2023-05-07 11:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 11:40:12 --> Parser Class Initialized
INFO - 2023-05-07 11:40:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 11:40:12 --> Pagination Class Initialized
INFO - 2023-05-07 11:40:12 --> Form Validation Class Initialized
INFO - 2023-05-07 11:40:12 --> Controller Class Initialized
INFO - 2023-05-07 11:40:12 --> Model Class Initialized
DEBUG - 2023-05-07 11:40:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 11:40:12 --> Model Class Initialized
INFO - 2023-05-07 11:40:12 --> Final output sent to browser
DEBUG - 2023-05-07 11:40:12 --> Total execution time: 0.0197
ERROR - 2023-05-07 11:40:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 11:40:13 --> Config Class Initialized
INFO - 2023-05-07 11:40:13 --> Hooks Class Initialized
DEBUG - 2023-05-07 11:40:13 --> UTF-8 Support Enabled
INFO - 2023-05-07 11:40:13 --> Utf8 Class Initialized
INFO - 2023-05-07 11:40:13 --> URI Class Initialized
DEBUG - 2023-05-07 11:40:13 --> No URI present. Default controller set.
INFO - 2023-05-07 11:40:13 --> Router Class Initialized
INFO - 2023-05-07 11:40:13 --> Output Class Initialized
INFO - 2023-05-07 11:40:13 --> Security Class Initialized
DEBUG - 2023-05-07 11:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 11:40:13 --> Input Class Initialized
INFO - 2023-05-07 11:40:13 --> Language Class Initialized
INFO - 2023-05-07 11:40:13 --> Loader Class Initialized
INFO - 2023-05-07 11:40:13 --> Helper loaded: url_helper
INFO - 2023-05-07 11:40:13 --> Helper loaded: file_helper
INFO - 2023-05-07 11:40:13 --> Helper loaded: html_helper
INFO - 2023-05-07 11:40:13 --> Helper loaded: text_helper
INFO - 2023-05-07 11:40:13 --> Helper loaded: form_helper
INFO - 2023-05-07 11:40:13 --> Helper loaded: lang_helper
INFO - 2023-05-07 11:40:13 --> Helper loaded: security_helper
INFO - 2023-05-07 11:40:13 --> Helper loaded: cookie_helper
INFO - 2023-05-07 11:40:13 --> Database Driver Class Initialized
INFO - 2023-05-07 11:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 11:40:13 --> Parser Class Initialized
INFO - 2023-05-07 11:40:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 11:40:13 --> Pagination Class Initialized
INFO - 2023-05-07 11:40:13 --> Form Validation Class Initialized
INFO - 2023-05-07 11:40:13 --> Controller Class Initialized
INFO - 2023-05-07 11:40:13 --> Model Class Initialized
DEBUG - 2023-05-07 11:40:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 11:40:13 --> Model Class Initialized
DEBUG - 2023-05-07 11:40:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 11:40:13 --> Model Class Initialized
INFO - 2023-05-07 11:40:13 --> Model Class Initialized
INFO - 2023-05-07 11:40:13 --> Model Class Initialized
INFO - 2023-05-07 11:40:13 --> Model Class Initialized
DEBUG - 2023-05-07 11:40:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 11:40:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 11:40:13 --> Model Class Initialized
INFO - 2023-05-07 11:40:13 --> Model Class Initialized
INFO - 2023-05-07 11:40:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-07 11:40:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 11:40:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 11:40:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 11:40:13 --> Model Class Initialized
INFO - 2023-05-07 11:40:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 11:40:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 11:40:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 11:40:13 --> Final output sent to browser
DEBUG - 2023-05-07 11:40:13 --> Total execution time: 0.0811
ERROR - 2023-05-07 11:42:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 11:42:03 --> Config Class Initialized
INFO - 2023-05-07 11:42:03 --> Hooks Class Initialized
DEBUG - 2023-05-07 11:42:03 --> UTF-8 Support Enabled
INFO - 2023-05-07 11:42:03 --> Utf8 Class Initialized
INFO - 2023-05-07 11:42:03 --> URI Class Initialized
INFO - 2023-05-07 11:42:03 --> Router Class Initialized
INFO - 2023-05-07 11:42:03 --> Output Class Initialized
INFO - 2023-05-07 11:42:03 --> Security Class Initialized
DEBUG - 2023-05-07 11:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 11:42:03 --> Input Class Initialized
INFO - 2023-05-07 11:42:03 --> Language Class Initialized
INFO - 2023-05-07 11:42:03 --> Loader Class Initialized
INFO - 2023-05-07 11:42:03 --> Helper loaded: url_helper
INFO - 2023-05-07 11:42:03 --> Helper loaded: file_helper
INFO - 2023-05-07 11:42:03 --> Helper loaded: html_helper
INFO - 2023-05-07 11:42:03 --> Helper loaded: text_helper
INFO - 2023-05-07 11:42:03 --> Helper loaded: form_helper
INFO - 2023-05-07 11:42:03 --> Helper loaded: lang_helper
INFO - 2023-05-07 11:42:03 --> Helper loaded: security_helper
INFO - 2023-05-07 11:42:03 --> Helper loaded: cookie_helper
INFO - 2023-05-07 11:42:03 --> Database Driver Class Initialized
INFO - 2023-05-07 11:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 11:42:03 --> Parser Class Initialized
INFO - 2023-05-07 11:42:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 11:42:03 --> Pagination Class Initialized
INFO - 2023-05-07 11:42:03 --> Form Validation Class Initialized
INFO - 2023-05-07 11:42:03 --> Controller Class Initialized
INFO - 2023-05-07 11:42:03 --> Model Class Initialized
DEBUG - 2023-05-07 11:42:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 11:42:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 11:42:03 --> Model Class Initialized
DEBUG - 2023-05-07 11:42:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 11:42:03 --> Model Class Initialized
INFO - 2023-05-07 11:42:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-05-07 11:42:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 11:42:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 11:42:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 11:42:03 --> Model Class Initialized
INFO - 2023-05-07 11:42:03 --> Model Class Initialized
INFO - 2023-05-07 11:42:03 --> Model Class Initialized
INFO - 2023-05-07 11:42:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 11:42:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 11:42:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 11:42:03 --> Final output sent to browser
DEBUG - 2023-05-07 11:42:03 --> Total execution time: 0.0734
ERROR - 2023-05-07 11:42:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 11:42:04 --> Config Class Initialized
INFO - 2023-05-07 11:42:04 --> Hooks Class Initialized
DEBUG - 2023-05-07 11:42:04 --> UTF-8 Support Enabled
INFO - 2023-05-07 11:42:04 --> Utf8 Class Initialized
INFO - 2023-05-07 11:42:04 --> URI Class Initialized
INFO - 2023-05-07 11:42:04 --> Router Class Initialized
INFO - 2023-05-07 11:42:04 --> Output Class Initialized
INFO - 2023-05-07 11:42:04 --> Security Class Initialized
DEBUG - 2023-05-07 11:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 11:42:04 --> Input Class Initialized
INFO - 2023-05-07 11:42:04 --> Language Class Initialized
INFO - 2023-05-07 11:42:04 --> Loader Class Initialized
INFO - 2023-05-07 11:42:04 --> Helper loaded: url_helper
INFO - 2023-05-07 11:42:04 --> Helper loaded: file_helper
INFO - 2023-05-07 11:42:04 --> Helper loaded: html_helper
INFO - 2023-05-07 11:42:04 --> Helper loaded: text_helper
INFO - 2023-05-07 11:42:04 --> Helper loaded: form_helper
INFO - 2023-05-07 11:42:04 --> Helper loaded: lang_helper
INFO - 2023-05-07 11:42:04 --> Helper loaded: security_helper
INFO - 2023-05-07 11:42:04 --> Helper loaded: cookie_helper
INFO - 2023-05-07 11:42:04 --> Database Driver Class Initialized
INFO - 2023-05-07 11:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 11:42:04 --> Parser Class Initialized
INFO - 2023-05-07 11:42:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 11:42:04 --> Pagination Class Initialized
INFO - 2023-05-07 11:42:04 --> Form Validation Class Initialized
INFO - 2023-05-07 11:42:04 --> Controller Class Initialized
INFO - 2023-05-07 11:42:04 --> Model Class Initialized
DEBUG - 2023-05-07 11:42:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 11:42:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 11:42:04 --> Model Class Initialized
DEBUG - 2023-05-07 11:42:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 11:42:04 --> Model Class Initialized
INFO - 2023-05-07 11:42:04 --> Final output sent to browser
DEBUG - 2023-05-07 11:42:04 --> Total execution time: 0.0429
ERROR - 2023-05-07 11:42:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 11:42:24 --> Config Class Initialized
INFO - 2023-05-07 11:42:24 --> Hooks Class Initialized
DEBUG - 2023-05-07 11:42:24 --> UTF-8 Support Enabled
INFO - 2023-05-07 11:42:24 --> Utf8 Class Initialized
INFO - 2023-05-07 11:42:24 --> URI Class Initialized
INFO - 2023-05-07 11:42:24 --> Router Class Initialized
INFO - 2023-05-07 11:42:24 --> Output Class Initialized
INFO - 2023-05-07 11:42:24 --> Security Class Initialized
DEBUG - 2023-05-07 11:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 11:42:24 --> Input Class Initialized
INFO - 2023-05-07 11:42:24 --> Language Class Initialized
INFO - 2023-05-07 11:42:24 --> Loader Class Initialized
INFO - 2023-05-07 11:42:24 --> Helper loaded: url_helper
INFO - 2023-05-07 11:42:24 --> Helper loaded: file_helper
INFO - 2023-05-07 11:42:24 --> Helper loaded: html_helper
INFO - 2023-05-07 11:42:24 --> Helper loaded: text_helper
INFO - 2023-05-07 11:42:24 --> Helper loaded: form_helper
INFO - 2023-05-07 11:42:24 --> Helper loaded: lang_helper
INFO - 2023-05-07 11:42:24 --> Helper loaded: security_helper
INFO - 2023-05-07 11:42:24 --> Helper loaded: cookie_helper
INFO - 2023-05-07 11:42:24 --> Database Driver Class Initialized
INFO - 2023-05-07 11:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 11:42:24 --> Parser Class Initialized
INFO - 2023-05-07 11:42:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 11:42:24 --> Pagination Class Initialized
INFO - 2023-05-07 11:42:24 --> Form Validation Class Initialized
INFO - 2023-05-07 11:42:24 --> Controller Class Initialized
INFO - 2023-05-07 11:42:24 --> Model Class Initialized
DEBUG - 2023-05-07 11:42:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 11:42:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 11:42:24 --> Model Class Initialized
DEBUG - 2023-05-07 11:42:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 11:42:24 --> Model Class Initialized
INFO - 2023-05-07 11:42:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html.php
DEBUG - 2023-05-07 11:42:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 11:42:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 11:42:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 11:42:24 --> Model Class Initialized
INFO - 2023-05-07 11:42:24 --> Model Class Initialized
INFO - 2023-05-07 11:42:24 --> Model Class Initialized
INFO - 2023-05-07 11:42:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 11:42:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 11:42:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 11:42:24 --> Final output sent to browser
DEBUG - 2023-05-07 11:42:24 --> Total execution time: 0.0839
ERROR - 2023-05-07 11:42:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 11:42:50 --> Config Class Initialized
INFO - 2023-05-07 11:42:50 --> Hooks Class Initialized
DEBUG - 2023-05-07 11:42:50 --> UTF-8 Support Enabled
INFO - 2023-05-07 11:42:50 --> Utf8 Class Initialized
INFO - 2023-05-07 11:42:50 --> URI Class Initialized
INFO - 2023-05-07 11:42:50 --> Router Class Initialized
INFO - 2023-05-07 11:42:50 --> Output Class Initialized
INFO - 2023-05-07 11:42:50 --> Security Class Initialized
DEBUG - 2023-05-07 11:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 11:42:50 --> Input Class Initialized
INFO - 2023-05-07 11:42:50 --> Language Class Initialized
INFO - 2023-05-07 11:42:50 --> Loader Class Initialized
INFO - 2023-05-07 11:42:50 --> Helper loaded: url_helper
INFO - 2023-05-07 11:42:50 --> Helper loaded: file_helper
INFO - 2023-05-07 11:42:50 --> Helper loaded: html_helper
INFO - 2023-05-07 11:42:50 --> Helper loaded: text_helper
INFO - 2023-05-07 11:42:50 --> Helper loaded: form_helper
INFO - 2023-05-07 11:42:50 --> Helper loaded: lang_helper
INFO - 2023-05-07 11:42:50 --> Helper loaded: security_helper
INFO - 2023-05-07 11:42:50 --> Helper loaded: cookie_helper
INFO - 2023-05-07 11:42:50 --> Database Driver Class Initialized
INFO - 2023-05-07 11:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 11:42:50 --> Parser Class Initialized
INFO - 2023-05-07 11:42:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 11:42:50 --> Pagination Class Initialized
INFO - 2023-05-07 11:42:50 --> Form Validation Class Initialized
INFO - 2023-05-07 11:42:50 --> Controller Class Initialized
INFO - 2023-05-07 11:42:50 --> Model Class Initialized
DEBUG - 2023-05-07 11:42:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 11:42:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 11:42:50 --> Model Class Initialized
DEBUG - 2023-05-07 11:42:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 11:42:50 --> Model Class Initialized
INFO - 2023-05-07 11:42:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-05-07 11:42:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 11:42:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 11:42:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 11:42:50 --> Model Class Initialized
INFO - 2023-05-07 11:42:50 --> Model Class Initialized
INFO - 2023-05-07 11:42:50 --> Model Class Initialized
INFO - 2023-05-07 11:42:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 11:42:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 11:42:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 11:42:50 --> Final output sent to browser
DEBUG - 2023-05-07 11:42:50 --> Total execution time: 0.0804
ERROR - 2023-05-07 11:42:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 11:42:52 --> Config Class Initialized
INFO - 2023-05-07 11:42:52 --> Hooks Class Initialized
DEBUG - 2023-05-07 11:42:52 --> UTF-8 Support Enabled
INFO - 2023-05-07 11:42:52 --> Utf8 Class Initialized
INFO - 2023-05-07 11:42:52 --> URI Class Initialized
INFO - 2023-05-07 11:42:52 --> Router Class Initialized
INFO - 2023-05-07 11:42:52 --> Output Class Initialized
INFO - 2023-05-07 11:42:52 --> Security Class Initialized
DEBUG - 2023-05-07 11:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 11:42:52 --> Input Class Initialized
INFO - 2023-05-07 11:42:52 --> Language Class Initialized
INFO - 2023-05-07 11:42:52 --> Loader Class Initialized
INFO - 2023-05-07 11:42:52 --> Helper loaded: url_helper
INFO - 2023-05-07 11:42:52 --> Helper loaded: file_helper
INFO - 2023-05-07 11:42:52 --> Helper loaded: html_helper
INFO - 2023-05-07 11:42:52 --> Helper loaded: text_helper
INFO - 2023-05-07 11:42:52 --> Helper loaded: form_helper
INFO - 2023-05-07 11:42:52 --> Helper loaded: lang_helper
INFO - 2023-05-07 11:42:52 --> Helper loaded: security_helper
INFO - 2023-05-07 11:42:52 --> Helper loaded: cookie_helper
INFO - 2023-05-07 11:42:52 --> Database Driver Class Initialized
INFO - 2023-05-07 11:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 11:42:52 --> Parser Class Initialized
INFO - 2023-05-07 11:42:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 11:42:52 --> Pagination Class Initialized
INFO - 2023-05-07 11:42:52 --> Form Validation Class Initialized
INFO - 2023-05-07 11:42:52 --> Controller Class Initialized
INFO - 2023-05-07 11:42:52 --> Model Class Initialized
DEBUG - 2023-05-07 11:42:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 11:42:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 11:42:52 --> Model Class Initialized
DEBUG - 2023-05-07 11:42:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 11:42:52 --> Model Class Initialized
INFO - 2023-05-07 11:42:52 --> Final output sent to browser
DEBUG - 2023-05-07 11:42:52 --> Total execution time: 0.0379
ERROR - 2023-05-07 11:42:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 11:42:53 --> Config Class Initialized
INFO - 2023-05-07 11:42:53 --> Hooks Class Initialized
DEBUG - 2023-05-07 11:42:53 --> UTF-8 Support Enabled
INFO - 2023-05-07 11:42:53 --> Utf8 Class Initialized
INFO - 2023-05-07 11:42:53 --> URI Class Initialized
DEBUG - 2023-05-07 11:42:53 --> No URI present. Default controller set.
INFO - 2023-05-07 11:42:53 --> Router Class Initialized
INFO - 2023-05-07 11:42:53 --> Output Class Initialized
INFO - 2023-05-07 11:42:53 --> Security Class Initialized
DEBUG - 2023-05-07 11:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 11:42:53 --> Input Class Initialized
INFO - 2023-05-07 11:42:53 --> Language Class Initialized
INFO - 2023-05-07 11:42:53 --> Loader Class Initialized
INFO - 2023-05-07 11:42:53 --> Helper loaded: url_helper
INFO - 2023-05-07 11:42:53 --> Helper loaded: file_helper
INFO - 2023-05-07 11:42:53 --> Helper loaded: html_helper
INFO - 2023-05-07 11:42:53 --> Helper loaded: text_helper
INFO - 2023-05-07 11:42:53 --> Helper loaded: form_helper
INFO - 2023-05-07 11:42:53 --> Helper loaded: lang_helper
INFO - 2023-05-07 11:42:53 --> Helper loaded: security_helper
INFO - 2023-05-07 11:42:53 --> Helper loaded: cookie_helper
INFO - 2023-05-07 11:42:53 --> Database Driver Class Initialized
INFO - 2023-05-07 11:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 11:42:53 --> Parser Class Initialized
INFO - 2023-05-07 11:42:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 11:42:53 --> Pagination Class Initialized
INFO - 2023-05-07 11:42:53 --> Form Validation Class Initialized
INFO - 2023-05-07 11:42:53 --> Controller Class Initialized
INFO - 2023-05-07 11:42:53 --> Model Class Initialized
DEBUG - 2023-05-07 11:42:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 11:42:53 --> Model Class Initialized
DEBUG - 2023-05-07 11:42:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 11:42:53 --> Model Class Initialized
INFO - 2023-05-07 11:42:53 --> Model Class Initialized
INFO - 2023-05-07 11:42:53 --> Model Class Initialized
INFO - 2023-05-07 11:42:53 --> Model Class Initialized
DEBUG - 2023-05-07 11:42:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 11:42:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 11:42:53 --> Model Class Initialized
INFO - 2023-05-07 11:42:53 --> Model Class Initialized
INFO - 2023-05-07 11:42:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-07 11:42:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 11:42:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 11:42:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 11:42:54 --> Model Class Initialized
INFO - 2023-05-07 11:42:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 11:42:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 11:42:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 11:42:54 --> Final output sent to browser
DEBUG - 2023-05-07 11:42:54 --> Total execution time: 0.0771
ERROR - 2023-05-07 11:42:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 11:42:55 --> Config Class Initialized
INFO - 2023-05-07 11:42:55 --> Hooks Class Initialized
DEBUG - 2023-05-07 11:42:55 --> UTF-8 Support Enabled
INFO - 2023-05-07 11:42:55 --> Utf8 Class Initialized
INFO - 2023-05-07 11:42:55 --> URI Class Initialized
INFO - 2023-05-07 11:42:55 --> Router Class Initialized
INFO - 2023-05-07 11:42:55 --> Output Class Initialized
INFO - 2023-05-07 11:42:55 --> Security Class Initialized
DEBUG - 2023-05-07 11:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 11:42:55 --> Input Class Initialized
INFO - 2023-05-07 11:42:55 --> Language Class Initialized
INFO - 2023-05-07 11:42:55 --> Loader Class Initialized
INFO - 2023-05-07 11:42:55 --> Helper loaded: url_helper
INFO - 2023-05-07 11:42:55 --> Helper loaded: file_helper
INFO - 2023-05-07 11:42:55 --> Helper loaded: html_helper
INFO - 2023-05-07 11:42:55 --> Helper loaded: text_helper
INFO - 2023-05-07 11:42:55 --> Helper loaded: form_helper
INFO - 2023-05-07 11:42:55 --> Helper loaded: lang_helper
INFO - 2023-05-07 11:42:55 --> Helper loaded: security_helper
INFO - 2023-05-07 11:42:55 --> Helper loaded: cookie_helper
INFO - 2023-05-07 11:42:55 --> Database Driver Class Initialized
INFO - 2023-05-07 11:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 11:42:55 --> Parser Class Initialized
INFO - 2023-05-07 11:42:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 11:42:55 --> Pagination Class Initialized
INFO - 2023-05-07 11:42:55 --> Form Validation Class Initialized
INFO - 2023-05-07 11:42:55 --> Controller Class Initialized
INFO - 2023-05-07 11:42:55 --> Model Class Initialized
DEBUG - 2023-05-07 11:42:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 11:42:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-07 11:42:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 11:42:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 11:42:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 11:42:55 --> Model Class Initialized
INFO - 2023-05-07 11:42:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 11:42:55 --> Final output sent to browser
DEBUG - 2023-05-07 11:42:55 --> Total execution time: 0.0294
ERROR - 2023-05-07 11:42:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 11:42:55 --> Config Class Initialized
INFO - 2023-05-07 11:42:55 --> Hooks Class Initialized
DEBUG - 2023-05-07 11:42:55 --> UTF-8 Support Enabled
INFO - 2023-05-07 11:42:55 --> Utf8 Class Initialized
INFO - 2023-05-07 11:42:55 --> URI Class Initialized
INFO - 2023-05-07 11:42:55 --> Router Class Initialized
INFO - 2023-05-07 11:42:55 --> Output Class Initialized
INFO - 2023-05-07 11:42:55 --> Security Class Initialized
DEBUG - 2023-05-07 11:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 11:42:55 --> Input Class Initialized
INFO - 2023-05-07 11:42:55 --> Language Class Initialized
INFO - 2023-05-07 11:42:55 --> Loader Class Initialized
INFO - 2023-05-07 11:42:55 --> Helper loaded: url_helper
INFO - 2023-05-07 11:42:55 --> Helper loaded: file_helper
INFO - 2023-05-07 11:42:55 --> Helper loaded: html_helper
INFO - 2023-05-07 11:42:55 --> Helper loaded: text_helper
INFO - 2023-05-07 11:42:55 --> Helper loaded: form_helper
INFO - 2023-05-07 11:42:55 --> Helper loaded: lang_helper
INFO - 2023-05-07 11:42:55 --> Helper loaded: security_helper
INFO - 2023-05-07 11:42:55 --> Helper loaded: cookie_helper
INFO - 2023-05-07 11:42:55 --> Database Driver Class Initialized
INFO - 2023-05-07 11:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 11:42:55 --> Parser Class Initialized
INFO - 2023-05-07 11:42:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 11:42:55 --> Pagination Class Initialized
INFO - 2023-05-07 11:42:55 --> Form Validation Class Initialized
INFO - 2023-05-07 11:42:55 --> Controller Class Initialized
INFO - 2023-05-07 11:42:55 --> Model Class Initialized
DEBUG - 2023-05-07 11:42:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 11:42:55 --> Model Class Initialized
DEBUG - 2023-05-07 11:42:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 11:42:55 --> Model Class Initialized
INFO - 2023-05-07 11:42:55 --> Model Class Initialized
INFO - 2023-05-07 11:42:55 --> Model Class Initialized
INFO - 2023-05-07 11:42:55 --> Model Class Initialized
DEBUG - 2023-05-07 11:42:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 11:42:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 11:42:55 --> Model Class Initialized
INFO - 2023-05-07 11:42:55 --> Model Class Initialized
INFO - 2023-05-07 11:42:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-07 11:42:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 11:42:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 11:42:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 11:42:55 --> Model Class Initialized
INFO - 2023-05-07 11:42:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 11:42:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 11:42:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 11:42:55 --> Final output sent to browser
DEBUG - 2023-05-07 11:42:55 --> Total execution time: 0.0714
ERROR - 2023-05-07 11:42:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 11:42:56 --> Config Class Initialized
INFO - 2023-05-07 11:42:56 --> Hooks Class Initialized
DEBUG - 2023-05-07 11:42:56 --> UTF-8 Support Enabled
INFO - 2023-05-07 11:42:56 --> Utf8 Class Initialized
INFO - 2023-05-07 11:42:56 --> URI Class Initialized
INFO - 2023-05-07 11:42:56 --> Router Class Initialized
INFO - 2023-05-07 11:42:56 --> Output Class Initialized
INFO - 2023-05-07 11:42:56 --> Security Class Initialized
DEBUG - 2023-05-07 11:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 11:42:56 --> Input Class Initialized
INFO - 2023-05-07 11:42:56 --> Language Class Initialized
INFO - 2023-05-07 11:42:56 --> Loader Class Initialized
INFO - 2023-05-07 11:42:56 --> Helper loaded: url_helper
INFO - 2023-05-07 11:42:56 --> Helper loaded: file_helper
INFO - 2023-05-07 11:42:56 --> Helper loaded: html_helper
INFO - 2023-05-07 11:42:56 --> Helper loaded: text_helper
INFO - 2023-05-07 11:42:56 --> Helper loaded: form_helper
INFO - 2023-05-07 11:42:56 --> Helper loaded: lang_helper
INFO - 2023-05-07 11:42:56 --> Helper loaded: security_helper
INFO - 2023-05-07 11:42:56 --> Helper loaded: cookie_helper
INFO - 2023-05-07 11:42:56 --> Database Driver Class Initialized
INFO - 2023-05-07 11:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 11:42:56 --> Parser Class Initialized
INFO - 2023-05-07 11:42:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 11:42:56 --> Pagination Class Initialized
INFO - 2023-05-07 11:42:56 --> Form Validation Class Initialized
INFO - 2023-05-07 11:42:56 --> Controller Class Initialized
INFO - 2023-05-07 11:42:56 --> Model Class Initialized
DEBUG - 2023-05-07 11:42:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 11:42:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-07 11:42:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 11:42:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 11:42:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 11:42:56 --> Model Class Initialized
INFO - 2023-05-07 11:42:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 11:42:56 --> Final output sent to browser
DEBUG - 2023-05-07 11:42:56 --> Total execution time: 0.0306
ERROR - 2023-05-07 11:42:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 11:42:56 --> Config Class Initialized
INFO - 2023-05-07 11:42:56 --> Hooks Class Initialized
DEBUG - 2023-05-07 11:42:56 --> UTF-8 Support Enabled
INFO - 2023-05-07 11:42:56 --> Utf8 Class Initialized
INFO - 2023-05-07 11:42:56 --> URI Class Initialized
INFO - 2023-05-07 11:42:56 --> Router Class Initialized
INFO - 2023-05-07 11:42:56 --> Output Class Initialized
INFO - 2023-05-07 11:42:56 --> Security Class Initialized
DEBUG - 2023-05-07 11:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 11:42:56 --> Input Class Initialized
INFO - 2023-05-07 11:42:56 --> Language Class Initialized
INFO - 2023-05-07 11:42:56 --> Loader Class Initialized
INFO - 2023-05-07 11:42:56 --> Helper loaded: url_helper
INFO - 2023-05-07 11:42:56 --> Helper loaded: file_helper
INFO - 2023-05-07 11:42:56 --> Helper loaded: html_helper
INFO - 2023-05-07 11:42:56 --> Helper loaded: text_helper
INFO - 2023-05-07 11:42:56 --> Helper loaded: form_helper
INFO - 2023-05-07 11:42:56 --> Helper loaded: lang_helper
INFO - 2023-05-07 11:42:56 --> Helper loaded: security_helper
INFO - 2023-05-07 11:42:56 --> Helper loaded: cookie_helper
INFO - 2023-05-07 11:42:56 --> Database Driver Class Initialized
INFO - 2023-05-07 11:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 11:42:56 --> Parser Class Initialized
INFO - 2023-05-07 11:42:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 11:42:56 --> Pagination Class Initialized
INFO - 2023-05-07 11:42:56 --> Form Validation Class Initialized
INFO - 2023-05-07 11:42:56 --> Controller Class Initialized
INFO - 2023-05-07 11:42:56 --> Model Class Initialized
DEBUG - 2023-05-07 11:42:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 11:42:56 --> Model Class Initialized
DEBUG - 2023-05-07 11:42:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 11:42:56 --> Model Class Initialized
INFO - 2023-05-07 11:42:56 --> Model Class Initialized
INFO - 2023-05-07 11:42:56 --> Model Class Initialized
INFO - 2023-05-07 11:42:56 --> Model Class Initialized
DEBUG - 2023-05-07 11:42:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 11:42:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 11:42:56 --> Model Class Initialized
INFO - 2023-05-07 11:42:56 --> Model Class Initialized
INFO - 2023-05-07 11:42:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-07 11:42:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 11:42:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 11:42:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 11:42:56 --> Model Class Initialized
INFO - 2023-05-07 11:42:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 11:42:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 11:42:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 11:42:56 --> Final output sent to browser
DEBUG - 2023-05-07 11:42:56 --> Total execution time: 0.0672
ERROR - 2023-05-07 18:12:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:12:59 --> Config Class Initialized
INFO - 2023-05-07 18:12:59 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:12:59 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:12:59 --> Utf8 Class Initialized
INFO - 2023-05-07 18:12:59 --> URI Class Initialized
DEBUG - 2023-05-07 18:12:59 --> No URI present. Default controller set.
INFO - 2023-05-07 18:12:59 --> Router Class Initialized
INFO - 2023-05-07 18:12:59 --> Output Class Initialized
INFO - 2023-05-07 18:12:59 --> Security Class Initialized
DEBUG - 2023-05-07 18:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:12:59 --> Input Class Initialized
INFO - 2023-05-07 18:12:59 --> Language Class Initialized
INFO - 2023-05-07 18:12:59 --> Loader Class Initialized
INFO - 2023-05-07 18:12:59 --> Helper loaded: url_helper
INFO - 2023-05-07 18:12:59 --> Helper loaded: file_helper
INFO - 2023-05-07 18:12:59 --> Helper loaded: html_helper
INFO - 2023-05-07 18:12:59 --> Helper loaded: text_helper
INFO - 2023-05-07 18:12:59 --> Helper loaded: form_helper
INFO - 2023-05-07 18:12:59 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:12:59 --> Helper loaded: security_helper
INFO - 2023-05-07 18:12:59 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:12:59 --> Database Driver Class Initialized
INFO - 2023-05-07 18:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:12:59 --> Parser Class Initialized
INFO - 2023-05-07 18:12:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:12:59 --> Pagination Class Initialized
INFO - 2023-05-07 18:12:59 --> Form Validation Class Initialized
INFO - 2023-05-07 18:12:59 --> Controller Class Initialized
INFO - 2023-05-07 18:12:59 --> Model Class Initialized
DEBUG - 2023-05-07 18:12:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-07 18:13:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:13:00 --> Config Class Initialized
INFO - 2023-05-07 18:13:00 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:13:00 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:13:00 --> Utf8 Class Initialized
INFO - 2023-05-07 18:13:00 --> URI Class Initialized
INFO - 2023-05-07 18:13:00 --> Router Class Initialized
INFO - 2023-05-07 18:13:00 --> Output Class Initialized
INFO - 2023-05-07 18:13:00 --> Security Class Initialized
DEBUG - 2023-05-07 18:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:13:00 --> Input Class Initialized
INFO - 2023-05-07 18:13:00 --> Language Class Initialized
INFO - 2023-05-07 18:13:00 --> Loader Class Initialized
INFO - 2023-05-07 18:13:00 --> Helper loaded: url_helper
INFO - 2023-05-07 18:13:00 --> Helper loaded: file_helper
INFO - 2023-05-07 18:13:00 --> Helper loaded: html_helper
INFO - 2023-05-07 18:13:00 --> Helper loaded: text_helper
INFO - 2023-05-07 18:13:00 --> Helper loaded: form_helper
INFO - 2023-05-07 18:13:00 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:13:00 --> Helper loaded: security_helper
INFO - 2023-05-07 18:13:00 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:13:00 --> Database Driver Class Initialized
INFO - 2023-05-07 18:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:13:00 --> Parser Class Initialized
INFO - 2023-05-07 18:13:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:13:00 --> Pagination Class Initialized
INFO - 2023-05-07 18:13:00 --> Form Validation Class Initialized
INFO - 2023-05-07 18:13:00 --> Controller Class Initialized
INFO - 2023-05-07 18:13:00 --> Model Class Initialized
DEBUG - 2023-05-07 18:13:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:13:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-07 18:13:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:13:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:13:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:13:00 --> Model Class Initialized
INFO - 2023-05-07 18:13:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:13:00 --> Final output sent to browser
DEBUG - 2023-05-07 18:13:00 --> Total execution time: 0.0340
ERROR - 2023-05-07 18:13:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:13:15 --> Config Class Initialized
INFO - 2023-05-07 18:13:15 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:13:15 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:13:15 --> Utf8 Class Initialized
INFO - 2023-05-07 18:13:15 --> URI Class Initialized
INFO - 2023-05-07 18:13:15 --> Router Class Initialized
INFO - 2023-05-07 18:13:15 --> Output Class Initialized
INFO - 2023-05-07 18:13:15 --> Security Class Initialized
DEBUG - 2023-05-07 18:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:13:15 --> Input Class Initialized
INFO - 2023-05-07 18:13:15 --> Language Class Initialized
INFO - 2023-05-07 18:13:15 --> Loader Class Initialized
INFO - 2023-05-07 18:13:15 --> Helper loaded: url_helper
INFO - 2023-05-07 18:13:15 --> Helper loaded: file_helper
INFO - 2023-05-07 18:13:15 --> Helper loaded: html_helper
INFO - 2023-05-07 18:13:15 --> Helper loaded: text_helper
INFO - 2023-05-07 18:13:15 --> Helper loaded: form_helper
INFO - 2023-05-07 18:13:15 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:13:15 --> Helper loaded: security_helper
INFO - 2023-05-07 18:13:15 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:13:15 --> Database Driver Class Initialized
INFO - 2023-05-07 18:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:13:15 --> Parser Class Initialized
INFO - 2023-05-07 18:13:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:13:15 --> Pagination Class Initialized
INFO - 2023-05-07 18:13:15 --> Form Validation Class Initialized
INFO - 2023-05-07 18:13:15 --> Controller Class Initialized
INFO - 2023-05-07 18:13:15 --> Model Class Initialized
DEBUG - 2023-05-07 18:13:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:13:15 --> Model Class Initialized
INFO - 2023-05-07 18:13:15 --> Final output sent to browser
DEBUG - 2023-05-07 18:13:15 --> Total execution time: 0.0204
ERROR - 2023-05-07 18:13:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:13:16 --> Config Class Initialized
INFO - 2023-05-07 18:13:16 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:13:16 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:13:16 --> Utf8 Class Initialized
INFO - 2023-05-07 18:13:16 --> URI Class Initialized
DEBUG - 2023-05-07 18:13:16 --> No URI present. Default controller set.
INFO - 2023-05-07 18:13:16 --> Router Class Initialized
INFO - 2023-05-07 18:13:16 --> Output Class Initialized
INFO - 2023-05-07 18:13:16 --> Security Class Initialized
DEBUG - 2023-05-07 18:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:13:16 --> Input Class Initialized
INFO - 2023-05-07 18:13:16 --> Language Class Initialized
INFO - 2023-05-07 18:13:16 --> Loader Class Initialized
INFO - 2023-05-07 18:13:16 --> Helper loaded: url_helper
INFO - 2023-05-07 18:13:16 --> Helper loaded: file_helper
INFO - 2023-05-07 18:13:16 --> Helper loaded: html_helper
INFO - 2023-05-07 18:13:16 --> Helper loaded: text_helper
INFO - 2023-05-07 18:13:16 --> Helper loaded: form_helper
INFO - 2023-05-07 18:13:16 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:13:16 --> Helper loaded: security_helper
INFO - 2023-05-07 18:13:16 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:13:16 --> Database Driver Class Initialized
INFO - 2023-05-07 18:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:13:16 --> Parser Class Initialized
INFO - 2023-05-07 18:13:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:13:16 --> Pagination Class Initialized
INFO - 2023-05-07 18:13:16 --> Form Validation Class Initialized
INFO - 2023-05-07 18:13:16 --> Controller Class Initialized
INFO - 2023-05-07 18:13:16 --> Model Class Initialized
DEBUG - 2023-05-07 18:13:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:13:16 --> Model Class Initialized
DEBUG - 2023-05-07 18:13:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:13:16 --> Model Class Initialized
INFO - 2023-05-07 18:13:16 --> Model Class Initialized
INFO - 2023-05-07 18:13:16 --> Model Class Initialized
INFO - 2023-05-07 18:13:16 --> Model Class Initialized
DEBUG - 2023-05-07 18:13:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:13:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:13:16 --> Model Class Initialized
INFO - 2023-05-07 18:13:16 --> Model Class Initialized
INFO - 2023-05-07 18:13:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-07 18:13:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:13:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:13:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:13:16 --> Model Class Initialized
INFO - 2023-05-07 18:13:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:13:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:13:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:13:16 --> Final output sent to browser
DEBUG - 2023-05-07 18:13:16 --> Total execution time: 0.1772
ERROR - 2023-05-07 18:13:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:13:17 --> Config Class Initialized
INFO - 2023-05-07 18:13:17 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:13:17 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:13:17 --> Utf8 Class Initialized
INFO - 2023-05-07 18:13:17 --> URI Class Initialized
INFO - 2023-05-07 18:13:17 --> Router Class Initialized
INFO - 2023-05-07 18:13:17 --> Output Class Initialized
INFO - 2023-05-07 18:13:17 --> Security Class Initialized
DEBUG - 2023-05-07 18:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:13:17 --> Input Class Initialized
INFO - 2023-05-07 18:13:17 --> Language Class Initialized
INFO - 2023-05-07 18:13:17 --> Loader Class Initialized
INFO - 2023-05-07 18:13:17 --> Helper loaded: url_helper
INFO - 2023-05-07 18:13:17 --> Helper loaded: file_helper
INFO - 2023-05-07 18:13:17 --> Helper loaded: html_helper
INFO - 2023-05-07 18:13:17 --> Helper loaded: text_helper
INFO - 2023-05-07 18:13:17 --> Helper loaded: form_helper
INFO - 2023-05-07 18:13:17 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:13:17 --> Helper loaded: security_helper
INFO - 2023-05-07 18:13:17 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:13:17 --> Database Driver Class Initialized
INFO - 2023-05-07 18:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:13:17 --> Parser Class Initialized
INFO - 2023-05-07 18:13:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:13:17 --> Pagination Class Initialized
INFO - 2023-05-07 18:13:17 --> Form Validation Class Initialized
INFO - 2023-05-07 18:13:17 --> Controller Class Initialized
DEBUG - 2023-05-07 18:13:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:13:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:13:17 --> Model Class Initialized
INFO - 2023-05-07 18:13:17 --> Final output sent to browser
DEBUG - 2023-05-07 18:13:17 --> Total execution time: 0.0133
ERROR - 2023-05-07 18:13:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:13:27 --> Config Class Initialized
INFO - 2023-05-07 18:13:27 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:13:27 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:13:27 --> Utf8 Class Initialized
INFO - 2023-05-07 18:13:27 --> URI Class Initialized
INFO - 2023-05-07 18:13:27 --> Router Class Initialized
INFO - 2023-05-07 18:13:27 --> Output Class Initialized
INFO - 2023-05-07 18:13:27 --> Security Class Initialized
DEBUG - 2023-05-07 18:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:13:27 --> Input Class Initialized
INFO - 2023-05-07 18:13:27 --> Language Class Initialized
INFO - 2023-05-07 18:13:27 --> Loader Class Initialized
INFO - 2023-05-07 18:13:27 --> Helper loaded: url_helper
INFO - 2023-05-07 18:13:27 --> Helper loaded: file_helper
INFO - 2023-05-07 18:13:27 --> Helper loaded: html_helper
INFO - 2023-05-07 18:13:27 --> Helper loaded: text_helper
INFO - 2023-05-07 18:13:27 --> Helper loaded: form_helper
INFO - 2023-05-07 18:13:27 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:13:27 --> Helper loaded: security_helper
INFO - 2023-05-07 18:13:27 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:13:27 --> Database Driver Class Initialized
INFO - 2023-05-07 18:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:13:27 --> Parser Class Initialized
INFO - 2023-05-07 18:13:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:13:27 --> Pagination Class Initialized
INFO - 2023-05-07 18:13:27 --> Form Validation Class Initialized
INFO - 2023-05-07 18:13:27 --> Controller Class Initialized
INFO - 2023-05-07 18:13:27 --> Model Class Initialized
DEBUG - 2023-05-07 18:13:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:13:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:13:27 --> Model Class Initialized
DEBUG - 2023-05-07 18:13:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:13:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/add_stockrequest_form.php
DEBUG - 2023-05-07 18:13:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:13:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:13:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:13:27 --> Model Class Initialized
INFO - 2023-05-07 18:13:27 --> Model Class Initialized
INFO - 2023-05-07 18:13:27 --> Model Class Initialized
INFO - 2023-05-07 18:13:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:13:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:13:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:13:27 --> Final output sent to browser
DEBUG - 2023-05-07 18:13:27 --> Total execution time: 0.1478
ERROR - 2023-05-07 18:13:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:13:33 --> Config Class Initialized
INFO - 2023-05-07 18:13:33 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:13:33 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:13:33 --> Utf8 Class Initialized
INFO - 2023-05-07 18:13:33 --> URI Class Initialized
INFO - 2023-05-07 18:13:33 --> Router Class Initialized
INFO - 2023-05-07 18:13:33 --> Output Class Initialized
INFO - 2023-05-07 18:13:33 --> Security Class Initialized
DEBUG - 2023-05-07 18:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:13:33 --> Input Class Initialized
INFO - 2023-05-07 18:13:33 --> Language Class Initialized
INFO - 2023-05-07 18:13:33 --> Loader Class Initialized
INFO - 2023-05-07 18:13:33 --> Helper loaded: url_helper
INFO - 2023-05-07 18:13:33 --> Helper loaded: file_helper
INFO - 2023-05-07 18:13:33 --> Helper loaded: html_helper
INFO - 2023-05-07 18:13:33 --> Helper loaded: text_helper
INFO - 2023-05-07 18:13:33 --> Helper loaded: form_helper
INFO - 2023-05-07 18:13:33 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:13:33 --> Helper loaded: security_helper
INFO - 2023-05-07 18:13:33 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:13:33 --> Database Driver Class Initialized
INFO - 2023-05-07 18:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:13:33 --> Parser Class Initialized
INFO - 2023-05-07 18:13:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:13:33 --> Pagination Class Initialized
INFO - 2023-05-07 18:13:33 --> Form Validation Class Initialized
INFO - 2023-05-07 18:13:33 --> Controller Class Initialized
INFO - 2023-05-07 18:13:33 --> Model Class Initialized
INFO - 2023-05-07 18:13:33 --> Final output sent to browser
DEBUG - 2023-05-07 18:13:33 --> Total execution time: 0.0142
ERROR - 2023-05-07 18:13:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:13:34 --> Config Class Initialized
INFO - 2023-05-07 18:13:34 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:13:34 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:13:34 --> Utf8 Class Initialized
INFO - 2023-05-07 18:13:34 --> URI Class Initialized
INFO - 2023-05-07 18:13:34 --> Router Class Initialized
INFO - 2023-05-07 18:13:34 --> Output Class Initialized
INFO - 2023-05-07 18:13:34 --> Security Class Initialized
DEBUG - 2023-05-07 18:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:13:34 --> Input Class Initialized
INFO - 2023-05-07 18:13:34 --> Language Class Initialized
INFO - 2023-05-07 18:13:34 --> Loader Class Initialized
INFO - 2023-05-07 18:13:34 --> Helper loaded: url_helper
INFO - 2023-05-07 18:13:34 --> Helper loaded: file_helper
INFO - 2023-05-07 18:13:34 --> Helper loaded: html_helper
INFO - 2023-05-07 18:13:34 --> Helper loaded: text_helper
INFO - 2023-05-07 18:13:34 --> Helper loaded: form_helper
INFO - 2023-05-07 18:13:34 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:13:34 --> Helper loaded: security_helper
INFO - 2023-05-07 18:13:34 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:13:34 --> Database Driver Class Initialized
INFO - 2023-05-07 18:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:13:34 --> Parser Class Initialized
INFO - 2023-05-07 18:13:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:13:34 --> Pagination Class Initialized
INFO - 2023-05-07 18:13:34 --> Form Validation Class Initialized
INFO - 2023-05-07 18:13:34 --> Controller Class Initialized
INFO - 2023-05-07 18:13:34 --> Model Class Initialized
INFO - 2023-05-07 18:13:34 --> Final output sent to browser
DEBUG - 2023-05-07 18:13:34 --> Total execution time: 0.0169
ERROR - 2023-05-07 18:13:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:13:34 --> Config Class Initialized
INFO - 2023-05-07 18:13:34 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:13:34 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:13:34 --> Utf8 Class Initialized
INFO - 2023-05-07 18:13:34 --> URI Class Initialized
INFO - 2023-05-07 18:13:34 --> Router Class Initialized
INFO - 2023-05-07 18:13:34 --> Output Class Initialized
INFO - 2023-05-07 18:13:34 --> Security Class Initialized
DEBUG - 2023-05-07 18:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:13:34 --> Input Class Initialized
INFO - 2023-05-07 18:13:34 --> Language Class Initialized
INFO - 2023-05-07 18:13:34 --> Loader Class Initialized
INFO - 2023-05-07 18:13:34 --> Helper loaded: url_helper
INFO - 2023-05-07 18:13:34 --> Helper loaded: file_helper
INFO - 2023-05-07 18:13:34 --> Helper loaded: html_helper
INFO - 2023-05-07 18:13:34 --> Helper loaded: text_helper
INFO - 2023-05-07 18:13:34 --> Helper loaded: form_helper
INFO - 2023-05-07 18:13:34 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:13:34 --> Helper loaded: security_helper
INFO - 2023-05-07 18:13:34 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:13:34 --> Database Driver Class Initialized
INFO - 2023-05-07 18:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:13:34 --> Parser Class Initialized
INFO - 2023-05-07 18:13:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:13:34 --> Pagination Class Initialized
INFO - 2023-05-07 18:13:34 --> Form Validation Class Initialized
INFO - 2023-05-07 18:13:34 --> Controller Class Initialized
INFO - 2023-05-07 18:13:34 --> Model Class Initialized
INFO - 2023-05-07 18:13:34 --> Final output sent to browser
DEBUG - 2023-05-07 18:13:34 --> Total execution time: 0.0128
ERROR - 2023-05-07 18:13:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:13:34 --> Config Class Initialized
INFO - 2023-05-07 18:13:34 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:13:34 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:13:34 --> Utf8 Class Initialized
INFO - 2023-05-07 18:13:34 --> URI Class Initialized
INFO - 2023-05-07 18:13:34 --> Router Class Initialized
INFO - 2023-05-07 18:13:34 --> Output Class Initialized
INFO - 2023-05-07 18:13:34 --> Security Class Initialized
DEBUG - 2023-05-07 18:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:13:34 --> Input Class Initialized
INFO - 2023-05-07 18:13:34 --> Language Class Initialized
INFO - 2023-05-07 18:13:34 --> Loader Class Initialized
INFO - 2023-05-07 18:13:34 --> Helper loaded: url_helper
INFO - 2023-05-07 18:13:34 --> Helper loaded: file_helper
INFO - 2023-05-07 18:13:34 --> Helper loaded: html_helper
INFO - 2023-05-07 18:13:34 --> Helper loaded: text_helper
INFO - 2023-05-07 18:13:34 --> Helper loaded: form_helper
INFO - 2023-05-07 18:13:34 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:13:34 --> Helper loaded: security_helper
INFO - 2023-05-07 18:13:34 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:13:34 --> Database Driver Class Initialized
INFO - 2023-05-07 18:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:13:34 --> Parser Class Initialized
INFO - 2023-05-07 18:13:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:13:34 --> Pagination Class Initialized
INFO - 2023-05-07 18:13:34 --> Form Validation Class Initialized
INFO - 2023-05-07 18:13:34 --> Controller Class Initialized
INFO - 2023-05-07 18:13:34 --> Model Class Initialized
INFO - 2023-05-07 18:13:34 --> Final output sent to browser
DEBUG - 2023-05-07 18:13:34 --> Total execution time: 0.0127
ERROR - 2023-05-07 18:13:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:13:35 --> Config Class Initialized
INFO - 2023-05-07 18:13:35 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:13:35 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:13:35 --> Utf8 Class Initialized
INFO - 2023-05-07 18:13:35 --> URI Class Initialized
INFO - 2023-05-07 18:13:35 --> Router Class Initialized
INFO - 2023-05-07 18:13:35 --> Output Class Initialized
INFO - 2023-05-07 18:13:35 --> Security Class Initialized
DEBUG - 2023-05-07 18:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:13:35 --> Input Class Initialized
INFO - 2023-05-07 18:13:35 --> Language Class Initialized
INFO - 2023-05-07 18:13:35 --> Loader Class Initialized
INFO - 2023-05-07 18:13:35 --> Helper loaded: url_helper
INFO - 2023-05-07 18:13:35 --> Helper loaded: file_helper
INFO - 2023-05-07 18:13:35 --> Helper loaded: html_helper
INFO - 2023-05-07 18:13:35 --> Helper loaded: text_helper
INFO - 2023-05-07 18:13:35 --> Helper loaded: form_helper
INFO - 2023-05-07 18:13:35 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:13:35 --> Helper loaded: security_helper
INFO - 2023-05-07 18:13:35 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:13:35 --> Database Driver Class Initialized
INFO - 2023-05-07 18:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:13:35 --> Parser Class Initialized
INFO - 2023-05-07 18:13:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:13:35 --> Pagination Class Initialized
INFO - 2023-05-07 18:13:35 --> Form Validation Class Initialized
INFO - 2023-05-07 18:13:35 --> Controller Class Initialized
INFO - 2023-05-07 18:13:35 --> Model Class Initialized
INFO - 2023-05-07 18:13:35 --> Final output sent to browser
DEBUG - 2023-05-07 18:13:35 --> Total execution time: 0.0133
ERROR - 2023-05-07 18:13:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:13:39 --> Config Class Initialized
INFO - 2023-05-07 18:13:39 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:13:39 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:13:39 --> Utf8 Class Initialized
INFO - 2023-05-07 18:13:39 --> URI Class Initialized
INFO - 2023-05-07 18:13:39 --> Router Class Initialized
INFO - 2023-05-07 18:13:39 --> Output Class Initialized
INFO - 2023-05-07 18:13:39 --> Security Class Initialized
DEBUG - 2023-05-07 18:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:13:39 --> Input Class Initialized
INFO - 2023-05-07 18:13:39 --> Language Class Initialized
INFO - 2023-05-07 18:13:39 --> Loader Class Initialized
INFO - 2023-05-07 18:13:39 --> Helper loaded: url_helper
INFO - 2023-05-07 18:13:39 --> Helper loaded: file_helper
INFO - 2023-05-07 18:13:39 --> Helper loaded: html_helper
INFO - 2023-05-07 18:13:39 --> Helper loaded: text_helper
INFO - 2023-05-07 18:13:39 --> Helper loaded: form_helper
INFO - 2023-05-07 18:13:39 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:13:39 --> Helper loaded: security_helper
INFO - 2023-05-07 18:13:39 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:13:39 --> Database Driver Class Initialized
INFO - 2023-05-07 18:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:13:39 --> Parser Class Initialized
INFO - 2023-05-07 18:13:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:13:39 --> Pagination Class Initialized
INFO - 2023-05-07 18:13:39 --> Form Validation Class Initialized
INFO - 2023-05-07 18:13:39 --> Controller Class Initialized
INFO - 2023-05-07 18:13:39 --> Model Class Initialized
DEBUG - 2023-05-07 18:13:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:13:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:13:39 --> Model Class Initialized
DEBUG - 2023-05-07 18:13:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:13:39 --> Model Class Initialized
INFO - 2023-05-07 18:13:39 --> Final output sent to browser
DEBUG - 2023-05-07 18:13:39 --> Total execution time: 0.0179
ERROR - 2023-05-07 18:13:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:13:39 --> Config Class Initialized
INFO - 2023-05-07 18:13:39 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:13:39 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:13:39 --> Utf8 Class Initialized
INFO - 2023-05-07 18:13:39 --> URI Class Initialized
INFO - 2023-05-07 18:13:39 --> Router Class Initialized
INFO - 2023-05-07 18:13:39 --> Output Class Initialized
INFO - 2023-05-07 18:13:39 --> Security Class Initialized
DEBUG - 2023-05-07 18:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:13:39 --> Input Class Initialized
INFO - 2023-05-07 18:13:39 --> Language Class Initialized
INFO - 2023-05-07 18:13:39 --> Loader Class Initialized
INFO - 2023-05-07 18:13:39 --> Helper loaded: url_helper
INFO - 2023-05-07 18:13:39 --> Helper loaded: file_helper
INFO - 2023-05-07 18:13:39 --> Helper loaded: html_helper
INFO - 2023-05-07 18:13:39 --> Helper loaded: text_helper
INFO - 2023-05-07 18:13:39 --> Helper loaded: form_helper
INFO - 2023-05-07 18:13:39 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:13:39 --> Helper loaded: security_helper
INFO - 2023-05-07 18:13:39 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:13:39 --> Database Driver Class Initialized
INFO - 2023-05-07 18:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:13:39 --> Parser Class Initialized
INFO - 2023-05-07 18:13:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:13:39 --> Pagination Class Initialized
INFO - 2023-05-07 18:13:39 --> Form Validation Class Initialized
INFO - 2023-05-07 18:13:39 --> Controller Class Initialized
INFO - 2023-05-07 18:13:39 --> Model Class Initialized
DEBUG - 2023-05-07 18:13:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:13:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:13:39 --> Model Class Initialized
DEBUG - 2023-05-07 18:13:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:13:39 --> Model Class Initialized
INFO - 2023-05-07 18:13:39 --> Final output sent to browser
DEBUG - 2023-05-07 18:13:39 --> Total execution time: 0.0169
ERROR - 2023-05-07 18:13:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:13:40 --> Config Class Initialized
INFO - 2023-05-07 18:13:40 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:13:40 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:13:40 --> Utf8 Class Initialized
INFO - 2023-05-07 18:13:40 --> URI Class Initialized
INFO - 2023-05-07 18:13:40 --> Router Class Initialized
INFO - 2023-05-07 18:13:40 --> Output Class Initialized
INFO - 2023-05-07 18:13:40 --> Security Class Initialized
DEBUG - 2023-05-07 18:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:13:40 --> Input Class Initialized
INFO - 2023-05-07 18:13:40 --> Language Class Initialized
INFO - 2023-05-07 18:13:40 --> Loader Class Initialized
INFO - 2023-05-07 18:13:40 --> Helper loaded: url_helper
INFO - 2023-05-07 18:13:40 --> Helper loaded: file_helper
INFO - 2023-05-07 18:13:40 --> Helper loaded: html_helper
INFO - 2023-05-07 18:13:40 --> Helper loaded: text_helper
INFO - 2023-05-07 18:13:40 --> Helper loaded: form_helper
INFO - 2023-05-07 18:13:40 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:13:40 --> Helper loaded: security_helper
INFO - 2023-05-07 18:13:40 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:13:40 --> Database Driver Class Initialized
INFO - 2023-05-07 18:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:13:40 --> Parser Class Initialized
INFO - 2023-05-07 18:13:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:13:40 --> Pagination Class Initialized
INFO - 2023-05-07 18:13:40 --> Form Validation Class Initialized
INFO - 2023-05-07 18:13:40 --> Controller Class Initialized
INFO - 2023-05-07 18:13:40 --> Model Class Initialized
DEBUG - 2023-05-07 18:13:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:13:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:13:40 --> Model Class Initialized
DEBUG - 2023-05-07 18:13:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:13:40 --> Model Class Initialized
INFO - 2023-05-07 18:13:40 --> Final output sent to browser
DEBUG - 2023-05-07 18:13:40 --> Total execution time: 0.0175
ERROR - 2023-05-07 18:13:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:13:41 --> Config Class Initialized
INFO - 2023-05-07 18:13:41 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:13:41 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:13:41 --> Utf8 Class Initialized
INFO - 2023-05-07 18:13:41 --> URI Class Initialized
INFO - 2023-05-07 18:13:41 --> Router Class Initialized
INFO - 2023-05-07 18:13:41 --> Output Class Initialized
INFO - 2023-05-07 18:13:41 --> Security Class Initialized
DEBUG - 2023-05-07 18:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:13:41 --> Input Class Initialized
INFO - 2023-05-07 18:13:41 --> Language Class Initialized
INFO - 2023-05-07 18:13:41 --> Loader Class Initialized
INFO - 2023-05-07 18:13:41 --> Helper loaded: url_helper
INFO - 2023-05-07 18:13:41 --> Helper loaded: file_helper
INFO - 2023-05-07 18:13:41 --> Helper loaded: html_helper
INFO - 2023-05-07 18:13:41 --> Helper loaded: text_helper
INFO - 2023-05-07 18:13:41 --> Helper loaded: form_helper
INFO - 2023-05-07 18:13:41 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:13:41 --> Helper loaded: security_helper
INFO - 2023-05-07 18:13:41 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:13:41 --> Database Driver Class Initialized
INFO - 2023-05-07 18:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:13:41 --> Parser Class Initialized
INFO - 2023-05-07 18:13:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:13:41 --> Pagination Class Initialized
INFO - 2023-05-07 18:13:41 --> Form Validation Class Initialized
INFO - 2023-05-07 18:13:41 --> Controller Class Initialized
INFO - 2023-05-07 18:13:41 --> Model Class Initialized
DEBUG - 2023-05-07 18:13:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:13:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:13:41 --> Model Class Initialized
DEBUG - 2023-05-07 18:13:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:13:41 --> Model Class Initialized
INFO - 2023-05-07 18:13:41 --> Final output sent to browser
DEBUG - 2023-05-07 18:13:41 --> Total execution time: 0.0172
ERROR - 2023-05-07 18:13:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:13:43 --> Config Class Initialized
INFO - 2023-05-07 18:13:43 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:13:43 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:13:43 --> Utf8 Class Initialized
INFO - 2023-05-07 18:13:43 --> URI Class Initialized
INFO - 2023-05-07 18:13:43 --> Router Class Initialized
INFO - 2023-05-07 18:13:43 --> Output Class Initialized
INFO - 2023-05-07 18:13:43 --> Security Class Initialized
DEBUG - 2023-05-07 18:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:13:43 --> Input Class Initialized
INFO - 2023-05-07 18:13:43 --> Language Class Initialized
INFO - 2023-05-07 18:13:43 --> Loader Class Initialized
INFO - 2023-05-07 18:13:43 --> Helper loaded: url_helper
INFO - 2023-05-07 18:13:43 --> Helper loaded: file_helper
INFO - 2023-05-07 18:13:43 --> Helper loaded: html_helper
INFO - 2023-05-07 18:13:43 --> Helper loaded: text_helper
INFO - 2023-05-07 18:13:43 --> Helper loaded: form_helper
INFO - 2023-05-07 18:13:43 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:13:43 --> Helper loaded: security_helper
INFO - 2023-05-07 18:13:43 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:13:43 --> Database Driver Class Initialized
INFO - 2023-05-07 18:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:13:43 --> Parser Class Initialized
INFO - 2023-05-07 18:13:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:13:43 --> Pagination Class Initialized
INFO - 2023-05-07 18:13:43 --> Form Validation Class Initialized
INFO - 2023-05-07 18:13:43 --> Controller Class Initialized
INFO - 2023-05-07 18:13:43 --> Model Class Initialized
DEBUG - 2023-05-07 18:13:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:13:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:13:43 --> Model Class Initialized
DEBUG - 2023-05-07 18:13:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:13:43 --> Model Class Initialized
INFO - 2023-05-07 18:13:43 --> Model Class Initialized
INFO - 2023-05-07 18:13:43 --> Final output sent to browser
DEBUG - 2023-05-07 18:13:43 --> Total execution time: 0.0252
ERROR - 2023-05-07 18:13:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:13:45 --> Config Class Initialized
INFO - 2023-05-07 18:13:45 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:13:45 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:13:45 --> Utf8 Class Initialized
INFO - 2023-05-07 18:13:45 --> URI Class Initialized
INFO - 2023-05-07 18:13:45 --> Router Class Initialized
INFO - 2023-05-07 18:13:45 --> Output Class Initialized
INFO - 2023-05-07 18:13:45 --> Security Class Initialized
DEBUG - 2023-05-07 18:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:13:45 --> Input Class Initialized
INFO - 2023-05-07 18:13:45 --> Language Class Initialized
INFO - 2023-05-07 18:13:45 --> Loader Class Initialized
INFO - 2023-05-07 18:13:45 --> Helper loaded: url_helper
INFO - 2023-05-07 18:13:45 --> Helper loaded: file_helper
INFO - 2023-05-07 18:13:45 --> Helper loaded: html_helper
INFO - 2023-05-07 18:13:45 --> Helper loaded: text_helper
INFO - 2023-05-07 18:13:45 --> Helper loaded: form_helper
INFO - 2023-05-07 18:13:45 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:13:45 --> Helper loaded: security_helper
INFO - 2023-05-07 18:13:45 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:13:45 --> Database Driver Class Initialized
INFO - 2023-05-07 18:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:13:45 --> Parser Class Initialized
INFO - 2023-05-07 18:13:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:13:45 --> Pagination Class Initialized
INFO - 2023-05-07 18:13:45 --> Form Validation Class Initialized
INFO - 2023-05-07 18:13:45 --> Controller Class Initialized
INFO - 2023-05-07 18:13:45 --> Model Class Initialized
DEBUG - 2023-05-07 18:13:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:13:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:13:45 --> Model Class Initialized
DEBUG - 2023-05-07 18:13:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:13:45 --> Model Class Initialized
INFO - 2023-05-07 18:13:45 --> Final output sent to browser
DEBUG - 2023-05-07 18:13:45 --> Total execution time: 0.0239
ERROR - 2023-05-07 18:13:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:13:49 --> Config Class Initialized
INFO - 2023-05-07 18:13:49 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:13:49 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:13:49 --> Utf8 Class Initialized
INFO - 2023-05-07 18:13:49 --> URI Class Initialized
INFO - 2023-05-07 18:13:49 --> Router Class Initialized
INFO - 2023-05-07 18:13:49 --> Output Class Initialized
INFO - 2023-05-07 18:13:49 --> Security Class Initialized
DEBUG - 2023-05-07 18:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:13:49 --> Input Class Initialized
INFO - 2023-05-07 18:13:49 --> Language Class Initialized
INFO - 2023-05-07 18:13:49 --> Loader Class Initialized
INFO - 2023-05-07 18:13:49 --> Helper loaded: url_helper
INFO - 2023-05-07 18:13:49 --> Helper loaded: file_helper
INFO - 2023-05-07 18:13:49 --> Helper loaded: html_helper
INFO - 2023-05-07 18:13:49 --> Helper loaded: text_helper
INFO - 2023-05-07 18:13:49 --> Helper loaded: form_helper
INFO - 2023-05-07 18:13:49 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:13:49 --> Helper loaded: security_helper
INFO - 2023-05-07 18:13:49 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:13:49 --> Database Driver Class Initialized
INFO - 2023-05-07 18:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:13:49 --> Parser Class Initialized
INFO - 2023-05-07 18:13:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:13:49 --> Pagination Class Initialized
INFO - 2023-05-07 18:13:49 --> Form Validation Class Initialized
INFO - 2023-05-07 18:13:49 --> Controller Class Initialized
INFO - 2023-05-07 18:13:49 --> Model Class Initialized
DEBUG - 2023-05-07 18:13:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:13:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:13:49 --> Model Class Initialized
DEBUG - 2023-05-07 18:13:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:13:49 --> Model Class Initialized
INFO - 2023-05-07 18:13:49 --> Final output sent to browser
DEBUG - 2023-05-07 18:13:49 --> Total execution time: 0.0184
ERROR - 2023-05-07 18:13:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:13:54 --> Config Class Initialized
INFO - 2023-05-07 18:13:54 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:13:54 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:13:54 --> Utf8 Class Initialized
INFO - 2023-05-07 18:13:54 --> URI Class Initialized
INFO - 2023-05-07 18:13:54 --> Router Class Initialized
INFO - 2023-05-07 18:13:54 --> Output Class Initialized
INFO - 2023-05-07 18:13:54 --> Security Class Initialized
DEBUG - 2023-05-07 18:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:13:54 --> Input Class Initialized
INFO - 2023-05-07 18:13:54 --> Language Class Initialized
INFO - 2023-05-07 18:13:54 --> Loader Class Initialized
INFO - 2023-05-07 18:13:54 --> Helper loaded: url_helper
INFO - 2023-05-07 18:13:54 --> Helper loaded: file_helper
INFO - 2023-05-07 18:13:54 --> Helper loaded: html_helper
INFO - 2023-05-07 18:13:54 --> Helper loaded: text_helper
INFO - 2023-05-07 18:13:54 --> Helper loaded: form_helper
INFO - 2023-05-07 18:13:54 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:13:54 --> Helper loaded: security_helper
INFO - 2023-05-07 18:13:54 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:13:54 --> Database Driver Class Initialized
INFO - 2023-05-07 18:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:13:54 --> Parser Class Initialized
INFO - 2023-05-07 18:13:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:13:54 --> Pagination Class Initialized
INFO - 2023-05-07 18:13:54 --> Form Validation Class Initialized
INFO - 2023-05-07 18:13:54 --> Controller Class Initialized
INFO - 2023-05-07 18:13:54 --> Model Class Initialized
DEBUG - 2023-05-07 18:13:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:13:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:13:54 --> Model Class Initialized
DEBUG - 2023-05-07 18:13:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:13:54 --> Model Class Initialized
INFO - 2023-05-07 18:13:54 --> Final output sent to browser
DEBUG - 2023-05-07 18:13:54 --> Total execution time: 0.0215
ERROR - 2023-05-07 18:14:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:14:06 --> Config Class Initialized
INFO - 2023-05-07 18:14:06 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:14:06 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:14:06 --> Utf8 Class Initialized
INFO - 2023-05-07 18:14:06 --> URI Class Initialized
DEBUG - 2023-05-07 18:14:06 --> No URI present. Default controller set.
INFO - 2023-05-07 18:14:06 --> Router Class Initialized
INFO - 2023-05-07 18:14:06 --> Output Class Initialized
INFO - 2023-05-07 18:14:06 --> Security Class Initialized
DEBUG - 2023-05-07 18:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:14:06 --> Input Class Initialized
INFO - 2023-05-07 18:14:06 --> Language Class Initialized
INFO - 2023-05-07 18:14:06 --> Loader Class Initialized
INFO - 2023-05-07 18:14:06 --> Helper loaded: url_helper
INFO - 2023-05-07 18:14:06 --> Helper loaded: file_helper
INFO - 2023-05-07 18:14:06 --> Helper loaded: html_helper
INFO - 2023-05-07 18:14:06 --> Helper loaded: text_helper
INFO - 2023-05-07 18:14:06 --> Helper loaded: form_helper
INFO - 2023-05-07 18:14:06 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:14:06 --> Helper loaded: security_helper
INFO - 2023-05-07 18:14:06 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:14:06 --> Database Driver Class Initialized
INFO - 2023-05-07 18:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:14:06 --> Parser Class Initialized
INFO - 2023-05-07 18:14:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:14:06 --> Pagination Class Initialized
INFO - 2023-05-07 18:14:06 --> Form Validation Class Initialized
INFO - 2023-05-07 18:14:06 --> Controller Class Initialized
INFO - 2023-05-07 18:14:06 --> Model Class Initialized
DEBUG - 2023-05-07 18:14:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:14:06 --> Model Class Initialized
DEBUG - 2023-05-07 18:14:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:14:06 --> Model Class Initialized
INFO - 2023-05-07 18:14:06 --> Model Class Initialized
INFO - 2023-05-07 18:14:06 --> Model Class Initialized
INFO - 2023-05-07 18:14:06 --> Model Class Initialized
DEBUG - 2023-05-07 18:14:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:14:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:14:06 --> Model Class Initialized
INFO - 2023-05-07 18:14:06 --> Model Class Initialized
INFO - 2023-05-07 18:14:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-07 18:14:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:14:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:14:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:14:06 --> Model Class Initialized
INFO - 2023-05-07 18:14:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:14:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:14:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:14:06 --> Final output sent to browser
DEBUG - 2023-05-07 18:14:06 --> Total execution time: 0.1609
ERROR - 2023-05-07 18:14:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:14:15 --> Config Class Initialized
INFO - 2023-05-07 18:14:15 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:14:15 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:14:15 --> Utf8 Class Initialized
INFO - 2023-05-07 18:14:15 --> URI Class Initialized
INFO - 2023-05-07 18:14:15 --> Router Class Initialized
INFO - 2023-05-07 18:14:15 --> Output Class Initialized
INFO - 2023-05-07 18:14:15 --> Security Class Initialized
DEBUG - 2023-05-07 18:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:14:15 --> Input Class Initialized
INFO - 2023-05-07 18:14:15 --> Language Class Initialized
INFO - 2023-05-07 18:14:15 --> Loader Class Initialized
INFO - 2023-05-07 18:14:15 --> Helper loaded: url_helper
INFO - 2023-05-07 18:14:15 --> Helper loaded: file_helper
INFO - 2023-05-07 18:14:15 --> Helper loaded: html_helper
INFO - 2023-05-07 18:14:15 --> Helper loaded: text_helper
INFO - 2023-05-07 18:14:15 --> Helper loaded: form_helper
INFO - 2023-05-07 18:14:15 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:14:15 --> Helper loaded: security_helper
INFO - 2023-05-07 18:14:15 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:14:15 --> Database Driver Class Initialized
INFO - 2023-05-07 18:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:14:15 --> Parser Class Initialized
INFO - 2023-05-07 18:14:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:14:15 --> Pagination Class Initialized
INFO - 2023-05-07 18:14:15 --> Form Validation Class Initialized
INFO - 2023-05-07 18:14:15 --> Controller Class Initialized
INFO - 2023-05-07 18:14:15 --> Model Class Initialized
DEBUG - 2023-05-07 18:14:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:14:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:14:15 --> Model Class Initialized
DEBUG - 2023-05-07 18:14:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:14:15 --> Model Class Initialized
INFO - 2023-05-07 18:14:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-07 18:14:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:14:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:14:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:14:15 --> Model Class Initialized
INFO - 2023-05-07 18:14:15 --> Model Class Initialized
INFO - 2023-05-07 18:14:15 --> Model Class Initialized
INFO - 2023-05-07 18:14:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:14:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:14:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:14:15 --> Final output sent to browser
DEBUG - 2023-05-07 18:14:15 --> Total execution time: 0.1286
ERROR - 2023-05-07 18:14:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:14:16 --> Config Class Initialized
INFO - 2023-05-07 18:14:16 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:14:16 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:14:16 --> Utf8 Class Initialized
INFO - 2023-05-07 18:14:16 --> URI Class Initialized
INFO - 2023-05-07 18:14:16 --> Router Class Initialized
INFO - 2023-05-07 18:14:16 --> Output Class Initialized
INFO - 2023-05-07 18:14:16 --> Security Class Initialized
DEBUG - 2023-05-07 18:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:14:16 --> Input Class Initialized
INFO - 2023-05-07 18:14:16 --> Language Class Initialized
INFO - 2023-05-07 18:14:16 --> Loader Class Initialized
INFO - 2023-05-07 18:14:16 --> Helper loaded: url_helper
INFO - 2023-05-07 18:14:16 --> Helper loaded: file_helper
INFO - 2023-05-07 18:14:16 --> Helper loaded: html_helper
INFO - 2023-05-07 18:14:16 --> Helper loaded: text_helper
INFO - 2023-05-07 18:14:16 --> Helper loaded: form_helper
INFO - 2023-05-07 18:14:16 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:14:16 --> Helper loaded: security_helper
INFO - 2023-05-07 18:14:16 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:14:16 --> Database Driver Class Initialized
INFO - 2023-05-07 18:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:14:16 --> Parser Class Initialized
INFO - 2023-05-07 18:14:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:14:16 --> Pagination Class Initialized
INFO - 2023-05-07 18:14:16 --> Form Validation Class Initialized
INFO - 2023-05-07 18:14:16 --> Controller Class Initialized
INFO - 2023-05-07 18:14:16 --> Model Class Initialized
DEBUG - 2023-05-07 18:14:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:14:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:14:16 --> Model Class Initialized
DEBUG - 2023-05-07 18:14:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:14:16 --> Model Class Initialized
INFO - 2023-05-07 18:14:16 --> Final output sent to browser
DEBUG - 2023-05-07 18:14:16 --> Total execution time: 0.0490
ERROR - 2023-05-07 18:14:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:14:30 --> Config Class Initialized
INFO - 2023-05-07 18:14:30 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:14:30 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:14:30 --> Utf8 Class Initialized
INFO - 2023-05-07 18:14:30 --> URI Class Initialized
INFO - 2023-05-07 18:14:30 --> Router Class Initialized
INFO - 2023-05-07 18:14:30 --> Output Class Initialized
INFO - 2023-05-07 18:14:30 --> Security Class Initialized
DEBUG - 2023-05-07 18:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:14:30 --> Input Class Initialized
INFO - 2023-05-07 18:14:30 --> Language Class Initialized
INFO - 2023-05-07 18:14:30 --> Loader Class Initialized
INFO - 2023-05-07 18:14:30 --> Helper loaded: url_helper
INFO - 2023-05-07 18:14:30 --> Helper loaded: file_helper
INFO - 2023-05-07 18:14:30 --> Helper loaded: html_helper
INFO - 2023-05-07 18:14:30 --> Helper loaded: text_helper
INFO - 2023-05-07 18:14:30 --> Helper loaded: form_helper
INFO - 2023-05-07 18:14:30 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:14:30 --> Helper loaded: security_helper
INFO - 2023-05-07 18:14:30 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:14:30 --> Database Driver Class Initialized
INFO - 2023-05-07 18:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:14:30 --> Parser Class Initialized
INFO - 2023-05-07 18:14:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:14:30 --> Pagination Class Initialized
INFO - 2023-05-07 18:14:30 --> Form Validation Class Initialized
INFO - 2023-05-07 18:14:30 --> Controller Class Initialized
INFO - 2023-05-07 18:14:30 --> Model Class Initialized
DEBUG - 2023-05-07 18:14:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:14:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:14:30 --> Model Class Initialized
DEBUG - 2023-05-07 18:14:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:14:30 --> Model Class Initialized
DEBUG - 2023-05-07 18:14:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:14:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-05-07 18:14:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:14:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:14:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:14:30 --> Model Class Initialized
INFO - 2023-05-07 18:14:30 --> Model Class Initialized
INFO - 2023-05-07 18:14:30 --> Model Class Initialized
INFO - 2023-05-07 18:14:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:14:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:14:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:14:30 --> Final output sent to browser
DEBUG - 2023-05-07 18:14:30 --> Total execution time: 0.1380
ERROR - 2023-05-07 18:15:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:15:01 --> Config Class Initialized
INFO - 2023-05-07 18:15:01 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:15:01 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:15:01 --> Utf8 Class Initialized
INFO - 2023-05-07 18:15:01 --> URI Class Initialized
DEBUG - 2023-05-07 18:15:01 --> No URI present. Default controller set.
INFO - 2023-05-07 18:15:01 --> Router Class Initialized
INFO - 2023-05-07 18:15:01 --> Output Class Initialized
INFO - 2023-05-07 18:15:01 --> Security Class Initialized
DEBUG - 2023-05-07 18:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:15:01 --> Input Class Initialized
INFO - 2023-05-07 18:15:01 --> Language Class Initialized
INFO - 2023-05-07 18:15:01 --> Loader Class Initialized
INFO - 2023-05-07 18:15:01 --> Helper loaded: url_helper
INFO - 2023-05-07 18:15:01 --> Helper loaded: file_helper
INFO - 2023-05-07 18:15:01 --> Helper loaded: html_helper
INFO - 2023-05-07 18:15:01 --> Helper loaded: text_helper
INFO - 2023-05-07 18:15:01 --> Helper loaded: form_helper
INFO - 2023-05-07 18:15:01 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:15:01 --> Helper loaded: security_helper
INFO - 2023-05-07 18:15:01 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:15:01 --> Database Driver Class Initialized
INFO - 2023-05-07 18:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:15:01 --> Parser Class Initialized
INFO - 2023-05-07 18:15:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:15:01 --> Pagination Class Initialized
INFO - 2023-05-07 18:15:01 --> Form Validation Class Initialized
INFO - 2023-05-07 18:15:01 --> Controller Class Initialized
INFO - 2023-05-07 18:15:01 --> Model Class Initialized
DEBUG - 2023-05-07 18:15:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:15:01 --> Model Class Initialized
DEBUG - 2023-05-07 18:15:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:15:01 --> Model Class Initialized
INFO - 2023-05-07 18:15:01 --> Model Class Initialized
INFO - 2023-05-07 18:15:01 --> Model Class Initialized
INFO - 2023-05-07 18:15:01 --> Model Class Initialized
DEBUG - 2023-05-07 18:15:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:15:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:15:01 --> Model Class Initialized
INFO - 2023-05-07 18:15:01 --> Model Class Initialized
INFO - 2023-05-07 18:15:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-07 18:15:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:15:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:15:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:15:01 --> Model Class Initialized
INFO - 2023-05-07 18:15:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:15:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:15:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:15:01 --> Final output sent to browser
DEBUG - 2023-05-07 18:15:01 --> Total execution time: 0.1788
ERROR - 2023-05-07 18:15:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:15:12 --> Config Class Initialized
INFO - 2023-05-07 18:15:12 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:15:12 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:15:12 --> Utf8 Class Initialized
INFO - 2023-05-07 18:15:12 --> URI Class Initialized
INFO - 2023-05-07 18:15:12 --> Router Class Initialized
INFO - 2023-05-07 18:15:12 --> Output Class Initialized
INFO - 2023-05-07 18:15:12 --> Security Class Initialized
DEBUG - 2023-05-07 18:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:15:12 --> Input Class Initialized
INFO - 2023-05-07 18:15:12 --> Language Class Initialized
INFO - 2023-05-07 18:15:12 --> Loader Class Initialized
INFO - 2023-05-07 18:15:12 --> Helper loaded: url_helper
INFO - 2023-05-07 18:15:12 --> Helper loaded: file_helper
INFO - 2023-05-07 18:15:12 --> Helper loaded: html_helper
INFO - 2023-05-07 18:15:12 --> Helper loaded: text_helper
INFO - 2023-05-07 18:15:12 --> Helper loaded: form_helper
INFO - 2023-05-07 18:15:12 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:15:12 --> Helper loaded: security_helper
INFO - 2023-05-07 18:15:12 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:15:12 --> Database Driver Class Initialized
INFO - 2023-05-07 18:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:15:12 --> Parser Class Initialized
INFO - 2023-05-07 18:15:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:15:12 --> Pagination Class Initialized
INFO - 2023-05-07 18:15:12 --> Form Validation Class Initialized
INFO - 2023-05-07 18:15:12 --> Controller Class Initialized
INFO - 2023-05-07 18:15:12 --> Model Class Initialized
DEBUG - 2023-05-07 18:15:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:15:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:15:12 --> Model Class Initialized
DEBUG - 2023-05-07 18:15:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:15:12 --> Model Class Initialized
INFO - 2023-05-07 18:15:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-07 18:15:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:15:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:15:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:15:12 --> Model Class Initialized
INFO - 2023-05-07 18:15:12 --> Model Class Initialized
INFO - 2023-05-07 18:15:12 --> Model Class Initialized
INFO - 2023-05-07 18:15:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:15:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:15:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:15:12 --> Final output sent to browser
DEBUG - 2023-05-07 18:15:12 --> Total execution time: 0.1347
ERROR - 2023-05-07 18:15:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:15:13 --> Config Class Initialized
INFO - 2023-05-07 18:15:13 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:15:13 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:15:13 --> Utf8 Class Initialized
INFO - 2023-05-07 18:15:13 --> URI Class Initialized
INFO - 2023-05-07 18:15:13 --> Router Class Initialized
INFO - 2023-05-07 18:15:13 --> Output Class Initialized
INFO - 2023-05-07 18:15:13 --> Security Class Initialized
DEBUG - 2023-05-07 18:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:15:13 --> Input Class Initialized
INFO - 2023-05-07 18:15:13 --> Language Class Initialized
INFO - 2023-05-07 18:15:13 --> Loader Class Initialized
INFO - 2023-05-07 18:15:13 --> Helper loaded: url_helper
INFO - 2023-05-07 18:15:13 --> Helper loaded: file_helper
INFO - 2023-05-07 18:15:13 --> Helper loaded: html_helper
INFO - 2023-05-07 18:15:13 --> Helper loaded: text_helper
INFO - 2023-05-07 18:15:13 --> Helper loaded: form_helper
INFO - 2023-05-07 18:15:13 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:15:13 --> Helper loaded: security_helper
INFO - 2023-05-07 18:15:13 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:15:13 --> Database Driver Class Initialized
INFO - 2023-05-07 18:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:15:13 --> Parser Class Initialized
INFO - 2023-05-07 18:15:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:15:13 --> Pagination Class Initialized
INFO - 2023-05-07 18:15:13 --> Form Validation Class Initialized
INFO - 2023-05-07 18:15:13 --> Controller Class Initialized
INFO - 2023-05-07 18:15:13 --> Model Class Initialized
DEBUG - 2023-05-07 18:15:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:15:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:15:13 --> Model Class Initialized
DEBUG - 2023-05-07 18:15:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:15:13 --> Model Class Initialized
INFO - 2023-05-07 18:15:13 --> Final output sent to browser
DEBUG - 2023-05-07 18:15:13 --> Total execution time: 0.0457
ERROR - 2023-05-07 18:15:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:15:21 --> Config Class Initialized
INFO - 2023-05-07 18:15:21 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:15:21 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:15:21 --> Utf8 Class Initialized
INFO - 2023-05-07 18:15:21 --> URI Class Initialized
INFO - 2023-05-07 18:15:21 --> Router Class Initialized
INFO - 2023-05-07 18:15:21 --> Output Class Initialized
INFO - 2023-05-07 18:15:21 --> Security Class Initialized
DEBUG - 2023-05-07 18:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:15:21 --> Input Class Initialized
INFO - 2023-05-07 18:15:21 --> Language Class Initialized
INFO - 2023-05-07 18:15:21 --> Loader Class Initialized
INFO - 2023-05-07 18:15:21 --> Helper loaded: url_helper
INFO - 2023-05-07 18:15:21 --> Helper loaded: file_helper
INFO - 2023-05-07 18:15:21 --> Helper loaded: html_helper
INFO - 2023-05-07 18:15:21 --> Helper loaded: text_helper
INFO - 2023-05-07 18:15:21 --> Helper loaded: form_helper
INFO - 2023-05-07 18:15:21 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:15:21 --> Helper loaded: security_helper
INFO - 2023-05-07 18:15:21 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:15:21 --> Database Driver Class Initialized
INFO - 2023-05-07 18:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:15:21 --> Parser Class Initialized
INFO - 2023-05-07 18:15:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:15:21 --> Pagination Class Initialized
INFO - 2023-05-07 18:15:21 --> Form Validation Class Initialized
INFO - 2023-05-07 18:15:21 --> Controller Class Initialized
INFO - 2023-05-07 18:15:21 --> Model Class Initialized
DEBUG - 2023-05-07 18:15:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:15:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:15:21 --> Model Class Initialized
DEBUG - 2023-05-07 18:15:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:15:21 --> Model Class Initialized
INFO - 2023-05-07 18:15:21 --> Final output sent to browser
DEBUG - 2023-05-07 18:15:21 --> Total execution time: 0.0316
ERROR - 2023-05-07 18:15:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:15:24 --> Config Class Initialized
INFO - 2023-05-07 18:15:24 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:15:24 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:15:24 --> Utf8 Class Initialized
INFO - 2023-05-07 18:15:24 --> URI Class Initialized
INFO - 2023-05-07 18:15:24 --> Router Class Initialized
INFO - 2023-05-07 18:15:24 --> Output Class Initialized
INFO - 2023-05-07 18:15:24 --> Security Class Initialized
DEBUG - 2023-05-07 18:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:15:24 --> Input Class Initialized
INFO - 2023-05-07 18:15:24 --> Language Class Initialized
INFO - 2023-05-07 18:15:24 --> Loader Class Initialized
INFO - 2023-05-07 18:15:24 --> Helper loaded: url_helper
INFO - 2023-05-07 18:15:24 --> Helper loaded: file_helper
INFO - 2023-05-07 18:15:24 --> Helper loaded: html_helper
INFO - 2023-05-07 18:15:24 --> Helper loaded: text_helper
INFO - 2023-05-07 18:15:24 --> Helper loaded: form_helper
INFO - 2023-05-07 18:15:24 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:15:24 --> Helper loaded: security_helper
INFO - 2023-05-07 18:15:24 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:15:24 --> Database Driver Class Initialized
INFO - 2023-05-07 18:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:15:24 --> Parser Class Initialized
INFO - 2023-05-07 18:15:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:15:24 --> Pagination Class Initialized
INFO - 2023-05-07 18:15:24 --> Form Validation Class Initialized
INFO - 2023-05-07 18:15:24 --> Controller Class Initialized
INFO - 2023-05-07 18:15:24 --> Model Class Initialized
DEBUG - 2023-05-07 18:15:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:15:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:15:24 --> Model Class Initialized
DEBUG - 2023-05-07 18:15:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:15:24 --> Model Class Initialized
INFO - 2023-05-07 18:15:24 --> Final output sent to browser
DEBUG - 2023-05-07 18:15:24 --> Total execution time: 0.0305
ERROR - 2023-05-07 18:15:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:15:26 --> Config Class Initialized
INFO - 2023-05-07 18:15:26 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:15:26 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:15:26 --> Utf8 Class Initialized
INFO - 2023-05-07 18:15:26 --> URI Class Initialized
INFO - 2023-05-07 18:15:26 --> Router Class Initialized
INFO - 2023-05-07 18:15:26 --> Output Class Initialized
INFO - 2023-05-07 18:15:26 --> Security Class Initialized
DEBUG - 2023-05-07 18:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:15:26 --> Input Class Initialized
INFO - 2023-05-07 18:15:26 --> Language Class Initialized
INFO - 2023-05-07 18:15:26 --> Loader Class Initialized
INFO - 2023-05-07 18:15:26 --> Helper loaded: url_helper
INFO - 2023-05-07 18:15:26 --> Helper loaded: file_helper
INFO - 2023-05-07 18:15:26 --> Helper loaded: html_helper
INFO - 2023-05-07 18:15:26 --> Helper loaded: text_helper
INFO - 2023-05-07 18:15:26 --> Helper loaded: form_helper
INFO - 2023-05-07 18:15:26 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:15:26 --> Helper loaded: security_helper
INFO - 2023-05-07 18:15:26 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:15:26 --> Database Driver Class Initialized
INFO - 2023-05-07 18:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:15:26 --> Parser Class Initialized
INFO - 2023-05-07 18:15:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:15:26 --> Pagination Class Initialized
INFO - 2023-05-07 18:15:26 --> Form Validation Class Initialized
INFO - 2023-05-07 18:15:26 --> Controller Class Initialized
INFO - 2023-05-07 18:15:26 --> Model Class Initialized
DEBUG - 2023-05-07 18:15:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:15:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:15:26 --> Model Class Initialized
DEBUG - 2023-05-07 18:15:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:15:26 --> Model Class Initialized
INFO - 2023-05-07 18:15:26 --> Final output sent to browser
DEBUG - 2023-05-07 18:15:26 --> Total execution time: 0.0322
ERROR - 2023-05-07 18:16:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:16:19 --> Config Class Initialized
INFO - 2023-05-07 18:16:19 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:16:19 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:16:19 --> Utf8 Class Initialized
INFO - 2023-05-07 18:16:19 --> URI Class Initialized
DEBUG - 2023-05-07 18:16:19 --> No URI present. Default controller set.
INFO - 2023-05-07 18:16:19 --> Router Class Initialized
INFO - 2023-05-07 18:16:19 --> Output Class Initialized
INFO - 2023-05-07 18:16:19 --> Security Class Initialized
DEBUG - 2023-05-07 18:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:16:19 --> Input Class Initialized
INFO - 2023-05-07 18:16:19 --> Language Class Initialized
INFO - 2023-05-07 18:16:19 --> Loader Class Initialized
INFO - 2023-05-07 18:16:19 --> Helper loaded: url_helper
INFO - 2023-05-07 18:16:19 --> Helper loaded: file_helper
INFO - 2023-05-07 18:16:19 --> Helper loaded: html_helper
INFO - 2023-05-07 18:16:19 --> Helper loaded: text_helper
INFO - 2023-05-07 18:16:19 --> Helper loaded: form_helper
INFO - 2023-05-07 18:16:19 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:16:19 --> Helper loaded: security_helper
INFO - 2023-05-07 18:16:19 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:16:19 --> Database Driver Class Initialized
INFO - 2023-05-07 18:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:16:19 --> Parser Class Initialized
INFO - 2023-05-07 18:16:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:16:19 --> Pagination Class Initialized
INFO - 2023-05-07 18:16:19 --> Form Validation Class Initialized
INFO - 2023-05-07 18:16:19 --> Controller Class Initialized
INFO - 2023-05-07 18:16:19 --> Model Class Initialized
DEBUG - 2023-05-07 18:16:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:16:19 --> Model Class Initialized
DEBUG - 2023-05-07 18:16:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:16:19 --> Model Class Initialized
INFO - 2023-05-07 18:16:19 --> Model Class Initialized
INFO - 2023-05-07 18:16:19 --> Model Class Initialized
INFO - 2023-05-07 18:16:19 --> Model Class Initialized
DEBUG - 2023-05-07 18:16:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:16:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:16:19 --> Model Class Initialized
INFO - 2023-05-07 18:16:19 --> Model Class Initialized
INFO - 2023-05-07 18:16:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-07 18:16:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:16:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:16:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:16:19 --> Model Class Initialized
INFO - 2023-05-07 18:16:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:16:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:16:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:16:19 --> Final output sent to browser
DEBUG - 2023-05-07 18:16:19 --> Total execution time: 0.1666
ERROR - 2023-05-07 18:16:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:16:30 --> Config Class Initialized
INFO - 2023-05-07 18:16:30 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:16:30 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:16:30 --> Utf8 Class Initialized
INFO - 2023-05-07 18:16:30 --> URI Class Initialized
INFO - 2023-05-07 18:16:30 --> Router Class Initialized
INFO - 2023-05-07 18:16:30 --> Output Class Initialized
INFO - 2023-05-07 18:16:30 --> Security Class Initialized
DEBUG - 2023-05-07 18:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:16:30 --> Input Class Initialized
INFO - 2023-05-07 18:16:30 --> Language Class Initialized
INFO - 2023-05-07 18:16:30 --> Loader Class Initialized
INFO - 2023-05-07 18:16:30 --> Helper loaded: url_helper
INFO - 2023-05-07 18:16:30 --> Helper loaded: file_helper
INFO - 2023-05-07 18:16:30 --> Helper loaded: html_helper
INFO - 2023-05-07 18:16:30 --> Helper loaded: text_helper
INFO - 2023-05-07 18:16:30 --> Helper loaded: form_helper
INFO - 2023-05-07 18:16:30 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:16:30 --> Helper loaded: security_helper
INFO - 2023-05-07 18:16:30 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:16:30 --> Database Driver Class Initialized
INFO - 2023-05-07 18:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:16:30 --> Parser Class Initialized
INFO - 2023-05-07 18:16:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:16:30 --> Pagination Class Initialized
INFO - 2023-05-07 18:16:30 --> Form Validation Class Initialized
INFO - 2023-05-07 18:16:30 --> Controller Class Initialized
INFO - 2023-05-07 18:16:30 --> Model Class Initialized
DEBUG - 2023-05-07 18:16:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:16:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:16:30 --> Model Class Initialized
INFO - 2023-05-07 18:16:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-05-07 18:16:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:16:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:16:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:16:30 --> Model Class Initialized
INFO - 2023-05-07 18:16:30 --> Model Class Initialized
INFO - 2023-05-07 18:16:30 --> Model Class Initialized
INFO - 2023-05-07 18:16:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:16:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:16:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:16:30 --> Final output sent to browser
DEBUG - 2023-05-07 18:16:30 --> Total execution time: 0.1319
ERROR - 2023-05-07 18:16:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:16:31 --> Config Class Initialized
INFO - 2023-05-07 18:16:31 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:16:31 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:16:31 --> Utf8 Class Initialized
INFO - 2023-05-07 18:16:31 --> URI Class Initialized
INFO - 2023-05-07 18:16:31 --> Router Class Initialized
INFO - 2023-05-07 18:16:31 --> Output Class Initialized
INFO - 2023-05-07 18:16:31 --> Security Class Initialized
DEBUG - 2023-05-07 18:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:16:31 --> Input Class Initialized
INFO - 2023-05-07 18:16:31 --> Language Class Initialized
INFO - 2023-05-07 18:16:31 --> Loader Class Initialized
INFO - 2023-05-07 18:16:31 --> Helper loaded: url_helper
INFO - 2023-05-07 18:16:31 --> Helper loaded: file_helper
INFO - 2023-05-07 18:16:31 --> Helper loaded: html_helper
INFO - 2023-05-07 18:16:31 --> Helper loaded: text_helper
INFO - 2023-05-07 18:16:31 --> Helper loaded: form_helper
INFO - 2023-05-07 18:16:31 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:16:31 --> Helper loaded: security_helper
INFO - 2023-05-07 18:16:31 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:16:31 --> Database Driver Class Initialized
INFO - 2023-05-07 18:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:16:31 --> Parser Class Initialized
INFO - 2023-05-07 18:16:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:16:31 --> Pagination Class Initialized
INFO - 2023-05-07 18:16:31 --> Form Validation Class Initialized
INFO - 2023-05-07 18:16:31 --> Controller Class Initialized
INFO - 2023-05-07 18:16:31 --> Model Class Initialized
DEBUG - 2023-05-07 18:16:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:16:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:16:31 --> Model Class Initialized
INFO - 2023-05-07 18:16:31 --> Final output sent to browser
DEBUG - 2023-05-07 18:16:31 --> Total execution time: 0.0310
ERROR - 2023-05-07 18:16:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:16:50 --> Config Class Initialized
INFO - 2023-05-07 18:16:50 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:16:50 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:16:50 --> Utf8 Class Initialized
INFO - 2023-05-07 18:16:50 --> URI Class Initialized
INFO - 2023-05-07 18:16:50 --> Router Class Initialized
INFO - 2023-05-07 18:16:50 --> Output Class Initialized
INFO - 2023-05-07 18:16:50 --> Security Class Initialized
DEBUG - 2023-05-07 18:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:16:50 --> Input Class Initialized
INFO - 2023-05-07 18:16:50 --> Language Class Initialized
INFO - 2023-05-07 18:16:50 --> Loader Class Initialized
INFO - 2023-05-07 18:16:50 --> Helper loaded: url_helper
INFO - 2023-05-07 18:16:50 --> Helper loaded: file_helper
INFO - 2023-05-07 18:16:50 --> Helper loaded: html_helper
INFO - 2023-05-07 18:16:50 --> Helper loaded: text_helper
INFO - 2023-05-07 18:16:50 --> Helper loaded: form_helper
INFO - 2023-05-07 18:16:50 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:16:50 --> Helper loaded: security_helper
INFO - 2023-05-07 18:16:50 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:16:50 --> Database Driver Class Initialized
INFO - 2023-05-07 18:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:16:50 --> Parser Class Initialized
INFO - 2023-05-07 18:16:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:16:50 --> Pagination Class Initialized
INFO - 2023-05-07 18:16:50 --> Form Validation Class Initialized
INFO - 2023-05-07 18:16:50 --> Controller Class Initialized
INFO - 2023-05-07 18:16:50 --> Model Class Initialized
DEBUG - 2023-05-07 18:16:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:16:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:16:50 --> Model Class Initialized
INFO - 2023-05-07 18:16:50 --> Final output sent to browser
DEBUG - 2023-05-07 18:16:50 --> Total execution time: 0.0208
ERROR - 2023-05-07 18:16:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:16:58 --> Config Class Initialized
INFO - 2023-05-07 18:16:58 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:16:58 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:16:58 --> Utf8 Class Initialized
INFO - 2023-05-07 18:16:58 --> URI Class Initialized
INFO - 2023-05-07 18:16:58 --> Router Class Initialized
INFO - 2023-05-07 18:16:58 --> Output Class Initialized
INFO - 2023-05-07 18:16:58 --> Security Class Initialized
DEBUG - 2023-05-07 18:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:16:58 --> Input Class Initialized
INFO - 2023-05-07 18:16:58 --> Language Class Initialized
INFO - 2023-05-07 18:16:58 --> Loader Class Initialized
INFO - 2023-05-07 18:16:58 --> Helper loaded: url_helper
INFO - 2023-05-07 18:16:58 --> Helper loaded: file_helper
INFO - 2023-05-07 18:16:58 --> Helper loaded: html_helper
INFO - 2023-05-07 18:16:58 --> Helper loaded: text_helper
INFO - 2023-05-07 18:16:58 --> Helper loaded: form_helper
INFO - 2023-05-07 18:16:58 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:16:58 --> Helper loaded: security_helper
INFO - 2023-05-07 18:16:58 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:16:58 --> Database Driver Class Initialized
INFO - 2023-05-07 18:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:16:58 --> Parser Class Initialized
INFO - 2023-05-07 18:16:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:16:58 --> Pagination Class Initialized
INFO - 2023-05-07 18:16:58 --> Form Validation Class Initialized
INFO - 2023-05-07 18:16:58 --> Controller Class Initialized
INFO - 2023-05-07 18:16:58 --> Model Class Initialized
INFO - 2023-05-07 18:16:58 --> Model Class Initialized
INFO - 2023-05-07 18:16:58 --> Model Class Initialized
INFO - 2023-05-07 18:16:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report_batch_wise.php
DEBUG - 2023-05-07 18:16:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:16:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:16:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:16:58 --> Model Class Initialized
INFO - 2023-05-07 18:16:58 --> Model Class Initialized
INFO - 2023-05-07 18:16:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:16:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:16:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:16:58 --> Final output sent to browser
DEBUG - 2023-05-07 18:16:58 --> Total execution time: 0.1307
ERROR - 2023-05-07 18:16:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:16:59 --> Config Class Initialized
INFO - 2023-05-07 18:16:59 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:16:59 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:16:59 --> Utf8 Class Initialized
INFO - 2023-05-07 18:16:59 --> URI Class Initialized
INFO - 2023-05-07 18:16:59 --> Router Class Initialized
INFO - 2023-05-07 18:16:59 --> Output Class Initialized
INFO - 2023-05-07 18:16:59 --> Security Class Initialized
DEBUG - 2023-05-07 18:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:16:59 --> Input Class Initialized
INFO - 2023-05-07 18:16:59 --> Language Class Initialized
INFO - 2023-05-07 18:16:59 --> Loader Class Initialized
INFO - 2023-05-07 18:16:59 --> Helper loaded: url_helper
INFO - 2023-05-07 18:16:59 --> Helper loaded: file_helper
INFO - 2023-05-07 18:16:59 --> Helper loaded: html_helper
INFO - 2023-05-07 18:16:59 --> Helper loaded: text_helper
INFO - 2023-05-07 18:16:59 --> Helper loaded: form_helper
INFO - 2023-05-07 18:16:59 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:16:59 --> Helper loaded: security_helper
INFO - 2023-05-07 18:16:59 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:16:59 --> Database Driver Class Initialized
INFO - 2023-05-07 18:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:16:59 --> Parser Class Initialized
INFO - 2023-05-07 18:16:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:16:59 --> Pagination Class Initialized
INFO - 2023-05-07 18:16:59 --> Form Validation Class Initialized
INFO - 2023-05-07 18:16:59 --> Controller Class Initialized
INFO - 2023-05-07 18:16:59 --> Model Class Initialized
INFO - 2023-05-07 18:16:59 --> Model Class Initialized
INFO - 2023-05-07 18:16:59 --> Final output sent to browser
DEBUG - 2023-05-07 18:16:59 --> Total execution time: 0.0212
ERROR - 2023-05-07 18:17:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:17:04 --> Config Class Initialized
INFO - 2023-05-07 18:17:04 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:17:04 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:17:04 --> Utf8 Class Initialized
INFO - 2023-05-07 18:17:04 --> URI Class Initialized
INFO - 2023-05-07 18:17:04 --> Router Class Initialized
INFO - 2023-05-07 18:17:04 --> Output Class Initialized
INFO - 2023-05-07 18:17:04 --> Security Class Initialized
DEBUG - 2023-05-07 18:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:17:04 --> Input Class Initialized
INFO - 2023-05-07 18:17:04 --> Language Class Initialized
INFO - 2023-05-07 18:17:04 --> Loader Class Initialized
INFO - 2023-05-07 18:17:04 --> Helper loaded: url_helper
INFO - 2023-05-07 18:17:04 --> Helper loaded: file_helper
INFO - 2023-05-07 18:17:04 --> Helper loaded: html_helper
INFO - 2023-05-07 18:17:04 --> Helper loaded: text_helper
INFO - 2023-05-07 18:17:04 --> Helper loaded: form_helper
INFO - 2023-05-07 18:17:04 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:17:04 --> Helper loaded: security_helper
INFO - 2023-05-07 18:17:04 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:17:04 --> Database Driver Class Initialized
INFO - 2023-05-07 18:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:17:04 --> Parser Class Initialized
INFO - 2023-05-07 18:17:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:17:04 --> Pagination Class Initialized
INFO - 2023-05-07 18:17:04 --> Form Validation Class Initialized
INFO - 2023-05-07 18:17:04 --> Controller Class Initialized
INFO - 2023-05-07 18:17:04 --> Model Class Initialized
INFO - 2023-05-07 18:17:04 --> Model Class Initialized
INFO - 2023-05-07 18:17:04 --> Final output sent to browser
DEBUG - 2023-05-07 18:17:04 --> Total execution time: 0.0327
ERROR - 2023-05-07 18:17:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:17:56 --> Config Class Initialized
INFO - 2023-05-07 18:17:56 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:17:56 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:17:56 --> Utf8 Class Initialized
INFO - 2023-05-07 18:17:56 --> URI Class Initialized
INFO - 2023-05-07 18:17:56 --> Router Class Initialized
INFO - 2023-05-07 18:17:56 --> Output Class Initialized
INFO - 2023-05-07 18:17:56 --> Security Class Initialized
DEBUG - 2023-05-07 18:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:17:56 --> Input Class Initialized
INFO - 2023-05-07 18:17:56 --> Language Class Initialized
INFO - 2023-05-07 18:17:56 --> Loader Class Initialized
INFO - 2023-05-07 18:17:56 --> Helper loaded: url_helper
INFO - 2023-05-07 18:17:56 --> Helper loaded: file_helper
INFO - 2023-05-07 18:17:56 --> Helper loaded: html_helper
INFO - 2023-05-07 18:17:56 --> Helper loaded: text_helper
INFO - 2023-05-07 18:17:56 --> Helper loaded: form_helper
INFO - 2023-05-07 18:17:56 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:17:56 --> Helper loaded: security_helper
INFO - 2023-05-07 18:17:56 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:17:56 --> Database Driver Class Initialized
INFO - 2023-05-07 18:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:17:56 --> Parser Class Initialized
INFO - 2023-05-07 18:17:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:17:56 --> Pagination Class Initialized
INFO - 2023-05-07 18:17:56 --> Form Validation Class Initialized
INFO - 2023-05-07 18:17:56 --> Controller Class Initialized
DEBUG - 2023-05-07 18:17:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:17:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:17:56 --> Model Class Initialized
INFO - 2023-05-07 18:17:56 --> Model Class Initialized
DEBUG - 2023-05-07 18:17:56 --> Lmr class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:17:56 --> Model Class Initialized
INFO - 2023-05-07 18:17:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/mr/mr.php
DEBUG - 2023-05-07 18:17:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:17:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:17:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:17:56 --> Model Class Initialized
INFO - 2023-05-07 18:17:56 --> Model Class Initialized
INFO - 2023-05-07 18:17:56 --> Model Class Initialized
INFO - 2023-05-07 18:17:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:17:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:17:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:17:56 --> Final output sent to browser
DEBUG - 2023-05-07 18:17:56 --> Total execution time: 0.1326
ERROR - 2023-05-07 18:17:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:17:57 --> Config Class Initialized
INFO - 2023-05-07 18:17:57 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:17:57 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:17:57 --> Utf8 Class Initialized
INFO - 2023-05-07 18:17:57 --> URI Class Initialized
INFO - 2023-05-07 18:17:57 --> Router Class Initialized
INFO - 2023-05-07 18:17:57 --> Output Class Initialized
INFO - 2023-05-07 18:17:57 --> Security Class Initialized
DEBUG - 2023-05-07 18:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:17:57 --> Input Class Initialized
INFO - 2023-05-07 18:17:57 --> Language Class Initialized
INFO - 2023-05-07 18:17:57 --> Loader Class Initialized
INFO - 2023-05-07 18:17:57 --> Helper loaded: url_helper
INFO - 2023-05-07 18:17:57 --> Helper loaded: file_helper
INFO - 2023-05-07 18:17:57 --> Helper loaded: html_helper
INFO - 2023-05-07 18:17:57 --> Helper loaded: text_helper
INFO - 2023-05-07 18:17:57 --> Helper loaded: form_helper
INFO - 2023-05-07 18:17:57 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:17:57 --> Helper loaded: security_helper
INFO - 2023-05-07 18:17:57 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:17:57 --> Database Driver Class Initialized
INFO - 2023-05-07 18:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:17:57 --> Parser Class Initialized
INFO - 2023-05-07 18:17:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:17:57 --> Pagination Class Initialized
INFO - 2023-05-07 18:17:57 --> Form Validation Class Initialized
INFO - 2023-05-07 18:17:57 --> Controller Class Initialized
DEBUG - 2023-05-07 18:17:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:17:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:17:57 --> Model Class Initialized
INFO - 2023-05-07 18:17:57 --> Model Class Initialized
INFO - 2023-05-07 18:17:57 --> Final output sent to browser
DEBUG - 2023-05-07 18:17:57 --> Total execution time: 0.0196
ERROR - 2023-05-07 18:18:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:18:06 --> Config Class Initialized
INFO - 2023-05-07 18:18:06 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:18:06 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:18:06 --> Utf8 Class Initialized
INFO - 2023-05-07 18:18:06 --> URI Class Initialized
INFO - 2023-05-07 18:18:06 --> Router Class Initialized
INFO - 2023-05-07 18:18:06 --> Output Class Initialized
INFO - 2023-05-07 18:18:06 --> Security Class Initialized
DEBUG - 2023-05-07 18:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:18:06 --> Input Class Initialized
INFO - 2023-05-07 18:18:06 --> Language Class Initialized
INFO - 2023-05-07 18:18:06 --> Loader Class Initialized
INFO - 2023-05-07 18:18:06 --> Helper loaded: url_helper
INFO - 2023-05-07 18:18:06 --> Helper loaded: file_helper
INFO - 2023-05-07 18:18:06 --> Helper loaded: html_helper
INFO - 2023-05-07 18:18:06 --> Helper loaded: text_helper
INFO - 2023-05-07 18:18:06 --> Helper loaded: form_helper
INFO - 2023-05-07 18:18:06 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:18:06 --> Helper loaded: security_helper
INFO - 2023-05-07 18:18:06 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:18:06 --> Database Driver Class Initialized
INFO - 2023-05-07 18:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:18:06 --> Parser Class Initialized
INFO - 2023-05-07 18:18:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:18:06 --> Pagination Class Initialized
INFO - 2023-05-07 18:18:06 --> Form Validation Class Initialized
INFO - 2023-05-07 18:18:06 --> Controller Class Initialized
ERROR - 2023-05-07 18:18:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:18:07 --> Config Class Initialized
INFO - 2023-05-07 18:18:07 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:18:07 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:18:07 --> Utf8 Class Initialized
INFO - 2023-05-07 18:18:07 --> URI Class Initialized
INFO - 2023-05-07 18:18:07 --> Router Class Initialized
INFO - 2023-05-07 18:18:07 --> Output Class Initialized
INFO - 2023-05-07 18:18:07 --> Security Class Initialized
DEBUG - 2023-05-07 18:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:18:07 --> Input Class Initialized
INFO - 2023-05-07 18:18:07 --> Language Class Initialized
INFO - 2023-05-07 18:18:07 --> Loader Class Initialized
INFO - 2023-05-07 18:18:07 --> Helper loaded: url_helper
INFO - 2023-05-07 18:18:07 --> Helper loaded: file_helper
INFO - 2023-05-07 18:18:07 --> Helper loaded: html_helper
INFO - 2023-05-07 18:18:07 --> Helper loaded: text_helper
INFO - 2023-05-07 18:18:07 --> Helper loaded: form_helper
INFO - 2023-05-07 18:18:07 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:18:07 --> Helper loaded: security_helper
INFO - 2023-05-07 18:18:07 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:18:07 --> Database Driver Class Initialized
INFO - 2023-05-07 18:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:18:07 --> Parser Class Initialized
INFO - 2023-05-07 18:18:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:18:07 --> Pagination Class Initialized
INFO - 2023-05-07 18:18:07 --> Form Validation Class Initialized
INFO - 2023-05-07 18:18:07 --> Controller Class Initialized
INFO - 2023-05-07 18:18:07 --> Model Class Initialized
DEBUG - 2023-05-07 18:18:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:18:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-07 18:18:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:18:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:18:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:18:07 --> Model Class Initialized
INFO - 2023-05-07 18:18:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:18:07 --> Final output sent to browser
DEBUG - 2023-05-07 18:18:07 --> Total execution time: 0.0281
ERROR - 2023-05-07 18:18:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:18:12 --> Config Class Initialized
INFO - 2023-05-07 18:18:12 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:18:12 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:18:12 --> Utf8 Class Initialized
INFO - 2023-05-07 18:18:12 --> URI Class Initialized
INFO - 2023-05-07 18:18:12 --> Router Class Initialized
INFO - 2023-05-07 18:18:12 --> Output Class Initialized
INFO - 2023-05-07 18:18:12 --> Security Class Initialized
DEBUG - 2023-05-07 18:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:18:12 --> Input Class Initialized
INFO - 2023-05-07 18:18:12 --> Language Class Initialized
INFO - 2023-05-07 18:18:12 --> Loader Class Initialized
INFO - 2023-05-07 18:18:12 --> Helper loaded: url_helper
INFO - 2023-05-07 18:18:12 --> Helper loaded: file_helper
INFO - 2023-05-07 18:18:12 --> Helper loaded: html_helper
INFO - 2023-05-07 18:18:12 --> Helper loaded: text_helper
INFO - 2023-05-07 18:18:12 --> Helper loaded: form_helper
INFO - 2023-05-07 18:18:12 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:18:12 --> Helper loaded: security_helper
INFO - 2023-05-07 18:18:12 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:18:12 --> Database Driver Class Initialized
INFO - 2023-05-07 18:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:18:12 --> Parser Class Initialized
INFO - 2023-05-07 18:18:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:18:12 --> Pagination Class Initialized
INFO - 2023-05-07 18:18:12 --> Form Validation Class Initialized
INFO - 2023-05-07 18:18:12 --> Controller Class Initialized
INFO - 2023-05-07 18:18:12 --> Model Class Initialized
DEBUG - 2023-05-07 18:18:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:18:12 --> Model Class Initialized
INFO - 2023-05-07 18:18:12 --> Final output sent to browser
DEBUG - 2023-05-07 18:18:12 --> Total execution time: 0.0163
ERROR - 2023-05-07 18:18:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:18:13 --> Config Class Initialized
INFO - 2023-05-07 18:18:13 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:18:13 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:18:13 --> Utf8 Class Initialized
INFO - 2023-05-07 18:18:13 --> URI Class Initialized
DEBUG - 2023-05-07 18:18:13 --> No URI present. Default controller set.
INFO - 2023-05-07 18:18:13 --> Router Class Initialized
INFO - 2023-05-07 18:18:13 --> Output Class Initialized
INFO - 2023-05-07 18:18:13 --> Security Class Initialized
DEBUG - 2023-05-07 18:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:18:13 --> Input Class Initialized
INFO - 2023-05-07 18:18:13 --> Language Class Initialized
INFO - 2023-05-07 18:18:13 --> Loader Class Initialized
INFO - 2023-05-07 18:18:13 --> Helper loaded: url_helper
INFO - 2023-05-07 18:18:13 --> Helper loaded: file_helper
INFO - 2023-05-07 18:18:13 --> Helper loaded: html_helper
INFO - 2023-05-07 18:18:13 --> Helper loaded: text_helper
INFO - 2023-05-07 18:18:13 --> Helper loaded: form_helper
INFO - 2023-05-07 18:18:13 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:18:13 --> Helper loaded: security_helper
INFO - 2023-05-07 18:18:13 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:18:13 --> Database Driver Class Initialized
INFO - 2023-05-07 18:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:18:13 --> Parser Class Initialized
INFO - 2023-05-07 18:18:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:18:13 --> Pagination Class Initialized
INFO - 2023-05-07 18:18:13 --> Form Validation Class Initialized
INFO - 2023-05-07 18:18:13 --> Controller Class Initialized
INFO - 2023-05-07 18:18:13 --> Model Class Initialized
DEBUG - 2023-05-07 18:18:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:18:13 --> Model Class Initialized
DEBUG - 2023-05-07 18:18:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:18:13 --> Model Class Initialized
INFO - 2023-05-07 18:18:13 --> Model Class Initialized
INFO - 2023-05-07 18:18:13 --> Model Class Initialized
INFO - 2023-05-07 18:18:13 --> Model Class Initialized
DEBUG - 2023-05-07 18:18:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:18:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:18:13 --> Model Class Initialized
INFO - 2023-05-07 18:18:13 --> Model Class Initialized
INFO - 2023-05-07 18:18:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-07 18:18:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:18:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:18:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:18:13 --> Model Class Initialized
INFO - 2023-05-07 18:18:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:18:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:18:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:18:13 --> Final output sent to browser
DEBUG - 2023-05-07 18:18:13 --> Total execution time: 0.0765
ERROR - 2023-05-07 18:18:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:18:19 --> Config Class Initialized
INFO - 2023-05-07 18:18:19 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:18:19 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:18:19 --> Utf8 Class Initialized
INFO - 2023-05-07 18:18:19 --> URI Class Initialized
INFO - 2023-05-07 18:18:19 --> Router Class Initialized
INFO - 2023-05-07 18:18:19 --> Output Class Initialized
INFO - 2023-05-07 18:18:19 --> Security Class Initialized
DEBUG - 2023-05-07 18:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:18:19 --> Input Class Initialized
INFO - 2023-05-07 18:18:19 --> Language Class Initialized
INFO - 2023-05-07 18:18:19 --> Loader Class Initialized
INFO - 2023-05-07 18:18:19 --> Helper loaded: url_helper
INFO - 2023-05-07 18:18:19 --> Helper loaded: file_helper
INFO - 2023-05-07 18:18:19 --> Helper loaded: html_helper
INFO - 2023-05-07 18:18:19 --> Helper loaded: text_helper
INFO - 2023-05-07 18:18:19 --> Helper loaded: form_helper
INFO - 2023-05-07 18:18:19 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:18:19 --> Helper loaded: security_helper
INFO - 2023-05-07 18:18:19 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:18:19 --> Database Driver Class Initialized
INFO - 2023-05-07 18:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:18:19 --> Parser Class Initialized
INFO - 2023-05-07 18:18:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:18:19 --> Pagination Class Initialized
INFO - 2023-05-07 18:18:19 --> Form Validation Class Initialized
INFO - 2023-05-07 18:18:19 --> Controller Class Initialized
INFO - 2023-05-07 18:18:19 --> Model Class Initialized
DEBUG - 2023-05-07 18:18:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:18:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:18:19 --> Model Class Initialized
INFO - 2023-05-07 18:18:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-05-07 18:18:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:18:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:18:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:18:19 --> Model Class Initialized
INFO - 2023-05-07 18:18:19 --> Model Class Initialized
INFO - 2023-05-07 18:18:19 --> Model Class Initialized
INFO - 2023-05-07 18:18:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:18:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:18:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:18:19 --> Final output sent to browser
DEBUG - 2023-05-07 18:18:19 --> Total execution time: 0.0636
ERROR - 2023-05-07 18:18:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:18:20 --> Config Class Initialized
INFO - 2023-05-07 18:18:20 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:18:20 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:18:20 --> Utf8 Class Initialized
INFO - 2023-05-07 18:18:20 --> URI Class Initialized
INFO - 2023-05-07 18:18:20 --> Router Class Initialized
INFO - 2023-05-07 18:18:20 --> Output Class Initialized
INFO - 2023-05-07 18:18:20 --> Security Class Initialized
DEBUG - 2023-05-07 18:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:18:20 --> Input Class Initialized
INFO - 2023-05-07 18:18:20 --> Language Class Initialized
INFO - 2023-05-07 18:18:20 --> Loader Class Initialized
INFO - 2023-05-07 18:18:20 --> Helper loaded: url_helper
INFO - 2023-05-07 18:18:20 --> Helper loaded: file_helper
INFO - 2023-05-07 18:18:20 --> Helper loaded: html_helper
INFO - 2023-05-07 18:18:20 --> Helper loaded: text_helper
INFO - 2023-05-07 18:18:20 --> Helper loaded: form_helper
INFO - 2023-05-07 18:18:20 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:18:20 --> Helper loaded: security_helper
INFO - 2023-05-07 18:18:20 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:18:20 --> Database Driver Class Initialized
INFO - 2023-05-07 18:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:18:20 --> Parser Class Initialized
INFO - 2023-05-07 18:18:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:18:20 --> Pagination Class Initialized
INFO - 2023-05-07 18:18:20 --> Form Validation Class Initialized
INFO - 2023-05-07 18:18:20 --> Controller Class Initialized
INFO - 2023-05-07 18:18:20 --> Model Class Initialized
DEBUG - 2023-05-07 18:18:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:18:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:18:20 --> Model Class Initialized
INFO - 2023-05-07 18:18:20 --> Final output sent to browser
DEBUG - 2023-05-07 18:18:20 --> Total execution time: 0.0200
ERROR - 2023-05-07 18:18:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:18:24 --> Config Class Initialized
INFO - 2023-05-07 18:18:24 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:18:24 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:18:24 --> Utf8 Class Initialized
INFO - 2023-05-07 18:18:24 --> URI Class Initialized
DEBUG - 2023-05-07 18:18:24 --> No URI present. Default controller set.
INFO - 2023-05-07 18:18:24 --> Router Class Initialized
INFO - 2023-05-07 18:18:24 --> Output Class Initialized
INFO - 2023-05-07 18:18:24 --> Security Class Initialized
DEBUG - 2023-05-07 18:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:18:24 --> Input Class Initialized
INFO - 2023-05-07 18:18:24 --> Language Class Initialized
INFO - 2023-05-07 18:18:24 --> Loader Class Initialized
INFO - 2023-05-07 18:18:24 --> Helper loaded: url_helper
INFO - 2023-05-07 18:18:24 --> Helper loaded: file_helper
INFO - 2023-05-07 18:18:24 --> Helper loaded: html_helper
INFO - 2023-05-07 18:18:24 --> Helper loaded: text_helper
INFO - 2023-05-07 18:18:24 --> Helper loaded: form_helper
INFO - 2023-05-07 18:18:24 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:18:24 --> Helper loaded: security_helper
INFO - 2023-05-07 18:18:24 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:18:24 --> Database Driver Class Initialized
INFO - 2023-05-07 18:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:18:24 --> Parser Class Initialized
INFO - 2023-05-07 18:18:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:18:24 --> Pagination Class Initialized
INFO - 2023-05-07 18:18:24 --> Form Validation Class Initialized
INFO - 2023-05-07 18:18:24 --> Controller Class Initialized
INFO - 2023-05-07 18:18:24 --> Model Class Initialized
DEBUG - 2023-05-07 18:18:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:18:24 --> Model Class Initialized
DEBUG - 2023-05-07 18:18:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:18:24 --> Model Class Initialized
INFO - 2023-05-07 18:18:24 --> Model Class Initialized
INFO - 2023-05-07 18:18:24 --> Model Class Initialized
INFO - 2023-05-07 18:18:24 --> Model Class Initialized
DEBUG - 2023-05-07 18:18:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:18:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:18:24 --> Model Class Initialized
INFO - 2023-05-07 18:18:24 --> Model Class Initialized
INFO - 2023-05-07 18:18:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-07 18:18:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:18:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:18:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:18:24 --> Model Class Initialized
INFO - 2023-05-07 18:18:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:18:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:18:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:18:24 --> Final output sent to browser
DEBUG - 2023-05-07 18:18:24 --> Total execution time: 0.0701
ERROR - 2023-05-07 18:18:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:18:39 --> Config Class Initialized
INFO - 2023-05-07 18:18:39 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:18:39 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:18:39 --> Utf8 Class Initialized
INFO - 2023-05-07 18:18:39 --> URI Class Initialized
INFO - 2023-05-07 18:18:39 --> Router Class Initialized
INFO - 2023-05-07 18:18:39 --> Output Class Initialized
INFO - 2023-05-07 18:18:39 --> Security Class Initialized
DEBUG - 2023-05-07 18:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:18:39 --> Input Class Initialized
INFO - 2023-05-07 18:18:39 --> Language Class Initialized
INFO - 2023-05-07 18:18:39 --> Loader Class Initialized
INFO - 2023-05-07 18:18:39 --> Helper loaded: url_helper
INFO - 2023-05-07 18:18:39 --> Helper loaded: file_helper
INFO - 2023-05-07 18:18:39 --> Helper loaded: html_helper
INFO - 2023-05-07 18:18:39 --> Helper loaded: text_helper
INFO - 2023-05-07 18:18:39 --> Helper loaded: form_helper
INFO - 2023-05-07 18:18:39 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:18:39 --> Helper loaded: security_helper
INFO - 2023-05-07 18:18:39 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:18:39 --> Database Driver Class Initialized
INFO - 2023-05-07 18:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:18:39 --> Parser Class Initialized
INFO - 2023-05-07 18:18:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:18:39 --> Pagination Class Initialized
INFO - 2023-05-07 18:18:39 --> Form Validation Class Initialized
INFO - 2023-05-07 18:18:39 --> Controller Class Initialized
INFO - 2023-05-07 18:18:39 --> Model Class Initialized
DEBUG - 2023-05-07 18:18:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:18:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:18:39 --> Model Class Initialized
INFO - 2023-05-07 18:18:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-05-07 18:18:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:18:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:18:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:18:39 --> Model Class Initialized
INFO - 2023-05-07 18:18:39 --> Model Class Initialized
INFO - 2023-05-07 18:18:39 --> Model Class Initialized
INFO - 2023-05-07 18:18:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:18:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:18:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:18:39 --> Final output sent to browser
DEBUG - 2023-05-07 18:18:39 --> Total execution time: 0.0619
ERROR - 2023-05-07 18:18:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:18:40 --> Config Class Initialized
INFO - 2023-05-07 18:18:40 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:18:40 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:18:40 --> Utf8 Class Initialized
INFO - 2023-05-07 18:18:40 --> URI Class Initialized
INFO - 2023-05-07 18:18:40 --> Router Class Initialized
INFO - 2023-05-07 18:18:40 --> Output Class Initialized
INFO - 2023-05-07 18:18:40 --> Security Class Initialized
DEBUG - 2023-05-07 18:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:18:40 --> Input Class Initialized
INFO - 2023-05-07 18:18:40 --> Language Class Initialized
INFO - 2023-05-07 18:18:40 --> Loader Class Initialized
INFO - 2023-05-07 18:18:40 --> Helper loaded: url_helper
INFO - 2023-05-07 18:18:40 --> Helper loaded: file_helper
INFO - 2023-05-07 18:18:40 --> Helper loaded: html_helper
INFO - 2023-05-07 18:18:40 --> Helper loaded: text_helper
INFO - 2023-05-07 18:18:40 --> Helper loaded: form_helper
INFO - 2023-05-07 18:18:40 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:18:40 --> Helper loaded: security_helper
INFO - 2023-05-07 18:18:40 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:18:40 --> Database Driver Class Initialized
INFO - 2023-05-07 18:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:18:40 --> Parser Class Initialized
INFO - 2023-05-07 18:18:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:18:40 --> Pagination Class Initialized
INFO - 2023-05-07 18:18:40 --> Form Validation Class Initialized
INFO - 2023-05-07 18:18:40 --> Controller Class Initialized
INFO - 2023-05-07 18:18:40 --> Model Class Initialized
DEBUG - 2023-05-07 18:18:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:18:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:18:40 --> Model Class Initialized
INFO - 2023-05-07 18:18:40 --> Final output sent to browser
DEBUG - 2023-05-07 18:18:40 --> Total execution time: 0.0195
ERROR - 2023-05-07 18:18:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:18:45 --> Config Class Initialized
INFO - 2023-05-07 18:18:45 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:18:45 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:18:45 --> Utf8 Class Initialized
INFO - 2023-05-07 18:18:45 --> URI Class Initialized
INFO - 2023-05-07 18:18:45 --> Router Class Initialized
INFO - 2023-05-07 18:18:45 --> Output Class Initialized
INFO - 2023-05-07 18:18:45 --> Security Class Initialized
DEBUG - 2023-05-07 18:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:18:45 --> Input Class Initialized
INFO - 2023-05-07 18:18:45 --> Language Class Initialized
INFO - 2023-05-07 18:18:45 --> Loader Class Initialized
INFO - 2023-05-07 18:18:45 --> Helper loaded: url_helper
INFO - 2023-05-07 18:18:45 --> Helper loaded: file_helper
INFO - 2023-05-07 18:18:45 --> Helper loaded: html_helper
INFO - 2023-05-07 18:18:45 --> Helper loaded: text_helper
INFO - 2023-05-07 18:18:45 --> Helper loaded: form_helper
INFO - 2023-05-07 18:18:45 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:18:45 --> Helper loaded: security_helper
INFO - 2023-05-07 18:18:45 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:18:45 --> Database Driver Class Initialized
INFO - 2023-05-07 18:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:18:45 --> Parser Class Initialized
INFO - 2023-05-07 18:18:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:18:45 --> Pagination Class Initialized
INFO - 2023-05-07 18:18:45 --> Form Validation Class Initialized
INFO - 2023-05-07 18:18:45 --> Controller Class Initialized
INFO - 2023-05-07 18:18:45 --> Model Class Initialized
DEBUG - 2023-05-07 18:18:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:18:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:18:45 --> Model Class Initialized
INFO - 2023-05-07 18:18:45 --> Final output sent to browser
DEBUG - 2023-05-07 18:18:45 --> Total execution time: 0.0227
ERROR - 2023-05-07 18:19:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:19:12 --> Config Class Initialized
INFO - 2023-05-07 18:19:12 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:19:12 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:19:12 --> Utf8 Class Initialized
INFO - 2023-05-07 18:19:12 --> URI Class Initialized
INFO - 2023-05-07 18:19:12 --> Router Class Initialized
INFO - 2023-05-07 18:19:12 --> Output Class Initialized
INFO - 2023-05-07 18:19:12 --> Security Class Initialized
DEBUG - 2023-05-07 18:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:19:12 --> Input Class Initialized
INFO - 2023-05-07 18:19:12 --> Language Class Initialized
INFO - 2023-05-07 18:19:12 --> Loader Class Initialized
INFO - 2023-05-07 18:19:12 --> Helper loaded: url_helper
INFO - 2023-05-07 18:19:12 --> Helper loaded: file_helper
INFO - 2023-05-07 18:19:12 --> Helper loaded: html_helper
INFO - 2023-05-07 18:19:12 --> Helper loaded: text_helper
INFO - 2023-05-07 18:19:12 --> Helper loaded: form_helper
INFO - 2023-05-07 18:19:12 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:19:12 --> Helper loaded: security_helper
INFO - 2023-05-07 18:19:12 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:19:12 --> Database Driver Class Initialized
INFO - 2023-05-07 18:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:19:12 --> Parser Class Initialized
INFO - 2023-05-07 18:19:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:19:12 --> Pagination Class Initialized
INFO - 2023-05-07 18:19:12 --> Form Validation Class Initialized
INFO - 2023-05-07 18:19:12 --> Controller Class Initialized
INFO - 2023-05-07 18:19:12 --> Model Class Initialized
INFO - 2023-05-07 18:19:12 --> Model Class Initialized
INFO - 2023-05-07 18:19:12 --> Model Class Initialized
INFO - 2023-05-07 18:19:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report_batch_wise.php
DEBUG - 2023-05-07 18:19:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:19:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:19:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:19:12 --> Model Class Initialized
INFO - 2023-05-07 18:19:12 --> Model Class Initialized
INFO - 2023-05-07 18:19:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:19:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:19:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:19:12 --> Final output sent to browser
DEBUG - 2023-05-07 18:19:12 --> Total execution time: 0.1209
ERROR - 2023-05-07 18:19:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:19:13 --> Config Class Initialized
INFO - 2023-05-07 18:19:13 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:19:13 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:19:13 --> Utf8 Class Initialized
INFO - 2023-05-07 18:19:13 --> URI Class Initialized
INFO - 2023-05-07 18:19:13 --> Router Class Initialized
INFO - 2023-05-07 18:19:13 --> Output Class Initialized
INFO - 2023-05-07 18:19:13 --> Security Class Initialized
DEBUG - 2023-05-07 18:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:19:13 --> Input Class Initialized
INFO - 2023-05-07 18:19:13 --> Language Class Initialized
INFO - 2023-05-07 18:19:13 --> Loader Class Initialized
INFO - 2023-05-07 18:19:13 --> Helper loaded: url_helper
INFO - 2023-05-07 18:19:13 --> Helper loaded: file_helper
INFO - 2023-05-07 18:19:13 --> Helper loaded: html_helper
INFO - 2023-05-07 18:19:13 --> Helper loaded: text_helper
INFO - 2023-05-07 18:19:13 --> Helper loaded: form_helper
INFO - 2023-05-07 18:19:13 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:19:13 --> Helper loaded: security_helper
INFO - 2023-05-07 18:19:13 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:19:13 --> Database Driver Class Initialized
INFO - 2023-05-07 18:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:19:13 --> Parser Class Initialized
INFO - 2023-05-07 18:19:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:19:13 --> Pagination Class Initialized
INFO - 2023-05-07 18:19:13 --> Form Validation Class Initialized
INFO - 2023-05-07 18:19:13 --> Controller Class Initialized
INFO - 2023-05-07 18:19:13 --> Model Class Initialized
INFO - 2023-05-07 18:19:13 --> Model Class Initialized
INFO - 2023-05-07 18:19:13 --> Final output sent to browser
DEBUG - 2023-05-07 18:19:13 --> Total execution time: 0.0221
ERROR - 2023-05-07 18:19:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:19:25 --> Config Class Initialized
INFO - 2023-05-07 18:19:25 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:19:25 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:19:25 --> Utf8 Class Initialized
INFO - 2023-05-07 18:19:25 --> URI Class Initialized
INFO - 2023-05-07 18:19:25 --> Router Class Initialized
INFO - 2023-05-07 18:19:25 --> Output Class Initialized
INFO - 2023-05-07 18:19:25 --> Security Class Initialized
DEBUG - 2023-05-07 18:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:19:25 --> Input Class Initialized
INFO - 2023-05-07 18:19:25 --> Language Class Initialized
INFO - 2023-05-07 18:19:25 --> Loader Class Initialized
INFO - 2023-05-07 18:19:25 --> Helper loaded: url_helper
INFO - 2023-05-07 18:19:25 --> Helper loaded: file_helper
INFO - 2023-05-07 18:19:25 --> Helper loaded: html_helper
INFO - 2023-05-07 18:19:25 --> Helper loaded: text_helper
INFO - 2023-05-07 18:19:25 --> Helper loaded: form_helper
INFO - 2023-05-07 18:19:25 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:19:25 --> Helper loaded: security_helper
INFO - 2023-05-07 18:19:25 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:19:25 --> Database Driver Class Initialized
INFO - 2023-05-07 18:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:19:25 --> Parser Class Initialized
INFO - 2023-05-07 18:19:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:19:25 --> Pagination Class Initialized
INFO - 2023-05-07 18:19:25 --> Form Validation Class Initialized
INFO - 2023-05-07 18:19:25 --> Controller Class Initialized
DEBUG - 2023-05-07 18:19:26 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:19:26 --> Model Class Initialized
INFO - 2023-05-07 18:19:26 --> Model Class Initialized
INFO - 2023-05-07 18:19:26 --> Model Class Initialized
INFO - 2023-05-07 18:19:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product_details.php
DEBUG - 2023-05-07 18:19:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:19:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:19:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:19:26 --> Model Class Initialized
INFO - 2023-05-07 18:19:26 --> Model Class Initialized
INFO - 2023-05-07 18:19:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:19:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:19:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:19:26 --> Final output sent to browser
DEBUG - 2023-05-07 18:19:26 --> Total execution time: 0.1577
ERROR - 2023-05-07 18:19:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:19:33 --> Config Class Initialized
INFO - 2023-05-07 18:19:33 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:19:33 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:19:33 --> Utf8 Class Initialized
INFO - 2023-05-07 18:19:33 --> URI Class Initialized
INFO - 2023-05-07 18:19:33 --> Router Class Initialized
INFO - 2023-05-07 18:19:33 --> Output Class Initialized
INFO - 2023-05-07 18:19:33 --> Security Class Initialized
DEBUG - 2023-05-07 18:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:19:33 --> Input Class Initialized
INFO - 2023-05-07 18:19:33 --> Language Class Initialized
INFO - 2023-05-07 18:19:33 --> Loader Class Initialized
INFO - 2023-05-07 18:19:33 --> Helper loaded: url_helper
INFO - 2023-05-07 18:19:33 --> Helper loaded: file_helper
INFO - 2023-05-07 18:19:33 --> Helper loaded: html_helper
INFO - 2023-05-07 18:19:33 --> Helper loaded: text_helper
INFO - 2023-05-07 18:19:33 --> Helper loaded: form_helper
INFO - 2023-05-07 18:19:33 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:19:33 --> Helper loaded: security_helper
INFO - 2023-05-07 18:19:33 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:19:33 --> Database Driver Class Initialized
INFO - 2023-05-07 18:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:19:33 --> Parser Class Initialized
INFO - 2023-05-07 18:19:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:19:33 --> Pagination Class Initialized
INFO - 2023-05-07 18:19:33 --> Form Validation Class Initialized
INFO - 2023-05-07 18:19:33 --> Controller Class Initialized
INFO - 2023-05-07 18:19:33 --> Model Class Initialized
INFO - 2023-05-07 18:19:33 --> Model Class Initialized
INFO - 2023-05-07 18:19:33 --> Model Class Initialized
INFO - 2023-05-07 18:19:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report_batch_wise.php
DEBUG - 2023-05-07 18:19:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:19:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:19:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:19:33 --> Model Class Initialized
INFO - 2023-05-07 18:19:33 --> Model Class Initialized
INFO - 2023-05-07 18:19:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:19:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:19:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:19:34 --> Final output sent to browser
DEBUG - 2023-05-07 18:19:34 --> Total execution time: 0.1205
ERROR - 2023-05-07 18:19:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:19:34 --> Config Class Initialized
INFO - 2023-05-07 18:19:34 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:19:34 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:19:34 --> Utf8 Class Initialized
INFO - 2023-05-07 18:19:34 --> URI Class Initialized
INFO - 2023-05-07 18:19:34 --> Router Class Initialized
INFO - 2023-05-07 18:19:34 --> Output Class Initialized
INFO - 2023-05-07 18:19:34 --> Security Class Initialized
DEBUG - 2023-05-07 18:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:19:34 --> Input Class Initialized
INFO - 2023-05-07 18:19:34 --> Language Class Initialized
INFO - 2023-05-07 18:19:34 --> Loader Class Initialized
INFO - 2023-05-07 18:19:34 --> Helper loaded: url_helper
INFO - 2023-05-07 18:19:34 --> Helper loaded: file_helper
INFO - 2023-05-07 18:19:34 --> Helper loaded: html_helper
INFO - 2023-05-07 18:19:34 --> Helper loaded: text_helper
INFO - 2023-05-07 18:19:34 --> Helper loaded: form_helper
INFO - 2023-05-07 18:19:34 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:19:34 --> Helper loaded: security_helper
INFO - 2023-05-07 18:19:34 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:19:34 --> Database Driver Class Initialized
INFO - 2023-05-07 18:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:19:34 --> Parser Class Initialized
INFO - 2023-05-07 18:19:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:19:34 --> Pagination Class Initialized
INFO - 2023-05-07 18:19:34 --> Form Validation Class Initialized
INFO - 2023-05-07 18:19:34 --> Controller Class Initialized
INFO - 2023-05-07 18:19:34 --> Model Class Initialized
INFO - 2023-05-07 18:19:34 --> Model Class Initialized
INFO - 2023-05-07 18:19:34 --> Final output sent to browser
DEBUG - 2023-05-07 18:19:34 --> Total execution time: 0.0212
ERROR - 2023-05-07 18:19:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:19:47 --> Config Class Initialized
INFO - 2023-05-07 18:19:47 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:19:47 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:19:47 --> Utf8 Class Initialized
INFO - 2023-05-07 18:19:47 --> URI Class Initialized
INFO - 2023-05-07 18:19:47 --> Router Class Initialized
INFO - 2023-05-07 18:19:47 --> Output Class Initialized
INFO - 2023-05-07 18:19:47 --> Security Class Initialized
DEBUG - 2023-05-07 18:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:19:47 --> Input Class Initialized
INFO - 2023-05-07 18:19:47 --> Language Class Initialized
INFO - 2023-05-07 18:19:47 --> Loader Class Initialized
INFO - 2023-05-07 18:19:47 --> Helper loaded: url_helper
INFO - 2023-05-07 18:19:47 --> Helper loaded: file_helper
INFO - 2023-05-07 18:19:47 --> Helper loaded: html_helper
INFO - 2023-05-07 18:19:47 --> Helper loaded: text_helper
INFO - 2023-05-07 18:19:47 --> Helper loaded: form_helper
INFO - 2023-05-07 18:19:47 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:19:47 --> Helper loaded: security_helper
INFO - 2023-05-07 18:19:47 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:19:47 --> Database Driver Class Initialized
INFO - 2023-05-07 18:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:19:47 --> Parser Class Initialized
INFO - 2023-05-07 18:19:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:19:47 --> Pagination Class Initialized
INFO - 2023-05-07 18:19:47 --> Form Validation Class Initialized
INFO - 2023-05-07 18:19:47 --> Controller Class Initialized
INFO - 2023-05-07 18:19:47 --> Model Class Initialized
DEBUG - 2023-05-07 18:19:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:19:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:19:47 --> Model Class Initialized
DEBUG - 2023-05-07 18:19:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:19:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/add_stockrequest_form.php
DEBUG - 2023-05-07 18:19:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:19:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:19:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:19:47 --> Model Class Initialized
INFO - 2023-05-07 18:19:47 --> Model Class Initialized
INFO - 2023-05-07 18:19:47 --> Model Class Initialized
INFO - 2023-05-07 18:19:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:19:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:19:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:19:47 --> Final output sent to browser
DEBUG - 2023-05-07 18:19:47 --> Total execution time: 0.1625
ERROR - 2023-05-07 18:19:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:19:53 --> Config Class Initialized
INFO - 2023-05-07 18:19:53 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:19:53 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:19:53 --> Utf8 Class Initialized
INFO - 2023-05-07 18:19:53 --> URI Class Initialized
INFO - 2023-05-07 18:19:53 --> Router Class Initialized
INFO - 2023-05-07 18:19:53 --> Output Class Initialized
INFO - 2023-05-07 18:19:53 --> Security Class Initialized
DEBUG - 2023-05-07 18:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:19:53 --> Input Class Initialized
INFO - 2023-05-07 18:19:53 --> Language Class Initialized
INFO - 2023-05-07 18:19:53 --> Loader Class Initialized
INFO - 2023-05-07 18:19:53 --> Helper loaded: url_helper
INFO - 2023-05-07 18:19:53 --> Helper loaded: file_helper
INFO - 2023-05-07 18:19:53 --> Helper loaded: html_helper
INFO - 2023-05-07 18:19:53 --> Helper loaded: text_helper
INFO - 2023-05-07 18:19:53 --> Helper loaded: form_helper
INFO - 2023-05-07 18:19:53 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:19:53 --> Helper loaded: security_helper
INFO - 2023-05-07 18:19:53 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:19:53 --> Database Driver Class Initialized
INFO - 2023-05-07 18:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:19:53 --> Parser Class Initialized
INFO - 2023-05-07 18:19:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:19:53 --> Pagination Class Initialized
INFO - 2023-05-07 18:19:53 --> Form Validation Class Initialized
INFO - 2023-05-07 18:19:53 --> Controller Class Initialized
INFO - 2023-05-07 18:19:53 --> Model Class Initialized
INFO - 2023-05-07 18:19:53 --> Final output sent to browser
DEBUG - 2023-05-07 18:19:53 --> Total execution time: 0.0142
ERROR - 2023-05-07 18:19:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:19:54 --> Config Class Initialized
INFO - 2023-05-07 18:19:54 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:19:54 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:19:54 --> Utf8 Class Initialized
INFO - 2023-05-07 18:19:54 --> URI Class Initialized
INFO - 2023-05-07 18:19:54 --> Router Class Initialized
INFO - 2023-05-07 18:19:54 --> Output Class Initialized
INFO - 2023-05-07 18:19:54 --> Security Class Initialized
DEBUG - 2023-05-07 18:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:19:54 --> Input Class Initialized
INFO - 2023-05-07 18:19:54 --> Language Class Initialized
INFO - 2023-05-07 18:19:54 --> Loader Class Initialized
INFO - 2023-05-07 18:19:54 --> Helper loaded: url_helper
INFO - 2023-05-07 18:19:54 --> Helper loaded: file_helper
INFO - 2023-05-07 18:19:54 --> Helper loaded: html_helper
INFO - 2023-05-07 18:19:54 --> Helper loaded: text_helper
INFO - 2023-05-07 18:19:54 --> Helper loaded: form_helper
INFO - 2023-05-07 18:19:54 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:19:54 --> Helper loaded: security_helper
INFO - 2023-05-07 18:19:54 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:19:54 --> Database Driver Class Initialized
INFO - 2023-05-07 18:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:19:54 --> Parser Class Initialized
INFO - 2023-05-07 18:19:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:19:54 --> Pagination Class Initialized
INFO - 2023-05-07 18:19:54 --> Form Validation Class Initialized
INFO - 2023-05-07 18:19:54 --> Controller Class Initialized
INFO - 2023-05-07 18:19:54 --> Model Class Initialized
INFO - 2023-05-07 18:19:54 --> Final output sent to browser
DEBUG - 2023-05-07 18:19:54 --> Total execution time: 0.0125
ERROR - 2023-05-07 18:19:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:19:54 --> Config Class Initialized
INFO - 2023-05-07 18:19:54 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:19:54 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:19:54 --> Utf8 Class Initialized
INFO - 2023-05-07 18:19:54 --> URI Class Initialized
INFO - 2023-05-07 18:19:54 --> Router Class Initialized
INFO - 2023-05-07 18:19:54 --> Output Class Initialized
INFO - 2023-05-07 18:19:54 --> Security Class Initialized
DEBUG - 2023-05-07 18:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:19:54 --> Input Class Initialized
INFO - 2023-05-07 18:19:54 --> Language Class Initialized
INFO - 2023-05-07 18:19:54 --> Loader Class Initialized
INFO - 2023-05-07 18:19:54 --> Helper loaded: url_helper
INFO - 2023-05-07 18:19:54 --> Helper loaded: file_helper
INFO - 2023-05-07 18:19:54 --> Helper loaded: html_helper
INFO - 2023-05-07 18:19:54 --> Helper loaded: text_helper
INFO - 2023-05-07 18:19:54 --> Helper loaded: form_helper
INFO - 2023-05-07 18:19:54 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:19:54 --> Helper loaded: security_helper
INFO - 2023-05-07 18:19:54 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:19:54 --> Database Driver Class Initialized
INFO - 2023-05-07 18:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:19:54 --> Parser Class Initialized
INFO - 2023-05-07 18:19:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:19:54 --> Pagination Class Initialized
INFO - 2023-05-07 18:19:54 --> Form Validation Class Initialized
INFO - 2023-05-07 18:19:54 --> Controller Class Initialized
INFO - 2023-05-07 18:19:54 --> Model Class Initialized
INFO - 2023-05-07 18:19:54 --> Final output sent to browser
DEBUG - 2023-05-07 18:19:54 --> Total execution time: 0.0133
ERROR - 2023-05-07 18:19:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:19:55 --> Config Class Initialized
INFO - 2023-05-07 18:19:55 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:19:55 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:19:55 --> Utf8 Class Initialized
INFO - 2023-05-07 18:19:55 --> URI Class Initialized
INFO - 2023-05-07 18:19:55 --> Router Class Initialized
INFO - 2023-05-07 18:19:55 --> Output Class Initialized
INFO - 2023-05-07 18:19:55 --> Security Class Initialized
DEBUG - 2023-05-07 18:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:19:55 --> Input Class Initialized
INFO - 2023-05-07 18:19:55 --> Language Class Initialized
INFO - 2023-05-07 18:19:55 --> Loader Class Initialized
INFO - 2023-05-07 18:19:55 --> Helper loaded: url_helper
INFO - 2023-05-07 18:19:55 --> Helper loaded: file_helper
INFO - 2023-05-07 18:19:55 --> Helper loaded: html_helper
INFO - 2023-05-07 18:19:55 --> Helper loaded: text_helper
INFO - 2023-05-07 18:19:55 --> Helper loaded: form_helper
INFO - 2023-05-07 18:19:55 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:19:55 --> Helper loaded: security_helper
INFO - 2023-05-07 18:19:55 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:19:55 --> Database Driver Class Initialized
INFO - 2023-05-07 18:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:19:55 --> Parser Class Initialized
INFO - 2023-05-07 18:19:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:19:55 --> Pagination Class Initialized
INFO - 2023-05-07 18:19:55 --> Form Validation Class Initialized
INFO - 2023-05-07 18:19:55 --> Controller Class Initialized
INFO - 2023-05-07 18:19:55 --> Model Class Initialized
INFO - 2023-05-07 18:19:55 --> Final output sent to browser
DEBUG - 2023-05-07 18:19:55 --> Total execution time: 0.0128
ERROR - 2023-05-07 18:20:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:20:01 --> Config Class Initialized
INFO - 2023-05-07 18:20:01 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:20:01 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:20:01 --> Utf8 Class Initialized
INFO - 2023-05-07 18:20:01 --> URI Class Initialized
INFO - 2023-05-07 18:20:01 --> Router Class Initialized
INFO - 2023-05-07 18:20:01 --> Output Class Initialized
INFO - 2023-05-07 18:20:01 --> Security Class Initialized
DEBUG - 2023-05-07 18:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:20:01 --> Input Class Initialized
INFO - 2023-05-07 18:20:01 --> Language Class Initialized
INFO - 2023-05-07 18:20:01 --> Loader Class Initialized
INFO - 2023-05-07 18:20:01 --> Helper loaded: url_helper
INFO - 2023-05-07 18:20:01 --> Helper loaded: file_helper
INFO - 2023-05-07 18:20:01 --> Helper loaded: html_helper
INFO - 2023-05-07 18:20:01 --> Helper loaded: text_helper
INFO - 2023-05-07 18:20:01 --> Helper loaded: form_helper
INFO - 2023-05-07 18:20:01 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:20:01 --> Helper loaded: security_helper
INFO - 2023-05-07 18:20:01 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:20:01 --> Database Driver Class Initialized
INFO - 2023-05-07 18:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:20:01 --> Parser Class Initialized
INFO - 2023-05-07 18:20:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:20:01 --> Pagination Class Initialized
INFO - 2023-05-07 18:20:01 --> Form Validation Class Initialized
INFO - 2023-05-07 18:20:01 --> Controller Class Initialized
INFO - 2023-05-07 18:20:01 --> Model Class Initialized
DEBUG - 2023-05-07 18:20:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:20:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:20:01 --> Model Class Initialized
DEBUG - 2023-05-07 18:20:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:20:01 --> Model Class Initialized
INFO - 2023-05-07 18:20:01 --> Final output sent to browser
DEBUG - 2023-05-07 18:20:01 --> Total execution time: 0.0178
ERROR - 2023-05-07 18:20:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:20:03 --> Config Class Initialized
INFO - 2023-05-07 18:20:03 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:20:03 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:20:03 --> Utf8 Class Initialized
INFO - 2023-05-07 18:20:03 --> URI Class Initialized
INFO - 2023-05-07 18:20:03 --> Router Class Initialized
INFO - 2023-05-07 18:20:03 --> Output Class Initialized
INFO - 2023-05-07 18:20:03 --> Security Class Initialized
DEBUG - 2023-05-07 18:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:20:03 --> Input Class Initialized
INFO - 2023-05-07 18:20:03 --> Language Class Initialized
INFO - 2023-05-07 18:20:03 --> Loader Class Initialized
INFO - 2023-05-07 18:20:03 --> Helper loaded: url_helper
INFO - 2023-05-07 18:20:03 --> Helper loaded: file_helper
INFO - 2023-05-07 18:20:03 --> Helper loaded: html_helper
INFO - 2023-05-07 18:20:03 --> Helper loaded: text_helper
INFO - 2023-05-07 18:20:03 --> Helper loaded: form_helper
INFO - 2023-05-07 18:20:03 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:20:03 --> Helper loaded: security_helper
INFO - 2023-05-07 18:20:03 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:20:03 --> Database Driver Class Initialized
INFO - 2023-05-07 18:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:20:03 --> Parser Class Initialized
INFO - 2023-05-07 18:20:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:20:03 --> Pagination Class Initialized
INFO - 2023-05-07 18:20:03 --> Form Validation Class Initialized
INFO - 2023-05-07 18:20:03 --> Controller Class Initialized
INFO - 2023-05-07 18:20:03 --> Model Class Initialized
DEBUG - 2023-05-07 18:20:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:20:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:20:03 --> Model Class Initialized
DEBUG - 2023-05-07 18:20:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:20:03 --> Model Class Initialized
INFO - 2023-05-07 18:20:03 --> Model Class Initialized
INFO - 2023-05-07 18:20:03 --> Final output sent to browser
DEBUG - 2023-05-07 18:20:03 --> Total execution time: 0.0201
ERROR - 2023-05-07 18:20:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:20:04 --> Config Class Initialized
INFO - 2023-05-07 18:20:04 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:20:04 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:20:04 --> Utf8 Class Initialized
INFO - 2023-05-07 18:20:04 --> URI Class Initialized
INFO - 2023-05-07 18:20:04 --> Router Class Initialized
INFO - 2023-05-07 18:20:04 --> Output Class Initialized
INFO - 2023-05-07 18:20:04 --> Security Class Initialized
DEBUG - 2023-05-07 18:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:20:04 --> Input Class Initialized
INFO - 2023-05-07 18:20:04 --> Language Class Initialized
INFO - 2023-05-07 18:20:04 --> Loader Class Initialized
INFO - 2023-05-07 18:20:04 --> Helper loaded: url_helper
INFO - 2023-05-07 18:20:04 --> Helper loaded: file_helper
INFO - 2023-05-07 18:20:04 --> Helper loaded: html_helper
INFO - 2023-05-07 18:20:04 --> Helper loaded: text_helper
INFO - 2023-05-07 18:20:04 --> Helper loaded: form_helper
INFO - 2023-05-07 18:20:04 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:20:04 --> Helper loaded: security_helper
INFO - 2023-05-07 18:20:04 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:20:04 --> Database Driver Class Initialized
INFO - 2023-05-07 18:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:20:04 --> Parser Class Initialized
INFO - 2023-05-07 18:20:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:20:04 --> Pagination Class Initialized
INFO - 2023-05-07 18:20:04 --> Form Validation Class Initialized
INFO - 2023-05-07 18:20:04 --> Controller Class Initialized
INFO - 2023-05-07 18:20:04 --> Model Class Initialized
DEBUG - 2023-05-07 18:20:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:20:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:20:04 --> Model Class Initialized
DEBUG - 2023-05-07 18:20:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:20:04 --> Model Class Initialized
INFO - 2023-05-07 18:20:04 --> Final output sent to browser
DEBUG - 2023-05-07 18:20:04 --> Total execution time: 0.0185
ERROR - 2023-05-07 18:20:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:20:10 --> Config Class Initialized
INFO - 2023-05-07 18:20:10 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:20:10 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:20:10 --> Utf8 Class Initialized
INFO - 2023-05-07 18:20:10 --> URI Class Initialized
INFO - 2023-05-07 18:20:10 --> Router Class Initialized
INFO - 2023-05-07 18:20:10 --> Output Class Initialized
INFO - 2023-05-07 18:20:10 --> Security Class Initialized
DEBUG - 2023-05-07 18:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:20:10 --> Input Class Initialized
INFO - 2023-05-07 18:20:10 --> Language Class Initialized
INFO - 2023-05-07 18:20:10 --> Loader Class Initialized
INFO - 2023-05-07 18:20:10 --> Helper loaded: url_helper
INFO - 2023-05-07 18:20:10 --> Helper loaded: file_helper
INFO - 2023-05-07 18:20:10 --> Helper loaded: html_helper
INFO - 2023-05-07 18:20:10 --> Helper loaded: text_helper
INFO - 2023-05-07 18:20:10 --> Helper loaded: form_helper
INFO - 2023-05-07 18:20:10 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:20:10 --> Helper loaded: security_helper
INFO - 2023-05-07 18:20:10 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:20:10 --> Database Driver Class Initialized
INFO - 2023-05-07 18:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:20:10 --> Parser Class Initialized
INFO - 2023-05-07 18:20:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:20:10 --> Pagination Class Initialized
INFO - 2023-05-07 18:20:10 --> Form Validation Class Initialized
INFO - 2023-05-07 18:20:10 --> Controller Class Initialized
INFO - 2023-05-07 18:20:10 --> Model Class Initialized
DEBUG - 2023-05-07 18:20:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:20:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:20:10 --> Model Class Initialized
DEBUG - 2023-05-07 18:20:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:20:10 --> Model Class Initialized
INFO - 2023-05-07 18:20:10 --> Final output sent to browser
DEBUG - 2023-05-07 18:20:10 --> Total execution time: 0.0217
ERROR - 2023-05-07 18:20:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:20:39 --> Config Class Initialized
INFO - 2023-05-07 18:20:39 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:20:39 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:20:39 --> Utf8 Class Initialized
INFO - 2023-05-07 18:20:39 --> URI Class Initialized
INFO - 2023-05-07 18:20:39 --> Router Class Initialized
INFO - 2023-05-07 18:20:39 --> Output Class Initialized
INFO - 2023-05-07 18:20:39 --> Security Class Initialized
DEBUG - 2023-05-07 18:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:20:39 --> Input Class Initialized
INFO - 2023-05-07 18:20:39 --> Language Class Initialized
INFO - 2023-05-07 18:20:39 --> Loader Class Initialized
INFO - 2023-05-07 18:20:39 --> Helper loaded: url_helper
INFO - 2023-05-07 18:20:39 --> Helper loaded: file_helper
INFO - 2023-05-07 18:20:39 --> Helper loaded: html_helper
INFO - 2023-05-07 18:20:39 --> Helper loaded: text_helper
INFO - 2023-05-07 18:20:39 --> Helper loaded: form_helper
INFO - 2023-05-07 18:20:39 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:20:39 --> Helper loaded: security_helper
INFO - 2023-05-07 18:20:39 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:20:39 --> Database Driver Class Initialized
INFO - 2023-05-07 18:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:20:39 --> Parser Class Initialized
INFO - 2023-05-07 18:20:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:20:39 --> Pagination Class Initialized
INFO - 2023-05-07 18:20:39 --> Form Validation Class Initialized
INFO - 2023-05-07 18:20:39 --> Controller Class Initialized
INFO - 2023-05-07 18:20:39 --> Model Class Initialized
DEBUG - 2023-05-07 18:20:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:20:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:20:39 --> Model Class Initialized
INFO - 2023-05-07 18:20:39 --> Email Class Initialized
INFO - 2023-05-07 18:20:39 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-05-07 18:20:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:20:40 --> Config Class Initialized
INFO - 2023-05-07 18:20:40 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:20:40 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:20:40 --> Utf8 Class Initialized
INFO - 2023-05-07 18:20:40 --> URI Class Initialized
INFO - 2023-05-07 18:20:40 --> Router Class Initialized
INFO - 2023-05-07 18:20:40 --> Output Class Initialized
INFO - 2023-05-07 18:20:40 --> Security Class Initialized
DEBUG - 2023-05-07 18:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:20:40 --> Input Class Initialized
INFO - 2023-05-07 18:20:40 --> Language Class Initialized
INFO - 2023-05-07 18:20:40 --> Loader Class Initialized
INFO - 2023-05-07 18:20:40 --> Helper loaded: url_helper
INFO - 2023-05-07 18:20:40 --> Helper loaded: file_helper
INFO - 2023-05-07 18:20:40 --> Helper loaded: html_helper
INFO - 2023-05-07 18:20:40 --> Helper loaded: text_helper
INFO - 2023-05-07 18:20:40 --> Helper loaded: form_helper
INFO - 2023-05-07 18:20:40 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:20:40 --> Helper loaded: security_helper
INFO - 2023-05-07 18:20:40 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:20:40 --> Database Driver Class Initialized
INFO - 2023-05-07 18:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:20:40 --> Parser Class Initialized
INFO - 2023-05-07 18:20:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:20:40 --> Pagination Class Initialized
INFO - 2023-05-07 18:20:40 --> Form Validation Class Initialized
INFO - 2023-05-07 18:20:40 --> Controller Class Initialized
INFO - 2023-05-07 18:20:40 --> Model Class Initialized
DEBUG - 2023-05-07 18:20:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:20:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:20:40 --> Model Class Initialized
DEBUG - 2023-05-07 18:20:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:20:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-05-07 18:20:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:20:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:20:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:20:40 --> Model Class Initialized
INFO - 2023-05-07 18:20:40 --> Model Class Initialized
INFO - 2023-05-07 18:20:40 --> Model Class Initialized
INFO - 2023-05-07 18:20:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:20:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:20:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:20:40 --> Final output sent to browser
DEBUG - 2023-05-07 18:20:40 --> Total execution time: 0.1307
ERROR - 2023-05-07 18:20:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:20:53 --> Config Class Initialized
INFO - 2023-05-07 18:20:53 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:20:53 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:20:53 --> Utf8 Class Initialized
INFO - 2023-05-07 18:20:53 --> URI Class Initialized
INFO - 2023-05-07 18:20:53 --> Router Class Initialized
INFO - 2023-05-07 18:20:53 --> Output Class Initialized
INFO - 2023-05-07 18:20:53 --> Security Class Initialized
DEBUG - 2023-05-07 18:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:20:53 --> Input Class Initialized
INFO - 2023-05-07 18:20:53 --> Language Class Initialized
INFO - 2023-05-07 18:20:53 --> Loader Class Initialized
INFO - 2023-05-07 18:20:53 --> Helper loaded: url_helper
INFO - 2023-05-07 18:20:53 --> Helper loaded: file_helper
INFO - 2023-05-07 18:20:53 --> Helper loaded: html_helper
INFO - 2023-05-07 18:20:53 --> Helper loaded: text_helper
INFO - 2023-05-07 18:20:53 --> Helper loaded: form_helper
INFO - 2023-05-07 18:20:53 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:20:53 --> Helper loaded: security_helper
INFO - 2023-05-07 18:20:53 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:20:53 --> Database Driver Class Initialized
INFO - 2023-05-07 18:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:20:53 --> Parser Class Initialized
INFO - 2023-05-07 18:20:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:20:53 --> Pagination Class Initialized
INFO - 2023-05-07 18:20:53 --> Form Validation Class Initialized
INFO - 2023-05-07 18:20:53 --> Controller Class Initialized
INFO - 2023-05-07 18:20:53 --> Model Class Initialized
DEBUG - 2023-05-07 18:20:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:20:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:20:53 --> Model Class Initialized
INFO - 2023-05-07 18:20:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-05-07 18:20:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:20:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:20:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:20:53 --> Model Class Initialized
INFO - 2023-05-07 18:20:53 --> Model Class Initialized
INFO - 2023-05-07 18:20:53 --> Model Class Initialized
INFO - 2023-05-07 18:20:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:20:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:20:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:20:53 --> Final output sent to browser
DEBUG - 2023-05-07 18:20:53 --> Total execution time: 0.0748
ERROR - 2023-05-07 18:20:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:20:55 --> Config Class Initialized
INFO - 2023-05-07 18:20:55 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:20:55 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:20:55 --> Utf8 Class Initialized
INFO - 2023-05-07 18:20:55 --> URI Class Initialized
INFO - 2023-05-07 18:20:55 --> Router Class Initialized
INFO - 2023-05-07 18:20:55 --> Output Class Initialized
INFO - 2023-05-07 18:20:55 --> Security Class Initialized
DEBUG - 2023-05-07 18:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:20:55 --> Input Class Initialized
INFO - 2023-05-07 18:20:55 --> Language Class Initialized
INFO - 2023-05-07 18:20:55 --> Loader Class Initialized
INFO - 2023-05-07 18:20:55 --> Helper loaded: url_helper
INFO - 2023-05-07 18:20:55 --> Helper loaded: file_helper
INFO - 2023-05-07 18:20:55 --> Helper loaded: html_helper
INFO - 2023-05-07 18:20:55 --> Helper loaded: text_helper
INFO - 2023-05-07 18:20:55 --> Helper loaded: form_helper
INFO - 2023-05-07 18:20:55 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:20:55 --> Helper loaded: security_helper
INFO - 2023-05-07 18:20:55 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:20:55 --> Database Driver Class Initialized
INFO - 2023-05-07 18:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:20:55 --> Parser Class Initialized
INFO - 2023-05-07 18:20:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:20:55 --> Pagination Class Initialized
INFO - 2023-05-07 18:20:55 --> Form Validation Class Initialized
INFO - 2023-05-07 18:20:55 --> Controller Class Initialized
INFO - 2023-05-07 18:20:55 --> Model Class Initialized
DEBUG - 2023-05-07 18:20:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:20:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:20:55 --> Model Class Initialized
INFO - 2023-05-07 18:20:55 --> Final output sent to browser
DEBUG - 2023-05-07 18:20:55 --> Total execution time: 0.0271
ERROR - 2023-05-07 18:20:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:20:58 --> Config Class Initialized
INFO - 2023-05-07 18:20:58 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:20:58 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:20:58 --> Utf8 Class Initialized
INFO - 2023-05-07 18:20:58 --> URI Class Initialized
INFO - 2023-05-07 18:20:58 --> Router Class Initialized
INFO - 2023-05-07 18:20:58 --> Output Class Initialized
INFO - 2023-05-07 18:20:58 --> Security Class Initialized
DEBUG - 2023-05-07 18:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:20:58 --> Input Class Initialized
INFO - 2023-05-07 18:20:58 --> Language Class Initialized
INFO - 2023-05-07 18:20:58 --> Loader Class Initialized
INFO - 2023-05-07 18:20:58 --> Helper loaded: url_helper
INFO - 2023-05-07 18:20:58 --> Helper loaded: file_helper
INFO - 2023-05-07 18:20:58 --> Helper loaded: html_helper
INFO - 2023-05-07 18:20:58 --> Helper loaded: text_helper
INFO - 2023-05-07 18:20:58 --> Helper loaded: form_helper
INFO - 2023-05-07 18:20:58 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:20:58 --> Helper loaded: security_helper
INFO - 2023-05-07 18:20:58 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:20:58 --> Database Driver Class Initialized
INFO - 2023-05-07 18:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:20:58 --> Parser Class Initialized
INFO - 2023-05-07 18:20:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:20:58 --> Pagination Class Initialized
INFO - 2023-05-07 18:20:58 --> Form Validation Class Initialized
INFO - 2023-05-07 18:20:58 --> Controller Class Initialized
INFO - 2023-05-07 18:20:58 --> Model Class Initialized
DEBUG - 2023-05-07 18:20:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:20:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:20:58 --> Model Class Initialized
DEBUG - 2023-05-07 18:20:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:20:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-05-07 18:20:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:20:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:20:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:20:58 --> Model Class Initialized
INFO - 2023-05-07 18:20:58 --> Model Class Initialized
INFO - 2023-05-07 18:20:58 --> Model Class Initialized
INFO - 2023-05-07 18:20:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:20:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:20:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:20:58 --> Final output sent to browser
DEBUG - 2023-05-07 18:20:58 --> Total execution time: 0.0733
ERROR - 2023-05-07 18:21:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:21:01 --> Config Class Initialized
INFO - 2023-05-07 18:21:01 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:21:01 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:21:01 --> Utf8 Class Initialized
INFO - 2023-05-07 18:21:01 --> URI Class Initialized
INFO - 2023-05-07 18:21:01 --> Router Class Initialized
INFO - 2023-05-07 18:21:01 --> Output Class Initialized
INFO - 2023-05-07 18:21:01 --> Security Class Initialized
DEBUG - 2023-05-07 18:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:21:01 --> Input Class Initialized
INFO - 2023-05-07 18:21:01 --> Language Class Initialized
INFO - 2023-05-07 18:21:01 --> Loader Class Initialized
INFO - 2023-05-07 18:21:01 --> Helper loaded: url_helper
INFO - 2023-05-07 18:21:01 --> Helper loaded: file_helper
INFO - 2023-05-07 18:21:01 --> Helper loaded: html_helper
INFO - 2023-05-07 18:21:01 --> Helper loaded: text_helper
INFO - 2023-05-07 18:21:01 --> Helper loaded: form_helper
INFO - 2023-05-07 18:21:01 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:21:01 --> Helper loaded: security_helper
INFO - 2023-05-07 18:21:01 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:21:01 --> Database Driver Class Initialized
INFO - 2023-05-07 18:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:21:01 --> Parser Class Initialized
INFO - 2023-05-07 18:21:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:21:01 --> Pagination Class Initialized
INFO - 2023-05-07 18:21:01 --> Form Validation Class Initialized
INFO - 2023-05-07 18:21:01 --> Controller Class Initialized
INFO - 2023-05-07 18:21:01 --> Final output sent to browser
DEBUG - 2023-05-07 18:21:01 --> Total execution time: 0.0178
ERROR - 2023-05-07 18:21:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:21:04 --> Config Class Initialized
INFO - 2023-05-07 18:21:04 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:21:04 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:21:04 --> Utf8 Class Initialized
INFO - 2023-05-07 18:21:04 --> URI Class Initialized
INFO - 2023-05-07 18:21:04 --> Router Class Initialized
INFO - 2023-05-07 18:21:04 --> Output Class Initialized
INFO - 2023-05-07 18:21:04 --> Security Class Initialized
DEBUG - 2023-05-07 18:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:21:04 --> Input Class Initialized
INFO - 2023-05-07 18:21:04 --> Language Class Initialized
INFO - 2023-05-07 18:21:04 --> Loader Class Initialized
INFO - 2023-05-07 18:21:04 --> Helper loaded: url_helper
INFO - 2023-05-07 18:21:04 --> Helper loaded: file_helper
INFO - 2023-05-07 18:21:04 --> Helper loaded: html_helper
INFO - 2023-05-07 18:21:04 --> Helper loaded: text_helper
INFO - 2023-05-07 18:21:04 --> Helper loaded: form_helper
INFO - 2023-05-07 18:21:04 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:21:04 --> Helper loaded: security_helper
INFO - 2023-05-07 18:21:04 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:21:04 --> Database Driver Class Initialized
INFO - 2023-05-07 18:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:21:04 --> Parser Class Initialized
INFO - 2023-05-07 18:21:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:21:04 --> Pagination Class Initialized
INFO - 2023-05-07 18:21:04 --> Form Validation Class Initialized
INFO - 2023-05-07 18:21:04 --> Controller Class Initialized
INFO - 2023-05-07 18:21:04 --> Model Class Initialized
DEBUG - 2023-05-07 18:21:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:21:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:21:04 --> Model Class Initialized
DEBUG - 2023-05-07 18:21:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:21:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-05-07 18:21:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:21:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:21:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:21:04 --> Model Class Initialized
INFO - 2023-05-07 18:21:04 --> Model Class Initialized
INFO - 2023-05-07 18:21:04 --> Model Class Initialized
INFO - 2023-05-07 18:21:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:21:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:21:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:21:04 --> Final output sent to browser
DEBUG - 2023-05-07 18:21:04 --> Total execution time: 0.0655
ERROR - 2023-05-07 18:21:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:21:09 --> Config Class Initialized
INFO - 2023-05-07 18:21:09 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:21:09 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:21:09 --> Utf8 Class Initialized
INFO - 2023-05-07 18:21:09 --> URI Class Initialized
INFO - 2023-05-07 18:21:09 --> Router Class Initialized
INFO - 2023-05-07 18:21:09 --> Output Class Initialized
INFO - 2023-05-07 18:21:09 --> Security Class Initialized
DEBUG - 2023-05-07 18:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:21:09 --> Input Class Initialized
INFO - 2023-05-07 18:21:09 --> Language Class Initialized
INFO - 2023-05-07 18:21:09 --> Loader Class Initialized
INFO - 2023-05-07 18:21:09 --> Helper loaded: url_helper
INFO - 2023-05-07 18:21:09 --> Helper loaded: file_helper
INFO - 2023-05-07 18:21:09 --> Helper loaded: html_helper
INFO - 2023-05-07 18:21:09 --> Helper loaded: text_helper
INFO - 2023-05-07 18:21:09 --> Helper loaded: form_helper
INFO - 2023-05-07 18:21:09 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:21:09 --> Helper loaded: security_helper
INFO - 2023-05-07 18:21:09 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:21:09 --> Database Driver Class Initialized
INFO - 2023-05-07 18:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:21:09 --> Parser Class Initialized
INFO - 2023-05-07 18:21:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:21:09 --> Pagination Class Initialized
INFO - 2023-05-07 18:21:09 --> Form Validation Class Initialized
INFO - 2023-05-07 18:21:09 --> Controller Class Initialized
INFO - 2023-05-07 18:21:09 --> Model Class Initialized
DEBUG - 2023-05-07 18:21:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:21:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:21:09 --> Model Class Initialized
INFO - 2023-05-07 18:21:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-05-07 18:21:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:21:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:21:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:21:09 --> Model Class Initialized
INFO - 2023-05-07 18:21:09 --> Model Class Initialized
INFO - 2023-05-07 18:21:09 --> Model Class Initialized
INFO - 2023-05-07 18:21:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:21:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:21:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:21:09 --> Final output sent to browser
DEBUG - 2023-05-07 18:21:09 --> Total execution time: 0.0689
ERROR - 2023-05-07 18:21:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:21:09 --> Config Class Initialized
INFO - 2023-05-07 18:21:09 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:21:09 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:21:09 --> Utf8 Class Initialized
INFO - 2023-05-07 18:21:09 --> URI Class Initialized
INFO - 2023-05-07 18:21:09 --> Router Class Initialized
INFO - 2023-05-07 18:21:09 --> Output Class Initialized
INFO - 2023-05-07 18:21:09 --> Security Class Initialized
DEBUG - 2023-05-07 18:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:21:09 --> Input Class Initialized
INFO - 2023-05-07 18:21:09 --> Language Class Initialized
INFO - 2023-05-07 18:21:09 --> Loader Class Initialized
INFO - 2023-05-07 18:21:09 --> Helper loaded: url_helper
INFO - 2023-05-07 18:21:09 --> Helper loaded: file_helper
INFO - 2023-05-07 18:21:09 --> Helper loaded: html_helper
INFO - 2023-05-07 18:21:09 --> Helper loaded: text_helper
INFO - 2023-05-07 18:21:09 --> Helper loaded: form_helper
INFO - 2023-05-07 18:21:09 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:21:09 --> Helper loaded: security_helper
INFO - 2023-05-07 18:21:09 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:21:09 --> Database Driver Class Initialized
INFO - 2023-05-07 18:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:21:09 --> Parser Class Initialized
INFO - 2023-05-07 18:21:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:21:09 --> Pagination Class Initialized
INFO - 2023-05-07 18:21:09 --> Form Validation Class Initialized
INFO - 2023-05-07 18:21:09 --> Controller Class Initialized
INFO - 2023-05-07 18:21:09 --> Model Class Initialized
DEBUG - 2023-05-07 18:21:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:21:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:21:09 --> Model Class Initialized
INFO - 2023-05-07 18:21:09 --> Final output sent to browser
DEBUG - 2023-05-07 18:21:09 --> Total execution time: 0.0205
ERROR - 2023-05-07 18:21:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:21:15 --> Config Class Initialized
INFO - 2023-05-07 18:21:15 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:21:15 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:21:15 --> Utf8 Class Initialized
INFO - 2023-05-07 18:21:15 --> URI Class Initialized
INFO - 2023-05-07 18:21:15 --> Router Class Initialized
INFO - 2023-05-07 18:21:15 --> Output Class Initialized
INFO - 2023-05-07 18:21:15 --> Security Class Initialized
DEBUG - 2023-05-07 18:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:21:15 --> Input Class Initialized
INFO - 2023-05-07 18:21:15 --> Language Class Initialized
INFO - 2023-05-07 18:21:15 --> Loader Class Initialized
INFO - 2023-05-07 18:21:15 --> Helper loaded: url_helper
INFO - 2023-05-07 18:21:15 --> Helper loaded: file_helper
INFO - 2023-05-07 18:21:15 --> Helper loaded: html_helper
INFO - 2023-05-07 18:21:15 --> Helper loaded: text_helper
INFO - 2023-05-07 18:21:15 --> Helper loaded: form_helper
INFO - 2023-05-07 18:21:15 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:21:15 --> Helper loaded: security_helper
INFO - 2023-05-07 18:21:15 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:21:15 --> Database Driver Class Initialized
INFO - 2023-05-07 18:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:21:15 --> Parser Class Initialized
INFO - 2023-05-07 18:21:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:21:15 --> Pagination Class Initialized
INFO - 2023-05-07 18:21:15 --> Form Validation Class Initialized
INFO - 2023-05-07 18:21:15 --> Controller Class Initialized
INFO - 2023-05-07 18:21:15 --> Model Class Initialized
DEBUG - 2023-05-07 18:21:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:21:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:21:15 --> Model Class Initialized
INFO - 2023-05-07 18:21:15 --> Final output sent to browser
DEBUG - 2023-05-07 18:21:15 --> Total execution time: 0.0198
ERROR - 2023-05-07 18:21:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:21:34 --> Config Class Initialized
INFO - 2023-05-07 18:21:34 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:21:34 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:21:34 --> Utf8 Class Initialized
INFO - 2023-05-07 18:21:34 --> URI Class Initialized
INFO - 2023-05-07 18:21:34 --> Router Class Initialized
INFO - 2023-05-07 18:21:34 --> Output Class Initialized
INFO - 2023-05-07 18:21:34 --> Security Class Initialized
DEBUG - 2023-05-07 18:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:21:34 --> Input Class Initialized
INFO - 2023-05-07 18:21:34 --> Language Class Initialized
INFO - 2023-05-07 18:21:34 --> Loader Class Initialized
INFO - 2023-05-07 18:21:34 --> Helper loaded: url_helper
INFO - 2023-05-07 18:21:34 --> Helper loaded: file_helper
INFO - 2023-05-07 18:21:34 --> Helper loaded: html_helper
INFO - 2023-05-07 18:21:34 --> Helper loaded: text_helper
INFO - 2023-05-07 18:21:34 --> Helper loaded: form_helper
INFO - 2023-05-07 18:21:34 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:21:34 --> Helper loaded: security_helper
INFO - 2023-05-07 18:21:34 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:21:34 --> Database Driver Class Initialized
INFO - 2023-05-07 18:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:21:34 --> Parser Class Initialized
INFO - 2023-05-07 18:21:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:21:34 --> Pagination Class Initialized
INFO - 2023-05-07 18:21:34 --> Form Validation Class Initialized
INFO - 2023-05-07 18:21:34 --> Controller Class Initialized
INFO - 2023-05-07 18:21:34 --> Model Class Initialized
DEBUG - 2023-05-07 18:21:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:21:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:21:34 --> Model Class Initialized
DEBUG - 2023-05-07 18:21:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:21:34 --> Model Class Initialized
INFO - 2023-05-07 18:21:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-05-07 18:21:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:21:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:21:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:21:34 --> Model Class Initialized
INFO - 2023-05-07 18:21:34 --> Model Class Initialized
INFO - 2023-05-07 18:21:34 --> Model Class Initialized
INFO - 2023-05-07 18:21:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:21:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:21:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:21:34 --> Final output sent to browser
DEBUG - 2023-05-07 18:21:34 --> Total execution time: 0.1003
ERROR - 2023-05-07 18:21:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:21:37 --> Config Class Initialized
INFO - 2023-05-07 18:21:37 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:21:37 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:21:37 --> Utf8 Class Initialized
INFO - 2023-05-07 18:21:37 --> URI Class Initialized
INFO - 2023-05-07 18:21:37 --> Router Class Initialized
INFO - 2023-05-07 18:21:37 --> Output Class Initialized
INFO - 2023-05-07 18:21:37 --> Security Class Initialized
DEBUG - 2023-05-07 18:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:21:37 --> Input Class Initialized
INFO - 2023-05-07 18:21:37 --> Language Class Initialized
INFO - 2023-05-07 18:21:37 --> Loader Class Initialized
INFO - 2023-05-07 18:21:37 --> Helper loaded: url_helper
INFO - 2023-05-07 18:21:37 --> Helper loaded: file_helper
INFO - 2023-05-07 18:21:37 --> Helper loaded: html_helper
INFO - 2023-05-07 18:21:37 --> Helper loaded: text_helper
INFO - 2023-05-07 18:21:37 --> Helper loaded: form_helper
INFO - 2023-05-07 18:21:37 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:21:37 --> Helper loaded: security_helper
INFO - 2023-05-07 18:21:37 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:21:37 --> Database Driver Class Initialized
INFO - 2023-05-07 18:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:21:37 --> Parser Class Initialized
INFO - 2023-05-07 18:21:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:21:37 --> Pagination Class Initialized
INFO - 2023-05-07 18:21:37 --> Form Validation Class Initialized
INFO - 2023-05-07 18:21:37 --> Controller Class Initialized
INFO - 2023-05-07 18:21:37 --> Model Class Initialized
DEBUG - 2023-05-07 18:21:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:21:37 --> Final output sent to browser
DEBUG - 2023-05-07 18:21:37 --> Total execution time: 0.0147
ERROR - 2023-05-07 18:21:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:21:38 --> Config Class Initialized
INFO - 2023-05-07 18:21:38 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:21:38 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:21:38 --> Utf8 Class Initialized
INFO - 2023-05-07 18:21:38 --> URI Class Initialized
INFO - 2023-05-07 18:21:38 --> Router Class Initialized
INFO - 2023-05-07 18:21:38 --> Output Class Initialized
INFO - 2023-05-07 18:21:38 --> Security Class Initialized
DEBUG - 2023-05-07 18:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:21:38 --> Input Class Initialized
INFO - 2023-05-07 18:21:38 --> Language Class Initialized
INFO - 2023-05-07 18:21:38 --> Loader Class Initialized
INFO - 2023-05-07 18:21:38 --> Helper loaded: url_helper
INFO - 2023-05-07 18:21:38 --> Helper loaded: file_helper
INFO - 2023-05-07 18:21:38 --> Helper loaded: html_helper
INFO - 2023-05-07 18:21:38 --> Helper loaded: text_helper
INFO - 2023-05-07 18:21:38 --> Helper loaded: form_helper
INFO - 2023-05-07 18:21:38 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:21:38 --> Helper loaded: security_helper
INFO - 2023-05-07 18:21:38 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:21:38 --> Database Driver Class Initialized
INFO - 2023-05-07 18:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:21:38 --> Parser Class Initialized
INFO - 2023-05-07 18:21:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:21:38 --> Pagination Class Initialized
INFO - 2023-05-07 18:21:38 --> Form Validation Class Initialized
INFO - 2023-05-07 18:21:38 --> Controller Class Initialized
INFO - 2023-05-07 18:21:38 --> Model Class Initialized
DEBUG - 2023-05-07 18:21:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:21:38 --> Final output sent to browser
DEBUG - 2023-05-07 18:21:38 --> Total execution time: 0.0151
ERROR - 2023-05-07 18:21:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:21:40 --> Config Class Initialized
INFO - 2023-05-07 18:21:40 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:21:40 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:21:40 --> Utf8 Class Initialized
INFO - 2023-05-07 18:21:40 --> URI Class Initialized
INFO - 2023-05-07 18:21:40 --> Router Class Initialized
INFO - 2023-05-07 18:21:40 --> Output Class Initialized
INFO - 2023-05-07 18:21:40 --> Security Class Initialized
DEBUG - 2023-05-07 18:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:21:40 --> Input Class Initialized
INFO - 2023-05-07 18:21:40 --> Language Class Initialized
INFO - 2023-05-07 18:21:40 --> Loader Class Initialized
INFO - 2023-05-07 18:21:40 --> Helper loaded: url_helper
INFO - 2023-05-07 18:21:40 --> Helper loaded: file_helper
INFO - 2023-05-07 18:21:40 --> Helper loaded: html_helper
INFO - 2023-05-07 18:21:40 --> Helper loaded: text_helper
INFO - 2023-05-07 18:21:40 --> Helper loaded: form_helper
INFO - 2023-05-07 18:21:40 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:21:40 --> Helper loaded: security_helper
INFO - 2023-05-07 18:21:40 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:21:40 --> Database Driver Class Initialized
INFO - 2023-05-07 18:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:21:40 --> Parser Class Initialized
INFO - 2023-05-07 18:21:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:21:40 --> Pagination Class Initialized
INFO - 2023-05-07 18:21:40 --> Form Validation Class Initialized
INFO - 2023-05-07 18:21:40 --> Controller Class Initialized
INFO - 2023-05-07 18:21:40 --> Model Class Initialized
DEBUG - 2023-05-07 18:21:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:21:40 --> Final output sent to browser
DEBUG - 2023-05-07 18:21:40 --> Total execution time: 0.0141
ERROR - 2023-05-07 18:21:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:21:41 --> Config Class Initialized
INFO - 2023-05-07 18:21:41 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:21:41 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:21:41 --> Utf8 Class Initialized
INFO - 2023-05-07 18:21:41 --> URI Class Initialized
INFO - 2023-05-07 18:21:41 --> Router Class Initialized
INFO - 2023-05-07 18:21:41 --> Output Class Initialized
INFO - 2023-05-07 18:21:41 --> Security Class Initialized
DEBUG - 2023-05-07 18:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:21:41 --> Input Class Initialized
INFO - 2023-05-07 18:21:41 --> Language Class Initialized
INFO - 2023-05-07 18:21:41 --> Loader Class Initialized
INFO - 2023-05-07 18:21:41 --> Helper loaded: url_helper
INFO - 2023-05-07 18:21:41 --> Helper loaded: file_helper
INFO - 2023-05-07 18:21:41 --> Helper loaded: html_helper
INFO - 2023-05-07 18:21:41 --> Helper loaded: text_helper
INFO - 2023-05-07 18:21:41 --> Helper loaded: form_helper
INFO - 2023-05-07 18:21:41 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:21:41 --> Helper loaded: security_helper
INFO - 2023-05-07 18:21:41 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:21:41 --> Database Driver Class Initialized
INFO - 2023-05-07 18:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:21:41 --> Parser Class Initialized
INFO - 2023-05-07 18:21:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:21:41 --> Pagination Class Initialized
INFO - 2023-05-07 18:21:41 --> Form Validation Class Initialized
INFO - 2023-05-07 18:21:41 --> Controller Class Initialized
INFO - 2023-05-07 18:21:41 --> Model Class Initialized
DEBUG - 2023-05-07 18:21:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:21:41 --> Final output sent to browser
DEBUG - 2023-05-07 18:21:41 --> Total execution time: 0.0150
ERROR - 2023-05-07 18:21:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:21:42 --> Config Class Initialized
INFO - 2023-05-07 18:21:42 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:21:42 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:21:42 --> Utf8 Class Initialized
INFO - 2023-05-07 18:21:42 --> URI Class Initialized
INFO - 2023-05-07 18:21:42 --> Router Class Initialized
INFO - 2023-05-07 18:21:42 --> Output Class Initialized
INFO - 2023-05-07 18:21:42 --> Security Class Initialized
DEBUG - 2023-05-07 18:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:21:42 --> Input Class Initialized
INFO - 2023-05-07 18:21:42 --> Language Class Initialized
INFO - 2023-05-07 18:21:42 --> Loader Class Initialized
INFO - 2023-05-07 18:21:42 --> Helper loaded: url_helper
INFO - 2023-05-07 18:21:42 --> Helper loaded: file_helper
INFO - 2023-05-07 18:21:42 --> Helper loaded: html_helper
INFO - 2023-05-07 18:21:42 --> Helper loaded: text_helper
INFO - 2023-05-07 18:21:42 --> Helper loaded: form_helper
INFO - 2023-05-07 18:21:42 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:21:42 --> Helper loaded: security_helper
INFO - 2023-05-07 18:21:42 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:21:42 --> Database Driver Class Initialized
INFO - 2023-05-07 18:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:21:42 --> Parser Class Initialized
INFO - 2023-05-07 18:21:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:21:42 --> Pagination Class Initialized
INFO - 2023-05-07 18:21:42 --> Form Validation Class Initialized
INFO - 2023-05-07 18:21:42 --> Controller Class Initialized
INFO - 2023-05-07 18:21:42 --> Final output sent to browser
DEBUG - 2023-05-07 18:21:42 --> Total execution time: 0.0134
ERROR - 2023-05-07 18:21:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:21:45 --> Config Class Initialized
INFO - 2023-05-07 18:21:45 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:21:45 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:21:45 --> Utf8 Class Initialized
INFO - 2023-05-07 18:21:45 --> URI Class Initialized
INFO - 2023-05-07 18:21:45 --> Router Class Initialized
INFO - 2023-05-07 18:21:45 --> Output Class Initialized
INFO - 2023-05-07 18:21:45 --> Security Class Initialized
DEBUG - 2023-05-07 18:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:21:45 --> Input Class Initialized
INFO - 2023-05-07 18:21:45 --> Language Class Initialized
INFO - 2023-05-07 18:21:45 --> Loader Class Initialized
INFO - 2023-05-07 18:21:45 --> Helper loaded: url_helper
INFO - 2023-05-07 18:21:45 --> Helper loaded: file_helper
INFO - 2023-05-07 18:21:45 --> Helper loaded: html_helper
INFO - 2023-05-07 18:21:45 --> Helper loaded: text_helper
INFO - 2023-05-07 18:21:45 --> Helper loaded: form_helper
INFO - 2023-05-07 18:21:45 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:21:45 --> Helper loaded: security_helper
INFO - 2023-05-07 18:21:45 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:21:45 --> Database Driver Class Initialized
INFO - 2023-05-07 18:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:21:45 --> Parser Class Initialized
INFO - 2023-05-07 18:21:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:21:45 --> Pagination Class Initialized
INFO - 2023-05-07 18:21:45 --> Form Validation Class Initialized
INFO - 2023-05-07 18:21:45 --> Controller Class Initialized
INFO - 2023-05-07 18:21:45 --> Model Class Initialized
DEBUG - 2023-05-07 18:21:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:21:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:21:45 --> Model Class Initialized
DEBUG - 2023-05-07 18:21:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:21:45 --> Model Class Initialized
INFO - 2023-05-07 18:21:45 --> Final output sent to browser
DEBUG - 2023-05-07 18:21:45 --> Total execution time: 0.0184
ERROR - 2023-05-07 18:21:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:21:47 --> Config Class Initialized
INFO - 2023-05-07 18:21:47 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:21:47 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:21:47 --> Utf8 Class Initialized
INFO - 2023-05-07 18:21:47 --> URI Class Initialized
INFO - 2023-05-07 18:21:47 --> Router Class Initialized
INFO - 2023-05-07 18:21:47 --> Output Class Initialized
INFO - 2023-05-07 18:21:47 --> Security Class Initialized
DEBUG - 2023-05-07 18:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:21:47 --> Input Class Initialized
INFO - 2023-05-07 18:21:47 --> Language Class Initialized
INFO - 2023-05-07 18:21:47 --> Loader Class Initialized
INFO - 2023-05-07 18:21:47 --> Helper loaded: url_helper
INFO - 2023-05-07 18:21:47 --> Helper loaded: file_helper
INFO - 2023-05-07 18:21:47 --> Helper loaded: html_helper
INFO - 2023-05-07 18:21:47 --> Helper loaded: text_helper
INFO - 2023-05-07 18:21:47 --> Helper loaded: form_helper
INFO - 2023-05-07 18:21:47 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:21:47 --> Helper loaded: security_helper
INFO - 2023-05-07 18:21:47 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:21:47 --> Database Driver Class Initialized
INFO - 2023-05-07 18:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:21:47 --> Parser Class Initialized
INFO - 2023-05-07 18:21:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:21:47 --> Pagination Class Initialized
INFO - 2023-05-07 18:21:47 --> Form Validation Class Initialized
INFO - 2023-05-07 18:21:47 --> Controller Class Initialized
INFO - 2023-05-07 18:21:47 --> Model Class Initialized
DEBUG - 2023-05-07 18:21:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:21:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:21:47 --> Model Class Initialized
DEBUG - 2023-05-07 18:21:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:21:47 --> Model Class Initialized
INFO - 2023-05-07 18:21:47 --> Final output sent to browser
DEBUG - 2023-05-07 18:21:47 --> Total execution time: 0.0179
ERROR - 2023-05-07 18:21:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:21:48 --> Config Class Initialized
INFO - 2023-05-07 18:21:48 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:21:48 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:21:48 --> Utf8 Class Initialized
INFO - 2023-05-07 18:21:48 --> URI Class Initialized
INFO - 2023-05-07 18:21:48 --> Router Class Initialized
INFO - 2023-05-07 18:21:48 --> Output Class Initialized
INFO - 2023-05-07 18:21:48 --> Security Class Initialized
DEBUG - 2023-05-07 18:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:21:48 --> Input Class Initialized
INFO - 2023-05-07 18:21:48 --> Language Class Initialized
INFO - 2023-05-07 18:21:48 --> Loader Class Initialized
INFO - 2023-05-07 18:21:48 --> Helper loaded: url_helper
INFO - 2023-05-07 18:21:48 --> Helper loaded: file_helper
INFO - 2023-05-07 18:21:48 --> Helper loaded: html_helper
INFO - 2023-05-07 18:21:48 --> Helper loaded: text_helper
INFO - 2023-05-07 18:21:48 --> Helper loaded: form_helper
INFO - 2023-05-07 18:21:48 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:21:48 --> Helper loaded: security_helper
INFO - 2023-05-07 18:21:48 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:21:48 --> Database Driver Class Initialized
INFO - 2023-05-07 18:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:21:48 --> Parser Class Initialized
INFO - 2023-05-07 18:21:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:21:48 --> Pagination Class Initialized
INFO - 2023-05-07 18:21:48 --> Form Validation Class Initialized
INFO - 2023-05-07 18:21:48 --> Controller Class Initialized
INFO - 2023-05-07 18:21:48 --> Model Class Initialized
DEBUG - 2023-05-07 18:21:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:21:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:21:48 --> Model Class Initialized
INFO - 2023-05-07 18:21:48 --> Model Class Initialized
INFO - 2023-05-07 18:21:48 --> Final output sent to browser
DEBUG - 2023-05-07 18:21:48 --> Total execution time: 0.0181
ERROR - 2023-05-07 18:21:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:21:51 --> Config Class Initialized
INFO - 2023-05-07 18:21:51 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:21:51 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:21:51 --> Utf8 Class Initialized
INFO - 2023-05-07 18:21:51 --> URI Class Initialized
INFO - 2023-05-07 18:21:51 --> Router Class Initialized
INFO - 2023-05-07 18:21:51 --> Output Class Initialized
INFO - 2023-05-07 18:21:51 --> Security Class Initialized
DEBUG - 2023-05-07 18:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:21:51 --> Input Class Initialized
INFO - 2023-05-07 18:21:51 --> Language Class Initialized
INFO - 2023-05-07 18:21:51 --> Loader Class Initialized
INFO - 2023-05-07 18:21:51 --> Helper loaded: url_helper
INFO - 2023-05-07 18:21:51 --> Helper loaded: file_helper
INFO - 2023-05-07 18:21:51 --> Helper loaded: html_helper
INFO - 2023-05-07 18:21:51 --> Helper loaded: text_helper
INFO - 2023-05-07 18:21:51 --> Helper loaded: form_helper
INFO - 2023-05-07 18:21:51 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:21:51 --> Helper loaded: security_helper
INFO - 2023-05-07 18:21:51 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:21:51 --> Database Driver Class Initialized
INFO - 2023-05-07 18:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:21:51 --> Parser Class Initialized
INFO - 2023-05-07 18:21:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:21:51 --> Pagination Class Initialized
INFO - 2023-05-07 18:21:51 --> Form Validation Class Initialized
INFO - 2023-05-07 18:21:51 --> Controller Class Initialized
INFO - 2023-05-07 18:21:51 --> Model Class Initialized
DEBUG - 2023-05-07 18:21:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:21:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:21:51 --> Model Class Initialized
INFO - 2023-05-07 18:21:51 --> Final output sent to browser
DEBUG - 2023-05-07 18:21:51 --> Total execution time: 0.0198
ERROR - 2023-05-07 18:22:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:22:05 --> Config Class Initialized
INFO - 2023-05-07 18:22:05 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:22:05 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:22:05 --> Utf8 Class Initialized
INFO - 2023-05-07 18:22:05 --> URI Class Initialized
INFO - 2023-05-07 18:22:05 --> Router Class Initialized
INFO - 2023-05-07 18:22:05 --> Output Class Initialized
INFO - 2023-05-07 18:22:05 --> Security Class Initialized
DEBUG - 2023-05-07 18:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:22:05 --> Input Class Initialized
INFO - 2023-05-07 18:22:05 --> Language Class Initialized
INFO - 2023-05-07 18:22:05 --> Loader Class Initialized
INFO - 2023-05-07 18:22:05 --> Helper loaded: url_helper
INFO - 2023-05-07 18:22:05 --> Helper loaded: file_helper
INFO - 2023-05-07 18:22:05 --> Helper loaded: html_helper
INFO - 2023-05-07 18:22:05 --> Helper loaded: text_helper
INFO - 2023-05-07 18:22:05 --> Helper loaded: form_helper
INFO - 2023-05-07 18:22:05 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:22:05 --> Helper loaded: security_helper
INFO - 2023-05-07 18:22:05 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:22:05 --> Database Driver Class Initialized
INFO - 2023-05-07 18:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:22:05 --> Parser Class Initialized
INFO - 2023-05-07 18:22:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:22:05 --> Pagination Class Initialized
INFO - 2023-05-07 18:22:05 --> Form Validation Class Initialized
INFO - 2023-05-07 18:22:05 --> Controller Class Initialized
INFO - 2023-05-07 18:22:05 --> Model Class Initialized
DEBUG - 2023-05-07 18:22:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:22:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:22:05 --> Model Class Initialized
INFO - 2023-05-07 18:22:05 --> Final output sent to browser
DEBUG - 2023-05-07 18:22:05 --> Total execution time: 0.0191
ERROR - 2023-05-07 18:22:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:22:11 --> Config Class Initialized
INFO - 2023-05-07 18:22:11 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:22:11 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:22:11 --> Utf8 Class Initialized
INFO - 2023-05-07 18:22:11 --> URI Class Initialized
INFO - 2023-05-07 18:22:11 --> Router Class Initialized
INFO - 2023-05-07 18:22:11 --> Output Class Initialized
INFO - 2023-05-07 18:22:11 --> Security Class Initialized
DEBUG - 2023-05-07 18:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:22:11 --> Input Class Initialized
INFO - 2023-05-07 18:22:11 --> Language Class Initialized
INFO - 2023-05-07 18:22:11 --> Loader Class Initialized
INFO - 2023-05-07 18:22:11 --> Helper loaded: url_helper
INFO - 2023-05-07 18:22:11 --> Helper loaded: file_helper
INFO - 2023-05-07 18:22:11 --> Helper loaded: html_helper
INFO - 2023-05-07 18:22:11 --> Helper loaded: text_helper
INFO - 2023-05-07 18:22:11 --> Helper loaded: form_helper
INFO - 2023-05-07 18:22:11 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:22:11 --> Helper loaded: security_helper
INFO - 2023-05-07 18:22:11 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:22:11 --> Database Driver Class Initialized
INFO - 2023-05-07 18:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:22:11 --> Parser Class Initialized
INFO - 2023-05-07 18:22:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:22:11 --> Pagination Class Initialized
INFO - 2023-05-07 18:22:11 --> Form Validation Class Initialized
INFO - 2023-05-07 18:22:11 --> Controller Class Initialized
INFO - 2023-05-07 18:22:11 --> Model Class Initialized
DEBUG - 2023-05-07 18:22:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:22:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:22:11 --> Model Class Initialized
INFO - 2023-05-07 18:22:11 --> Final output sent to browser
DEBUG - 2023-05-07 18:22:11 --> Total execution time: 0.0169
ERROR - 2023-05-07 18:22:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:22:34 --> Config Class Initialized
INFO - 2023-05-07 18:22:34 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:22:34 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:22:34 --> Utf8 Class Initialized
INFO - 2023-05-07 18:22:34 --> URI Class Initialized
INFO - 2023-05-07 18:22:34 --> Router Class Initialized
INFO - 2023-05-07 18:22:34 --> Output Class Initialized
INFO - 2023-05-07 18:22:34 --> Security Class Initialized
DEBUG - 2023-05-07 18:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:22:34 --> Input Class Initialized
INFO - 2023-05-07 18:22:34 --> Language Class Initialized
INFO - 2023-05-07 18:22:34 --> Loader Class Initialized
INFO - 2023-05-07 18:22:34 --> Helper loaded: url_helper
INFO - 2023-05-07 18:22:34 --> Helper loaded: file_helper
INFO - 2023-05-07 18:22:34 --> Helper loaded: html_helper
INFO - 2023-05-07 18:22:34 --> Helper loaded: text_helper
INFO - 2023-05-07 18:22:34 --> Helper loaded: form_helper
INFO - 2023-05-07 18:22:34 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:22:34 --> Helper loaded: security_helper
INFO - 2023-05-07 18:22:34 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:22:34 --> Database Driver Class Initialized
INFO - 2023-05-07 18:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:22:34 --> Parser Class Initialized
INFO - 2023-05-07 18:22:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:22:34 --> Pagination Class Initialized
INFO - 2023-05-07 18:22:34 --> Form Validation Class Initialized
INFO - 2023-05-07 18:22:34 --> Controller Class Initialized
INFO - 2023-05-07 18:22:34 --> Model Class Initialized
DEBUG - 2023-05-07 18:22:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:22:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:22:34 --> Model Class Initialized
INFO - 2023-05-07 18:22:34 --> Final output sent to browser
DEBUG - 2023-05-07 18:22:34 --> Total execution time: 0.0182
ERROR - 2023-05-07 18:22:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:22:37 --> Config Class Initialized
INFO - 2023-05-07 18:22:37 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:22:37 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:22:37 --> Utf8 Class Initialized
INFO - 2023-05-07 18:22:37 --> URI Class Initialized
INFO - 2023-05-07 18:22:37 --> Router Class Initialized
INFO - 2023-05-07 18:22:37 --> Output Class Initialized
INFO - 2023-05-07 18:22:37 --> Security Class Initialized
DEBUG - 2023-05-07 18:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:22:37 --> Input Class Initialized
INFO - 2023-05-07 18:22:37 --> Language Class Initialized
INFO - 2023-05-07 18:22:37 --> Loader Class Initialized
INFO - 2023-05-07 18:22:37 --> Helper loaded: url_helper
INFO - 2023-05-07 18:22:37 --> Helper loaded: file_helper
INFO - 2023-05-07 18:22:37 --> Helper loaded: html_helper
INFO - 2023-05-07 18:22:37 --> Helper loaded: text_helper
INFO - 2023-05-07 18:22:37 --> Helper loaded: form_helper
INFO - 2023-05-07 18:22:37 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:22:37 --> Helper loaded: security_helper
INFO - 2023-05-07 18:22:37 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:22:37 --> Database Driver Class Initialized
INFO - 2023-05-07 18:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:22:37 --> Parser Class Initialized
INFO - 2023-05-07 18:22:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:22:37 --> Pagination Class Initialized
INFO - 2023-05-07 18:22:37 --> Form Validation Class Initialized
INFO - 2023-05-07 18:22:37 --> Controller Class Initialized
INFO - 2023-05-07 18:22:37 --> Model Class Initialized
DEBUG - 2023-05-07 18:22:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:22:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:22:37 --> Model Class Initialized
INFO - 2023-05-07 18:22:37 --> Final output sent to browser
DEBUG - 2023-05-07 18:22:37 --> Total execution time: 0.0198
ERROR - 2023-05-07 18:22:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:22:57 --> Config Class Initialized
INFO - 2023-05-07 18:22:57 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:22:57 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:22:57 --> Utf8 Class Initialized
INFO - 2023-05-07 18:22:57 --> URI Class Initialized
INFO - 2023-05-07 18:22:57 --> Router Class Initialized
INFO - 2023-05-07 18:22:57 --> Output Class Initialized
INFO - 2023-05-07 18:22:57 --> Security Class Initialized
DEBUG - 2023-05-07 18:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:22:57 --> Input Class Initialized
INFO - 2023-05-07 18:22:57 --> Language Class Initialized
INFO - 2023-05-07 18:22:57 --> Loader Class Initialized
INFO - 2023-05-07 18:22:57 --> Helper loaded: url_helper
INFO - 2023-05-07 18:22:57 --> Helper loaded: file_helper
INFO - 2023-05-07 18:22:57 --> Helper loaded: html_helper
INFO - 2023-05-07 18:22:57 --> Helper loaded: text_helper
INFO - 2023-05-07 18:22:57 --> Helper loaded: form_helper
INFO - 2023-05-07 18:22:57 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:22:57 --> Helper loaded: security_helper
INFO - 2023-05-07 18:22:57 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:22:57 --> Database Driver Class Initialized
INFO - 2023-05-07 18:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:22:57 --> Parser Class Initialized
INFO - 2023-05-07 18:22:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:22:57 --> Pagination Class Initialized
INFO - 2023-05-07 18:22:57 --> Form Validation Class Initialized
INFO - 2023-05-07 18:22:57 --> Controller Class Initialized
INFO - 2023-05-07 18:22:57 --> Model Class Initialized
DEBUG - 2023-05-07 18:22:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:22:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:22:57 --> Model Class Initialized
INFO - 2023-05-07 18:22:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-05-07 18:22:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:22:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:22:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:22:57 --> Model Class Initialized
INFO - 2023-05-07 18:22:57 --> Model Class Initialized
INFO - 2023-05-07 18:22:57 --> Model Class Initialized
INFO - 2023-05-07 18:22:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:22:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:22:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:22:57 --> Final output sent to browser
DEBUG - 2023-05-07 18:22:57 --> Total execution time: 0.0672
ERROR - 2023-05-07 18:22:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:22:57 --> Config Class Initialized
INFO - 2023-05-07 18:22:57 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:22:57 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:22:57 --> Utf8 Class Initialized
INFO - 2023-05-07 18:22:57 --> URI Class Initialized
INFO - 2023-05-07 18:22:57 --> Router Class Initialized
INFO - 2023-05-07 18:22:57 --> Output Class Initialized
INFO - 2023-05-07 18:22:57 --> Security Class Initialized
DEBUG - 2023-05-07 18:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:22:57 --> Input Class Initialized
INFO - 2023-05-07 18:22:57 --> Language Class Initialized
INFO - 2023-05-07 18:22:57 --> Loader Class Initialized
INFO - 2023-05-07 18:22:57 --> Helper loaded: url_helper
INFO - 2023-05-07 18:22:57 --> Helper loaded: file_helper
INFO - 2023-05-07 18:22:57 --> Helper loaded: html_helper
INFO - 2023-05-07 18:22:57 --> Helper loaded: text_helper
INFO - 2023-05-07 18:22:57 --> Helper loaded: form_helper
INFO - 2023-05-07 18:22:57 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:22:57 --> Helper loaded: security_helper
INFO - 2023-05-07 18:22:57 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:22:57 --> Database Driver Class Initialized
INFO - 2023-05-07 18:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:22:58 --> Parser Class Initialized
INFO - 2023-05-07 18:22:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:22:58 --> Pagination Class Initialized
INFO - 2023-05-07 18:22:58 --> Form Validation Class Initialized
INFO - 2023-05-07 18:22:58 --> Controller Class Initialized
INFO - 2023-05-07 18:22:58 --> Model Class Initialized
DEBUG - 2023-05-07 18:22:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:22:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:22:58 --> Model Class Initialized
INFO - 2023-05-07 18:22:58 --> Final output sent to browser
DEBUG - 2023-05-07 18:22:58 --> Total execution time: 0.0259
ERROR - 2023-05-07 18:23:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:23:03 --> Config Class Initialized
INFO - 2023-05-07 18:23:03 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:23:03 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:23:03 --> Utf8 Class Initialized
INFO - 2023-05-07 18:23:03 --> URI Class Initialized
INFO - 2023-05-07 18:23:03 --> Router Class Initialized
INFO - 2023-05-07 18:23:03 --> Output Class Initialized
INFO - 2023-05-07 18:23:03 --> Security Class Initialized
DEBUG - 2023-05-07 18:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:23:03 --> Input Class Initialized
INFO - 2023-05-07 18:23:03 --> Language Class Initialized
INFO - 2023-05-07 18:23:03 --> Loader Class Initialized
INFO - 2023-05-07 18:23:03 --> Helper loaded: url_helper
INFO - 2023-05-07 18:23:03 --> Helper loaded: file_helper
INFO - 2023-05-07 18:23:03 --> Helper loaded: html_helper
INFO - 2023-05-07 18:23:03 --> Helper loaded: text_helper
INFO - 2023-05-07 18:23:03 --> Helper loaded: form_helper
INFO - 2023-05-07 18:23:03 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:23:03 --> Helper loaded: security_helper
INFO - 2023-05-07 18:23:03 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:23:03 --> Database Driver Class Initialized
INFO - 2023-05-07 18:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:23:03 --> Parser Class Initialized
INFO - 2023-05-07 18:23:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:23:03 --> Pagination Class Initialized
INFO - 2023-05-07 18:23:03 --> Form Validation Class Initialized
INFO - 2023-05-07 18:23:03 --> Controller Class Initialized
INFO - 2023-05-07 18:23:03 --> Model Class Initialized
DEBUG - 2023-05-07 18:23:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:23:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:23:03 --> Model Class Initialized
INFO - 2023-05-07 18:23:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/upcoming.php
DEBUG - 2023-05-07 18:23:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:23:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:23:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:23:03 --> Model Class Initialized
INFO - 2023-05-07 18:23:03 --> Model Class Initialized
INFO - 2023-05-07 18:23:03 --> Model Class Initialized
INFO - 2023-05-07 18:23:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:23:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:23:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:23:03 --> Final output sent to browser
DEBUG - 2023-05-07 18:23:03 --> Total execution time: 0.0593
ERROR - 2023-05-07 18:23:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:23:04 --> Config Class Initialized
INFO - 2023-05-07 18:23:04 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:23:04 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:23:04 --> Utf8 Class Initialized
INFO - 2023-05-07 18:23:04 --> URI Class Initialized
INFO - 2023-05-07 18:23:04 --> Router Class Initialized
INFO - 2023-05-07 18:23:04 --> Output Class Initialized
INFO - 2023-05-07 18:23:04 --> Security Class Initialized
DEBUG - 2023-05-07 18:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:23:04 --> Input Class Initialized
INFO - 2023-05-07 18:23:04 --> Language Class Initialized
INFO - 2023-05-07 18:23:04 --> Loader Class Initialized
INFO - 2023-05-07 18:23:04 --> Helper loaded: url_helper
INFO - 2023-05-07 18:23:04 --> Helper loaded: file_helper
INFO - 2023-05-07 18:23:04 --> Helper loaded: html_helper
INFO - 2023-05-07 18:23:04 --> Helper loaded: text_helper
INFO - 2023-05-07 18:23:04 --> Helper loaded: form_helper
INFO - 2023-05-07 18:23:04 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:23:04 --> Helper loaded: security_helper
INFO - 2023-05-07 18:23:04 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:23:04 --> Database Driver Class Initialized
INFO - 2023-05-07 18:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:23:04 --> Parser Class Initialized
INFO - 2023-05-07 18:23:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:23:04 --> Pagination Class Initialized
INFO - 2023-05-07 18:23:04 --> Form Validation Class Initialized
INFO - 2023-05-07 18:23:04 --> Controller Class Initialized
INFO - 2023-05-07 18:23:04 --> Model Class Initialized
DEBUG - 2023-05-07 18:23:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:23:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:23:04 --> Model Class Initialized
INFO - 2023-05-07 18:23:04 --> Final output sent to browser
DEBUG - 2023-05-07 18:23:04 --> Total execution time: 0.0185
ERROR - 2023-05-07 18:23:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:23:08 --> Config Class Initialized
INFO - 2023-05-07 18:23:08 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:23:08 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:23:08 --> Utf8 Class Initialized
INFO - 2023-05-07 18:23:08 --> URI Class Initialized
INFO - 2023-05-07 18:23:08 --> Router Class Initialized
INFO - 2023-05-07 18:23:08 --> Output Class Initialized
INFO - 2023-05-07 18:23:08 --> Security Class Initialized
DEBUG - 2023-05-07 18:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:23:08 --> Input Class Initialized
INFO - 2023-05-07 18:23:08 --> Language Class Initialized
INFO - 2023-05-07 18:23:08 --> Loader Class Initialized
INFO - 2023-05-07 18:23:08 --> Helper loaded: url_helper
INFO - 2023-05-07 18:23:08 --> Helper loaded: file_helper
INFO - 2023-05-07 18:23:08 --> Helper loaded: html_helper
INFO - 2023-05-07 18:23:08 --> Helper loaded: text_helper
INFO - 2023-05-07 18:23:08 --> Helper loaded: form_helper
INFO - 2023-05-07 18:23:08 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:23:08 --> Helper loaded: security_helper
INFO - 2023-05-07 18:23:08 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:23:08 --> Database Driver Class Initialized
INFO - 2023-05-07 18:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:23:08 --> Parser Class Initialized
INFO - 2023-05-07 18:23:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:23:08 --> Pagination Class Initialized
INFO - 2023-05-07 18:23:08 --> Form Validation Class Initialized
INFO - 2023-05-07 18:23:08 --> Controller Class Initialized
INFO - 2023-05-07 18:23:08 --> Model Class Initialized
DEBUG - 2023-05-07 18:23:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:23:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:23:08 --> Model Class Initialized
INFO - 2023-05-07 18:23:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-05-07 18:23:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:23:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:23:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:23:08 --> Model Class Initialized
INFO - 2023-05-07 18:23:08 --> Model Class Initialized
INFO - 2023-05-07 18:23:08 --> Model Class Initialized
INFO - 2023-05-07 18:23:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:23:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:23:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:23:08 --> Final output sent to browser
DEBUG - 2023-05-07 18:23:08 --> Total execution time: 0.0763
ERROR - 2023-05-07 18:23:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:23:08 --> Config Class Initialized
INFO - 2023-05-07 18:23:08 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:23:08 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:23:08 --> Utf8 Class Initialized
INFO - 2023-05-07 18:23:08 --> URI Class Initialized
INFO - 2023-05-07 18:23:08 --> Router Class Initialized
INFO - 2023-05-07 18:23:08 --> Output Class Initialized
INFO - 2023-05-07 18:23:08 --> Security Class Initialized
DEBUG - 2023-05-07 18:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:23:08 --> Input Class Initialized
INFO - 2023-05-07 18:23:08 --> Language Class Initialized
INFO - 2023-05-07 18:23:08 --> Loader Class Initialized
INFO - 2023-05-07 18:23:08 --> Helper loaded: url_helper
INFO - 2023-05-07 18:23:08 --> Helper loaded: file_helper
INFO - 2023-05-07 18:23:08 --> Helper loaded: html_helper
INFO - 2023-05-07 18:23:08 --> Helper loaded: text_helper
INFO - 2023-05-07 18:23:08 --> Helper loaded: form_helper
INFO - 2023-05-07 18:23:08 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:23:08 --> Helper loaded: security_helper
INFO - 2023-05-07 18:23:08 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:23:08 --> Database Driver Class Initialized
INFO - 2023-05-07 18:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:23:08 --> Parser Class Initialized
INFO - 2023-05-07 18:23:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:23:08 --> Pagination Class Initialized
INFO - 2023-05-07 18:23:08 --> Form Validation Class Initialized
INFO - 2023-05-07 18:23:08 --> Controller Class Initialized
INFO - 2023-05-07 18:23:08 --> Model Class Initialized
DEBUG - 2023-05-07 18:23:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:23:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:23:08 --> Model Class Initialized
INFO - 2023-05-07 18:23:08 --> Final output sent to browser
DEBUG - 2023-05-07 18:23:08 --> Total execution time: 0.0224
ERROR - 2023-05-07 18:23:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:23:13 --> Config Class Initialized
INFO - 2023-05-07 18:23:13 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:23:13 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:23:13 --> Utf8 Class Initialized
INFO - 2023-05-07 18:23:13 --> URI Class Initialized
INFO - 2023-05-07 18:23:13 --> Router Class Initialized
INFO - 2023-05-07 18:23:13 --> Output Class Initialized
INFO - 2023-05-07 18:23:13 --> Security Class Initialized
DEBUG - 2023-05-07 18:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:23:13 --> Input Class Initialized
INFO - 2023-05-07 18:23:13 --> Language Class Initialized
INFO - 2023-05-07 18:23:13 --> Loader Class Initialized
INFO - 2023-05-07 18:23:13 --> Helper loaded: url_helper
INFO - 2023-05-07 18:23:13 --> Helper loaded: file_helper
INFO - 2023-05-07 18:23:13 --> Helper loaded: html_helper
INFO - 2023-05-07 18:23:13 --> Helper loaded: text_helper
INFO - 2023-05-07 18:23:13 --> Helper loaded: form_helper
INFO - 2023-05-07 18:23:13 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:23:13 --> Helper loaded: security_helper
INFO - 2023-05-07 18:23:13 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:23:13 --> Database Driver Class Initialized
INFO - 2023-05-07 18:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:23:13 --> Parser Class Initialized
INFO - 2023-05-07 18:23:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:23:13 --> Pagination Class Initialized
INFO - 2023-05-07 18:23:13 --> Form Validation Class Initialized
INFO - 2023-05-07 18:23:13 --> Controller Class Initialized
INFO - 2023-05-07 18:23:13 --> Model Class Initialized
DEBUG - 2023-05-07 18:23:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:23:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:23:13 --> Model Class Initialized
INFO - 2023-05-07 18:23:13 --> Final output sent to browser
DEBUG - 2023-05-07 18:23:13 --> Total execution time: 0.0199
ERROR - 2023-05-07 18:23:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:23:39 --> Config Class Initialized
INFO - 2023-05-07 18:23:39 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:23:39 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:23:39 --> Utf8 Class Initialized
INFO - 2023-05-07 18:23:39 --> URI Class Initialized
INFO - 2023-05-07 18:23:39 --> Router Class Initialized
INFO - 2023-05-07 18:23:39 --> Output Class Initialized
INFO - 2023-05-07 18:23:39 --> Security Class Initialized
DEBUG - 2023-05-07 18:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:23:39 --> Input Class Initialized
INFO - 2023-05-07 18:23:39 --> Language Class Initialized
INFO - 2023-05-07 18:23:39 --> Loader Class Initialized
INFO - 2023-05-07 18:23:39 --> Helper loaded: url_helper
INFO - 2023-05-07 18:23:39 --> Helper loaded: file_helper
INFO - 2023-05-07 18:23:39 --> Helper loaded: html_helper
INFO - 2023-05-07 18:23:39 --> Helper loaded: text_helper
INFO - 2023-05-07 18:23:39 --> Helper loaded: form_helper
INFO - 2023-05-07 18:23:39 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:23:39 --> Helper loaded: security_helper
INFO - 2023-05-07 18:23:39 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:23:39 --> Database Driver Class Initialized
INFO - 2023-05-07 18:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:23:39 --> Parser Class Initialized
INFO - 2023-05-07 18:23:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:23:39 --> Pagination Class Initialized
INFO - 2023-05-07 18:23:39 --> Form Validation Class Initialized
INFO - 2023-05-07 18:23:39 --> Controller Class Initialized
INFO - 2023-05-07 18:23:39 --> Model Class Initialized
DEBUG - 2023-05-07 18:23:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:23:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:23:39 --> Model Class Initialized
DEBUG - 2023-05-07 18:23:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:23:39 --> Model Class Initialized
INFO - 2023-05-07 18:23:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-05-07 18:23:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:23:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:23:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:23:39 --> Model Class Initialized
INFO - 2023-05-07 18:23:39 --> Model Class Initialized
INFO - 2023-05-07 18:23:39 --> Model Class Initialized
INFO - 2023-05-07 18:23:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:23:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:23:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:23:39 --> Final output sent to browser
DEBUG - 2023-05-07 18:23:39 --> Total execution time: 0.0870
ERROR - 2023-05-07 18:23:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:23:43 --> Config Class Initialized
INFO - 2023-05-07 18:23:43 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:23:43 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:23:43 --> Utf8 Class Initialized
INFO - 2023-05-07 18:23:43 --> URI Class Initialized
INFO - 2023-05-07 18:23:43 --> Router Class Initialized
INFO - 2023-05-07 18:23:43 --> Output Class Initialized
INFO - 2023-05-07 18:23:43 --> Security Class Initialized
DEBUG - 2023-05-07 18:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:23:43 --> Input Class Initialized
INFO - 2023-05-07 18:23:43 --> Language Class Initialized
INFO - 2023-05-07 18:23:43 --> Loader Class Initialized
INFO - 2023-05-07 18:23:43 --> Helper loaded: url_helper
INFO - 2023-05-07 18:23:43 --> Helper loaded: file_helper
INFO - 2023-05-07 18:23:43 --> Helper loaded: html_helper
INFO - 2023-05-07 18:23:43 --> Helper loaded: text_helper
INFO - 2023-05-07 18:23:43 --> Helper loaded: form_helper
INFO - 2023-05-07 18:23:43 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:23:43 --> Helper loaded: security_helper
INFO - 2023-05-07 18:23:43 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:23:43 --> Database Driver Class Initialized
INFO - 2023-05-07 18:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:23:43 --> Parser Class Initialized
INFO - 2023-05-07 18:23:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:23:43 --> Pagination Class Initialized
INFO - 2023-05-07 18:23:43 --> Form Validation Class Initialized
INFO - 2023-05-07 18:23:43 --> Controller Class Initialized
INFO - 2023-05-07 18:23:43 --> Model Class Initialized
DEBUG - 2023-05-07 18:23:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:23:43 --> Final output sent to browser
DEBUG - 2023-05-07 18:23:43 --> Total execution time: 0.0156
ERROR - 2023-05-07 18:23:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:23:43 --> Config Class Initialized
INFO - 2023-05-07 18:23:43 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:23:43 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:23:43 --> Utf8 Class Initialized
INFO - 2023-05-07 18:23:43 --> URI Class Initialized
INFO - 2023-05-07 18:23:43 --> Router Class Initialized
INFO - 2023-05-07 18:23:43 --> Output Class Initialized
INFO - 2023-05-07 18:23:43 --> Security Class Initialized
DEBUG - 2023-05-07 18:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:23:43 --> Input Class Initialized
INFO - 2023-05-07 18:23:43 --> Language Class Initialized
INFO - 2023-05-07 18:23:43 --> Loader Class Initialized
INFO - 2023-05-07 18:23:43 --> Helper loaded: url_helper
INFO - 2023-05-07 18:23:43 --> Helper loaded: file_helper
INFO - 2023-05-07 18:23:43 --> Helper loaded: html_helper
INFO - 2023-05-07 18:23:43 --> Helper loaded: text_helper
INFO - 2023-05-07 18:23:43 --> Helper loaded: form_helper
INFO - 2023-05-07 18:23:43 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:23:43 --> Helper loaded: security_helper
INFO - 2023-05-07 18:23:43 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:23:43 --> Database Driver Class Initialized
INFO - 2023-05-07 18:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:23:43 --> Parser Class Initialized
INFO - 2023-05-07 18:23:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:23:43 --> Pagination Class Initialized
INFO - 2023-05-07 18:23:43 --> Form Validation Class Initialized
INFO - 2023-05-07 18:23:43 --> Controller Class Initialized
INFO - 2023-05-07 18:23:43 --> Model Class Initialized
DEBUG - 2023-05-07 18:23:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:23:43 --> Final output sent to browser
DEBUG - 2023-05-07 18:23:43 --> Total execution time: 0.0151
ERROR - 2023-05-07 18:23:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:23:44 --> Config Class Initialized
INFO - 2023-05-07 18:23:44 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:23:44 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:23:44 --> Utf8 Class Initialized
INFO - 2023-05-07 18:23:44 --> URI Class Initialized
INFO - 2023-05-07 18:23:44 --> Router Class Initialized
INFO - 2023-05-07 18:23:44 --> Output Class Initialized
INFO - 2023-05-07 18:23:44 --> Security Class Initialized
DEBUG - 2023-05-07 18:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:23:44 --> Input Class Initialized
INFO - 2023-05-07 18:23:44 --> Language Class Initialized
INFO - 2023-05-07 18:23:44 --> Loader Class Initialized
INFO - 2023-05-07 18:23:44 --> Helper loaded: url_helper
INFO - 2023-05-07 18:23:44 --> Helper loaded: file_helper
INFO - 2023-05-07 18:23:44 --> Helper loaded: html_helper
INFO - 2023-05-07 18:23:44 --> Helper loaded: text_helper
INFO - 2023-05-07 18:23:44 --> Helper loaded: form_helper
INFO - 2023-05-07 18:23:44 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:23:44 --> Helper loaded: security_helper
INFO - 2023-05-07 18:23:44 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:23:44 --> Database Driver Class Initialized
INFO - 2023-05-07 18:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:23:44 --> Parser Class Initialized
INFO - 2023-05-07 18:23:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:23:44 --> Pagination Class Initialized
INFO - 2023-05-07 18:23:44 --> Form Validation Class Initialized
INFO - 2023-05-07 18:23:44 --> Controller Class Initialized
INFO - 2023-05-07 18:23:44 --> Model Class Initialized
DEBUG - 2023-05-07 18:23:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:23:44 --> Final output sent to browser
DEBUG - 2023-05-07 18:23:44 --> Total execution time: 0.0151
ERROR - 2023-05-07 18:23:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:23:46 --> Config Class Initialized
INFO - 2023-05-07 18:23:46 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:23:46 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:23:46 --> Utf8 Class Initialized
INFO - 2023-05-07 18:23:46 --> URI Class Initialized
INFO - 2023-05-07 18:23:46 --> Router Class Initialized
INFO - 2023-05-07 18:23:46 --> Output Class Initialized
INFO - 2023-05-07 18:23:46 --> Security Class Initialized
DEBUG - 2023-05-07 18:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:23:46 --> Input Class Initialized
INFO - 2023-05-07 18:23:46 --> Language Class Initialized
INFO - 2023-05-07 18:23:46 --> Loader Class Initialized
INFO - 2023-05-07 18:23:46 --> Helper loaded: url_helper
INFO - 2023-05-07 18:23:46 --> Helper loaded: file_helper
INFO - 2023-05-07 18:23:46 --> Helper loaded: html_helper
INFO - 2023-05-07 18:23:46 --> Helper loaded: text_helper
INFO - 2023-05-07 18:23:46 --> Helper loaded: form_helper
INFO - 2023-05-07 18:23:46 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:23:46 --> Helper loaded: security_helper
INFO - 2023-05-07 18:23:46 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:23:46 --> Database Driver Class Initialized
INFO - 2023-05-07 18:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:23:46 --> Parser Class Initialized
INFO - 2023-05-07 18:23:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:23:46 --> Pagination Class Initialized
INFO - 2023-05-07 18:23:46 --> Form Validation Class Initialized
INFO - 2023-05-07 18:23:46 --> Controller Class Initialized
INFO - 2023-05-07 18:23:46 --> Final output sent to browser
DEBUG - 2023-05-07 18:23:46 --> Total execution time: 0.0147
ERROR - 2023-05-07 18:23:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:23:48 --> Config Class Initialized
INFO - 2023-05-07 18:23:48 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:23:48 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:23:48 --> Utf8 Class Initialized
INFO - 2023-05-07 18:23:48 --> URI Class Initialized
INFO - 2023-05-07 18:23:48 --> Router Class Initialized
INFO - 2023-05-07 18:23:48 --> Output Class Initialized
INFO - 2023-05-07 18:23:48 --> Security Class Initialized
DEBUG - 2023-05-07 18:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:23:48 --> Input Class Initialized
INFO - 2023-05-07 18:23:48 --> Language Class Initialized
INFO - 2023-05-07 18:23:48 --> Loader Class Initialized
INFO - 2023-05-07 18:23:48 --> Helper loaded: url_helper
INFO - 2023-05-07 18:23:48 --> Helper loaded: file_helper
INFO - 2023-05-07 18:23:48 --> Helper loaded: html_helper
INFO - 2023-05-07 18:23:48 --> Helper loaded: text_helper
INFO - 2023-05-07 18:23:48 --> Helper loaded: form_helper
INFO - 2023-05-07 18:23:48 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:23:48 --> Helper loaded: security_helper
INFO - 2023-05-07 18:23:48 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:23:48 --> Database Driver Class Initialized
INFO - 2023-05-07 18:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:23:48 --> Parser Class Initialized
INFO - 2023-05-07 18:23:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:23:48 --> Pagination Class Initialized
INFO - 2023-05-07 18:23:48 --> Form Validation Class Initialized
INFO - 2023-05-07 18:23:48 --> Controller Class Initialized
INFO - 2023-05-07 18:23:48 --> Model Class Initialized
DEBUG - 2023-05-07 18:23:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:23:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:23:48 --> Model Class Initialized
DEBUG - 2023-05-07 18:23:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:23:48 --> Model Class Initialized
INFO - 2023-05-07 18:23:48 --> Final output sent to browser
DEBUG - 2023-05-07 18:23:48 --> Total execution time: 0.0188
ERROR - 2023-05-07 18:23:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:23:50 --> Config Class Initialized
INFO - 2023-05-07 18:23:50 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:23:50 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:23:50 --> Utf8 Class Initialized
INFO - 2023-05-07 18:23:50 --> URI Class Initialized
INFO - 2023-05-07 18:23:50 --> Router Class Initialized
INFO - 2023-05-07 18:23:50 --> Output Class Initialized
INFO - 2023-05-07 18:23:50 --> Security Class Initialized
DEBUG - 2023-05-07 18:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:23:50 --> Input Class Initialized
INFO - 2023-05-07 18:23:50 --> Language Class Initialized
INFO - 2023-05-07 18:23:50 --> Loader Class Initialized
INFO - 2023-05-07 18:23:50 --> Helper loaded: url_helper
INFO - 2023-05-07 18:23:50 --> Helper loaded: file_helper
INFO - 2023-05-07 18:23:50 --> Helper loaded: html_helper
INFO - 2023-05-07 18:23:50 --> Helper loaded: text_helper
INFO - 2023-05-07 18:23:50 --> Helper loaded: form_helper
INFO - 2023-05-07 18:23:50 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:23:50 --> Helper loaded: security_helper
INFO - 2023-05-07 18:23:50 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:23:50 --> Database Driver Class Initialized
INFO - 2023-05-07 18:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:23:50 --> Parser Class Initialized
INFO - 2023-05-07 18:23:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:23:50 --> Pagination Class Initialized
INFO - 2023-05-07 18:23:50 --> Form Validation Class Initialized
INFO - 2023-05-07 18:23:50 --> Controller Class Initialized
INFO - 2023-05-07 18:23:50 --> Model Class Initialized
DEBUG - 2023-05-07 18:23:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:23:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:23:50 --> Model Class Initialized
DEBUG - 2023-05-07 18:23:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:23:50 --> Model Class Initialized
INFO - 2023-05-07 18:23:50 --> Final output sent to browser
DEBUG - 2023-05-07 18:23:50 --> Total execution time: 0.0174
ERROR - 2023-05-07 18:23:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:23:51 --> Config Class Initialized
INFO - 2023-05-07 18:23:51 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:23:51 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:23:51 --> Utf8 Class Initialized
INFO - 2023-05-07 18:23:51 --> URI Class Initialized
INFO - 2023-05-07 18:23:51 --> Router Class Initialized
INFO - 2023-05-07 18:23:51 --> Output Class Initialized
INFO - 2023-05-07 18:23:51 --> Security Class Initialized
DEBUG - 2023-05-07 18:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:23:51 --> Input Class Initialized
INFO - 2023-05-07 18:23:51 --> Language Class Initialized
INFO - 2023-05-07 18:23:51 --> Loader Class Initialized
INFO - 2023-05-07 18:23:51 --> Helper loaded: url_helper
INFO - 2023-05-07 18:23:51 --> Helper loaded: file_helper
INFO - 2023-05-07 18:23:51 --> Helper loaded: html_helper
INFO - 2023-05-07 18:23:51 --> Helper loaded: text_helper
INFO - 2023-05-07 18:23:51 --> Helper loaded: form_helper
INFO - 2023-05-07 18:23:51 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:23:51 --> Helper loaded: security_helper
INFO - 2023-05-07 18:23:51 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:23:51 --> Database Driver Class Initialized
INFO - 2023-05-07 18:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:23:51 --> Parser Class Initialized
INFO - 2023-05-07 18:23:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:23:51 --> Pagination Class Initialized
INFO - 2023-05-07 18:23:51 --> Form Validation Class Initialized
INFO - 2023-05-07 18:23:51 --> Controller Class Initialized
INFO - 2023-05-07 18:23:51 --> Model Class Initialized
DEBUG - 2023-05-07 18:23:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:23:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:23:51 --> Model Class Initialized
INFO - 2023-05-07 18:23:51 --> Model Class Initialized
INFO - 2023-05-07 18:23:51 --> Final output sent to browser
DEBUG - 2023-05-07 18:23:51 --> Total execution time: 0.0210
ERROR - 2023-05-07 18:24:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:24:01 --> Config Class Initialized
INFO - 2023-05-07 18:24:01 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:24:01 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:24:01 --> Utf8 Class Initialized
INFO - 2023-05-07 18:24:01 --> URI Class Initialized
INFO - 2023-05-07 18:24:01 --> Router Class Initialized
INFO - 2023-05-07 18:24:01 --> Output Class Initialized
INFO - 2023-05-07 18:24:01 --> Security Class Initialized
DEBUG - 2023-05-07 18:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:24:01 --> Input Class Initialized
INFO - 2023-05-07 18:24:01 --> Language Class Initialized
INFO - 2023-05-07 18:24:01 --> Loader Class Initialized
INFO - 2023-05-07 18:24:01 --> Helper loaded: url_helper
INFO - 2023-05-07 18:24:01 --> Helper loaded: file_helper
INFO - 2023-05-07 18:24:01 --> Helper loaded: html_helper
INFO - 2023-05-07 18:24:01 --> Helper loaded: text_helper
INFO - 2023-05-07 18:24:01 --> Helper loaded: form_helper
INFO - 2023-05-07 18:24:01 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:24:01 --> Helper loaded: security_helper
INFO - 2023-05-07 18:24:01 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:24:01 --> Database Driver Class Initialized
INFO - 2023-05-07 18:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:24:01 --> Parser Class Initialized
INFO - 2023-05-07 18:24:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:24:01 --> Pagination Class Initialized
INFO - 2023-05-07 18:24:01 --> Form Validation Class Initialized
INFO - 2023-05-07 18:24:01 --> Controller Class Initialized
INFO - 2023-05-07 18:24:01 --> Model Class Initialized
DEBUG - 2023-05-07 18:24:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:24:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:24:01 --> Model Class Initialized
INFO - 2023-05-07 18:24:01 --> Final output sent to browser
DEBUG - 2023-05-07 18:24:01 --> Total execution time: 0.0166
ERROR - 2023-05-07 18:24:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:24:10 --> Config Class Initialized
INFO - 2023-05-07 18:24:10 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:24:10 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:24:10 --> Utf8 Class Initialized
INFO - 2023-05-07 18:24:10 --> URI Class Initialized
INFO - 2023-05-07 18:24:10 --> Router Class Initialized
INFO - 2023-05-07 18:24:10 --> Output Class Initialized
INFO - 2023-05-07 18:24:10 --> Security Class Initialized
DEBUG - 2023-05-07 18:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:24:10 --> Input Class Initialized
INFO - 2023-05-07 18:24:10 --> Language Class Initialized
INFO - 2023-05-07 18:24:10 --> Loader Class Initialized
INFO - 2023-05-07 18:24:10 --> Helper loaded: url_helper
INFO - 2023-05-07 18:24:10 --> Helper loaded: file_helper
INFO - 2023-05-07 18:24:10 --> Helper loaded: html_helper
INFO - 2023-05-07 18:24:10 --> Helper loaded: text_helper
INFO - 2023-05-07 18:24:10 --> Helper loaded: form_helper
INFO - 2023-05-07 18:24:10 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:24:10 --> Helper loaded: security_helper
INFO - 2023-05-07 18:24:10 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:24:10 --> Database Driver Class Initialized
INFO - 2023-05-07 18:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:24:10 --> Parser Class Initialized
INFO - 2023-05-07 18:24:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:24:10 --> Pagination Class Initialized
INFO - 2023-05-07 18:24:10 --> Form Validation Class Initialized
INFO - 2023-05-07 18:24:10 --> Controller Class Initialized
INFO - 2023-05-07 18:24:10 --> Model Class Initialized
DEBUG - 2023-05-07 18:24:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:24:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:24:10 --> Model Class Initialized
INFO - 2023-05-07 18:24:10 --> Final output sent to browser
DEBUG - 2023-05-07 18:24:10 --> Total execution time: 0.0193
ERROR - 2023-05-07 18:24:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:24:15 --> Config Class Initialized
INFO - 2023-05-07 18:24:15 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:24:15 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:24:15 --> Utf8 Class Initialized
INFO - 2023-05-07 18:24:15 --> URI Class Initialized
INFO - 2023-05-07 18:24:15 --> Router Class Initialized
INFO - 2023-05-07 18:24:15 --> Output Class Initialized
INFO - 2023-05-07 18:24:15 --> Security Class Initialized
DEBUG - 2023-05-07 18:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:24:15 --> Input Class Initialized
INFO - 2023-05-07 18:24:15 --> Language Class Initialized
INFO - 2023-05-07 18:24:15 --> Loader Class Initialized
INFO - 2023-05-07 18:24:15 --> Helper loaded: url_helper
INFO - 2023-05-07 18:24:15 --> Helper loaded: file_helper
INFO - 2023-05-07 18:24:15 --> Helper loaded: html_helper
INFO - 2023-05-07 18:24:15 --> Helper loaded: text_helper
INFO - 2023-05-07 18:24:15 --> Helper loaded: form_helper
INFO - 2023-05-07 18:24:15 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:24:15 --> Helper loaded: security_helper
INFO - 2023-05-07 18:24:15 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:24:15 --> Database Driver Class Initialized
INFO - 2023-05-07 18:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:24:15 --> Parser Class Initialized
INFO - 2023-05-07 18:24:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:24:15 --> Pagination Class Initialized
INFO - 2023-05-07 18:24:15 --> Form Validation Class Initialized
INFO - 2023-05-07 18:24:15 --> Controller Class Initialized
INFO - 2023-05-07 18:24:15 --> Model Class Initialized
DEBUG - 2023-05-07 18:24:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:24:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:24:15 --> Model Class Initialized
INFO - 2023-05-07 18:24:15 --> Final output sent to browser
DEBUG - 2023-05-07 18:24:15 --> Total execution time: 0.0155
ERROR - 2023-05-07 18:24:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:24:19 --> Config Class Initialized
INFO - 2023-05-07 18:24:19 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:24:19 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:24:19 --> Utf8 Class Initialized
INFO - 2023-05-07 18:24:19 --> URI Class Initialized
INFO - 2023-05-07 18:24:19 --> Router Class Initialized
INFO - 2023-05-07 18:24:19 --> Output Class Initialized
INFO - 2023-05-07 18:24:19 --> Security Class Initialized
DEBUG - 2023-05-07 18:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:24:19 --> Input Class Initialized
INFO - 2023-05-07 18:24:19 --> Language Class Initialized
INFO - 2023-05-07 18:24:19 --> Loader Class Initialized
INFO - 2023-05-07 18:24:19 --> Helper loaded: url_helper
INFO - 2023-05-07 18:24:19 --> Helper loaded: file_helper
INFO - 2023-05-07 18:24:19 --> Helper loaded: html_helper
INFO - 2023-05-07 18:24:19 --> Helper loaded: text_helper
INFO - 2023-05-07 18:24:19 --> Helper loaded: form_helper
INFO - 2023-05-07 18:24:19 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:24:19 --> Helper loaded: security_helper
INFO - 2023-05-07 18:24:19 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:24:19 --> Database Driver Class Initialized
INFO - 2023-05-07 18:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:24:19 --> Parser Class Initialized
INFO - 2023-05-07 18:24:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:24:19 --> Pagination Class Initialized
INFO - 2023-05-07 18:24:19 --> Form Validation Class Initialized
INFO - 2023-05-07 18:24:19 --> Controller Class Initialized
INFO - 2023-05-07 18:24:19 --> Model Class Initialized
DEBUG - 2023-05-07 18:24:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:24:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:24:19 --> Model Class Initialized
INFO - 2023-05-07 18:24:19 --> Final output sent to browser
DEBUG - 2023-05-07 18:24:19 --> Total execution time: 0.0164
ERROR - 2023-05-07 18:24:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:24:25 --> Config Class Initialized
INFO - 2023-05-07 18:24:25 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:24:25 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:24:25 --> Utf8 Class Initialized
INFO - 2023-05-07 18:24:25 --> URI Class Initialized
INFO - 2023-05-07 18:24:25 --> Router Class Initialized
INFO - 2023-05-07 18:24:25 --> Output Class Initialized
INFO - 2023-05-07 18:24:25 --> Security Class Initialized
DEBUG - 2023-05-07 18:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:24:25 --> Input Class Initialized
INFO - 2023-05-07 18:24:25 --> Language Class Initialized
INFO - 2023-05-07 18:24:25 --> Loader Class Initialized
INFO - 2023-05-07 18:24:25 --> Helper loaded: url_helper
INFO - 2023-05-07 18:24:25 --> Helper loaded: file_helper
INFO - 2023-05-07 18:24:25 --> Helper loaded: html_helper
INFO - 2023-05-07 18:24:25 --> Helper loaded: text_helper
INFO - 2023-05-07 18:24:25 --> Helper loaded: form_helper
INFO - 2023-05-07 18:24:25 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:24:25 --> Helper loaded: security_helper
INFO - 2023-05-07 18:24:25 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:24:25 --> Database Driver Class Initialized
INFO - 2023-05-07 18:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:24:25 --> Parser Class Initialized
INFO - 2023-05-07 18:24:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:24:25 --> Pagination Class Initialized
INFO - 2023-05-07 18:24:25 --> Form Validation Class Initialized
INFO - 2023-05-07 18:24:25 --> Controller Class Initialized
INFO - 2023-05-07 18:24:25 --> Model Class Initialized
DEBUG - 2023-05-07 18:24:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:24:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:24:25 --> Model Class Initialized
INFO - 2023-05-07 18:24:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-05-07 18:24:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:24:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:24:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:24:25 --> Model Class Initialized
INFO - 2023-05-07 18:24:25 --> Model Class Initialized
INFO - 2023-05-07 18:24:25 --> Model Class Initialized
INFO - 2023-05-07 18:24:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:24:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:24:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:24:25 --> Final output sent to browser
DEBUG - 2023-05-07 18:24:25 --> Total execution time: 0.0596
ERROR - 2023-05-07 18:24:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:24:26 --> Config Class Initialized
INFO - 2023-05-07 18:24:26 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:24:26 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:24:26 --> Utf8 Class Initialized
INFO - 2023-05-07 18:24:26 --> URI Class Initialized
INFO - 2023-05-07 18:24:26 --> Router Class Initialized
INFO - 2023-05-07 18:24:26 --> Output Class Initialized
INFO - 2023-05-07 18:24:26 --> Security Class Initialized
DEBUG - 2023-05-07 18:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:24:26 --> Input Class Initialized
INFO - 2023-05-07 18:24:26 --> Language Class Initialized
INFO - 2023-05-07 18:24:26 --> Loader Class Initialized
INFO - 2023-05-07 18:24:26 --> Helper loaded: url_helper
INFO - 2023-05-07 18:24:26 --> Helper loaded: file_helper
INFO - 2023-05-07 18:24:26 --> Helper loaded: html_helper
INFO - 2023-05-07 18:24:26 --> Helper loaded: text_helper
INFO - 2023-05-07 18:24:26 --> Helper loaded: form_helper
INFO - 2023-05-07 18:24:26 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:24:26 --> Helper loaded: security_helper
INFO - 2023-05-07 18:24:26 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:24:26 --> Database Driver Class Initialized
INFO - 2023-05-07 18:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:24:26 --> Parser Class Initialized
INFO - 2023-05-07 18:24:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:24:26 --> Pagination Class Initialized
INFO - 2023-05-07 18:24:26 --> Form Validation Class Initialized
INFO - 2023-05-07 18:24:26 --> Controller Class Initialized
INFO - 2023-05-07 18:24:26 --> Model Class Initialized
DEBUG - 2023-05-07 18:24:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:24:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:24:26 --> Model Class Initialized
INFO - 2023-05-07 18:24:26 --> Final output sent to browser
DEBUG - 2023-05-07 18:24:26 --> Total execution time: 0.0192
ERROR - 2023-05-07 18:24:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:24:30 --> Config Class Initialized
INFO - 2023-05-07 18:24:30 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:24:30 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:24:30 --> Utf8 Class Initialized
INFO - 2023-05-07 18:24:30 --> URI Class Initialized
INFO - 2023-05-07 18:24:30 --> Router Class Initialized
INFO - 2023-05-07 18:24:30 --> Output Class Initialized
INFO - 2023-05-07 18:24:30 --> Security Class Initialized
DEBUG - 2023-05-07 18:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:24:30 --> Input Class Initialized
INFO - 2023-05-07 18:24:30 --> Language Class Initialized
INFO - 2023-05-07 18:24:30 --> Loader Class Initialized
INFO - 2023-05-07 18:24:30 --> Helper loaded: url_helper
INFO - 2023-05-07 18:24:30 --> Helper loaded: file_helper
INFO - 2023-05-07 18:24:30 --> Helper loaded: html_helper
INFO - 2023-05-07 18:24:30 --> Helper loaded: text_helper
INFO - 2023-05-07 18:24:30 --> Helper loaded: form_helper
INFO - 2023-05-07 18:24:30 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:24:30 --> Helper loaded: security_helper
INFO - 2023-05-07 18:24:30 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:24:30 --> Database Driver Class Initialized
INFO - 2023-05-07 18:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:24:30 --> Parser Class Initialized
INFO - 2023-05-07 18:24:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:24:30 --> Pagination Class Initialized
INFO - 2023-05-07 18:24:30 --> Form Validation Class Initialized
INFO - 2023-05-07 18:24:30 --> Controller Class Initialized
INFO - 2023-05-07 18:24:30 --> Model Class Initialized
DEBUG - 2023-05-07 18:24:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:24:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:24:30 --> Model Class Initialized
INFO - 2023-05-07 18:24:30 --> Final output sent to browser
DEBUG - 2023-05-07 18:24:30 --> Total execution time: 0.0192
ERROR - 2023-05-07 18:25:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:25:50 --> Config Class Initialized
INFO - 2023-05-07 18:25:50 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:25:50 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:25:50 --> Utf8 Class Initialized
INFO - 2023-05-07 18:25:50 --> URI Class Initialized
INFO - 2023-05-07 18:25:50 --> Router Class Initialized
INFO - 2023-05-07 18:25:50 --> Output Class Initialized
INFO - 2023-05-07 18:25:50 --> Security Class Initialized
DEBUG - 2023-05-07 18:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:25:50 --> Input Class Initialized
INFO - 2023-05-07 18:25:50 --> Language Class Initialized
INFO - 2023-05-07 18:25:50 --> Loader Class Initialized
INFO - 2023-05-07 18:25:50 --> Helper loaded: url_helper
INFO - 2023-05-07 18:25:50 --> Helper loaded: file_helper
INFO - 2023-05-07 18:25:50 --> Helper loaded: html_helper
INFO - 2023-05-07 18:25:50 --> Helper loaded: text_helper
INFO - 2023-05-07 18:25:50 --> Helper loaded: form_helper
INFO - 2023-05-07 18:25:50 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:25:50 --> Helper loaded: security_helper
INFO - 2023-05-07 18:25:50 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:25:50 --> Database Driver Class Initialized
INFO - 2023-05-07 18:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:25:50 --> Parser Class Initialized
INFO - 2023-05-07 18:25:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:25:50 --> Pagination Class Initialized
INFO - 2023-05-07 18:25:50 --> Form Validation Class Initialized
INFO - 2023-05-07 18:25:50 --> Controller Class Initialized
INFO - 2023-05-07 18:25:50 --> Model Class Initialized
DEBUG - 2023-05-07 18:25:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:25:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:25:50 --> Model Class Initialized
INFO - 2023-05-07 18:25:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-05-07 18:25:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:25:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:25:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:25:50 --> Model Class Initialized
INFO - 2023-05-07 18:25:50 --> Model Class Initialized
INFO - 2023-05-07 18:25:50 --> Model Class Initialized
INFO - 2023-05-07 18:25:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:25:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:25:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:25:50 --> Final output sent to browser
DEBUG - 2023-05-07 18:25:50 --> Total execution time: 0.0627
ERROR - 2023-05-07 18:25:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:25:51 --> Config Class Initialized
INFO - 2023-05-07 18:25:51 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:25:51 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:25:51 --> Utf8 Class Initialized
INFO - 2023-05-07 18:25:51 --> URI Class Initialized
INFO - 2023-05-07 18:25:51 --> Router Class Initialized
INFO - 2023-05-07 18:25:51 --> Output Class Initialized
INFO - 2023-05-07 18:25:51 --> Security Class Initialized
DEBUG - 2023-05-07 18:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:25:51 --> Input Class Initialized
INFO - 2023-05-07 18:25:51 --> Language Class Initialized
INFO - 2023-05-07 18:25:51 --> Loader Class Initialized
INFO - 2023-05-07 18:25:51 --> Helper loaded: url_helper
INFO - 2023-05-07 18:25:51 --> Helper loaded: file_helper
INFO - 2023-05-07 18:25:51 --> Helper loaded: html_helper
INFO - 2023-05-07 18:25:51 --> Helper loaded: text_helper
INFO - 2023-05-07 18:25:51 --> Helper loaded: form_helper
INFO - 2023-05-07 18:25:51 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:25:51 --> Helper loaded: security_helper
INFO - 2023-05-07 18:25:51 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:25:51 --> Database Driver Class Initialized
INFO - 2023-05-07 18:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:25:51 --> Parser Class Initialized
INFO - 2023-05-07 18:25:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:25:51 --> Pagination Class Initialized
INFO - 2023-05-07 18:25:51 --> Form Validation Class Initialized
INFO - 2023-05-07 18:25:51 --> Controller Class Initialized
INFO - 2023-05-07 18:25:51 --> Model Class Initialized
DEBUG - 2023-05-07 18:25:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:25:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:25:51 --> Model Class Initialized
INFO - 2023-05-07 18:25:51 --> Final output sent to browser
DEBUG - 2023-05-07 18:25:51 --> Total execution time: 0.0272
ERROR - 2023-05-07 18:25:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:25:57 --> Config Class Initialized
INFO - 2023-05-07 18:25:57 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:25:57 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:25:57 --> Utf8 Class Initialized
INFO - 2023-05-07 18:25:57 --> URI Class Initialized
INFO - 2023-05-07 18:25:57 --> Router Class Initialized
INFO - 2023-05-07 18:25:57 --> Output Class Initialized
INFO - 2023-05-07 18:25:57 --> Security Class Initialized
DEBUG - 2023-05-07 18:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:25:57 --> Input Class Initialized
INFO - 2023-05-07 18:25:57 --> Language Class Initialized
INFO - 2023-05-07 18:25:57 --> Loader Class Initialized
INFO - 2023-05-07 18:25:57 --> Helper loaded: url_helper
INFO - 2023-05-07 18:25:57 --> Helper loaded: file_helper
INFO - 2023-05-07 18:25:57 --> Helper loaded: html_helper
INFO - 2023-05-07 18:25:57 --> Helper loaded: text_helper
INFO - 2023-05-07 18:25:57 --> Helper loaded: form_helper
INFO - 2023-05-07 18:25:57 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:25:57 --> Helper loaded: security_helper
INFO - 2023-05-07 18:25:57 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:25:57 --> Database Driver Class Initialized
INFO - 2023-05-07 18:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:25:57 --> Parser Class Initialized
INFO - 2023-05-07 18:25:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:25:57 --> Pagination Class Initialized
INFO - 2023-05-07 18:25:57 --> Form Validation Class Initialized
INFO - 2023-05-07 18:25:57 --> Controller Class Initialized
INFO - 2023-05-07 18:25:57 --> Model Class Initialized
DEBUG - 2023-05-07 18:25:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:25:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:25:57 --> Model Class Initialized
DEBUG - 2023-05-07 18:25:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:25:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-05-07 18:25:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:25:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:25:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:25:57 --> Model Class Initialized
INFO - 2023-05-07 18:25:57 --> Model Class Initialized
INFO - 2023-05-07 18:25:57 --> Model Class Initialized
INFO - 2023-05-07 18:25:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:25:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:25:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:25:57 --> Final output sent to browser
DEBUG - 2023-05-07 18:25:57 --> Total execution time: 0.0604
ERROR - 2023-05-07 18:26:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:26:09 --> Config Class Initialized
INFO - 2023-05-07 18:26:09 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:26:09 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:26:09 --> Utf8 Class Initialized
INFO - 2023-05-07 18:26:09 --> URI Class Initialized
INFO - 2023-05-07 18:26:09 --> Router Class Initialized
INFO - 2023-05-07 18:26:09 --> Output Class Initialized
INFO - 2023-05-07 18:26:09 --> Security Class Initialized
DEBUG - 2023-05-07 18:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:26:09 --> Input Class Initialized
INFO - 2023-05-07 18:26:09 --> Language Class Initialized
INFO - 2023-05-07 18:26:09 --> Loader Class Initialized
INFO - 2023-05-07 18:26:09 --> Helper loaded: url_helper
INFO - 2023-05-07 18:26:09 --> Helper loaded: file_helper
INFO - 2023-05-07 18:26:09 --> Helper loaded: html_helper
INFO - 2023-05-07 18:26:09 --> Helper loaded: text_helper
INFO - 2023-05-07 18:26:09 --> Helper loaded: form_helper
INFO - 2023-05-07 18:26:09 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:26:09 --> Helper loaded: security_helper
INFO - 2023-05-07 18:26:09 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:26:09 --> Database Driver Class Initialized
INFO - 2023-05-07 18:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:26:09 --> Parser Class Initialized
INFO - 2023-05-07 18:26:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:26:09 --> Pagination Class Initialized
INFO - 2023-05-07 18:26:09 --> Form Validation Class Initialized
INFO - 2023-05-07 18:26:09 --> Controller Class Initialized
INFO - 2023-05-07 18:26:09 --> Model Class Initialized
DEBUG - 2023-05-07 18:26:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:26:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:26:09 --> Model Class Initialized
INFO - 2023-05-07 18:26:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-05-07 18:26:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:26:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:26:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:26:09 --> Model Class Initialized
INFO - 2023-05-07 18:26:09 --> Model Class Initialized
INFO - 2023-05-07 18:26:09 --> Model Class Initialized
INFO - 2023-05-07 18:26:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:26:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:26:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:26:09 --> Final output sent to browser
DEBUG - 2023-05-07 18:26:09 --> Total execution time: 0.0656
ERROR - 2023-05-07 18:26:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:26:10 --> Config Class Initialized
INFO - 2023-05-07 18:26:10 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:26:10 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:26:10 --> Utf8 Class Initialized
INFO - 2023-05-07 18:26:10 --> URI Class Initialized
INFO - 2023-05-07 18:26:10 --> Router Class Initialized
INFO - 2023-05-07 18:26:10 --> Output Class Initialized
INFO - 2023-05-07 18:26:10 --> Security Class Initialized
DEBUG - 2023-05-07 18:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:26:10 --> Input Class Initialized
INFO - 2023-05-07 18:26:10 --> Language Class Initialized
INFO - 2023-05-07 18:26:10 --> Loader Class Initialized
INFO - 2023-05-07 18:26:10 --> Helper loaded: url_helper
INFO - 2023-05-07 18:26:10 --> Helper loaded: file_helper
INFO - 2023-05-07 18:26:10 --> Helper loaded: html_helper
INFO - 2023-05-07 18:26:10 --> Helper loaded: text_helper
INFO - 2023-05-07 18:26:10 --> Helper loaded: form_helper
INFO - 2023-05-07 18:26:10 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:26:10 --> Helper loaded: security_helper
INFO - 2023-05-07 18:26:10 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:26:10 --> Database Driver Class Initialized
INFO - 2023-05-07 18:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:26:10 --> Parser Class Initialized
INFO - 2023-05-07 18:26:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:26:10 --> Pagination Class Initialized
INFO - 2023-05-07 18:26:10 --> Form Validation Class Initialized
INFO - 2023-05-07 18:26:10 --> Controller Class Initialized
INFO - 2023-05-07 18:26:10 --> Model Class Initialized
DEBUG - 2023-05-07 18:26:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:26:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:26:10 --> Model Class Initialized
INFO - 2023-05-07 18:26:10 --> Final output sent to browser
DEBUG - 2023-05-07 18:26:10 --> Total execution time: 0.0275
ERROR - 2023-05-07 18:26:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:26:13 --> Config Class Initialized
INFO - 2023-05-07 18:26:13 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:26:13 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:26:13 --> Utf8 Class Initialized
INFO - 2023-05-07 18:26:13 --> URI Class Initialized
INFO - 2023-05-07 18:26:13 --> Router Class Initialized
INFO - 2023-05-07 18:26:13 --> Output Class Initialized
INFO - 2023-05-07 18:26:13 --> Security Class Initialized
DEBUG - 2023-05-07 18:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:26:13 --> Input Class Initialized
INFO - 2023-05-07 18:26:13 --> Language Class Initialized
INFO - 2023-05-07 18:26:13 --> Loader Class Initialized
INFO - 2023-05-07 18:26:13 --> Helper loaded: url_helper
INFO - 2023-05-07 18:26:13 --> Helper loaded: file_helper
INFO - 2023-05-07 18:26:13 --> Helper loaded: html_helper
INFO - 2023-05-07 18:26:13 --> Helper loaded: text_helper
INFO - 2023-05-07 18:26:13 --> Helper loaded: form_helper
INFO - 2023-05-07 18:26:13 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:26:13 --> Helper loaded: security_helper
INFO - 2023-05-07 18:26:13 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:26:13 --> Database Driver Class Initialized
INFO - 2023-05-07 18:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:26:13 --> Parser Class Initialized
INFO - 2023-05-07 18:26:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:26:13 --> Pagination Class Initialized
INFO - 2023-05-07 18:26:13 --> Form Validation Class Initialized
INFO - 2023-05-07 18:26:13 --> Controller Class Initialized
INFO - 2023-05-07 18:26:13 --> Model Class Initialized
DEBUG - 2023-05-07 18:26:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:26:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:26:13 --> Model Class Initialized
DEBUG - 2023-05-07 18:26:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:26:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-05-07 18:26:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:26:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:26:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:26:13 --> Model Class Initialized
INFO - 2023-05-07 18:26:13 --> Model Class Initialized
INFO - 2023-05-07 18:26:13 --> Model Class Initialized
INFO - 2023-05-07 18:26:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:26:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:26:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:26:13 --> Final output sent to browser
DEBUG - 2023-05-07 18:26:13 --> Total execution time: 0.0622
ERROR - 2023-05-07 18:26:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:26:17 --> Config Class Initialized
INFO - 2023-05-07 18:26:17 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:26:17 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:26:17 --> Utf8 Class Initialized
INFO - 2023-05-07 18:26:17 --> URI Class Initialized
INFO - 2023-05-07 18:26:17 --> Router Class Initialized
INFO - 2023-05-07 18:26:17 --> Output Class Initialized
INFO - 2023-05-07 18:26:17 --> Security Class Initialized
DEBUG - 2023-05-07 18:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:26:17 --> Input Class Initialized
INFO - 2023-05-07 18:26:17 --> Language Class Initialized
INFO - 2023-05-07 18:26:17 --> Loader Class Initialized
INFO - 2023-05-07 18:26:17 --> Helper loaded: url_helper
INFO - 2023-05-07 18:26:17 --> Helper loaded: file_helper
INFO - 2023-05-07 18:26:17 --> Helper loaded: html_helper
INFO - 2023-05-07 18:26:17 --> Helper loaded: text_helper
INFO - 2023-05-07 18:26:17 --> Helper loaded: form_helper
INFO - 2023-05-07 18:26:17 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:26:17 --> Helper loaded: security_helper
INFO - 2023-05-07 18:26:17 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:26:17 --> Database Driver Class Initialized
INFO - 2023-05-07 18:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:26:17 --> Parser Class Initialized
INFO - 2023-05-07 18:26:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:26:17 --> Pagination Class Initialized
INFO - 2023-05-07 18:26:17 --> Form Validation Class Initialized
INFO - 2023-05-07 18:26:17 --> Controller Class Initialized
INFO - 2023-05-07 18:26:17 --> Model Class Initialized
DEBUG - 2023-05-07 18:26:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:26:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:26:17 --> Model Class Initialized
INFO - 2023-05-07 18:26:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-05-07 18:26:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:26:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:26:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:26:17 --> Model Class Initialized
INFO - 2023-05-07 18:26:17 --> Model Class Initialized
INFO - 2023-05-07 18:26:17 --> Model Class Initialized
INFO - 2023-05-07 18:26:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:26:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:26:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:26:17 --> Final output sent to browser
DEBUG - 2023-05-07 18:26:17 --> Total execution time: 0.0632
ERROR - 2023-05-07 18:26:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:26:18 --> Config Class Initialized
INFO - 2023-05-07 18:26:18 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:26:18 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:26:18 --> Utf8 Class Initialized
INFO - 2023-05-07 18:26:18 --> URI Class Initialized
INFO - 2023-05-07 18:26:18 --> Router Class Initialized
INFO - 2023-05-07 18:26:18 --> Output Class Initialized
INFO - 2023-05-07 18:26:18 --> Security Class Initialized
DEBUG - 2023-05-07 18:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:26:18 --> Input Class Initialized
INFO - 2023-05-07 18:26:18 --> Language Class Initialized
INFO - 2023-05-07 18:26:18 --> Loader Class Initialized
INFO - 2023-05-07 18:26:18 --> Helper loaded: url_helper
INFO - 2023-05-07 18:26:18 --> Helper loaded: file_helper
INFO - 2023-05-07 18:26:18 --> Helper loaded: html_helper
INFO - 2023-05-07 18:26:18 --> Helper loaded: text_helper
INFO - 2023-05-07 18:26:18 --> Helper loaded: form_helper
INFO - 2023-05-07 18:26:18 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:26:18 --> Helper loaded: security_helper
INFO - 2023-05-07 18:26:18 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:26:18 --> Database Driver Class Initialized
INFO - 2023-05-07 18:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:26:18 --> Parser Class Initialized
INFO - 2023-05-07 18:26:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:26:18 --> Pagination Class Initialized
INFO - 2023-05-07 18:26:18 --> Form Validation Class Initialized
INFO - 2023-05-07 18:26:18 --> Controller Class Initialized
INFO - 2023-05-07 18:26:18 --> Model Class Initialized
DEBUG - 2023-05-07 18:26:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:26:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:26:18 --> Model Class Initialized
INFO - 2023-05-07 18:26:18 --> Final output sent to browser
DEBUG - 2023-05-07 18:26:18 --> Total execution time: 0.0287
ERROR - 2023-05-07 18:26:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:26:20 --> Config Class Initialized
INFO - 2023-05-07 18:26:20 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:26:20 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:26:20 --> Utf8 Class Initialized
INFO - 2023-05-07 18:26:20 --> URI Class Initialized
INFO - 2023-05-07 18:26:20 --> Router Class Initialized
INFO - 2023-05-07 18:26:20 --> Output Class Initialized
INFO - 2023-05-07 18:26:20 --> Security Class Initialized
DEBUG - 2023-05-07 18:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:26:20 --> Input Class Initialized
INFO - 2023-05-07 18:26:20 --> Language Class Initialized
INFO - 2023-05-07 18:26:20 --> Loader Class Initialized
INFO - 2023-05-07 18:26:20 --> Helper loaded: url_helper
INFO - 2023-05-07 18:26:20 --> Helper loaded: file_helper
INFO - 2023-05-07 18:26:20 --> Helper loaded: html_helper
INFO - 2023-05-07 18:26:20 --> Helper loaded: text_helper
INFO - 2023-05-07 18:26:20 --> Helper loaded: form_helper
INFO - 2023-05-07 18:26:20 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:26:20 --> Helper loaded: security_helper
INFO - 2023-05-07 18:26:20 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:26:20 --> Database Driver Class Initialized
INFO - 2023-05-07 18:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:26:20 --> Parser Class Initialized
INFO - 2023-05-07 18:26:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:26:20 --> Pagination Class Initialized
INFO - 2023-05-07 18:26:20 --> Form Validation Class Initialized
INFO - 2023-05-07 18:26:20 --> Controller Class Initialized
INFO - 2023-05-07 18:26:20 --> Model Class Initialized
DEBUG - 2023-05-07 18:26:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:26:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:26:20 --> Model Class Initialized
DEBUG - 2023-05-07 18:26:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:26:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-05-07 18:26:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:26:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:26:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:26:20 --> Model Class Initialized
INFO - 2023-05-07 18:26:20 --> Model Class Initialized
INFO - 2023-05-07 18:26:20 --> Model Class Initialized
INFO - 2023-05-07 18:26:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:26:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:26:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:26:20 --> Final output sent to browser
DEBUG - 2023-05-07 18:26:20 --> Total execution time: 0.0726
ERROR - 2023-05-07 18:26:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:26:25 --> Config Class Initialized
INFO - 2023-05-07 18:26:25 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:26:25 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:26:25 --> Utf8 Class Initialized
INFO - 2023-05-07 18:26:25 --> URI Class Initialized
INFO - 2023-05-07 18:26:25 --> Router Class Initialized
INFO - 2023-05-07 18:26:25 --> Output Class Initialized
INFO - 2023-05-07 18:26:25 --> Security Class Initialized
DEBUG - 2023-05-07 18:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:26:25 --> Input Class Initialized
INFO - 2023-05-07 18:26:25 --> Language Class Initialized
INFO - 2023-05-07 18:26:25 --> Loader Class Initialized
INFO - 2023-05-07 18:26:25 --> Helper loaded: url_helper
INFO - 2023-05-07 18:26:25 --> Helper loaded: file_helper
INFO - 2023-05-07 18:26:25 --> Helper loaded: html_helper
INFO - 2023-05-07 18:26:25 --> Helper loaded: text_helper
INFO - 2023-05-07 18:26:25 --> Helper loaded: form_helper
INFO - 2023-05-07 18:26:25 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:26:25 --> Helper loaded: security_helper
INFO - 2023-05-07 18:26:25 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:26:25 --> Database Driver Class Initialized
INFO - 2023-05-07 18:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:26:25 --> Parser Class Initialized
INFO - 2023-05-07 18:26:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:26:25 --> Pagination Class Initialized
INFO - 2023-05-07 18:26:25 --> Form Validation Class Initialized
INFO - 2023-05-07 18:26:25 --> Controller Class Initialized
INFO - 2023-05-07 18:26:25 --> Model Class Initialized
DEBUG - 2023-05-07 18:26:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:26:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:26:25 --> Model Class Initialized
INFO - 2023-05-07 18:26:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest.php
DEBUG - 2023-05-07 18:26:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:26:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:26:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:26:25 --> Model Class Initialized
INFO - 2023-05-07 18:26:25 --> Model Class Initialized
INFO - 2023-05-07 18:26:25 --> Model Class Initialized
INFO - 2023-05-07 18:26:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:26:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:26:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:26:25 --> Final output sent to browser
DEBUG - 2023-05-07 18:26:25 --> Total execution time: 0.0633
ERROR - 2023-05-07 18:26:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:26:26 --> Config Class Initialized
INFO - 2023-05-07 18:26:26 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:26:26 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:26:26 --> Utf8 Class Initialized
INFO - 2023-05-07 18:26:26 --> URI Class Initialized
INFO - 2023-05-07 18:26:26 --> Router Class Initialized
INFO - 2023-05-07 18:26:26 --> Output Class Initialized
INFO - 2023-05-07 18:26:26 --> Security Class Initialized
DEBUG - 2023-05-07 18:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:26:26 --> Input Class Initialized
INFO - 2023-05-07 18:26:26 --> Language Class Initialized
INFO - 2023-05-07 18:26:26 --> Loader Class Initialized
INFO - 2023-05-07 18:26:26 --> Helper loaded: url_helper
INFO - 2023-05-07 18:26:26 --> Helper loaded: file_helper
INFO - 2023-05-07 18:26:26 --> Helper loaded: html_helper
INFO - 2023-05-07 18:26:26 --> Helper loaded: text_helper
INFO - 2023-05-07 18:26:26 --> Helper loaded: form_helper
INFO - 2023-05-07 18:26:26 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:26:26 --> Helper loaded: security_helper
INFO - 2023-05-07 18:26:26 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:26:26 --> Database Driver Class Initialized
INFO - 2023-05-07 18:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:26:26 --> Parser Class Initialized
INFO - 2023-05-07 18:26:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:26:26 --> Pagination Class Initialized
INFO - 2023-05-07 18:26:26 --> Form Validation Class Initialized
INFO - 2023-05-07 18:26:26 --> Controller Class Initialized
INFO - 2023-05-07 18:26:26 --> Model Class Initialized
DEBUG - 2023-05-07 18:26:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:26:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:26:26 --> Model Class Initialized
INFO - 2023-05-07 18:26:26 --> Final output sent to browser
DEBUG - 2023-05-07 18:26:26 --> Total execution time: 0.0180
ERROR - 2023-05-07 18:26:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:26:33 --> Config Class Initialized
INFO - 2023-05-07 18:26:33 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:26:33 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:26:33 --> Utf8 Class Initialized
INFO - 2023-05-07 18:26:33 --> URI Class Initialized
INFO - 2023-05-07 18:26:33 --> Router Class Initialized
INFO - 2023-05-07 18:26:33 --> Output Class Initialized
INFO - 2023-05-07 18:26:33 --> Security Class Initialized
DEBUG - 2023-05-07 18:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:26:33 --> Input Class Initialized
INFO - 2023-05-07 18:26:33 --> Language Class Initialized
INFO - 2023-05-07 18:26:33 --> Loader Class Initialized
INFO - 2023-05-07 18:26:33 --> Helper loaded: url_helper
INFO - 2023-05-07 18:26:33 --> Helper loaded: file_helper
INFO - 2023-05-07 18:26:33 --> Helper loaded: html_helper
INFO - 2023-05-07 18:26:33 --> Helper loaded: text_helper
INFO - 2023-05-07 18:26:33 --> Helper loaded: form_helper
INFO - 2023-05-07 18:26:33 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:26:33 --> Helper loaded: security_helper
INFO - 2023-05-07 18:26:33 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:26:33 --> Database Driver Class Initialized
INFO - 2023-05-07 18:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:26:33 --> Parser Class Initialized
INFO - 2023-05-07 18:26:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:26:33 --> Pagination Class Initialized
INFO - 2023-05-07 18:26:33 --> Form Validation Class Initialized
INFO - 2023-05-07 18:26:33 --> Controller Class Initialized
INFO - 2023-05-07 18:26:33 --> Model Class Initialized
DEBUG - 2023-05-07 18:26:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:26:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:26:33 --> Model Class Initialized
DEBUG - 2023-05-07 18:26:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:26:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-05-07 18:26:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:26:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:26:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:26:33 --> Model Class Initialized
INFO - 2023-05-07 18:26:33 --> Model Class Initialized
INFO - 2023-05-07 18:26:33 --> Model Class Initialized
INFO - 2023-05-07 18:26:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:26:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:26:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:26:33 --> Final output sent to browser
DEBUG - 2023-05-07 18:26:33 --> Total execution time: 0.0626
ERROR - 2023-05-07 18:27:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:27:01 --> Config Class Initialized
INFO - 2023-05-07 18:27:01 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:27:01 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:27:01 --> Utf8 Class Initialized
INFO - 2023-05-07 18:27:01 --> URI Class Initialized
INFO - 2023-05-07 18:27:01 --> Router Class Initialized
INFO - 2023-05-07 18:27:01 --> Output Class Initialized
INFO - 2023-05-07 18:27:01 --> Security Class Initialized
DEBUG - 2023-05-07 18:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:27:01 --> Input Class Initialized
INFO - 2023-05-07 18:27:01 --> Language Class Initialized
INFO - 2023-05-07 18:27:01 --> Loader Class Initialized
INFO - 2023-05-07 18:27:01 --> Helper loaded: url_helper
INFO - 2023-05-07 18:27:01 --> Helper loaded: file_helper
INFO - 2023-05-07 18:27:01 --> Helper loaded: html_helper
INFO - 2023-05-07 18:27:01 --> Helper loaded: text_helper
INFO - 2023-05-07 18:27:01 --> Helper loaded: form_helper
INFO - 2023-05-07 18:27:01 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:27:01 --> Helper loaded: security_helper
INFO - 2023-05-07 18:27:01 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:27:01 --> Database Driver Class Initialized
INFO - 2023-05-07 18:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:27:01 --> Parser Class Initialized
INFO - 2023-05-07 18:27:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:27:01 --> Pagination Class Initialized
INFO - 2023-05-07 18:27:01 --> Form Validation Class Initialized
INFO - 2023-05-07 18:27:01 --> Controller Class Initialized
DEBUG - 2023-05-07 18:27:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:27:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:27:01 --> Model Class Initialized
DEBUG - 2023-05-07 18:27:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:27:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:27:01 --> Ltarget class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:27:01 --> Model Class Initialized
DEBUG - 2023-05-07 18:27:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:27:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:27:01 --> Model Class Initialized
DEBUG - 2023-05-07 18:27:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:27:01 --> Model Class Initialized
INFO - 2023-05-07 18:27:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/target/target.php
DEBUG - 2023-05-07 18:27:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:27:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:27:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:27:01 --> Model Class Initialized
INFO - 2023-05-07 18:27:01 --> Model Class Initialized
INFO - 2023-05-07 18:27:01 --> Model Class Initialized
INFO - 2023-05-07 18:27:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:27:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:27:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:27:01 --> Final output sent to browser
DEBUG - 2023-05-07 18:27:01 --> Total execution time: 0.0662
ERROR - 2023-05-07 18:27:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:27:01 --> Config Class Initialized
INFO - 2023-05-07 18:27:01 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:27:01 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:27:01 --> Utf8 Class Initialized
INFO - 2023-05-07 18:27:01 --> URI Class Initialized
INFO - 2023-05-07 18:27:01 --> Router Class Initialized
INFO - 2023-05-07 18:27:01 --> Output Class Initialized
INFO - 2023-05-07 18:27:01 --> Security Class Initialized
DEBUG - 2023-05-07 18:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:27:01 --> Input Class Initialized
INFO - 2023-05-07 18:27:01 --> Language Class Initialized
INFO - 2023-05-07 18:27:01 --> Loader Class Initialized
INFO - 2023-05-07 18:27:01 --> Helper loaded: url_helper
INFO - 2023-05-07 18:27:01 --> Helper loaded: file_helper
INFO - 2023-05-07 18:27:01 --> Helper loaded: html_helper
INFO - 2023-05-07 18:27:01 --> Helper loaded: text_helper
INFO - 2023-05-07 18:27:01 --> Helper loaded: form_helper
INFO - 2023-05-07 18:27:01 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:27:01 --> Helper loaded: security_helper
INFO - 2023-05-07 18:27:01 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:27:01 --> Database Driver Class Initialized
INFO - 2023-05-07 18:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:27:01 --> Parser Class Initialized
INFO - 2023-05-07 18:27:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:27:01 --> Pagination Class Initialized
INFO - 2023-05-07 18:27:01 --> Form Validation Class Initialized
INFO - 2023-05-07 18:27:01 --> Controller Class Initialized
DEBUG - 2023-05-07 18:27:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:27:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:27:01 --> Model Class Initialized
DEBUG - 2023-05-07 18:27:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:27:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:27:01 --> Model Class Initialized
DEBUG - 2023-05-07 18:27:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:27:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:27:01 --> Model Class Initialized
DEBUG - 2023-05-07 18:27:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:27:01 --> Model Class Initialized
INFO - 2023-05-07 18:27:01 --> Final output sent to browser
DEBUG - 2023-05-07 18:27:01 --> Total execution time: 0.0210
ERROR - 2023-05-07 18:27:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:27:39 --> Config Class Initialized
INFO - 2023-05-07 18:27:39 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:27:39 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:27:39 --> Utf8 Class Initialized
INFO - 2023-05-07 18:27:39 --> URI Class Initialized
INFO - 2023-05-07 18:27:39 --> Router Class Initialized
INFO - 2023-05-07 18:27:39 --> Output Class Initialized
INFO - 2023-05-07 18:27:39 --> Security Class Initialized
DEBUG - 2023-05-07 18:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:27:39 --> Input Class Initialized
INFO - 2023-05-07 18:27:39 --> Language Class Initialized
INFO - 2023-05-07 18:27:39 --> Loader Class Initialized
INFO - 2023-05-07 18:27:39 --> Helper loaded: url_helper
INFO - 2023-05-07 18:27:39 --> Helper loaded: file_helper
INFO - 2023-05-07 18:27:39 --> Helper loaded: html_helper
INFO - 2023-05-07 18:27:39 --> Helper loaded: text_helper
INFO - 2023-05-07 18:27:39 --> Helper loaded: form_helper
INFO - 2023-05-07 18:27:39 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:27:39 --> Helper loaded: security_helper
INFO - 2023-05-07 18:27:39 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:27:39 --> Database Driver Class Initialized
INFO - 2023-05-07 18:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:27:39 --> Parser Class Initialized
INFO - 2023-05-07 18:27:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:27:39 --> Pagination Class Initialized
INFO - 2023-05-07 18:27:39 --> Form Validation Class Initialized
INFO - 2023-05-07 18:27:39 --> Controller Class Initialized
INFO - 2023-05-07 18:27:39 --> Model Class Initialized
DEBUG - 2023-05-07 18:27:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:27:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:27:39 --> Model Class Initialized
DEBUG - 2023-05-07 18:27:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:27:39 --> Model Class Initialized
INFO - 2023-05-07 18:27:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-05-07 18:27:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:27:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:27:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:27:39 --> Model Class Initialized
INFO - 2023-05-07 18:27:39 --> Model Class Initialized
INFO - 2023-05-07 18:27:39 --> Model Class Initialized
INFO - 2023-05-07 18:27:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:27:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:27:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:27:39 --> Final output sent to browser
DEBUG - 2023-05-07 18:27:39 --> Total execution time: 0.0676
ERROR - 2023-05-07 18:27:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:27:39 --> Config Class Initialized
INFO - 2023-05-07 18:27:39 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:27:39 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:27:39 --> Utf8 Class Initialized
INFO - 2023-05-07 18:27:39 --> URI Class Initialized
INFO - 2023-05-07 18:27:39 --> Router Class Initialized
INFO - 2023-05-07 18:27:39 --> Output Class Initialized
INFO - 2023-05-07 18:27:39 --> Security Class Initialized
DEBUG - 2023-05-07 18:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:27:39 --> Input Class Initialized
INFO - 2023-05-07 18:27:39 --> Language Class Initialized
INFO - 2023-05-07 18:27:39 --> Loader Class Initialized
INFO - 2023-05-07 18:27:39 --> Helper loaded: url_helper
INFO - 2023-05-07 18:27:39 --> Helper loaded: file_helper
INFO - 2023-05-07 18:27:39 --> Helper loaded: html_helper
INFO - 2023-05-07 18:27:39 --> Helper loaded: text_helper
INFO - 2023-05-07 18:27:39 --> Helper loaded: form_helper
INFO - 2023-05-07 18:27:39 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:27:39 --> Helper loaded: security_helper
INFO - 2023-05-07 18:27:39 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:27:39 --> Database Driver Class Initialized
INFO - 2023-05-07 18:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:27:39 --> Parser Class Initialized
INFO - 2023-05-07 18:27:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:27:39 --> Pagination Class Initialized
INFO - 2023-05-07 18:27:39 --> Form Validation Class Initialized
INFO - 2023-05-07 18:27:39 --> Controller Class Initialized
INFO - 2023-05-07 18:27:39 --> Model Class Initialized
DEBUG - 2023-05-07 18:27:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:27:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:27:39 --> Model Class Initialized
DEBUG - 2023-05-07 18:27:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:27:39 --> Model Class Initialized
INFO - 2023-05-07 18:27:39 --> Final output sent to browser
DEBUG - 2023-05-07 18:27:39 --> Total execution time: 0.0438
ERROR - 2023-05-07 18:27:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:27:44 --> Config Class Initialized
INFO - 2023-05-07 18:27:44 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:27:44 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:27:44 --> Utf8 Class Initialized
INFO - 2023-05-07 18:27:44 --> URI Class Initialized
INFO - 2023-05-07 18:27:44 --> Router Class Initialized
INFO - 2023-05-07 18:27:44 --> Output Class Initialized
INFO - 2023-05-07 18:27:44 --> Security Class Initialized
DEBUG - 2023-05-07 18:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:27:44 --> Input Class Initialized
INFO - 2023-05-07 18:27:44 --> Language Class Initialized
INFO - 2023-05-07 18:27:44 --> Loader Class Initialized
INFO - 2023-05-07 18:27:44 --> Helper loaded: url_helper
INFO - 2023-05-07 18:27:44 --> Helper loaded: file_helper
INFO - 2023-05-07 18:27:44 --> Helper loaded: html_helper
INFO - 2023-05-07 18:27:44 --> Helper loaded: text_helper
INFO - 2023-05-07 18:27:44 --> Helper loaded: form_helper
INFO - 2023-05-07 18:27:44 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:27:44 --> Helper loaded: security_helper
INFO - 2023-05-07 18:27:44 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:27:44 --> Database Driver Class Initialized
INFO - 2023-05-07 18:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:27:44 --> Parser Class Initialized
INFO - 2023-05-07 18:27:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:27:44 --> Pagination Class Initialized
INFO - 2023-05-07 18:27:44 --> Form Validation Class Initialized
INFO - 2023-05-07 18:27:44 --> Controller Class Initialized
INFO - 2023-05-07 18:27:44 --> Model Class Initialized
DEBUG - 2023-05-07 18:27:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:27:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:27:44 --> Model Class Initialized
DEBUG - 2023-05-07 18:27:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:27:44 --> Model Class Initialized
INFO - 2023-05-07 18:27:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html.php
DEBUG - 2023-05-07 18:27:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:27:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:27:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:27:44 --> Model Class Initialized
INFO - 2023-05-07 18:27:44 --> Model Class Initialized
INFO - 2023-05-07 18:27:44 --> Model Class Initialized
INFO - 2023-05-07 18:27:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:27:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:27:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:27:44 --> Final output sent to browser
DEBUG - 2023-05-07 18:27:44 --> Total execution time: 0.0719
ERROR - 2023-05-07 18:28:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:28:01 --> Config Class Initialized
INFO - 2023-05-07 18:28:01 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:28:01 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:28:01 --> Utf8 Class Initialized
INFO - 2023-05-07 18:28:01 --> URI Class Initialized
INFO - 2023-05-07 18:28:01 --> Router Class Initialized
INFO - 2023-05-07 18:28:01 --> Output Class Initialized
INFO - 2023-05-07 18:28:01 --> Security Class Initialized
DEBUG - 2023-05-07 18:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:28:01 --> Input Class Initialized
INFO - 2023-05-07 18:28:01 --> Language Class Initialized
INFO - 2023-05-07 18:28:01 --> Loader Class Initialized
INFO - 2023-05-07 18:28:01 --> Helper loaded: url_helper
INFO - 2023-05-07 18:28:01 --> Helper loaded: file_helper
INFO - 2023-05-07 18:28:01 --> Helper loaded: html_helper
INFO - 2023-05-07 18:28:01 --> Helper loaded: text_helper
INFO - 2023-05-07 18:28:01 --> Helper loaded: form_helper
INFO - 2023-05-07 18:28:01 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:28:01 --> Helper loaded: security_helper
INFO - 2023-05-07 18:28:01 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:28:01 --> Database Driver Class Initialized
INFO - 2023-05-07 18:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:28:01 --> Parser Class Initialized
INFO - 2023-05-07 18:28:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:28:01 --> Pagination Class Initialized
INFO - 2023-05-07 18:28:01 --> Form Validation Class Initialized
INFO - 2023-05-07 18:28:01 --> Controller Class Initialized
DEBUG - 2023-05-07 18:28:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:28:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:28:01 --> Model Class Initialized
DEBUG - 2023-05-07 18:28:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:28:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:28:01 --> Ltarget class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:28:01 --> Model Class Initialized
DEBUG - 2023-05-07 18:28:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:28:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:28:01 --> Model Class Initialized
DEBUG - 2023-05-07 18:28:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:28:01 --> Model Class Initialized
INFO - 2023-05-07 18:28:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/target/target.php
DEBUG - 2023-05-07 18:28:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:28:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:28:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:28:01 --> Model Class Initialized
INFO - 2023-05-07 18:28:01 --> Model Class Initialized
INFO - 2023-05-07 18:28:01 --> Model Class Initialized
INFO - 2023-05-07 18:28:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:28:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:28:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:28:01 --> Final output sent to browser
DEBUG - 2023-05-07 18:28:01 --> Total execution time: 0.0786
ERROR - 2023-05-07 18:28:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:28:01 --> Config Class Initialized
INFO - 2023-05-07 18:28:01 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:28:01 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:28:01 --> Utf8 Class Initialized
INFO - 2023-05-07 18:28:01 --> URI Class Initialized
INFO - 2023-05-07 18:28:01 --> Router Class Initialized
INFO - 2023-05-07 18:28:01 --> Output Class Initialized
INFO - 2023-05-07 18:28:01 --> Security Class Initialized
DEBUG - 2023-05-07 18:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:28:01 --> Input Class Initialized
INFO - 2023-05-07 18:28:01 --> Language Class Initialized
INFO - 2023-05-07 18:28:01 --> Loader Class Initialized
INFO - 2023-05-07 18:28:01 --> Helper loaded: url_helper
INFO - 2023-05-07 18:28:01 --> Helper loaded: file_helper
INFO - 2023-05-07 18:28:01 --> Helper loaded: html_helper
INFO - 2023-05-07 18:28:01 --> Helper loaded: text_helper
INFO - 2023-05-07 18:28:01 --> Helper loaded: form_helper
INFO - 2023-05-07 18:28:01 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:28:01 --> Helper loaded: security_helper
INFO - 2023-05-07 18:28:01 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:28:01 --> Database Driver Class Initialized
INFO - 2023-05-07 18:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:28:01 --> Parser Class Initialized
INFO - 2023-05-07 18:28:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:28:01 --> Pagination Class Initialized
INFO - 2023-05-07 18:28:01 --> Form Validation Class Initialized
INFO - 2023-05-07 18:28:01 --> Controller Class Initialized
DEBUG - 2023-05-07 18:28:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:28:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:28:01 --> Model Class Initialized
DEBUG - 2023-05-07 18:28:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:28:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:28:01 --> Ltarget class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:28:01 --> Model Class Initialized
DEBUG - 2023-05-07 18:28:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:28:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:28:01 --> Model Class Initialized
DEBUG - 2023-05-07 18:28:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:28:01 --> Model Class Initialized
INFO - 2023-05-07 18:28:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/target/target.php
DEBUG - 2023-05-07 18:28:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:28:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:28:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:28:01 --> Model Class Initialized
INFO - 2023-05-07 18:28:01 --> Model Class Initialized
INFO - 2023-05-07 18:28:01 --> Model Class Initialized
INFO - 2023-05-07 18:28:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:28:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:28:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:28:01 --> Final output sent to browser
DEBUG - 2023-05-07 18:28:01 --> Total execution time: 0.0653
ERROR - 2023-05-07 18:28:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:28:02 --> Config Class Initialized
INFO - 2023-05-07 18:28:02 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:28:02 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:28:02 --> Utf8 Class Initialized
INFO - 2023-05-07 18:28:02 --> URI Class Initialized
INFO - 2023-05-07 18:28:02 --> Router Class Initialized
INFO - 2023-05-07 18:28:02 --> Output Class Initialized
INFO - 2023-05-07 18:28:02 --> Security Class Initialized
DEBUG - 2023-05-07 18:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:28:02 --> Input Class Initialized
INFO - 2023-05-07 18:28:02 --> Language Class Initialized
INFO - 2023-05-07 18:28:02 --> Loader Class Initialized
INFO - 2023-05-07 18:28:02 --> Helper loaded: url_helper
INFO - 2023-05-07 18:28:02 --> Helper loaded: file_helper
INFO - 2023-05-07 18:28:02 --> Helper loaded: html_helper
INFO - 2023-05-07 18:28:02 --> Helper loaded: text_helper
INFO - 2023-05-07 18:28:02 --> Helper loaded: form_helper
INFO - 2023-05-07 18:28:02 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:28:02 --> Helper loaded: security_helper
INFO - 2023-05-07 18:28:02 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:28:02 --> Database Driver Class Initialized
INFO - 2023-05-07 18:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:28:02 --> Parser Class Initialized
INFO - 2023-05-07 18:28:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:28:02 --> Pagination Class Initialized
INFO - 2023-05-07 18:28:02 --> Form Validation Class Initialized
INFO - 2023-05-07 18:28:02 --> Controller Class Initialized
DEBUG - 2023-05-07 18:28:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:28:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:28:02 --> Model Class Initialized
DEBUG - 2023-05-07 18:28:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:28:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:28:02 --> Model Class Initialized
DEBUG - 2023-05-07 18:28:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:28:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:28:02 --> Model Class Initialized
DEBUG - 2023-05-07 18:28:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:28:02 --> Model Class Initialized
INFO - 2023-05-07 18:28:02 --> Final output sent to browser
DEBUG - 2023-05-07 18:28:02 --> Total execution time: 0.0200
ERROR - 2023-05-07 18:28:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:28:29 --> Config Class Initialized
INFO - 2023-05-07 18:28:29 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:28:29 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:28:29 --> Utf8 Class Initialized
INFO - 2023-05-07 18:28:29 --> URI Class Initialized
DEBUG - 2023-05-07 18:28:29 --> No URI present. Default controller set.
INFO - 2023-05-07 18:28:29 --> Router Class Initialized
INFO - 2023-05-07 18:28:29 --> Output Class Initialized
INFO - 2023-05-07 18:28:29 --> Security Class Initialized
DEBUG - 2023-05-07 18:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:28:29 --> Input Class Initialized
INFO - 2023-05-07 18:28:29 --> Language Class Initialized
INFO - 2023-05-07 18:28:29 --> Loader Class Initialized
INFO - 2023-05-07 18:28:29 --> Helper loaded: url_helper
INFO - 2023-05-07 18:28:29 --> Helper loaded: file_helper
INFO - 2023-05-07 18:28:29 --> Helper loaded: html_helper
INFO - 2023-05-07 18:28:29 --> Helper loaded: text_helper
INFO - 2023-05-07 18:28:29 --> Helper loaded: form_helper
INFO - 2023-05-07 18:28:29 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:28:29 --> Helper loaded: security_helper
INFO - 2023-05-07 18:28:29 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:28:29 --> Database Driver Class Initialized
INFO - 2023-05-07 18:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:28:29 --> Parser Class Initialized
INFO - 2023-05-07 18:28:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:28:29 --> Pagination Class Initialized
INFO - 2023-05-07 18:28:29 --> Form Validation Class Initialized
INFO - 2023-05-07 18:28:29 --> Controller Class Initialized
INFO - 2023-05-07 18:28:29 --> Model Class Initialized
DEBUG - 2023-05-07 18:28:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-07 18:28:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:28:30 --> Config Class Initialized
INFO - 2023-05-07 18:28:30 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:28:30 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:28:30 --> Utf8 Class Initialized
INFO - 2023-05-07 18:28:30 --> URI Class Initialized
INFO - 2023-05-07 18:28:30 --> Router Class Initialized
INFO - 2023-05-07 18:28:30 --> Output Class Initialized
INFO - 2023-05-07 18:28:30 --> Security Class Initialized
DEBUG - 2023-05-07 18:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:28:30 --> Input Class Initialized
INFO - 2023-05-07 18:28:30 --> Language Class Initialized
INFO - 2023-05-07 18:28:30 --> Loader Class Initialized
INFO - 2023-05-07 18:28:30 --> Helper loaded: url_helper
INFO - 2023-05-07 18:28:30 --> Helper loaded: file_helper
INFO - 2023-05-07 18:28:30 --> Helper loaded: html_helper
INFO - 2023-05-07 18:28:30 --> Helper loaded: text_helper
INFO - 2023-05-07 18:28:30 --> Helper loaded: form_helper
INFO - 2023-05-07 18:28:30 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:28:30 --> Helper loaded: security_helper
INFO - 2023-05-07 18:28:30 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:28:30 --> Database Driver Class Initialized
INFO - 2023-05-07 18:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:28:30 --> Parser Class Initialized
INFO - 2023-05-07 18:28:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:28:30 --> Pagination Class Initialized
INFO - 2023-05-07 18:28:30 --> Form Validation Class Initialized
INFO - 2023-05-07 18:28:30 --> Controller Class Initialized
INFO - 2023-05-07 18:28:30 --> Model Class Initialized
DEBUG - 2023-05-07 18:28:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:28:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-07 18:28:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:28:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:28:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:28:30 --> Model Class Initialized
INFO - 2023-05-07 18:28:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:28:30 --> Final output sent to browser
DEBUG - 2023-05-07 18:28:30 --> Total execution time: 0.0293
ERROR - 2023-05-07 18:28:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:28:33 --> Config Class Initialized
INFO - 2023-05-07 18:28:33 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:28:33 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:28:33 --> Utf8 Class Initialized
INFO - 2023-05-07 18:28:33 --> URI Class Initialized
INFO - 2023-05-07 18:28:33 --> Router Class Initialized
INFO - 2023-05-07 18:28:33 --> Output Class Initialized
INFO - 2023-05-07 18:28:33 --> Security Class Initialized
DEBUG - 2023-05-07 18:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:28:33 --> Input Class Initialized
INFO - 2023-05-07 18:28:33 --> Language Class Initialized
INFO - 2023-05-07 18:28:33 --> Loader Class Initialized
INFO - 2023-05-07 18:28:33 --> Helper loaded: url_helper
INFO - 2023-05-07 18:28:33 --> Helper loaded: file_helper
INFO - 2023-05-07 18:28:33 --> Helper loaded: html_helper
INFO - 2023-05-07 18:28:33 --> Helper loaded: text_helper
INFO - 2023-05-07 18:28:33 --> Helper loaded: form_helper
INFO - 2023-05-07 18:28:33 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:28:33 --> Helper loaded: security_helper
INFO - 2023-05-07 18:28:33 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:28:33 --> Database Driver Class Initialized
INFO - 2023-05-07 18:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:28:33 --> Parser Class Initialized
INFO - 2023-05-07 18:28:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:28:33 --> Pagination Class Initialized
INFO - 2023-05-07 18:28:33 --> Form Validation Class Initialized
INFO - 2023-05-07 18:28:33 --> Controller Class Initialized
DEBUG - 2023-05-07 18:28:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:28:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:28:33 --> Model Class Initialized
DEBUG - 2023-05-07 18:28:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:28:33 --> Model Class Initialized
DEBUG - 2023-05-07 18:28:33 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:28:33 --> Model Class Initialized
INFO - 2023-05-07 18:28:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-05-07 18:28:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:28:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:28:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:28:33 --> Model Class Initialized
INFO - 2023-05-07 18:28:33 --> Model Class Initialized
INFO - 2023-05-07 18:28:33 --> Model Class Initialized
INFO - 2023-05-07 18:28:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:28:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:28:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:28:33 --> Final output sent to browser
DEBUG - 2023-05-07 18:28:33 --> Total execution time: 0.0722
ERROR - 2023-05-07 18:28:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:28:33 --> Config Class Initialized
INFO - 2023-05-07 18:28:33 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:28:33 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:28:33 --> Utf8 Class Initialized
INFO - 2023-05-07 18:28:33 --> URI Class Initialized
INFO - 2023-05-07 18:28:33 --> Router Class Initialized
INFO - 2023-05-07 18:28:33 --> Output Class Initialized
INFO - 2023-05-07 18:28:33 --> Security Class Initialized
DEBUG - 2023-05-07 18:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:28:33 --> Input Class Initialized
INFO - 2023-05-07 18:28:33 --> Language Class Initialized
INFO - 2023-05-07 18:28:33 --> Loader Class Initialized
INFO - 2023-05-07 18:28:33 --> Helper loaded: url_helper
INFO - 2023-05-07 18:28:33 --> Helper loaded: file_helper
INFO - 2023-05-07 18:28:33 --> Helper loaded: html_helper
INFO - 2023-05-07 18:28:33 --> Helper loaded: text_helper
INFO - 2023-05-07 18:28:33 --> Helper loaded: form_helper
INFO - 2023-05-07 18:28:33 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:28:33 --> Helper loaded: security_helper
INFO - 2023-05-07 18:28:33 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:28:33 --> Database Driver Class Initialized
INFO - 2023-05-07 18:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:28:33 --> Parser Class Initialized
INFO - 2023-05-07 18:28:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:28:33 --> Pagination Class Initialized
INFO - 2023-05-07 18:28:33 --> Form Validation Class Initialized
INFO - 2023-05-07 18:28:33 --> Controller Class Initialized
DEBUG - 2023-05-07 18:28:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:28:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:28:33 --> Model Class Initialized
DEBUG - 2023-05-07 18:28:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:28:33 --> Model Class Initialized
INFO - 2023-05-07 18:28:33 --> Final output sent to browser
DEBUG - 2023-05-07 18:28:33 --> Total execution time: 0.0212
ERROR - 2023-05-07 18:28:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:28:40 --> Config Class Initialized
INFO - 2023-05-07 18:28:40 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:28:40 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:28:40 --> Utf8 Class Initialized
INFO - 2023-05-07 18:28:40 --> URI Class Initialized
INFO - 2023-05-07 18:28:40 --> Router Class Initialized
INFO - 2023-05-07 18:28:40 --> Output Class Initialized
INFO - 2023-05-07 18:28:40 --> Security Class Initialized
DEBUG - 2023-05-07 18:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:28:40 --> Input Class Initialized
INFO - 2023-05-07 18:28:40 --> Language Class Initialized
INFO - 2023-05-07 18:28:40 --> Loader Class Initialized
INFO - 2023-05-07 18:28:40 --> Helper loaded: url_helper
INFO - 2023-05-07 18:28:40 --> Helper loaded: file_helper
INFO - 2023-05-07 18:28:40 --> Helper loaded: html_helper
INFO - 2023-05-07 18:28:40 --> Helper loaded: text_helper
INFO - 2023-05-07 18:28:40 --> Helper loaded: form_helper
INFO - 2023-05-07 18:28:40 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:28:40 --> Helper loaded: security_helper
INFO - 2023-05-07 18:28:40 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:28:40 --> Database Driver Class Initialized
INFO - 2023-05-07 18:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:28:40 --> Parser Class Initialized
INFO - 2023-05-07 18:28:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:28:40 --> Pagination Class Initialized
INFO - 2023-05-07 18:28:40 --> Form Validation Class Initialized
INFO - 2023-05-07 18:28:40 --> Controller Class Initialized
DEBUG - 2023-05-07 18:28:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:28:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:28:40 --> Model Class Initialized
DEBUG - 2023-05-07 18:28:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:28:40 --> Model Class Initialized
INFO - 2023-05-07 18:28:40 --> Final output sent to browser
DEBUG - 2023-05-07 18:28:40 --> Total execution time: 0.0268
ERROR - 2023-05-07 18:28:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:28:48 --> Config Class Initialized
INFO - 2023-05-07 18:28:48 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:28:48 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:28:48 --> Utf8 Class Initialized
INFO - 2023-05-07 18:28:48 --> URI Class Initialized
INFO - 2023-05-07 18:28:48 --> Router Class Initialized
INFO - 2023-05-07 18:28:48 --> Output Class Initialized
INFO - 2023-05-07 18:28:48 --> Security Class Initialized
DEBUG - 2023-05-07 18:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:28:48 --> Input Class Initialized
INFO - 2023-05-07 18:28:48 --> Language Class Initialized
INFO - 2023-05-07 18:28:48 --> Loader Class Initialized
INFO - 2023-05-07 18:28:48 --> Helper loaded: url_helper
INFO - 2023-05-07 18:28:48 --> Helper loaded: file_helper
INFO - 2023-05-07 18:28:48 --> Helper loaded: html_helper
INFO - 2023-05-07 18:28:48 --> Helper loaded: text_helper
INFO - 2023-05-07 18:28:48 --> Helper loaded: form_helper
INFO - 2023-05-07 18:28:48 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:28:48 --> Helper loaded: security_helper
INFO - 2023-05-07 18:28:48 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:28:48 --> Database Driver Class Initialized
INFO - 2023-05-07 18:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:28:48 --> Parser Class Initialized
INFO - 2023-05-07 18:28:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:28:48 --> Pagination Class Initialized
INFO - 2023-05-07 18:28:48 --> Form Validation Class Initialized
INFO - 2023-05-07 18:28:48 --> Controller Class Initialized
DEBUG - 2023-05-07 18:28:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:28:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:28:48 --> Model Class Initialized
DEBUG - 2023-05-07 18:28:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:28:48 --> Model Class Initialized
INFO - 2023-05-07 18:28:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/view_customer.php
DEBUG - 2023-05-07 18:28:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:28:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:28:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:28:48 --> Model Class Initialized
INFO - 2023-05-07 18:28:48 --> Model Class Initialized
INFO - 2023-05-07 18:28:48 --> Model Class Initialized
INFO - 2023-05-07 18:28:48 --> Model Class Initialized
INFO - 2023-05-07 18:28:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:28:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:28:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:28:48 --> Final output sent to browser
DEBUG - 2023-05-07 18:28:48 --> Total execution time: 0.0657
ERROR - 2023-05-07 18:29:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:29:23 --> Config Class Initialized
INFO - 2023-05-07 18:29:23 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:29:23 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:29:23 --> Utf8 Class Initialized
INFO - 2023-05-07 18:29:23 --> URI Class Initialized
INFO - 2023-05-07 18:29:23 --> Router Class Initialized
INFO - 2023-05-07 18:29:23 --> Output Class Initialized
INFO - 2023-05-07 18:29:23 --> Security Class Initialized
DEBUG - 2023-05-07 18:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:29:23 --> Input Class Initialized
INFO - 2023-05-07 18:29:23 --> Language Class Initialized
INFO - 2023-05-07 18:29:23 --> Loader Class Initialized
INFO - 2023-05-07 18:29:23 --> Helper loaded: url_helper
INFO - 2023-05-07 18:29:23 --> Helper loaded: file_helper
INFO - 2023-05-07 18:29:23 --> Helper loaded: html_helper
INFO - 2023-05-07 18:29:23 --> Helper loaded: text_helper
INFO - 2023-05-07 18:29:23 --> Helper loaded: form_helper
INFO - 2023-05-07 18:29:23 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:29:23 --> Helper loaded: security_helper
INFO - 2023-05-07 18:29:23 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:29:23 --> Database Driver Class Initialized
INFO - 2023-05-07 18:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:29:23 --> Parser Class Initialized
INFO - 2023-05-07 18:29:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:29:23 --> Pagination Class Initialized
INFO - 2023-05-07 18:29:23 --> Form Validation Class Initialized
INFO - 2023-05-07 18:29:23 --> Controller Class Initialized
INFO - 2023-05-07 18:29:23 --> Model Class Initialized
DEBUG - 2023-05-07 18:29:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:29:23 --> Model Class Initialized
INFO - 2023-05-07 18:29:23 --> Final output sent to browser
DEBUG - 2023-05-07 18:29:23 --> Total execution time: 0.0192
ERROR - 2023-05-07 18:29:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:29:24 --> Config Class Initialized
INFO - 2023-05-07 18:29:24 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:29:24 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:29:24 --> Utf8 Class Initialized
INFO - 2023-05-07 18:29:24 --> URI Class Initialized
DEBUG - 2023-05-07 18:29:24 --> No URI present. Default controller set.
INFO - 2023-05-07 18:29:24 --> Router Class Initialized
INFO - 2023-05-07 18:29:24 --> Output Class Initialized
INFO - 2023-05-07 18:29:24 --> Security Class Initialized
DEBUG - 2023-05-07 18:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:29:24 --> Input Class Initialized
INFO - 2023-05-07 18:29:24 --> Language Class Initialized
INFO - 2023-05-07 18:29:24 --> Loader Class Initialized
INFO - 2023-05-07 18:29:24 --> Helper loaded: url_helper
INFO - 2023-05-07 18:29:24 --> Helper loaded: file_helper
INFO - 2023-05-07 18:29:24 --> Helper loaded: html_helper
INFO - 2023-05-07 18:29:24 --> Helper loaded: text_helper
INFO - 2023-05-07 18:29:24 --> Helper loaded: form_helper
INFO - 2023-05-07 18:29:24 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:29:24 --> Helper loaded: security_helper
INFO - 2023-05-07 18:29:24 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:29:24 --> Database Driver Class Initialized
INFO - 2023-05-07 18:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:29:24 --> Parser Class Initialized
INFO - 2023-05-07 18:29:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:29:24 --> Pagination Class Initialized
INFO - 2023-05-07 18:29:24 --> Form Validation Class Initialized
INFO - 2023-05-07 18:29:24 --> Controller Class Initialized
INFO - 2023-05-07 18:29:24 --> Model Class Initialized
DEBUG - 2023-05-07 18:29:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:29:24 --> Model Class Initialized
DEBUG - 2023-05-07 18:29:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:29:24 --> Model Class Initialized
INFO - 2023-05-07 18:29:24 --> Model Class Initialized
INFO - 2023-05-07 18:29:24 --> Model Class Initialized
INFO - 2023-05-07 18:29:24 --> Model Class Initialized
DEBUG - 2023-05-07 18:29:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:29:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:29:24 --> Model Class Initialized
INFO - 2023-05-07 18:29:24 --> Model Class Initialized
INFO - 2023-05-07 18:29:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-07 18:29:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:29:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:29:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:29:24 --> Model Class Initialized
INFO - 2023-05-07 18:29:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:29:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:29:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:29:24 --> Final output sent to browser
DEBUG - 2023-05-07 18:29:24 --> Total execution time: 0.0594
ERROR - 2023-05-07 18:29:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:29:30 --> Config Class Initialized
INFO - 2023-05-07 18:29:30 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:29:30 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:29:30 --> Utf8 Class Initialized
INFO - 2023-05-07 18:29:30 --> URI Class Initialized
INFO - 2023-05-07 18:29:30 --> Router Class Initialized
INFO - 2023-05-07 18:29:30 --> Output Class Initialized
INFO - 2023-05-07 18:29:30 --> Security Class Initialized
DEBUG - 2023-05-07 18:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:29:30 --> Input Class Initialized
INFO - 2023-05-07 18:29:30 --> Language Class Initialized
INFO - 2023-05-07 18:29:30 --> Loader Class Initialized
INFO - 2023-05-07 18:29:30 --> Helper loaded: url_helper
INFO - 2023-05-07 18:29:30 --> Helper loaded: file_helper
INFO - 2023-05-07 18:29:30 --> Helper loaded: html_helper
INFO - 2023-05-07 18:29:30 --> Helper loaded: text_helper
INFO - 2023-05-07 18:29:30 --> Helper loaded: form_helper
INFO - 2023-05-07 18:29:30 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:29:30 --> Helper loaded: security_helper
INFO - 2023-05-07 18:29:30 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:29:30 --> Database Driver Class Initialized
INFO - 2023-05-07 18:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:29:30 --> Parser Class Initialized
INFO - 2023-05-07 18:29:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:29:30 --> Pagination Class Initialized
INFO - 2023-05-07 18:29:30 --> Form Validation Class Initialized
INFO - 2023-05-07 18:29:30 --> Controller Class Initialized
INFO - 2023-05-07 18:29:30 --> Model Class Initialized
DEBUG - 2023-05-07 18:29:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:29:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:29:30 --> Model Class Initialized
DEBUG - 2023-05-07 18:29:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:29:30 --> Model Class Initialized
INFO - 2023-05-07 18:29:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-05-07 18:29:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:29:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:29:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:29:30 --> Model Class Initialized
INFO - 2023-05-07 18:29:30 --> Model Class Initialized
INFO - 2023-05-07 18:29:30 --> Model Class Initialized
INFO - 2023-05-07 18:29:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:29:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:29:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:29:30 --> Final output sent to browser
DEBUG - 2023-05-07 18:29:30 --> Total execution time: 0.0596
ERROR - 2023-05-07 18:29:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:29:30 --> Config Class Initialized
INFO - 2023-05-07 18:29:30 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:29:30 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:29:30 --> Utf8 Class Initialized
INFO - 2023-05-07 18:29:30 --> URI Class Initialized
INFO - 2023-05-07 18:29:30 --> Router Class Initialized
INFO - 2023-05-07 18:29:30 --> Output Class Initialized
INFO - 2023-05-07 18:29:30 --> Security Class Initialized
DEBUG - 2023-05-07 18:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:29:30 --> Input Class Initialized
INFO - 2023-05-07 18:29:30 --> Language Class Initialized
INFO - 2023-05-07 18:29:30 --> Loader Class Initialized
INFO - 2023-05-07 18:29:30 --> Helper loaded: url_helper
INFO - 2023-05-07 18:29:30 --> Helper loaded: file_helper
INFO - 2023-05-07 18:29:30 --> Helper loaded: html_helper
INFO - 2023-05-07 18:29:30 --> Helper loaded: text_helper
INFO - 2023-05-07 18:29:30 --> Helper loaded: form_helper
INFO - 2023-05-07 18:29:30 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:29:30 --> Helper loaded: security_helper
INFO - 2023-05-07 18:29:30 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:29:30 --> Database Driver Class Initialized
INFO - 2023-05-07 18:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:29:30 --> Parser Class Initialized
INFO - 2023-05-07 18:29:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:29:30 --> Pagination Class Initialized
INFO - 2023-05-07 18:29:30 --> Form Validation Class Initialized
INFO - 2023-05-07 18:29:30 --> Controller Class Initialized
INFO - 2023-05-07 18:29:30 --> Model Class Initialized
DEBUG - 2023-05-07 18:29:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:29:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:29:30 --> Model Class Initialized
DEBUG - 2023-05-07 18:29:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:29:30 --> Model Class Initialized
INFO - 2023-05-07 18:29:30 --> Final output sent to browser
DEBUG - 2023-05-07 18:29:30 --> Total execution time: 0.0222
ERROR - 2023-05-07 18:29:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:29:33 --> Config Class Initialized
INFO - 2023-05-07 18:29:33 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:29:33 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:29:33 --> Utf8 Class Initialized
INFO - 2023-05-07 18:29:33 --> URI Class Initialized
INFO - 2023-05-07 18:29:33 --> Router Class Initialized
INFO - 2023-05-07 18:29:33 --> Output Class Initialized
INFO - 2023-05-07 18:29:33 --> Security Class Initialized
DEBUG - 2023-05-07 18:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:29:33 --> Input Class Initialized
INFO - 2023-05-07 18:29:33 --> Language Class Initialized
INFO - 2023-05-07 18:29:33 --> Loader Class Initialized
INFO - 2023-05-07 18:29:33 --> Helper loaded: url_helper
INFO - 2023-05-07 18:29:33 --> Helper loaded: file_helper
INFO - 2023-05-07 18:29:33 --> Helper loaded: html_helper
INFO - 2023-05-07 18:29:33 --> Helper loaded: text_helper
INFO - 2023-05-07 18:29:33 --> Helper loaded: form_helper
INFO - 2023-05-07 18:29:33 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:29:33 --> Helper loaded: security_helper
INFO - 2023-05-07 18:29:33 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:29:33 --> Database Driver Class Initialized
INFO - 2023-05-07 18:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:29:33 --> Parser Class Initialized
INFO - 2023-05-07 18:29:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:29:33 --> Pagination Class Initialized
INFO - 2023-05-07 18:29:33 --> Form Validation Class Initialized
INFO - 2023-05-07 18:29:33 --> Controller Class Initialized
INFO - 2023-05-07 18:29:33 --> Model Class Initialized
DEBUG - 2023-05-07 18:29:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:29:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:29:33 --> Model Class Initialized
DEBUG - 2023-05-07 18:29:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:29:33 --> Model Class Initialized
INFO - 2023-05-07 18:29:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html.php
DEBUG - 2023-05-07 18:29:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:29:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:29:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:29:33 --> Model Class Initialized
INFO - 2023-05-07 18:29:33 --> Model Class Initialized
INFO - 2023-05-07 18:29:33 --> Model Class Initialized
INFO - 2023-05-07 18:29:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:29:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:29:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:29:34 --> Final output sent to browser
DEBUG - 2023-05-07 18:29:34 --> Total execution time: 0.0692
ERROR - 2023-05-07 18:29:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:29:44 --> Config Class Initialized
INFO - 2023-05-07 18:29:44 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:29:44 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:29:44 --> Utf8 Class Initialized
INFO - 2023-05-07 18:29:44 --> URI Class Initialized
INFO - 2023-05-07 18:29:44 --> Router Class Initialized
INFO - 2023-05-07 18:29:44 --> Output Class Initialized
INFO - 2023-05-07 18:29:44 --> Security Class Initialized
DEBUG - 2023-05-07 18:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:29:44 --> Input Class Initialized
INFO - 2023-05-07 18:29:44 --> Language Class Initialized
INFO - 2023-05-07 18:29:44 --> Loader Class Initialized
INFO - 2023-05-07 18:29:44 --> Helper loaded: url_helper
INFO - 2023-05-07 18:29:44 --> Helper loaded: file_helper
INFO - 2023-05-07 18:29:44 --> Helper loaded: html_helper
INFO - 2023-05-07 18:29:44 --> Helper loaded: text_helper
INFO - 2023-05-07 18:29:44 --> Helper loaded: form_helper
INFO - 2023-05-07 18:29:44 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:29:44 --> Helper loaded: security_helper
INFO - 2023-05-07 18:29:44 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:29:44 --> Database Driver Class Initialized
INFO - 2023-05-07 18:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:29:44 --> Parser Class Initialized
INFO - 2023-05-07 18:29:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:29:44 --> Pagination Class Initialized
INFO - 2023-05-07 18:29:44 --> Form Validation Class Initialized
INFO - 2023-05-07 18:29:44 --> Controller Class Initialized
DEBUG - 2023-05-07 18:29:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:29:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:29:44 --> Model Class Initialized
DEBUG - 2023-05-07 18:29:44 --> Lgift class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:29:44 --> Model Class Initialized
DEBUG - 2023-05-07 18:29:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:29:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:29:44 --> Model Class Initialized
DEBUG - 2023-05-07 18:29:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:29:44 --> Model Class Initialized
INFO - 2023-05-07 18:29:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/gift.php
DEBUG - 2023-05-07 18:29:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:29:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:29:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:29:44 --> Model Class Initialized
INFO - 2023-05-07 18:29:44 --> Model Class Initialized
INFO - 2023-05-07 18:29:44 --> Model Class Initialized
INFO - 2023-05-07 18:29:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:29:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:29:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:29:44 --> Final output sent to browser
DEBUG - 2023-05-07 18:29:44 --> Total execution time: 0.0553
ERROR - 2023-05-07 18:29:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:29:45 --> Config Class Initialized
INFO - 2023-05-07 18:29:45 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:29:45 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:29:45 --> Utf8 Class Initialized
INFO - 2023-05-07 18:29:45 --> URI Class Initialized
INFO - 2023-05-07 18:29:45 --> Router Class Initialized
INFO - 2023-05-07 18:29:45 --> Output Class Initialized
INFO - 2023-05-07 18:29:45 --> Security Class Initialized
DEBUG - 2023-05-07 18:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:29:45 --> Input Class Initialized
INFO - 2023-05-07 18:29:45 --> Language Class Initialized
INFO - 2023-05-07 18:29:45 --> Loader Class Initialized
INFO - 2023-05-07 18:29:45 --> Helper loaded: url_helper
INFO - 2023-05-07 18:29:45 --> Helper loaded: file_helper
INFO - 2023-05-07 18:29:45 --> Helper loaded: html_helper
INFO - 2023-05-07 18:29:45 --> Helper loaded: text_helper
INFO - 2023-05-07 18:29:45 --> Helper loaded: form_helper
INFO - 2023-05-07 18:29:45 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:29:45 --> Helper loaded: security_helper
INFO - 2023-05-07 18:29:45 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:29:45 --> Database Driver Class Initialized
INFO - 2023-05-07 18:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:29:45 --> Parser Class Initialized
INFO - 2023-05-07 18:29:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:29:45 --> Pagination Class Initialized
INFO - 2023-05-07 18:29:45 --> Form Validation Class Initialized
INFO - 2023-05-07 18:29:45 --> Controller Class Initialized
DEBUG - 2023-05-07 18:29:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:29:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:29:45 --> Model Class Initialized
INFO - 2023-05-07 18:29:45 --> Final output sent to browser
DEBUG - 2023-05-07 18:29:45 --> Total execution time: 0.0151
ERROR - 2023-05-07 18:30:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:30:25 --> Config Class Initialized
INFO - 2023-05-07 18:30:25 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:30:25 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:30:25 --> Utf8 Class Initialized
INFO - 2023-05-07 18:30:25 --> URI Class Initialized
INFO - 2023-05-07 18:30:25 --> Router Class Initialized
INFO - 2023-05-07 18:30:25 --> Output Class Initialized
INFO - 2023-05-07 18:30:25 --> Security Class Initialized
DEBUG - 2023-05-07 18:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:30:25 --> Input Class Initialized
INFO - 2023-05-07 18:30:25 --> Language Class Initialized
INFO - 2023-05-07 18:30:25 --> Loader Class Initialized
INFO - 2023-05-07 18:30:25 --> Helper loaded: url_helper
INFO - 2023-05-07 18:30:25 --> Helper loaded: file_helper
INFO - 2023-05-07 18:30:25 --> Helper loaded: html_helper
INFO - 2023-05-07 18:30:25 --> Helper loaded: text_helper
INFO - 2023-05-07 18:30:25 --> Helper loaded: form_helper
INFO - 2023-05-07 18:30:25 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:30:25 --> Helper loaded: security_helper
INFO - 2023-05-07 18:30:25 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:30:25 --> Database Driver Class Initialized
INFO - 2023-05-07 18:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:30:25 --> Parser Class Initialized
INFO - 2023-05-07 18:30:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:30:25 --> Pagination Class Initialized
INFO - 2023-05-07 18:30:25 --> Form Validation Class Initialized
INFO - 2023-05-07 18:30:25 --> Controller Class Initialized
INFO - 2023-05-07 18:30:25 --> Model Class Initialized
DEBUG - 2023-05-07 18:30:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:30:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:30:25 --> Model Class Initialized
DEBUG - 2023-05-07 18:30:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:30:25 --> Model Class Initialized
INFO - 2023-05-07 18:30:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-07 18:30:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:30:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:30:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:30:25 --> Model Class Initialized
INFO - 2023-05-07 18:30:25 --> Model Class Initialized
INFO - 2023-05-07 18:30:25 --> Model Class Initialized
INFO - 2023-05-07 18:30:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:30:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:30:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:30:25 --> Final output sent to browser
DEBUG - 2023-05-07 18:30:25 --> Total execution time: 0.0617
ERROR - 2023-05-07 18:30:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:30:25 --> Config Class Initialized
INFO - 2023-05-07 18:30:25 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:30:25 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:30:25 --> Utf8 Class Initialized
INFO - 2023-05-07 18:30:25 --> URI Class Initialized
INFO - 2023-05-07 18:30:25 --> Router Class Initialized
INFO - 2023-05-07 18:30:25 --> Output Class Initialized
INFO - 2023-05-07 18:30:25 --> Security Class Initialized
DEBUG - 2023-05-07 18:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:30:25 --> Input Class Initialized
INFO - 2023-05-07 18:30:25 --> Language Class Initialized
INFO - 2023-05-07 18:30:25 --> Loader Class Initialized
INFO - 2023-05-07 18:30:25 --> Helper loaded: url_helper
INFO - 2023-05-07 18:30:25 --> Helper loaded: file_helper
INFO - 2023-05-07 18:30:25 --> Helper loaded: html_helper
INFO - 2023-05-07 18:30:25 --> Helper loaded: text_helper
INFO - 2023-05-07 18:30:25 --> Helper loaded: form_helper
INFO - 2023-05-07 18:30:25 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:30:25 --> Helper loaded: security_helper
INFO - 2023-05-07 18:30:25 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:30:25 --> Database Driver Class Initialized
INFO - 2023-05-07 18:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:30:25 --> Parser Class Initialized
INFO - 2023-05-07 18:30:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:30:25 --> Pagination Class Initialized
INFO - 2023-05-07 18:30:25 --> Form Validation Class Initialized
INFO - 2023-05-07 18:30:25 --> Controller Class Initialized
INFO - 2023-05-07 18:30:25 --> Model Class Initialized
DEBUG - 2023-05-07 18:30:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:30:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:30:25 --> Model Class Initialized
DEBUG - 2023-05-07 18:30:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:30:25 --> Model Class Initialized
INFO - 2023-05-07 18:30:25 --> Final output sent to browser
DEBUG - 2023-05-07 18:30:25 --> Total execution time: 0.0258
ERROR - 2023-05-07 18:30:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:30:32 --> Config Class Initialized
INFO - 2023-05-07 18:30:32 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:30:32 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:30:32 --> Utf8 Class Initialized
INFO - 2023-05-07 18:30:32 --> URI Class Initialized
INFO - 2023-05-07 18:30:32 --> Router Class Initialized
INFO - 2023-05-07 18:30:32 --> Output Class Initialized
INFO - 2023-05-07 18:30:32 --> Security Class Initialized
DEBUG - 2023-05-07 18:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:30:32 --> Input Class Initialized
INFO - 2023-05-07 18:30:32 --> Language Class Initialized
INFO - 2023-05-07 18:30:32 --> Loader Class Initialized
INFO - 2023-05-07 18:30:32 --> Helper loaded: url_helper
INFO - 2023-05-07 18:30:32 --> Helper loaded: file_helper
INFO - 2023-05-07 18:30:32 --> Helper loaded: html_helper
INFO - 2023-05-07 18:30:32 --> Helper loaded: text_helper
INFO - 2023-05-07 18:30:32 --> Helper loaded: form_helper
INFO - 2023-05-07 18:30:32 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:30:32 --> Helper loaded: security_helper
INFO - 2023-05-07 18:30:32 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:30:32 --> Database Driver Class Initialized
INFO - 2023-05-07 18:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:30:32 --> Parser Class Initialized
INFO - 2023-05-07 18:30:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:30:32 --> Pagination Class Initialized
INFO - 2023-05-07 18:30:32 --> Form Validation Class Initialized
INFO - 2023-05-07 18:30:32 --> Controller Class Initialized
INFO - 2023-05-07 18:30:32 --> Model Class Initialized
DEBUG - 2023-05-07 18:30:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:30:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:30:32 --> Model Class Initialized
DEBUG - 2023-05-07 18:30:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:30:32 --> Model Class Initialized
DEBUG - 2023-05-07 18:30:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:30:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-05-07 18:30:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:30:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:30:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:30:32 --> Model Class Initialized
INFO - 2023-05-07 18:30:32 --> Model Class Initialized
INFO - 2023-05-07 18:30:32 --> Model Class Initialized
INFO - 2023-05-07 18:30:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:30:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:30:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:30:32 --> Final output sent to browser
DEBUG - 2023-05-07 18:30:32 --> Total execution time: 0.0608
ERROR - 2023-05-07 18:30:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:30:51 --> Config Class Initialized
INFO - 2023-05-07 18:30:51 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:30:51 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:30:51 --> Utf8 Class Initialized
INFO - 2023-05-07 18:30:51 --> URI Class Initialized
INFO - 2023-05-07 18:30:51 --> Router Class Initialized
INFO - 2023-05-07 18:30:51 --> Output Class Initialized
INFO - 2023-05-07 18:30:51 --> Security Class Initialized
DEBUG - 2023-05-07 18:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:30:51 --> Input Class Initialized
INFO - 2023-05-07 18:30:51 --> Language Class Initialized
INFO - 2023-05-07 18:30:51 --> Loader Class Initialized
INFO - 2023-05-07 18:30:51 --> Helper loaded: url_helper
INFO - 2023-05-07 18:30:51 --> Helper loaded: file_helper
INFO - 2023-05-07 18:30:51 --> Helper loaded: html_helper
INFO - 2023-05-07 18:30:51 --> Helper loaded: text_helper
INFO - 2023-05-07 18:30:51 --> Helper loaded: form_helper
INFO - 2023-05-07 18:30:51 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:30:51 --> Helper loaded: security_helper
INFO - 2023-05-07 18:30:51 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:30:51 --> Database Driver Class Initialized
INFO - 2023-05-07 18:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:30:51 --> Parser Class Initialized
INFO - 2023-05-07 18:30:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:30:51 --> Pagination Class Initialized
INFO - 2023-05-07 18:30:51 --> Form Validation Class Initialized
INFO - 2023-05-07 18:30:51 --> Controller Class Initialized
INFO - 2023-05-07 18:30:51 --> Model Class Initialized
DEBUG - 2023-05-07 18:30:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:30:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:30:51 --> Model Class Initialized
INFO - 2023-05-07 18:30:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest.php
DEBUG - 2023-05-07 18:30:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:30:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:30:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:30:52 --> Model Class Initialized
INFO - 2023-05-07 18:30:52 --> Model Class Initialized
INFO - 2023-05-07 18:30:52 --> Model Class Initialized
INFO - 2023-05-07 18:30:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:30:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:30:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:30:52 --> Final output sent to browser
DEBUG - 2023-05-07 18:30:52 --> Total execution time: 0.0634
ERROR - 2023-05-07 18:30:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:30:52 --> Config Class Initialized
INFO - 2023-05-07 18:30:52 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:30:52 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:30:52 --> Utf8 Class Initialized
INFO - 2023-05-07 18:30:52 --> URI Class Initialized
INFO - 2023-05-07 18:30:52 --> Router Class Initialized
INFO - 2023-05-07 18:30:52 --> Output Class Initialized
INFO - 2023-05-07 18:30:52 --> Security Class Initialized
DEBUG - 2023-05-07 18:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:30:52 --> Input Class Initialized
INFO - 2023-05-07 18:30:52 --> Language Class Initialized
INFO - 2023-05-07 18:30:52 --> Loader Class Initialized
INFO - 2023-05-07 18:30:52 --> Helper loaded: url_helper
INFO - 2023-05-07 18:30:52 --> Helper loaded: file_helper
INFO - 2023-05-07 18:30:52 --> Helper loaded: html_helper
INFO - 2023-05-07 18:30:52 --> Helper loaded: text_helper
INFO - 2023-05-07 18:30:52 --> Helper loaded: form_helper
INFO - 2023-05-07 18:30:52 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:30:52 --> Helper loaded: security_helper
INFO - 2023-05-07 18:30:52 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:30:52 --> Database Driver Class Initialized
INFO - 2023-05-07 18:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:30:52 --> Parser Class Initialized
INFO - 2023-05-07 18:30:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:30:52 --> Pagination Class Initialized
INFO - 2023-05-07 18:30:52 --> Form Validation Class Initialized
INFO - 2023-05-07 18:30:52 --> Controller Class Initialized
INFO - 2023-05-07 18:30:52 --> Model Class Initialized
DEBUG - 2023-05-07 18:30:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:30:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:30:52 --> Model Class Initialized
INFO - 2023-05-07 18:30:52 --> Final output sent to browser
DEBUG - 2023-05-07 18:30:52 --> Total execution time: 0.0183
ERROR - 2023-05-07 18:31:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:31:03 --> Config Class Initialized
INFO - 2023-05-07 18:31:03 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:31:03 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:31:03 --> Utf8 Class Initialized
INFO - 2023-05-07 18:31:03 --> URI Class Initialized
INFO - 2023-05-07 18:31:03 --> Router Class Initialized
INFO - 2023-05-07 18:31:03 --> Output Class Initialized
INFO - 2023-05-07 18:31:03 --> Security Class Initialized
DEBUG - 2023-05-07 18:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:31:03 --> Input Class Initialized
INFO - 2023-05-07 18:31:03 --> Language Class Initialized
INFO - 2023-05-07 18:31:03 --> Loader Class Initialized
INFO - 2023-05-07 18:31:03 --> Helper loaded: url_helper
INFO - 2023-05-07 18:31:03 --> Helper loaded: file_helper
INFO - 2023-05-07 18:31:03 --> Helper loaded: html_helper
INFO - 2023-05-07 18:31:03 --> Helper loaded: text_helper
INFO - 2023-05-07 18:31:03 --> Helper loaded: form_helper
INFO - 2023-05-07 18:31:03 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:31:03 --> Helper loaded: security_helper
INFO - 2023-05-07 18:31:03 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:31:03 --> Database Driver Class Initialized
INFO - 2023-05-07 18:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:31:03 --> Parser Class Initialized
INFO - 2023-05-07 18:31:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:31:03 --> Pagination Class Initialized
INFO - 2023-05-07 18:31:03 --> Form Validation Class Initialized
INFO - 2023-05-07 18:31:03 --> Controller Class Initialized
DEBUG - 2023-05-07 18:31:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:31:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:31:03 --> Model Class Initialized
DEBUG - 2023-05-07 18:31:03 --> Lgift class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:31:03 --> Model Class Initialized
DEBUG - 2023-05-07 18:31:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:31:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:31:03 --> Model Class Initialized
DEBUG - 2023-05-07 18:31:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:31:03 --> Model Class Initialized
INFO - 2023-05-07 18:31:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/gift.php
DEBUG - 2023-05-07 18:31:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:31:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:31:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:31:03 --> Model Class Initialized
INFO - 2023-05-07 18:31:03 --> Model Class Initialized
INFO - 2023-05-07 18:31:03 --> Model Class Initialized
INFO - 2023-05-07 18:31:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:31:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:31:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:31:03 --> Final output sent to browser
DEBUG - 2023-05-07 18:31:03 --> Total execution time: 0.0560
ERROR - 2023-05-07 18:31:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:31:04 --> Config Class Initialized
INFO - 2023-05-07 18:31:04 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:31:04 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:31:04 --> Utf8 Class Initialized
INFO - 2023-05-07 18:31:04 --> URI Class Initialized
INFO - 2023-05-07 18:31:04 --> Router Class Initialized
INFO - 2023-05-07 18:31:04 --> Output Class Initialized
INFO - 2023-05-07 18:31:04 --> Security Class Initialized
DEBUG - 2023-05-07 18:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:31:04 --> Input Class Initialized
INFO - 2023-05-07 18:31:04 --> Language Class Initialized
INFO - 2023-05-07 18:31:04 --> Loader Class Initialized
INFO - 2023-05-07 18:31:04 --> Helper loaded: url_helper
INFO - 2023-05-07 18:31:04 --> Helper loaded: file_helper
INFO - 2023-05-07 18:31:04 --> Helper loaded: html_helper
INFO - 2023-05-07 18:31:04 --> Helper loaded: text_helper
INFO - 2023-05-07 18:31:04 --> Helper loaded: form_helper
INFO - 2023-05-07 18:31:04 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:31:04 --> Helper loaded: security_helper
INFO - 2023-05-07 18:31:04 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:31:04 --> Database Driver Class Initialized
INFO - 2023-05-07 18:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:31:04 --> Parser Class Initialized
INFO - 2023-05-07 18:31:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:31:04 --> Pagination Class Initialized
INFO - 2023-05-07 18:31:04 --> Form Validation Class Initialized
INFO - 2023-05-07 18:31:04 --> Controller Class Initialized
DEBUG - 2023-05-07 18:31:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:31:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:31:04 --> Model Class Initialized
INFO - 2023-05-07 18:31:04 --> Final output sent to browser
DEBUG - 2023-05-07 18:31:04 --> Total execution time: 0.0148
ERROR - 2023-05-07 18:34:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:34:51 --> Config Class Initialized
INFO - 2023-05-07 18:34:51 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:34:51 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:34:51 --> Utf8 Class Initialized
INFO - 2023-05-07 18:34:51 --> URI Class Initialized
INFO - 2023-05-07 18:34:51 --> Router Class Initialized
INFO - 2023-05-07 18:34:51 --> Output Class Initialized
INFO - 2023-05-07 18:34:51 --> Security Class Initialized
DEBUG - 2023-05-07 18:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:34:51 --> Input Class Initialized
INFO - 2023-05-07 18:34:51 --> Language Class Initialized
INFO - 2023-05-07 18:34:51 --> Loader Class Initialized
INFO - 2023-05-07 18:34:51 --> Helper loaded: url_helper
INFO - 2023-05-07 18:34:51 --> Helper loaded: file_helper
INFO - 2023-05-07 18:34:51 --> Helper loaded: html_helper
INFO - 2023-05-07 18:34:51 --> Helper loaded: text_helper
INFO - 2023-05-07 18:34:51 --> Helper loaded: form_helper
INFO - 2023-05-07 18:34:51 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:34:51 --> Helper loaded: security_helper
INFO - 2023-05-07 18:34:51 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:34:51 --> Database Driver Class Initialized
INFO - 2023-05-07 18:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:34:51 --> Parser Class Initialized
INFO - 2023-05-07 18:34:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:34:51 --> Pagination Class Initialized
INFO - 2023-05-07 18:34:51 --> Form Validation Class Initialized
INFO - 2023-05-07 18:34:51 --> Controller Class Initialized
INFO - 2023-05-07 18:34:51 --> Model Class Initialized
DEBUG - 2023-05-07 18:34:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:34:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:34:51 --> Model Class Initialized
INFO - 2023-05-07 18:34:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-05-07 18:34:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:34:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:34:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:34:51 --> Model Class Initialized
INFO - 2023-05-07 18:34:51 --> Model Class Initialized
INFO - 2023-05-07 18:34:51 --> Model Class Initialized
INFO - 2023-05-07 18:34:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:34:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:34:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:34:51 --> Final output sent to browser
DEBUG - 2023-05-07 18:34:51 --> Total execution time: 0.0803
ERROR - 2023-05-07 18:34:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:34:52 --> Config Class Initialized
INFO - 2023-05-07 18:34:52 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:34:52 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:34:52 --> Utf8 Class Initialized
INFO - 2023-05-07 18:34:52 --> URI Class Initialized
INFO - 2023-05-07 18:34:52 --> Router Class Initialized
INFO - 2023-05-07 18:34:52 --> Output Class Initialized
INFO - 2023-05-07 18:34:52 --> Security Class Initialized
DEBUG - 2023-05-07 18:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:34:52 --> Input Class Initialized
INFO - 2023-05-07 18:34:52 --> Language Class Initialized
INFO - 2023-05-07 18:34:52 --> Loader Class Initialized
INFO - 2023-05-07 18:34:52 --> Helper loaded: url_helper
INFO - 2023-05-07 18:34:52 --> Helper loaded: file_helper
INFO - 2023-05-07 18:34:52 --> Helper loaded: html_helper
INFO - 2023-05-07 18:34:52 --> Helper loaded: text_helper
INFO - 2023-05-07 18:34:52 --> Helper loaded: form_helper
INFO - 2023-05-07 18:34:52 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:34:52 --> Helper loaded: security_helper
INFO - 2023-05-07 18:34:52 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:34:52 --> Database Driver Class Initialized
INFO - 2023-05-07 18:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:34:52 --> Parser Class Initialized
INFO - 2023-05-07 18:34:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:34:52 --> Pagination Class Initialized
INFO - 2023-05-07 18:34:52 --> Form Validation Class Initialized
INFO - 2023-05-07 18:34:52 --> Controller Class Initialized
INFO - 2023-05-07 18:34:52 --> Model Class Initialized
DEBUG - 2023-05-07 18:34:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:34:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:34:52 --> Model Class Initialized
INFO - 2023-05-07 18:34:52 --> Final output sent to browser
DEBUG - 2023-05-07 18:34:52 --> Total execution time: 0.0275
ERROR - 2023-05-07 18:35:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:35:00 --> Config Class Initialized
INFO - 2023-05-07 18:35:00 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:35:00 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:35:00 --> Utf8 Class Initialized
INFO - 2023-05-07 18:35:00 --> URI Class Initialized
INFO - 2023-05-07 18:35:00 --> Router Class Initialized
INFO - 2023-05-07 18:35:00 --> Output Class Initialized
INFO - 2023-05-07 18:35:00 --> Security Class Initialized
DEBUG - 2023-05-07 18:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:35:00 --> Input Class Initialized
INFO - 2023-05-07 18:35:00 --> Language Class Initialized
INFO - 2023-05-07 18:35:00 --> Loader Class Initialized
INFO - 2023-05-07 18:35:00 --> Helper loaded: url_helper
INFO - 2023-05-07 18:35:00 --> Helper loaded: file_helper
INFO - 2023-05-07 18:35:00 --> Helper loaded: html_helper
INFO - 2023-05-07 18:35:00 --> Helper loaded: text_helper
INFO - 2023-05-07 18:35:00 --> Helper loaded: form_helper
INFO - 2023-05-07 18:35:00 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:35:00 --> Helper loaded: security_helper
INFO - 2023-05-07 18:35:00 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:35:00 --> Database Driver Class Initialized
INFO - 2023-05-07 18:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:35:00 --> Parser Class Initialized
INFO - 2023-05-07 18:35:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:35:00 --> Pagination Class Initialized
INFO - 2023-05-07 18:35:00 --> Form Validation Class Initialized
INFO - 2023-05-07 18:35:00 --> Controller Class Initialized
INFO - 2023-05-07 18:35:00 --> Model Class Initialized
DEBUG - 2023-05-07 18:35:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:35:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:35:00 --> Model Class Initialized
INFO - 2023-05-07 18:35:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-05-07 18:35:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:35:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-07 18:35:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-07 18:35:00 --> Model Class Initialized
INFO - 2023-05-07 18:35:00 --> Model Class Initialized
INFO - 2023-05-07 18:35:00 --> Model Class Initialized
INFO - 2023-05-07 18:35:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-07 18:35:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-07 18:35:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-07 18:35:00 --> Final output sent to browser
DEBUG - 2023-05-07 18:35:00 --> Total execution time: 0.0583
ERROR - 2023-05-07 18:35:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:35:01 --> Config Class Initialized
INFO - 2023-05-07 18:35:01 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:35:01 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:35:01 --> Utf8 Class Initialized
INFO - 2023-05-07 18:35:01 --> URI Class Initialized
INFO - 2023-05-07 18:35:01 --> Router Class Initialized
INFO - 2023-05-07 18:35:01 --> Output Class Initialized
INFO - 2023-05-07 18:35:01 --> Security Class Initialized
DEBUG - 2023-05-07 18:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:35:01 --> Input Class Initialized
INFO - 2023-05-07 18:35:01 --> Language Class Initialized
INFO - 2023-05-07 18:35:01 --> Loader Class Initialized
INFO - 2023-05-07 18:35:01 --> Helper loaded: url_helper
INFO - 2023-05-07 18:35:01 --> Helper loaded: file_helper
INFO - 2023-05-07 18:35:01 --> Helper loaded: html_helper
INFO - 2023-05-07 18:35:01 --> Helper loaded: text_helper
INFO - 2023-05-07 18:35:01 --> Helper loaded: form_helper
INFO - 2023-05-07 18:35:01 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:35:01 --> Helper loaded: security_helper
INFO - 2023-05-07 18:35:01 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:35:01 --> Database Driver Class Initialized
INFO - 2023-05-07 18:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:35:01 --> Parser Class Initialized
INFO - 2023-05-07 18:35:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:35:01 --> Pagination Class Initialized
INFO - 2023-05-07 18:35:01 --> Form Validation Class Initialized
INFO - 2023-05-07 18:35:01 --> Controller Class Initialized
INFO - 2023-05-07 18:35:01 --> Model Class Initialized
DEBUG - 2023-05-07 18:35:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:35:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:35:01 --> Model Class Initialized
INFO - 2023-05-07 18:35:01 --> Final output sent to browser
DEBUG - 2023-05-07 18:35:01 --> Total execution time: 0.0186
ERROR - 2023-05-07 18:35:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-07 18:35:06 --> Config Class Initialized
INFO - 2023-05-07 18:35:06 --> Hooks Class Initialized
DEBUG - 2023-05-07 18:35:06 --> UTF-8 Support Enabled
INFO - 2023-05-07 18:35:06 --> Utf8 Class Initialized
INFO - 2023-05-07 18:35:06 --> URI Class Initialized
INFO - 2023-05-07 18:35:06 --> Router Class Initialized
INFO - 2023-05-07 18:35:06 --> Output Class Initialized
INFO - 2023-05-07 18:35:06 --> Security Class Initialized
DEBUG - 2023-05-07 18:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-07 18:35:06 --> Input Class Initialized
INFO - 2023-05-07 18:35:06 --> Language Class Initialized
INFO - 2023-05-07 18:35:06 --> Loader Class Initialized
INFO - 2023-05-07 18:35:06 --> Helper loaded: url_helper
INFO - 2023-05-07 18:35:06 --> Helper loaded: file_helper
INFO - 2023-05-07 18:35:06 --> Helper loaded: html_helper
INFO - 2023-05-07 18:35:06 --> Helper loaded: text_helper
INFO - 2023-05-07 18:35:06 --> Helper loaded: form_helper
INFO - 2023-05-07 18:35:06 --> Helper loaded: lang_helper
INFO - 2023-05-07 18:35:06 --> Helper loaded: security_helper
INFO - 2023-05-07 18:35:06 --> Helper loaded: cookie_helper
INFO - 2023-05-07 18:35:06 --> Database Driver Class Initialized
INFO - 2023-05-07 18:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-07 18:35:06 --> Parser Class Initialized
INFO - 2023-05-07 18:35:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-07 18:35:06 --> Pagination Class Initialized
INFO - 2023-05-07 18:35:06 --> Form Validation Class Initialized
INFO - 2023-05-07 18:35:06 --> Controller Class Initialized
INFO - 2023-05-07 18:35:06 --> Model Class Initialized
DEBUG - 2023-05-07 18:35:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-07 18:35:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-07 18:35:06 --> Model Class Initialized
INFO - 2023-05-07 18:35:06 --> Final output sent to browser
DEBUG - 2023-05-07 18:35:06 --> Total execution time: 0.0199
