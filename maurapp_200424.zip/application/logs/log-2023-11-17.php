<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-17 03:28:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 03:28:26 --> Config Class Initialized
INFO - 2023-11-17 03:28:26 --> Hooks Class Initialized
DEBUG - 2023-11-17 03:28:26 --> UTF-8 Support Enabled
INFO - 2023-11-17 03:28:26 --> Utf8 Class Initialized
INFO - 2023-11-17 03:28:26 --> URI Class Initialized
DEBUG - 2023-11-17 03:28:26 --> No URI present. Default controller set.
INFO - 2023-11-17 03:28:26 --> Router Class Initialized
INFO - 2023-11-17 03:28:26 --> Output Class Initialized
INFO - 2023-11-17 03:28:26 --> Security Class Initialized
DEBUG - 2023-11-17 03:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 03:28:26 --> Input Class Initialized
INFO - 2023-11-17 03:28:26 --> Language Class Initialized
INFO - 2023-11-17 03:28:26 --> Loader Class Initialized
INFO - 2023-11-17 03:28:26 --> Helper loaded: url_helper
INFO - 2023-11-17 03:28:26 --> Helper loaded: file_helper
INFO - 2023-11-17 03:28:26 --> Helper loaded: html_helper
INFO - 2023-11-17 03:28:26 --> Helper loaded: text_helper
INFO - 2023-11-17 03:28:26 --> Helper loaded: form_helper
INFO - 2023-11-17 03:28:26 --> Helper loaded: lang_helper
INFO - 2023-11-17 03:28:26 --> Helper loaded: security_helper
INFO - 2023-11-17 03:28:26 --> Helper loaded: cookie_helper
INFO - 2023-11-17 03:28:26 --> Database Driver Class Initialized
INFO - 2023-11-17 03:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 03:28:26 --> Parser Class Initialized
INFO - 2023-11-17 03:28:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 03:28:26 --> Pagination Class Initialized
INFO - 2023-11-17 03:28:26 --> Form Validation Class Initialized
INFO - 2023-11-17 03:28:26 --> Controller Class Initialized
INFO - 2023-11-17 03:28:26 --> Model Class Initialized
DEBUG - 2023-11-17 03:28:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-17 03:28:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 03:28:26 --> Config Class Initialized
INFO - 2023-11-17 03:28:26 --> Hooks Class Initialized
DEBUG - 2023-11-17 03:28:26 --> UTF-8 Support Enabled
INFO - 2023-11-17 03:28:26 --> Utf8 Class Initialized
INFO - 2023-11-17 03:28:26 --> URI Class Initialized
INFO - 2023-11-17 03:28:26 --> Router Class Initialized
INFO - 2023-11-17 03:28:26 --> Output Class Initialized
INFO - 2023-11-17 03:28:26 --> Security Class Initialized
DEBUG - 2023-11-17 03:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 03:28:26 --> Input Class Initialized
INFO - 2023-11-17 03:28:26 --> Language Class Initialized
INFO - 2023-11-17 03:28:26 --> Loader Class Initialized
INFO - 2023-11-17 03:28:26 --> Helper loaded: url_helper
INFO - 2023-11-17 03:28:26 --> Helper loaded: file_helper
INFO - 2023-11-17 03:28:26 --> Helper loaded: html_helper
INFO - 2023-11-17 03:28:26 --> Helper loaded: text_helper
INFO - 2023-11-17 03:28:26 --> Helper loaded: form_helper
INFO - 2023-11-17 03:28:26 --> Helper loaded: lang_helper
INFO - 2023-11-17 03:28:26 --> Helper loaded: security_helper
INFO - 2023-11-17 03:28:26 --> Helper loaded: cookie_helper
INFO - 2023-11-17 03:28:26 --> Database Driver Class Initialized
INFO - 2023-11-17 03:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 03:28:26 --> Parser Class Initialized
INFO - 2023-11-17 03:28:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 03:28:26 --> Pagination Class Initialized
INFO - 2023-11-17 03:28:26 --> Form Validation Class Initialized
INFO - 2023-11-17 03:28:26 --> Controller Class Initialized
INFO - 2023-11-17 03:28:26 --> Model Class Initialized
DEBUG - 2023-11-17 03:28:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 03:28:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-17 03:28:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 03:28:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 03:28:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 03:28:26 --> Model Class Initialized
INFO - 2023-11-17 03:28:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 03:28:26 --> Final output sent to browser
DEBUG - 2023-11-17 03:28:26 --> Total execution time: 0.0328
ERROR - 2023-11-17 03:28:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 03:28:30 --> Config Class Initialized
INFO - 2023-11-17 03:28:30 --> Hooks Class Initialized
DEBUG - 2023-11-17 03:28:30 --> UTF-8 Support Enabled
INFO - 2023-11-17 03:28:30 --> Utf8 Class Initialized
INFO - 2023-11-17 03:28:30 --> URI Class Initialized
INFO - 2023-11-17 03:28:30 --> Router Class Initialized
INFO - 2023-11-17 03:28:30 --> Output Class Initialized
INFO - 2023-11-17 03:28:30 --> Security Class Initialized
DEBUG - 2023-11-17 03:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 03:28:30 --> Input Class Initialized
INFO - 2023-11-17 03:28:30 --> Language Class Initialized
INFO - 2023-11-17 03:28:30 --> Loader Class Initialized
INFO - 2023-11-17 03:28:30 --> Helper loaded: url_helper
INFO - 2023-11-17 03:28:30 --> Helper loaded: file_helper
INFO - 2023-11-17 03:28:30 --> Helper loaded: html_helper
INFO - 2023-11-17 03:28:30 --> Helper loaded: text_helper
INFO - 2023-11-17 03:28:30 --> Helper loaded: form_helper
INFO - 2023-11-17 03:28:30 --> Helper loaded: lang_helper
INFO - 2023-11-17 03:28:30 --> Helper loaded: security_helper
INFO - 2023-11-17 03:28:30 --> Helper loaded: cookie_helper
INFO - 2023-11-17 03:28:30 --> Database Driver Class Initialized
INFO - 2023-11-17 03:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 03:28:30 --> Parser Class Initialized
INFO - 2023-11-17 03:28:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 03:28:30 --> Pagination Class Initialized
INFO - 2023-11-17 03:28:30 --> Form Validation Class Initialized
INFO - 2023-11-17 03:28:30 --> Controller Class Initialized
INFO - 2023-11-17 03:28:30 --> Model Class Initialized
DEBUG - 2023-11-17 03:28:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 03:28:30 --> Model Class Initialized
INFO - 2023-11-17 03:28:30 --> Final output sent to browser
DEBUG - 2023-11-17 03:28:30 --> Total execution time: 0.0245
ERROR - 2023-11-17 03:28:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 03:28:30 --> Config Class Initialized
INFO - 2023-11-17 03:28:30 --> Hooks Class Initialized
DEBUG - 2023-11-17 03:28:30 --> UTF-8 Support Enabled
INFO - 2023-11-17 03:28:30 --> Utf8 Class Initialized
INFO - 2023-11-17 03:28:30 --> URI Class Initialized
DEBUG - 2023-11-17 03:28:30 --> No URI present. Default controller set.
INFO - 2023-11-17 03:28:30 --> Router Class Initialized
INFO - 2023-11-17 03:28:30 --> Output Class Initialized
INFO - 2023-11-17 03:28:30 --> Security Class Initialized
DEBUG - 2023-11-17 03:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 03:28:30 --> Input Class Initialized
INFO - 2023-11-17 03:28:30 --> Language Class Initialized
INFO - 2023-11-17 03:28:30 --> Loader Class Initialized
INFO - 2023-11-17 03:28:30 --> Helper loaded: url_helper
INFO - 2023-11-17 03:28:30 --> Helper loaded: file_helper
INFO - 2023-11-17 03:28:30 --> Helper loaded: html_helper
INFO - 2023-11-17 03:28:30 --> Helper loaded: text_helper
INFO - 2023-11-17 03:28:30 --> Helper loaded: form_helper
INFO - 2023-11-17 03:28:30 --> Helper loaded: lang_helper
INFO - 2023-11-17 03:28:30 --> Helper loaded: security_helper
INFO - 2023-11-17 03:28:30 --> Helper loaded: cookie_helper
INFO - 2023-11-17 03:28:30 --> Database Driver Class Initialized
INFO - 2023-11-17 03:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 03:28:30 --> Parser Class Initialized
INFO - 2023-11-17 03:28:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 03:28:30 --> Pagination Class Initialized
INFO - 2023-11-17 03:28:30 --> Form Validation Class Initialized
INFO - 2023-11-17 03:28:30 --> Controller Class Initialized
INFO - 2023-11-17 03:28:30 --> Model Class Initialized
DEBUG - 2023-11-17 03:28:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 03:28:30 --> Model Class Initialized
DEBUG - 2023-11-17 03:28:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 03:28:30 --> Model Class Initialized
INFO - 2023-11-17 03:28:30 --> Model Class Initialized
INFO - 2023-11-17 03:28:30 --> Model Class Initialized
INFO - 2023-11-17 03:28:30 --> Model Class Initialized
DEBUG - 2023-11-17 03:28:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 03:28:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 03:28:30 --> Model Class Initialized
INFO - 2023-11-17 03:28:30 --> Model Class Initialized
INFO - 2023-11-17 03:28:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-17 03:28:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 03:28:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 03:28:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 03:28:30 --> Model Class Initialized
INFO - 2023-11-17 03:28:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 03:28:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 03:28:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 03:28:30 --> Final output sent to browser
DEBUG - 2023-11-17 03:28:30 --> Total execution time: 0.3868
ERROR - 2023-11-17 03:28:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 03:28:31 --> Config Class Initialized
INFO - 2023-11-17 03:28:31 --> Hooks Class Initialized
DEBUG - 2023-11-17 03:28:31 --> UTF-8 Support Enabled
INFO - 2023-11-17 03:28:31 --> Utf8 Class Initialized
INFO - 2023-11-17 03:28:31 --> URI Class Initialized
INFO - 2023-11-17 03:28:31 --> Router Class Initialized
INFO - 2023-11-17 03:28:31 --> Output Class Initialized
INFO - 2023-11-17 03:28:31 --> Security Class Initialized
DEBUG - 2023-11-17 03:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 03:28:31 --> Input Class Initialized
INFO - 2023-11-17 03:28:31 --> Language Class Initialized
INFO - 2023-11-17 03:28:31 --> Loader Class Initialized
INFO - 2023-11-17 03:28:31 --> Helper loaded: url_helper
INFO - 2023-11-17 03:28:31 --> Helper loaded: file_helper
INFO - 2023-11-17 03:28:31 --> Helper loaded: html_helper
INFO - 2023-11-17 03:28:31 --> Helper loaded: text_helper
INFO - 2023-11-17 03:28:31 --> Helper loaded: form_helper
INFO - 2023-11-17 03:28:31 --> Helper loaded: lang_helper
INFO - 2023-11-17 03:28:31 --> Helper loaded: security_helper
INFO - 2023-11-17 03:28:31 --> Helper loaded: cookie_helper
INFO - 2023-11-17 03:28:31 --> Database Driver Class Initialized
INFO - 2023-11-17 03:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 03:28:31 --> Parser Class Initialized
INFO - 2023-11-17 03:28:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 03:28:31 --> Pagination Class Initialized
INFO - 2023-11-17 03:28:31 --> Form Validation Class Initialized
INFO - 2023-11-17 03:28:31 --> Controller Class Initialized
DEBUG - 2023-11-17 03:28:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 03:28:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 03:28:31 --> Model Class Initialized
INFO - 2023-11-17 03:28:31 --> Final output sent to browser
DEBUG - 2023-11-17 03:28:31 --> Total execution time: 0.0131
ERROR - 2023-11-17 03:28:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 03:28:49 --> Config Class Initialized
INFO - 2023-11-17 03:28:49 --> Hooks Class Initialized
DEBUG - 2023-11-17 03:28:49 --> UTF-8 Support Enabled
INFO - 2023-11-17 03:28:49 --> Utf8 Class Initialized
INFO - 2023-11-17 03:28:49 --> URI Class Initialized
INFO - 2023-11-17 03:28:49 --> Router Class Initialized
INFO - 2023-11-17 03:28:49 --> Output Class Initialized
INFO - 2023-11-17 03:28:49 --> Security Class Initialized
DEBUG - 2023-11-17 03:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 03:28:49 --> Input Class Initialized
INFO - 2023-11-17 03:28:49 --> Language Class Initialized
INFO - 2023-11-17 03:28:49 --> Loader Class Initialized
INFO - 2023-11-17 03:28:49 --> Helper loaded: url_helper
INFO - 2023-11-17 03:28:49 --> Helper loaded: file_helper
INFO - 2023-11-17 03:28:49 --> Helper loaded: html_helper
INFO - 2023-11-17 03:28:49 --> Helper loaded: text_helper
INFO - 2023-11-17 03:28:49 --> Helper loaded: form_helper
INFO - 2023-11-17 03:28:49 --> Helper loaded: lang_helper
INFO - 2023-11-17 03:28:49 --> Helper loaded: security_helper
INFO - 2023-11-17 03:28:49 --> Helper loaded: cookie_helper
INFO - 2023-11-17 03:28:49 --> Database Driver Class Initialized
INFO - 2023-11-17 03:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 03:28:49 --> Parser Class Initialized
INFO - 2023-11-17 03:28:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 03:28:49 --> Pagination Class Initialized
INFO - 2023-11-17 03:28:49 --> Form Validation Class Initialized
INFO - 2023-11-17 03:28:49 --> Controller Class Initialized
INFO - 2023-11-17 03:28:49 --> Model Class Initialized
INFO - 2023-11-17 03:28:49 --> Model Class Initialized
INFO - 2023-11-17 03:28:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report.php
DEBUG - 2023-11-17 03:28:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 03:28:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 03:28:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 03:28:49 --> Model Class Initialized
INFO - 2023-11-17 03:28:49 --> Model Class Initialized
INFO - 2023-11-17 03:28:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 03:28:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 03:28:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 03:28:49 --> Final output sent to browser
DEBUG - 2023-11-17 03:28:49 --> Total execution time: 0.2153
ERROR - 2023-11-17 03:28:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 03:28:50 --> Config Class Initialized
INFO - 2023-11-17 03:28:50 --> Hooks Class Initialized
DEBUG - 2023-11-17 03:28:50 --> UTF-8 Support Enabled
INFO - 2023-11-17 03:28:50 --> Utf8 Class Initialized
INFO - 2023-11-17 03:28:50 --> URI Class Initialized
INFO - 2023-11-17 03:28:50 --> Router Class Initialized
INFO - 2023-11-17 03:28:50 --> Output Class Initialized
INFO - 2023-11-17 03:28:50 --> Security Class Initialized
DEBUG - 2023-11-17 03:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 03:28:50 --> Input Class Initialized
INFO - 2023-11-17 03:28:50 --> Language Class Initialized
INFO - 2023-11-17 03:28:50 --> Loader Class Initialized
INFO - 2023-11-17 03:28:50 --> Helper loaded: url_helper
INFO - 2023-11-17 03:28:50 --> Helper loaded: file_helper
INFO - 2023-11-17 03:28:50 --> Helper loaded: html_helper
INFO - 2023-11-17 03:28:50 --> Helper loaded: text_helper
INFO - 2023-11-17 03:28:50 --> Helper loaded: form_helper
INFO - 2023-11-17 03:28:50 --> Helper loaded: lang_helper
INFO - 2023-11-17 03:28:50 --> Helper loaded: security_helper
INFO - 2023-11-17 03:28:50 --> Helper loaded: cookie_helper
INFO - 2023-11-17 03:28:50 --> Database Driver Class Initialized
INFO - 2023-11-17 03:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 03:28:50 --> Parser Class Initialized
INFO - 2023-11-17 03:28:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 03:28:50 --> Pagination Class Initialized
INFO - 2023-11-17 03:28:50 --> Form Validation Class Initialized
INFO - 2023-11-17 03:28:50 --> Controller Class Initialized
INFO - 2023-11-17 03:28:50 --> Model Class Initialized
INFO - 2023-11-17 03:28:50 --> Model Class Initialized
INFO - 2023-11-17 03:28:50 --> Final output sent to browser
DEBUG - 2023-11-17 03:28:50 --> Total execution time: 0.0275
ERROR - 2023-11-17 03:28:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 03:28:58 --> Config Class Initialized
INFO - 2023-11-17 03:28:58 --> Hooks Class Initialized
DEBUG - 2023-11-17 03:28:58 --> UTF-8 Support Enabled
INFO - 2023-11-17 03:28:58 --> Utf8 Class Initialized
INFO - 2023-11-17 03:28:58 --> URI Class Initialized
INFO - 2023-11-17 03:28:58 --> Router Class Initialized
INFO - 2023-11-17 03:28:58 --> Output Class Initialized
INFO - 2023-11-17 03:28:58 --> Security Class Initialized
DEBUG - 2023-11-17 03:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 03:28:58 --> Input Class Initialized
INFO - 2023-11-17 03:28:58 --> Language Class Initialized
INFO - 2023-11-17 03:28:58 --> Loader Class Initialized
INFO - 2023-11-17 03:28:58 --> Helper loaded: url_helper
INFO - 2023-11-17 03:28:58 --> Helper loaded: file_helper
INFO - 2023-11-17 03:28:58 --> Helper loaded: html_helper
INFO - 2023-11-17 03:28:58 --> Helper loaded: text_helper
INFO - 2023-11-17 03:28:58 --> Helper loaded: form_helper
INFO - 2023-11-17 03:28:58 --> Helper loaded: lang_helper
INFO - 2023-11-17 03:28:58 --> Helper loaded: security_helper
INFO - 2023-11-17 03:28:58 --> Helper loaded: cookie_helper
INFO - 2023-11-17 03:28:58 --> Database Driver Class Initialized
INFO - 2023-11-17 03:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 03:28:58 --> Parser Class Initialized
INFO - 2023-11-17 03:28:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 03:28:58 --> Pagination Class Initialized
INFO - 2023-11-17 03:28:58 --> Form Validation Class Initialized
INFO - 2023-11-17 03:28:58 --> Controller Class Initialized
INFO - 2023-11-17 03:28:58 --> Model Class Initialized
INFO - 2023-11-17 03:28:58 --> Model Class Initialized
INFO - 2023-11-17 03:28:58 --> Final output sent to browser
DEBUG - 2023-11-17 03:28:58 --> Total execution time: 0.0453
ERROR - 2023-11-17 03:45:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 03:45:26 --> Config Class Initialized
INFO - 2023-11-17 03:45:26 --> Hooks Class Initialized
DEBUG - 2023-11-17 03:45:26 --> UTF-8 Support Enabled
INFO - 2023-11-17 03:45:26 --> Utf8 Class Initialized
INFO - 2023-11-17 03:45:26 --> URI Class Initialized
DEBUG - 2023-11-17 03:45:26 --> No URI present. Default controller set.
INFO - 2023-11-17 03:45:26 --> Router Class Initialized
INFO - 2023-11-17 03:45:26 --> Output Class Initialized
INFO - 2023-11-17 03:45:26 --> Security Class Initialized
DEBUG - 2023-11-17 03:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 03:45:26 --> Input Class Initialized
INFO - 2023-11-17 03:45:26 --> Language Class Initialized
INFO - 2023-11-17 03:45:26 --> Loader Class Initialized
INFO - 2023-11-17 03:45:26 --> Helper loaded: url_helper
INFO - 2023-11-17 03:45:26 --> Helper loaded: file_helper
INFO - 2023-11-17 03:45:26 --> Helper loaded: html_helper
INFO - 2023-11-17 03:45:26 --> Helper loaded: text_helper
INFO - 2023-11-17 03:45:26 --> Helper loaded: form_helper
INFO - 2023-11-17 03:45:26 --> Helper loaded: lang_helper
INFO - 2023-11-17 03:45:26 --> Helper loaded: security_helper
INFO - 2023-11-17 03:45:26 --> Helper loaded: cookie_helper
INFO - 2023-11-17 03:45:26 --> Database Driver Class Initialized
INFO - 2023-11-17 03:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 03:45:26 --> Parser Class Initialized
INFO - 2023-11-17 03:45:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 03:45:26 --> Pagination Class Initialized
INFO - 2023-11-17 03:45:26 --> Form Validation Class Initialized
INFO - 2023-11-17 03:45:26 --> Controller Class Initialized
INFO - 2023-11-17 03:45:26 --> Model Class Initialized
DEBUG - 2023-11-17 03:45:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-17 03:45:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 03:45:27 --> Config Class Initialized
INFO - 2023-11-17 03:45:27 --> Hooks Class Initialized
DEBUG - 2023-11-17 03:45:27 --> UTF-8 Support Enabled
INFO - 2023-11-17 03:45:27 --> Utf8 Class Initialized
INFO - 2023-11-17 03:45:27 --> URI Class Initialized
INFO - 2023-11-17 03:45:27 --> Router Class Initialized
INFO - 2023-11-17 03:45:27 --> Output Class Initialized
INFO - 2023-11-17 03:45:27 --> Security Class Initialized
DEBUG - 2023-11-17 03:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 03:45:27 --> Input Class Initialized
INFO - 2023-11-17 03:45:27 --> Language Class Initialized
INFO - 2023-11-17 03:45:27 --> Loader Class Initialized
INFO - 2023-11-17 03:45:27 --> Helper loaded: url_helper
INFO - 2023-11-17 03:45:27 --> Helper loaded: file_helper
INFO - 2023-11-17 03:45:27 --> Helper loaded: html_helper
INFO - 2023-11-17 03:45:27 --> Helper loaded: text_helper
INFO - 2023-11-17 03:45:27 --> Helper loaded: form_helper
INFO - 2023-11-17 03:45:27 --> Helper loaded: lang_helper
INFO - 2023-11-17 03:45:27 --> Helper loaded: security_helper
INFO - 2023-11-17 03:45:27 --> Helper loaded: cookie_helper
INFO - 2023-11-17 03:45:27 --> Database Driver Class Initialized
INFO - 2023-11-17 03:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 03:45:27 --> Parser Class Initialized
INFO - 2023-11-17 03:45:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 03:45:27 --> Pagination Class Initialized
INFO - 2023-11-17 03:45:27 --> Form Validation Class Initialized
INFO - 2023-11-17 03:45:27 --> Controller Class Initialized
INFO - 2023-11-17 03:45:27 --> Model Class Initialized
DEBUG - 2023-11-17 03:45:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 03:45:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-17 03:45:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 03:45:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 03:45:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 03:45:27 --> Model Class Initialized
INFO - 2023-11-17 03:45:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 03:45:27 --> Final output sent to browser
DEBUG - 2023-11-17 03:45:27 --> Total execution time: 0.0310
ERROR - 2023-11-17 03:45:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 03:45:27 --> Config Class Initialized
INFO - 2023-11-17 03:45:27 --> Hooks Class Initialized
DEBUG - 2023-11-17 03:45:27 --> UTF-8 Support Enabled
INFO - 2023-11-17 03:45:27 --> Utf8 Class Initialized
INFO - 2023-11-17 03:45:27 --> URI Class Initialized
INFO - 2023-11-17 03:45:27 --> Router Class Initialized
INFO - 2023-11-17 03:45:27 --> Output Class Initialized
INFO - 2023-11-17 03:45:27 --> Security Class Initialized
DEBUG - 2023-11-17 03:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 03:45:27 --> Input Class Initialized
INFO - 2023-11-17 03:45:27 --> Language Class Initialized
ERROR - 2023-11-17 03:45:27 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2023-11-17 03:45:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 03:45:27 --> Config Class Initialized
INFO - 2023-11-17 03:45:27 --> Hooks Class Initialized
DEBUG - 2023-11-17 03:45:27 --> UTF-8 Support Enabled
INFO - 2023-11-17 03:45:27 --> Utf8 Class Initialized
INFO - 2023-11-17 03:45:27 --> URI Class Initialized
INFO - 2023-11-17 03:45:27 --> Router Class Initialized
INFO - 2023-11-17 03:45:27 --> Output Class Initialized
INFO - 2023-11-17 03:45:27 --> Security Class Initialized
DEBUG - 2023-11-17 03:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 03:45:27 --> Input Class Initialized
INFO - 2023-11-17 03:45:27 --> Language Class Initialized
ERROR - 2023-11-17 03:45:27 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2023-11-17 03:45:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 03:45:34 --> Config Class Initialized
INFO - 2023-11-17 03:45:34 --> Hooks Class Initialized
DEBUG - 2023-11-17 03:45:34 --> UTF-8 Support Enabled
INFO - 2023-11-17 03:45:34 --> Utf8 Class Initialized
INFO - 2023-11-17 03:45:34 --> URI Class Initialized
INFO - 2023-11-17 03:45:34 --> Router Class Initialized
INFO - 2023-11-17 03:45:34 --> Output Class Initialized
INFO - 2023-11-17 03:45:34 --> Security Class Initialized
DEBUG - 2023-11-17 03:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 03:45:34 --> Input Class Initialized
INFO - 2023-11-17 03:45:34 --> Language Class Initialized
INFO - 2023-11-17 03:45:34 --> Loader Class Initialized
INFO - 2023-11-17 03:45:34 --> Helper loaded: url_helper
INFO - 2023-11-17 03:45:34 --> Helper loaded: file_helper
INFO - 2023-11-17 03:45:34 --> Helper loaded: html_helper
INFO - 2023-11-17 03:45:34 --> Helper loaded: text_helper
INFO - 2023-11-17 03:45:34 --> Helper loaded: form_helper
INFO - 2023-11-17 03:45:34 --> Helper loaded: lang_helper
INFO - 2023-11-17 03:45:34 --> Helper loaded: security_helper
INFO - 2023-11-17 03:45:34 --> Helper loaded: cookie_helper
INFO - 2023-11-17 03:45:34 --> Database Driver Class Initialized
INFO - 2023-11-17 03:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 03:45:34 --> Parser Class Initialized
INFO - 2023-11-17 03:45:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 03:45:34 --> Pagination Class Initialized
INFO - 2023-11-17 03:45:34 --> Form Validation Class Initialized
INFO - 2023-11-17 03:45:34 --> Controller Class Initialized
INFO - 2023-11-17 03:45:34 --> Model Class Initialized
DEBUG - 2023-11-17 03:45:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 03:45:34 --> Model Class Initialized
INFO - 2023-11-17 03:45:34 --> Final output sent to browser
DEBUG - 2023-11-17 03:45:34 --> Total execution time: 0.0186
ERROR - 2023-11-17 03:45:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 03:45:35 --> Config Class Initialized
INFO - 2023-11-17 03:45:35 --> Hooks Class Initialized
DEBUG - 2023-11-17 03:45:35 --> UTF-8 Support Enabled
INFO - 2023-11-17 03:45:35 --> Utf8 Class Initialized
INFO - 2023-11-17 03:45:35 --> URI Class Initialized
DEBUG - 2023-11-17 03:45:35 --> No URI present. Default controller set.
INFO - 2023-11-17 03:45:35 --> Router Class Initialized
INFO - 2023-11-17 03:45:35 --> Output Class Initialized
INFO - 2023-11-17 03:45:35 --> Security Class Initialized
DEBUG - 2023-11-17 03:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 03:45:35 --> Input Class Initialized
INFO - 2023-11-17 03:45:35 --> Language Class Initialized
INFO - 2023-11-17 03:45:35 --> Loader Class Initialized
INFO - 2023-11-17 03:45:35 --> Helper loaded: url_helper
INFO - 2023-11-17 03:45:35 --> Helper loaded: file_helper
INFO - 2023-11-17 03:45:35 --> Helper loaded: html_helper
INFO - 2023-11-17 03:45:35 --> Helper loaded: text_helper
INFO - 2023-11-17 03:45:35 --> Helper loaded: form_helper
INFO - 2023-11-17 03:45:35 --> Helper loaded: lang_helper
INFO - 2023-11-17 03:45:35 --> Helper loaded: security_helper
INFO - 2023-11-17 03:45:35 --> Helper loaded: cookie_helper
INFO - 2023-11-17 03:45:35 --> Database Driver Class Initialized
INFO - 2023-11-17 03:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 03:45:35 --> Parser Class Initialized
INFO - 2023-11-17 03:45:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 03:45:35 --> Pagination Class Initialized
INFO - 2023-11-17 03:45:35 --> Form Validation Class Initialized
INFO - 2023-11-17 03:45:35 --> Controller Class Initialized
INFO - 2023-11-17 03:45:35 --> Model Class Initialized
DEBUG - 2023-11-17 03:45:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 03:45:35 --> Model Class Initialized
DEBUG - 2023-11-17 03:45:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 03:45:35 --> Model Class Initialized
INFO - 2023-11-17 03:45:35 --> Model Class Initialized
INFO - 2023-11-17 03:45:35 --> Model Class Initialized
INFO - 2023-11-17 03:45:35 --> Model Class Initialized
DEBUG - 2023-11-17 03:45:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 03:45:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 03:45:35 --> Model Class Initialized
INFO - 2023-11-17 03:45:35 --> Model Class Initialized
INFO - 2023-11-17 03:45:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-17 03:45:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 03:45:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 03:45:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 03:45:35 --> Model Class Initialized
INFO - 2023-11-17 03:45:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 03:45:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 03:45:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 03:45:35 --> Final output sent to browser
DEBUG - 2023-11-17 03:45:35 --> Total execution time: 0.2101
ERROR - 2023-11-17 03:45:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 03:45:43 --> Config Class Initialized
INFO - 2023-11-17 03:45:43 --> Hooks Class Initialized
DEBUG - 2023-11-17 03:45:43 --> UTF-8 Support Enabled
INFO - 2023-11-17 03:45:43 --> Utf8 Class Initialized
INFO - 2023-11-17 03:45:43 --> URI Class Initialized
INFO - 2023-11-17 03:45:43 --> Router Class Initialized
INFO - 2023-11-17 03:45:43 --> Output Class Initialized
INFO - 2023-11-17 03:45:43 --> Security Class Initialized
DEBUG - 2023-11-17 03:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 03:45:43 --> Input Class Initialized
INFO - 2023-11-17 03:45:43 --> Language Class Initialized
INFO - 2023-11-17 03:45:43 --> Loader Class Initialized
INFO - 2023-11-17 03:45:43 --> Helper loaded: url_helper
INFO - 2023-11-17 03:45:43 --> Helper loaded: file_helper
INFO - 2023-11-17 03:45:43 --> Helper loaded: html_helper
INFO - 2023-11-17 03:45:43 --> Helper loaded: text_helper
INFO - 2023-11-17 03:45:43 --> Helper loaded: form_helper
INFO - 2023-11-17 03:45:43 --> Helper loaded: lang_helper
INFO - 2023-11-17 03:45:43 --> Helper loaded: security_helper
INFO - 2023-11-17 03:45:43 --> Helper loaded: cookie_helper
INFO - 2023-11-17 03:45:43 --> Database Driver Class Initialized
INFO - 2023-11-17 03:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 03:45:43 --> Parser Class Initialized
INFO - 2023-11-17 03:45:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 03:45:43 --> Pagination Class Initialized
INFO - 2023-11-17 03:45:43 --> Form Validation Class Initialized
INFO - 2023-11-17 03:45:43 --> Controller Class Initialized
INFO - 2023-11-17 03:45:43 --> Model Class Initialized
DEBUG - 2023-11-17 03:45:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 03:45:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 03:45:43 --> Model Class Initialized
INFO - 2023-11-17 03:45:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-11-17 03:45:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 03:45:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 03:45:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 03:45:43 --> Model Class Initialized
INFO - 2023-11-17 03:45:43 --> Model Class Initialized
INFO - 2023-11-17 03:45:43 --> Model Class Initialized
INFO - 2023-11-17 03:45:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 03:45:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 03:45:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 03:45:43 --> Final output sent to browser
DEBUG - 2023-11-17 03:45:43 --> Total execution time: 0.1389
ERROR - 2023-11-17 03:45:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 03:45:44 --> Config Class Initialized
INFO - 2023-11-17 03:45:44 --> Hooks Class Initialized
DEBUG - 2023-11-17 03:45:44 --> UTF-8 Support Enabled
INFO - 2023-11-17 03:45:44 --> Utf8 Class Initialized
INFO - 2023-11-17 03:45:44 --> URI Class Initialized
INFO - 2023-11-17 03:45:44 --> Router Class Initialized
INFO - 2023-11-17 03:45:44 --> Output Class Initialized
INFO - 2023-11-17 03:45:44 --> Security Class Initialized
DEBUG - 2023-11-17 03:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 03:45:44 --> Input Class Initialized
INFO - 2023-11-17 03:45:44 --> Language Class Initialized
INFO - 2023-11-17 03:45:44 --> Loader Class Initialized
INFO - 2023-11-17 03:45:44 --> Helper loaded: url_helper
INFO - 2023-11-17 03:45:44 --> Helper loaded: file_helper
INFO - 2023-11-17 03:45:44 --> Helper loaded: html_helper
INFO - 2023-11-17 03:45:44 --> Helper loaded: text_helper
INFO - 2023-11-17 03:45:44 --> Helper loaded: form_helper
INFO - 2023-11-17 03:45:44 --> Helper loaded: lang_helper
INFO - 2023-11-17 03:45:44 --> Helper loaded: security_helper
INFO - 2023-11-17 03:45:44 --> Helper loaded: cookie_helper
INFO - 2023-11-17 03:45:44 --> Database Driver Class Initialized
INFO - 2023-11-17 03:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 03:45:44 --> Parser Class Initialized
INFO - 2023-11-17 03:45:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 03:45:44 --> Pagination Class Initialized
INFO - 2023-11-17 03:45:44 --> Form Validation Class Initialized
INFO - 2023-11-17 03:45:44 --> Controller Class Initialized
INFO - 2023-11-17 03:45:44 --> Model Class Initialized
DEBUG - 2023-11-17 03:45:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 03:45:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 03:45:44 --> Model Class Initialized
INFO - 2023-11-17 03:45:44 --> Final output sent to browser
DEBUG - 2023-11-17 03:45:44 --> Total execution time: 0.0717
ERROR - 2023-11-17 03:45:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 03:45:48 --> Config Class Initialized
INFO - 2023-11-17 03:45:48 --> Hooks Class Initialized
DEBUG - 2023-11-17 03:45:48 --> UTF-8 Support Enabled
INFO - 2023-11-17 03:45:48 --> Utf8 Class Initialized
INFO - 2023-11-17 03:45:48 --> URI Class Initialized
INFO - 2023-11-17 03:45:48 --> Router Class Initialized
INFO - 2023-11-17 03:45:48 --> Output Class Initialized
INFO - 2023-11-17 03:45:48 --> Security Class Initialized
DEBUG - 2023-11-17 03:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 03:45:48 --> Input Class Initialized
INFO - 2023-11-17 03:45:48 --> Language Class Initialized
INFO - 2023-11-17 03:45:48 --> Loader Class Initialized
INFO - 2023-11-17 03:45:48 --> Helper loaded: url_helper
INFO - 2023-11-17 03:45:48 --> Helper loaded: file_helper
INFO - 2023-11-17 03:45:48 --> Helper loaded: html_helper
INFO - 2023-11-17 03:45:48 --> Helper loaded: text_helper
INFO - 2023-11-17 03:45:48 --> Helper loaded: form_helper
INFO - 2023-11-17 03:45:48 --> Helper loaded: lang_helper
INFO - 2023-11-17 03:45:48 --> Helper loaded: security_helper
INFO - 2023-11-17 03:45:48 --> Helper loaded: cookie_helper
INFO - 2023-11-17 03:45:48 --> Database Driver Class Initialized
INFO - 2023-11-17 03:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 03:45:48 --> Parser Class Initialized
INFO - 2023-11-17 03:45:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 03:45:48 --> Pagination Class Initialized
INFO - 2023-11-17 03:45:48 --> Form Validation Class Initialized
INFO - 2023-11-17 03:45:48 --> Controller Class Initialized
INFO - 2023-11-17 03:45:48 --> Model Class Initialized
DEBUG - 2023-11-17 03:45:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 03:45:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 03:45:48 --> Model Class Initialized
INFO - 2023-11-17 03:45:48 --> Final output sent to browser
DEBUG - 2023-11-17 03:45:48 --> Total execution time: 0.0729
ERROR - 2023-11-17 03:46:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 03:46:17 --> Config Class Initialized
INFO - 2023-11-17 03:46:17 --> Hooks Class Initialized
DEBUG - 2023-11-17 03:46:17 --> UTF-8 Support Enabled
INFO - 2023-11-17 03:46:17 --> Utf8 Class Initialized
INFO - 2023-11-17 03:46:17 --> URI Class Initialized
DEBUG - 2023-11-17 03:46:17 --> No URI present. Default controller set.
INFO - 2023-11-17 03:46:17 --> Router Class Initialized
INFO - 2023-11-17 03:46:17 --> Output Class Initialized
INFO - 2023-11-17 03:46:17 --> Security Class Initialized
DEBUG - 2023-11-17 03:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 03:46:17 --> Input Class Initialized
INFO - 2023-11-17 03:46:17 --> Language Class Initialized
INFO - 2023-11-17 03:46:17 --> Loader Class Initialized
INFO - 2023-11-17 03:46:17 --> Helper loaded: url_helper
INFO - 2023-11-17 03:46:17 --> Helper loaded: file_helper
INFO - 2023-11-17 03:46:17 --> Helper loaded: html_helper
INFO - 2023-11-17 03:46:17 --> Helper loaded: text_helper
INFO - 2023-11-17 03:46:17 --> Helper loaded: form_helper
INFO - 2023-11-17 03:46:17 --> Helper loaded: lang_helper
INFO - 2023-11-17 03:46:17 --> Helper loaded: security_helper
INFO - 2023-11-17 03:46:17 --> Helper loaded: cookie_helper
INFO - 2023-11-17 03:46:17 --> Database Driver Class Initialized
INFO - 2023-11-17 03:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 03:46:17 --> Parser Class Initialized
INFO - 2023-11-17 03:46:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 03:46:17 --> Pagination Class Initialized
INFO - 2023-11-17 03:46:17 --> Form Validation Class Initialized
INFO - 2023-11-17 03:46:17 --> Controller Class Initialized
INFO - 2023-11-17 03:46:17 --> Model Class Initialized
DEBUG - 2023-11-17 03:46:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 03:46:17 --> Model Class Initialized
DEBUG - 2023-11-17 03:46:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 03:46:17 --> Model Class Initialized
INFO - 2023-11-17 03:46:17 --> Model Class Initialized
INFO - 2023-11-17 03:46:17 --> Model Class Initialized
INFO - 2023-11-17 03:46:17 --> Model Class Initialized
DEBUG - 2023-11-17 03:46:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 03:46:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 03:46:17 --> Model Class Initialized
INFO - 2023-11-17 03:46:17 --> Model Class Initialized
INFO - 2023-11-17 03:46:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-17 03:46:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 03:46:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 03:46:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 03:46:17 --> Model Class Initialized
INFO - 2023-11-17 03:46:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 03:46:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 03:46:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 03:46:17 --> Final output sent to browser
DEBUG - 2023-11-17 03:46:17 --> Total execution time: 0.4116
ERROR - 2023-11-17 03:49:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 03:49:20 --> Config Class Initialized
INFO - 2023-11-17 03:49:20 --> Hooks Class Initialized
DEBUG - 2023-11-17 03:49:20 --> UTF-8 Support Enabled
INFO - 2023-11-17 03:49:20 --> Utf8 Class Initialized
INFO - 2023-11-17 03:49:20 --> URI Class Initialized
INFO - 2023-11-17 03:49:20 --> Router Class Initialized
INFO - 2023-11-17 03:49:20 --> Output Class Initialized
INFO - 2023-11-17 03:49:20 --> Security Class Initialized
DEBUG - 2023-11-17 03:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 03:49:20 --> Input Class Initialized
INFO - 2023-11-17 03:49:20 --> Language Class Initialized
INFO - 2023-11-17 03:49:20 --> Loader Class Initialized
INFO - 2023-11-17 03:49:20 --> Helper loaded: url_helper
INFO - 2023-11-17 03:49:20 --> Helper loaded: file_helper
INFO - 2023-11-17 03:49:20 --> Helper loaded: html_helper
INFO - 2023-11-17 03:49:20 --> Helper loaded: text_helper
INFO - 2023-11-17 03:49:20 --> Helper loaded: form_helper
INFO - 2023-11-17 03:49:20 --> Helper loaded: lang_helper
INFO - 2023-11-17 03:49:20 --> Helper loaded: security_helper
INFO - 2023-11-17 03:49:20 --> Helper loaded: cookie_helper
INFO - 2023-11-17 03:49:20 --> Database Driver Class Initialized
INFO - 2023-11-17 03:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 03:49:20 --> Parser Class Initialized
INFO - 2023-11-17 03:49:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 03:49:20 --> Pagination Class Initialized
INFO - 2023-11-17 03:49:20 --> Form Validation Class Initialized
INFO - 2023-11-17 03:49:20 --> Controller Class Initialized
INFO - 2023-11-17 03:49:20 --> Model Class Initialized
DEBUG - 2023-11-17 03:49:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 03:49:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 03:49:20 --> Model Class Initialized
DEBUG - 2023-11-17 03:49:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 03:49:20 --> Model Class Initialized
INFO - 2023-11-17 03:49:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-11-17 03:49:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 03:49:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 03:49:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 03:49:21 --> Model Class Initialized
INFO - 2023-11-17 03:49:21 --> Model Class Initialized
INFO - 2023-11-17 03:49:21 --> Model Class Initialized
INFO - 2023-11-17 03:49:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 03:49:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 03:49:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 03:49:21 --> Final output sent to browser
DEBUG - 2023-11-17 03:49:21 --> Total execution time: 0.2308
ERROR - 2023-11-17 03:49:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 03:49:21 --> Config Class Initialized
INFO - 2023-11-17 03:49:21 --> Hooks Class Initialized
DEBUG - 2023-11-17 03:49:21 --> UTF-8 Support Enabled
INFO - 2023-11-17 03:49:21 --> Utf8 Class Initialized
INFO - 2023-11-17 03:49:21 --> URI Class Initialized
INFO - 2023-11-17 03:49:21 --> Router Class Initialized
INFO - 2023-11-17 03:49:21 --> Output Class Initialized
INFO - 2023-11-17 03:49:21 --> Security Class Initialized
DEBUG - 2023-11-17 03:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 03:49:21 --> Input Class Initialized
INFO - 2023-11-17 03:49:21 --> Language Class Initialized
INFO - 2023-11-17 03:49:21 --> Loader Class Initialized
INFO - 2023-11-17 03:49:21 --> Helper loaded: url_helper
INFO - 2023-11-17 03:49:21 --> Helper loaded: file_helper
INFO - 2023-11-17 03:49:21 --> Helper loaded: html_helper
INFO - 2023-11-17 03:49:21 --> Helper loaded: text_helper
INFO - 2023-11-17 03:49:21 --> Helper loaded: form_helper
INFO - 2023-11-17 03:49:21 --> Helper loaded: lang_helper
INFO - 2023-11-17 03:49:21 --> Helper loaded: security_helper
INFO - 2023-11-17 03:49:21 --> Helper loaded: cookie_helper
INFO - 2023-11-17 03:49:21 --> Database Driver Class Initialized
INFO - 2023-11-17 03:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 03:49:21 --> Parser Class Initialized
INFO - 2023-11-17 03:49:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 03:49:21 --> Pagination Class Initialized
INFO - 2023-11-17 03:49:21 --> Form Validation Class Initialized
INFO - 2023-11-17 03:49:21 --> Controller Class Initialized
INFO - 2023-11-17 03:49:21 --> Model Class Initialized
DEBUG - 2023-11-17 03:49:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 03:49:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 03:49:21 --> Model Class Initialized
DEBUG - 2023-11-17 03:49:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 03:49:21 --> Model Class Initialized
INFO - 2023-11-17 03:49:21 --> Final output sent to browser
DEBUG - 2023-11-17 03:49:21 --> Total execution time: 0.0620
ERROR - 2023-11-17 03:49:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 03:49:28 --> Config Class Initialized
INFO - 2023-11-17 03:49:28 --> Hooks Class Initialized
DEBUG - 2023-11-17 03:49:28 --> UTF-8 Support Enabled
INFO - 2023-11-17 03:49:28 --> Utf8 Class Initialized
INFO - 2023-11-17 03:49:28 --> URI Class Initialized
DEBUG - 2023-11-17 03:49:28 --> No URI present. Default controller set.
INFO - 2023-11-17 03:49:28 --> Router Class Initialized
INFO - 2023-11-17 03:49:28 --> Output Class Initialized
INFO - 2023-11-17 03:49:28 --> Security Class Initialized
DEBUG - 2023-11-17 03:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 03:49:28 --> Input Class Initialized
INFO - 2023-11-17 03:49:28 --> Language Class Initialized
INFO - 2023-11-17 03:49:28 --> Loader Class Initialized
INFO - 2023-11-17 03:49:28 --> Helper loaded: url_helper
INFO - 2023-11-17 03:49:28 --> Helper loaded: file_helper
INFO - 2023-11-17 03:49:28 --> Helper loaded: html_helper
INFO - 2023-11-17 03:49:28 --> Helper loaded: text_helper
INFO - 2023-11-17 03:49:28 --> Helper loaded: form_helper
INFO - 2023-11-17 03:49:28 --> Helper loaded: lang_helper
INFO - 2023-11-17 03:49:28 --> Helper loaded: security_helper
INFO - 2023-11-17 03:49:28 --> Helper loaded: cookie_helper
INFO - 2023-11-17 03:49:28 --> Database Driver Class Initialized
INFO - 2023-11-17 03:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 03:49:28 --> Parser Class Initialized
INFO - 2023-11-17 03:49:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 03:49:28 --> Pagination Class Initialized
INFO - 2023-11-17 03:49:28 --> Form Validation Class Initialized
INFO - 2023-11-17 03:49:28 --> Controller Class Initialized
INFO - 2023-11-17 03:49:28 --> Model Class Initialized
DEBUG - 2023-11-17 03:49:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 03:49:28 --> Model Class Initialized
DEBUG - 2023-11-17 03:49:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 03:49:28 --> Model Class Initialized
INFO - 2023-11-17 03:49:28 --> Model Class Initialized
INFO - 2023-11-17 03:49:28 --> Model Class Initialized
INFO - 2023-11-17 03:49:28 --> Model Class Initialized
DEBUG - 2023-11-17 03:49:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 03:49:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 03:49:28 --> Model Class Initialized
INFO - 2023-11-17 03:49:28 --> Model Class Initialized
INFO - 2023-11-17 03:49:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-17 03:49:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 03:49:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 03:49:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 03:49:29 --> Model Class Initialized
INFO - 2023-11-17 03:49:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 03:49:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 03:49:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 03:49:29 --> Final output sent to browser
DEBUG - 2023-11-17 03:49:29 --> Total execution time: 0.3917
ERROR - 2023-11-17 03:50:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 03:50:17 --> Config Class Initialized
INFO - 2023-11-17 03:50:17 --> Hooks Class Initialized
DEBUG - 2023-11-17 03:50:17 --> UTF-8 Support Enabled
INFO - 2023-11-17 03:50:17 --> Utf8 Class Initialized
INFO - 2023-11-17 03:50:17 --> URI Class Initialized
DEBUG - 2023-11-17 03:50:17 --> No URI present. Default controller set.
INFO - 2023-11-17 03:50:17 --> Router Class Initialized
INFO - 2023-11-17 03:50:17 --> Output Class Initialized
INFO - 2023-11-17 03:50:17 --> Security Class Initialized
DEBUG - 2023-11-17 03:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 03:50:17 --> Input Class Initialized
INFO - 2023-11-17 03:50:17 --> Language Class Initialized
INFO - 2023-11-17 03:50:17 --> Loader Class Initialized
INFO - 2023-11-17 03:50:17 --> Helper loaded: url_helper
INFO - 2023-11-17 03:50:17 --> Helper loaded: file_helper
INFO - 2023-11-17 03:50:17 --> Helper loaded: html_helper
INFO - 2023-11-17 03:50:17 --> Helper loaded: text_helper
INFO - 2023-11-17 03:50:17 --> Helper loaded: form_helper
INFO - 2023-11-17 03:50:17 --> Helper loaded: lang_helper
INFO - 2023-11-17 03:50:17 --> Helper loaded: security_helper
INFO - 2023-11-17 03:50:17 --> Helper loaded: cookie_helper
INFO - 2023-11-17 03:50:17 --> Database Driver Class Initialized
INFO - 2023-11-17 03:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 03:50:17 --> Parser Class Initialized
INFO - 2023-11-17 03:50:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 03:50:17 --> Pagination Class Initialized
INFO - 2023-11-17 03:50:17 --> Form Validation Class Initialized
INFO - 2023-11-17 03:50:17 --> Controller Class Initialized
INFO - 2023-11-17 03:50:17 --> Model Class Initialized
DEBUG - 2023-11-17 03:50:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 03:50:17 --> Model Class Initialized
DEBUG - 2023-11-17 03:50:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 03:50:17 --> Model Class Initialized
INFO - 2023-11-17 03:50:17 --> Model Class Initialized
INFO - 2023-11-17 03:50:17 --> Model Class Initialized
INFO - 2023-11-17 03:50:17 --> Model Class Initialized
DEBUG - 2023-11-17 03:50:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 03:50:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 03:50:17 --> Model Class Initialized
INFO - 2023-11-17 03:50:17 --> Model Class Initialized
INFO - 2023-11-17 03:50:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-17 03:50:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 03:50:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 03:50:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 03:50:17 --> Model Class Initialized
INFO - 2023-11-17 03:50:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 03:50:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 03:50:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 03:50:17 --> Final output sent to browser
DEBUG - 2023-11-17 03:50:17 --> Total execution time: 0.3864
ERROR - 2023-11-17 05:06:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:06:43 --> Config Class Initialized
INFO - 2023-11-17 05:06:43 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:06:43 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:06:43 --> Utf8 Class Initialized
INFO - 2023-11-17 05:06:43 --> URI Class Initialized
INFO - 2023-11-17 05:06:43 --> Router Class Initialized
INFO - 2023-11-17 05:06:43 --> Output Class Initialized
INFO - 2023-11-17 05:06:43 --> Security Class Initialized
DEBUG - 2023-11-17 05:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:06:43 --> Input Class Initialized
INFO - 2023-11-17 05:06:43 --> Language Class Initialized
ERROR - 2023-11-17 05:06:43 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-11-17 05:10:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:10:15 --> Config Class Initialized
INFO - 2023-11-17 05:10:15 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:10:15 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:10:15 --> Utf8 Class Initialized
INFO - 2023-11-17 05:10:15 --> URI Class Initialized
DEBUG - 2023-11-17 05:10:15 --> No URI present. Default controller set.
INFO - 2023-11-17 05:10:15 --> Router Class Initialized
INFO - 2023-11-17 05:10:15 --> Output Class Initialized
INFO - 2023-11-17 05:10:15 --> Security Class Initialized
DEBUG - 2023-11-17 05:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:10:15 --> Input Class Initialized
INFO - 2023-11-17 05:10:15 --> Language Class Initialized
INFO - 2023-11-17 05:10:15 --> Loader Class Initialized
INFO - 2023-11-17 05:10:15 --> Helper loaded: url_helper
INFO - 2023-11-17 05:10:15 --> Helper loaded: file_helper
INFO - 2023-11-17 05:10:15 --> Helper loaded: html_helper
INFO - 2023-11-17 05:10:15 --> Helper loaded: text_helper
INFO - 2023-11-17 05:10:15 --> Helper loaded: form_helper
INFO - 2023-11-17 05:10:15 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:10:15 --> Helper loaded: security_helper
INFO - 2023-11-17 05:10:15 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:10:15 --> Database Driver Class Initialized
INFO - 2023-11-17 05:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:10:15 --> Parser Class Initialized
INFO - 2023-11-17 05:10:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:10:15 --> Pagination Class Initialized
INFO - 2023-11-17 05:10:15 --> Form Validation Class Initialized
INFO - 2023-11-17 05:10:15 --> Controller Class Initialized
INFO - 2023-11-17 05:10:15 --> Model Class Initialized
DEBUG - 2023-11-17 05:10:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:10:15 --> Model Class Initialized
DEBUG - 2023-11-17 05:10:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:10:15 --> Model Class Initialized
INFO - 2023-11-17 05:10:15 --> Model Class Initialized
INFO - 2023-11-17 05:10:15 --> Model Class Initialized
INFO - 2023-11-17 05:10:15 --> Model Class Initialized
DEBUG - 2023-11-17 05:10:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:10:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:10:15 --> Model Class Initialized
INFO - 2023-11-17 05:10:15 --> Model Class Initialized
INFO - 2023-11-17 05:10:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-17 05:10:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:10:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 05:10:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 05:10:15 --> Model Class Initialized
INFO - 2023-11-17 05:10:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 05:10:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 05:10:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 05:10:16 --> Final output sent to browser
DEBUG - 2023-11-17 05:10:16 --> Total execution time: 0.3832
ERROR - 2023-11-17 05:10:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:10:24 --> Config Class Initialized
INFO - 2023-11-17 05:10:24 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:10:24 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:10:24 --> Utf8 Class Initialized
INFO - 2023-11-17 05:10:24 --> URI Class Initialized
INFO - 2023-11-17 05:10:24 --> Router Class Initialized
INFO - 2023-11-17 05:10:24 --> Output Class Initialized
INFO - 2023-11-17 05:10:24 --> Security Class Initialized
DEBUG - 2023-11-17 05:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:10:24 --> Input Class Initialized
INFO - 2023-11-17 05:10:24 --> Language Class Initialized
INFO - 2023-11-17 05:10:24 --> Loader Class Initialized
INFO - 2023-11-17 05:10:24 --> Helper loaded: url_helper
INFO - 2023-11-17 05:10:24 --> Helper loaded: file_helper
INFO - 2023-11-17 05:10:24 --> Helper loaded: html_helper
INFO - 2023-11-17 05:10:24 --> Helper loaded: text_helper
INFO - 2023-11-17 05:10:24 --> Helper loaded: form_helper
INFO - 2023-11-17 05:10:24 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:10:24 --> Helper loaded: security_helper
INFO - 2023-11-17 05:10:24 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:10:24 --> Database Driver Class Initialized
INFO - 2023-11-17 05:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:10:24 --> Parser Class Initialized
INFO - 2023-11-17 05:10:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:10:24 --> Pagination Class Initialized
INFO - 2023-11-17 05:10:24 --> Form Validation Class Initialized
INFO - 2023-11-17 05:10:24 --> Controller Class Initialized
INFO - 2023-11-17 05:10:24 --> Model Class Initialized
INFO - 2023-11-17 05:10:24 --> Model Class Initialized
INFO - 2023-11-17 05:10:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report.php
DEBUG - 2023-11-17 05:10:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:10:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 05:10:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 05:10:24 --> Model Class Initialized
INFO - 2023-11-17 05:10:24 --> Model Class Initialized
INFO - 2023-11-17 05:10:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 05:10:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 05:10:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 05:10:25 --> Final output sent to browser
DEBUG - 2023-11-17 05:10:25 --> Total execution time: 0.2227
ERROR - 2023-11-17 05:10:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:10:25 --> Config Class Initialized
INFO - 2023-11-17 05:10:25 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:10:25 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:10:25 --> Utf8 Class Initialized
INFO - 2023-11-17 05:10:25 --> URI Class Initialized
INFO - 2023-11-17 05:10:25 --> Router Class Initialized
INFO - 2023-11-17 05:10:25 --> Output Class Initialized
INFO - 2023-11-17 05:10:25 --> Security Class Initialized
DEBUG - 2023-11-17 05:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:10:25 --> Input Class Initialized
INFO - 2023-11-17 05:10:25 --> Language Class Initialized
INFO - 2023-11-17 05:10:25 --> Loader Class Initialized
INFO - 2023-11-17 05:10:25 --> Helper loaded: url_helper
INFO - 2023-11-17 05:10:25 --> Helper loaded: file_helper
INFO - 2023-11-17 05:10:25 --> Helper loaded: html_helper
INFO - 2023-11-17 05:10:25 --> Helper loaded: text_helper
INFO - 2023-11-17 05:10:25 --> Helper loaded: form_helper
INFO - 2023-11-17 05:10:25 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:10:25 --> Helper loaded: security_helper
INFO - 2023-11-17 05:10:25 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:10:25 --> Database Driver Class Initialized
INFO - 2023-11-17 05:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:10:25 --> Parser Class Initialized
INFO - 2023-11-17 05:10:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:10:25 --> Pagination Class Initialized
INFO - 2023-11-17 05:10:25 --> Form Validation Class Initialized
INFO - 2023-11-17 05:10:25 --> Controller Class Initialized
INFO - 2023-11-17 05:10:25 --> Model Class Initialized
INFO - 2023-11-17 05:10:25 --> Model Class Initialized
INFO - 2023-11-17 05:10:25 --> Final output sent to browser
DEBUG - 2023-11-17 05:10:25 --> Total execution time: 0.0265
ERROR - 2023-11-17 05:10:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:10:52 --> Config Class Initialized
INFO - 2023-11-17 05:10:52 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:10:52 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:10:52 --> Utf8 Class Initialized
INFO - 2023-11-17 05:10:52 --> URI Class Initialized
INFO - 2023-11-17 05:10:52 --> Router Class Initialized
INFO - 2023-11-17 05:10:52 --> Output Class Initialized
INFO - 2023-11-17 05:10:52 --> Security Class Initialized
DEBUG - 2023-11-17 05:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:10:52 --> Input Class Initialized
INFO - 2023-11-17 05:10:52 --> Language Class Initialized
INFO - 2023-11-17 05:10:52 --> Loader Class Initialized
INFO - 2023-11-17 05:10:52 --> Helper loaded: url_helper
INFO - 2023-11-17 05:10:52 --> Helper loaded: file_helper
INFO - 2023-11-17 05:10:52 --> Helper loaded: html_helper
INFO - 2023-11-17 05:10:52 --> Helper loaded: text_helper
INFO - 2023-11-17 05:10:52 --> Helper loaded: form_helper
INFO - 2023-11-17 05:10:52 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:10:52 --> Helper loaded: security_helper
INFO - 2023-11-17 05:10:52 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:10:52 --> Database Driver Class Initialized
INFO - 2023-11-17 05:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:10:52 --> Parser Class Initialized
INFO - 2023-11-17 05:10:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:10:52 --> Pagination Class Initialized
INFO - 2023-11-17 05:10:52 --> Form Validation Class Initialized
INFO - 2023-11-17 05:10:52 --> Controller Class Initialized
INFO - 2023-11-17 05:10:52 --> Model Class Initialized
INFO - 2023-11-17 05:10:52 --> Model Class Initialized
INFO - 2023-11-17 05:10:52 --> Final output sent to browser
DEBUG - 2023-11-17 05:10:52 --> Total execution time: 0.0483
ERROR - 2023-11-17 05:19:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:19:05 --> Config Class Initialized
INFO - 2023-11-17 05:19:05 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:19:05 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:19:05 --> Utf8 Class Initialized
INFO - 2023-11-17 05:19:05 --> URI Class Initialized
DEBUG - 2023-11-17 05:19:05 --> No URI present. Default controller set.
INFO - 2023-11-17 05:19:05 --> Router Class Initialized
INFO - 2023-11-17 05:19:05 --> Output Class Initialized
INFO - 2023-11-17 05:19:05 --> Security Class Initialized
DEBUG - 2023-11-17 05:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:19:05 --> Input Class Initialized
INFO - 2023-11-17 05:19:05 --> Language Class Initialized
INFO - 2023-11-17 05:19:05 --> Loader Class Initialized
INFO - 2023-11-17 05:19:05 --> Helper loaded: url_helper
INFO - 2023-11-17 05:19:05 --> Helper loaded: file_helper
INFO - 2023-11-17 05:19:05 --> Helper loaded: html_helper
INFO - 2023-11-17 05:19:05 --> Helper loaded: text_helper
INFO - 2023-11-17 05:19:05 --> Helper loaded: form_helper
INFO - 2023-11-17 05:19:05 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:19:05 --> Helper loaded: security_helper
INFO - 2023-11-17 05:19:05 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:19:05 --> Database Driver Class Initialized
INFO - 2023-11-17 05:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:19:05 --> Parser Class Initialized
INFO - 2023-11-17 05:19:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:19:05 --> Pagination Class Initialized
INFO - 2023-11-17 05:19:05 --> Form Validation Class Initialized
INFO - 2023-11-17 05:19:05 --> Controller Class Initialized
INFO - 2023-11-17 05:19:05 --> Model Class Initialized
DEBUG - 2023-11-17 05:19:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:19:05 --> Model Class Initialized
DEBUG - 2023-11-17 05:19:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:19:05 --> Model Class Initialized
INFO - 2023-11-17 05:19:05 --> Model Class Initialized
INFO - 2023-11-17 05:19:05 --> Model Class Initialized
INFO - 2023-11-17 05:19:05 --> Model Class Initialized
DEBUG - 2023-11-17 05:19:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:19:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:19:05 --> Model Class Initialized
INFO - 2023-11-17 05:19:05 --> Model Class Initialized
INFO - 2023-11-17 05:19:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-17 05:19:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:19:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 05:19:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 05:19:06 --> Model Class Initialized
INFO - 2023-11-17 05:19:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 05:19:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 05:19:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 05:19:06 --> Final output sent to browser
DEBUG - 2023-11-17 05:19:06 --> Total execution time: 0.3946
ERROR - 2023-11-17 05:23:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:23:33 --> Config Class Initialized
INFO - 2023-11-17 05:23:33 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:23:33 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:23:33 --> Utf8 Class Initialized
INFO - 2023-11-17 05:23:33 --> URI Class Initialized
INFO - 2023-11-17 05:23:33 --> Router Class Initialized
INFO - 2023-11-17 05:23:33 --> Output Class Initialized
INFO - 2023-11-17 05:23:33 --> Security Class Initialized
DEBUG - 2023-11-17 05:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:23:33 --> Input Class Initialized
INFO - 2023-11-17 05:23:33 --> Language Class Initialized
INFO - 2023-11-17 05:23:33 --> Loader Class Initialized
INFO - 2023-11-17 05:23:33 --> Helper loaded: url_helper
INFO - 2023-11-17 05:23:33 --> Helper loaded: file_helper
INFO - 2023-11-17 05:23:33 --> Helper loaded: html_helper
INFO - 2023-11-17 05:23:33 --> Helper loaded: text_helper
INFO - 2023-11-17 05:23:33 --> Helper loaded: form_helper
INFO - 2023-11-17 05:23:33 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:23:33 --> Helper loaded: security_helper
INFO - 2023-11-17 05:23:33 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:23:33 --> Database Driver Class Initialized
INFO - 2023-11-17 05:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:23:33 --> Parser Class Initialized
INFO - 2023-11-17 05:23:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:23:33 --> Pagination Class Initialized
INFO - 2023-11-17 05:23:33 --> Form Validation Class Initialized
INFO - 2023-11-17 05:23:33 --> Controller Class Initialized
DEBUG - 2023-11-17 05:23:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:23:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:23:33 --> Model Class Initialized
DEBUG - 2023-11-17 05:23:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:23:33 --> Model Class Initialized
ERROR - 2023-11-17 05:23:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:23:33 --> Config Class Initialized
INFO - 2023-11-17 05:23:33 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:23:33 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:23:33 --> Utf8 Class Initialized
INFO - 2023-11-17 05:23:33 --> URI Class Initialized
INFO - 2023-11-17 05:23:33 --> Router Class Initialized
INFO - 2023-11-17 05:23:33 --> Output Class Initialized
INFO - 2023-11-17 05:23:33 --> Security Class Initialized
DEBUG - 2023-11-17 05:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:23:33 --> Input Class Initialized
INFO - 2023-11-17 05:23:33 --> Language Class Initialized
INFO - 2023-11-17 05:23:33 --> Loader Class Initialized
INFO - 2023-11-17 05:23:33 --> Helper loaded: url_helper
INFO - 2023-11-17 05:23:33 --> Helper loaded: file_helper
INFO - 2023-11-17 05:23:33 --> Helper loaded: html_helper
INFO - 2023-11-17 05:23:33 --> Helper loaded: text_helper
INFO - 2023-11-17 05:23:33 --> Helper loaded: form_helper
INFO - 2023-11-17 05:23:33 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:23:33 --> Helper loaded: security_helper
INFO - 2023-11-17 05:23:33 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:23:33 --> Database Driver Class Initialized
INFO - 2023-11-17 05:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:23:33 --> Parser Class Initialized
INFO - 2023-11-17 05:23:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:23:33 --> Pagination Class Initialized
INFO - 2023-11-17 05:23:33 --> Form Validation Class Initialized
INFO - 2023-11-17 05:23:33 --> Controller Class Initialized
INFO - 2023-11-17 05:23:33 --> Model Class Initialized
DEBUG - 2023-11-17 05:23:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:23:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-17 05:23:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:23:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 05:23:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 05:23:33 --> Model Class Initialized
INFO - 2023-11-17 05:23:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 05:23:33 --> Final output sent to browser
DEBUG - 2023-11-17 05:23:33 --> Total execution time: 0.0293
ERROR - 2023-11-17 05:23:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:23:45 --> Config Class Initialized
INFO - 2023-11-17 05:23:45 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:23:45 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:23:45 --> Utf8 Class Initialized
INFO - 2023-11-17 05:23:45 --> URI Class Initialized
DEBUG - 2023-11-17 05:23:45 --> No URI present. Default controller set.
INFO - 2023-11-17 05:23:45 --> Router Class Initialized
INFO - 2023-11-17 05:23:45 --> Output Class Initialized
INFO - 2023-11-17 05:23:45 --> Security Class Initialized
DEBUG - 2023-11-17 05:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:23:45 --> Input Class Initialized
INFO - 2023-11-17 05:23:45 --> Language Class Initialized
INFO - 2023-11-17 05:23:45 --> Loader Class Initialized
INFO - 2023-11-17 05:23:45 --> Helper loaded: url_helper
INFO - 2023-11-17 05:23:45 --> Helper loaded: file_helper
INFO - 2023-11-17 05:23:45 --> Helper loaded: html_helper
INFO - 2023-11-17 05:23:45 --> Helper loaded: text_helper
INFO - 2023-11-17 05:23:45 --> Helper loaded: form_helper
INFO - 2023-11-17 05:23:45 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:23:45 --> Helper loaded: security_helper
INFO - 2023-11-17 05:23:45 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:23:45 --> Database Driver Class Initialized
INFO - 2023-11-17 05:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:23:45 --> Parser Class Initialized
INFO - 2023-11-17 05:23:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:23:45 --> Pagination Class Initialized
INFO - 2023-11-17 05:23:45 --> Form Validation Class Initialized
INFO - 2023-11-17 05:23:45 --> Controller Class Initialized
INFO - 2023-11-17 05:23:45 --> Model Class Initialized
DEBUG - 2023-11-17 05:23:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:23:45 --> Model Class Initialized
DEBUG - 2023-11-17 05:23:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:23:45 --> Model Class Initialized
INFO - 2023-11-17 05:23:45 --> Model Class Initialized
INFO - 2023-11-17 05:23:45 --> Model Class Initialized
INFO - 2023-11-17 05:23:45 --> Model Class Initialized
DEBUG - 2023-11-17 05:23:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:23:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:23:45 --> Model Class Initialized
INFO - 2023-11-17 05:23:45 --> Model Class Initialized
INFO - 2023-11-17 05:23:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-17 05:23:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:23:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 05:23:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 05:23:45 --> Model Class Initialized
INFO - 2023-11-17 05:23:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 05:23:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 05:23:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 05:23:45 --> Final output sent to browser
DEBUG - 2023-11-17 05:23:45 --> Total execution time: 0.2083
ERROR - 2023-11-17 05:23:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:23:51 --> Config Class Initialized
INFO - 2023-11-17 05:23:51 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:23:51 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:23:51 --> Utf8 Class Initialized
INFO - 2023-11-17 05:23:51 --> URI Class Initialized
INFO - 2023-11-17 05:23:51 --> Router Class Initialized
INFO - 2023-11-17 05:23:51 --> Output Class Initialized
INFO - 2023-11-17 05:23:51 --> Security Class Initialized
DEBUG - 2023-11-17 05:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:23:51 --> Input Class Initialized
INFO - 2023-11-17 05:23:51 --> Language Class Initialized
INFO - 2023-11-17 05:23:51 --> Loader Class Initialized
INFO - 2023-11-17 05:23:51 --> Helper loaded: url_helper
INFO - 2023-11-17 05:23:51 --> Helper loaded: file_helper
INFO - 2023-11-17 05:23:51 --> Helper loaded: html_helper
INFO - 2023-11-17 05:23:51 --> Helper loaded: text_helper
INFO - 2023-11-17 05:23:51 --> Helper loaded: form_helper
INFO - 2023-11-17 05:23:51 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:23:51 --> Helper loaded: security_helper
INFO - 2023-11-17 05:23:51 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:23:51 --> Database Driver Class Initialized
INFO - 2023-11-17 05:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:23:51 --> Parser Class Initialized
INFO - 2023-11-17 05:23:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:23:51 --> Pagination Class Initialized
INFO - 2023-11-17 05:23:51 --> Form Validation Class Initialized
INFO - 2023-11-17 05:23:51 --> Controller Class Initialized
INFO - 2023-11-17 05:23:51 --> Model Class Initialized
DEBUG - 2023-11-17 05:23:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:23:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:23:51 --> Model Class Initialized
DEBUG - 2023-11-17 05:23:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:23:51 --> Model Class Initialized
INFO - 2023-11-17 05:23:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-11-17 05:23:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:23:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 05:23:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 05:23:51 --> Model Class Initialized
INFO - 2023-11-17 05:23:51 --> Model Class Initialized
INFO - 2023-11-17 05:23:51 --> Model Class Initialized
INFO - 2023-11-17 05:23:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 05:23:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 05:23:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 05:23:51 --> Final output sent to browser
DEBUG - 2023-11-17 05:23:51 --> Total execution time: 0.1683
ERROR - 2023-11-17 05:23:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:23:59 --> Config Class Initialized
INFO - 2023-11-17 05:23:59 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:23:59 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:23:59 --> Utf8 Class Initialized
INFO - 2023-11-17 05:23:59 --> URI Class Initialized
INFO - 2023-11-17 05:23:59 --> Router Class Initialized
INFO - 2023-11-17 05:23:59 --> Output Class Initialized
INFO - 2023-11-17 05:23:59 --> Security Class Initialized
DEBUG - 2023-11-17 05:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:23:59 --> Input Class Initialized
INFO - 2023-11-17 05:23:59 --> Language Class Initialized
INFO - 2023-11-17 05:23:59 --> Loader Class Initialized
INFO - 2023-11-17 05:23:59 --> Helper loaded: url_helper
INFO - 2023-11-17 05:23:59 --> Helper loaded: file_helper
INFO - 2023-11-17 05:23:59 --> Helper loaded: html_helper
INFO - 2023-11-17 05:23:59 --> Helper loaded: text_helper
INFO - 2023-11-17 05:23:59 --> Helper loaded: form_helper
INFO - 2023-11-17 05:23:59 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:23:59 --> Helper loaded: security_helper
INFO - 2023-11-17 05:23:59 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:23:59 --> Database Driver Class Initialized
INFO - 2023-11-17 05:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:23:59 --> Parser Class Initialized
INFO - 2023-11-17 05:23:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:23:59 --> Pagination Class Initialized
INFO - 2023-11-17 05:23:59 --> Form Validation Class Initialized
INFO - 2023-11-17 05:23:59 --> Controller Class Initialized
INFO - 2023-11-17 05:23:59 --> Model Class Initialized
DEBUG - 2023-11-17 05:23:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:23:59 --> Final output sent to browser
DEBUG - 2023-11-17 05:23:59 --> Total execution time: 0.0196
ERROR - 2023-11-17 05:24:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:24:01 --> Config Class Initialized
INFO - 2023-11-17 05:24:01 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:24:01 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:24:01 --> Utf8 Class Initialized
INFO - 2023-11-17 05:24:01 --> URI Class Initialized
INFO - 2023-11-17 05:24:01 --> Router Class Initialized
INFO - 2023-11-17 05:24:01 --> Output Class Initialized
INFO - 2023-11-17 05:24:01 --> Security Class Initialized
DEBUG - 2023-11-17 05:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:24:01 --> Input Class Initialized
INFO - 2023-11-17 05:24:01 --> Language Class Initialized
INFO - 2023-11-17 05:24:01 --> Loader Class Initialized
INFO - 2023-11-17 05:24:01 --> Helper loaded: url_helper
INFO - 2023-11-17 05:24:01 --> Helper loaded: file_helper
INFO - 2023-11-17 05:24:01 --> Helper loaded: html_helper
INFO - 2023-11-17 05:24:01 --> Helper loaded: text_helper
INFO - 2023-11-17 05:24:01 --> Helper loaded: form_helper
INFO - 2023-11-17 05:24:01 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:24:01 --> Helper loaded: security_helper
INFO - 2023-11-17 05:24:01 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:24:01 --> Database Driver Class Initialized
INFO - 2023-11-17 05:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:24:01 --> Parser Class Initialized
INFO - 2023-11-17 05:24:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:24:01 --> Pagination Class Initialized
INFO - 2023-11-17 05:24:01 --> Form Validation Class Initialized
INFO - 2023-11-17 05:24:01 --> Controller Class Initialized
INFO - 2023-11-17 05:24:01 --> Final output sent to browser
DEBUG - 2023-11-17 05:24:01 --> Total execution time: 0.0172
ERROR - 2023-11-17 05:24:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:24:07 --> Config Class Initialized
INFO - 2023-11-17 05:24:07 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:24:07 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:24:07 --> Utf8 Class Initialized
INFO - 2023-11-17 05:24:07 --> URI Class Initialized
INFO - 2023-11-17 05:24:07 --> Router Class Initialized
INFO - 2023-11-17 05:24:07 --> Output Class Initialized
INFO - 2023-11-17 05:24:07 --> Security Class Initialized
DEBUG - 2023-11-17 05:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:24:07 --> Input Class Initialized
INFO - 2023-11-17 05:24:07 --> Language Class Initialized
INFO - 2023-11-17 05:24:07 --> Loader Class Initialized
INFO - 2023-11-17 05:24:07 --> Helper loaded: url_helper
INFO - 2023-11-17 05:24:07 --> Helper loaded: file_helper
INFO - 2023-11-17 05:24:07 --> Helper loaded: html_helper
INFO - 2023-11-17 05:24:07 --> Helper loaded: text_helper
INFO - 2023-11-17 05:24:07 --> Helper loaded: form_helper
INFO - 2023-11-17 05:24:07 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:24:07 --> Helper loaded: security_helper
INFO - 2023-11-17 05:24:07 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:24:07 --> Database Driver Class Initialized
INFO - 2023-11-17 05:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:24:07 --> Parser Class Initialized
INFO - 2023-11-17 05:24:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:24:07 --> Pagination Class Initialized
INFO - 2023-11-17 05:24:07 --> Form Validation Class Initialized
INFO - 2023-11-17 05:24:07 --> Controller Class Initialized
INFO - 2023-11-17 05:24:07 --> Model Class Initialized
DEBUG - 2023-11-17 05:24:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:24:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:24:07 --> Model Class Initialized
DEBUG - 2023-11-17 05:24:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:24:07 --> Model Class Initialized
INFO - 2023-11-17 05:24:07 --> Final output sent to browser
DEBUG - 2023-11-17 05:24:07 --> Total execution time: 0.1420
ERROR - 2023-11-17 05:24:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:24:07 --> Config Class Initialized
INFO - 2023-11-17 05:24:07 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:24:07 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:24:07 --> Utf8 Class Initialized
INFO - 2023-11-17 05:24:07 --> URI Class Initialized
INFO - 2023-11-17 05:24:07 --> Router Class Initialized
INFO - 2023-11-17 05:24:07 --> Output Class Initialized
INFO - 2023-11-17 05:24:07 --> Security Class Initialized
DEBUG - 2023-11-17 05:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:24:07 --> Input Class Initialized
INFO - 2023-11-17 05:24:07 --> Language Class Initialized
INFO - 2023-11-17 05:24:07 --> Loader Class Initialized
INFO - 2023-11-17 05:24:07 --> Helper loaded: url_helper
INFO - 2023-11-17 05:24:07 --> Helper loaded: file_helper
INFO - 2023-11-17 05:24:07 --> Helper loaded: html_helper
INFO - 2023-11-17 05:24:07 --> Helper loaded: text_helper
INFO - 2023-11-17 05:24:07 --> Helper loaded: form_helper
INFO - 2023-11-17 05:24:07 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:24:07 --> Helper loaded: security_helper
INFO - 2023-11-17 05:24:07 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:24:07 --> Database Driver Class Initialized
INFO - 2023-11-17 05:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:24:07 --> Parser Class Initialized
INFO - 2023-11-17 05:24:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:24:07 --> Pagination Class Initialized
INFO - 2023-11-17 05:24:07 --> Form Validation Class Initialized
INFO - 2023-11-17 05:24:07 --> Controller Class Initialized
INFO - 2023-11-17 05:24:07 --> Model Class Initialized
DEBUG - 2023-11-17 05:24:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:24:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:24:07 --> Model Class Initialized
DEBUG - 2023-11-17 05:24:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:24:07 --> Model Class Initialized
INFO - 2023-11-17 05:24:08 --> Final output sent to browser
DEBUG - 2023-11-17 05:24:08 --> Total execution time: 0.1434
ERROR - 2023-11-17 05:24:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:24:08 --> Config Class Initialized
INFO - 2023-11-17 05:24:08 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:24:08 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:24:08 --> Utf8 Class Initialized
INFO - 2023-11-17 05:24:08 --> URI Class Initialized
INFO - 2023-11-17 05:24:08 --> Router Class Initialized
INFO - 2023-11-17 05:24:08 --> Output Class Initialized
INFO - 2023-11-17 05:24:08 --> Security Class Initialized
DEBUG - 2023-11-17 05:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:24:08 --> Input Class Initialized
INFO - 2023-11-17 05:24:08 --> Language Class Initialized
INFO - 2023-11-17 05:24:08 --> Loader Class Initialized
INFO - 2023-11-17 05:24:08 --> Helper loaded: url_helper
INFO - 2023-11-17 05:24:08 --> Helper loaded: file_helper
INFO - 2023-11-17 05:24:08 --> Helper loaded: html_helper
INFO - 2023-11-17 05:24:08 --> Helper loaded: text_helper
INFO - 2023-11-17 05:24:08 --> Helper loaded: form_helper
INFO - 2023-11-17 05:24:08 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:24:08 --> Helper loaded: security_helper
INFO - 2023-11-17 05:24:08 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:24:08 --> Database Driver Class Initialized
INFO - 2023-11-17 05:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:24:08 --> Parser Class Initialized
INFO - 2023-11-17 05:24:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:24:08 --> Pagination Class Initialized
INFO - 2023-11-17 05:24:08 --> Form Validation Class Initialized
INFO - 2023-11-17 05:24:08 --> Controller Class Initialized
INFO - 2023-11-17 05:24:08 --> Model Class Initialized
DEBUG - 2023-11-17 05:24:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:24:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:24:08 --> Model Class Initialized
DEBUG - 2023-11-17 05:24:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:24:08 --> Model Class Initialized
INFO - 2023-11-17 05:24:08 --> Final output sent to browser
DEBUG - 2023-11-17 05:24:08 --> Total execution time: 0.1390
ERROR - 2023-11-17 05:24:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:24:09 --> Config Class Initialized
INFO - 2023-11-17 05:24:09 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:24:09 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:24:09 --> Utf8 Class Initialized
INFO - 2023-11-17 05:24:09 --> URI Class Initialized
INFO - 2023-11-17 05:24:09 --> Router Class Initialized
INFO - 2023-11-17 05:24:09 --> Output Class Initialized
INFO - 2023-11-17 05:24:09 --> Security Class Initialized
DEBUG - 2023-11-17 05:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:24:09 --> Input Class Initialized
INFO - 2023-11-17 05:24:09 --> Language Class Initialized
INFO - 2023-11-17 05:24:09 --> Loader Class Initialized
INFO - 2023-11-17 05:24:09 --> Helper loaded: url_helper
INFO - 2023-11-17 05:24:09 --> Helper loaded: file_helper
INFO - 2023-11-17 05:24:09 --> Helper loaded: html_helper
INFO - 2023-11-17 05:24:09 --> Helper loaded: text_helper
INFO - 2023-11-17 05:24:09 --> Helper loaded: form_helper
INFO - 2023-11-17 05:24:09 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:24:09 --> Helper loaded: security_helper
INFO - 2023-11-17 05:24:09 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:24:09 --> Database Driver Class Initialized
INFO - 2023-11-17 05:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:24:09 --> Parser Class Initialized
INFO - 2023-11-17 05:24:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:24:09 --> Pagination Class Initialized
INFO - 2023-11-17 05:24:09 --> Form Validation Class Initialized
INFO - 2023-11-17 05:24:09 --> Controller Class Initialized
INFO - 2023-11-17 05:24:09 --> Model Class Initialized
DEBUG - 2023-11-17 05:24:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:24:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:24:09 --> Model Class Initialized
DEBUG - 2023-11-17 05:24:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:24:09 --> Model Class Initialized
INFO - 2023-11-17 05:24:09 --> Final output sent to browser
DEBUG - 2023-11-17 05:24:09 --> Total execution time: 0.1421
ERROR - 2023-11-17 05:24:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:24:09 --> Config Class Initialized
INFO - 2023-11-17 05:24:09 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:24:09 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:24:09 --> Utf8 Class Initialized
INFO - 2023-11-17 05:24:09 --> URI Class Initialized
INFO - 2023-11-17 05:24:09 --> Router Class Initialized
INFO - 2023-11-17 05:24:09 --> Output Class Initialized
INFO - 2023-11-17 05:24:09 --> Security Class Initialized
DEBUG - 2023-11-17 05:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:24:09 --> Input Class Initialized
INFO - 2023-11-17 05:24:09 --> Language Class Initialized
INFO - 2023-11-17 05:24:09 --> Loader Class Initialized
INFO - 2023-11-17 05:24:09 --> Helper loaded: url_helper
INFO - 2023-11-17 05:24:09 --> Helper loaded: file_helper
INFO - 2023-11-17 05:24:09 --> Helper loaded: html_helper
INFO - 2023-11-17 05:24:09 --> Helper loaded: text_helper
INFO - 2023-11-17 05:24:09 --> Helper loaded: form_helper
INFO - 2023-11-17 05:24:09 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:24:09 --> Helper loaded: security_helper
INFO - 2023-11-17 05:24:09 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:24:09 --> Database Driver Class Initialized
INFO - 2023-11-17 05:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:24:09 --> Parser Class Initialized
INFO - 2023-11-17 05:24:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:24:09 --> Pagination Class Initialized
INFO - 2023-11-17 05:24:09 --> Form Validation Class Initialized
INFO - 2023-11-17 05:24:09 --> Controller Class Initialized
INFO - 2023-11-17 05:24:09 --> Model Class Initialized
DEBUG - 2023-11-17 05:24:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:24:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:24:09 --> Model Class Initialized
DEBUG - 2023-11-17 05:24:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:24:09 --> Model Class Initialized
INFO - 2023-11-17 05:24:09 --> Final output sent to browser
DEBUG - 2023-11-17 05:24:09 --> Total execution time: 0.0564
ERROR - 2023-11-17 05:24:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:24:11 --> Config Class Initialized
INFO - 2023-11-17 05:24:11 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:24:11 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:24:11 --> Utf8 Class Initialized
INFO - 2023-11-17 05:24:11 --> URI Class Initialized
INFO - 2023-11-17 05:24:11 --> Router Class Initialized
INFO - 2023-11-17 05:24:11 --> Output Class Initialized
INFO - 2023-11-17 05:24:11 --> Security Class Initialized
DEBUG - 2023-11-17 05:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:24:11 --> Input Class Initialized
INFO - 2023-11-17 05:24:11 --> Language Class Initialized
INFO - 2023-11-17 05:24:11 --> Loader Class Initialized
INFO - 2023-11-17 05:24:11 --> Helper loaded: url_helper
INFO - 2023-11-17 05:24:11 --> Helper loaded: file_helper
INFO - 2023-11-17 05:24:11 --> Helper loaded: html_helper
INFO - 2023-11-17 05:24:11 --> Helper loaded: text_helper
INFO - 2023-11-17 05:24:11 --> Helper loaded: form_helper
INFO - 2023-11-17 05:24:11 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:24:11 --> Helper loaded: security_helper
INFO - 2023-11-17 05:24:11 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:24:11 --> Database Driver Class Initialized
INFO - 2023-11-17 05:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:24:11 --> Parser Class Initialized
INFO - 2023-11-17 05:24:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:24:11 --> Pagination Class Initialized
INFO - 2023-11-17 05:24:11 --> Form Validation Class Initialized
INFO - 2023-11-17 05:24:11 --> Controller Class Initialized
INFO - 2023-11-17 05:24:11 --> Model Class Initialized
DEBUG - 2023-11-17 05:24:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:24:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:24:11 --> Model Class Initialized
DEBUG - 2023-11-17 05:24:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:24:11 --> Model Class Initialized
INFO - 2023-11-17 05:24:11 --> Final output sent to browser
DEBUG - 2023-11-17 05:24:11 --> Total execution time: 0.0279
ERROR - 2023-11-17 05:24:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:24:13 --> Config Class Initialized
INFO - 2023-11-17 05:24:13 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:24:13 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:24:13 --> Utf8 Class Initialized
INFO - 2023-11-17 05:24:13 --> URI Class Initialized
INFO - 2023-11-17 05:24:13 --> Router Class Initialized
INFO - 2023-11-17 05:24:13 --> Output Class Initialized
INFO - 2023-11-17 05:24:13 --> Security Class Initialized
DEBUG - 2023-11-17 05:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:24:13 --> Input Class Initialized
INFO - 2023-11-17 05:24:13 --> Language Class Initialized
INFO - 2023-11-17 05:24:13 --> Loader Class Initialized
INFO - 2023-11-17 05:24:13 --> Helper loaded: url_helper
INFO - 2023-11-17 05:24:13 --> Helper loaded: file_helper
INFO - 2023-11-17 05:24:13 --> Helper loaded: html_helper
INFO - 2023-11-17 05:24:13 --> Helper loaded: text_helper
INFO - 2023-11-17 05:24:13 --> Helper loaded: form_helper
INFO - 2023-11-17 05:24:13 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:24:13 --> Helper loaded: security_helper
INFO - 2023-11-17 05:24:13 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:24:13 --> Database Driver Class Initialized
INFO - 2023-11-17 05:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:24:13 --> Parser Class Initialized
INFO - 2023-11-17 05:24:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:24:13 --> Pagination Class Initialized
INFO - 2023-11-17 05:24:13 --> Form Validation Class Initialized
INFO - 2023-11-17 05:24:13 --> Controller Class Initialized
INFO - 2023-11-17 05:24:13 --> Model Class Initialized
DEBUG - 2023-11-17 05:24:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:24:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:24:13 --> Model Class Initialized
INFO - 2023-11-17 05:24:13 --> Model Class Initialized
INFO - 2023-11-17 05:24:13 --> Final output sent to browser
DEBUG - 2023-11-17 05:24:13 --> Total execution time: 0.0236
ERROR - 2023-11-17 05:24:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:24:16 --> Config Class Initialized
INFO - 2023-11-17 05:24:16 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:24:16 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:24:16 --> Utf8 Class Initialized
INFO - 2023-11-17 05:24:16 --> URI Class Initialized
INFO - 2023-11-17 05:24:16 --> Router Class Initialized
INFO - 2023-11-17 05:24:16 --> Output Class Initialized
INFO - 2023-11-17 05:24:16 --> Security Class Initialized
DEBUG - 2023-11-17 05:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:24:16 --> Input Class Initialized
INFO - 2023-11-17 05:24:16 --> Language Class Initialized
INFO - 2023-11-17 05:24:16 --> Loader Class Initialized
INFO - 2023-11-17 05:24:16 --> Helper loaded: url_helper
INFO - 2023-11-17 05:24:16 --> Helper loaded: file_helper
INFO - 2023-11-17 05:24:16 --> Helper loaded: html_helper
INFO - 2023-11-17 05:24:16 --> Helper loaded: text_helper
INFO - 2023-11-17 05:24:16 --> Helper loaded: form_helper
INFO - 2023-11-17 05:24:16 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:24:16 --> Helper loaded: security_helper
INFO - 2023-11-17 05:24:16 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:24:16 --> Database Driver Class Initialized
INFO - 2023-11-17 05:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:24:16 --> Parser Class Initialized
INFO - 2023-11-17 05:24:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:24:16 --> Pagination Class Initialized
INFO - 2023-11-17 05:24:16 --> Form Validation Class Initialized
INFO - 2023-11-17 05:24:16 --> Controller Class Initialized
INFO - 2023-11-17 05:24:16 --> Model Class Initialized
DEBUG - 2023-11-17 05:24:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:24:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:24:16 --> Model Class Initialized
INFO - 2023-11-17 05:24:16 --> Final output sent to browser
DEBUG - 2023-11-17 05:24:16 --> Total execution time: 0.0172
ERROR - 2023-11-17 05:25:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:25:02 --> Config Class Initialized
INFO - 2023-11-17 05:25:02 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:25:02 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:25:02 --> Utf8 Class Initialized
INFO - 2023-11-17 05:25:02 --> URI Class Initialized
INFO - 2023-11-17 05:25:02 --> Router Class Initialized
INFO - 2023-11-17 05:25:02 --> Output Class Initialized
INFO - 2023-11-17 05:25:02 --> Security Class Initialized
DEBUG - 2023-11-17 05:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:25:02 --> Input Class Initialized
INFO - 2023-11-17 05:25:02 --> Language Class Initialized
INFO - 2023-11-17 05:25:02 --> Loader Class Initialized
INFO - 2023-11-17 05:25:02 --> Helper loaded: url_helper
INFO - 2023-11-17 05:25:02 --> Helper loaded: file_helper
INFO - 2023-11-17 05:25:02 --> Helper loaded: html_helper
INFO - 2023-11-17 05:25:02 --> Helper loaded: text_helper
INFO - 2023-11-17 05:25:02 --> Helper loaded: form_helper
INFO - 2023-11-17 05:25:02 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:25:02 --> Helper loaded: security_helper
INFO - 2023-11-17 05:25:02 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:25:02 --> Database Driver Class Initialized
INFO - 2023-11-17 05:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:25:02 --> Parser Class Initialized
INFO - 2023-11-17 05:25:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:25:02 --> Pagination Class Initialized
INFO - 2023-11-17 05:25:02 --> Form Validation Class Initialized
INFO - 2023-11-17 05:25:02 --> Controller Class Initialized
INFO - 2023-11-17 05:25:02 --> Model Class Initialized
DEBUG - 2023-11-17 05:25:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:25:02 --> Model Class Initialized
INFO - 2023-11-17 05:25:02 --> Final output sent to browser
DEBUG - 2023-11-17 05:25:02 --> Total execution time: 0.0202
ERROR - 2023-11-17 05:25:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:25:02 --> Config Class Initialized
INFO - 2023-11-17 05:25:02 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:25:02 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:25:02 --> Utf8 Class Initialized
INFO - 2023-11-17 05:25:02 --> URI Class Initialized
DEBUG - 2023-11-17 05:25:02 --> No URI present. Default controller set.
INFO - 2023-11-17 05:25:02 --> Router Class Initialized
INFO - 2023-11-17 05:25:02 --> Output Class Initialized
INFO - 2023-11-17 05:25:02 --> Security Class Initialized
DEBUG - 2023-11-17 05:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:25:02 --> Input Class Initialized
INFO - 2023-11-17 05:25:02 --> Language Class Initialized
INFO - 2023-11-17 05:25:02 --> Loader Class Initialized
INFO - 2023-11-17 05:25:02 --> Helper loaded: url_helper
INFO - 2023-11-17 05:25:02 --> Helper loaded: file_helper
INFO - 2023-11-17 05:25:02 --> Helper loaded: html_helper
INFO - 2023-11-17 05:25:02 --> Helper loaded: text_helper
INFO - 2023-11-17 05:25:02 --> Helper loaded: form_helper
INFO - 2023-11-17 05:25:02 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:25:02 --> Helper loaded: security_helper
INFO - 2023-11-17 05:25:02 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:25:02 --> Database Driver Class Initialized
INFO - 2023-11-17 05:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:25:02 --> Parser Class Initialized
INFO - 2023-11-17 05:25:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:25:02 --> Pagination Class Initialized
INFO - 2023-11-17 05:25:02 --> Form Validation Class Initialized
INFO - 2023-11-17 05:25:02 --> Controller Class Initialized
INFO - 2023-11-17 05:25:02 --> Model Class Initialized
DEBUG - 2023-11-17 05:25:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:25:02 --> Model Class Initialized
DEBUG - 2023-11-17 05:25:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:25:02 --> Model Class Initialized
INFO - 2023-11-17 05:25:02 --> Model Class Initialized
INFO - 2023-11-17 05:25:02 --> Model Class Initialized
INFO - 2023-11-17 05:25:02 --> Model Class Initialized
DEBUG - 2023-11-17 05:25:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:25:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:25:02 --> Model Class Initialized
INFO - 2023-11-17 05:25:02 --> Model Class Initialized
INFO - 2023-11-17 05:25:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-17 05:25:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:25:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 05:25:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 05:25:02 --> Model Class Initialized
INFO - 2023-11-17 05:25:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 05:25:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 05:25:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 05:25:03 --> Final output sent to browser
DEBUG - 2023-11-17 05:25:03 --> Total execution time: 0.3804
ERROR - 2023-11-17 05:25:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:25:03 --> Config Class Initialized
INFO - 2023-11-17 05:25:03 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:25:03 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:25:03 --> Utf8 Class Initialized
INFO - 2023-11-17 05:25:03 --> URI Class Initialized
INFO - 2023-11-17 05:25:03 --> Router Class Initialized
INFO - 2023-11-17 05:25:03 --> Output Class Initialized
INFO - 2023-11-17 05:25:03 --> Security Class Initialized
DEBUG - 2023-11-17 05:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:25:03 --> Input Class Initialized
INFO - 2023-11-17 05:25:03 --> Language Class Initialized
INFO - 2023-11-17 05:25:03 --> Loader Class Initialized
INFO - 2023-11-17 05:25:03 --> Helper loaded: url_helper
INFO - 2023-11-17 05:25:03 --> Helper loaded: file_helper
INFO - 2023-11-17 05:25:03 --> Helper loaded: html_helper
INFO - 2023-11-17 05:25:03 --> Helper loaded: text_helper
INFO - 2023-11-17 05:25:03 --> Helper loaded: form_helper
INFO - 2023-11-17 05:25:03 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:25:03 --> Helper loaded: security_helper
INFO - 2023-11-17 05:25:03 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:25:03 --> Database Driver Class Initialized
INFO - 2023-11-17 05:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:25:03 --> Parser Class Initialized
INFO - 2023-11-17 05:25:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:25:03 --> Pagination Class Initialized
INFO - 2023-11-17 05:25:03 --> Form Validation Class Initialized
INFO - 2023-11-17 05:25:03 --> Controller Class Initialized
DEBUG - 2023-11-17 05:25:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:25:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:25:03 --> Model Class Initialized
INFO - 2023-11-17 05:25:03 --> Final output sent to browser
DEBUG - 2023-11-17 05:25:03 --> Total execution time: 0.0132
ERROR - 2023-11-17 05:25:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:25:15 --> Config Class Initialized
INFO - 2023-11-17 05:25:15 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:25:15 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:25:15 --> Utf8 Class Initialized
INFO - 2023-11-17 05:25:15 --> URI Class Initialized
INFO - 2023-11-17 05:25:15 --> Router Class Initialized
INFO - 2023-11-17 05:25:15 --> Output Class Initialized
INFO - 2023-11-17 05:25:15 --> Security Class Initialized
DEBUG - 2023-11-17 05:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:25:15 --> Input Class Initialized
INFO - 2023-11-17 05:25:15 --> Language Class Initialized
INFO - 2023-11-17 05:25:15 --> Loader Class Initialized
INFO - 2023-11-17 05:25:15 --> Helper loaded: url_helper
INFO - 2023-11-17 05:25:15 --> Helper loaded: file_helper
INFO - 2023-11-17 05:25:15 --> Helper loaded: html_helper
INFO - 2023-11-17 05:25:15 --> Helper loaded: text_helper
INFO - 2023-11-17 05:25:15 --> Helper loaded: form_helper
INFO - 2023-11-17 05:25:15 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:25:15 --> Helper loaded: security_helper
INFO - 2023-11-17 05:25:15 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:25:15 --> Database Driver Class Initialized
INFO - 2023-11-17 05:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:25:15 --> Parser Class Initialized
INFO - 2023-11-17 05:25:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:25:15 --> Pagination Class Initialized
INFO - 2023-11-17 05:25:15 --> Form Validation Class Initialized
INFO - 2023-11-17 05:25:15 --> Controller Class Initialized
INFO - 2023-11-17 05:25:15 --> Model Class Initialized
INFO - 2023-11-17 05:25:15 --> Model Class Initialized
INFO - 2023-11-17 05:25:15 --> Model Class Initialized
INFO - 2023-11-17 05:25:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report_batch_wise.php
DEBUG - 2023-11-17 05:25:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:25:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 05:25:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 05:25:15 --> Model Class Initialized
INFO - 2023-11-17 05:25:15 --> Model Class Initialized
INFO - 2023-11-17 05:25:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 05:25:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 05:25:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 05:25:16 --> Final output sent to browser
DEBUG - 2023-11-17 05:25:16 --> Total execution time: 0.1876
ERROR - 2023-11-17 05:25:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:25:16 --> Config Class Initialized
INFO - 2023-11-17 05:25:16 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:25:16 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:25:16 --> Utf8 Class Initialized
INFO - 2023-11-17 05:25:16 --> URI Class Initialized
INFO - 2023-11-17 05:25:16 --> Router Class Initialized
INFO - 2023-11-17 05:25:16 --> Output Class Initialized
INFO - 2023-11-17 05:25:16 --> Security Class Initialized
DEBUG - 2023-11-17 05:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:25:16 --> Input Class Initialized
INFO - 2023-11-17 05:25:16 --> Language Class Initialized
INFO - 2023-11-17 05:25:16 --> Loader Class Initialized
INFO - 2023-11-17 05:25:16 --> Helper loaded: url_helper
INFO - 2023-11-17 05:25:16 --> Helper loaded: file_helper
INFO - 2023-11-17 05:25:16 --> Helper loaded: html_helper
INFO - 2023-11-17 05:25:16 --> Helper loaded: text_helper
INFO - 2023-11-17 05:25:16 --> Helper loaded: form_helper
INFO - 2023-11-17 05:25:16 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:25:16 --> Helper loaded: security_helper
INFO - 2023-11-17 05:25:16 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:25:16 --> Database Driver Class Initialized
INFO - 2023-11-17 05:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:25:16 --> Parser Class Initialized
INFO - 2023-11-17 05:25:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:25:16 --> Pagination Class Initialized
INFO - 2023-11-17 05:25:16 --> Form Validation Class Initialized
INFO - 2023-11-17 05:25:16 --> Controller Class Initialized
INFO - 2023-11-17 05:25:16 --> Model Class Initialized
INFO - 2023-11-17 05:25:16 --> Model Class Initialized
INFO - 2023-11-17 05:25:16 --> Final output sent to browser
DEBUG - 2023-11-17 05:25:16 --> Total execution time: 0.0275
ERROR - 2023-11-17 05:25:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:25:48 --> Config Class Initialized
INFO - 2023-11-17 05:25:48 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:25:48 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:25:48 --> Utf8 Class Initialized
INFO - 2023-11-17 05:25:48 --> URI Class Initialized
INFO - 2023-11-17 05:25:48 --> Router Class Initialized
INFO - 2023-11-17 05:25:48 --> Output Class Initialized
INFO - 2023-11-17 05:25:48 --> Security Class Initialized
DEBUG - 2023-11-17 05:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:25:48 --> Input Class Initialized
INFO - 2023-11-17 05:25:48 --> Language Class Initialized
INFO - 2023-11-17 05:25:48 --> Loader Class Initialized
INFO - 2023-11-17 05:25:48 --> Helper loaded: url_helper
INFO - 2023-11-17 05:25:48 --> Helper loaded: file_helper
INFO - 2023-11-17 05:25:48 --> Helper loaded: html_helper
INFO - 2023-11-17 05:25:48 --> Helper loaded: text_helper
INFO - 2023-11-17 05:25:48 --> Helper loaded: form_helper
INFO - 2023-11-17 05:25:48 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:25:48 --> Helper loaded: security_helper
INFO - 2023-11-17 05:25:48 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:25:48 --> Database Driver Class Initialized
INFO - 2023-11-17 05:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:25:48 --> Parser Class Initialized
INFO - 2023-11-17 05:25:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:25:48 --> Pagination Class Initialized
INFO - 2023-11-17 05:25:48 --> Form Validation Class Initialized
INFO - 2023-11-17 05:25:48 --> Controller Class Initialized
INFO - 2023-11-17 05:25:48 --> Model Class Initialized
INFO - 2023-11-17 05:25:48 --> Model Class Initialized
INFO - 2023-11-17 05:25:48 --> Final output sent to browser
DEBUG - 2023-11-17 05:25:48 --> Total execution time: 0.0546
ERROR - 2023-11-17 05:25:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:25:55 --> Config Class Initialized
INFO - 2023-11-17 05:25:55 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:25:55 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:25:55 --> Utf8 Class Initialized
INFO - 2023-11-17 05:25:55 --> URI Class Initialized
INFO - 2023-11-17 05:25:55 --> Router Class Initialized
INFO - 2023-11-17 05:25:55 --> Output Class Initialized
INFO - 2023-11-17 05:25:55 --> Security Class Initialized
DEBUG - 2023-11-17 05:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:25:55 --> Input Class Initialized
INFO - 2023-11-17 05:25:55 --> Language Class Initialized
INFO - 2023-11-17 05:25:55 --> Loader Class Initialized
INFO - 2023-11-17 05:25:55 --> Helper loaded: url_helper
INFO - 2023-11-17 05:25:55 --> Helper loaded: file_helper
INFO - 2023-11-17 05:25:55 --> Helper loaded: html_helper
INFO - 2023-11-17 05:25:55 --> Helper loaded: text_helper
INFO - 2023-11-17 05:25:55 --> Helper loaded: form_helper
INFO - 2023-11-17 05:25:55 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:25:55 --> Helper loaded: security_helper
INFO - 2023-11-17 05:25:55 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:25:55 --> Database Driver Class Initialized
INFO - 2023-11-17 05:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:25:55 --> Parser Class Initialized
INFO - 2023-11-17 05:25:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:25:55 --> Pagination Class Initialized
INFO - 2023-11-17 05:25:55 --> Form Validation Class Initialized
INFO - 2023-11-17 05:25:55 --> Controller Class Initialized
INFO - 2023-11-17 05:25:55 --> Model Class Initialized
INFO - 2023-11-17 05:25:55 --> Model Class Initialized
INFO - 2023-11-17 05:25:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase.php
DEBUG - 2023-11-17 05:25:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:25:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 05:25:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 05:25:55 --> Model Class Initialized
INFO - 2023-11-17 05:25:55 --> Model Class Initialized
INFO - 2023-11-17 05:25:55 --> Model Class Initialized
INFO - 2023-11-17 05:25:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 05:25:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 05:25:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 05:25:55 --> Final output sent to browser
DEBUG - 2023-11-17 05:25:55 --> Total execution time: 0.2007
ERROR - 2023-11-17 05:25:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:25:56 --> Config Class Initialized
INFO - 2023-11-17 05:25:56 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:25:56 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:25:56 --> Utf8 Class Initialized
INFO - 2023-11-17 05:25:56 --> URI Class Initialized
INFO - 2023-11-17 05:25:56 --> Router Class Initialized
INFO - 2023-11-17 05:25:56 --> Output Class Initialized
INFO - 2023-11-17 05:25:56 --> Security Class Initialized
DEBUG - 2023-11-17 05:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:25:56 --> Input Class Initialized
INFO - 2023-11-17 05:25:56 --> Language Class Initialized
INFO - 2023-11-17 05:25:56 --> Loader Class Initialized
INFO - 2023-11-17 05:25:56 --> Helper loaded: url_helper
INFO - 2023-11-17 05:25:56 --> Helper loaded: file_helper
INFO - 2023-11-17 05:25:56 --> Helper loaded: html_helper
INFO - 2023-11-17 05:25:56 --> Helper loaded: text_helper
INFO - 2023-11-17 05:25:56 --> Helper loaded: form_helper
INFO - 2023-11-17 05:25:56 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:25:56 --> Helper loaded: security_helper
INFO - 2023-11-17 05:25:56 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:25:56 --> Database Driver Class Initialized
INFO - 2023-11-17 05:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:25:56 --> Parser Class Initialized
INFO - 2023-11-17 05:25:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:25:56 --> Pagination Class Initialized
INFO - 2023-11-17 05:25:56 --> Form Validation Class Initialized
INFO - 2023-11-17 05:25:56 --> Controller Class Initialized
INFO - 2023-11-17 05:25:56 --> Model Class Initialized
INFO - 2023-11-17 05:25:56 --> Model Class Initialized
INFO - 2023-11-17 05:25:56 --> Final output sent to browser
DEBUG - 2023-11-17 05:25:56 --> Total execution time: 0.0504
ERROR - 2023-11-17 05:26:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:26:06 --> Config Class Initialized
INFO - 2023-11-17 05:26:06 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:26:06 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:26:06 --> Utf8 Class Initialized
INFO - 2023-11-17 05:26:06 --> URI Class Initialized
INFO - 2023-11-17 05:26:06 --> Router Class Initialized
INFO - 2023-11-17 05:26:06 --> Output Class Initialized
INFO - 2023-11-17 05:26:06 --> Security Class Initialized
DEBUG - 2023-11-17 05:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:26:06 --> Input Class Initialized
INFO - 2023-11-17 05:26:06 --> Language Class Initialized
INFO - 2023-11-17 05:26:06 --> Loader Class Initialized
INFO - 2023-11-17 05:26:06 --> Helper loaded: url_helper
INFO - 2023-11-17 05:26:06 --> Helper loaded: file_helper
INFO - 2023-11-17 05:26:06 --> Helper loaded: html_helper
INFO - 2023-11-17 05:26:06 --> Helper loaded: text_helper
INFO - 2023-11-17 05:26:06 --> Helper loaded: form_helper
INFO - 2023-11-17 05:26:06 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:26:06 --> Helper loaded: security_helper
INFO - 2023-11-17 05:26:06 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:26:06 --> Database Driver Class Initialized
INFO - 2023-11-17 05:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:26:06 --> Parser Class Initialized
INFO - 2023-11-17 05:26:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:26:06 --> Pagination Class Initialized
INFO - 2023-11-17 05:26:06 --> Form Validation Class Initialized
INFO - 2023-11-17 05:26:06 --> Controller Class Initialized
INFO - 2023-11-17 05:26:06 --> Model Class Initialized
INFO - 2023-11-17 05:26:06 --> Model Class Initialized
INFO - 2023-11-17 05:26:06 --> Final output sent to browser
DEBUG - 2023-11-17 05:26:06 --> Total execution time: 0.0844
ERROR - 2023-11-17 05:26:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:26:12 --> Config Class Initialized
INFO - 2023-11-17 05:26:12 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:26:12 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:26:12 --> Utf8 Class Initialized
INFO - 2023-11-17 05:26:12 --> URI Class Initialized
INFO - 2023-11-17 05:26:12 --> Router Class Initialized
INFO - 2023-11-17 05:26:12 --> Output Class Initialized
INFO - 2023-11-17 05:26:12 --> Security Class Initialized
DEBUG - 2023-11-17 05:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:26:12 --> Input Class Initialized
INFO - 2023-11-17 05:26:12 --> Language Class Initialized
INFO - 2023-11-17 05:26:12 --> Loader Class Initialized
INFO - 2023-11-17 05:26:12 --> Helper loaded: url_helper
INFO - 2023-11-17 05:26:12 --> Helper loaded: file_helper
INFO - 2023-11-17 05:26:12 --> Helper loaded: html_helper
INFO - 2023-11-17 05:26:12 --> Helper loaded: text_helper
INFO - 2023-11-17 05:26:12 --> Helper loaded: form_helper
INFO - 2023-11-17 05:26:12 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:26:12 --> Helper loaded: security_helper
INFO - 2023-11-17 05:26:12 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:26:12 --> Database Driver Class Initialized
INFO - 2023-11-17 05:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:26:12 --> Parser Class Initialized
INFO - 2023-11-17 05:26:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:26:12 --> Pagination Class Initialized
INFO - 2023-11-17 05:26:12 --> Form Validation Class Initialized
INFO - 2023-11-17 05:26:12 --> Controller Class Initialized
INFO - 2023-11-17 05:26:12 --> Model Class Initialized
INFO - 2023-11-17 05:26:12 --> Model Class Initialized
INFO - 2023-11-17 05:26:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase_html.php
DEBUG - 2023-11-17 05:26:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:26:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 05:26:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 05:26:12 --> Model Class Initialized
INFO - 2023-11-17 05:26:12 --> Model Class Initialized
INFO - 2023-11-17 05:26:12 --> Model Class Initialized
INFO - 2023-11-17 05:26:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 05:26:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 05:26:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 05:26:12 --> Final output sent to browser
DEBUG - 2023-11-17 05:26:12 --> Total execution time: 0.2174
ERROR - 2023-11-17 05:26:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:26:22 --> Config Class Initialized
INFO - 2023-11-17 05:26:22 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:26:22 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:26:22 --> Utf8 Class Initialized
INFO - 2023-11-17 05:26:22 --> URI Class Initialized
INFO - 2023-11-17 05:26:22 --> Router Class Initialized
INFO - 2023-11-17 05:26:22 --> Output Class Initialized
INFO - 2023-11-17 05:26:22 --> Security Class Initialized
DEBUG - 2023-11-17 05:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:26:22 --> Input Class Initialized
INFO - 2023-11-17 05:26:22 --> Language Class Initialized
INFO - 2023-11-17 05:26:22 --> Loader Class Initialized
INFO - 2023-11-17 05:26:22 --> Helper loaded: url_helper
INFO - 2023-11-17 05:26:22 --> Helper loaded: file_helper
INFO - 2023-11-17 05:26:22 --> Helper loaded: html_helper
INFO - 2023-11-17 05:26:22 --> Helper loaded: text_helper
INFO - 2023-11-17 05:26:22 --> Helper loaded: form_helper
INFO - 2023-11-17 05:26:22 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:26:22 --> Helper loaded: security_helper
INFO - 2023-11-17 05:26:22 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:26:22 --> Database Driver Class Initialized
INFO - 2023-11-17 05:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:26:22 --> Parser Class Initialized
INFO - 2023-11-17 05:26:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:26:22 --> Pagination Class Initialized
INFO - 2023-11-17 05:26:22 --> Form Validation Class Initialized
INFO - 2023-11-17 05:26:22 --> Controller Class Initialized
INFO - 2023-11-17 05:26:22 --> Model Class Initialized
INFO - 2023-11-17 05:26:22 --> Model Class Initialized
INFO - 2023-11-17 05:26:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase.php
DEBUG - 2023-11-17 05:26:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:26:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 05:26:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 05:26:22 --> Model Class Initialized
INFO - 2023-11-17 05:26:22 --> Model Class Initialized
INFO - 2023-11-17 05:26:22 --> Model Class Initialized
INFO - 2023-11-17 05:26:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 05:26:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 05:26:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 05:26:22 --> Final output sent to browser
DEBUG - 2023-11-17 05:26:22 --> Total execution time: 0.1976
ERROR - 2023-11-17 05:26:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:26:22 --> Config Class Initialized
INFO - 2023-11-17 05:26:22 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:26:22 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:26:22 --> Utf8 Class Initialized
INFO - 2023-11-17 05:26:22 --> URI Class Initialized
INFO - 2023-11-17 05:26:22 --> Router Class Initialized
INFO - 2023-11-17 05:26:22 --> Output Class Initialized
INFO - 2023-11-17 05:26:22 --> Security Class Initialized
DEBUG - 2023-11-17 05:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:26:22 --> Input Class Initialized
INFO - 2023-11-17 05:26:22 --> Language Class Initialized
INFO - 2023-11-17 05:26:22 --> Loader Class Initialized
INFO - 2023-11-17 05:26:22 --> Helper loaded: url_helper
INFO - 2023-11-17 05:26:22 --> Helper loaded: file_helper
INFO - 2023-11-17 05:26:22 --> Helper loaded: html_helper
INFO - 2023-11-17 05:26:22 --> Helper loaded: text_helper
INFO - 2023-11-17 05:26:22 --> Helper loaded: form_helper
INFO - 2023-11-17 05:26:22 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:26:22 --> Helper loaded: security_helper
INFO - 2023-11-17 05:26:22 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:26:22 --> Database Driver Class Initialized
INFO - 2023-11-17 05:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:26:22 --> Parser Class Initialized
INFO - 2023-11-17 05:26:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:26:22 --> Pagination Class Initialized
INFO - 2023-11-17 05:26:22 --> Form Validation Class Initialized
INFO - 2023-11-17 05:26:22 --> Controller Class Initialized
INFO - 2023-11-17 05:26:22 --> Model Class Initialized
INFO - 2023-11-17 05:26:22 --> Model Class Initialized
INFO - 2023-11-17 05:26:22 --> Final output sent to browser
DEBUG - 2023-11-17 05:26:22 --> Total execution time: 0.0499
ERROR - 2023-11-17 05:26:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:26:32 --> Config Class Initialized
INFO - 2023-11-17 05:26:32 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:26:32 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:26:32 --> Utf8 Class Initialized
INFO - 2023-11-17 05:26:32 --> URI Class Initialized
INFO - 2023-11-17 05:26:32 --> Router Class Initialized
INFO - 2023-11-17 05:26:32 --> Output Class Initialized
INFO - 2023-11-17 05:26:32 --> Security Class Initialized
DEBUG - 2023-11-17 05:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:26:32 --> Input Class Initialized
INFO - 2023-11-17 05:26:32 --> Language Class Initialized
INFO - 2023-11-17 05:26:32 --> Loader Class Initialized
INFO - 2023-11-17 05:26:32 --> Helper loaded: url_helper
INFO - 2023-11-17 05:26:32 --> Helper loaded: file_helper
INFO - 2023-11-17 05:26:32 --> Helper loaded: html_helper
INFO - 2023-11-17 05:26:32 --> Helper loaded: text_helper
INFO - 2023-11-17 05:26:32 --> Helper loaded: form_helper
INFO - 2023-11-17 05:26:32 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:26:32 --> Helper loaded: security_helper
INFO - 2023-11-17 05:26:32 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:26:32 --> Database Driver Class Initialized
INFO - 2023-11-17 05:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:26:32 --> Parser Class Initialized
INFO - 2023-11-17 05:26:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:26:32 --> Pagination Class Initialized
INFO - 2023-11-17 05:26:32 --> Form Validation Class Initialized
INFO - 2023-11-17 05:26:32 --> Controller Class Initialized
INFO - 2023-11-17 05:26:32 --> Model Class Initialized
INFO - 2023-11-17 05:26:32 --> Model Class Initialized
INFO - 2023-11-17 05:26:32 --> Final output sent to browser
DEBUG - 2023-11-17 05:26:32 --> Total execution time: 0.0857
ERROR - 2023-11-17 05:26:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:26:43 --> Config Class Initialized
INFO - 2023-11-17 05:26:43 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:26:43 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:26:43 --> Utf8 Class Initialized
INFO - 2023-11-17 05:26:43 --> URI Class Initialized
INFO - 2023-11-17 05:26:43 --> Router Class Initialized
INFO - 2023-11-17 05:26:43 --> Output Class Initialized
INFO - 2023-11-17 05:26:43 --> Security Class Initialized
DEBUG - 2023-11-17 05:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:26:43 --> Input Class Initialized
INFO - 2023-11-17 05:26:43 --> Language Class Initialized
INFO - 2023-11-17 05:26:43 --> Loader Class Initialized
INFO - 2023-11-17 05:26:43 --> Helper loaded: url_helper
INFO - 2023-11-17 05:26:43 --> Helper loaded: file_helper
INFO - 2023-11-17 05:26:43 --> Helper loaded: html_helper
INFO - 2023-11-17 05:26:43 --> Helper loaded: text_helper
INFO - 2023-11-17 05:26:43 --> Helper loaded: form_helper
INFO - 2023-11-17 05:26:43 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:26:43 --> Helper loaded: security_helper
INFO - 2023-11-17 05:26:43 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:26:43 --> Database Driver Class Initialized
INFO - 2023-11-17 05:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:26:43 --> Parser Class Initialized
INFO - 2023-11-17 05:26:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:26:43 --> Pagination Class Initialized
INFO - 2023-11-17 05:26:43 --> Form Validation Class Initialized
INFO - 2023-11-17 05:26:43 --> Controller Class Initialized
INFO - 2023-11-17 05:26:43 --> Model Class Initialized
INFO - 2023-11-17 05:26:43 --> Model Class Initialized
INFO - 2023-11-17 05:26:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase_html.php
DEBUG - 2023-11-17 05:26:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:26:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 05:26:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 05:26:43 --> Model Class Initialized
INFO - 2023-11-17 05:26:43 --> Model Class Initialized
INFO - 2023-11-17 05:26:43 --> Model Class Initialized
INFO - 2023-11-17 05:26:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 05:26:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 05:26:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 05:26:43 --> Final output sent to browser
DEBUG - 2023-11-17 05:26:43 --> Total execution time: 0.2042
ERROR - 2023-11-17 05:26:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:26:49 --> Config Class Initialized
INFO - 2023-11-17 05:26:49 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:26:49 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:26:49 --> Utf8 Class Initialized
INFO - 2023-11-17 05:26:49 --> URI Class Initialized
INFO - 2023-11-17 05:26:49 --> Router Class Initialized
INFO - 2023-11-17 05:26:49 --> Output Class Initialized
INFO - 2023-11-17 05:26:49 --> Security Class Initialized
DEBUG - 2023-11-17 05:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:26:49 --> Input Class Initialized
INFO - 2023-11-17 05:26:49 --> Language Class Initialized
INFO - 2023-11-17 05:26:49 --> Loader Class Initialized
INFO - 2023-11-17 05:26:49 --> Helper loaded: url_helper
INFO - 2023-11-17 05:26:49 --> Helper loaded: file_helper
INFO - 2023-11-17 05:26:49 --> Helper loaded: html_helper
INFO - 2023-11-17 05:26:49 --> Helper loaded: text_helper
INFO - 2023-11-17 05:26:49 --> Helper loaded: form_helper
INFO - 2023-11-17 05:26:49 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:26:49 --> Helper loaded: security_helper
INFO - 2023-11-17 05:26:49 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:26:49 --> Database Driver Class Initialized
INFO - 2023-11-17 05:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:26:49 --> Parser Class Initialized
INFO - 2023-11-17 05:26:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:26:49 --> Pagination Class Initialized
INFO - 2023-11-17 05:26:49 --> Form Validation Class Initialized
INFO - 2023-11-17 05:26:49 --> Controller Class Initialized
INFO - 2023-11-17 05:26:49 --> Model Class Initialized
INFO - 2023-11-17 05:26:49 --> Model Class Initialized
INFO - 2023-11-17 05:26:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase.php
DEBUG - 2023-11-17 05:26:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:26:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 05:26:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 05:26:49 --> Model Class Initialized
INFO - 2023-11-17 05:26:49 --> Model Class Initialized
INFO - 2023-11-17 05:26:49 --> Model Class Initialized
INFO - 2023-11-17 05:26:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 05:26:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 05:26:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 05:26:49 --> Final output sent to browser
DEBUG - 2023-11-17 05:26:49 --> Total execution time: 0.1937
ERROR - 2023-11-17 05:26:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:26:50 --> Config Class Initialized
INFO - 2023-11-17 05:26:50 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:26:50 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:26:50 --> Utf8 Class Initialized
INFO - 2023-11-17 05:26:50 --> URI Class Initialized
INFO - 2023-11-17 05:26:50 --> Router Class Initialized
INFO - 2023-11-17 05:26:50 --> Output Class Initialized
INFO - 2023-11-17 05:26:50 --> Security Class Initialized
DEBUG - 2023-11-17 05:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:26:50 --> Input Class Initialized
INFO - 2023-11-17 05:26:50 --> Language Class Initialized
INFO - 2023-11-17 05:26:50 --> Loader Class Initialized
INFO - 2023-11-17 05:26:50 --> Helper loaded: url_helper
INFO - 2023-11-17 05:26:50 --> Helper loaded: file_helper
INFO - 2023-11-17 05:26:50 --> Helper loaded: html_helper
INFO - 2023-11-17 05:26:50 --> Helper loaded: text_helper
INFO - 2023-11-17 05:26:50 --> Helper loaded: form_helper
INFO - 2023-11-17 05:26:50 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:26:50 --> Helper loaded: security_helper
INFO - 2023-11-17 05:26:50 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:26:50 --> Database Driver Class Initialized
INFO - 2023-11-17 05:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:26:50 --> Parser Class Initialized
INFO - 2023-11-17 05:26:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:26:50 --> Pagination Class Initialized
INFO - 2023-11-17 05:26:50 --> Form Validation Class Initialized
INFO - 2023-11-17 05:26:50 --> Controller Class Initialized
INFO - 2023-11-17 05:26:50 --> Model Class Initialized
INFO - 2023-11-17 05:26:50 --> Model Class Initialized
INFO - 2023-11-17 05:26:50 --> Final output sent to browser
DEBUG - 2023-11-17 05:26:50 --> Total execution time: 0.0417
ERROR - 2023-11-17 05:26:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:26:57 --> Config Class Initialized
INFO - 2023-11-17 05:26:57 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:26:57 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:26:57 --> Utf8 Class Initialized
INFO - 2023-11-17 05:26:57 --> URI Class Initialized
INFO - 2023-11-17 05:26:57 --> Router Class Initialized
INFO - 2023-11-17 05:26:57 --> Output Class Initialized
INFO - 2023-11-17 05:26:57 --> Security Class Initialized
DEBUG - 2023-11-17 05:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:26:57 --> Input Class Initialized
INFO - 2023-11-17 05:26:57 --> Language Class Initialized
INFO - 2023-11-17 05:26:57 --> Loader Class Initialized
INFO - 2023-11-17 05:26:57 --> Helper loaded: url_helper
INFO - 2023-11-17 05:26:57 --> Helper loaded: file_helper
INFO - 2023-11-17 05:26:57 --> Helper loaded: html_helper
INFO - 2023-11-17 05:26:57 --> Helper loaded: text_helper
INFO - 2023-11-17 05:26:57 --> Helper loaded: form_helper
INFO - 2023-11-17 05:26:57 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:26:57 --> Helper loaded: security_helper
INFO - 2023-11-17 05:26:57 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:26:57 --> Database Driver Class Initialized
INFO - 2023-11-17 05:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:26:57 --> Parser Class Initialized
INFO - 2023-11-17 05:26:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:26:57 --> Pagination Class Initialized
INFO - 2023-11-17 05:26:57 --> Form Validation Class Initialized
INFO - 2023-11-17 05:26:57 --> Controller Class Initialized
INFO - 2023-11-17 05:26:57 --> Model Class Initialized
INFO - 2023-11-17 05:26:57 --> Model Class Initialized
INFO - 2023-11-17 05:26:57 --> Final output sent to browser
DEBUG - 2023-11-17 05:26:57 --> Total execution time: 0.0889
ERROR - 2023-11-17 05:27:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:27:09 --> Config Class Initialized
INFO - 2023-11-17 05:27:09 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:27:09 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:27:09 --> Utf8 Class Initialized
INFO - 2023-11-17 05:27:09 --> URI Class Initialized
INFO - 2023-11-17 05:27:09 --> Router Class Initialized
INFO - 2023-11-17 05:27:09 --> Output Class Initialized
INFO - 2023-11-17 05:27:09 --> Security Class Initialized
DEBUG - 2023-11-17 05:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:27:09 --> Input Class Initialized
INFO - 2023-11-17 05:27:09 --> Language Class Initialized
INFO - 2023-11-17 05:27:09 --> Loader Class Initialized
INFO - 2023-11-17 05:27:09 --> Helper loaded: url_helper
INFO - 2023-11-17 05:27:09 --> Helper loaded: file_helper
INFO - 2023-11-17 05:27:09 --> Helper loaded: html_helper
INFO - 2023-11-17 05:27:09 --> Helper loaded: text_helper
INFO - 2023-11-17 05:27:09 --> Helper loaded: form_helper
INFO - 2023-11-17 05:27:09 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:27:09 --> Helper loaded: security_helper
INFO - 2023-11-17 05:27:09 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:27:09 --> Database Driver Class Initialized
INFO - 2023-11-17 05:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:27:09 --> Parser Class Initialized
INFO - 2023-11-17 05:27:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:27:09 --> Pagination Class Initialized
INFO - 2023-11-17 05:27:09 --> Form Validation Class Initialized
INFO - 2023-11-17 05:27:09 --> Controller Class Initialized
INFO - 2023-11-17 05:27:09 --> Model Class Initialized
INFO - 2023-11-17 05:27:09 --> Model Class Initialized
INFO - 2023-11-17 05:27:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase_html.php
DEBUG - 2023-11-17 05:27:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:27:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 05:27:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 05:27:09 --> Model Class Initialized
INFO - 2023-11-17 05:27:09 --> Model Class Initialized
INFO - 2023-11-17 05:27:09 --> Model Class Initialized
INFO - 2023-11-17 05:27:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 05:27:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 05:27:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 05:27:10 --> Final output sent to browser
DEBUG - 2023-11-17 05:27:10 --> Total execution time: 0.2152
ERROR - 2023-11-17 05:27:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:27:13 --> Config Class Initialized
INFO - 2023-11-17 05:27:13 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:27:13 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:27:13 --> Utf8 Class Initialized
INFO - 2023-11-17 05:27:13 --> URI Class Initialized
INFO - 2023-11-17 05:27:13 --> Router Class Initialized
INFO - 2023-11-17 05:27:13 --> Output Class Initialized
INFO - 2023-11-17 05:27:13 --> Security Class Initialized
DEBUG - 2023-11-17 05:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:27:13 --> Input Class Initialized
INFO - 2023-11-17 05:27:13 --> Language Class Initialized
INFO - 2023-11-17 05:27:13 --> Loader Class Initialized
INFO - 2023-11-17 05:27:13 --> Helper loaded: url_helper
INFO - 2023-11-17 05:27:13 --> Helper loaded: file_helper
INFO - 2023-11-17 05:27:13 --> Helper loaded: html_helper
INFO - 2023-11-17 05:27:13 --> Helper loaded: text_helper
INFO - 2023-11-17 05:27:13 --> Helper loaded: form_helper
INFO - 2023-11-17 05:27:13 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:27:13 --> Helper loaded: security_helper
INFO - 2023-11-17 05:27:13 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:27:13 --> Database Driver Class Initialized
INFO - 2023-11-17 05:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:27:13 --> Parser Class Initialized
INFO - 2023-11-17 05:27:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:27:13 --> Pagination Class Initialized
INFO - 2023-11-17 05:27:13 --> Form Validation Class Initialized
INFO - 2023-11-17 05:27:13 --> Controller Class Initialized
INFO - 2023-11-17 05:27:13 --> Model Class Initialized
INFO - 2023-11-17 05:27:13 --> Model Class Initialized
INFO - 2023-11-17 05:27:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase.php
DEBUG - 2023-11-17 05:27:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:27:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 05:27:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 05:27:13 --> Model Class Initialized
INFO - 2023-11-17 05:27:13 --> Model Class Initialized
INFO - 2023-11-17 05:27:13 --> Model Class Initialized
INFO - 2023-11-17 05:27:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 05:27:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 05:27:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 05:27:13 --> Final output sent to browser
DEBUG - 2023-11-17 05:27:13 --> Total execution time: 0.1911
ERROR - 2023-11-17 05:27:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:27:14 --> Config Class Initialized
INFO - 2023-11-17 05:27:14 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:27:14 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:27:14 --> Utf8 Class Initialized
INFO - 2023-11-17 05:27:14 --> URI Class Initialized
INFO - 2023-11-17 05:27:14 --> Router Class Initialized
INFO - 2023-11-17 05:27:14 --> Output Class Initialized
INFO - 2023-11-17 05:27:14 --> Security Class Initialized
DEBUG - 2023-11-17 05:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:27:14 --> Input Class Initialized
INFO - 2023-11-17 05:27:14 --> Language Class Initialized
INFO - 2023-11-17 05:27:14 --> Loader Class Initialized
INFO - 2023-11-17 05:27:14 --> Helper loaded: url_helper
INFO - 2023-11-17 05:27:14 --> Helper loaded: file_helper
INFO - 2023-11-17 05:27:14 --> Helper loaded: html_helper
INFO - 2023-11-17 05:27:14 --> Helper loaded: text_helper
INFO - 2023-11-17 05:27:14 --> Helper loaded: form_helper
INFO - 2023-11-17 05:27:14 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:27:14 --> Helper loaded: security_helper
INFO - 2023-11-17 05:27:14 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:27:14 --> Database Driver Class Initialized
INFO - 2023-11-17 05:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:27:14 --> Parser Class Initialized
INFO - 2023-11-17 05:27:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:27:14 --> Pagination Class Initialized
INFO - 2023-11-17 05:27:14 --> Form Validation Class Initialized
INFO - 2023-11-17 05:27:14 --> Controller Class Initialized
INFO - 2023-11-17 05:27:14 --> Model Class Initialized
INFO - 2023-11-17 05:27:14 --> Model Class Initialized
INFO - 2023-11-17 05:27:14 --> Final output sent to browser
DEBUG - 2023-11-17 05:27:14 --> Total execution time: 0.0448
ERROR - 2023-11-17 05:27:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:27:18 --> Config Class Initialized
INFO - 2023-11-17 05:27:18 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:27:18 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:27:18 --> Utf8 Class Initialized
INFO - 2023-11-17 05:27:18 --> URI Class Initialized
INFO - 2023-11-17 05:27:18 --> Router Class Initialized
INFO - 2023-11-17 05:27:18 --> Output Class Initialized
INFO - 2023-11-17 05:27:18 --> Security Class Initialized
DEBUG - 2023-11-17 05:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:27:18 --> Input Class Initialized
INFO - 2023-11-17 05:27:18 --> Language Class Initialized
INFO - 2023-11-17 05:27:18 --> Loader Class Initialized
INFO - 2023-11-17 05:27:18 --> Helper loaded: url_helper
INFO - 2023-11-17 05:27:18 --> Helper loaded: file_helper
INFO - 2023-11-17 05:27:18 --> Helper loaded: html_helper
INFO - 2023-11-17 05:27:18 --> Helper loaded: text_helper
INFO - 2023-11-17 05:27:18 --> Helper loaded: form_helper
INFO - 2023-11-17 05:27:18 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:27:18 --> Helper loaded: security_helper
INFO - 2023-11-17 05:27:18 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:27:18 --> Database Driver Class Initialized
INFO - 2023-11-17 05:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:27:18 --> Parser Class Initialized
INFO - 2023-11-17 05:27:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:27:18 --> Pagination Class Initialized
INFO - 2023-11-17 05:27:18 --> Form Validation Class Initialized
INFO - 2023-11-17 05:27:18 --> Controller Class Initialized
INFO - 2023-11-17 05:27:18 --> Model Class Initialized
INFO - 2023-11-17 05:27:18 --> Model Class Initialized
INFO - 2023-11-17 05:27:18 --> Final output sent to browser
DEBUG - 2023-11-17 05:27:18 --> Total execution time: 0.0726
ERROR - 2023-11-17 05:27:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:27:24 --> Config Class Initialized
INFO - 2023-11-17 05:27:24 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:27:24 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:27:24 --> Utf8 Class Initialized
INFO - 2023-11-17 05:27:24 --> URI Class Initialized
INFO - 2023-11-17 05:27:24 --> Router Class Initialized
INFO - 2023-11-17 05:27:24 --> Output Class Initialized
INFO - 2023-11-17 05:27:24 --> Security Class Initialized
DEBUG - 2023-11-17 05:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:27:24 --> Input Class Initialized
INFO - 2023-11-17 05:27:24 --> Language Class Initialized
INFO - 2023-11-17 05:27:24 --> Loader Class Initialized
INFO - 2023-11-17 05:27:24 --> Helper loaded: url_helper
INFO - 2023-11-17 05:27:24 --> Helper loaded: file_helper
INFO - 2023-11-17 05:27:24 --> Helper loaded: html_helper
INFO - 2023-11-17 05:27:24 --> Helper loaded: text_helper
INFO - 2023-11-17 05:27:24 --> Helper loaded: form_helper
INFO - 2023-11-17 05:27:24 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:27:24 --> Helper loaded: security_helper
INFO - 2023-11-17 05:27:24 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:27:24 --> Database Driver Class Initialized
INFO - 2023-11-17 05:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:27:24 --> Parser Class Initialized
INFO - 2023-11-17 05:27:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:27:24 --> Pagination Class Initialized
INFO - 2023-11-17 05:27:24 --> Form Validation Class Initialized
INFO - 2023-11-17 05:27:24 --> Controller Class Initialized
INFO - 2023-11-17 05:27:24 --> Model Class Initialized
INFO - 2023-11-17 05:27:24 --> Model Class Initialized
INFO - 2023-11-17 05:27:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase_html.php
DEBUG - 2023-11-17 05:27:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:27:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 05:27:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 05:27:24 --> Model Class Initialized
INFO - 2023-11-17 05:27:24 --> Model Class Initialized
INFO - 2023-11-17 05:27:24 --> Model Class Initialized
INFO - 2023-11-17 05:27:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 05:27:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 05:27:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 05:27:24 --> Final output sent to browser
DEBUG - 2023-11-17 05:27:24 --> Total execution time: 0.1965
ERROR - 2023-11-17 05:29:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:29:03 --> Config Class Initialized
INFO - 2023-11-17 05:29:03 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:29:03 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:29:03 --> Utf8 Class Initialized
INFO - 2023-11-17 05:29:03 --> URI Class Initialized
DEBUG - 2023-11-17 05:29:03 --> No URI present. Default controller set.
INFO - 2023-11-17 05:29:03 --> Router Class Initialized
INFO - 2023-11-17 05:29:03 --> Output Class Initialized
INFO - 2023-11-17 05:29:03 --> Security Class Initialized
DEBUG - 2023-11-17 05:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:29:03 --> Input Class Initialized
INFO - 2023-11-17 05:29:03 --> Language Class Initialized
INFO - 2023-11-17 05:29:03 --> Loader Class Initialized
INFO - 2023-11-17 05:29:03 --> Helper loaded: url_helper
INFO - 2023-11-17 05:29:03 --> Helper loaded: file_helper
INFO - 2023-11-17 05:29:03 --> Helper loaded: html_helper
INFO - 2023-11-17 05:29:03 --> Helper loaded: text_helper
INFO - 2023-11-17 05:29:03 --> Helper loaded: form_helper
INFO - 2023-11-17 05:29:03 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:29:03 --> Helper loaded: security_helper
INFO - 2023-11-17 05:29:03 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:29:03 --> Database Driver Class Initialized
INFO - 2023-11-17 05:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:29:03 --> Parser Class Initialized
INFO - 2023-11-17 05:29:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:29:03 --> Pagination Class Initialized
INFO - 2023-11-17 05:29:03 --> Form Validation Class Initialized
INFO - 2023-11-17 05:29:03 --> Controller Class Initialized
INFO - 2023-11-17 05:29:03 --> Model Class Initialized
DEBUG - 2023-11-17 05:29:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:29:03 --> Model Class Initialized
DEBUG - 2023-11-17 05:29:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:29:03 --> Model Class Initialized
INFO - 2023-11-17 05:29:03 --> Model Class Initialized
INFO - 2023-11-17 05:29:03 --> Model Class Initialized
INFO - 2023-11-17 05:29:03 --> Model Class Initialized
DEBUG - 2023-11-17 05:29:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:29:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:29:03 --> Model Class Initialized
INFO - 2023-11-17 05:29:03 --> Model Class Initialized
INFO - 2023-11-17 05:29:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-17 05:29:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:29:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 05:29:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 05:29:03 --> Model Class Initialized
INFO - 2023-11-17 05:29:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 05:29:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 05:29:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 05:29:03 --> Final output sent to browser
DEBUG - 2023-11-17 05:29:03 --> Total execution time: 0.3612
ERROR - 2023-11-17 05:29:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:29:23 --> Config Class Initialized
INFO - 2023-11-17 05:29:23 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:29:23 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:29:23 --> Utf8 Class Initialized
INFO - 2023-11-17 05:29:23 --> URI Class Initialized
INFO - 2023-11-17 05:29:23 --> Router Class Initialized
INFO - 2023-11-17 05:29:23 --> Output Class Initialized
INFO - 2023-11-17 05:29:23 --> Security Class Initialized
DEBUG - 2023-11-17 05:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:29:23 --> Input Class Initialized
INFO - 2023-11-17 05:29:23 --> Language Class Initialized
INFO - 2023-11-17 05:29:23 --> Loader Class Initialized
INFO - 2023-11-17 05:29:23 --> Helper loaded: url_helper
INFO - 2023-11-17 05:29:23 --> Helper loaded: file_helper
INFO - 2023-11-17 05:29:23 --> Helper loaded: html_helper
INFO - 2023-11-17 05:29:23 --> Helper loaded: text_helper
INFO - 2023-11-17 05:29:23 --> Helper loaded: form_helper
INFO - 2023-11-17 05:29:23 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:29:23 --> Helper loaded: security_helper
INFO - 2023-11-17 05:29:23 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:29:23 --> Database Driver Class Initialized
INFO - 2023-11-17 05:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:29:23 --> Parser Class Initialized
INFO - 2023-11-17 05:29:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:29:23 --> Pagination Class Initialized
INFO - 2023-11-17 05:29:23 --> Form Validation Class Initialized
INFO - 2023-11-17 05:29:23 --> Controller Class Initialized
INFO - 2023-11-17 05:29:23 --> Model Class Initialized
DEBUG - 2023-11-17 05:29:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:29:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:29:23 --> Model Class Initialized
DEBUG - 2023-11-17 05:29:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:29:23 --> Model Class Initialized
INFO - 2023-11-17 05:29:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-11-17 05:29:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:29:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 05:29:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 05:29:23 --> Model Class Initialized
INFO - 2023-11-17 05:29:23 --> Model Class Initialized
INFO - 2023-11-17 05:29:23 --> Model Class Initialized
INFO - 2023-11-17 05:29:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 05:29:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 05:29:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 05:29:23 --> Final output sent to browser
DEBUG - 2023-11-17 05:29:23 --> Total execution time: 0.2081
ERROR - 2023-11-17 05:29:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:29:23 --> Config Class Initialized
INFO - 2023-11-17 05:29:23 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:29:23 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:29:23 --> Utf8 Class Initialized
INFO - 2023-11-17 05:29:23 --> URI Class Initialized
INFO - 2023-11-17 05:29:23 --> Router Class Initialized
INFO - 2023-11-17 05:29:23 --> Output Class Initialized
INFO - 2023-11-17 05:29:23 --> Security Class Initialized
DEBUG - 2023-11-17 05:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:29:23 --> Input Class Initialized
INFO - 2023-11-17 05:29:23 --> Language Class Initialized
INFO - 2023-11-17 05:29:23 --> Loader Class Initialized
INFO - 2023-11-17 05:29:23 --> Helper loaded: url_helper
INFO - 2023-11-17 05:29:23 --> Helper loaded: file_helper
INFO - 2023-11-17 05:29:23 --> Helper loaded: html_helper
INFO - 2023-11-17 05:29:23 --> Helper loaded: text_helper
INFO - 2023-11-17 05:29:23 --> Helper loaded: form_helper
INFO - 2023-11-17 05:29:23 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:29:23 --> Helper loaded: security_helper
INFO - 2023-11-17 05:29:23 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:29:23 --> Database Driver Class Initialized
INFO - 2023-11-17 05:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:29:23 --> Parser Class Initialized
INFO - 2023-11-17 05:29:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:29:23 --> Pagination Class Initialized
INFO - 2023-11-17 05:29:23 --> Form Validation Class Initialized
INFO - 2023-11-17 05:29:23 --> Controller Class Initialized
INFO - 2023-11-17 05:29:23 --> Model Class Initialized
DEBUG - 2023-11-17 05:29:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:29:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:29:23 --> Model Class Initialized
DEBUG - 2023-11-17 05:29:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:29:23 --> Model Class Initialized
INFO - 2023-11-17 05:29:23 --> Final output sent to browser
DEBUG - 2023-11-17 05:29:23 --> Total execution time: 0.0631
ERROR - 2023-11-17 05:29:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:29:33 --> Config Class Initialized
INFO - 2023-11-17 05:29:33 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:29:33 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:29:33 --> Utf8 Class Initialized
INFO - 2023-11-17 05:29:33 --> URI Class Initialized
INFO - 2023-11-17 05:29:33 --> Router Class Initialized
INFO - 2023-11-17 05:29:33 --> Output Class Initialized
INFO - 2023-11-17 05:29:33 --> Security Class Initialized
DEBUG - 2023-11-17 05:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:29:33 --> Input Class Initialized
INFO - 2023-11-17 05:29:33 --> Language Class Initialized
INFO - 2023-11-17 05:29:33 --> Loader Class Initialized
INFO - 2023-11-17 05:29:33 --> Helper loaded: url_helper
INFO - 2023-11-17 05:29:33 --> Helper loaded: file_helper
INFO - 2023-11-17 05:29:33 --> Helper loaded: html_helper
INFO - 2023-11-17 05:29:33 --> Helper loaded: text_helper
INFO - 2023-11-17 05:29:33 --> Helper loaded: form_helper
INFO - 2023-11-17 05:29:33 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:29:33 --> Helper loaded: security_helper
INFO - 2023-11-17 05:29:33 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:29:33 --> Database Driver Class Initialized
INFO - 2023-11-17 05:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:29:33 --> Parser Class Initialized
INFO - 2023-11-17 05:29:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:29:33 --> Pagination Class Initialized
INFO - 2023-11-17 05:29:33 --> Form Validation Class Initialized
INFO - 2023-11-17 05:29:33 --> Controller Class Initialized
INFO - 2023-11-17 05:29:33 --> Model Class Initialized
DEBUG - 2023-11-17 05:29:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:29:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:29:33 --> Model Class Initialized
DEBUG - 2023-11-17 05:29:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:29:33 --> Model Class Initialized
INFO - 2023-11-17 05:29:34 --> Final output sent to browser
DEBUG - 2023-11-17 05:29:34 --> Total execution time: 0.9535
ERROR - 2023-11-17 05:29:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:29:58 --> Config Class Initialized
INFO - 2023-11-17 05:29:58 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:29:58 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:29:58 --> Utf8 Class Initialized
INFO - 2023-11-17 05:29:58 --> URI Class Initialized
DEBUG - 2023-11-17 05:29:58 --> No URI present. Default controller set.
INFO - 2023-11-17 05:29:58 --> Router Class Initialized
INFO - 2023-11-17 05:29:58 --> Output Class Initialized
INFO - 2023-11-17 05:29:58 --> Security Class Initialized
DEBUG - 2023-11-17 05:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:29:58 --> Input Class Initialized
INFO - 2023-11-17 05:29:58 --> Language Class Initialized
INFO - 2023-11-17 05:29:58 --> Loader Class Initialized
INFO - 2023-11-17 05:29:58 --> Helper loaded: url_helper
INFO - 2023-11-17 05:29:58 --> Helper loaded: file_helper
INFO - 2023-11-17 05:29:58 --> Helper loaded: html_helper
INFO - 2023-11-17 05:29:58 --> Helper loaded: text_helper
INFO - 2023-11-17 05:29:58 --> Helper loaded: form_helper
INFO - 2023-11-17 05:29:58 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:29:58 --> Helper loaded: security_helper
INFO - 2023-11-17 05:29:58 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:29:58 --> Database Driver Class Initialized
INFO - 2023-11-17 05:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:29:58 --> Parser Class Initialized
INFO - 2023-11-17 05:29:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:29:58 --> Pagination Class Initialized
INFO - 2023-11-17 05:29:58 --> Form Validation Class Initialized
INFO - 2023-11-17 05:29:58 --> Controller Class Initialized
INFO - 2023-11-17 05:29:58 --> Model Class Initialized
DEBUG - 2023-11-17 05:29:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:29:58 --> Model Class Initialized
DEBUG - 2023-11-17 05:29:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:29:58 --> Model Class Initialized
INFO - 2023-11-17 05:29:58 --> Model Class Initialized
INFO - 2023-11-17 05:29:58 --> Model Class Initialized
INFO - 2023-11-17 05:29:58 --> Model Class Initialized
DEBUG - 2023-11-17 05:29:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:29:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:29:58 --> Model Class Initialized
INFO - 2023-11-17 05:29:58 --> Model Class Initialized
INFO - 2023-11-17 05:29:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-17 05:29:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:29:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 05:29:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 05:29:58 --> Model Class Initialized
INFO - 2023-11-17 05:29:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 05:29:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 05:29:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 05:29:58 --> Final output sent to browser
DEBUG - 2023-11-17 05:29:58 --> Total execution time: 0.3723
ERROR - 2023-11-17 05:30:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:30:13 --> Config Class Initialized
INFO - 2023-11-17 05:30:13 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:30:13 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:30:13 --> Utf8 Class Initialized
INFO - 2023-11-17 05:30:13 --> URI Class Initialized
DEBUG - 2023-11-17 05:30:13 --> No URI present. Default controller set.
INFO - 2023-11-17 05:30:13 --> Router Class Initialized
INFO - 2023-11-17 05:30:13 --> Output Class Initialized
INFO - 2023-11-17 05:30:13 --> Security Class Initialized
DEBUG - 2023-11-17 05:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:30:13 --> Input Class Initialized
INFO - 2023-11-17 05:30:13 --> Language Class Initialized
INFO - 2023-11-17 05:30:13 --> Loader Class Initialized
INFO - 2023-11-17 05:30:13 --> Helper loaded: url_helper
INFO - 2023-11-17 05:30:13 --> Helper loaded: file_helper
INFO - 2023-11-17 05:30:13 --> Helper loaded: html_helper
INFO - 2023-11-17 05:30:13 --> Helper loaded: text_helper
INFO - 2023-11-17 05:30:13 --> Helper loaded: form_helper
INFO - 2023-11-17 05:30:13 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:30:13 --> Helper loaded: security_helper
INFO - 2023-11-17 05:30:13 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:30:13 --> Database Driver Class Initialized
INFO - 2023-11-17 05:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:30:13 --> Parser Class Initialized
INFO - 2023-11-17 05:30:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:30:13 --> Pagination Class Initialized
INFO - 2023-11-17 05:30:13 --> Form Validation Class Initialized
INFO - 2023-11-17 05:30:13 --> Controller Class Initialized
INFO - 2023-11-17 05:30:13 --> Model Class Initialized
DEBUG - 2023-11-17 05:30:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:30:13 --> Model Class Initialized
DEBUG - 2023-11-17 05:30:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:30:13 --> Model Class Initialized
INFO - 2023-11-17 05:30:13 --> Model Class Initialized
INFO - 2023-11-17 05:30:13 --> Model Class Initialized
INFO - 2023-11-17 05:30:13 --> Model Class Initialized
DEBUG - 2023-11-17 05:30:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:30:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:30:13 --> Model Class Initialized
INFO - 2023-11-17 05:30:13 --> Model Class Initialized
INFO - 2023-11-17 05:30:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-17 05:30:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:30:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 05:30:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 05:30:13 --> Model Class Initialized
INFO - 2023-11-17 05:30:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 05:30:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 05:30:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 05:30:13 --> Final output sent to browser
DEBUG - 2023-11-17 05:30:13 --> Total execution time: 0.2120
ERROR - 2023-11-17 05:45:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:45:03 --> Config Class Initialized
INFO - 2023-11-17 05:45:03 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:45:03 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:45:03 --> Utf8 Class Initialized
INFO - 2023-11-17 05:45:03 --> URI Class Initialized
INFO - 2023-11-17 05:45:03 --> Router Class Initialized
INFO - 2023-11-17 05:45:03 --> Output Class Initialized
INFO - 2023-11-17 05:45:03 --> Security Class Initialized
DEBUG - 2023-11-17 05:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:45:03 --> Input Class Initialized
INFO - 2023-11-17 05:45:03 --> Language Class Initialized
INFO - 2023-11-17 05:45:03 --> Loader Class Initialized
INFO - 2023-11-17 05:45:03 --> Helper loaded: url_helper
INFO - 2023-11-17 05:45:03 --> Helper loaded: file_helper
INFO - 2023-11-17 05:45:03 --> Helper loaded: html_helper
INFO - 2023-11-17 05:45:03 --> Helper loaded: text_helper
INFO - 2023-11-17 05:45:03 --> Helper loaded: form_helper
INFO - 2023-11-17 05:45:03 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:45:03 --> Helper loaded: security_helper
INFO - 2023-11-17 05:45:03 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:45:03 --> Database Driver Class Initialized
INFO - 2023-11-17 05:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:45:03 --> Parser Class Initialized
INFO - 2023-11-17 05:45:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:45:03 --> Pagination Class Initialized
INFO - 2023-11-17 05:45:03 --> Form Validation Class Initialized
INFO - 2023-11-17 05:45:03 --> Controller Class Initialized
INFO - 2023-11-17 05:45:03 --> Model Class Initialized
DEBUG - 2023-11-17 05:45:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:45:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:45:03 --> Model Class Initialized
INFO - 2023-11-17 05:45:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-11-17 05:45:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:45:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 05:45:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 05:45:03 --> Model Class Initialized
INFO - 2023-11-17 05:45:03 --> Model Class Initialized
INFO - 2023-11-17 05:45:03 --> Model Class Initialized
INFO - 2023-11-17 05:45:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 05:45:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 05:45:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 05:45:03 --> Final output sent to browser
DEBUG - 2023-11-17 05:45:03 --> Total execution time: 0.1283
ERROR - 2023-11-17 05:45:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:45:04 --> Config Class Initialized
INFO - 2023-11-17 05:45:04 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:45:04 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:45:04 --> Utf8 Class Initialized
INFO - 2023-11-17 05:45:04 --> URI Class Initialized
INFO - 2023-11-17 05:45:04 --> Router Class Initialized
INFO - 2023-11-17 05:45:04 --> Output Class Initialized
INFO - 2023-11-17 05:45:04 --> Security Class Initialized
DEBUG - 2023-11-17 05:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:45:04 --> Input Class Initialized
INFO - 2023-11-17 05:45:04 --> Language Class Initialized
INFO - 2023-11-17 05:45:04 --> Loader Class Initialized
INFO - 2023-11-17 05:45:04 --> Helper loaded: url_helper
INFO - 2023-11-17 05:45:04 --> Helper loaded: file_helper
INFO - 2023-11-17 05:45:04 --> Helper loaded: html_helper
INFO - 2023-11-17 05:45:04 --> Helper loaded: text_helper
INFO - 2023-11-17 05:45:04 --> Helper loaded: form_helper
INFO - 2023-11-17 05:45:04 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:45:04 --> Helper loaded: security_helper
INFO - 2023-11-17 05:45:04 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:45:04 --> Database Driver Class Initialized
INFO - 2023-11-17 05:45:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:45:04 --> Parser Class Initialized
INFO - 2023-11-17 05:45:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:45:04 --> Pagination Class Initialized
INFO - 2023-11-17 05:45:04 --> Form Validation Class Initialized
INFO - 2023-11-17 05:45:04 --> Controller Class Initialized
INFO - 2023-11-17 05:45:04 --> Model Class Initialized
DEBUG - 2023-11-17 05:45:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:45:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:45:04 --> Model Class Initialized
INFO - 2023-11-17 05:45:04 --> Final output sent to browser
DEBUG - 2023-11-17 05:45:04 --> Total execution time: 0.0737
ERROR - 2023-11-17 05:45:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:45:13 --> Config Class Initialized
INFO - 2023-11-17 05:45:13 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:45:13 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:45:13 --> Utf8 Class Initialized
INFO - 2023-11-17 05:45:13 --> URI Class Initialized
INFO - 2023-11-17 05:45:13 --> Router Class Initialized
INFO - 2023-11-17 05:45:13 --> Output Class Initialized
INFO - 2023-11-17 05:45:13 --> Security Class Initialized
DEBUG - 2023-11-17 05:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:45:13 --> Input Class Initialized
INFO - 2023-11-17 05:45:13 --> Language Class Initialized
INFO - 2023-11-17 05:45:13 --> Loader Class Initialized
INFO - 2023-11-17 05:45:13 --> Helper loaded: url_helper
INFO - 2023-11-17 05:45:13 --> Helper loaded: file_helper
INFO - 2023-11-17 05:45:13 --> Helper loaded: html_helper
INFO - 2023-11-17 05:45:13 --> Helper loaded: text_helper
INFO - 2023-11-17 05:45:13 --> Helper loaded: form_helper
INFO - 2023-11-17 05:45:13 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:45:13 --> Helper loaded: security_helper
INFO - 2023-11-17 05:45:13 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:45:13 --> Database Driver Class Initialized
INFO - 2023-11-17 05:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:45:13 --> Parser Class Initialized
INFO - 2023-11-17 05:45:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:45:13 --> Pagination Class Initialized
INFO - 2023-11-17 05:45:13 --> Form Validation Class Initialized
INFO - 2023-11-17 05:45:13 --> Controller Class Initialized
INFO - 2023-11-17 05:45:13 --> Model Class Initialized
DEBUG - 2023-11-17 05:45:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:45:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:45:13 --> Model Class Initialized
INFO - 2023-11-17 05:45:13 --> Final output sent to browser
DEBUG - 2023-11-17 05:45:13 --> Total execution time: 0.0722
ERROR - 2023-11-17 05:45:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:45:18 --> Config Class Initialized
INFO - 2023-11-17 05:45:18 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:45:18 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:45:18 --> Utf8 Class Initialized
INFO - 2023-11-17 05:45:18 --> URI Class Initialized
DEBUG - 2023-11-17 05:45:18 --> No URI present. Default controller set.
INFO - 2023-11-17 05:45:18 --> Router Class Initialized
INFO - 2023-11-17 05:45:18 --> Output Class Initialized
INFO - 2023-11-17 05:45:18 --> Security Class Initialized
DEBUG - 2023-11-17 05:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:45:18 --> Input Class Initialized
INFO - 2023-11-17 05:45:18 --> Language Class Initialized
INFO - 2023-11-17 05:45:18 --> Loader Class Initialized
INFO - 2023-11-17 05:45:18 --> Helper loaded: url_helper
INFO - 2023-11-17 05:45:18 --> Helper loaded: file_helper
INFO - 2023-11-17 05:45:18 --> Helper loaded: html_helper
INFO - 2023-11-17 05:45:18 --> Helper loaded: text_helper
INFO - 2023-11-17 05:45:18 --> Helper loaded: form_helper
INFO - 2023-11-17 05:45:18 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:45:18 --> Helper loaded: security_helper
INFO - 2023-11-17 05:45:18 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:45:18 --> Database Driver Class Initialized
INFO - 2023-11-17 05:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:45:18 --> Parser Class Initialized
INFO - 2023-11-17 05:45:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:45:18 --> Pagination Class Initialized
INFO - 2023-11-17 05:45:18 --> Form Validation Class Initialized
INFO - 2023-11-17 05:45:18 --> Controller Class Initialized
INFO - 2023-11-17 05:45:18 --> Model Class Initialized
DEBUG - 2023-11-17 05:45:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:45:18 --> Model Class Initialized
DEBUG - 2023-11-17 05:45:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:45:18 --> Model Class Initialized
INFO - 2023-11-17 05:45:18 --> Model Class Initialized
INFO - 2023-11-17 05:45:18 --> Model Class Initialized
INFO - 2023-11-17 05:45:18 --> Model Class Initialized
DEBUG - 2023-11-17 05:45:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:45:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:45:18 --> Model Class Initialized
INFO - 2023-11-17 05:45:18 --> Model Class Initialized
INFO - 2023-11-17 05:45:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-17 05:45:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:45:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 05:45:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 05:45:19 --> Model Class Initialized
INFO - 2023-11-17 05:45:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 05:45:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 05:45:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 05:45:19 --> Final output sent to browser
DEBUG - 2023-11-17 05:45:19 --> Total execution time: 0.2065
ERROR - 2023-11-17 05:45:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:45:48 --> Config Class Initialized
INFO - 2023-11-17 05:45:48 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:45:48 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:45:48 --> Utf8 Class Initialized
INFO - 2023-11-17 05:45:48 --> URI Class Initialized
INFO - 2023-11-17 05:45:48 --> Router Class Initialized
INFO - 2023-11-17 05:45:48 --> Output Class Initialized
INFO - 2023-11-17 05:45:48 --> Security Class Initialized
DEBUG - 2023-11-17 05:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:45:48 --> Input Class Initialized
INFO - 2023-11-17 05:45:48 --> Language Class Initialized
INFO - 2023-11-17 05:45:48 --> Loader Class Initialized
INFO - 2023-11-17 05:45:48 --> Helper loaded: url_helper
INFO - 2023-11-17 05:45:48 --> Helper loaded: file_helper
INFO - 2023-11-17 05:45:48 --> Helper loaded: html_helper
INFO - 2023-11-17 05:45:48 --> Helper loaded: text_helper
INFO - 2023-11-17 05:45:48 --> Helper loaded: form_helper
INFO - 2023-11-17 05:45:48 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:45:48 --> Helper loaded: security_helper
INFO - 2023-11-17 05:45:48 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:45:48 --> Database Driver Class Initialized
INFO - 2023-11-17 05:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:45:48 --> Parser Class Initialized
INFO - 2023-11-17 05:45:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:45:48 --> Pagination Class Initialized
INFO - 2023-11-17 05:45:48 --> Form Validation Class Initialized
INFO - 2023-11-17 05:45:48 --> Controller Class Initialized
INFO - 2023-11-17 05:45:48 --> Model Class Initialized
DEBUG - 2023-11-17 05:45:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:45:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:45:48 --> Model Class Initialized
DEBUG - 2023-11-17 05:45:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:45:48 --> Model Class Initialized
INFO - 2023-11-17 05:45:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-11-17 05:45:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:45:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 05:45:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 05:45:48 --> Model Class Initialized
INFO - 2023-11-17 05:45:48 --> Model Class Initialized
INFO - 2023-11-17 05:45:48 --> Model Class Initialized
INFO - 2023-11-17 05:45:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 05:45:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 05:45:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 05:45:48 --> Final output sent to browser
DEBUG - 2023-11-17 05:45:48 --> Total execution time: 0.2281
ERROR - 2023-11-17 05:45:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:45:49 --> Config Class Initialized
INFO - 2023-11-17 05:45:49 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:45:49 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:45:49 --> Utf8 Class Initialized
INFO - 2023-11-17 05:45:49 --> URI Class Initialized
INFO - 2023-11-17 05:45:49 --> Router Class Initialized
INFO - 2023-11-17 05:45:49 --> Output Class Initialized
INFO - 2023-11-17 05:45:49 --> Security Class Initialized
DEBUG - 2023-11-17 05:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:45:49 --> Input Class Initialized
INFO - 2023-11-17 05:45:49 --> Language Class Initialized
INFO - 2023-11-17 05:45:49 --> Loader Class Initialized
INFO - 2023-11-17 05:45:49 --> Helper loaded: url_helper
INFO - 2023-11-17 05:45:49 --> Helper loaded: file_helper
INFO - 2023-11-17 05:45:49 --> Helper loaded: html_helper
INFO - 2023-11-17 05:45:49 --> Helper loaded: text_helper
INFO - 2023-11-17 05:45:49 --> Helper loaded: form_helper
INFO - 2023-11-17 05:45:49 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:45:49 --> Helper loaded: security_helper
INFO - 2023-11-17 05:45:49 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:45:49 --> Database Driver Class Initialized
INFO - 2023-11-17 05:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:45:49 --> Parser Class Initialized
INFO - 2023-11-17 05:45:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:45:49 --> Pagination Class Initialized
INFO - 2023-11-17 05:45:49 --> Form Validation Class Initialized
INFO - 2023-11-17 05:45:49 --> Controller Class Initialized
INFO - 2023-11-17 05:45:49 --> Model Class Initialized
DEBUG - 2023-11-17 05:45:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:45:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:45:49 --> Model Class Initialized
DEBUG - 2023-11-17 05:45:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:45:49 --> Model Class Initialized
INFO - 2023-11-17 05:45:49 --> Final output sent to browser
DEBUG - 2023-11-17 05:45:49 --> Total execution time: 0.0627
ERROR - 2023-11-17 05:46:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:46:04 --> Config Class Initialized
INFO - 2023-11-17 05:46:04 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:46:04 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:46:04 --> Utf8 Class Initialized
INFO - 2023-11-17 05:46:04 --> URI Class Initialized
INFO - 2023-11-17 05:46:04 --> Router Class Initialized
INFO - 2023-11-17 05:46:04 --> Output Class Initialized
INFO - 2023-11-17 05:46:04 --> Security Class Initialized
DEBUG - 2023-11-17 05:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:46:04 --> Input Class Initialized
INFO - 2023-11-17 05:46:04 --> Language Class Initialized
INFO - 2023-11-17 05:46:04 --> Loader Class Initialized
INFO - 2023-11-17 05:46:04 --> Helper loaded: url_helper
INFO - 2023-11-17 05:46:04 --> Helper loaded: file_helper
INFO - 2023-11-17 05:46:04 --> Helper loaded: html_helper
INFO - 2023-11-17 05:46:04 --> Helper loaded: text_helper
INFO - 2023-11-17 05:46:04 --> Helper loaded: form_helper
INFO - 2023-11-17 05:46:04 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:46:04 --> Helper loaded: security_helper
INFO - 2023-11-17 05:46:04 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:46:04 --> Database Driver Class Initialized
INFO - 2023-11-17 05:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:46:04 --> Parser Class Initialized
INFO - 2023-11-17 05:46:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:46:04 --> Pagination Class Initialized
INFO - 2023-11-17 05:46:04 --> Form Validation Class Initialized
INFO - 2023-11-17 05:46:04 --> Controller Class Initialized
INFO - 2023-11-17 05:46:04 --> Model Class Initialized
DEBUG - 2023-11-17 05:46:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:46:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:46:04 --> Model Class Initialized
DEBUG - 2023-11-17 05:46:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:46:04 --> Model Class Initialized
INFO - 2023-11-17 05:46:04 --> Final output sent to browser
DEBUG - 2023-11-17 05:46:04 --> Total execution time: 0.0607
ERROR - 2023-11-17 05:46:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:46:10 --> Config Class Initialized
INFO - 2023-11-17 05:46:10 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:46:10 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:46:10 --> Utf8 Class Initialized
INFO - 2023-11-17 05:46:10 --> URI Class Initialized
INFO - 2023-11-17 05:46:10 --> Router Class Initialized
INFO - 2023-11-17 05:46:10 --> Output Class Initialized
INFO - 2023-11-17 05:46:10 --> Security Class Initialized
DEBUG - 2023-11-17 05:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:46:10 --> Input Class Initialized
INFO - 2023-11-17 05:46:10 --> Language Class Initialized
INFO - 2023-11-17 05:46:10 --> Loader Class Initialized
INFO - 2023-11-17 05:46:10 --> Helper loaded: url_helper
INFO - 2023-11-17 05:46:10 --> Helper loaded: file_helper
INFO - 2023-11-17 05:46:10 --> Helper loaded: html_helper
INFO - 2023-11-17 05:46:10 --> Helper loaded: text_helper
INFO - 2023-11-17 05:46:10 --> Helper loaded: form_helper
INFO - 2023-11-17 05:46:10 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:46:10 --> Helper loaded: security_helper
INFO - 2023-11-17 05:46:10 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:46:10 --> Database Driver Class Initialized
INFO - 2023-11-17 05:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:46:10 --> Parser Class Initialized
INFO - 2023-11-17 05:46:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:46:10 --> Pagination Class Initialized
INFO - 2023-11-17 05:46:10 --> Form Validation Class Initialized
INFO - 2023-11-17 05:46:10 --> Controller Class Initialized
INFO - 2023-11-17 05:46:10 --> Model Class Initialized
DEBUG - 2023-11-17 05:46:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:46:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:46:10 --> Model Class Initialized
DEBUG - 2023-11-17 05:46:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:46:10 --> Model Class Initialized
INFO - 2023-11-17 05:46:10 --> Final output sent to browser
DEBUG - 2023-11-17 05:46:10 --> Total execution time: 0.1501
ERROR - 2023-11-17 05:46:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:46:28 --> Config Class Initialized
INFO - 2023-11-17 05:46:28 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:46:28 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:46:28 --> Utf8 Class Initialized
INFO - 2023-11-17 05:46:28 --> URI Class Initialized
INFO - 2023-11-17 05:46:28 --> Router Class Initialized
INFO - 2023-11-17 05:46:28 --> Output Class Initialized
INFO - 2023-11-17 05:46:28 --> Security Class Initialized
DEBUG - 2023-11-17 05:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:46:28 --> Input Class Initialized
INFO - 2023-11-17 05:46:28 --> Language Class Initialized
INFO - 2023-11-17 05:46:28 --> Loader Class Initialized
INFO - 2023-11-17 05:46:28 --> Helper loaded: url_helper
INFO - 2023-11-17 05:46:28 --> Helper loaded: file_helper
INFO - 2023-11-17 05:46:28 --> Helper loaded: html_helper
INFO - 2023-11-17 05:46:28 --> Helper loaded: text_helper
INFO - 2023-11-17 05:46:28 --> Helper loaded: form_helper
INFO - 2023-11-17 05:46:28 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:46:28 --> Helper loaded: security_helper
INFO - 2023-11-17 05:46:28 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:46:28 --> Database Driver Class Initialized
INFO - 2023-11-17 05:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:46:28 --> Parser Class Initialized
INFO - 2023-11-17 05:46:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:46:28 --> Pagination Class Initialized
INFO - 2023-11-17 05:46:28 --> Form Validation Class Initialized
INFO - 2023-11-17 05:46:28 --> Controller Class Initialized
INFO - 2023-11-17 05:46:28 --> Model Class Initialized
DEBUG - 2023-11-17 05:46:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:46:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:46:28 --> Model Class Initialized
DEBUG - 2023-11-17 05:46:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:46:28 --> Model Class Initialized
INFO - 2023-11-17 05:46:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-11-17 05:46:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:46:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 05:46:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 05:46:28 --> Model Class Initialized
INFO - 2023-11-17 05:46:28 --> Model Class Initialized
INFO - 2023-11-17 05:46:28 --> Model Class Initialized
INFO - 2023-11-17 05:46:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 05:46:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 05:46:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 05:46:28 --> Final output sent to browser
DEBUG - 2023-11-17 05:46:28 --> Total execution time: 0.1433
ERROR - 2023-11-17 05:46:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:46:29 --> Config Class Initialized
INFO - 2023-11-17 05:46:29 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:46:29 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:46:29 --> Utf8 Class Initialized
INFO - 2023-11-17 05:46:29 --> URI Class Initialized
INFO - 2023-11-17 05:46:29 --> Router Class Initialized
INFO - 2023-11-17 05:46:29 --> Output Class Initialized
INFO - 2023-11-17 05:46:29 --> Security Class Initialized
DEBUG - 2023-11-17 05:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:46:29 --> Input Class Initialized
INFO - 2023-11-17 05:46:29 --> Language Class Initialized
INFO - 2023-11-17 05:46:29 --> Loader Class Initialized
INFO - 2023-11-17 05:46:29 --> Helper loaded: url_helper
INFO - 2023-11-17 05:46:29 --> Helper loaded: file_helper
INFO - 2023-11-17 05:46:29 --> Helper loaded: html_helper
INFO - 2023-11-17 05:46:29 --> Helper loaded: text_helper
INFO - 2023-11-17 05:46:29 --> Helper loaded: form_helper
INFO - 2023-11-17 05:46:29 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:46:29 --> Helper loaded: security_helper
INFO - 2023-11-17 05:46:29 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:46:29 --> Database Driver Class Initialized
INFO - 2023-11-17 05:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:46:29 --> Parser Class Initialized
INFO - 2023-11-17 05:46:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:46:29 --> Pagination Class Initialized
INFO - 2023-11-17 05:46:29 --> Form Validation Class Initialized
INFO - 2023-11-17 05:46:29 --> Controller Class Initialized
INFO - 2023-11-17 05:46:29 --> Model Class Initialized
DEBUG - 2023-11-17 05:46:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:46:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:46:29 --> Model Class Initialized
DEBUG - 2023-11-17 05:46:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:46:29 --> Model Class Initialized
INFO - 2023-11-17 05:46:29 --> Final output sent to browser
DEBUG - 2023-11-17 05:46:29 --> Total execution time: 0.0457
ERROR - 2023-11-17 05:46:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:46:44 --> Config Class Initialized
INFO - 2023-11-17 05:46:44 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:46:44 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:46:44 --> Utf8 Class Initialized
INFO - 2023-11-17 05:46:44 --> URI Class Initialized
INFO - 2023-11-17 05:46:44 --> Router Class Initialized
INFO - 2023-11-17 05:46:44 --> Output Class Initialized
INFO - 2023-11-17 05:46:44 --> Security Class Initialized
DEBUG - 2023-11-17 05:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:46:44 --> Input Class Initialized
INFO - 2023-11-17 05:46:44 --> Language Class Initialized
INFO - 2023-11-17 05:46:44 --> Loader Class Initialized
INFO - 2023-11-17 05:46:44 --> Helper loaded: url_helper
INFO - 2023-11-17 05:46:44 --> Helper loaded: file_helper
INFO - 2023-11-17 05:46:44 --> Helper loaded: html_helper
INFO - 2023-11-17 05:46:44 --> Helper loaded: text_helper
INFO - 2023-11-17 05:46:44 --> Helper loaded: form_helper
INFO - 2023-11-17 05:46:44 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:46:44 --> Helper loaded: security_helper
INFO - 2023-11-17 05:46:44 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:46:44 --> Database Driver Class Initialized
INFO - 2023-11-17 05:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:46:44 --> Parser Class Initialized
INFO - 2023-11-17 05:46:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:46:44 --> Pagination Class Initialized
INFO - 2023-11-17 05:46:44 --> Form Validation Class Initialized
INFO - 2023-11-17 05:46:44 --> Controller Class Initialized
INFO - 2023-11-17 05:46:44 --> Model Class Initialized
DEBUG - 2023-11-17 05:46:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:46:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:46:44 --> Model Class Initialized
DEBUG - 2023-11-17 05:46:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:46:44 --> Model Class Initialized
INFO - 2023-11-17 05:46:44 --> Final output sent to browser
DEBUG - 2023-11-17 05:46:44 --> Total execution time: 0.0443
ERROR - 2023-11-17 05:46:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:46:45 --> Config Class Initialized
INFO - 2023-11-17 05:46:45 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:46:45 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:46:45 --> Utf8 Class Initialized
INFO - 2023-11-17 05:46:45 --> URI Class Initialized
INFO - 2023-11-17 05:46:45 --> Router Class Initialized
INFO - 2023-11-17 05:46:45 --> Output Class Initialized
INFO - 2023-11-17 05:46:45 --> Security Class Initialized
DEBUG - 2023-11-17 05:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:46:45 --> Input Class Initialized
INFO - 2023-11-17 05:46:45 --> Language Class Initialized
INFO - 2023-11-17 05:46:45 --> Loader Class Initialized
INFO - 2023-11-17 05:46:45 --> Helper loaded: url_helper
INFO - 2023-11-17 05:46:45 --> Helper loaded: file_helper
INFO - 2023-11-17 05:46:45 --> Helper loaded: html_helper
INFO - 2023-11-17 05:46:45 --> Helper loaded: text_helper
INFO - 2023-11-17 05:46:45 --> Helper loaded: form_helper
INFO - 2023-11-17 05:46:45 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:46:45 --> Helper loaded: security_helper
INFO - 2023-11-17 05:46:45 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:46:45 --> Database Driver Class Initialized
INFO - 2023-11-17 05:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:46:45 --> Parser Class Initialized
INFO - 2023-11-17 05:46:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:46:45 --> Pagination Class Initialized
INFO - 2023-11-17 05:46:45 --> Form Validation Class Initialized
INFO - 2023-11-17 05:46:45 --> Controller Class Initialized
INFO - 2023-11-17 05:46:45 --> Model Class Initialized
DEBUG - 2023-11-17 05:46:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:46:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:46:45 --> Model Class Initialized
DEBUG - 2023-11-17 05:46:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:46:45 --> Model Class Initialized
INFO - 2023-11-17 05:46:45 --> Final output sent to browser
DEBUG - 2023-11-17 05:46:45 --> Total execution time: 0.0422
ERROR - 2023-11-17 05:46:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:46:49 --> Config Class Initialized
INFO - 2023-11-17 05:46:49 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:46:49 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:46:49 --> Utf8 Class Initialized
INFO - 2023-11-17 05:46:49 --> URI Class Initialized
INFO - 2023-11-17 05:46:49 --> Router Class Initialized
INFO - 2023-11-17 05:46:49 --> Output Class Initialized
INFO - 2023-11-17 05:46:49 --> Security Class Initialized
DEBUG - 2023-11-17 05:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:46:49 --> Input Class Initialized
INFO - 2023-11-17 05:46:49 --> Language Class Initialized
INFO - 2023-11-17 05:46:49 --> Loader Class Initialized
INFO - 2023-11-17 05:46:49 --> Helper loaded: url_helper
INFO - 2023-11-17 05:46:49 --> Helper loaded: file_helper
INFO - 2023-11-17 05:46:49 --> Helper loaded: html_helper
INFO - 2023-11-17 05:46:49 --> Helper loaded: text_helper
INFO - 2023-11-17 05:46:49 --> Helper loaded: form_helper
INFO - 2023-11-17 05:46:49 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:46:49 --> Helper loaded: security_helper
INFO - 2023-11-17 05:46:49 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:46:49 --> Database Driver Class Initialized
INFO - 2023-11-17 05:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:46:49 --> Parser Class Initialized
INFO - 2023-11-17 05:46:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:46:49 --> Pagination Class Initialized
INFO - 2023-11-17 05:46:49 --> Form Validation Class Initialized
INFO - 2023-11-17 05:46:49 --> Controller Class Initialized
INFO - 2023-11-17 05:46:49 --> Model Class Initialized
DEBUG - 2023-11-17 05:46:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:46:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:46:49 --> Model Class Initialized
DEBUG - 2023-11-17 05:46:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:46:49 --> Model Class Initialized
INFO - 2023-11-17 05:46:49 --> Final output sent to browser
DEBUG - 2023-11-17 05:46:49 --> Total execution time: 0.0754
ERROR - 2023-11-17 05:47:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:47:48 --> Config Class Initialized
INFO - 2023-11-17 05:47:48 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:47:48 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:47:48 --> Utf8 Class Initialized
INFO - 2023-11-17 05:47:48 --> URI Class Initialized
INFO - 2023-11-17 05:47:48 --> Router Class Initialized
INFO - 2023-11-17 05:47:48 --> Output Class Initialized
INFO - 2023-11-17 05:47:48 --> Security Class Initialized
DEBUG - 2023-11-17 05:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:47:48 --> Input Class Initialized
INFO - 2023-11-17 05:47:48 --> Language Class Initialized
INFO - 2023-11-17 05:47:48 --> Loader Class Initialized
INFO - 2023-11-17 05:47:48 --> Helper loaded: url_helper
INFO - 2023-11-17 05:47:48 --> Helper loaded: file_helper
INFO - 2023-11-17 05:47:48 --> Helper loaded: html_helper
INFO - 2023-11-17 05:47:48 --> Helper loaded: text_helper
INFO - 2023-11-17 05:47:48 --> Helper loaded: form_helper
INFO - 2023-11-17 05:47:48 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:47:48 --> Helper loaded: security_helper
INFO - 2023-11-17 05:47:48 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:47:48 --> Database Driver Class Initialized
INFO - 2023-11-17 05:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:47:48 --> Parser Class Initialized
INFO - 2023-11-17 05:47:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:47:48 --> Pagination Class Initialized
INFO - 2023-11-17 05:47:48 --> Form Validation Class Initialized
INFO - 2023-11-17 05:47:48 --> Controller Class Initialized
INFO - 2023-11-17 05:47:48 --> Model Class Initialized
DEBUG - 2023-11-17 05:47:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:47:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:47:48 --> Model Class Initialized
DEBUG - 2023-11-17 05:47:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:47:48 --> Model Class Initialized
INFO - 2023-11-17 05:47:48 --> Final output sent to browser
DEBUG - 2023-11-17 05:47:48 --> Total execution time: 0.0249
ERROR - 2023-11-17 05:47:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:47:58 --> Config Class Initialized
INFO - 2023-11-17 05:47:58 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:47:58 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:47:58 --> Utf8 Class Initialized
INFO - 2023-11-17 05:47:58 --> URI Class Initialized
DEBUG - 2023-11-17 05:47:58 --> No URI present. Default controller set.
INFO - 2023-11-17 05:47:58 --> Router Class Initialized
INFO - 2023-11-17 05:47:58 --> Output Class Initialized
INFO - 2023-11-17 05:47:58 --> Security Class Initialized
DEBUG - 2023-11-17 05:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:47:58 --> Input Class Initialized
INFO - 2023-11-17 05:47:58 --> Language Class Initialized
INFO - 2023-11-17 05:47:58 --> Loader Class Initialized
INFO - 2023-11-17 05:47:58 --> Helper loaded: url_helper
INFO - 2023-11-17 05:47:58 --> Helper loaded: file_helper
INFO - 2023-11-17 05:47:58 --> Helper loaded: html_helper
INFO - 2023-11-17 05:47:58 --> Helper loaded: text_helper
INFO - 2023-11-17 05:47:58 --> Helper loaded: form_helper
INFO - 2023-11-17 05:47:58 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:47:58 --> Helper loaded: security_helper
INFO - 2023-11-17 05:47:58 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:47:58 --> Database Driver Class Initialized
INFO - 2023-11-17 05:47:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:47:58 --> Parser Class Initialized
INFO - 2023-11-17 05:47:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:47:58 --> Pagination Class Initialized
INFO - 2023-11-17 05:47:58 --> Form Validation Class Initialized
INFO - 2023-11-17 05:47:58 --> Controller Class Initialized
INFO - 2023-11-17 05:47:58 --> Model Class Initialized
DEBUG - 2023-11-17 05:47:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:47:58 --> Model Class Initialized
DEBUG - 2023-11-17 05:47:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:47:58 --> Model Class Initialized
INFO - 2023-11-17 05:47:58 --> Model Class Initialized
INFO - 2023-11-17 05:47:58 --> Model Class Initialized
INFO - 2023-11-17 05:47:58 --> Model Class Initialized
DEBUG - 2023-11-17 05:47:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:47:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:47:58 --> Model Class Initialized
INFO - 2023-11-17 05:47:58 --> Model Class Initialized
INFO - 2023-11-17 05:47:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-17 05:47:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:47:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 05:47:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 05:47:59 --> Model Class Initialized
INFO - 2023-11-17 05:47:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 05:47:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 05:47:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 05:47:59 --> Final output sent to browser
DEBUG - 2023-11-17 05:47:59 --> Total execution time: 0.2091
ERROR - 2023-11-17 05:48:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:48:08 --> Config Class Initialized
INFO - 2023-11-17 05:48:08 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:48:08 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:48:08 --> Utf8 Class Initialized
INFO - 2023-11-17 05:48:08 --> URI Class Initialized
DEBUG - 2023-11-17 05:48:08 --> No URI present. Default controller set.
INFO - 2023-11-17 05:48:08 --> Router Class Initialized
INFO - 2023-11-17 05:48:08 --> Output Class Initialized
INFO - 2023-11-17 05:48:08 --> Security Class Initialized
DEBUG - 2023-11-17 05:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:48:08 --> Input Class Initialized
INFO - 2023-11-17 05:48:08 --> Language Class Initialized
INFO - 2023-11-17 05:48:08 --> Loader Class Initialized
INFO - 2023-11-17 05:48:08 --> Helper loaded: url_helper
INFO - 2023-11-17 05:48:08 --> Helper loaded: file_helper
INFO - 2023-11-17 05:48:08 --> Helper loaded: html_helper
INFO - 2023-11-17 05:48:08 --> Helper loaded: text_helper
INFO - 2023-11-17 05:48:08 --> Helper loaded: form_helper
INFO - 2023-11-17 05:48:08 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:48:08 --> Helper loaded: security_helper
INFO - 2023-11-17 05:48:08 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:48:08 --> Database Driver Class Initialized
INFO - 2023-11-17 05:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:48:08 --> Parser Class Initialized
INFO - 2023-11-17 05:48:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:48:08 --> Pagination Class Initialized
INFO - 2023-11-17 05:48:08 --> Form Validation Class Initialized
INFO - 2023-11-17 05:48:08 --> Controller Class Initialized
INFO - 2023-11-17 05:48:08 --> Model Class Initialized
DEBUG - 2023-11-17 05:48:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:48:08 --> Model Class Initialized
DEBUG - 2023-11-17 05:48:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:48:08 --> Model Class Initialized
INFO - 2023-11-17 05:48:08 --> Model Class Initialized
INFO - 2023-11-17 05:48:08 --> Model Class Initialized
INFO - 2023-11-17 05:48:08 --> Model Class Initialized
DEBUG - 2023-11-17 05:48:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:48:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:48:08 --> Model Class Initialized
INFO - 2023-11-17 05:48:08 --> Model Class Initialized
INFO - 2023-11-17 05:48:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-17 05:48:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:48:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 05:48:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 05:48:08 --> Model Class Initialized
INFO - 2023-11-17 05:48:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 05:48:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 05:48:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 05:48:08 --> Final output sent to browser
DEBUG - 2023-11-17 05:48:08 --> Total execution time: 0.2028
ERROR - 2023-11-17 05:48:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:48:18 --> Config Class Initialized
INFO - 2023-11-17 05:48:18 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:48:18 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:48:18 --> Utf8 Class Initialized
INFO - 2023-11-17 05:48:18 --> URI Class Initialized
INFO - 2023-11-17 05:48:18 --> Router Class Initialized
INFO - 2023-11-17 05:48:18 --> Output Class Initialized
INFO - 2023-11-17 05:48:18 --> Security Class Initialized
DEBUG - 2023-11-17 05:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:48:18 --> Input Class Initialized
INFO - 2023-11-17 05:48:18 --> Language Class Initialized
INFO - 2023-11-17 05:48:18 --> Loader Class Initialized
INFO - 2023-11-17 05:48:18 --> Helper loaded: url_helper
INFO - 2023-11-17 05:48:18 --> Helper loaded: file_helper
INFO - 2023-11-17 05:48:18 --> Helper loaded: html_helper
INFO - 2023-11-17 05:48:18 --> Helper loaded: text_helper
INFO - 2023-11-17 05:48:18 --> Helper loaded: form_helper
INFO - 2023-11-17 05:48:18 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:48:18 --> Helper loaded: security_helper
INFO - 2023-11-17 05:48:18 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:48:18 --> Database Driver Class Initialized
INFO - 2023-11-17 05:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:48:18 --> Parser Class Initialized
INFO - 2023-11-17 05:48:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:48:18 --> Pagination Class Initialized
INFO - 2023-11-17 05:48:18 --> Form Validation Class Initialized
INFO - 2023-11-17 05:48:18 --> Controller Class Initialized
DEBUG - 2023-11-17 05:48:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:48:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:48:18 --> Model Class Initialized
DEBUG - 2023-11-17 05:48:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:48:18 --> Model Class Initialized
DEBUG - 2023-11-17 05:48:18 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:48:18 --> Model Class Initialized
INFO - 2023-11-17 05:48:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-11-17 05:48:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:48:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 05:48:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 05:48:18 --> Model Class Initialized
INFO - 2023-11-17 05:48:18 --> Model Class Initialized
INFO - 2023-11-17 05:48:18 --> Model Class Initialized
INFO - 2023-11-17 05:48:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 05:48:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 05:48:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 05:48:18 --> Final output sent to browser
DEBUG - 2023-11-17 05:48:18 --> Total execution time: 0.1356
ERROR - 2023-11-17 05:48:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:48:19 --> Config Class Initialized
INFO - 2023-11-17 05:48:19 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:48:19 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:48:19 --> Utf8 Class Initialized
INFO - 2023-11-17 05:48:19 --> URI Class Initialized
INFO - 2023-11-17 05:48:19 --> Router Class Initialized
INFO - 2023-11-17 05:48:19 --> Output Class Initialized
INFO - 2023-11-17 05:48:19 --> Security Class Initialized
DEBUG - 2023-11-17 05:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:48:19 --> Input Class Initialized
INFO - 2023-11-17 05:48:19 --> Language Class Initialized
INFO - 2023-11-17 05:48:19 --> Loader Class Initialized
INFO - 2023-11-17 05:48:19 --> Helper loaded: url_helper
INFO - 2023-11-17 05:48:19 --> Helper loaded: file_helper
INFO - 2023-11-17 05:48:19 --> Helper loaded: html_helper
INFO - 2023-11-17 05:48:19 --> Helper loaded: text_helper
INFO - 2023-11-17 05:48:19 --> Helper loaded: form_helper
INFO - 2023-11-17 05:48:19 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:48:19 --> Helper loaded: security_helper
INFO - 2023-11-17 05:48:19 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:48:19 --> Database Driver Class Initialized
INFO - 2023-11-17 05:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:48:19 --> Parser Class Initialized
INFO - 2023-11-17 05:48:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:48:19 --> Pagination Class Initialized
INFO - 2023-11-17 05:48:19 --> Form Validation Class Initialized
INFO - 2023-11-17 05:48:19 --> Controller Class Initialized
DEBUG - 2023-11-17 05:48:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:48:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:48:19 --> Model Class Initialized
DEBUG - 2023-11-17 05:48:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:48:19 --> Model Class Initialized
INFO - 2023-11-17 05:48:19 --> Final output sent to browser
DEBUG - 2023-11-17 05:48:19 --> Total execution time: 0.0217
ERROR - 2023-11-17 05:48:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:48:22 --> Config Class Initialized
INFO - 2023-11-17 05:48:22 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:48:22 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:48:22 --> Utf8 Class Initialized
INFO - 2023-11-17 05:48:22 --> URI Class Initialized
INFO - 2023-11-17 05:48:22 --> Router Class Initialized
INFO - 2023-11-17 05:48:22 --> Output Class Initialized
INFO - 2023-11-17 05:48:22 --> Security Class Initialized
DEBUG - 2023-11-17 05:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:48:22 --> Input Class Initialized
INFO - 2023-11-17 05:48:22 --> Language Class Initialized
INFO - 2023-11-17 05:48:22 --> Loader Class Initialized
INFO - 2023-11-17 05:48:22 --> Helper loaded: url_helper
INFO - 2023-11-17 05:48:22 --> Helper loaded: file_helper
INFO - 2023-11-17 05:48:22 --> Helper loaded: html_helper
INFO - 2023-11-17 05:48:22 --> Helper loaded: text_helper
INFO - 2023-11-17 05:48:22 --> Helper loaded: form_helper
INFO - 2023-11-17 05:48:22 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:48:22 --> Helper loaded: security_helper
INFO - 2023-11-17 05:48:22 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:48:22 --> Database Driver Class Initialized
INFO - 2023-11-17 05:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:48:22 --> Parser Class Initialized
INFO - 2023-11-17 05:48:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:48:22 --> Pagination Class Initialized
INFO - 2023-11-17 05:48:22 --> Form Validation Class Initialized
INFO - 2023-11-17 05:48:22 --> Controller Class Initialized
DEBUG - 2023-11-17 05:48:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:48:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:48:22 --> Model Class Initialized
DEBUG - 2023-11-17 05:48:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:48:22 --> Model Class Initialized
INFO - 2023-11-17 05:48:22 --> Final output sent to browser
DEBUG - 2023-11-17 05:48:22 --> Total execution time: 0.0414
ERROR - 2023-11-17 05:48:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:48:31 --> Config Class Initialized
INFO - 2023-11-17 05:48:31 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:48:31 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:48:31 --> Utf8 Class Initialized
INFO - 2023-11-17 05:48:31 --> URI Class Initialized
DEBUG - 2023-11-17 05:48:31 --> No URI present. Default controller set.
INFO - 2023-11-17 05:48:31 --> Router Class Initialized
INFO - 2023-11-17 05:48:31 --> Output Class Initialized
INFO - 2023-11-17 05:48:31 --> Security Class Initialized
DEBUG - 2023-11-17 05:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:48:31 --> Input Class Initialized
INFO - 2023-11-17 05:48:31 --> Language Class Initialized
INFO - 2023-11-17 05:48:31 --> Loader Class Initialized
INFO - 2023-11-17 05:48:31 --> Helper loaded: url_helper
INFO - 2023-11-17 05:48:31 --> Helper loaded: file_helper
INFO - 2023-11-17 05:48:31 --> Helper loaded: html_helper
INFO - 2023-11-17 05:48:31 --> Helper loaded: text_helper
INFO - 2023-11-17 05:48:31 --> Helper loaded: form_helper
INFO - 2023-11-17 05:48:31 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:48:31 --> Helper loaded: security_helper
INFO - 2023-11-17 05:48:31 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:48:31 --> Database Driver Class Initialized
INFO - 2023-11-17 05:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:48:31 --> Parser Class Initialized
INFO - 2023-11-17 05:48:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:48:31 --> Pagination Class Initialized
INFO - 2023-11-17 05:48:31 --> Form Validation Class Initialized
INFO - 2023-11-17 05:48:31 --> Controller Class Initialized
INFO - 2023-11-17 05:48:31 --> Model Class Initialized
DEBUG - 2023-11-17 05:48:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:48:31 --> Model Class Initialized
DEBUG - 2023-11-17 05:48:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:48:31 --> Model Class Initialized
INFO - 2023-11-17 05:48:31 --> Model Class Initialized
INFO - 2023-11-17 05:48:31 --> Model Class Initialized
INFO - 2023-11-17 05:48:31 --> Model Class Initialized
DEBUG - 2023-11-17 05:48:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:48:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:48:31 --> Model Class Initialized
INFO - 2023-11-17 05:48:31 --> Model Class Initialized
INFO - 2023-11-17 05:48:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-17 05:48:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:48:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 05:48:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 05:48:32 --> Model Class Initialized
INFO - 2023-11-17 05:48:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 05:48:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 05:48:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 05:48:32 --> Final output sent to browser
DEBUG - 2023-11-17 05:48:32 --> Total execution time: 0.3800
ERROR - 2023-11-17 05:48:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:48:43 --> Config Class Initialized
INFO - 2023-11-17 05:48:43 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:48:43 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:48:43 --> Utf8 Class Initialized
INFO - 2023-11-17 05:48:43 --> URI Class Initialized
INFO - 2023-11-17 05:48:43 --> Router Class Initialized
INFO - 2023-11-17 05:48:43 --> Output Class Initialized
INFO - 2023-11-17 05:48:43 --> Security Class Initialized
DEBUG - 2023-11-17 05:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:48:43 --> Input Class Initialized
INFO - 2023-11-17 05:48:43 --> Language Class Initialized
INFO - 2023-11-17 05:48:43 --> Loader Class Initialized
INFO - 2023-11-17 05:48:43 --> Helper loaded: url_helper
INFO - 2023-11-17 05:48:43 --> Helper loaded: file_helper
INFO - 2023-11-17 05:48:43 --> Helper loaded: html_helper
INFO - 2023-11-17 05:48:43 --> Helper loaded: text_helper
INFO - 2023-11-17 05:48:43 --> Helper loaded: form_helper
INFO - 2023-11-17 05:48:43 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:48:43 --> Helper loaded: security_helper
INFO - 2023-11-17 05:48:43 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:48:43 --> Database Driver Class Initialized
INFO - 2023-11-17 05:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:48:43 --> Parser Class Initialized
INFO - 2023-11-17 05:48:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:48:43 --> Pagination Class Initialized
INFO - 2023-11-17 05:48:43 --> Form Validation Class Initialized
INFO - 2023-11-17 05:48:43 --> Controller Class Initialized
DEBUG - 2023-11-17 05:48:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:48:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:48:43 --> Model Class Initialized
DEBUG - 2023-11-17 05:48:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:48:43 --> Model Class Initialized
DEBUG - 2023-11-17 05:48:43 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:48:43 --> Model Class Initialized
INFO - 2023-11-17 05:48:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-11-17 05:48:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:48:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 05:48:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 05:48:43 --> Model Class Initialized
INFO - 2023-11-17 05:48:43 --> Model Class Initialized
INFO - 2023-11-17 05:48:43 --> Model Class Initialized
INFO - 2023-11-17 05:48:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 05:48:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 05:48:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 05:48:43 --> Final output sent to browser
DEBUG - 2023-11-17 05:48:43 --> Total execution time: 0.2060
ERROR - 2023-11-17 05:48:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:48:44 --> Config Class Initialized
INFO - 2023-11-17 05:48:44 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:48:44 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:48:44 --> Utf8 Class Initialized
INFO - 2023-11-17 05:48:44 --> URI Class Initialized
INFO - 2023-11-17 05:48:44 --> Router Class Initialized
INFO - 2023-11-17 05:48:44 --> Output Class Initialized
INFO - 2023-11-17 05:48:44 --> Security Class Initialized
DEBUG - 2023-11-17 05:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:48:44 --> Input Class Initialized
INFO - 2023-11-17 05:48:44 --> Language Class Initialized
INFO - 2023-11-17 05:48:44 --> Loader Class Initialized
INFO - 2023-11-17 05:48:44 --> Helper loaded: url_helper
INFO - 2023-11-17 05:48:44 --> Helper loaded: file_helper
INFO - 2023-11-17 05:48:44 --> Helper loaded: html_helper
INFO - 2023-11-17 05:48:44 --> Helper loaded: text_helper
INFO - 2023-11-17 05:48:44 --> Helper loaded: form_helper
INFO - 2023-11-17 05:48:44 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:48:44 --> Helper loaded: security_helper
INFO - 2023-11-17 05:48:44 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:48:44 --> Database Driver Class Initialized
INFO - 2023-11-17 05:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:48:44 --> Parser Class Initialized
INFO - 2023-11-17 05:48:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:48:44 --> Pagination Class Initialized
INFO - 2023-11-17 05:48:44 --> Form Validation Class Initialized
INFO - 2023-11-17 05:48:44 --> Controller Class Initialized
DEBUG - 2023-11-17 05:48:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:48:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:48:44 --> Model Class Initialized
DEBUG - 2023-11-17 05:48:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:48:44 --> Model Class Initialized
INFO - 2023-11-17 05:48:44 --> Final output sent to browser
DEBUG - 2023-11-17 05:48:44 --> Total execution time: 0.0314
ERROR - 2023-11-17 05:48:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:48:46 --> Config Class Initialized
INFO - 2023-11-17 05:48:46 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:48:46 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:48:46 --> Utf8 Class Initialized
INFO - 2023-11-17 05:48:46 --> URI Class Initialized
DEBUG - 2023-11-17 05:48:46 --> No URI present. Default controller set.
INFO - 2023-11-17 05:48:46 --> Router Class Initialized
INFO - 2023-11-17 05:48:46 --> Output Class Initialized
INFO - 2023-11-17 05:48:46 --> Security Class Initialized
DEBUG - 2023-11-17 05:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:48:46 --> Input Class Initialized
INFO - 2023-11-17 05:48:46 --> Language Class Initialized
INFO - 2023-11-17 05:48:46 --> Loader Class Initialized
INFO - 2023-11-17 05:48:46 --> Helper loaded: url_helper
INFO - 2023-11-17 05:48:46 --> Helper loaded: file_helper
INFO - 2023-11-17 05:48:46 --> Helper loaded: html_helper
INFO - 2023-11-17 05:48:46 --> Helper loaded: text_helper
INFO - 2023-11-17 05:48:46 --> Helper loaded: form_helper
INFO - 2023-11-17 05:48:46 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:48:46 --> Helper loaded: security_helper
INFO - 2023-11-17 05:48:46 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:48:46 --> Database Driver Class Initialized
INFO - 2023-11-17 05:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:48:46 --> Parser Class Initialized
INFO - 2023-11-17 05:48:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:48:46 --> Pagination Class Initialized
INFO - 2023-11-17 05:48:46 --> Form Validation Class Initialized
INFO - 2023-11-17 05:48:46 --> Controller Class Initialized
INFO - 2023-11-17 05:48:46 --> Model Class Initialized
DEBUG - 2023-11-17 05:48:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:48:46 --> Model Class Initialized
DEBUG - 2023-11-17 05:48:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:48:46 --> Model Class Initialized
INFO - 2023-11-17 05:48:46 --> Model Class Initialized
INFO - 2023-11-17 05:48:46 --> Model Class Initialized
INFO - 2023-11-17 05:48:46 --> Model Class Initialized
DEBUG - 2023-11-17 05:48:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:48:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:48:46 --> Model Class Initialized
INFO - 2023-11-17 05:48:46 --> Model Class Initialized
INFO - 2023-11-17 05:48:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-17 05:48:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:48:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 05:48:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 05:48:47 --> Model Class Initialized
INFO - 2023-11-17 05:48:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 05:48:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 05:48:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 05:48:47 --> Final output sent to browser
DEBUG - 2023-11-17 05:48:47 --> Total execution time: 0.3953
ERROR - 2023-11-17 05:53:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 05:53:53 --> Config Class Initialized
INFO - 2023-11-17 05:53:53 --> Hooks Class Initialized
DEBUG - 2023-11-17 05:53:53 --> UTF-8 Support Enabled
INFO - 2023-11-17 05:53:53 --> Utf8 Class Initialized
INFO - 2023-11-17 05:53:53 --> URI Class Initialized
DEBUG - 2023-11-17 05:53:53 --> No URI present. Default controller set.
INFO - 2023-11-17 05:53:53 --> Router Class Initialized
INFO - 2023-11-17 05:53:53 --> Output Class Initialized
INFO - 2023-11-17 05:53:53 --> Security Class Initialized
DEBUG - 2023-11-17 05:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 05:53:53 --> Input Class Initialized
INFO - 2023-11-17 05:53:53 --> Language Class Initialized
INFO - 2023-11-17 05:53:53 --> Loader Class Initialized
INFO - 2023-11-17 05:53:53 --> Helper loaded: url_helper
INFO - 2023-11-17 05:53:53 --> Helper loaded: file_helper
INFO - 2023-11-17 05:53:53 --> Helper loaded: html_helper
INFO - 2023-11-17 05:53:53 --> Helper loaded: text_helper
INFO - 2023-11-17 05:53:53 --> Helper loaded: form_helper
INFO - 2023-11-17 05:53:53 --> Helper loaded: lang_helper
INFO - 2023-11-17 05:53:53 --> Helper loaded: security_helper
INFO - 2023-11-17 05:53:53 --> Helper loaded: cookie_helper
INFO - 2023-11-17 05:53:53 --> Database Driver Class Initialized
INFO - 2023-11-17 05:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 05:53:53 --> Parser Class Initialized
INFO - 2023-11-17 05:53:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 05:53:53 --> Pagination Class Initialized
INFO - 2023-11-17 05:53:53 --> Form Validation Class Initialized
INFO - 2023-11-17 05:53:53 --> Controller Class Initialized
INFO - 2023-11-17 05:53:53 --> Model Class Initialized
DEBUG - 2023-11-17 05:53:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:53:53 --> Model Class Initialized
DEBUG - 2023-11-17 05:53:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:53:53 --> Model Class Initialized
INFO - 2023-11-17 05:53:53 --> Model Class Initialized
INFO - 2023-11-17 05:53:53 --> Model Class Initialized
INFO - 2023-11-17 05:53:53 --> Model Class Initialized
DEBUG - 2023-11-17 05:53:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 05:53:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:53:53 --> Model Class Initialized
INFO - 2023-11-17 05:53:53 --> Model Class Initialized
INFO - 2023-11-17 05:53:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-17 05:53:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 05:53:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 05:53:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 05:53:53 --> Model Class Initialized
INFO - 2023-11-17 05:53:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 05:53:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 05:53:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 05:53:53 --> Final output sent to browser
DEBUG - 2023-11-17 05:53:53 --> Total execution time: 0.3740
ERROR - 2023-11-17 06:13:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 06:13:26 --> Config Class Initialized
INFO - 2023-11-17 06:13:26 --> Hooks Class Initialized
DEBUG - 2023-11-17 06:13:26 --> UTF-8 Support Enabled
INFO - 2023-11-17 06:13:26 --> Utf8 Class Initialized
INFO - 2023-11-17 06:13:26 --> URI Class Initialized
DEBUG - 2023-11-17 06:13:26 --> No URI present. Default controller set.
INFO - 2023-11-17 06:13:26 --> Router Class Initialized
INFO - 2023-11-17 06:13:26 --> Output Class Initialized
INFO - 2023-11-17 06:13:26 --> Security Class Initialized
DEBUG - 2023-11-17 06:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 06:13:27 --> Input Class Initialized
INFO - 2023-11-17 06:13:27 --> Language Class Initialized
INFO - 2023-11-17 06:13:27 --> Loader Class Initialized
INFO - 2023-11-17 06:13:27 --> Helper loaded: url_helper
INFO - 2023-11-17 06:13:27 --> Helper loaded: file_helper
INFO - 2023-11-17 06:13:27 --> Helper loaded: html_helper
INFO - 2023-11-17 06:13:27 --> Helper loaded: text_helper
INFO - 2023-11-17 06:13:27 --> Helper loaded: form_helper
INFO - 2023-11-17 06:13:27 --> Helper loaded: lang_helper
INFO - 2023-11-17 06:13:27 --> Helper loaded: security_helper
INFO - 2023-11-17 06:13:27 --> Helper loaded: cookie_helper
INFO - 2023-11-17 06:13:27 --> Database Driver Class Initialized
INFO - 2023-11-17 06:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 06:13:27 --> Parser Class Initialized
INFO - 2023-11-17 06:13:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 06:13:27 --> Pagination Class Initialized
INFO - 2023-11-17 06:13:27 --> Form Validation Class Initialized
INFO - 2023-11-17 06:13:27 --> Controller Class Initialized
INFO - 2023-11-17 06:13:27 --> Model Class Initialized
DEBUG - 2023-11-17 06:13:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:13:27 --> Model Class Initialized
DEBUG - 2023-11-17 06:13:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:13:27 --> Model Class Initialized
INFO - 2023-11-17 06:13:27 --> Model Class Initialized
INFO - 2023-11-17 06:13:27 --> Model Class Initialized
INFO - 2023-11-17 06:13:27 --> Model Class Initialized
DEBUG - 2023-11-17 06:13:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 06:13:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:13:27 --> Model Class Initialized
INFO - 2023-11-17 06:13:27 --> Model Class Initialized
INFO - 2023-11-17 06:13:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-17 06:13:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:13:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 06:13:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 06:13:27 --> Model Class Initialized
INFO - 2023-11-17 06:13:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 06:13:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 06:13:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 06:13:27 --> Final output sent to browser
DEBUG - 2023-11-17 06:13:27 --> Total execution time: 0.2067
ERROR - 2023-11-17 06:14:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 06:14:40 --> Config Class Initialized
INFO - 2023-11-17 06:14:40 --> Hooks Class Initialized
DEBUG - 2023-11-17 06:14:40 --> UTF-8 Support Enabled
INFO - 2023-11-17 06:14:40 --> Utf8 Class Initialized
INFO - 2023-11-17 06:14:40 --> URI Class Initialized
DEBUG - 2023-11-17 06:14:40 --> No URI present. Default controller set.
INFO - 2023-11-17 06:14:40 --> Router Class Initialized
INFO - 2023-11-17 06:14:40 --> Output Class Initialized
INFO - 2023-11-17 06:14:40 --> Security Class Initialized
DEBUG - 2023-11-17 06:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 06:14:40 --> Input Class Initialized
INFO - 2023-11-17 06:14:40 --> Language Class Initialized
INFO - 2023-11-17 06:14:40 --> Loader Class Initialized
INFO - 2023-11-17 06:14:40 --> Helper loaded: url_helper
INFO - 2023-11-17 06:14:40 --> Helper loaded: file_helper
INFO - 2023-11-17 06:14:40 --> Helper loaded: html_helper
INFO - 2023-11-17 06:14:40 --> Helper loaded: text_helper
INFO - 2023-11-17 06:14:40 --> Helper loaded: form_helper
INFO - 2023-11-17 06:14:40 --> Helper loaded: lang_helper
INFO - 2023-11-17 06:14:40 --> Helper loaded: security_helper
INFO - 2023-11-17 06:14:40 --> Helper loaded: cookie_helper
INFO - 2023-11-17 06:14:40 --> Database Driver Class Initialized
INFO - 2023-11-17 06:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 06:14:40 --> Parser Class Initialized
INFO - 2023-11-17 06:14:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 06:14:40 --> Pagination Class Initialized
INFO - 2023-11-17 06:14:40 --> Form Validation Class Initialized
INFO - 2023-11-17 06:14:40 --> Controller Class Initialized
INFO - 2023-11-17 06:14:40 --> Model Class Initialized
DEBUG - 2023-11-17 06:14:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:14:40 --> Model Class Initialized
DEBUG - 2023-11-17 06:14:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:14:40 --> Model Class Initialized
INFO - 2023-11-17 06:14:40 --> Model Class Initialized
INFO - 2023-11-17 06:14:40 --> Model Class Initialized
INFO - 2023-11-17 06:14:40 --> Model Class Initialized
DEBUG - 2023-11-17 06:14:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 06:14:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:14:40 --> Model Class Initialized
INFO - 2023-11-17 06:14:40 --> Model Class Initialized
INFO - 2023-11-17 06:14:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-17 06:14:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:14:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 06:14:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 06:14:40 --> Model Class Initialized
INFO - 2023-11-17 06:14:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 06:14:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 06:14:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 06:14:41 --> Final output sent to browser
DEBUG - 2023-11-17 06:14:41 --> Total execution time: 0.2129
ERROR - 2023-11-17 06:14:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 06:14:48 --> Config Class Initialized
INFO - 2023-11-17 06:14:48 --> Hooks Class Initialized
DEBUG - 2023-11-17 06:14:48 --> UTF-8 Support Enabled
INFO - 2023-11-17 06:14:48 --> Utf8 Class Initialized
INFO - 2023-11-17 06:14:48 --> URI Class Initialized
INFO - 2023-11-17 06:14:48 --> Router Class Initialized
INFO - 2023-11-17 06:14:48 --> Output Class Initialized
INFO - 2023-11-17 06:14:48 --> Security Class Initialized
DEBUG - 2023-11-17 06:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 06:14:48 --> Input Class Initialized
INFO - 2023-11-17 06:14:48 --> Language Class Initialized
INFO - 2023-11-17 06:14:48 --> Loader Class Initialized
INFO - 2023-11-17 06:14:48 --> Helper loaded: url_helper
INFO - 2023-11-17 06:14:48 --> Helper loaded: file_helper
INFO - 2023-11-17 06:14:48 --> Helper loaded: html_helper
INFO - 2023-11-17 06:14:48 --> Helper loaded: text_helper
INFO - 2023-11-17 06:14:48 --> Helper loaded: form_helper
INFO - 2023-11-17 06:14:48 --> Helper loaded: lang_helper
INFO - 2023-11-17 06:14:48 --> Helper loaded: security_helper
INFO - 2023-11-17 06:14:48 --> Helper loaded: cookie_helper
INFO - 2023-11-17 06:14:48 --> Database Driver Class Initialized
INFO - 2023-11-17 06:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 06:14:48 --> Parser Class Initialized
INFO - 2023-11-17 06:14:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 06:14:48 --> Pagination Class Initialized
INFO - 2023-11-17 06:14:48 --> Form Validation Class Initialized
INFO - 2023-11-17 06:14:48 --> Controller Class Initialized
DEBUG - 2023-11-17 06:14:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 06:14:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:14:48 --> Model Class Initialized
DEBUG - 2023-11-17 06:14:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:14:48 --> Model Class Initialized
DEBUG - 2023-11-17 06:14:48 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:14:48 --> Model Class Initialized
INFO - 2023-11-17 06:14:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-11-17 06:14:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:14:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 06:14:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 06:14:48 --> Model Class Initialized
INFO - 2023-11-17 06:14:48 --> Model Class Initialized
INFO - 2023-11-17 06:14:48 --> Model Class Initialized
INFO - 2023-11-17 06:14:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 06:14:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 06:14:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 06:14:48 --> Final output sent to browser
DEBUG - 2023-11-17 06:14:48 --> Total execution time: 0.1364
ERROR - 2023-11-17 06:14:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 06:14:49 --> Config Class Initialized
INFO - 2023-11-17 06:14:49 --> Hooks Class Initialized
DEBUG - 2023-11-17 06:14:49 --> UTF-8 Support Enabled
INFO - 2023-11-17 06:14:49 --> Utf8 Class Initialized
INFO - 2023-11-17 06:14:49 --> URI Class Initialized
INFO - 2023-11-17 06:14:49 --> Router Class Initialized
INFO - 2023-11-17 06:14:49 --> Output Class Initialized
INFO - 2023-11-17 06:14:49 --> Security Class Initialized
DEBUG - 2023-11-17 06:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 06:14:49 --> Input Class Initialized
INFO - 2023-11-17 06:14:49 --> Language Class Initialized
INFO - 2023-11-17 06:14:49 --> Loader Class Initialized
INFO - 2023-11-17 06:14:49 --> Helper loaded: url_helper
INFO - 2023-11-17 06:14:49 --> Helper loaded: file_helper
INFO - 2023-11-17 06:14:49 --> Helper loaded: html_helper
INFO - 2023-11-17 06:14:49 --> Helper loaded: text_helper
INFO - 2023-11-17 06:14:49 --> Helper loaded: form_helper
INFO - 2023-11-17 06:14:49 --> Helper loaded: lang_helper
INFO - 2023-11-17 06:14:49 --> Helper loaded: security_helper
INFO - 2023-11-17 06:14:49 --> Helper loaded: cookie_helper
INFO - 2023-11-17 06:14:49 --> Database Driver Class Initialized
INFO - 2023-11-17 06:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 06:14:49 --> Parser Class Initialized
INFO - 2023-11-17 06:14:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 06:14:49 --> Pagination Class Initialized
INFO - 2023-11-17 06:14:49 --> Form Validation Class Initialized
INFO - 2023-11-17 06:14:49 --> Controller Class Initialized
DEBUG - 2023-11-17 06:14:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 06:14:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:14:49 --> Model Class Initialized
DEBUG - 2023-11-17 06:14:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:14:49 --> Model Class Initialized
INFO - 2023-11-17 06:14:49 --> Final output sent to browser
DEBUG - 2023-11-17 06:14:49 --> Total execution time: 0.0214
ERROR - 2023-11-17 06:14:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 06:14:53 --> Config Class Initialized
INFO - 2023-11-17 06:14:53 --> Hooks Class Initialized
DEBUG - 2023-11-17 06:14:53 --> UTF-8 Support Enabled
INFO - 2023-11-17 06:14:53 --> Utf8 Class Initialized
INFO - 2023-11-17 06:14:53 --> URI Class Initialized
INFO - 2023-11-17 06:14:53 --> Router Class Initialized
INFO - 2023-11-17 06:14:53 --> Output Class Initialized
INFO - 2023-11-17 06:14:53 --> Security Class Initialized
DEBUG - 2023-11-17 06:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 06:14:53 --> Input Class Initialized
INFO - 2023-11-17 06:14:53 --> Language Class Initialized
INFO - 2023-11-17 06:14:53 --> Loader Class Initialized
INFO - 2023-11-17 06:14:53 --> Helper loaded: url_helper
INFO - 2023-11-17 06:14:53 --> Helper loaded: file_helper
INFO - 2023-11-17 06:14:53 --> Helper loaded: html_helper
INFO - 2023-11-17 06:14:53 --> Helper loaded: text_helper
INFO - 2023-11-17 06:14:53 --> Helper loaded: form_helper
INFO - 2023-11-17 06:14:53 --> Helper loaded: lang_helper
INFO - 2023-11-17 06:14:53 --> Helper loaded: security_helper
INFO - 2023-11-17 06:14:53 --> Helper loaded: cookie_helper
INFO - 2023-11-17 06:14:53 --> Database Driver Class Initialized
INFO - 2023-11-17 06:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 06:14:53 --> Parser Class Initialized
INFO - 2023-11-17 06:14:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 06:14:53 --> Pagination Class Initialized
INFO - 2023-11-17 06:14:53 --> Form Validation Class Initialized
INFO - 2023-11-17 06:14:53 --> Controller Class Initialized
DEBUG - 2023-11-17 06:14:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 06:14:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:14:53 --> Model Class Initialized
DEBUG - 2023-11-17 06:14:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:14:53 --> Model Class Initialized
INFO - 2023-11-17 06:14:53 --> Final output sent to browser
DEBUG - 2023-11-17 06:14:53 --> Total execution time: 0.0394
ERROR - 2023-11-17 06:15:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 06:15:33 --> Config Class Initialized
INFO - 2023-11-17 06:15:33 --> Hooks Class Initialized
DEBUG - 2023-11-17 06:15:33 --> UTF-8 Support Enabled
INFO - 2023-11-17 06:15:33 --> Utf8 Class Initialized
INFO - 2023-11-17 06:15:33 --> URI Class Initialized
DEBUG - 2023-11-17 06:15:33 --> No URI present. Default controller set.
INFO - 2023-11-17 06:15:33 --> Router Class Initialized
INFO - 2023-11-17 06:15:33 --> Output Class Initialized
INFO - 2023-11-17 06:15:33 --> Security Class Initialized
DEBUG - 2023-11-17 06:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 06:15:33 --> Input Class Initialized
INFO - 2023-11-17 06:15:33 --> Language Class Initialized
INFO - 2023-11-17 06:15:33 --> Loader Class Initialized
INFO - 2023-11-17 06:15:33 --> Helper loaded: url_helper
INFO - 2023-11-17 06:15:33 --> Helper loaded: file_helper
INFO - 2023-11-17 06:15:33 --> Helper loaded: html_helper
INFO - 2023-11-17 06:15:33 --> Helper loaded: text_helper
INFO - 2023-11-17 06:15:33 --> Helper loaded: form_helper
INFO - 2023-11-17 06:15:33 --> Helper loaded: lang_helper
INFO - 2023-11-17 06:15:33 --> Helper loaded: security_helper
INFO - 2023-11-17 06:15:33 --> Helper loaded: cookie_helper
INFO - 2023-11-17 06:15:33 --> Database Driver Class Initialized
INFO - 2023-11-17 06:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 06:15:33 --> Parser Class Initialized
INFO - 2023-11-17 06:15:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 06:15:33 --> Pagination Class Initialized
INFO - 2023-11-17 06:15:33 --> Form Validation Class Initialized
INFO - 2023-11-17 06:15:33 --> Controller Class Initialized
INFO - 2023-11-17 06:15:33 --> Model Class Initialized
DEBUG - 2023-11-17 06:15:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:15:33 --> Model Class Initialized
DEBUG - 2023-11-17 06:15:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:15:33 --> Model Class Initialized
INFO - 2023-11-17 06:15:33 --> Model Class Initialized
INFO - 2023-11-17 06:15:33 --> Model Class Initialized
INFO - 2023-11-17 06:15:33 --> Model Class Initialized
DEBUG - 2023-11-17 06:15:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 06:15:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:15:33 --> Model Class Initialized
INFO - 2023-11-17 06:15:33 --> Model Class Initialized
INFO - 2023-11-17 06:15:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-17 06:15:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:15:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 06:15:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 06:15:33 --> Model Class Initialized
INFO - 2023-11-17 06:15:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 06:15:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 06:15:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 06:15:33 --> Final output sent to browser
DEBUG - 2023-11-17 06:15:33 --> Total execution time: 0.2075
ERROR - 2023-11-17 06:15:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 06:15:38 --> Config Class Initialized
INFO - 2023-11-17 06:15:38 --> Hooks Class Initialized
DEBUG - 2023-11-17 06:15:38 --> UTF-8 Support Enabled
INFO - 2023-11-17 06:15:38 --> Utf8 Class Initialized
INFO - 2023-11-17 06:15:38 --> URI Class Initialized
DEBUG - 2023-11-17 06:15:38 --> No URI present. Default controller set.
INFO - 2023-11-17 06:15:38 --> Router Class Initialized
INFO - 2023-11-17 06:15:38 --> Output Class Initialized
INFO - 2023-11-17 06:15:38 --> Security Class Initialized
DEBUG - 2023-11-17 06:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 06:15:38 --> Input Class Initialized
INFO - 2023-11-17 06:15:38 --> Language Class Initialized
INFO - 2023-11-17 06:15:38 --> Loader Class Initialized
INFO - 2023-11-17 06:15:38 --> Helper loaded: url_helper
INFO - 2023-11-17 06:15:38 --> Helper loaded: file_helper
INFO - 2023-11-17 06:15:38 --> Helper loaded: html_helper
INFO - 2023-11-17 06:15:38 --> Helper loaded: text_helper
INFO - 2023-11-17 06:15:38 --> Helper loaded: form_helper
INFO - 2023-11-17 06:15:38 --> Helper loaded: lang_helper
INFO - 2023-11-17 06:15:38 --> Helper loaded: security_helper
INFO - 2023-11-17 06:15:38 --> Helper loaded: cookie_helper
INFO - 2023-11-17 06:15:38 --> Database Driver Class Initialized
INFO - 2023-11-17 06:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 06:15:38 --> Parser Class Initialized
INFO - 2023-11-17 06:15:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 06:15:38 --> Pagination Class Initialized
INFO - 2023-11-17 06:15:38 --> Form Validation Class Initialized
INFO - 2023-11-17 06:15:38 --> Controller Class Initialized
INFO - 2023-11-17 06:15:38 --> Model Class Initialized
DEBUG - 2023-11-17 06:15:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:15:38 --> Model Class Initialized
DEBUG - 2023-11-17 06:15:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:15:38 --> Model Class Initialized
INFO - 2023-11-17 06:15:38 --> Model Class Initialized
INFO - 2023-11-17 06:15:38 --> Model Class Initialized
INFO - 2023-11-17 06:15:38 --> Model Class Initialized
DEBUG - 2023-11-17 06:15:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 06:15:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:15:38 --> Model Class Initialized
INFO - 2023-11-17 06:15:38 --> Model Class Initialized
INFO - 2023-11-17 06:15:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-17 06:15:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:15:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 06:15:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 06:15:39 --> Model Class Initialized
INFO - 2023-11-17 06:15:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 06:15:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 06:15:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 06:15:39 --> Final output sent to browser
DEBUG - 2023-11-17 06:15:39 --> Total execution time: 0.2083
ERROR - 2023-11-17 06:15:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 06:15:45 --> Config Class Initialized
INFO - 2023-11-17 06:15:45 --> Hooks Class Initialized
DEBUG - 2023-11-17 06:15:45 --> UTF-8 Support Enabled
INFO - 2023-11-17 06:15:45 --> Utf8 Class Initialized
INFO - 2023-11-17 06:15:45 --> URI Class Initialized
DEBUG - 2023-11-17 06:15:45 --> No URI present. Default controller set.
INFO - 2023-11-17 06:15:45 --> Router Class Initialized
INFO - 2023-11-17 06:15:45 --> Output Class Initialized
INFO - 2023-11-17 06:15:45 --> Security Class Initialized
DEBUG - 2023-11-17 06:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 06:15:45 --> Input Class Initialized
INFO - 2023-11-17 06:15:45 --> Language Class Initialized
INFO - 2023-11-17 06:15:45 --> Loader Class Initialized
INFO - 2023-11-17 06:15:45 --> Helper loaded: url_helper
INFO - 2023-11-17 06:15:45 --> Helper loaded: file_helper
INFO - 2023-11-17 06:15:45 --> Helper loaded: html_helper
INFO - 2023-11-17 06:15:45 --> Helper loaded: text_helper
INFO - 2023-11-17 06:15:45 --> Helper loaded: form_helper
INFO - 2023-11-17 06:15:45 --> Helper loaded: lang_helper
INFO - 2023-11-17 06:15:45 --> Helper loaded: security_helper
INFO - 2023-11-17 06:15:45 --> Helper loaded: cookie_helper
INFO - 2023-11-17 06:15:45 --> Database Driver Class Initialized
INFO - 2023-11-17 06:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 06:15:45 --> Parser Class Initialized
INFO - 2023-11-17 06:15:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 06:15:45 --> Pagination Class Initialized
INFO - 2023-11-17 06:15:45 --> Form Validation Class Initialized
INFO - 2023-11-17 06:15:45 --> Controller Class Initialized
INFO - 2023-11-17 06:15:45 --> Model Class Initialized
DEBUG - 2023-11-17 06:15:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:15:45 --> Model Class Initialized
DEBUG - 2023-11-17 06:15:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:15:45 --> Model Class Initialized
INFO - 2023-11-17 06:15:45 --> Model Class Initialized
INFO - 2023-11-17 06:15:45 --> Model Class Initialized
INFO - 2023-11-17 06:15:45 --> Model Class Initialized
DEBUG - 2023-11-17 06:15:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 06:15:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:15:45 --> Model Class Initialized
INFO - 2023-11-17 06:15:45 --> Model Class Initialized
INFO - 2023-11-17 06:15:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-17 06:15:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:15:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 06:15:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 06:15:45 --> Model Class Initialized
INFO - 2023-11-17 06:15:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 06:15:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 06:15:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 06:15:45 --> Final output sent to browser
DEBUG - 2023-11-17 06:15:45 --> Total execution time: 0.2083
ERROR - 2023-11-17 06:15:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 06:15:50 --> Config Class Initialized
INFO - 2023-11-17 06:15:50 --> Hooks Class Initialized
DEBUG - 2023-11-17 06:15:50 --> UTF-8 Support Enabled
INFO - 2023-11-17 06:15:50 --> Utf8 Class Initialized
INFO - 2023-11-17 06:15:50 --> URI Class Initialized
INFO - 2023-11-17 06:15:50 --> Router Class Initialized
INFO - 2023-11-17 06:15:50 --> Output Class Initialized
INFO - 2023-11-17 06:15:50 --> Security Class Initialized
DEBUG - 2023-11-17 06:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 06:15:50 --> Input Class Initialized
INFO - 2023-11-17 06:15:50 --> Language Class Initialized
INFO - 2023-11-17 06:15:50 --> Loader Class Initialized
INFO - 2023-11-17 06:15:50 --> Helper loaded: url_helper
INFO - 2023-11-17 06:15:50 --> Helper loaded: file_helper
INFO - 2023-11-17 06:15:50 --> Helper loaded: html_helper
INFO - 2023-11-17 06:15:50 --> Helper loaded: text_helper
INFO - 2023-11-17 06:15:50 --> Helper loaded: form_helper
INFO - 2023-11-17 06:15:50 --> Helper loaded: lang_helper
INFO - 2023-11-17 06:15:50 --> Helper loaded: security_helper
INFO - 2023-11-17 06:15:50 --> Helper loaded: cookie_helper
INFO - 2023-11-17 06:15:50 --> Database Driver Class Initialized
INFO - 2023-11-17 06:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 06:15:50 --> Parser Class Initialized
INFO - 2023-11-17 06:15:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 06:15:50 --> Pagination Class Initialized
INFO - 2023-11-17 06:15:50 --> Form Validation Class Initialized
INFO - 2023-11-17 06:15:50 --> Controller Class Initialized
INFO - 2023-11-17 06:15:50 --> Model Class Initialized
DEBUG - 2023-11-17 06:15:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 06:15:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:15:50 --> Model Class Initialized
DEBUG - 2023-11-17 06:15:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:15:50 --> Model Class Initialized
INFO - 2023-11-17 06:15:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-11-17 06:15:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:15:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 06:15:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 06:15:50 --> Model Class Initialized
INFO - 2023-11-17 06:15:50 --> Model Class Initialized
INFO - 2023-11-17 06:15:50 --> Model Class Initialized
INFO - 2023-11-17 06:15:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 06:15:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 06:15:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 06:15:50 --> Final output sent to browser
DEBUG - 2023-11-17 06:15:50 --> Total execution time: 0.1430
ERROR - 2023-11-17 06:15:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 06:15:51 --> Config Class Initialized
INFO - 2023-11-17 06:15:51 --> Hooks Class Initialized
DEBUG - 2023-11-17 06:15:51 --> UTF-8 Support Enabled
INFO - 2023-11-17 06:15:51 --> Utf8 Class Initialized
INFO - 2023-11-17 06:15:51 --> URI Class Initialized
INFO - 2023-11-17 06:15:51 --> Router Class Initialized
INFO - 2023-11-17 06:15:51 --> Output Class Initialized
INFO - 2023-11-17 06:15:51 --> Security Class Initialized
DEBUG - 2023-11-17 06:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 06:15:51 --> Input Class Initialized
INFO - 2023-11-17 06:15:51 --> Language Class Initialized
INFO - 2023-11-17 06:15:51 --> Loader Class Initialized
INFO - 2023-11-17 06:15:51 --> Helper loaded: url_helper
INFO - 2023-11-17 06:15:51 --> Helper loaded: file_helper
INFO - 2023-11-17 06:15:51 --> Helper loaded: html_helper
INFO - 2023-11-17 06:15:51 --> Helper loaded: text_helper
INFO - 2023-11-17 06:15:51 --> Helper loaded: form_helper
INFO - 2023-11-17 06:15:51 --> Helper loaded: lang_helper
INFO - 2023-11-17 06:15:51 --> Helper loaded: security_helper
INFO - 2023-11-17 06:15:51 --> Helper loaded: cookie_helper
INFO - 2023-11-17 06:15:51 --> Database Driver Class Initialized
INFO - 2023-11-17 06:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 06:15:51 --> Parser Class Initialized
INFO - 2023-11-17 06:15:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 06:15:51 --> Pagination Class Initialized
INFO - 2023-11-17 06:15:51 --> Form Validation Class Initialized
INFO - 2023-11-17 06:15:51 --> Controller Class Initialized
INFO - 2023-11-17 06:15:51 --> Model Class Initialized
DEBUG - 2023-11-17 06:15:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 06:15:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:15:51 --> Model Class Initialized
DEBUG - 2023-11-17 06:15:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:15:51 --> Model Class Initialized
INFO - 2023-11-17 06:15:51 --> Final output sent to browser
DEBUG - 2023-11-17 06:15:51 --> Total execution time: 0.0410
ERROR - 2023-11-17 06:15:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 06:15:54 --> Config Class Initialized
INFO - 2023-11-17 06:15:54 --> Hooks Class Initialized
DEBUG - 2023-11-17 06:15:54 --> UTF-8 Support Enabled
INFO - 2023-11-17 06:15:54 --> Utf8 Class Initialized
INFO - 2023-11-17 06:15:54 --> URI Class Initialized
DEBUG - 2023-11-17 06:15:54 --> No URI present. Default controller set.
INFO - 2023-11-17 06:15:54 --> Router Class Initialized
INFO - 2023-11-17 06:15:54 --> Output Class Initialized
INFO - 2023-11-17 06:15:54 --> Security Class Initialized
DEBUG - 2023-11-17 06:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 06:15:54 --> Input Class Initialized
INFO - 2023-11-17 06:15:54 --> Language Class Initialized
INFO - 2023-11-17 06:15:54 --> Loader Class Initialized
INFO - 2023-11-17 06:15:54 --> Helper loaded: url_helper
INFO - 2023-11-17 06:15:54 --> Helper loaded: file_helper
INFO - 2023-11-17 06:15:54 --> Helper loaded: html_helper
INFO - 2023-11-17 06:15:54 --> Helper loaded: text_helper
INFO - 2023-11-17 06:15:54 --> Helper loaded: form_helper
INFO - 2023-11-17 06:15:54 --> Helper loaded: lang_helper
INFO - 2023-11-17 06:15:54 --> Helper loaded: security_helper
INFO - 2023-11-17 06:15:54 --> Helper loaded: cookie_helper
INFO - 2023-11-17 06:15:54 --> Database Driver Class Initialized
INFO - 2023-11-17 06:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 06:15:54 --> Parser Class Initialized
INFO - 2023-11-17 06:15:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 06:15:54 --> Pagination Class Initialized
INFO - 2023-11-17 06:15:54 --> Form Validation Class Initialized
INFO - 2023-11-17 06:15:54 --> Controller Class Initialized
INFO - 2023-11-17 06:15:54 --> Model Class Initialized
DEBUG - 2023-11-17 06:15:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:15:54 --> Model Class Initialized
DEBUG - 2023-11-17 06:15:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:15:54 --> Model Class Initialized
INFO - 2023-11-17 06:15:54 --> Model Class Initialized
INFO - 2023-11-17 06:15:54 --> Model Class Initialized
INFO - 2023-11-17 06:15:54 --> Model Class Initialized
DEBUG - 2023-11-17 06:15:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 06:15:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:15:54 --> Model Class Initialized
INFO - 2023-11-17 06:15:54 --> Model Class Initialized
INFO - 2023-11-17 06:15:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-17 06:15:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:15:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 06:15:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 06:15:54 --> Model Class Initialized
INFO - 2023-11-17 06:15:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 06:15:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 06:15:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 06:15:54 --> Final output sent to browser
DEBUG - 2023-11-17 06:15:54 --> Total execution time: 0.2160
ERROR - 2023-11-17 06:16:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 06:16:16 --> Config Class Initialized
INFO - 2023-11-17 06:16:16 --> Hooks Class Initialized
DEBUG - 2023-11-17 06:16:16 --> UTF-8 Support Enabled
INFO - 2023-11-17 06:16:16 --> Utf8 Class Initialized
INFO - 2023-11-17 06:16:16 --> URI Class Initialized
DEBUG - 2023-11-17 06:16:16 --> No URI present. Default controller set.
INFO - 2023-11-17 06:16:16 --> Router Class Initialized
INFO - 2023-11-17 06:16:16 --> Output Class Initialized
INFO - 2023-11-17 06:16:16 --> Security Class Initialized
DEBUG - 2023-11-17 06:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 06:16:16 --> Input Class Initialized
INFO - 2023-11-17 06:16:16 --> Language Class Initialized
INFO - 2023-11-17 06:16:16 --> Loader Class Initialized
INFO - 2023-11-17 06:16:16 --> Helper loaded: url_helper
INFO - 2023-11-17 06:16:16 --> Helper loaded: file_helper
INFO - 2023-11-17 06:16:16 --> Helper loaded: html_helper
INFO - 2023-11-17 06:16:16 --> Helper loaded: text_helper
INFO - 2023-11-17 06:16:16 --> Helper loaded: form_helper
INFO - 2023-11-17 06:16:16 --> Helper loaded: lang_helper
INFO - 2023-11-17 06:16:16 --> Helper loaded: security_helper
INFO - 2023-11-17 06:16:16 --> Helper loaded: cookie_helper
INFO - 2023-11-17 06:16:16 --> Database Driver Class Initialized
INFO - 2023-11-17 06:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 06:16:16 --> Parser Class Initialized
INFO - 2023-11-17 06:16:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 06:16:16 --> Pagination Class Initialized
INFO - 2023-11-17 06:16:16 --> Form Validation Class Initialized
INFO - 2023-11-17 06:16:16 --> Controller Class Initialized
INFO - 2023-11-17 06:16:16 --> Model Class Initialized
DEBUG - 2023-11-17 06:16:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:16:16 --> Model Class Initialized
DEBUG - 2023-11-17 06:16:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:16:16 --> Model Class Initialized
INFO - 2023-11-17 06:16:16 --> Model Class Initialized
INFO - 2023-11-17 06:16:16 --> Model Class Initialized
INFO - 2023-11-17 06:16:16 --> Model Class Initialized
DEBUG - 2023-11-17 06:16:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 06:16:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:16:16 --> Model Class Initialized
INFO - 2023-11-17 06:16:16 --> Model Class Initialized
INFO - 2023-11-17 06:16:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-17 06:16:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:16:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 06:16:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 06:16:16 --> Model Class Initialized
INFO - 2023-11-17 06:16:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 06:16:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 06:16:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 06:16:16 --> Final output sent to browser
DEBUG - 2023-11-17 06:16:16 --> Total execution time: 0.3656
ERROR - 2023-11-17 06:16:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 06:16:48 --> Config Class Initialized
INFO - 2023-11-17 06:16:48 --> Hooks Class Initialized
DEBUG - 2023-11-17 06:16:48 --> UTF-8 Support Enabled
INFO - 2023-11-17 06:16:48 --> Utf8 Class Initialized
INFO - 2023-11-17 06:16:48 --> URI Class Initialized
INFO - 2023-11-17 06:16:48 --> Router Class Initialized
INFO - 2023-11-17 06:16:48 --> Output Class Initialized
INFO - 2023-11-17 06:16:48 --> Security Class Initialized
DEBUG - 2023-11-17 06:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 06:16:48 --> Input Class Initialized
INFO - 2023-11-17 06:16:48 --> Language Class Initialized
INFO - 2023-11-17 06:16:48 --> Loader Class Initialized
INFO - 2023-11-17 06:16:48 --> Helper loaded: url_helper
INFO - 2023-11-17 06:16:48 --> Helper loaded: file_helper
INFO - 2023-11-17 06:16:48 --> Helper loaded: html_helper
INFO - 2023-11-17 06:16:48 --> Helper loaded: text_helper
INFO - 2023-11-17 06:16:48 --> Helper loaded: form_helper
INFO - 2023-11-17 06:16:48 --> Helper loaded: lang_helper
INFO - 2023-11-17 06:16:48 --> Helper loaded: security_helper
INFO - 2023-11-17 06:16:48 --> Helper loaded: cookie_helper
INFO - 2023-11-17 06:16:48 --> Database Driver Class Initialized
INFO - 2023-11-17 06:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 06:16:48 --> Parser Class Initialized
INFO - 2023-11-17 06:16:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 06:16:48 --> Pagination Class Initialized
INFO - 2023-11-17 06:16:48 --> Form Validation Class Initialized
INFO - 2023-11-17 06:16:48 --> Controller Class Initialized
INFO - 2023-11-17 06:16:48 --> Model Class Initialized
DEBUG - 2023-11-17 06:16:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 06:16:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:16:48 --> Model Class Initialized
DEBUG - 2023-11-17 06:16:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:16:48 --> Model Class Initialized
INFO - 2023-11-17 06:16:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-11-17 06:16:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:16:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 06:16:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 06:16:48 --> Model Class Initialized
INFO - 2023-11-17 06:16:48 --> Model Class Initialized
INFO - 2023-11-17 06:16:48 --> Model Class Initialized
INFO - 2023-11-17 06:16:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 06:16:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 06:16:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 06:16:48 --> Final output sent to browser
DEBUG - 2023-11-17 06:16:48 --> Total execution time: 0.1990
ERROR - 2023-11-17 06:16:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 06:16:49 --> Config Class Initialized
INFO - 2023-11-17 06:16:49 --> Hooks Class Initialized
DEBUG - 2023-11-17 06:16:49 --> UTF-8 Support Enabled
INFO - 2023-11-17 06:16:49 --> Utf8 Class Initialized
INFO - 2023-11-17 06:16:49 --> URI Class Initialized
INFO - 2023-11-17 06:16:49 --> Router Class Initialized
INFO - 2023-11-17 06:16:49 --> Output Class Initialized
INFO - 2023-11-17 06:16:49 --> Security Class Initialized
DEBUG - 2023-11-17 06:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 06:16:49 --> Input Class Initialized
INFO - 2023-11-17 06:16:49 --> Language Class Initialized
INFO - 2023-11-17 06:16:49 --> Loader Class Initialized
INFO - 2023-11-17 06:16:49 --> Helper loaded: url_helper
INFO - 2023-11-17 06:16:49 --> Helper loaded: file_helper
INFO - 2023-11-17 06:16:49 --> Helper loaded: html_helper
INFO - 2023-11-17 06:16:49 --> Helper loaded: text_helper
INFO - 2023-11-17 06:16:49 --> Helper loaded: form_helper
INFO - 2023-11-17 06:16:49 --> Helper loaded: lang_helper
INFO - 2023-11-17 06:16:49 --> Helper loaded: security_helper
INFO - 2023-11-17 06:16:49 --> Helper loaded: cookie_helper
INFO - 2023-11-17 06:16:49 --> Database Driver Class Initialized
INFO - 2023-11-17 06:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 06:16:49 --> Parser Class Initialized
INFO - 2023-11-17 06:16:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 06:16:49 --> Pagination Class Initialized
INFO - 2023-11-17 06:16:49 --> Form Validation Class Initialized
INFO - 2023-11-17 06:16:49 --> Controller Class Initialized
INFO - 2023-11-17 06:16:49 --> Model Class Initialized
DEBUG - 2023-11-17 06:16:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 06:16:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:16:49 --> Model Class Initialized
DEBUG - 2023-11-17 06:16:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:16:49 --> Model Class Initialized
INFO - 2023-11-17 06:16:49 --> Final output sent to browser
DEBUG - 2023-11-17 06:16:49 --> Total execution time: 0.0465
ERROR - 2023-11-17 06:16:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 06:16:54 --> Config Class Initialized
INFO - 2023-11-17 06:16:54 --> Hooks Class Initialized
DEBUG - 2023-11-17 06:16:54 --> UTF-8 Support Enabled
INFO - 2023-11-17 06:16:54 --> Utf8 Class Initialized
INFO - 2023-11-17 06:16:54 --> URI Class Initialized
DEBUG - 2023-11-17 06:16:54 --> No URI present. Default controller set.
INFO - 2023-11-17 06:16:54 --> Router Class Initialized
INFO - 2023-11-17 06:16:54 --> Output Class Initialized
INFO - 2023-11-17 06:16:54 --> Security Class Initialized
DEBUG - 2023-11-17 06:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 06:16:54 --> Input Class Initialized
INFO - 2023-11-17 06:16:54 --> Language Class Initialized
INFO - 2023-11-17 06:16:54 --> Loader Class Initialized
INFO - 2023-11-17 06:16:54 --> Helper loaded: url_helper
INFO - 2023-11-17 06:16:54 --> Helper loaded: file_helper
INFO - 2023-11-17 06:16:54 --> Helper loaded: html_helper
INFO - 2023-11-17 06:16:54 --> Helper loaded: text_helper
INFO - 2023-11-17 06:16:54 --> Helper loaded: form_helper
INFO - 2023-11-17 06:16:54 --> Helper loaded: lang_helper
INFO - 2023-11-17 06:16:54 --> Helper loaded: security_helper
INFO - 2023-11-17 06:16:54 --> Helper loaded: cookie_helper
INFO - 2023-11-17 06:16:54 --> Database Driver Class Initialized
INFO - 2023-11-17 06:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 06:16:54 --> Parser Class Initialized
INFO - 2023-11-17 06:16:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 06:16:54 --> Pagination Class Initialized
INFO - 2023-11-17 06:16:54 --> Form Validation Class Initialized
INFO - 2023-11-17 06:16:54 --> Controller Class Initialized
INFO - 2023-11-17 06:16:54 --> Model Class Initialized
DEBUG - 2023-11-17 06:16:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:16:54 --> Model Class Initialized
DEBUG - 2023-11-17 06:16:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:16:54 --> Model Class Initialized
INFO - 2023-11-17 06:16:54 --> Model Class Initialized
INFO - 2023-11-17 06:16:54 --> Model Class Initialized
INFO - 2023-11-17 06:16:54 --> Model Class Initialized
DEBUG - 2023-11-17 06:16:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 06:16:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:16:54 --> Model Class Initialized
INFO - 2023-11-17 06:16:54 --> Model Class Initialized
INFO - 2023-11-17 06:16:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-17 06:16:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:16:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 06:16:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 06:16:54 --> Model Class Initialized
INFO - 2023-11-17 06:16:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 06:16:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 06:16:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 06:16:54 --> Final output sent to browser
DEBUG - 2023-11-17 06:16:54 --> Total execution time: 0.3521
ERROR - 2023-11-17 06:25:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 06:25:46 --> Config Class Initialized
INFO - 2023-11-17 06:25:46 --> Hooks Class Initialized
DEBUG - 2023-11-17 06:25:46 --> UTF-8 Support Enabled
INFO - 2023-11-17 06:25:46 --> Utf8 Class Initialized
INFO - 2023-11-17 06:25:46 --> URI Class Initialized
INFO - 2023-11-17 06:25:46 --> Router Class Initialized
INFO - 2023-11-17 06:25:46 --> Output Class Initialized
INFO - 2023-11-17 06:25:46 --> Security Class Initialized
DEBUG - 2023-11-17 06:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 06:25:46 --> Input Class Initialized
INFO - 2023-11-17 06:25:46 --> Language Class Initialized
INFO - 2023-11-17 06:25:46 --> Loader Class Initialized
INFO - 2023-11-17 06:25:46 --> Helper loaded: url_helper
INFO - 2023-11-17 06:25:46 --> Helper loaded: file_helper
INFO - 2023-11-17 06:25:46 --> Helper loaded: html_helper
INFO - 2023-11-17 06:25:46 --> Helper loaded: text_helper
INFO - 2023-11-17 06:25:46 --> Helper loaded: form_helper
INFO - 2023-11-17 06:25:46 --> Helper loaded: lang_helper
INFO - 2023-11-17 06:25:46 --> Helper loaded: security_helper
INFO - 2023-11-17 06:25:46 --> Helper loaded: cookie_helper
INFO - 2023-11-17 06:25:46 --> Database Driver Class Initialized
INFO - 2023-11-17 06:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 06:25:46 --> Parser Class Initialized
INFO - 2023-11-17 06:25:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 06:25:46 --> Pagination Class Initialized
INFO - 2023-11-17 06:25:46 --> Form Validation Class Initialized
INFO - 2023-11-17 06:25:46 --> Controller Class Initialized
DEBUG - 2023-11-17 06:25:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 06:25:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:25:46 --> Model Class Initialized
INFO - 2023-11-17 06:25:46 --> Model Class Initialized
DEBUG - 2023-11-17 06:25:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 06:25:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:25:46 --> Model Class Initialized
DEBUG - 2023-11-17 06:25:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:25:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gst/list.php
DEBUG - 2023-11-17 06:25:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:25:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 06:25:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 06:25:46 --> Model Class Initialized
INFO - 2023-11-17 06:25:46 --> Model Class Initialized
INFO - 2023-11-17 06:25:46 --> Model Class Initialized
INFO - 2023-11-17 06:25:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 06:25:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 06:25:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 06:25:46 --> Final output sent to browser
DEBUG - 2023-11-17 06:25:46 --> Total execution time: 0.2159
ERROR - 2023-11-17 06:32:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 06:32:52 --> Config Class Initialized
INFO - 2023-11-17 06:32:52 --> Hooks Class Initialized
DEBUG - 2023-11-17 06:32:52 --> UTF-8 Support Enabled
INFO - 2023-11-17 06:32:52 --> Utf8 Class Initialized
INFO - 2023-11-17 06:32:52 --> URI Class Initialized
INFO - 2023-11-17 06:32:52 --> Router Class Initialized
INFO - 2023-11-17 06:32:52 --> Output Class Initialized
INFO - 2023-11-17 06:32:52 --> Security Class Initialized
DEBUG - 2023-11-17 06:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 06:32:52 --> Input Class Initialized
INFO - 2023-11-17 06:32:52 --> Language Class Initialized
INFO - 2023-11-17 06:32:52 --> Loader Class Initialized
INFO - 2023-11-17 06:32:52 --> Helper loaded: url_helper
INFO - 2023-11-17 06:32:52 --> Helper loaded: file_helper
INFO - 2023-11-17 06:32:52 --> Helper loaded: html_helper
INFO - 2023-11-17 06:32:52 --> Helper loaded: text_helper
INFO - 2023-11-17 06:32:52 --> Helper loaded: form_helper
INFO - 2023-11-17 06:32:52 --> Helper loaded: lang_helper
INFO - 2023-11-17 06:32:52 --> Helper loaded: security_helper
INFO - 2023-11-17 06:32:52 --> Helper loaded: cookie_helper
INFO - 2023-11-17 06:32:52 --> Database Driver Class Initialized
INFO - 2023-11-17 06:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 06:32:52 --> Parser Class Initialized
INFO - 2023-11-17 06:32:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 06:32:52 --> Pagination Class Initialized
INFO - 2023-11-17 06:32:52 --> Form Validation Class Initialized
INFO - 2023-11-17 06:32:52 --> Controller Class Initialized
DEBUG - 2023-11-17 06:32:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 06:32:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:32:52 --> Model Class Initialized
DEBUG - 2023-11-17 06:32:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 06:32:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:32:52 --> Model Class Initialized
DEBUG - 2023-11-17 06:32:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:32:52 --> Model Class Initialized
INFO - 2023-11-17 06:32:52 --> Final output sent to browser
DEBUG - 2023-11-17 06:32:52 --> Total execution time: 0.0185
ERROR - 2023-11-17 06:33:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 06:33:13 --> Config Class Initialized
INFO - 2023-11-17 06:33:13 --> Hooks Class Initialized
DEBUG - 2023-11-17 06:33:13 --> UTF-8 Support Enabled
INFO - 2023-11-17 06:33:13 --> Utf8 Class Initialized
INFO - 2023-11-17 06:33:13 --> URI Class Initialized
DEBUG - 2023-11-17 06:33:13 --> No URI present. Default controller set.
INFO - 2023-11-17 06:33:13 --> Router Class Initialized
INFO - 2023-11-17 06:33:13 --> Output Class Initialized
INFO - 2023-11-17 06:33:13 --> Security Class Initialized
DEBUG - 2023-11-17 06:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 06:33:13 --> Input Class Initialized
INFO - 2023-11-17 06:33:13 --> Language Class Initialized
INFO - 2023-11-17 06:33:13 --> Loader Class Initialized
INFO - 2023-11-17 06:33:13 --> Helper loaded: url_helper
INFO - 2023-11-17 06:33:13 --> Helper loaded: file_helper
INFO - 2023-11-17 06:33:13 --> Helper loaded: html_helper
INFO - 2023-11-17 06:33:13 --> Helper loaded: text_helper
INFO - 2023-11-17 06:33:13 --> Helper loaded: form_helper
INFO - 2023-11-17 06:33:13 --> Helper loaded: lang_helper
INFO - 2023-11-17 06:33:13 --> Helper loaded: security_helper
INFO - 2023-11-17 06:33:13 --> Helper loaded: cookie_helper
INFO - 2023-11-17 06:33:13 --> Database Driver Class Initialized
INFO - 2023-11-17 06:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 06:33:13 --> Parser Class Initialized
INFO - 2023-11-17 06:33:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 06:33:13 --> Pagination Class Initialized
INFO - 2023-11-17 06:33:13 --> Form Validation Class Initialized
INFO - 2023-11-17 06:33:13 --> Controller Class Initialized
INFO - 2023-11-17 06:33:13 --> Model Class Initialized
DEBUG - 2023-11-17 06:33:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:33:13 --> Model Class Initialized
DEBUG - 2023-11-17 06:33:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:33:13 --> Model Class Initialized
INFO - 2023-11-17 06:33:13 --> Model Class Initialized
INFO - 2023-11-17 06:33:13 --> Model Class Initialized
INFO - 2023-11-17 06:33:13 --> Model Class Initialized
DEBUG - 2023-11-17 06:33:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 06:33:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:33:13 --> Model Class Initialized
INFO - 2023-11-17 06:33:13 --> Model Class Initialized
INFO - 2023-11-17 06:33:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-17 06:33:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:33:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 06:33:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 06:33:14 --> Model Class Initialized
INFO - 2023-11-17 06:33:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 06:33:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 06:33:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 06:33:14 --> Final output sent to browser
DEBUG - 2023-11-17 06:33:14 --> Total execution time: 0.2072
ERROR - 2023-11-17 06:52:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 06:52:36 --> Config Class Initialized
INFO - 2023-11-17 06:52:36 --> Hooks Class Initialized
DEBUG - 2023-11-17 06:52:36 --> UTF-8 Support Enabled
INFO - 2023-11-17 06:52:36 --> Utf8 Class Initialized
INFO - 2023-11-17 06:52:36 --> URI Class Initialized
DEBUG - 2023-11-17 06:52:36 --> No URI present. Default controller set.
INFO - 2023-11-17 06:52:36 --> Router Class Initialized
INFO - 2023-11-17 06:52:36 --> Output Class Initialized
INFO - 2023-11-17 06:52:36 --> Security Class Initialized
DEBUG - 2023-11-17 06:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 06:52:36 --> Input Class Initialized
INFO - 2023-11-17 06:52:36 --> Language Class Initialized
INFO - 2023-11-17 06:52:36 --> Loader Class Initialized
INFO - 2023-11-17 06:52:36 --> Helper loaded: url_helper
INFO - 2023-11-17 06:52:36 --> Helper loaded: file_helper
INFO - 2023-11-17 06:52:36 --> Helper loaded: html_helper
INFO - 2023-11-17 06:52:36 --> Helper loaded: text_helper
INFO - 2023-11-17 06:52:36 --> Helper loaded: form_helper
INFO - 2023-11-17 06:52:36 --> Helper loaded: lang_helper
INFO - 2023-11-17 06:52:36 --> Helper loaded: security_helper
INFO - 2023-11-17 06:52:36 --> Helper loaded: cookie_helper
INFO - 2023-11-17 06:52:36 --> Database Driver Class Initialized
INFO - 2023-11-17 06:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 06:52:36 --> Parser Class Initialized
INFO - 2023-11-17 06:52:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 06:52:36 --> Pagination Class Initialized
INFO - 2023-11-17 06:52:36 --> Form Validation Class Initialized
INFO - 2023-11-17 06:52:36 --> Controller Class Initialized
INFO - 2023-11-17 06:52:36 --> Model Class Initialized
DEBUG - 2023-11-17 06:52:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:52:36 --> Model Class Initialized
DEBUG - 2023-11-17 06:52:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:52:36 --> Model Class Initialized
INFO - 2023-11-17 06:52:36 --> Model Class Initialized
INFO - 2023-11-17 06:52:36 --> Model Class Initialized
INFO - 2023-11-17 06:52:36 --> Model Class Initialized
DEBUG - 2023-11-17 06:52:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 06:52:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:52:36 --> Model Class Initialized
INFO - 2023-11-17 06:52:36 --> Model Class Initialized
INFO - 2023-11-17 06:52:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-17 06:52:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:52:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 06:52:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 06:52:36 --> Model Class Initialized
INFO - 2023-11-17 06:52:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 06:52:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 06:52:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 06:52:36 --> Final output sent to browser
DEBUG - 2023-11-17 06:52:36 --> Total execution time: 0.3852
ERROR - 2023-11-17 06:52:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 06:52:58 --> Config Class Initialized
INFO - 2023-11-17 06:52:58 --> Hooks Class Initialized
DEBUG - 2023-11-17 06:52:58 --> UTF-8 Support Enabled
INFO - 2023-11-17 06:52:58 --> Utf8 Class Initialized
INFO - 2023-11-17 06:52:58 --> URI Class Initialized
INFO - 2023-11-17 06:52:58 --> Router Class Initialized
INFO - 2023-11-17 06:52:58 --> Output Class Initialized
INFO - 2023-11-17 06:52:58 --> Security Class Initialized
DEBUG - 2023-11-17 06:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 06:52:58 --> Input Class Initialized
INFO - 2023-11-17 06:52:58 --> Language Class Initialized
INFO - 2023-11-17 06:52:58 --> Loader Class Initialized
INFO - 2023-11-17 06:52:58 --> Helper loaded: url_helper
INFO - 2023-11-17 06:52:58 --> Helper loaded: file_helper
INFO - 2023-11-17 06:52:58 --> Helper loaded: html_helper
INFO - 2023-11-17 06:52:58 --> Helper loaded: text_helper
INFO - 2023-11-17 06:52:58 --> Helper loaded: form_helper
INFO - 2023-11-17 06:52:58 --> Helper loaded: lang_helper
INFO - 2023-11-17 06:52:58 --> Helper loaded: security_helper
INFO - 2023-11-17 06:52:58 --> Helper loaded: cookie_helper
INFO - 2023-11-17 06:52:58 --> Database Driver Class Initialized
INFO - 2023-11-17 06:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 06:52:58 --> Parser Class Initialized
INFO - 2023-11-17 06:52:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 06:52:58 --> Pagination Class Initialized
INFO - 2023-11-17 06:52:58 --> Form Validation Class Initialized
INFO - 2023-11-17 06:52:58 --> Controller Class Initialized
DEBUG - 2023-11-17 06:52:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 06:52:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:52:58 --> Model Class Initialized
DEBUG - 2023-11-17 06:52:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:52:58 --> Model Class Initialized
DEBUG - 2023-11-17 06:52:58 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:52:58 --> Model Class Initialized
INFO - 2023-11-17 06:52:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-11-17 06:52:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:52:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 06:52:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 06:52:58 --> Model Class Initialized
INFO - 2023-11-17 06:52:58 --> Model Class Initialized
INFO - 2023-11-17 06:52:58 --> Model Class Initialized
INFO - 2023-11-17 06:52:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 06:52:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 06:52:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 06:52:59 --> Final output sent to browser
DEBUG - 2023-11-17 06:52:59 --> Total execution time: 0.2067
ERROR - 2023-11-17 06:52:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 06:52:59 --> Config Class Initialized
INFO - 2023-11-17 06:52:59 --> Hooks Class Initialized
DEBUG - 2023-11-17 06:52:59 --> UTF-8 Support Enabled
INFO - 2023-11-17 06:52:59 --> Utf8 Class Initialized
INFO - 2023-11-17 06:52:59 --> URI Class Initialized
INFO - 2023-11-17 06:52:59 --> Router Class Initialized
INFO - 2023-11-17 06:52:59 --> Output Class Initialized
INFO - 2023-11-17 06:52:59 --> Security Class Initialized
DEBUG - 2023-11-17 06:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 06:52:59 --> Input Class Initialized
INFO - 2023-11-17 06:52:59 --> Language Class Initialized
INFO - 2023-11-17 06:52:59 --> Loader Class Initialized
INFO - 2023-11-17 06:52:59 --> Helper loaded: url_helper
INFO - 2023-11-17 06:52:59 --> Helper loaded: file_helper
INFO - 2023-11-17 06:52:59 --> Helper loaded: html_helper
INFO - 2023-11-17 06:52:59 --> Helper loaded: text_helper
INFO - 2023-11-17 06:52:59 --> Helper loaded: form_helper
INFO - 2023-11-17 06:52:59 --> Helper loaded: lang_helper
INFO - 2023-11-17 06:52:59 --> Helper loaded: security_helper
INFO - 2023-11-17 06:52:59 --> Helper loaded: cookie_helper
INFO - 2023-11-17 06:52:59 --> Database Driver Class Initialized
INFO - 2023-11-17 06:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 06:52:59 --> Parser Class Initialized
INFO - 2023-11-17 06:52:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 06:52:59 --> Pagination Class Initialized
INFO - 2023-11-17 06:52:59 --> Form Validation Class Initialized
INFO - 2023-11-17 06:52:59 --> Controller Class Initialized
DEBUG - 2023-11-17 06:52:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 06:52:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:52:59 --> Model Class Initialized
DEBUG - 2023-11-17 06:52:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:52:59 --> Model Class Initialized
INFO - 2023-11-17 06:52:59 --> Final output sent to browser
DEBUG - 2023-11-17 06:52:59 --> Total execution time: 0.0304
ERROR - 2023-11-17 06:53:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 06:53:03 --> Config Class Initialized
INFO - 2023-11-17 06:53:03 --> Hooks Class Initialized
DEBUG - 2023-11-17 06:53:03 --> UTF-8 Support Enabled
INFO - 2023-11-17 06:53:03 --> Utf8 Class Initialized
INFO - 2023-11-17 06:53:03 --> URI Class Initialized
DEBUG - 2023-11-17 06:53:03 --> No URI present. Default controller set.
INFO - 2023-11-17 06:53:03 --> Router Class Initialized
INFO - 2023-11-17 06:53:03 --> Output Class Initialized
INFO - 2023-11-17 06:53:03 --> Security Class Initialized
DEBUG - 2023-11-17 06:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 06:53:03 --> Input Class Initialized
INFO - 2023-11-17 06:53:03 --> Language Class Initialized
INFO - 2023-11-17 06:53:03 --> Loader Class Initialized
INFO - 2023-11-17 06:53:03 --> Helper loaded: url_helper
INFO - 2023-11-17 06:53:03 --> Helper loaded: file_helper
INFO - 2023-11-17 06:53:03 --> Helper loaded: html_helper
INFO - 2023-11-17 06:53:03 --> Helper loaded: text_helper
INFO - 2023-11-17 06:53:03 --> Helper loaded: form_helper
INFO - 2023-11-17 06:53:03 --> Helper loaded: lang_helper
INFO - 2023-11-17 06:53:03 --> Helper loaded: security_helper
INFO - 2023-11-17 06:53:03 --> Helper loaded: cookie_helper
INFO - 2023-11-17 06:53:03 --> Database Driver Class Initialized
INFO - 2023-11-17 06:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 06:53:03 --> Parser Class Initialized
INFO - 2023-11-17 06:53:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 06:53:03 --> Pagination Class Initialized
INFO - 2023-11-17 06:53:03 --> Form Validation Class Initialized
INFO - 2023-11-17 06:53:03 --> Controller Class Initialized
INFO - 2023-11-17 06:53:03 --> Model Class Initialized
DEBUG - 2023-11-17 06:53:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:53:03 --> Model Class Initialized
DEBUG - 2023-11-17 06:53:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:53:03 --> Model Class Initialized
INFO - 2023-11-17 06:53:03 --> Model Class Initialized
INFO - 2023-11-17 06:53:03 --> Model Class Initialized
INFO - 2023-11-17 06:53:03 --> Model Class Initialized
DEBUG - 2023-11-17 06:53:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 06:53:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:53:03 --> Model Class Initialized
INFO - 2023-11-17 06:53:03 --> Model Class Initialized
INFO - 2023-11-17 06:53:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-17 06:53:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 06:53:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 06:53:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 06:53:03 --> Model Class Initialized
INFO - 2023-11-17 06:53:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 06:53:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 06:53:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 06:53:03 --> Final output sent to browser
DEBUG - 2023-11-17 06:53:03 --> Total execution time: 0.3560
ERROR - 2023-11-17 07:09:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 07:09:23 --> Config Class Initialized
INFO - 2023-11-17 07:09:23 --> Hooks Class Initialized
DEBUG - 2023-11-17 07:09:23 --> UTF-8 Support Enabled
INFO - 2023-11-17 07:09:23 --> Utf8 Class Initialized
INFO - 2023-11-17 07:09:23 --> URI Class Initialized
DEBUG - 2023-11-17 07:09:23 --> No URI present. Default controller set.
INFO - 2023-11-17 07:09:23 --> Router Class Initialized
INFO - 2023-11-17 07:09:23 --> Output Class Initialized
INFO - 2023-11-17 07:09:23 --> Security Class Initialized
DEBUG - 2023-11-17 07:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 07:09:23 --> Input Class Initialized
INFO - 2023-11-17 07:09:23 --> Language Class Initialized
INFO - 2023-11-17 07:09:23 --> Loader Class Initialized
INFO - 2023-11-17 07:09:23 --> Helper loaded: url_helper
INFO - 2023-11-17 07:09:23 --> Helper loaded: file_helper
INFO - 2023-11-17 07:09:23 --> Helper loaded: html_helper
INFO - 2023-11-17 07:09:23 --> Helper loaded: text_helper
INFO - 2023-11-17 07:09:23 --> Helper loaded: form_helper
INFO - 2023-11-17 07:09:23 --> Helper loaded: lang_helper
INFO - 2023-11-17 07:09:23 --> Helper loaded: security_helper
INFO - 2023-11-17 07:09:23 --> Helper loaded: cookie_helper
INFO - 2023-11-17 07:09:23 --> Database Driver Class Initialized
INFO - 2023-11-17 07:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 07:09:23 --> Parser Class Initialized
INFO - 2023-11-17 07:09:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 07:09:23 --> Pagination Class Initialized
INFO - 2023-11-17 07:09:23 --> Form Validation Class Initialized
INFO - 2023-11-17 07:09:23 --> Controller Class Initialized
INFO - 2023-11-17 07:09:23 --> Model Class Initialized
DEBUG - 2023-11-17 07:09:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 07:09:23 --> Model Class Initialized
DEBUG - 2023-11-17 07:09:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 07:09:23 --> Model Class Initialized
INFO - 2023-11-17 07:09:23 --> Model Class Initialized
INFO - 2023-11-17 07:09:23 --> Model Class Initialized
INFO - 2023-11-17 07:09:23 --> Model Class Initialized
DEBUG - 2023-11-17 07:09:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 07:09:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 07:09:23 --> Model Class Initialized
INFO - 2023-11-17 07:09:23 --> Model Class Initialized
INFO - 2023-11-17 07:09:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-17 07:09:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 07:09:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 07:09:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 07:09:23 --> Model Class Initialized
INFO - 2023-11-17 07:09:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 07:09:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 07:09:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 07:09:23 --> Final output sent to browser
DEBUG - 2023-11-17 07:09:23 --> Total execution time: 0.3920
ERROR - 2023-11-17 07:09:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 07:09:41 --> Config Class Initialized
INFO - 2023-11-17 07:09:41 --> Hooks Class Initialized
DEBUG - 2023-11-17 07:09:41 --> UTF-8 Support Enabled
INFO - 2023-11-17 07:09:41 --> Utf8 Class Initialized
INFO - 2023-11-17 07:09:41 --> URI Class Initialized
DEBUG - 2023-11-17 07:09:41 --> No URI present. Default controller set.
INFO - 2023-11-17 07:09:41 --> Router Class Initialized
INFO - 2023-11-17 07:09:41 --> Output Class Initialized
INFO - 2023-11-17 07:09:41 --> Security Class Initialized
DEBUG - 2023-11-17 07:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 07:09:41 --> Input Class Initialized
INFO - 2023-11-17 07:09:41 --> Language Class Initialized
INFO - 2023-11-17 07:09:41 --> Loader Class Initialized
INFO - 2023-11-17 07:09:41 --> Helper loaded: url_helper
INFO - 2023-11-17 07:09:41 --> Helper loaded: file_helper
INFO - 2023-11-17 07:09:41 --> Helper loaded: html_helper
INFO - 2023-11-17 07:09:41 --> Helper loaded: text_helper
INFO - 2023-11-17 07:09:41 --> Helper loaded: form_helper
INFO - 2023-11-17 07:09:41 --> Helper loaded: lang_helper
INFO - 2023-11-17 07:09:41 --> Helper loaded: security_helper
INFO - 2023-11-17 07:09:41 --> Helper loaded: cookie_helper
INFO - 2023-11-17 07:09:41 --> Database Driver Class Initialized
INFO - 2023-11-17 07:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 07:09:41 --> Parser Class Initialized
INFO - 2023-11-17 07:09:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 07:09:41 --> Pagination Class Initialized
INFO - 2023-11-17 07:09:41 --> Form Validation Class Initialized
INFO - 2023-11-17 07:09:41 --> Controller Class Initialized
INFO - 2023-11-17 07:09:41 --> Model Class Initialized
DEBUG - 2023-11-17 07:09:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 07:09:41 --> Model Class Initialized
DEBUG - 2023-11-17 07:09:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 07:09:41 --> Model Class Initialized
INFO - 2023-11-17 07:09:41 --> Model Class Initialized
INFO - 2023-11-17 07:09:41 --> Model Class Initialized
INFO - 2023-11-17 07:09:41 --> Model Class Initialized
DEBUG - 2023-11-17 07:09:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 07:09:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 07:09:41 --> Model Class Initialized
INFO - 2023-11-17 07:09:41 --> Model Class Initialized
INFO - 2023-11-17 07:09:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-17 07:09:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 07:09:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 07:09:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 07:09:41 --> Model Class Initialized
INFO - 2023-11-17 07:09:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 07:09:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 07:09:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 07:09:42 --> Final output sent to browser
DEBUG - 2023-11-17 07:09:42 --> Total execution time: 0.3695
ERROR - 2023-11-17 07:10:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 07:10:02 --> Config Class Initialized
INFO - 2023-11-17 07:10:02 --> Hooks Class Initialized
DEBUG - 2023-11-17 07:10:02 --> UTF-8 Support Enabled
INFO - 2023-11-17 07:10:02 --> Utf8 Class Initialized
INFO - 2023-11-17 07:10:02 --> URI Class Initialized
INFO - 2023-11-17 07:10:02 --> Router Class Initialized
INFO - 2023-11-17 07:10:02 --> Output Class Initialized
INFO - 2023-11-17 07:10:02 --> Security Class Initialized
DEBUG - 2023-11-17 07:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 07:10:02 --> Input Class Initialized
INFO - 2023-11-17 07:10:02 --> Language Class Initialized
INFO - 2023-11-17 07:10:02 --> Loader Class Initialized
INFO - 2023-11-17 07:10:02 --> Helper loaded: url_helper
INFO - 2023-11-17 07:10:02 --> Helper loaded: file_helper
INFO - 2023-11-17 07:10:02 --> Helper loaded: html_helper
INFO - 2023-11-17 07:10:02 --> Helper loaded: text_helper
INFO - 2023-11-17 07:10:02 --> Helper loaded: form_helper
INFO - 2023-11-17 07:10:02 --> Helper loaded: lang_helper
INFO - 2023-11-17 07:10:02 --> Helper loaded: security_helper
INFO - 2023-11-17 07:10:02 --> Helper loaded: cookie_helper
INFO - 2023-11-17 07:10:02 --> Database Driver Class Initialized
INFO - 2023-11-17 07:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 07:10:02 --> Parser Class Initialized
INFO - 2023-11-17 07:10:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 07:10:02 --> Pagination Class Initialized
INFO - 2023-11-17 07:10:02 --> Form Validation Class Initialized
INFO - 2023-11-17 07:10:02 --> Controller Class Initialized
INFO - 2023-11-17 07:10:02 --> Model Class Initialized
DEBUG - 2023-11-17 07:10:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 07:10:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 07:10:02 --> Model Class Initialized
DEBUG - 2023-11-17 07:10:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 07:10:02 --> Model Class Initialized
INFO - 2023-11-17 07:10:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-11-17 07:10:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 07:10:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 07:10:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 07:10:02 --> Model Class Initialized
INFO - 2023-11-17 07:10:02 --> Model Class Initialized
INFO - 2023-11-17 07:10:02 --> Model Class Initialized
INFO - 2023-11-17 07:10:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 07:10:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 07:10:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 07:10:02 --> Final output sent to browser
DEBUG - 2023-11-17 07:10:02 --> Total execution time: 0.2314
ERROR - 2023-11-17 07:10:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 07:10:03 --> Config Class Initialized
INFO - 2023-11-17 07:10:03 --> Hooks Class Initialized
DEBUG - 2023-11-17 07:10:03 --> UTF-8 Support Enabled
INFO - 2023-11-17 07:10:03 --> Utf8 Class Initialized
INFO - 2023-11-17 07:10:03 --> URI Class Initialized
INFO - 2023-11-17 07:10:03 --> Router Class Initialized
INFO - 2023-11-17 07:10:03 --> Output Class Initialized
INFO - 2023-11-17 07:10:03 --> Security Class Initialized
DEBUG - 2023-11-17 07:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 07:10:03 --> Input Class Initialized
INFO - 2023-11-17 07:10:03 --> Language Class Initialized
INFO - 2023-11-17 07:10:03 --> Loader Class Initialized
INFO - 2023-11-17 07:10:03 --> Helper loaded: url_helper
INFO - 2023-11-17 07:10:03 --> Helper loaded: file_helper
INFO - 2023-11-17 07:10:03 --> Helper loaded: html_helper
INFO - 2023-11-17 07:10:03 --> Helper loaded: text_helper
INFO - 2023-11-17 07:10:03 --> Helper loaded: form_helper
INFO - 2023-11-17 07:10:03 --> Helper loaded: lang_helper
INFO - 2023-11-17 07:10:03 --> Helper loaded: security_helper
INFO - 2023-11-17 07:10:03 --> Helper loaded: cookie_helper
INFO - 2023-11-17 07:10:03 --> Database Driver Class Initialized
INFO - 2023-11-17 07:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 07:10:03 --> Parser Class Initialized
INFO - 2023-11-17 07:10:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 07:10:03 --> Pagination Class Initialized
INFO - 2023-11-17 07:10:03 --> Form Validation Class Initialized
INFO - 2023-11-17 07:10:03 --> Controller Class Initialized
INFO - 2023-11-17 07:10:03 --> Model Class Initialized
DEBUG - 2023-11-17 07:10:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 07:10:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 07:10:03 --> Model Class Initialized
DEBUG - 2023-11-17 07:10:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 07:10:03 --> Model Class Initialized
INFO - 2023-11-17 07:10:03 --> Final output sent to browser
DEBUG - 2023-11-17 07:10:03 --> Total execution time: 0.0585
ERROR - 2023-11-17 07:10:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 07:10:08 --> Config Class Initialized
INFO - 2023-11-17 07:10:08 --> Hooks Class Initialized
DEBUG - 2023-11-17 07:10:08 --> UTF-8 Support Enabled
INFO - 2023-11-17 07:10:08 --> Utf8 Class Initialized
INFO - 2023-11-17 07:10:08 --> URI Class Initialized
DEBUG - 2023-11-17 07:10:08 --> No URI present. Default controller set.
INFO - 2023-11-17 07:10:08 --> Router Class Initialized
INFO - 2023-11-17 07:10:08 --> Output Class Initialized
INFO - 2023-11-17 07:10:08 --> Security Class Initialized
DEBUG - 2023-11-17 07:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 07:10:08 --> Input Class Initialized
INFO - 2023-11-17 07:10:08 --> Language Class Initialized
INFO - 2023-11-17 07:10:08 --> Loader Class Initialized
INFO - 2023-11-17 07:10:08 --> Helper loaded: url_helper
INFO - 2023-11-17 07:10:08 --> Helper loaded: file_helper
INFO - 2023-11-17 07:10:08 --> Helper loaded: html_helper
INFO - 2023-11-17 07:10:08 --> Helper loaded: text_helper
INFO - 2023-11-17 07:10:08 --> Helper loaded: form_helper
INFO - 2023-11-17 07:10:08 --> Helper loaded: lang_helper
INFO - 2023-11-17 07:10:08 --> Helper loaded: security_helper
INFO - 2023-11-17 07:10:08 --> Helper loaded: cookie_helper
INFO - 2023-11-17 07:10:08 --> Database Driver Class Initialized
INFO - 2023-11-17 07:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 07:10:08 --> Parser Class Initialized
INFO - 2023-11-17 07:10:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 07:10:08 --> Pagination Class Initialized
INFO - 2023-11-17 07:10:08 --> Form Validation Class Initialized
INFO - 2023-11-17 07:10:08 --> Controller Class Initialized
INFO - 2023-11-17 07:10:08 --> Model Class Initialized
DEBUG - 2023-11-17 07:10:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 07:10:08 --> Model Class Initialized
DEBUG - 2023-11-17 07:10:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 07:10:08 --> Model Class Initialized
INFO - 2023-11-17 07:10:08 --> Model Class Initialized
INFO - 2023-11-17 07:10:08 --> Model Class Initialized
INFO - 2023-11-17 07:10:08 --> Model Class Initialized
DEBUG - 2023-11-17 07:10:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 07:10:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 07:10:08 --> Model Class Initialized
INFO - 2023-11-17 07:10:08 --> Model Class Initialized
INFO - 2023-11-17 07:10:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-17 07:10:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 07:10:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 07:10:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 07:10:09 --> Model Class Initialized
INFO - 2023-11-17 07:10:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 07:10:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 07:10:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 07:10:09 --> Final output sent to browser
DEBUG - 2023-11-17 07:10:09 --> Total execution time: 0.3722
ERROR - 2023-11-17 07:13:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 07:13:18 --> Config Class Initialized
INFO - 2023-11-17 07:13:18 --> Hooks Class Initialized
DEBUG - 2023-11-17 07:13:18 --> UTF-8 Support Enabled
INFO - 2023-11-17 07:13:18 --> Utf8 Class Initialized
INFO - 2023-11-17 07:13:18 --> URI Class Initialized
DEBUG - 2023-11-17 07:13:18 --> No URI present. Default controller set.
INFO - 2023-11-17 07:13:18 --> Router Class Initialized
INFO - 2023-11-17 07:13:18 --> Output Class Initialized
INFO - 2023-11-17 07:13:18 --> Security Class Initialized
DEBUG - 2023-11-17 07:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 07:13:18 --> Input Class Initialized
INFO - 2023-11-17 07:13:18 --> Language Class Initialized
INFO - 2023-11-17 07:13:18 --> Loader Class Initialized
INFO - 2023-11-17 07:13:18 --> Helper loaded: url_helper
INFO - 2023-11-17 07:13:18 --> Helper loaded: file_helper
INFO - 2023-11-17 07:13:18 --> Helper loaded: html_helper
INFO - 2023-11-17 07:13:18 --> Helper loaded: text_helper
INFO - 2023-11-17 07:13:18 --> Helper loaded: form_helper
INFO - 2023-11-17 07:13:18 --> Helper loaded: lang_helper
INFO - 2023-11-17 07:13:18 --> Helper loaded: security_helper
INFO - 2023-11-17 07:13:18 --> Helper loaded: cookie_helper
INFO - 2023-11-17 07:13:18 --> Database Driver Class Initialized
INFO - 2023-11-17 07:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 07:13:18 --> Parser Class Initialized
INFO - 2023-11-17 07:13:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 07:13:18 --> Pagination Class Initialized
INFO - 2023-11-17 07:13:18 --> Form Validation Class Initialized
INFO - 2023-11-17 07:13:18 --> Controller Class Initialized
INFO - 2023-11-17 07:13:18 --> Model Class Initialized
DEBUG - 2023-11-17 07:13:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 07:13:18 --> Model Class Initialized
DEBUG - 2023-11-17 07:13:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 07:13:18 --> Model Class Initialized
INFO - 2023-11-17 07:13:18 --> Model Class Initialized
INFO - 2023-11-17 07:13:18 --> Model Class Initialized
INFO - 2023-11-17 07:13:18 --> Model Class Initialized
DEBUG - 2023-11-17 07:13:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 07:13:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 07:13:18 --> Model Class Initialized
INFO - 2023-11-17 07:13:18 --> Model Class Initialized
INFO - 2023-11-17 07:13:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-17 07:13:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 07:13:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 07:13:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 07:13:18 --> Model Class Initialized
INFO - 2023-11-17 07:13:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 07:13:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 07:13:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 07:13:19 --> Final output sent to browser
DEBUG - 2023-11-17 07:13:19 --> Total execution time: 0.3608
ERROR - 2023-11-17 07:24:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 07:24:28 --> Config Class Initialized
INFO - 2023-11-17 07:24:28 --> Hooks Class Initialized
DEBUG - 2023-11-17 07:24:28 --> UTF-8 Support Enabled
INFO - 2023-11-17 07:24:28 --> Utf8 Class Initialized
INFO - 2023-11-17 07:24:28 --> URI Class Initialized
DEBUG - 2023-11-17 07:24:28 --> No URI present. Default controller set.
INFO - 2023-11-17 07:24:28 --> Router Class Initialized
INFO - 2023-11-17 07:24:28 --> Output Class Initialized
INFO - 2023-11-17 07:24:28 --> Security Class Initialized
DEBUG - 2023-11-17 07:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 07:24:28 --> Input Class Initialized
INFO - 2023-11-17 07:24:28 --> Language Class Initialized
INFO - 2023-11-17 07:24:28 --> Loader Class Initialized
INFO - 2023-11-17 07:24:28 --> Helper loaded: url_helper
INFO - 2023-11-17 07:24:28 --> Helper loaded: file_helper
INFO - 2023-11-17 07:24:28 --> Helper loaded: html_helper
INFO - 2023-11-17 07:24:28 --> Helper loaded: text_helper
INFO - 2023-11-17 07:24:28 --> Helper loaded: form_helper
INFO - 2023-11-17 07:24:28 --> Helper loaded: lang_helper
INFO - 2023-11-17 07:24:28 --> Helper loaded: security_helper
INFO - 2023-11-17 07:24:28 --> Helper loaded: cookie_helper
INFO - 2023-11-17 07:24:28 --> Database Driver Class Initialized
INFO - 2023-11-17 07:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 07:24:28 --> Parser Class Initialized
INFO - 2023-11-17 07:24:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 07:24:28 --> Pagination Class Initialized
INFO - 2023-11-17 07:24:28 --> Form Validation Class Initialized
INFO - 2023-11-17 07:24:28 --> Controller Class Initialized
INFO - 2023-11-17 07:24:28 --> Model Class Initialized
DEBUG - 2023-11-17 07:24:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 07:24:28 --> Model Class Initialized
DEBUG - 2023-11-17 07:24:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 07:24:28 --> Model Class Initialized
INFO - 2023-11-17 07:24:28 --> Model Class Initialized
INFO - 2023-11-17 07:24:28 --> Model Class Initialized
INFO - 2023-11-17 07:24:28 --> Model Class Initialized
DEBUG - 2023-11-17 07:24:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 07:24:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 07:24:28 --> Model Class Initialized
INFO - 2023-11-17 07:24:28 --> Model Class Initialized
INFO - 2023-11-17 07:24:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-17 07:24:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 07:24:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 07:24:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 07:24:28 --> Model Class Initialized
INFO - 2023-11-17 07:24:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 07:24:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 07:24:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 07:24:28 --> Final output sent to browser
DEBUG - 2023-11-17 07:24:28 --> Total execution time: 0.3722
ERROR - 2023-11-17 12:39:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 12:39:43 --> Config Class Initialized
INFO - 2023-11-17 12:39:43 --> Hooks Class Initialized
DEBUG - 2023-11-17 12:39:43 --> UTF-8 Support Enabled
INFO - 2023-11-17 12:39:43 --> Utf8 Class Initialized
INFO - 2023-11-17 12:39:43 --> URI Class Initialized
DEBUG - 2023-11-17 12:39:43 --> No URI present. Default controller set.
INFO - 2023-11-17 12:39:43 --> Router Class Initialized
INFO - 2023-11-17 12:39:43 --> Output Class Initialized
INFO - 2023-11-17 12:39:43 --> Security Class Initialized
DEBUG - 2023-11-17 12:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 12:39:43 --> Input Class Initialized
INFO - 2023-11-17 12:39:43 --> Language Class Initialized
INFO - 2023-11-17 12:39:43 --> Loader Class Initialized
INFO - 2023-11-17 12:39:43 --> Helper loaded: url_helper
INFO - 2023-11-17 12:39:43 --> Helper loaded: file_helper
INFO - 2023-11-17 12:39:43 --> Helper loaded: html_helper
INFO - 2023-11-17 12:39:43 --> Helper loaded: text_helper
INFO - 2023-11-17 12:39:43 --> Helper loaded: form_helper
INFO - 2023-11-17 12:39:43 --> Helper loaded: lang_helper
INFO - 2023-11-17 12:39:43 --> Helper loaded: security_helper
INFO - 2023-11-17 12:39:43 --> Helper loaded: cookie_helper
INFO - 2023-11-17 12:39:43 --> Database Driver Class Initialized
INFO - 2023-11-17 12:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 12:39:43 --> Parser Class Initialized
INFO - 2023-11-17 12:39:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 12:39:43 --> Pagination Class Initialized
INFO - 2023-11-17 12:39:43 --> Form Validation Class Initialized
INFO - 2023-11-17 12:39:43 --> Controller Class Initialized
INFO - 2023-11-17 12:39:43 --> Model Class Initialized
DEBUG - 2023-11-17 12:39:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-17 12:39:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 12:39:44 --> Config Class Initialized
INFO - 2023-11-17 12:39:44 --> Hooks Class Initialized
DEBUG - 2023-11-17 12:39:44 --> UTF-8 Support Enabled
INFO - 2023-11-17 12:39:44 --> Utf8 Class Initialized
INFO - 2023-11-17 12:39:44 --> URI Class Initialized
INFO - 2023-11-17 12:39:44 --> Router Class Initialized
INFO - 2023-11-17 12:39:44 --> Output Class Initialized
INFO - 2023-11-17 12:39:44 --> Security Class Initialized
DEBUG - 2023-11-17 12:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 12:39:44 --> Input Class Initialized
INFO - 2023-11-17 12:39:44 --> Language Class Initialized
INFO - 2023-11-17 12:39:44 --> Loader Class Initialized
INFO - 2023-11-17 12:39:44 --> Helper loaded: url_helper
INFO - 2023-11-17 12:39:44 --> Helper loaded: file_helper
INFO - 2023-11-17 12:39:44 --> Helper loaded: html_helper
INFO - 2023-11-17 12:39:44 --> Helper loaded: text_helper
INFO - 2023-11-17 12:39:44 --> Helper loaded: form_helper
INFO - 2023-11-17 12:39:44 --> Helper loaded: lang_helper
INFO - 2023-11-17 12:39:44 --> Helper loaded: security_helper
INFO - 2023-11-17 12:39:44 --> Helper loaded: cookie_helper
INFO - 2023-11-17 12:39:44 --> Database Driver Class Initialized
INFO - 2023-11-17 12:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 12:39:44 --> Parser Class Initialized
INFO - 2023-11-17 12:39:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 12:39:44 --> Pagination Class Initialized
INFO - 2023-11-17 12:39:44 --> Form Validation Class Initialized
INFO - 2023-11-17 12:39:44 --> Controller Class Initialized
INFO - 2023-11-17 12:39:44 --> Model Class Initialized
DEBUG - 2023-11-17 12:39:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 12:39:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-17 12:39:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 12:39:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 12:39:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 12:39:44 --> Model Class Initialized
INFO - 2023-11-17 12:39:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 12:39:44 --> Final output sent to browser
DEBUG - 2023-11-17 12:39:44 --> Total execution time: 0.0370
ERROR - 2023-11-17 16:36:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 16:36:45 --> Config Class Initialized
INFO - 2023-11-17 16:36:45 --> Hooks Class Initialized
DEBUG - 2023-11-17 16:36:45 --> UTF-8 Support Enabled
INFO - 2023-11-17 16:36:45 --> Utf8 Class Initialized
INFO - 2023-11-17 16:36:45 --> URI Class Initialized
INFO - 2023-11-17 16:36:45 --> Router Class Initialized
INFO - 2023-11-17 16:36:45 --> Output Class Initialized
INFO - 2023-11-17 16:36:45 --> Security Class Initialized
DEBUG - 2023-11-17 16:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 16:36:45 --> Input Class Initialized
INFO - 2023-11-17 16:36:45 --> Language Class Initialized
ERROR - 2023-11-17 16:36:45 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-11-17 16:43:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 16:43:25 --> Config Class Initialized
INFO - 2023-11-17 16:43:25 --> Hooks Class Initialized
DEBUG - 2023-11-17 16:43:25 --> UTF-8 Support Enabled
INFO - 2023-11-17 16:43:25 --> Utf8 Class Initialized
INFO - 2023-11-17 16:43:25 --> URI Class Initialized
DEBUG - 2023-11-17 16:43:25 --> No URI present. Default controller set.
INFO - 2023-11-17 16:43:25 --> Router Class Initialized
INFO - 2023-11-17 16:43:25 --> Output Class Initialized
INFO - 2023-11-17 16:43:25 --> Security Class Initialized
DEBUG - 2023-11-17 16:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 16:43:25 --> Input Class Initialized
INFO - 2023-11-17 16:43:25 --> Language Class Initialized
INFO - 2023-11-17 16:43:25 --> Loader Class Initialized
INFO - 2023-11-17 16:43:25 --> Helper loaded: url_helper
INFO - 2023-11-17 16:43:25 --> Helper loaded: file_helper
INFO - 2023-11-17 16:43:25 --> Helper loaded: html_helper
INFO - 2023-11-17 16:43:25 --> Helper loaded: text_helper
INFO - 2023-11-17 16:43:25 --> Helper loaded: form_helper
INFO - 2023-11-17 16:43:25 --> Helper loaded: lang_helper
INFO - 2023-11-17 16:43:25 --> Helper loaded: security_helper
INFO - 2023-11-17 16:43:25 --> Helper loaded: cookie_helper
INFO - 2023-11-17 16:43:25 --> Database Driver Class Initialized
INFO - 2023-11-17 16:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 16:43:25 --> Parser Class Initialized
INFO - 2023-11-17 16:43:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 16:43:25 --> Pagination Class Initialized
INFO - 2023-11-17 16:43:25 --> Form Validation Class Initialized
INFO - 2023-11-17 16:43:25 --> Controller Class Initialized
INFO - 2023-11-17 16:43:25 --> Model Class Initialized
DEBUG - 2023-11-17 16:43:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-17 16:43:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 16:43:26 --> Config Class Initialized
INFO - 2023-11-17 16:43:26 --> Hooks Class Initialized
DEBUG - 2023-11-17 16:43:26 --> UTF-8 Support Enabled
INFO - 2023-11-17 16:43:26 --> Utf8 Class Initialized
INFO - 2023-11-17 16:43:26 --> URI Class Initialized
INFO - 2023-11-17 16:43:26 --> Router Class Initialized
INFO - 2023-11-17 16:43:26 --> Output Class Initialized
INFO - 2023-11-17 16:43:26 --> Security Class Initialized
DEBUG - 2023-11-17 16:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 16:43:26 --> Input Class Initialized
INFO - 2023-11-17 16:43:26 --> Language Class Initialized
INFO - 2023-11-17 16:43:26 --> Loader Class Initialized
INFO - 2023-11-17 16:43:26 --> Helper loaded: url_helper
INFO - 2023-11-17 16:43:26 --> Helper loaded: file_helper
INFO - 2023-11-17 16:43:26 --> Helper loaded: html_helper
INFO - 2023-11-17 16:43:26 --> Helper loaded: text_helper
INFO - 2023-11-17 16:43:26 --> Helper loaded: form_helper
INFO - 2023-11-17 16:43:26 --> Helper loaded: lang_helper
INFO - 2023-11-17 16:43:26 --> Helper loaded: security_helper
INFO - 2023-11-17 16:43:26 --> Helper loaded: cookie_helper
INFO - 2023-11-17 16:43:26 --> Database Driver Class Initialized
INFO - 2023-11-17 16:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 16:43:26 --> Parser Class Initialized
INFO - 2023-11-17 16:43:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 16:43:26 --> Pagination Class Initialized
INFO - 2023-11-17 16:43:26 --> Form Validation Class Initialized
INFO - 2023-11-17 16:43:26 --> Controller Class Initialized
INFO - 2023-11-17 16:43:26 --> Model Class Initialized
DEBUG - 2023-11-17 16:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 16:43:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-17 16:43:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 16:43:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 16:43:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 16:43:26 --> Model Class Initialized
INFO - 2023-11-17 16:43:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 16:43:26 --> Final output sent to browser
DEBUG - 2023-11-17 16:43:26 --> Total execution time: 0.0316
ERROR - 2023-11-17 16:43:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 16:43:29 --> Config Class Initialized
INFO - 2023-11-17 16:43:29 --> Hooks Class Initialized
DEBUG - 2023-11-17 16:43:29 --> UTF-8 Support Enabled
INFO - 2023-11-17 16:43:29 --> Utf8 Class Initialized
INFO - 2023-11-17 16:43:29 --> URI Class Initialized
INFO - 2023-11-17 16:43:29 --> Router Class Initialized
INFO - 2023-11-17 16:43:29 --> Output Class Initialized
INFO - 2023-11-17 16:43:29 --> Security Class Initialized
DEBUG - 2023-11-17 16:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 16:43:29 --> Input Class Initialized
INFO - 2023-11-17 16:43:29 --> Language Class Initialized
INFO - 2023-11-17 16:43:29 --> Loader Class Initialized
INFO - 2023-11-17 16:43:29 --> Helper loaded: url_helper
INFO - 2023-11-17 16:43:29 --> Helper loaded: file_helper
INFO - 2023-11-17 16:43:29 --> Helper loaded: html_helper
INFO - 2023-11-17 16:43:29 --> Helper loaded: text_helper
INFO - 2023-11-17 16:43:29 --> Helper loaded: form_helper
INFO - 2023-11-17 16:43:29 --> Helper loaded: lang_helper
INFO - 2023-11-17 16:43:29 --> Helper loaded: security_helper
INFO - 2023-11-17 16:43:29 --> Helper loaded: cookie_helper
INFO - 2023-11-17 16:43:29 --> Database Driver Class Initialized
INFO - 2023-11-17 16:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 16:43:29 --> Parser Class Initialized
INFO - 2023-11-17 16:43:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 16:43:29 --> Pagination Class Initialized
INFO - 2023-11-17 16:43:29 --> Form Validation Class Initialized
INFO - 2023-11-17 16:43:29 --> Controller Class Initialized
INFO - 2023-11-17 16:43:29 --> Model Class Initialized
DEBUG - 2023-11-17 16:43:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 16:43:29 --> Model Class Initialized
INFO - 2023-11-17 16:43:29 --> Final output sent to browser
DEBUG - 2023-11-17 16:43:29 --> Total execution time: 0.0183
ERROR - 2023-11-17 16:43:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 16:43:29 --> Config Class Initialized
INFO - 2023-11-17 16:43:29 --> Hooks Class Initialized
DEBUG - 2023-11-17 16:43:29 --> UTF-8 Support Enabled
INFO - 2023-11-17 16:43:29 --> Utf8 Class Initialized
INFO - 2023-11-17 16:43:29 --> URI Class Initialized
DEBUG - 2023-11-17 16:43:29 --> No URI present. Default controller set.
INFO - 2023-11-17 16:43:29 --> Router Class Initialized
INFO - 2023-11-17 16:43:29 --> Output Class Initialized
INFO - 2023-11-17 16:43:29 --> Security Class Initialized
DEBUG - 2023-11-17 16:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 16:43:29 --> Input Class Initialized
INFO - 2023-11-17 16:43:29 --> Language Class Initialized
INFO - 2023-11-17 16:43:29 --> Loader Class Initialized
INFO - 2023-11-17 16:43:29 --> Helper loaded: url_helper
INFO - 2023-11-17 16:43:29 --> Helper loaded: file_helper
INFO - 2023-11-17 16:43:29 --> Helper loaded: html_helper
INFO - 2023-11-17 16:43:29 --> Helper loaded: text_helper
INFO - 2023-11-17 16:43:29 --> Helper loaded: form_helper
INFO - 2023-11-17 16:43:29 --> Helper loaded: lang_helper
INFO - 2023-11-17 16:43:29 --> Helper loaded: security_helper
INFO - 2023-11-17 16:43:29 --> Helper loaded: cookie_helper
INFO - 2023-11-17 16:43:29 --> Database Driver Class Initialized
INFO - 2023-11-17 16:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 16:43:29 --> Parser Class Initialized
INFO - 2023-11-17 16:43:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 16:43:29 --> Pagination Class Initialized
INFO - 2023-11-17 16:43:29 --> Form Validation Class Initialized
INFO - 2023-11-17 16:43:29 --> Controller Class Initialized
INFO - 2023-11-17 16:43:29 --> Model Class Initialized
DEBUG - 2023-11-17 16:43:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 16:43:29 --> Model Class Initialized
DEBUG - 2023-11-17 16:43:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 16:43:29 --> Model Class Initialized
INFO - 2023-11-17 16:43:29 --> Model Class Initialized
INFO - 2023-11-17 16:43:29 --> Model Class Initialized
INFO - 2023-11-17 16:43:29 --> Model Class Initialized
DEBUG - 2023-11-17 16:43:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 16:43:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 16:43:29 --> Model Class Initialized
INFO - 2023-11-17 16:43:29 --> Model Class Initialized
INFO - 2023-11-17 16:43:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-17 16:43:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 16:43:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 16:43:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 16:43:29 --> Model Class Initialized
INFO - 2023-11-17 16:43:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 16:43:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 16:43:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 16:43:29 --> Final output sent to browser
DEBUG - 2023-11-17 16:43:29 --> Total execution time: 0.3793
ERROR - 2023-11-17 16:43:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 16:43:30 --> Config Class Initialized
INFO - 2023-11-17 16:43:30 --> Hooks Class Initialized
DEBUG - 2023-11-17 16:43:30 --> UTF-8 Support Enabled
INFO - 2023-11-17 16:43:30 --> Utf8 Class Initialized
INFO - 2023-11-17 16:43:30 --> URI Class Initialized
INFO - 2023-11-17 16:43:30 --> Router Class Initialized
INFO - 2023-11-17 16:43:30 --> Output Class Initialized
INFO - 2023-11-17 16:43:30 --> Security Class Initialized
DEBUG - 2023-11-17 16:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 16:43:30 --> Input Class Initialized
INFO - 2023-11-17 16:43:30 --> Language Class Initialized
INFO - 2023-11-17 16:43:30 --> Loader Class Initialized
INFO - 2023-11-17 16:43:30 --> Helper loaded: url_helper
INFO - 2023-11-17 16:43:30 --> Helper loaded: file_helper
INFO - 2023-11-17 16:43:30 --> Helper loaded: html_helper
INFO - 2023-11-17 16:43:30 --> Helper loaded: text_helper
INFO - 2023-11-17 16:43:30 --> Helper loaded: form_helper
INFO - 2023-11-17 16:43:30 --> Helper loaded: lang_helper
INFO - 2023-11-17 16:43:30 --> Helper loaded: security_helper
INFO - 2023-11-17 16:43:30 --> Helper loaded: cookie_helper
INFO - 2023-11-17 16:43:30 --> Database Driver Class Initialized
INFO - 2023-11-17 16:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 16:43:30 --> Parser Class Initialized
INFO - 2023-11-17 16:43:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 16:43:30 --> Pagination Class Initialized
INFO - 2023-11-17 16:43:30 --> Form Validation Class Initialized
INFO - 2023-11-17 16:43:30 --> Controller Class Initialized
DEBUG - 2023-11-17 16:43:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 16:43:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 16:43:30 --> Model Class Initialized
INFO - 2023-11-17 16:43:30 --> Final output sent to browser
DEBUG - 2023-11-17 16:43:30 --> Total execution time: 0.0163
ERROR - 2023-11-17 16:47:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 16:47:12 --> Config Class Initialized
INFO - 2023-11-17 16:47:12 --> Hooks Class Initialized
DEBUG - 2023-11-17 16:47:12 --> UTF-8 Support Enabled
INFO - 2023-11-17 16:47:12 --> Utf8 Class Initialized
INFO - 2023-11-17 16:47:12 --> URI Class Initialized
DEBUG - 2023-11-17 16:47:12 --> No URI present. Default controller set.
INFO - 2023-11-17 16:47:12 --> Router Class Initialized
INFO - 2023-11-17 16:47:12 --> Output Class Initialized
INFO - 2023-11-17 16:47:12 --> Security Class Initialized
DEBUG - 2023-11-17 16:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 16:47:12 --> Input Class Initialized
INFO - 2023-11-17 16:47:12 --> Language Class Initialized
INFO - 2023-11-17 16:47:12 --> Loader Class Initialized
INFO - 2023-11-17 16:47:12 --> Helper loaded: url_helper
INFO - 2023-11-17 16:47:12 --> Helper loaded: file_helper
INFO - 2023-11-17 16:47:12 --> Helper loaded: html_helper
INFO - 2023-11-17 16:47:12 --> Helper loaded: text_helper
INFO - 2023-11-17 16:47:12 --> Helper loaded: form_helper
INFO - 2023-11-17 16:47:12 --> Helper loaded: lang_helper
INFO - 2023-11-17 16:47:12 --> Helper loaded: security_helper
INFO - 2023-11-17 16:47:12 --> Helper loaded: cookie_helper
INFO - 2023-11-17 16:47:12 --> Database Driver Class Initialized
INFO - 2023-11-17 16:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 16:47:12 --> Parser Class Initialized
INFO - 2023-11-17 16:47:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 16:47:12 --> Pagination Class Initialized
INFO - 2023-11-17 16:47:12 --> Form Validation Class Initialized
INFO - 2023-11-17 16:47:12 --> Controller Class Initialized
INFO - 2023-11-17 16:47:12 --> Model Class Initialized
DEBUG - 2023-11-17 16:47:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 16:47:12 --> Model Class Initialized
DEBUG - 2023-11-17 16:47:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 16:47:12 --> Model Class Initialized
INFO - 2023-11-17 16:47:12 --> Model Class Initialized
INFO - 2023-11-17 16:47:12 --> Model Class Initialized
INFO - 2023-11-17 16:47:12 --> Model Class Initialized
DEBUG - 2023-11-17 16:47:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 16:47:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 16:47:12 --> Model Class Initialized
INFO - 2023-11-17 16:47:12 --> Model Class Initialized
INFO - 2023-11-17 16:47:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-17 16:47:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 16:47:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 16:47:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 16:47:12 --> Model Class Initialized
INFO - 2023-11-17 16:47:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-17 16:47:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-17 16:47:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 16:47:13 --> Final output sent to browser
DEBUG - 2023-11-17 16:47:13 --> Total execution time: 0.4036
ERROR - 2023-11-17 17:46:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 17:46:45 --> Config Class Initialized
INFO - 2023-11-17 17:46:45 --> Hooks Class Initialized
DEBUG - 2023-11-17 17:46:45 --> UTF-8 Support Enabled
INFO - 2023-11-17 17:46:45 --> Utf8 Class Initialized
INFO - 2023-11-17 17:46:45 --> URI Class Initialized
DEBUG - 2023-11-17 17:46:45 --> No URI present. Default controller set.
INFO - 2023-11-17 17:46:45 --> Router Class Initialized
INFO - 2023-11-17 17:46:45 --> Output Class Initialized
INFO - 2023-11-17 17:46:45 --> Security Class Initialized
DEBUG - 2023-11-17 17:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 17:46:45 --> Input Class Initialized
INFO - 2023-11-17 17:46:45 --> Language Class Initialized
INFO - 2023-11-17 17:46:45 --> Loader Class Initialized
INFO - 2023-11-17 17:46:45 --> Helper loaded: url_helper
INFO - 2023-11-17 17:46:45 --> Helper loaded: file_helper
INFO - 2023-11-17 17:46:45 --> Helper loaded: html_helper
INFO - 2023-11-17 17:46:45 --> Helper loaded: text_helper
INFO - 2023-11-17 17:46:45 --> Helper loaded: form_helper
INFO - 2023-11-17 17:46:45 --> Helper loaded: lang_helper
INFO - 2023-11-17 17:46:45 --> Helper loaded: security_helper
INFO - 2023-11-17 17:46:45 --> Helper loaded: cookie_helper
INFO - 2023-11-17 17:46:45 --> Database Driver Class Initialized
INFO - 2023-11-17 17:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 17:46:45 --> Parser Class Initialized
INFO - 2023-11-17 17:46:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 17:46:45 --> Pagination Class Initialized
INFO - 2023-11-17 17:46:45 --> Form Validation Class Initialized
INFO - 2023-11-17 17:46:45 --> Controller Class Initialized
INFO - 2023-11-17 17:46:45 --> Model Class Initialized
DEBUG - 2023-11-17 17:46:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-17 17:46:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-17 17:46:45 --> Config Class Initialized
INFO - 2023-11-17 17:46:45 --> Hooks Class Initialized
DEBUG - 2023-11-17 17:46:45 --> UTF-8 Support Enabled
INFO - 2023-11-17 17:46:45 --> Utf8 Class Initialized
INFO - 2023-11-17 17:46:45 --> URI Class Initialized
INFO - 2023-11-17 17:46:45 --> Router Class Initialized
INFO - 2023-11-17 17:46:45 --> Output Class Initialized
INFO - 2023-11-17 17:46:45 --> Security Class Initialized
DEBUG - 2023-11-17 17:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 17:46:45 --> Input Class Initialized
INFO - 2023-11-17 17:46:45 --> Language Class Initialized
INFO - 2023-11-17 17:46:45 --> Loader Class Initialized
INFO - 2023-11-17 17:46:45 --> Helper loaded: url_helper
INFO - 2023-11-17 17:46:45 --> Helper loaded: file_helper
INFO - 2023-11-17 17:46:45 --> Helper loaded: html_helper
INFO - 2023-11-17 17:46:45 --> Helper loaded: text_helper
INFO - 2023-11-17 17:46:45 --> Helper loaded: form_helper
INFO - 2023-11-17 17:46:45 --> Helper loaded: lang_helper
INFO - 2023-11-17 17:46:45 --> Helper loaded: security_helper
INFO - 2023-11-17 17:46:45 --> Helper loaded: cookie_helper
INFO - 2023-11-17 17:46:45 --> Database Driver Class Initialized
INFO - 2023-11-17 17:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 17:46:46 --> Parser Class Initialized
INFO - 2023-11-17 17:46:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-17 17:46:46 --> Pagination Class Initialized
INFO - 2023-11-17 17:46:46 --> Form Validation Class Initialized
INFO - 2023-11-17 17:46:46 --> Controller Class Initialized
INFO - 2023-11-17 17:46:46 --> Model Class Initialized
DEBUG - 2023-11-17 17:46:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-17 17:46:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-17 17:46:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-17 17:46:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-17 17:46:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-17 17:46:46 --> Model Class Initialized
INFO - 2023-11-17 17:46:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-17 17:46:46 --> Final output sent to browser
DEBUG - 2023-11-17 17:46:46 --> Total execution time: 0.0280
