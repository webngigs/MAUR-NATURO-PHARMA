<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-02-12 04:43:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 04:43:07 --> Config Class Initialized
INFO - 2024-02-12 04:43:07 --> Hooks Class Initialized
DEBUG - 2024-02-12 04:43:07 --> UTF-8 Support Enabled
INFO - 2024-02-12 04:43:07 --> Utf8 Class Initialized
INFO - 2024-02-12 04:43:07 --> URI Class Initialized
DEBUG - 2024-02-12 04:43:07 --> No URI present. Default controller set.
INFO - 2024-02-12 04:43:07 --> Router Class Initialized
INFO - 2024-02-12 04:43:07 --> Output Class Initialized
INFO - 2024-02-12 04:43:07 --> Security Class Initialized
DEBUG - 2024-02-12 04:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 04:43:07 --> Input Class Initialized
INFO - 2024-02-12 04:43:07 --> Language Class Initialized
INFO - 2024-02-12 04:43:07 --> Loader Class Initialized
INFO - 2024-02-12 04:43:07 --> Helper loaded: url_helper
INFO - 2024-02-12 04:43:07 --> Helper loaded: file_helper
INFO - 2024-02-12 04:43:07 --> Helper loaded: html_helper
INFO - 2024-02-12 04:43:07 --> Helper loaded: text_helper
INFO - 2024-02-12 04:43:07 --> Helper loaded: form_helper
INFO - 2024-02-12 04:43:07 --> Helper loaded: lang_helper
INFO - 2024-02-12 04:43:07 --> Helper loaded: security_helper
INFO - 2024-02-12 04:43:07 --> Helper loaded: cookie_helper
INFO - 2024-02-12 04:43:07 --> Database Driver Class Initialized
INFO - 2024-02-12 04:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 04:43:07 --> Parser Class Initialized
INFO - 2024-02-12 04:43:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 04:43:07 --> Pagination Class Initialized
INFO - 2024-02-12 04:43:07 --> Form Validation Class Initialized
INFO - 2024-02-12 04:43:07 --> Controller Class Initialized
INFO - 2024-02-12 04:43:07 --> Model Class Initialized
DEBUG - 2024-02-12 04:43:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-12 04:43:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 04:43:08 --> Config Class Initialized
INFO - 2024-02-12 04:43:08 --> Hooks Class Initialized
DEBUG - 2024-02-12 04:43:08 --> UTF-8 Support Enabled
INFO - 2024-02-12 04:43:08 --> Utf8 Class Initialized
INFO - 2024-02-12 04:43:08 --> URI Class Initialized
INFO - 2024-02-12 04:43:08 --> Router Class Initialized
INFO - 2024-02-12 04:43:08 --> Output Class Initialized
INFO - 2024-02-12 04:43:08 --> Security Class Initialized
DEBUG - 2024-02-12 04:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 04:43:08 --> Input Class Initialized
INFO - 2024-02-12 04:43:08 --> Language Class Initialized
INFO - 2024-02-12 04:43:08 --> Loader Class Initialized
INFO - 2024-02-12 04:43:08 --> Helper loaded: url_helper
INFO - 2024-02-12 04:43:08 --> Helper loaded: file_helper
INFO - 2024-02-12 04:43:08 --> Helper loaded: html_helper
INFO - 2024-02-12 04:43:08 --> Helper loaded: text_helper
INFO - 2024-02-12 04:43:08 --> Helper loaded: form_helper
INFO - 2024-02-12 04:43:08 --> Helper loaded: lang_helper
INFO - 2024-02-12 04:43:08 --> Helper loaded: security_helper
INFO - 2024-02-12 04:43:08 --> Helper loaded: cookie_helper
INFO - 2024-02-12 04:43:08 --> Database Driver Class Initialized
INFO - 2024-02-12 04:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 04:43:08 --> Parser Class Initialized
INFO - 2024-02-12 04:43:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 04:43:08 --> Pagination Class Initialized
INFO - 2024-02-12 04:43:08 --> Form Validation Class Initialized
INFO - 2024-02-12 04:43:08 --> Controller Class Initialized
INFO - 2024-02-12 04:43:08 --> Model Class Initialized
DEBUG - 2024-02-12 04:43:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 04:43:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-12 04:43:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 04:43:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 04:43:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 04:43:08 --> Model Class Initialized
INFO - 2024-02-12 04:43:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 04:43:08 --> Final output sent to browser
DEBUG - 2024-02-12 04:43:08 --> Total execution time: 0.0349
ERROR - 2024-02-12 04:43:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 04:43:21 --> Config Class Initialized
INFO - 2024-02-12 04:43:21 --> Hooks Class Initialized
DEBUG - 2024-02-12 04:43:21 --> UTF-8 Support Enabled
INFO - 2024-02-12 04:43:21 --> Utf8 Class Initialized
INFO - 2024-02-12 04:43:21 --> URI Class Initialized
INFO - 2024-02-12 04:43:21 --> Router Class Initialized
INFO - 2024-02-12 04:43:21 --> Output Class Initialized
INFO - 2024-02-12 04:43:21 --> Security Class Initialized
DEBUG - 2024-02-12 04:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 04:43:21 --> Input Class Initialized
INFO - 2024-02-12 04:43:21 --> Language Class Initialized
INFO - 2024-02-12 04:43:21 --> Loader Class Initialized
INFO - 2024-02-12 04:43:21 --> Helper loaded: url_helper
INFO - 2024-02-12 04:43:21 --> Helper loaded: file_helper
INFO - 2024-02-12 04:43:21 --> Helper loaded: html_helper
INFO - 2024-02-12 04:43:21 --> Helper loaded: text_helper
INFO - 2024-02-12 04:43:21 --> Helper loaded: form_helper
INFO - 2024-02-12 04:43:21 --> Helper loaded: lang_helper
INFO - 2024-02-12 04:43:21 --> Helper loaded: security_helper
INFO - 2024-02-12 04:43:21 --> Helper loaded: cookie_helper
INFO - 2024-02-12 04:43:21 --> Database Driver Class Initialized
INFO - 2024-02-12 04:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 04:43:21 --> Parser Class Initialized
INFO - 2024-02-12 04:43:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 04:43:21 --> Pagination Class Initialized
INFO - 2024-02-12 04:43:21 --> Form Validation Class Initialized
INFO - 2024-02-12 04:43:21 --> Controller Class Initialized
INFO - 2024-02-12 04:43:21 --> Model Class Initialized
DEBUG - 2024-02-12 04:43:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 04:43:21 --> Model Class Initialized
INFO - 2024-02-12 04:43:21 --> Final output sent to browser
DEBUG - 2024-02-12 04:43:21 --> Total execution time: 0.0217
ERROR - 2024-02-12 04:43:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 04:43:21 --> Config Class Initialized
INFO - 2024-02-12 04:43:21 --> Hooks Class Initialized
DEBUG - 2024-02-12 04:43:21 --> UTF-8 Support Enabled
INFO - 2024-02-12 04:43:21 --> Utf8 Class Initialized
INFO - 2024-02-12 04:43:21 --> URI Class Initialized
DEBUG - 2024-02-12 04:43:21 --> No URI present. Default controller set.
INFO - 2024-02-12 04:43:21 --> Router Class Initialized
INFO - 2024-02-12 04:43:21 --> Output Class Initialized
INFO - 2024-02-12 04:43:21 --> Security Class Initialized
DEBUG - 2024-02-12 04:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 04:43:21 --> Input Class Initialized
INFO - 2024-02-12 04:43:21 --> Language Class Initialized
INFO - 2024-02-12 04:43:21 --> Loader Class Initialized
INFO - 2024-02-12 04:43:21 --> Helper loaded: url_helper
INFO - 2024-02-12 04:43:21 --> Helper loaded: file_helper
INFO - 2024-02-12 04:43:21 --> Helper loaded: html_helper
INFO - 2024-02-12 04:43:21 --> Helper loaded: text_helper
INFO - 2024-02-12 04:43:21 --> Helper loaded: form_helper
INFO - 2024-02-12 04:43:21 --> Helper loaded: lang_helper
INFO - 2024-02-12 04:43:21 --> Helper loaded: security_helper
INFO - 2024-02-12 04:43:21 --> Helper loaded: cookie_helper
INFO - 2024-02-12 04:43:21 --> Database Driver Class Initialized
INFO - 2024-02-12 04:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 04:43:21 --> Parser Class Initialized
INFO - 2024-02-12 04:43:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 04:43:21 --> Pagination Class Initialized
INFO - 2024-02-12 04:43:21 --> Form Validation Class Initialized
INFO - 2024-02-12 04:43:21 --> Controller Class Initialized
INFO - 2024-02-12 04:43:21 --> Model Class Initialized
DEBUG - 2024-02-12 04:43:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 04:43:21 --> Model Class Initialized
DEBUG - 2024-02-12 04:43:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 04:43:21 --> Model Class Initialized
INFO - 2024-02-12 04:43:21 --> Model Class Initialized
INFO - 2024-02-12 04:43:21 --> Model Class Initialized
INFO - 2024-02-12 04:43:21 --> Model Class Initialized
DEBUG - 2024-02-12 04:43:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 04:43:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 04:43:21 --> Model Class Initialized
INFO - 2024-02-12 04:43:21 --> Model Class Initialized
INFO - 2024-02-12 04:43:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-12 04:43:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 04:43:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 04:43:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 04:43:22 --> Model Class Initialized
INFO - 2024-02-12 04:43:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 04:43:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 04:43:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 04:43:22 --> Final output sent to browser
DEBUG - 2024-02-12 04:43:22 --> Total execution time: 0.2702
ERROR - 2024-02-12 04:43:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 04:43:39 --> Config Class Initialized
INFO - 2024-02-12 04:43:39 --> Hooks Class Initialized
DEBUG - 2024-02-12 04:43:39 --> UTF-8 Support Enabled
INFO - 2024-02-12 04:43:39 --> Utf8 Class Initialized
INFO - 2024-02-12 04:43:39 --> URI Class Initialized
INFO - 2024-02-12 04:43:39 --> Router Class Initialized
INFO - 2024-02-12 04:43:39 --> Output Class Initialized
INFO - 2024-02-12 04:43:39 --> Security Class Initialized
DEBUG - 2024-02-12 04:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 04:43:39 --> Input Class Initialized
INFO - 2024-02-12 04:43:39 --> Language Class Initialized
INFO - 2024-02-12 04:43:39 --> Loader Class Initialized
INFO - 2024-02-12 04:43:39 --> Helper loaded: url_helper
INFO - 2024-02-12 04:43:39 --> Helper loaded: file_helper
INFO - 2024-02-12 04:43:39 --> Helper loaded: html_helper
INFO - 2024-02-12 04:43:39 --> Helper loaded: text_helper
INFO - 2024-02-12 04:43:39 --> Helper loaded: form_helper
INFO - 2024-02-12 04:43:39 --> Helper loaded: lang_helper
INFO - 2024-02-12 04:43:39 --> Helper loaded: security_helper
INFO - 2024-02-12 04:43:39 --> Helper loaded: cookie_helper
INFO - 2024-02-12 04:43:39 --> Database Driver Class Initialized
INFO - 2024-02-12 04:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 04:43:39 --> Parser Class Initialized
INFO - 2024-02-12 04:43:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 04:43:39 --> Pagination Class Initialized
INFO - 2024-02-12 04:43:39 --> Form Validation Class Initialized
INFO - 2024-02-12 04:43:39 --> Controller Class Initialized
INFO - 2024-02-12 04:43:39 --> Model Class Initialized
DEBUG - 2024-02-12 04:43:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 04:43:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 04:43:39 --> Model Class Initialized
DEBUG - 2024-02-12 04:43:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 04:43:39 --> Model Class Initialized
INFO - 2024-02-12 04:43:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2024-02-12 04:43:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 04:43:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 04:43:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 04:43:39 --> Model Class Initialized
INFO - 2024-02-12 04:43:39 --> Model Class Initialized
INFO - 2024-02-12 04:43:39 --> Model Class Initialized
INFO - 2024-02-12 04:43:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 04:43:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 04:43:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 04:43:39 --> Final output sent to browser
DEBUG - 2024-02-12 04:43:39 --> Total execution time: 0.1706
ERROR - 2024-02-12 04:43:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 04:43:39 --> Config Class Initialized
INFO - 2024-02-12 04:43:39 --> Hooks Class Initialized
DEBUG - 2024-02-12 04:43:39 --> UTF-8 Support Enabled
INFO - 2024-02-12 04:43:39 --> Utf8 Class Initialized
INFO - 2024-02-12 04:43:39 --> URI Class Initialized
INFO - 2024-02-12 04:43:39 --> Router Class Initialized
INFO - 2024-02-12 04:43:39 --> Output Class Initialized
INFO - 2024-02-12 04:43:39 --> Security Class Initialized
DEBUG - 2024-02-12 04:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 04:43:39 --> Input Class Initialized
INFO - 2024-02-12 04:43:39 --> Language Class Initialized
INFO - 2024-02-12 04:43:39 --> Loader Class Initialized
INFO - 2024-02-12 04:43:39 --> Helper loaded: url_helper
INFO - 2024-02-12 04:43:39 --> Helper loaded: file_helper
INFO - 2024-02-12 04:43:39 --> Helper loaded: html_helper
INFO - 2024-02-12 04:43:39 --> Helper loaded: text_helper
INFO - 2024-02-12 04:43:39 --> Helper loaded: form_helper
INFO - 2024-02-12 04:43:39 --> Helper loaded: lang_helper
INFO - 2024-02-12 04:43:39 --> Helper loaded: security_helper
INFO - 2024-02-12 04:43:39 --> Helper loaded: cookie_helper
INFO - 2024-02-12 04:43:39 --> Database Driver Class Initialized
INFO - 2024-02-12 04:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 04:43:39 --> Parser Class Initialized
INFO - 2024-02-12 04:43:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 04:43:40 --> Pagination Class Initialized
INFO - 2024-02-12 04:43:40 --> Form Validation Class Initialized
INFO - 2024-02-12 04:43:40 --> Controller Class Initialized
INFO - 2024-02-12 04:43:40 --> Model Class Initialized
DEBUG - 2024-02-12 04:43:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 04:43:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 04:43:40 --> Model Class Initialized
DEBUG - 2024-02-12 04:43:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 04:43:40 --> Model Class Initialized
INFO - 2024-02-12 04:43:40 --> Final output sent to browser
DEBUG - 2024-02-12 04:43:40 --> Total execution time: 0.0518
ERROR - 2024-02-12 04:43:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 04:43:49 --> Config Class Initialized
INFO - 2024-02-12 04:43:49 --> Hooks Class Initialized
DEBUG - 2024-02-12 04:43:49 --> UTF-8 Support Enabled
INFO - 2024-02-12 04:43:49 --> Utf8 Class Initialized
INFO - 2024-02-12 04:43:49 --> URI Class Initialized
DEBUG - 2024-02-12 04:43:49 --> No URI present. Default controller set.
INFO - 2024-02-12 04:43:49 --> Router Class Initialized
INFO - 2024-02-12 04:43:49 --> Output Class Initialized
INFO - 2024-02-12 04:43:49 --> Security Class Initialized
DEBUG - 2024-02-12 04:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 04:43:49 --> Input Class Initialized
INFO - 2024-02-12 04:43:49 --> Language Class Initialized
INFO - 2024-02-12 04:43:49 --> Loader Class Initialized
INFO - 2024-02-12 04:43:49 --> Helper loaded: url_helper
INFO - 2024-02-12 04:43:49 --> Helper loaded: file_helper
INFO - 2024-02-12 04:43:49 --> Helper loaded: html_helper
INFO - 2024-02-12 04:43:49 --> Helper loaded: text_helper
INFO - 2024-02-12 04:43:49 --> Helper loaded: form_helper
INFO - 2024-02-12 04:43:49 --> Helper loaded: lang_helper
INFO - 2024-02-12 04:43:49 --> Helper loaded: security_helper
INFO - 2024-02-12 04:43:49 --> Helper loaded: cookie_helper
INFO - 2024-02-12 04:43:49 --> Database Driver Class Initialized
INFO - 2024-02-12 04:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 04:43:49 --> Parser Class Initialized
INFO - 2024-02-12 04:43:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 04:43:49 --> Pagination Class Initialized
INFO - 2024-02-12 04:43:49 --> Form Validation Class Initialized
INFO - 2024-02-12 04:43:49 --> Controller Class Initialized
INFO - 2024-02-12 04:43:49 --> Model Class Initialized
DEBUG - 2024-02-12 04:43:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 04:43:49 --> Model Class Initialized
DEBUG - 2024-02-12 04:43:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 04:43:49 --> Model Class Initialized
INFO - 2024-02-12 04:43:49 --> Model Class Initialized
INFO - 2024-02-12 04:43:49 --> Model Class Initialized
INFO - 2024-02-12 04:43:49 --> Model Class Initialized
DEBUG - 2024-02-12 04:43:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 04:43:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 04:43:49 --> Model Class Initialized
INFO - 2024-02-12 04:43:49 --> Model Class Initialized
INFO - 2024-02-12 04:43:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-12 04:43:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 04:43:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 04:43:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 04:43:49 --> Model Class Initialized
INFO - 2024-02-12 04:43:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 04:43:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 04:43:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 04:43:49 --> Final output sent to browser
DEBUG - 2024-02-12 04:43:49 --> Total execution time: 0.2276
ERROR - 2024-02-12 04:43:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 04:43:52 --> Config Class Initialized
INFO - 2024-02-12 04:43:52 --> Hooks Class Initialized
DEBUG - 2024-02-12 04:43:52 --> UTF-8 Support Enabled
INFO - 2024-02-12 04:43:52 --> Utf8 Class Initialized
INFO - 2024-02-12 04:43:52 --> URI Class Initialized
INFO - 2024-02-12 04:43:52 --> Router Class Initialized
INFO - 2024-02-12 04:43:52 --> Output Class Initialized
INFO - 2024-02-12 04:43:52 --> Security Class Initialized
DEBUG - 2024-02-12 04:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 04:43:52 --> Input Class Initialized
INFO - 2024-02-12 04:43:52 --> Language Class Initialized
INFO - 2024-02-12 04:43:52 --> Loader Class Initialized
INFO - 2024-02-12 04:43:52 --> Helper loaded: url_helper
INFO - 2024-02-12 04:43:52 --> Helper loaded: file_helper
INFO - 2024-02-12 04:43:52 --> Helper loaded: html_helper
INFO - 2024-02-12 04:43:52 --> Helper loaded: text_helper
INFO - 2024-02-12 04:43:52 --> Helper loaded: form_helper
INFO - 2024-02-12 04:43:52 --> Helper loaded: lang_helper
INFO - 2024-02-12 04:43:52 --> Helper loaded: security_helper
INFO - 2024-02-12 04:43:52 --> Helper loaded: cookie_helper
INFO - 2024-02-12 04:43:52 --> Database Driver Class Initialized
INFO - 2024-02-12 04:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 04:43:52 --> Parser Class Initialized
INFO - 2024-02-12 04:43:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 04:43:52 --> Pagination Class Initialized
INFO - 2024-02-12 04:43:52 --> Form Validation Class Initialized
INFO - 2024-02-12 04:43:52 --> Controller Class Initialized
INFO - 2024-02-12 04:43:52 --> Model Class Initialized
DEBUG - 2024-02-12 04:43:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 04:43:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 04:43:52 --> Model Class Initialized
DEBUG - 2024-02-12 04:43:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 04:43:52 --> Model Class Initialized
INFO - 2024-02-12 04:43:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-12 04:43:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 04:43:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 04:43:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 04:43:52 --> Model Class Initialized
INFO - 2024-02-12 04:43:52 --> Model Class Initialized
INFO - 2024-02-12 04:43:52 --> Model Class Initialized
INFO - 2024-02-12 04:43:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 04:43:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 04:43:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 04:43:52 --> Final output sent to browser
DEBUG - 2024-02-12 04:43:52 --> Total execution time: 0.1475
ERROR - 2024-02-12 04:43:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 04:43:53 --> Config Class Initialized
INFO - 2024-02-12 04:43:53 --> Hooks Class Initialized
DEBUG - 2024-02-12 04:43:53 --> UTF-8 Support Enabled
INFO - 2024-02-12 04:43:53 --> Utf8 Class Initialized
INFO - 2024-02-12 04:43:53 --> URI Class Initialized
INFO - 2024-02-12 04:43:53 --> Router Class Initialized
INFO - 2024-02-12 04:43:53 --> Output Class Initialized
INFO - 2024-02-12 04:43:53 --> Security Class Initialized
DEBUG - 2024-02-12 04:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 04:43:53 --> Input Class Initialized
INFO - 2024-02-12 04:43:53 --> Language Class Initialized
INFO - 2024-02-12 04:43:53 --> Loader Class Initialized
INFO - 2024-02-12 04:43:53 --> Helper loaded: url_helper
INFO - 2024-02-12 04:43:53 --> Helper loaded: file_helper
INFO - 2024-02-12 04:43:53 --> Helper loaded: html_helper
INFO - 2024-02-12 04:43:53 --> Helper loaded: text_helper
INFO - 2024-02-12 04:43:53 --> Helper loaded: form_helper
INFO - 2024-02-12 04:43:53 --> Helper loaded: lang_helper
INFO - 2024-02-12 04:43:53 --> Helper loaded: security_helper
INFO - 2024-02-12 04:43:53 --> Helper loaded: cookie_helper
INFO - 2024-02-12 04:43:53 --> Database Driver Class Initialized
INFO - 2024-02-12 04:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 04:43:53 --> Parser Class Initialized
INFO - 2024-02-12 04:43:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 04:43:53 --> Pagination Class Initialized
INFO - 2024-02-12 04:43:53 --> Form Validation Class Initialized
INFO - 2024-02-12 04:43:53 --> Controller Class Initialized
INFO - 2024-02-12 04:43:53 --> Model Class Initialized
DEBUG - 2024-02-12 04:43:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 04:43:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 04:43:53 --> Model Class Initialized
DEBUG - 2024-02-12 04:43:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 04:43:53 --> Model Class Initialized
INFO - 2024-02-12 04:43:53 --> Final output sent to browser
DEBUG - 2024-02-12 04:43:53 --> Total execution time: 0.0417
ERROR - 2024-02-12 04:43:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 04:43:59 --> Config Class Initialized
INFO - 2024-02-12 04:43:59 --> Hooks Class Initialized
DEBUG - 2024-02-12 04:43:59 --> UTF-8 Support Enabled
INFO - 2024-02-12 04:43:59 --> Utf8 Class Initialized
INFO - 2024-02-12 04:43:59 --> URI Class Initialized
INFO - 2024-02-12 04:43:59 --> Router Class Initialized
INFO - 2024-02-12 04:43:59 --> Output Class Initialized
INFO - 2024-02-12 04:43:59 --> Security Class Initialized
DEBUG - 2024-02-12 04:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 04:43:59 --> Input Class Initialized
INFO - 2024-02-12 04:43:59 --> Language Class Initialized
INFO - 2024-02-12 04:43:59 --> Loader Class Initialized
INFO - 2024-02-12 04:43:59 --> Helper loaded: url_helper
INFO - 2024-02-12 04:43:59 --> Helper loaded: file_helper
INFO - 2024-02-12 04:43:59 --> Helper loaded: html_helper
INFO - 2024-02-12 04:43:59 --> Helper loaded: text_helper
INFO - 2024-02-12 04:43:59 --> Helper loaded: form_helper
INFO - 2024-02-12 04:43:59 --> Helper loaded: lang_helper
INFO - 2024-02-12 04:43:59 --> Helper loaded: security_helper
INFO - 2024-02-12 04:43:59 --> Helper loaded: cookie_helper
INFO - 2024-02-12 04:43:59 --> Database Driver Class Initialized
INFO - 2024-02-12 04:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 04:43:59 --> Parser Class Initialized
INFO - 2024-02-12 04:43:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 04:43:59 --> Pagination Class Initialized
INFO - 2024-02-12 04:43:59 --> Form Validation Class Initialized
INFO - 2024-02-12 04:43:59 --> Controller Class Initialized
INFO - 2024-02-12 04:43:59 --> Model Class Initialized
DEBUG - 2024-02-12 04:43:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 04:43:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 04:43:59 --> Model Class Initialized
DEBUG - 2024-02-12 04:43:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 04:43:59 --> Model Class Initialized
INFO - 2024-02-12 04:43:59 --> Final output sent to browser
DEBUG - 2024-02-12 04:43:59 --> Total execution time: 0.0431
ERROR - 2024-02-12 04:44:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 04:44:00 --> Config Class Initialized
INFO - 2024-02-12 04:44:00 --> Hooks Class Initialized
DEBUG - 2024-02-12 04:44:00 --> UTF-8 Support Enabled
INFO - 2024-02-12 04:44:00 --> Utf8 Class Initialized
INFO - 2024-02-12 04:44:00 --> URI Class Initialized
INFO - 2024-02-12 04:44:00 --> Router Class Initialized
INFO - 2024-02-12 04:44:00 --> Output Class Initialized
INFO - 2024-02-12 04:44:00 --> Security Class Initialized
DEBUG - 2024-02-12 04:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 04:44:00 --> Input Class Initialized
INFO - 2024-02-12 04:44:00 --> Language Class Initialized
INFO - 2024-02-12 04:44:00 --> Loader Class Initialized
INFO - 2024-02-12 04:44:00 --> Helper loaded: url_helper
INFO - 2024-02-12 04:44:00 --> Helper loaded: file_helper
INFO - 2024-02-12 04:44:00 --> Helper loaded: html_helper
INFO - 2024-02-12 04:44:00 --> Helper loaded: text_helper
INFO - 2024-02-12 04:44:00 --> Helper loaded: form_helper
INFO - 2024-02-12 04:44:00 --> Helper loaded: lang_helper
INFO - 2024-02-12 04:44:00 --> Helper loaded: security_helper
INFO - 2024-02-12 04:44:00 --> Helper loaded: cookie_helper
INFO - 2024-02-12 04:44:00 --> Database Driver Class Initialized
INFO - 2024-02-12 04:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 04:44:00 --> Parser Class Initialized
INFO - 2024-02-12 04:44:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 04:44:00 --> Pagination Class Initialized
INFO - 2024-02-12 04:44:00 --> Form Validation Class Initialized
INFO - 2024-02-12 04:44:00 --> Controller Class Initialized
INFO - 2024-02-12 04:44:00 --> Model Class Initialized
DEBUG - 2024-02-12 04:44:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 04:44:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 04:44:00 --> Model Class Initialized
DEBUG - 2024-02-12 04:44:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 04:44:00 --> Model Class Initialized
INFO - 2024-02-12 04:44:00 --> Final output sent to browser
DEBUG - 2024-02-12 04:44:00 --> Total execution time: 0.0413
ERROR - 2024-02-12 04:44:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 04:44:00 --> Config Class Initialized
INFO - 2024-02-12 04:44:00 --> Hooks Class Initialized
DEBUG - 2024-02-12 04:44:00 --> UTF-8 Support Enabled
INFO - 2024-02-12 04:44:00 --> Utf8 Class Initialized
INFO - 2024-02-12 04:44:00 --> URI Class Initialized
INFO - 2024-02-12 04:44:00 --> Router Class Initialized
INFO - 2024-02-12 04:44:00 --> Output Class Initialized
INFO - 2024-02-12 04:44:00 --> Security Class Initialized
DEBUG - 2024-02-12 04:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 04:44:00 --> Input Class Initialized
INFO - 2024-02-12 04:44:00 --> Language Class Initialized
INFO - 2024-02-12 04:44:00 --> Loader Class Initialized
INFO - 2024-02-12 04:44:00 --> Helper loaded: url_helper
INFO - 2024-02-12 04:44:00 --> Helper loaded: file_helper
INFO - 2024-02-12 04:44:00 --> Helper loaded: html_helper
INFO - 2024-02-12 04:44:00 --> Helper loaded: text_helper
INFO - 2024-02-12 04:44:00 --> Helper loaded: form_helper
INFO - 2024-02-12 04:44:00 --> Helper loaded: lang_helper
INFO - 2024-02-12 04:44:00 --> Helper loaded: security_helper
INFO - 2024-02-12 04:44:00 --> Helper loaded: cookie_helper
INFO - 2024-02-12 04:44:00 --> Database Driver Class Initialized
INFO - 2024-02-12 04:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 04:44:00 --> Parser Class Initialized
INFO - 2024-02-12 04:44:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 04:44:00 --> Pagination Class Initialized
INFO - 2024-02-12 04:44:00 --> Form Validation Class Initialized
INFO - 2024-02-12 04:44:00 --> Controller Class Initialized
INFO - 2024-02-12 04:44:00 --> Model Class Initialized
DEBUG - 2024-02-12 04:44:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 04:44:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 04:44:00 --> Model Class Initialized
DEBUG - 2024-02-12 04:44:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 04:44:00 --> Model Class Initialized
INFO - 2024-02-12 04:44:00 --> Final output sent to browser
DEBUG - 2024-02-12 04:44:00 --> Total execution time: 0.0304
ERROR - 2024-02-12 04:44:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 04:44:01 --> Config Class Initialized
INFO - 2024-02-12 04:44:01 --> Hooks Class Initialized
DEBUG - 2024-02-12 04:44:01 --> UTF-8 Support Enabled
INFO - 2024-02-12 04:44:01 --> Utf8 Class Initialized
INFO - 2024-02-12 04:44:01 --> URI Class Initialized
INFO - 2024-02-12 04:44:01 --> Router Class Initialized
INFO - 2024-02-12 04:44:01 --> Output Class Initialized
INFO - 2024-02-12 04:44:01 --> Security Class Initialized
DEBUG - 2024-02-12 04:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 04:44:01 --> Input Class Initialized
INFO - 2024-02-12 04:44:01 --> Language Class Initialized
INFO - 2024-02-12 04:44:01 --> Loader Class Initialized
INFO - 2024-02-12 04:44:01 --> Helper loaded: url_helper
INFO - 2024-02-12 04:44:01 --> Helper loaded: file_helper
INFO - 2024-02-12 04:44:01 --> Helper loaded: html_helper
INFO - 2024-02-12 04:44:01 --> Helper loaded: text_helper
INFO - 2024-02-12 04:44:01 --> Helper loaded: form_helper
INFO - 2024-02-12 04:44:01 --> Helper loaded: lang_helper
INFO - 2024-02-12 04:44:01 --> Helper loaded: security_helper
INFO - 2024-02-12 04:44:01 --> Helper loaded: cookie_helper
INFO - 2024-02-12 04:44:01 --> Database Driver Class Initialized
INFO - 2024-02-12 04:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 04:44:01 --> Parser Class Initialized
INFO - 2024-02-12 04:44:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 04:44:01 --> Pagination Class Initialized
INFO - 2024-02-12 04:44:01 --> Form Validation Class Initialized
INFO - 2024-02-12 04:44:01 --> Controller Class Initialized
INFO - 2024-02-12 04:44:01 --> Model Class Initialized
DEBUG - 2024-02-12 04:44:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 04:44:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 04:44:01 --> Model Class Initialized
DEBUG - 2024-02-12 04:44:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 04:44:01 --> Model Class Initialized
INFO - 2024-02-12 04:44:01 --> Final output sent to browser
DEBUG - 2024-02-12 04:44:01 --> Total execution time: 0.0324
ERROR - 2024-02-12 04:44:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 04:44:25 --> Config Class Initialized
INFO - 2024-02-12 04:44:25 --> Hooks Class Initialized
DEBUG - 2024-02-12 04:44:25 --> UTF-8 Support Enabled
INFO - 2024-02-12 04:44:25 --> Utf8 Class Initialized
INFO - 2024-02-12 04:44:25 --> URI Class Initialized
DEBUG - 2024-02-12 04:44:25 --> No URI present. Default controller set.
INFO - 2024-02-12 04:44:25 --> Router Class Initialized
INFO - 2024-02-12 04:44:25 --> Output Class Initialized
INFO - 2024-02-12 04:44:25 --> Security Class Initialized
DEBUG - 2024-02-12 04:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 04:44:25 --> Input Class Initialized
INFO - 2024-02-12 04:44:25 --> Language Class Initialized
INFO - 2024-02-12 04:44:25 --> Loader Class Initialized
INFO - 2024-02-12 04:44:25 --> Helper loaded: url_helper
INFO - 2024-02-12 04:44:25 --> Helper loaded: file_helper
INFO - 2024-02-12 04:44:25 --> Helper loaded: html_helper
INFO - 2024-02-12 04:44:25 --> Helper loaded: text_helper
INFO - 2024-02-12 04:44:25 --> Helper loaded: form_helper
INFO - 2024-02-12 04:44:25 --> Helper loaded: lang_helper
INFO - 2024-02-12 04:44:25 --> Helper loaded: security_helper
INFO - 2024-02-12 04:44:25 --> Helper loaded: cookie_helper
INFO - 2024-02-12 04:44:25 --> Database Driver Class Initialized
INFO - 2024-02-12 04:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 04:44:25 --> Parser Class Initialized
INFO - 2024-02-12 04:44:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 04:44:25 --> Pagination Class Initialized
INFO - 2024-02-12 04:44:25 --> Form Validation Class Initialized
INFO - 2024-02-12 04:44:25 --> Controller Class Initialized
INFO - 2024-02-12 04:44:25 --> Model Class Initialized
DEBUG - 2024-02-12 04:44:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 04:44:25 --> Model Class Initialized
DEBUG - 2024-02-12 04:44:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 04:44:25 --> Model Class Initialized
INFO - 2024-02-12 04:44:25 --> Model Class Initialized
INFO - 2024-02-12 04:44:25 --> Model Class Initialized
INFO - 2024-02-12 04:44:25 --> Model Class Initialized
DEBUG - 2024-02-12 04:44:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 04:44:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 04:44:25 --> Model Class Initialized
INFO - 2024-02-12 04:44:25 --> Model Class Initialized
INFO - 2024-02-12 04:44:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-12 04:44:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 04:44:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 04:44:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 04:44:25 --> Model Class Initialized
INFO - 2024-02-12 04:44:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 04:44:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 04:44:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 04:44:25 --> Final output sent to browser
DEBUG - 2024-02-12 04:44:25 --> Total execution time: 0.2355
ERROR - 2024-02-12 04:44:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 04:44:29 --> Config Class Initialized
INFO - 2024-02-12 04:44:29 --> Hooks Class Initialized
DEBUG - 2024-02-12 04:44:29 --> UTF-8 Support Enabled
INFO - 2024-02-12 04:44:29 --> Utf8 Class Initialized
INFO - 2024-02-12 04:44:29 --> URI Class Initialized
INFO - 2024-02-12 04:44:29 --> Router Class Initialized
INFO - 2024-02-12 04:44:29 --> Output Class Initialized
INFO - 2024-02-12 04:44:29 --> Security Class Initialized
DEBUG - 2024-02-12 04:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 04:44:29 --> Input Class Initialized
INFO - 2024-02-12 04:44:29 --> Language Class Initialized
INFO - 2024-02-12 04:44:29 --> Loader Class Initialized
INFO - 2024-02-12 04:44:29 --> Helper loaded: url_helper
INFO - 2024-02-12 04:44:29 --> Helper loaded: file_helper
INFO - 2024-02-12 04:44:29 --> Helper loaded: html_helper
INFO - 2024-02-12 04:44:29 --> Helper loaded: text_helper
INFO - 2024-02-12 04:44:29 --> Helper loaded: form_helper
INFO - 2024-02-12 04:44:29 --> Helper loaded: lang_helper
INFO - 2024-02-12 04:44:29 --> Helper loaded: security_helper
INFO - 2024-02-12 04:44:29 --> Helper loaded: cookie_helper
INFO - 2024-02-12 04:44:29 --> Database Driver Class Initialized
INFO - 2024-02-12 04:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 04:44:29 --> Parser Class Initialized
INFO - 2024-02-12 04:44:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 04:44:29 --> Pagination Class Initialized
INFO - 2024-02-12 04:44:29 --> Form Validation Class Initialized
INFO - 2024-02-12 04:44:29 --> Controller Class Initialized
INFO - 2024-02-12 04:44:29 --> Model Class Initialized
DEBUG - 2024-02-12 04:44:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 04:44:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 04:44:29 --> Model Class Initialized
DEBUG - 2024-02-12 04:44:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 04:44:29 --> Model Class Initialized
INFO - 2024-02-12 04:44:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2024-02-12 04:44:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 04:44:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 04:44:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 04:44:29 --> Model Class Initialized
INFO - 2024-02-12 04:44:29 --> Model Class Initialized
INFO - 2024-02-12 04:44:29 --> Model Class Initialized
INFO - 2024-02-12 04:44:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 04:44:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 04:44:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 04:44:29 --> Final output sent to browser
DEBUG - 2024-02-12 04:44:29 --> Total execution time: 0.1480
ERROR - 2024-02-12 04:44:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 04:44:29 --> Config Class Initialized
INFO - 2024-02-12 04:44:29 --> Hooks Class Initialized
DEBUG - 2024-02-12 04:44:29 --> UTF-8 Support Enabled
INFO - 2024-02-12 04:44:29 --> Utf8 Class Initialized
INFO - 2024-02-12 04:44:29 --> URI Class Initialized
INFO - 2024-02-12 04:44:29 --> Router Class Initialized
INFO - 2024-02-12 04:44:29 --> Output Class Initialized
INFO - 2024-02-12 04:44:29 --> Security Class Initialized
DEBUG - 2024-02-12 04:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 04:44:29 --> Input Class Initialized
INFO - 2024-02-12 04:44:29 --> Language Class Initialized
INFO - 2024-02-12 04:44:29 --> Loader Class Initialized
INFO - 2024-02-12 04:44:29 --> Helper loaded: url_helper
INFO - 2024-02-12 04:44:29 --> Helper loaded: file_helper
INFO - 2024-02-12 04:44:29 --> Helper loaded: html_helper
INFO - 2024-02-12 04:44:29 --> Helper loaded: text_helper
INFO - 2024-02-12 04:44:29 --> Helper loaded: form_helper
INFO - 2024-02-12 04:44:29 --> Helper loaded: lang_helper
INFO - 2024-02-12 04:44:29 --> Helper loaded: security_helper
INFO - 2024-02-12 04:44:29 --> Helper loaded: cookie_helper
INFO - 2024-02-12 04:44:29 --> Database Driver Class Initialized
INFO - 2024-02-12 04:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 04:44:29 --> Parser Class Initialized
INFO - 2024-02-12 04:44:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 04:44:29 --> Pagination Class Initialized
INFO - 2024-02-12 04:44:29 --> Form Validation Class Initialized
INFO - 2024-02-12 04:44:29 --> Controller Class Initialized
INFO - 2024-02-12 04:44:29 --> Model Class Initialized
DEBUG - 2024-02-12 04:44:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 04:44:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 04:44:29 --> Model Class Initialized
DEBUG - 2024-02-12 04:44:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 04:44:29 --> Model Class Initialized
INFO - 2024-02-12 04:44:29 --> Final output sent to browser
DEBUG - 2024-02-12 04:44:29 --> Total execution time: 0.0519
ERROR - 2024-02-12 04:44:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 04:44:34 --> Config Class Initialized
INFO - 2024-02-12 04:44:34 --> Hooks Class Initialized
DEBUG - 2024-02-12 04:44:34 --> UTF-8 Support Enabled
INFO - 2024-02-12 04:44:34 --> Utf8 Class Initialized
INFO - 2024-02-12 04:44:34 --> URI Class Initialized
DEBUG - 2024-02-12 04:44:34 --> No URI present. Default controller set.
INFO - 2024-02-12 04:44:34 --> Router Class Initialized
INFO - 2024-02-12 04:44:34 --> Output Class Initialized
INFO - 2024-02-12 04:44:34 --> Security Class Initialized
DEBUG - 2024-02-12 04:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 04:44:34 --> Input Class Initialized
INFO - 2024-02-12 04:44:34 --> Language Class Initialized
INFO - 2024-02-12 04:44:34 --> Loader Class Initialized
INFO - 2024-02-12 04:44:34 --> Helper loaded: url_helper
INFO - 2024-02-12 04:44:34 --> Helper loaded: file_helper
INFO - 2024-02-12 04:44:34 --> Helper loaded: html_helper
INFO - 2024-02-12 04:44:34 --> Helper loaded: text_helper
INFO - 2024-02-12 04:44:34 --> Helper loaded: form_helper
INFO - 2024-02-12 04:44:34 --> Helper loaded: lang_helper
INFO - 2024-02-12 04:44:34 --> Helper loaded: security_helper
INFO - 2024-02-12 04:44:34 --> Helper loaded: cookie_helper
INFO - 2024-02-12 04:44:34 --> Database Driver Class Initialized
INFO - 2024-02-12 04:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 04:44:34 --> Parser Class Initialized
INFO - 2024-02-12 04:44:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 04:44:34 --> Pagination Class Initialized
INFO - 2024-02-12 04:44:34 --> Form Validation Class Initialized
INFO - 2024-02-12 04:44:34 --> Controller Class Initialized
INFO - 2024-02-12 04:44:34 --> Model Class Initialized
DEBUG - 2024-02-12 04:44:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 04:44:34 --> Model Class Initialized
DEBUG - 2024-02-12 04:44:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 04:44:34 --> Model Class Initialized
INFO - 2024-02-12 04:44:34 --> Model Class Initialized
INFO - 2024-02-12 04:44:34 --> Model Class Initialized
INFO - 2024-02-12 04:44:34 --> Model Class Initialized
DEBUG - 2024-02-12 04:44:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 04:44:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 04:44:34 --> Model Class Initialized
INFO - 2024-02-12 04:44:34 --> Model Class Initialized
INFO - 2024-02-12 04:44:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-12 04:44:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 04:44:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 04:44:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 04:44:34 --> Model Class Initialized
INFO - 2024-02-12 04:44:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 04:44:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 04:44:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 04:44:34 --> Final output sent to browser
DEBUG - 2024-02-12 04:44:34 --> Total execution time: 0.2277
ERROR - 2024-02-12 07:23:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 07:23:26 --> Config Class Initialized
INFO - 2024-02-12 07:23:26 --> Hooks Class Initialized
DEBUG - 2024-02-12 07:23:26 --> UTF-8 Support Enabled
INFO - 2024-02-12 07:23:26 --> Utf8 Class Initialized
INFO - 2024-02-12 07:23:26 --> URI Class Initialized
DEBUG - 2024-02-12 07:23:26 --> No URI present. Default controller set.
INFO - 2024-02-12 07:23:26 --> Router Class Initialized
INFO - 2024-02-12 07:23:26 --> Output Class Initialized
INFO - 2024-02-12 07:23:26 --> Security Class Initialized
DEBUG - 2024-02-12 07:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 07:23:26 --> Input Class Initialized
INFO - 2024-02-12 07:23:26 --> Language Class Initialized
INFO - 2024-02-12 07:23:26 --> Loader Class Initialized
INFO - 2024-02-12 07:23:26 --> Helper loaded: url_helper
INFO - 2024-02-12 07:23:26 --> Helper loaded: file_helper
INFO - 2024-02-12 07:23:26 --> Helper loaded: html_helper
INFO - 2024-02-12 07:23:26 --> Helper loaded: text_helper
INFO - 2024-02-12 07:23:26 --> Helper loaded: form_helper
INFO - 2024-02-12 07:23:26 --> Helper loaded: lang_helper
INFO - 2024-02-12 07:23:26 --> Helper loaded: security_helper
INFO - 2024-02-12 07:23:26 --> Helper loaded: cookie_helper
INFO - 2024-02-12 07:23:26 --> Database Driver Class Initialized
INFO - 2024-02-12 07:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 07:23:26 --> Parser Class Initialized
INFO - 2024-02-12 07:23:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 07:23:26 --> Pagination Class Initialized
INFO - 2024-02-12 07:23:26 --> Form Validation Class Initialized
INFO - 2024-02-12 07:23:26 --> Controller Class Initialized
INFO - 2024-02-12 07:23:26 --> Model Class Initialized
DEBUG - 2024-02-12 07:23:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-12 07:23:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 07:23:31 --> Config Class Initialized
INFO - 2024-02-12 07:23:31 --> Hooks Class Initialized
DEBUG - 2024-02-12 07:23:31 --> UTF-8 Support Enabled
INFO - 2024-02-12 07:23:31 --> Utf8 Class Initialized
INFO - 2024-02-12 07:23:31 --> URI Class Initialized
INFO - 2024-02-12 07:23:31 --> Router Class Initialized
INFO - 2024-02-12 07:23:31 --> Output Class Initialized
INFO - 2024-02-12 07:23:31 --> Security Class Initialized
DEBUG - 2024-02-12 07:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 07:23:31 --> Input Class Initialized
INFO - 2024-02-12 07:23:31 --> Language Class Initialized
INFO - 2024-02-12 07:23:31 --> Loader Class Initialized
INFO - 2024-02-12 07:23:31 --> Helper loaded: url_helper
INFO - 2024-02-12 07:23:31 --> Helper loaded: file_helper
INFO - 2024-02-12 07:23:31 --> Helper loaded: html_helper
INFO - 2024-02-12 07:23:31 --> Helper loaded: text_helper
INFO - 2024-02-12 07:23:31 --> Helper loaded: form_helper
INFO - 2024-02-12 07:23:31 --> Helper loaded: lang_helper
INFO - 2024-02-12 07:23:31 --> Helper loaded: security_helper
INFO - 2024-02-12 07:23:31 --> Helper loaded: cookie_helper
INFO - 2024-02-12 07:23:31 --> Database Driver Class Initialized
INFO - 2024-02-12 07:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 07:23:31 --> Parser Class Initialized
INFO - 2024-02-12 07:23:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 07:23:31 --> Pagination Class Initialized
INFO - 2024-02-12 07:23:31 --> Form Validation Class Initialized
INFO - 2024-02-12 07:23:31 --> Controller Class Initialized
INFO - 2024-02-12 07:23:31 --> Model Class Initialized
DEBUG - 2024-02-12 07:23:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:23:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-12 07:23:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:23:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 07:23:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 07:23:31 --> Model Class Initialized
INFO - 2024-02-12 07:23:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 07:23:31 --> Final output sent to browser
DEBUG - 2024-02-12 07:23:31 --> Total execution time: 0.0322
ERROR - 2024-02-12 07:25:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 07:25:06 --> Config Class Initialized
INFO - 2024-02-12 07:25:06 --> Hooks Class Initialized
DEBUG - 2024-02-12 07:25:06 --> UTF-8 Support Enabled
INFO - 2024-02-12 07:25:06 --> Utf8 Class Initialized
INFO - 2024-02-12 07:25:06 --> URI Class Initialized
INFO - 2024-02-12 07:25:06 --> Router Class Initialized
INFO - 2024-02-12 07:25:06 --> Output Class Initialized
INFO - 2024-02-12 07:25:06 --> Security Class Initialized
DEBUG - 2024-02-12 07:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 07:25:06 --> Input Class Initialized
INFO - 2024-02-12 07:25:06 --> Language Class Initialized
INFO - 2024-02-12 07:25:06 --> Loader Class Initialized
INFO - 2024-02-12 07:25:06 --> Helper loaded: url_helper
INFO - 2024-02-12 07:25:06 --> Helper loaded: file_helper
INFO - 2024-02-12 07:25:06 --> Helper loaded: html_helper
INFO - 2024-02-12 07:25:06 --> Helper loaded: text_helper
INFO - 2024-02-12 07:25:06 --> Helper loaded: form_helper
INFO - 2024-02-12 07:25:06 --> Helper loaded: lang_helper
INFO - 2024-02-12 07:25:06 --> Helper loaded: security_helper
INFO - 2024-02-12 07:25:06 --> Helper loaded: cookie_helper
INFO - 2024-02-12 07:25:06 --> Database Driver Class Initialized
INFO - 2024-02-12 07:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 07:25:06 --> Parser Class Initialized
INFO - 2024-02-12 07:25:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 07:25:06 --> Pagination Class Initialized
INFO - 2024-02-12 07:25:06 --> Form Validation Class Initialized
INFO - 2024-02-12 07:25:06 --> Controller Class Initialized
INFO - 2024-02-12 07:25:06 --> Model Class Initialized
DEBUG - 2024-02-12 07:25:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:25:06 --> Model Class Initialized
INFO - 2024-02-12 07:25:06 --> Final output sent to browser
DEBUG - 2024-02-12 07:25:06 --> Total execution time: 0.0192
ERROR - 2024-02-12 07:25:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 07:25:06 --> Config Class Initialized
INFO - 2024-02-12 07:25:06 --> Hooks Class Initialized
DEBUG - 2024-02-12 07:25:06 --> UTF-8 Support Enabled
INFO - 2024-02-12 07:25:06 --> Utf8 Class Initialized
INFO - 2024-02-12 07:25:06 --> URI Class Initialized
DEBUG - 2024-02-12 07:25:06 --> No URI present. Default controller set.
INFO - 2024-02-12 07:25:06 --> Router Class Initialized
INFO - 2024-02-12 07:25:06 --> Output Class Initialized
INFO - 2024-02-12 07:25:06 --> Security Class Initialized
DEBUG - 2024-02-12 07:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 07:25:06 --> Input Class Initialized
INFO - 2024-02-12 07:25:06 --> Language Class Initialized
INFO - 2024-02-12 07:25:06 --> Loader Class Initialized
INFO - 2024-02-12 07:25:06 --> Helper loaded: url_helper
INFO - 2024-02-12 07:25:06 --> Helper loaded: file_helper
INFO - 2024-02-12 07:25:06 --> Helper loaded: html_helper
INFO - 2024-02-12 07:25:06 --> Helper loaded: text_helper
INFO - 2024-02-12 07:25:06 --> Helper loaded: form_helper
INFO - 2024-02-12 07:25:06 --> Helper loaded: lang_helper
INFO - 2024-02-12 07:25:06 --> Helper loaded: security_helper
INFO - 2024-02-12 07:25:06 --> Helper loaded: cookie_helper
INFO - 2024-02-12 07:25:06 --> Database Driver Class Initialized
INFO - 2024-02-12 07:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 07:25:06 --> Parser Class Initialized
INFO - 2024-02-12 07:25:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 07:25:06 --> Pagination Class Initialized
INFO - 2024-02-12 07:25:06 --> Form Validation Class Initialized
INFO - 2024-02-12 07:25:06 --> Controller Class Initialized
INFO - 2024-02-12 07:25:06 --> Model Class Initialized
DEBUG - 2024-02-12 07:25:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:25:06 --> Model Class Initialized
DEBUG - 2024-02-12 07:25:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:25:06 --> Model Class Initialized
INFO - 2024-02-12 07:25:06 --> Model Class Initialized
INFO - 2024-02-12 07:25:06 --> Model Class Initialized
INFO - 2024-02-12 07:25:06 --> Model Class Initialized
DEBUG - 2024-02-12 07:25:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 07:25:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:25:06 --> Model Class Initialized
INFO - 2024-02-12 07:25:06 --> Model Class Initialized
INFO - 2024-02-12 07:25:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-12 07:25:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:25:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 07:25:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 07:25:06 --> Model Class Initialized
INFO - 2024-02-12 07:25:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 07:25:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 07:25:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 07:25:06 --> Final output sent to browser
DEBUG - 2024-02-12 07:25:06 --> Total execution time: 0.2260
ERROR - 2024-02-12 07:38:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 07:38:52 --> Config Class Initialized
INFO - 2024-02-12 07:38:52 --> Hooks Class Initialized
DEBUG - 2024-02-12 07:38:52 --> UTF-8 Support Enabled
INFO - 2024-02-12 07:38:52 --> Utf8 Class Initialized
INFO - 2024-02-12 07:38:52 --> URI Class Initialized
INFO - 2024-02-12 07:38:52 --> Router Class Initialized
INFO - 2024-02-12 07:38:52 --> Output Class Initialized
INFO - 2024-02-12 07:38:52 --> Security Class Initialized
DEBUG - 2024-02-12 07:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 07:38:52 --> Input Class Initialized
INFO - 2024-02-12 07:38:52 --> Language Class Initialized
INFO - 2024-02-12 07:38:52 --> Loader Class Initialized
INFO - 2024-02-12 07:38:52 --> Helper loaded: url_helper
INFO - 2024-02-12 07:38:52 --> Helper loaded: file_helper
INFO - 2024-02-12 07:38:52 --> Helper loaded: html_helper
INFO - 2024-02-12 07:38:52 --> Helper loaded: text_helper
INFO - 2024-02-12 07:38:52 --> Helper loaded: form_helper
INFO - 2024-02-12 07:38:52 --> Helper loaded: lang_helper
INFO - 2024-02-12 07:38:52 --> Helper loaded: security_helper
INFO - 2024-02-12 07:38:52 --> Helper loaded: cookie_helper
INFO - 2024-02-12 07:38:52 --> Database Driver Class Initialized
INFO - 2024-02-12 07:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 07:38:52 --> Parser Class Initialized
INFO - 2024-02-12 07:38:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 07:38:52 --> Pagination Class Initialized
INFO - 2024-02-12 07:38:52 --> Form Validation Class Initialized
INFO - 2024-02-12 07:38:52 --> Controller Class Initialized
DEBUG - 2024-02-12 07:38:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 07:38:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:38:52 --> Model Class Initialized
DEBUG - 2024-02-12 07:38:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:38:52 --> Model Class Initialized
INFO - 2024-02-12 07:38:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2024-02-12 07:38:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:38:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 07:38:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 07:38:52 --> Model Class Initialized
INFO - 2024-02-12 07:38:52 --> Model Class Initialized
INFO - 2024-02-12 07:38:52 --> Model Class Initialized
INFO - 2024-02-12 07:38:52 --> Model Class Initialized
INFO - 2024-02-12 07:38:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 07:38:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 07:38:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 07:38:53 --> Final output sent to browser
DEBUG - 2024-02-12 07:38:53 --> Total execution time: 0.1966
ERROR - 2024-02-12 07:42:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 07:42:53 --> Config Class Initialized
INFO - 2024-02-12 07:42:53 --> Hooks Class Initialized
DEBUG - 2024-02-12 07:42:53 --> UTF-8 Support Enabled
INFO - 2024-02-12 07:42:53 --> Utf8 Class Initialized
INFO - 2024-02-12 07:42:53 --> URI Class Initialized
INFO - 2024-02-12 07:42:53 --> Router Class Initialized
INFO - 2024-02-12 07:42:53 --> Output Class Initialized
INFO - 2024-02-12 07:42:53 --> Security Class Initialized
DEBUG - 2024-02-12 07:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 07:42:53 --> Input Class Initialized
INFO - 2024-02-12 07:42:53 --> Language Class Initialized
INFO - 2024-02-12 07:42:53 --> Loader Class Initialized
INFO - 2024-02-12 07:42:53 --> Helper loaded: url_helper
INFO - 2024-02-12 07:42:53 --> Helper loaded: file_helper
INFO - 2024-02-12 07:42:53 --> Helper loaded: html_helper
INFO - 2024-02-12 07:42:53 --> Helper loaded: text_helper
INFO - 2024-02-12 07:42:53 --> Helper loaded: form_helper
INFO - 2024-02-12 07:42:53 --> Helper loaded: lang_helper
INFO - 2024-02-12 07:42:53 --> Helper loaded: security_helper
INFO - 2024-02-12 07:42:53 --> Helper loaded: cookie_helper
INFO - 2024-02-12 07:42:53 --> Database Driver Class Initialized
INFO - 2024-02-12 07:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 07:42:53 --> Parser Class Initialized
INFO - 2024-02-12 07:42:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 07:42:53 --> Pagination Class Initialized
INFO - 2024-02-12 07:42:53 --> Form Validation Class Initialized
INFO - 2024-02-12 07:42:53 --> Controller Class Initialized
DEBUG - 2024-02-12 07:42:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 07:42:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:42:53 --> Model Class Initialized
DEBUG - 2024-02-12 07:42:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:42:53 --> Model Class Initialized
DEBUG - 2024-02-12 07:42:53 --> Auth class already loaded. Second attempt ignored.
ERROR - 2024-02-12 07:42:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 07:42:53 --> Config Class Initialized
INFO - 2024-02-12 07:42:53 --> Hooks Class Initialized
DEBUG - 2024-02-12 07:42:53 --> UTF-8 Support Enabled
INFO - 2024-02-12 07:42:53 --> Utf8 Class Initialized
INFO - 2024-02-12 07:42:53 --> URI Class Initialized
INFO - 2024-02-12 07:42:53 --> Router Class Initialized
INFO - 2024-02-12 07:42:53 --> Output Class Initialized
INFO - 2024-02-12 07:42:53 --> Security Class Initialized
DEBUG - 2024-02-12 07:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 07:42:53 --> Input Class Initialized
INFO - 2024-02-12 07:42:53 --> Language Class Initialized
INFO - 2024-02-12 07:42:53 --> Loader Class Initialized
INFO - 2024-02-12 07:42:53 --> Helper loaded: url_helper
INFO - 2024-02-12 07:42:53 --> Helper loaded: file_helper
INFO - 2024-02-12 07:42:53 --> Helper loaded: html_helper
INFO - 2024-02-12 07:42:53 --> Helper loaded: text_helper
INFO - 2024-02-12 07:42:53 --> Helper loaded: form_helper
INFO - 2024-02-12 07:42:53 --> Helper loaded: lang_helper
INFO - 2024-02-12 07:42:53 --> Helper loaded: security_helper
INFO - 2024-02-12 07:42:53 --> Helper loaded: cookie_helper
INFO - 2024-02-12 07:42:53 --> Database Driver Class Initialized
INFO - 2024-02-12 07:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 07:42:53 --> Parser Class Initialized
INFO - 2024-02-12 07:42:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 07:42:53 --> Pagination Class Initialized
INFO - 2024-02-12 07:42:53 --> Form Validation Class Initialized
INFO - 2024-02-12 07:42:53 --> Controller Class Initialized
DEBUG - 2024-02-12 07:42:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 07:42:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:42:53 --> Model Class Initialized
DEBUG - 2024-02-12 07:42:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:42:53 --> Model Class Initialized
INFO - 2024-02-12 07:42:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2024-02-12 07:42:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:42:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 07:42:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 07:42:54 --> Model Class Initialized
INFO - 2024-02-12 07:42:54 --> Model Class Initialized
INFO - 2024-02-12 07:42:54 --> Model Class Initialized
INFO - 2024-02-12 07:42:54 --> Model Class Initialized
INFO - 2024-02-12 07:42:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 07:42:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 07:42:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 07:42:54 --> Final output sent to browser
DEBUG - 2024-02-12 07:42:54 --> Total execution time: 0.1795
ERROR - 2024-02-12 07:51:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 07:51:56 --> Config Class Initialized
INFO - 2024-02-12 07:51:56 --> Hooks Class Initialized
DEBUG - 2024-02-12 07:51:56 --> UTF-8 Support Enabled
INFO - 2024-02-12 07:51:56 --> Utf8 Class Initialized
INFO - 2024-02-12 07:51:56 --> URI Class Initialized
INFO - 2024-02-12 07:51:56 --> Router Class Initialized
INFO - 2024-02-12 07:51:56 --> Output Class Initialized
INFO - 2024-02-12 07:51:56 --> Security Class Initialized
DEBUG - 2024-02-12 07:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 07:51:56 --> Input Class Initialized
INFO - 2024-02-12 07:51:56 --> Language Class Initialized
INFO - 2024-02-12 07:51:56 --> Loader Class Initialized
INFO - 2024-02-12 07:51:56 --> Helper loaded: url_helper
INFO - 2024-02-12 07:51:56 --> Helper loaded: file_helper
INFO - 2024-02-12 07:51:56 --> Helper loaded: html_helper
INFO - 2024-02-12 07:51:56 --> Helper loaded: text_helper
INFO - 2024-02-12 07:51:56 --> Helper loaded: form_helper
INFO - 2024-02-12 07:51:56 --> Helper loaded: lang_helper
INFO - 2024-02-12 07:51:56 --> Helper loaded: security_helper
INFO - 2024-02-12 07:51:56 --> Helper loaded: cookie_helper
INFO - 2024-02-12 07:51:56 --> Database Driver Class Initialized
INFO - 2024-02-12 07:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 07:51:56 --> Parser Class Initialized
INFO - 2024-02-12 07:51:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 07:51:56 --> Pagination Class Initialized
INFO - 2024-02-12 07:51:56 --> Form Validation Class Initialized
INFO - 2024-02-12 07:51:56 --> Controller Class Initialized
DEBUG - 2024-02-12 07:51:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 07:51:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:51:56 --> Model Class Initialized
DEBUG - 2024-02-12 07:51:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:51:56 --> Model Class Initialized
DEBUG - 2024-02-12 07:51:56 --> Auth class already loaded. Second attempt ignored.
ERROR - 2024-02-12 07:51:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 07:51:56 --> Config Class Initialized
INFO - 2024-02-12 07:51:56 --> Hooks Class Initialized
DEBUG - 2024-02-12 07:51:56 --> UTF-8 Support Enabled
INFO - 2024-02-12 07:51:56 --> Utf8 Class Initialized
INFO - 2024-02-12 07:51:56 --> URI Class Initialized
INFO - 2024-02-12 07:51:56 --> Router Class Initialized
INFO - 2024-02-12 07:51:56 --> Output Class Initialized
INFO - 2024-02-12 07:51:56 --> Security Class Initialized
DEBUG - 2024-02-12 07:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 07:51:56 --> Input Class Initialized
INFO - 2024-02-12 07:51:56 --> Language Class Initialized
INFO - 2024-02-12 07:51:56 --> Loader Class Initialized
INFO - 2024-02-12 07:51:56 --> Helper loaded: url_helper
INFO - 2024-02-12 07:51:56 --> Helper loaded: file_helper
INFO - 2024-02-12 07:51:56 --> Helper loaded: html_helper
INFO - 2024-02-12 07:51:56 --> Helper loaded: text_helper
INFO - 2024-02-12 07:51:56 --> Helper loaded: form_helper
INFO - 2024-02-12 07:51:56 --> Helper loaded: lang_helper
INFO - 2024-02-12 07:51:56 --> Helper loaded: security_helper
INFO - 2024-02-12 07:51:56 --> Helper loaded: cookie_helper
INFO - 2024-02-12 07:51:56 --> Database Driver Class Initialized
INFO - 2024-02-12 07:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 07:51:56 --> Parser Class Initialized
INFO - 2024-02-12 07:51:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 07:51:56 --> Pagination Class Initialized
INFO - 2024-02-12 07:51:56 --> Form Validation Class Initialized
INFO - 2024-02-12 07:51:56 --> Controller Class Initialized
DEBUG - 2024-02-12 07:51:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 07:51:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:51:56 --> Model Class Initialized
DEBUG - 2024-02-12 07:51:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:51:56 --> Model Class Initialized
INFO - 2024-02-12 07:51:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2024-02-12 07:51:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:51:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 07:51:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 07:51:56 --> Model Class Initialized
INFO - 2024-02-12 07:51:56 --> Model Class Initialized
INFO - 2024-02-12 07:51:56 --> Model Class Initialized
INFO - 2024-02-12 07:51:56 --> Model Class Initialized
INFO - 2024-02-12 07:51:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 07:51:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 07:51:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 07:51:56 --> Final output sent to browser
DEBUG - 2024-02-12 07:51:56 --> Total execution time: 0.1732
ERROR - 2024-02-12 07:52:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 07:52:54 --> Config Class Initialized
INFO - 2024-02-12 07:52:54 --> Hooks Class Initialized
DEBUG - 2024-02-12 07:52:54 --> UTF-8 Support Enabled
INFO - 2024-02-12 07:52:54 --> Utf8 Class Initialized
INFO - 2024-02-12 07:52:54 --> URI Class Initialized
INFO - 2024-02-12 07:52:54 --> Router Class Initialized
INFO - 2024-02-12 07:52:54 --> Output Class Initialized
INFO - 2024-02-12 07:52:54 --> Security Class Initialized
DEBUG - 2024-02-12 07:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 07:52:54 --> Input Class Initialized
INFO - 2024-02-12 07:52:54 --> Language Class Initialized
INFO - 2024-02-12 07:52:54 --> Loader Class Initialized
INFO - 2024-02-12 07:52:54 --> Helper loaded: url_helper
INFO - 2024-02-12 07:52:54 --> Helper loaded: file_helper
INFO - 2024-02-12 07:52:54 --> Helper loaded: html_helper
INFO - 2024-02-12 07:52:54 --> Helper loaded: text_helper
INFO - 2024-02-12 07:52:54 --> Helper loaded: form_helper
INFO - 2024-02-12 07:52:54 --> Helper loaded: lang_helper
INFO - 2024-02-12 07:52:54 --> Helper loaded: security_helper
INFO - 2024-02-12 07:52:54 --> Helper loaded: cookie_helper
INFO - 2024-02-12 07:52:54 --> Database Driver Class Initialized
INFO - 2024-02-12 07:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 07:52:54 --> Parser Class Initialized
INFO - 2024-02-12 07:52:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 07:52:54 --> Pagination Class Initialized
INFO - 2024-02-12 07:52:54 --> Form Validation Class Initialized
INFO - 2024-02-12 07:52:54 --> Controller Class Initialized
DEBUG - 2024-02-12 07:52:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 07:52:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:52:54 --> Model Class Initialized
DEBUG - 2024-02-12 07:52:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:52:54 --> Model Class Initialized
INFO - 2024-02-12 07:52:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2024-02-12 07:52:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:52:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 07:52:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 07:52:54 --> Model Class Initialized
INFO - 2024-02-12 07:52:54 --> Model Class Initialized
INFO - 2024-02-12 07:52:54 --> Model Class Initialized
INFO - 2024-02-12 07:52:54 --> Model Class Initialized
INFO - 2024-02-12 07:52:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 07:52:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 07:52:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 07:52:54 --> Final output sent to browser
DEBUG - 2024-02-12 07:52:54 --> Total execution time: 0.1648
ERROR - 2024-02-12 07:52:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 07:52:56 --> Config Class Initialized
INFO - 2024-02-12 07:52:56 --> Hooks Class Initialized
DEBUG - 2024-02-12 07:52:56 --> UTF-8 Support Enabled
INFO - 2024-02-12 07:52:56 --> Utf8 Class Initialized
INFO - 2024-02-12 07:52:56 --> URI Class Initialized
DEBUG - 2024-02-12 07:52:56 --> No URI present. Default controller set.
INFO - 2024-02-12 07:52:56 --> Router Class Initialized
INFO - 2024-02-12 07:52:56 --> Output Class Initialized
INFO - 2024-02-12 07:52:56 --> Security Class Initialized
DEBUG - 2024-02-12 07:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 07:52:56 --> Input Class Initialized
INFO - 2024-02-12 07:52:56 --> Language Class Initialized
INFO - 2024-02-12 07:52:56 --> Loader Class Initialized
INFO - 2024-02-12 07:52:56 --> Helper loaded: url_helper
INFO - 2024-02-12 07:52:56 --> Helper loaded: file_helper
INFO - 2024-02-12 07:52:56 --> Helper loaded: html_helper
INFO - 2024-02-12 07:52:56 --> Helper loaded: text_helper
INFO - 2024-02-12 07:52:56 --> Helper loaded: form_helper
INFO - 2024-02-12 07:52:56 --> Helper loaded: lang_helper
INFO - 2024-02-12 07:52:56 --> Helper loaded: security_helper
INFO - 2024-02-12 07:52:56 --> Helper loaded: cookie_helper
INFO - 2024-02-12 07:52:56 --> Database Driver Class Initialized
INFO - 2024-02-12 07:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 07:52:56 --> Parser Class Initialized
INFO - 2024-02-12 07:52:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 07:52:56 --> Pagination Class Initialized
INFO - 2024-02-12 07:52:56 --> Form Validation Class Initialized
INFO - 2024-02-12 07:52:56 --> Controller Class Initialized
INFO - 2024-02-12 07:52:56 --> Model Class Initialized
DEBUG - 2024-02-12 07:52:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-12 07:52:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 07:52:56 --> Config Class Initialized
INFO - 2024-02-12 07:52:56 --> Hooks Class Initialized
DEBUG - 2024-02-12 07:52:56 --> UTF-8 Support Enabled
INFO - 2024-02-12 07:52:56 --> Utf8 Class Initialized
INFO - 2024-02-12 07:52:56 --> URI Class Initialized
INFO - 2024-02-12 07:52:56 --> Router Class Initialized
INFO - 2024-02-12 07:52:56 --> Output Class Initialized
INFO - 2024-02-12 07:52:56 --> Security Class Initialized
DEBUG - 2024-02-12 07:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 07:52:56 --> Input Class Initialized
INFO - 2024-02-12 07:52:56 --> Language Class Initialized
INFO - 2024-02-12 07:52:56 --> Loader Class Initialized
INFO - 2024-02-12 07:52:56 --> Helper loaded: url_helper
INFO - 2024-02-12 07:52:56 --> Helper loaded: file_helper
INFO - 2024-02-12 07:52:56 --> Helper loaded: html_helper
INFO - 2024-02-12 07:52:56 --> Helper loaded: text_helper
INFO - 2024-02-12 07:52:56 --> Helper loaded: form_helper
INFO - 2024-02-12 07:52:56 --> Helper loaded: lang_helper
INFO - 2024-02-12 07:52:56 --> Helper loaded: security_helper
INFO - 2024-02-12 07:52:56 --> Helper loaded: cookie_helper
INFO - 2024-02-12 07:52:56 --> Database Driver Class Initialized
INFO - 2024-02-12 07:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 07:52:56 --> Parser Class Initialized
INFO - 2024-02-12 07:52:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 07:52:56 --> Pagination Class Initialized
INFO - 2024-02-12 07:52:56 --> Form Validation Class Initialized
INFO - 2024-02-12 07:52:56 --> Controller Class Initialized
INFO - 2024-02-12 07:52:56 --> Model Class Initialized
DEBUG - 2024-02-12 07:52:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:52:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-12 07:52:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:52:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 07:52:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 07:52:56 --> Model Class Initialized
INFO - 2024-02-12 07:52:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 07:52:56 --> Final output sent to browser
DEBUG - 2024-02-12 07:52:56 --> Total execution time: 0.0278
ERROR - 2024-02-12 07:52:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 07:52:57 --> Config Class Initialized
INFO - 2024-02-12 07:52:57 --> Hooks Class Initialized
DEBUG - 2024-02-12 07:52:57 --> UTF-8 Support Enabled
INFO - 2024-02-12 07:52:57 --> Utf8 Class Initialized
INFO - 2024-02-12 07:52:57 --> URI Class Initialized
INFO - 2024-02-12 07:52:57 --> Router Class Initialized
INFO - 2024-02-12 07:52:57 --> Output Class Initialized
INFO - 2024-02-12 07:52:57 --> Security Class Initialized
DEBUG - 2024-02-12 07:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 07:52:57 --> Input Class Initialized
INFO - 2024-02-12 07:52:57 --> Language Class Initialized
INFO - 2024-02-12 07:52:57 --> Loader Class Initialized
INFO - 2024-02-12 07:52:57 --> Helper loaded: url_helper
INFO - 2024-02-12 07:52:57 --> Helper loaded: file_helper
INFO - 2024-02-12 07:52:57 --> Helper loaded: html_helper
INFO - 2024-02-12 07:52:57 --> Helper loaded: text_helper
INFO - 2024-02-12 07:52:57 --> Helper loaded: form_helper
INFO - 2024-02-12 07:52:57 --> Helper loaded: lang_helper
INFO - 2024-02-12 07:52:57 --> Helper loaded: security_helper
INFO - 2024-02-12 07:52:57 --> Helper loaded: cookie_helper
INFO - 2024-02-12 07:52:57 --> Database Driver Class Initialized
INFO - 2024-02-12 07:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 07:52:57 --> Parser Class Initialized
INFO - 2024-02-12 07:52:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 07:52:57 --> Pagination Class Initialized
INFO - 2024-02-12 07:52:57 --> Form Validation Class Initialized
INFO - 2024-02-12 07:52:57 --> Controller Class Initialized
DEBUG - 2024-02-12 07:52:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 07:52:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:52:57 --> Model Class Initialized
DEBUG - 2024-02-12 07:52:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:52:57 --> Model Class Initialized
INFO - 2024-02-12 07:52:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2024-02-12 07:52:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:52:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 07:52:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 07:52:57 --> Model Class Initialized
INFO - 2024-02-12 07:52:57 --> Model Class Initialized
INFO - 2024-02-12 07:52:57 --> Model Class Initialized
INFO - 2024-02-12 07:52:57 --> Model Class Initialized
INFO - 2024-02-12 07:52:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 07:52:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 07:52:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 07:52:58 --> Final output sent to browser
DEBUG - 2024-02-12 07:52:58 --> Total execution time: 0.1904
ERROR - 2024-02-12 07:53:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 07:53:00 --> Config Class Initialized
INFO - 2024-02-12 07:53:00 --> Hooks Class Initialized
DEBUG - 2024-02-12 07:53:00 --> UTF-8 Support Enabled
INFO - 2024-02-12 07:53:00 --> Utf8 Class Initialized
INFO - 2024-02-12 07:53:00 --> URI Class Initialized
DEBUG - 2024-02-12 07:53:00 --> No URI present. Default controller set.
INFO - 2024-02-12 07:53:00 --> Router Class Initialized
INFO - 2024-02-12 07:53:00 --> Output Class Initialized
INFO - 2024-02-12 07:53:00 --> Security Class Initialized
DEBUG - 2024-02-12 07:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 07:53:00 --> Input Class Initialized
INFO - 2024-02-12 07:53:00 --> Language Class Initialized
INFO - 2024-02-12 07:53:00 --> Loader Class Initialized
INFO - 2024-02-12 07:53:00 --> Helper loaded: url_helper
INFO - 2024-02-12 07:53:00 --> Helper loaded: file_helper
INFO - 2024-02-12 07:53:00 --> Helper loaded: html_helper
INFO - 2024-02-12 07:53:00 --> Helper loaded: text_helper
INFO - 2024-02-12 07:53:00 --> Helper loaded: form_helper
INFO - 2024-02-12 07:53:00 --> Helper loaded: lang_helper
INFO - 2024-02-12 07:53:00 --> Helper loaded: security_helper
INFO - 2024-02-12 07:53:00 --> Helper loaded: cookie_helper
INFO - 2024-02-12 07:53:00 --> Database Driver Class Initialized
INFO - 2024-02-12 07:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 07:53:00 --> Parser Class Initialized
INFO - 2024-02-12 07:53:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 07:53:00 --> Pagination Class Initialized
INFO - 2024-02-12 07:53:00 --> Form Validation Class Initialized
INFO - 2024-02-12 07:53:00 --> Controller Class Initialized
INFO - 2024-02-12 07:53:00 --> Model Class Initialized
DEBUG - 2024-02-12 07:53:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:53:00 --> Model Class Initialized
DEBUG - 2024-02-12 07:53:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:53:00 --> Model Class Initialized
INFO - 2024-02-12 07:53:00 --> Model Class Initialized
INFO - 2024-02-12 07:53:00 --> Model Class Initialized
INFO - 2024-02-12 07:53:00 --> Model Class Initialized
DEBUG - 2024-02-12 07:53:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 07:53:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:53:00 --> Model Class Initialized
INFO - 2024-02-12 07:53:00 --> Model Class Initialized
INFO - 2024-02-12 07:53:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-12 07:53:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:53:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 07:53:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 07:53:00 --> Model Class Initialized
INFO - 2024-02-12 07:53:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 07:53:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 07:53:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 07:53:00 --> Final output sent to browser
DEBUG - 2024-02-12 07:53:00 --> Total execution time: 0.2333
ERROR - 2024-02-12 07:53:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 07:53:04 --> Config Class Initialized
INFO - 2024-02-12 07:53:04 --> Hooks Class Initialized
DEBUG - 2024-02-12 07:53:04 --> UTF-8 Support Enabled
INFO - 2024-02-12 07:53:04 --> Utf8 Class Initialized
INFO - 2024-02-12 07:53:04 --> URI Class Initialized
INFO - 2024-02-12 07:53:04 --> Router Class Initialized
INFO - 2024-02-12 07:53:04 --> Output Class Initialized
INFO - 2024-02-12 07:53:04 --> Security Class Initialized
DEBUG - 2024-02-12 07:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 07:53:04 --> Input Class Initialized
INFO - 2024-02-12 07:53:04 --> Language Class Initialized
INFO - 2024-02-12 07:53:04 --> Loader Class Initialized
INFO - 2024-02-12 07:53:04 --> Helper loaded: url_helper
INFO - 2024-02-12 07:53:04 --> Helper loaded: file_helper
INFO - 2024-02-12 07:53:04 --> Helper loaded: html_helper
INFO - 2024-02-12 07:53:04 --> Helper loaded: text_helper
INFO - 2024-02-12 07:53:04 --> Helper loaded: form_helper
INFO - 2024-02-12 07:53:04 --> Helper loaded: lang_helper
INFO - 2024-02-12 07:53:04 --> Helper loaded: security_helper
INFO - 2024-02-12 07:53:04 --> Helper loaded: cookie_helper
INFO - 2024-02-12 07:53:04 --> Database Driver Class Initialized
INFO - 2024-02-12 07:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 07:53:04 --> Parser Class Initialized
INFO - 2024-02-12 07:53:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 07:53:04 --> Pagination Class Initialized
INFO - 2024-02-12 07:53:04 --> Form Validation Class Initialized
INFO - 2024-02-12 07:53:04 --> Controller Class Initialized
INFO - 2024-02-12 07:53:04 --> Model Class Initialized
INFO - 2024-02-12 07:53:04 --> Model Class Initialized
INFO - 2024-02-12 07:53:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2024-02-12 07:53:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:53:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 07:53:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 07:53:04 --> Model Class Initialized
INFO - 2024-02-12 07:53:04 --> Model Class Initialized
INFO - 2024-02-12 07:53:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 07:53:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 07:53:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 07:53:05 --> Final output sent to browser
DEBUG - 2024-02-12 07:53:05 --> Total execution time: 0.1573
ERROR - 2024-02-12 07:53:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 07:53:05 --> Config Class Initialized
INFO - 2024-02-12 07:53:05 --> Hooks Class Initialized
DEBUG - 2024-02-12 07:53:05 --> UTF-8 Support Enabled
INFO - 2024-02-12 07:53:05 --> Utf8 Class Initialized
INFO - 2024-02-12 07:53:05 --> URI Class Initialized
INFO - 2024-02-12 07:53:05 --> Router Class Initialized
INFO - 2024-02-12 07:53:05 --> Output Class Initialized
INFO - 2024-02-12 07:53:05 --> Security Class Initialized
DEBUG - 2024-02-12 07:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 07:53:05 --> Input Class Initialized
INFO - 2024-02-12 07:53:05 --> Language Class Initialized
INFO - 2024-02-12 07:53:05 --> Loader Class Initialized
INFO - 2024-02-12 07:53:05 --> Helper loaded: url_helper
INFO - 2024-02-12 07:53:05 --> Helper loaded: file_helper
INFO - 2024-02-12 07:53:05 --> Helper loaded: html_helper
INFO - 2024-02-12 07:53:05 --> Helper loaded: text_helper
INFO - 2024-02-12 07:53:05 --> Helper loaded: form_helper
INFO - 2024-02-12 07:53:05 --> Helper loaded: lang_helper
INFO - 2024-02-12 07:53:05 --> Helper loaded: security_helper
INFO - 2024-02-12 07:53:05 --> Helper loaded: cookie_helper
INFO - 2024-02-12 07:53:05 --> Database Driver Class Initialized
INFO - 2024-02-12 07:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 07:53:05 --> Parser Class Initialized
INFO - 2024-02-12 07:53:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 07:53:05 --> Pagination Class Initialized
INFO - 2024-02-12 07:53:05 --> Form Validation Class Initialized
INFO - 2024-02-12 07:53:05 --> Controller Class Initialized
INFO - 2024-02-12 07:53:05 --> Model Class Initialized
INFO - 2024-02-12 07:53:05 --> Model Class Initialized
INFO - 2024-02-12 07:53:05 --> Final output sent to browser
DEBUG - 2024-02-12 07:53:05 --> Total execution time: 0.0768
ERROR - 2024-02-12 07:53:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 07:53:10 --> Config Class Initialized
INFO - 2024-02-12 07:53:10 --> Hooks Class Initialized
DEBUG - 2024-02-12 07:53:10 --> UTF-8 Support Enabled
INFO - 2024-02-12 07:53:10 --> Utf8 Class Initialized
INFO - 2024-02-12 07:53:10 --> URI Class Initialized
DEBUG - 2024-02-12 07:53:10 --> No URI present. Default controller set.
INFO - 2024-02-12 07:53:10 --> Router Class Initialized
INFO - 2024-02-12 07:53:10 --> Output Class Initialized
INFO - 2024-02-12 07:53:10 --> Security Class Initialized
DEBUG - 2024-02-12 07:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 07:53:10 --> Input Class Initialized
INFO - 2024-02-12 07:53:10 --> Language Class Initialized
INFO - 2024-02-12 07:53:10 --> Loader Class Initialized
INFO - 2024-02-12 07:53:10 --> Helper loaded: url_helper
INFO - 2024-02-12 07:53:10 --> Helper loaded: file_helper
INFO - 2024-02-12 07:53:10 --> Helper loaded: html_helper
INFO - 2024-02-12 07:53:10 --> Helper loaded: text_helper
INFO - 2024-02-12 07:53:10 --> Helper loaded: form_helper
INFO - 2024-02-12 07:53:10 --> Helper loaded: lang_helper
INFO - 2024-02-12 07:53:10 --> Helper loaded: security_helper
INFO - 2024-02-12 07:53:10 --> Helper loaded: cookie_helper
INFO - 2024-02-12 07:53:10 --> Database Driver Class Initialized
INFO - 2024-02-12 07:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 07:53:10 --> Parser Class Initialized
INFO - 2024-02-12 07:53:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 07:53:10 --> Pagination Class Initialized
INFO - 2024-02-12 07:53:10 --> Form Validation Class Initialized
INFO - 2024-02-12 07:53:10 --> Controller Class Initialized
INFO - 2024-02-12 07:53:10 --> Model Class Initialized
DEBUG - 2024-02-12 07:53:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:53:10 --> Model Class Initialized
DEBUG - 2024-02-12 07:53:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:53:10 --> Model Class Initialized
INFO - 2024-02-12 07:53:10 --> Model Class Initialized
INFO - 2024-02-12 07:53:10 --> Model Class Initialized
INFO - 2024-02-12 07:53:10 --> Model Class Initialized
DEBUG - 2024-02-12 07:53:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 07:53:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:53:10 --> Model Class Initialized
INFO - 2024-02-12 07:53:10 --> Model Class Initialized
INFO - 2024-02-12 07:53:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-12 07:53:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:53:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 07:53:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 07:53:10 --> Model Class Initialized
ERROR - 2024-02-12 07:53:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 07:53:10 --> Config Class Initialized
INFO - 2024-02-12 07:53:10 --> Hooks Class Initialized
DEBUG - 2024-02-12 07:53:10 --> UTF-8 Support Enabled
INFO - 2024-02-12 07:53:10 --> Utf8 Class Initialized
INFO - 2024-02-12 07:53:10 --> URI Class Initialized
INFO - 2024-02-12 07:53:10 --> Router Class Initialized
INFO - 2024-02-12 07:53:10 --> Output Class Initialized
INFO - 2024-02-12 07:53:10 --> Security Class Initialized
DEBUG - 2024-02-12 07:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 07:53:10 --> Input Class Initialized
INFO - 2024-02-12 07:53:10 --> Language Class Initialized
INFO - 2024-02-12 07:53:10 --> Loader Class Initialized
INFO - 2024-02-12 07:53:10 --> Helper loaded: url_helper
INFO - 2024-02-12 07:53:10 --> Helper loaded: file_helper
INFO - 2024-02-12 07:53:10 --> Helper loaded: html_helper
INFO - 2024-02-12 07:53:10 --> Helper loaded: text_helper
INFO - 2024-02-12 07:53:10 --> Helper loaded: form_helper
INFO - 2024-02-12 07:53:10 --> Helper loaded: lang_helper
INFO - 2024-02-12 07:53:10 --> Helper loaded: security_helper
INFO - 2024-02-12 07:53:10 --> Helper loaded: cookie_helper
INFO - 2024-02-12 07:53:10 --> Database Driver Class Initialized
INFO - 2024-02-12 07:53:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 07:53:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 07:53:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 07:53:10 --> Final output sent to browser
DEBUG - 2024-02-12 07:53:10 --> Total execution time: 0.2269
INFO - 2024-02-12 07:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 07:53:10 --> Parser Class Initialized
INFO - 2024-02-12 07:53:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 07:53:10 --> Pagination Class Initialized
INFO - 2024-02-12 07:53:10 --> Form Validation Class Initialized
INFO - 2024-02-12 07:53:10 --> Controller Class Initialized
INFO - 2024-02-12 07:53:10 --> Model Class Initialized
DEBUG - 2024-02-12 07:53:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:53:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-12 07:53:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:53:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 07:53:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 07:53:10 --> Model Class Initialized
INFO - 2024-02-12 07:53:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 07:53:10 --> Final output sent to browser
DEBUG - 2024-02-12 07:53:10 --> Total execution time: 0.0796
ERROR - 2024-02-12 07:53:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 07:53:10 --> Config Class Initialized
INFO - 2024-02-12 07:53:10 --> Hooks Class Initialized
DEBUG - 2024-02-12 07:53:10 --> UTF-8 Support Enabled
INFO - 2024-02-12 07:53:10 --> Utf8 Class Initialized
INFO - 2024-02-12 07:53:10 --> URI Class Initialized
INFO - 2024-02-12 07:53:10 --> Router Class Initialized
INFO - 2024-02-12 07:53:10 --> Output Class Initialized
INFO - 2024-02-12 07:53:10 --> Security Class Initialized
DEBUG - 2024-02-12 07:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 07:53:10 --> Input Class Initialized
INFO - 2024-02-12 07:53:10 --> Language Class Initialized
INFO - 2024-02-12 07:53:10 --> Loader Class Initialized
INFO - 2024-02-12 07:53:10 --> Helper loaded: url_helper
INFO - 2024-02-12 07:53:10 --> Helper loaded: file_helper
INFO - 2024-02-12 07:53:10 --> Helper loaded: html_helper
INFO - 2024-02-12 07:53:10 --> Helper loaded: text_helper
INFO - 2024-02-12 07:53:10 --> Helper loaded: form_helper
INFO - 2024-02-12 07:53:10 --> Helper loaded: lang_helper
INFO - 2024-02-12 07:53:10 --> Helper loaded: security_helper
INFO - 2024-02-12 07:53:10 --> Helper loaded: cookie_helper
INFO - 2024-02-12 07:53:10 --> Database Driver Class Initialized
INFO - 2024-02-12 07:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 07:53:10 --> Parser Class Initialized
INFO - 2024-02-12 07:53:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 07:53:10 --> Pagination Class Initialized
INFO - 2024-02-12 07:53:10 --> Form Validation Class Initialized
INFO - 2024-02-12 07:53:10 --> Controller Class Initialized
INFO - 2024-02-12 07:53:10 --> Model Class Initialized
DEBUG - 2024-02-12 07:53:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:53:10 --> Model Class Initialized
DEBUG - 2024-02-12 07:53:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:53:10 --> Model Class Initialized
INFO - 2024-02-12 07:53:10 --> Model Class Initialized
INFO - 2024-02-12 07:53:10 --> Model Class Initialized
INFO - 2024-02-12 07:53:10 --> Model Class Initialized
DEBUG - 2024-02-12 07:53:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 07:53:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:53:10 --> Model Class Initialized
INFO - 2024-02-12 07:53:10 --> Model Class Initialized
INFO - 2024-02-12 07:53:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-12 07:53:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:53:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 07:53:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 07:53:10 --> Model Class Initialized
INFO - 2024-02-12 07:53:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 07:53:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 07:53:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 07:53:10 --> Final output sent to browser
DEBUG - 2024-02-12 07:53:10 --> Total execution time: 0.2292
ERROR - 2024-02-12 07:53:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 07:53:14 --> Config Class Initialized
INFO - 2024-02-12 07:53:14 --> Hooks Class Initialized
DEBUG - 2024-02-12 07:53:14 --> UTF-8 Support Enabled
INFO - 2024-02-12 07:53:14 --> Utf8 Class Initialized
INFO - 2024-02-12 07:53:14 --> URI Class Initialized
INFO - 2024-02-12 07:53:14 --> Router Class Initialized
INFO - 2024-02-12 07:53:14 --> Output Class Initialized
INFO - 2024-02-12 07:53:14 --> Security Class Initialized
DEBUG - 2024-02-12 07:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 07:53:14 --> Input Class Initialized
INFO - 2024-02-12 07:53:14 --> Language Class Initialized
INFO - 2024-02-12 07:53:14 --> Loader Class Initialized
INFO - 2024-02-12 07:53:14 --> Helper loaded: url_helper
INFO - 2024-02-12 07:53:14 --> Helper loaded: file_helper
INFO - 2024-02-12 07:53:14 --> Helper loaded: html_helper
INFO - 2024-02-12 07:53:14 --> Helper loaded: text_helper
INFO - 2024-02-12 07:53:14 --> Helper loaded: form_helper
INFO - 2024-02-12 07:53:14 --> Helper loaded: lang_helper
INFO - 2024-02-12 07:53:14 --> Helper loaded: security_helper
INFO - 2024-02-12 07:53:14 --> Helper loaded: cookie_helper
INFO - 2024-02-12 07:53:14 --> Database Driver Class Initialized
INFO - 2024-02-12 07:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 07:53:14 --> Parser Class Initialized
INFO - 2024-02-12 07:53:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 07:53:14 --> Pagination Class Initialized
INFO - 2024-02-12 07:53:14 --> Form Validation Class Initialized
INFO - 2024-02-12 07:53:14 --> Controller Class Initialized
INFO - 2024-02-12 07:53:14 --> Model Class Initialized
DEBUG - 2024-02-12 07:53:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:53:14 --> Model Class Initialized
INFO - 2024-02-12 07:53:14 --> Final output sent to browser
DEBUG - 2024-02-12 07:53:14 --> Total execution time: 0.0187
ERROR - 2024-02-12 07:53:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 07:53:14 --> Config Class Initialized
INFO - 2024-02-12 07:53:14 --> Hooks Class Initialized
DEBUG - 2024-02-12 07:53:14 --> UTF-8 Support Enabled
INFO - 2024-02-12 07:53:14 --> Utf8 Class Initialized
INFO - 2024-02-12 07:53:14 --> URI Class Initialized
DEBUG - 2024-02-12 07:53:14 --> No URI present. Default controller set.
INFO - 2024-02-12 07:53:14 --> Router Class Initialized
INFO - 2024-02-12 07:53:14 --> Output Class Initialized
INFO - 2024-02-12 07:53:14 --> Security Class Initialized
DEBUG - 2024-02-12 07:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 07:53:14 --> Input Class Initialized
INFO - 2024-02-12 07:53:14 --> Language Class Initialized
INFO - 2024-02-12 07:53:14 --> Loader Class Initialized
INFO - 2024-02-12 07:53:14 --> Helper loaded: url_helper
INFO - 2024-02-12 07:53:14 --> Helper loaded: file_helper
INFO - 2024-02-12 07:53:14 --> Helper loaded: html_helper
INFO - 2024-02-12 07:53:14 --> Helper loaded: text_helper
INFO - 2024-02-12 07:53:14 --> Helper loaded: form_helper
INFO - 2024-02-12 07:53:14 --> Helper loaded: lang_helper
INFO - 2024-02-12 07:53:14 --> Helper loaded: security_helper
INFO - 2024-02-12 07:53:14 --> Helper loaded: cookie_helper
INFO - 2024-02-12 07:53:14 --> Database Driver Class Initialized
INFO - 2024-02-12 07:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 07:53:14 --> Parser Class Initialized
INFO - 2024-02-12 07:53:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 07:53:14 --> Pagination Class Initialized
INFO - 2024-02-12 07:53:14 --> Form Validation Class Initialized
INFO - 2024-02-12 07:53:14 --> Controller Class Initialized
INFO - 2024-02-12 07:53:14 --> Model Class Initialized
DEBUG - 2024-02-12 07:53:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:53:14 --> Model Class Initialized
DEBUG - 2024-02-12 07:53:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:53:14 --> Model Class Initialized
INFO - 2024-02-12 07:53:14 --> Model Class Initialized
INFO - 2024-02-12 07:53:14 --> Model Class Initialized
INFO - 2024-02-12 07:53:14 --> Model Class Initialized
DEBUG - 2024-02-12 07:53:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 07:53:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:53:14 --> Model Class Initialized
INFO - 2024-02-12 07:53:14 --> Model Class Initialized
INFO - 2024-02-12 07:53:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-12 07:53:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:53:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 07:53:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 07:53:14 --> Model Class Initialized
INFO - 2024-02-12 07:53:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 07:53:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 07:53:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 07:53:15 --> Final output sent to browser
DEBUG - 2024-02-12 07:53:15 --> Total execution time: 0.3872
ERROR - 2024-02-12 07:53:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 07:53:19 --> Config Class Initialized
INFO - 2024-02-12 07:53:19 --> Hooks Class Initialized
DEBUG - 2024-02-12 07:53:19 --> UTF-8 Support Enabled
INFO - 2024-02-12 07:53:19 --> Utf8 Class Initialized
INFO - 2024-02-12 07:53:19 --> URI Class Initialized
INFO - 2024-02-12 07:53:19 --> Router Class Initialized
INFO - 2024-02-12 07:53:19 --> Output Class Initialized
INFO - 2024-02-12 07:53:19 --> Security Class Initialized
DEBUG - 2024-02-12 07:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 07:53:19 --> Input Class Initialized
INFO - 2024-02-12 07:53:19 --> Language Class Initialized
INFO - 2024-02-12 07:53:19 --> Loader Class Initialized
INFO - 2024-02-12 07:53:19 --> Helper loaded: url_helper
INFO - 2024-02-12 07:53:19 --> Helper loaded: file_helper
INFO - 2024-02-12 07:53:19 --> Helper loaded: html_helper
INFO - 2024-02-12 07:53:19 --> Helper loaded: text_helper
INFO - 2024-02-12 07:53:19 --> Helper loaded: form_helper
INFO - 2024-02-12 07:53:19 --> Helper loaded: lang_helper
INFO - 2024-02-12 07:53:19 --> Helper loaded: security_helper
INFO - 2024-02-12 07:53:19 --> Helper loaded: cookie_helper
INFO - 2024-02-12 07:53:19 --> Database Driver Class Initialized
INFO - 2024-02-12 07:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 07:53:19 --> Parser Class Initialized
INFO - 2024-02-12 07:53:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 07:53:19 --> Pagination Class Initialized
INFO - 2024-02-12 07:53:19 --> Form Validation Class Initialized
INFO - 2024-02-12 07:53:19 --> Controller Class Initialized
DEBUG - 2024-02-12 07:53:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 07:53:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:53:19 --> Model Class Initialized
INFO - 2024-02-12 07:53:19 --> Final output sent to browser
DEBUG - 2024-02-12 07:53:19 --> Total execution time: 0.0154
ERROR - 2024-02-12 07:53:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 07:53:35 --> Config Class Initialized
INFO - 2024-02-12 07:53:35 --> Hooks Class Initialized
DEBUG - 2024-02-12 07:53:35 --> UTF-8 Support Enabled
INFO - 2024-02-12 07:53:35 --> Utf8 Class Initialized
INFO - 2024-02-12 07:53:35 --> URI Class Initialized
INFO - 2024-02-12 07:53:35 --> Router Class Initialized
INFO - 2024-02-12 07:53:35 --> Output Class Initialized
INFO - 2024-02-12 07:53:35 --> Security Class Initialized
DEBUG - 2024-02-12 07:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 07:53:35 --> Input Class Initialized
INFO - 2024-02-12 07:53:35 --> Language Class Initialized
INFO - 2024-02-12 07:53:35 --> Loader Class Initialized
INFO - 2024-02-12 07:53:35 --> Helper loaded: url_helper
INFO - 2024-02-12 07:53:35 --> Helper loaded: file_helper
INFO - 2024-02-12 07:53:35 --> Helper loaded: html_helper
INFO - 2024-02-12 07:53:35 --> Helper loaded: text_helper
INFO - 2024-02-12 07:53:35 --> Helper loaded: form_helper
INFO - 2024-02-12 07:53:35 --> Helper loaded: lang_helper
INFO - 2024-02-12 07:53:35 --> Helper loaded: security_helper
INFO - 2024-02-12 07:53:35 --> Helper loaded: cookie_helper
INFO - 2024-02-12 07:53:35 --> Database Driver Class Initialized
INFO - 2024-02-12 07:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 07:53:35 --> Parser Class Initialized
INFO - 2024-02-12 07:53:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 07:53:35 --> Pagination Class Initialized
INFO - 2024-02-12 07:53:35 --> Form Validation Class Initialized
INFO - 2024-02-12 07:53:35 --> Controller Class Initialized
DEBUG - 2024-02-12 07:53:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 07:53:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:53:35 --> Model Class Initialized
DEBUG - 2024-02-12 07:53:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:53:35 --> Model Class Initialized
DEBUG - 2024-02-12 07:53:35 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:53:35 --> Model Class Initialized
INFO - 2024-02-12 07:53:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-12 07:53:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:53:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 07:53:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 07:53:35 --> Model Class Initialized
INFO - 2024-02-12 07:53:35 --> Model Class Initialized
INFO - 2024-02-12 07:53:35 --> Model Class Initialized
INFO - 2024-02-12 07:53:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 07:53:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 07:53:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 07:53:35 --> Final output sent to browser
DEBUG - 2024-02-12 07:53:35 --> Total execution time: 0.2000
ERROR - 2024-02-12 07:53:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 07:53:36 --> Config Class Initialized
INFO - 2024-02-12 07:53:36 --> Hooks Class Initialized
DEBUG - 2024-02-12 07:53:36 --> UTF-8 Support Enabled
INFO - 2024-02-12 07:53:36 --> Utf8 Class Initialized
INFO - 2024-02-12 07:53:36 --> URI Class Initialized
INFO - 2024-02-12 07:53:36 --> Router Class Initialized
INFO - 2024-02-12 07:53:36 --> Output Class Initialized
INFO - 2024-02-12 07:53:36 --> Security Class Initialized
DEBUG - 2024-02-12 07:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 07:53:36 --> Input Class Initialized
INFO - 2024-02-12 07:53:36 --> Language Class Initialized
INFO - 2024-02-12 07:53:36 --> Loader Class Initialized
INFO - 2024-02-12 07:53:36 --> Helper loaded: url_helper
INFO - 2024-02-12 07:53:36 --> Helper loaded: file_helper
INFO - 2024-02-12 07:53:36 --> Helper loaded: html_helper
INFO - 2024-02-12 07:53:36 --> Helper loaded: text_helper
INFO - 2024-02-12 07:53:36 --> Helper loaded: form_helper
INFO - 2024-02-12 07:53:36 --> Helper loaded: lang_helper
INFO - 2024-02-12 07:53:36 --> Helper loaded: security_helper
INFO - 2024-02-12 07:53:36 --> Helper loaded: cookie_helper
INFO - 2024-02-12 07:53:36 --> Database Driver Class Initialized
INFO - 2024-02-12 07:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 07:53:36 --> Parser Class Initialized
INFO - 2024-02-12 07:53:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 07:53:36 --> Pagination Class Initialized
INFO - 2024-02-12 07:53:36 --> Form Validation Class Initialized
INFO - 2024-02-12 07:53:36 --> Controller Class Initialized
DEBUG - 2024-02-12 07:53:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 07:53:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:53:36 --> Model Class Initialized
DEBUG - 2024-02-12 07:53:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:53:36 --> Model Class Initialized
INFO - 2024-02-12 07:53:36 --> Final output sent to browser
DEBUG - 2024-02-12 07:53:36 --> Total execution time: 0.0326
ERROR - 2024-02-12 07:54:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 07:54:04 --> Config Class Initialized
INFO - 2024-02-12 07:54:04 --> Hooks Class Initialized
DEBUG - 2024-02-12 07:54:04 --> UTF-8 Support Enabled
INFO - 2024-02-12 07:54:04 --> Utf8 Class Initialized
INFO - 2024-02-12 07:54:04 --> URI Class Initialized
INFO - 2024-02-12 07:54:04 --> Router Class Initialized
INFO - 2024-02-12 07:54:04 --> Output Class Initialized
INFO - 2024-02-12 07:54:04 --> Security Class Initialized
DEBUG - 2024-02-12 07:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 07:54:04 --> Input Class Initialized
INFO - 2024-02-12 07:54:04 --> Language Class Initialized
INFO - 2024-02-12 07:54:04 --> Loader Class Initialized
INFO - 2024-02-12 07:54:04 --> Helper loaded: url_helper
INFO - 2024-02-12 07:54:04 --> Helper loaded: file_helper
INFO - 2024-02-12 07:54:04 --> Helper loaded: html_helper
INFO - 2024-02-12 07:54:04 --> Helper loaded: text_helper
INFO - 2024-02-12 07:54:04 --> Helper loaded: form_helper
INFO - 2024-02-12 07:54:04 --> Helper loaded: lang_helper
INFO - 2024-02-12 07:54:04 --> Helper loaded: security_helper
INFO - 2024-02-12 07:54:04 --> Helper loaded: cookie_helper
INFO - 2024-02-12 07:54:04 --> Database Driver Class Initialized
INFO - 2024-02-12 07:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 07:54:04 --> Parser Class Initialized
INFO - 2024-02-12 07:54:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 07:54:04 --> Pagination Class Initialized
INFO - 2024-02-12 07:54:04 --> Form Validation Class Initialized
INFO - 2024-02-12 07:54:04 --> Controller Class Initialized
DEBUG - 2024-02-12 07:54:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 07:54:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:54:04 --> Model Class Initialized
DEBUG - 2024-02-12 07:54:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:54:04 --> Model Class Initialized
INFO - 2024-02-12 07:54:04 --> Final output sent to browser
DEBUG - 2024-02-12 07:54:04 --> Total execution time: 0.1573
ERROR - 2024-02-12 07:54:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 07:54:17 --> Config Class Initialized
INFO - 2024-02-12 07:54:17 --> Hooks Class Initialized
DEBUG - 2024-02-12 07:54:17 --> UTF-8 Support Enabled
INFO - 2024-02-12 07:54:17 --> Utf8 Class Initialized
INFO - 2024-02-12 07:54:17 --> URI Class Initialized
INFO - 2024-02-12 07:54:17 --> Router Class Initialized
INFO - 2024-02-12 07:54:17 --> Output Class Initialized
INFO - 2024-02-12 07:54:17 --> Security Class Initialized
DEBUG - 2024-02-12 07:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 07:54:17 --> Input Class Initialized
INFO - 2024-02-12 07:54:17 --> Language Class Initialized
INFO - 2024-02-12 07:54:17 --> Loader Class Initialized
INFO - 2024-02-12 07:54:17 --> Helper loaded: url_helper
INFO - 2024-02-12 07:54:17 --> Helper loaded: file_helper
INFO - 2024-02-12 07:54:17 --> Helper loaded: html_helper
INFO - 2024-02-12 07:54:17 --> Helper loaded: text_helper
INFO - 2024-02-12 07:54:17 --> Helper loaded: form_helper
INFO - 2024-02-12 07:54:17 --> Helper loaded: lang_helper
INFO - 2024-02-12 07:54:17 --> Helper loaded: security_helper
INFO - 2024-02-12 07:54:17 --> Helper loaded: cookie_helper
INFO - 2024-02-12 07:54:17 --> Database Driver Class Initialized
INFO - 2024-02-12 07:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 07:54:17 --> Parser Class Initialized
INFO - 2024-02-12 07:54:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 07:54:17 --> Pagination Class Initialized
INFO - 2024-02-12 07:54:17 --> Form Validation Class Initialized
INFO - 2024-02-12 07:54:17 --> Controller Class Initialized
DEBUG - 2024-02-12 07:54:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 07:54:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:54:17 --> Model Class Initialized
DEBUG - 2024-02-12 07:54:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:54:17 --> Model Class Initialized
INFO - 2024-02-12 07:54:17 --> Final output sent to browser
DEBUG - 2024-02-12 07:54:17 --> Total execution time: 0.2237
ERROR - 2024-02-12 07:54:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 07:54:36 --> Config Class Initialized
INFO - 2024-02-12 07:54:36 --> Hooks Class Initialized
DEBUG - 2024-02-12 07:54:36 --> UTF-8 Support Enabled
INFO - 2024-02-12 07:54:36 --> Utf8 Class Initialized
INFO - 2024-02-12 07:54:36 --> URI Class Initialized
INFO - 2024-02-12 07:54:36 --> Router Class Initialized
INFO - 2024-02-12 07:54:36 --> Output Class Initialized
INFO - 2024-02-12 07:54:36 --> Security Class Initialized
DEBUG - 2024-02-12 07:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 07:54:36 --> Input Class Initialized
INFO - 2024-02-12 07:54:36 --> Language Class Initialized
INFO - 2024-02-12 07:54:36 --> Loader Class Initialized
INFO - 2024-02-12 07:54:36 --> Helper loaded: url_helper
INFO - 2024-02-12 07:54:36 --> Helper loaded: file_helper
INFO - 2024-02-12 07:54:36 --> Helper loaded: html_helper
INFO - 2024-02-12 07:54:36 --> Helper loaded: text_helper
INFO - 2024-02-12 07:54:36 --> Helper loaded: form_helper
INFO - 2024-02-12 07:54:36 --> Helper loaded: lang_helper
INFO - 2024-02-12 07:54:36 --> Helper loaded: security_helper
INFO - 2024-02-12 07:54:36 --> Helper loaded: cookie_helper
INFO - 2024-02-12 07:54:36 --> Database Driver Class Initialized
INFO - 2024-02-12 07:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 07:54:36 --> Parser Class Initialized
INFO - 2024-02-12 07:54:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 07:54:36 --> Pagination Class Initialized
INFO - 2024-02-12 07:54:36 --> Form Validation Class Initialized
INFO - 2024-02-12 07:54:36 --> Controller Class Initialized
DEBUG - 2024-02-12 07:54:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 07:54:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:54:36 --> Model Class Initialized
DEBUG - 2024-02-12 07:54:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:54:36 --> Model Class Initialized
INFO - 2024-02-12 07:54:36 --> Final output sent to browser
DEBUG - 2024-02-12 07:54:36 --> Total execution time: 0.1996
ERROR - 2024-02-12 07:54:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 07:54:37 --> Config Class Initialized
INFO - 2024-02-12 07:54:37 --> Hooks Class Initialized
DEBUG - 2024-02-12 07:54:37 --> UTF-8 Support Enabled
INFO - 2024-02-12 07:54:37 --> Utf8 Class Initialized
INFO - 2024-02-12 07:54:37 --> URI Class Initialized
INFO - 2024-02-12 07:54:37 --> Router Class Initialized
INFO - 2024-02-12 07:54:37 --> Output Class Initialized
INFO - 2024-02-12 07:54:37 --> Security Class Initialized
DEBUG - 2024-02-12 07:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 07:54:37 --> Input Class Initialized
INFO - 2024-02-12 07:54:37 --> Language Class Initialized
INFO - 2024-02-12 07:54:37 --> Loader Class Initialized
INFO - 2024-02-12 07:54:37 --> Helper loaded: url_helper
INFO - 2024-02-12 07:54:37 --> Helper loaded: file_helper
INFO - 2024-02-12 07:54:37 --> Helper loaded: html_helper
INFO - 2024-02-12 07:54:37 --> Helper loaded: text_helper
INFO - 2024-02-12 07:54:37 --> Helper loaded: form_helper
INFO - 2024-02-12 07:54:37 --> Helper loaded: lang_helper
INFO - 2024-02-12 07:54:37 --> Helper loaded: security_helper
INFO - 2024-02-12 07:54:37 --> Helper loaded: cookie_helper
INFO - 2024-02-12 07:54:37 --> Database Driver Class Initialized
INFO - 2024-02-12 07:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 07:54:37 --> Parser Class Initialized
INFO - 2024-02-12 07:54:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 07:54:37 --> Pagination Class Initialized
INFO - 2024-02-12 07:54:37 --> Form Validation Class Initialized
INFO - 2024-02-12 07:54:37 --> Controller Class Initialized
DEBUG - 2024-02-12 07:54:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 07:54:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:54:37 --> Model Class Initialized
DEBUG - 2024-02-12 07:54:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:54:37 --> Model Class Initialized
INFO - 2024-02-12 07:54:38 --> Final output sent to browser
DEBUG - 2024-02-12 07:54:38 --> Total execution time: 0.2018
ERROR - 2024-02-12 07:55:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 07:55:53 --> Config Class Initialized
INFO - 2024-02-12 07:55:53 --> Hooks Class Initialized
DEBUG - 2024-02-12 07:55:53 --> UTF-8 Support Enabled
INFO - 2024-02-12 07:55:53 --> Utf8 Class Initialized
INFO - 2024-02-12 07:55:53 --> URI Class Initialized
INFO - 2024-02-12 07:55:53 --> Router Class Initialized
INFO - 2024-02-12 07:55:53 --> Output Class Initialized
INFO - 2024-02-12 07:55:53 --> Security Class Initialized
DEBUG - 2024-02-12 07:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 07:55:53 --> Input Class Initialized
INFO - 2024-02-12 07:55:53 --> Language Class Initialized
INFO - 2024-02-12 07:55:53 --> Loader Class Initialized
INFO - 2024-02-12 07:55:53 --> Helper loaded: url_helper
INFO - 2024-02-12 07:55:53 --> Helper loaded: file_helper
INFO - 2024-02-12 07:55:53 --> Helper loaded: html_helper
INFO - 2024-02-12 07:55:53 --> Helper loaded: text_helper
INFO - 2024-02-12 07:55:53 --> Helper loaded: form_helper
INFO - 2024-02-12 07:55:53 --> Helper loaded: lang_helper
INFO - 2024-02-12 07:55:53 --> Helper loaded: security_helper
INFO - 2024-02-12 07:55:53 --> Helper loaded: cookie_helper
INFO - 2024-02-12 07:55:53 --> Database Driver Class Initialized
INFO - 2024-02-12 07:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 07:55:53 --> Parser Class Initialized
INFO - 2024-02-12 07:55:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 07:55:53 --> Pagination Class Initialized
INFO - 2024-02-12 07:55:53 --> Form Validation Class Initialized
INFO - 2024-02-12 07:55:53 --> Controller Class Initialized
DEBUG - 2024-02-12 07:55:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 07:55:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:55:53 --> Model Class Initialized
DEBUG - 2024-02-12 07:55:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:55:53 --> Model Class Initialized
INFO - 2024-02-12 07:55:54 --> Final output sent to browser
DEBUG - 2024-02-12 07:55:54 --> Total execution time: 0.1990
ERROR - 2024-02-12 07:55:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 07:55:56 --> Config Class Initialized
INFO - 2024-02-12 07:55:56 --> Hooks Class Initialized
DEBUG - 2024-02-12 07:55:56 --> UTF-8 Support Enabled
INFO - 2024-02-12 07:55:56 --> Utf8 Class Initialized
INFO - 2024-02-12 07:55:56 --> URI Class Initialized
DEBUG - 2024-02-12 07:55:56 --> No URI present. Default controller set.
INFO - 2024-02-12 07:55:56 --> Router Class Initialized
INFO - 2024-02-12 07:55:56 --> Output Class Initialized
INFO - 2024-02-12 07:55:56 --> Security Class Initialized
DEBUG - 2024-02-12 07:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 07:55:56 --> Input Class Initialized
INFO - 2024-02-12 07:55:56 --> Language Class Initialized
INFO - 2024-02-12 07:55:56 --> Loader Class Initialized
INFO - 2024-02-12 07:55:56 --> Helper loaded: url_helper
INFO - 2024-02-12 07:55:56 --> Helper loaded: file_helper
INFO - 2024-02-12 07:55:56 --> Helper loaded: html_helper
INFO - 2024-02-12 07:55:56 --> Helper loaded: text_helper
INFO - 2024-02-12 07:55:56 --> Helper loaded: form_helper
INFO - 2024-02-12 07:55:56 --> Helper loaded: lang_helper
INFO - 2024-02-12 07:55:56 --> Helper loaded: security_helper
INFO - 2024-02-12 07:55:56 --> Helper loaded: cookie_helper
INFO - 2024-02-12 07:55:56 --> Database Driver Class Initialized
INFO - 2024-02-12 07:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 07:55:56 --> Parser Class Initialized
INFO - 2024-02-12 07:55:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 07:55:56 --> Pagination Class Initialized
INFO - 2024-02-12 07:55:56 --> Form Validation Class Initialized
INFO - 2024-02-12 07:55:56 --> Controller Class Initialized
INFO - 2024-02-12 07:55:56 --> Model Class Initialized
DEBUG - 2024-02-12 07:55:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:55:56 --> Model Class Initialized
DEBUG - 2024-02-12 07:55:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:55:56 --> Model Class Initialized
INFO - 2024-02-12 07:55:56 --> Model Class Initialized
INFO - 2024-02-12 07:55:56 --> Model Class Initialized
INFO - 2024-02-12 07:55:56 --> Model Class Initialized
DEBUG - 2024-02-12 07:55:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 07:55:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:55:56 --> Model Class Initialized
INFO - 2024-02-12 07:55:56 --> Model Class Initialized
INFO - 2024-02-12 07:55:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-12 07:55:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:55:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 07:55:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 07:55:56 --> Model Class Initialized
INFO - 2024-02-12 07:55:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 07:55:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 07:55:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 07:55:56 --> Final output sent to browser
DEBUG - 2024-02-12 07:55:56 --> Total execution time: 0.4159
ERROR - 2024-02-12 07:56:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 07:56:05 --> Config Class Initialized
INFO - 2024-02-12 07:56:05 --> Hooks Class Initialized
DEBUG - 2024-02-12 07:56:05 --> UTF-8 Support Enabled
INFO - 2024-02-12 07:56:05 --> Utf8 Class Initialized
INFO - 2024-02-12 07:56:05 --> URI Class Initialized
INFO - 2024-02-12 07:56:05 --> Router Class Initialized
INFO - 2024-02-12 07:56:05 --> Output Class Initialized
INFO - 2024-02-12 07:56:05 --> Security Class Initialized
DEBUG - 2024-02-12 07:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 07:56:05 --> Input Class Initialized
INFO - 2024-02-12 07:56:05 --> Language Class Initialized
INFO - 2024-02-12 07:56:05 --> Loader Class Initialized
INFO - 2024-02-12 07:56:05 --> Helper loaded: url_helper
INFO - 2024-02-12 07:56:05 --> Helper loaded: file_helper
INFO - 2024-02-12 07:56:05 --> Helper loaded: html_helper
INFO - 2024-02-12 07:56:05 --> Helper loaded: text_helper
INFO - 2024-02-12 07:56:05 --> Helper loaded: form_helper
INFO - 2024-02-12 07:56:05 --> Helper loaded: lang_helper
INFO - 2024-02-12 07:56:05 --> Helper loaded: security_helper
INFO - 2024-02-12 07:56:05 --> Helper loaded: cookie_helper
INFO - 2024-02-12 07:56:05 --> Database Driver Class Initialized
INFO - 2024-02-12 07:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 07:56:05 --> Parser Class Initialized
INFO - 2024-02-12 07:56:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 07:56:05 --> Pagination Class Initialized
INFO - 2024-02-12 07:56:05 --> Form Validation Class Initialized
INFO - 2024-02-12 07:56:05 --> Controller Class Initialized
DEBUG - 2024-02-12 07:56:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 07:56:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:56:05 --> Model Class Initialized
DEBUG - 2024-02-12 07:56:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:56:05 --> Model Class Initialized
DEBUG - 2024-02-12 07:56:05 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:56:05 --> Model Class Initialized
INFO - 2024-02-12 07:56:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-12 07:56:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:56:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 07:56:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 07:56:05 --> Model Class Initialized
INFO - 2024-02-12 07:56:05 --> Model Class Initialized
INFO - 2024-02-12 07:56:05 --> Model Class Initialized
INFO - 2024-02-12 07:56:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 07:56:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 07:56:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 07:56:06 --> Final output sent to browser
DEBUG - 2024-02-12 07:56:06 --> Total execution time: 0.1962
ERROR - 2024-02-12 07:56:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 07:56:06 --> Config Class Initialized
INFO - 2024-02-12 07:56:06 --> Hooks Class Initialized
DEBUG - 2024-02-12 07:56:06 --> UTF-8 Support Enabled
INFO - 2024-02-12 07:56:06 --> Utf8 Class Initialized
INFO - 2024-02-12 07:56:06 --> URI Class Initialized
INFO - 2024-02-12 07:56:06 --> Router Class Initialized
INFO - 2024-02-12 07:56:06 --> Output Class Initialized
INFO - 2024-02-12 07:56:06 --> Security Class Initialized
DEBUG - 2024-02-12 07:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 07:56:06 --> Input Class Initialized
INFO - 2024-02-12 07:56:06 --> Language Class Initialized
INFO - 2024-02-12 07:56:06 --> Loader Class Initialized
INFO - 2024-02-12 07:56:06 --> Helper loaded: url_helper
INFO - 2024-02-12 07:56:06 --> Helper loaded: file_helper
INFO - 2024-02-12 07:56:06 --> Helper loaded: html_helper
INFO - 2024-02-12 07:56:06 --> Helper loaded: text_helper
INFO - 2024-02-12 07:56:06 --> Helper loaded: form_helper
INFO - 2024-02-12 07:56:06 --> Helper loaded: lang_helper
INFO - 2024-02-12 07:56:06 --> Helper loaded: security_helper
INFO - 2024-02-12 07:56:06 --> Helper loaded: cookie_helper
INFO - 2024-02-12 07:56:06 --> Database Driver Class Initialized
INFO - 2024-02-12 07:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 07:56:06 --> Parser Class Initialized
INFO - 2024-02-12 07:56:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 07:56:06 --> Pagination Class Initialized
INFO - 2024-02-12 07:56:06 --> Form Validation Class Initialized
INFO - 2024-02-12 07:56:06 --> Controller Class Initialized
DEBUG - 2024-02-12 07:56:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 07:56:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:56:06 --> Model Class Initialized
DEBUG - 2024-02-12 07:56:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:56:06 --> Model Class Initialized
INFO - 2024-02-12 07:56:06 --> Final output sent to browser
DEBUG - 2024-02-12 07:56:06 --> Total execution time: 0.0387
ERROR - 2024-02-12 07:56:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 07:56:19 --> Config Class Initialized
INFO - 2024-02-12 07:56:19 --> Hooks Class Initialized
DEBUG - 2024-02-12 07:56:19 --> UTF-8 Support Enabled
INFO - 2024-02-12 07:56:19 --> Utf8 Class Initialized
INFO - 2024-02-12 07:56:19 --> URI Class Initialized
INFO - 2024-02-12 07:56:19 --> Router Class Initialized
INFO - 2024-02-12 07:56:19 --> Output Class Initialized
INFO - 2024-02-12 07:56:19 --> Security Class Initialized
DEBUG - 2024-02-12 07:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 07:56:19 --> Input Class Initialized
INFO - 2024-02-12 07:56:19 --> Language Class Initialized
INFO - 2024-02-12 07:56:19 --> Loader Class Initialized
INFO - 2024-02-12 07:56:19 --> Helper loaded: url_helper
INFO - 2024-02-12 07:56:19 --> Helper loaded: file_helper
INFO - 2024-02-12 07:56:19 --> Helper loaded: html_helper
INFO - 2024-02-12 07:56:19 --> Helper loaded: text_helper
INFO - 2024-02-12 07:56:19 --> Helper loaded: form_helper
INFO - 2024-02-12 07:56:19 --> Helper loaded: lang_helper
INFO - 2024-02-12 07:56:19 --> Helper loaded: security_helper
INFO - 2024-02-12 07:56:19 --> Helper loaded: cookie_helper
INFO - 2024-02-12 07:56:19 --> Database Driver Class Initialized
INFO - 2024-02-12 07:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 07:56:19 --> Parser Class Initialized
INFO - 2024-02-12 07:56:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 07:56:19 --> Pagination Class Initialized
INFO - 2024-02-12 07:56:19 --> Form Validation Class Initialized
INFO - 2024-02-12 07:56:19 --> Controller Class Initialized
DEBUG - 2024-02-12 07:56:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 07:56:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:56:19 --> Model Class Initialized
DEBUG - 2024-02-12 07:56:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:56:19 --> Model Class Initialized
INFO - 2024-02-12 07:56:19 --> Final output sent to browser
DEBUG - 2024-02-12 07:56:19 --> Total execution time: 0.1958
ERROR - 2024-02-12 07:58:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 07:58:04 --> Config Class Initialized
INFO - 2024-02-12 07:58:04 --> Hooks Class Initialized
DEBUG - 2024-02-12 07:58:04 --> UTF-8 Support Enabled
INFO - 2024-02-12 07:58:04 --> Utf8 Class Initialized
INFO - 2024-02-12 07:58:04 --> URI Class Initialized
INFO - 2024-02-12 07:58:04 --> Router Class Initialized
INFO - 2024-02-12 07:58:04 --> Output Class Initialized
INFO - 2024-02-12 07:58:04 --> Security Class Initialized
DEBUG - 2024-02-12 07:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 07:58:04 --> Input Class Initialized
INFO - 2024-02-12 07:58:04 --> Language Class Initialized
INFO - 2024-02-12 07:58:04 --> Loader Class Initialized
INFO - 2024-02-12 07:58:04 --> Helper loaded: url_helper
INFO - 2024-02-12 07:58:04 --> Helper loaded: file_helper
INFO - 2024-02-12 07:58:04 --> Helper loaded: html_helper
INFO - 2024-02-12 07:58:04 --> Helper loaded: text_helper
INFO - 2024-02-12 07:58:04 --> Helper loaded: form_helper
INFO - 2024-02-12 07:58:04 --> Helper loaded: lang_helper
INFO - 2024-02-12 07:58:04 --> Helper loaded: security_helper
INFO - 2024-02-12 07:58:04 --> Helper loaded: cookie_helper
INFO - 2024-02-12 07:58:04 --> Database Driver Class Initialized
INFO - 2024-02-12 07:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 07:58:04 --> Parser Class Initialized
INFO - 2024-02-12 07:58:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 07:58:04 --> Pagination Class Initialized
INFO - 2024-02-12 07:58:04 --> Form Validation Class Initialized
INFO - 2024-02-12 07:58:04 --> Controller Class Initialized
DEBUG - 2024-02-12 07:58:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 07:58:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:58:04 --> Model Class Initialized
DEBUG - 2024-02-12 07:58:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:58:04 --> Model Class Initialized
INFO - 2024-02-12 07:58:04 --> Final output sent to browser
DEBUG - 2024-02-12 07:58:04 --> Total execution time: 0.1723
ERROR - 2024-02-12 07:58:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 07:58:05 --> Config Class Initialized
INFO - 2024-02-12 07:58:05 --> Hooks Class Initialized
DEBUG - 2024-02-12 07:58:05 --> UTF-8 Support Enabled
INFO - 2024-02-12 07:58:05 --> Utf8 Class Initialized
INFO - 2024-02-12 07:58:05 --> URI Class Initialized
INFO - 2024-02-12 07:58:05 --> Router Class Initialized
INFO - 2024-02-12 07:58:05 --> Output Class Initialized
INFO - 2024-02-12 07:58:05 --> Security Class Initialized
DEBUG - 2024-02-12 07:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 07:58:05 --> Input Class Initialized
INFO - 2024-02-12 07:58:05 --> Language Class Initialized
INFO - 2024-02-12 07:58:05 --> Loader Class Initialized
INFO - 2024-02-12 07:58:05 --> Helper loaded: url_helper
INFO - 2024-02-12 07:58:05 --> Helper loaded: file_helper
INFO - 2024-02-12 07:58:05 --> Helper loaded: html_helper
INFO - 2024-02-12 07:58:05 --> Helper loaded: text_helper
INFO - 2024-02-12 07:58:05 --> Helper loaded: form_helper
INFO - 2024-02-12 07:58:05 --> Helper loaded: lang_helper
INFO - 2024-02-12 07:58:05 --> Helper loaded: security_helper
INFO - 2024-02-12 07:58:05 --> Helper loaded: cookie_helper
INFO - 2024-02-12 07:58:05 --> Database Driver Class Initialized
INFO - 2024-02-12 07:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 07:58:05 --> Parser Class Initialized
INFO - 2024-02-12 07:58:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 07:58:05 --> Pagination Class Initialized
INFO - 2024-02-12 07:58:05 --> Form Validation Class Initialized
INFO - 2024-02-12 07:58:05 --> Controller Class Initialized
DEBUG - 2024-02-12 07:58:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 07:58:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:58:05 --> Model Class Initialized
DEBUG - 2024-02-12 07:58:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:58:05 --> Model Class Initialized
INFO - 2024-02-12 07:58:05 --> Final output sent to browser
DEBUG - 2024-02-12 07:58:05 --> Total execution time: 0.0167
ERROR - 2024-02-12 07:58:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 07:58:07 --> Config Class Initialized
INFO - 2024-02-12 07:58:07 --> Hooks Class Initialized
DEBUG - 2024-02-12 07:58:07 --> UTF-8 Support Enabled
INFO - 2024-02-12 07:58:07 --> Utf8 Class Initialized
INFO - 2024-02-12 07:58:07 --> URI Class Initialized
INFO - 2024-02-12 07:58:07 --> Router Class Initialized
INFO - 2024-02-12 07:58:07 --> Output Class Initialized
INFO - 2024-02-12 07:58:07 --> Security Class Initialized
DEBUG - 2024-02-12 07:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 07:58:07 --> Input Class Initialized
INFO - 2024-02-12 07:58:07 --> Language Class Initialized
INFO - 2024-02-12 07:58:07 --> Loader Class Initialized
INFO - 2024-02-12 07:58:07 --> Helper loaded: url_helper
INFO - 2024-02-12 07:58:07 --> Helper loaded: file_helper
INFO - 2024-02-12 07:58:07 --> Helper loaded: html_helper
INFO - 2024-02-12 07:58:07 --> Helper loaded: text_helper
INFO - 2024-02-12 07:58:07 --> Helper loaded: form_helper
INFO - 2024-02-12 07:58:07 --> Helper loaded: lang_helper
INFO - 2024-02-12 07:58:07 --> Helper loaded: security_helper
INFO - 2024-02-12 07:58:07 --> Helper loaded: cookie_helper
INFO - 2024-02-12 07:58:07 --> Database Driver Class Initialized
INFO - 2024-02-12 07:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 07:58:07 --> Parser Class Initialized
INFO - 2024-02-12 07:58:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 07:58:07 --> Pagination Class Initialized
INFO - 2024-02-12 07:58:07 --> Form Validation Class Initialized
INFO - 2024-02-12 07:58:07 --> Controller Class Initialized
DEBUG - 2024-02-12 07:58:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 07:58:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:58:07 --> Model Class Initialized
DEBUG - 2024-02-12 07:58:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:58:07 --> Model Class Initialized
INFO - 2024-02-12 07:58:07 --> Final output sent to browser
DEBUG - 2024-02-12 07:58:07 --> Total execution time: 0.1604
ERROR - 2024-02-12 07:58:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 07:58:08 --> Config Class Initialized
INFO - 2024-02-12 07:58:08 --> Hooks Class Initialized
DEBUG - 2024-02-12 07:58:08 --> UTF-8 Support Enabled
INFO - 2024-02-12 07:58:08 --> Utf8 Class Initialized
INFO - 2024-02-12 07:58:08 --> URI Class Initialized
INFO - 2024-02-12 07:58:08 --> Router Class Initialized
INFO - 2024-02-12 07:58:08 --> Output Class Initialized
INFO - 2024-02-12 07:58:08 --> Security Class Initialized
DEBUG - 2024-02-12 07:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 07:58:08 --> Input Class Initialized
INFO - 2024-02-12 07:58:08 --> Language Class Initialized
INFO - 2024-02-12 07:58:08 --> Loader Class Initialized
INFO - 2024-02-12 07:58:08 --> Helper loaded: url_helper
INFO - 2024-02-12 07:58:08 --> Helper loaded: file_helper
INFO - 2024-02-12 07:58:08 --> Helper loaded: html_helper
INFO - 2024-02-12 07:58:08 --> Helper loaded: text_helper
INFO - 2024-02-12 07:58:08 --> Helper loaded: form_helper
INFO - 2024-02-12 07:58:08 --> Helper loaded: lang_helper
INFO - 2024-02-12 07:58:08 --> Helper loaded: security_helper
INFO - 2024-02-12 07:58:08 --> Helper loaded: cookie_helper
INFO - 2024-02-12 07:58:08 --> Database Driver Class Initialized
INFO - 2024-02-12 07:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 07:58:08 --> Parser Class Initialized
INFO - 2024-02-12 07:58:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 07:58:08 --> Pagination Class Initialized
INFO - 2024-02-12 07:58:08 --> Form Validation Class Initialized
INFO - 2024-02-12 07:58:08 --> Controller Class Initialized
DEBUG - 2024-02-12 07:58:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 07:58:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:58:08 --> Model Class Initialized
DEBUG - 2024-02-12 07:58:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:58:08 --> Model Class Initialized
INFO - 2024-02-12 07:58:08 --> Final output sent to browser
DEBUG - 2024-02-12 07:58:08 --> Total execution time: 0.2121
ERROR - 2024-02-12 07:58:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 07:58:09 --> Config Class Initialized
INFO - 2024-02-12 07:58:09 --> Hooks Class Initialized
DEBUG - 2024-02-12 07:58:09 --> UTF-8 Support Enabled
INFO - 2024-02-12 07:58:09 --> Utf8 Class Initialized
INFO - 2024-02-12 07:58:09 --> URI Class Initialized
INFO - 2024-02-12 07:58:09 --> Router Class Initialized
INFO - 2024-02-12 07:58:09 --> Output Class Initialized
INFO - 2024-02-12 07:58:09 --> Security Class Initialized
DEBUG - 2024-02-12 07:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 07:58:09 --> Input Class Initialized
INFO - 2024-02-12 07:58:09 --> Language Class Initialized
INFO - 2024-02-12 07:58:09 --> Loader Class Initialized
INFO - 2024-02-12 07:58:09 --> Helper loaded: url_helper
INFO - 2024-02-12 07:58:09 --> Helper loaded: file_helper
INFO - 2024-02-12 07:58:09 --> Helper loaded: html_helper
INFO - 2024-02-12 07:58:09 --> Helper loaded: text_helper
INFO - 2024-02-12 07:58:09 --> Helper loaded: form_helper
INFO - 2024-02-12 07:58:09 --> Helper loaded: lang_helper
INFO - 2024-02-12 07:58:09 --> Helper loaded: security_helper
INFO - 2024-02-12 07:58:09 --> Helper loaded: cookie_helper
INFO - 2024-02-12 07:58:09 --> Database Driver Class Initialized
INFO - 2024-02-12 07:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 07:58:09 --> Parser Class Initialized
INFO - 2024-02-12 07:58:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 07:58:09 --> Pagination Class Initialized
INFO - 2024-02-12 07:58:09 --> Form Validation Class Initialized
INFO - 2024-02-12 07:58:09 --> Controller Class Initialized
DEBUG - 2024-02-12 07:58:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 07:58:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:58:09 --> Model Class Initialized
DEBUG - 2024-02-12 07:58:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:58:09 --> Model Class Initialized
INFO - 2024-02-12 07:58:09 --> Final output sent to browser
DEBUG - 2024-02-12 07:58:09 --> Total execution time: 0.0312
ERROR - 2024-02-12 07:59:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 07:59:27 --> Config Class Initialized
INFO - 2024-02-12 07:59:27 --> Hooks Class Initialized
DEBUG - 2024-02-12 07:59:27 --> UTF-8 Support Enabled
INFO - 2024-02-12 07:59:27 --> Utf8 Class Initialized
INFO - 2024-02-12 07:59:27 --> URI Class Initialized
INFO - 2024-02-12 07:59:27 --> Router Class Initialized
INFO - 2024-02-12 07:59:27 --> Output Class Initialized
INFO - 2024-02-12 07:59:27 --> Security Class Initialized
DEBUG - 2024-02-12 07:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 07:59:27 --> Input Class Initialized
INFO - 2024-02-12 07:59:27 --> Language Class Initialized
INFO - 2024-02-12 07:59:27 --> Loader Class Initialized
INFO - 2024-02-12 07:59:27 --> Helper loaded: url_helper
INFO - 2024-02-12 07:59:27 --> Helper loaded: file_helper
INFO - 2024-02-12 07:59:27 --> Helper loaded: html_helper
INFO - 2024-02-12 07:59:27 --> Helper loaded: text_helper
INFO - 2024-02-12 07:59:27 --> Helper loaded: form_helper
INFO - 2024-02-12 07:59:27 --> Helper loaded: lang_helper
INFO - 2024-02-12 07:59:27 --> Helper loaded: security_helper
INFO - 2024-02-12 07:59:27 --> Helper loaded: cookie_helper
INFO - 2024-02-12 07:59:27 --> Database Driver Class Initialized
INFO - 2024-02-12 07:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 07:59:27 --> Parser Class Initialized
INFO - 2024-02-12 07:59:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 07:59:27 --> Pagination Class Initialized
INFO - 2024-02-12 07:59:27 --> Form Validation Class Initialized
INFO - 2024-02-12 07:59:27 --> Controller Class Initialized
DEBUG - 2024-02-12 07:59:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 07:59:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:59:27 --> Model Class Initialized
DEBUG - 2024-02-12 07:59:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:59:27 --> Model Class Initialized
DEBUG - 2024-02-12 07:59:27 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:59:27 --> Model Class Initialized
INFO - 2024-02-12 07:59:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-12 07:59:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:59:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 07:59:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 07:59:27 --> Model Class Initialized
INFO - 2024-02-12 07:59:27 --> Model Class Initialized
INFO - 2024-02-12 07:59:27 --> Model Class Initialized
INFO - 2024-02-12 07:59:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 07:59:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 07:59:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 07:59:27 --> Final output sent to browser
DEBUG - 2024-02-12 07:59:27 --> Total execution time: 0.1428
ERROR - 2024-02-12 07:59:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 07:59:28 --> Config Class Initialized
INFO - 2024-02-12 07:59:28 --> Hooks Class Initialized
DEBUG - 2024-02-12 07:59:28 --> UTF-8 Support Enabled
INFO - 2024-02-12 07:59:28 --> Utf8 Class Initialized
INFO - 2024-02-12 07:59:28 --> URI Class Initialized
INFO - 2024-02-12 07:59:28 --> Router Class Initialized
INFO - 2024-02-12 07:59:28 --> Output Class Initialized
INFO - 2024-02-12 07:59:28 --> Security Class Initialized
DEBUG - 2024-02-12 07:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 07:59:28 --> Input Class Initialized
INFO - 2024-02-12 07:59:28 --> Language Class Initialized
INFO - 2024-02-12 07:59:28 --> Loader Class Initialized
INFO - 2024-02-12 07:59:28 --> Helper loaded: url_helper
INFO - 2024-02-12 07:59:28 --> Helper loaded: file_helper
INFO - 2024-02-12 07:59:28 --> Helper loaded: html_helper
INFO - 2024-02-12 07:59:28 --> Helper loaded: text_helper
INFO - 2024-02-12 07:59:28 --> Helper loaded: form_helper
INFO - 2024-02-12 07:59:28 --> Helper loaded: lang_helper
INFO - 2024-02-12 07:59:28 --> Helper loaded: security_helper
INFO - 2024-02-12 07:59:28 --> Helper loaded: cookie_helper
INFO - 2024-02-12 07:59:28 --> Database Driver Class Initialized
INFO - 2024-02-12 07:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 07:59:28 --> Parser Class Initialized
INFO - 2024-02-12 07:59:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 07:59:28 --> Pagination Class Initialized
INFO - 2024-02-12 07:59:28 --> Form Validation Class Initialized
INFO - 2024-02-12 07:59:28 --> Controller Class Initialized
DEBUG - 2024-02-12 07:59:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 07:59:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:59:28 --> Model Class Initialized
DEBUG - 2024-02-12 07:59:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:59:28 --> Model Class Initialized
INFO - 2024-02-12 07:59:28 --> Final output sent to browser
DEBUG - 2024-02-12 07:59:28 --> Total execution time: 0.0211
ERROR - 2024-02-12 07:59:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 07:59:35 --> Config Class Initialized
INFO - 2024-02-12 07:59:35 --> Hooks Class Initialized
DEBUG - 2024-02-12 07:59:35 --> UTF-8 Support Enabled
INFO - 2024-02-12 07:59:35 --> Utf8 Class Initialized
INFO - 2024-02-12 07:59:35 --> URI Class Initialized
INFO - 2024-02-12 07:59:35 --> Router Class Initialized
INFO - 2024-02-12 07:59:35 --> Output Class Initialized
INFO - 2024-02-12 07:59:35 --> Security Class Initialized
DEBUG - 2024-02-12 07:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 07:59:35 --> Input Class Initialized
INFO - 2024-02-12 07:59:35 --> Language Class Initialized
INFO - 2024-02-12 07:59:35 --> Loader Class Initialized
INFO - 2024-02-12 07:59:35 --> Helper loaded: url_helper
INFO - 2024-02-12 07:59:35 --> Helper loaded: file_helper
INFO - 2024-02-12 07:59:35 --> Helper loaded: html_helper
INFO - 2024-02-12 07:59:35 --> Helper loaded: text_helper
INFO - 2024-02-12 07:59:35 --> Helper loaded: form_helper
INFO - 2024-02-12 07:59:35 --> Helper loaded: lang_helper
INFO - 2024-02-12 07:59:35 --> Helper loaded: security_helper
INFO - 2024-02-12 07:59:35 --> Helper loaded: cookie_helper
INFO - 2024-02-12 07:59:35 --> Database Driver Class Initialized
INFO - 2024-02-12 07:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 07:59:35 --> Parser Class Initialized
INFO - 2024-02-12 07:59:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 07:59:35 --> Pagination Class Initialized
INFO - 2024-02-12 07:59:35 --> Form Validation Class Initialized
INFO - 2024-02-12 07:59:35 --> Controller Class Initialized
DEBUG - 2024-02-12 07:59:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 07:59:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:59:35 --> Model Class Initialized
DEBUG - 2024-02-12 07:59:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 07:59:35 --> Model Class Initialized
INFO - 2024-02-12 07:59:35 --> Final output sent to browser
DEBUG - 2024-02-12 07:59:35 --> Total execution time: 0.0304
ERROR - 2024-02-12 08:00:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:00:38 --> Config Class Initialized
INFO - 2024-02-12 08:00:38 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:00:38 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:00:38 --> Utf8 Class Initialized
INFO - 2024-02-12 08:00:38 --> URI Class Initialized
DEBUG - 2024-02-12 08:00:38 --> No URI present. Default controller set.
INFO - 2024-02-12 08:00:38 --> Router Class Initialized
INFO - 2024-02-12 08:00:38 --> Output Class Initialized
INFO - 2024-02-12 08:00:38 --> Security Class Initialized
DEBUG - 2024-02-12 08:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:00:38 --> Input Class Initialized
INFO - 2024-02-12 08:00:38 --> Language Class Initialized
INFO - 2024-02-12 08:00:38 --> Loader Class Initialized
INFO - 2024-02-12 08:00:38 --> Helper loaded: url_helper
INFO - 2024-02-12 08:00:38 --> Helper loaded: file_helper
INFO - 2024-02-12 08:00:38 --> Helper loaded: html_helper
INFO - 2024-02-12 08:00:38 --> Helper loaded: text_helper
INFO - 2024-02-12 08:00:38 --> Helper loaded: form_helper
INFO - 2024-02-12 08:00:38 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:00:38 --> Helper loaded: security_helper
INFO - 2024-02-12 08:00:38 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:00:38 --> Database Driver Class Initialized
INFO - 2024-02-12 08:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:00:38 --> Parser Class Initialized
INFO - 2024-02-12 08:00:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:00:38 --> Pagination Class Initialized
INFO - 2024-02-12 08:00:38 --> Form Validation Class Initialized
INFO - 2024-02-12 08:00:38 --> Controller Class Initialized
INFO - 2024-02-12 08:00:38 --> Model Class Initialized
DEBUG - 2024-02-12 08:00:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-12 08:00:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:00:39 --> Config Class Initialized
INFO - 2024-02-12 08:00:39 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:00:39 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:00:39 --> Utf8 Class Initialized
INFO - 2024-02-12 08:00:39 --> URI Class Initialized
INFO - 2024-02-12 08:00:39 --> Router Class Initialized
INFO - 2024-02-12 08:00:39 --> Output Class Initialized
INFO - 2024-02-12 08:00:39 --> Security Class Initialized
DEBUG - 2024-02-12 08:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:00:39 --> Input Class Initialized
INFO - 2024-02-12 08:00:39 --> Language Class Initialized
INFO - 2024-02-12 08:00:39 --> Loader Class Initialized
INFO - 2024-02-12 08:00:39 --> Helper loaded: url_helper
INFO - 2024-02-12 08:00:39 --> Helper loaded: file_helper
INFO - 2024-02-12 08:00:39 --> Helper loaded: html_helper
INFO - 2024-02-12 08:00:39 --> Helper loaded: text_helper
INFO - 2024-02-12 08:00:39 --> Helper loaded: form_helper
INFO - 2024-02-12 08:00:39 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:00:39 --> Helper loaded: security_helper
INFO - 2024-02-12 08:00:39 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:00:39 --> Database Driver Class Initialized
INFO - 2024-02-12 08:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:00:39 --> Parser Class Initialized
INFO - 2024-02-12 08:00:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:00:39 --> Pagination Class Initialized
INFO - 2024-02-12 08:00:39 --> Form Validation Class Initialized
INFO - 2024-02-12 08:00:39 --> Controller Class Initialized
INFO - 2024-02-12 08:00:39 --> Model Class Initialized
DEBUG - 2024-02-12 08:00:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:00:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-12 08:00:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:00:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 08:00:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 08:00:39 --> Model Class Initialized
INFO - 2024-02-12 08:00:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 08:00:39 --> Final output sent to browser
DEBUG - 2024-02-12 08:00:39 --> Total execution time: 0.0290
ERROR - 2024-02-12 08:00:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:00:55 --> Config Class Initialized
INFO - 2024-02-12 08:00:55 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:00:55 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:00:55 --> Utf8 Class Initialized
INFO - 2024-02-12 08:00:55 --> URI Class Initialized
INFO - 2024-02-12 08:00:55 --> Router Class Initialized
INFO - 2024-02-12 08:00:55 --> Output Class Initialized
INFO - 2024-02-12 08:00:55 --> Security Class Initialized
DEBUG - 2024-02-12 08:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:00:55 --> Input Class Initialized
INFO - 2024-02-12 08:00:55 --> Language Class Initialized
INFO - 2024-02-12 08:00:55 --> Loader Class Initialized
INFO - 2024-02-12 08:00:55 --> Helper loaded: url_helper
INFO - 2024-02-12 08:00:55 --> Helper loaded: file_helper
INFO - 2024-02-12 08:00:55 --> Helper loaded: html_helper
INFO - 2024-02-12 08:00:55 --> Helper loaded: text_helper
INFO - 2024-02-12 08:00:55 --> Helper loaded: form_helper
INFO - 2024-02-12 08:00:55 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:00:55 --> Helper loaded: security_helper
INFO - 2024-02-12 08:00:55 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:00:55 --> Database Driver Class Initialized
INFO - 2024-02-12 08:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:00:55 --> Parser Class Initialized
INFO - 2024-02-12 08:00:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:00:55 --> Pagination Class Initialized
INFO - 2024-02-12 08:00:55 --> Form Validation Class Initialized
INFO - 2024-02-12 08:00:55 --> Controller Class Initialized
INFO - 2024-02-12 08:00:55 --> Model Class Initialized
DEBUG - 2024-02-12 08:00:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:00:55 --> Model Class Initialized
INFO - 2024-02-12 08:00:55 --> Final output sent to browser
DEBUG - 2024-02-12 08:00:55 --> Total execution time: 0.0186
ERROR - 2024-02-12 08:00:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:00:55 --> Config Class Initialized
INFO - 2024-02-12 08:00:55 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:00:55 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:00:55 --> Utf8 Class Initialized
INFO - 2024-02-12 08:00:55 --> URI Class Initialized
DEBUG - 2024-02-12 08:00:55 --> No URI present. Default controller set.
INFO - 2024-02-12 08:00:55 --> Router Class Initialized
INFO - 2024-02-12 08:00:55 --> Output Class Initialized
INFO - 2024-02-12 08:00:55 --> Security Class Initialized
DEBUG - 2024-02-12 08:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:00:55 --> Input Class Initialized
INFO - 2024-02-12 08:00:55 --> Language Class Initialized
INFO - 2024-02-12 08:00:55 --> Loader Class Initialized
INFO - 2024-02-12 08:00:55 --> Helper loaded: url_helper
INFO - 2024-02-12 08:00:55 --> Helper loaded: file_helper
INFO - 2024-02-12 08:00:55 --> Helper loaded: html_helper
INFO - 2024-02-12 08:00:55 --> Helper loaded: text_helper
INFO - 2024-02-12 08:00:55 --> Helper loaded: form_helper
INFO - 2024-02-12 08:00:55 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:00:55 --> Helper loaded: security_helper
INFO - 2024-02-12 08:00:55 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:00:55 --> Database Driver Class Initialized
INFO - 2024-02-12 08:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:00:55 --> Parser Class Initialized
INFO - 2024-02-12 08:00:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:00:55 --> Pagination Class Initialized
INFO - 2024-02-12 08:00:55 --> Form Validation Class Initialized
INFO - 2024-02-12 08:00:55 --> Controller Class Initialized
INFO - 2024-02-12 08:00:55 --> Model Class Initialized
DEBUG - 2024-02-12 08:00:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:00:55 --> Model Class Initialized
DEBUG - 2024-02-12 08:00:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:00:55 --> Model Class Initialized
INFO - 2024-02-12 08:00:55 --> Model Class Initialized
INFO - 2024-02-12 08:00:55 --> Model Class Initialized
INFO - 2024-02-12 08:00:55 --> Model Class Initialized
DEBUG - 2024-02-12 08:00:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:00:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:00:55 --> Model Class Initialized
INFO - 2024-02-12 08:00:55 --> Model Class Initialized
INFO - 2024-02-12 08:00:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-12 08:00:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:00:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 08:00:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 08:00:56 --> Model Class Initialized
INFO - 2024-02-12 08:00:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 08:00:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 08:00:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 08:00:56 --> Final output sent to browser
DEBUG - 2024-02-12 08:00:56 --> Total execution time: 0.3880
ERROR - 2024-02-12 08:00:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:00:57 --> Config Class Initialized
INFO - 2024-02-12 08:00:57 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:00:57 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:00:57 --> Utf8 Class Initialized
INFO - 2024-02-12 08:00:57 --> URI Class Initialized
INFO - 2024-02-12 08:00:57 --> Router Class Initialized
INFO - 2024-02-12 08:00:57 --> Output Class Initialized
INFO - 2024-02-12 08:00:57 --> Security Class Initialized
DEBUG - 2024-02-12 08:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:00:57 --> Input Class Initialized
INFO - 2024-02-12 08:00:57 --> Language Class Initialized
INFO - 2024-02-12 08:00:57 --> Loader Class Initialized
INFO - 2024-02-12 08:00:57 --> Helper loaded: url_helper
INFO - 2024-02-12 08:00:57 --> Helper loaded: file_helper
INFO - 2024-02-12 08:00:57 --> Helper loaded: html_helper
INFO - 2024-02-12 08:00:57 --> Helper loaded: text_helper
INFO - 2024-02-12 08:00:57 --> Helper loaded: form_helper
INFO - 2024-02-12 08:00:57 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:00:57 --> Helper loaded: security_helper
INFO - 2024-02-12 08:00:57 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:00:57 --> Database Driver Class Initialized
INFO - 2024-02-12 08:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:00:57 --> Parser Class Initialized
INFO - 2024-02-12 08:00:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:00:57 --> Pagination Class Initialized
INFO - 2024-02-12 08:00:57 --> Form Validation Class Initialized
INFO - 2024-02-12 08:00:57 --> Controller Class Initialized
DEBUG - 2024-02-12 08:00:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:00:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:00:57 --> Model Class Initialized
INFO - 2024-02-12 08:00:57 --> Final output sent to browser
DEBUG - 2024-02-12 08:00:57 --> Total execution time: 0.0121
ERROR - 2024-02-12 08:01:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:01:02 --> Config Class Initialized
INFO - 2024-02-12 08:01:02 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:01:02 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:01:02 --> Utf8 Class Initialized
INFO - 2024-02-12 08:01:02 --> URI Class Initialized
INFO - 2024-02-12 08:01:02 --> Router Class Initialized
INFO - 2024-02-12 08:01:02 --> Output Class Initialized
INFO - 2024-02-12 08:01:02 --> Security Class Initialized
DEBUG - 2024-02-12 08:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:01:02 --> Input Class Initialized
INFO - 2024-02-12 08:01:02 --> Language Class Initialized
INFO - 2024-02-12 08:01:02 --> Loader Class Initialized
INFO - 2024-02-12 08:01:02 --> Helper loaded: url_helper
INFO - 2024-02-12 08:01:02 --> Helper loaded: file_helper
INFO - 2024-02-12 08:01:02 --> Helper loaded: html_helper
INFO - 2024-02-12 08:01:02 --> Helper loaded: text_helper
INFO - 2024-02-12 08:01:02 --> Helper loaded: form_helper
INFO - 2024-02-12 08:01:02 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:01:02 --> Helper loaded: security_helper
INFO - 2024-02-12 08:01:02 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:01:02 --> Database Driver Class Initialized
INFO - 2024-02-12 08:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:01:02 --> Parser Class Initialized
INFO - 2024-02-12 08:01:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:01:02 --> Pagination Class Initialized
INFO - 2024-02-12 08:01:03 --> Form Validation Class Initialized
INFO - 2024-02-12 08:01:03 --> Controller Class Initialized
DEBUG - 2024-02-12 08:01:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:01:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:01:03 --> Model Class Initialized
DEBUG - 2024-02-12 08:01:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:01:03 --> Model Class Initialized
DEBUG - 2024-02-12 08:01:03 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:01:03 --> Model Class Initialized
INFO - 2024-02-12 08:01:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-12 08:01:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:01:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 08:01:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 08:01:03 --> Model Class Initialized
INFO - 2024-02-12 08:01:03 --> Model Class Initialized
INFO - 2024-02-12 08:01:03 --> Model Class Initialized
INFO - 2024-02-12 08:01:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 08:01:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 08:01:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 08:01:03 --> Final output sent to browser
DEBUG - 2024-02-12 08:01:03 --> Total execution time: 0.2229
ERROR - 2024-02-12 08:01:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:01:04 --> Config Class Initialized
INFO - 2024-02-12 08:01:04 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:01:04 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:01:04 --> Utf8 Class Initialized
INFO - 2024-02-12 08:01:04 --> URI Class Initialized
INFO - 2024-02-12 08:01:04 --> Router Class Initialized
INFO - 2024-02-12 08:01:04 --> Output Class Initialized
INFO - 2024-02-12 08:01:04 --> Security Class Initialized
DEBUG - 2024-02-12 08:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:01:04 --> Input Class Initialized
INFO - 2024-02-12 08:01:04 --> Language Class Initialized
INFO - 2024-02-12 08:01:04 --> Loader Class Initialized
INFO - 2024-02-12 08:01:04 --> Helper loaded: url_helper
INFO - 2024-02-12 08:01:04 --> Helper loaded: file_helper
INFO - 2024-02-12 08:01:04 --> Helper loaded: html_helper
INFO - 2024-02-12 08:01:04 --> Helper loaded: text_helper
INFO - 2024-02-12 08:01:04 --> Helper loaded: form_helper
INFO - 2024-02-12 08:01:04 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:01:04 --> Helper loaded: security_helper
INFO - 2024-02-12 08:01:04 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:01:04 --> Database Driver Class Initialized
INFO - 2024-02-12 08:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:01:04 --> Parser Class Initialized
INFO - 2024-02-12 08:01:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:01:04 --> Pagination Class Initialized
INFO - 2024-02-12 08:01:04 --> Form Validation Class Initialized
INFO - 2024-02-12 08:01:04 --> Controller Class Initialized
DEBUG - 2024-02-12 08:01:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:01:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:01:04 --> Model Class Initialized
DEBUG - 2024-02-12 08:01:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:01:04 --> Model Class Initialized
INFO - 2024-02-12 08:01:04 --> Final output sent to browser
DEBUG - 2024-02-12 08:01:04 --> Total execution time: 0.0322
ERROR - 2024-02-12 08:01:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:01:13 --> Config Class Initialized
INFO - 2024-02-12 08:01:13 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:01:13 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:01:13 --> Utf8 Class Initialized
INFO - 2024-02-12 08:01:13 --> URI Class Initialized
INFO - 2024-02-12 08:01:13 --> Router Class Initialized
INFO - 2024-02-12 08:01:13 --> Output Class Initialized
INFO - 2024-02-12 08:01:13 --> Security Class Initialized
DEBUG - 2024-02-12 08:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:01:13 --> Input Class Initialized
INFO - 2024-02-12 08:01:13 --> Language Class Initialized
INFO - 2024-02-12 08:01:13 --> Loader Class Initialized
INFO - 2024-02-12 08:01:13 --> Helper loaded: url_helper
INFO - 2024-02-12 08:01:13 --> Helper loaded: file_helper
INFO - 2024-02-12 08:01:13 --> Helper loaded: html_helper
INFO - 2024-02-12 08:01:13 --> Helper loaded: text_helper
INFO - 2024-02-12 08:01:13 --> Helper loaded: form_helper
INFO - 2024-02-12 08:01:13 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:01:13 --> Helper loaded: security_helper
INFO - 2024-02-12 08:01:13 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:01:13 --> Database Driver Class Initialized
INFO - 2024-02-12 08:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:01:13 --> Parser Class Initialized
INFO - 2024-02-12 08:01:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:01:13 --> Pagination Class Initialized
INFO - 2024-02-12 08:01:13 --> Form Validation Class Initialized
INFO - 2024-02-12 08:01:13 --> Controller Class Initialized
DEBUG - 2024-02-12 08:01:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:01:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:01:13 --> Model Class Initialized
DEBUG - 2024-02-12 08:01:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:01:13 --> Model Class Initialized
INFO - 2024-02-12 08:01:13 --> Final output sent to browser
DEBUG - 2024-02-12 08:01:13 --> Total execution time: 0.0301
ERROR - 2024-02-12 08:01:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:01:19 --> Config Class Initialized
INFO - 2024-02-12 08:01:19 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:01:19 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:01:19 --> Utf8 Class Initialized
INFO - 2024-02-12 08:01:19 --> URI Class Initialized
INFO - 2024-02-12 08:01:19 --> Router Class Initialized
INFO - 2024-02-12 08:01:19 --> Output Class Initialized
INFO - 2024-02-12 08:01:19 --> Security Class Initialized
DEBUG - 2024-02-12 08:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:01:19 --> Input Class Initialized
INFO - 2024-02-12 08:01:19 --> Language Class Initialized
INFO - 2024-02-12 08:01:19 --> Loader Class Initialized
INFO - 2024-02-12 08:01:19 --> Helper loaded: url_helper
INFO - 2024-02-12 08:01:19 --> Helper loaded: file_helper
INFO - 2024-02-12 08:01:19 --> Helper loaded: html_helper
INFO - 2024-02-12 08:01:19 --> Helper loaded: text_helper
INFO - 2024-02-12 08:01:19 --> Helper loaded: form_helper
INFO - 2024-02-12 08:01:19 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:01:19 --> Helper loaded: security_helper
INFO - 2024-02-12 08:01:19 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:01:19 --> Database Driver Class Initialized
INFO - 2024-02-12 08:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:01:19 --> Parser Class Initialized
INFO - 2024-02-12 08:01:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:01:19 --> Pagination Class Initialized
INFO - 2024-02-12 08:01:19 --> Form Validation Class Initialized
INFO - 2024-02-12 08:01:19 --> Controller Class Initialized
DEBUG - 2024-02-12 08:01:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:01:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:01:19 --> Model Class Initialized
DEBUG - 2024-02-12 08:01:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:01:19 --> Model Class Initialized
INFO - 2024-02-12 08:01:19 --> Final output sent to browser
DEBUG - 2024-02-12 08:01:19 --> Total execution time: 0.0318
ERROR - 2024-02-12 08:01:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:01:21 --> Config Class Initialized
INFO - 2024-02-12 08:01:21 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:01:21 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:01:21 --> Utf8 Class Initialized
INFO - 2024-02-12 08:01:21 --> URI Class Initialized
INFO - 2024-02-12 08:01:21 --> Router Class Initialized
INFO - 2024-02-12 08:01:21 --> Output Class Initialized
INFO - 2024-02-12 08:01:21 --> Security Class Initialized
DEBUG - 2024-02-12 08:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:01:21 --> Input Class Initialized
INFO - 2024-02-12 08:01:21 --> Language Class Initialized
INFO - 2024-02-12 08:01:21 --> Loader Class Initialized
INFO - 2024-02-12 08:01:21 --> Helper loaded: url_helper
INFO - 2024-02-12 08:01:21 --> Helper loaded: file_helper
INFO - 2024-02-12 08:01:21 --> Helper loaded: html_helper
INFO - 2024-02-12 08:01:21 --> Helper loaded: text_helper
INFO - 2024-02-12 08:01:21 --> Helper loaded: form_helper
INFO - 2024-02-12 08:01:21 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:01:21 --> Helper loaded: security_helper
INFO - 2024-02-12 08:01:21 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:01:21 --> Database Driver Class Initialized
INFO - 2024-02-12 08:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:01:21 --> Parser Class Initialized
INFO - 2024-02-12 08:01:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:01:21 --> Pagination Class Initialized
INFO - 2024-02-12 08:01:21 --> Form Validation Class Initialized
INFO - 2024-02-12 08:01:21 --> Controller Class Initialized
DEBUG - 2024-02-12 08:01:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:01:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:01:21 --> Model Class Initialized
DEBUG - 2024-02-12 08:01:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:01:21 --> Model Class Initialized
INFO - 2024-02-12 08:01:21 --> Final output sent to browser
DEBUG - 2024-02-12 08:01:21 --> Total execution time: 0.0380
ERROR - 2024-02-12 08:01:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:01:37 --> Config Class Initialized
INFO - 2024-02-12 08:01:37 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:01:37 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:01:37 --> Utf8 Class Initialized
INFO - 2024-02-12 08:01:37 --> URI Class Initialized
INFO - 2024-02-12 08:01:37 --> Router Class Initialized
INFO - 2024-02-12 08:01:37 --> Output Class Initialized
INFO - 2024-02-12 08:01:37 --> Security Class Initialized
DEBUG - 2024-02-12 08:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:01:37 --> Input Class Initialized
INFO - 2024-02-12 08:01:37 --> Language Class Initialized
INFO - 2024-02-12 08:01:37 --> Loader Class Initialized
INFO - 2024-02-12 08:01:37 --> Helper loaded: url_helper
INFO - 2024-02-12 08:01:37 --> Helper loaded: file_helper
INFO - 2024-02-12 08:01:37 --> Helper loaded: html_helper
INFO - 2024-02-12 08:01:37 --> Helper loaded: text_helper
INFO - 2024-02-12 08:01:37 --> Helper loaded: form_helper
INFO - 2024-02-12 08:01:37 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:01:37 --> Helper loaded: security_helper
INFO - 2024-02-12 08:01:37 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:01:37 --> Database Driver Class Initialized
INFO - 2024-02-12 08:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:01:37 --> Parser Class Initialized
INFO - 2024-02-12 08:01:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:01:37 --> Pagination Class Initialized
INFO - 2024-02-12 08:01:37 --> Form Validation Class Initialized
INFO - 2024-02-12 08:01:37 --> Controller Class Initialized
DEBUG - 2024-02-12 08:01:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:01:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:01:37 --> Model Class Initialized
DEBUG - 2024-02-12 08:01:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:01:37 --> Model Class Initialized
INFO - 2024-02-12 08:01:37 --> Final output sent to browser
DEBUG - 2024-02-12 08:01:37 --> Total execution time: 0.0326
ERROR - 2024-02-12 08:01:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:01:46 --> Config Class Initialized
INFO - 2024-02-12 08:01:46 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:01:46 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:01:46 --> Utf8 Class Initialized
INFO - 2024-02-12 08:01:46 --> URI Class Initialized
INFO - 2024-02-12 08:01:46 --> Router Class Initialized
INFO - 2024-02-12 08:01:46 --> Output Class Initialized
INFO - 2024-02-12 08:01:46 --> Security Class Initialized
DEBUG - 2024-02-12 08:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:01:46 --> Input Class Initialized
INFO - 2024-02-12 08:01:46 --> Language Class Initialized
INFO - 2024-02-12 08:01:46 --> Loader Class Initialized
INFO - 2024-02-12 08:01:46 --> Helper loaded: url_helper
INFO - 2024-02-12 08:01:46 --> Helper loaded: file_helper
INFO - 2024-02-12 08:01:46 --> Helper loaded: html_helper
INFO - 2024-02-12 08:01:46 --> Helper loaded: text_helper
INFO - 2024-02-12 08:01:46 --> Helper loaded: form_helper
INFO - 2024-02-12 08:01:46 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:01:46 --> Helper loaded: security_helper
INFO - 2024-02-12 08:01:46 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:01:46 --> Database Driver Class Initialized
INFO - 2024-02-12 08:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:01:46 --> Parser Class Initialized
INFO - 2024-02-12 08:01:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:01:46 --> Pagination Class Initialized
INFO - 2024-02-12 08:01:46 --> Form Validation Class Initialized
INFO - 2024-02-12 08:01:46 --> Controller Class Initialized
DEBUG - 2024-02-12 08:01:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:01:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:01:46 --> Model Class Initialized
DEBUG - 2024-02-12 08:01:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:01:46 --> Model Class Initialized
INFO - 2024-02-12 08:01:46 --> Final output sent to browser
DEBUG - 2024-02-12 08:01:46 --> Total execution time: 0.0210
ERROR - 2024-02-12 08:01:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:01:46 --> Config Class Initialized
INFO - 2024-02-12 08:01:46 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:01:46 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:01:46 --> Utf8 Class Initialized
INFO - 2024-02-12 08:01:46 --> URI Class Initialized
INFO - 2024-02-12 08:01:46 --> Router Class Initialized
INFO - 2024-02-12 08:01:46 --> Output Class Initialized
INFO - 2024-02-12 08:01:46 --> Security Class Initialized
DEBUG - 2024-02-12 08:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:01:46 --> Input Class Initialized
INFO - 2024-02-12 08:01:46 --> Language Class Initialized
INFO - 2024-02-12 08:01:46 --> Loader Class Initialized
INFO - 2024-02-12 08:01:46 --> Helper loaded: url_helper
INFO - 2024-02-12 08:01:46 --> Helper loaded: file_helper
INFO - 2024-02-12 08:01:46 --> Helper loaded: html_helper
INFO - 2024-02-12 08:01:46 --> Helper loaded: text_helper
INFO - 2024-02-12 08:01:46 --> Helper loaded: form_helper
INFO - 2024-02-12 08:01:46 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:01:46 --> Helper loaded: security_helper
INFO - 2024-02-12 08:01:46 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:01:46 --> Database Driver Class Initialized
INFO - 2024-02-12 08:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:01:46 --> Parser Class Initialized
INFO - 2024-02-12 08:01:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:01:46 --> Pagination Class Initialized
INFO - 2024-02-12 08:01:46 --> Form Validation Class Initialized
INFO - 2024-02-12 08:01:46 --> Controller Class Initialized
DEBUG - 2024-02-12 08:01:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:01:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:01:46 --> Model Class Initialized
DEBUG - 2024-02-12 08:01:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:01:46 --> Model Class Initialized
INFO - 2024-02-12 08:01:46 --> Final output sent to browser
DEBUG - 2024-02-12 08:01:46 --> Total execution time: 0.0274
ERROR - 2024-02-12 08:01:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:01:47 --> Config Class Initialized
INFO - 2024-02-12 08:01:47 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:01:47 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:01:47 --> Utf8 Class Initialized
INFO - 2024-02-12 08:01:47 --> URI Class Initialized
INFO - 2024-02-12 08:01:47 --> Router Class Initialized
INFO - 2024-02-12 08:01:47 --> Output Class Initialized
INFO - 2024-02-12 08:01:47 --> Security Class Initialized
DEBUG - 2024-02-12 08:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:01:47 --> Input Class Initialized
INFO - 2024-02-12 08:01:47 --> Language Class Initialized
INFO - 2024-02-12 08:01:47 --> Loader Class Initialized
INFO - 2024-02-12 08:01:47 --> Helper loaded: url_helper
INFO - 2024-02-12 08:01:47 --> Helper loaded: file_helper
INFO - 2024-02-12 08:01:47 --> Helper loaded: html_helper
INFO - 2024-02-12 08:01:47 --> Helper loaded: text_helper
INFO - 2024-02-12 08:01:47 --> Helper loaded: form_helper
INFO - 2024-02-12 08:01:47 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:01:47 --> Helper loaded: security_helper
INFO - 2024-02-12 08:01:47 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:01:47 --> Database Driver Class Initialized
INFO - 2024-02-12 08:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:01:47 --> Parser Class Initialized
INFO - 2024-02-12 08:01:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:01:47 --> Pagination Class Initialized
INFO - 2024-02-12 08:01:47 --> Form Validation Class Initialized
INFO - 2024-02-12 08:01:47 --> Controller Class Initialized
DEBUG - 2024-02-12 08:01:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:01:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:01:47 --> Model Class Initialized
DEBUG - 2024-02-12 08:01:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:01:47 --> Model Class Initialized
INFO - 2024-02-12 08:01:47 --> Final output sent to browser
DEBUG - 2024-02-12 08:01:47 --> Total execution time: 0.0175
ERROR - 2024-02-12 08:01:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:01:49 --> Config Class Initialized
INFO - 2024-02-12 08:01:49 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:01:49 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:01:49 --> Utf8 Class Initialized
INFO - 2024-02-12 08:01:49 --> URI Class Initialized
INFO - 2024-02-12 08:01:49 --> Router Class Initialized
INFO - 2024-02-12 08:01:49 --> Output Class Initialized
INFO - 2024-02-12 08:01:49 --> Security Class Initialized
DEBUG - 2024-02-12 08:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:01:49 --> Input Class Initialized
INFO - 2024-02-12 08:01:49 --> Language Class Initialized
INFO - 2024-02-12 08:01:49 --> Loader Class Initialized
INFO - 2024-02-12 08:01:49 --> Helper loaded: url_helper
INFO - 2024-02-12 08:01:49 --> Helper loaded: file_helper
INFO - 2024-02-12 08:01:49 --> Helper loaded: html_helper
INFO - 2024-02-12 08:01:49 --> Helper loaded: text_helper
INFO - 2024-02-12 08:01:49 --> Helper loaded: form_helper
INFO - 2024-02-12 08:01:49 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:01:49 --> Helper loaded: security_helper
INFO - 2024-02-12 08:01:49 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:01:49 --> Database Driver Class Initialized
INFO - 2024-02-12 08:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:01:49 --> Parser Class Initialized
INFO - 2024-02-12 08:01:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:01:49 --> Pagination Class Initialized
INFO - 2024-02-12 08:01:49 --> Form Validation Class Initialized
INFO - 2024-02-12 08:01:49 --> Controller Class Initialized
DEBUG - 2024-02-12 08:01:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:01:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:01:49 --> Model Class Initialized
DEBUG - 2024-02-12 08:01:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:01:49 --> Model Class Initialized
INFO - 2024-02-12 08:01:49 --> Final output sent to browser
DEBUG - 2024-02-12 08:01:49 --> Total execution time: 0.0176
ERROR - 2024-02-12 08:01:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:01:49 --> Config Class Initialized
INFO - 2024-02-12 08:01:49 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:01:49 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:01:49 --> Utf8 Class Initialized
INFO - 2024-02-12 08:01:49 --> URI Class Initialized
INFO - 2024-02-12 08:01:49 --> Router Class Initialized
INFO - 2024-02-12 08:01:49 --> Output Class Initialized
INFO - 2024-02-12 08:01:49 --> Security Class Initialized
DEBUG - 2024-02-12 08:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:01:49 --> Input Class Initialized
INFO - 2024-02-12 08:01:49 --> Language Class Initialized
INFO - 2024-02-12 08:01:49 --> Loader Class Initialized
INFO - 2024-02-12 08:01:49 --> Helper loaded: url_helper
INFO - 2024-02-12 08:01:49 --> Helper loaded: file_helper
INFO - 2024-02-12 08:01:49 --> Helper loaded: html_helper
INFO - 2024-02-12 08:01:49 --> Helper loaded: text_helper
INFO - 2024-02-12 08:01:49 --> Helper loaded: form_helper
INFO - 2024-02-12 08:01:49 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:01:49 --> Helper loaded: security_helper
INFO - 2024-02-12 08:01:49 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:01:49 --> Database Driver Class Initialized
INFO - 2024-02-12 08:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:01:49 --> Parser Class Initialized
INFO - 2024-02-12 08:01:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:01:49 --> Pagination Class Initialized
INFO - 2024-02-12 08:01:49 --> Form Validation Class Initialized
INFO - 2024-02-12 08:01:49 --> Controller Class Initialized
DEBUG - 2024-02-12 08:01:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:01:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:01:49 --> Model Class Initialized
DEBUG - 2024-02-12 08:01:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:01:49 --> Model Class Initialized
INFO - 2024-02-12 08:01:50 --> Final output sent to browser
DEBUG - 2024-02-12 08:01:50 --> Total execution time: 0.0271
ERROR - 2024-02-12 08:01:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:01:50 --> Config Class Initialized
INFO - 2024-02-12 08:01:50 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:01:50 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:01:50 --> Utf8 Class Initialized
INFO - 2024-02-12 08:01:50 --> URI Class Initialized
INFO - 2024-02-12 08:01:50 --> Router Class Initialized
INFO - 2024-02-12 08:01:50 --> Output Class Initialized
INFO - 2024-02-12 08:01:50 --> Security Class Initialized
DEBUG - 2024-02-12 08:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:01:50 --> Input Class Initialized
INFO - 2024-02-12 08:01:50 --> Language Class Initialized
INFO - 2024-02-12 08:01:50 --> Loader Class Initialized
INFO - 2024-02-12 08:01:50 --> Helper loaded: url_helper
INFO - 2024-02-12 08:01:50 --> Helper loaded: file_helper
INFO - 2024-02-12 08:01:50 --> Helper loaded: html_helper
INFO - 2024-02-12 08:01:50 --> Helper loaded: text_helper
INFO - 2024-02-12 08:01:50 --> Helper loaded: form_helper
INFO - 2024-02-12 08:01:50 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:01:50 --> Helper loaded: security_helper
INFO - 2024-02-12 08:01:50 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:01:50 --> Database Driver Class Initialized
INFO - 2024-02-12 08:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:01:50 --> Parser Class Initialized
INFO - 2024-02-12 08:01:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:01:50 --> Pagination Class Initialized
INFO - 2024-02-12 08:01:50 --> Form Validation Class Initialized
INFO - 2024-02-12 08:01:50 --> Controller Class Initialized
DEBUG - 2024-02-12 08:01:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:01:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:01:50 --> Model Class Initialized
DEBUG - 2024-02-12 08:01:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:01:50 --> Model Class Initialized
INFO - 2024-02-12 08:01:50 --> Final output sent to browser
DEBUG - 2024-02-12 08:01:50 --> Total execution time: 0.0290
ERROR - 2024-02-12 08:01:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:01:51 --> Config Class Initialized
INFO - 2024-02-12 08:01:51 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:01:51 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:01:51 --> Utf8 Class Initialized
INFO - 2024-02-12 08:01:51 --> URI Class Initialized
INFO - 2024-02-12 08:01:51 --> Router Class Initialized
INFO - 2024-02-12 08:01:51 --> Output Class Initialized
INFO - 2024-02-12 08:01:51 --> Security Class Initialized
DEBUG - 2024-02-12 08:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:01:51 --> Input Class Initialized
INFO - 2024-02-12 08:01:51 --> Language Class Initialized
INFO - 2024-02-12 08:01:51 --> Loader Class Initialized
INFO - 2024-02-12 08:01:51 --> Helper loaded: url_helper
INFO - 2024-02-12 08:01:51 --> Helper loaded: file_helper
INFO - 2024-02-12 08:01:51 --> Helper loaded: html_helper
INFO - 2024-02-12 08:01:51 --> Helper loaded: text_helper
INFO - 2024-02-12 08:01:51 --> Helper loaded: form_helper
INFO - 2024-02-12 08:01:51 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:01:51 --> Helper loaded: security_helper
INFO - 2024-02-12 08:01:51 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:01:51 --> Database Driver Class Initialized
INFO - 2024-02-12 08:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:01:51 --> Parser Class Initialized
INFO - 2024-02-12 08:01:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:01:51 --> Pagination Class Initialized
INFO - 2024-02-12 08:01:51 --> Form Validation Class Initialized
INFO - 2024-02-12 08:01:51 --> Controller Class Initialized
DEBUG - 2024-02-12 08:01:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:01:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:01:51 --> Model Class Initialized
DEBUG - 2024-02-12 08:01:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:01:51 --> Model Class Initialized
INFO - 2024-02-12 08:01:51 --> Final output sent to browser
DEBUG - 2024-02-12 08:01:51 --> Total execution time: 0.0280
ERROR - 2024-02-12 08:01:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:01:51 --> Config Class Initialized
INFO - 2024-02-12 08:01:51 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:01:51 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:01:51 --> Utf8 Class Initialized
INFO - 2024-02-12 08:01:51 --> URI Class Initialized
INFO - 2024-02-12 08:01:51 --> Router Class Initialized
INFO - 2024-02-12 08:01:51 --> Output Class Initialized
INFO - 2024-02-12 08:01:51 --> Security Class Initialized
DEBUG - 2024-02-12 08:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:01:51 --> Input Class Initialized
INFO - 2024-02-12 08:01:51 --> Language Class Initialized
INFO - 2024-02-12 08:01:51 --> Loader Class Initialized
INFO - 2024-02-12 08:01:51 --> Helper loaded: url_helper
INFO - 2024-02-12 08:01:51 --> Helper loaded: file_helper
INFO - 2024-02-12 08:01:51 --> Helper loaded: html_helper
INFO - 2024-02-12 08:01:51 --> Helper loaded: text_helper
INFO - 2024-02-12 08:01:51 --> Helper loaded: form_helper
INFO - 2024-02-12 08:01:51 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:01:51 --> Helper loaded: security_helper
INFO - 2024-02-12 08:01:51 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:01:51 --> Database Driver Class Initialized
INFO - 2024-02-12 08:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:01:51 --> Parser Class Initialized
INFO - 2024-02-12 08:01:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:01:51 --> Pagination Class Initialized
INFO - 2024-02-12 08:01:51 --> Form Validation Class Initialized
INFO - 2024-02-12 08:01:51 --> Controller Class Initialized
DEBUG - 2024-02-12 08:01:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:01:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:01:51 --> Model Class Initialized
DEBUG - 2024-02-12 08:01:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:01:51 --> Model Class Initialized
INFO - 2024-02-12 08:01:51 --> Final output sent to browser
DEBUG - 2024-02-12 08:01:51 --> Total execution time: 0.0179
ERROR - 2024-02-12 08:01:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:01:52 --> Config Class Initialized
INFO - 2024-02-12 08:01:52 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:01:52 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:01:52 --> Utf8 Class Initialized
INFO - 2024-02-12 08:01:52 --> URI Class Initialized
INFO - 2024-02-12 08:01:52 --> Router Class Initialized
INFO - 2024-02-12 08:01:52 --> Output Class Initialized
INFO - 2024-02-12 08:01:52 --> Security Class Initialized
DEBUG - 2024-02-12 08:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:01:52 --> Input Class Initialized
INFO - 2024-02-12 08:01:52 --> Language Class Initialized
INFO - 2024-02-12 08:01:52 --> Loader Class Initialized
INFO - 2024-02-12 08:01:52 --> Helper loaded: url_helper
INFO - 2024-02-12 08:01:52 --> Helper loaded: file_helper
INFO - 2024-02-12 08:01:52 --> Helper loaded: html_helper
INFO - 2024-02-12 08:01:52 --> Helper loaded: text_helper
INFO - 2024-02-12 08:01:52 --> Helper loaded: form_helper
INFO - 2024-02-12 08:01:52 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:01:52 --> Helper loaded: security_helper
INFO - 2024-02-12 08:01:52 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:01:52 --> Database Driver Class Initialized
INFO - 2024-02-12 08:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:01:52 --> Parser Class Initialized
INFO - 2024-02-12 08:01:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:01:52 --> Pagination Class Initialized
INFO - 2024-02-12 08:01:52 --> Form Validation Class Initialized
INFO - 2024-02-12 08:01:52 --> Controller Class Initialized
DEBUG - 2024-02-12 08:01:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:01:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:01:52 --> Model Class Initialized
DEBUG - 2024-02-12 08:01:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:01:52 --> Model Class Initialized
INFO - 2024-02-12 08:01:52 --> Final output sent to browser
DEBUG - 2024-02-12 08:01:52 --> Total execution time: 0.0178
ERROR - 2024-02-12 08:01:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:01:53 --> Config Class Initialized
INFO - 2024-02-12 08:01:53 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:01:53 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:01:53 --> Utf8 Class Initialized
INFO - 2024-02-12 08:01:53 --> URI Class Initialized
INFO - 2024-02-12 08:01:53 --> Router Class Initialized
INFO - 2024-02-12 08:01:53 --> Output Class Initialized
INFO - 2024-02-12 08:01:53 --> Security Class Initialized
DEBUG - 2024-02-12 08:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:01:53 --> Input Class Initialized
INFO - 2024-02-12 08:01:53 --> Language Class Initialized
INFO - 2024-02-12 08:01:53 --> Loader Class Initialized
INFO - 2024-02-12 08:01:53 --> Helper loaded: url_helper
INFO - 2024-02-12 08:01:53 --> Helper loaded: file_helper
INFO - 2024-02-12 08:01:53 --> Helper loaded: html_helper
INFO - 2024-02-12 08:01:53 --> Helper loaded: text_helper
INFO - 2024-02-12 08:01:53 --> Helper loaded: form_helper
INFO - 2024-02-12 08:01:53 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:01:53 --> Helper loaded: security_helper
INFO - 2024-02-12 08:01:53 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:01:53 --> Database Driver Class Initialized
INFO - 2024-02-12 08:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:01:53 --> Parser Class Initialized
INFO - 2024-02-12 08:01:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:01:53 --> Pagination Class Initialized
INFO - 2024-02-12 08:01:53 --> Form Validation Class Initialized
INFO - 2024-02-12 08:01:53 --> Controller Class Initialized
DEBUG - 2024-02-12 08:01:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:01:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:01:53 --> Model Class Initialized
DEBUG - 2024-02-12 08:01:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:01:53 --> Model Class Initialized
INFO - 2024-02-12 08:01:53 --> Final output sent to browser
DEBUG - 2024-02-12 08:01:53 --> Total execution time: 0.0178
ERROR - 2024-02-12 08:01:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:01:54 --> Config Class Initialized
INFO - 2024-02-12 08:01:54 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:01:54 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:01:54 --> Utf8 Class Initialized
INFO - 2024-02-12 08:01:54 --> URI Class Initialized
INFO - 2024-02-12 08:01:54 --> Router Class Initialized
INFO - 2024-02-12 08:01:54 --> Output Class Initialized
INFO - 2024-02-12 08:01:54 --> Security Class Initialized
DEBUG - 2024-02-12 08:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:01:54 --> Input Class Initialized
INFO - 2024-02-12 08:01:54 --> Language Class Initialized
INFO - 2024-02-12 08:01:54 --> Loader Class Initialized
INFO - 2024-02-12 08:01:54 --> Helper loaded: url_helper
INFO - 2024-02-12 08:01:54 --> Helper loaded: file_helper
INFO - 2024-02-12 08:01:54 --> Helper loaded: html_helper
INFO - 2024-02-12 08:01:54 --> Helper loaded: text_helper
INFO - 2024-02-12 08:01:54 --> Helper loaded: form_helper
INFO - 2024-02-12 08:01:54 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:01:54 --> Helper loaded: security_helper
INFO - 2024-02-12 08:01:54 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:01:54 --> Database Driver Class Initialized
INFO - 2024-02-12 08:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:01:54 --> Parser Class Initialized
INFO - 2024-02-12 08:01:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:01:54 --> Pagination Class Initialized
INFO - 2024-02-12 08:01:54 --> Form Validation Class Initialized
INFO - 2024-02-12 08:01:54 --> Controller Class Initialized
DEBUG - 2024-02-12 08:01:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:01:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:01:54 --> Model Class Initialized
DEBUG - 2024-02-12 08:01:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:01:54 --> Model Class Initialized
INFO - 2024-02-12 08:01:54 --> Final output sent to browser
DEBUG - 2024-02-12 08:01:54 --> Total execution time: 0.0304
ERROR - 2024-02-12 08:01:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:01:54 --> Config Class Initialized
INFO - 2024-02-12 08:01:54 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:01:54 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:01:54 --> Utf8 Class Initialized
INFO - 2024-02-12 08:01:54 --> URI Class Initialized
INFO - 2024-02-12 08:01:54 --> Router Class Initialized
INFO - 2024-02-12 08:01:54 --> Output Class Initialized
INFO - 2024-02-12 08:01:54 --> Security Class Initialized
DEBUG - 2024-02-12 08:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:01:54 --> Input Class Initialized
INFO - 2024-02-12 08:01:54 --> Language Class Initialized
INFO - 2024-02-12 08:01:54 --> Loader Class Initialized
INFO - 2024-02-12 08:01:54 --> Helper loaded: url_helper
INFO - 2024-02-12 08:01:54 --> Helper loaded: file_helper
INFO - 2024-02-12 08:01:54 --> Helper loaded: html_helper
INFO - 2024-02-12 08:01:54 --> Helper loaded: text_helper
INFO - 2024-02-12 08:01:54 --> Helper loaded: form_helper
INFO - 2024-02-12 08:01:54 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:01:54 --> Helper loaded: security_helper
INFO - 2024-02-12 08:01:54 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:01:54 --> Database Driver Class Initialized
INFO - 2024-02-12 08:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:01:54 --> Parser Class Initialized
INFO - 2024-02-12 08:01:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:01:54 --> Pagination Class Initialized
INFO - 2024-02-12 08:01:54 --> Form Validation Class Initialized
INFO - 2024-02-12 08:01:54 --> Controller Class Initialized
DEBUG - 2024-02-12 08:01:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:01:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:01:54 --> Model Class Initialized
DEBUG - 2024-02-12 08:01:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:01:54 --> Model Class Initialized
INFO - 2024-02-12 08:01:54 --> Final output sent to browser
DEBUG - 2024-02-12 08:01:54 --> Total execution time: 0.0291
ERROR - 2024-02-12 08:02:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:02:06 --> Config Class Initialized
INFO - 2024-02-12 08:02:06 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:02:06 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:02:06 --> Utf8 Class Initialized
INFO - 2024-02-12 08:02:06 --> URI Class Initialized
INFO - 2024-02-12 08:02:06 --> Router Class Initialized
INFO - 2024-02-12 08:02:06 --> Output Class Initialized
INFO - 2024-02-12 08:02:06 --> Security Class Initialized
DEBUG - 2024-02-12 08:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:02:06 --> Input Class Initialized
INFO - 2024-02-12 08:02:06 --> Language Class Initialized
INFO - 2024-02-12 08:02:06 --> Loader Class Initialized
INFO - 2024-02-12 08:02:06 --> Helper loaded: url_helper
INFO - 2024-02-12 08:02:06 --> Helper loaded: file_helper
INFO - 2024-02-12 08:02:06 --> Helper loaded: html_helper
INFO - 2024-02-12 08:02:06 --> Helper loaded: text_helper
INFO - 2024-02-12 08:02:06 --> Helper loaded: form_helper
INFO - 2024-02-12 08:02:06 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:02:06 --> Helper loaded: security_helper
INFO - 2024-02-12 08:02:06 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:02:06 --> Database Driver Class Initialized
INFO - 2024-02-12 08:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:02:06 --> Parser Class Initialized
INFO - 2024-02-12 08:02:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:02:06 --> Pagination Class Initialized
INFO - 2024-02-12 08:02:06 --> Form Validation Class Initialized
INFO - 2024-02-12 08:02:06 --> Controller Class Initialized
DEBUG - 2024-02-12 08:02:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:02:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:02:06 --> Model Class Initialized
DEBUG - 2024-02-12 08:02:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:02:06 --> Model Class Initialized
INFO - 2024-02-12 08:02:06 --> Final output sent to browser
DEBUG - 2024-02-12 08:02:06 --> Total execution time: 0.0306
ERROR - 2024-02-12 08:02:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:02:06 --> Config Class Initialized
INFO - 2024-02-12 08:02:06 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:02:06 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:02:06 --> Utf8 Class Initialized
INFO - 2024-02-12 08:02:06 --> URI Class Initialized
INFO - 2024-02-12 08:02:06 --> Router Class Initialized
INFO - 2024-02-12 08:02:06 --> Output Class Initialized
INFO - 2024-02-12 08:02:06 --> Security Class Initialized
DEBUG - 2024-02-12 08:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:02:06 --> Input Class Initialized
INFO - 2024-02-12 08:02:06 --> Language Class Initialized
INFO - 2024-02-12 08:02:06 --> Loader Class Initialized
INFO - 2024-02-12 08:02:06 --> Helper loaded: url_helper
INFO - 2024-02-12 08:02:06 --> Helper loaded: file_helper
INFO - 2024-02-12 08:02:06 --> Helper loaded: html_helper
INFO - 2024-02-12 08:02:06 --> Helper loaded: text_helper
INFO - 2024-02-12 08:02:06 --> Helper loaded: form_helper
INFO - 2024-02-12 08:02:06 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:02:06 --> Helper loaded: security_helper
INFO - 2024-02-12 08:02:06 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:02:06 --> Database Driver Class Initialized
INFO - 2024-02-12 08:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:02:06 --> Parser Class Initialized
INFO - 2024-02-12 08:02:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:02:06 --> Pagination Class Initialized
INFO - 2024-02-12 08:02:06 --> Form Validation Class Initialized
INFO - 2024-02-12 08:02:06 --> Controller Class Initialized
DEBUG - 2024-02-12 08:02:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:02:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:02:06 --> Model Class Initialized
DEBUG - 2024-02-12 08:02:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:02:06 --> Model Class Initialized
INFO - 2024-02-12 08:02:07 --> Final output sent to browser
DEBUG - 2024-02-12 08:02:07 --> Total execution time: 0.0216
ERROR - 2024-02-12 08:02:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:02:10 --> Config Class Initialized
INFO - 2024-02-12 08:02:10 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:02:10 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:02:10 --> Utf8 Class Initialized
INFO - 2024-02-12 08:02:10 --> URI Class Initialized
INFO - 2024-02-12 08:02:10 --> Router Class Initialized
INFO - 2024-02-12 08:02:10 --> Output Class Initialized
INFO - 2024-02-12 08:02:10 --> Security Class Initialized
DEBUG - 2024-02-12 08:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:02:10 --> Input Class Initialized
INFO - 2024-02-12 08:02:10 --> Language Class Initialized
INFO - 2024-02-12 08:02:10 --> Loader Class Initialized
INFO - 2024-02-12 08:02:10 --> Helper loaded: url_helper
INFO - 2024-02-12 08:02:10 --> Helper loaded: file_helper
INFO - 2024-02-12 08:02:10 --> Helper loaded: html_helper
INFO - 2024-02-12 08:02:10 --> Helper loaded: text_helper
INFO - 2024-02-12 08:02:10 --> Helper loaded: form_helper
INFO - 2024-02-12 08:02:10 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:02:10 --> Helper loaded: security_helper
INFO - 2024-02-12 08:02:10 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:02:10 --> Database Driver Class Initialized
INFO - 2024-02-12 08:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:02:10 --> Parser Class Initialized
INFO - 2024-02-12 08:02:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:02:10 --> Pagination Class Initialized
INFO - 2024-02-12 08:02:10 --> Form Validation Class Initialized
INFO - 2024-02-12 08:02:10 --> Controller Class Initialized
DEBUG - 2024-02-12 08:02:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:02:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:02:10 --> Model Class Initialized
DEBUG - 2024-02-12 08:02:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:02:10 --> Model Class Initialized
INFO - 2024-02-12 08:02:10 --> Final output sent to browser
DEBUG - 2024-02-12 08:02:10 --> Total execution time: 0.0168
ERROR - 2024-02-12 08:02:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:02:13 --> Config Class Initialized
INFO - 2024-02-12 08:02:13 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:02:13 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:02:13 --> Utf8 Class Initialized
INFO - 2024-02-12 08:02:13 --> URI Class Initialized
INFO - 2024-02-12 08:02:13 --> Router Class Initialized
INFO - 2024-02-12 08:02:13 --> Output Class Initialized
INFO - 2024-02-12 08:02:13 --> Security Class Initialized
DEBUG - 2024-02-12 08:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:02:13 --> Input Class Initialized
INFO - 2024-02-12 08:02:13 --> Language Class Initialized
INFO - 2024-02-12 08:02:13 --> Loader Class Initialized
INFO - 2024-02-12 08:02:13 --> Helper loaded: url_helper
INFO - 2024-02-12 08:02:13 --> Helper loaded: file_helper
INFO - 2024-02-12 08:02:13 --> Helper loaded: html_helper
INFO - 2024-02-12 08:02:13 --> Helper loaded: text_helper
INFO - 2024-02-12 08:02:13 --> Helper loaded: form_helper
INFO - 2024-02-12 08:02:13 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:02:13 --> Helper loaded: security_helper
INFO - 2024-02-12 08:02:13 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:02:13 --> Database Driver Class Initialized
INFO - 2024-02-12 08:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:02:13 --> Parser Class Initialized
INFO - 2024-02-12 08:02:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:02:13 --> Pagination Class Initialized
INFO - 2024-02-12 08:02:13 --> Form Validation Class Initialized
INFO - 2024-02-12 08:02:13 --> Controller Class Initialized
DEBUG - 2024-02-12 08:02:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:02:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:02:13 --> Model Class Initialized
DEBUG - 2024-02-12 08:02:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:02:13 --> Model Class Initialized
DEBUG - 2024-02-12 08:02:13 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:02:13 --> Model Class Initialized
INFO - 2024-02-12 08:02:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-12 08:02:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:02:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 08:02:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 08:02:13 --> Model Class Initialized
INFO - 2024-02-12 08:02:13 --> Model Class Initialized
INFO - 2024-02-12 08:02:13 --> Model Class Initialized
INFO - 2024-02-12 08:02:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 08:02:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 08:02:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 08:02:14 --> Final output sent to browser
DEBUG - 2024-02-12 08:02:14 --> Total execution time: 0.2109
ERROR - 2024-02-12 08:02:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:02:14 --> Config Class Initialized
INFO - 2024-02-12 08:02:14 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:02:14 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:02:14 --> Utf8 Class Initialized
INFO - 2024-02-12 08:02:14 --> URI Class Initialized
INFO - 2024-02-12 08:02:14 --> Router Class Initialized
INFO - 2024-02-12 08:02:14 --> Output Class Initialized
INFO - 2024-02-12 08:02:14 --> Security Class Initialized
DEBUG - 2024-02-12 08:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:02:14 --> Input Class Initialized
INFO - 2024-02-12 08:02:14 --> Language Class Initialized
INFO - 2024-02-12 08:02:14 --> Loader Class Initialized
INFO - 2024-02-12 08:02:14 --> Helper loaded: url_helper
INFO - 2024-02-12 08:02:14 --> Helper loaded: file_helper
INFO - 2024-02-12 08:02:14 --> Helper loaded: html_helper
INFO - 2024-02-12 08:02:14 --> Helper loaded: text_helper
INFO - 2024-02-12 08:02:14 --> Helper loaded: form_helper
INFO - 2024-02-12 08:02:14 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:02:14 --> Helper loaded: security_helper
INFO - 2024-02-12 08:02:14 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:02:14 --> Database Driver Class Initialized
INFO - 2024-02-12 08:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:02:14 --> Parser Class Initialized
INFO - 2024-02-12 08:02:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:02:14 --> Pagination Class Initialized
INFO - 2024-02-12 08:02:14 --> Form Validation Class Initialized
INFO - 2024-02-12 08:02:14 --> Controller Class Initialized
DEBUG - 2024-02-12 08:02:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:02:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:02:14 --> Model Class Initialized
DEBUG - 2024-02-12 08:02:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:02:14 --> Model Class Initialized
INFO - 2024-02-12 08:02:14 --> Final output sent to browser
DEBUG - 2024-02-12 08:02:14 --> Total execution time: 0.0305
ERROR - 2024-02-12 08:02:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:02:18 --> Config Class Initialized
INFO - 2024-02-12 08:02:18 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:02:18 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:02:18 --> Utf8 Class Initialized
INFO - 2024-02-12 08:02:18 --> URI Class Initialized
INFO - 2024-02-12 08:02:18 --> Router Class Initialized
INFO - 2024-02-12 08:02:18 --> Output Class Initialized
INFO - 2024-02-12 08:02:18 --> Security Class Initialized
DEBUG - 2024-02-12 08:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:02:18 --> Input Class Initialized
INFO - 2024-02-12 08:02:18 --> Language Class Initialized
INFO - 2024-02-12 08:02:18 --> Loader Class Initialized
INFO - 2024-02-12 08:02:18 --> Helper loaded: url_helper
INFO - 2024-02-12 08:02:18 --> Helper loaded: file_helper
INFO - 2024-02-12 08:02:18 --> Helper loaded: html_helper
INFO - 2024-02-12 08:02:18 --> Helper loaded: text_helper
INFO - 2024-02-12 08:02:18 --> Helper loaded: form_helper
INFO - 2024-02-12 08:02:18 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:02:18 --> Helper loaded: security_helper
INFO - 2024-02-12 08:02:18 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:02:18 --> Database Driver Class Initialized
INFO - 2024-02-12 08:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:02:18 --> Parser Class Initialized
INFO - 2024-02-12 08:02:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:02:18 --> Pagination Class Initialized
INFO - 2024-02-12 08:02:18 --> Form Validation Class Initialized
INFO - 2024-02-12 08:02:18 --> Controller Class Initialized
DEBUG - 2024-02-12 08:02:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:02:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:02:18 --> Model Class Initialized
DEBUG - 2024-02-12 08:02:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:02:18 --> Model Class Initialized
INFO - 2024-02-12 08:02:18 --> Final output sent to browser
DEBUG - 2024-02-12 08:02:18 --> Total execution time: 0.1955
ERROR - 2024-02-12 08:02:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:02:31 --> Config Class Initialized
INFO - 2024-02-12 08:02:31 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:02:31 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:02:31 --> Utf8 Class Initialized
INFO - 2024-02-12 08:02:31 --> URI Class Initialized
INFO - 2024-02-12 08:02:31 --> Router Class Initialized
INFO - 2024-02-12 08:02:31 --> Output Class Initialized
INFO - 2024-02-12 08:02:31 --> Security Class Initialized
DEBUG - 2024-02-12 08:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:02:31 --> Input Class Initialized
INFO - 2024-02-12 08:02:31 --> Language Class Initialized
INFO - 2024-02-12 08:02:31 --> Loader Class Initialized
INFO - 2024-02-12 08:02:31 --> Helper loaded: url_helper
INFO - 2024-02-12 08:02:31 --> Helper loaded: file_helper
INFO - 2024-02-12 08:02:31 --> Helper loaded: html_helper
INFO - 2024-02-12 08:02:31 --> Helper loaded: text_helper
INFO - 2024-02-12 08:02:31 --> Helper loaded: form_helper
INFO - 2024-02-12 08:02:31 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:02:31 --> Helper loaded: security_helper
INFO - 2024-02-12 08:02:31 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:02:31 --> Database Driver Class Initialized
INFO - 2024-02-12 08:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:02:31 --> Parser Class Initialized
INFO - 2024-02-12 08:02:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:02:31 --> Pagination Class Initialized
INFO - 2024-02-12 08:02:31 --> Form Validation Class Initialized
INFO - 2024-02-12 08:02:31 --> Controller Class Initialized
DEBUG - 2024-02-12 08:02:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:02:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:02:31 --> Model Class Initialized
DEBUG - 2024-02-12 08:02:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:02:31 --> Model Class Initialized
INFO - 2024-02-12 08:02:31 --> Final output sent to browser
DEBUG - 2024-02-12 08:02:31 --> Total execution time: 0.0184
ERROR - 2024-02-12 08:02:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:02:34 --> Config Class Initialized
INFO - 2024-02-12 08:02:34 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:02:34 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:02:34 --> Utf8 Class Initialized
INFO - 2024-02-12 08:02:34 --> URI Class Initialized
INFO - 2024-02-12 08:02:34 --> Router Class Initialized
INFO - 2024-02-12 08:02:34 --> Output Class Initialized
INFO - 2024-02-12 08:02:34 --> Security Class Initialized
DEBUG - 2024-02-12 08:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:02:34 --> Input Class Initialized
INFO - 2024-02-12 08:02:34 --> Language Class Initialized
INFO - 2024-02-12 08:02:34 --> Loader Class Initialized
INFO - 2024-02-12 08:02:34 --> Helper loaded: url_helper
INFO - 2024-02-12 08:02:34 --> Helper loaded: file_helper
INFO - 2024-02-12 08:02:34 --> Helper loaded: html_helper
INFO - 2024-02-12 08:02:34 --> Helper loaded: text_helper
INFO - 2024-02-12 08:02:34 --> Helper loaded: form_helper
INFO - 2024-02-12 08:02:34 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:02:34 --> Helper loaded: security_helper
INFO - 2024-02-12 08:02:34 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:02:34 --> Database Driver Class Initialized
INFO - 2024-02-12 08:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:02:34 --> Parser Class Initialized
INFO - 2024-02-12 08:02:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:02:34 --> Pagination Class Initialized
INFO - 2024-02-12 08:02:34 --> Form Validation Class Initialized
INFO - 2024-02-12 08:02:34 --> Controller Class Initialized
DEBUG - 2024-02-12 08:02:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:02:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:02:34 --> Model Class Initialized
DEBUG - 2024-02-12 08:02:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:02:34 --> Model Class Initialized
INFO - 2024-02-12 08:02:34 --> Final output sent to browser
DEBUG - 2024-02-12 08:02:34 --> Total execution time: 0.0187
ERROR - 2024-02-12 08:02:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:02:36 --> Config Class Initialized
INFO - 2024-02-12 08:02:36 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:02:36 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:02:36 --> Utf8 Class Initialized
INFO - 2024-02-12 08:02:36 --> URI Class Initialized
INFO - 2024-02-12 08:02:36 --> Router Class Initialized
INFO - 2024-02-12 08:02:36 --> Output Class Initialized
INFO - 2024-02-12 08:02:36 --> Security Class Initialized
DEBUG - 2024-02-12 08:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:02:36 --> Input Class Initialized
INFO - 2024-02-12 08:02:36 --> Language Class Initialized
INFO - 2024-02-12 08:02:36 --> Loader Class Initialized
INFO - 2024-02-12 08:02:36 --> Helper loaded: url_helper
INFO - 2024-02-12 08:02:36 --> Helper loaded: file_helper
INFO - 2024-02-12 08:02:36 --> Helper loaded: html_helper
INFO - 2024-02-12 08:02:36 --> Helper loaded: text_helper
INFO - 2024-02-12 08:02:36 --> Helper loaded: form_helper
INFO - 2024-02-12 08:02:36 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:02:36 --> Helper loaded: security_helper
INFO - 2024-02-12 08:02:36 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:02:37 --> Database Driver Class Initialized
INFO - 2024-02-12 08:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:02:37 --> Parser Class Initialized
INFO - 2024-02-12 08:02:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:02:37 --> Pagination Class Initialized
INFO - 2024-02-12 08:02:37 --> Form Validation Class Initialized
INFO - 2024-02-12 08:02:37 --> Controller Class Initialized
DEBUG - 2024-02-12 08:02:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:02:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:02:37 --> Model Class Initialized
DEBUG - 2024-02-12 08:02:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:02:37 --> Model Class Initialized
DEBUG - 2024-02-12 08:02:37 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:02:37 --> Model Class Initialized
INFO - 2024-02-12 08:02:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-12 08:02:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:02:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 08:02:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 08:02:37 --> Model Class Initialized
INFO - 2024-02-12 08:02:37 --> Model Class Initialized
INFO - 2024-02-12 08:02:37 --> Model Class Initialized
INFO - 2024-02-12 08:02:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 08:02:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 08:02:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 08:02:37 --> Final output sent to browser
DEBUG - 2024-02-12 08:02:37 --> Total execution time: 0.2096
ERROR - 2024-02-12 08:02:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:02:37 --> Config Class Initialized
INFO - 2024-02-12 08:02:37 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:02:37 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:02:37 --> Utf8 Class Initialized
INFO - 2024-02-12 08:02:37 --> URI Class Initialized
INFO - 2024-02-12 08:02:37 --> Router Class Initialized
INFO - 2024-02-12 08:02:37 --> Output Class Initialized
INFO - 2024-02-12 08:02:37 --> Security Class Initialized
DEBUG - 2024-02-12 08:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:02:37 --> Input Class Initialized
INFO - 2024-02-12 08:02:37 --> Language Class Initialized
INFO - 2024-02-12 08:02:37 --> Loader Class Initialized
INFO - 2024-02-12 08:02:37 --> Helper loaded: url_helper
INFO - 2024-02-12 08:02:37 --> Helper loaded: file_helper
INFO - 2024-02-12 08:02:37 --> Helper loaded: html_helper
INFO - 2024-02-12 08:02:37 --> Helper loaded: text_helper
INFO - 2024-02-12 08:02:37 --> Helper loaded: form_helper
INFO - 2024-02-12 08:02:37 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:02:37 --> Helper loaded: security_helper
INFO - 2024-02-12 08:02:37 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:02:37 --> Database Driver Class Initialized
INFO - 2024-02-12 08:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:02:37 --> Parser Class Initialized
INFO - 2024-02-12 08:02:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:02:37 --> Pagination Class Initialized
INFO - 2024-02-12 08:02:37 --> Form Validation Class Initialized
INFO - 2024-02-12 08:02:37 --> Controller Class Initialized
DEBUG - 2024-02-12 08:02:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:02:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:02:37 --> Model Class Initialized
DEBUG - 2024-02-12 08:02:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:02:37 --> Model Class Initialized
INFO - 2024-02-12 08:02:37 --> Final output sent to browser
DEBUG - 2024-02-12 08:02:37 --> Total execution time: 0.0283
ERROR - 2024-02-12 08:05:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:05:28 --> Config Class Initialized
INFO - 2024-02-12 08:05:28 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:05:28 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:05:28 --> Utf8 Class Initialized
INFO - 2024-02-12 08:05:28 --> URI Class Initialized
DEBUG - 2024-02-12 08:05:28 --> No URI present. Default controller set.
INFO - 2024-02-12 08:05:28 --> Router Class Initialized
INFO - 2024-02-12 08:05:28 --> Output Class Initialized
INFO - 2024-02-12 08:05:28 --> Security Class Initialized
DEBUG - 2024-02-12 08:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:05:28 --> Input Class Initialized
INFO - 2024-02-12 08:05:28 --> Language Class Initialized
INFO - 2024-02-12 08:05:28 --> Loader Class Initialized
INFO - 2024-02-12 08:05:28 --> Helper loaded: url_helper
INFO - 2024-02-12 08:05:28 --> Helper loaded: file_helper
INFO - 2024-02-12 08:05:28 --> Helper loaded: html_helper
INFO - 2024-02-12 08:05:28 --> Helper loaded: text_helper
INFO - 2024-02-12 08:05:28 --> Helper loaded: form_helper
INFO - 2024-02-12 08:05:28 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:05:28 --> Helper loaded: security_helper
INFO - 2024-02-12 08:05:28 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:05:28 --> Database Driver Class Initialized
INFO - 2024-02-12 08:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:05:28 --> Parser Class Initialized
INFO - 2024-02-12 08:05:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:05:28 --> Pagination Class Initialized
INFO - 2024-02-12 08:05:28 --> Form Validation Class Initialized
INFO - 2024-02-12 08:05:28 --> Controller Class Initialized
INFO - 2024-02-12 08:05:28 --> Model Class Initialized
DEBUG - 2024-02-12 08:05:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:05:28 --> Model Class Initialized
DEBUG - 2024-02-12 08:05:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:05:28 --> Model Class Initialized
INFO - 2024-02-12 08:05:28 --> Model Class Initialized
INFO - 2024-02-12 08:05:28 --> Model Class Initialized
INFO - 2024-02-12 08:05:28 --> Model Class Initialized
DEBUG - 2024-02-12 08:05:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:05:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:05:28 --> Model Class Initialized
INFO - 2024-02-12 08:05:28 --> Model Class Initialized
INFO - 2024-02-12 08:05:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-12 08:05:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:05:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 08:05:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 08:05:29 --> Model Class Initialized
INFO - 2024-02-12 08:05:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 08:05:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 08:05:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 08:05:29 --> Final output sent to browser
DEBUG - 2024-02-12 08:05:29 --> Total execution time: 0.2276
ERROR - 2024-02-12 08:05:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:05:37 --> Config Class Initialized
INFO - 2024-02-12 08:05:37 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:05:37 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:05:37 --> Utf8 Class Initialized
INFO - 2024-02-12 08:05:37 --> URI Class Initialized
INFO - 2024-02-12 08:05:37 --> Router Class Initialized
INFO - 2024-02-12 08:05:37 --> Output Class Initialized
INFO - 2024-02-12 08:05:37 --> Security Class Initialized
DEBUG - 2024-02-12 08:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:05:37 --> Input Class Initialized
INFO - 2024-02-12 08:05:37 --> Language Class Initialized
INFO - 2024-02-12 08:05:37 --> Loader Class Initialized
INFO - 2024-02-12 08:05:37 --> Helper loaded: url_helper
INFO - 2024-02-12 08:05:37 --> Helper loaded: file_helper
INFO - 2024-02-12 08:05:37 --> Helper loaded: html_helper
INFO - 2024-02-12 08:05:37 --> Helper loaded: text_helper
INFO - 2024-02-12 08:05:37 --> Helper loaded: form_helper
INFO - 2024-02-12 08:05:37 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:05:37 --> Helper loaded: security_helper
INFO - 2024-02-12 08:05:37 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:05:37 --> Database Driver Class Initialized
INFO - 2024-02-12 08:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:05:37 --> Parser Class Initialized
INFO - 2024-02-12 08:05:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:05:37 --> Pagination Class Initialized
INFO - 2024-02-12 08:05:37 --> Form Validation Class Initialized
INFO - 2024-02-12 08:05:37 --> Controller Class Initialized
INFO - 2024-02-12 08:05:37 --> Model Class Initialized
DEBUG - 2024-02-12 08:05:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:05:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:05:37 --> Model Class Initialized
DEBUG - 2024-02-12 08:05:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:05:37 --> Model Class Initialized
INFO - 2024-02-12 08:05:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-02-12 08:05:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:05:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 08:05:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 08:05:37 --> Model Class Initialized
INFO - 2024-02-12 08:05:37 --> Model Class Initialized
INFO - 2024-02-12 08:05:37 --> Model Class Initialized
INFO - 2024-02-12 08:05:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 08:05:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 08:05:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 08:05:37 --> Final output sent to browser
DEBUG - 2024-02-12 08:05:37 --> Total execution time: 0.1746
ERROR - 2024-02-12 08:06:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:06:17 --> Config Class Initialized
INFO - 2024-02-12 08:06:17 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:06:17 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:06:17 --> Utf8 Class Initialized
INFO - 2024-02-12 08:06:17 --> URI Class Initialized
DEBUG - 2024-02-12 08:06:17 --> No URI present. Default controller set.
INFO - 2024-02-12 08:06:17 --> Router Class Initialized
INFO - 2024-02-12 08:06:17 --> Output Class Initialized
INFO - 2024-02-12 08:06:17 --> Security Class Initialized
DEBUG - 2024-02-12 08:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:06:17 --> Input Class Initialized
INFO - 2024-02-12 08:06:17 --> Language Class Initialized
INFO - 2024-02-12 08:06:17 --> Loader Class Initialized
INFO - 2024-02-12 08:06:17 --> Helper loaded: url_helper
INFO - 2024-02-12 08:06:17 --> Helper loaded: file_helper
INFO - 2024-02-12 08:06:17 --> Helper loaded: html_helper
INFO - 2024-02-12 08:06:17 --> Helper loaded: text_helper
INFO - 2024-02-12 08:06:17 --> Helper loaded: form_helper
INFO - 2024-02-12 08:06:17 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:06:17 --> Helper loaded: security_helper
INFO - 2024-02-12 08:06:17 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:06:17 --> Database Driver Class Initialized
INFO - 2024-02-12 08:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:06:17 --> Parser Class Initialized
INFO - 2024-02-12 08:06:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:06:17 --> Pagination Class Initialized
INFO - 2024-02-12 08:06:17 --> Form Validation Class Initialized
INFO - 2024-02-12 08:06:17 --> Controller Class Initialized
INFO - 2024-02-12 08:06:17 --> Model Class Initialized
DEBUG - 2024-02-12 08:06:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:06:17 --> Model Class Initialized
DEBUG - 2024-02-12 08:06:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:06:17 --> Model Class Initialized
INFO - 2024-02-12 08:06:17 --> Model Class Initialized
INFO - 2024-02-12 08:06:17 --> Model Class Initialized
INFO - 2024-02-12 08:06:17 --> Model Class Initialized
DEBUG - 2024-02-12 08:06:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:06:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:06:17 --> Model Class Initialized
INFO - 2024-02-12 08:06:17 --> Model Class Initialized
INFO - 2024-02-12 08:06:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-12 08:06:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:06:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 08:06:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 08:06:17 --> Model Class Initialized
INFO - 2024-02-12 08:06:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 08:06:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 08:06:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 08:06:17 --> Final output sent to browser
DEBUG - 2024-02-12 08:06:17 --> Total execution time: 0.2325
ERROR - 2024-02-12 08:06:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:06:22 --> Config Class Initialized
INFO - 2024-02-12 08:06:22 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:06:22 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:06:22 --> Utf8 Class Initialized
INFO - 2024-02-12 08:06:22 --> URI Class Initialized
INFO - 2024-02-12 08:06:22 --> Router Class Initialized
INFO - 2024-02-12 08:06:22 --> Output Class Initialized
INFO - 2024-02-12 08:06:22 --> Security Class Initialized
DEBUG - 2024-02-12 08:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:06:22 --> Input Class Initialized
INFO - 2024-02-12 08:06:22 --> Language Class Initialized
INFO - 2024-02-12 08:06:22 --> Loader Class Initialized
INFO - 2024-02-12 08:06:22 --> Helper loaded: url_helper
INFO - 2024-02-12 08:06:22 --> Helper loaded: file_helper
INFO - 2024-02-12 08:06:22 --> Helper loaded: html_helper
INFO - 2024-02-12 08:06:22 --> Helper loaded: text_helper
INFO - 2024-02-12 08:06:22 --> Helper loaded: form_helper
INFO - 2024-02-12 08:06:22 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:06:22 --> Helper loaded: security_helper
INFO - 2024-02-12 08:06:22 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:06:22 --> Database Driver Class Initialized
INFO - 2024-02-12 08:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:06:22 --> Parser Class Initialized
INFO - 2024-02-12 08:06:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:06:22 --> Pagination Class Initialized
INFO - 2024-02-12 08:06:22 --> Form Validation Class Initialized
INFO - 2024-02-12 08:06:22 --> Controller Class Initialized
DEBUG - 2024-02-12 08:06:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:06:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:06:22 --> Model Class Initialized
DEBUG - 2024-02-12 08:06:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:06:22 --> Model Class Initialized
DEBUG - 2024-02-12 08:06:22 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:06:22 --> Model Class Initialized
INFO - 2024-02-12 08:06:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-12 08:06:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:06:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 08:06:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 08:06:22 --> Model Class Initialized
INFO - 2024-02-12 08:06:22 --> Model Class Initialized
INFO - 2024-02-12 08:06:22 --> Model Class Initialized
INFO - 2024-02-12 08:06:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 08:06:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 08:06:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 08:06:22 --> Final output sent to browser
DEBUG - 2024-02-12 08:06:22 --> Total execution time: 0.1512
ERROR - 2024-02-12 08:06:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:06:23 --> Config Class Initialized
INFO - 2024-02-12 08:06:23 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:06:23 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:06:23 --> Utf8 Class Initialized
INFO - 2024-02-12 08:06:23 --> URI Class Initialized
INFO - 2024-02-12 08:06:23 --> Router Class Initialized
INFO - 2024-02-12 08:06:23 --> Output Class Initialized
INFO - 2024-02-12 08:06:23 --> Security Class Initialized
DEBUG - 2024-02-12 08:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:06:23 --> Input Class Initialized
INFO - 2024-02-12 08:06:23 --> Language Class Initialized
INFO - 2024-02-12 08:06:23 --> Loader Class Initialized
INFO - 2024-02-12 08:06:23 --> Helper loaded: url_helper
INFO - 2024-02-12 08:06:23 --> Helper loaded: file_helper
INFO - 2024-02-12 08:06:23 --> Helper loaded: html_helper
INFO - 2024-02-12 08:06:23 --> Helper loaded: text_helper
INFO - 2024-02-12 08:06:23 --> Helper loaded: form_helper
INFO - 2024-02-12 08:06:23 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:06:23 --> Helper loaded: security_helper
INFO - 2024-02-12 08:06:23 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:06:23 --> Database Driver Class Initialized
INFO - 2024-02-12 08:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:06:23 --> Parser Class Initialized
INFO - 2024-02-12 08:06:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:06:23 --> Pagination Class Initialized
INFO - 2024-02-12 08:06:23 --> Form Validation Class Initialized
INFO - 2024-02-12 08:06:23 --> Controller Class Initialized
DEBUG - 2024-02-12 08:06:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:06:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:06:23 --> Model Class Initialized
DEBUG - 2024-02-12 08:06:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:06:23 --> Model Class Initialized
INFO - 2024-02-12 08:06:23 --> Final output sent to browser
DEBUG - 2024-02-12 08:06:23 --> Total execution time: 0.0220
ERROR - 2024-02-12 08:06:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:06:30 --> Config Class Initialized
INFO - 2024-02-12 08:06:30 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:06:30 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:06:30 --> Utf8 Class Initialized
INFO - 2024-02-12 08:06:30 --> URI Class Initialized
INFO - 2024-02-12 08:06:30 --> Router Class Initialized
INFO - 2024-02-12 08:06:30 --> Output Class Initialized
INFO - 2024-02-12 08:06:30 --> Security Class Initialized
DEBUG - 2024-02-12 08:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:06:30 --> Input Class Initialized
INFO - 2024-02-12 08:06:30 --> Language Class Initialized
INFO - 2024-02-12 08:06:30 --> Loader Class Initialized
INFO - 2024-02-12 08:06:30 --> Helper loaded: url_helper
INFO - 2024-02-12 08:06:30 --> Helper loaded: file_helper
INFO - 2024-02-12 08:06:30 --> Helper loaded: html_helper
INFO - 2024-02-12 08:06:30 --> Helper loaded: text_helper
INFO - 2024-02-12 08:06:30 --> Helper loaded: form_helper
INFO - 2024-02-12 08:06:30 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:06:30 --> Helper loaded: security_helper
INFO - 2024-02-12 08:06:30 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:06:30 --> Database Driver Class Initialized
INFO - 2024-02-12 08:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:06:30 --> Parser Class Initialized
INFO - 2024-02-12 08:06:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:06:30 --> Pagination Class Initialized
INFO - 2024-02-12 08:06:30 --> Form Validation Class Initialized
INFO - 2024-02-12 08:06:30 --> Controller Class Initialized
DEBUG - 2024-02-12 08:06:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:06:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:06:30 --> Model Class Initialized
DEBUG - 2024-02-12 08:06:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:06:30 --> Model Class Initialized
INFO - 2024-02-12 08:06:30 --> Final output sent to browser
DEBUG - 2024-02-12 08:06:30 --> Total execution time: 0.0281
ERROR - 2024-02-12 08:07:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:07:26 --> Config Class Initialized
INFO - 2024-02-12 08:07:26 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:07:26 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:07:26 --> Utf8 Class Initialized
INFO - 2024-02-12 08:07:26 --> URI Class Initialized
DEBUG - 2024-02-12 08:07:26 --> No URI present. Default controller set.
INFO - 2024-02-12 08:07:26 --> Router Class Initialized
INFO - 2024-02-12 08:07:26 --> Output Class Initialized
INFO - 2024-02-12 08:07:26 --> Security Class Initialized
DEBUG - 2024-02-12 08:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:07:26 --> Input Class Initialized
INFO - 2024-02-12 08:07:26 --> Language Class Initialized
INFO - 2024-02-12 08:07:26 --> Loader Class Initialized
INFO - 2024-02-12 08:07:26 --> Helper loaded: url_helper
INFO - 2024-02-12 08:07:26 --> Helper loaded: file_helper
INFO - 2024-02-12 08:07:26 --> Helper loaded: html_helper
INFO - 2024-02-12 08:07:26 --> Helper loaded: text_helper
INFO - 2024-02-12 08:07:26 --> Helper loaded: form_helper
INFO - 2024-02-12 08:07:26 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:07:26 --> Helper loaded: security_helper
INFO - 2024-02-12 08:07:26 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:07:26 --> Database Driver Class Initialized
INFO - 2024-02-12 08:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:07:26 --> Parser Class Initialized
INFO - 2024-02-12 08:07:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:07:26 --> Pagination Class Initialized
INFO - 2024-02-12 08:07:26 --> Form Validation Class Initialized
INFO - 2024-02-12 08:07:26 --> Controller Class Initialized
INFO - 2024-02-12 08:07:26 --> Model Class Initialized
DEBUG - 2024-02-12 08:07:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:07:26 --> Model Class Initialized
DEBUG - 2024-02-12 08:07:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:07:26 --> Model Class Initialized
INFO - 2024-02-12 08:07:26 --> Model Class Initialized
INFO - 2024-02-12 08:07:26 --> Model Class Initialized
INFO - 2024-02-12 08:07:26 --> Model Class Initialized
DEBUG - 2024-02-12 08:07:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:07:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:07:26 --> Model Class Initialized
INFO - 2024-02-12 08:07:26 --> Model Class Initialized
INFO - 2024-02-12 08:07:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-12 08:07:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:07:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 08:07:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 08:07:27 --> Model Class Initialized
INFO - 2024-02-12 08:07:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 08:07:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 08:07:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 08:07:27 --> Final output sent to browser
DEBUG - 2024-02-12 08:07:27 --> Total execution time: 0.2411
ERROR - 2024-02-12 08:07:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:07:33 --> Config Class Initialized
INFO - 2024-02-12 08:07:33 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:07:33 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:07:33 --> Utf8 Class Initialized
INFO - 2024-02-12 08:07:33 --> URI Class Initialized
INFO - 2024-02-12 08:07:33 --> Router Class Initialized
INFO - 2024-02-12 08:07:33 --> Output Class Initialized
INFO - 2024-02-12 08:07:33 --> Security Class Initialized
DEBUG - 2024-02-12 08:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:07:33 --> Input Class Initialized
INFO - 2024-02-12 08:07:33 --> Language Class Initialized
INFO - 2024-02-12 08:07:33 --> Loader Class Initialized
INFO - 2024-02-12 08:07:33 --> Helper loaded: url_helper
INFO - 2024-02-12 08:07:33 --> Helper loaded: file_helper
INFO - 2024-02-12 08:07:33 --> Helper loaded: html_helper
INFO - 2024-02-12 08:07:33 --> Helper loaded: text_helper
INFO - 2024-02-12 08:07:33 --> Helper loaded: form_helper
INFO - 2024-02-12 08:07:33 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:07:33 --> Helper loaded: security_helper
INFO - 2024-02-12 08:07:33 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:07:33 --> Database Driver Class Initialized
INFO - 2024-02-12 08:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:07:33 --> Parser Class Initialized
INFO - 2024-02-12 08:07:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:07:33 --> Pagination Class Initialized
INFO - 2024-02-12 08:07:33 --> Form Validation Class Initialized
INFO - 2024-02-12 08:07:33 --> Controller Class Initialized
INFO - 2024-02-12 08:07:33 --> Model Class Initialized
DEBUG - 2024-02-12 08:07:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:07:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:07:33 --> Model Class Initialized
DEBUG - 2024-02-12 08:07:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:07:33 --> Model Class Initialized
INFO - 2024-02-12 08:07:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-02-12 08:07:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:07:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 08:07:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 08:07:33 --> Model Class Initialized
INFO - 2024-02-12 08:07:33 --> Model Class Initialized
INFO - 2024-02-12 08:07:33 --> Model Class Initialized
INFO - 2024-02-12 08:07:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 08:07:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 08:07:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 08:07:33 --> Final output sent to browser
DEBUG - 2024-02-12 08:07:33 --> Total execution time: 0.1779
ERROR - 2024-02-12 08:07:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:07:40 --> Config Class Initialized
INFO - 2024-02-12 08:07:40 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:07:40 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:07:40 --> Utf8 Class Initialized
INFO - 2024-02-12 08:07:40 --> URI Class Initialized
INFO - 2024-02-12 08:07:40 --> Router Class Initialized
INFO - 2024-02-12 08:07:40 --> Output Class Initialized
INFO - 2024-02-12 08:07:40 --> Security Class Initialized
DEBUG - 2024-02-12 08:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:07:40 --> Input Class Initialized
INFO - 2024-02-12 08:07:40 --> Language Class Initialized
INFO - 2024-02-12 08:07:40 --> Loader Class Initialized
INFO - 2024-02-12 08:07:40 --> Helper loaded: url_helper
INFO - 2024-02-12 08:07:40 --> Helper loaded: file_helper
INFO - 2024-02-12 08:07:40 --> Helper loaded: html_helper
INFO - 2024-02-12 08:07:40 --> Helper loaded: text_helper
INFO - 2024-02-12 08:07:40 --> Helper loaded: form_helper
INFO - 2024-02-12 08:07:40 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:07:40 --> Helper loaded: security_helper
INFO - 2024-02-12 08:07:40 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:07:40 --> Database Driver Class Initialized
INFO - 2024-02-12 08:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:07:40 --> Parser Class Initialized
INFO - 2024-02-12 08:07:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:07:40 --> Pagination Class Initialized
INFO - 2024-02-12 08:07:40 --> Form Validation Class Initialized
INFO - 2024-02-12 08:07:40 --> Controller Class Initialized
INFO - 2024-02-12 08:07:40 --> Model Class Initialized
DEBUG - 2024-02-12 08:07:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:07:40 --> Final output sent to browser
DEBUG - 2024-02-12 08:07:40 --> Total execution time: 0.0185
ERROR - 2024-02-12 08:07:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:07:42 --> Config Class Initialized
INFO - 2024-02-12 08:07:42 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:07:42 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:07:42 --> Utf8 Class Initialized
INFO - 2024-02-12 08:07:42 --> URI Class Initialized
INFO - 2024-02-12 08:07:42 --> Router Class Initialized
INFO - 2024-02-12 08:07:42 --> Output Class Initialized
INFO - 2024-02-12 08:07:42 --> Security Class Initialized
DEBUG - 2024-02-12 08:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:07:42 --> Input Class Initialized
INFO - 2024-02-12 08:07:42 --> Language Class Initialized
INFO - 2024-02-12 08:07:42 --> Loader Class Initialized
INFO - 2024-02-12 08:07:42 --> Helper loaded: url_helper
INFO - 2024-02-12 08:07:42 --> Helper loaded: file_helper
INFO - 2024-02-12 08:07:42 --> Helper loaded: html_helper
INFO - 2024-02-12 08:07:42 --> Helper loaded: text_helper
INFO - 2024-02-12 08:07:42 --> Helper loaded: form_helper
INFO - 2024-02-12 08:07:42 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:07:42 --> Helper loaded: security_helper
INFO - 2024-02-12 08:07:42 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:07:42 --> Database Driver Class Initialized
INFO - 2024-02-12 08:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:07:42 --> Parser Class Initialized
INFO - 2024-02-12 08:07:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:07:42 --> Pagination Class Initialized
INFO - 2024-02-12 08:07:42 --> Form Validation Class Initialized
INFO - 2024-02-12 08:07:42 --> Controller Class Initialized
INFO - 2024-02-12 08:07:42 --> Model Class Initialized
DEBUG - 2024-02-12 08:07:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:07:42 --> Final output sent to browser
DEBUG - 2024-02-12 08:07:42 --> Total execution time: 0.0157
ERROR - 2024-02-12 08:07:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:07:42 --> Config Class Initialized
INFO - 2024-02-12 08:07:42 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:07:42 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:07:42 --> Utf8 Class Initialized
INFO - 2024-02-12 08:07:42 --> URI Class Initialized
INFO - 2024-02-12 08:07:42 --> Router Class Initialized
INFO - 2024-02-12 08:07:42 --> Output Class Initialized
INFO - 2024-02-12 08:07:42 --> Security Class Initialized
DEBUG - 2024-02-12 08:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:07:42 --> Input Class Initialized
INFO - 2024-02-12 08:07:42 --> Language Class Initialized
INFO - 2024-02-12 08:07:42 --> Loader Class Initialized
INFO - 2024-02-12 08:07:42 --> Helper loaded: url_helper
INFO - 2024-02-12 08:07:42 --> Helper loaded: file_helper
INFO - 2024-02-12 08:07:42 --> Helper loaded: html_helper
INFO - 2024-02-12 08:07:42 --> Helper loaded: text_helper
INFO - 2024-02-12 08:07:42 --> Helper loaded: form_helper
INFO - 2024-02-12 08:07:42 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:07:42 --> Helper loaded: security_helper
INFO - 2024-02-12 08:07:42 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:07:42 --> Database Driver Class Initialized
INFO - 2024-02-12 08:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:07:42 --> Parser Class Initialized
INFO - 2024-02-12 08:07:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:07:42 --> Pagination Class Initialized
INFO - 2024-02-12 08:07:42 --> Form Validation Class Initialized
INFO - 2024-02-12 08:07:42 --> Controller Class Initialized
INFO - 2024-02-12 08:07:42 --> Model Class Initialized
DEBUG - 2024-02-12 08:07:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-12 08:07:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-02-12 08:07:42 --> Final output sent to browser
DEBUG - 2024-02-12 08:07:42 --> Total execution time: 0.0161
ERROR - 2024-02-12 08:07:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:07:45 --> Config Class Initialized
INFO - 2024-02-12 08:07:45 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:07:45 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:07:45 --> Utf8 Class Initialized
INFO - 2024-02-12 08:07:45 --> URI Class Initialized
INFO - 2024-02-12 08:07:45 --> Router Class Initialized
INFO - 2024-02-12 08:07:45 --> Output Class Initialized
INFO - 2024-02-12 08:07:45 --> Security Class Initialized
DEBUG - 2024-02-12 08:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:07:45 --> Input Class Initialized
INFO - 2024-02-12 08:07:45 --> Language Class Initialized
INFO - 2024-02-12 08:07:45 --> Loader Class Initialized
INFO - 2024-02-12 08:07:45 --> Helper loaded: url_helper
INFO - 2024-02-12 08:07:45 --> Helper loaded: file_helper
INFO - 2024-02-12 08:07:45 --> Helper loaded: html_helper
INFO - 2024-02-12 08:07:45 --> Helper loaded: text_helper
INFO - 2024-02-12 08:07:45 --> Helper loaded: form_helper
INFO - 2024-02-12 08:07:45 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:07:45 --> Helper loaded: security_helper
INFO - 2024-02-12 08:07:45 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:07:45 --> Database Driver Class Initialized
INFO - 2024-02-12 08:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:07:45 --> Parser Class Initialized
INFO - 2024-02-12 08:07:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:07:45 --> Pagination Class Initialized
INFO - 2024-02-12 08:07:45 --> Form Validation Class Initialized
INFO - 2024-02-12 08:07:45 --> Controller Class Initialized
INFO - 2024-02-12 08:07:45 --> Model Class Initialized
DEBUG - 2024-02-12 08:07:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:07:45 --> Final output sent to browser
DEBUG - 2024-02-12 08:07:45 --> Total execution time: 0.0159
ERROR - 2024-02-12 08:07:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:07:48 --> Config Class Initialized
INFO - 2024-02-12 08:07:48 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:07:48 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:07:48 --> Utf8 Class Initialized
INFO - 2024-02-12 08:07:48 --> URI Class Initialized
INFO - 2024-02-12 08:07:48 --> Router Class Initialized
INFO - 2024-02-12 08:07:48 --> Output Class Initialized
INFO - 2024-02-12 08:07:48 --> Security Class Initialized
DEBUG - 2024-02-12 08:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:07:48 --> Input Class Initialized
INFO - 2024-02-12 08:07:48 --> Language Class Initialized
INFO - 2024-02-12 08:07:48 --> Loader Class Initialized
INFO - 2024-02-12 08:07:48 --> Helper loaded: url_helper
INFO - 2024-02-12 08:07:48 --> Helper loaded: file_helper
INFO - 2024-02-12 08:07:48 --> Helper loaded: html_helper
INFO - 2024-02-12 08:07:48 --> Helper loaded: text_helper
INFO - 2024-02-12 08:07:48 --> Helper loaded: form_helper
INFO - 2024-02-12 08:07:48 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:07:48 --> Helper loaded: security_helper
INFO - 2024-02-12 08:07:48 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:07:48 --> Database Driver Class Initialized
INFO - 2024-02-12 08:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:07:48 --> Parser Class Initialized
INFO - 2024-02-12 08:07:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:07:48 --> Pagination Class Initialized
INFO - 2024-02-12 08:07:48 --> Form Validation Class Initialized
INFO - 2024-02-12 08:07:48 --> Controller Class Initialized
INFO - 2024-02-12 08:07:48 --> Final output sent to browser
DEBUG - 2024-02-12 08:07:48 --> Total execution time: 0.0137
ERROR - 2024-02-12 08:07:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:07:56 --> Config Class Initialized
INFO - 2024-02-12 08:07:56 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:07:56 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:07:56 --> Utf8 Class Initialized
INFO - 2024-02-12 08:07:56 --> URI Class Initialized
INFO - 2024-02-12 08:07:56 --> Router Class Initialized
INFO - 2024-02-12 08:07:56 --> Output Class Initialized
INFO - 2024-02-12 08:07:56 --> Security Class Initialized
DEBUG - 2024-02-12 08:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:07:56 --> Input Class Initialized
INFO - 2024-02-12 08:07:56 --> Language Class Initialized
INFO - 2024-02-12 08:07:56 --> Loader Class Initialized
INFO - 2024-02-12 08:07:56 --> Helper loaded: url_helper
INFO - 2024-02-12 08:07:56 --> Helper loaded: file_helper
INFO - 2024-02-12 08:07:56 --> Helper loaded: html_helper
INFO - 2024-02-12 08:07:56 --> Helper loaded: text_helper
INFO - 2024-02-12 08:07:56 --> Helper loaded: form_helper
INFO - 2024-02-12 08:07:56 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:07:56 --> Helper loaded: security_helper
INFO - 2024-02-12 08:07:56 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:07:56 --> Database Driver Class Initialized
INFO - 2024-02-12 08:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:07:56 --> Parser Class Initialized
INFO - 2024-02-12 08:07:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:07:56 --> Pagination Class Initialized
INFO - 2024-02-12 08:07:56 --> Form Validation Class Initialized
INFO - 2024-02-12 08:07:56 --> Controller Class Initialized
INFO - 2024-02-12 08:07:56 --> Model Class Initialized
DEBUG - 2024-02-12 08:07:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:07:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:07:56 --> Model Class Initialized
DEBUG - 2024-02-12 08:07:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:07:56 --> Model Class Initialized
INFO - 2024-02-12 08:07:56 --> Final output sent to browser
DEBUG - 2024-02-12 08:07:56 --> Total execution time: 0.0942
ERROR - 2024-02-12 08:08:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:08:00 --> Config Class Initialized
INFO - 2024-02-12 08:08:00 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:08:00 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:08:00 --> Utf8 Class Initialized
INFO - 2024-02-12 08:08:00 --> URI Class Initialized
INFO - 2024-02-12 08:08:00 --> Router Class Initialized
INFO - 2024-02-12 08:08:00 --> Output Class Initialized
INFO - 2024-02-12 08:08:00 --> Security Class Initialized
DEBUG - 2024-02-12 08:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:08:00 --> Input Class Initialized
INFO - 2024-02-12 08:08:00 --> Language Class Initialized
INFO - 2024-02-12 08:08:00 --> Loader Class Initialized
INFO - 2024-02-12 08:08:00 --> Helper loaded: url_helper
INFO - 2024-02-12 08:08:00 --> Helper loaded: file_helper
INFO - 2024-02-12 08:08:00 --> Helper loaded: html_helper
INFO - 2024-02-12 08:08:00 --> Helper loaded: text_helper
INFO - 2024-02-12 08:08:00 --> Helper loaded: form_helper
INFO - 2024-02-12 08:08:00 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:08:00 --> Helper loaded: security_helper
INFO - 2024-02-12 08:08:00 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:08:00 --> Database Driver Class Initialized
INFO - 2024-02-12 08:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:08:00 --> Parser Class Initialized
INFO - 2024-02-12 08:08:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:08:00 --> Pagination Class Initialized
INFO - 2024-02-12 08:08:00 --> Form Validation Class Initialized
INFO - 2024-02-12 08:08:00 --> Controller Class Initialized
INFO - 2024-02-12 08:08:00 --> Model Class Initialized
DEBUG - 2024-02-12 08:08:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:08:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:08:00 --> Model Class Initialized
DEBUG - 2024-02-12 08:08:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:08:00 --> Model Class Initialized
INFO - 2024-02-12 08:08:00 --> Final output sent to browser
DEBUG - 2024-02-12 08:08:00 --> Total execution time: 0.0924
ERROR - 2024-02-12 08:08:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:08:00 --> Config Class Initialized
INFO - 2024-02-12 08:08:00 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:08:00 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:08:00 --> Utf8 Class Initialized
INFO - 2024-02-12 08:08:00 --> URI Class Initialized
INFO - 2024-02-12 08:08:00 --> Router Class Initialized
INFO - 2024-02-12 08:08:00 --> Output Class Initialized
INFO - 2024-02-12 08:08:00 --> Security Class Initialized
DEBUG - 2024-02-12 08:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:08:00 --> Input Class Initialized
INFO - 2024-02-12 08:08:00 --> Language Class Initialized
INFO - 2024-02-12 08:08:00 --> Loader Class Initialized
INFO - 2024-02-12 08:08:00 --> Helper loaded: url_helper
INFO - 2024-02-12 08:08:00 --> Helper loaded: file_helper
INFO - 2024-02-12 08:08:00 --> Helper loaded: html_helper
INFO - 2024-02-12 08:08:00 --> Helper loaded: text_helper
INFO - 2024-02-12 08:08:00 --> Helper loaded: form_helper
INFO - 2024-02-12 08:08:00 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:08:00 --> Helper loaded: security_helper
INFO - 2024-02-12 08:08:00 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:08:00 --> Database Driver Class Initialized
INFO - 2024-02-12 08:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:08:00 --> Parser Class Initialized
INFO - 2024-02-12 08:08:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:08:00 --> Pagination Class Initialized
INFO - 2024-02-12 08:08:00 --> Form Validation Class Initialized
INFO - 2024-02-12 08:08:00 --> Controller Class Initialized
INFO - 2024-02-12 08:08:00 --> Model Class Initialized
DEBUG - 2024-02-12 08:08:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:08:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:08:00 --> Model Class Initialized
DEBUG - 2024-02-12 08:08:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:08:00 --> Model Class Initialized
INFO - 2024-02-12 08:08:01 --> Final output sent to browser
DEBUG - 2024-02-12 08:08:01 --> Total execution time: 0.0940
ERROR - 2024-02-12 08:08:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:08:06 --> Config Class Initialized
INFO - 2024-02-12 08:08:06 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:08:06 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:08:06 --> Utf8 Class Initialized
INFO - 2024-02-12 08:08:06 --> URI Class Initialized
INFO - 2024-02-12 08:08:06 --> Router Class Initialized
INFO - 2024-02-12 08:08:06 --> Output Class Initialized
INFO - 2024-02-12 08:08:06 --> Security Class Initialized
DEBUG - 2024-02-12 08:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:08:06 --> Input Class Initialized
INFO - 2024-02-12 08:08:06 --> Language Class Initialized
INFO - 2024-02-12 08:08:06 --> Loader Class Initialized
INFO - 2024-02-12 08:08:06 --> Helper loaded: url_helper
INFO - 2024-02-12 08:08:06 --> Helper loaded: file_helper
INFO - 2024-02-12 08:08:06 --> Helper loaded: html_helper
INFO - 2024-02-12 08:08:06 --> Helper loaded: text_helper
INFO - 2024-02-12 08:08:06 --> Helper loaded: form_helper
INFO - 2024-02-12 08:08:06 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:08:06 --> Helper loaded: security_helper
INFO - 2024-02-12 08:08:06 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:08:06 --> Database Driver Class Initialized
INFO - 2024-02-12 08:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:08:06 --> Parser Class Initialized
INFO - 2024-02-12 08:08:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:08:06 --> Pagination Class Initialized
INFO - 2024-02-12 08:08:06 --> Form Validation Class Initialized
INFO - 2024-02-12 08:08:06 --> Controller Class Initialized
INFO - 2024-02-12 08:08:06 --> Model Class Initialized
DEBUG - 2024-02-12 08:08:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:08:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:08:06 --> Model Class Initialized
DEBUG - 2024-02-12 08:08:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:08:06 --> Model Class Initialized
INFO - 2024-02-12 08:08:06 --> Final output sent to browser
DEBUG - 2024-02-12 08:08:06 --> Total execution time: 0.0246
ERROR - 2024-02-12 08:08:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:08:09 --> Config Class Initialized
INFO - 2024-02-12 08:08:09 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:08:09 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:08:09 --> Utf8 Class Initialized
INFO - 2024-02-12 08:08:09 --> URI Class Initialized
INFO - 2024-02-12 08:08:09 --> Router Class Initialized
INFO - 2024-02-12 08:08:09 --> Output Class Initialized
INFO - 2024-02-12 08:08:09 --> Security Class Initialized
DEBUG - 2024-02-12 08:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:08:09 --> Input Class Initialized
INFO - 2024-02-12 08:08:09 --> Language Class Initialized
INFO - 2024-02-12 08:08:09 --> Loader Class Initialized
INFO - 2024-02-12 08:08:09 --> Helper loaded: url_helper
INFO - 2024-02-12 08:08:09 --> Helper loaded: file_helper
INFO - 2024-02-12 08:08:09 --> Helper loaded: html_helper
INFO - 2024-02-12 08:08:09 --> Helper loaded: text_helper
INFO - 2024-02-12 08:08:09 --> Helper loaded: form_helper
INFO - 2024-02-12 08:08:09 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:08:09 --> Helper loaded: security_helper
INFO - 2024-02-12 08:08:09 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:08:09 --> Database Driver Class Initialized
INFO - 2024-02-12 08:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:08:09 --> Parser Class Initialized
INFO - 2024-02-12 08:08:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:08:09 --> Pagination Class Initialized
INFO - 2024-02-12 08:08:09 --> Form Validation Class Initialized
INFO - 2024-02-12 08:08:09 --> Controller Class Initialized
INFO - 2024-02-12 08:08:09 --> Model Class Initialized
DEBUG - 2024-02-12 08:08:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:08:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:08:09 --> Model Class Initialized
INFO - 2024-02-12 08:08:09 --> Model Class Initialized
INFO - 2024-02-12 08:08:09 --> Final output sent to browser
DEBUG - 2024-02-12 08:08:09 --> Total execution time: 0.0221
ERROR - 2024-02-12 08:08:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:08:10 --> Config Class Initialized
INFO - 2024-02-12 08:08:10 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:08:10 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:08:10 --> Utf8 Class Initialized
INFO - 2024-02-12 08:08:10 --> URI Class Initialized
INFO - 2024-02-12 08:08:10 --> Router Class Initialized
INFO - 2024-02-12 08:08:10 --> Output Class Initialized
INFO - 2024-02-12 08:08:10 --> Security Class Initialized
DEBUG - 2024-02-12 08:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:08:10 --> Input Class Initialized
INFO - 2024-02-12 08:08:10 --> Language Class Initialized
INFO - 2024-02-12 08:08:10 --> Loader Class Initialized
INFO - 2024-02-12 08:08:10 --> Helper loaded: url_helper
INFO - 2024-02-12 08:08:10 --> Helper loaded: file_helper
INFO - 2024-02-12 08:08:10 --> Helper loaded: html_helper
INFO - 2024-02-12 08:08:10 --> Helper loaded: text_helper
INFO - 2024-02-12 08:08:10 --> Helper loaded: form_helper
INFO - 2024-02-12 08:08:10 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:08:10 --> Helper loaded: security_helper
INFO - 2024-02-12 08:08:10 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:08:10 --> Database Driver Class Initialized
INFO - 2024-02-12 08:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:08:10 --> Parser Class Initialized
INFO - 2024-02-12 08:08:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:08:10 --> Pagination Class Initialized
INFO - 2024-02-12 08:08:10 --> Form Validation Class Initialized
INFO - 2024-02-12 08:08:10 --> Controller Class Initialized
INFO - 2024-02-12 08:08:10 --> Model Class Initialized
DEBUG - 2024-02-12 08:08:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:08:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:08:10 --> Model Class Initialized
INFO - 2024-02-12 08:08:10 --> Final output sent to browser
DEBUG - 2024-02-12 08:08:10 --> Total execution time: 0.0154
ERROR - 2024-02-12 08:08:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:08:12 --> Config Class Initialized
INFO - 2024-02-12 08:08:12 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:08:12 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:08:12 --> Utf8 Class Initialized
INFO - 2024-02-12 08:08:12 --> URI Class Initialized
INFO - 2024-02-12 08:08:12 --> Router Class Initialized
INFO - 2024-02-12 08:08:12 --> Output Class Initialized
INFO - 2024-02-12 08:08:12 --> Security Class Initialized
DEBUG - 2024-02-12 08:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:08:12 --> Input Class Initialized
INFO - 2024-02-12 08:08:12 --> Language Class Initialized
INFO - 2024-02-12 08:08:12 --> Loader Class Initialized
INFO - 2024-02-12 08:08:12 --> Helper loaded: url_helper
INFO - 2024-02-12 08:08:12 --> Helper loaded: file_helper
INFO - 2024-02-12 08:08:12 --> Helper loaded: html_helper
INFO - 2024-02-12 08:08:12 --> Helper loaded: text_helper
INFO - 2024-02-12 08:08:12 --> Helper loaded: form_helper
INFO - 2024-02-12 08:08:12 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:08:12 --> Helper loaded: security_helper
INFO - 2024-02-12 08:08:12 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:08:12 --> Database Driver Class Initialized
INFO - 2024-02-12 08:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:08:12 --> Parser Class Initialized
INFO - 2024-02-12 08:08:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:08:12 --> Pagination Class Initialized
INFO - 2024-02-12 08:08:12 --> Form Validation Class Initialized
INFO - 2024-02-12 08:08:12 --> Controller Class Initialized
INFO - 2024-02-12 08:08:12 --> Model Class Initialized
DEBUG - 2024-02-12 08:08:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:08:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:08:12 --> Model Class Initialized
INFO - 2024-02-12 08:08:12 --> Final output sent to browser
DEBUG - 2024-02-12 08:08:12 --> Total execution time: 0.0164
ERROR - 2024-02-12 08:08:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:08:34 --> Config Class Initialized
INFO - 2024-02-12 08:08:34 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:08:34 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:08:34 --> Utf8 Class Initialized
INFO - 2024-02-12 08:08:34 --> URI Class Initialized
INFO - 2024-02-12 08:08:34 --> Router Class Initialized
INFO - 2024-02-12 08:08:34 --> Output Class Initialized
INFO - 2024-02-12 08:08:34 --> Security Class Initialized
DEBUG - 2024-02-12 08:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:08:34 --> Input Class Initialized
INFO - 2024-02-12 08:08:34 --> Language Class Initialized
INFO - 2024-02-12 08:08:34 --> Loader Class Initialized
INFO - 2024-02-12 08:08:34 --> Helper loaded: url_helper
INFO - 2024-02-12 08:08:34 --> Helper loaded: file_helper
INFO - 2024-02-12 08:08:34 --> Helper loaded: html_helper
INFO - 2024-02-12 08:08:34 --> Helper loaded: text_helper
INFO - 2024-02-12 08:08:34 --> Helper loaded: form_helper
INFO - 2024-02-12 08:08:34 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:08:34 --> Helper loaded: security_helper
INFO - 2024-02-12 08:08:34 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:08:34 --> Database Driver Class Initialized
INFO - 2024-02-12 08:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:08:34 --> Parser Class Initialized
INFO - 2024-02-12 08:08:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:08:34 --> Pagination Class Initialized
INFO - 2024-02-12 08:08:34 --> Form Validation Class Initialized
INFO - 2024-02-12 08:08:34 --> Controller Class Initialized
INFO - 2024-02-12 08:08:34 --> Model Class Initialized
DEBUG - 2024-02-12 08:08:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:08:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:08:34 --> Model Class Initialized
DEBUG - 2024-02-12 08:08:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:08:34 --> Model Class Initialized
INFO - 2024-02-12 08:08:34 --> Final output sent to browser
DEBUG - 2024-02-12 08:08:34 --> Total execution time: 0.0941
ERROR - 2024-02-12 08:08:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:08:37 --> Config Class Initialized
INFO - 2024-02-12 08:08:37 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:08:37 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:08:37 --> Utf8 Class Initialized
INFO - 2024-02-12 08:08:37 --> URI Class Initialized
INFO - 2024-02-12 08:08:37 --> Router Class Initialized
INFO - 2024-02-12 08:08:37 --> Output Class Initialized
INFO - 2024-02-12 08:08:37 --> Security Class Initialized
DEBUG - 2024-02-12 08:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:08:37 --> Input Class Initialized
INFO - 2024-02-12 08:08:37 --> Language Class Initialized
INFO - 2024-02-12 08:08:37 --> Loader Class Initialized
INFO - 2024-02-12 08:08:37 --> Helper loaded: url_helper
INFO - 2024-02-12 08:08:37 --> Helper loaded: file_helper
INFO - 2024-02-12 08:08:37 --> Helper loaded: html_helper
INFO - 2024-02-12 08:08:37 --> Helper loaded: text_helper
INFO - 2024-02-12 08:08:37 --> Helper loaded: form_helper
INFO - 2024-02-12 08:08:37 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:08:37 --> Helper loaded: security_helper
INFO - 2024-02-12 08:08:37 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:08:37 --> Database Driver Class Initialized
INFO - 2024-02-12 08:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:08:37 --> Parser Class Initialized
INFO - 2024-02-12 08:08:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:08:37 --> Pagination Class Initialized
INFO - 2024-02-12 08:08:37 --> Form Validation Class Initialized
INFO - 2024-02-12 08:08:37 --> Controller Class Initialized
INFO - 2024-02-12 08:08:37 --> Model Class Initialized
DEBUG - 2024-02-12 08:08:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:08:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:08:37 --> Model Class Initialized
DEBUG - 2024-02-12 08:08:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:08:37 --> Model Class Initialized
INFO - 2024-02-12 08:08:37 --> Final output sent to browser
DEBUG - 2024-02-12 08:08:37 --> Total execution time: 0.0903
ERROR - 2024-02-12 08:08:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:08:38 --> Config Class Initialized
INFO - 2024-02-12 08:08:38 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:08:38 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:08:38 --> Utf8 Class Initialized
INFO - 2024-02-12 08:08:38 --> URI Class Initialized
INFO - 2024-02-12 08:08:38 --> Router Class Initialized
INFO - 2024-02-12 08:08:38 --> Output Class Initialized
INFO - 2024-02-12 08:08:38 --> Security Class Initialized
DEBUG - 2024-02-12 08:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:08:38 --> Input Class Initialized
INFO - 2024-02-12 08:08:38 --> Language Class Initialized
INFO - 2024-02-12 08:08:38 --> Loader Class Initialized
INFO - 2024-02-12 08:08:38 --> Helper loaded: url_helper
INFO - 2024-02-12 08:08:38 --> Helper loaded: file_helper
INFO - 2024-02-12 08:08:38 --> Helper loaded: html_helper
INFO - 2024-02-12 08:08:38 --> Helper loaded: text_helper
INFO - 2024-02-12 08:08:38 --> Helper loaded: form_helper
INFO - 2024-02-12 08:08:38 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:08:38 --> Helper loaded: security_helper
INFO - 2024-02-12 08:08:38 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:08:38 --> Database Driver Class Initialized
INFO - 2024-02-12 08:08:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:08:38 --> Parser Class Initialized
INFO - 2024-02-12 08:08:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:08:38 --> Pagination Class Initialized
INFO - 2024-02-12 08:08:38 --> Form Validation Class Initialized
INFO - 2024-02-12 08:08:38 --> Controller Class Initialized
INFO - 2024-02-12 08:08:38 --> Model Class Initialized
DEBUG - 2024-02-12 08:08:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:08:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:08:38 --> Model Class Initialized
DEBUG - 2024-02-12 08:08:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:08:38 --> Model Class Initialized
INFO - 2024-02-12 08:08:38 --> Final output sent to browser
DEBUG - 2024-02-12 08:08:38 --> Total execution time: 0.0916
ERROR - 2024-02-12 08:08:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:08:43 --> Config Class Initialized
INFO - 2024-02-12 08:08:43 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:08:43 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:08:43 --> Utf8 Class Initialized
INFO - 2024-02-12 08:08:43 --> URI Class Initialized
INFO - 2024-02-12 08:08:43 --> Router Class Initialized
INFO - 2024-02-12 08:08:43 --> Output Class Initialized
INFO - 2024-02-12 08:08:43 --> Security Class Initialized
DEBUG - 2024-02-12 08:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:08:43 --> Input Class Initialized
INFO - 2024-02-12 08:08:43 --> Language Class Initialized
INFO - 2024-02-12 08:08:43 --> Loader Class Initialized
INFO - 2024-02-12 08:08:43 --> Helper loaded: url_helper
INFO - 2024-02-12 08:08:43 --> Helper loaded: file_helper
INFO - 2024-02-12 08:08:43 --> Helper loaded: html_helper
INFO - 2024-02-12 08:08:43 --> Helper loaded: text_helper
INFO - 2024-02-12 08:08:43 --> Helper loaded: form_helper
INFO - 2024-02-12 08:08:43 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:08:43 --> Helper loaded: security_helper
INFO - 2024-02-12 08:08:43 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:08:43 --> Database Driver Class Initialized
INFO - 2024-02-12 08:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:08:43 --> Parser Class Initialized
INFO - 2024-02-12 08:08:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:08:43 --> Pagination Class Initialized
INFO - 2024-02-12 08:08:43 --> Form Validation Class Initialized
INFO - 2024-02-12 08:08:43 --> Controller Class Initialized
INFO - 2024-02-12 08:08:43 --> Model Class Initialized
DEBUG - 2024-02-12 08:08:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:08:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:08:43 --> Model Class Initialized
INFO - 2024-02-12 08:08:43 --> Model Class Initialized
INFO - 2024-02-12 08:08:43 --> Final output sent to browser
DEBUG - 2024-02-12 08:08:43 --> Total execution time: 0.0187
ERROR - 2024-02-12 08:08:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:08:47 --> Config Class Initialized
INFO - 2024-02-12 08:08:47 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:08:47 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:08:47 --> Utf8 Class Initialized
INFO - 2024-02-12 08:08:47 --> URI Class Initialized
INFO - 2024-02-12 08:08:47 --> Router Class Initialized
INFO - 2024-02-12 08:08:47 --> Output Class Initialized
INFO - 2024-02-12 08:08:47 --> Security Class Initialized
DEBUG - 2024-02-12 08:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:08:47 --> Input Class Initialized
INFO - 2024-02-12 08:08:47 --> Language Class Initialized
INFO - 2024-02-12 08:08:47 --> Loader Class Initialized
INFO - 2024-02-12 08:08:47 --> Helper loaded: url_helper
INFO - 2024-02-12 08:08:47 --> Helper loaded: file_helper
INFO - 2024-02-12 08:08:47 --> Helper loaded: html_helper
INFO - 2024-02-12 08:08:47 --> Helper loaded: text_helper
INFO - 2024-02-12 08:08:47 --> Helper loaded: form_helper
INFO - 2024-02-12 08:08:47 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:08:47 --> Helper loaded: security_helper
INFO - 2024-02-12 08:08:47 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:08:47 --> Database Driver Class Initialized
INFO - 2024-02-12 08:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:08:47 --> Parser Class Initialized
INFO - 2024-02-12 08:08:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:08:47 --> Pagination Class Initialized
INFO - 2024-02-12 08:08:47 --> Form Validation Class Initialized
INFO - 2024-02-12 08:08:47 --> Controller Class Initialized
INFO - 2024-02-12 08:08:47 --> Model Class Initialized
DEBUG - 2024-02-12 08:08:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:08:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:08:47 --> Model Class Initialized
INFO - 2024-02-12 08:08:47 --> Final output sent to browser
DEBUG - 2024-02-12 08:08:47 --> Total execution time: 0.0166
ERROR - 2024-02-12 08:09:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:09:01 --> Config Class Initialized
INFO - 2024-02-12 08:09:01 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:09:01 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:09:01 --> Utf8 Class Initialized
INFO - 2024-02-12 08:09:01 --> URI Class Initialized
INFO - 2024-02-12 08:09:01 --> Router Class Initialized
INFO - 2024-02-12 08:09:01 --> Output Class Initialized
INFO - 2024-02-12 08:09:01 --> Security Class Initialized
DEBUG - 2024-02-12 08:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:09:01 --> Input Class Initialized
INFO - 2024-02-12 08:09:01 --> Language Class Initialized
INFO - 2024-02-12 08:09:01 --> Loader Class Initialized
INFO - 2024-02-12 08:09:01 --> Helper loaded: url_helper
INFO - 2024-02-12 08:09:01 --> Helper loaded: file_helper
INFO - 2024-02-12 08:09:01 --> Helper loaded: html_helper
INFO - 2024-02-12 08:09:01 --> Helper loaded: text_helper
INFO - 2024-02-12 08:09:01 --> Helper loaded: form_helper
INFO - 2024-02-12 08:09:01 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:09:01 --> Helper loaded: security_helper
INFO - 2024-02-12 08:09:01 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:09:01 --> Database Driver Class Initialized
INFO - 2024-02-12 08:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:09:01 --> Parser Class Initialized
INFO - 2024-02-12 08:09:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:09:01 --> Pagination Class Initialized
INFO - 2024-02-12 08:09:01 --> Form Validation Class Initialized
INFO - 2024-02-12 08:09:01 --> Controller Class Initialized
INFO - 2024-02-12 08:09:01 --> Model Class Initialized
DEBUG - 2024-02-12 08:09:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:09:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:09:01 --> Model Class Initialized
DEBUG - 2024-02-12 08:09:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:09:01 --> Model Class Initialized
INFO - 2024-02-12 08:09:01 --> Email Class Initialized
DEBUG - 2024-02-12 08:09:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:09:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:09:02 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-02-12 08:09:02 --> Language file loaded: language/english/email_lang.php
INFO - 2024-02-12 08:09:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2024-02-12 08:09:02 --> Final output sent to browser
DEBUG - 2024-02-12 08:09:02 --> Total execution time: 0.3474
ERROR - 2024-02-12 08:09:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:09:10 --> Config Class Initialized
INFO - 2024-02-12 08:09:10 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:09:10 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:09:10 --> Utf8 Class Initialized
INFO - 2024-02-12 08:09:10 --> URI Class Initialized
INFO - 2024-02-12 08:09:10 --> Router Class Initialized
INFO - 2024-02-12 08:09:10 --> Output Class Initialized
INFO - 2024-02-12 08:09:10 --> Security Class Initialized
DEBUG - 2024-02-12 08:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:09:10 --> Input Class Initialized
INFO - 2024-02-12 08:09:10 --> Language Class Initialized
INFO - 2024-02-12 08:09:10 --> Loader Class Initialized
INFO - 2024-02-12 08:09:10 --> Helper loaded: url_helper
INFO - 2024-02-12 08:09:10 --> Helper loaded: file_helper
INFO - 2024-02-12 08:09:10 --> Helper loaded: html_helper
INFO - 2024-02-12 08:09:10 --> Helper loaded: text_helper
INFO - 2024-02-12 08:09:10 --> Helper loaded: form_helper
INFO - 2024-02-12 08:09:10 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:09:10 --> Helper loaded: security_helper
INFO - 2024-02-12 08:09:10 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:09:10 --> Database Driver Class Initialized
INFO - 2024-02-12 08:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:09:10 --> Parser Class Initialized
INFO - 2024-02-12 08:09:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:09:10 --> Pagination Class Initialized
INFO - 2024-02-12 08:09:10 --> Form Validation Class Initialized
INFO - 2024-02-12 08:09:10 --> Controller Class Initialized
INFO - 2024-02-12 08:09:10 --> Model Class Initialized
DEBUG - 2024-02-12 08:09:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:09:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:09:10 --> Model Class Initialized
DEBUG - 2024-02-12 08:09:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:09:10 --> Model Class Initialized
INFO - 2024-02-12 08:09:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-02-12 08:09:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:09:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 08:09:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 08:09:10 --> Model Class Initialized
INFO - 2024-02-12 08:09:10 --> Model Class Initialized
INFO - 2024-02-12 08:09:10 --> Model Class Initialized
INFO - 2024-02-12 08:09:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 08:09:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 08:09:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 08:09:10 --> Final output sent to browser
DEBUG - 2024-02-12 08:09:10 --> Total execution time: 0.1710
ERROR - 2024-02-12 08:09:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:09:18 --> Config Class Initialized
INFO - 2024-02-12 08:09:18 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:09:18 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:09:18 --> Utf8 Class Initialized
INFO - 2024-02-12 08:09:18 --> URI Class Initialized
INFO - 2024-02-12 08:09:18 --> Router Class Initialized
INFO - 2024-02-12 08:09:18 --> Output Class Initialized
INFO - 2024-02-12 08:09:18 --> Security Class Initialized
DEBUG - 2024-02-12 08:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:09:18 --> Input Class Initialized
INFO - 2024-02-12 08:09:18 --> Language Class Initialized
INFO - 2024-02-12 08:09:18 --> Loader Class Initialized
INFO - 2024-02-12 08:09:18 --> Helper loaded: url_helper
INFO - 2024-02-12 08:09:18 --> Helper loaded: file_helper
INFO - 2024-02-12 08:09:18 --> Helper loaded: html_helper
INFO - 2024-02-12 08:09:18 --> Helper loaded: text_helper
INFO - 2024-02-12 08:09:18 --> Helper loaded: form_helper
INFO - 2024-02-12 08:09:18 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:09:18 --> Helper loaded: security_helper
INFO - 2024-02-12 08:09:18 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:09:18 --> Database Driver Class Initialized
INFO - 2024-02-12 08:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:09:18 --> Parser Class Initialized
INFO - 2024-02-12 08:09:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:09:18 --> Pagination Class Initialized
INFO - 2024-02-12 08:09:18 --> Form Validation Class Initialized
INFO - 2024-02-12 08:09:18 --> Controller Class Initialized
INFO - 2024-02-12 08:09:18 --> Model Class Initialized
DEBUG - 2024-02-12 08:09:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:09:18 --> Final output sent to browser
DEBUG - 2024-02-12 08:09:18 --> Total execution time: 0.0153
ERROR - 2024-02-12 08:09:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:09:36 --> Config Class Initialized
INFO - 2024-02-12 08:09:36 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:09:36 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:09:36 --> Utf8 Class Initialized
INFO - 2024-02-12 08:09:36 --> URI Class Initialized
DEBUG - 2024-02-12 08:09:36 --> No URI present. Default controller set.
INFO - 2024-02-12 08:09:36 --> Router Class Initialized
INFO - 2024-02-12 08:09:36 --> Output Class Initialized
INFO - 2024-02-12 08:09:36 --> Security Class Initialized
DEBUG - 2024-02-12 08:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:09:36 --> Input Class Initialized
INFO - 2024-02-12 08:09:36 --> Language Class Initialized
INFO - 2024-02-12 08:09:36 --> Loader Class Initialized
INFO - 2024-02-12 08:09:36 --> Helper loaded: url_helper
INFO - 2024-02-12 08:09:36 --> Helper loaded: file_helper
INFO - 2024-02-12 08:09:36 --> Helper loaded: html_helper
INFO - 2024-02-12 08:09:36 --> Helper loaded: text_helper
INFO - 2024-02-12 08:09:36 --> Helper loaded: form_helper
INFO - 2024-02-12 08:09:36 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:09:36 --> Helper loaded: security_helper
INFO - 2024-02-12 08:09:36 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:09:36 --> Database Driver Class Initialized
INFO - 2024-02-12 08:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:09:36 --> Parser Class Initialized
INFO - 2024-02-12 08:09:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:09:36 --> Pagination Class Initialized
INFO - 2024-02-12 08:09:36 --> Form Validation Class Initialized
INFO - 2024-02-12 08:09:36 --> Controller Class Initialized
INFO - 2024-02-12 08:09:36 --> Model Class Initialized
DEBUG - 2024-02-12 08:09:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:09:36 --> Model Class Initialized
DEBUG - 2024-02-12 08:09:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:09:36 --> Model Class Initialized
INFO - 2024-02-12 08:09:36 --> Model Class Initialized
INFO - 2024-02-12 08:09:36 --> Model Class Initialized
INFO - 2024-02-12 08:09:36 --> Model Class Initialized
DEBUG - 2024-02-12 08:09:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:09:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:09:36 --> Model Class Initialized
INFO - 2024-02-12 08:09:36 --> Model Class Initialized
INFO - 2024-02-12 08:09:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-12 08:09:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:09:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 08:09:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 08:09:37 --> Model Class Initialized
INFO - 2024-02-12 08:09:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 08:09:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 08:09:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 08:09:37 --> Final output sent to browser
DEBUG - 2024-02-12 08:09:37 --> Total execution time: 0.2349
ERROR - 2024-02-12 08:09:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:09:41 --> Config Class Initialized
INFO - 2024-02-12 08:09:41 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:09:41 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:09:41 --> Utf8 Class Initialized
INFO - 2024-02-12 08:09:41 --> URI Class Initialized
INFO - 2024-02-12 08:09:41 --> Router Class Initialized
INFO - 2024-02-12 08:09:41 --> Output Class Initialized
INFO - 2024-02-12 08:09:41 --> Security Class Initialized
DEBUG - 2024-02-12 08:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:09:41 --> Input Class Initialized
INFO - 2024-02-12 08:09:41 --> Language Class Initialized
INFO - 2024-02-12 08:09:41 --> Loader Class Initialized
INFO - 2024-02-12 08:09:41 --> Helper loaded: url_helper
INFO - 2024-02-12 08:09:41 --> Helper loaded: file_helper
INFO - 2024-02-12 08:09:41 --> Helper loaded: html_helper
INFO - 2024-02-12 08:09:41 --> Helper loaded: text_helper
INFO - 2024-02-12 08:09:41 --> Helper loaded: form_helper
INFO - 2024-02-12 08:09:41 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:09:41 --> Helper loaded: security_helper
INFO - 2024-02-12 08:09:41 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:09:41 --> Database Driver Class Initialized
INFO - 2024-02-12 08:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:09:41 --> Parser Class Initialized
INFO - 2024-02-12 08:09:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:09:41 --> Pagination Class Initialized
INFO - 2024-02-12 08:09:41 --> Form Validation Class Initialized
INFO - 2024-02-12 08:09:41 --> Controller Class Initialized
DEBUG - 2024-02-12 08:09:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:09:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:09:41 --> Model Class Initialized
DEBUG - 2024-02-12 08:09:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:09:41 --> Model Class Initialized
DEBUG - 2024-02-12 08:09:41 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:09:41 --> Model Class Initialized
INFO - 2024-02-12 08:09:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-12 08:09:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:09:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 08:09:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 08:09:41 --> Model Class Initialized
INFO - 2024-02-12 08:09:41 --> Model Class Initialized
INFO - 2024-02-12 08:09:41 --> Model Class Initialized
INFO - 2024-02-12 08:09:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 08:09:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 08:09:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 08:09:41 --> Final output sent to browser
DEBUG - 2024-02-12 08:09:41 --> Total execution time: 0.1426
ERROR - 2024-02-12 08:09:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:09:42 --> Config Class Initialized
INFO - 2024-02-12 08:09:42 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:09:42 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:09:42 --> Utf8 Class Initialized
INFO - 2024-02-12 08:09:42 --> URI Class Initialized
INFO - 2024-02-12 08:09:42 --> Router Class Initialized
INFO - 2024-02-12 08:09:42 --> Output Class Initialized
INFO - 2024-02-12 08:09:42 --> Security Class Initialized
DEBUG - 2024-02-12 08:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:09:42 --> Input Class Initialized
INFO - 2024-02-12 08:09:42 --> Language Class Initialized
INFO - 2024-02-12 08:09:42 --> Loader Class Initialized
INFO - 2024-02-12 08:09:42 --> Helper loaded: url_helper
INFO - 2024-02-12 08:09:42 --> Helper loaded: file_helper
INFO - 2024-02-12 08:09:42 --> Helper loaded: html_helper
INFO - 2024-02-12 08:09:42 --> Helper loaded: text_helper
INFO - 2024-02-12 08:09:42 --> Helper loaded: form_helper
INFO - 2024-02-12 08:09:42 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:09:42 --> Helper loaded: security_helper
INFO - 2024-02-12 08:09:42 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:09:42 --> Database Driver Class Initialized
INFO - 2024-02-12 08:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:09:42 --> Parser Class Initialized
INFO - 2024-02-12 08:09:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:09:42 --> Pagination Class Initialized
INFO - 2024-02-12 08:09:42 --> Form Validation Class Initialized
INFO - 2024-02-12 08:09:42 --> Controller Class Initialized
DEBUG - 2024-02-12 08:09:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:09:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:09:42 --> Model Class Initialized
DEBUG - 2024-02-12 08:09:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:09:42 --> Model Class Initialized
INFO - 2024-02-12 08:09:42 --> Final output sent to browser
DEBUG - 2024-02-12 08:09:42 --> Total execution time: 0.0220
ERROR - 2024-02-12 08:09:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:09:48 --> Config Class Initialized
INFO - 2024-02-12 08:09:48 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:09:48 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:09:48 --> Utf8 Class Initialized
INFO - 2024-02-12 08:09:48 --> URI Class Initialized
INFO - 2024-02-12 08:09:48 --> Router Class Initialized
INFO - 2024-02-12 08:09:48 --> Output Class Initialized
INFO - 2024-02-12 08:09:48 --> Security Class Initialized
DEBUG - 2024-02-12 08:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:09:48 --> Input Class Initialized
INFO - 2024-02-12 08:09:48 --> Language Class Initialized
INFO - 2024-02-12 08:09:48 --> Loader Class Initialized
INFO - 2024-02-12 08:09:48 --> Helper loaded: url_helper
INFO - 2024-02-12 08:09:48 --> Helper loaded: file_helper
INFO - 2024-02-12 08:09:48 --> Helper loaded: html_helper
INFO - 2024-02-12 08:09:48 --> Helper loaded: text_helper
INFO - 2024-02-12 08:09:48 --> Helper loaded: form_helper
INFO - 2024-02-12 08:09:48 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:09:48 --> Helper loaded: security_helper
INFO - 2024-02-12 08:09:48 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:09:48 --> Database Driver Class Initialized
INFO - 2024-02-12 08:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:09:48 --> Parser Class Initialized
INFO - 2024-02-12 08:09:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:09:48 --> Pagination Class Initialized
INFO - 2024-02-12 08:09:48 --> Form Validation Class Initialized
INFO - 2024-02-12 08:09:48 --> Controller Class Initialized
DEBUG - 2024-02-12 08:09:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:09:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:09:48 --> Model Class Initialized
DEBUG - 2024-02-12 08:09:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:09:48 --> Model Class Initialized
INFO - 2024-02-12 08:09:48 --> Final output sent to browser
DEBUG - 2024-02-12 08:09:48 --> Total execution time: 0.0280
ERROR - 2024-02-12 08:10:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:10:07 --> Config Class Initialized
INFO - 2024-02-12 08:10:07 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:10:07 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:10:07 --> Utf8 Class Initialized
INFO - 2024-02-12 08:10:07 --> URI Class Initialized
DEBUG - 2024-02-12 08:10:07 --> No URI present. Default controller set.
INFO - 2024-02-12 08:10:07 --> Router Class Initialized
INFO - 2024-02-12 08:10:07 --> Output Class Initialized
INFO - 2024-02-12 08:10:07 --> Security Class Initialized
DEBUG - 2024-02-12 08:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:10:07 --> Input Class Initialized
INFO - 2024-02-12 08:10:07 --> Language Class Initialized
INFO - 2024-02-12 08:10:07 --> Loader Class Initialized
INFO - 2024-02-12 08:10:07 --> Helper loaded: url_helper
INFO - 2024-02-12 08:10:07 --> Helper loaded: file_helper
INFO - 2024-02-12 08:10:07 --> Helper loaded: html_helper
INFO - 2024-02-12 08:10:07 --> Helper loaded: text_helper
INFO - 2024-02-12 08:10:07 --> Helper loaded: form_helper
INFO - 2024-02-12 08:10:07 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:10:07 --> Helper loaded: security_helper
INFO - 2024-02-12 08:10:07 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:10:07 --> Database Driver Class Initialized
INFO - 2024-02-12 08:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:10:07 --> Parser Class Initialized
INFO - 2024-02-12 08:10:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:10:07 --> Pagination Class Initialized
INFO - 2024-02-12 08:10:07 --> Form Validation Class Initialized
INFO - 2024-02-12 08:10:07 --> Controller Class Initialized
INFO - 2024-02-12 08:10:07 --> Model Class Initialized
DEBUG - 2024-02-12 08:10:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:10:07 --> Model Class Initialized
DEBUG - 2024-02-12 08:10:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:10:07 --> Model Class Initialized
INFO - 2024-02-12 08:10:07 --> Model Class Initialized
INFO - 2024-02-12 08:10:07 --> Model Class Initialized
INFO - 2024-02-12 08:10:07 --> Model Class Initialized
DEBUG - 2024-02-12 08:10:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:10:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:10:07 --> Model Class Initialized
INFO - 2024-02-12 08:10:07 --> Model Class Initialized
INFO - 2024-02-12 08:10:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-12 08:10:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:10:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 08:10:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 08:10:07 --> Model Class Initialized
INFO - 2024-02-12 08:10:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 08:10:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 08:10:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 08:10:07 --> Final output sent to browser
DEBUG - 2024-02-12 08:10:07 --> Total execution time: 0.2343
ERROR - 2024-02-12 08:10:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:10:14 --> Config Class Initialized
INFO - 2024-02-12 08:10:14 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:10:14 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:10:14 --> Utf8 Class Initialized
INFO - 2024-02-12 08:10:14 --> URI Class Initialized
INFO - 2024-02-12 08:10:14 --> Router Class Initialized
INFO - 2024-02-12 08:10:14 --> Output Class Initialized
INFO - 2024-02-12 08:10:14 --> Security Class Initialized
DEBUG - 2024-02-12 08:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:10:14 --> Input Class Initialized
INFO - 2024-02-12 08:10:14 --> Language Class Initialized
INFO - 2024-02-12 08:10:14 --> Loader Class Initialized
INFO - 2024-02-12 08:10:14 --> Helper loaded: url_helper
INFO - 2024-02-12 08:10:14 --> Helper loaded: file_helper
INFO - 2024-02-12 08:10:14 --> Helper loaded: html_helper
INFO - 2024-02-12 08:10:14 --> Helper loaded: text_helper
INFO - 2024-02-12 08:10:14 --> Helper loaded: form_helper
INFO - 2024-02-12 08:10:14 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:10:14 --> Helper loaded: security_helper
INFO - 2024-02-12 08:10:14 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:10:14 --> Database Driver Class Initialized
INFO - 2024-02-12 08:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:10:14 --> Parser Class Initialized
INFO - 2024-02-12 08:10:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:10:14 --> Pagination Class Initialized
INFO - 2024-02-12 08:10:14 --> Form Validation Class Initialized
INFO - 2024-02-12 08:10:14 --> Controller Class Initialized
INFO - 2024-02-12 08:10:14 --> Model Class Initialized
DEBUG - 2024-02-12 08:10:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:10:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:10:14 --> Model Class Initialized
DEBUG - 2024-02-12 08:10:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:10:14 --> Model Class Initialized
INFO - 2024-02-12 08:10:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-02-12 08:10:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:10:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 08:10:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 08:10:14 --> Model Class Initialized
INFO - 2024-02-12 08:10:14 --> Model Class Initialized
INFO - 2024-02-12 08:10:14 --> Model Class Initialized
INFO - 2024-02-12 08:10:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 08:10:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 08:10:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 08:10:14 --> Final output sent to browser
DEBUG - 2024-02-12 08:10:14 --> Total execution time: 0.1665
ERROR - 2024-02-12 08:10:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:10:20 --> Config Class Initialized
INFO - 2024-02-12 08:10:20 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:10:20 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:10:20 --> Utf8 Class Initialized
INFO - 2024-02-12 08:10:20 --> URI Class Initialized
INFO - 2024-02-12 08:10:20 --> Router Class Initialized
INFO - 2024-02-12 08:10:20 --> Output Class Initialized
INFO - 2024-02-12 08:10:20 --> Security Class Initialized
DEBUG - 2024-02-12 08:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:10:20 --> Input Class Initialized
INFO - 2024-02-12 08:10:20 --> Language Class Initialized
INFO - 2024-02-12 08:10:20 --> Loader Class Initialized
INFO - 2024-02-12 08:10:20 --> Helper loaded: url_helper
INFO - 2024-02-12 08:10:20 --> Helper loaded: file_helper
INFO - 2024-02-12 08:10:20 --> Helper loaded: html_helper
INFO - 2024-02-12 08:10:20 --> Helper loaded: text_helper
INFO - 2024-02-12 08:10:20 --> Helper loaded: form_helper
INFO - 2024-02-12 08:10:20 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:10:20 --> Helper loaded: security_helper
INFO - 2024-02-12 08:10:20 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:10:20 --> Database Driver Class Initialized
INFO - 2024-02-12 08:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:10:20 --> Parser Class Initialized
INFO - 2024-02-12 08:10:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:10:20 --> Pagination Class Initialized
INFO - 2024-02-12 08:10:20 --> Form Validation Class Initialized
INFO - 2024-02-12 08:10:20 --> Controller Class Initialized
INFO - 2024-02-12 08:10:20 --> Model Class Initialized
DEBUG - 2024-02-12 08:10:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:10:20 --> Final output sent to browser
DEBUG - 2024-02-12 08:10:20 --> Total execution time: 0.0155
ERROR - 2024-02-12 08:10:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:10:22 --> Config Class Initialized
INFO - 2024-02-12 08:10:22 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:10:22 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:10:22 --> Utf8 Class Initialized
INFO - 2024-02-12 08:10:22 --> URI Class Initialized
INFO - 2024-02-12 08:10:22 --> Router Class Initialized
INFO - 2024-02-12 08:10:22 --> Output Class Initialized
INFO - 2024-02-12 08:10:22 --> Security Class Initialized
DEBUG - 2024-02-12 08:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:10:22 --> Input Class Initialized
INFO - 2024-02-12 08:10:22 --> Language Class Initialized
INFO - 2024-02-12 08:10:22 --> Loader Class Initialized
INFO - 2024-02-12 08:10:22 --> Helper loaded: url_helper
INFO - 2024-02-12 08:10:22 --> Helper loaded: file_helper
INFO - 2024-02-12 08:10:22 --> Helper loaded: html_helper
INFO - 2024-02-12 08:10:22 --> Helper loaded: text_helper
INFO - 2024-02-12 08:10:22 --> Helper loaded: form_helper
INFO - 2024-02-12 08:10:22 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:10:22 --> Helper loaded: security_helper
INFO - 2024-02-12 08:10:22 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:10:22 --> Database Driver Class Initialized
INFO - 2024-02-12 08:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:10:22 --> Parser Class Initialized
INFO - 2024-02-12 08:10:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:10:22 --> Pagination Class Initialized
INFO - 2024-02-12 08:10:22 --> Form Validation Class Initialized
INFO - 2024-02-12 08:10:22 --> Controller Class Initialized
INFO - 2024-02-12 08:10:22 --> Model Class Initialized
DEBUG - 2024-02-12 08:10:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:10:22 --> Final output sent to browser
DEBUG - 2024-02-12 08:10:22 --> Total execution time: 0.0156
ERROR - 2024-02-12 08:10:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:10:22 --> Config Class Initialized
INFO - 2024-02-12 08:10:22 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:10:22 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:10:22 --> Utf8 Class Initialized
INFO - 2024-02-12 08:10:22 --> URI Class Initialized
INFO - 2024-02-12 08:10:22 --> Router Class Initialized
INFO - 2024-02-12 08:10:22 --> Output Class Initialized
INFO - 2024-02-12 08:10:22 --> Security Class Initialized
DEBUG - 2024-02-12 08:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:10:22 --> Input Class Initialized
INFO - 2024-02-12 08:10:22 --> Language Class Initialized
INFO - 2024-02-12 08:10:22 --> Loader Class Initialized
INFO - 2024-02-12 08:10:22 --> Helper loaded: url_helper
INFO - 2024-02-12 08:10:22 --> Helper loaded: file_helper
INFO - 2024-02-12 08:10:22 --> Helper loaded: html_helper
INFO - 2024-02-12 08:10:22 --> Helper loaded: text_helper
INFO - 2024-02-12 08:10:22 --> Helper loaded: form_helper
INFO - 2024-02-12 08:10:22 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:10:22 --> Helper loaded: security_helper
INFO - 2024-02-12 08:10:22 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:10:22 --> Database Driver Class Initialized
INFO - 2024-02-12 08:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:10:22 --> Parser Class Initialized
INFO - 2024-02-12 08:10:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:10:22 --> Pagination Class Initialized
INFO - 2024-02-12 08:10:22 --> Form Validation Class Initialized
INFO - 2024-02-12 08:10:22 --> Controller Class Initialized
INFO - 2024-02-12 08:10:22 --> Model Class Initialized
DEBUG - 2024-02-12 08:10:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:10:22 --> Final output sent to browser
DEBUG - 2024-02-12 08:10:22 --> Total execution time: 0.0153
ERROR - 2024-02-12 08:10:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:10:25 --> Config Class Initialized
INFO - 2024-02-12 08:10:25 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:10:25 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:10:25 --> Utf8 Class Initialized
INFO - 2024-02-12 08:10:25 --> URI Class Initialized
INFO - 2024-02-12 08:10:25 --> Router Class Initialized
INFO - 2024-02-12 08:10:25 --> Output Class Initialized
INFO - 2024-02-12 08:10:25 --> Security Class Initialized
DEBUG - 2024-02-12 08:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:10:25 --> Input Class Initialized
INFO - 2024-02-12 08:10:25 --> Language Class Initialized
INFO - 2024-02-12 08:10:25 --> Loader Class Initialized
INFO - 2024-02-12 08:10:25 --> Helper loaded: url_helper
INFO - 2024-02-12 08:10:25 --> Helper loaded: file_helper
INFO - 2024-02-12 08:10:25 --> Helper loaded: html_helper
INFO - 2024-02-12 08:10:25 --> Helper loaded: text_helper
INFO - 2024-02-12 08:10:25 --> Helper loaded: form_helper
INFO - 2024-02-12 08:10:25 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:10:25 --> Helper loaded: security_helper
INFO - 2024-02-12 08:10:25 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:10:25 --> Database Driver Class Initialized
INFO - 2024-02-12 08:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:10:25 --> Parser Class Initialized
INFO - 2024-02-12 08:10:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:10:25 --> Pagination Class Initialized
INFO - 2024-02-12 08:10:25 --> Form Validation Class Initialized
INFO - 2024-02-12 08:10:25 --> Controller Class Initialized
INFO - 2024-02-12 08:10:25 --> Final output sent to browser
DEBUG - 2024-02-12 08:10:25 --> Total execution time: 0.0168
ERROR - 2024-02-12 08:10:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:10:30 --> Config Class Initialized
INFO - 2024-02-12 08:10:30 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:10:30 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:10:30 --> Utf8 Class Initialized
INFO - 2024-02-12 08:10:30 --> URI Class Initialized
INFO - 2024-02-12 08:10:30 --> Router Class Initialized
INFO - 2024-02-12 08:10:30 --> Output Class Initialized
INFO - 2024-02-12 08:10:30 --> Security Class Initialized
DEBUG - 2024-02-12 08:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:10:30 --> Input Class Initialized
INFO - 2024-02-12 08:10:30 --> Language Class Initialized
INFO - 2024-02-12 08:10:30 --> Loader Class Initialized
INFO - 2024-02-12 08:10:30 --> Helper loaded: url_helper
INFO - 2024-02-12 08:10:30 --> Helper loaded: file_helper
INFO - 2024-02-12 08:10:30 --> Helper loaded: html_helper
INFO - 2024-02-12 08:10:30 --> Helper loaded: text_helper
INFO - 2024-02-12 08:10:30 --> Helper loaded: form_helper
INFO - 2024-02-12 08:10:30 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:10:30 --> Helper loaded: security_helper
INFO - 2024-02-12 08:10:30 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:10:30 --> Database Driver Class Initialized
INFO - 2024-02-12 08:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:10:30 --> Parser Class Initialized
INFO - 2024-02-12 08:10:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:10:30 --> Pagination Class Initialized
INFO - 2024-02-12 08:10:30 --> Form Validation Class Initialized
INFO - 2024-02-12 08:10:30 --> Controller Class Initialized
INFO - 2024-02-12 08:10:30 --> Model Class Initialized
DEBUG - 2024-02-12 08:10:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:10:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:10:30 --> Model Class Initialized
DEBUG - 2024-02-12 08:10:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:10:30 --> Model Class Initialized
INFO - 2024-02-12 08:10:30 --> Final output sent to browser
DEBUG - 2024-02-12 08:10:30 --> Total execution time: 0.0915
ERROR - 2024-02-12 08:10:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:10:32 --> Config Class Initialized
INFO - 2024-02-12 08:10:32 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:10:32 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:10:32 --> Utf8 Class Initialized
INFO - 2024-02-12 08:10:32 --> URI Class Initialized
INFO - 2024-02-12 08:10:32 --> Router Class Initialized
INFO - 2024-02-12 08:10:32 --> Output Class Initialized
INFO - 2024-02-12 08:10:32 --> Security Class Initialized
DEBUG - 2024-02-12 08:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:10:32 --> Input Class Initialized
INFO - 2024-02-12 08:10:32 --> Language Class Initialized
INFO - 2024-02-12 08:10:32 --> Loader Class Initialized
INFO - 2024-02-12 08:10:32 --> Helper loaded: url_helper
INFO - 2024-02-12 08:10:32 --> Helper loaded: file_helper
INFO - 2024-02-12 08:10:32 --> Helper loaded: html_helper
INFO - 2024-02-12 08:10:32 --> Helper loaded: text_helper
INFO - 2024-02-12 08:10:32 --> Helper loaded: form_helper
INFO - 2024-02-12 08:10:32 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:10:32 --> Helper loaded: security_helper
INFO - 2024-02-12 08:10:32 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:10:32 --> Database Driver Class Initialized
INFO - 2024-02-12 08:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:10:32 --> Parser Class Initialized
INFO - 2024-02-12 08:10:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:10:32 --> Pagination Class Initialized
INFO - 2024-02-12 08:10:32 --> Form Validation Class Initialized
INFO - 2024-02-12 08:10:32 --> Controller Class Initialized
INFO - 2024-02-12 08:10:32 --> Model Class Initialized
DEBUG - 2024-02-12 08:10:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:10:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:10:32 --> Model Class Initialized
DEBUG - 2024-02-12 08:10:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:10:32 --> Model Class Initialized
INFO - 2024-02-12 08:10:32 --> Final output sent to browser
DEBUG - 2024-02-12 08:10:32 --> Total execution time: 0.0917
ERROR - 2024-02-12 08:10:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:10:35 --> Config Class Initialized
INFO - 2024-02-12 08:10:35 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:10:35 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:10:35 --> Utf8 Class Initialized
INFO - 2024-02-12 08:10:35 --> URI Class Initialized
INFO - 2024-02-12 08:10:35 --> Router Class Initialized
INFO - 2024-02-12 08:10:35 --> Output Class Initialized
INFO - 2024-02-12 08:10:35 --> Security Class Initialized
DEBUG - 2024-02-12 08:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:10:35 --> Input Class Initialized
INFO - 2024-02-12 08:10:35 --> Language Class Initialized
INFO - 2024-02-12 08:10:35 --> Loader Class Initialized
INFO - 2024-02-12 08:10:35 --> Helper loaded: url_helper
INFO - 2024-02-12 08:10:35 --> Helper loaded: file_helper
INFO - 2024-02-12 08:10:35 --> Helper loaded: html_helper
INFO - 2024-02-12 08:10:35 --> Helper loaded: text_helper
INFO - 2024-02-12 08:10:35 --> Helper loaded: form_helper
INFO - 2024-02-12 08:10:35 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:10:35 --> Helper loaded: security_helper
INFO - 2024-02-12 08:10:35 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:10:35 --> Database Driver Class Initialized
INFO - 2024-02-12 08:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:10:35 --> Parser Class Initialized
INFO - 2024-02-12 08:10:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:10:35 --> Pagination Class Initialized
INFO - 2024-02-12 08:10:35 --> Form Validation Class Initialized
INFO - 2024-02-12 08:10:35 --> Controller Class Initialized
INFO - 2024-02-12 08:10:35 --> Model Class Initialized
DEBUG - 2024-02-12 08:10:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:10:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:10:35 --> Model Class Initialized
DEBUG - 2024-02-12 08:10:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:10:35 --> Model Class Initialized
INFO - 2024-02-12 08:10:35 --> Final output sent to browser
DEBUG - 2024-02-12 08:10:35 --> Total execution time: 0.0946
ERROR - 2024-02-12 08:10:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:10:36 --> Config Class Initialized
INFO - 2024-02-12 08:10:36 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:10:36 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:10:36 --> Utf8 Class Initialized
INFO - 2024-02-12 08:10:36 --> URI Class Initialized
INFO - 2024-02-12 08:10:36 --> Router Class Initialized
INFO - 2024-02-12 08:10:36 --> Output Class Initialized
INFO - 2024-02-12 08:10:36 --> Security Class Initialized
DEBUG - 2024-02-12 08:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:10:36 --> Input Class Initialized
INFO - 2024-02-12 08:10:36 --> Language Class Initialized
INFO - 2024-02-12 08:10:36 --> Loader Class Initialized
INFO - 2024-02-12 08:10:36 --> Helper loaded: url_helper
INFO - 2024-02-12 08:10:36 --> Helper loaded: file_helper
INFO - 2024-02-12 08:10:36 --> Helper loaded: html_helper
INFO - 2024-02-12 08:10:36 --> Helper loaded: text_helper
INFO - 2024-02-12 08:10:36 --> Helper loaded: form_helper
INFO - 2024-02-12 08:10:36 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:10:36 --> Helper loaded: security_helper
INFO - 2024-02-12 08:10:36 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:10:36 --> Database Driver Class Initialized
INFO - 2024-02-12 08:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:10:36 --> Parser Class Initialized
INFO - 2024-02-12 08:10:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:10:36 --> Pagination Class Initialized
INFO - 2024-02-12 08:10:36 --> Form Validation Class Initialized
INFO - 2024-02-12 08:10:36 --> Controller Class Initialized
INFO - 2024-02-12 08:10:36 --> Model Class Initialized
DEBUG - 2024-02-12 08:10:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:10:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:10:36 --> Model Class Initialized
DEBUG - 2024-02-12 08:10:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:10:36 --> Model Class Initialized
INFO - 2024-02-12 08:10:36 --> Final output sent to browser
DEBUG - 2024-02-12 08:10:36 --> Total execution time: 0.0218
ERROR - 2024-02-12 08:10:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:10:37 --> Config Class Initialized
INFO - 2024-02-12 08:10:37 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:10:37 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:10:37 --> Utf8 Class Initialized
INFO - 2024-02-12 08:10:37 --> URI Class Initialized
INFO - 2024-02-12 08:10:37 --> Router Class Initialized
INFO - 2024-02-12 08:10:37 --> Output Class Initialized
INFO - 2024-02-12 08:10:37 --> Security Class Initialized
DEBUG - 2024-02-12 08:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:10:37 --> Input Class Initialized
INFO - 2024-02-12 08:10:37 --> Language Class Initialized
INFO - 2024-02-12 08:10:37 --> Loader Class Initialized
INFO - 2024-02-12 08:10:37 --> Helper loaded: url_helper
INFO - 2024-02-12 08:10:37 --> Helper loaded: file_helper
INFO - 2024-02-12 08:10:37 --> Helper loaded: html_helper
INFO - 2024-02-12 08:10:37 --> Helper loaded: text_helper
INFO - 2024-02-12 08:10:37 --> Helper loaded: form_helper
INFO - 2024-02-12 08:10:37 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:10:37 --> Helper loaded: security_helper
INFO - 2024-02-12 08:10:37 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:10:37 --> Database Driver Class Initialized
INFO - 2024-02-12 08:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:10:37 --> Parser Class Initialized
INFO - 2024-02-12 08:10:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:10:37 --> Pagination Class Initialized
INFO - 2024-02-12 08:10:37 --> Form Validation Class Initialized
INFO - 2024-02-12 08:10:37 --> Controller Class Initialized
INFO - 2024-02-12 08:10:37 --> Model Class Initialized
DEBUG - 2024-02-12 08:10:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:10:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:10:37 --> Model Class Initialized
DEBUG - 2024-02-12 08:10:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:10:37 --> Model Class Initialized
INFO - 2024-02-12 08:10:37 --> Final output sent to browser
DEBUG - 2024-02-12 08:10:37 --> Total execution time: 0.0246
ERROR - 2024-02-12 08:10:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:10:38 --> Config Class Initialized
INFO - 2024-02-12 08:10:38 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:10:38 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:10:38 --> Utf8 Class Initialized
INFO - 2024-02-12 08:10:38 --> URI Class Initialized
INFO - 2024-02-12 08:10:38 --> Router Class Initialized
INFO - 2024-02-12 08:10:38 --> Output Class Initialized
INFO - 2024-02-12 08:10:38 --> Security Class Initialized
DEBUG - 2024-02-12 08:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:10:38 --> Input Class Initialized
INFO - 2024-02-12 08:10:38 --> Language Class Initialized
INFO - 2024-02-12 08:10:38 --> Loader Class Initialized
INFO - 2024-02-12 08:10:38 --> Helper loaded: url_helper
INFO - 2024-02-12 08:10:38 --> Helper loaded: file_helper
INFO - 2024-02-12 08:10:38 --> Helper loaded: html_helper
INFO - 2024-02-12 08:10:38 --> Helper loaded: text_helper
INFO - 2024-02-12 08:10:38 --> Helper loaded: form_helper
INFO - 2024-02-12 08:10:38 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:10:38 --> Helper loaded: security_helper
INFO - 2024-02-12 08:10:38 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:10:38 --> Database Driver Class Initialized
INFO - 2024-02-12 08:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:10:38 --> Parser Class Initialized
INFO - 2024-02-12 08:10:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:10:38 --> Pagination Class Initialized
INFO - 2024-02-12 08:10:38 --> Form Validation Class Initialized
INFO - 2024-02-12 08:10:38 --> Controller Class Initialized
INFO - 2024-02-12 08:10:38 --> Model Class Initialized
DEBUG - 2024-02-12 08:10:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:10:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:10:38 --> Model Class Initialized
INFO - 2024-02-12 08:10:38 --> Model Class Initialized
INFO - 2024-02-12 08:10:38 --> Final output sent to browser
DEBUG - 2024-02-12 08:10:38 --> Total execution time: 0.0191
ERROR - 2024-02-12 08:10:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:10:40 --> Config Class Initialized
INFO - 2024-02-12 08:10:40 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:10:40 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:10:40 --> Utf8 Class Initialized
INFO - 2024-02-12 08:10:40 --> URI Class Initialized
INFO - 2024-02-12 08:10:40 --> Router Class Initialized
INFO - 2024-02-12 08:10:40 --> Output Class Initialized
INFO - 2024-02-12 08:10:40 --> Security Class Initialized
DEBUG - 2024-02-12 08:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:10:40 --> Input Class Initialized
INFO - 2024-02-12 08:10:40 --> Language Class Initialized
INFO - 2024-02-12 08:10:40 --> Loader Class Initialized
INFO - 2024-02-12 08:10:40 --> Helper loaded: url_helper
INFO - 2024-02-12 08:10:40 --> Helper loaded: file_helper
INFO - 2024-02-12 08:10:40 --> Helper loaded: html_helper
INFO - 2024-02-12 08:10:40 --> Helper loaded: text_helper
INFO - 2024-02-12 08:10:40 --> Helper loaded: form_helper
INFO - 2024-02-12 08:10:40 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:10:40 --> Helper loaded: security_helper
INFO - 2024-02-12 08:10:40 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:10:40 --> Database Driver Class Initialized
INFO - 2024-02-12 08:10:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:10:40 --> Parser Class Initialized
INFO - 2024-02-12 08:10:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:10:40 --> Pagination Class Initialized
INFO - 2024-02-12 08:10:40 --> Form Validation Class Initialized
INFO - 2024-02-12 08:10:40 --> Controller Class Initialized
INFO - 2024-02-12 08:10:40 --> Model Class Initialized
DEBUG - 2024-02-12 08:10:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:10:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:10:40 --> Model Class Initialized
INFO - 2024-02-12 08:10:40 --> Final output sent to browser
DEBUG - 2024-02-12 08:10:40 --> Total execution time: 0.0205
ERROR - 2024-02-12 08:10:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:10:56 --> Config Class Initialized
INFO - 2024-02-12 08:10:56 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:10:56 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:10:56 --> Utf8 Class Initialized
INFO - 2024-02-12 08:10:56 --> URI Class Initialized
INFO - 2024-02-12 08:10:56 --> Router Class Initialized
INFO - 2024-02-12 08:10:56 --> Output Class Initialized
INFO - 2024-02-12 08:10:56 --> Security Class Initialized
DEBUG - 2024-02-12 08:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:10:56 --> Input Class Initialized
INFO - 2024-02-12 08:10:56 --> Language Class Initialized
INFO - 2024-02-12 08:10:56 --> Loader Class Initialized
INFO - 2024-02-12 08:10:56 --> Helper loaded: url_helper
INFO - 2024-02-12 08:10:56 --> Helper loaded: file_helper
INFO - 2024-02-12 08:10:56 --> Helper loaded: html_helper
INFO - 2024-02-12 08:10:56 --> Helper loaded: text_helper
INFO - 2024-02-12 08:10:56 --> Helper loaded: form_helper
INFO - 2024-02-12 08:10:56 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:10:56 --> Helper loaded: security_helper
INFO - 2024-02-12 08:10:56 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:10:56 --> Database Driver Class Initialized
INFO - 2024-02-12 08:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:10:56 --> Parser Class Initialized
INFO - 2024-02-12 08:10:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:10:56 --> Pagination Class Initialized
INFO - 2024-02-12 08:10:56 --> Form Validation Class Initialized
INFO - 2024-02-12 08:10:56 --> Controller Class Initialized
INFO - 2024-02-12 08:10:56 --> Model Class Initialized
DEBUG - 2024-02-12 08:10:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:10:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:10:56 --> Model Class Initialized
DEBUG - 2024-02-12 08:10:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:10:56 --> Model Class Initialized
INFO - 2024-02-12 08:10:56 --> Final output sent to browser
DEBUG - 2024-02-12 08:10:56 --> Total execution time: 0.0944
ERROR - 2024-02-12 08:10:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:10:59 --> Config Class Initialized
INFO - 2024-02-12 08:10:59 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:10:59 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:10:59 --> Utf8 Class Initialized
INFO - 2024-02-12 08:10:59 --> URI Class Initialized
INFO - 2024-02-12 08:10:59 --> Router Class Initialized
INFO - 2024-02-12 08:10:59 --> Output Class Initialized
INFO - 2024-02-12 08:10:59 --> Security Class Initialized
DEBUG - 2024-02-12 08:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:10:59 --> Input Class Initialized
INFO - 2024-02-12 08:10:59 --> Language Class Initialized
INFO - 2024-02-12 08:10:59 --> Loader Class Initialized
INFO - 2024-02-12 08:10:59 --> Helper loaded: url_helper
INFO - 2024-02-12 08:10:59 --> Helper loaded: file_helper
INFO - 2024-02-12 08:10:59 --> Helper loaded: html_helper
INFO - 2024-02-12 08:10:59 --> Helper loaded: text_helper
INFO - 2024-02-12 08:10:59 --> Helper loaded: form_helper
INFO - 2024-02-12 08:10:59 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:10:59 --> Helper loaded: security_helper
INFO - 2024-02-12 08:10:59 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:10:59 --> Database Driver Class Initialized
INFO - 2024-02-12 08:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:10:59 --> Parser Class Initialized
INFO - 2024-02-12 08:10:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:10:59 --> Pagination Class Initialized
INFO - 2024-02-12 08:10:59 --> Form Validation Class Initialized
INFO - 2024-02-12 08:10:59 --> Controller Class Initialized
INFO - 2024-02-12 08:10:59 --> Model Class Initialized
DEBUG - 2024-02-12 08:10:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:10:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:10:59 --> Model Class Initialized
DEBUG - 2024-02-12 08:10:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:10:59 --> Model Class Initialized
INFO - 2024-02-12 08:10:59 --> Final output sent to browser
DEBUG - 2024-02-12 08:10:59 --> Total execution time: 0.0919
ERROR - 2024-02-12 08:11:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:11:00 --> Config Class Initialized
INFO - 2024-02-12 08:11:00 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:11:00 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:11:00 --> Utf8 Class Initialized
INFO - 2024-02-12 08:11:00 --> URI Class Initialized
INFO - 2024-02-12 08:11:00 --> Router Class Initialized
INFO - 2024-02-12 08:11:00 --> Output Class Initialized
INFO - 2024-02-12 08:11:00 --> Security Class Initialized
DEBUG - 2024-02-12 08:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:11:00 --> Input Class Initialized
INFO - 2024-02-12 08:11:00 --> Language Class Initialized
INFO - 2024-02-12 08:11:00 --> Loader Class Initialized
INFO - 2024-02-12 08:11:00 --> Helper loaded: url_helper
INFO - 2024-02-12 08:11:00 --> Helper loaded: file_helper
INFO - 2024-02-12 08:11:00 --> Helper loaded: html_helper
INFO - 2024-02-12 08:11:00 --> Helper loaded: text_helper
INFO - 2024-02-12 08:11:00 --> Helper loaded: form_helper
INFO - 2024-02-12 08:11:00 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:11:00 --> Helper loaded: security_helper
INFO - 2024-02-12 08:11:00 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:11:00 --> Database Driver Class Initialized
INFO - 2024-02-12 08:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:11:00 --> Parser Class Initialized
INFO - 2024-02-12 08:11:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:11:00 --> Pagination Class Initialized
INFO - 2024-02-12 08:11:00 --> Form Validation Class Initialized
INFO - 2024-02-12 08:11:00 --> Controller Class Initialized
INFO - 2024-02-12 08:11:00 --> Model Class Initialized
DEBUG - 2024-02-12 08:11:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:11:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:11:00 --> Model Class Initialized
DEBUG - 2024-02-12 08:11:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:11:00 --> Model Class Initialized
INFO - 2024-02-12 08:11:00 --> Final output sent to browser
DEBUG - 2024-02-12 08:11:00 --> Total execution time: 0.0937
ERROR - 2024-02-12 08:11:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:11:11 --> Config Class Initialized
INFO - 2024-02-12 08:11:11 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:11:11 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:11:11 --> Utf8 Class Initialized
INFO - 2024-02-12 08:11:11 --> URI Class Initialized
INFO - 2024-02-12 08:11:11 --> Router Class Initialized
INFO - 2024-02-12 08:11:11 --> Output Class Initialized
INFO - 2024-02-12 08:11:11 --> Security Class Initialized
DEBUG - 2024-02-12 08:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:11:11 --> Input Class Initialized
INFO - 2024-02-12 08:11:11 --> Language Class Initialized
INFO - 2024-02-12 08:11:11 --> Loader Class Initialized
INFO - 2024-02-12 08:11:11 --> Helper loaded: url_helper
INFO - 2024-02-12 08:11:11 --> Helper loaded: file_helper
INFO - 2024-02-12 08:11:11 --> Helper loaded: html_helper
INFO - 2024-02-12 08:11:11 --> Helper loaded: text_helper
INFO - 2024-02-12 08:11:11 --> Helper loaded: form_helper
INFO - 2024-02-12 08:11:11 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:11:11 --> Helper loaded: security_helper
INFO - 2024-02-12 08:11:11 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:11:11 --> Database Driver Class Initialized
INFO - 2024-02-12 08:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:11:11 --> Parser Class Initialized
INFO - 2024-02-12 08:11:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:11:11 --> Pagination Class Initialized
INFO - 2024-02-12 08:11:11 --> Form Validation Class Initialized
INFO - 2024-02-12 08:11:11 --> Controller Class Initialized
INFO - 2024-02-12 08:11:11 --> Model Class Initialized
DEBUG - 2024-02-12 08:11:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:11:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:11:11 --> Model Class Initialized
INFO - 2024-02-12 08:11:11 --> Model Class Initialized
INFO - 2024-02-12 08:11:11 --> Final output sent to browser
DEBUG - 2024-02-12 08:11:11 --> Total execution time: 0.0191
ERROR - 2024-02-12 08:11:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:11:15 --> Config Class Initialized
INFO - 2024-02-12 08:11:15 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:11:15 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:11:15 --> Utf8 Class Initialized
INFO - 2024-02-12 08:11:15 --> URI Class Initialized
INFO - 2024-02-12 08:11:15 --> Router Class Initialized
INFO - 2024-02-12 08:11:15 --> Output Class Initialized
INFO - 2024-02-12 08:11:15 --> Security Class Initialized
DEBUG - 2024-02-12 08:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:11:15 --> Input Class Initialized
INFO - 2024-02-12 08:11:15 --> Language Class Initialized
INFO - 2024-02-12 08:11:15 --> Loader Class Initialized
INFO - 2024-02-12 08:11:15 --> Helper loaded: url_helper
INFO - 2024-02-12 08:11:15 --> Helper loaded: file_helper
INFO - 2024-02-12 08:11:15 --> Helper loaded: html_helper
INFO - 2024-02-12 08:11:15 --> Helper loaded: text_helper
INFO - 2024-02-12 08:11:15 --> Helper loaded: form_helper
INFO - 2024-02-12 08:11:15 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:11:15 --> Helper loaded: security_helper
INFO - 2024-02-12 08:11:15 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:11:15 --> Database Driver Class Initialized
INFO - 2024-02-12 08:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:11:15 --> Parser Class Initialized
INFO - 2024-02-12 08:11:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:11:15 --> Pagination Class Initialized
INFO - 2024-02-12 08:11:15 --> Form Validation Class Initialized
INFO - 2024-02-12 08:11:15 --> Controller Class Initialized
INFO - 2024-02-12 08:11:15 --> Model Class Initialized
DEBUG - 2024-02-12 08:11:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:11:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:11:15 --> Model Class Initialized
INFO - 2024-02-12 08:11:15 --> Final output sent to browser
DEBUG - 2024-02-12 08:11:15 --> Total execution time: 0.0162
ERROR - 2024-02-12 08:11:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:11:30 --> Config Class Initialized
INFO - 2024-02-12 08:11:30 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:11:30 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:11:30 --> Utf8 Class Initialized
INFO - 2024-02-12 08:11:30 --> URI Class Initialized
INFO - 2024-02-12 08:11:30 --> Router Class Initialized
INFO - 2024-02-12 08:11:30 --> Output Class Initialized
INFO - 2024-02-12 08:11:30 --> Security Class Initialized
DEBUG - 2024-02-12 08:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:11:30 --> Input Class Initialized
INFO - 2024-02-12 08:11:30 --> Language Class Initialized
INFO - 2024-02-12 08:11:30 --> Loader Class Initialized
INFO - 2024-02-12 08:11:30 --> Helper loaded: url_helper
INFO - 2024-02-12 08:11:30 --> Helper loaded: file_helper
INFO - 2024-02-12 08:11:30 --> Helper loaded: html_helper
INFO - 2024-02-12 08:11:30 --> Helper loaded: text_helper
INFO - 2024-02-12 08:11:30 --> Helper loaded: form_helper
INFO - 2024-02-12 08:11:30 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:11:30 --> Helper loaded: security_helper
INFO - 2024-02-12 08:11:30 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:11:30 --> Database Driver Class Initialized
INFO - 2024-02-12 08:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:11:30 --> Parser Class Initialized
INFO - 2024-02-12 08:11:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:11:30 --> Pagination Class Initialized
INFO - 2024-02-12 08:11:30 --> Form Validation Class Initialized
INFO - 2024-02-12 08:11:30 --> Controller Class Initialized
INFO - 2024-02-12 08:11:30 --> Model Class Initialized
DEBUG - 2024-02-12 08:11:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:11:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:11:30 --> Model Class Initialized
DEBUG - 2024-02-12 08:11:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:11:30 --> Model Class Initialized
INFO - 2024-02-12 08:11:30 --> Email Class Initialized
DEBUG - 2024-02-12 08:11:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:11:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 08:11:30 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-02-12 08:11:30 --> Language file loaded: language/english/email_lang.php
INFO - 2024-02-12 08:11:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2024-02-12 08:11:30 --> Final output sent to browser
DEBUG - 2024-02-12 08:11:30 --> Total execution time: 0.2322
ERROR - 2024-02-12 08:13:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:13:17 --> Config Class Initialized
INFO - 2024-02-12 08:13:17 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:13:17 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:13:17 --> Utf8 Class Initialized
INFO - 2024-02-12 08:13:17 --> URI Class Initialized
DEBUG - 2024-02-12 08:13:17 --> No URI present. Default controller set.
INFO - 2024-02-12 08:13:17 --> Router Class Initialized
INFO - 2024-02-12 08:13:17 --> Output Class Initialized
INFO - 2024-02-12 08:13:17 --> Security Class Initialized
DEBUG - 2024-02-12 08:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:13:17 --> Input Class Initialized
INFO - 2024-02-12 08:13:17 --> Language Class Initialized
INFO - 2024-02-12 08:13:17 --> Loader Class Initialized
INFO - 2024-02-12 08:13:17 --> Helper loaded: url_helper
INFO - 2024-02-12 08:13:17 --> Helper loaded: file_helper
INFO - 2024-02-12 08:13:17 --> Helper loaded: html_helper
INFO - 2024-02-12 08:13:17 --> Helper loaded: text_helper
INFO - 2024-02-12 08:13:17 --> Helper loaded: form_helper
INFO - 2024-02-12 08:13:17 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:13:17 --> Helper loaded: security_helper
INFO - 2024-02-12 08:13:17 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:13:17 --> Database Driver Class Initialized
INFO - 2024-02-12 08:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:13:17 --> Parser Class Initialized
INFO - 2024-02-12 08:13:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:13:17 --> Pagination Class Initialized
INFO - 2024-02-12 08:13:17 --> Form Validation Class Initialized
INFO - 2024-02-12 08:13:17 --> Controller Class Initialized
INFO - 2024-02-12 08:13:17 --> Model Class Initialized
DEBUG - 2024-02-12 08:13:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-12 08:13:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:13:17 --> Config Class Initialized
INFO - 2024-02-12 08:13:17 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:13:17 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:13:17 --> Utf8 Class Initialized
INFO - 2024-02-12 08:13:17 --> URI Class Initialized
INFO - 2024-02-12 08:13:17 --> Router Class Initialized
INFO - 2024-02-12 08:13:17 --> Output Class Initialized
INFO - 2024-02-12 08:13:17 --> Security Class Initialized
DEBUG - 2024-02-12 08:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:13:17 --> Input Class Initialized
INFO - 2024-02-12 08:13:17 --> Language Class Initialized
INFO - 2024-02-12 08:13:17 --> Loader Class Initialized
INFO - 2024-02-12 08:13:17 --> Helper loaded: url_helper
INFO - 2024-02-12 08:13:17 --> Helper loaded: file_helper
INFO - 2024-02-12 08:13:17 --> Helper loaded: html_helper
INFO - 2024-02-12 08:13:17 --> Helper loaded: text_helper
INFO - 2024-02-12 08:13:17 --> Helper loaded: form_helper
INFO - 2024-02-12 08:13:17 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:13:17 --> Helper loaded: security_helper
INFO - 2024-02-12 08:13:17 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:13:17 --> Database Driver Class Initialized
INFO - 2024-02-12 08:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:13:17 --> Parser Class Initialized
INFO - 2024-02-12 08:13:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:13:17 --> Pagination Class Initialized
INFO - 2024-02-12 08:13:17 --> Form Validation Class Initialized
INFO - 2024-02-12 08:13:17 --> Controller Class Initialized
INFO - 2024-02-12 08:13:17 --> Model Class Initialized
DEBUG - 2024-02-12 08:13:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:13:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-12 08:13:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:13:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 08:13:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 08:13:17 --> Model Class Initialized
INFO - 2024-02-12 08:13:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 08:13:17 --> Final output sent to browser
DEBUG - 2024-02-12 08:13:17 --> Total execution time: 0.0297
ERROR - 2024-02-12 08:16:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:16:34 --> Config Class Initialized
INFO - 2024-02-12 08:16:34 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:16:34 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:16:34 --> Utf8 Class Initialized
INFO - 2024-02-12 08:16:34 --> URI Class Initialized
INFO - 2024-02-12 08:16:34 --> Router Class Initialized
INFO - 2024-02-12 08:16:34 --> Output Class Initialized
INFO - 2024-02-12 08:16:34 --> Security Class Initialized
DEBUG - 2024-02-12 08:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:16:34 --> Input Class Initialized
INFO - 2024-02-12 08:16:34 --> Language Class Initialized
INFO - 2024-02-12 08:16:34 --> Loader Class Initialized
INFO - 2024-02-12 08:16:34 --> Helper loaded: url_helper
INFO - 2024-02-12 08:16:34 --> Helper loaded: file_helper
INFO - 2024-02-12 08:16:34 --> Helper loaded: html_helper
INFO - 2024-02-12 08:16:34 --> Helper loaded: text_helper
INFO - 2024-02-12 08:16:34 --> Helper loaded: form_helper
INFO - 2024-02-12 08:16:34 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:16:34 --> Helper loaded: security_helper
INFO - 2024-02-12 08:16:34 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:16:34 --> Database Driver Class Initialized
INFO - 2024-02-12 08:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:16:34 --> Parser Class Initialized
INFO - 2024-02-12 08:16:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:16:34 --> Pagination Class Initialized
INFO - 2024-02-12 08:16:34 --> Form Validation Class Initialized
INFO - 2024-02-12 08:16:34 --> Controller Class Initialized
INFO - 2024-02-12 08:16:34 --> Model Class Initialized
DEBUG - 2024-02-12 08:16:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:16:34 --> Model Class Initialized
INFO - 2024-02-12 08:16:34 --> Final output sent to browser
DEBUG - 2024-02-12 08:16:34 --> Total execution time: 0.0200
ERROR - 2024-02-12 08:16:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:16:34 --> Config Class Initialized
INFO - 2024-02-12 08:16:34 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:16:34 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:16:34 --> Utf8 Class Initialized
INFO - 2024-02-12 08:16:34 --> URI Class Initialized
DEBUG - 2024-02-12 08:16:34 --> No URI present. Default controller set.
INFO - 2024-02-12 08:16:34 --> Router Class Initialized
INFO - 2024-02-12 08:16:34 --> Output Class Initialized
INFO - 2024-02-12 08:16:34 --> Security Class Initialized
DEBUG - 2024-02-12 08:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:16:34 --> Input Class Initialized
INFO - 2024-02-12 08:16:34 --> Language Class Initialized
INFO - 2024-02-12 08:16:34 --> Loader Class Initialized
INFO - 2024-02-12 08:16:34 --> Helper loaded: url_helper
INFO - 2024-02-12 08:16:34 --> Helper loaded: file_helper
INFO - 2024-02-12 08:16:34 --> Helper loaded: html_helper
INFO - 2024-02-12 08:16:34 --> Helper loaded: text_helper
INFO - 2024-02-12 08:16:34 --> Helper loaded: form_helper
INFO - 2024-02-12 08:16:34 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:16:34 --> Helper loaded: security_helper
INFO - 2024-02-12 08:16:34 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:16:34 --> Database Driver Class Initialized
INFO - 2024-02-12 08:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:16:34 --> Parser Class Initialized
INFO - 2024-02-12 08:16:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:16:34 --> Pagination Class Initialized
INFO - 2024-02-12 08:16:34 --> Form Validation Class Initialized
INFO - 2024-02-12 08:16:34 --> Controller Class Initialized
INFO - 2024-02-12 08:16:34 --> Model Class Initialized
DEBUG - 2024-02-12 08:16:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:16:34 --> Model Class Initialized
DEBUG - 2024-02-12 08:16:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:16:34 --> Model Class Initialized
INFO - 2024-02-12 08:16:34 --> Model Class Initialized
INFO - 2024-02-12 08:16:34 --> Model Class Initialized
INFO - 2024-02-12 08:16:34 --> Model Class Initialized
DEBUG - 2024-02-12 08:16:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:16:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:16:34 --> Model Class Initialized
INFO - 2024-02-12 08:16:34 --> Model Class Initialized
INFO - 2024-02-12 08:16:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-12 08:16:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:16:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 08:16:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 08:16:34 --> Model Class Initialized
INFO - 2024-02-12 08:16:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 08:16:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 08:16:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 08:16:34 --> Final output sent to browser
DEBUG - 2024-02-12 08:16:34 --> Total execution time: 0.2144
ERROR - 2024-02-12 08:18:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:18:49 --> Config Class Initialized
INFO - 2024-02-12 08:18:49 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:18:49 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:18:49 --> Utf8 Class Initialized
INFO - 2024-02-12 08:18:49 --> URI Class Initialized
INFO - 2024-02-12 08:18:49 --> Router Class Initialized
INFO - 2024-02-12 08:18:49 --> Output Class Initialized
INFO - 2024-02-12 08:18:49 --> Security Class Initialized
DEBUG - 2024-02-12 08:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:18:49 --> Input Class Initialized
INFO - 2024-02-12 08:18:49 --> Language Class Initialized
INFO - 2024-02-12 08:18:49 --> Loader Class Initialized
INFO - 2024-02-12 08:18:49 --> Helper loaded: url_helper
INFO - 2024-02-12 08:18:49 --> Helper loaded: file_helper
INFO - 2024-02-12 08:18:49 --> Helper loaded: html_helper
INFO - 2024-02-12 08:18:49 --> Helper loaded: text_helper
INFO - 2024-02-12 08:18:49 --> Helper loaded: form_helper
INFO - 2024-02-12 08:18:49 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:18:49 --> Helper loaded: security_helper
INFO - 2024-02-12 08:18:49 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:18:49 --> Database Driver Class Initialized
INFO - 2024-02-12 08:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:18:49 --> Parser Class Initialized
INFO - 2024-02-12 08:18:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:18:49 --> Pagination Class Initialized
INFO - 2024-02-12 08:18:49 --> Form Validation Class Initialized
INFO - 2024-02-12 08:18:49 --> Controller Class Initialized
INFO - 2024-02-12 08:18:49 --> Model Class Initialized
DEBUG - 2024-02-12 08:18:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:18:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:18:49 --> Model Class Initialized
DEBUG - 2024-02-12 08:18:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:18:49 --> Model Class Initialized
INFO - 2024-02-12 08:18:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-12 08:18:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:18:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 08:18:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 08:18:49 --> Model Class Initialized
INFO - 2024-02-12 08:18:49 --> Model Class Initialized
INFO - 2024-02-12 08:18:49 --> Model Class Initialized
INFO - 2024-02-12 08:18:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 08:18:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 08:18:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 08:18:50 --> Final output sent to browser
DEBUG - 2024-02-12 08:18:50 --> Total execution time: 0.1469
ERROR - 2024-02-12 08:18:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:18:50 --> Config Class Initialized
INFO - 2024-02-12 08:18:50 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:18:50 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:18:50 --> Utf8 Class Initialized
INFO - 2024-02-12 08:18:50 --> URI Class Initialized
INFO - 2024-02-12 08:18:50 --> Router Class Initialized
INFO - 2024-02-12 08:18:50 --> Output Class Initialized
INFO - 2024-02-12 08:18:50 --> Security Class Initialized
DEBUG - 2024-02-12 08:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:18:50 --> Input Class Initialized
INFO - 2024-02-12 08:18:50 --> Language Class Initialized
INFO - 2024-02-12 08:18:50 --> Loader Class Initialized
INFO - 2024-02-12 08:18:50 --> Helper loaded: url_helper
INFO - 2024-02-12 08:18:50 --> Helper loaded: file_helper
INFO - 2024-02-12 08:18:50 --> Helper loaded: html_helper
INFO - 2024-02-12 08:18:50 --> Helper loaded: text_helper
INFO - 2024-02-12 08:18:50 --> Helper loaded: form_helper
INFO - 2024-02-12 08:18:50 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:18:50 --> Helper loaded: security_helper
INFO - 2024-02-12 08:18:50 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:18:50 --> Database Driver Class Initialized
INFO - 2024-02-12 08:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:18:50 --> Parser Class Initialized
INFO - 2024-02-12 08:18:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:18:50 --> Pagination Class Initialized
INFO - 2024-02-12 08:18:50 --> Form Validation Class Initialized
INFO - 2024-02-12 08:18:50 --> Controller Class Initialized
INFO - 2024-02-12 08:18:50 --> Model Class Initialized
DEBUG - 2024-02-12 08:18:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:18:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:18:50 --> Model Class Initialized
DEBUG - 2024-02-12 08:18:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:18:50 --> Model Class Initialized
INFO - 2024-02-12 08:18:50 --> Final output sent to browser
DEBUG - 2024-02-12 08:18:50 --> Total execution time: 0.0238
ERROR - 2024-02-12 08:18:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:18:56 --> Config Class Initialized
INFO - 2024-02-12 08:18:56 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:18:56 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:18:56 --> Utf8 Class Initialized
INFO - 2024-02-12 08:18:56 --> URI Class Initialized
DEBUG - 2024-02-12 08:18:56 --> No URI present. Default controller set.
INFO - 2024-02-12 08:18:56 --> Router Class Initialized
INFO - 2024-02-12 08:18:56 --> Output Class Initialized
INFO - 2024-02-12 08:18:56 --> Security Class Initialized
DEBUG - 2024-02-12 08:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:18:56 --> Input Class Initialized
INFO - 2024-02-12 08:18:56 --> Language Class Initialized
INFO - 2024-02-12 08:18:56 --> Loader Class Initialized
INFO - 2024-02-12 08:18:56 --> Helper loaded: url_helper
INFO - 2024-02-12 08:18:56 --> Helper loaded: file_helper
INFO - 2024-02-12 08:18:56 --> Helper loaded: html_helper
INFO - 2024-02-12 08:18:56 --> Helper loaded: text_helper
INFO - 2024-02-12 08:18:56 --> Helper loaded: form_helper
INFO - 2024-02-12 08:18:56 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:18:56 --> Helper loaded: security_helper
INFO - 2024-02-12 08:18:56 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:18:56 --> Database Driver Class Initialized
INFO - 2024-02-12 08:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:18:56 --> Parser Class Initialized
INFO - 2024-02-12 08:18:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:18:56 --> Pagination Class Initialized
INFO - 2024-02-12 08:18:56 --> Form Validation Class Initialized
INFO - 2024-02-12 08:18:56 --> Controller Class Initialized
INFO - 2024-02-12 08:18:56 --> Model Class Initialized
DEBUG - 2024-02-12 08:18:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:18:56 --> Model Class Initialized
DEBUG - 2024-02-12 08:18:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:18:56 --> Model Class Initialized
INFO - 2024-02-12 08:18:56 --> Model Class Initialized
INFO - 2024-02-12 08:18:56 --> Model Class Initialized
INFO - 2024-02-12 08:18:56 --> Model Class Initialized
DEBUG - 2024-02-12 08:18:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:18:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:18:56 --> Model Class Initialized
INFO - 2024-02-12 08:18:56 --> Model Class Initialized
INFO - 2024-02-12 08:18:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-12 08:18:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:18:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 08:18:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 08:18:57 --> Model Class Initialized
INFO - 2024-02-12 08:18:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 08:18:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 08:18:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 08:18:57 --> Final output sent to browser
DEBUG - 2024-02-12 08:18:57 --> Total execution time: 0.2097
ERROR - 2024-02-12 08:19:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:19:04 --> Config Class Initialized
INFO - 2024-02-12 08:19:04 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:19:04 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:19:04 --> Utf8 Class Initialized
INFO - 2024-02-12 08:19:04 --> URI Class Initialized
INFO - 2024-02-12 08:19:04 --> Router Class Initialized
INFO - 2024-02-12 08:19:04 --> Output Class Initialized
INFO - 2024-02-12 08:19:04 --> Security Class Initialized
DEBUG - 2024-02-12 08:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:19:04 --> Input Class Initialized
INFO - 2024-02-12 08:19:04 --> Language Class Initialized
INFO - 2024-02-12 08:19:04 --> Loader Class Initialized
INFO - 2024-02-12 08:19:04 --> Helper loaded: url_helper
INFO - 2024-02-12 08:19:04 --> Helper loaded: file_helper
INFO - 2024-02-12 08:19:04 --> Helper loaded: html_helper
INFO - 2024-02-12 08:19:04 --> Helper loaded: text_helper
INFO - 2024-02-12 08:19:04 --> Helper loaded: form_helper
INFO - 2024-02-12 08:19:04 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:19:04 --> Helper loaded: security_helper
INFO - 2024-02-12 08:19:04 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:19:04 --> Database Driver Class Initialized
INFO - 2024-02-12 08:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:19:04 --> Parser Class Initialized
INFO - 2024-02-12 08:19:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:19:04 --> Pagination Class Initialized
INFO - 2024-02-12 08:19:04 --> Form Validation Class Initialized
INFO - 2024-02-12 08:19:04 --> Controller Class Initialized
INFO - 2024-02-12 08:19:04 --> Model Class Initialized
DEBUG - 2024-02-12 08:19:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:19:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:19:04 --> Model Class Initialized
DEBUG - 2024-02-12 08:19:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:19:04 --> Model Class Initialized
INFO - 2024-02-12 08:19:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-12 08:19:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:19:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 08:19:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 08:19:04 --> Model Class Initialized
INFO - 2024-02-12 08:19:04 --> Model Class Initialized
INFO - 2024-02-12 08:19:04 --> Model Class Initialized
INFO - 2024-02-12 08:19:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 08:19:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 08:19:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 08:19:04 --> Final output sent to browser
DEBUG - 2024-02-12 08:19:04 --> Total execution time: 0.1379
ERROR - 2024-02-12 08:19:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:19:05 --> Config Class Initialized
INFO - 2024-02-12 08:19:05 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:19:05 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:19:05 --> Utf8 Class Initialized
INFO - 2024-02-12 08:19:05 --> URI Class Initialized
INFO - 2024-02-12 08:19:05 --> Router Class Initialized
INFO - 2024-02-12 08:19:05 --> Output Class Initialized
INFO - 2024-02-12 08:19:05 --> Security Class Initialized
DEBUG - 2024-02-12 08:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:19:05 --> Input Class Initialized
INFO - 2024-02-12 08:19:05 --> Language Class Initialized
INFO - 2024-02-12 08:19:05 --> Loader Class Initialized
INFO - 2024-02-12 08:19:05 --> Helper loaded: url_helper
INFO - 2024-02-12 08:19:05 --> Helper loaded: file_helper
INFO - 2024-02-12 08:19:05 --> Helper loaded: html_helper
INFO - 2024-02-12 08:19:05 --> Helper loaded: text_helper
INFO - 2024-02-12 08:19:05 --> Helper loaded: form_helper
INFO - 2024-02-12 08:19:05 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:19:05 --> Helper loaded: security_helper
INFO - 2024-02-12 08:19:05 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:19:05 --> Database Driver Class Initialized
INFO - 2024-02-12 08:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:19:05 --> Parser Class Initialized
INFO - 2024-02-12 08:19:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:19:05 --> Pagination Class Initialized
INFO - 2024-02-12 08:19:05 --> Form Validation Class Initialized
INFO - 2024-02-12 08:19:05 --> Controller Class Initialized
INFO - 2024-02-12 08:19:05 --> Model Class Initialized
DEBUG - 2024-02-12 08:19:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:19:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:19:05 --> Model Class Initialized
DEBUG - 2024-02-12 08:19:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:19:05 --> Model Class Initialized
INFO - 2024-02-12 08:19:05 --> Final output sent to browser
DEBUG - 2024-02-12 08:19:05 --> Total execution time: 0.0222
ERROR - 2024-02-12 08:19:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:19:06 --> Config Class Initialized
INFO - 2024-02-12 08:19:06 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:19:06 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:19:06 --> Utf8 Class Initialized
INFO - 2024-02-12 08:19:06 --> URI Class Initialized
DEBUG - 2024-02-12 08:19:06 --> No URI present. Default controller set.
INFO - 2024-02-12 08:19:06 --> Router Class Initialized
INFO - 2024-02-12 08:19:06 --> Output Class Initialized
INFO - 2024-02-12 08:19:06 --> Security Class Initialized
DEBUG - 2024-02-12 08:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:19:06 --> Input Class Initialized
INFO - 2024-02-12 08:19:06 --> Language Class Initialized
INFO - 2024-02-12 08:19:06 --> Loader Class Initialized
INFO - 2024-02-12 08:19:06 --> Helper loaded: url_helper
INFO - 2024-02-12 08:19:06 --> Helper loaded: file_helper
INFO - 2024-02-12 08:19:06 --> Helper loaded: html_helper
INFO - 2024-02-12 08:19:06 --> Helper loaded: text_helper
INFO - 2024-02-12 08:19:06 --> Helper loaded: form_helper
INFO - 2024-02-12 08:19:06 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:19:06 --> Helper loaded: security_helper
INFO - 2024-02-12 08:19:06 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:19:06 --> Database Driver Class Initialized
INFO - 2024-02-12 08:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:19:06 --> Parser Class Initialized
INFO - 2024-02-12 08:19:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:19:06 --> Pagination Class Initialized
INFO - 2024-02-12 08:19:06 --> Form Validation Class Initialized
INFO - 2024-02-12 08:19:06 --> Controller Class Initialized
INFO - 2024-02-12 08:19:06 --> Model Class Initialized
DEBUG - 2024-02-12 08:19:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:19:06 --> Model Class Initialized
DEBUG - 2024-02-12 08:19:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:19:06 --> Model Class Initialized
INFO - 2024-02-12 08:19:06 --> Model Class Initialized
INFO - 2024-02-12 08:19:06 --> Model Class Initialized
INFO - 2024-02-12 08:19:06 --> Model Class Initialized
DEBUG - 2024-02-12 08:19:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:19:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:19:06 --> Model Class Initialized
INFO - 2024-02-12 08:19:06 --> Model Class Initialized
INFO - 2024-02-12 08:19:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-12 08:19:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:19:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 08:19:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 08:19:07 --> Model Class Initialized
INFO - 2024-02-12 08:19:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 08:19:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 08:19:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 08:19:07 --> Final output sent to browser
DEBUG - 2024-02-12 08:19:07 --> Total execution time: 0.2284
ERROR - 2024-02-12 08:19:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:19:16 --> Config Class Initialized
INFO - 2024-02-12 08:19:16 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:19:16 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:19:16 --> Utf8 Class Initialized
INFO - 2024-02-12 08:19:16 --> URI Class Initialized
INFO - 2024-02-12 08:19:16 --> Router Class Initialized
INFO - 2024-02-12 08:19:16 --> Output Class Initialized
INFO - 2024-02-12 08:19:16 --> Security Class Initialized
DEBUG - 2024-02-12 08:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:19:16 --> Input Class Initialized
INFO - 2024-02-12 08:19:16 --> Language Class Initialized
INFO - 2024-02-12 08:19:16 --> Loader Class Initialized
INFO - 2024-02-12 08:19:16 --> Helper loaded: url_helper
INFO - 2024-02-12 08:19:16 --> Helper loaded: file_helper
INFO - 2024-02-12 08:19:16 --> Helper loaded: html_helper
INFO - 2024-02-12 08:19:16 --> Helper loaded: text_helper
INFO - 2024-02-12 08:19:16 --> Helper loaded: form_helper
INFO - 2024-02-12 08:19:16 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:19:16 --> Helper loaded: security_helper
INFO - 2024-02-12 08:19:16 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:19:16 --> Database Driver Class Initialized
INFO - 2024-02-12 08:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:19:16 --> Parser Class Initialized
INFO - 2024-02-12 08:19:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:19:16 --> Pagination Class Initialized
INFO - 2024-02-12 08:19:16 --> Form Validation Class Initialized
INFO - 2024-02-12 08:19:16 --> Controller Class Initialized
INFO - 2024-02-12 08:19:16 --> Model Class Initialized
DEBUG - 2024-02-12 08:19:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:19:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:19:16 --> Model Class Initialized
DEBUG - 2024-02-12 08:19:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:19:16 --> Model Class Initialized
INFO - 2024-02-12 08:19:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-12 08:19:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:19:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 08:19:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 08:19:16 --> Model Class Initialized
INFO - 2024-02-12 08:19:16 --> Model Class Initialized
INFO - 2024-02-12 08:19:16 --> Model Class Initialized
INFO - 2024-02-12 08:19:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 08:19:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 08:19:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 08:19:16 --> Final output sent to browser
DEBUG - 2024-02-12 08:19:16 --> Total execution time: 0.1431
ERROR - 2024-02-12 08:19:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:19:17 --> Config Class Initialized
INFO - 2024-02-12 08:19:17 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:19:17 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:19:17 --> Utf8 Class Initialized
INFO - 2024-02-12 08:19:17 --> URI Class Initialized
INFO - 2024-02-12 08:19:17 --> Router Class Initialized
INFO - 2024-02-12 08:19:17 --> Output Class Initialized
INFO - 2024-02-12 08:19:17 --> Security Class Initialized
DEBUG - 2024-02-12 08:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:19:17 --> Input Class Initialized
INFO - 2024-02-12 08:19:17 --> Language Class Initialized
INFO - 2024-02-12 08:19:17 --> Loader Class Initialized
INFO - 2024-02-12 08:19:17 --> Helper loaded: url_helper
INFO - 2024-02-12 08:19:17 --> Helper loaded: file_helper
INFO - 2024-02-12 08:19:17 --> Helper loaded: html_helper
INFO - 2024-02-12 08:19:17 --> Helper loaded: text_helper
INFO - 2024-02-12 08:19:17 --> Helper loaded: form_helper
INFO - 2024-02-12 08:19:17 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:19:17 --> Helper loaded: security_helper
INFO - 2024-02-12 08:19:17 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:19:17 --> Database Driver Class Initialized
INFO - 2024-02-12 08:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:19:17 --> Parser Class Initialized
INFO - 2024-02-12 08:19:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:19:17 --> Pagination Class Initialized
INFO - 2024-02-12 08:19:17 --> Form Validation Class Initialized
INFO - 2024-02-12 08:19:17 --> Controller Class Initialized
INFO - 2024-02-12 08:19:17 --> Model Class Initialized
DEBUG - 2024-02-12 08:19:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:19:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:19:17 --> Model Class Initialized
DEBUG - 2024-02-12 08:19:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:19:17 --> Model Class Initialized
INFO - 2024-02-12 08:19:17 --> Final output sent to browser
DEBUG - 2024-02-12 08:19:17 --> Total execution time: 0.0237
ERROR - 2024-02-12 08:19:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:19:39 --> Config Class Initialized
INFO - 2024-02-12 08:19:39 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:19:39 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:19:39 --> Utf8 Class Initialized
INFO - 2024-02-12 08:19:39 --> URI Class Initialized
DEBUG - 2024-02-12 08:19:39 --> No URI present. Default controller set.
INFO - 2024-02-12 08:19:39 --> Router Class Initialized
INFO - 2024-02-12 08:19:39 --> Output Class Initialized
INFO - 2024-02-12 08:19:39 --> Security Class Initialized
DEBUG - 2024-02-12 08:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:19:39 --> Input Class Initialized
INFO - 2024-02-12 08:19:39 --> Language Class Initialized
INFO - 2024-02-12 08:19:39 --> Loader Class Initialized
INFO - 2024-02-12 08:19:39 --> Helper loaded: url_helper
INFO - 2024-02-12 08:19:39 --> Helper loaded: file_helper
INFO - 2024-02-12 08:19:39 --> Helper loaded: html_helper
INFO - 2024-02-12 08:19:39 --> Helper loaded: text_helper
INFO - 2024-02-12 08:19:39 --> Helper loaded: form_helper
INFO - 2024-02-12 08:19:39 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:19:39 --> Helper loaded: security_helper
INFO - 2024-02-12 08:19:39 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:19:39 --> Database Driver Class Initialized
INFO - 2024-02-12 08:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:19:39 --> Parser Class Initialized
INFO - 2024-02-12 08:19:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:19:39 --> Pagination Class Initialized
INFO - 2024-02-12 08:19:39 --> Form Validation Class Initialized
INFO - 2024-02-12 08:19:39 --> Controller Class Initialized
INFO - 2024-02-12 08:19:39 --> Model Class Initialized
DEBUG - 2024-02-12 08:19:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:19:39 --> Model Class Initialized
DEBUG - 2024-02-12 08:19:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:19:39 --> Model Class Initialized
INFO - 2024-02-12 08:19:39 --> Model Class Initialized
INFO - 2024-02-12 08:19:39 --> Model Class Initialized
INFO - 2024-02-12 08:19:39 --> Model Class Initialized
DEBUG - 2024-02-12 08:19:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:19:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:19:39 --> Model Class Initialized
INFO - 2024-02-12 08:19:39 --> Model Class Initialized
INFO - 2024-02-12 08:19:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-12 08:19:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:19:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 08:19:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 08:19:39 --> Model Class Initialized
INFO - 2024-02-12 08:19:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 08:19:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 08:19:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 08:19:39 --> Final output sent to browser
DEBUG - 2024-02-12 08:19:39 --> Total execution time: 0.2163
ERROR - 2024-02-12 08:19:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:19:47 --> Config Class Initialized
INFO - 2024-02-12 08:19:47 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:19:47 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:19:47 --> Utf8 Class Initialized
INFO - 2024-02-12 08:19:47 --> URI Class Initialized
INFO - 2024-02-12 08:19:47 --> Router Class Initialized
INFO - 2024-02-12 08:19:47 --> Output Class Initialized
INFO - 2024-02-12 08:19:47 --> Security Class Initialized
DEBUG - 2024-02-12 08:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:19:47 --> Input Class Initialized
INFO - 2024-02-12 08:19:47 --> Language Class Initialized
INFO - 2024-02-12 08:19:47 --> Loader Class Initialized
INFO - 2024-02-12 08:19:47 --> Helper loaded: url_helper
INFO - 2024-02-12 08:19:47 --> Helper loaded: file_helper
INFO - 2024-02-12 08:19:47 --> Helper loaded: html_helper
INFO - 2024-02-12 08:19:47 --> Helper loaded: text_helper
INFO - 2024-02-12 08:19:47 --> Helper loaded: form_helper
INFO - 2024-02-12 08:19:47 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:19:47 --> Helper loaded: security_helper
INFO - 2024-02-12 08:19:47 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:19:47 --> Database Driver Class Initialized
INFO - 2024-02-12 08:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:19:47 --> Parser Class Initialized
INFO - 2024-02-12 08:19:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:19:47 --> Pagination Class Initialized
INFO - 2024-02-12 08:19:47 --> Form Validation Class Initialized
INFO - 2024-02-12 08:19:47 --> Controller Class Initialized
DEBUG - 2024-02-12 08:19:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:19:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:19:47 --> Model Class Initialized
DEBUG - 2024-02-12 08:19:47 --> Lgift class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:19:47 --> Model Class Initialized
DEBUG - 2024-02-12 08:19:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:19:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:19:47 --> Model Class Initialized
DEBUG - 2024-02-12 08:19:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:19:47 --> Model Class Initialized
INFO - 2024-02-12 08:19:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/gift.php
DEBUG - 2024-02-12 08:19:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:19:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 08:19:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 08:19:47 --> Model Class Initialized
INFO - 2024-02-12 08:19:47 --> Model Class Initialized
INFO - 2024-02-12 08:19:47 --> Model Class Initialized
INFO - 2024-02-12 08:19:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 08:19:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 08:19:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 08:19:47 --> Final output sent to browser
DEBUG - 2024-02-12 08:19:47 --> Total execution time: 0.1377
ERROR - 2024-02-12 08:19:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:19:48 --> Config Class Initialized
INFO - 2024-02-12 08:19:48 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:19:48 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:19:48 --> Utf8 Class Initialized
INFO - 2024-02-12 08:19:48 --> URI Class Initialized
INFO - 2024-02-12 08:19:48 --> Router Class Initialized
INFO - 2024-02-12 08:19:48 --> Output Class Initialized
INFO - 2024-02-12 08:19:48 --> Security Class Initialized
DEBUG - 2024-02-12 08:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:19:48 --> Input Class Initialized
INFO - 2024-02-12 08:19:48 --> Language Class Initialized
INFO - 2024-02-12 08:19:48 --> Loader Class Initialized
INFO - 2024-02-12 08:19:48 --> Helper loaded: url_helper
INFO - 2024-02-12 08:19:48 --> Helper loaded: file_helper
INFO - 2024-02-12 08:19:48 --> Helper loaded: html_helper
INFO - 2024-02-12 08:19:48 --> Helper loaded: text_helper
INFO - 2024-02-12 08:19:48 --> Helper loaded: form_helper
INFO - 2024-02-12 08:19:48 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:19:48 --> Helper loaded: security_helper
INFO - 2024-02-12 08:19:48 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:19:48 --> Database Driver Class Initialized
INFO - 2024-02-12 08:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:19:48 --> Parser Class Initialized
INFO - 2024-02-12 08:19:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:19:48 --> Pagination Class Initialized
INFO - 2024-02-12 08:19:48 --> Form Validation Class Initialized
INFO - 2024-02-12 08:19:48 --> Controller Class Initialized
DEBUG - 2024-02-12 08:19:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:19:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:19:48 --> Model Class Initialized
INFO - 2024-02-12 08:19:48 --> Final output sent to browser
DEBUG - 2024-02-12 08:19:48 --> Total execution time: 0.0171
ERROR - 2024-02-12 08:21:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:21:13 --> Config Class Initialized
INFO - 2024-02-12 08:21:13 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:21:13 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:21:13 --> Utf8 Class Initialized
INFO - 2024-02-12 08:21:13 --> URI Class Initialized
DEBUG - 2024-02-12 08:21:13 --> No URI present. Default controller set.
INFO - 2024-02-12 08:21:13 --> Router Class Initialized
INFO - 2024-02-12 08:21:13 --> Output Class Initialized
INFO - 2024-02-12 08:21:13 --> Security Class Initialized
DEBUG - 2024-02-12 08:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:21:13 --> Input Class Initialized
INFO - 2024-02-12 08:21:13 --> Language Class Initialized
INFO - 2024-02-12 08:21:13 --> Loader Class Initialized
INFO - 2024-02-12 08:21:13 --> Helper loaded: url_helper
INFO - 2024-02-12 08:21:13 --> Helper loaded: file_helper
INFO - 2024-02-12 08:21:13 --> Helper loaded: html_helper
INFO - 2024-02-12 08:21:13 --> Helper loaded: text_helper
INFO - 2024-02-12 08:21:13 --> Helper loaded: form_helper
INFO - 2024-02-12 08:21:13 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:21:13 --> Helper loaded: security_helper
INFO - 2024-02-12 08:21:13 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:21:13 --> Database Driver Class Initialized
INFO - 2024-02-12 08:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:21:13 --> Parser Class Initialized
INFO - 2024-02-12 08:21:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:21:13 --> Pagination Class Initialized
INFO - 2024-02-12 08:21:13 --> Form Validation Class Initialized
INFO - 2024-02-12 08:21:13 --> Controller Class Initialized
INFO - 2024-02-12 08:21:13 --> Model Class Initialized
DEBUG - 2024-02-12 08:21:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:21:13 --> Model Class Initialized
DEBUG - 2024-02-12 08:21:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:21:13 --> Model Class Initialized
INFO - 2024-02-12 08:21:13 --> Model Class Initialized
INFO - 2024-02-12 08:21:13 --> Model Class Initialized
INFO - 2024-02-12 08:21:13 --> Model Class Initialized
DEBUG - 2024-02-12 08:21:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:21:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:21:13 --> Model Class Initialized
INFO - 2024-02-12 08:21:13 --> Model Class Initialized
INFO - 2024-02-12 08:21:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-12 08:21:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:21:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 08:21:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 08:21:13 --> Model Class Initialized
INFO - 2024-02-12 08:21:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 08:21:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 08:21:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 08:21:13 --> Final output sent to browser
DEBUG - 2024-02-12 08:21:13 --> Total execution time: 0.2208
ERROR - 2024-02-12 08:21:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:21:44 --> Config Class Initialized
INFO - 2024-02-12 08:21:44 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:21:44 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:21:44 --> Utf8 Class Initialized
INFO - 2024-02-12 08:21:44 --> URI Class Initialized
INFO - 2024-02-12 08:21:44 --> Router Class Initialized
INFO - 2024-02-12 08:21:44 --> Output Class Initialized
INFO - 2024-02-12 08:21:44 --> Security Class Initialized
DEBUG - 2024-02-12 08:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:21:44 --> Input Class Initialized
INFO - 2024-02-12 08:21:44 --> Language Class Initialized
INFO - 2024-02-12 08:21:44 --> Loader Class Initialized
INFO - 2024-02-12 08:21:44 --> Helper loaded: url_helper
INFO - 2024-02-12 08:21:44 --> Helper loaded: file_helper
INFO - 2024-02-12 08:21:44 --> Helper loaded: html_helper
INFO - 2024-02-12 08:21:44 --> Helper loaded: text_helper
INFO - 2024-02-12 08:21:44 --> Helper loaded: form_helper
INFO - 2024-02-12 08:21:44 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:21:44 --> Helper loaded: security_helper
INFO - 2024-02-12 08:21:44 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:21:44 --> Database Driver Class Initialized
INFO - 2024-02-12 08:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:21:44 --> Parser Class Initialized
INFO - 2024-02-12 08:21:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:21:44 --> Pagination Class Initialized
INFO - 2024-02-12 08:21:44 --> Form Validation Class Initialized
INFO - 2024-02-12 08:21:44 --> Controller Class Initialized
INFO - 2024-02-12 08:21:44 --> Model Class Initialized
DEBUG - 2024-02-12 08:21:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:21:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:21:44 --> Model Class Initialized
DEBUG - 2024-02-12 08:21:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:21:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2024-02-12 08:21:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:21:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 08:21:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 08:21:44 --> Model Class Initialized
INFO - 2024-02-12 08:21:44 --> Model Class Initialized
INFO - 2024-02-12 08:21:44 --> Model Class Initialized
INFO - 2024-02-12 08:21:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 08:21:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 08:21:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 08:21:44 --> Final output sent to browser
DEBUG - 2024-02-12 08:21:44 --> Total execution time: 0.1564
ERROR - 2024-02-12 08:22:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:22:17 --> Config Class Initialized
INFO - 2024-02-12 08:22:17 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:22:17 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:22:17 --> Utf8 Class Initialized
INFO - 2024-02-12 08:22:17 --> URI Class Initialized
DEBUG - 2024-02-12 08:22:17 --> No URI present. Default controller set.
INFO - 2024-02-12 08:22:17 --> Router Class Initialized
INFO - 2024-02-12 08:22:17 --> Output Class Initialized
INFO - 2024-02-12 08:22:17 --> Security Class Initialized
DEBUG - 2024-02-12 08:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:22:17 --> Input Class Initialized
INFO - 2024-02-12 08:22:17 --> Language Class Initialized
INFO - 2024-02-12 08:22:17 --> Loader Class Initialized
INFO - 2024-02-12 08:22:17 --> Helper loaded: url_helper
INFO - 2024-02-12 08:22:17 --> Helper loaded: file_helper
INFO - 2024-02-12 08:22:17 --> Helper loaded: html_helper
INFO - 2024-02-12 08:22:17 --> Helper loaded: text_helper
INFO - 2024-02-12 08:22:17 --> Helper loaded: form_helper
INFO - 2024-02-12 08:22:17 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:22:17 --> Helper loaded: security_helper
INFO - 2024-02-12 08:22:17 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:22:17 --> Database Driver Class Initialized
INFO - 2024-02-12 08:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:22:17 --> Parser Class Initialized
INFO - 2024-02-12 08:22:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:22:17 --> Pagination Class Initialized
INFO - 2024-02-12 08:22:17 --> Form Validation Class Initialized
INFO - 2024-02-12 08:22:17 --> Controller Class Initialized
INFO - 2024-02-12 08:22:17 --> Model Class Initialized
DEBUG - 2024-02-12 08:22:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:22:17 --> Model Class Initialized
DEBUG - 2024-02-12 08:22:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:22:17 --> Model Class Initialized
INFO - 2024-02-12 08:22:17 --> Model Class Initialized
INFO - 2024-02-12 08:22:17 --> Model Class Initialized
INFO - 2024-02-12 08:22:17 --> Model Class Initialized
DEBUG - 2024-02-12 08:22:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:22:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:22:17 --> Model Class Initialized
INFO - 2024-02-12 08:22:18 --> Model Class Initialized
INFO - 2024-02-12 08:22:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-12 08:22:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:22:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 08:22:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 08:22:18 --> Model Class Initialized
INFO - 2024-02-12 08:22:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 08:22:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 08:22:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 08:22:18 --> Final output sent to browser
DEBUG - 2024-02-12 08:22:18 --> Total execution time: 0.2162
ERROR - 2024-02-12 08:22:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:22:25 --> Config Class Initialized
INFO - 2024-02-12 08:22:25 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:22:25 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:22:25 --> Utf8 Class Initialized
INFO - 2024-02-12 08:22:25 --> URI Class Initialized
INFO - 2024-02-12 08:22:25 --> Router Class Initialized
INFO - 2024-02-12 08:22:25 --> Output Class Initialized
INFO - 2024-02-12 08:22:25 --> Security Class Initialized
DEBUG - 2024-02-12 08:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:22:25 --> Input Class Initialized
INFO - 2024-02-12 08:22:25 --> Language Class Initialized
INFO - 2024-02-12 08:22:25 --> Loader Class Initialized
INFO - 2024-02-12 08:22:25 --> Helper loaded: url_helper
INFO - 2024-02-12 08:22:25 --> Helper loaded: file_helper
INFO - 2024-02-12 08:22:25 --> Helper loaded: html_helper
INFO - 2024-02-12 08:22:25 --> Helper loaded: text_helper
INFO - 2024-02-12 08:22:25 --> Helper loaded: form_helper
INFO - 2024-02-12 08:22:25 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:22:25 --> Helper loaded: security_helper
INFO - 2024-02-12 08:22:25 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:22:25 --> Database Driver Class Initialized
INFO - 2024-02-12 08:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:22:25 --> Parser Class Initialized
INFO - 2024-02-12 08:22:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:22:25 --> Pagination Class Initialized
INFO - 2024-02-12 08:22:25 --> Form Validation Class Initialized
INFO - 2024-02-12 08:22:25 --> Controller Class Initialized
INFO - 2024-02-12 08:22:25 --> Model Class Initialized
DEBUG - 2024-02-12 08:22:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:22:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-12 08:22:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:22:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 08:22:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 08:22:25 --> Model Class Initialized
INFO - 2024-02-12 08:22:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 08:22:25 --> Final output sent to browser
DEBUG - 2024-02-12 08:22:25 --> Total execution time: 0.0274
ERROR - 2024-02-12 08:22:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:22:25 --> Config Class Initialized
INFO - 2024-02-12 08:22:25 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:22:25 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:22:25 --> Utf8 Class Initialized
INFO - 2024-02-12 08:22:25 --> URI Class Initialized
INFO - 2024-02-12 08:22:25 --> Router Class Initialized
INFO - 2024-02-12 08:22:25 --> Output Class Initialized
INFO - 2024-02-12 08:22:25 --> Security Class Initialized
DEBUG - 2024-02-12 08:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:22:25 --> Input Class Initialized
INFO - 2024-02-12 08:22:25 --> Language Class Initialized
INFO - 2024-02-12 08:22:25 --> Loader Class Initialized
INFO - 2024-02-12 08:22:25 --> Helper loaded: url_helper
INFO - 2024-02-12 08:22:25 --> Helper loaded: file_helper
INFO - 2024-02-12 08:22:25 --> Helper loaded: html_helper
INFO - 2024-02-12 08:22:25 --> Helper loaded: text_helper
INFO - 2024-02-12 08:22:25 --> Helper loaded: form_helper
INFO - 2024-02-12 08:22:25 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:22:25 --> Helper loaded: security_helper
INFO - 2024-02-12 08:22:25 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:22:25 --> Database Driver Class Initialized
INFO - 2024-02-12 08:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:22:25 --> Parser Class Initialized
INFO - 2024-02-12 08:22:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:22:25 --> Pagination Class Initialized
INFO - 2024-02-12 08:22:25 --> Form Validation Class Initialized
INFO - 2024-02-12 08:22:25 --> Controller Class Initialized
INFO - 2024-02-12 08:22:25 --> Model Class Initialized
DEBUG - 2024-02-12 08:22:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:22:25 --> Model Class Initialized
DEBUG - 2024-02-12 08:22:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:22:25 --> Model Class Initialized
INFO - 2024-02-12 08:22:25 --> Model Class Initialized
INFO - 2024-02-12 08:22:25 --> Model Class Initialized
INFO - 2024-02-12 08:22:25 --> Model Class Initialized
DEBUG - 2024-02-12 08:22:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:22:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:22:25 --> Model Class Initialized
INFO - 2024-02-12 08:22:25 --> Model Class Initialized
INFO - 2024-02-12 08:22:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-12 08:22:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:22:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 08:22:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 08:22:25 --> Model Class Initialized
INFO - 2024-02-12 08:22:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 08:22:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 08:22:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 08:22:25 --> Final output sent to browser
DEBUG - 2024-02-12 08:22:25 --> Total execution time: 0.2093
ERROR - 2024-02-12 08:24:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:24:20 --> Config Class Initialized
INFO - 2024-02-12 08:24:20 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:24:20 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:24:20 --> Utf8 Class Initialized
INFO - 2024-02-12 08:24:20 --> URI Class Initialized
INFO - 2024-02-12 08:24:20 --> Router Class Initialized
INFO - 2024-02-12 08:24:20 --> Output Class Initialized
INFO - 2024-02-12 08:24:20 --> Security Class Initialized
DEBUG - 2024-02-12 08:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:24:20 --> Input Class Initialized
INFO - 2024-02-12 08:24:20 --> Language Class Initialized
INFO - 2024-02-12 08:24:20 --> Loader Class Initialized
INFO - 2024-02-12 08:24:20 --> Helper loaded: url_helper
INFO - 2024-02-12 08:24:20 --> Helper loaded: file_helper
INFO - 2024-02-12 08:24:20 --> Helper loaded: html_helper
INFO - 2024-02-12 08:24:20 --> Helper loaded: text_helper
INFO - 2024-02-12 08:24:20 --> Helper loaded: form_helper
INFO - 2024-02-12 08:24:20 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:24:20 --> Helper loaded: security_helper
INFO - 2024-02-12 08:24:20 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:24:20 --> Database Driver Class Initialized
INFO - 2024-02-12 08:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:24:20 --> Parser Class Initialized
INFO - 2024-02-12 08:24:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:24:20 --> Pagination Class Initialized
INFO - 2024-02-12 08:24:20 --> Form Validation Class Initialized
INFO - 2024-02-12 08:24:20 --> Controller Class Initialized
INFO - 2024-02-12 08:24:20 --> Model Class Initialized
DEBUG - 2024-02-12 08:24:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:24:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:24:20 --> Model Class Initialized
DEBUG - 2024-02-12 08:24:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:24:20 --> Model Class Initialized
INFO - 2024-02-12 08:24:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-02-12 08:24:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:24:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 08:24:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 08:24:20 --> Model Class Initialized
INFO - 2024-02-12 08:24:20 --> Model Class Initialized
INFO - 2024-02-12 08:24:20 --> Model Class Initialized
INFO - 2024-02-12 08:24:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 08:24:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 08:24:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 08:24:20 --> Final output sent to browser
DEBUG - 2024-02-12 08:24:20 --> Total execution time: 0.1691
ERROR - 2024-02-12 08:24:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:24:22 --> Config Class Initialized
INFO - 2024-02-12 08:24:22 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:24:22 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:24:22 --> Utf8 Class Initialized
INFO - 2024-02-12 08:24:22 --> URI Class Initialized
DEBUG - 2024-02-12 08:24:22 --> No URI present. Default controller set.
INFO - 2024-02-12 08:24:22 --> Router Class Initialized
INFO - 2024-02-12 08:24:22 --> Output Class Initialized
INFO - 2024-02-12 08:24:22 --> Security Class Initialized
DEBUG - 2024-02-12 08:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:24:22 --> Input Class Initialized
INFO - 2024-02-12 08:24:22 --> Language Class Initialized
INFO - 2024-02-12 08:24:22 --> Loader Class Initialized
INFO - 2024-02-12 08:24:22 --> Helper loaded: url_helper
INFO - 2024-02-12 08:24:22 --> Helper loaded: file_helper
INFO - 2024-02-12 08:24:22 --> Helper loaded: html_helper
INFO - 2024-02-12 08:24:22 --> Helper loaded: text_helper
INFO - 2024-02-12 08:24:22 --> Helper loaded: form_helper
INFO - 2024-02-12 08:24:22 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:24:22 --> Helper loaded: security_helper
INFO - 2024-02-12 08:24:22 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:24:22 --> Database Driver Class Initialized
INFO - 2024-02-12 08:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:24:22 --> Parser Class Initialized
INFO - 2024-02-12 08:24:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:24:22 --> Pagination Class Initialized
INFO - 2024-02-12 08:24:22 --> Form Validation Class Initialized
INFO - 2024-02-12 08:24:22 --> Controller Class Initialized
INFO - 2024-02-12 08:24:22 --> Model Class Initialized
DEBUG - 2024-02-12 08:24:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:24:22 --> Model Class Initialized
DEBUG - 2024-02-12 08:24:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:24:22 --> Model Class Initialized
INFO - 2024-02-12 08:24:22 --> Model Class Initialized
INFO - 2024-02-12 08:24:22 --> Model Class Initialized
INFO - 2024-02-12 08:24:22 --> Model Class Initialized
DEBUG - 2024-02-12 08:24:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:24:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:24:22 --> Model Class Initialized
INFO - 2024-02-12 08:24:22 --> Model Class Initialized
INFO - 2024-02-12 08:24:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-12 08:24:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:24:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 08:24:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 08:24:23 --> Model Class Initialized
INFO - 2024-02-12 08:24:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 08:24:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 08:24:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 08:24:23 --> Final output sent to browser
DEBUG - 2024-02-12 08:24:23 --> Total execution time: 0.2301
ERROR - 2024-02-12 08:24:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:24:30 --> Config Class Initialized
INFO - 2024-02-12 08:24:30 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:24:30 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:24:30 --> Utf8 Class Initialized
INFO - 2024-02-12 08:24:30 --> URI Class Initialized
INFO - 2024-02-12 08:24:30 --> Router Class Initialized
INFO - 2024-02-12 08:24:30 --> Output Class Initialized
INFO - 2024-02-12 08:24:30 --> Security Class Initialized
DEBUG - 2024-02-12 08:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:24:30 --> Input Class Initialized
INFO - 2024-02-12 08:24:30 --> Language Class Initialized
INFO - 2024-02-12 08:24:30 --> Loader Class Initialized
INFO - 2024-02-12 08:24:30 --> Helper loaded: url_helper
INFO - 2024-02-12 08:24:30 --> Helper loaded: file_helper
INFO - 2024-02-12 08:24:30 --> Helper loaded: html_helper
INFO - 2024-02-12 08:24:30 --> Helper loaded: text_helper
INFO - 2024-02-12 08:24:30 --> Helper loaded: form_helper
INFO - 2024-02-12 08:24:30 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:24:30 --> Helper loaded: security_helper
INFO - 2024-02-12 08:24:30 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:24:30 --> Database Driver Class Initialized
INFO - 2024-02-12 08:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:24:30 --> Parser Class Initialized
INFO - 2024-02-12 08:24:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:24:30 --> Pagination Class Initialized
INFO - 2024-02-12 08:24:30 --> Form Validation Class Initialized
INFO - 2024-02-12 08:24:30 --> Controller Class Initialized
DEBUG - 2024-02-12 08:24:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:24:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:24:30 --> Model Class Initialized
DEBUG - 2024-02-12 08:24:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:24:30 --> Model Class Initialized
INFO - 2024-02-12 08:24:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2024-02-12 08:24:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:24:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 08:24:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 08:24:30 --> Model Class Initialized
INFO - 2024-02-12 08:24:30 --> Model Class Initialized
INFO - 2024-02-12 08:24:30 --> Model Class Initialized
INFO - 2024-02-12 08:24:30 --> Model Class Initialized
INFO - 2024-02-12 08:24:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 08:24:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 08:24:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 08:24:30 --> Final output sent to browser
DEBUG - 2024-02-12 08:24:30 --> Total execution time: 0.1741
ERROR - 2024-02-12 08:34:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:34:51 --> Config Class Initialized
INFO - 2024-02-12 08:34:51 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:34:51 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:34:51 --> Utf8 Class Initialized
INFO - 2024-02-12 08:34:51 --> URI Class Initialized
INFO - 2024-02-12 08:34:51 --> Router Class Initialized
INFO - 2024-02-12 08:34:51 --> Output Class Initialized
INFO - 2024-02-12 08:34:51 --> Security Class Initialized
DEBUG - 2024-02-12 08:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:34:51 --> Input Class Initialized
INFO - 2024-02-12 08:34:51 --> Language Class Initialized
INFO - 2024-02-12 08:34:51 --> Loader Class Initialized
INFO - 2024-02-12 08:34:51 --> Helper loaded: url_helper
INFO - 2024-02-12 08:34:51 --> Helper loaded: file_helper
INFO - 2024-02-12 08:34:51 --> Helper loaded: html_helper
INFO - 2024-02-12 08:34:51 --> Helper loaded: text_helper
INFO - 2024-02-12 08:34:51 --> Helper loaded: form_helper
INFO - 2024-02-12 08:34:51 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:34:51 --> Helper loaded: security_helper
INFO - 2024-02-12 08:34:51 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:34:51 --> Database Driver Class Initialized
INFO - 2024-02-12 08:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:34:51 --> Parser Class Initialized
INFO - 2024-02-12 08:34:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:34:51 --> Pagination Class Initialized
INFO - 2024-02-12 08:34:51 --> Form Validation Class Initialized
INFO - 2024-02-12 08:34:51 --> Controller Class Initialized
DEBUG - 2024-02-12 08:34:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:34:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:34:51 --> Model Class Initialized
DEBUG - 2024-02-12 08:34:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:34:51 --> Model Class Initialized
DEBUG - 2024-02-12 08:34:51 --> Auth class already loaded. Second attempt ignored.
ERROR - 2024-02-12 08:34:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 08:34:51 --> Config Class Initialized
INFO - 2024-02-12 08:34:51 --> Hooks Class Initialized
DEBUG - 2024-02-12 08:34:51 --> UTF-8 Support Enabled
INFO - 2024-02-12 08:34:51 --> Utf8 Class Initialized
INFO - 2024-02-12 08:34:51 --> URI Class Initialized
INFO - 2024-02-12 08:34:51 --> Router Class Initialized
INFO - 2024-02-12 08:34:51 --> Output Class Initialized
INFO - 2024-02-12 08:34:51 --> Security Class Initialized
DEBUG - 2024-02-12 08:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 08:34:51 --> Input Class Initialized
INFO - 2024-02-12 08:34:51 --> Language Class Initialized
INFO - 2024-02-12 08:34:51 --> Loader Class Initialized
INFO - 2024-02-12 08:34:51 --> Helper loaded: url_helper
INFO - 2024-02-12 08:34:51 --> Helper loaded: file_helper
INFO - 2024-02-12 08:34:51 --> Helper loaded: html_helper
INFO - 2024-02-12 08:34:51 --> Helper loaded: text_helper
INFO - 2024-02-12 08:34:51 --> Helper loaded: form_helper
INFO - 2024-02-12 08:34:51 --> Helper loaded: lang_helper
INFO - 2024-02-12 08:34:51 --> Helper loaded: security_helper
INFO - 2024-02-12 08:34:51 --> Helper loaded: cookie_helper
INFO - 2024-02-12 08:34:51 --> Database Driver Class Initialized
INFO - 2024-02-12 08:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 08:34:51 --> Parser Class Initialized
INFO - 2024-02-12 08:34:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 08:34:51 --> Pagination Class Initialized
INFO - 2024-02-12 08:34:51 --> Form Validation Class Initialized
INFO - 2024-02-12 08:34:51 --> Controller Class Initialized
DEBUG - 2024-02-12 08:34:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 08:34:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:34:51 --> Model Class Initialized
DEBUG - 2024-02-12 08:34:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:34:51 --> Model Class Initialized
INFO - 2024-02-12 08:34:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2024-02-12 08:34:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 08:34:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 08:34:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 08:34:51 --> Model Class Initialized
INFO - 2024-02-12 08:34:51 --> Model Class Initialized
INFO - 2024-02-12 08:34:51 --> Model Class Initialized
INFO - 2024-02-12 08:34:51 --> Model Class Initialized
INFO - 2024-02-12 08:34:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 08:34:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 08:34:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 08:34:51 --> Final output sent to browser
DEBUG - 2024-02-12 08:34:51 --> Total execution time: 0.1771
ERROR - 2024-02-12 11:05:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 11:05:17 --> Config Class Initialized
INFO - 2024-02-12 11:05:17 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:05:17 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:05:17 --> Utf8 Class Initialized
INFO - 2024-02-12 11:05:17 --> URI Class Initialized
DEBUG - 2024-02-12 11:05:17 --> No URI present. Default controller set.
INFO - 2024-02-12 11:05:17 --> Router Class Initialized
INFO - 2024-02-12 11:05:17 --> Output Class Initialized
INFO - 2024-02-12 11:05:17 --> Security Class Initialized
DEBUG - 2024-02-12 11:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:05:17 --> Input Class Initialized
INFO - 2024-02-12 11:05:17 --> Language Class Initialized
INFO - 2024-02-12 11:05:17 --> Loader Class Initialized
INFO - 2024-02-12 11:05:17 --> Helper loaded: url_helper
INFO - 2024-02-12 11:05:17 --> Helper loaded: file_helper
INFO - 2024-02-12 11:05:17 --> Helper loaded: html_helper
INFO - 2024-02-12 11:05:17 --> Helper loaded: text_helper
INFO - 2024-02-12 11:05:17 --> Helper loaded: form_helper
INFO - 2024-02-12 11:05:17 --> Helper loaded: lang_helper
INFO - 2024-02-12 11:05:17 --> Helper loaded: security_helper
INFO - 2024-02-12 11:05:17 --> Helper loaded: cookie_helper
INFO - 2024-02-12 11:05:17 --> Database Driver Class Initialized
INFO - 2024-02-12 11:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:05:17 --> Parser Class Initialized
INFO - 2024-02-12 11:05:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 11:05:17 --> Pagination Class Initialized
INFO - 2024-02-12 11:05:17 --> Form Validation Class Initialized
INFO - 2024-02-12 11:05:17 --> Controller Class Initialized
INFO - 2024-02-12 11:05:17 --> Model Class Initialized
DEBUG - 2024-02-12 11:05:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-12 11:09:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 11:09:33 --> Config Class Initialized
INFO - 2024-02-12 11:09:33 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:09:33 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:09:33 --> Utf8 Class Initialized
INFO - 2024-02-12 11:09:33 --> URI Class Initialized
INFO - 2024-02-12 11:09:33 --> Router Class Initialized
INFO - 2024-02-12 11:09:33 --> Output Class Initialized
INFO - 2024-02-12 11:09:33 --> Security Class Initialized
DEBUG - 2024-02-12 11:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:09:33 --> Input Class Initialized
INFO - 2024-02-12 11:09:33 --> Language Class Initialized
ERROR - 2024-02-12 11:09:33 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-02-12 11:51:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 11:51:19 --> Config Class Initialized
INFO - 2024-02-12 11:51:19 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:51:19 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:51:19 --> Utf8 Class Initialized
INFO - 2024-02-12 11:51:19 --> URI Class Initialized
DEBUG - 2024-02-12 11:51:19 --> No URI present. Default controller set.
INFO - 2024-02-12 11:51:19 --> Router Class Initialized
INFO - 2024-02-12 11:51:19 --> Output Class Initialized
INFO - 2024-02-12 11:51:19 --> Security Class Initialized
DEBUG - 2024-02-12 11:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:51:19 --> Input Class Initialized
INFO - 2024-02-12 11:51:19 --> Language Class Initialized
INFO - 2024-02-12 11:51:19 --> Loader Class Initialized
INFO - 2024-02-12 11:51:19 --> Helper loaded: url_helper
INFO - 2024-02-12 11:51:19 --> Helper loaded: file_helper
INFO - 2024-02-12 11:51:19 --> Helper loaded: html_helper
INFO - 2024-02-12 11:51:19 --> Helper loaded: text_helper
INFO - 2024-02-12 11:51:19 --> Helper loaded: form_helper
INFO - 2024-02-12 11:51:19 --> Helper loaded: lang_helper
INFO - 2024-02-12 11:51:19 --> Helper loaded: security_helper
INFO - 2024-02-12 11:51:19 --> Helper loaded: cookie_helper
INFO - 2024-02-12 11:51:19 --> Database Driver Class Initialized
INFO - 2024-02-12 11:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:51:19 --> Parser Class Initialized
INFO - 2024-02-12 11:51:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 11:51:19 --> Pagination Class Initialized
INFO - 2024-02-12 11:51:19 --> Form Validation Class Initialized
INFO - 2024-02-12 11:51:19 --> Controller Class Initialized
INFO - 2024-02-12 11:51:19 --> Model Class Initialized
DEBUG - 2024-02-12 11:51:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-12 11:51:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 11:51:20 --> Config Class Initialized
INFO - 2024-02-12 11:51:20 --> Hooks Class Initialized
DEBUG - 2024-02-12 11:51:20 --> UTF-8 Support Enabled
INFO - 2024-02-12 11:51:20 --> Utf8 Class Initialized
INFO - 2024-02-12 11:51:20 --> URI Class Initialized
INFO - 2024-02-12 11:51:20 --> Router Class Initialized
INFO - 2024-02-12 11:51:20 --> Output Class Initialized
INFO - 2024-02-12 11:51:20 --> Security Class Initialized
DEBUG - 2024-02-12 11:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 11:51:20 --> Input Class Initialized
INFO - 2024-02-12 11:51:20 --> Language Class Initialized
INFO - 2024-02-12 11:51:20 --> Loader Class Initialized
INFO - 2024-02-12 11:51:20 --> Helper loaded: url_helper
INFO - 2024-02-12 11:51:20 --> Helper loaded: file_helper
INFO - 2024-02-12 11:51:20 --> Helper loaded: html_helper
INFO - 2024-02-12 11:51:20 --> Helper loaded: text_helper
INFO - 2024-02-12 11:51:20 --> Helper loaded: form_helper
INFO - 2024-02-12 11:51:20 --> Helper loaded: lang_helper
INFO - 2024-02-12 11:51:20 --> Helper loaded: security_helper
INFO - 2024-02-12 11:51:20 --> Helper loaded: cookie_helper
INFO - 2024-02-12 11:51:20 --> Database Driver Class Initialized
INFO - 2024-02-12 11:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 11:51:20 --> Parser Class Initialized
INFO - 2024-02-12 11:51:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 11:51:20 --> Pagination Class Initialized
INFO - 2024-02-12 11:51:20 --> Form Validation Class Initialized
INFO - 2024-02-12 11:51:20 --> Controller Class Initialized
INFO - 2024-02-12 11:51:20 --> Model Class Initialized
DEBUG - 2024-02-12 11:51:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 11:51:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-12 11:51:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 11:51:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 11:51:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 11:51:20 --> Model Class Initialized
INFO - 2024-02-12 11:51:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 11:51:20 --> Final output sent to browser
DEBUG - 2024-02-12 11:51:20 --> Total execution time: 0.0337
ERROR - 2024-02-12 12:28:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 12:28:53 --> Config Class Initialized
INFO - 2024-02-12 12:28:53 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:28:53 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:28:53 --> Utf8 Class Initialized
INFO - 2024-02-12 12:28:53 --> URI Class Initialized
DEBUG - 2024-02-12 12:28:53 --> No URI present. Default controller set.
INFO - 2024-02-12 12:28:53 --> Router Class Initialized
INFO - 2024-02-12 12:28:53 --> Output Class Initialized
INFO - 2024-02-12 12:28:53 --> Security Class Initialized
DEBUG - 2024-02-12 12:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:28:53 --> Input Class Initialized
INFO - 2024-02-12 12:28:53 --> Language Class Initialized
INFO - 2024-02-12 12:28:53 --> Loader Class Initialized
INFO - 2024-02-12 12:28:53 --> Helper loaded: url_helper
INFO - 2024-02-12 12:28:53 --> Helper loaded: file_helper
INFO - 2024-02-12 12:28:53 --> Helper loaded: html_helper
INFO - 2024-02-12 12:28:53 --> Helper loaded: text_helper
INFO - 2024-02-12 12:28:53 --> Helper loaded: form_helper
INFO - 2024-02-12 12:28:53 --> Helper loaded: lang_helper
INFO - 2024-02-12 12:28:53 --> Helper loaded: security_helper
INFO - 2024-02-12 12:28:53 --> Helper loaded: cookie_helper
INFO - 2024-02-12 12:28:53 --> Database Driver Class Initialized
INFO - 2024-02-12 12:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:28:53 --> Parser Class Initialized
INFO - 2024-02-12 12:28:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 12:28:53 --> Pagination Class Initialized
INFO - 2024-02-12 12:28:53 --> Form Validation Class Initialized
INFO - 2024-02-12 12:28:53 --> Controller Class Initialized
INFO - 2024-02-12 12:28:53 --> Model Class Initialized
DEBUG - 2024-02-12 12:28:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-12 12:28:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 12:28:53 --> Config Class Initialized
INFO - 2024-02-12 12:28:53 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:28:53 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:28:53 --> Utf8 Class Initialized
INFO - 2024-02-12 12:28:53 --> URI Class Initialized
INFO - 2024-02-12 12:28:53 --> Router Class Initialized
INFO - 2024-02-12 12:28:53 --> Output Class Initialized
INFO - 2024-02-12 12:28:53 --> Security Class Initialized
DEBUG - 2024-02-12 12:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:28:53 --> Input Class Initialized
INFO - 2024-02-12 12:28:53 --> Language Class Initialized
INFO - 2024-02-12 12:28:53 --> Loader Class Initialized
INFO - 2024-02-12 12:28:53 --> Helper loaded: url_helper
INFO - 2024-02-12 12:28:53 --> Helper loaded: file_helper
INFO - 2024-02-12 12:28:53 --> Helper loaded: html_helper
INFO - 2024-02-12 12:28:53 --> Helper loaded: text_helper
INFO - 2024-02-12 12:28:53 --> Helper loaded: form_helper
INFO - 2024-02-12 12:28:53 --> Helper loaded: lang_helper
INFO - 2024-02-12 12:28:53 --> Helper loaded: security_helper
INFO - 2024-02-12 12:28:53 --> Helper loaded: cookie_helper
INFO - 2024-02-12 12:28:53 --> Database Driver Class Initialized
INFO - 2024-02-12 12:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:28:53 --> Parser Class Initialized
INFO - 2024-02-12 12:28:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 12:28:53 --> Pagination Class Initialized
INFO - 2024-02-12 12:28:53 --> Form Validation Class Initialized
INFO - 2024-02-12 12:28:53 --> Controller Class Initialized
INFO - 2024-02-12 12:28:53 --> Model Class Initialized
DEBUG - 2024-02-12 12:28:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 12:28:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-12 12:28:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 12:28:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 12:28:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 12:28:53 --> Model Class Initialized
INFO - 2024-02-12 12:28:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 12:28:53 --> Final output sent to browser
DEBUG - 2024-02-12 12:28:53 --> Total execution time: 0.0342
ERROR - 2024-02-12 12:29:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 12:29:03 --> Config Class Initialized
INFO - 2024-02-12 12:29:03 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:29:03 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:29:03 --> Utf8 Class Initialized
INFO - 2024-02-12 12:29:03 --> URI Class Initialized
INFO - 2024-02-12 12:29:03 --> Router Class Initialized
INFO - 2024-02-12 12:29:03 --> Output Class Initialized
INFO - 2024-02-12 12:29:03 --> Security Class Initialized
DEBUG - 2024-02-12 12:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:29:03 --> Input Class Initialized
INFO - 2024-02-12 12:29:03 --> Language Class Initialized
INFO - 2024-02-12 12:29:03 --> Loader Class Initialized
INFO - 2024-02-12 12:29:03 --> Helper loaded: url_helper
INFO - 2024-02-12 12:29:03 --> Helper loaded: file_helper
INFO - 2024-02-12 12:29:03 --> Helper loaded: html_helper
INFO - 2024-02-12 12:29:03 --> Helper loaded: text_helper
INFO - 2024-02-12 12:29:03 --> Helper loaded: form_helper
INFO - 2024-02-12 12:29:03 --> Helper loaded: lang_helper
INFO - 2024-02-12 12:29:03 --> Helper loaded: security_helper
INFO - 2024-02-12 12:29:03 --> Helper loaded: cookie_helper
INFO - 2024-02-12 12:29:03 --> Database Driver Class Initialized
INFO - 2024-02-12 12:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:29:03 --> Parser Class Initialized
INFO - 2024-02-12 12:29:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 12:29:03 --> Pagination Class Initialized
INFO - 2024-02-12 12:29:03 --> Form Validation Class Initialized
INFO - 2024-02-12 12:29:03 --> Controller Class Initialized
INFO - 2024-02-12 12:29:03 --> Model Class Initialized
DEBUG - 2024-02-12 12:29:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 12:29:03 --> Model Class Initialized
INFO - 2024-02-12 12:29:03 --> Final output sent to browser
DEBUG - 2024-02-12 12:29:03 --> Total execution time: 0.0207
ERROR - 2024-02-12 12:29:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 12:29:03 --> Config Class Initialized
INFO - 2024-02-12 12:29:03 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:29:03 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:29:03 --> Utf8 Class Initialized
INFO - 2024-02-12 12:29:03 --> URI Class Initialized
DEBUG - 2024-02-12 12:29:03 --> No URI present. Default controller set.
INFO - 2024-02-12 12:29:03 --> Router Class Initialized
INFO - 2024-02-12 12:29:03 --> Output Class Initialized
INFO - 2024-02-12 12:29:03 --> Security Class Initialized
DEBUG - 2024-02-12 12:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:29:03 --> Input Class Initialized
INFO - 2024-02-12 12:29:03 --> Language Class Initialized
INFO - 2024-02-12 12:29:03 --> Loader Class Initialized
INFO - 2024-02-12 12:29:03 --> Helper loaded: url_helper
INFO - 2024-02-12 12:29:03 --> Helper loaded: file_helper
INFO - 2024-02-12 12:29:03 --> Helper loaded: html_helper
INFO - 2024-02-12 12:29:03 --> Helper loaded: text_helper
INFO - 2024-02-12 12:29:03 --> Helper loaded: form_helper
INFO - 2024-02-12 12:29:03 --> Helper loaded: lang_helper
INFO - 2024-02-12 12:29:03 --> Helper loaded: security_helper
INFO - 2024-02-12 12:29:03 --> Helper loaded: cookie_helper
INFO - 2024-02-12 12:29:03 --> Database Driver Class Initialized
INFO - 2024-02-12 12:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:29:03 --> Parser Class Initialized
INFO - 2024-02-12 12:29:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 12:29:03 --> Pagination Class Initialized
INFO - 2024-02-12 12:29:03 --> Form Validation Class Initialized
INFO - 2024-02-12 12:29:03 --> Controller Class Initialized
INFO - 2024-02-12 12:29:03 --> Model Class Initialized
DEBUG - 2024-02-12 12:29:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 12:29:03 --> Model Class Initialized
DEBUG - 2024-02-12 12:29:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 12:29:03 --> Model Class Initialized
INFO - 2024-02-12 12:29:03 --> Model Class Initialized
INFO - 2024-02-12 12:29:03 --> Model Class Initialized
INFO - 2024-02-12 12:29:03 --> Model Class Initialized
DEBUG - 2024-02-12 12:29:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 12:29:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 12:29:03 --> Model Class Initialized
INFO - 2024-02-12 12:29:03 --> Model Class Initialized
INFO - 2024-02-12 12:29:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-12 12:29:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 12:29:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 12:29:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 12:29:03 --> Model Class Initialized
INFO - 2024-02-12 12:29:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 12:29:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 12:29:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 12:29:03 --> Final output sent to browser
DEBUG - 2024-02-12 12:29:03 --> Total execution time: 0.2562
ERROR - 2024-02-12 12:29:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 12:29:09 --> Config Class Initialized
INFO - 2024-02-12 12:29:09 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:29:09 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:29:09 --> Utf8 Class Initialized
INFO - 2024-02-12 12:29:09 --> URI Class Initialized
INFO - 2024-02-12 12:29:09 --> Router Class Initialized
INFO - 2024-02-12 12:29:09 --> Output Class Initialized
INFO - 2024-02-12 12:29:09 --> Security Class Initialized
DEBUG - 2024-02-12 12:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:29:09 --> Input Class Initialized
INFO - 2024-02-12 12:29:09 --> Language Class Initialized
INFO - 2024-02-12 12:29:09 --> Loader Class Initialized
INFO - 2024-02-12 12:29:09 --> Helper loaded: url_helper
INFO - 2024-02-12 12:29:09 --> Helper loaded: file_helper
INFO - 2024-02-12 12:29:09 --> Helper loaded: html_helper
INFO - 2024-02-12 12:29:09 --> Helper loaded: text_helper
INFO - 2024-02-12 12:29:09 --> Helper loaded: form_helper
INFO - 2024-02-12 12:29:09 --> Helper loaded: lang_helper
INFO - 2024-02-12 12:29:09 --> Helper loaded: security_helper
INFO - 2024-02-12 12:29:09 --> Helper loaded: cookie_helper
INFO - 2024-02-12 12:29:09 --> Database Driver Class Initialized
INFO - 2024-02-12 12:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:29:09 --> Parser Class Initialized
INFO - 2024-02-12 12:29:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 12:29:09 --> Pagination Class Initialized
INFO - 2024-02-12 12:29:09 --> Form Validation Class Initialized
INFO - 2024-02-12 12:29:09 --> Controller Class Initialized
INFO - 2024-02-12 12:29:09 --> Model Class Initialized
DEBUG - 2024-02-12 12:29:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 12:29:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 12:29:09 --> Model Class Initialized
DEBUG - 2024-02-12 12:29:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 12:29:09 --> Model Class Initialized
INFO - 2024-02-12 12:29:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-12 12:29:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 12:29:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 12:29:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 12:29:09 --> Model Class Initialized
INFO - 2024-02-12 12:29:09 --> Model Class Initialized
INFO - 2024-02-12 12:29:09 --> Model Class Initialized
INFO - 2024-02-12 12:29:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 12:29:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 12:29:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 12:29:09 --> Final output sent to browser
DEBUG - 2024-02-12 12:29:09 --> Total execution time: 0.1447
ERROR - 2024-02-12 12:29:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 12:29:10 --> Config Class Initialized
INFO - 2024-02-12 12:29:10 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:29:10 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:29:10 --> Utf8 Class Initialized
INFO - 2024-02-12 12:29:10 --> URI Class Initialized
INFO - 2024-02-12 12:29:10 --> Router Class Initialized
INFO - 2024-02-12 12:29:10 --> Output Class Initialized
INFO - 2024-02-12 12:29:10 --> Security Class Initialized
DEBUG - 2024-02-12 12:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:29:10 --> Input Class Initialized
INFO - 2024-02-12 12:29:10 --> Language Class Initialized
INFO - 2024-02-12 12:29:10 --> Loader Class Initialized
INFO - 2024-02-12 12:29:10 --> Helper loaded: url_helper
INFO - 2024-02-12 12:29:10 --> Helper loaded: file_helper
INFO - 2024-02-12 12:29:10 --> Helper loaded: html_helper
INFO - 2024-02-12 12:29:10 --> Helper loaded: text_helper
INFO - 2024-02-12 12:29:10 --> Helper loaded: form_helper
INFO - 2024-02-12 12:29:10 --> Helper loaded: lang_helper
INFO - 2024-02-12 12:29:10 --> Helper loaded: security_helper
INFO - 2024-02-12 12:29:10 --> Helper loaded: cookie_helper
INFO - 2024-02-12 12:29:10 --> Database Driver Class Initialized
INFO - 2024-02-12 12:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:29:10 --> Parser Class Initialized
INFO - 2024-02-12 12:29:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 12:29:10 --> Pagination Class Initialized
INFO - 2024-02-12 12:29:10 --> Form Validation Class Initialized
INFO - 2024-02-12 12:29:10 --> Controller Class Initialized
INFO - 2024-02-12 12:29:10 --> Model Class Initialized
DEBUG - 2024-02-12 12:29:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 12:29:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 12:29:10 --> Model Class Initialized
DEBUG - 2024-02-12 12:29:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 12:29:10 --> Model Class Initialized
INFO - 2024-02-12 12:29:10 --> Final output sent to browser
DEBUG - 2024-02-12 12:29:10 --> Total execution time: 0.0404
ERROR - 2024-02-12 12:29:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 12:29:13 --> Config Class Initialized
INFO - 2024-02-12 12:29:13 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:29:13 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:29:13 --> Utf8 Class Initialized
INFO - 2024-02-12 12:29:13 --> URI Class Initialized
INFO - 2024-02-12 12:29:13 --> Router Class Initialized
INFO - 2024-02-12 12:29:13 --> Output Class Initialized
INFO - 2024-02-12 12:29:13 --> Security Class Initialized
DEBUG - 2024-02-12 12:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:29:13 --> Input Class Initialized
INFO - 2024-02-12 12:29:13 --> Language Class Initialized
INFO - 2024-02-12 12:29:13 --> Loader Class Initialized
INFO - 2024-02-12 12:29:13 --> Helper loaded: url_helper
INFO - 2024-02-12 12:29:13 --> Helper loaded: file_helper
INFO - 2024-02-12 12:29:13 --> Helper loaded: html_helper
INFO - 2024-02-12 12:29:13 --> Helper loaded: text_helper
INFO - 2024-02-12 12:29:13 --> Helper loaded: form_helper
INFO - 2024-02-12 12:29:13 --> Helper loaded: lang_helper
INFO - 2024-02-12 12:29:13 --> Helper loaded: security_helper
INFO - 2024-02-12 12:29:13 --> Helper loaded: cookie_helper
INFO - 2024-02-12 12:29:13 --> Database Driver Class Initialized
INFO - 2024-02-12 12:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:29:13 --> Parser Class Initialized
INFO - 2024-02-12 12:29:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 12:29:13 --> Pagination Class Initialized
INFO - 2024-02-12 12:29:13 --> Form Validation Class Initialized
INFO - 2024-02-12 12:29:13 --> Controller Class Initialized
INFO - 2024-02-12 12:29:13 --> Model Class Initialized
DEBUG - 2024-02-12 12:29:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 12:29:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 12:29:13 --> Model Class Initialized
DEBUG - 2024-02-12 12:29:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 12:29:13 --> Model Class Initialized
INFO - 2024-02-12 12:29:13 --> Final output sent to browser
DEBUG - 2024-02-12 12:29:13 --> Total execution time: 0.1201
ERROR - 2024-02-12 12:29:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 12:29:21 --> Config Class Initialized
INFO - 2024-02-12 12:29:21 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:29:21 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:29:21 --> Utf8 Class Initialized
INFO - 2024-02-12 12:29:21 --> URI Class Initialized
INFO - 2024-02-12 12:29:21 --> Router Class Initialized
INFO - 2024-02-12 12:29:21 --> Output Class Initialized
INFO - 2024-02-12 12:29:21 --> Security Class Initialized
DEBUG - 2024-02-12 12:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:29:21 --> Input Class Initialized
INFO - 2024-02-12 12:29:21 --> Language Class Initialized
INFO - 2024-02-12 12:29:21 --> Loader Class Initialized
INFO - 2024-02-12 12:29:21 --> Helper loaded: url_helper
INFO - 2024-02-12 12:29:21 --> Helper loaded: file_helper
INFO - 2024-02-12 12:29:21 --> Helper loaded: html_helper
INFO - 2024-02-12 12:29:21 --> Helper loaded: text_helper
INFO - 2024-02-12 12:29:21 --> Helper loaded: form_helper
INFO - 2024-02-12 12:29:21 --> Helper loaded: lang_helper
INFO - 2024-02-12 12:29:21 --> Helper loaded: security_helper
INFO - 2024-02-12 12:29:21 --> Helper loaded: cookie_helper
INFO - 2024-02-12 12:29:21 --> Database Driver Class Initialized
INFO - 2024-02-12 12:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:29:21 --> Parser Class Initialized
INFO - 2024-02-12 12:29:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 12:29:21 --> Pagination Class Initialized
INFO - 2024-02-12 12:29:21 --> Form Validation Class Initialized
INFO - 2024-02-12 12:29:21 --> Controller Class Initialized
INFO - 2024-02-12 12:29:21 --> Model Class Initialized
DEBUG - 2024-02-12 12:29:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 12:29:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 12:29:21 --> Model Class Initialized
DEBUG - 2024-02-12 12:29:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 12:29:21 --> Model Class Initialized
DEBUG - 2024-02-12 12:29:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 12:29:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-02-12 12:29:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 12:29:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 12:29:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 12:29:21 --> Model Class Initialized
INFO - 2024-02-12 12:29:21 --> Model Class Initialized
INFO - 2024-02-12 12:29:21 --> Model Class Initialized
INFO - 2024-02-12 12:29:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 12:29:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 12:29:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 12:29:22 --> Final output sent to browser
DEBUG - 2024-02-12 12:29:22 --> Total execution time: 0.1472
ERROR - 2024-02-12 12:30:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 12:30:15 --> Config Class Initialized
INFO - 2024-02-12 12:30:15 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:30:15 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:30:15 --> Utf8 Class Initialized
INFO - 2024-02-12 12:30:15 --> URI Class Initialized
INFO - 2024-02-12 12:30:15 --> Router Class Initialized
INFO - 2024-02-12 12:30:15 --> Output Class Initialized
INFO - 2024-02-12 12:30:15 --> Security Class Initialized
DEBUG - 2024-02-12 12:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:30:15 --> Input Class Initialized
INFO - 2024-02-12 12:30:15 --> Language Class Initialized
INFO - 2024-02-12 12:30:15 --> Loader Class Initialized
INFO - 2024-02-12 12:30:15 --> Helper loaded: url_helper
INFO - 2024-02-12 12:30:15 --> Helper loaded: file_helper
INFO - 2024-02-12 12:30:15 --> Helper loaded: html_helper
INFO - 2024-02-12 12:30:15 --> Helper loaded: text_helper
INFO - 2024-02-12 12:30:15 --> Helper loaded: form_helper
INFO - 2024-02-12 12:30:15 --> Helper loaded: lang_helper
INFO - 2024-02-12 12:30:15 --> Helper loaded: security_helper
INFO - 2024-02-12 12:30:15 --> Helper loaded: cookie_helper
INFO - 2024-02-12 12:30:15 --> Database Driver Class Initialized
INFO - 2024-02-12 12:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:30:15 --> Parser Class Initialized
INFO - 2024-02-12 12:30:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 12:30:15 --> Pagination Class Initialized
INFO - 2024-02-12 12:30:15 --> Form Validation Class Initialized
INFO - 2024-02-12 12:30:15 --> Controller Class Initialized
INFO - 2024-02-12 12:30:15 --> Model Class Initialized
DEBUG - 2024-02-12 12:30:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 12:30:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 12:30:15 --> Model Class Initialized
DEBUG - 2024-02-12 12:30:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 12:30:15 --> Model Class Initialized
INFO - 2024-02-12 12:30:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-12 12:30:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 12:30:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 12:30:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 12:30:15 --> Model Class Initialized
INFO - 2024-02-12 12:30:15 --> Model Class Initialized
INFO - 2024-02-12 12:30:15 --> Model Class Initialized
ERROR - 2024-02-12 12:30:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 12:30:15 --> Config Class Initialized
INFO - 2024-02-12 12:30:15 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:30:15 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:30:15 --> Utf8 Class Initialized
INFO - 2024-02-12 12:30:15 --> URI Class Initialized
DEBUG - 2024-02-12 12:30:15 --> No URI present. Default controller set.
INFO - 2024-02-12 12:30:15 --> Router Class Initialized
INFO - 2024-02-12 12:30:15 --> Output Class Initialized
INFO - 2024-02-12 12:30:15 --> Security Class Initialized
DEBUG - 2024-02-12 12:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:30:15 --> Input Class Initialized
INFO - 2024-02-12 12:30:15 --> Language Class Initialized
INFO - 2024-02-12 12:30:15 --> Loader Class Initialized
INFO - 2024-02-12 12:30:15 --> Helper loaded: url_helper
INFO - 2024-02-12 12:30:15 --> Helper loaded: file_helper
INFO - 2024-02-12 12:30:15 --> Helper loaded: html_helper
INFO - 2024-02-12 12:30:15 --> Helper loaded: text_helper
INFO - 2024-02-12 12:30:15 --> Helper loaded: form_helper
INFO - 2024-02-12 12:30:15 --> Helper loaded: lang_helper
INFO - 2024-02-12 12:30:15 --> Helper loaded: security_helper
INFO - 2024-02-12 12:30:15 --> Helper loaded: cookie_helper
INFO - 2024-02-12 12:30:15 --> Database Driver Class Initialized
INFO - 2024-02-12 12:30:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 12:30:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 12:30:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 12:30:15 --> Final output sent to browser
DEBUG - 2024-02-12 12:30:15 --> Total execution time: 0.1626
INFO - 2024-02-12 12:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:30:15 --> Parser Class Initialized
INFO - 2024-02-12 12:30:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 12:30:15 --> Pagination Class Initialized
INFO - 2024-02-12 12:30:15 --> Form Validation Class Initialized
INFO - 2024-02-12 12:30:15 --> Controller Class Initialized
INFO - 2024-02-12 12:30:15 --> Model Class Initialized
DEBUG - 2024-02-12 12:30:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 12:30:15 --> Model Class Initialized
DEBUG - 2024-02-12 12:30:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 12:30:15 --> Model Class Initialized
INFO - 2024-02-12 12:30:15 --> Model Class Initialized
INFO - 2024-02-12 12:30:15 --> Model Class Initialized
INFO - 2024-02-12 12:30:15 --> Model Class Initialized
DEBUG - 2024-02-12 12:30:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 12:30:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 12:30:15 --> Model Class Initialized
INFO - 2024-02-12 12:30:15 --> Model Class Initialized
ERROR - 2024-02-12 12:30:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 12:30:16 --> Config Class Initialized
INFO - 2024-02-12 12:30:16 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:30:16 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:30:16 --> Utf8 Class Initialized
INFO - 2024-02-12 12:30:16 --> URI Class Initialized
INFO - 2024-02-12 12:30:16 --> Router Class Initialized
INFO - 2024-02-12 12:30:16 --> Output Class Initialized
INFO - 2024-02-12 12:30:16 --> Security Class Initialized
DEBUG - 2024-02-12 12:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:30:16 --> Input Class Initialized
INFO - 2024-02-12 12:30:16 --> Language Class Initialized
INFO - 2024-02-12 12:30:16 --> Loader Class Initialized
INFO - 2024-02-12 12:30:16 --> Helper loaded: url_helper
INFO - 2024-02-12 12:30:16 --> Helper loaded: file_helper
INFO - 2024-02-12 12:30:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
INFO - 2024-02-12 12:30:16 --> Helper loaded: html_helper
INFO - 2024-02-12 12:30:16 --> Helper loaded: text_helper
DEBUG - 2024-02-12 12:30:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 12:30:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 12:30:16 --> Helper loaded: form_helper
INFO - 2024-02-12 12:30:16 --> Helper loaded: lang_helper
INFO - 2024-02-12 12:30:16 --> Helper loaded: security_helper
INFO - 2024-02-12 12:30:16 --> Helper loaded: cookie_helper
INFO - 2024-02-12 12:30:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 12:30:16 --> Database Driver Class Initialized
INFO - 2024-02-12 12:30:16 --> Model Class Initialized
INFO - 2024-02-12 12:30:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 12:30:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 12:30:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 12:30:16 --> Final output sent to browser
DEBUG - 2024-02-12 12:30:16 --> Total execution time: 0.2644
INFO - 2024-02-12 12:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:30:16 --> Parser Class Initialized
INFO - 2024-02-12 12:30:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 12:30:16 --> Pagination Class Initialized
INFO - 2024-02-12 12:30:16 --> Form Validation Class Initialized
INFO - 2024-02-12 12:30:16 --> Controller Class Initialized
INFO - 2024-02-12 12:30:16 --> Model Class Initialized
DEBUG - 2024-02-12 12:30:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 12:30:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-12 12:30:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 12:30:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 12:30:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 12:30:16 --> Model Class Initialized
INFO - 2024-02-12 12:30:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 12:30:16 --> Final output sent to browser
DEBUG - 2024-02-12 12:30:16 --> Total execution time: 0.1407
ERROR - 2024-02-12 12:30:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 12:30:16 --> Config Class Initialized
INFO - 2024-02-12 12:30:16 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:30:16 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:30:16 --> Utf8 Class Initialized
INFO - 2024-02-12 12:30:16 --> URI Class Initialized
INFO - 2024-02-12 12:30:16 --> Router Class Initialized
INFO - 2024-02-12 12:30:16 --> Output Class Initialized
INFO - 2024-02-12 12:30:16 --> Security Class Initialized
DEBUG - 2024-02-12 12:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:30:16 --> Input Class Initialized
INFO - 2024-02-12 12:30:16 --> Language Class Initialized
INFO - 2024-02-12 12:30:16 --> Loader Class Initialized
INFO - 2024-02-12 12:30:16 --> Helper loaded: url_helper
INFO - 2024-02-12 12:30:16 --> Helper loaded: file_helper
INFO - 2024-02-12 12:30:16 --> Helper loaded: html_helper
INFO - 2024-02-12 12:30:16 --> Helper loaded: text_helper
INFO - 2024-02-12 12:30:16 --> Helper loaded: form_helper
INFO - 2024-02-12 12:30:16 --> Helper loaded: lang_helper
INFO - 2024-02-12 12:30:16 --> Helper loaded: security_helper
INFO - 2024-02-12 12:30:16 --> Helper loaded: cookie_helper
INFO - 2024-02-12 12:30:16 --> Database Driver Class Initialized
INFO - 2024-02-12 12:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:30:16 --> Parser Class Initialized
INFO - 2024-02-12 12:30:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 12:30:16 --> Pagination Class Initialized
INFO - 2024-02-12 12:30:16 --> Form Validation Class Initialized
INFO - 2024-02-12 12:30:16 --> Controller Class Initialized
INFO - 2024-02-12 12:30:16 --> Model Class Initialized
DEBUG - 2024-02-12 12:30:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 12:30:16 --> Model Class Initialized
DEBUG - 2024-02-12 12:30:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 12:30:16 --> Model Class Initialized
INFO - 2024-02-12 12:30:16 --> Model Class Initialized
INFO - 2024-02-12 12:30:16 --> Model Class Initialized
INFO - 2024-02-12 12:30:16 --> Model Class Initialized
DEBUG - 2024-02-12 12:30:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 12:30:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 12:30:16 --> Model Class Initialized
INFO - 2024-02-12 12:30:16 --> Model Class Initialized
INFO - 2024-02-12 12:30:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-12 12:30:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 12:30:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 12:30:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 12:30:16 --> Model Class Initialized
INFO - 2024-02-12 12:30:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 12:30:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 12:30:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 12:30:16 --> Final output sent to browser
DEBUG - 2024-02-12 12:30:16 --> Total execution time: 0.2310
ERROR - 2024-02-12 12:55:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 12:55:03 --> Config Class Initialized
INFO - 2024-02-12 12:55:03 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:55:03 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:55:03 --> Utf8 Class Initialized
INFO - 2024-02-12 12:55:03 --> URI Class Initialized
INFO - 2024-02-12 12:55:03 --> Router Class Initialized
INFO - 2024-02-12 12:55:03 --> Output Class Initialized
INFO - 2024-02-12 12:55:03 --> Security Class Initialized
DEBUG - 2024-02-12 12:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:55:03 --> Input Class Initialized
INFO - 2024-02-12 12:55:03 --> Language Class Initialized
INFO - 2024-02-12 12:55:03 --> Loader Class Initialized
INFO - 2024-02-12 12:55:03 --> Helper loaded: url_helper
INFO - 2024-02-12 12:55:03 --> Helper loaded: file_helper
INFO - 2024-02-12 12:55:03 --> Helper loaded: html_helper
INFO - 2024-02-12 12:55:03 --> Helper loaded: text_helper
INFO - 2024-02-12 12:55:03 --> Helper loaded: form_helper
INFO - 2024-02-12 12:55:03 --> Helper loaded: lang_helper
INFO - 2024-02-12 12:55:03 --> Helper loaded: security_helper
INFO - 2024-02-12 12:55:03 --> Helper loaded: cookie_helper
INFO - 2024-02-12 12:55:03 --> Database Driver Class Initialized
INFO - 2024-02-12 12:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:55:03 --> Parser Class Initialized
INFO - 2024-02-12 12:55:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 12:55:03 --> Pagination Class Initialized
INFO - 2024-02-12 12:55:03 --> Form Validation Class Initialized
INFO - 2024-02-12 12:55:03 --> Controller Class Initialized
INFO - 2024-02-12 12:55:03 --> Model Class Initialized
DEBUG - 2024-02-12 12:55:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 12:55:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 12:55:03 --> Model Class Initialized
DEBUG - 2024-02-12 12:55:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 12:55:03 --> Model Class Initialized
INFO - 2024-02-12 12:55:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-12 12:55:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 12:55:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 12:55:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 12:55:03 --> Model Class Initialized
INFO - 2024-02-12 12:55:03 --> Model Class Initialized
INFO - 2024-02-12 12:55:03 --> Model Class Initialized
INFO - 2024-02-12 12:55:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 12:55:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 12:55:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 12:55:03 --> Final output sent to browser
DEBUG - 2024-02-12 12:55:03 --> Total execution time: 0.1587
ERROR - 2024-02-12 12:55:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 12:55:05 --> Config Class Initialized
INFO - 2024-02-12 12:55:05 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:55:05 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:55:05 --> Utf8 Class Initialized
INFO - 2024-02-12 12:55:05 --> URI Class Initialized
INFO - 2024-02-12 12:55:05 --> Router Class Initialized
INFO - 2024-02-12 12:55:05 --> Output Class Initialized
INFO - 2024-02-12 12:55:05 --> Security Class Initialized
DEBUG - 2024-02-12 12:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:55:05 --> Input Class Initialized
INFO - 2024-02-12 12:55:05 --> Language Class Initialized
INFO - 2024-02-12 12:55:05 --> Loader Class Initialized
INFO - 2024-02-12 12:55:05 --> Helper loaded: url_helper
INFO - 2024-02-12 12:55:05 --> Helper loaded: file_helper
INFO - 2024-02-12 12:55:05 --> Helper loaded: html_helper
INFO - 2024-02-12 12:55:05 --> Helper loaded: text_helper
INFO - 2024-02-12 12:55:05 --> Helper loaded: form_helper
INFO - 2024-02-12 12:55:05 --> Helper loaded: lang_helper
INFO - 2024-02-12 12:55:05 --> Helper loaded: security_helper
INFO - 2024-02-12 12:55:05 --> Helper loaded: cookie_helper
INFO - 2024-02-12 12:55:05 --> Database Driver Class Initialized
INFO - 2024-02-12 12:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:55:05 --> Parser Class Initialized
INFO - 2024-02-12 12:55:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 12:55:05 --> Pagination Class Initialized
INFO - 2024-02-12 12:55:05 --> Form Validation Class Initialized
INFO - 2024-02-12 12:55:05 --> Controller Class Initialized
INFO - 2024-02-12 12:55:05 --> Model Class Initialized
DEBUG - 2024-02-12 12:55:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 12:55:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 12:55:05 --> Model Class Initialized
DEBUG - 2024-02-12 12:55:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 12:55:05 --> Model Class Initialized
INFO - 2024-02-12 12:55:05 --> Final output sent to browser
DEBUG - 2024-02-12 12:55:05 --> Total execution time: 0.0467
ERROR - 2024-02-12 12:55:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 12:55:11 --> Config Class Initialized
INFO - 2024-02-12 12:55:11 --> Hooks Class Initialized
DEBUG - 2024-02-12 12:55:11 --> UTF-8 Support Enabled
INFO - 2024-02-12 12:55:11 --> Utf8 Class Initialized
INFO - 2024-02-12 12:55:11 --> URI Class Initialized
INFO - 2024-02-12 12:55:11 --> Router Class Initialized
INFO - 2024-02-12 12:55:11 --> Output Class Initialized
INFO - 2024-02-12 12:55:11 --> Security Class Initialized
DEBUG - 2024-02-12 12:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 12:55:11 --> Input Class Initialized
INFO - 2024-02-12 12:55:11 --> Language Class Initialized
INFO - 2024-02-12 12:55:11 --> Loader Class Initialized
INFO - 2024-02-12 12:55:11 --> Helper loaded: url_helper
INFO - 2024-02-12 12:55:11 --> Helper loaded: file_helper
INFO - 2024-02-12 12:55:11 --> Helper loaded: html_helper
INFO - 2024-02-12 12:55:11 --> Helper loaded: text_helper
INFO - 2024-02-12 12:55:11 --> Helper loaded: form_helper
INFO - 2024-02-12 12:55:11 --> Helper loaded: lang_helper
INFO - 2024-02-12 12:55:11 --> Helper loaded: security_helper
INFO - 2024-02-12 12:55:11 --> Helper loaded: cookie_helper
INFO - 2024-02-12 12:55:11 --> Database Driver Class Initialized
INFO - 2024-02-12 12:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 12:55:11 --> Parser Class Initialized
INFO - 2024-02-12 12:55:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 12:55:11 --> Pagination Class Initialized
INFO - 2024-02-12 12:55:11 --> Form Validation Class Initialized
INFO - 2024-02-12 12:55:11 --> Controller Class Initialized
INFO - 2024-02-12 12:55:11 --> Model Class Initialized
DEBUG - 2024-02-12 12:55:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 12:55:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 12:55:11 --> Model Class Initialized
DEBUG - 2024-02-12 12:55:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 12:55:11 --> Model Class Initialized
DEBUG - 2024-02-12 12:55:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 12:55:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-02-12 12:55:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 12:55:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 12:55:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 12:55:11 --> Model Class Initialized
INFO - 2024-02-12 12:55:11 --> Model Class Initialized
INFO - 2024-02-12 12:55:11 --> Model Class Initialized
INFO - 2024-02-12 12:55:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 12:55:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 12:55:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 12:55:11 --> Final output sent to browser
DEBUG - 2024-02-12 12:55:11 --> Total execution time: 0.1780
ERROR - 2024-02-12 13:00:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 13:00:59 --> Config Class Initialized
INFO - 2024-02-12 13:00:59 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:00:59 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:00:59 --> Utf8 Class Initialized
INFO - 2024-02-12 13:00:59 --> URI Class Initialized
INFO - 2024-02-12 13:00:59 --> Router Class Initialized
INFO - 2024-02-12 13:00:59 --> Output Class Initialized
INFO - 2024-02-12 13:00:59 --> Security Class Initialized
DEBUG - 2024-02-12 13:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:00:59 --> Input Class Initialized
INFO - 2024-02-12 13:00:59 --> Language Class Initialized
INFO - 2024-02-12 13:00:59 --> Loader Class Initialized
INFO - 2024-02-12 13:00:59 --> Helper loaded: url_helper
INFO - 2024-02-12 13:00:59 --> Helper loaded: file_helper
INFO - 2024-02-12 13:00:59 --> Helper loaded: html_helper
INFO - 2024-02-12 13:00:59 --> Helper loaded: text_helper
INFO - 2024-02-12 13:00:59 --> Helper loaded: form_helper
INFO - 2024-02-12 13:00:59 --> Helper loaded: lang_helper
INFO - 2024-02-12 13:00:59 --> Helper loaded: security_helper
INFO - 2024-02-12 13:00:59 --> Helper loaded: cookie_helper
INFO - 2024-02-12 13:00:59 --> Database Driver Class Initialized
INFO - 2024-02-12 13:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:00:59 --> Parser Class Initialized
INFO - 2024-02-12 13:00:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 13:00:59 --> Pagination Class Initialized
INFO - 2024-02-12 13:00:59 --> Form Validation Class Initialized
INFO - 2024-02-12 13:00:59 --> Controller Class Initialized
INFO - 2024-02-12 13:00:59 --> Model Class Initialized
DEBUG - 2024-02-12 13:00:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 13:00:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:00:59 --> Model Class Initialized
DEBUG - 2024-02-12 13:00:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:00:59 --> Model Class Initialized
INFO - 2024-02-12 13:00:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-12 13:00:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:00:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 13:00:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 13:00:59 --> Model Class Initialized
INFO - 2024-02-12 13:00:59 --> Model Class Initialized
INFO - 2024-02-12 13:00:59 --> Model Class Initialized
INFO - 2024-02-12 13:00:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 13:00:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 13:00:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 13:00:59 --> Final output sent to browser
DEBUG - 2024-02-12 13:00:59 --> Total execution time: 0.1514
ERROR - 2024-02-12 13:01:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 13:01:01 --> Config Class Initialized
INFO - 2024-02-12 13:01:01 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:01:01 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:01:01 --> Utf8 Class Initialized
INFO - 2024-02-12 13:01:01 --> URI Class Initialized
INFO - 2024-02-12 13:01:01 --> Router Class Initialized
INFO - 2024-02-12 13:01:01 --> Output Class Initialized
INFO - 2024-02-12 13:01:01 --> Security Class Initialized
DEBUG - 2024-02-12 13:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:01:01 --> Input Class Initialized
INFO - 2024-02-12 13:01:01 --> Language Class Initialized
INFO - 2024-02-12 13:01:01 --> Loader Class Initialized
INFO - 2024-02-12 13:01:01 --> Helper loaded: url_helper
INFO - 2024-02-12 13:01:01 --> Helper loaded: file_helper
INFO - 2024-02-12 13:01:01 --> Helper loaded: html_helper
INFO - 2024-02-12 13:01:01 --> Helper loaded: text_helper
INFO - 2024-02-12 13:01:01 --> Helper loaded: form_helper
INFO - 2024-02-12 13:01:01 --> Helper loaded: lang_helper
INFO - 2024-02-12 13:01:01 --> Helper loaded: security_helper
INFO - 2024-02-12 13:01:01 --> Helper loaded: cookie_helper
INFO - 2024-02-12 13:01:01 --> Database Driver Class Initialized
INFO - 2024-02-12 13:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:01:01 --> Parser Class Initialized
INFO - 2024-02-12 13:01:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 13:01:01 --> Pagination Class Initialized
INFO - 2024-02-12 13:01:01 --> Form Validation Class Initialized
INFO - 2024-02-12 13:01:01 --> Controller Class Initialized
INFO - 2024-02-12 13:01:01 --> Model Class Initialized
DEBUG - 2024-02-12 13:01:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 13:01:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:01:01 --> Model Class Initialized
DEBUG - 2024-02-12 13:01:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:01:01 --> Model Class Initialized
INFO - 2024-02-12 13:01:01 --> Final output sent to browser
DEBUG - 2024-02-12 13:01:01 --> Total execution time: 0.0381
ERROR - 2024-02-12 13:16:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 13:16:55 --> Config Class Initialized
INFO - 2024-02-12 13:16:55 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:16:55 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:16:55 --> Utf8 Class Initialized
INFO - 2024-02-12 13:16:55 --> URI Class Initialized
DEBUG - 2024-02-12 13:16:55 --> No URI present. Default controller set.
INFO - 2024-02-12 13:16:55 --> Router Class Initialized
INFO - 2024-02-12 13:16:55 --> Output Class Initialized
INFO - 2024-02-12 13:16:55 --> Security Class Initialized
DEBUG - 2024-02-12 13:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:16:55 --> Input Class Initialized
INFO - 2024-02-12 13:16:55 --> Language Class Initialized
INFO - 2024-02-12 13:16:55 --> Loader Class Initialized
INFO - 2024-02-12 13:16:55 --> Helper loaded: url_helper
INFO - 2024-02-12 13:16:55 --> Helper loaded: file_helper
INFO - 2024-02-12 13:16:55 --> Helper loaded: html_helper
INFO - 2024-02-12 13:16:55 --> Helper loaded: text_helper
INFO - 2024-02-12 13:16:55 --> Helper loaded: form_helper
INFO - 2024-02-12 13:16:55 --> Helper loaded: lang_helper
INFO - 2024-02-12 13:16:55 --> Helper loaded: security_helper
INFO - 2024-02-12 13:16:55 --> Helper loaded: cookie_helper
INFO - 2024-02-12 13:16:55 --> Database Driver Class Initialized
INFO - 2024-02-12 13:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:16:55 --> Parser Class Initialized
INFO - 2024-02-12 13:16:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 13:16:55 --> Pagination Class Initialized
INFO - 2024-02-12 13:16:55 --> Form Validation Class Initialized
INFO - 2024-02-12 13:16:55 --> Controller Class Initialized
INFO - 2024-02-12 13:16:55 --> Model Class Initialized
DEBUG - 2024-02-12 13:16:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:16:55 --> Model Class Initialized
DEBUG - 2024-02-12 13:16:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:16:55 --> Model Class Initialized
INFO - 2024-02-12 13:16:55 --> Model Class Initialized
INFO - 2024-02-12 13:16:55 --> Model Class Initialized
INFO - 2024-02-12 13:16:55 --> Model Class Initialized
DEBUG - 2024-02-12 13:16:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 13:16:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:16:55 --> Model Class Initialized
INFO - 2024-02-12 13:16:55 --> Model Class Initialized
INFO - 2024-02-12 13:16:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-12 13:16:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:16:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 13:16:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 13:16:55 --> Model Class Initialized
INFO - 2024-02-12 13:16:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 13:16:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 13:16:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 13:16:55 --> Final output sent to browser
DEBUG - 2024-02-12 13:16:55 --> Total execution time: 0.2560
ERROR - 2024-02-12 13:17:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 13:17:26 --> Config Class Initialized
INFO - 2024-02-12 13:17:26 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:17:26 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:17:26 --> Utf8 Class Initialized
INFO - 2024-02-12 13:17:26 --> URI Class Initialized
INFO - 2024-02-12 13:17:26 --> Router Class Initialized
INFO - 2024-02-12 13:17:26 --> Output Class Initialized
INFO - 2024-02-12 13:17:26 --> Security Class Initialized
DEBUG - 2024-02-12 13:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:17:26 --> Input Class Initialized
INFO - 2024-02-12 13:17:26 --> Language Class Initialized
INFO - 2024-02-12 13:17:26 --> Loader Class Initialized
INFO - 2024-02-12 13:17:26 --> Helper loaded: url_helper
INFO - 2024-02-12 13:17:26 --> Helper loaded: file_helper
INFO - 2024-02-12 13:17:26 --> Helper loaded: html_helper
INFO - 2024-02-12 13:17:26 --> Helper loaded: text_helper
INFO - 2024-02-12 13:17:26 --> Helper loaded: form_helper
INFO - 2024-02-12 13:17:26 --> Helper loaded: lang_helper
INFO - 2024-02-12 13:17:26 --> Helper loaded: security_helper
INFO - 2024-02-12 13:17:26 --> Helper loaded: cookie_helper
INFO - 2024-02-12 13:17:26 --> Database Driver Class Initialized
INFO - 2024-02-12 13:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:17:26 --> Parser Class Initialized
INFO - 2024-02-12 13:17:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 13:17:26 --> Pagination Class Initialized
INFO - 2024-02-12 13:17:26 --> Form Validation Class Initialized
INFO - 2024-02-12 13:17:26 --> Controller Class Initialized
DEBUG - 2024-02-12 13:17:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 13:17:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:17:26 --> Model Class Initialized
DEBUG - 2024-02-12 13:17:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:17:26 --> Model Class Initialized
INFO - 2024-02-12 13:17:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2024-02-12 13:17:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:17:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 13:17:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 13:17:26 --> Model Class Initialized
INFO - 2024-02-12 13:17:26 --> Model Class Initialized
INFO - 2024-02-12 13:17:26 --> Model Class Initialized
INFO - 2024-02-12 13:17:26 --> Model Class Initialized
INFO - 2024-02-12 13:17:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 13:17:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 13:17:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 13:17:26 --> Final output sent to browser
DEBUG - 2024-02-12 13:17:26 --> Total execution time: 0.1986
ERROR - 2024-02-12 13:22:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 13:22:52 --> Config Class Initialized
INFO - 2024-02-12 13:22:52 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:22:52 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:22:52 --> Utf8 Class Initialized
INFO - 2024-02-12 13:22:52 --> URI Class Initialized
INFO - 2024-02-12 13:22:52 --> Router Class Initialized
INFO - 2024-02-12 13:22:52 --> Output Class Initialized
INFO - 2024-02-12 13:22:52 --> Security Class Initialized
DEBUG - 2024-02-12 13:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:22:52 --> Input Class Initialized
INFO - 2024-02-12 13:22:52 --> Language Class Initialized
INFO - 2024-02-12 13:22:52 --> Loader Class Initialized
INFO - 2024-02-12 13:22:52 --> Helper loaded: url_helper
INFO - 2024-02-12 13:22:52 --> Helper loaded: file_helper
INFO - 2024-02-12 13:22:52 --> Helper loaded: html_helper
INFO - 2024-02-12 13:22:52 --> Helper loaded: text_helper
INFO - 2024-02-12 13:22:52 --> Helper loaded: form_helper
INFO - 2024-02-12 13:22:52 --> Helper loaded: lang_helper
INFO - 2024-02-12 13:22:52 --> Helper loaded: security_helper
INFO - 2024-02-12 13:22:52 --> Helper loaded: cookie_helper
INFO - 2024-02-12 13:22:52 --> Database Driver Class Initialized
INFO - 2024-02-12 13:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:22:52 --> Parser Class Initialized
INFO - 2024-02-12 13:22:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 13:22:52 --> Pagination Class Initialized
INFO - 2024-02-12 13:22:52 --> Form Validation Class Initialized
INFO - 2024-02-12 13:22:52 --> Controller Class Initialized
DEBUG - 2024-02-12 13:22:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 13:22:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:22:52 --> Model Class Initialized
DEBUG - 2024-02-12 13:22:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:22:52 --> Model Class Initialized
DEBUG - 2024-02-12 13:22:52 --> Auth class already loaded. Second attempt ignored.
ERROR - 2024-02-12 13:22:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 13:22:52 --> Config Class Initialized
INFO - 2024-02-12 13:22:52 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:22:52 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:22:52 --> Utf8 Class Initialized
INFO - 2024-02-12 13:22:52 --> URI Class Initialized
INFO - 2024-02-12 13:22:52 --> Router Class Initialized
INFO - 2024-02-12 13:22:52 --> Output Class Initialized
INFO - 2024-02-12 13:22:52 --> Security Class Initialized
DEBUG - 2024-02-12 13:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:22:52 --> Input Class Initialized
INFO - 2024-02-12 13:22:52 --> Language Class Initialized
INFO - 2024-02-12 13:22:52 --> Loader Class Initialized
INFO - 2024-02-12 13:22:52 --> Helper loaded: url_helper
INFO - 2024-02-12 13:22:52 --> Helper loaded: file_helper
INFO - 2024-02-12 13:22:52 --> Helper loaded: html_helper
INFO - 2024-02-12 13:22:52 --> Helper loaded: text_helper
INFO - 2024-02-12 13:22:52 --> Helper loaded: form_helper
INFO - 2024-02-12 13:22:52 --> Helper loaded: lang_helper
INFO - 2024-02-12 13:22:52 --> Helper loaded: security_helper
INFO - 2024-02-12 13:22:52 --> Helper loaded: cookie_helper
INFO - 2024-02-12 13:22:52 --> Database Driver Class Initialized
INFO - 2024-02-12 13:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:22:52 --> Parser Class Initialized
INFO - 2024-02-12 13:22:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 13:22:52 --> Pagination Class Initialized
INFO - 2024-02-12 13:22:52 --> Form Validation Class Initialized
INFO - 2024-02-12 13:22:52 --> Controller Class Initialized
DEBUG - 2024-02-12 13:22:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 13:22:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:22:52 --> Model Class Initialized
DEBUG - 2024-02-12 13:22:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:22:52 --> Model Class Initialized
INFO - 2024-02-12 13:22:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2024-02-12 13:22:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:22:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 13:22:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 13:22:52 --> Model Class Initialized
INFO - 2024-02-12 13:22:52 --> Model Class Initialized
INFO - 2024-02-12 13:22:52 --> Model Class Initialized
INFO - 2024-02-12 13:22:52 --> Model Class Initialized
INFO - 2024-02-12 13:22:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 13:22:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 13:22:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 13:22:52 --> Final output sent to browser
DEBUG - 2024-02-12 13:22:52 --> Total execution time: 0.1900
ERROR - 2024-02-12 13:37:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 13:37:52 --> Config Class Initialized
INFO - 2024-02-12 13:37:52 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:37:52 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:37:52 --> Utf8 Class Initialized
INFO - 2024-02-12 13:37:52 --> URI Class Initialized
INFO - 2024-02-12 13:37:52 --> Router Class Initialized
INFO - 2024-02-12 13:37:52 --> Output Class Initialized
INFO - 2024-02-12 13:37:52 --> Security Class Initialized
DEBUG - 2024-02-12 13:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:37:52 --> Input Class Initialized
INFO - 2024-02-12 13:37:52 --> Language Class Initialized
INFO - 2024-02-12 13:37:52 --> Loader Class Initialized
INFO - 2024-02-12 13:37:52 --> Helper loaded: url_helper
INFO - 2024-02-12 13:37:52 --> Helper loaded: file_helper
INFO - 2024-02-12 13:37:52 --> Helper loaded: html_helper
INFO - 2024-02-12 13:37:52 --> Helper loaded: text_helper
INFO - 2024-02-12 13:37:52 --> Helper loaded: form_helper
INFO - 2024-02-12 13:37:52 --> Helper loaded: lang_helper
INFO - 2024-02-12 13:37:52 --> Helper loaded: security_helper
INFO - 2024-02-12 13:37:52 --> Helper loaded: cookie_helper
INFO - 2024-02-12 13:37:52 --> Database Driver Class Initialized
INFO - 2024-02-12 13:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:37:52 --> Parser Class Initialized
INFO - 2024-02-12 13:37:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 13:37:52 --> Pagination Class Initialized
INFO - 2024-02-12 13:37:52 --> Form Validation Class Initialized
INFO - 2024-02-12 13:37:52 --> Controller Class Initialized
DEBUG - 2024-02-12 13:37:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 13:37:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:37:52 --> Model Class Initialized
DEBUG - 2024-02-12 13:37:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:37:52 --> Model Class Initialized
DEBUG - 2024-02-12 13:37:52 --> Auth class already loaded. Second attempt ignored.
ERROR - 2024-02-12 13:37:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 13:37:52 --> Config Class Initialized
INFO - 2024-02-12 13:37:52 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:37:52 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:37:52 --> Utf8 Class Initialized
INFO - 2024-02-12 13:37:52 --> URI Class Initialized
INFO - 2024-02-12 13:37:52 --> Router Class Initialized
INFO - 2024-02-12 13:37:52 --> Output Class Initialized
INFO - 2024-02-12 13:37:52 --> Security Class Initialized
DEBUG - 2024-02-12 13:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:37:52 --> Input Class Initialized
INFO - 2024-02-12 13:37:52 --> Language Class Initialized
INFO - 2024-02-12 13:37:52 --> Loader Class Initialized
INFO - 2024-02-12 13:37:52 --> Helper loaded: url_helper
INFO - 2024-02-12 13:37:52 --> Helper loaded: file_helper
INFO - 2024-02-12 13:37:52 --> Helper loaded: html_helper
INFO - 2024-02-12 13:37:52 --> Helper loaded: text_helper
INFO - 2024-02-12 13:37:52 --> Helper loaded: form_helper
INFO - 2024-02-12 13:37:52 --> Helper loaded: lang_helper
INFO - 2024-02-12 13:37:52 --> Helper loaded: security_helper
INFO - 2024-02-12 13:37:52 --> Helper loaded: cookie_helper
INFO - 2024-02-12 13:37:52 --> Database Driver Class Initialized
INFO - 2024-02-12 13:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:37:52 --> Parser Class Initialized
INFO - 2024-02-12 13:37:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 13:37:52 --> Pagination Class Initialized
INFO - 2024-02-12 13:37:52 --> Form Validation Class Initialized
INFO - 2024-02-12 13:37:52 --> Controller Class Initialized
DEBUG - 2024-02-12 13:37:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 13:37:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:37:52 --> Model Class Initialized
DEBUG - 2024-02-12 13:37:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:37:52 --> Model Class Initialized
INFO - 2024-02-12 13:37:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2024-02-12 13:37:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:37:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 13:37:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 13:37:53 --> Model Class Initialized
INFO - 2024-02-12 13:37:53 --> Model Class Initialized
INFO - 2024-02-12 13:37:53 --> Model Class Initialized
INFO - 2024-02-12 13:37:53 --> Model Class Initialized
INFO - 2024-02-12 13:37:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 13:37:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 13:37:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 13:37:53 --> Final output sent to browser
DEBUG - 2024-02-12 13:37:53 --> Total execution time: 0.2241
ERROR - 2024-02-12 13:46:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 13:46:12 --> Config Class Initialized
INFO - 2024-02-12 13:46:12 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:46:12 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:46:12 --> Utf8 Class Initialized
INFO - 2024-02-12 13:46:12 --> URI Class Initialized
DEBUG - 2024-02-12 13:46:12 --> No URI present. Default controller set.
INFO - 2024-02-12 13:46:12 --> Router Class Initialized
INFO - 2024-02-12 13:46:12 --> Output Class Initialized
INFO - 2024-02-12 13:46:12 --> Security Class Initialized
DEBUG - 2024-02-12 13:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:46:12 --> Input Class Initialized
INFO - 2024-02-12 13:46:12 --> Language Class Initialized
INFO - 2024-02-12 13:46:12 --> Loader Class Initialized
INFO - 2024-02-12 13:46:12 --> Helper loaded: url_helper
INFO - 2024-02-12 13:46:12 --> Helper loaded: file_helper
INFO - 2024-02-12 13:46:12 --> Helper loaded: html_helper
INFO - 2024-02-12 13:46:12 --> Helper loaded: text_helper
INFO - 2024-02-12 13:46:12 --> Helper loaded: form_helper
INFO - 2024-02-12 13:46:12 --> Helper loaded: lang_helper
INFO - 2024-02-12 13:46:12 --> Helper loaded: security_helper
INFO - 2024-02-12 13:46:12 --> Helper loaded: cookie_helper
INFO - 2024-02-12 13:46:12 --> Database Driver Class Initialized
INFO - 2024-02-12 13:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:46:12 --> Parser Class Initialized
INFO - 2024-02-12 13:46:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 13:46:12 --> Pagination Class Initialized
INFO - 2024-02-12 13:46:12 --> Form Validation Class Initialized
INFO - 2024-02-12 13:46:12 --> Controller Class Initialized
INFO - 2024-02-12 13:46:12 --> Model Class Initialized
DEBUG - 2024-02-12 13:46:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-12 13:46:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 13:46:12 --> Config Class Initialized
INFO - 2024-02-12 13:46:12 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:46:12 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:46:12 --> Utf8 Class Initialized
INFO - 2024-02-12 13:46:12 --> URI Class Initialized
INFO - 2024-02-12 13:46:12 --> Router Class Initialized
INFO - 2024-02-12 13:46:12 --> Output Class Initialized
INFO - 2024-02-12 13:46:12 --> Security Class Initialized
DEBUG - 2024-02-12 13:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:46:12 --> Input Class Initialized
INFO - 2024-02-12 13:46:12 --> Language Class Initialized
INFO - 2024-02-12 13:46:12 --> Loader Class Initialized
INFO - 2024-02-12 13:46:12 --> Helper loaded: url_helper
INFO - 2024-02-12 13:46:12 --> Helper loaded: file_helper
INFO - 2024-02-12 13:46:12 --> Helper loaded: html_helper
INFO - 2024-02-12 13:46:12 --> Helper loaded: text_helper
INFO - 2024-02-12 13:46:12 --> Helper loaded: form_helper
INFO - 2024-02-12 13:46:12 --> Helper loaded: lang_helper
INFO - 2024-02-12 13:46:12 --> Helper loaded: security_helper
INFO - 2024-02-12 13:46:12 --> Helper loaded: cookie_helper
INFO - 2024-02-12 13:46:12 --> Database Driver Class Initialized
INFO - 2024-02-12 13:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:46:12 --> Parser Class Initialized
INFO - 2024-02-12 13:46:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 13:46:12 --> Pagination Class Initialized
INFO - 2024-02-12 13:46:12 --> Form Validation Class Initialized
INFO - 2024-02-12 13:46:12 --> Controller Class Initialized
INFO - 2024-02-12 13:46:12 --> Model Class Initialized
DEBUG - 2024-02-12 13:46:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:46:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-12 13:46:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:46:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 13:46:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 13:46:12 --> Model Class Initialized
INFO - 2024-02-12 13:46:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 13:46:12 --> Final output sent to browser
DEBUG - 2024-02-12 13:46:12 --> Total execution time: 0.0375
ERROR - 2024-02-12 13:46:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 13:46:25 --> Config Class Initialized
INFO - 2024-02-12 13:46:25 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:46:25 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:46:25 --> Utf8 Class Initialized
INFO - 2024-02-12 13:46:25 --> URI Class Initialized
INFO - 2024-02-12 13:46:25 --> Router Class Initialized
INFO - 2024-02-12 13:46:25 --> Output Class Initialized
INFO - 2024-02-12 13:46:25 --> Security Class Initialized
DEBUG - 2024-02-12 13:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:46:25 --> Input Class Initialized
INFO - 2024-02-12 13:46:25 --> Language Class Initialized
INFO - 2024-02-12 13:46:25 --> Loader Class Initialized
INFO - 2024-02-12 13:46:25 --> Helper loaded: url_helper
INFO - 2024-02-12 13:46:25 --> Helper loaded: file_helper
INFO - 2024-02-12 13:46:25 --> Helper loaded: html_helper
INFO - 2024-02-12 13:46:25 --> Helper loaded: text_helper
INFO - 2024-02-12 13:46:25 --> Helper loaded: form_helper
INFO - 2024-02-12 13:46:25 --> Helper loaded: lang_helper
INFO - 2024-02-12 13:46:25 --> Helper loaded: security_helper
INFO - 2024-02-12 13:46:25 --> Helper loaded: cookie_helper
INFO - 2024-02-12 13:46:25 --> Database Driver Class Initialized
INFO - 2024-02-12 13:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:46:25 --> Parser Class Initialized
INFO - 2024-02-12 13:46:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 13:46:25 --> Pagination Class Initialized
INFO - 2024-02-12 13:46:25 --> Form Validation Class Initialized
INFO - 2024-02-12 13:46:25 --> Controller Class Initialized
INFO - 2024-02-12 13:46:25 --> Model Class Initialized
DEBUG - 2024-02-12 13:46:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:46:25 --> Model Class Initialized
INFO - 2024-02-12 13:46:25 --> Final output sent to browser
DEBUG - 2024-02-12 13:46:25 --> Total execution time: 0.0206
ERROR - 2024-02-12 13:46:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 13:46:25 --> Config Class Initialized
INFO - 2024-02-12 13:46:25 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:46:25 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:46:25 --> Utf8 Class Initialized
INFO - 2024-02-12 13:46:25 --> URI Class Initialized
DEBUG - 2024-02-12 13:46:25 --> No URI present. Default controller set.
INFO - 2024-02-12 13:46:25 --> Router Class Initialized
INFO - 2024-02-12 13:46:25 --> Output Class Initialized
INFO - 2024-02-12 13:46:25 --> Security Class Initialized
DEBUG - 2024-02-12 13:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:46:25 --> Input Class Initialized
INFO - 2024-02-12 13:46:25 --> Language Class Initialized
INFO - 2024-02-12 13:46:25 --> Loader Class Initialized
INFO - 2024-02-12 13:46:25 --> Helper loaded: url_helper
INFO - 2024-02-12 13:46:25 --> Helper loaded: file_helper
INFO - 2024-02-12 13:46:25 --> Helper loaded: html_helper
INFO - 2024-02-12 13:46:25 --> Helper loaded: text_helper
INFO - 2024-02-12 13:46:25 --> Helper loaded: form_helper
INFO - 2024-02-12 13:46:25 --> Helper loaded: lang_helper
INFO - 2024-02-12 13:46:25 --> Helper loaded: security_helper
INFO - 2024-02-12 13:46:25 --> Helper loaded: cookie_helper
INFO - 2024-02-12 13:46:25 --> Database Driver Class Initialized
INFO - 2024-02-12 13:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:46:25 --> Parser Class Initialized
INFO - 2024-02-12 13:46:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 13:46:25 --> Pagination Class Initialized
INFO - 2024-02-12 13:46:25 --> Form Validation Class Initialized
INFO - 2024-02-12 13:46:25 --> Controller Class Initialized
INFO - 2024-02-12 13:46:25 --> Model Class Initialized
DEBUG - 2024-02-12 13:46:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:46:25 --> Model Class Initialized
DEBUG - 2024-02-12 13:46:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:46:25 --> Model Class Initialized
INFO - 2024-02-12 13:46:25 --> Model Class Initialized
INFO - 2024-02-12 13:46:25 --> Model Class Initialized
INFO - 2024-02-12 13:46:25 --> Model Class Initialized
DEBUG - 2024-02-12 13:46:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 13:46:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:46:25 --> Model Class Initialized
INFO - 2024-02-12 13:46:25 --> Model Class Initialized
INFO - 2024-02-12 13:46:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-12 13:46:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:46:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 13:46:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 13:46:26 --> Model Class Initialized
INFO - 2024-02-12 13:46:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 13:46:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 13:46:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 13:46:26 --> Final output sent to browser
DEBUG - 2024-02-12 13:46:26 --> Total execution time: 0.4600
ERROR - 2024-02-12 13:46:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 13:46:27 --> Config Class Initialized
INFO - 2024-02-12 13:46:27 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:46:27 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:46:27 --> Utf8 Class Initialized
INFO - 2024-02-12 13:46:27 --> URI Class Initialized
INFO - 2024-02-12 13:46:27 --> Router Class Initialized
INFO - 2024-02-12 13:46:27 --> Output Class Initialized
INFO - 2024-02-12 13:46:27 --> Security Class Initialized
DEBUG - 2024-02-12 13:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:46:27 --> Input Class Initialized
INFO - 2024-02-12 13:46:27 --> Language Class Initialized
INFO - 2024-02-12 13:46:27 --> Loader Class Initialized
INFO - 2024-02-12 13:46:27 --> Helper loaded: url_helper
INFO - 2024-02-12 13:46:27 --> Helper loaded: file_helper
INFO - 2024-02-12 13:46:27 --> Helper loaded: html_helper
INFO - 2024-02-12 13:46:27 --> Helper loaded: text_helper
INFO - 2024-02-12 13:46:27 --> Helper loaded: form_helper
INFO - 2024-02-12 13:46:27 --> Helper loaded: lang_helper
INFO - 2024-02-12 13:46:27 --> Helper loaded: security_helper
INFO - 2024-02-12 13:46:27 --> Helper loaded: cookie_helper
INFO - 2024-02-12 13:46:27 --> Database Driver Class Initialized
INFO - 2024-02-12 13:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:46:27 --> Parser Class Initialized
INFO - 2024-02-12 13:46:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 13:46:27 --> Pagination Class Initialized
INFO - 2024-02-12 13:46:27 --> Form Validation Class Initialized
INFO - 2024-02-12 13:46:27 --> Controller Class Initialized
DEBUG - 2024-02-12 13:46:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 13:46:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:46:27 --> Model Class Initialized
INFO - 2024-02-12 13:46:27 --> Final output sent to browser
DEBUG - 2024-02-12 13:46:27 --> Total execution time: 0.0136
ERROR - 2024-02-12 13:46:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 13:46:36 --> Config Class Initialized
INFO - 2024-02-12 13:46:36 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:46:36 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:46:36 --> Utf8 Class Initialized
INFO - 2024-02-12 13:46:36 --> URI Class Initialized
INFO - 2024-02-12 13:46:36 --> Router Class Initialized
INFO - 2024-02-12 13:46:36 --> Output Class Initialized
INFO - 2024-02-12 13:46:36 --> Security Class Initialized
DEBUG - 2024-02-12 13:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:46:36 --> Input Class Initialized
INFO - 2024-02-12 13:46:36 --> Language Class Initialized
INFO - 2024-02-12 13:46:36 --> Loader Class Initialized
INFO - 2024-02-12 13:46:36 --> Helper loaded: url_helper
INFO - 2024-02-12 13:46:36 --> Helper loaded: file_helper
INFO - 2024-02-12 13:46:36 --> Helper loaded: html_helper
INFO - 2024-02-12 13:46:36 --> Helper loaded: text_helper
INFO - 2024-02-12 13:46:36 --> Helper loaded: form_helper
INFO - 2024-02-12 13:46:36 --> Helper loaded: lang_helper
INFO - 2024-02-12 13:46:36 --> Helper loaded: security_helper
INFO - 2024-02-12 13:46:36 --> Helper loaded: cookie_helper
INFO - 2024-02-12 13:46:36 --> Database Driver Class Initialized
INFO - 2024-02-12 13:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:46:36 --> Parser Class Initialized
INFO - 2024-02-12 13:46:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 13:46:36 --> Pagination Class Initialized
INFO - 2024-02-12 13:46:36 --> Form Validation Class Initialized
INFO - 2024-02-12 13:46:36 --> Controller Class Initialized
DEBUG - 2024-02-12 13:46:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 13:46:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:46:36 --> Model Class Initialized
DEBUG - 2024-02-12 13:46:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:46:36 --> Model Class Initialized
DEBUG - 2024-02-12 13:46:36 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:46:36 --> Model Class Initialized
INFO - 2024-02-12 13:46:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-12 13:46:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:46:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 13:46:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 13:46:36 --> Model Class Initialized
INFO - 2024-02-12 13:46:36 --> Model Class Initialized
INFO - 2024-02-12 13:46:36 --> Model Class Initialized
INFO - 2024-02-12 13:46:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 13:46:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 13:46:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 13:46:36 --> Final output sent to browser
DEBUG - 2024-02-12 13:46:36 --> Total execution time: 0.2388
ERROR - 2024-02-12 13:46:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 13:46:37 --> Config Class Initialized
INFO - 2024-02-12 13:46:37 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:46:37 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:46:37 --> Utf8 Class Initialized
INFO - 2024-02-12 13:46:37 --> URI Class Initialized
INFO - 2024-02-12 13:46:37 --> Router Class Initialized
INFO - 2024-02-12 13:46:37 --> Output Class Initialized
INFO - 2024-02-12 13:46:37 --> Security Class Initialized
DEBUG - 2024-02-12 13:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:46:37 --> Input Class Initialized
INFO - 2024-02-12 13:46:37 --> Language Class Initialized
INFO - 2024-02-12 13:46:37 --> Loader Class Initialized
INFO - 2024-02-12 13:46:37 --> Helper loaded: url_helper
INFO - 2024-02-12 13:46:37 --> Helper loaded: file_helper
INFO - 2024-02-12 13:46:37 --> Helper loaded: html_helper
INFO - 2024-02-12 13:46:37 --> Helper loaded: text_helper
INFO - 2024-02-12 13:46:37 --> Helper loaded: form_helper
INFO - 2024-02-12 13:46:37 --> Helper loaded: lang_helper
INFO - 2024-02-12 13:46:37 --> Helper loaded: security_helper
INFO - 2024-02-12 13:46:37 --> Helper loaded: cookie_helper
INFO - 2024-02-12 13:46:37 --> Database Driver Class Initialized
INFO - 2024-02-12 13:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:46:37 --> Parser Class Initialized
INFO - 2024-02-12 13:46:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 13:46:37 --> Pagination Class Initialized
INFO - 2024-02-12 13:46:37 --> Form Validation Class Initialized
INFO - 2024-02-12 13:46:37 --> Controller Class Initialized
DEBUG - 2024-02-12 13:46:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 13:46:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:46:37 --> Model Class Initialized
DEBUG - 2024-02-12 13:46:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:46:37 --> Model Class Initialized
INFO - 2024-02-12 13:46:37 --> Final output sent to browser
DEBUG - 2024-02-12 13:46:37 --> Total execution time: 0.0346
ERROR - 2024-02-12 13:46:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 13:46:41 --> Config Class Initialized
INFO - 2024-02-12 13:46:41 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:46:41 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:46:41 --> Utf8 Class Initialized
INFO - 2024-02-12 13:46:41 --> URI Class Initialized
INFO - 2024-02-12 13:46:41 --> Router Class Initialized
INFO - 2024-02-12 13:46:41 --> Output Class Initialized
INFO - 2024-02-12 13:46:41 --> Security Class Initialized
DEBUG - 2024-02-12 13:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:46:41 --> Input Class Initialized
INFO - 2024-02-12 13:46:41 --> Language Class Initialized
INFO - 2024-02-12 13:46:41 --> Loader Class Initialized
INFO - 2024-02-12 13:46:41 --> Helper loaded: url_helper
INFO - 2024-02-12 13:46:41 --> Helper loaded: file_helper
INFO - 2024-02-12 13:46:41 --> Helper loaded: html_helper
INFO - 2024-02-12 13:46:41 --> Helper loaded: text_helper
INFO - 2024-02-12 13:46:41 --> Helper loaded: form_helper
INFO - 2024-02-12 13:46:41 --> Helper loaded: lang_helper
INFO - 2024-02-12 13:46:41 --> Helper loaded: security_helper
INFO - 2024-02-12 13:46:41 --> Helper loaded: cookie_helper
INFO - 2024-02-12 13:46:41 --> Database Driver Class Initialized
INFO - 2024-02-12 13:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:46:41 --> Parser Class Initialized
INFO - 2024-02-12 13:46:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 13:46:41 --> Pagination Class Initialized
INFO - 2024-02-12 13:46:41 --> Form Validation Class Initialized
INFO - 2024-02-12 13:46:41 --> Controller Class Initialized
DEBUG - 2024-02-12 13:46:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 13:46:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:46:41 --> Model Class Initialized
DEBUG - 2024-02-12 13:46:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:46:41 --> Model Class Initialized
INFO - 2024-02-12 13:46:41 --> Final output sent to browser
DEBUG - 2024-02-12 13:46:41 --> Total execution time: 0.0375
ERROR - 2024-02-12 13:46:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 13:46:49 --> Config Class Initialized
INFO - 2024-02-12 13:46:49 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:46:49 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:46:49 --> Utf8 Class Initialized
INFO - 2024-02-12 13:46:49 --> URI Class Initialized
INFO - 2024-02-12 13:46:49 --> Router Class Initialized
INFO - 2024-02-12 13:46:49 --> Output Class Initialized
INFO - 2024-02-12 13:46:49 --> Security Class Initialized
DEBUG - 2024-02-12 13:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:46:49 --> Input Class Initialized
INFO - 2024-02-12 13:46:49 --> Language Class Initialized
INFO - 2024-02-12 13:46:49 --> Loader Class Initialized
INFO - 2024-02-12 13:46:49 --> Helper loaded: url_helper
INFO - 2024-02-12 13:46:49 --> Helper loaded: file_helper
INFO - 2024-02-12 13:46:49 --> Helper loaded: html_helper
INFO - 2024-02-12 13:46:49 --> Helper loaded: text_helper
INFO - 2024-02-12 13:46:49 --> Helper loaded: form_helper
INFO - 2024-02-12 13:46:49 --> Helper loaded: lang_helper
INFO - 2024-02-12 13:46:49 --> Helper loaded: security_helper
INFO - 2024-02-12 13:46:49 --> Helper loaded: cookie_helper
INFO - 2024-02-12 13:46:49 --> Database Driver Class Initialized
INFO - 2024-02-12 13:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:46:49 --> Parser Class Initialized
INFO - 2024-02-12 13:46:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 13:46:49 --> Pagination Class Initialized
INFO - 2024-02-12 13:46:49 --> Form Validation Class Initialized
INFO - 2024-02-12 13:46:49 --> Controller Class Initialized
DEBUG - 2024-02-12 13:46:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 13:46:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:46:49 --> Model Class Initialized
DEBUG - 2024-02-12 13:46:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:46:49 --> Model Class Initialized
INFO - 2024-02-12 13:46:49 --> Final output sent to browser
DEBUG - 2024-02-12 13:46:49 --> Total execution time: 0.0337
ERROR - 2024-02-12 13:46:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 13:46:52 --> Config Class Initialized
INFO - 2024-02-12 13:46:52 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:46:52 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:46:52 --> Utf8 Class Initialized
INFO - 2024-02-12 13:46:52 --> URI Class Initialized
INFO - 2024-02-12 13:46:52 --> Router Class Initialized
INFO - 2024-02-12 13:46:52 --> Output Class Initialized
INFO - 2024-02-12 13:46:52 --> Security Class Initialized
DEBUG - 2024-02-12 13:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:46:52 --> Input Class Initialized
INFO - 2024-02-12 13:46:52 --> Language Class Initialized
INFO - 2024-02-12 13:46:52 --> Loader Class Initialized
INFO - 2024-02-12 13:46:52 --> Helper loaded: url_helper
INFO - 2024-02-12 13:46:52 --> Helper loaded: file_helper
INFO - 2024-02-12 13:46:52 --> Helper loaded: html_helper
INFO - 2024-02-12 13:46:52 --> Helper loaded: text_helper
INFO - 2024-02-12 13:46:52 --> Helper loaded: form_helper
INFO - 2024-02-12 13:46:52 --> Helper loaded: lang_helper
INFO - 2024-02-12 13:46:52 --> Helper loaded: security_helper
INFO - 2024-02-12 13:46:52 --> Helper loaded: cookie_helper
INFO - 2024-02-12 13:46:52 --> Database Driver Class Initialized
INFO - 2024-02-12 13:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:46:52 --> Parser Class Initialized
INFO - 2024-02-12 13:46:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 13:46:52 --> Pagination Class Initialized
INFO - 2024-02-12 13:46:52 --> Form Validation Class Initialized
INFO - 2024-02-12 13:46:52 --> Controller Class Initialized
DEBUG - 2024-02-12 13:46:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 13:46:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:46:52 --> Model Class Initialized
DEBUG - 2024-02-12 13:46:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:46:52 --> Model Class Initialized
INFO - 2024-02-12 13:46:52 --> Final output sent to browser
DEBUG - 2024-02-12 13:46:52 --> Total execution time: 0.0322
ERROR - 2024-02-12 13:51:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 13:51:34 --> Config Class Initialized
INFO - 2024-02-12 13:51:34 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:51:34 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:51:34 --> Utf8 Class Initialized
INFO - 2024-02-12 13:51:34 --> URI Class Initialized
INFO - 2024-02-12 13:51:34 --> Router Class Initialized
INFO - 2024-02-12 13:51:34 --> Output Class Initialized
INFO - 2024-02-12 13:51:34 --> Security Class Initialized
DEBUG - 2024-02-12 13:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:51:34 --> Input Class Initialized
INFO - 2024-02-12 13:51:34 --> Language Class Initialized
INFO - 2024-02-12 13:51:34 --> Loader Class Initialized
INFO - 2024-02-12 13:51:34 --> Helper loaded: url_helper
INFO - 2024-02-12 13:51:34 --> Helper loaded: file_helper
INFO - 2024-02-12 13:51:34 --> Helper loaded: html_helper
INFO - 2024-02-12 13:51:34 --> Helper loaded: text_helper
INFO - 2024-02-12 13:51:34 --> Helper loaded: form_helper
INFO - 2024-02-12 13:51:34 --> Helper loaded: lang_helper
INFO - 2024-02-12 13:51:34 --> Helper loaded: security_helper
INFO - 2024-02-12 13:51:34 --> Helper loaded: cookie_helper
INFO - 2024-02-12 13:51:34 --> Database Driver Class Initialized
INFO - 2024-02-12 13:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:51:34 --> Parser Class Initialized
INFO - 2024-02-12 13:51:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 13:51:34 --> Pagination Class Initialized
INFO - 2024-02-12 13:51:34 --> Form Validation Class Initialized
INFO - 2024-02-12 13:51:34 --> Controller Class Initialized
DEBUG - 2024-02-12 13:51:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 13:51:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:51:34 --> Model Class Initialized
DEBUG - 2024-02-12 13:51:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:51:34 --> Model Class Initialized
INFO - 2024-02-12 13:51:34 --> Final output sent to browser
DEBUG - 2024-02-12 13:51:34 --> Total execution time: 0.2186
ERROR - 2024-02-12 13:55:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 13:55:16 --> Config Class Initialized
INFO - 2024-02-12 13:55:16 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:55:16 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:55:16 --> Utf8 Class Initialized
INFO - 2024-02-12 13:55:16 --> URI Class Initialized
INFO - 2024-02-12 13:55:16 --> Router Class Initialized
INFO - 2024-02-12 13:55:16 --> Output Class Initialized
INFO - 2024-02-12 13:55:16 --> Security Class Initialized
DEBUG - 2024-02-12 13:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:55:16 --> Input Class Initialized
INFO - 2024-02-12 13:55:16 --> Language Class Initialized
INFO - 2024-02-12 13:55:16 --> Loader Class Initialized
INFO - 2024-02-12 13:55:16 --> Helper loaded: url_helper
INFO - 2024-02-12 13:55:16 --> Helper loaded: file_helper
INFO - 2024-02-12 13:55:16 --> Helper loaded: html_helper
INFO - 2024-02-12 13:55:16 --> Helper loaded: text_helper
INFO - 2024-02-12 13:55:16 --> Helper loaded: form_helper
INFO - 2024-02-12 13:55:16 --> Helper loaded: lang_helper
INFO - 2024-02-12 13:55:16 --> Helper loaded: security_helper
INFO - 2024-02-12 13:55:16 --> Helper loaded: cookie_helper
INFO - 2024-02-12 13:55:16 --> Database Driver Class Initialized
INFO - 2024-02-12 13:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:55:16 --> Parser Class Initialized
INFO - 2024-02-12 13:55:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 13:55:16 --> Pagination Class Initialized
INFO - 2024-02-12 13:55:16 --> Form Validation Class Initialized
INFO - 2024-02-12 13:55:16 --> Controller Class Initialized
DEBUG - 2024-02-12 13:55:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 13:55:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:55:16 --> Model Class Initialized
DEBUG - 2024-02-12 13:55:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:55:16 --> Model Class Initialized
INFO - 2024-02-12 13:55:16 --> Final output sent to browser
DEBUG - 2024-02-12 13:55:16 --> Total execution time: 0.0216
ERROR - 2024-02-12 13:55:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 13:55:27 --> Config Class Initialized
INFO - 2024-02-12 13:55:27 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:55:27 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:55:27 --> Utf8 Class Initialized
INFO - 2024-02-12 13:55:27 --> URI Class Initialized
INFO - 2024-02-12 13:55:27 --> Router Class Initialized
INFO - 2024-02-12 13:55:27 --> Output Class Initialized
INFO - 2024-02-12 13:55:27 --> Security Class Initialized
DEBUG - 2024-02-12 13:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:55:27 --> Input Class Initialized
INFO - 2024-02-12 13:55:27 --> Language Class Initialized
INFO - 2024-02-12 13:55:27 --> Loader Class Initialized
INFO - 2024-02-12 13:55:27 --> Helper loaded: url_helper
INFO - 2024-02-12 13:55:27 --> Helper loaded: file_helper
INFO - 2024-02-12 13:55:27 --> Helper loaded: html_helper
INFO - 2024-02-12 13:55:27 --> Helper loaded: text_helper
INFO - 2024-02-12 13:55:27 --> Helper loaded: form_helper
INFO - 2024-02-12 13:55:27 --> Helper loaded: lang_helper
INFO - 2024-02-12 13:55:27 --> Helper loaded: security_helper
INFO - 2024-02-12 13:55:27 --> Helper loaded: cookie_helper
INFO - 2024-02-12 13:55:27 --> Database Driver Class Initialized
INFO - 2024-02-12 13:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:55:27 --> Parser Class Initialized
INFO - 2024-02-12 13:55:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 13:55:27 --> Pagination Class Initialized
INFO - 2024-02-12 13:55:27 --> Form Validation Class Initialized
INFO - 2024-02-12 13:55:27 --> Controller Class Initialized
DEBUG - 2024-02-12 13:55:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 13:55:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:55:27 --> Model Class Initialized
DEBUG - 2024-02-12 13:55:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:55:27 --> Model Class Initialized
INFO - 2024-02-12 13:55:27 --> Final output sent to browser
DEBUG - 2024-02-12 13:55:27 --> Total execution time: 0.0160
ERROR - 2024-02-12 13:57:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 13:57:25 --> Config Class Initialized
INFO - 2024-02-12 13:57:25 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:57:25 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:57:25 --> Utf8 Class Initialized
INFO - 2024-02-12 13:57:25 --> URI Class Initialized
INFO - 2024-02-12 13:57:25 --> Router Class Initialized
INFO - 2024-02-12 13:57:25 --> Output Class Initialized
INFO - 2024-02-12 13:57:25 --> Security Class Initialized
DEBUG - 2024-02-12 13:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:57:25 --> Input Class Initialized
INFO - 2024-02-12 13:57:25 --> Language Class Initialized
INFO - 2024-02-12 13:57:25 --> Loader Class Initialized
INFO - 2024-02-12 13:57:25 --> Helper loaded: url_helper
INFO - 2024-02-12 13:57:25 --> Helper loaded: file_helper
INFO - 2024-02-12 13:57:25 --> Helper loaded: html_helper
INFO - 2024-02-12 13:57:25 --> Helper loaded: text_helper
INFO - 2024-02-12 13:57:25 --> Helper loaded: form_helper
INFO - 2024-02-12 13:57:25 --> Helper loaded: lang_helper
INFO - 2024-02-12 13:57:25 --> Helper loaded: security_helper
INFO - 2024-02-12 13:57:25 --> Helper loaded: cookie_helper
INFO - 2024-02-12 13:57:25 --> Database Driver Class Initialized
INFO - 2024-02-12 13:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:57:25 --> Parser Class Initialized
INFO - 2024-02-12 13:57:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 13:57:25 --> Pagination Class Initialized
INFO - 2024-02-12 13:57:25 --> Form Validation Class Initialized
INFO - 2024-02-12 13:57:25 --> Controller Class Initialized
DEBUG - 2024-02-12 13:57:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 13:57:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:57:25 --> Model Class Initialized
DEBUG - 2024-02-12 13:57:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:57:25 --> Model Class Initialized
INFO - 2024-02-12 13:57:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2024-02-12 13:57:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:57:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 13:57:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 13:57:25 --> Model Class Initialized
INFO - 2024-02-12 13:57:25 --> Model Class Initialized
INFO - 2024-02-12 13:57:25 --> Model Class Initialized
INFO - 2024-02-12 13:57:25 --> Model Class Initialized
INFO - 2024-02-12 13:57:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 13:57:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 13:57:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 13:57:25 --> Final output sent to browser
DEBUG - 2024-02-12 13:57:25 --> Total execution time: 0.2091
ERROR - 2024-02-12 13:57:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 13:57:26 --> Config Class Initialized
INFO - 2024-02-12 13:57:26 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:57:26 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:57:26 --> Utf8 Class Initialized
INFO - 2024-02-12 13:57:26 --> URI Class Initialized
INFO - 2024-02-12 13:57:26 --> Router Class Initialized
INFO - 2024-02-12 13:57:26 --> Output Class Initialized
INFO - 2024-02-12 13:57:26 --> Security Class Initialized
DEBUG - 2024-02-12 13:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:57:26 --> Input Class Initialized
INFO - 2024-02-12 13:57:26 --> Language Class Initialized
INFO - 2024-02-12 13:57:26 --> Loader Class Initialized
INFO - 2024-02-12 13:57:26 --> Helper loaded: url_helper
INFO - 2024-02-12 13:57:26 --> Helper loaded: file_helper
INFO - 2024-02-12 13:57:26 --> Helper loaded: html_helper
INFO - 2024-02-12 13:57:26 --> Helper loaded: text_helper
INFO - 2024-02-12 13:57:26 --> Helper loaded: form_helper
INFO - 2024-02-12 13:57:26 --> Helper loaded: lang_helper
INFO - 2024-02-12 13:57:26 --> Helper loaded: security_helper
INFO - 2024-02-12 13:57:26 --> Helper loaded: cookie_helper
INFO - 2024-02-12 13:57:26 --> Database Driver Class Initialized
INFO - 2024-02-12 13:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:57:26 --> Parser Class Initialized
INFO - 2024-02-12 13:57:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 13:57:26 --> Pagination Class Initialized
INFO - 2024-02-12 13:57:26 --> Form Validation Class Initialized
INFO - 2024-02-12 13:57:26 --> Controller Class Initialized
DEBUG - 2024-02-12 13:57:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 13:57:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:57:26 --> Model Class Initialized
DEBUG - 2024-02-12 13:57:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:57:26 --> Model Class Initialized
INFO - 2024-02-12 13:57:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2024-02-12 13:57:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:57:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 13:57:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 13:57:26 --> Model Class Initialized
INFO - 2024-02-12 13:57:26 --> Model Class Initialized
INFO - 2024-02-12 13:57:26 --> Model Class Initialized
INFO - 2024-02-12 13:57:26 --> Model Class Initialized
INFO - 2024-02-12 13:57:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 13:57:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 13:57:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 13:57:26 --> Final output sent to browser
DEBUG - 2024-02-12 13:57:26 --> Total execution time: 0.2019
ERROR - 2024-02-12 13:57:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 13:57:27 --> Config Class Initialized
INFO - 2024-02-12 13:57:27 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:57:27 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:57:27 --> Utf8 Class Initialized
INFO - 2024-02-12 13:57:27 --> URI Class Initialized
DEBUG - 2024-02-12 13:57:27 --> No URI present. Default controller set.
INFO - 2024-02-12 13:57:27 --> Router Class Initialized
INFO - 2024-02-12 13:57:27 --> Output Class Initialized
INFO - 2024-02-12 13:57:27 --> Security Class Initialized
DEBUG - 2024-02-12 13:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:57:27 --> Input Class Initialized
INFO - 2024-02-12 13:57:27 --> Language Class Initialized
INFO - 2024-02-12 13:57:27 --> Loader Class Initialized
INFO - 2024-02-12 13:57:27 --> Helper loaded: url_helper
INFO - 2024-02-12 13:57:27 --> Helper loaded: file_helper
INFO - 2024-02-12 13:57:27 --> Helper loaded: html_helper
INFO - 2024-02-12 13:57:27 --> Helper loaded: text_helper
INFO - 2024-02-12 13:57:27 --> Helper loaded: form_helper
INFO - 2024-02-12 13:57:27 --> Helper loaded: lang_helper
INFO - 2024-02-12 13:57:27 --> Helper loaded: security_helper
INFO - 2024-02-12 13:57:27 --> Helper loaded: cookie_helper
INFO - 2024-02-12 13:57:27 --> Database Driver Class Initialized
INFO - 2024-02-12 13:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:57:27 --> Parser Class Initialized
INFO - 2024-02-12 13:57:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 13:57:27 --> Pagination Class Initialized
INFO - 2024-02-12 13:57:27 --> Form Validation Class Initialized
INFO - 2024-02-12 13:57:27 --> Controller Class Initialized
INFO - 2024-02-12 13:57:27 --> Model Class Initialized
DEBUG - 2024-02-12 13:57:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:57:27 --> Model Class Initialized
DEBUG - 2024-02-12 13:57:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:57:27 --> Model Class Initialized
INFO - 2024-02-12 13:57:27 --> Model Class Initialized
INFO - 2024-02-12 13:57:27 --> Model Class Initialized
INFO - 2024-02-12 13:57:27 --> Model Class Initialized
DEBUG - 2024-02-12 13:57:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 13:57:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:57:27 --> Model Class Initialized
INFO - 2024-02-12 13:57:27 --> Model Class Initialized
INFO - 2024-02-12 13:57:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-12 13:57:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:57:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 13:57:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 13:57:27 --> Model Class Initialized
INFO - 2024-02-12 13:57:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 13:57:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 13:57:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 13:57:28 --> Final output sent to browser
DEBUG - 2024-02-12 13:57:28 --> Total execution time: 0.2463
ERROR - 2024-02-12 13:58:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 13:58:15 --> Config Class Initialized
INFO - 2024-02-12 13:58:15 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:58:15 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:58:15 --> Utf8 Class Initialized
INFO - 2024-02-12 13:58:15 --> URI Class Initialized
DEBUG - 2024-02-12 13:58:15 --> No URI present. Default controller set.
INFO - 2024-02-12 13:58:15 --> Router Class Initialized
INFO - 2024-02-12 13:58:15 --> Output Class Initialized
INFO - 2024-02-12 13:58:15 --> Security Class Initialized
DEBUG - 2024-02-12 13:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:58:15 --> Input Class Initialized
INFO - 2024-02-12 13:58:15 --> Language Class Initialized
INFO - 2024-02-12 13:58:15 --> Loader Class Initialized
INFO - 2024-02-12 13:58:15 --> Helper loaded: url_helper
INFO - 2024-02-12 13:58:15 --> Helper loaded: file_helper
INFO - 2024-02-12 13:58:15 --> Helper loaded: html_helper
INFO - 2024-02-12 13:58:15 --> Helper loaded: text_helper
INFO - 2024-02-12 13:58:15 --> Helper loaded: form_helper
INFO - 2024-02-12 13:58:15 --> Helper loaded: lang_helper
INFO - 2024-02-12 13:58:15 --> Helper loaded: security_helper
INFO - 2024-02-12 13:58:15 --> Helper loaded: cookie_helper
INFO - 2024-02-12 13:58:15 --> Database Driver Class Initialized
INFO - 2024-02-12 13:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:58:15 --> Parser Class Initialized
INFO - 2024-02-12 13:58:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 13:58:15 --> Pagination Class Initialized
INFO - 2024-02-12 13:58:15 --> Form Validation Class Initialized
INFO - 2024-02-12 13:58:15 --> Controller Class Initialized
INFO - 2024-02-12 13:58:15 --> Model Class Initialized
DEBUG - 2024-02-12 13:58:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-12 13:58:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 13:58:15 --> Config Class Initialized
INFO - 2024-02-12 13:58:15 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:58:15 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:58:15 --> Utf8 Class Initialized
INFO - 2024-02-12 13:58:15 --> URI Class Initialized
INFO - 2024-02-12 13:58:15 --> Router Class Initialized
INFO - 2024-02-12 13:58:15 --> Output Class Initialized
INFO - 2024-02-12 13:58:15 --> Security Class Initialized
DEBUG - 2024-02-12 13:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:58:15 --> Input Class Initialized
INFO - 2024-02-12 13:58:15 --> Language Class Initialized
INFO - 2024-02-12 13:58:15 --> Loader Class Initialized
INFO - 2024-02-12 13:58:15 --> Helper loaded: url_helper
INFO - 2024-02-12 13:58:15 --> Helper loaded: file_helper
INFO - 2024-02-12 13:58:15 --> Helper loaded: html_helper
INFO - 2024-02-12 13:58:15 --> Helper loaded: text_helper
INFO - 2024-02-12 13:58:15 --> Helper loaded: form_helper
INFO - 2024-02-12 13:58:15 --> Helper loaded: lang_helper
INFO - 2024-02-12 13:58:15 --> Helper loaded: security_helper
INFO - 2024-02-12 13:58:15 --> Helper loaded: cookie_helper
INFO - 2024-02-12 13:58:15 --> Database Driver Class Initialized
INFO - 2024-02-12 13:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:58:15 --> Parser Class Initialized
INFO - 2024-02-12 13:58:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 13:58:15 --> Pagination Class Initialized
INFO - 2024-02-12 13:58:15 --> Form Validation Class Initialized
INFO - 2024-02-12 13:58:15 --> Controller Class Initialized
INFO - 2024-02-12 13:58:15 --> Model Class Initialized
DEBUG - 2024-02-12 13:58:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:58:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-12 13:58:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:58:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 13:58:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 13:58:15 --> Model Class Initialized
INFO - 2024-02-12 13:58:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 13:58:15 --> Final output sent to browser
DEBUG - 2024-02-12 13:58:15 --> Total execution time: 0.0310
ERROR - 2024-02-12 13:58:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 13:58:31 --> Config Class Initialized
INFO - 2024-02-12 13:58:31 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:58:31 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:58:31 --> Utf8 Class Initialized
INFO - 2024-02-12 13:58:31 --> URI Class Initialized
INFO - 2024-02-12 13:58:31 --> Router Class Initialized
INFO - 2024-02-12 13:58:31 --> Output Class Initialized
INFO - 2024-02-12 13:58:31 --> Security Class Initialized
DEBUG - 2024-02-12 13:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:58:31 --> Input Class Initialized
INFO - 2024-02-12 13:58:31 --> Language Class Initialized
INFO - 2024-02-12 13:58:31 --> Loader Class Initialized
INFO - 2024-02-12 13:58:31 --> Helper loaded: url_helper
INFO - 2024-02-12 13:58:31 --> Helper loaded: file_helper
INFO - 2024-02-12 13:58:31 --> Helper loaded: html_helper
INFO - 2024-02-12 13:58:31 --> Helper loaded: text_helper
INFO - 2024-02-12 13:58:31 --> Helper loaded: form_helper
INFO - 2024-02-12 13:58:31 --> Helper loaded: lang_helper
INFO - 2024-02-12 13:58:31 --> Helper loaded: security_helper
INFO - 2024-02-12 13:58:31 --> Helper loaded: cookie_helper
INFO - 2024-02-12 13:58:31 --> Database Driver Class Initialized
INFO - 2024-02-12 13:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:58:31 --> Parser Class Initialized
INFO - 2024-02-12 13:58:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 13:58:31 --> Pagination Class Initialized
INFO - 2024-02-12 13:58:31 --> Form Validation Class Initialized
INFO - 2024-02-12 13:58:31 --> Controller Class Initialized
DEBUG - 2024-02-12 13:58:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 13:58:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:58:31 --> Model Class Initialized
DEBUG - 2024-02-12 13:58:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:58:31 --> Model Class Initialized
DEBUG - 2024-02-12 13:58:31 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:58:31 --> Model Class Initialized
INFO - 2024-02-12 13:58:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-12 13:58:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:58:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 13:58:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 13:58:31 --> Model Class Initialized
INFO - 2024-02-12 13:58:31 --> Model Class Initialized
INFO - 2024-02-12 13:58:31 --> Model Class Initialized
INFO - 2024-02-12 13:58:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 13:58:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 13:58:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 13:58:31 --> Final output sent to browser
DEBUG - 2024-02-12 13:58:31 --> Total execution time: 0.1535
ERROR - 2024-02-12 13:58:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 13:58:32 --> Config Class Initialized
INFO - 2024-02-12 13:58:32 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:58:32 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:58:32 --> Utf8 Class Initialized
INFO - 2024-02-12 13:58:32 --> URI Class Initialized
INFO - 2024-02-12 13:58:32 --> Router Class Initialized
INFO - 2024-02-12 13:58:32 --> Output Class Initialized
INFO - 2024-02-12 13:58:32 --> Security Class Initialized
DEBUG - 2024-02-12 13:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:58:32 --> Input Class Initialized
INFO - 2024-02-12 13:58:32 --> Language Class Initialized
INFO - 2024-02-12 13:58:32 --> Loader Class Initialized
INFO - 2024-02-12 13:58:32 --> Helper loaded: url_helper
INFO - 2024-02-12 13:58:32 --> Helper loaded: file_helper
INFO - 2024-02-12 13:58:32 --> Helper loaded: html_helper
INFO - 2024-02-12 13:58:32 --> Helper loaded: text_helper
INFO - 2024-02-12 13:58:32 --> Helper loaded: form_helper
INFO - 2024-02-12 13:58:32 --> Helper loaded: lang_helper
INFO - 2024-02-12 13:58:32 --> Helper loaded: security_helper
INFO - 2024-02-12 13:58:32 --> Helper loaded: cookie_helper
INFO - 2024-02-12 13:58:32 --> Database Driver Class Initialized
INFO - 2024-02-12 13:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:58:32 --> Parser Class Initialized
INFO - 2024-02-12 13:58:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 13:58:32 --> Pagination Class Initialized
INFO - 2024-02-12 13:58:32 --> Form Validation Class Initialized
INFO - 2024-02-12 13:58:32 --> Controller Class Initialized
DEBUG - 2024-02-12 13:58:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 13:58:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:58:32 --> Model Class Initialized
DEBUG - 2024-02-12 13:58:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:58:32 --> Model Class Initialized
INFO - 2024-02-12 13:58:32 --> Final output sent to browser
DEBUG - 2024-02-12 13:58:32 --> Total execution time: 0.0217
ERROR - 2024-02-12 13:59:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 13:59:00 --> Config Class Initialized
INFO - 2024-02-12 13:59:00 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:59:00 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:59:00 --> Utf8 Class Initialized
INFO - 2024-02-12 13:59:00 --> URI Class Initialized
INFO - 2024-02-12 13:59:00 --> Router Class Initialized
INFO - 2024-02-12 13:59:00 --> Output Class Initialized
INFO - 2024-02-12 13:59:00 --> Security Class Initialized
DEBUG - 2024-02-12 13:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:59:00 --> Input Class Initialized
INFO - 2024-02-12 13:59:00 --> Language Class Initialized
INFO - 2024-02-12 13:59:00 --> Loader Class Initialized
INFO - 2024-02-12 13:59:00 --> Helper loaded: url_helper
INFO - 2024-02-12 13:59:00 --> Helper loaded: file_helper
INFO - 2024-02-12 13:59:00 --> Helper loaded: html_helper
INFO - 2024-02-12 13:59:00 --> Helper loaded: text_helper
INFO - 2024-02-12 13:59:00 --> Helper loaded: form_helper
INFO - 2024-02-12 13:59:00 --> Helper loaded: lang_helper
INFO - 2024-02-12 13:59:00 --> Helper loaded: security_helper
INFO - 2024-02-12 13:59:00 --> Helper loaded: cookie_helper
INFO - 2024-02-12 13:59:00 --> Database Driver Class Initialized
INFO - 2024-02-12 13:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:59:00 --> Parser Class Initialized
INFO - 2024-02-12 13:59:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 13:59:00 --> Pagination Class Initialized
INFO - 2024-02-12 13:59:00 --> Form Validation Class Initialized
INFO - 2024-02-12 13:59:00 --> Controller Class Initialized
INFO - 2024-02-12 13:59:00 --> Model Class Initialized
DEBUG - 2024-02-12 13:59:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:59:00 --> Model Class Initialized
INFO - 2024-02-12 13:59:00 --> Final output sent to browser
DEBUG - 2024-02-12 13:59:00 --> Total execution time: 0.0190
ERROR - 2024-02-12 13:59:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 13:59:00 --> Config Class Initialized
INFO - 2024-02-12 13:59:00 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:59:00 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:59:00 --> Utf8 Class Initialized
INFO - 2024-02-12 13:59:00 --> URI Class Initialized
DEBUG - 2024-02-12 13:59:00 --> No URI present. Default controller set.
INFO - 2024-02-12 13:59:00 --> Router Class Initialized
INFO - 2024-02-12 13:59:00 --> Output Class Initialized
INFO - 2024-02-12 13:59:00 --> Security Class Initialized
DEBUG - 2024-02-12 13:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:59:00 --> Input Class Initialized
INFO - 2024-02-12 13:59:00 --> Language Class Initialized
INFO - 2024-02-12 13:59:00 --> Loader Class Initialized
INFO - 2024-02-12 13:59:00 --> Helper loaded: url_helper
INFO - 2024-02-12 13:59:00 --> Helper loaded: file_helper
INFO - 2024-02-12 13:59:00 --> Helper loaded: html_helper
INFO - 2024-02-12 13:59:00 --> Helper loaded: text_helper
INFO - 2024-02-12 13:59:00 --> Helper loaded: form_helper
INFO - 2024-02-12 13:59:00 --> Helper loaded: lang_helper
INFO - 2024-02-12 13:59:00 --> Helper loaded: security_helper
INFO - 2024-02-12 13:59:00 --> Helper loaded: cookie_helper
INFO - 2024-02-12 13:59:00 --> Database Driver Class Initialized
INFO - 2024-02-12 13:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:59:00 --> Parser Class Initialized
INFO - 2024-02-12 13:59:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 13:59:00 --> Pagination Class Initialized
INFO - 2024-02-12 13:59:00 --> Form Validation Class Initialized
INFO - 2024-02-12 13:59:00 --> Controller Class Initialized
INFO - 2024-02-12 13:59:00 --> Model Class Initialized
DEBUG - 2024-02-12 13:59:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:59:00 --> Model Class Initialized
DEBUG - 2024-02-12 13:59:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:59:00 --> Model Class Initialized
INFO - 2024-02-12 13:59:00 --> Model Class Initialized
INFO - 2024-02-12 13:59:00 --> Model Class Initialized
INFO - 2024-02-12 13:59:00 --> Model Class Initialized
DEBUG - 2024-02-12 13:59:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 13:59:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:59:00 --> Model Class Initialized
INFO - 2024-02-12 13:59:00 --> Model Class Initialized
INFO - 2024-02-12 13:59:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-12 13:59:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:59:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 13:59:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 13:59:00 --> Model Class Initialized
INFO - 2024-02-12 13:59:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 13:59:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 13:59:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 13:59:00 --> Final output sent to browser
DEBUG - 2024-02-12 13:59:00 --> Total execution time: 0.2153
ERROR - 2024-02-12 13:59:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 13:59:17 --> Config Class Initialized
INFO - 2024-02-12 13:59:17 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:59:17 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:59:17 --> Utf8 Class Initialized
INFO - 2024-02-12 13:59:17 --> URI Class Initialized
DEBUG - 2024-02-12 13:59:17 --> No URI present. Default controller set.
INFO - 2024-02-12 13:59:17 --> Router Class Initialized
INFO - 2024-02-12 13:59:17 --> Output Class Initialized
INFO - 2024-02-12 13:59:17 --> Security Class Initialized
DEBUG - 2024-02-12 13:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:59:17 --> Input Class Initialized
INFO - 2024-02-12 13:59:17 --> Language Class Initialized
INFO - 2024-02-12 13:59:17 --> Loader Class Initialized
INFO - 2024-02-12 13:59:17 --> Helper loaded: url_helper
INFO - 2024-02-12 13:59:17 --> Helper loaded: file_helper
INFO - 2024-02-12 13:59:17 --> Helper loaded: html_helper
INFO - 2024-02-12 13:59:17 --> Helper loaded: text_helper
INFO - 2024-02-12 13:59:17 --> Helper loaded: form_helper
INFO - 2024-02-12 13:59:17 --> Helper loaded: lang_helper
INFO - 2024-02-12 13:59:17 --> Helper loaded: security_helper
INFO - 2024-02-12 13:59:17 --> Helper loaded: cookie_helper
INFO - 2024-02-12 13:59:17 --> Database Driver Class Initialized
INFO - 2024-02-12 13:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:59:17 --> Parser Class Initialized
INFO - 2024-02-12 13:59:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 13:59:17 --> Pagination Class Initialized
INFO - 2024-02-12 13:59:17 --> Form Validation Class Initialized
INFO - 2024-02-12 13:59:17 --> Controller Class Initialized
INFO - 2024-02-12 13:59:17 --> Model Class Initialized
DEBUG - 2024-02-12 13:59:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:59:17 --> Model Class Initialized
DEBUG - 2024-02-12 13:59:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:59:17 --> Model Class Initialized
INFO - 2024-02-12 13:59:17 --> Model Class Initialized
INFO - 2024-02-12 13:59:17 --> Model Class Initialized
INFO - 2024-02-12 13:59:17 --> Model Class Initialized
DEBUG - 2024-02-12 13:59:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 13:59:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:59:17 --> Model Class Initialized
INFO - 2024-02-12 13:59:17 --> Model Class Initialized
INFO - 2024-02-12 13:59:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-12 13:59:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:59:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 13:59:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 13:59:18 --> Model Class Initialized
INFO - 2024-02-12 13:59:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 13:59:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 13:59:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 13:59:18 --> Final output sent to browser
DEBUG - 2024-02-12 13:59:18 --> Total execution time: 0.2407
ERROR - 2024-02-12 13:59:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 13:59:33 --> Config Class Initialized
INFO - 2024-02-12 13:59:33 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:59:33 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:59:33 --> Utf8 Class Initialized
INFO - 2024-02-12 13:59:33 --> URI Class Initialized
INFO - 2024-02-12 13:59:33 --> Router Class Initialized
INFO - 2024-02-12 13:59:33 --> Output Class Initialized
INFO - 2024-02-12 13:59:33 --> Security Class Initialized
DEBUG - 2024-02-12 13:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:59:33 --> Input Class Initialized
INFO - 2024-02-12 13:59:33 --> Language Class Initialized
INFO - 2024-02-12 13:59:33 --> Loader Class Initialized
INFO - 2024-02-12 13:59:33 --> Helper loaded: url_helper
INFO - 2024-02-12 13:59:33 --> Helper loaded: file_helper
INFO - 2024-02-12 13:59:33 --> Helper loaded: html_helper
INFO - 2024-02-12 13:59:33 --> Helper loaded: text_helper
INFO - 2024-02-12 13:59:33 --> Helper loaded: form_helper
INFO - 2024-02-12 13:59:33 --> Helper loaded: lang_helper
INFO - 2024-02-12 13:59:33 --> Helper loaded: security_helper
INFO - 2024-02-12 13:59:33 --> Helper loaded: cookie_helper
INFO - 2024-02-12 13:59:33 --> Database Driver Class Initialized
INFO - 2024-02-12 13:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:59:33 --> Parser Class Initialized
INFO - 2024-02-12 13:59:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 13:59:33 --> Pagination Class Initialized
INFO - 2024-02-12 13:59:33 --> Form Validation Class Initialized
INFO - 2024-02-12 13:59:33 --> Controller Class Initialized
INFO - 2024-02-12 13:59:33 --> Model Class Initialized
DEBUG - 2024-02-12 13:59:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 13:59:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:59:33 --> Model Class Initialized
DEBUG - 2024-02-12 13:59:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:59:33 --> Model Class Initialized
INFO - 2024-02-12 13:59:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-02-12 13:59:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:59:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 13:59:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 13:59:33 --> Model Class Initialized
INFO - 2024-02-12 13:59:33 --> Model Class Initialized
INFO - 2024-02-12 13:59:33 --> Model Class Initialized
INFO - 2024-02-12 13:59:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 13:59:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 13:59:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 13:59:33 --> Final output sent to browser
DEBUG - 2024-02-12 13:59:33 --> Total execution time: 0.1991
ERROR - 2024-02-12 13:59:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 13:59:38 --> Config Class Initialized
INFO - 2024-02-12 13:59:38 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:59:38 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:59:38 --> Utf8 Class Initialized
INFO - 2024-02-12 13:59:38 --> URI Class Initialized
INFO - 2024-02-12 13:59:38 --> Router Class Initialized
INFO - 2024-02-12 13:59:38 --> Output Class Initialized
INFO - 2024-02-12 13:59:38 --> Security Class Initialized
DEBUG - 2024-02-12 13:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:59:38 --> Input Class Initialized
INFO - 2024-02-12 13:59:38 --> Language Class Initialized
INFO - 2024-02-12 13:59:38 --> Loader Class Initialized
INFO - 2024-02-12 13:59:38 --> Helper loaded: url_helper
INFO - 2024-02-12 13:59:38 --> Helper loaded: file_helper
INFO - 2024-02-12 13:59:38 --> Helper loaded: html_helper
INFO - 2024-02-12 13:59:38 --> Helper loaded: text_helper
INFO - 2024-02-12 13:59:38 --> Helper loaded: form_helper
INFO - 2024-02-12 13:59:38 --> Helper loaded: lang_helper
INFO - 2024-02-12 13:59:38 --> Helper loaded: security_helper
INFO - 2024-02-12 13:59:38 --> Helper loaded: cookie_helper
INFO - 2024-02-12 13:59:38 --> Database Driver Class Initialized
INFO - 2024-02-12 13:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:59:38 --> Parser Class Initialized
INFO - 2024-02-12 13:59:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 13:59:38 --> Pagination Class Initialized
INFO - 2024-02-12 13:59:38 --> Form Validation Class Initialized
INFO - 2024-02-12 13:59:38 --> Controller Class Initialized
INFO - 2024-02-12 13:59:38 --> Model Class Initialized
DEBUG - 2024-02-12 13:59:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:59:38 --> Final output sent to browser
DEBUG - 2024-02-12 13:59:38 --> Total execution time: 0.0170
ERROR - 2024-02-12 13:59:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 13:59:47 --> Config Class Initialized
INFO - 2024-02-12 13:59:47 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:59:47 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:59:47 --> Utf8 Class Initialized
INFO - 2024-02-12 13:59:47 --> URI Class Initialized
INFO - 2024-02-12 13:59:47 --> Router Class Initialized
INFO - 2024-02-12 13:59:47 --> Output Class Initialized
INFO - 2024-02-12 13:59:47 --> Security Class Initialized
DEBUG - 2024-02-12 13:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:59:47 --> Input Class Initialized
INFO - 2024-02-12 13:59:47 --> Language Class Initialized
INFO - 2024-02-12 13:59:47 --> Loader Class Initialized
INFO - 2024-02-12 13:59:47 --> Helper loaded: url_helper
INFO - 2024-02-12 13:59:47 --> Helper loaded: file_helper
INFO - 2024-02-12 13:59:47 --> Helper loaded: html_helper
INFO - 2024-02-12 13:59:47 --> Helper loaded: text_helper
INFO - 2024-02-12 13:59:47 --> Helper loaded: form_helper
INFO - 2024-02-12 13:59:47 --> Helper loaded: lang_helper
INFO - 2024-02-12 13:59:47 --> Helper loaded: security_helper
INFO - 2024-02-12 13:59:47 --> Helper loaded: cookie_helper
INFO - 2024-02-12 13:59:47 --> Database Driver Class Initialized
INFO - 2024-02-12 13:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:59:47 --> Parser Class Initialized
INFO - 2024-02-12 13:59:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 13:59:47 --> Pagination Class Initialized
INFO - 2024-02-12 13:59:47 --> Form Validation Class Initialized
INFO - 2024-02-12 13:59:47 --> Controller Class Initialized
INFO - 2024-02-12 13:59:47 --> Final output sent to browser
DEBUG - 2024-02-12 13:59:47 --> Total execution time: 0.0133
ERROR - 2024-02-12 13:59:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 13:59:55 --> Config Class Initialized
INFO - 2024-02-12 13:59:55 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:59:55 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:59:55 --> Utf8 Class Initialized
INFO - 2024-02-12 13:59:55 --> URI Class Initialized
INFO - 2024-02-12 13:59:55 --> Router Class Initialized
INFO - 2024-02-12 13:59:55 --> Output Class Initialized
INFO - 2024-02-12 13:59:55 --> Security Class Initialized
DEBUG - 2024-02-12 13:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:59:55 --> Input Class Initialized
INFO - 2024-02-12 13:59:55 --> Language Class Initialized
INFO - 2024-02-12 13:59:55 --> Loader Class Initialized
INFO - 2024-02-12 13:59:55 --> Helper loaded: url_helper
INFO - 2024-02-12 13:59:55 --> Helper loaded: file_helper
INFO - 2024-02-12 13:59:55 --> Helper loaded: html_helper
INFO - 2024-02-12 13:59:55 --> Helper loaded: text_helper
INFO - 2024-02-12 13:59:55 --> Helper loaded: form_helper
INFO - 2024-02-12 13:59:55 --> Helper loaded: lang_helper
INFO - 2024-02-12 13:59:55 --> Helper loaded: security_helper
INFO - 2024-02-12 13:59:55 --> Helper loaded: cookie_helper
INFO - 2024-02-12 13:59:55 --> Database Driver Class Initialized
INFO - 2024-02-12 13:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:59:55 --> Parser Class Initialized
INFO - 2024-02-12 13:59:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 13:59:55 --> Pagination Class Initialized
INFO - 2024-02-12 13:59:55 --> Form Validation Class Initialized
INFO - 2024-02-12 13:59:55 --> Controller Class Initialized
INFO - 2024-02-12 13:59:55 --> Model Class Initialized
DEBUG - 2024-02-12 13:59:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 13:59:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:59:55 --> Model Class Initialized
DEBUG - 2024-02-12 13:59:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:59:55 --> Model Class Initialized
INFO - 2024-02-12 13:59:55 --> Final output sent to browser
DEBUG - 2024-02-12 13:59:55 --> Total execution time: 0.0908
ERROR - 2024-02-12 13:59:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 13:59:57 --> Config Class Initialized
INFO - 2024-02-12 13:59:57 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:59:57 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:59:57 --> Utf8 Class Initialized
INFO - 2024-02-12 13:59:57 --> URI Class Initialized
INFO - 2024-02-12 13:59:57 --> Router Class Initialized
INFO - 2024-02-12 13:59:57 --> Output Class Initialized
INFO - 2024-02-12 13:59:57 --> Security Class Initialized
DEBUG - 2024-02-12 13:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:59:57 --> Input Class Initialized
INFO - 2024-02-12 13:59:57 --> Language Class Initialized
INFO - 2024-02-12 13:59:57 --> Loader Class Initialized
INFO - 2024-02-12 13:59:57 --> Helper loaded: url_helper
INFO - 2024-02-12 13:59:57 --> Helper loaded: file_helper
INFO - 2024-02-12 13:59:57 --> Helper loaded: html_helper
INFO - 2024-02-12 13:59:57 --> Helper loaded: text_helper
INFO - 2024-02-12 13:59:57 --> Helper loaded: form_helper
INFO - 2024-02-12 13:59:57 --> Helper loaded: lang_helper
INFO - 2024-02-12 13:59:57 --> Helper loaded: security_helper
INFO - 2024-02-12 13:59:57 --> Helper loaded: cookie_helper
INFO - 2024-02-12 13:59:57 --> Database Driver Class Initialized
INFO - 2024-02-12 13:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:59:57 --> Parser Class Initialized
INFO - 2024-02-12 13:59:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 13:59:57 --> Pagination Class Initialized
INFO - 2024-02-12 13:59:57 --> Form Validation Class Initialized
INFO - 2024-02-12 13:59:57 --> Controller Class Initialized
INFO - 2024-02-12 13:59:57 --> Model Class Initialized
DEBUG - 2024-02-12 13:59:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 13:59:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:59:57 --> Model Class Initialized
DEBUG - 2024-02-12 13:59:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:59:57 --> Model Class Initialized
INFO - 2024-02-12 13:59:57 --> Final output sent to browser
DEBUG - 2024-02-12 13:59:57 --> Total execution time: 0.0913
ERROR - 2024-02-12 13:59:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 13:59:59 --> Config Class Initialized
INFO - 2024-02-12 13:59:59 --> Hooks Class Initialized
DEBUG - 2024-02-12 13:59:59 --> UTF-8 Support Enabled
INFO - 2024-02-12 13:59:59 --> Utf8 Class Initialized
INFO - 2024-02-12 13:59:59 --> URI Class Initialized
INFO - 2024-02-12 13:59:59 --> Router Class Initialized
INFO - 2024-02-12 13:59:59 --> Output Class Initialized
INFO - 2024-02-12 13:59:59 --> Security Class Initialized
DEBUG - 2024-02-12 13:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 13:59:59 --> Input Class Initialized
INFO - 2024-02-12 13:59:59 --> Language Class Initialized
INFO - 2024-02-12 13:59:59 --> Loader Class Initialized
INFO - 2024-02-12 13:59:59 --> Helper loaded: url_helper
INFO - 2024-02-12 13:59:59 --> Helper loaded: file_helper
INFO - 2024-02-12 13:59:59 --> Helper loaded: html_helper
INFO - 2024-02-12 13:59:59 --> Helper loaded: text_helper
INFO - 2024-02-12 13:59:59 --> Helper loaded: form_helper
INFO - 2024-02-12 13:59:59 --> Helper loaded: lang_helper
INFO - 2024-02-12 13:59:59 --> Helper loaded: security_helper
INFO - 2024-02-12 13:59:59 --> Helper loaded: cookie_helper
INFO - 2024-02-12 13:59:59 --> Database Driver Class Initialized
INFO - 2024-02-12 13:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 13:59:59 --> Parser Class Initialized
INFO - 2024-02-12 13:59:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 13:59:59 --> Pagination Class Initialized
INFO - 2024-02-12 13:59:59 --> Form Validation Class Initialized
INFO - 2024-02-12 13:59:59 --> Controller Class Initialized
INFO - 2024-02-12 13:59:59 --> Model Class Initialized
DEBUG - 2024-02-12 13:59:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 13:59:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 13:59:59 --> Model Class Initialized
INFO - 2024-02-12 13:59:59 --> Model Class Initialized
INFO - 2024-02-12 13:59:59 --> Final output sent to browser
DEBUG - 2024-02-12 13:59:59 --> Total execution time: 0.0235
ERROR - 2024-02-12 14:00:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:00:00 --> Config Class Initialized
INFO - 2024-02-12 14:00:00 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:00:00 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:00:00 --> Utf8 Class Initialized
INFO - 2024-02-12 14:00:00 --> URI Class Initialized
INFO - 2024-02-12 14:00:00 --> Router Class Initialized
INFO - 2024-02-12 14:00:00 --> Output Class Initialized
INFO - 2024-02-12 14:00:00 --> Security Class Initialized
DEBUG - 2024-02-12 14:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:00:00 --> Input Class Initialized
INFO - 2024-02-12 14:00:00 --> Language Class Initialized
INFO - 2024-02-12 14:00:00 --> Loader Class Initialized
INFO - 2024-02-12 14:00:00 --> Helper loaded: url_helper
INFO - 2024-02-12 14:00:00 --> Helper loaded: file_helper
INFO - 2024-02-12 14:00:00 --> Helper loaded: html_helper
INFO - 2024-02-12 14:00:00 --> Helper loaded: text_helper
INFO - 2024-02-12 14:00:00 --> Helper loaded: form_helper
INFO - 2024-02-12 14:00:00 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:00:00 --> Helper loaded: security_helper
INFO - 2024-02-12 14:00:00 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:00:00 --> Database Driver Class Initialized
INFO - 2024-02-12 14:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:00:00 --> Parser Class Initialized
INFO - 2024-02-12 14:00:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:00:00 --> Pagination Class Initialized
INFO - 2024-02-12 14:00:00 --> Form Validation Class Initialized
INFO - 2024-02-12 14:00:00 --> Controller Class Initialized
INFO - 2024-02-12 14:00:00 --> Model Class Initialized
DEBUG - 2024-02-12 14:00:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:00:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:00:00 --> Model Class Initialized
INFO - 2024-02-12 14:00:00 --> Final output sent to browser
DEBUG - 2024-02-12 14:00:00 --> Total execution time: 0.0160
ERROR - 2024-02-12 14:00:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:00:02 --> Config Class Initialized
INFO - 2024-02-12 14:00:02 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:00:02 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:00:02 --> Utf8 Class Initialized
INFO - 2024-02-12 14:00:02 --> URI Class Initialized
INFO - 2024-02-12 14:00:02 --> Router Class Initialized
INFO - 2024-02-12 14:00:02 --> Output Class Initialized
INFO - 2024-02-12 14:00:02 --> Security Class Initialized
DEBUG - 2024-02-12 14:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:00:02 --> Input Class Initialized
INFO - 2024-02-12 14:00:02 --> Language Class Initialized
INFO - 2024-02-12 14:00:02 --> Loader Class Initialized
INFO - 2024-02-12 14:00:02 --> Helper loaded: url_helper
INFO - 2024-02-12 14:00:02 --> Helper loaded: file_helper
INFO - 2024-02-12 14:00:02 --> Helper loaded: html_helper
INFO - 2024-02-12 14:00:02 --> Helper loaded: text_helper
INFO - 2024-02-12 14:00:02 --> Helper loaded: form_helper
INFO - 2024-02-12 14:00:02 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:00:02 --> Helper loaded: security_helper
INFO - 2024-02-12 14:00:02 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:00:02 --> Database Driver Class Initialized
INFO - 2024-02-12 14:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:00:02 --> Parser Class Initialized
INFO - 2024-02-12 14:00:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:00:02 --> Pagination Class Initialized
INFO - 2024-02-12 14:00:02 --> Form Validation Class Initialized
INFO - 2024-02-12 14:00:02 --> Controller Class Initialized
INFO - 2024-02-12 14:00:02 --> Model Class Initialized
DEBUG - 2024-02-12 14:00:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:00:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:00:02 --> Model Class Initialized
INFO - 2024-02-12 14:00:02 --> Final output sent to browser
DEBUG - 2024-02-12 14:00:02 --> Total execution time: 0.0172
ERROR - 2024-02-12 14:00:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:00:22 --> Config Class Initialized
INFO - 2024-02-12 14:00:22 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:00:22 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:00:22 --> Utf8 Class Initialized
INFO - 2024-02-12 14:00:22 --> URI Class Initialized
INFO - 2024-02-12 14:00:22 --> Router Class Initialized
INFO - 2024-02-12 14:00:22 --> Output Class Initialized
INFO - 2024-02-12 14:00:22 --> Security Class Initialized
DEBUG - 2024-02-12 14:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:00:22 --> Input Class Initialized
INFO - 2024-02-12 14:00:22 --> Language Class Initialized
INFO - 2024-02-12 14:00:22 --> Loader Class Initialized
INFO - 2024-02-12 14:00:22 --> Helper loaded: url_helper
INFO - 2024-02-12 14:00:22 --> Helper loaded: file_helper
INFO - 2024-02-12 14:00:22 --> Helper loaded: html_helper
INFO - 2024-02-12 14:00:22 --> Helper loaded: text_helper
INFO - 2024-02-12 14:00:22 --> Helper loaded: form_helper
INFO - 2024-02-12 14:00:22 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:00:22 --> Helper loaded: security_helper
INFO - 2024-02-12 14:00:22 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:00:22 --> Database Driver Class Initialized
INFO - 2024-02-12 14:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:00:22 --> Parser Class Initialized
INFO - 2024-02-12 14:00:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:00:22 --> Pagination Class Initialized
INFO - 2024-02-12 14:00:22 --> Form Validation Class Initialized
INFO - 2024-02-12 14:00:22 --> Controller Class Initialized
INFO - 2024-02-12 14:00:22 --> Model Class Initialized
DEBUG - 2024-02-12 14:00:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:00:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:00:22 --> Model Class Initialized
DEBUG - 2024-02-12 14:00:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:00:22 --> Model Class Initialized
INFO - 2024-02-12 14:00:22 --> Final output sent to browser
DEBUG - 2024-02-12 14:00:22 --> Total execution time: 0.0975
ERROR - 2024-02-12 14:00:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:00:25 --> Config Class Initialized
INFO - 2024-02-12 14:00:25 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:00:25 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:00:25 --> Utf8 Class Initialized
INFO - 2024-02-12 14:00:25 --> URI Class Initialized
INFO - 2024-02-12 14:00:25 --> Router Class Initialized
INFO - 2024-02-12 14:00:25 --> Output Class Initialized
INFO - 2024-02-12 14:00:25 --> Security Class Initialized
DEBUG - 2024-02-12 14:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:00:25 --> Input Class Initialized
INFO - 2024-02-12 14:00:25 --> Language Class Initialized
INFO - 2024-02-12 14:00:25 --> Loader Class Initialized
INFO - 2024-02-12 14:00:25 --> Helper loaded: url_helper
INFO - 2024-02-12 14:00:25 --> Helper loaded: file_helper
INFO - 2024-02-12 14:00:25 --> Helper loaded: html_helper
INFO - 2024-02-12 14:00:25 --> Helper loaded: text_helper
INFO - 2024-02-12 14:00:25 --> Helper loaded: form_helper
INFO - 2024-02-12 14:00:25 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:00:25 --> Helper loaded: security_helper
INFO - 2024-02-12 14:00:25 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:00:25 --> Database Driver Class Initialized
INFO - 2024-02-12 14:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:00:25 --> Parser Class Initialized
INFO - 2024-02-12 14:00:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:00:25 --> Pagination Class Initialized
INFO - 2024-02-12 14:00:25 --> Form Validation Class Initialized
INFO - 2024-02-12 14:00:25 --> Controller Class Initialized
INFO - 2024-02-12 14:00:25 --> Model Class Initialized
DEBUG - 2024-02-12 14:00:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:00:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:00:25 --> Model Class Initialized
DEBUG - 2024-02-12 14:00:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:00:25 --> Model Class Initialized
INFO - 2024-02-12 14:00:25 --> Final output sent to browser
DEBUG - 2024-02-12 14:00:25 --> Total execution time: 0.0998
ERROR - 2024-02-12 14:00:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:00:25 --> Config Class Initialized
INFO - 2024-02-12 14:00:25 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:00:25 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:00:25 --> Utf8 Class Initialized
INFO - 2024-02-12 14:00:25 --> URI Class Initialized
INFO - 2024-02-12 14:00:25 --> Router Class Initialized
INFO - 2024-02-12 14:00:25 --> Output Class Initialized
INFO - 2024-02-12 14:00:25 --> Security Class Initialized
DEBUG - 2024-02-12 14:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:00:25 --> Input Class Initialized
INFO - 2024-02-12 14:00:25 --> Language Class Initialized
INFO - 2024-02-12 14:00:25 --> Loader Class Initialized
INFO - 2024-02-12 14:00:25 --> Helper loaded: url_helper
INFO - 2024-02-12 14:00:25 --> Helper loaded: file_helper
INFO - 2024-02-12 14:00:25 --> Helper loaded: html_helper
INFO - 2024-02-12 14:00:25 --> Helper loaded: text_helper
INFO - 2024-02-12 14:00:25 --> Helper loaded: form_helper
INFO - 2024-02-12 14:00:25 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:00:25 --> Helper loaded: security_helper
INFO - 2024-02-12 14:00:25 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:00:25 --> Database Driver Class Initialized
INFO - 2024-02-12 14:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:00:25 --> Parser Class Initialized
INFO - 2024-02-12 14:00:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:00:25 --> Pagination Class Initialized
INFO - 2024-02-12 14:00:25 --> Form Validation Class Initialized
INFO - 2024-02-12 14:00:25 --> Controller Class Initialized
INFO - 2024-02-12 14:00:25 --> Model Class Initialized
DEBUG - 2024-02-12 14:00:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:00:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:00:25 --> Model Class Initialized
DEBUG - 2024-02-12 14:00:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:00:25 --> Model Class Initialized
INFO - 2024-02-12 14:00:26 --> Final output sent to browser
DEBUG - 2024-02-12 14:00:26 --> Total execution time: 0.0921
ERROR - 2024-02-12 14:00:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:00:28 --> Config Class Initialized
INFO - 2024-02-12 14:00:28 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:00:28 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:00:28 --> Utf8 Class Initialized
INFO - 2024-02-12 14:00:28 --> URI Class Initialized
INFO - 2024-02-12 14:00:28 --> Router Class Initialized
INFO - 2024-02-12 14:00:28 --> Output Class Initialized
INFO - 2024-02-12 14:00:28 --> Security Class Initialized
DEBUG - 2024-02-12 14:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:00:28 --> Input Class Initialized
INFO - 2024-02-12 14:00:28 --> Language Class Initialized
INFO - 2024-02-12 14:00:28 --> Loader Class Initialized
INFO - 2024-02-12 14:00:28 --> Helper loaded: url_helper
INFO - 2024-02-12 14:00:28 --> Helper loaded: file_helper
INFO - 2024-02-12 14:00:28 --> Helper loaded: html_helper
INFO - 2024-02-12 14:00:28 --> Helper loaded: text_helper
INFO - 2024-02-12 14:00:28 --> Helper loaded: form_helper
INFO - 2024-02-12 14:00:28 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:00:28 --> Helper loaded: security_helper
INFO - 2024-02-12 14:00:28 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:00:28 --> Database Driver Class Initialized
INFO - 2024-02-12 14:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:00:28 --> Parser Class Initialized
INFO - 2024-02-12 14:00:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:00:28 --> Pagination Class Initialized
INFO - 2024-02-12 14:00:28 --> Form Validation Class Initialized
INFO - 2024-02-12 14:00:28 --> Controller Class Initialized
INFO - 2024-02-12 14:00:28 --> Model Class Initialized
DEBUG - 2024-02-12 14:00:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:00:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:00:28 --> Model Class Initialized
DEBUG - 2024-02-12 14:00:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:00:28 --> Model Class Initialized
INFO - 2024-02-12 14:00:28 --> Final output sent to browser
DEBUG - 2024-02-12 14:00:28 --> Total execution time: 0.0214
ERROR - 2024-02-12 14:00:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:00:30 --> Config Class Initialized
INFO - 2024-02-12 14:00:30 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:00:30 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:00:30 --> Utf8 Class Initialized
INFO - 2024-02-12 14:00:30 --> URI Class Initialized
INFO - 2024-02-12 14:00:30 --> Router Class Initialized
INFO - 2024-02-12 14:00:30 --> Output Class Initialized
INFO - 2024-02-12 14:00:30 --> Security Class Initialized
DEBUG - 2024-02-12 14:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:00:30 --> Input Class Initialized
INFO - 2024-02-12 14:00:30 --> Language Class Initialized
INFO - 2024-02-12 14:00:30 --> Loader Class Initialized
INFO - 2024-02-12 14:00:30 --> Helper loaded: url_helper
INFO - 2024-02-12 14:00:30 --> Helper loaded: file_helper
INFO - 2024-02-12 14:00:30 --> Helper loaded: html_helper
INFO - 2024-02-12 14:00:30 --> Helper loaded: text_helper
INFO - 2024-02-12 14:00:30 --> Helper loaded: form_helper
INFO - 2024-02-12 14:00:30 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:00:30 --> Helper loaded: security_helper
INFO - 2024-02-12 14:00:30 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:00:30 --> Database Driver Class Initialized
INFO - 2024-02-12 14:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:00:30 --> Parser Class Initialized
INFO - 2024-02-12 14:00:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:00:30 --> Pagination Class Initialized
INFO - 2024-02-12 14:00:30 --> Form Validation Class Initialized
INFO - 2024-02-12 14:00:30 --> Controller Class Initialized
INFO - 2024-02-12 14:00:30 --> Model Class Initialized
DEBUG - 2024-02-12 14:00:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:00:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:00:30 --> Model Class Initialized
DEBUG - 2024-02-12 14:00:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:00:30 --> Model Class Initialized
INFO - 2024-02-12 14:00:30 --> Final output sent to browser
DEBUG - 2024-02-12 14:00:30 --> Total execution time: 0.0231
ERROR - 2024-02-12 14:00:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:00:33 --> Config Class Initialized
INFO - 2024-02-12 14:00:33 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:00:33 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:00:33 --> Utf8 Class Initialized
INFO - 2024-02-12 14:00:33 --> URI Class Initialized
INFO - 2024-02-12 14:00:33 --> Router Class Initialized
INFO - 2024-02-12 14:00:33 --> Output Class Initialized
INFO - 2024-02-12 14:00:33 --> Security Class Initialized
DEBUG - 2024-02-12 14:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:00:33 --> Input Class Initialized
INFO - 2024-02-12 14:00:33 --> Language Class Initialized
INFO - 2024-02-12 14:00:33 --> Loader Class Initialized
INFO - 2024-02-12 14:00:33 --> Helper loaded: url_helper
INFO - 2024-02-12 14:00:33 --> Helper loaded: file_helper
INFO - 2024-02-12 14:00:33 --> Helper loaded: html_helper
INFO - 2024-02-12 14:00:33 --> Helper loaded: text_helper
INFO - 2024-02-12 14:00:33 --> Helper loaded: form_helper
INFO - 2024-02-12 14:00:33 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:00:33 --> Helper loaded: security_helper
INFO - 2024-02-12 14:00:33 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:00:33 --> Database Driver Class Initialized
INFO - 2024-02-12 14:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:00:33 --> Parser Class Initialized
INFO - 2024-02-12 14:00:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:00:33 --> Pagination Class Initialized
INFO - 2024-02-12 14:00:33 --> Form Validation Class Initialized
INFO - 2024-02-12 14:00:33 --> Controller Class Initialized
INFO - 2024-02-12 14:00:33 --> Model Class Initialized
DEBUG - 2024-02-12 14:00:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:00:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:00:33 --> Model Class Initialized
DEBUG - 2024-02-12 14:00:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:00:33 --> Model Class Initialized
INFO - 2024-02-12 14:00:33 --> Final output sent to browser
DEBUG - 2024-02-12 14:00:33 --> Total execution time: 0.0239
ERROR - 2024-02-12 14:00:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:00:36 --> Config Class Initialized
INFO - 2024-02-12 14:00:36 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:00:36 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:00:36 --> Utf8 Class Initialized
INFO - 2024-02-12 14:00:36 --> URI Class Initialized
INFO - 2024-02-12 14:00:36 --> Router Class Initialized
INFO - 2024-02-12 14:00:36 --> Output Class Initialized
INFO - 2024-02-12 14:00:36 --> Security Class Initialized
DEBUG - 2024-02-12 14:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:00:36 --> Input Class Initialized
INFO - 2024-02-12 14:00:36 --> Language Class Initialized
INFO - 2024-02-12 14:00:36 --> Loader Class Initialized
INFO - 2024-02-12 14:00:36 --> Helper loaded: url_helper
INFO - 2024-02-12 14:00:36 --> Helper loaded: file_helper
INFO - 2024-02-12 14:00:36 --> Helper loaded: html_helper
INFO - 2024-02-12 14:00:36 --> Helper loaded: text_helper
INFO - 2024-02-12 14:00:36 --> Helper loaded: form_helper
INFO - 2024-02-12 14:00:36 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:00:36 --> Helper loaded: security_helper
INFO - 2024-02-12 14:00:36 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:00:36 --> Database Driver Class Initialized
INFO - 2024-02-12 14:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:00:36 --> Parser Class Initialized
INFO - 2024-02-12 14:00:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:00:36 --> Pagination Class Initialized
INFO - 2024-02-12 14:00:36 --> Form Validation Class Initialized
INFO - 2024-02-12 14:00:36 --> Controller Class Initialized
INFO - 2024-02-12 14:00:36 --> Model Class Initialized
DEBUG - 2024-02-12 14:00:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:00:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:00:36 --> Model Class Initialized
INFO - 2024-02-12 14:00:36 --> Model Class Initialized
INFO - 2024-02-12 14:00:36 --> Final output sent to browser
DEBUG - 2024-02-12 14:00:36 --> Total execution time: 0.0195
ERROR - 2024-02-12 14:00:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:00:39 --> Config Class Initialized
INFO - 2024-02-12 14:00:39 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:00:39 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:00:39 --> Utf8 Class Initialized
INFO - 2024-02-12 14:00:39 --> URI Class Initialized
INFO - 2024-02-12 14:00:39 --> Router Class Initialized
INFO - 2024-02-12 14:00:39 --> Output Class Initialized
INFO - 2024-02-12 14:00:39 --> Security Class Initialized
DEBUG - 2024-02-12 14:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:00:39 --> Input Class Initialized
INFO - 2024-02-12 14:00:39 --> Language Class Initialized
INFO - 2024-02-12 14:00:39 --> Loader Class Initialized
INFO - 2024-02-12 14:00:39 --> Helper loaded: url_helper
INFO - 2024-02-12 14:00:39 --> Helper loaded: file_helper
INFO - 2024-02-12 14:00:39 --> Helper loaded: html_helper
INFO - 2024-02-12 14:00:39 --> Helper loaded: text_helper
INFO - 2024-02-12 14:00:39 --> Helper loaded: form_helper
INFO - 2024-02-12 14:00:39 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:00:39 --> Helper loaded: security_helper
INFO - 2024-02-12 14:00:39 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:00:39 --> Database Driver Class Initialized
INFO - 2024-02-12 14:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:00:39 --> Parser Class Initialized
INFO - 2024-02-12 14:00:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:00:39 --> Pagination Class Initialized
INFO - 2024-02-12 14:00:39 --> Form Validation Class Initialized
INFO - 2024-02-12 14:00:39 --> Controller Class Initialized
INFO - 2024-02-12 14:00:39 --> Model Class Initialized
DEBUG - 2024-02-12 14:00:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:00:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:00:39 --> Model Class Initialized
INFO - 2024-02-12 14:00:39 --> Final output sent to browser
DEBUG - 2024-02-12 14:00:39 --> Total execution time: 0.0174
ERROR - 2024-02-12 14:00:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:00:57 --> Config Class Initialized
INFO - 2024-02-12 14:00:57 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:00:57 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:00:57 --> Utf8 Class Initialized
INFO - 2024-02-12 14:00:57 --> URI Class Initialized
INFO - 2024-02-12 14:00:57 --> Router Class Initialized
INFO - 2024-02-12 14:00:57 --> Output Class Initialized
INFO - 2024-02-12 14:00:57 --> Security Class Initialized
DEBUG - 2024-02-12 14:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:00:57 --> Input Class Initialized
INFO - 2024-02-12 14:00:57 --> Language Class Initialized
INFO - 2024-02-12 14:00:57 --> Loader Class Initialized
INFO - 2024-02-12 14:00:57 --> Helper loaded: url_helper
INFO - 2024-02-12 14:00:57 --> Helper loaded: file_helper
INFO - 2024-02-12 14:00:57 --> Helper loaded: html_helper
INFO - 2024-02-12 14:00:57 --> Helper loaded: text_helper
INFO - 2024-02-12 14:00:57 --> Helper loaded: form_helper
INFO - 2024-02-12 14:00:57 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:00:57 --> Helper loaded: security_helper
INFO - 2024-02-12 14:00:57 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:00:57 --> Database Driver Class Initialized
INFO - 2024-02-12 14:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:00:57 --> Parser Class Initialized
INFO - 2024-02-12 14:00:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:00:57 --> Pagination Class Initialized
INFO - 2024-02-12 14:00:57 --> Form Validation Class Initialized
INFO - 2024-02-12 14:00:57 --> Controller Class Initialized
INFO - 2024-02-12 14:00:57 --> Model Class Initialized
DEBUG - 2024-02-12 14:00:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:00:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:00:57 --> Model Class Initialized
DEBUG - 2024-02-12 14:00:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:00:57 --> Model Class Initialized
INFO - 2024-02-12 14:00:57 --> Final output sent to browser
DEBUG - 2024-02-12 14:00:57 --> Total execution time: 0.0938
ERROR - 2024-02-12 14:01:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:01:00 --> Config Class Initialized
INFO - 2024-02-12 14:01:00 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:01:00 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:01:00 --> Utf8 Class Initialized
INFO - 2024-02-12 14:01:00 --> URI Class Initialized
INFO - 2024-02-12 14:01:00 --> Router Class Initialized
INFO - 2024-02-12 14:01:00 --> Output Class Initialized
INFO - 2024-02-12 14:01:00 --> Security Class Initialized
DEBUG - 2024-02-12 14:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:01:00 --> Input Class Initialized
INFO - 2024-02-12 14:01:00 --> Language Class Initialized
INFO - 2024-02-12 14:01:00 --> Loader Class Initialized
INFO - 2024-02-12 14:01:00 --> Helper loaded: url_helper
INFO - 2024-02-12 14:01:00 --> Helper loaded: file_helper
INFO - 2024-02-12 14:01:00 --> Helper loaded: html_helper
INFO - 2024-02-12 14:01:00 --> Helper loaded: text_helper
INFO - 2024-02-12 14:01:00 --> Helper loaded: form_helper
INFO - 2024-02-12 14:01:00 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:01:00 --> Helper loaded: security_helper
INFO - 2024-02-12 14:01:00 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:01:00 --> Database Driver Class Initialized
INFO - 2024-02-12 14:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:01:00 --> Parser Class Initialized
INFO - 2024-02-12 14:01:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:01:00 --> Pagination Class Initialized
INFO - 2024-02-12 14:01:00 --> Form Validation Class Initialized
INFO - 2024-02-12 14:01:00 --> Controller Class Initialized
INFO - 2024-02-12 14:01:00 --> Model Class Initialized
DEBUG - 2024-02-12 14:01:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:01:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:01:00 --> Model Class Initialized
DEBUG - 2024-02-12 14:01:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:01:00 --> Model Class Initialized
INFO - 2024-02-12 14:01:00 --> Final output sent to browser
DEBUG - 2024-02-12 14:01:00 --> Total execution time: 0.0909
ERROR - 2024-02-12 14:01:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:01:01 --> Config Class Initialized
INFO - 2024-02-12 14:01:01 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:01:01 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:01:01 --> Utf8 Class Initialized
INFO - 2024-02-12 14:01:01 --> URI Class Initialized
INFO - 2024-02-12 14:01:01 --> Router Class Initialized
INFO - 2024-02-12 14:01:01 --> Output Class Initialized
INFO - 2024-02-12 14:01:01 --> Security Class Initialized
DEBUG - 2024-02-12 14:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:01:01 --> Input Class Initialized
INFO - 2024-02-12 14:01:01 --> Language Class Initialized
INFO - 2024-02-12 14:01:01 --> Loader Class Initialized
INFO - 2024-02-12 14:01:01 --> Helper loaded: url_helper
INFO - 2024-02-12 14:01:01 --> Helper loaded: file_helper
INFO - 2024-02-12 14:01:01 --> Helper loaded: html_helper
INFO - 2024-02-12 14:01:01 --> Helper loaded: text_helper
INFO - 2024-02-12 14:01:01 --> Helper loaded: form_helper
INFO - 2024-02-12 14:01:01 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:01:01 --> Helper loaded: security_helper
INFO - 2024-02-12 14:01:01 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:01:01 --> Database Driver Class Initialized
INFO - 2024-02-12 14:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:01:01 --> Parser Class Initialized
INFO - 2024-02-12 14:01:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:01:01 --> Pagination Class Initialized
INFO - 2024-02-12 14:01:01 --> Form Validation Class Initialized
INFO - 2024-02-12 14:01:01 --> Controller Class Initialized
INFO - 2024-02-12 14:01:01 --> Model Class Initialized
DEBUG - 2024-02-12 14:01:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:01:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:01:01 --> Model Class Initialized
DEBUG - 2024-02-12 14:01:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:01:01 --> Model Class Initialized
INFO - 2024-02-12 14:01:01 --> Final output sent to browser
DEBUG - 2024-02-12 14:01:01 --> Total execution time: 0.0991
ERROR - 2024-02-12 14:01:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:01:12 --> Config Class Initialized
INFO - 2024-02-12 14:01:12 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:01:12 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:01:12 --> Utf8 Class Initialized
INFO - 2024-02-12 14:01:12 --> URI Class Initialized
INFO - 2024-02-12 14:01:12 --> Router Class Initialized
INFO - 2024-02-12 14:01:12 --> Output Class Initialized
INFO - 2024-02-12 14:01:12 --> Security Class Initialized
DEBUG - 2024-02-12 14:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:01:12 --> Input Class Initialized
INFO - 2024-02-12 14:01:12 --> Language Class Initialized
INFO - 2024-02-12 14:01:12 --> Loader Class Initialized
INFO - 2024-02-12 14:01:12 --> Helper loaded: url_helper
INFO - 2024-02-12 14:01:12 --> Helper loaded: file_helper
INFO - 2024-02-12 14:01:12 --> Helper loaded: html_helper
INFO - 2024-02-12 14:01:12 --> Helper loaded: text_helper
INFO - 2024-02-12 14:01:12 --> Helper loaded: form_helper
INFO - 2024-02-12 14:01:12 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:01:12 --> Helper loaded: security_helper
INFO - 2024-02-12 14:01:12 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:01:12 --> Database Driver Class Initialized
INFO - 2024-02-12 14:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:01:12 --> Parser Class Initialized
INFO - 2024-02-12 14:01:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:01:12 --> Pagination Class Initialized
INFO - 2024-02-12 14:01:12 --> Form Validation Class Initialized
INFO - 2024-02-12 14:01:12 --> Controller Class Initialized
INFO - 2024-02-12 14:01:12 --> Model Class Initialized
DEBUG - 2024-02-12 14:01:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:01:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:01:12 --> Model Class Initialized
INFO - 2024-02-12 14:01:12 --> Model Class Initialized
INFO - 2024-02-12 14:01:12 --> Final output sent to browser
DEBUG - 2024-02-12 14:01:12 --> Total execution time: 0.0195
ERROR - 2024-02-12 14:01:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:01:16 --> Config Class Initialized
INFO - 2024-02-12 14:01:16 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:01:16 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:01:16 --> Utf8 Class Initialized
INFO - 2024-02-12 14:01:16 --> URI Class Initialized
INFO - 2024-02-12 14:01:16 --> Router Class Initialized
INFO - 2024-02-12 14:01:16 --> Output Class Initialized
INFO - 2024-02-12 14:01:16 --> Security Class Initialized
DEBUG - 2024-02-12 14:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:01:16 --> Input Class Initialized
INFO - 2024-02-12 14:01:16 --> Language Class Initialized
INFO - 2024-02-12 14:01:16 --> Loader Class Initialized
INFO - 2024-02-12 14:01:16 --> Helper loaded: url_helper
INFO - 2024-02-12 14:01:16 --> Helper loaded: file_helper
INFO - 2024-02-12 14:01:16 --> Helper loaded: html_helper
INFO - 2024-02-12 14:01:16 --> Helper loaded: text_helper
INFO - 2024-02-12 14:01:16 --> Helper loaded: form_helper
INFO - 2024-02-12 14:01:16 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:01:16 --> Helper loaded: security_helper
INFO - 2024-02-12 14:01:16 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:01:16 --> Database Driver Class Initialized
INFO - 2024-02-12 14:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:01:16 --> Parser Class Initialized
INFO - 2024-02-12 14:01:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:01:16 --> Pagination Class Initialized
INFO - 2024-02-12 14:01:16 --> Form Validation Class Initialized
INFO - 2024-02-12 14:01:16 --> Controller Class Initialized
INFO - 2024-02-12 14:01:16 --> Model Class Initialized
DEBUG - 2024-02-12 14:01:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:01:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:01:16 --> Model Class Initialized
INFO - 2024-02-12 14:01:16 --> Final output sent to browser
DEBUG - 2024-02-12 14:01:16 --> Total execution time: 0.0160
ERROR - 2024-02-12 14:01:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:01:28 --> Config Class Initialized
INFO - 2024-02-12 14:01:28 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:01:28 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:01:28 --> Utf8 Class Initialized
INFO - 2024-02-12 14:01:28 --> URI Class Initialized
INFO - 2024-02-12 14:01:28 --> Router Class Initialized
INFO - 2024-02-12 14:01:28 --> Output Class Initialized
INFO - 2024-02-12 14:01:28 --> Security Class Initialized
DEBUG - 2024-02-12 14:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:01:28 --> Input Class Initialized
INFO - 2024-02-12 14:01:28 --> Language Class Initialized
INFO - 2024-02-12 14:01:28 --> Loader Class Initialized
INFO - 2024-02-12 14:01:28 --> Helper loaded: url_helper
INFO - 2024-02-12 14:01:28 --> Helper loaded: file_helper
INFO - 2024-02-12 14:01:28 --> Helper loaded: html_helper
INFO - 2024-02-12 14:01:28 --> Helper loaded: text_helper
INFO - 2024-02-12 14:01:28 --> Helper loaded: form_helper
INFO - 2024-02-12 14:01:28 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:01:28 --> Helper loaded: security_helper
INFO - 2024-02-12 14:01:28 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:01:28 --> Database Driver Class Initialized
INFO - 2024-02-12 14:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:01:28 --> Parser Class Initialized
INFO - 2024-02-12 14:01:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:01:28 --> Pagination Class Initialized
INFO - 2024-02-12 14:01:28 --> Form Validation Class Initialized
INFO - 2024-02-12 14:01:28 --> Controller Class Initialized
INFO - 2024-02-12 14:01:28 --> Model Class Initialized
DEBUG - 2024-02-12 14:01:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:01:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:01:28 --> Model Class Initialized
DEBUG - 2024-02-12 14:01:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:01:28 --> Model Class Initialized
INFO - 2024-02-12 14:01:28 --> Email Class Initialized
DEBUG - 2024-02-12 14:01:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:01:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:01:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-02-12 14:01:28 --> Language file loaded: language/english/email_lang.php
INFO - 2024-02-12 14:01:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2024-02-12 14:01:29 --> Final output sent to browser
DEBUG - 2024-02-12 14:01:29 --> Total execution time: 0.2467
ERROR - 2024-02-12 14:01:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:01:39 --> Config Class Initialized
INFO - 2024-02-12 14:01:39 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:01:39 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:01:39 --> Utf8 Class Initialized
INFO - 2024-02-12 14:01:39 --> URI Class Initialized
INFO - 2024-02-12 14:01:39 --> Router Class Initialized
INFO - 2024-02-12 14:01:39 --> Output Class Initialized
INFO - 2024-02-12 14:01:39 --> Security Class Initialized
DEBUG - 2024-02-12 14:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:01:39 --> Input Class Initialized
INFO - 2024-02-12 14:01:39 --> Language Class Initialized
INFO - 2024-02-12 14:01:39 --> Loader Class Initialized
INFO - 2024-02-12 14:01:39 --> Helper loaded: url_helper
INFO - 2024-02-12 14:01:39 --> Helper loaded: file_helper
INFO - 2024-02-12 14:01:39 --> Helper loaded: html_helper
INFO - 2024-02-12 14:01:39 --> Helper loaded: text_helper
INFO - 2024-02-12 14:01:39 --> Helper loaded: form_helper
INFO - 2024-02-12 14:01:39 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:01:39 --> Helper loaded: security_helper
INFO - 2024-02-12 14:01:39 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:01:39 --> Database Driver Class Initialized
INFO - 2024-02-12 14:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:01:39 --> Parser Class Initialized
INFO - 2024-02-12 14:01:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:01:39 --> Pagination Class Initialized
INFO - 2024-02-12 14:01:39 --> Form Validation Class Initialized
INFO - 2024-02-12 14:01:39 --> Controller Class Initialized
INFO - 2024-02-12 14:01:39 --> Model Class Initialized
DEBUG - 2024-02-12 14:01:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:01:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:01:39 --> Model Class Initialized
DEBUG - 2024-02-12 14:01:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:01:39 --> Model Class Initialized
INFO - 2024-02-12 14:01:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-02-12 14:01:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:01:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 14:01:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 14:01:39 --> Model Class Initialized
INFO - 2024-02-12 14:01:39 --> Model Class Initialized
INFO - 2024-02-12 14:01:39 --> Model Class Initialized
INFO - 2024-02-12 14:01:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 14:01:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 14:01:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 14:01:39 --> Final output sent to browser
DEBUG - 2024-02-12 14:01:39 --> Total execution time: 0.1823
ERROR - 2024-02-12 14:01:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:01:47 --> Config Class Initialized
INFO - 2024-02-12 14:01:47 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:01:47 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:01:47 --> Utf8 Class Initialized
INFO - 2024-02-12 14:01:47 --> URI Class Initialized
INFO - 2024-02-12 14:01:47 --> Router Class Initialized
INFO - 2024-02-12 14:01:47 --> Output Class Initialized
INFO - 2024-02-12 14:01:47 --> Security Class Initialized
DEBUG - 2024-02-12 14:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:01:47 --> Input Class Initialized
INFO - 2024-02-12 14:01:47 --> Language Class Initialized
INFO - 2024-02-12 14:01:47 --> Loader Class Initialized
INFO - 2024-02-12 14:01:47 --> Helper loaded: url_helper
INFO - 2024-02-12 14:01:47 --> Helper loaded: file_helper
INFO - 2024-02-12 14:01:47 --> Helper loaded: html_helper
INFO - 2024-02-12 14:01:47 --> Helper loaded: text_helper
INFO - 2024-02-12 14:01:47 --> Helper loaded: form_helper
INFO - 2024-02-12 14:01:47 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:01:47 --> Helper loaded: security_helper
INFO - 2024-02-12 14:01:47 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:01:47 --> Database Driver Class Initialized
INFO - 2024-02-12 14:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:01:47 --> Parser Class Initialized
INFO - 2024-02-12 14:01:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:01:47 --> Pagination Class Initialized
INFO - 2024-02-12 14:01:47 --> Form Validation Class Initialized
INFO - 2024-02-12 14:01:47 --> Controller Class Initialized
INFO - 2024-02-12 14:01:47 --> Model Class Initialized
DEBUG - 2024-02-12 14:01:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:01:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:01:47 --> Model Class Initialized
DEBUG - 2024-02-12 14:01:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:01:47 --> Model Class Initialized
INFO - 2024-02-12 14:01:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-12 14:01:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:01:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 14:01:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 14:01:47 --> Model Class Initialized
INFO - 2024-02-12 14:01:47 --> Model Class Initialized
INFO - 2024-02-12 14:01:47 --> Model Class Initialized
INFO - 2024-02-12 14:01:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 14:01:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 14:01:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 14:01:47 --> Final output sent to browser
DEBUG - 2024-02-12 14:01:47 --> Total execution time: 0.1532
ERROR - 2024-02-12 14:01:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:01:48 --> Config Class Initialized
INFO - 2024-02-12 14:01:48 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:01:48 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:01:48 --> Utf8 Class Initialized
INFO - 2024-02-12 14:01:48 --> URI Class Initialized
INFO - 2024-02-12 14:01:48 --> Router Class Initialized
INFO - 2024-02-12 14:01:48 --> Output Class Initialized
INFO - 2024-02-12 14:01:48 --> Security Class Initialized
DEBUG - 2024-02-12 14:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:01:48 --> Input Class Initialized
INFO - 2024-02-12 14:01:48 --> Language Class Initialized
INFO - 2024-02-12 14:01:48 --> Loader Class Initialized
INFO - 2024-02-12 14:01:48 --> Helper loaded: url_helper
INFO - 2024-02-12 14:01:48 --> Helper loaded: file_helper
INFO - 2024-02-12 14:01:48 --> Helper loaded: html_helper
INFO - 2024-02-12 14:01:48 --> Helper loaded: text_helper
INFO - 2024-02-12 14:01:48 --> Helper loaded: form_helper
INFO - 2024-02-12 14:01:48 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:01:48 --> Helper loaded: security_helper
INFO - 2024-02-12 14:01:48 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:01:48 --> Database Driver Class Initialized
INFO - 2024-02-12 14:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:01:48 --> Parser Class Initialized
INFO - 2024-02-12 14:01:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:01:48 --> Pagination Class Initialized
INFO - 2024-02-12 14:01:48 --> Form Validation Class Initialized
INFO - 2024-02-12 14:01:48 --> Controller Class Initialized
INFO - 2024-02-12 14:01:48 --> Model Class Initialized
DEBUG - 2024-02-12 14:01:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:01:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:01:48 --> Model Class Initialized
DEBUG - 2024-02-12 14:01:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:01:48 --> Model Class Initialized
INFO - 2024-02-12 14:01:48 --> Final output sent to browser
DEBUG - 2024-02-12 14:01:48 --> Total execution time: 0.0242
ERROR - 2024-02-12 14:02:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:02:23 --> Config Class Initialized
INFO - 2024-02-12 14:02:23 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:02:23 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:02:23 --> Utf8 Class Initialized
INFO - 2024-02-12 14:02:23 --> URI Class Initialized
INFO - 2024-02-12 14:02:23 --> Router Class Initialized
INFO - 2024-02-12 14:02:23 --> Output Class Initialized
INFO - 2024-02-12 14:02:23 --> Security Class Initialized
DEBUG - 2024-02-12 14:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:02:23 --> Input Class Initialized
INFO - 2024-02-12 14:02:23 --> Language Class Initialized
INFO - 2024-02-12 14:02:23 --> Loader Class Initialized
INFO - 2024-02-12 14:02:23 --> Helper loaded: url_helper
INFO - 2024-02-12 14:02:23 --> Helper loaded: file_helper
INFO - 2024-02-12 14:02:23 --> Helper loaded: html_helper
INFO - 2024-02-12 14:02:23 --> Helper loaded: text_helper
INFO - 2024-02-12 14:02:23 --> Helper loaded: form_helper
INFO - 2024-02-12 14:02:23 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:02:23 --> Helper loaded: security_helper
INFO - 2024-02-12 14:02:23 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:02:23 --> Database Driver Class Initialized
INFO - 2024-02-12 14:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:02:23 --> Parser Class Initialized
INFO - 2024-02-12 14:02:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:02:23 --> Pagination Class Initialized
INFO - 2024-02-12 14:02:23 --> Form Validation Class Initialized
INFO - 2024-02-12 14:02:23 --> Controller Class Initialized
INFO - 2024-02-12 14:02:23 --> Model Class Initialized
DEBUG - 2024-02-12 14:02:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:02:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:02:23 --> Model Class Initialized
DEBUG - 2024-02-12 14:02:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:02:23 --> Model Class Initialized
DEBUG - 2024-02-12 14:02:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:02:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-02-12 14:02:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:02:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 14:02:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 14:02:23 --> Model Class Initialized
INFO - 2024-02-12 14:02:23 --> Model Class Initialized
INFO - 2024-02-12 14:02:23 --> Model Class Initialized
INFO - 2024-02-12 14:02:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 14:02:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 14:02:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 14:02:23 --> Final output sent to browser
DEBUG - 2024-02-12 14:02:23 --> Total execution time: 0.1584
ERROR - 2024-02-12 14:02:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:02:58 --> Config Class Initialized
INFO - 2024-02-12 14:02:58 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:02:58 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:02:58 --> Utf8 Class Initialized
INFO - 2024-02-12 14:02:58 --> URI Class Initialized
INFO - 2024-02-12 14:02:58 --> Router Class Initialized
INFO - 2024-02-12 14:02:58 --> Output Class Initialized
INFO - 2024-02-12 14:02:58 --> Security Class Initialized
DEBUG - 2024-02-12 14:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:02:58 --> Input Class Initialized
INFO - 2024-02-12 14:02:58 --> Language Class Initialized
INFO - 2024-02-12 14:02:58 --> Loader Class Initialized
INFO - 2024-02-12 14:02:58 --> Helper loaded: url_helper
INFO - 2024-02-12 14:02:58 --> Helper loaded: file_helper
INFO - 2024-02-12 14:02:58 --> Helper loaded: html_helper
INFO - 2024-02-12 14:02:58 --> Helper loaded: text_helper
INFO - 2024-02-12 14:02:58 --> Helper loaded: form_helper
INFO - 2024-02-12 14:02:58 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:02:58 --> Helper loaded: security_helper
INFO - 2024-02-12 14:02:58 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:02:58 --> Database Driver Class Initialized
INFO - 2024-02-12 14:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:02:58 --> Parser Class Initialized
INFO - 2024-02-12 14:02:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:02:58 --> Pagination Class Initialized
INFO - 2024-02-12 14:02:58 --> Form Validation Class Initialized
INFO - 2024-02-12 14:02:58 --> Controller Class Initialized
INFO - 2024-02-12 14:02:58 --> Model Class Initialized
DEBUG - 2024-02-12 14:02:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:02:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:02:58 --> Model Class Initialized
DEBUG - 2024-02-12 14:02:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:02:58 --> Model Class Initialized
INFO - 2024-02-12 14:02:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-12 14:02:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:02:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 14:02:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 14:02:58 --> Model Class Initialized
INFO - 2024-02-12 14:02:58 --> Model Class Initialized
INFO - 2024-02-12 14:02:58 --> Model Class Initialized
INFO - 2024-02-12 14:02:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 14:02:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 14:02:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 14:02:58 --> Final output sent to browser
DEBUG - 2024-02-12 14:02:58 --> Total execution time: 0.1466
ERROR - 2024-02-12 14:02:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:02:59 --> Config Class Initialized
INFO - 2024-02-12 14:02:59 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:02:59 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:02:59 --> Utf8 Class Initialized
INFO - 2024-02-12 14:02:59 --> URI Class Initialized
INFO - 2024-02-12 14:02:59 --> Router Class Initialized
INFO - 2024-02-12 14:02:59 --> Output Class Initialized
INFO - 2024-02-12 14:02:59 --> Security Class Initialized
DEBUG - 2024-02-12 14:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:02:59 --> Input Class Initialized
INFO - 2024-02-12 14:02:59 --> Language Class Initialized
INFO - 2024-02-12 14:02:59 --> Loader Class Initialized
INFO - 2024-02-12 14:02:59 --> Helper loaded: url_helper
INFO - 2024-02-12 14:02:59 --> Helper loaded: file_helper
INFO - 2024-02-12 14:02:59 --> Helper loaded: html_helper
INFO - 2024-02-12 14:02:59 --> Helper loaded: text_helper
INFO - 2024-02-12 14:02:59 --> Helper loaded: form_helper
INFO - 2024-02-12 14:02:59 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:02:59 --> Helper loaded: security_helper
INFO - 2024-02-12 14:02:59 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:02:59 --> Database Driver Class Initialized
INFO - 2024-02-12 14:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:02:59 --> Parser Class Initialized
INFO - 2024-02-12 14:02:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:02:59 --> Pagination Class Initialized
INFO - 2024-02-12 14:02:59 --> Form Validation Class Initialized
INFO - 2024-02-12 14:02:59 --> Controller Class Initialized
INFO - 2024-02-12 14:02:59 --> Model Class Initialized
DEBUG - 2024-02-12 14:02:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:02:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:02:59 --> Model Class Initialized
DEBUG - 2024-02-12 14:02:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:02:59 --> Model Class Initialized
INFO - 2024-02-12 14:02:59 --> Final output sent to browser
DEBUG - 2024-02-12 14:02:59 --> Total execution time: 0.0243
ERROR - 2024-02-12 14:03:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:03:01 --> Config Class Initialized
INFO - 2024-02-12 14:03:01 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:03:01 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:03:01 --> Utf8 Class Initialized
INFO - 2024-02-12 14:03:01 --> URI Class Initialized
DEBUG - 2024-02-12 14:03:01 --> No URI present. Default controller set.
INFO - 2024-02-12 14:03:01 --> Router Class Initialized
INFO - 2024-02-12 14:03:01 --> Output Class Initialized
INFO - 2024-02-12 14:03:01 --> Security Class Initialized
DEBUG - 2024-02-12 14:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:03:01 --> Input Class Initialized
INFO - 2024-02-12 14:03:01 --> Language Class Initialized
INFO - 2024-02-12 14:03:01 --> Loader Class Initialized
INFO - 2024-02-12 14:03:01 --> Helper loaded: url_helper
INFO - 2024-02-12 14:03:01 --> Helper loaded: file_helper
INFO - 2024-02-12 14:03:01 --> Helper loaded: html_helper
INFO - 2024-02-12 14:03:01 --> Helper loaded: text_helper
INFO - 2024-02-12 14:03:01 --> Helper loaded: form_helper
INFO - 2024-02-12 14:03:01 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:03:01 --> Helper loaded: security_helper
INFO - 2024-02-12 14:03:01 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:03:01 --> Database Driver Class Initialized
INFO - 2024-02-12 14:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:03:01 --> Parser Class Initialized
INFO - 2024-02-12 14:03:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:03:01 --> Pagination Class Initialized
INFO - 2024-02-12 14:03:01 --> Form Validation Class Initialized
INFO - 2024-02-12 14:03:01 --> Controller Class Initialized
INFO - 2024-02-12 14:03:01 --> Model Class Initialized
DEBUG - 2024-02-12 14:03:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:03:01 --> Model Class Initialized
DEBUG - 2024-02-12 14:03:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:03:01 --> Model Class Initialized
INFO - 2024-02-12 14:03:01 --> Model Class Initialized
INFO - 2024-02-12 14:03:01 --> Model Class Initialized
INFO - 2024-02-12 14:03:01 --> Model Class Initialized
DEBUG - 2024-02-12 14:03:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:03:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:03:01 --> Model Class Initialized
INFO - 2024-02-12 14:03:01 --> Model Class Initialized
INFO - 2024-02-12 14:03:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-12 14:03:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:03:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 14:03:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 14:03:02 --> Model Class Initialized
INFO - 2024-02-12 14:03:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 14:03:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 14:03:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 14:03:02 --> Final output sent to browser
DEBUG - 2024-02-12 14:03:02 --> Total execution time: 0.3227
ERROR - 2024-02-12 14:03:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:03:08 --> Config Class Initialized
INFO - 2024-02-12 14:03:08 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:03:08 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:03:08 --> Utf8 Class Initialized
INFO - 2024-02-12 14:03:08 --> URI Class Initialized
INFO - 2024-02-12 14:03:08 --> Router Class Initialized
INFO - 2024-02-12 14:03:08 --> Output Class Initialized
INFO - 2024-02-12 14:03:08 --> Security Class Initialized
DEBUG - 2024-02-12 14:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:03:08 --> Input Class Initialized
INFO - 2024-02-12 14:03:08 --> Language Class Initialized
INFO - 2024-02-12 14:03:08 --> Loader Class Initialized
INFO - 2024-02-12 14:03:08 --> Helper loaded: url_helper
INFO - 2024-02-12 14:03:08 --> Helper loaded: file_helper
INFO - 2024-02-12 14:03:08 --> Helper loaded: html_helper
INFO - 2024-02-12 14:03:08 --> Helper loaded: text_helper
INFO - 2024-02-12 14:03:08 --> Helper loaded: form_helper
INFO - 2024-02-12 14:03:08 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:03:08 --> Helper loaded: security_helper
INFO - 2024-02-12 14:03:08 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:03:08 --> Database Driver Class Initialized
INFO - 2024-02-12 14:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:03:08 --> Parser Class Initialized
INFO - 2024-02-12 14:03:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:03:08 --> Pagination Class Initialized
INFO - 2024-02-12 14:03:08 --> Form Validation Class Initialized
INFO - 2024-02-12 14:03:08 --> Controller Class Initialized
DEBUG - 2024-02-12 14:03:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:03:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:03:08 --> Model Class Initialized
DEBUG - 2024-02-12 14:03:08 --> Lgift class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:03:08 --> Model Class Initialized
DEBUG - 2024-02-12 14:03:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:03:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:03:08 --> Model Class Initialized
DEBUG - 2024-02-12 14:03:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:03:08 --> Model Class Initialized
INFO - 2024-02-12 14:03:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/gift.php
DEBUG - 2024-02-12 14:03:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:03:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 14:03:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 14:03:08 --> Model Class Initialized
INFO - 2024-02-12 14:03:08 --> Model Class Initialized
INFO - 2024-02-12 14:03:08 --> Model Class Initialized
INFO - 2024-02-12 14:03:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 14:03:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 14:03:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 14:03:09 --> Final output sent to browser
DEBUG - 2024-02-12 14:03:09 --> Total execution time: 0.1429
ERROR - 2024-02-12 14:03:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:03:09 --> Config Class Initialized
INFO - 2024-02-12 14:03:09 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:03:09 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:03:09 --> Utf8 Class Initialized
INFO - 2024-02-12 14:03:09 --> URI Class Initialized
INFO - 2024-02-12 14:03:09 --> Router Class Initialized
INFO - 2024-02-12 14:03:09 --> Output Class Initialized
INFO - 2024-02-12 14:03:09 --> Security Class Initialized
DEBUG - 2024-02-12 14:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:03:09 --> Input Class Initialized
INFO - 2024-02-12 14:03:09 --> Language Class Initialized
INFO - 2024-02-12 14:03:09 --> Loader Class Initialized
INFO - 2024-02-12 14:03:09 --> Helper loaded: url_helper
INFO - 2024-02-12 14:03:09 --> Helper loaded: file_helper
INFO - 2024-02-12 14:03:09 --> Helper loaded: html_helper
INFO - 2024-02-12 14:03:09 --> Helper loaded: text_helper
INFO - 2024-02-12 14:03:09 --> Helper loaded: form_helper
INFO - 2024-02-12 14:03:09 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:03:09 --> Helper loaded: security_helper
INFO - 2024-02-12 14:03:09 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:03:09 --> Database Driver Class Initialized
INFO - 2024-02-12 14:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:03:09 --> Parser Class Initialized
INFO - 2024-02-12 14:03:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:03:09 --> Pagination Class Initialized
INFO - 2024-02-12 14:03:09 --> Form Validation Class Initialized
INFO - 2024-02-12 14:03:09 --> Controller Class Initialized
DEBUG - 2024-02-12 14:03:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:03:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:03:09 --> Model Class Initialized
INFO - 2024-02-12 14:03:09 --> Final output sent to browser
DEBUG - 2024-02-12 14:03:09 --> Total execution time: 0.0171
ERROR - 2024-02-12 14:03:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:03:34 --> Config Class Initialized
INFO - 2024-02-12 14:03:34 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:03:34 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:03:34 --> Utf8 Class Initialized
INFO - 2024-02-12 14:03:34 --> URI Class Initialized
DEBUG - 2024-02-12 14:03:34 --> No URI present. Default controller set.
INFO - 2024-02-12 14:03:34 --> Router Class Initialized
INFO - 2024-02-12 14:03:34 --> Output Class Initialized
INFO - 2024-02-12 14:03:34 --> Security Class Initialized
DEBUG - 2024-02-12 14:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:03:34 --> Input Class Initialized
INFO - 2024-02-12 14:03:34 --> Language Class Initialized
INFO - 2024-02-12 14:03:34 --> Loader Class Initialized
INFO - 2024-02-12 14:03:34 --> Helper loaded: url_helper
INFO - 2024-02-12 14:03:34 --> Helper loaded: file_helper
INFO - 2024-02-12 14:03:34 --> Helper loaded: html_helper
INFO - 2024-02-12 14:03:34 --> Helper loaded: text_helper
INFO - 2024-02-12 14:03:34 --> Helper loaded: form_helper
INFO - 2024-02-12 14:03:34 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:03:34 --> Helper loaded: security_helper
INFO - 2024-02-12 14:03:34 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:03:34 --> Database Driver Class Initialized
INFO - 2024-02-12 14:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:03:34 --> Parser Class Initialized
INFO - 2024-02-12 14:03:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:03:34 --> Pagination Class Initialized
INFO - 2024-02-12 14:03:34 --> Form Validation Class Initialized
INFO - 2024-02-12 14:03:34 --> Controller Class Initialized
INFO - 2024-02-12 14:03:34 --> Model Class Initialized
DEBUG - 2024-02-12 14:03:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:03:34 --> Model Class Initialized
DEBUG - 2024-02-12 14:03:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:03:34 --> Model Class Initialized
INFO - 2024-02-12 14:03:34 --> Model Class Initialized
INFO - 2024-02-12 14:03:34 --> Model Class Initialized
INFO - 2024-02-12 14:03:34 --> Model Class Initialized
DEBUG - 2024-02-12 14:03:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:03:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:03:34 --> Model Class Initialized
INFO - 2024-02-12 14:03:34 --> Model Class Initialized
INFO - 2024-02-12 14:03:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-12 14:03:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:03:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 14:03:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 14:03:35 --> Model Class Initialized
INFO - 2024-02-12 14:03:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 14:03:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 14:03:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 14:03:35 --> Final output sent to browser
DEBUG - 2024-02-12 14:03:35 --> Total execution time: 0.2307
ERROR - 2024-02-12 14:03:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:03:37 --> Config Class Initialized
INFO - 2024-02-12 14:03:37 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:03:37 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:03:37 --> Utf8 Class Initialized
INFO - 2024-02-12 14:03:37 --> URI Class Initialized
INFO - 2024-02-12 14:03:37 --> Router Class Initialized
INFO - 2024-02-12 14:03:37 --> Output Class Initialized
INFO - 2024-02-12 14:03:37 --> Security Class Initialized
DEBUG - 2024-02-12 14:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:03:37 --> Input Class Initialized
INFO - 2024-02-12 14:03:37 --> Language Class Initialized
INFO - 2024-02-12 14:03:37 --> Loader Class Initialized
INFO - 2024-02-12 14:03:37 --> Helper loaded: url_helper
INFO - 2024-02-12 14:03:37 --> Helper loaded: file_helper
INFO - 2024-02-12 14:03:37 --> Helper loaded: html_helper
INFO - 2024-02-12 14:03:37 --> Helper loaded: text_helper
INFO - 2024-02-12 14:03:37 --> Helper loaded: form_helper
INFO - 2024-02-12 14:03:37 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:03:37 --> Helper loaded: security_helper
INFO - 2024-02-12 14:03:37 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:03:37 --> Database Driver Class Initialized
INFO - 2024-02-12 14:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:03:37 --> Parser Class Initialized
INFO - 2024-02-12 14:03:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:03:37 --> Pagination Class Initialized
INFO - 2024-02-12 14:03:37 --> Form Validation Class Initialized
INFO - 2024-02-12 14:03:37 --> Controller Class Initialized
INFO - 2024-02-12 14:03:37 --> Model Class Initialized
DEBUG - 2024-02-12 14:03:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:03:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-12 14:03:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:03:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 14:03:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 14:03:37 --> Model Class Initialized
INFO - 2024-02-12 14:03:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 14:03:37 --> Final output sent to browser
DEBUG - 2024-02-12 14:03:37 --> Total execution time: 0.0316
ERROR - 2024-02-12 14:03:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:03:37 --> Config Class Initialized
INFO - 2024-02-12 14:03:37 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:03:37 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:03:37 --> Utf8 Class Initialized
INFO - 2024-02-12 14:03:37 --> URI Class Initialized
INFO - 2024-02-12 14:03:37 --> Router Class Initialized
INFO - 2024-02-12 14:03:37 --> Output Class Initialized
INFO - 2024-02-12 14:03:37 --> Security Class Initialized
DEBUG - 2024-02-12 14:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:03:37 --> Input Class Initialized
INFO - 2024-02-12 14:03:37 --> Language Class Initialized
INFO - 2024-02-12 14:03:37 --> Loader Class Initialized
INFO - 2024-02-12 14:03:37 --> Helper loaded: url_helper
INFO - 2024-02-12 14:03:37 --> Helper loaded: file_helper
INFO - 2024-02-12 14:03:37 --> Helper loaded: html_helper
INFO - 2024-02-12 14:03:37 --> Helper loaded: text_helper
INFO - 2024-02-12 14:03:37 --> Helper loaded: form_helper
INFO - 2024-02-12 14:03:37 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:03:37 --> Helper loaded: security_helper
INFO - 2024-02-12 14:03:37 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:03:37 --> Database Driver Class Initialized
INFO - 2024-02-12 14:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:03:37 --> Parser Class Initialized
INFO - 2024-02-12 14:03:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:03:37 --> Pagination Class Initialized
INFO - 2024-02-12 14:03:37 --> Form Validation Class Initialized
INFO - 2024-02-12 14:03:37 --> Controller Class Initialized
INFO - 2024-02-12 14:03:37 --> Model Class Initialized
DEBUG - 2024-02-12 14:03:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:03:37 --> Model Class Initialized
DEBUG - 2024-02-12 14:03:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:03:37 --> Model Class Initialized
INFO - 2024-02-12 14:03:37 --> Model Class Initialized
INFO - 2024-02-12 14:03:37 --> Model Class Initialized
INFO - 2024-02-12 14:03:37 --> Model Class Initialized
DEBUG - 2024-02-12 14:03:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:03:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:03:37 --> Model Class Initialized
INFO - 2024-02-12 14:03:37 --> Model Class Initialized
INFO - 2024-02-12 14:03:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-12 14:03:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:03:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 14:03:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 14:03:38 --> Model Class Initialized
INFO - 2024-02-12 14:03:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 14:03:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 14:03:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 14:03:38 --> Final output sent to browser
DEBUG - 2024-02-12 14:03:38 --> Total execution time: 0.2337
ERROR - 2024-02-12 14:05:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:05:14 --> Config Class Initialized
INFO - 2024-02-12 14:05:14 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:05:14 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:05:14 --> Utf8 Class Initialized
INFO - 2024-02-12 14:05:14 --> URI Class Initialized
DEBUG - 2024-02-12 14:05:14 --> No URI present. Default controller set.
INFO - 2024-02-12 14:05:14 --> Router Class Initialized
INFO - 2024-02-12 14:05:14 --> Output Class Initialized
INFO - 2024-02-12 14:05:14 --> Security Class Initialized
DEBUG - 2024-02-12 14:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:05:14 --> Input Class Initialized
INFO - 2024-02-12 14:05:14 --> Language Class Initialized
INFO - 2024-02-12 14:05:14 --> Loader Class Initialized
INFO - 2024-02-12 14:05:14 --> Helper loaded: url_helper
INFO - 2024-02-12 14:05:14 --> Helper loaded: file_helper
INFO - 2024-02-12 14:05:14 --> Helper loaded: html_helper
INFO - 2024-02-12 14:05:14 --> Helper loaded: text_helper
INFO - 2024-02-12 14:05:14 --> Helper loaded: form_helper
INFO - 2024-02-12 14:05:14 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:05:14 --> Helper loaded: security_helper
INFO - 2024-02-12 14:05:14 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:05:14 --> Database Driver Class Initialized
INFO - 2024-02-12 14:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:05:14 --> Parser Class Initialized
INFO - 2024-02-12 14:05:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:05:14 --> Pagination Class Initialized
INFO - 2024-02-12 14:05:14 --> Form Validation Class Initialized
INFO - 2024-02-12 14:05:14 --> Controller Class Initialized
INFO - 2024-02-12 14:05:14 --> Model Class Initialized
DEBUG - 2024-02-12 14:05:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-12 14:05:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:05:14 --> Config Class Initialized
INFO - 2024-02-12 14:05:14 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:05:14 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:05:14 --> Utf8 Class Initialized
INFO - 2024-02-12 14:05:14 --> URI Class Initialized
INFO - 2024-02-12 14:05:14 --> Router Class Initialized
INFO - 2024-02-12 14:05:14 --> Output Class Initialized
INFO - 2024-02-12 14:05:14 --> Security Class Initialized
DEBUG - 2024-02-12 14:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:05:14 --> Input Class Initialized
INFO - 2024-02-12 14:05:14 --> Language Class Initialized
INFO - 2024-02-12 14:05:14 --> Loader Class Initialized
INFO - 2024-02-12 14:05:14 --> Helper loaded: url_helper
INFO - 2024-02-12 14:05:14 --> Helper loaded: file_helper
INFO - 2024-02-12 14:05:14 --> Helper loaded: html_helper
INFO - 2024-02-12 14:05:14 --> Helper loaded: text_helper
INFO - 2024-02-12 14:05:14 --> Helper loaded: form_helper
INFO - 2024-02-12 14:05:14 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:05:14 --> Helper loaded: security_helper
INFO - 2024-02-12 14:05:14 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:05:14 --> Database Driver Class Initialized
INFO - 2024-02-12 14:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:05:14 --> Parser Class Initialized
INFO - 2024-02-12 14:05:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:05:14 --> Pagination Class Initialized
INFO - 2024-02-12 14:05:14 --> Form Validation Class Initialized
INFO - 2024-02-12 14:05:14 --> Controller Class Initialized
INFO - 2024-02-12 14:05:14 --> Model Class Initialized
DEBUG - 2024-02-12 14:05:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:05:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-12 14:05:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:05:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 14:05:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 14:05:14 --> Model Class Initialized
INFO - 2024-02-12 14:05:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 14:05:14 --> Final output sent to browser
DEBUG - 2024-02-12 14:05:14 --> Total execution time: 0.0316
ERROR - 2024-02-12 14:07:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:07:08 --> Config Class Initialized
INFO - 2024-02-12 14:07:08 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:07:08 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:07:08 --> Utf8 Class Initialized
INFO - 2024-02-12 14:07:08 --> URI Class Initialized
INFO - 2024-02-12 14:07:08 --> Router Class Initialized
INFO - 2024-02-12 14:07:08 --> Output Class Initialized
INFO - 2024-02-12 14:07:08 --> Security Class Initialized
DEBUG - 2024-02-12 14:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:07:08 --> Input Class Initialized
INFO - 2024-02-12 14:07:08 --> Language Class Initialized
INFO - 2024-02-12 14:07:08 --> Loader Class Initialized
INFO - 2024-02-12 14:07:08 --> Helper loaded: url_helper
INFO - 2024-02-12 14:07:08 --> Helper loaded: file_helper
INFO - 2024-02-12 14:07:08 --> Helper loaded: html_helper
INFO - 2024-02-12 14:07:08 --> Helper loaded: text_helper
INFO - 2024-02-12 14:07:08 --> Helper loaded: form_helper
INFO - 2024-02-12 14:07:08 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:07:08 --> Helper loaded: security_helper
INFO - 2024-02-12 14:07:08 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:07:08 --> Database Driver Class Initialized
INFO - 2024-02-12 14:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:07:08 --> Parser Class Initialized
INFO - 2024-02-12 14:07:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:07:08 --> Pagination Class Initialized
INFO - 2024-02-12 14:07:08 --> Form Validation Class Initialized
INFO - 2024-02-12 14:07:08 --> Controller Class Initialized
INFO - 2024-02-12 14:07:08 --> Model Class Initialized
DEBUG - 2024-02-12 14:07:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:07:08 --> Final output sent to browser
DEBUG - 2024-02-12 14:07:08 --> Total execution time: 0.0182
ERROR - 2024-02-12 14:07:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:07:12 --> Config Class Initialized
INFO - 2024-02-12 14:07:12 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:07:12 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:07:12 --> Utf8 Class Initialized
INFO - 2024-02-12 14:07:12 --> URI Class Initialized
INFO - 2024-02-12 14:07:12 --> Router Class Initialized
INFO - 2024-02-12 14:07:12 --> Output Class Initialized
INFO - 2024-02-12 14:07:12 --> Security Class Initialized
DEBUG - 2024-02-12 14:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:07:12 --> Input Class Initialized
INFO - 2024-02-12 14:07:12 --> Language Class Initialized
INFO - 2024-02-12 14:07:12 --> Loader Class Initialized
INFO - 2024-02-12 14:07:12 --> Helper loaded: url_helper
INFO - 2024-02-12 14:07:12 --> Helper loaded: file_helper
INFO - 2024-02-12 14:07:12 --> Helper loaded: html_helper
INFO - 2024-02-12 14:07:12 --> Helper loaded: text_helper
INFO - 2024-02-12 14:07:12 --> Helper loaded: form_helper
INFO - 2024-02-12 14:07:12 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:07:12 --> Helper loaded: security_helper
INFO - 2024-02-12 14:07:12 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:07:12 --> Database Driver Class Initialized
INFO - 2024-02-12 14:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:07:12 --> Parser Class Initialized
INFO - 2024-02-12 14:07:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:07:12 --> Pagination Class Initialized
INFO - 2024-02-12 14:07:12 --> Form Validation Class Initialized
INFO - 2024-02-12 14:07:12 --> Controller Class Initialized
INFO - 2024-02-12 14:07:12 --> Final output sent to browser
DEBUG - 2024-02-12 14:07:12 --> Total execution time: 0.0143
ERROR - 2024-02-12 14:07:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:07:19 --> Config Class Initialized
INFO - 2024-02-12 14:07:19 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:07:19 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:07:19 --> Utf8 Class Initialized
INFO - 2024-02-12 14:07:19 --> URI Class Initialized
INFO - 2024-02-12 14:07:19 --> Router Class Initialized
INFO - 2024-02-12 14:07:19 --> Output Class Initialized
INFO - 2024-02-12 14:07:19 --> Security Class Initialized
DEBUG - 2024-02-12 14:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:07:19 --> Input Class Initialized
INFO - 2024-02-12 14:07:19 --> Language Class Initialized
INFO - 2024-02-12 14:07:19 --> Loader Class Initialized
INFO - 2024-02-12 14:07:19 --> Helper loaded: url_helper
INFO - 2024-02-12 14:07:19 --> Helper loaded: file_helper
INFO - 2024-02-12 14:07:19 --> Helper loaded: html_helper
INFO - 2024-02-12 14:07:19 --> Helper loaded: text_helper
INFO - 2024-02-12 14:07:19 --> Helper loaded: form_helper
INFO - 2024-02-12 14:07:19 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:07:19 --> Helper loaded: security_helper
INFO - 2024-02-12 14:07:19 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:07:19 --> Database Driver Class Initialized
INFO - 2024-02-12 14:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:07:19 --> Parser Class Initialized
INFO - 2024-02-12 14:07:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:07:19 --> Pagination Class Initialized
INFO - 2024-02-12 14:07:19 --> Form Validation Class Initialized
INFO - 2024-02-12 14:07:19 --> Controller Class Initialized
INFO - 2024-02-12 14:07:19 --> Model Class Initialized
DEBUG - 2024-02-12 14:07:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:07:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:07:19 --> Model Class Initialized
DEBUG - 2024-02-12 14:07:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:07:19 --> Model Class Initialized
INFO - 2024-02-12 14:07:20 --> Final output sent to browser
DEBUG - 2024-02-12 14:07:20 --> Total execution time: 0.0904
ERROR - 2024-02-12 14:07:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:07:22 --> Config Class Initialized
INFO - 2024-02-12 14:07:22 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:07:22 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:07:22 --> Utf8 Class Initialized
INFO - 2024-02-12 14:07:22 --> URI Class Initialized
INFO - 2024-02-12 14:07:22 --> Router Class Initialized
INFO - 2024-02-12 14:07:22 --> Output Class Initialized
INFO - 2024-02-12 14:07:22 --> Security Class Initialized
DEBUG - 2024-02-12 14:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:07:22 --> Input Class Initialized
INFO - 2024-02-12 14:07:22 --> Language Class Initialized
INFO - 2024-02-12 14:07:22 --> Loader Class Initialized
INFO - 2024-02-12 14:07:22 --> Helper loaded: url_helper
INFO - 2024-02-12 14:07:22 --> Helper loaded: file_helper
INFO - 2024-02-12 14:07:22 --> Helper loaded: html_helper
INFO - 2024-02-12 14:07:22 --> Helper loaded: text_helper
INFO - 2024-02-12 14:07:22 --> Helper loaded: form_helper
INFO - 2024-02-12 14:07:22 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:07:22 --> Helper loaded: security_helper
INFO - 2024-02-12 14:07:22 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:07:22 --> Database Driver Class Initialized
INFO - 2024-02-12 14:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:07:22 --> Parser Class Initialized
INFO - 2024-02-12 14:07:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:07:22 --> Pagination Class Initialized
INFO - 2024-02-12 14:07:22 --> Form Validation Class Initialized
INFO - 2024-02-12 14:07:22 --> Controller Class Initialized
INFO - 2024-02-12 14:07:22 --> Model Class Initialized
DEBUG - 2024-02-12 14:07:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:07:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:07:22 --> Model Class Initialized
DEBUG - 2024-02-12 14:07:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:07:22 --> Model Class Initialized
INFO - 2024-02-12 14:07:23 --> Final output sent to browser
DEBUG - 2024-02-12 14:07:23 --> Total execution time: 0.0904
ERROR - 2024-02-12 14:07:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:07:27 --> Config Class Initialized
INFO - 2024-02-12 14:07:27 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:07:27 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:07:27 --> Utf8 Class Initialized
INFO - 2024-02-12 14:07:27 --> URI Class Initialized
INFO - 2024-02-12 14:07:27 --> Router Class Initialized
INFO - 2024-02-12 14:07:27 --> Output Class Initialized
INFO - 2024-02-12 14:07:27 --> Security Class Initialized
DEBUG - 2024-02-12 14:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:07:27 --> Input Class Initialized
INFO - 2024-02-12 14:07:27 --> Language Class Initialized
INFO - 2024-02-12 14:07:27 --> Loader Class Initialized
INFO - 2024-02-12 14:07:27 --> Helper loaded: url_helper
INFO - 2024-02-12 14:07:27 --> Helper loaded: file_helper
INFO - 2024-02-12 14:07:27 --> Helper loaded: html_helper
INFO - 2024-02-12 14:07:27 --> Helper loaded: text_helper
INFO - 2024-02-12 14:07:27 --> Helper loaded: form_helper
INFO - 2024-02-12 14:07:27 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:07:27 --> Helper loaded: security_helper
INFO - 2024-02-12 14:07:27 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:07:27 --> Database Driver Class Initialized
INFO - 2024-02-12 14:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:07:27 --> Parser Class Initialized
INFO - 2024-02-12 14:07:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:07:27 --> Pagination Class Initialized
INFO - 2024-02-12 14:07:27 --> Form Validation Class Initialized
INFO - 2024-02-12 14:07:27 --> Controller Class Initialized
INFO - 2024-02-12 14:07:27 --> Model Class Initialized
DEBUG - 2024-02-12 14:07:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:07:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:07:27 --> Model Class Initialized
DEBUG - 2024-02-12 14:07:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:07:27 --> Model Class Initialized
INFO - 2024-02-12 14:07:27 --> Final output sent to browser
DEBUG - 2024-02-12 14:07:27 --> Total execution time: 0.0193
ERROR - 2024-02-12 14:07:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:07:35 --> Config Class Initialized
INFO - 2024-02-12 14:07:35 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:07:35 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:07:35 --> Utf8 Class Initialized
INFO - 2024-02-12 14:07:35 --> URI Class Initialized
INFO - 2024-02-12 14:07:35 --> Router Class Initialized
INFO - 2024-02-12 14:07:35 --> Output Class Initialized
INFO - 2024-02-12 14:07:35 --> Security Class Initialized
DEBUG - 2024-02-12 14:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:07:35 --> Input Class Initialized
INFO - 2024-02-12 14:07:35 --> Language Class Initialized
INFO - 2024-02-12 14:07:35 --> Loader Class Initialized
INFO - 2024-02-12 14:07:35 --> Helper loaded: url_helper
INFO - 2024-02-12 14:07:35 --> Helper loaded: file_helper
INFO - 2024-02-12 14:07:35 --> Helper loaded: html_helper
INFO - 2024-02-12 14:07:35 --> Helper loaded: text_helper
INFO - 2024-02-12 14:07:35 --> Helper loaded: form_helper
INFO - 2024-02-12 14:07:35 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:07:35 --> Helper loaded: security_helper
INFO - 2024-02-12 14:07:35 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:07:35 --> Database Driver Class Initialized
INFO - 2024-02-12 14:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:07:35 --> Parser Class Initialized
INFO - 2024-02-12 14:07:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:07:35 --> Pagination Class Initialized
INFO - 2024-02-12 14:07:35 --> Form Validation Class Initialized
INFO - 2024-02-12 14:07:35 --> Controller Class Initialized
INFO - 2024-02-12 14:07:35 --> Model Class Initialized
DEBUG - 2024-02-12 14:07:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:07:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:07:35 --> Model Class Initialized
DEBUG - 2024-02-12 14:07:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:07:35 --> Model Class Initialized
INFO - 2024-02-12 14:07:35 --> Final output sent to browser
DEBUG - 2024-02-12 14:07:35 --> Total execution time: 0.0909
ERROR - 2024-02-12 14:07:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:07:36 --> Config Class Initialized
INFO - 2024-02-12 14:07:36 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:07:36 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:07:36 --> Utf8 Class Initialized
INFO - 2024-02-12 14:07:36 --> URI Class Initialized
INFO - 2024-02-12 14:07:36 --> Router Class Initialized
INFO - 2024-02-12 14:07:36 --> Output Class Initialized
INFO - 2024-02-12 14:07:36 --> Security Class Initialized
DEBUG - 2024-02-12 14:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:07:36 --> Input Class Initialized
INFO - 2024-02-12 14:07:36 --> Language Class Initialized
INFO - 2024-02-12 14:07:36 --> Loader Class Initialized
INFO - 2024-02-12 14:07:36 --> Helper loaded: url_helper
INFO - 2024-02-12 14:07:36 --> Helper loaded: file_helper
INFO - 2024-02-12 14:07:36 --> Helper loaded: html_helper
INFO - 2024-02-12 14:07:36 --> Helper loaded: text_helper
INFO - 2024-02-12 14:07:36 --> Helper loaded: form_helper
INFO - 2024-02-12 14:07:36 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:07:36 --> Helper loaded: security_helper
INFO - 2024-02-12 14:07:36 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:07:36 --> Database Driver Class Initialized
INFO - 2024-02-12 14:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:07:36 --> Parser Class Initialized
INFO - 2024-02-12 14:07:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:07:36 --> Pagination Class Initialized
INFO - 2024-02-12 14:07:36 --> Form Validation Class Initialized
INFO - 2024-02-12 14:07:36 --> Controller Class Initialized
INFO - 2024-02-12 14:07:36 --> Model Class Initialized
DEBUG - 2024-02-12 14:07:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:07:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:07:36 --> Model Class Initialized
DEBUG - 2024-02-12 14:07:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:07:36 --> Model Class Initialized
INFO - 2024-02-12 14:07:36 --> Final output sent to browser
DEBUG - 2024-02-12 14:07:36 --> Total execution time: 0.0964
ERROR - 2024-02-12 14:07:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:07:38 --> Config Class Initialized
INFO - 2024-02-12 14:07:38 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:07:38 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:07:38 --> Utf8 Class Initialized
INFO - 2024-02-12 14:07:38 --> URI Class Initialized
INFO - 2024-02-12 14:07:38 --> Router Class Initialized
INFO - 2024-02-12 14:07:38 --> Output Class Initialized
INFO - 2024-02-12 14:07:38 --> Security Class Initialized
DEBUG - 2024-02-12 14:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:07:38 --> Input Class Initialized
INFO - 2024-02-12 14:07:38 --> Language Class Initialized
INFO - 2024-02-12 14:07:38 --> Loader Class Initialized
INFO - 2024-02-12 14:07:38 --> Helper loaded: url_helper
INFO - 2024-02-12 14:07:38 --> Helper loaded: file_helper
INFO - 2024-02-12 14:07:38 --> Helper loaded: html_helper
INFO - 2024-02-12 14:07:38 --> Helper loaded: text_helper
INFO - 2024-02-12 14:07:38 --> Helper loaded: form_helper
INFO - 2024-02-12 14:07:38 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:07:38 --> Helper loaded: security_helper
INFO - 2024-02-12 14:07:38 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:07:38 --> Database Driver Class Initialized
INFO - 2024-02-12 14:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:07:38 --> Parser Class Initialized
INFO - 2024-02-12 14:07:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:07:38 --> Pagination Class Initialized
INFO - 2024-02-12 14:07:38 --> Form Validation Class Initialized
INFO - 2024-02-12 14:07:38 --> Controller Class Initialized
INFO - 2024-02-12 14:07:38 --> Model Class Initialized
DEBUG - 2024-02-12 14:07:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:07:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:07:38 --> Model Class Initialized
DEBUG - 2024-02-12 14:07:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:07:38 --> Model Class Initialized
INFO - 2024-02-12 14:07:38 --> Final output sent to browser
DEBUG - 2024-02-12 14:07:38 --> Total execution time: 0.0367
ERROR - 2024-02-12 14:07:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:07:39 --> Config Class Initialized
INFO - 2024-02-12 14:07:39 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:07:39 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:07:39 --> Utf8 Class Initialized
INFO - 2024-02-12 14:07:39 --> URI Class Initialized
INFO - 2024-02-12 14:07:39 --> Router Class Initialized
INFO - 2024-02-12 14:07:39 --> Output Class Initialized
INFO - 2024-02-12 14:07:39 --> Security Class Initialized
DEBUG - 2024-02-12 14:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:07:39 --> Input Class Initialized
INFO - 2024-02-12 14:07:39 --> Language Class Initialized
INFO - 2024-02-12 14:07:39 --> Loader Class Initialized
INFO - 2024-02-12 14:07:39 --> Helper loaded: url_helper
INFO - 2024-02-12 14:07:39 --> Helper loaded: file_helper
INFO - 2024-02-12 14:07:39 --> Helper loaded: html_helper
INFO - 2024-02-12 14:07:39 --> Helper loaded: text_helper
INFO - 2024-02-12 14:07:39 --> Helper loaded: form_helper
INFO - 2024-02-12 14:07:39 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:07:39 --> Helper loaded: security_helper
INFO - 2024-02-12 14:07:39 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:07:39 --> Database Driver Class Initialized
INFO - 2024-02-12 14:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:07:39 --> Parser Class Initialized
INFO - 2024-02-12 14:07:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:07:39 --> Pagination Class Initialized
INFO - 2024-02-12 14:07:39 --> Form Validation Class Initialized
INFO - 2024-02-12 14:07:39 --> Controller Class Initialized
INFO - 2024-02-12 14:07:39 --> Model Class Initialized
DEBUG - 2024-02-12 14:07:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:07:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:07:39 --> Model Class Initialized
DEBUG - 2024-02-12 14:07:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:07:39 --> Model Class Initialized
INFO - 2024-02-12 14:07:39 --> Final output sent to browser
DEBUG - 2024-02-12 14:07:39 --> Total execution time: 0.0233
ERROR - 2024-02-12 14:07:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:07:42 --> Config Class Initialized
INFO - 2024-02-12 14:07:42 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:07:42 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:07:42 --> Utf8 Class Initialized
INFO - 2024-02-12 14:07:42 --> URI Class Initialized
INFO - 2024-02-12 14:07:42 --> Router Class Initialized
INFO - 2024-02-12 14:07:42 --> Output Class Initialized
INFO - 2024-02-12 14:07:42 --> Security Class Initialized
DEBUG - 2024-02-12 14:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:07:42 --> Input Class Initialized
INFO - 2024-02-12 14:07:42 --> Language Class Initialized
INFO - 2024-02-12 14:07:42 --> Loader Class Initialized
INFO - 2024-02-12 14:07:42 --> Helper loaded: url_helper
INFO - 2024-02-12 14:07:42 --> Helper loaded: file_helper
INFO - 2024-02-12 14:07:42 --> Helper loaded: html_helper
INFO - 2024-02-12 14:07:42 --> Helper loaded: text_helper
INFO - 2024-02-12 14:07:42 --> Helper loaded: form_helper
INFO - 2024-02-12 14:07:42 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:07:42 --> Helper loaded: security_helper
INFO - 2024-02-12 14:07:42 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:07:42 --> Database Driver Class Initialized
INFO - 2024-02-12 14:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:07:42 --> Parser Class Initialized
INFO - 2024-02-12 14:07:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:07:42 --> Pagination Class Initialized
INFO - 2024-02-12 14:07:42 --> Form Validation Class Initialized
INFO - 2024-02-12 14:07:42 --> Controller Class Initialized
INFO - 2024-02-12 14:07:42 --> Model Class Initialized
DEBUG - 2024-02-12 14:07:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:07:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:07:42 --> Model Class Initialized
DEBUG - 2024-02-12 14:07:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:07:42 --> Model Class Initialized
INFO - 2024-02-12 14:07:42 --> Final output sent to browser
DEBUG - 2024-02-12 14:07:42 --> Total execution time: 0.0186
ERROR - 2024-02-12 14:07:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:07:43 --> Config Class Initialized
INFO - 2024-02-12 14:07:43 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:07:43 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:07:43 --> Utf8 Class Initialized
INFO - 2024-02-12 14:07:43 --> URI Class Initialized
INFO - 2024-02-12 14:07:43 --> Router Class Initialized
INFO - 2024-02-12 14:07:43 --> Output Class Initialized
INFO - 2024-02-12 14:07:43 --> Security Class Initialized
DEBUG - 2024-02-12 14:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:07:43 --> Input Class Initialized
INFO - 2024-02-12 14:07:43 --> Language Class Initialized
INFO - 2024-02-12 14:07:43 --> Loader Class Initialized
INFO - 2024-02-12 14:07:43 --> Helper loaded: url_helper
INFO - 2024-02-12 14:07:43 --> Helper loaded: file_helper
INFO - 2024-02-12 14:07:43 --> Helper loaded: html_helper
INFO - 2024-02-12 14:07:43 --> Helper loaded: text_helper
INFO - 2024-02-12 14:07:43 --> Helper loaded: form_helper
INFO - 2024-02-12 14:07:43 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:07:43 --> Helper loaded: security_helper
INFO - 2024-02-12 14:07:43 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:07:44 --> Database Driver Class Initialized
INFO - 2024-02-12 14:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:07:44 --> Parser Class Initialized
INFO - 2024-02-12 14:07:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:07:44 --> Pagination Class Initialized
INFO - 2024-02-12 14:07:44 --> Form Validation Class Initialized
INFO - 2024-02-12 14:07:44 --> Controller Class Initialized
INFO - 2024-02-12 14:07:44 --> Model Class Initialized
DEBUG - 2024-02-12 14:07:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:07:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:07:44 --> Model Class Initialized
DEBUG - 2024-02-12 14:07:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:07:44 --> Model Class Initialized
INFO - 2024-02-12 14:07:44 --> Final output sent to browser
DEBUG - 2024-02-12 14:07:44 --> Total execution time: 0.0176
ERROR - 2024-02-12 14:07:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:07:45 --> Config Class Initialized
INFO - 2024-02-12 14:07:45 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:07:45 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:07:45 --> Utf8 Class Initialized
INFO - 2024-02-12 14:07:45 --> URI Class Initialized
INFO - 2024-02-12 14:07:45 --> Router Class Initialized
INFO - 2024-02-12 14:07:45 --> Output Class Initialized
INFO - 2024-02-12 14:07:45 --> Security Class Initialized
DEBUG - 2024-02-12 14:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:07:45 --> Input Class Initialized
INFO - 2024-02-12 14:07:45 --> Language Class Initialized
INFO - 2024-02-12 14:07:45 --> Loader Class Initialized
INFO - 2024-02-12 14:07:45 --> Helper loaded: url_helper
INFO - 2024-02-12 14:07:45 --> Helper loaded: file_helper
INFO - 2024-02-12 14:07:45 --> Helper loaded: html_helper
INFO - 2024-02-12 14:07:45 --> Helper loaded: text_helper
INFO - 2024-02-12 14:07:45 --> Helper loaded: form_helper
INFO - 2024-02-12 14:07:45 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:07:45 --> Helper loaded: security_helper
INFO - 2024-02-12 14:07:45 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:07:45 --> Database Driver Class Initialized
INFO - 2024-02-12 14:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:07:45 --> Parser Class Initialized
INFO - 2024-02-12 14:07:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:07:45 --> Pagination Class Initialized
INFO - 2024-02-12 14:07:45 --> Form Validation Class Initialized
INFO - 2024-02-12 14:07:45 --> Controller Class Initialized
INFO - 2024-02-12 14:07:45 --> Model Class Initialized
DEBUG - 2024-02-12 14:07:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:07:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:07:45 --> Model Class Initialized
DEBUG - 2024-02-12 14:07:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:07:45 --> Model Class Initialized
INFO - 2024-02-12 14:07:45 --> Final output sent to browser
DEBUG - 2024-02-12 14:07:45 --> Total execution time: 0.0190
ERROR - 2024-02-12 14:07:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:07:46 --> Config Class Initialized
INFO - 2024-02-12 14:07:46 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:07:46 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:07:46 --> Utf8 Class Initialized
INFO - 2024-02-12 14:07:46 --> URI Class Initialized
INFO - 2024-02-12 14:07:46 --> Router Class Initialized
INFO - 2024-02-12 14:07:46 --> Output Class Initialized
INFO - 2024-02-12 14:07:46 --> Security Class Initialized
DEBUG - 2024-02-12 14:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:07:46 --> Input Class Initialized
INFO - 2024-02-12 14:07:46 --> Language Class Initialized
INFO - 2024-02-12 14:07:46 --> Loader Class Initialized
INFO - 2024-02-12 14:07:46 --> Helper loaded: url_helper
INFO - 2024-02-12 14:07:46 --> Helper loaded: file_helper
INFO - 2024-02-12 14:07:46 --> Helper loaded: html_helper
INFO - 2024-02-12 14:07:46 --> Helper loaded: text_helper
INFO - 2024-02-12 14:07:46 --> Helper loaded: form_helper
INFO - 2024-02-12 14:07:46 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:07:46 --> Helper loaded: security_helper
INFO - 2024-02-12 14:07:46 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:07:46 --> Database Driver Class Initialized
INFO - 2024-02-12 14:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:07:46 --> Parser Class Initialized
INFO - 2024-02-12 14:07:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:07:46 --> Pagination Class Initialized
INFO - 2024-02-12 14:07:46 --> Form Validation Class Initialized
INFO - 2024-02-12 14:07:46 --> Controller Class Initialized
INFO - 2024-02-12 14:07:46 --> Model Class Initialized
DEBUG - 2024-02-12 14:07:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:07:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:07:46 --> Model Class Initialized
DEBUG - 2024-02-12 14:07:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:07:46 --> Model Class Initialized
INFO - 2024-02-12 14:07:46 --> Final output sent to browser
DEBUG - 2024-02-12 14:07:46 --> Total execution time: 0.0909
ERROR - 2024-02-12 14:07:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:07:55 --> Config Class Initialized
INFO - 2024-02-12 14:07:55 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:07:55 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:07:55 --> Utf8 Class Initialized
INFO - 2024-02-12 14:07:55 --> URI Class Initialized
INFO - 2024-02-12 14:07:55 --> Router Class Initialized
INFO - 2024-02-12 14:07:55 --> Output Class Initialized
INFO - 2024-02-12 14:07:55 --> Security Class Initialized
DEBUG - 2024-02-12 14:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:07:55 --> Input Class Initialized
INFO - 2024-02-12 14:07:55 --> Language Class Initialized
INFO - 2024-02-12 14:07:55 --> Loader Class Initialized
INFO - 2024-02-12 14:07:55 --> Helper loaded: url_helper
INFO - 2024-02-12 14:07:55 --> Helper loaded: file_helper
INFO - 2024-02-12 14:07:55 --> Helper loaded: html_helper
INFO - 2024-02-12 14:07:55 --> Helper loaded: text_helper
INFO - 2024-02-12 14:07:55 --> Helper loaded: form_helper
INFO - 2024-02-12 14:07:55 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:07:55 --> Helper loaded: security_helper
INFO - 2024-02-12 14:07:55 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:07:55 --> Database Driver Class Initialized
INFO - 2024-02-12 14:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:07:55 --> Parser Class Initialized
INFO - 2024-02-12 14:07:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:07:55 --> Pagination Class Initialized
INFO - 2024-02-12 14:07:55 --> Form Validation Class Initialized
INFO - 2024-02-12 14:07:55 --> Controller Class Initialized
INFO - 2024-02-12 14:07:55 --> Model Class Initialized
DEBUG - 2024-02-12 14:07:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:07:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:07:55 --> Model Class Initialized
DEBUG - 2024-02-12 14:07:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:07:55 --> Model Class Initialized
INFO - 2024-02-12 14:07:55 --> Final output sent to browser
DEBUG - 2024-02-12 14:07:55 --> Total execution time: 0.0367
ERROR - 2024-02-12 14:08:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:08:01 --> Config Class Initialized
INFO - 2024-02-12 14:08:01 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:08:01 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:08:01 --> Utf8 Class Initialized
INFO - 2024-02-12 14:08:01 --> URI Class Initialized
INFO - 2024-02-12 14:08:01 --> Router Class Initialized
INFO - 2024-02-12 14:08:01 --> Output Class Initialized
INFO - 2024-02-12 14:08:01 --> Security Class Initialized
DEBUG - 2024-02-12 14:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:08:01 --> Input Class Initialized
INFO - 2024-02-12 14:08:01 --> Language Class Initialized
INFO - 2024-02-12 14:08:01 --> Loader Class Initialized
INFO - 2024-02-12 14:08:01 --> Helper loaded: url_helper
INFO - 2024-02-12 14:08:01 --> Helper loaded: file_helper
INFO - 2024-02-12 14:08:01 --> Helper loaded: html_helper
INFO - 2024-02-12 14:08:01 --> Helper loaded: text_helper
INFO - 2024-02-12 14:08:01 --> Helper loaded: form_helper
INFO - 2024-02-12 14:08:01 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:08:01 --> Helper loaded: security_helper
INFO - 2024-02-12 14:08:01 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:08:01 --> Database Driver Class Initialized
INFO - 2024-02-12 14:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:08:01 --> Parser Class Initialized
INFO - 2024-02-12 14:08:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:08:01 --> Pagination Class Initialized
INFO - 2024-02-12 14:08:01 --> Form Validation Class Initialized
INFO - 2024-02-12 14:08:01 --> Controller Class Initialized
INFO - 2024-02-12 14:08:01 --> Model Class Initialized
DEBUG - 2024-02-12 14:08:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:08:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:08:01 --> Model Class Initialized
DEBUG - 2024-02-12 14:08:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:08:01 --> Model Class Initialized
INFO - 2024-02-12 14:08:01 --> Final output sent to browser
DEBUG - 2024-02-12 14:08:01 --> Total execution time: 0.0294
ERROR - 2024-02-12 14:08:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:08:04 --> Config Class Initialized
INFO - 2024-02-12 14:08:04 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:08:04 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:08:04 --> Utf8 Class Initialized
INFO - 2024-02-12 14:08:04 --> URI Class Initialized
INFO - 2024-02-12 14:08:04 --> Router Class Initialized
INFO - 2024-02-12 14:08:04 --> Output Class Initialized
INFO - 2024-02-12 14:08:04 --> Security Class Initialized
DEBUG - 2024-02-12 14:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:08:04 --> Input Class Initialized
INFO - 2024-02-12 14:08:04 --> Language Class Initialized
INFO - 2024-02-12 14:08:04 --> Loader Class Initialized
INFO - 2024-02-12 14:08:04 --> Helper loaded: url_helper
INFO - 2024-02-12 14:08:04 --> Helper loaded: file_helper
INFO - 2024-02-12 14:08:04 --> Helper loaded: html_helper
INFO - 2024-02-12 14:08:04 --> Helper loaded: text_helper
INFO - 2024-02-12 14:08:04 --> Helper loaded: form_helper
INFO - 2024-02-12 14:08:04 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:08:04 --> Helper loaded: security_helper
INFO - 2024-02-12 14:08:04 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:08:04 --> Database Driver Class Initialized
INFO - 2024-02-12 14:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:08:04 --> Parser Class Initialized
INFO - 2024-02-12 14:08:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:08:04 --> Pagination Class Initialized
INFO - 2024-02-12 14:08:04 --> Form Validation Class Initialized
INFO - 2024-02-12 14:08:04 --> Controller Class Initialized
INFO - 2024-02-12 14:08:04 --> Model Class Initialized
DEBUG - 2024-02-12 14:08:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:08:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:08:04 --> Model Class Initialized
DEBUG - 2024-02-12 14:08:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:08:04 --> Model Class Initialized
INFO - 2024-02-12 14:08:04 --> Final output sent to browser
DEBUG - 2024-02-12 14:08:04 --> Total execution time: 0.0390
ERROR - 2024-02-12 14:08:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:08:15 --> Config Class Initialized
INFO - 2024-02-12 14:08:15 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:08:15 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:08:15 --> Utf8 Class Initialized
INFO - 2024-02-12 14:08:15 --> URI Class Initialized
INFO - 2024-02-12 14:08:15 --> Router Class Initialized
INFO - 2024-02-12 14:08:15 --> Output Class Initialized
INFO - 2024-02-12 14:08:15 --> Security Class Initialized
DEBUG - 2024-02-12 14:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:08:15 --> Input Class Initialized
INFO - 2024-02-12 14:08:15 --> Language Class Initialized
INFO - 2024-02-12 14:08:15 --> Loader Class Initialized
INFO - 2024-02-12 14:08:15 --> Helper loaded: url_helper
INFO - 2024-02-12 14:08:15 --> Helper loaded: file_helper
INFO - 2024-02-12 14:08:15 --> Helper loaded: html_helper
INFO - 2024-02-12 14:08:15 --> Helper loaded: text_helper
INFO - 2024-02-12 14:08:15 --> Helper loaded: form_helper
INFO - 2024-02-12 14:08:15 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:08:15 --> Helper loaded: security_helper
INFO - 2024-02-12 14:08:15 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:08:15 --> Database Driver Class Initialized
INFO - 2024-02-12 14:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:08:15 --> Parser Class Initialized
INFO - 2024-02-12 14:08:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:08:15 --> Pagination Class Initialized
INFO - 2024-02-12 14:08:15 --> Form Validation Class Initialized
INFO - 2024-02-12 14:08:15 --> Controller Class Initialized
INFO - 2024-02-12 14:08:15 --> Model Class Initialized
DEBUG - 2024-02-12 14:08:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:08:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:08:15 --> Model Class Initialized
DEBUG - 2024-02-12 14:08:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:08:15 --> Model Class Initialized
INFO - 2024-02-12 14:08:15 --> Final output sent to browser
DEBUG - 2024-02-12 14:08:15 --> Total execution time: 0.0261
ERROR - 2024-02-12 14:08:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:08:15 --> Config Class Initialized
INFO - 2024-02-12 14:08:15 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:08:15 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:08:15 --> Utf8 Class Initialized
INFO - 2024-02-12 14:08:15 --> URI Class Initialized
INFO - 2024-02-12 14:08:15 --> Router Class Initialized
INFO - 2024-02-12 14:08:16 --> Output Class Initialized
INFO - 2024-02-12 14:08:16 --> Security Class Initialized
DEBUG - 2024-02-12 14:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:08:16 --> Input Class Initialized
INFO - 2024-02-12 14:08:16 --> Language Class Initialized
INFO - 2024-02-12 14:08:16 --> Loader Class Initialized
INFO - 2024-02-12 14:08:16 --> Helper loaded: url_helper
INFO - 2024-02-12 14:08:16 --> Helper loaded: file_helper
INFO - 2024-02-12 14:08:16 --> Helper loaded: html_helper
INFO - 2024-02-12 14:08:16 --> Helper loaded: text_helper
INFO - 2024-02-12 14:08:16 --> Helper loaded: form_helper
INFO - 2024-02-12 14:08:16 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:08:16 --> Helper loaded: security_helper
INFO - 2024-02-12 14:08:16 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:08:16 --> Database Driver Class Initialized
INFO - 2024-02-12 14:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:08:16 --> Parser Class Initialized
INFO - 2024-02-12 14:08:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:08:16 --> Pagination Class Initialized
INFO - 2024-02-12 14:08:16 --> Form Validation Class Initialized
INFO - 2024-02-12 14:08:16 --> Controller Class Initialized
INFO - 2024-02-12 14:08:16 --> Model Class Initialized
DEBUG - 2024-02-12 14:08:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:08:16 --> Model Class Initialized
DEBUG - 2024-02-12 14:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:08:16 --> Model Class Initialized
INFO - 2024-02-12 14:08:16 --> Final output sent to browser
DEBUG - 2024-02-12 14:08:16 --> Total execution time: 0.0301
ERROR - 2024-02-12 14:08:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:08:16 --> Config Class Initialized
INFO - 2024-02-12 14:08:16 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:08:16 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:08:16 --> Utf8 Class Initialized
INFO - 2024-02-12 14:08:16 --> URI Class Initialized
INFO - 2024-02-12 14:08:16 --> Router Class Initialized
INFO - 2024-02-12 14:08:16 --> Output Class Initialized
INFO - 2024-02-12 14:08:16 --> Security Class Initialized
DEBUG - 2024-02-12 14:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:08:16 --> Input Class Initialized
INFO - 2024-02-12 14:08:16 --> Language Class Initialized
INFO - 2024-02-12 14:08:16 --> Loader Class Initialized
INFO - 2024-02-12 14:08:16 --> Helper loaded: url_helper
INFO - 2024-02-12 14:08:16 --> Helper loaded: file_helper
INFO - 2024-02-12 14:08:16 --> Helper loaded: html_helper
INFO - 2024-02-12 14:08:16 --> Helper loaded: text_helper
INFO - 2024-02-12 14:08:16 --> Helper loaded: form_helper
INFO - 2024-02-12 14:08:16 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:08:16 --> Helper loaded: security_helper
INFO - 2024-02-12 14:08:16 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:08:16 --> Database Driver Class Initialized
INFO - 2024-02-12 14:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:08:16 --> Parser Class Initialized
INFO - 2024-02-12 14:08:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:08:16 --> Pagination Class Initialized
INFO - 2024-02-12 14:08:16 --> Form Validation Class Initialized
INFO - 2024-02-12 14:08:16 --> Controller Class Initialized
INFO - 2024-02-12 14:08:16 --> Model Class Initialized
DEBUG - 2024-02-12 14:08:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:08:16 --> Model Class Initialized
DEBUG - 2024-02-12 14:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:08:16 --> Model Class Initialized
INFO - 2024-02-12 14:08:16 --> Final output sent to browser
DEBUG - 2024-02-12 14:08:16 --> Total execution time: 0.0174
ERROR - 2024-02-12 14:08:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:08:18 --> Config Class Initialized
INFO - 2024-02-12 14:08:18 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:08:18 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:08:18 --> Utf8 Class Initialized
INFO - 2024-02-12 14:08:18 --> URI Class Initialized
INFO - 2024-02-12 14:08:18 --> Router Class Initialized
INFO - 2024-02-12 14:08:18 --> Output Class Initialized
INFO - 2024-02-12 14:08:18 --> Security Class Initialized
DEBUG - 2024-02-12 14:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:08:18 --> Input Class Initialized
INFO - 2024-02-12 14:08:18 --> Language Class Initialized
INFO - 2024-02-12 14:08:18 --> Loader Class Initialized
INFO - 2024-02-12 14:08:18 --> Helper loaded: url_helper
INFO - 2024-02-12 14:08:18 --> Helper loaded: file_helper
INFO - 2024-02-12 14:08:18 --> Helper loaded: html_helper
INFO - 2024-02-12 14:08:18 --> Helper loaded: text_helper
INFO - 2024-02-12 14:08:18 --> Helper loaded: form_helper
INFO - 2024-02-12 14:08:18 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:08:18 --> Helper loaded: security_helper
INFO - 2024-02-12 14:08:18 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:08:18 --> Database Driver Class Initialized
INFO - 2024-02-12 14:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:08:18 --> Parser Class Initialized
INFO - 2024-02-12 14:08:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:08:18 --> Pagination Class Initialized
INFO - 2024-02-12 14:08:18 --> Form Validation Class Initialized
INFO - 2024-02-12 14:08:18 --> Controller Class Initialized
INFO - 2024-02-12 14:08:18 --> Model Class Initialized
DEBUG - 2024-02-12 14:08:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:08:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:08:18 --> Model Class Initialized
DEBUG - 2024-02-12 14:08:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:08:18 --> Model Class Initialized
INFO - 2024-02-12 14:08:18 --> Final output sent to browser
DEBUG - 2024-02-12 14:08:18 --> Total execution time: 0.0266
ERROR - 2024-02-12 14:08:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:08:19 --> Config Class Initialized
INFO - 2024-02-12 14:08:19 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:08:19 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:08:19 --> Utf8 Class Initialized
INFO - 2024-02-12 14:08:19 --> URI Class Initialized
INFO - 2024-02-12 14:08:19 --> Router Class Initialized
INFO - 2024-02-12 14:08:19 --> Output Class Initialized
INFO - 2024-02-12 14:08:19 --> Security Class Initialized
DEBUG - 2024-02-12 14:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:08:19 --> Input Class Initialized
INFO - 2024-02-12 14:08:19 --> Language Class Initialized
INFO - 2024-02-12 14:08:19 --> Loader Class Initialized
INFO - 2024-02-12 14:08:19 --> Helper loaded: url_helper
INFO - 2024-02-12 14:08:19 --> Helper loaded: file_helper
INFO - 2024-02-12 14:08:19 --> Helper loaded: html_helper
INFO - 2024-02-12 14:08:19 --> Helper loaded: text_helper
INFO - 2024-02-12 14:08:19 --> Helper loaded: form_helper
INFO - 2024-02-12 14:08:19 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:08:19 --> Helper loaded: security_helper
INFO - 2024-02-12 14:08:19 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:08:19 --> Database Driver Class Initialized
INFO - 2024-02-12 14:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:08:19 --> Parser Class Initialized
INFO - 2024-02-12 14:08:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:08:19 --> Pagination Class Initialized
INFO - 2024-02-12 14:08:19 --> Form Validation Class Initialized
INFO - 2024-02-12 14:08:19 --> Controller Class Initialized
INFO - 2024-02-12 14:08:19 --> Model Class Initialized
DEBUG - 2024-02-12 14:08:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:08:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:08:19 --> Model Class Initialized
DEBUG - 2024-02-12 14:08:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:08:19 --> Model Class Initialized
INFO - 2024-02-12 14:08:20 --> Final output sent to browser
DEBUG - 2024-02-12 14:08:20 --> Total execution time: 0.0416
ERROR - 2024-02-12 14:08:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:08:20 --> Config Class Initialized
INFO - 2024-02-12 14:08:20 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:08:20 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:08:20 --> Utf8 Class Initialized
INFO - 2024-02-12 14:08:20 --> URI Class Initialized
INFO - 2024-02-12 14:08:20 --> Router Class Initialized
INFO - 2024-02-12 14:08:20 --> Output Class Initialized
INFO - 2024-02-12 14:08:20 --> Security Class Initialized
DEBUG - 2024-02-12 14:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:08:20 --> Input Class Initialized
INFO - 2024-02-12 14:08:20 --> Language Class Initialized
INFO - 2024-02-12 14:08:20 --> Loader Class Initialized
INFO - 2024-02-12 14:08:20 --> Helper loaded: url_helper
INFO - 2024-02-12 14:08:20 --> Helper loaded: file_helper
INFO - 2024-02-12 14:08:20 --> Helper loaded: html_helper
INFO - 2024-02-12 14:08:20 --> Helper loaded: text_helper
INFO - 2024-02-12 14:08:20 --> Helper loaded: form_helper
INFO - 2024-02-12 14:08:20 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:08:20 --> Helper loaded: security_helper
INFO - 2024-02-12 14:08:20 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:08:20 --> Database Driver Class Initialized
INFO - 2024-02-12 14:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:08:20 --> Parser Class Initialized
INFO - 2024-02-12 14:08:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:08:20 --> Pagination Class Initialized
INFO - 2024-02-12 14:08:20 --> Form Validation Class Initialized
INFO - 2024-02-12 14:08:20 --> Controller Class Initialized
INFO - 2024-02-12 14:08:20 --> Model Class Initialized
DEBUG - 2024-02-12 14:08:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:08:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:08:20 --> Model Class Initialized
DEBUG - 2024-02-12 14:08:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:08:20 --> Model Class Initialized
INFO - 2024-02-12 14:08:20 --> Final output sent to browser
DEBUG - 2024-02-12 14:08:20 --> Total execution time: 0.0993
ERROR - 2024-02-12 14:10:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:10:26 --> Config Class Initialized
INFO - 2024-02-12 14:10:26 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:10:26 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:10:26 --> Utf8 Class Initialized
INFO - 2024-02-12 14:10:26 --> URI Class Initialized
INFO - 2024-02-12 14:10:26 --> Router Class Initialized
INFO - 2024-02-12 14:10:26 --> Output Class Initialized
INFO - 2024-02-12 14:10:26 --> Security Class Initialized
DEBUG - 2024-02-12 14:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:10:26 --> Input Class Initialized
INFO - 2024-02-12 14:10:26 --> Language Class Initialized
INFO - 2024-02-12 14:10:26 --> Loader Class Initialized
INFO - 2024-02-12 14:10:26 --> Helper loaded: url_helper
INFO - 2024-02-12 14:10:26 --> Helper loaded: file_helper
INFO - 2024-02-12 14:10:26 --> Helper loaded: html_helper
INFO - 2024-02-12 14:10:26 --> Helper loaded: text_helper
INFO - 2024-02-12 14:10:26 --> Helper loaded: form_helper
INFO - 2024-02-12 14:10:26 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:10:26 --> Helper loaded: security_helper
INFO - 2024-02-12 14:10:26 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:10:26 --> Database Driver Class Initialized
INFO - 2024-02-12 14:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:10:26 --> Parser Class Initialized
INFO - 2024-02-12 14:10:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:10:26 --> Pagination Class Initialized
INFO - 2024-02-12 14:10:26 --> Form Validation Class Initialized
INFO - 2024-02-12 14:10:26 --> Controller Class Initialized
INFO - 2024-02-12 14:10:26 --> Model Class Initialized
DEBUG - 2024-02-12 14:10:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:10:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:10:26 --> Model Class Initialized
DEBUG - 2024-02-12 14:10:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:10:26 --> Model Class Initialized
INFO - 2024-02-12 14:10:26 --> Final output sent to browser
DEBUG - 2024-02-12 14:10:26 --> Total execution time: 0.0237
ERROR - 2024-02-12 14:10:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:10:30 --> Config Class Initialized
INFO - 2024-02-12 14:10:30 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:10:30 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:10:30 --> Utf8 Class Initialized
INFO - 2024-02-12 14:10:30 --> URI Class Initialized
INFO - 2024-02-12 14:10:30 --> Router Class Initialized
INFO - 2024-02-12 14:10:30 --> Output Class Initialized
INFO - 2024-02-12 14:10:30 --> Security Class Initialized
DEBUG - 2024-02-12 14:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:10:30 --> Input Class Initialized
INFO - 2024-02-12 14:10:30 --> Language Class Initialized
INFO - 2024-02-12 14:10:30 --> Loader Class Initialized
INFO - 2024-02-12 14:10:30 --> Helper loaded: url_helper
INFO - 2024-02-12 14:10:30 --> Helper loaded: file_helper
INFO - 2024-02-12 14:10:30 --> Helper loaded: html_helper
INFO - 2024-02-12 14:10:30 --> Helper loaded: text_helper
INFO - 2024-02-12 14:10:30 --> Helper loaded: form_helper
INFO - 2024-02-12 14:10:30 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:10:30 --> Helper loaded: security_helper
INFO - 2024-02-12 14:10:30 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:10:30 --> Database Driver Class Initialized
INFO - 2024-02-12 14:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:10:30 --> Parser Class Initialized
INFO - 2024-02-12 14:10:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:10:30 --> Pagination Class Initialized
INFO - 2024-02-12 14:10:30 --> Form Validation Class Initialized
INFO - 2024-02-12 14:10:30 --> Controller Class Initialized
INFO - 2024-02-12 14:10:30 --> Model Class Initialized
DEBUG - 2024-02-12 14:10:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:10:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:10:30 --> Model Class Initialized
DEBUG - 2024-02-12 14:10:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:10:30 --> Model Class Initialized
INFO - 2024-02-12 14:10:30 --> Final output sent to browser
DEBUG - 2024-02-12 14:10:30 --> Total execution time: 0.0238
ERROR - 2024-02-12 14:10:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:10:32 --> Config Class Initialized
INFO - 2024-02-12 14:10:32 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:10:32 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:10:32 --> Utf8 Class Initialized
INFO - 2024-02-12 14:10:32 --> URI Class Initialized
INFO - 2024-02-12 14:10:32 --> Router Class Initialized
INFO - 2024-02-12 14:10:32 --> Output Class Initialized
INFO - 2024-02-12 14:10:32 --> Security Class Initialized
DEBUG - 2024-02-12 14:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:10:32 --> Input Class Initialized
INFO - 2024-02-12 14:10:32 --> Language Class Initialized
INFO - 2024-02-12 14:10:32 --> Loader Class Initialized
INFO - 2024-02-12 14:10:32 --> Helper loaded: url_helper
INFO - 2024-02-12 14:10:32 --> Helper loaded: file_helper
INFO - 2024-02-12 14:10:32 --> Helper loaded: html_helper
INFO - 2024-02-12 14:10:32 --> Helper loaded: text_helper
INFO - 2024-02-12 14:10:32 --> Helper loaded: form_helper
INFO - 2024-02-12 14:10:32 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:10:32 --> Helper loaded: security_helper
INFO - 2024-02-12 14:10:32 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:10:32 --> Database Driver Class Initialized
INFO - 2024-02-12 14:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:10:32 --> Parser Class Initialized
INFO - 2024-02-12 14:10:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:10:32 --> Pagination Class Initialized
INFO - 2024-02-12 14:10:32 --> Form Validation Class Initialized
INFO - 2024-02-12 14:10:32 --> Controller Class Initialized
INFO - 2024-02-12 14:10:32 --> Model Class Initialized
DEBUG - 2024-02-12 14:10:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:10:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:10:32 --> Model Class Initialized
INFO - 2024-02-12 14:10:32 --> Model Class Initialized
INFO - 2024-02-12 14:10:32 --> Final output sent to browser
DEBUG - 2024-02-12 14:10:32 --> Total execution time: 0.0226
ERROR - 2024-02-12 14:10:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:10:34 --> Config Class Initialized
INFO - 2024-02-12 14:10:34 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:10:34 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:10:34 --> Utf8 Class Initialized
INFO - 2024-02-12 14:10:34 --> URI Class Initialized
INFO - 2024-02-12 14:10:34 --> Router Class Initialized
INFO - 2024-02-12 14:10:34 --> Output Class Initialized
INFO - 2024-02-12 14:10:35 --> Security Class Initialized
DEBUG - 2024-02-12 14:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:10:35 --> Input Class Initialized
INFO - 2024-02-12 14:10:35 --> Language Class Initialized
INFO - 2024-02-12 14:10:35 --> Loader Class Initialized
INFO - 2024-02-12 14:10:35 --> Helper loaded: url_helper
INFO - 2024-02-12 14:10:35 --> Helper loaded: file_helper
INFO - 2024-02-12 14:10:35 --> Helper loaded: html_helper
INFO - 2024-02-12 14:10:35 --> Helper loaded: text_helper
INFO - 2024-02-12 14:10:35 --> Helper loaded: form_helper
INFO - 2024-02-12 14:10:35 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:10:35 --> Helper loaded: security_helper
INFO - 2024-02-12 14:10:35 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:10:35 --> Database Driver Class Initialized
INFO - 2024-02-12 14:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:10:35 --> Parser Class Initialized
INFO - 2024-02-12 14:10:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:10:35 --> Pagination Class Initialized
INFO - 2024-02-12 14:10:35 --> Form Validation Class Initialized
INFO - 2024-02-12 14:10:35 --> Controller Class Initialized
INFO - 2024-02-12 14:10:35 --> Model Class Initialized
DEBUG - 2024-02-12 14:10:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:10:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:10:35 --> Model Class Initialized
INFO - 2024-02-12 14:10:35 --> Final output sent to browser
DEBUG - 2024-02-12 14:10:35 --> Total execution time: 0.0228
ERROR - 2024-02-12 14:10:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:10:55 --> Config Class Initialized
INFO - 2024-02-12 14:10:55 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:10:55 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:10:55 --> Utf8 Class Initialized
INFO - 2024-02-12 14:10:55 --> URI Class Initialized
INFO - 2024-02-12 14:10:55 --> Router Class Initialized
INFO - 2024-02-12 14:10:55 --> Output Class Initialized
INFO - 2024-02-12 14:10:55 --> Security Class Initialized
DEBUG - 2024-02-12 14:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:10:55 --> Input Class Initialized
INFO - 2024-02-12 14:10:55 --> Language Class Initialized
INFO - 2024-02-12 14:10:55 --> Loader Class Initialized
INFO - 2024-02-12 14:10:55 --> Helper loaded: url_helper
INFO - 2024-02-12 14:10:55 --> Helper loaded: file_helper
INFO - 2024-02-12 14:10:55 --> Helper loaded: html_helper
INFO - 2024-02-12 14:10:55 --> Helper loaded: text_helper
INFO - 2024-02-12 14:10:55 --> Helper loaded: form_helper
INFO - 2024-02-12 14:10:55 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:10:55 --> Helper loaded: security_helper
INFO - 2024-02-12 14:10:55 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:10:55 --> Database Driver Class Initialized
INFO - 2024-02-12 14:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:10:55 --> Parser Class Initialized
INFO - 2024-02-12 14:10:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:10:55 --> Pagination Class Initialized
INFO - 2024-02-12 14:10:55 --> Form Validation Class Initialized
INFO - 2024-02-12 14:10:55 --> Controller Class Initialized
INFO - 2024-02-12 14:10:55 --> Model Class Initialized
DEBUG - 2024-02-12 14:10:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:10:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:10:55 --> Model Class Initialized
DEBUG - 2024-02-12 14:10:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:10:55 --> Model Class Initialized
INFO - 2024-02-12 14:10:55 --> Final output sent to browser
DEBUG - 2024-02-12 14:10:55 --> Total execution time: 0.1022
ERROR - 2024-02-12 14:10:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:10:57 --> Config Class Initialized
INFO - 2024-02-12 14:10:57 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:10:57 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:10:57 --> Utf8 Class Initialized
INFO - 2024-02-12 14:10:57 --> URI Class Initialized
INFO - 2024-02-12 14:10:57 --> Router Class Initialized
INFO - 2024-02-12 14:10:57 --> Output Class Initialized
INFO - 2024-02-12 14:10:57 --> Security Class Initialized
DEBUG - 2024-02-12 14:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:10:57 --> Input Class Initialized
INFO - 2024-02-12 14:10:57 --> Language Class Initialized
INFO - 2024-02-12 14:10:57 --> Loader Class Initialized
INFO - 2024-02-12 14:10:57 --> Helper loaded: url_helper
INFO - 2024-02-12 14:10:57 --> Helper loaded: file_helper
INFO - 2024-02-12 14:10:57 --> Helper loaded: html_helper
INFO - 2024-02-12 14:10:57 --> Helper loaded: text_helper
INFO - 2024-02-12 14:10:57 --> Helper loaded: form_helper
INFO - 2024-02-12 14:10:57 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:10:57 --> Helper loaded: security_helper
INFO - 2024-02-12 14:10:57 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:10:57 --> Database Driver Class Initialized
INFO - 2024-02-12 14:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:10:57 --> Parser Class Initialized
INFO - 2024-02-12 14:10:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:10:57 --> Pagination Class Initialized
INFO - 2024-02-12 14:10:57 --> Form Validation Class Initialized
INFO - 2024-02-12 14:10:57 --> Controller Class Initialized
INFO - 2024-02-12 14:10:57 --> Model Class Initialized
DEBUG - 2024-02-12 14:10:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:10:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:10:57 --> Model Class Initialized
DEBUG - 2024-02-12 14:10:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:10:57 --> Model Class Initialized
INFO - 2024-02-12 14:10:57 --> Final output sent to browser
DEBUG - 2024-02-12 14:10:57 --> Total execution time: 0.0904
ERROR - 2024-02-12 14:10:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:10:58 --> Config Class Initialized
INFO - 2024-02-12 14:10:58 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:10:58 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:10:58 --> Utf8 Class Initialized
INFO - 2024-02-12 14:10:58 --> URI Class Initialized
INFO - 2024-02-12 14:10:58 --> Router Class Initialized
INFO - 2024-02-12 14:10:58 --> Output Class Initialized
INFO - 2024-02-12 14:10:58 --> Security Class Initialized
DEBUG - 2024-02-12 14:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:10:58 --> Input Class Initialized
INFO - 2024-02-12 14:10:58 --> Language Class Initialized
INFO - 2024-02-12 14:10:58 --> Loader Class Initialized
INFO - 2024-02-12 14:10:58 --> Helper loaded: url_helper
INFO - 2024-02-12 14:10:58 --> Helper loaded: file_helper
INFO - 2024-02-12 14:10:58 --> Helper loaded: html_helper
INFO - 2024-02-12 14:10:58 --> Helper loaded: text_helper
INFO - 2024-02-12 14:10:58 --> Helper loaded: form_helper
INFO - 2024-02-12 14:10:58 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:10:58 --> Helper loaded: security_helper
INFO - 2024-02-12 14:10:58 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:10:58 --> Database Driver Class Initialized
INFO - 2024-02-12 14:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:10:58 --> Parser Class Initialized
INFO - 2024-02-12 14:10:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:10:58 --> Pagination Class Initialized
INFO - 2024-02-12 14:10:58 --> Form Validation Class Initialized
INFO - 2024-02-12 14:10:58 --> Controller Class Initialized
INFO - 2024-02-12 14:10:58 --> Model Class Initialized
DEBUG - 2024-02-12 14:10:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:10:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:10:58 --> Model Class Initialized
DEBUG - 2024-02-12 14:10:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:10:58 --> Model Class Initialized
INFO - 2024-02-12 14:10:58 --> Final output sent to browser
DEBUG - 2024-02-12 14:10:58 --> Total execution time: 0.0973
ERROR - 2024-02-12 14:11:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:11:10 --> Config Class Initialized
INFO - 2024-02-12 14:11:10 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:11:10 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:11:10 --> Utf8 Class Initialized
INFO - 2024-02-12 14:11:10 --> URI Class Initialized
INFO - 2024-02-12 14:11:10 --> Router Class Initialized
INFO - 2024-02-12 14:11:10 --> Output Class Initialized
INFO - 2024-02-12 14:11:10 --> Security Class Initialized
DEBUG - 2024-02-12 14:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:11:10 --> Input Class Initialized
INFO - 2024-02-12 14:11:10 --> Language Class Initialized
INFO - 2024-02-12 14:11:10 --> Loader Class Initialized
INFO - 2024-02-12 14:11:10 --> Helper loaded: url_helper
INFO - 2024-02-12 14:11:10 --> Helper loaded: file_helper
INFO - 2024-02-12 14:11:10 --> Helper loaded: html_helper
INFO - 2024-02-12 14:11:10 --> Helper loaded: text_helper
INFO - 2024-02-12 14:11:10 --> Helper loaded: form_helper
INFO - 2024-02-12 14:11:10 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:11:10 --> Helper loaded: security_helper
INFO - 2024-02-12 14:11:10 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:11:10 --> Database Driver Class Initialized
INFO - 2024-02-12 14:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:11:10 --> Parser Class Initialized
INFO - 2024-02-12 14:11:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:11:10 --> Pagination Class Initialized
INFO - 2024-02-12 14:11:10 --> Form Validation Class Initialized
INFO - 2024-02-12 14:11:10 --> Controller Class Initialized
INFO - 2024-02-12 14:11:10 --> Model Class Initialized
DEBUG - 2024-02-12 14:11:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:11:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:11:10 --> Model Class Initialized
INFO - 2024-02-12 14:11:10 --> Model Class Initialized
INFO - 2024-02-12 14:11:10 --> Final output sent to browser
DEBUG - 2024-02-12 14:11:10 --> Total execution time: 0.0214
ERROR - 2024-02-12 14:11:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:11:14 --> Config Class Initialized
INFO - 2024-02-12 14:11:14 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:11:14 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:11:14 --> Utf8 Class Initialized
INFO - 2024-02-12 14:11:14 --> URI Class Initialized
INFO - 2024-02-12 14:11:14 --> Router Class Initialized
INFO - 2024-02-12 14:11:14 --> Output Class Initialized
INFO - 2024-02-12 14:11:14 --> Security Class Initialized
DEBUG - 2024-02-12 14:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:11:14 --> Input Class Initialized
INFO - 2024-02-12 14:11:14 --> Language Class Initialized
INFO - 2024-02-12 14:11:14 --> Loader Class Initialized
INFO - 2024-02-12 14:11:14 --> Helper loaded: url_helper
INFO - 2024-02-12 14:11:14 --> Helper loaded: file_helper
INFO - 2024-02-12 14:11:14 --> Helper loaded: html_helper
INFO - 2024-02-12 14:11:14 --> Helper loaded: text_helper
INFO - 2024-02-12 14:11:14 --> Helper loaded: form_helper
INFO - 2024-02-12 14:11:14 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:11:14 --> Helper loaded: security_helper
INFO - 2024-02-12 14:11:14 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:11:14 --> Database Driver Class Initialized
INFO - 2024-02-12 14:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:11:14 --> Parser Class Initialized
INFO - 2024-02-12 14:11:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:11:14 --> Pagination Class Initialized
INFO - 2024-02-12 14:11:14 --> Form Validation Class Initialized
INFO - 2024-02-12 14:11:14 --> Controller Class Initialized
INFO - 2024-02-12 14:11:14 --> Model Class Initialized
DEBUG - 2024-02-12 14:11:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:11:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:11:14 --> Model Class Initialized
INFO - 2024-02-12 14:11:14 --> Final output sent to browser
DEBUG - 2024-02-12 14:11:14 --> Total execution time: 0.0168
ERROR - 2024-02-12 14:11:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:11:31 --> Config Class Initialized
INFO - 2024-02-12 14:11:31 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:11:31 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:11:31 --> Utf8 Class Initialized
INFO - 2024-02-12 14:11:31 --> URI Class Initialized
INFO - 2024-02-12 14:11:31 --> Router Class Initialized
INFO - 2024-02-12 14:11:31 --> Output Class Initialized
INFO - 2024-02-12 14:11:31 --> Security Class Initialized
DEBUG - 2024-02-12 14:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:11:31 --> Input Class Initialized
INFO - 2024-02-12 14:11:31 --> Language Class Initialized
INFO - 2024-02-12 14:11:31 --> Loader Class Initialized
INFO - 2024-02-12 14:11:31 --> Helper loaded: url_helper
INFO - 2024-02-12 14:11:31 --> Helper loaded: file_helper
INFO - 2024-02-12 14:11:31 --> Helper loaded: html_helper
INFO - 2024-02-12 14:11:31 --> Helper loaded: text_helper
INFO - 2024-02-12 14:11:31 --> Helper loaded: form_helper
INFO - 2024-02-12 14:11:31 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:11:31 --> Helper loaded: security_helper
INFO - 2024-02-12 14:11:31 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:11:31 --> Database Driver Class Initialized
INFO - 2024-02-12 14:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:11:31 --> Parser Class Initialized
INFO - 2024-02-12 14:11:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:11:31 --> Pagination Class Initialized
INFO - 2024-02-12 14:11:31 --> Form Validation Class Initialized
INFO - 2024-02-12 14:11:31 --> Controller Class Initialized
INFO - 2024-02-12 14:11:31 --> Model Class Initialized
DEBUG - 2024-02-12 14:11:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:11:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:11:31 --> Model Class Initialized
DEBUG - 2024-02-12 14:11:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:11:31 --> Model Class Initialized
INFO - 2024-02-12 14:11:31 --> Final output sent to browser
DEBUG - 2024-02-12 14:11:31 --> Total execution time: 0.0935
ERROR - 2024-02-12 14:11:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:11:34 --> Config Class Initialized
INFO - 2024-02-12 14:11:34 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:11:34 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:11:34 --> Utf8 Class Initialized
INFO - 2024-02-12 14:11:34 --> URI Class Initialized
INFO - 2024-02-12 14:11:34 --> Router Class Initialized
INFO - 2024-02-12 14:11:34 --> Output Class Initialized
INFO - 2024-02-12 14:11:34 --> Security Class Initialized
DEBUG - 2024-02-12 14:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:11:34 --> Input Class Initialized
INFO - 2024-02-12 14:11:34 --> Language Class Initialized
INFO - 2024-02-12 14:11:34 --> Loader Class Initialized
INFO - 2024-02-12 14:11:34 --> Helper loaded: url_helper
INFO - 2024-02-12 14:11:34 --> Helper loaded: file_helper
INFO - 2024-02-12 14:11:34 --> Helper loaded: html_helper
INFO - 2024-02-12 14:11:34 --> Helper loaded: text_helper
INFO - 2024-02-12 14:11:34 --> Helper loaded: form_helper
INFO - 2024-02-12 14:11:34 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:11:34 --> Helper loaded: security_helper
INFO - 2024-02-12 14:11:34 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:11:34 --> Database Driver Class Initialized
INFO - 2024-02-12 14:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:11:34 --> Parser Class Initialized
INFO - 2024-02-12 14:11:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:11:34 --> Pagination Class Initialized
INFO - 2024-02-12 14:11:34 --> Form Validation Class Initialized
INFO - 2024-02-12 14:11:34 --> Controller Class Initialized
INFO - 2024-02-12 14:11:34 --> Model Class Initialized
DEBUG - 2024-02-12 14:11:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:11:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:11:34 --> Model Class Initialized
DEBUG - 2024-02-12 14:11:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:11:34 --> Model Class Initialized
INFO - 2024-02-12 14:11:34 --> Final output sent to browser
DEBUG - 2024-02-12 14:11:34 --> Total execution time: 0.0901
ERROR - 2024-02-12 14:11:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:11:34 --> Config Class Initialized
INFO - 2024-02-12 14:11:34 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:11:34 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:11:34 --> Utf8 Class Initialized
INFO - 2024-02-12 14:11:34 --> URI Class Initialized
INFO - 2024-02-12 14:11:34 --> Router Class Initialized
INFO - 2024-02-12 14:11:34 --> Output Class Initialized
INFO - 2024-02-12 14:11:34 --> Security Class Initialized
DEBUG - 2024-02-12 14:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:11:34 --> Input Class Initialized
INFO - 2024-02-12 14:11:34 --> Language Class Initialized
INFO - 2024-02-12 14:11:34 --> Loader Class Initialized
INFO - 2024-02-12 14:11:34 --> Helper loaded: url_helper
INFO - 2024-02-12 14:11:34 --> Helper loaded: file_helper
INFO - 2024-02-12 14:11:34 --> Helper loaded: html_helper
INFO - 2024-02-12 14:11:34 --> Helper loaded: text_helper
INFO - 2024-02-12 14:11:34 --> Helper loaded: form_helper
INFO - 2024-02-12 14:11:34 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:11:34 --> Helper loaded: security_helper
INFO - 2024-02-12 14:11:34 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:11:34 --> Database Driver Class Initialized
INFO - 2024-02-12 14:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:11:34 --> Parser Class Initialized
INFO - 2024-02-12 14:11:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:11:34 --> Pagination Class Initialized
INFO - 2024-02-12 14:11:34 --> Form Validation Class Initialized
INFO - 2024-02-12 14:11:34 --> Controller Class Initialized
INFO - 2024-02-12 14:11:34 --> Model Class Initialized
DEBUG - 2024-02-12 14:11:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:11:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:11:34 --> Model Class Initialized
DEBUG - 2024-02-12 14:11:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:11:34 --> Model Class Initialized
INFO - 2024-02-12 14:11:34 --> Final output sent to browser
DEBUG - 2024-02-12 14:11:34 --> Total execution time: 0.0991
ERROR - 2024-02-12 14:11:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:11:36 --> Config Class Initialized
INFO - 2024-02-12 14:11:36 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:11:36 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:11:36 --> Utf8 Class Initialized
INFO - 2024-02-12 14:11:36 --> URI Class Initialized
INFO - 2024-02-12 14:11:36 --> Router Class Initialized
INFO - 2024-02-12 14:11:36 --> Output Class Initialized
INFO - 2024-02-12 14:11:36 --> Security Class Initialized
DEBUG - 2024-02-12 14:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:11:36 --> Input Class Initialized
INFO - 2024-02-12 14:11:36 --> Language Class Initialized
INFO - 2024-02-12 14:11:36 --> Loader Class Initialized
INFO - 2024-02-12 14:11:36 --> Helper loaded: url_helper
INFO - 2024-02-12 14:11:36 --> Helper loaded: file_helper
INFO - 2024-02-12 14:11:36 --> Helper loaded: html_helper
INFO - 2024-02-12 14:11:36 --> Helper loaded: text_helper
INFO - 2024-02-12 14:11:36 --> Helper loaded: form_helper
INFO - 2024-02-12 14:11:36 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:11:36 --> Helper loaded: security_helper
INFO - 2024-02-12 14:11:36 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:11:36 --> Database Driver Class Initialized
INFO - 2024-02-12 14:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:11:36 --> Parser Class Initialized
INFO - 2024-02-12 14:11:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:11:36 --> Pagination Class Initialized
INFO - 2024-02-12 14:11:36 --> Form Validation Class Initialized
INFO - 2024-02-12 14:11:36 --> Controller Class Initialized
INFO - 2024-02-12 14:11:36 --> Model Class Initialized
DEBUG - 2024-02-12 14:11:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:11:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:11:36 --> Model Class Initialized
DEBUG - 2024-02-12 14:11:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:11:36 --> Model Class Initialized
INFO - 2024-02-12 14:11:36 --> Final output sent to browser
DEBUG - 2024-02-12 14:11:36 --> Total execution time: 0.0432
ERROR - 2024-02-12 14:11:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:11:37 --> Config Class Initialized
INFO - 2024-02-12 14:11:37 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:11:37 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:11:37 --> Utf8 Class Initialized
INFO - 2024-02-12 14:11:37 --> URI Class Initialized
INFO - 2024-02-12 14:11:37 --> Router Class Initialized
INFO - 2024-02-12 14:11:37 --> Output Class Initialized
INFO - 2024-02-12 14:11:37 --> Security Class Initialized
DEBUG - 2024-02-12 14:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:11:37 --> Input Class Initialized
INFO - 2024-02-12 14:11:37 --> Language Class Initialized
INFO - 2024-02-12 14:11:37 --> Loader Class Initialized
INFO - 2024-02-12 14:11:37 --> Helper loaded: url_helper
INFO - 2024-02-12 14:11:37 --> Helper loaded: file_helper
INFO - 2024-02-12 14:11:37 --> Helper loaded: html_helper
INFO - 2024-02-12 14:11:37 --> Helper loaded: text_helper
INFO - 2024-02-12 14:11:37 --> Helper loaded: form_helper
INFO - 2024-02-12 14:11:37 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:11:37 --> Helper loaded: security_helper
INFO - 2024-02-12 14:11:37 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:11:37 --> Database Driver Class Initialized
INFO - 2024-02-12 14:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:11:37 --> Parser Class Initialized
INFO - 2024-02-12 14:11:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:11:37 --> Pagination Class Initialized
INFO - 2024-02-12 14:11:37 --> Form Validation Class Initialized
INFO - 2024-02-12 14:11:37 --> Controller Class Initialized
INFO - 2024-02-12 14:11:37 --> Model Class Initialized
DEBUG - 2024-02-12 14:11:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:11:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:11:37 --> Model Class Initialized
DEBUG - 2024-02-12 14:11:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:11:37 --> Model Class Initialized
INFO - 2024-02-12 14:11:37 --> Final output sent to browser
DEBUG - 2024-02-12 14:11:37 --> Total execution time: 0.0242
ERROR - 2024-02-12 14:11:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:11:40 --> Config Class Initialized
INFO - 2024-02-12 14:11:40 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:11:40 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:11:40 --> Utf8 Class Initialized
INFO - 2024-02-12 14:11:40 --> URI Class Initialized
INFO - 2024-02-12 14:11:40 --> Router Class Initialized
INFO - 2024-02-12 14:11:40 --> Output Class Initialized
INFO - 2024-02-12 14:11:40 --> Security Class Initialized
DEBUG - 2024-02-12 14:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:11:40 --> Input Class Initialized
INFO - 2024-02-12 14:11:40 --> Language Class Initialized
INFO - 2024-02-12 14:11:40 --> Loader Class Initialized
INFO - 2024-02-12 14:11:40 --> Helper loaded: url_helper
INFO - 2024-02-12 14:11:40 --> Helper loaded: file_helper
INFO - 2024-02-12 14:11:40 --> Helper loaded: html_helper
INFO - 2024-02-12 14:11:40 --> Helper loaded: text_helper
INFO - 2024-02-12 14:11:40 --> Helper loaded: form_helper
INFO - 2024-02-12 14:11:40 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:11:40 --> Helper loaded: security_helper
INFO - 2024-02-12 14:11:40 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:11:40 --> Database Driver Class Initialized
INFO - 2024-02-12 14:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:11:40 --> Parser Class Initialized
INFO - 2024-02-12 14:11:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:11:40 --> Pagination Class Initialized
INFO - 2024-02-12 14:11:40 --> Form Validation Class Initialized
INFO - 2024-02-12 14:11:40 --> Controller Class Initialized
INFO - 2024-02-12 14:11:40 --> Model Class Initialized
DEBUG - 2024-02-12 14:11:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:11:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:11:40 --> Model Class Initialized
DEBUG - 2024-02-12 14:11:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:11:40 --> Model Class Initialized
INFO - 2024-02-12 14:11:40 --> Final output sent to browser
DEBUG - 2024-02-12 14:11:40 --> Total execution time: 0.0364
ERROR - 2024-02-12 14:11:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:11:42 --> Config Class Initialized
INFO - 2024-02-12 14:11:42 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:11:42 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:11:42 --> Utf8 Class Initialized
INFO - 2024-02-12 14:11:42 --> URI Class Initialized
INFO - 2024-02-12 14:11:42 --> Router Class Initialized
INFO - 2024-02-12 14:11:42 --> Output Class Initialized
INFO - 2024-02-12 14:11:42 --> Security Class Initialized
DEBUG - 2024-02-12 14:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:11:42 --> Input Class Initialized
INFO - 2024-02-12 14:11:42 --> Language Class Initialized
INFO - 2024-02-12 14:11:42 --> Loader Class Initialized
INFO - 2024-02-12 14:11:42 --> Helper loaded: url_helper
INFO - 2024-02-12 14:11:42 --> Helper loaded: file_helper
INFO - 2024-02-12 14:11:42 --> Helper loaded: html_helper
INFO - 2024-02-12 14:11:42 --> Helper loaded: text_helper
INFO - 2024-02-12 14:11:42 --> Helper loaded: form_helper
INFO - 2024-02-12 14:11:42 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:11:42 --> Helper loaded: security_helper
INFO - 2024-02-12 14:11:42 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:11:42 --> Database Driver Class Initialized
INFO - 2024-02-12 14:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:11:42 --> Parser Class Initialized
INFO - 2024-02-12 14:11:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:11:42 --> Pagination Class Initialized
INFO - 2024-02-12 14:11:42 --> Form Validation Class Initialized
INFO - 2024-02-12 14:11:42 --> Controller Class Initialized
INFO - 2024-02-12 14:11:42 --> Model Class Initialized
DEBUG - 2024-02-12 14:11:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:11:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:11:42 --> Model Class Initialized
DEBUG - 2024-02-12 14:11:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:11:42 --> Model Class Initialized
INFO - 2024-02-12 14:11:42 --> Final output sent to browser
DEBUG - 2024-02-12 14:11:42 --> Total execution time: 0.0174
ERROR - 2024-02-12 14:12:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:12:06 --> Config Class Initialized
INFO - 2024-02-12 14:12:06 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:12:06 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:12:06 --> Utf8 Class Initialized
INFO - 2024-02-12 14:12:06 --> URI Class Initialized
INFO - 2024-02-12 14:12:06 --> Router Class Initialized
INFO - 2024-02-12 14:12:06 --> Output Class Initialized
INFO - 2024-02-12 14:12:06 --> Security Class Initialized
DEBUG - 2024-02-12 14:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:12:06 --> Input Class Initialized
INFO - 2024-02-12 14:12:06 --> Language Class Initialized
INFO - 2024-02-12 14:12:06 --> Loader Class Initialized
INFO - 2024-02-12 14:12:06 --> Helper loaded: url_helper
INFO - 2024-02-12 14:12:06 --> Helper loaded: file_helper
INFO - 2024-02-12 14:12:06 --> Helper loaded: html_helper
INFO - 2024-02-12 14:12:06 --> Helper loaded: text_helper
INFO - 2024-02-12 14:12:06 --> Helper loaded: form_helper
INFO - 2024-02-12 14:12:06 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:12:06 --> Helper loaded: security_helper
INFO - 2024-02-12 14:12:06 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:12:06 --> Database Driver Class Initialized
INFO - 2024-02-12 14:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:12:06 --> Parser Class Initialized
INFO - 2024-02-12 14:12:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:12:06 --> Pagination Class Initialized
INFO - 2024-02-12 14:12:06 --> Form Validation Class Initialized
INFO - 2024-02-12 14:12:06 --> Controller Class Initialized
INFO - 2024-02-12 14:12:06 --> Model Class Initialized
DEBUG - 2024-02-12 14:12:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:12:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:12:06 --> Model Class Initialized
DEBUG - 2024-02-12 14:12:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:12:06 --> Model Class Initialized
INFO - 2024-02-12 14:12:06 --> Final output sent to browser
DEBUG - 2024-02-12 14:12:06 --> Total execution time: 0.0965
ERROR - 2024-02-12 14:12:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:12:08 --> Config Class Initialized
INFO - 2024-02-12 14:12:08 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:12:08 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:12:08 --> Utf8 Class Initialized
INFO - 2024-02-12 14:12:08 --> URI Class Initialized
INFO - 2024-02-12 14:12:08 --> Router Class Initialized
INFO - 2024-02-12 14:12:08 --> Output Class Initialized
INFO - 2024-02-12 14:12:08 --> Security Class Initialized
DEBUG - 2024-02-12 14:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:12:08 --> Input Class Initialized
INFO - 2024-02-12 14:12:08 --> Language Class Initialized
INFO - 2024-02-12 14:12:08 --> Loader Class Initialized
INFO - 2024-02-12 14:12:08 --> Helper loaded: url_helper
INFO - 2024-02-12 14:12:08 --> Helper loaded: file_helper
INFO - 2024-02-12 14:12:08 --> Helper loaded: html_helper
INFO - 2024-02-12 14:12:08 --> Helper loaded: text_helper
INFO - 2024-02-12 14:12:08 --> Helper loaded: form_helper
INFO - 2024-02-12 14:12:08 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:12:08 --> Helper loaded: security_helper
INFO - 2024-02-12 14:12:08 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:12:08 --> Database Driver Class Initialized
INFO - 2024-02-12 14:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:12:08 --> Parser Class Initialized
INFO - 2024-02-12 14:12:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:12:08 --> Pagination Class Initialized
INFO - 2024-02-12 14:12:08 --> Form Validation Class Initialized
INFO - 2024-02-12 14:12:08 --> Controller Class Initialized
INFO - 2024-02-12 14:12:08 --> Model Class Initialized
DEBUG - 2024-02-12 14:12:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:12:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:12:08 --> Model Class Initialized
DEBUG - 2024-02-12 14:12:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:12:08 --> Model Class Initialized
INFO - 2024-02-12 14:12:08 --> Final output sent to browser
DEBUG - 2024-02-12 14:12:08 --> Total execution time: 0.0938
ERROR - 2024-02-12 14:12:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:12:09 --> Config Class Initialized
INFO - 2024-02-12 14:12:09 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:12:09 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:12:09 --> Utf8 Class Initialized
INFO - 2024-02-12 14:12:09 --> URI Class Initialized
INFO - 2024-02-12 14:12:09 --> Router Class Initialized
INFO - 2024-02-12 14:12:09 --> Output Class Initialized
INFO - 2024-02-12 14:12:09 --> Security Class Initialized
DEBUG - 2024-02-12 14:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:12:09 --> Input Class Initialized
INFO - 2024-02-12 14:12:09 --> Language Class Initialized
INFO - 2024-02-12 14:12:09 --> Loader Class Initialized
INFO - 2024-02-12 14:12:09 --> Helper loaded: url_helper
INFO - 2024-02-12 14:12:09 --> Helper loaded: file_helper
INFO - 2024-02-12 14:12:09 --> Helper loaded: html_helper
INFO - 2024-02-12 14:12:09 --> Helper loaded: text_helper
INFO - 2024-02-12 14:12:09 --> Helper loaded: form_helper
INFO - 2024-02-12 14:12:09 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:12:09 --> Helper loaded: security_helper
INFO - 2024-02-12 14:12:09 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:12:09 --> Database Driver Class Initialized
INFO - 2024-02-12 14:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:12:09 --> Parser Class Initialized
INFO - 2024-02-12 14:12:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:12:09 --> Pagination Class Initialized
INFO - 2024-02-12 14:12:09 --> Form Validation Class Initialized
INFO - 2024-02-12 14:12:09 --> Controller Class Initialized
INFO - 2024-02-12 14:12:09 --> Model Class Initialized
DEBUG - 2024-02-12 14:12:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:12:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:12:09 --> Model Class Initialized
DEBUG - 2024-02-12 14:12:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:12:09 --> Model Class Initialized
INFO - 2024-02-12 14:12:09 --> Final output sent to browser
DEBUG - 2024-02-12 14:12:09 --> Total execution time: 0.0979
ERROR - 2024-02-12 14:12:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:12:21 --> Config Class Initialized
INFO - 2024-02-12 14:12:21 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:12:21 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:12:21 --> Utf8 Class Initialized
INFO - 2024-02-12 14:12:21 --> URI Class Initialized
INFO - 2024-02-12 14:12:21 --> Router Class Initialized
INFO - 2024-02-12 14:12:21 --> Output Class Initialized
INFO - 2024-02-12 14:12:21 --> Security Class Initialized
DEBUG - 2024-02-12 14:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:12:21 --> Input Class Initialized
INFO - 2024-02-12 14:12:21 --> Language Class Initialized
INFO - 2024-02-12 14:12:21 --> Loader Class Initialized
INFO - 2024-02-12 14:12:21 --> Helper loaded: url_helper
INFO - 2024-02-12 14:12:21 --> Helper loaded: file_helper
INFO - 2024-02-12 14:12:21 --> Helper loaded: html_helper
INFO - 2024-02-12 14:12:21 --> Helper loaded: text_helper
INFO - 2024-02-12 14:12:21 --> Helper loaded: form_helper
INFO - 2024-02-12 14:12:21 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:12:21 --> Helper loaded: security_helper
INFO - 2024-02-12 14:12:21 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:12:21 --> Database Driver Class Initialized
INFO - 2024-02-12 14:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:12:21 --> Parser Class Initialized
INFO - 2024-02-12 14:12:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:12:21 --> Pagination Class Initialized
INFO - 2024-02-12 14:12:21 --> Form Validation Class Initialized
INFO - 2024-02-12 14:12:21 --> Controller Class Initialized
INFO - 2024-02-12 14:12:21 --> Model Class Initialized
DEBUG - 2024-02-12 14:12:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:12:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:12:21 --> Model Class Initialized
DEBUG - 2024-02-12 14:12:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:12:21 --> Model Class Initialized
INFO - 2024-02-12 14:12:21 --> Final output sent to browser
DEBUG - 2024-02-12 14:12:21 --> Total execution time: 0.0950
ERROR - 2024-02-12 14:12:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:12:22 --> Config Class Initialized
INFO - 2024-02-12 14:12:22 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:12:22 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:12:22 --> Utf8 Class Initialized
INFO - 2024-02-12 14:12:22 --> URI Class Initialized
INFO - 2024-02-12 14:12:22 --> Router Class Initialized
INFO - 2024-02-12 14:12:22 --> Output Class Initialized
INFO - 2024-02-12 14:12:22 --> Security Class Initialized
DEBUG - 2024-02-12 14:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:12:22 --> Input Class Initialized
INFO - 2024-02-12 14:12:22 --> Language Class Initialized
INFO - 2024-02-12 14:12:22 --> Loader Class Initialized
INFO - 2024-02-12 14:12:22 --> Helper loaded: url_helper
INFO - 2024-02-12 14:12:22 --> Helper loaded: file_helper
INFO - 2024-02-12 14:12:22 --> Helper loaded: html_helper
INFO - 2024-02-12 14:12:22 --> Helper loaded: text_helper
INFO - 2024-02-12 14:12:22 --> Helper loaded: form_helper
INFO - 2024-02-12 14:12:22 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:12:22 --> Helper loaded: security_helper
INFO - 2024-02-12 14:12:22 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:12:22 --> Database Driver Class Initialized
INFO - 2024-02-12 14:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:12:22 --> Parser Class Initialized
INFO - 2024-02-12 14:12:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:12:22 --> Pagination Class Initialized
INFO - 2024-02-12 14:12:22 --> Form Validation Class Initialized
INFO - 2024-02-12 14:12:22 --> Controller Class Initialized
INFO - 2024-02-12 14:12:22 --> Model Class Initialized
DEBUG - 2024-02-12 14:12:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:12:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:12:22 --> Model Class Initialized
DEBUG - 2024-02-12 14:12:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:12:22 --> Model Class Initialized
INFO - 2024-02-12 14:12:22 --> Final output sent to browser
DEBUG - 2024-02-12 14:12:22 --> Total execution time: 0.0895
ERROR - 2024-02-12 14:12:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:12:23 --> Config Class Initialized
INFO - 2024-02-12 14:12:23 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:12:23 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:12:23 --> Utf8 Class Initialized
INFO - 2024-02-12 14:12:23 --> URI Class Initialized
INFO - 2024-02-12 14:12:23 --> Router Class Initialized
INFO - 2024-02-12 14:12:23 --> Output Class Initialized
INFO - 2024-02-12 14:12:23 --> Security Class Initialized
DEBUG - 2024-02-12 14:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:12:23 --> Input Class Initialized
INFO - 2024-02-12 14:12:23 --> Language Class Initialized
INFO - 2024-02-12 14:12:23 --> Loader Class Initialized
INFO - 2024-02-12 14:12:23 --> Helper loaded: url_helper
INFO - 2024-02-12 14:12:23 --> Helper loaded: file_helper
INFO - 2024-02-12 14:12:23 --> Helper loaded: html_helper
INFO - 2024-02-12 14:12:23 --> Helper loaded: text_helper
INFO - 2024-02-12 14:12:23 --> Helper loaded: form_helper
INFO - 2024-02-12 14:12:23 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:12:23 --> Helper loaded: security_helper
INFO - 2024-02-12 14:12:23 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:12:23 --> Database Driver Class Initialized
INFO - 2024-02-12 14:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:12:23 --> Parser Class Initialized
INFO - 2024-02-12 14:12:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:12:23 --> Pagination Class Initialized
INFO - 2024-02-12 14:12:23 --> Form Validation Class Initialized
INFO - 2024-02-12 14:12:23 --> Controller Class Initialized
INFO - 2024-02-12 14:12:23 --> Model Class Initialized
DEBUG - 2024-02-12 14:12:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:12:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:12:23 --> Model Class Initialized
DEBUG - 2024-02-12 14:12:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:12:23 --> Model Class Initialized
INFO - 2024-02-12 14:12:23 --> Final output sent to browser
DEBUG - 2024-02-12 14:12:23 --> Total execution time: 0.0916
ERROR - 2024-02-12 14:12:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:12:24 --> Config Class Initialized
INFO - 2024-02-12 14:12:24 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:12:24 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:12:24 --> Utf8 Class Initialized
INFO - 2024-02-12 14:12:24 --> URI Class Initialized
INFO - 2024-02-12 14:12:24 --> Router Class Initialized
INFO - 2024-02-12 14:12:24 --> Output Class Initialized
INFO - 2024-02-12 14:12:24 --> Security Class Initialized
DEBUG - 2024-02-12 14:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:12:24 --> Input Class Initialized
INFO - 2024-02-12 14:12:24 --> Language Class Initialized
INFO - 2024-02-12 14:12:24 --> Loader Class Initialized
INFO - 2024-02-12 14:12:24 --> Helper loaded: url_helper
INFO - 2024-02-12 14:12:24 --> Helper loaded: file_helper
INFO - 2024-02-12 14:12:24 --> Helper loaded: html_helper
INFO - 2024-02-12 14:12:24 --> Helper loaded: text_helper
INFO - 2024-02-12 14:12:24 --> Helper loaded: form_helper
INFO - 2024-02-12 14:12:24 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:12:24 --> Helper loaded: security_helper
INFO - 2024-02-12 14:12:24 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:12:24 --> Database Driver Class Initialized
INFO - 2024-02-12 14:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:12:24 --> Parser Class Initialized
INFO - 2024-02-12 14:12:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:12:24 --> Pagination Class Initialized
INFO - 2024-02-12 14:12:24 --> Form Validation Class Initialized
INFO - 2024-02-12 14:12:24 --> Controller Class Initialized
INFO - 2024-02-12 14:12:24 --> Model Class Initialized
DEBUG - 2024-02-12 14:12:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:12:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:12:24 --> Model Class Initialized
DEBUG - 2024-02-12 14:12:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:12:24 --> Model Class Initialized
INFO - 2024-02-12 14:12:24 --> Final output sent to browser
DEBUG - 2024-02-12 14:12:24 --> Total execution time: 0.1008
ERROR - 2024-02-12 14:12:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:12:36 --> Config Class Initialized
INFO - 2024-02-12 14:12:36 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:12:36 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:12:36 --> Utf8 Class Initialized
INFO - 2024-02-12 14:12:36 --> URI Class Initialized
INFO - 2024-02-12 14:12:36 --> Router Class Initialized
INFO - 2024-02-12 14:12:36 --> Output Class Initialized
INFO - 2024-02-12 14:12:36 --> Security Class Initialized
DEBUG - 2024-02-12 14:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:12:36 --> Input Class Initialized
INFO - 2024-02-12 14:12:36 --> Language Class Initialized
INFO - 2024-02-12 14:12:36 --> Loader Class Initialized
INFO - 2024-02-12 14:12:36 --> Helper loaded: url_helper
INFO - 2024-02-12 14:12:36 --> Helper loaded: file_helper
INFO - 2024-02-12 14:12:36 --> Helper loaded: html_helper
INFO - 2024-02-12 14:12:36 --> Helper loaded: text_helper
INFO - 2024-02-12 14:12:36 --> Helper loaded: form_helper
INFO - 2024-02-12 14:12:36 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:12:36 --> Helper loaded: security_helper
INFO - 2024-02-12 14:12:36 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:12:36 --> Database Driver Class Initialized
INFO - 2024-02-12 14:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:12:36 --> Parser Class Initialized
INFO - 2024-02-12 14:12:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:12:36 --> Pagination Class Initialized
INFO - 2024-02-12 14:12:36 --> Form Validation Class Initialized
INFO - 2024-02-12 14:12:36 --> Controller Class Initialized
INFO - 2024-02-12 14:12:36 --> Model Class Initialized
DEBUG - 2024-02-12 14:12:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:12:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:12:36 --> Model Class Initialized
DEBUG - 2024-02-12 14:12:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:12:36 --> Model Class Initialized
INFO - 2024-02-12 14:12:36 --> Final output sent to browser
DEBUG - 2024-02-12 14:12:36 --> Total execution time: 0.0408
ERROR - 2024-02-12 14:12:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:12:37 --> Config Class Initialized
INFO - 2024-02-12 14:12:37 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:12:37 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:12:37 --> Utf8 Class Initialized
INFO - 2024-02-12 14:12:37 --> URI Class Initialized
INFO - 2024-02-12 14:12:37 --> Router Class Initialized
INFO - 2024-02-12 14:12:37 --> Output Class Initialized
INFO - 2024-02-12 14:12:37 --> Security Class Initialized
DEBUG - 2024-02-12 14:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:12:37 --> Input Class Initialized
INFO - 2024-02-12 14:12:37 --> Language Class Initialized
INFO - 2024-02-12 14:12:37 --> Loader Class Initialized
INFO - 2024-02-12 14:12:37 --> Helper loaded: url_helper
INFO - 2024-02-12 14:12:37 --> Helper loaded: file_helper
INFO - 2024-02-12 14:12:37 --> Helper loaded: html_helper
INFO - 2024-02-12 14:12:37 --> Helper loaded: text_helper
INFO - 2024-02-12 14:12:37 --> Helper loaded: form_helper
INFO - 2024-02-12 14:12:37 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:12:37 --> Helper loaded: security_helper
INFO - 2024-02-12 14:12:37 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:12:37 --> Database Driver Class Initialized
INFO - 2024-02-12 14:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:12:37 --> Parser Class Initialized
INFO - 2024-02-12 14:12:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:12:37 --> Pagination Class Initialized
INFO - 2024-02-12 14:12:37 --> Form Validation Class Initialized
INFO - 2024-02-12 14:12:37 --> Controller Class Initialized
INFO - 2024-02-12 14:12:37 --> Model Class Initialized
DEBUG - 2024-02-12 14:12:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:12:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:12:37 --> Model Class Initialized
DEBUG - 2024-02-12 14:12:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:12:37 --> Model Class Initialized
INFO - 2024-02-12 14:12:37 --> Final output sent to browser
DEBUG - 2024-02-12 14:12:37 --> Total execution time: 0.0249
ERROR - 2024-02-12 14:12:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:12:40 --> Config Class Initialized
INFO - 2024-02-12 14:12:40 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:12:40 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:12:40 --> Utf8 Class Initialized
INFO - 2024-02-12 14:12:40 --> URI Class Initialized
INFO - 2024-02-12 14:12:40 --> Router Class Initialized
INFO - 2024-02-12 14:12:40 --> Output Class Initialized
INFO - 2024-02-12 14:12:40 --> Security Class Initialized
DEBUG - 2024-02-12 14:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:12:40 --> Input Class Initialized
INFO - 2024-02-12 14:12:40 --> Language Class Initialized
INFO - 2024-02-12 14:12:40 --> Loader Class Initialized
INFO - 2024-02-12 14:12:40 --> Helper loaded: url_helper
INFO - 2024-02-12 14:12:40 --> Helper loaded: file_helper
INFO - 2024-02-12 14:12:40 --> Helper loaded: html_helper
INFO - 2024-02-12 14:12:40 --> Helper loaded: text_helper
INFO - 2024-02-12 14:12:40 --> Helper loaded: form_helper
INFO - 2024-02-12 14:12:40 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:12:40 --> Helper loaded: security_helper
INFO - 2024-02-12 14:12:40 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:12:40 --> Database Driver Class Initialized
INFO - 2024-02-12 14:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:12:40 --> Parser Class Initialized
INFO - 2024-02-12 14:12:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:12:40 --> Pagination Class Initialized
INFO - 2024-02-12 14:12:40 --> Form Validation Class Initialized
INFO - 2024-02-12 14:12:40 --> Controller Class Initialized
INFO - 2024-02-12 14:12:40 --> Model Class Initialized
DEBUG - 2024-02-12 14:12:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:12:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:12:40 --> Model Class Initialized
DEBUG - 2024-02-12 14:12:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:12:40 --> Model Class Initialized
INFO - 2024-02-12 14:12:40 --> Final output sent to browser
DEBUG - 2024-02-12 14:12:40 --> Total execution time: 0.0271
ERROR - 2024-02-12 14:12:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:12:58 --> Config Class Initialized
INFO - 2024-02-12 14:12:58 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:12:58 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:12:58 --> Utf8 Class Initialized
INFO - 2024-02-12 14:12:58 --> URI Class Initialized
INFO - 2024-02-12 14:12:58 --> Router Class Initialized
INFO - 2024-02-12 14:12:58 --> Output Class Initialized
INFO - 2024-02-12 14:12:58 --> Security Class Initialized
DEBUG - 2024-02-12 14:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:12:58 --> Input Class Initialized
INFO - 2024-02-12 14:12:58 --> Language Class Initialized
INFO - 2024-02-12 14:12:58 --> Loader Class Initialized
INFO - 2024-02-12 14:12:58 --> Helper loaded: url_helper
INFO - 2024-02-12 14:12:58 --> Helper loaded: file_helper
INFO - 2024-02-12 14:12:58 --> Helper loaded: html_helper
INFO - 2024-02-12 14:12:58 --> Helper loaded: text_helper
INFO - 2024-02-12 14:12:58 --> Helper loaded: form_helper
INFO - 2024-02-12 14:12:58 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:12:58 --> Helper loaded: security_helper
INFO - 2024-02-12 14:12:58 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:12:58 --> Database Driver Class Initialized
INFO - 2024-02-12 14:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:12:58 --> Parser Class Initialized
INFO - 2024-02-12 14:12:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:12:58 --> Pagination Class Initialized
INFO - 2024-02-12 14:12:58 --> Form Validation Class Initialized
INFO - 2024-02-12 14:12:58 --> Controller Class Initialized
INFO - 2024-02-12 14:12:58 --> Model Class Initialized
DEBUG - 2024-02-12 14:12:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:12:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:12:58 --> Model Class Initialized
DEBUG - 2024-02-12 14:12:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:12:58 --> Model Class Initialized
INFO - 2024-02-12 14:12:58 --> Final output sent to browser
DEBUG - 2024-02-12 14:12:58 --> Total execution time: 0.0272
ERROR - 2024-02-12 14:12:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:12:59 --> Config Class Initialized
INFO - 2024-02-12 14:12:59 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:12:59 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:12:59 --> Utf8 Class Initialized
INFO - 2024-02-12 14:12:59 --> URI Class Initialized
INFO - 2024-02-12 14:12:59 --> Router Class Initialized
INFO - 2024-02-12 14:12:59 --> Output Class Initialized
INFO - 2024-02-12 14:12:59 --> Security Class Initialized
DEBUG - 2024-02-12 14:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:12:59 --> Input Class Initialized
INFO - 2024-02-12 14:12:59 --> Language Class Initialized
INFO - 2024-02-12 14:12:59 --> Loader Class Initialized
INFO - 2024-02-12 14:12:59 --> Helper loaded: url_helper
INFO - 2024-02-12 14:12:59 --> Helper loaded: file_helper
INFO - 2024-02-12 14:12:59 --> Helper loaded: html_helper
INFO - 2024-02-12 14:12:59 --> Helper loaded: text_helper
INFO - 2024-02-12 14:12:59 --> Helper loaded: form_helper
INFO - 2024-02-12 14:12:59 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:12:59 --> Helper loaded: security_helper
INFO - 2024-02-12 14:12:59 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:12:59 --> Database Driver Class Initialized
INFO - 2024-02-12 14:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:12:59 --> Parser Class Initialized
INFO - 2024-02-12 14:12:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:12:59 --> Pagination Class Initialized
INFO - 2024-02-12 14:12:59 --> Form Validation Class Initialized
INFO - 2024-02-12 14:12:59 --> Controller Class Initialized
INFO - 2024-02-12 14:12:59 --> Model Class Initialized
DEBUG - 2024-02-12 14:12:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:12:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:12:59 --> Model Class Initialized
DEBUG - 2024-02-12 14:12:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:12:59 --> Model Class Initialized
INFO - 2024-02-12 14:12:59 --> Final output sent to browser
DEBUG - 2024-02-12 14:12:59 --> Total execution time: 0.0372
ERROR - 2024-02-12 14:13:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:13:10 --> Config Class Initialized
INFO - 2024-02-12 14:13:10 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:13:10 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:13:10 --> Utf8 Class Initialized
INFO - 2024-02-12 14:13:10 --> URI Class Initialized
INFO - 2024-02-12 14:13:10 --> Router Class Initialized
INFO - 2024-02-12 14:13:10 --> Output Class Initialized
INFO - 2024-02-12 14:13:10 --> Security Class Initialized
DEBUG - 2024-02-12 14:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:13:10 --> Input Class Initialized
INFO - 2024-02-12 14:13:10 --> Language Class Initialized
INFO - 2024-02-12 14:13:10 --> Loader Class Initialized
INFO - 2024-02-12 14:13:10 --> Helper loaded: url_helper
INFO - 2024-02-12 14:13:10 --> Helper loaded: file_helper
INFO - 2024-02-12 14:13:10 --> Helper loaded: html_helper
INFO - 2024-02-12 14:13:10 --> Helper loaded: text_helper
INFO - 2024-02-12 14:13:10 --> Helper loaded: form_helper
INFO - 2024-02-12 14:13:10 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:13:10 --> Helper loaded: security_helper
INFO - 2024-02-12 14:13:10 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:13:10 --> Database Driver Class Initialized
INFO - 2024-02-12 14:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:13:10 --> Parser Class Initialized
INFO - 2024-02-12 14:13:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:13:10 --> Pagination Class Initialized
INFO - 2024-02-12 14:13:10 --> Form Validation Class Initialized
INFO - 2024-02-12 14:13:10 --> Controller Class Initialized
INFO - 2024-02-12 14:13:10 --> Model Class Initialized
DEBUG - 2024-02-12 14:13:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:13:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:13:10 --> Model Class Initialized
DEBUG - 2024-02-12 14:13:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:13:10 --> Model Class Initialized
INFO - 2024-02-12 14:13:10 --> Final output sent to browser
DEBUG - 2024-02-12 14:13:10 --> Total execution time: 0.1004
ERROR - 2024-02-12 14:13:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:13:35 --> Config Class Initialized
INFO - 2024-02-12 14:13:35 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:13:35 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:13:35 --> Utf8 Class Initialized
INFO - 2024-02-12 14:13:35 --> URI Class Initialized
INFO - 2024-02-12 14:13:35 --> Router Class Initialized
INFO - 2024-02-12 14:13:35 --> Output Class Initialized
INFO - 2024-02-12 14:13:35 --> Security Class Initialized
DEBUG - 2024-02-12 14:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:13:35 --> Input Class Initialized
INFO - 2024-02-12 14:13:35 --> Language Class Initialized
INFO - 2024-02-12 14:13:35 --> Loader Class Initialized
INFO - 2024-02-12 14:13:35 --> Helper loaded: url_helper
INFO - 2024-02-12 14:13:35 --> Helper loaded: file_helper
INFO - 2024-02-12 14:13:35 --> Helper loaded: html_helper
INFO - 2024-02-12 14:13:35 --> Helper loaded: text_helper
INFO - 2024-02-12 14:13:35 --> Helper loaded: form_helper
INFO - 2024-02-12 14:13:35 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:13:35 --> Helper loaded: security_helper
INFO - 2024-02-12 14:13:35 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:13:35 --> Database Driver Class Initialized
INFO - 2024-02-12 14:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:13:35 --> Parser Class Initialized
INFO - 2024-02-12 14:13:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:13:35 --> Pagination Class Initialized
INFO - 2024-02-12 14:13:35 --> Form Validation Class Initialized
INFO - 2024-02-12 14:13:35 --> Controller Class Initialized
INFO - 2024-02-12 14:13:35 --> Model Class Initialized
DEBUG - 2024-02-12 14:13:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:13:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:13:35 --> Model Class Initialized
INFO - 2024-02-12 14:13:35 --> Final output sent to browser
DEBUG - 2024-02-12 14:13:35 --> Total execution time: 0.0198
ERROR - 2024-02-12 14:13:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:13:41 --> Config Class Initialized
INFO - 2024-02-12 14:13:41 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:13:41 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:13:41 --> Utf8 Class Initialized
INFO - 2024-02-12 14:13:41 --> URI Class Initialized
INFO - 2024-02-12 14:13:41 --> Router Class Initialized
INFO - 2024-02-12 14:13:41 --> Output Class Initialized
INFO - 2024-02-12 14:13:41 --> Security Class Initialized
DEBUG - 2024-02-12 14:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:13:41 --> Input Class Initialized
INFO - 2024-02-12 14:13:41 --> Language Class Initialized
INFO - 2024-02-12 14:13:41 --> Loader Class Initialized
INFO - 2024-02-12 14:13:41 --> Helper loaded: url_helper
INFO - 2024-02-12 14:13:41 --> Helper loaded: file_helper
INFO - 2024-02-12 14:13:41 --> Helper loaded: html_helper
INFO - 2024-02-12 14:13:41 --> Helper loaded: text_helper
INFO - 2024-02-12 14:13:41 --> Helper loaded: form_helper
INFO - 2024-02-12 14:13:41 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:13:41 --> Helper loaded: security_helper
INFO - 2024-02-12 14:13:41 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:13:41 --> Database Driver Class Initialized
INFO - 2024-02-12 14:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:13:41 --> Parser Class Initialized
INFO - 2024-02-12 14:13:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:13:41 --> Pagination Class Initialized
INFO - 2024-02-12 14:13:41 --> Form Validation Class Initialized
INFO - 2024-02-12 14:13:41 --> Controller Class Initialized
INFO - 2024-02-12 14:13:41 --> Model Class Initialized
DEBUG - 2024-02-12 14:13:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:13:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:13:41 --> Model Class Initialized
INFO - 2024-02-12 14:13:41 --> Final output sent to browser
DEBUG - 2024-02-12 14:13:41 --> Total execution time: 0.0171
ERROR - 2024-02-12 14:14:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:14:04 --> Config Class Initialized
INFO - 2024-02-12 14:14:04 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:14:04 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:14:04 --> Utf8 Class Initialized
INFO - 2024-02-12 14:14:04 --> URI Class Initialized
INFO - 2024-02-12 14:14:04 --> Router Class Initialized
INFO - 2024-02-12 14:14:04 --> Output Class Initialized
INFO - 2024-02-12 14:14:04 --> Security Class Initialized
DEBUG - 2024-02-12 14:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:14:04 --> Input Class Initialized
INFO - 2024-02-12 14:14:04 --> Language Class Initialized
INFO - 2024-02-12 14:14:04 --> Loader Class Initialized
INFO - 2024-02-12 14:14:04 --> Helper loaded: url_helper
INFO - 2024-02-12 14:14:04 --> Helper loaded: file_helper
INFO - 2024-02-12 14:14:04 --> Helper loaded: html_helper
INFO - 2024-02-12 14:14:04 --> Helper loaded: text_helper
INFO - 2024-02-12 14:14:04 --> Helper loaded: form_helper
INFO - 2024-02-12 14:14:04 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:14:04 --> Helper loaded: security_helper
INFO - 2024-02-12 14:14:04 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:14:04 --> Database Driver Class Initialized
INFO - 2024-02-12 14:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:14:04 --> Parser Class Initialized
INFO - 2024-02-12 14:14:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:14:04 --> Pagination Class Initialized
INFO - 2024-02-12 14:14:04 --> Form Validation Class Initialized
INFO - 2024-02-12 14:14:04 --> Controller Class Initialized
INFO - 2024-02-12 14:14:04 --> Model Class Initialized
DEBUG - 2024-02-12 14:14:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:14:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:14:04 --> Model Class Initialized
DEBUG - 2024-02-12 14:14:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:14:04 --> Model Class Initialized
INFO - 2024-02-12 14:14:04 --> Email Class Initialized
DEBUG - 2024-02-12 14:14:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:14:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-12 14:14:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-02-12 14:14:04 --> Language file loaded: language/english/email_lang.php
INFO - 2024-02-12 14:14:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2024-02-12 14:14:04 --> Final output sent to browser
DEBUG - 2024-02-12 14:14:04 --> Total execution time: 0.2315
ERROR - 2024-02-12 14:38:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:38:09 --> Config Class Initialized
INFO - 2024-02-12 14:38:09 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:38:09 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:38:09 --> Utf8 Class Initialized
INFO - 2024-02-12 14:38:09 --> URI Class Initialized
DEBUG - 2024-02-12 14:38:09 --> No URI present. Default controller set.
INFO - 2024-02-12 14:38:09 --> Router Class Initialized
INFO - 2024-02-12 14:38:09 --> Output Class Initialized
INFO - 2024-02-12 14:38:09 --> Security Class Initialized
DEBUG - 2024-02-12 14:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:38:09 --> Input Class Initialized
INFO - 2024-02-12 14:38:09 --> Language Class Initialized
INFO - 2024-02-12 14:38:09 --> Loader Class Initialized
INFO - 2024-02-12 14:38:09 --> Helper loaded: url_helper
INFO - 2024-02-12 14:38:09 --> Helper loaded: file_helper
INFO - 2024-02-12 14:38:09 --> Helper loaded: html_helper
INFO - 2024-02-12 14:38:09 --> Helper loaded: text_helper
INFO - 2024-02-12 14:38:09 --> Helper loaded: form_helper
INFO - 2024-02-12 14:38:09 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:38:09 --> Helper loaded: security_helper
INFO - 2024-02-12 14:38:09 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:38:09 --> Database Driver Class Initialized
INFO - 2024-02-12 14:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:38:09 --> Parser Class Initialized
INFO - 2024-02-12 14:38:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:38:09 --> Pagination Class Initialized
INFO - 2024-02-12 14:38:09 --> Form Validation Class Initialized
INFO - 2024-02-12 14:38:09 --> Controller Class Initialized
INFO - 2024-02-12 14:38:09 --> Model Class Initialized
DEBUG - 2024-02-12 14:38:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-12 14:38:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:38:09 --> Config Class Initialized
INFO - 2024-02-12 14:38:09 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:38:09 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:38:09 --> Utf8 Class Initialized
INFO - 2024-02-12 14:38:09 --> URI Class Initialized
INFO - 2024-02-12 14:38:09 --> Router Class Initialized
INFO - 2024-02-12 14:38:09 --> Output Class Initialized
INFO - 2024-02-12 14:38:09 --> Security Class Initialized
DEBUG - 2024-02-12 14:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:38:09 --> Input Class Initialized
INFO - 2024-02-12 14:38:09 --> Language Class Initialized
INFO - 2024-02-12 14:38:09 --> Loader Class Initialized
INFO - 2024-02-12 14:38:09 --> Helper loaded: url_helper
INFO - 2024-02-12 14:38:09 --> Helper loaded: file_helper
INFO - 2024-02-12 14:38:09 --> Helper loaded: html_helper
INFO - 2024-02-12 14:38:09 --> Helper loaded: text_helper
INFO - 2024-02-12 14:38:09 --> Helper loaded: form_helper
INFO - 2024-02-12 14:38:09 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:38:09 --> Helper loaded: security_helper
INFO - 2024-02-12 14:38:09 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:38:09 --> Database Driver Class Initialized
INFO - 2024-02-12 14:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:38:09 --> Parser Class Initialized
INFO - 2024-02-12 14:38:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:38:09 --> Pagination Class Initialized
INFO - 2024-02-12 14:38:09 --> Form Validation Class Initialized
INFO - 2024-02-12 14:38:09 --> Controller Class Initialized
INFO - 2024-02-12 14:38:09 --> Model Class Initialized
DEBUG - 2024-02-12 14:38:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:38:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-12 14:38:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:38:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 14:38:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 14:38:09 --> Model Class Initialized
INFO - 2024-02-12 14:38:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 14:38:09 --> Final output sent to browser
DEBUG - 2024-02-12 14:38:09 --> Total execution time: 0.0365
ERROR - 2024-02-12 14:45:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:45:55 --> Config Class Initialized
INFO - 2024-02-12 14:45:55 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:45:55 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:45:55 --> Utf8 Class Initialized
INFO - 2024-02-12 14:45:55 --> URI Class Initialized
DEBUG - 2024-02-12 14:45:55 --> No URI present. Default controller set.
INFO - 2024-02-12 14:45:55 --> Router Class Initialized
INFO - 2024-02-12 14:45:55 --> Output Class Initialized
INFO - 2024-02-12 14:45:55 --> Security Class Initialized
DEBUG - 2024-02-12 14:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:45:55 --> Input Class Initialized
INFO - 2024-02-12 14:45:55 --> Language Class Initialized
INFO - 2024-02-12 14:45:55 --> Loader Class Initialized
INFO - 2024-02-12 14:45:55 --> Helper loaded: url_helper
INFO - 2024-02-12 14:45:55 --> Helper loaded: file_helper
INFO - 2024-02-12 14:45:55 --> Helper loaded: html_helper
INFO - 2024-02-12 14:45:55 --> Helper loaded: text_helper
INFO - 2024-02-12 14:45:55 --> Helper loaded: form_helper
INFO - 2024-02-12 14:45:55 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:45:55 --> Helper loaded: security_helper
INFO - 2024-02-12 14:45:55 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:45:55 --> Database Driver Class Initialized
INFO - 2024-02-12 14:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:45:55 --> Parser Class Initialized
INFO - 2024-02-12 14:45:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:45:55 --> Pagination Class Initialized
INFO - 2024-02-12 14:45:55 --> Form Validation Class Initialized
INFO - 2024-02-12 14:45:55 --> Controller Class Initialized
INFO - 2024-02-12 14:45:55 --> Model Class Initialized
DEBUG - 2024-02-12 14:45:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:45:55 --> Model Class Initialized
DEBUG - 2024-02-12 14:45:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:45:55 --> Model Class Initialized
INFO - 2024-02-12 14:45:55 --> Model Class Initialized
INFO - 2024-02-12 14:45:55 --> Model Class Initialized
INFO - 2024-02-12 14:45:55 --> Model Class Initialized
DEBUG - 2024-02-12 14:45:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:45:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:45:55 --> Model Class Initialized
INFO - 2024-02-12 14:45:55 --> Model Class Initialized
INFO - 2024-02-12 14:45:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-12 14:45:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:45:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 14:45:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 14:45:55 --> Model Class Initialized
INFO - 2024-02-12 14:45:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 14:45:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 14:45:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 14:45:55 --> Final output sent to browser
DEBUG - 2024-02-12 14:45:55 --> Total execution time: 0.2531
ERROR - 2024-02-12 14:46:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:46:07 --> Config Class Initialized
INFO - 2024-02-12 14:46:07 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:46:07 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:46:07 --> Utf8 Class Initialized
INFO - 2024-02-12 14:46:07 --> URI Class Initialized
INFO - 2024-02-12 14:46:07 --> Router Class Initialized
INFO - 2024-02-12 14:46:07 --> Output Class Initialized
INFO - 2024-02-12 14:46:07 --> Security Class Initialized
DEBUG - 2024-02-12 14:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:46:07 --> Input Class Initialized
INFO - 2024-02-12 14:46:07 --> Language Class Initialized
INFO - 2024-02-12 14:46:07 --> Loader Class Initialized
INFO - 2024-02-12 14:46:07 --> Helper loaded: url_helper
INFO - 2024-02-12 14:46:07 --> Helper loaded: file_helper
INFO - 2024-02-12 14:46:07 --> Helper loaded: html_helper
INFO - 2024-02-12 14:46:07 --> Helper loaded: text_helper
INFO - 2024-02-12 14:46:07 --> Helper loaded: form_helper
INFO - 2024-02-12 14:46:07 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:46:07 --> Helper loaded: security_helper
INFO - 2024-02-12 14:46:07 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:46:07 --> Database Driver Class Initialized
INFO - 2024-02-12 14:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:46:07 --> Parser Class Initialized
INFO - 2024-02-12 14:46:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:46:07 --> Pagination Class Initialized
INFO - 2024-02-12 14:46:07 --> Form Validation Class Initialized
INFO - 2024-02-12 14:46:07 --> Controller Class Initialized
DEBUG - 2024-02-12 14:46:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:46:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:46:07 --> Model Class Initialized
DEBUG - 2024-02-12 14:46:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:46:07 --> Model Class Initialized
DEBUG - 2024-02-12 14:46:07 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:46:07 --> Model Class Initialized
INFO - 2024-02-12 14:46:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-12 14:46:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:46:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 14:46:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 14:46:07 --> Model Class Initialized
INFO - 2024-02-12 14:46:07 --> Model Class Initialized
INFO - 2024-02-12 14:46:07 --> Model Class Initialized
INFO - 2024-02-12 14:46:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 14:46:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 14:46:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 14:46:07 --> Final output sent to browser
DEBUG - 2024-02-12 14:46:07 --> Total execution time: 0.1660
ERROR - 2024-02-12 14:46:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:46:08 --> Config Class Initialized
INFO - 2024-02-12 14:46:08 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:46:08 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:46:08 --> Utf8 Class Initialized
INFO - 2024-02-12 14:46:08 --> URI Class Initialized
INFO - 2024-02-12 14:46:08 --> Router Class Initialized
INFO - 2024-02-12 14:46:08 --> Output Class Initialized
INFO - 2024-02-12 14:46:08 --> Security Class Initialized
DEBUG - 2024-02-12 14:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:46:08 --> Input Class Initialized
INFO - 2024-02-12 14:46:08 --> Language Class Initialized
INFO - 2024-02-12 14:46:08 --> Loader Class Initialized
INFO - 2024-02-12 14:46:08 --> Helper loaded: url_helper
INFO - 2024-02-12 14:46:08 --> Helper loaded: file_helper
INFO - 2024-02-12 14:46:08 --> Helper loaded: html_helper
INFO - 2024-02-12 14:46:08 --> Helper loaded: text_helper
INFO - 2024-02-12 14:46:08 --> Helper loaded: form_helper
INFO - 2024-02-12 14:46:08 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:46:08 --> Helper loaded: security_helper
INFO - 2024-02-12 14:46:08 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:46:08 --> Database Driver Class Initialized
INFO - 2024-02-12 14:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:46:08 --> Parser Class Initialized
INFO - 2024-02-12 14:46:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:46:08 --> Pagination Class Initialized
INFO - 2024-02-12 14:46:08 --> Form Validation Class Initialized
INFO - 2024-02-12 14:46:08 --> Controller Class Initialized
DEBUG - 2024-02-12 14:46:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:46:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:46:08 --> Model Class Initialized
DEBUG - 2024-02-12 14:46:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:46:08 --> Model Class Initialized
INFO - 2024-02-12 14:46:08 --> Final output sent to browser
DEBUG - 2024-02-12 14:46:08 --> Total execution time: 0.0227
ERROR - 2024-02-12 14:46:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:46:15 --> Config Class Initialized
INFO - 2024-02-12 14:46:15 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:46:15 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:46:15 --> Utf8 Class Initialized
INFO - 2024-02-12 14:46:15 --> URI Class Initialized
INFO - 2024-02-12 14:46:15 --> Router Class Initialized
INFO - 2024-02-12 14:46:15 --> Output Class Initialized
INFO - 2024-02-12 14:46:15 --> Security Class Initialized
DEBUG - 2024-02-12 14:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:46:15 --> Input Class Initialized
INFO - 2024-02-12 14:46:15 --> Language Class Initialized
INFO - 2024-02-12 14:46:15 --> Loader Class Initialized
INFO - 2024-02-12 14:46:15 --> Helper loaded: url_helper
INFO - 2024-02-12 14:46:15 --> Helper loaded: file_helper
INFO - 2024-02-12 14:46:15 --> Helper loaded: html_helper
INFO - 2024-02-12 14:46:15 --> Helper loaded: text_helper
INFO - 2024-02-12 14:46:15 --> Helper loaded: form_helper
INFO - 2024-02-12 14:46:15 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:46:15 --> Helper loaded: security_helper
INFO - 2024-02-12 14:46:15 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:46:15 --> Database Driver Class Initialized
INFO - 2024-02-12 14:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:46:15 --> Parser Class Initialized
INFO - 2024-02-12 14:46:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:46:15 --> Pagination Class Initialized
INFO - 2024-02-12 14:46:15 --> Form Validation Class Initialized
INFO - 2024-02-12 14:46:15 --> Controller Class Initialized
DEBUG - 2024-02-12 14:46:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:46:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:46:15 --> Model Class Initialized
DEBUG - 2024-02-12 14:46:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:46:15 --> Model Class Initialized
INFO - 2024-02-12 14:46:15 --> Final output sent to browser
DEBUG - 2024-02-12 14:46:15 --> Total execution time: 0.0339
ERROR - 2024-02-12 14:48:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:48:25 --> Config Class Initialized
INFO - 2024-02-12 14:48:25 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:48:25 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:48:25 --> Utf8 Class Initialized
INFO - 2024-02-12 14:48:25 --> URI Class Initialized
DEBUG - 2024-02-12 14:48:25 --> No URI present. Default controller set.
INFO - 2024-02-12 14:48:25 --> Router Class Initialized
INFO - 2024-02-12 14:48:25 --> Output Class Initialized
INFO - 2024-02-12 14:48:25 --> Security Class Initialized
DEBUG - 2024-02-12 14:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:48:25 --> Input Class Initialized
INFO - 2024-02-12 14:48:25 --> Language Class Initialized
INFO - 2024-02-12 14:48:25 --> Loader Class Initialized
INFO - 2024-02-12 14:48:25 --> Helper loaded: url_helper
INFO - 2024-02-12 14:48:25 --> Helper loaded: file_helper
INFO - 2024-02-12 14:48:25 --> Helper loaded: html_helper
INFO - 2024-02-12 14:48:25 --> Helper loaded: text_helper
INFO - 2024-02-12 14:48:25 --> Helper loaded: form_helper
INFO - 2024-02-12 14:48:25 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:48:25 --> Helper loaded: security_helper
INFO - 2024-02-12 14:48:25 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:48:25 --> Database Driver Class Initialized
INFO - 2024-02-12 14:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:48:25 --> Parser Class Initialized
INFO - 2024-02-12 14:48:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:48:25 --> Pagination Class Initialized
INFO - 2024-02-12 14:48:25 --> Form Validation Class Initialized
INFO - 2024-02-12 14:48:25 --> Controller Class Initialized
INFO - 2024-02-12 14:48:25 --> Model Class Initialized
DEBUG - 2024-02-12 14:48:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:48:25 --> Model Class Initialized
DEBUG - 2024-02-12 14:48:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:48:25 --> Model Class Initialized
INFO - 2024-02-12 14:48:25 --> Model Class Initialized
INFO - 2024-02-12 14:48:25 --> Model Class Initialized
INFO - 2024-02-12 14:48:25 --> Model Class Initialized
DEBUG - 2024-02-12 14:48:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:48:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:48:25 --> Model Class Initialized
INFO - 2024-02-12 14:48:25 --> Model Class Initialized
INFO - 2024-02-12 14:48:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-12 14:48:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:48:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 14:48:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 14:48:25 --> Model Class Initialized
INFO - 2024-02-12 14:48:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 14:48:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 14:48:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 14:48:25 --> Final output sent to browser
DEBUG - 2024-02-12 14:48:25 --> Total execution time: 0.2629
ERROR - 2024-02-12 14:48:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:48:33 --> Config Class Initialized
INFO - 2024-02-12 14:48:33 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:48:33 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:48:33 --> Utf8 Class Initialized
INFO - 2024-02-12 14:48:33 --> URI Class Initialized
INFO - 2024-02-12 14:48:33 --> Router Class Initialized
INFO - 2024-02-12 14:48:33 --> Output Class Initialized
INFO - 2024-02-12 14:48:33 --> Security Class Initialized
DEBUG - 2024-02-12 14:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:48:33 --> Input Class Initialized
INFO - 2024-02-12 14:48:33 --> Language Class Initialized
INFO - 2024-02-12 14:48:33 --> Loader Class Initialized
INFO - 2024-02-12 14:48:33 --> Helper loaded: url_helper
INFO - 2024-02-12 14:48:33 --> Helper loaded: file_helper
INFO - 2024-02-12 14:48:33 --> Helper loaded: html_helper
INFO - 2024-02-12 14:48:33 --> Helper loaded: text_helper
INFO - 2024-02-12 14:48:33 --> Helper loaded: form_helper
INFO - 2024-02-12 14:48:33 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:48:33 --> Helper loaded: security_helper
INFO - 2024-02-12 14:48:33 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:48:33 --> Database Driver Class Initialized
INFO - 2024-02-12 14:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:48:33 --> Parser Class Initialized
INFO - 2024-02-12 14:48:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:48:33 --> Pagination Class Initialized
INFO - 2024-02-12 14:48:33 --> Form Validation Class Initialized
INFO - 2024-02-12 14:48:33 --> Controller Class Initialized
INFO - 2024-02-12 14:48:33 --> Model Class Initialized
DEBUG - 2024-02-12 14:48:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:48:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:48:33 --> Model Class Initialized
DEBUG - 2024-02-12 14:48:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:48:33 --> Model Class Initialized
INFO - 2024-02-12 14:48:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-02-12 14:48:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:48:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 14:48:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 14:48:33 --> Model Class Initialized
INFO - 2024-02-12 14:48:33 --> Model Class Initialized
INFO - 2024-02-12 14:48:33 --> Model Class Initialized
INFO - 2024-02-12 14:48:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 14:48:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 14:48:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 14:48:33 --> Final output sent to browser
DEBUG - 2024-02-12 14:48:33 --> Total execution time: 0.1940
ERROR - 2024-02-12 14:48:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:48:36 --> Config Class Initialized
INFO - 2024-02-12 14:48:36 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:48:36 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:48:36 --> Utf8 Class Initialized
INFO - 2024-02-12 14:48:36 --> URI Class Initialized
DEBUG - 2024-02-12 14:48:36 --> No URI present. Default controller set.
INFO - 2024-02-12 14:48:36 --> Router Class Initialized
INFO - 2024-02-12 14:48:36 --> Output Class Initialized
INFO - 2024-02-12 14:48:36 --> Security Class Initialized
DEBUG - 2024-02-12 14:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:48:36 --> Input Class Initialized
INFO - 2024-02-12 14:48:36 --> Language Class Initialized
INFO - 2024-02-12 14:48:36 --> Loader Class Initialized
INFO - 2024-02-12 14:48:36 --> Helper loaded: url_helper
INFO - 2024-02-12 14:48:36 --> Helper loaded: file_helper
INFO - 2024-02-12 14:48:36 --> Helper loaded: html_helper
INFO - 2024-02-12 14:48:36 --> Helper loaded: text_helper
INFO - 2024-02-12 14:48:36 --> Helper loaded: form_helper
INFO - 2024-02-12 14:48:36 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:48:36 --> Helper loaded: security_helper
INFO - 2024-02-12 14:48:36 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:48:36 --> Database Driver Class Initialized
INFO - 2024-02-12 14:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:48:36 --> Parser Class Initialized
INFO - 2024-02-12 14:48:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:48:36 --> Pagination Class Initialized
INFO - 2024-02-12 14:48:36 --> Form Validation Class Initialized
INFO - 2024-02-12 14:48:36 --> Controller Class Initialized
INFO - 2024-02-12 14:48:36 --> Model Class Initialized
DEBUG - 2024-02-12 14:48:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:48:36 --> Model Class Initialized
DEBUG - 2024-02-12 14:48:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:48:36 --> Model Class Initialized
INFO - 2024-02-12 14:48:36 --> Model Class Initialized
INFO - 2024-02-12 14:48:36 --> Model Class Initialized
INFO - 2024-02-12 14:48:36 --> Model Class Initialized
DEBUG - 2024-02-12 14:48:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:48:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:48:36 --> Model Class Initialized
INFO - 2024-02-12 14:48:36 --> Model Class Initialized
INFO - 2024-02-12 14:48:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-12 14:48:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:48:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 14:48:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 14:48:36 --> Model Class Initialized
INFO - 2024-02-12 14:48:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 14:48:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 14:48:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 14:48:36 --> Final output sent to browser
DEBUG - 2024-02-12 14:48:36 --> Total execution time: 0.2352
ERROR - 2024-02-12 14:48:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:48:44 --> Config Class Initialized
INFO - 2024-02-12 14:48:44 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:48:44 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:48:44 --> Utf8 Class Initialized
INFO - 2024-02-12 14:48:44 --> URI Class Initialized
INFO - 2024-02-12 14:48:44 --> Router Class Initialized
INFO - 2024-02-12 14:48:44 --> Output Class Initialized
INFO - 2024-02-12 14:48:44 --> Security Class Initialized
DEBUG - 2024-02-12 14:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:48:44 --> Input Class Initialized
INFO - 2024-02-12 14:48:44 --> Language Class Initialized
INFO - 2024-02-12 14:48:44 --> Loader Class Initialized
INFO - 2024-02-12 14:48:44 --> Helper loaded: url_helper
INFO - 2024-02-12 14:48:44 --> Helper loaded: file_helper
INFO - 2024-02-12 14:48:44 --> Helper loaded: html_helper
INFO - 2024-02-12 14:48:44 --> Helper loaded: text_helper
INFO - 2024-02-12 14:48:44 --> Helper loaded: form_helper
INFO - 2024-02-12 14:48:44 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:48:44 --> Helper loaded: security_helper
INFO - 2024-02-12 14:48:44 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:48:44 --> Database Driver Class Initialized
INFO - 2024-02-12 14:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:48:44 --> Parser Class Initialized
INFO - 2024-02-12 14:48:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:48:44 --> Pagination Class Initialized
INFO - 2024-02-12 14:48:44 --> Form Validation Class Initialized
INFO - 2024-02-12 14:48:44 --> Controller Class Initialized
INFO - 2024-02-12 14:48:44 --> Model Class Initialized
DEBUG - 2024-02-12 14:48:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:48:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:48:44 --> Model Class Initialized
DEBUG - 2024-02-12 14:48:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:48:44 --> Model Class Initialized
INFO - 2024-02-12 14:48:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-12 14:48:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:48:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 14:48:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 14:48:44 --> Model Class Initialized
INFO - 2024-02-12 14:48:44 --> Model Class Initialized
INFO - 2024-02-12 14:48:44 --> Model Class Initialized
INFO - 2024-02-12 14:48:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 14:48:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 14:48:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 14:48:44 --> Final output sent to browser
DEBUG - 2024-02-12 14:48:44 --> Total execution time: 0.1523
ERROR - 2024-02-12 14:48:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:48:44 --> Config Class Initialized
INFO - 2024-02-12 14:48:44 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:48:44 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:48:44 --> Utf8 Class Initialized
INFO - 2024-02-12 14:48:44 --> URI Class Initialized
INFO - 2024-02-12 14:48:44 --> Router Class Initialized
INFO - 2024-02-12 14:48:44 --> Output Class Initialized
INFO - 2024-02-12 14:48:44 --> Security Class Initialized
DEBUG - 2024-02-12 14:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:48:44 --> Input Class Initialized
INFO - 2024-02-12 14:48:44 --> Language Class Initialized
INFO - 2024-02-12 14:48:44 --> Loader Class Initialized
INFO - 2024-02-12 14:48:44 --> Helper loaded: url_helper
INFO - 2024-02-12 14:48:44 --> Helper loaded: file_helper
INFO - 2024-02-12 14:48:44 --> Helper loaded: html_helper
INFO - 2024-02-12 14:48:44 --> Helper loaded: text_helper
INFO - 2024-02-12 14:48:44 --> Helper loaded: form_helper
INFO - 2024-02-12 14:48:44 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:48:44 --> Helper loaded: security_helper
INFO - 2024-02-12 14:48:44 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:48:44 --> Database Driver Class Initialized
INFO - 2024-02-12 14:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:48:44 --> Parser Class Initialized
INFO - 2024-02-12 14:48:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:48:44 --> Pagination Class Initialized
INFO - 2024-02-12 14:48:44 --> Form Validation Class Initialized
INFO - 2024-02-12 14:48:44 --> Controller Class Initialized
INFO - 2024-02-12 14:48:44 --> Model Class Initialized
DEBUG - 2024-02-12 14:48:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:48:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:48:44 --> Model Class Initialized
DEBUG - 2024-02-12 14:48:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:48:44 --> Model Class Initialized
INFO - 2024-02-12 14:48:44 --> Final output sent to browser
DEBUG - 2024-02-12 14:48:44 --> Total execution time: 0.0427
ERROR - 2024-02-12 14:48:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:48:49 --> Config Class Initialized
INFO - 2024-02-12 14:48:49 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:48:49 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:48:49 --> Utf8 Class Initialized
INFO - 2024-02-12 14:48:49 --> URI Class Initialized
DEBUG - 2024-02-12 14:48:49 --> No URI present. Default controller set.
INFO - 2024-02-12 14:48:49 --> Router Class Initialized
INFO - 2024-02-12 14:48:49 --> Output Class Initialized
INFO - 2024-02-12 14:48:49 --> Security Class Initialized
DEBUG - 2024-02-12 14:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:48:49 --> Input Class Initialized
INFO - 2024-02-12 14:48:49 --> Language Class Initialized
INFO - 2024-02-12 14:48:49 --> Loader Class Initialized
INFO - 2024-02-12 14:48:49 --> Helper loaded: url_helper
INFO - 2024-02-12 14:48:49 --> Helper loaded: file_helper
INFO - 2024-02-12 14:48:49 --> Helper loaded: html_helper
INFO - 2024-02-12 14:48:49 --> Helper loaded: text_helper
INFO - 2024-02-12 14:48:49 --> Helper loaded: form_helper
INFO - 2024-02-12 14:48:49 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:48:49 --> Helper loaded: security_helper
INFO - 2024-02-12 14:48:49 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:48:49 --> Database Driver Class Initialized
INFO - 2024-02-12 14:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:48:49 --> Parser Class Initialized
INFO - 2024-02-12 14:48:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:48:49 --> Pagination Class Initialized
INFO - 2024-02-12 14:48:49 --> Form Validation Class Initialized
INFO - 2024-02-12 14:48:49 --> Controller Class Initialized
INFO - 2024-02-12 14:48:49 --> Model Class Initialized
DEBUG - 2024-02-12 14:48:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:48:49 --> Model Class Initialized
DEBUG - 2024-02-12 14:48:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:48:49 --> Model Class Initialized
INFO - 2024-02-12 14:48:49 --> Model Class Initialized
INFO - 2024-02-12 14:48:49 --> Model Class Initialized
INFO - 2024-02-12 14:48:49 --> Model Class Initialized
DEBUG - 2024-02-12 14:48:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:48:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:48:49 --> Model Class Initialized
INFO - 2024-02-12 14:48:49 --> Model Class Initialized
INFO - 2024-02-12 14:48:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-12 14:48:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:48:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 14:48:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 14:48:49 --> Model Class Initialized
INFO - 2024-02-12 14:48:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 14:48:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 14:48:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 14:48:49 --> Final output sent to browser
DEBUG - 2024-02-12 14:48:49 --> Total execution time: 0.2384
ERROR - 2024-02-12 14:48:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:48:54 --> Config Class Initialized
INFO - 2024-02-12 14:48:54 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:48:54 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:48:54 --> Utf8 Class Initialized
INFO - 2024-02-12 14:48:54 --> URI Class Initialized
INFO - 2024-02-12 14:48:54 --> Router Class Initialized
INFO - 2024-02-12 14:48:54 --> Output Class Initialized
INFO - 2024-02-12 14:48:54 --> Security Class Initialized
DEBUG - 2024-02-12 14:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:48:54 --> Input Class Initialized
INFO - 2024-02-12 14:48:54 --> Language Class Initialized
INFO - 2024-02-12 14:48:54 --> Loader Class Initialized
INFO - 2024-02-12 14:48:54 --> Helper loaded: url_helper
INFO - 2024-02-12 14:48:54 --> Helper loaded: file_helper
INFO - 2024-02-12 14:48:54 --> Helper loaded: html_helper
INFO - 2024-02-12 14:48:54 --> Helper loaded: text_helper
INFO - 2024-02-12 14:48:54 --> Helper loaded: form_helper
INFO - 2024-02-12 14:48:54 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:48:54 --> Helper loaded: security_helper
INFO - 2024-02-12 14:48:54 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:48:54 --> Database Driver Class Initialized
INFO - 2024-02-12 14:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:48:54 --> Parser Class Initialized
INFO - 2024-02-12 14:48:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:48:54 --> Pagination Class Initialized
INFO - 2024-02-12 14:48:54 --> Form Validation Class Initialized
INFO - 2024-02-12 14:48:54 --> Controller Class Initialized
INFO - 2024-02-12 14:48:54 --> Model Class Initialized
DEBUG - 2024-02-12 14:48:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:48:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:48:54 --> Model Class Initialized
DEBUG - 2024-02-12 14:48:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:48:54 --> Model Class Initialized
INFO - 2024-02-12 14:48:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-12 14:48:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:48:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 14:48:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 14:48:54 --> Model Class Initialized
INFO - 2024-02-12 14:48:54 --> Model Class Initialized
INFO - 2024-02-12 14:48:54 --> Model Class Initialized
INFO - 2024-02-12 14:48:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 14:48:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 14:48:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 14:48:54 --> Final output sent to browser
DEBUG - 2024-02-12 14:48:54 --> Total execution time: 0.1619
ERROR - 2024-02-12 14:48:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:48:55 --> Config Class Initialized
INFO - 2024-02-12 14:48:55 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:48:55 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:48:55 --> Utf8 Class Initialized
INFO - 2024-02-12 14:48:55 --> URI Class Initialized
INFO - 2024-02-12 14:48:55 --> Router Class Initialized
INFO - 2024-02-12 14:48:55 --> Output Class Initialized
INFO - 2024-02-12 14:48:55 --> Security Class Initialized
DEBUG - 2024-02-12 14:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:48:55 --> Input Class Initialized
INFO - 2024-02-12 14:48:55 --> Language Class Initialized
INFO - 2024-02-12 14:48:55 --> Loader Class Initialized
INFO - 2024-02-12 14:48:55 --> Helper loaded: url_helper
INFO - 2024-02-12 14:48:55 --> Helper loaded: file_helper
INFO - 2024-02-12 14:48:55 --> Helper loaded: html_helper
INFO - 2024-02-12 14:48:55 --> Helper loaded: text_helper
INFO - 2024-02-12 14:48:55 --> Helper loaded: form_helper
INFO - 2024-02-12 14:48:55 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:48:55 --> Helper loaded: security_helper
INFO - 2024-02-12 14:48:55 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:48:55 --> Database Driver Class Initialized
INFO - 2024-02-12 14:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:48:55 --> Parser Class Initialized
INFO - 2024-02-12 14:48:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:48:55 --> Pagination Class Initialized
INFO - 2024-02-12 14:48:55 --> Form Validation Class Initialized
INFO - 2024-02-12 14:48:55 --> Controller Class Initialized
INFO - 2024-02-12 14:48:55 --> Model Class Initialized
DEBUG - 2024-02-12 14:48:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:48:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:48:55 --> Model Class Initialized
DEBUG - 2024-02-12 14:48:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:48:55 --> Model Class Initialized
INFO - 2024-02-12 14:48:55 --> Final output sent to browser
DEBUG - 2024-02-12 14:48:55 --> Total execution time: 0.0406
ERROR - 2024-02-12 14:49:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 14:49:53 --> Config Class Initialized
INFO - 2024-02-12 14:49:53 --> Hooks Class Initialized
DEBUG - 2024-02-12 14:49:53 --> UTF-8 Support Enabled
INFO - 2024-02-12 14:49:53 --> Utf8 Class Initialized
INFO - 2024-02-12 14:49:53 --> URI Class Initialized
DEBUG - 2024-02-12 14:49:53 --> No URI present. Default controller set.
INFO - 2024-02-12 14:49:53 --> Router Class Initialized
INFO - 2024-02-12 14:49:53 --> Output Class Initialized
INFO - 2024-02-12 14:49:53 --> Security Class Initialized
DEBUG - 2024-02-12 14:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 14:49:53 --> Input Class Initialized
INFO - 2024-02-12 14:49:53 --> Language Class Initialized
INFO - 2024-02-12 14:49:53 --> Loader Class Initialized
INFO - 2024-02-12 14:49:53 --> Helper loaded: url_helper
INFO - 2024-02-12 14:49:53 --> Helper loaded: file_helper
INFO - 2024-02-12 14:49:53 --> Helper loaded: html_helper
INFO - 2024-02-12 14:49:53 --> Helper loaded: text_helper
INFO - 2024-02-12 14:49:53 --> Helper loaded: form_helper
INFO - 2024-02-12 14:49:53 --> Helper loaded: lang_helper
INFO - 2024-02-12 14:49:53 --> Helper loaded: security_helper
INFO - 2024-02-12 14:49:53 --> Helper loaded: cookie_helper
INFO - 2024-02-12 14:49:53 --> Database Driver Class Initialized
INFO - 2024-02-12 14:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-12 14:49:53 --> Parser Class Initialized
INFO - 2024-02-12 14:49:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-12 14:49:53 --> Pagination Class Initialized
INFO - 2024-02-12 14:49:53 --> Form Validation Class Initialized
INFO - 2024-02-12 14:49:53 --> Controller Class Initialized
INFO - 2024-02-12 14:49:53 --> Model Class Initialized
DEBUG - 2024-02-12 14:49:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:49:53 --> Model Class Initialized
DEBUG - 2024-02-12 14:49:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:49:53 --> Model Class Initialized
INFO - 2024-02-12 14:49:53 --> Model Class Initialized
INFO - 2024-02-12 14:49:53 --> Model Class Initialized
INFO - 2024-02-12 14:49:53 --> Model Class Initialized
DEBUG - 2024-02-12 14:49:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-12 14:49:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:49:53 --> Model Class Initialized
INFO - 2024-02-12 14:49:53 --> Model Class Initialized
INFO - 2024-02-12 14:49:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-12 14:49:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-12 14:49:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-12 14:49:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-12 14:49:53 --> Model Class Initialized
INFO - 2024-02-12 14:49:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-12 14:49:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-12 14:49:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-12 14:49:53 --> Final output sent to browser
DEBUG - 2024-02-12 14:49:53 --> Total execution time: 0.2370
ERROR - 2024-02-12 23:09:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-12 23:09:44 --> Config Class Initialized
INFO - 2024-02-12 23:09:44 --> Hooks Class Initialized
DEBUG - 2024-02-12 23:09:44 --> UTF-8 Support Enabled
INFO - 2024-02-12 23:09:44 --> Utf8 Class Initialized
INFO - 2024-02-12 23:09:44 --> URI Class Initialized
INFO - 2024-02-12 23:09:44 --> Router Class Initialized
INFO - 2024-02-12 23:09:44 --> Output Class Initialized
INFO - 2024-02-12 23:09:44 --> Security Class Initialized
DEBUG - 2024-02-12 23:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-12 23:09:44 --> Input Class Initialized
INFO - 2024-02-12 23:09:44 --> Language Class Initialized
ERROR - 2024-02-12 23:09:44 --> 404 Page Not Found: Well-known/assetlinks.json
