<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-29 02:15:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 02:15:24 --> Config Class Initialized
INFO - 2023-07-29 02:15:24 --> Hooks Class Initialized
DEBUG - 2023-07-29 02:15:24 --> UTF-8 Support Enabled
INFO - 2023-07-29 02:15:24 --> Utf8 Class Initialized
INFO - 2023-07-29 02:15:24 --> URI Class Initialized
DEBUG - 2023-07-29 02:15:24 --> No URI present. Default controller set.
INFO - 2023-07-29 02:15:24 --> Router Class Initialized
INFO - 2023-07-29 02:15:24 --> Output Class Initialized
INFO - 2023-07-29 02:15:24 --> Security Class Initialized
DEBUG - 2023-07-29 02:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 02:15:24 --> Input Class Initialized
INFO - 2023-07-29 02:15:24 --> Language Class Initialized
INFO - 2023-07-29 02:15:24 --> Loader Class Initialized
INFO - 2023-07-29 02:15:24 --> Helper loaded: url_helper
INFO - 2023-07-29 02:15:24 --> Helper loaded: file_helper
INFO - 2023-07-29 02:15:24 --> Helper loaded: html_helper
INFO - 2023-07-29 02:15:24 --> Helper loaded: text_helper
INFO - 2023-07-29 02:15:24 --> Helper loaded: form_helper
INFO - 2023-07-29 02:15:24 --> Helper loaded: lang_helper
INFO - 2023-07-29 02:15:24 --> Helper loaded: security_helper
INFO - 2023-07-29 02:15:24 --> Helper loaded: cookie_helper
INFO - 2023-07-29 02:15:24 --> Database Driver Class Initialized
INFO - 2023-07-29 02:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 02:15:24 --> Parser Class Initialized
INFO - 2023-07-29 02:15:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 02:15:24 --> Pagination Class Initialized
INFO - 2023-07-29 02:15:24 --> Form Validation Class Initialized
INFO - 2023-07-29 02:15:24 --> Controller Class Initialized
INFO - 2023-07-29 02:15:24 --> Model Class Initialized
DEBUG - 2023-07-29 02:15:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-29 02:15:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 02:15:24 --> Config Class Initialized
INFO - 2023-07-29 02:15:24 --> Hooks Class Initialized
DEBUG - 2023-07-29 02:15:24 --> UTF-8 Support Enabled
INFO - 2023-07-29 02:15:24 --> Utf8 Class Initialized
INFO - 2023-07-29 02:15:24 --> URI Class Initialized
INFO - 2023-07-29 02:15:24 --> Router Class Initialized
INFO - 2023-07-29 02:15:24 --> Output Class Initialized
INFO - 2023-07-29 02:15:24 --> Security Class Initialized
DEBUG - 2023-07-29 02:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 02:15:24 --> Input Class Initialized
INFO - 2023-07-29 02:15:24 --> Language Class Initialized
INFO - 2023-07-29 02:15:24 --> Loader Class Initialized
INFO - 2023-07-29 02:15:24 --> Helper loaded: url_helper
INFO - 2023-07-29 02:15:24 --> Helper loaded: file_helper
INFO - 2023-07-29 02:15:24 --> Helper loaded: html_helper
INFO - 2023-07-29 02:15:24 --> Helper loaded: text_helper
INFO - 2023-07-29 02:15:24 --> Helper loaded: form_helper
INFO - 2023-07-29 02:15:24 --> Helper loaded: lang_helper
INFO - 2023-07-29 02:15:24 --> Helper loaded: security_helper
INFO - 2023-07-29 02:15:24 --> Helper loaded: cookie_helper
INFO - 2023-07-29 02:15:24 --> Database Driver Class Initialized
INFO - 2023-07-29 02:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 02:15:24 --> Parser Class Initialized
INFO - 2023-07-29 02:15:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 02:15:24 --> Pagination Class Initialized
INFO - 2023-07-29 02:15:24 --> Form Validation Class Initialized
INFO - 2023-07-29 02:15:24 --> Controller Class Initialized
INFO - 2023-07-29 02:15:24 --> Model Class Initialized
DEBUG - 2023-07-29 02:15:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 02:15:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-29 02:15:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-29 02:15:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-29 02:15:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-29 02:15:24 --> Model Class Initialized
INFO - 2023-07-29 02:15:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-29 02:15:24 --> Final output sent to browser
DEBUG - 2023-07-29 02:15:24 --> Total execution time: 0.0346
ERROR - 2023-07-29 02:15:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 02:15:33 --> Config Class Initialized
INFO - 2023-07-29 02:15:33 --> Hooks Class Initialized
DEBUG - 2023-07-29 02:15:33 --> UTF-8 Support Enabled
INFO - 2023-07-29 02:15:33 --> Utf8 Class Initialized
INFO - 2023-07-29 02:15:33 --> URI Class Initialized
INFO - 2023-07-29 02:15:33 --> Router Class Initialized
INFO - 2023-07-29 02:15:33 --> Output Class Initialized
INFO - 2023-07-29 02:15:33 --> Security Class Initialized
DEBUG - 2023-07-29 02:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 02:15:33 --> Input Class Initialized
INFO - 2023-07-29 02:15:33 --> Language Class Initialized
INFO - 2023-07-29 02:15:33 --> Loader Class Initialized
INFO - 2023-07-29 02:15:33 --> Helper loaded: url_helper
INFO - 2023-07-29 02:15:33 --> Helper loaded: file_helper
INFO - 2023-07-29 02:15:33 --> Helper loaded: html_helper
INFO - 2023-07-29 02:15:33 --> Helper loaded: text_helper
INFO - 2023-07-29 02:15:33 --> Helper loaded: form_helper
INFO - 2023-07-29 02:15:33 --> Helper loaded: lang_helper
INFO - 2023-07-29 02:15:33 --> Helper loaded: security_helper
INFO - 2023-07-29 02:15:33 --> Helper loaded: cookie_helper
INFO - 2023-07-29 02:15:33 --> Database Driver Class Initialized
INFO - 2023-07-29 02:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 02:15:33 --> Parser Class Initialized
INFO - 2023-07-29 02:15:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 02:15:33 --> Pagination Class Initialized
INFO - 2023-07-29 02:15:33 --> Form Validation Class Initialized
INFO - 2023-07-29 02:15:33 --> Controller Class Initialized
INFO - 2023-07-29 02:15:33 --> Model Class Initialized
DEBUG - 2023-07-29 02:15:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 02:15:33 --> Model Class Initialized
INFO - 2023-07-29 02:15:33 --> Final output sent to browser
DEBUG - 2023-07-29 02:15:33 --> Total execution time: 0.0194
ERROR - 2023-07-29 02:15:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 02:15:33 --> Config Class Initialized
INFO - 2023-07-29 02:15:33 --> Hooks Class Initialized
DEBUG - 2023-07-29 02:15:33 --> UTF-8 Support Enabled
INFO - 2023-07-29 02:15:33 --> Utf8 Class Initialized
INFO - 2023-07-29 02:15:33 --> URI Class Initialized
DEBUG - 2023-07-29 02:15:33 --> No URI present. Default controller set.
INFO - 2023-07-29 02:15:33 --> Router Class Initialized
INFO - 2023-07-29 02:15:33 --> Output Class Initialized
INFO - 2023-07-29 02:15:33 --> Security Class Initialized
DEBUG - 2023-07-29 02:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 02:15:33 --> Input Class Initialized
INFO - 2023-07-29 02:15:33 --> Language Class Initialized
INFO - 2023-07-29 02:15:33 --> Loader Class Initialized
INFO - 2023-07-29 02:15:33 --> Helper loaded: url_helper
INFO - 2023-07-29 02:15:33 --> Helper loaded: file_helper
INFO - 2023-07-29 02:15:33 --> Helper loaded: html_helper
INFO - 2023-07-29 02:15:33 --> Helper loaded: text_helper
INFO - 2023-07-29 02:15:33 --> Helper loaded: form_helper
INFO - 2023-07-29 02:15:33 --> Helper loaded: lang_helper
INFO - 2023-07-29 02:15:33 --> Helper loaded: security_helper
INFO - 2023-07-29 02:15:33 --> Helper loaded: cookie_helper
INFO - 2023-07-29 02:15:33 --> Database Driver Class Initialized
INFO - 2023-07-29 02:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 02:15:33 --> Parser Class Initialized
INFO - 2023-07-29 02:15:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 02:15:33 --> Pagination Class Initialized
INFO - 2023-07-29 02:15:33 --> Form Validation Class Initialized
INFO - 2023-07-29 02:15:33 --> Controller Class Initialized
INFO - 2023-07-29 02:15:33 --> Model Class Initialized
DEBUG - 2023-07-29 02:15:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 02:15:33 --> Model Class Initialized
DEBUG - 2023-07-29 02:15:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 02:15:33 --> Model Class Initialized
INFO - 2023-07-29 02:15:33 --> Model Class Initialized
INFO - 2023-07-29 02:15:33 --> Model Class Initialized
INFO - 2023-07-29 02:15:33 --> Model Class Initialized
DEBUG - 2023-07-29 02:15:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-29 02:15:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 02:15:33 --> Model Class Initialized
INFO - 2023-07-29 02:15:33 --> Model Class Initialized
INFO - 2023-07-29 02:15:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-29 02:15:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-29 02:15:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-29 02:15:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-29 02:15:33 --> Model Class Initialized
INFO - 2023-07-29 02:15:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-29 02:15:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-29 02:15:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-29 02:15:33 --> Final output sent to browser
DEBUG - 2023-07-29 02:15:33 --> Total execution time: 0.0893
ERROR - 2023-07-29 02:16:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 02:16:10 --> Config Class Initialized
INFO - 2023-07-29 02:16:10 --> Hooks Class Initialized
DEBUG - 2023-07-29 02:16:10 --> UTF-8 Support Enabled
INFO - 2023-07-29 02:16:10 --> Utf8 Class Initialized
INFO - 2023-07-29 02:16:10 --> URI Class Initialized
INFO - 2023-07-29 02:16:10 --> Router Class Initialized
INFO - 2023-07-29 02:16:10 --> Output Class Initialized
INFO - 2023-07-29 02:16:10 --> Security Class Initialized
DEBUG - 2023-07-29 02:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 02:16:10 --> Input Class Initialized
INFO - 2023-07-29 02:16:10 --> Language Class Initialized
INFO - 2023-07-29 02:16:10 --> Loader Class Initialized
INFO - 2023-07-29 02:16:10 --> Helper loaded: url_helper
INFO - 2023-07-29 02:16:10 --> Helper loaded: file_helper
INFO - 2023-07-29 02:16:10 --> Helper loaded: html_helper
INFO - 2023-07-29 02:16:10 --> Helper loaded: text_helper
INFO - 2023-07-29 02:16:10 --> Helper loaded: form_helper
INFO - 2023-07-29 02:16:10 --> Helper loaded: lang_helper
INFO - 2023-07-29 02:16:10 --> Helper loaded: security_helper
INFO - 2023-07-29 02:16:10 --> Helper loaded: cookie_helper
INFO - 2023-07-29 02:16:10 --> Database Driver Class Initialized
INFO - 2023-07-29 02:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 02:16:10 --> Parser Class Initialized
INFO - 2023-07-29 02:16:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 02:16:10 --> Pagination Class Initialized
INFO - 2023-07-29 02:16:10 --> Form Validation Class Initialized
INFO - 2023-07-29 02:16:10 --> Controller Class Initialized
INFO - 2023-07-29 02:16:10 --> Model Class Initialized
INFO - 2023-07-29 02:16:10 --> Model Class Initialized
INFO - 2023-07-29 02:16:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2023-07-29 02:16:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-29 02:16:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-29 02:16:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-29 02:16:10 --> Model Class Initialized
INFO - 2023-07-29 02:16:10 --> Model Class Initialized
INFO - 2023-07-29 02:16:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-29 02:16:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-29 02:16:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-29 02:16:10 --> Final output sent to browser
DEBUG - 2023-07-29 02:16:10 --> Total execution time: 0.1617
ERROR - 2023-07-29 02:16:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 02:16:11 --> Config Class Initialized
INFO - 2023-07-29 02:16:11 --> Hooks Class Initialized
DEBUG - 2023-07-29 02:16:11 --> UTF-8 Support Enabled
INFO - 2023-07-29 02:16:11 --> Utf8 Class Initialized
INFO - 2023-07-29 02:16:11 --> URI Class Initialized
INFO - 2023-07-29 02:16:11 --> Router Class Initialized
INFO - 2023-07-29 02:16:11 --> Output Class Initialized
INFO - 2023-07-29 02:16:11 --> Security Class Initialized
DEBUG - 2023-07-29 02:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 02:16:11 --> Input Class Initialized
INFO - 2023-07-29 02:16:11 --> Language Class Initialized
INFO - 2023-07-29 02:16:11 --> Loader Class Initialized
INFO - 2023-07-29 02:16:11 --> Helper loaded: url_helper
INFO - 2023-07-29 02:16:11 --> Helper loaded: file_helper
INFO - 2023-07-29 02:16:11 --> Helper loaded: html_helper
INFO - 2023-07-29 02:16:11 --> Helper loaded: text_helper
INFO - 2023-07-29 02:16:11 --> Helper loaded: form_helper
INFO - 2023-07-29 02:16:11 --> Helper loaded: lang_helper
INFO - 2023-07-29 02:16:11 --> Helper loaded: security_helper
INFO - 2023-07-29 02:16:11 --> Helper loaded: cookie_helper
INFO - 2023-07-29 02:16:11 --> Database Driver Class Initialized
INFO - 2023-07-29 02:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 02:16:11 --> Parser Class Initialized
INFO - 2023-07-29 02:16:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 02:16:11 --> Pagination Class Initialized
INFO - 2023-07-29 02:16:11 --> Form Validation Class Initialized
INFO - 2023-07-29 02:16:11 --> Controller Class Initialized
INFO - 2023-07-29 02:16:11 --> Model Class Initialized
INFO - 2023-07-29 02:16:11 --> Model Class Initialized
INFO - 2023-07-29 02:16:11 --> Final output sent to browser
DEBUG - 2023-07-29 02:16:11 --> Total execution time: 0.0588
ERROR - 2023-07-29 02:16:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 02:16:29 --> Config Class Initialized
INFO - 2023-07-29 02:16:29 --> Hooks Class Initialized
DEBUG - 2023-07-29 02:16:29 --> UTF-8 Support Enabled
INFO - 2023-07-29 02:16:29 --> Utf8 Class Initialized
INFO - 2023-07-29 02:16:29 --> URI Class Initialized
INFO - 2023-07-29 02:16:29 --> Router Class Initialized
INFO - 2023-07-29 02:16:29 --> Output Class Initialized
INFO - 2023-07-29 02:16:29 --> Security Class Initialized
DEBUG - 2023-07-29 02:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 02:16:29 --> Input Class Initialized
INFO - 2023-07-29 02:16:29 --> Language Class Initialized
INFO - 2023-07-29 02:16:29 --> Loader Class Initialized
INFO - 2023-07-29 02:16:29 --> Helper loaded: url_helper
INFO - 2023-07-29 02:16:29 --> Helper loaded: file_helper
INFO - 2023-07-29 02:16:29 --> Helper loaded: html_helper
INFO - 2023-07-29 02:16:29 --> Helper loaded: text_helper
INFO - 2023-07-29 02:16:29 --> Helper loaded: form_helper
INFO - 2023-07-29 02:16:29 --> Helper loaded: lang_helper
INFO - 2023-07-29 02:16:29 --> Helper loaded: security_helper
INFO - 2023-07-29 02:16:29 --> Helper loaded: cookie_helper
INFO - 2023-07-29 02:16:29 --> Database Driver Class Initialized
INFO - 2023-07-29 02:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 02:16:29 --> Parser Class Initialized
INFO - 2023-07-29 02:16:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 02:16:29 --> Pagination Class Initialized
INFO - 2023-07-29 02:16:29 --> Form Validation Class Initialized
INFO - 2023-07-29 02:16:29 --> Controller Class Initialized
INFO - 2023-07-29 02:16:29 --> Model Class Initialized
INFO - 2023-07-29 02:16:29 --> Model Class Initialized
INFO - 2023-07-29 02:16:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-07-29 02:16:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-29 02:16:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-29 02:16:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-29 02:16:29 --> Model Class Initialized
INFO - 2023-07-29 02:16:29 --> Model Class Initialized
INFO - 2023-07-29 02:16:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-29 02:16:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-29 02:16:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-29 02:16:29 --> Final output sent to browser
DEBUG - 2023-07-29 02:16:29 --> Total execution time: 0.0685
ERROR - 2023-07-29 02:16:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 02:16:30 --> Config Class Initialized
INFO - 2023-07-29 02:16:30 --> Hooks Class Initialized
DEBUG - 2023-07-29 02:16:30 --> UTF-8 Support Enabled
INFO - 2023-07-29 02:16:30 --> Utf8 Class Initialized
INFO - 2023-07-29 02:16:30 --> URI Class Initialized
INFO - 2023-07-29 02:16:30 --> Router Class Initialized
INFO - 2023-07-29 02:16:30 --> Output Class Initialized
INFO - 2023-07-29 02:16:30 --> Security Class Initialized
DEBUG - 2023-07-29 02:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 02:16:30 --> Input Class Initialized
INFO - 2023-07-29 02:16:30 --> Language Class Initialized
INFO - 2023-07-29 02:16:30 --> Loader Class Initialized
INFO - 2023-07-29 02:16:30 --> Helper loaded: url_helper
INFO - 2023-07-29 02:16:30 --> Helper loaded: file_helper
INFO - 2023-07-29 02:16:30 --> Helper loaded: html_helper
INFO - 2023-07-29 02:16:30 --> Helper loaded: text_helper
INFO - 2023-07-29 02:16:30 --> Helper loaded: form_helper
INFO - 2023-07-29 02:16:30 --> Helper loaded: lang_helper
INFO - 2023-07-29 02:16:30 --> Helper loaded: security_helper
INFO - 2023-07-29 02:16:30 --> Helper loaded: cookie_helper
INFO - 2023-07-29 02:16:30 --> Database Driver Class Initialized
INFO - 2023-07-29 02:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 02:16:30 --> Parser Class Initialized
INFO - 2023-07-29 02:16:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 02:16:30 --> Pagination Class Initialized
INFO - 2023-07-29 02:16:30 --> Form Validation Class Initialized
INFO - 2023-07-29 02:16:30 --> Controller Class Initialized
INFO - 2023-07-29 02:16:30 --> Model Class Initialized
INFO - 2023-07-29 02:16:30 --> Model Class Initialized
INFO - 2023-07-29 02:16:30 --> Final output sent to browser
DEBUG - 2023-07-29 02:16:30 --> Total execution time: 0.0220
ERROR - 2023-07-29 02:17:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 02:17:02 --> Config Class Initialized
INFO - 2023-07-29 02:17:02 --> Hooks Class Initialized
DEBUG - 2023-07-29 02:17:02 --> UTF-8 Support Enabled
INFO - 2023-07-29 02:17:02 --> Utf8 Class Initialized
INFO - 2023-07-29 02:17:02 --> URI Class Initialized
INFO - 2023-07-29 02:17:02 --> Router Class Initialized
INFO - 2023-07-29 02:17:02 --> Output Class Initialized
INFO - 2023-07-29 02:17:02 --> Security Class Initialized
DEBUG - 2023-07-29 02:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 02:17:02 --> Input Class Initialized
INFO - 2023-07-29 02:17:02 --> Language Class Initialized
INFO - 2023-07-29 02:17:02 --> Loader Class Initialized
INFO - 2023-07-29 02:17:02 --> Helper loaded: url_helper
INFO - 2023-07-29 02:17:02 --> Helper loaded: file_helper
INFO - 2023-07-29 02:17:02 --> Helper loaded: html_helper
INFO - 2023-07-29 02:17:02 --> Helper loaded: text_helper
INFO - 2023-07-29 02:17:02 --> Helper loaded: form_helper
INFO - 2023-07-29 02:17:02 --> Helper loaded: lang_helper
INFO - 2023-07-29 02:17:02 --> Helper loaded: security_helper
INFO - 2023-07-29 02:17:02 --> Helper loaded: cookie_helper
INFO - 2023-07-29 02:17:02 --> Database Driver Class Initialized
INFO - 2023-07-29 02:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 02:17:02 --> Parser Class Initialized
INFO - 2023-07-29 02:17:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 02:17:02 --> Pagination Class Initialized
INFO - 2023-07-29 02:17:02 --> Form Validation Class Initialized
INFO - 2023-07-29 02:17:02 --> Controller Class Initialized
INFO - 2023-07-29 02:17:02 --> Model Class Initialized
INFO - 2023-07-29 02:17:02 --> Model Class Initialized
INFO - 2023-07-29 02:17:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-07-29 02:17:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-29 02:17:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-29 02:17:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-29 02:17:02 --> Model Class Initialized
INFO - 2023-07-29 02:17:02 --> Model Class Initialized
INFO - 2023-07-29 02:17:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-29 02:17:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-29 02:17:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-29 02:17:02 --> Final output sent to browser
DEBUG - 2023-07-29 02:17:02 --> Total execution time: 0.0651
ERROR - 2023-07-29 02:17:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 02:17:03 --> Config Class Initialized
INFO - 2023-07-29 02:17:03 --> Hooks Class Initialized
DEBUG - 2023-07-29 02:17:03 --> UTF-8 Support Enabled
INFO - 2023-07-29 02:17:03 --> Utf8 Class Initialized
INFO - 2023-07-29 02:17:03 --> URI Class Initialized
INFO - 2023-07-29 02:17:03 --> Router Class Initialized
INFO - 2023-07-29 02:17:03 --> Output Class Initialized
INFO - 2023-07-29 02:17:03 --> Security Class Initialized
DEBUG - 2023-07-29 02:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 02:17:03 --> Input Class Initialized
INFO - 2023-07-29 02:17:03 --> Language Class Initialized
INFO - 2023-07-29 02:17:03 --> Loader Class Initialized
INFO - 2023-07-29 02:17:03 --> Helper loaded: url_helper
INFO - 2023-07-29 02:17:03 --> Helper loaded: file_helper
INFO - 2023-07-29 02:17:03 --> Helper loaded: html_helper
INFO - 2023-07-29 02:17:03 --> Helper loaded: text_helper
INFO - 2023-07-29 02:17:03 --> Helper loaded: form_helper
INFO - 2023-07-29 02:17:03 --> Helper loaded: lang_helper
INFO - 2023-07-29 02:17:03 --> Helper loaded: security_helper
INFO - 2023-07-29 02:17:03 --> Helper loaded: cookie_helper
INFO - 2023-07-29 02:17:03 --> Database Driver Class Initialized
INFO - 2023-07-29 02:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 02:17:03 --> Parser Class Initialized
INFO - 2023-07-29 02:17:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 02:17:03 --> Pagination Class Initialized
INFO - 2023-07-29 02:17:03 --> Form Validation Class Initialized
INFO - 2023-07-29 02:17:03 --> Controller Class Initialized
INFO - 2023-07-29 02:17:03 --> Model Class Initialized
INFO - 2023-07-29 02:17:03 --> Model Class Initialized
INFO - 2023-07-29 02:17:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-07-29 02:17:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-29 02:17:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-29 02:17:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-29 02:17:03 --> Model Class Initialized
INFO - 2023-07-29 02:17:03 --> Model Class Initialized
INFO - 2023-07-29 02:17:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-29 02:17:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-29 02:17:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-29 02:17:03 --> Final output sent to browser
DEBUG - 2023-07-29 02:17:03 --> Total execution time: 0.0646
ERROR - 2023-07-29 02:17:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 02:17:03 --> Config Class Initialized
INFO - 2023-07-29 02:17:03 --> Hooks Class Initialized
DEBUG - 2023-07-29 02:17:03 --> UTF-8 Support Enabled
INFO - 2023-07-29 02:17:03 --> Utf8 Class Initialized
INFO - 2023-07-29 02:17:03 --> URI Class Initialized
INFO - 2023-07-29 02:17:03 --> Router Class Initialized
INFO - 2023-07-29 02:17:03 --> Output Class Initialized
INFO - 2023-07-29 02:17:03 --> Security Class Initialized
DEBUG - 2023-07-29 02:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 02:17:03 --> Input Class Initialized
INFO - 2023-07-29 02:17:03 --> Language Class Initialized
INFO - 2023-07-29 02:17:03 --> Loader Class Initialized
INFO - 2023-07-29 02:17:03 --> Helper loaded: url_helper
INFO - 2023-07-29 02:17:03 --> Helper loaded: file_helper
INFO - 2023-07-29 02:17:03 --> Helper loaded: html_helper
INFO - 2023-07-29 02:17:03 --> Helper loaded: text_helper
INFO - 2023-07-29 02:17:03 --> Helper loaded: form_helper
INFO - 2023-07-29 02:17:03 --> Helper loaded: lang_helper
INFO - 2023-07-29 02:17:03 --> Helper loaded: security_helper
INFO - 2023-07-29 02:17:03 --> Helper loaded: cookie_helper
INFO - 2023-07-29 02:17:03 --> Database Driver Class Initialized
INFO - 2023-07-29 02:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 02:17:03 --> Parser Class Initialized
INFO - 2023-07-29 02:17:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 02:17:03 --> Pagination Class Initialized
INFO - 2023-07-29 02:17:03 --> Form Validation Class Initialized
INFO - 2023-07-29 02:17:03 --> Controller Class Initialized
INFO - 2023-07-29 02:17:03 --> Model Class Initialized
INFO - 2023-07-29 02:17:03 --> Model Class Initialized
INFO - 2023-07-29 02:17:03 --> Final output sent to browser
DEBUG - 2023-07-29 02:17:03 --> Total execution time: 0.0197
ERROR - 2023-07-29 02:17:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 02:17:17 --> Config Class Initialized
INFO - 2023-07-29 02:17:17 --> Hooks Class Initialized
DEBUG - 2023-07-29 02:17:17 --> UTF-8 Support Enabled
INFO - 2023-07-29 02:17:17 --> Utf8 Class Initialized
INFO - 2023-07-29 02:17:17 --> URI Class Initialized
INFO - 2023-07-29 02:17:17 --> Router Class Initialized
INFO - 2023-07-29 02:17:17 --> Output Class Initialized
INFO - 2023-07-29 02:17:17 --> Security Class Initialized
DEBUG - 2023-07-29 02:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 02:17:17 --> Input Class Initialized
INFO - 2023-07-29 02:17:17 --> Language Class Initialized
INFO - 2023-07-29 02:17:17 --> Loader Class Initialized
INFO - 2023-07-29 02:17:17 --> Helper loaded: url_helper
INFO - 2023-07-29 02:17:17 --> Helper loaded: file_helper
INFO - 2023-07-29 02:17:17 --> Helper loaded: html_helper
INFO - 2023-07-29 02:17:17 --> Helper loaded: text_helper
INFO - 2023-07-29 02:17:17 --> Helper loaded: form_helper
INFO - 2023-07-29 02:17:17 --> Helper loaded: lang_helper
INFO - 2023-07-29 02:17:17 --> Helper loaded: security_helper
INFO - 2023-07-29 02:17:17 --> Helper loaded: cookie_helper
INFO - 2023-07-29 02:17:17 --> Database Driver Class Initialized
INFO - 2023-07-29 02:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 02:17:17 --> Parser Class Initialized
INFO - 2023-07-29 02:17:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 02:17:17 --> Pagination Class Initialized
INFO - 2023-07-29 02:17:17 --> Form Validation Class Initialized
INFO - 2023-07-29 02:17:17 --> Controller Class Initialized
DEBUG - 2023-07-29 02:17:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-29 02:17:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 02:17:17 --> Model Class Initialized
DEBUG - 2023-07-29 02:17:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 02:17:17 --> Model Class Initialized
DEBUG - 2023-07-29 02:17:17 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-07-29 02:17:17 --> Model Class Initialized
INFO - 2023-07-29 02:17:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-07-29 02:17:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-29 02:17:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-29 02:17:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-29 02:17:17 --> Model Class Initialized
INFO - 2023-07-29 02:17:17 --> Model Class Initialized
INFO - 2023-07-29 02:17:17 --> Model Class Initialized
INFO - 2023-07-29 02:17:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-29 02:17:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-29 02:17:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-29 02:17:17 --> Final output sent to browser
DEBUG - 2023-07-29 02:17:17 --> Total execution time: 0.0709
ERROR - 2023-07-29 02:17:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 02:17:18 --> Config Class Initialized
INFO - 2023-07-29 02:17:18 --> Hooks Class Initialized
DEBUG - 2023-07-29 02:17:18 --> UTF-8 Support Enabled
INFO - 2023-07-29 02:17:18 --> Utf8 Class Initialized
INFO - 2023-07-29 02:17:18 --> URI Class Initialized
INFO - 2023-07-29 02:17:18 --> Router Class Initialized
INFO - 2023-07-29 02:17:18 --> Output Class Initialized
INFO - 2023-07-29 02:17:18 --> Security Class Initialized
DEBUG - 2023-07-29 02:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 02:17:18 --> Input Class Initialized
INFO - 2023-07-29 02:17:18 --> Language Class Initialized
INFO - 2023-07-29 02:17:18 --> Loader Class Initialized
INFO - 2023-07-29 02:17:18 --> Helper loaded: url_helper
INFO - 2023-07-29 02:17:18 --> Helper loaded: file_helper
INFO - 2023-07-29 02:17:18 --> Helper loaded: html_helper
INFO - 2023-07-29 02:17:18 --> Helper loaded: text_helper
INFO - 2023-07-29 02:17:18 --> Helper loaded: form_helper
INFO - 2023-07-29 02:17:18 --> Helper loaded: lang_helper
INFO - 2023-07-29 02:17:18 --> Helper loaded: security_helper
INFO - 2023-07-29 02:17:18 --> Helper loaded: cookie_helper
INFO - 2023-07-29 02:17:18 --> Database Driver Class Initialized
INFO - 2023-07-29 02:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 02:17:18 --> Parser Class Initialized
INFO - 2023-07-29 02:17:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 02:17:18 --> Pagination Class Initialized
INFO - 2023-07-29 02:17:18 --> Form Validation Class Initialized
INFO - 2023-07-29 02:17:18 --> Controller Class Initialized
DEBUG - 2023-07-29 02:17:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-29 02:17:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 02:17:18 --> Model Class Initialized
DEBUG - 2023-07-29 02:17:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 02:17:18 --> Model Class Initialized
INFO - 2023-07-29 02:17:18 --> Final output sent to browser
DEBUG - 2023-07-29 02:17:18 --> Total execution time: 0.0214
ERROR - 2023-07-29 02:18:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 02:18:11 --> Config Class Initialized
INFO - 2023-07-29 02:18:11 --> Hooks Class Initialized
DEBUG - 2023-07-29 02:18:11 --> UTF-8 Support Enabled
INFO - 2023-07-29 02:18:11 --> Utf8 Class Initialized
INFO - 2023-07-29 02:18:11 --> URI Class Initialized
INFO - 2023-07-29 02:18:11 --> Router Class Initialized
INFO - 2023-07-29 02:18:11 --> Output Class Initialized
INFO - 2023-07-29 02:18:11 --> Security Class Initialized
DEBUG - 2023-07-29 02:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 02:18:11 --> Input Class Initialized
INFO - 2023-07-29 02:18:11 --> Language Class Initialized
INFO - 2023-07-29 02:18:11 --> Loader Class Initialized
INFO - 2023-07-29 02:18:11 --> Helper loaded: url_helper
INFO - 2023-07-29 02:18:11 --> Helper loaded: file_helper
INFO - 2023-07-29 02:18:11 --> Helper loaded: html_helper
INFO - 2023-07-29 02:18:11 --> Helper loaded: text_helper
INFO - 2023-07-29 02:18:11 --> Helper loaded: form_helper
INFO - 2023-07-29 02:18:11 --> Helper loaded: lang_helper
INFO - 2023-07-29 02:18:11 --> Helper loaded: security_helper
INFO - 2023-07-29 02:18:11 --> Helper loaded: cookie_helper
INFO - 2023-07-29 02:18:11 --> Database Driver Class Initialized
INFO - 2023-07-29 02:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 02:18:11 --> Parser Class Initialized
INFO - 2023-07-29 02:18:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 02:18:11 --> Pagination Class Initialized
INFO - 2023-07-29 02:18:11 --> Form Validation Class Initialized
INFO - 2023-07-29 02:18:11 --> Controller Class Initialized
DEBUG - 2023-07-29 02:18:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-29 02:18:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 02:18:11 --> Model Class Initialized
DEBUG - 2023-07-29 02:18:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 02:18:11 --> Model Class Initialized
INFO - 2023-07-29 02:18:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/view_customer.php
DEBUG - 2023-07-29 02:18:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-29 02:18:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-29 02:18:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-29 02:18:11 --> Model Class Initialized
INFO - 2023-07-29 02:18:11 --> Model Class Initialized
INFO - 2023-07-29 02:18:11 --> Model Class Initialized
INFO - 2023-07-29 02:18:11 --> Model Class Initialized
INFO - 2023-07-29 02:18:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-29 02:18:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-29 02:18:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-29 02:18:11 --> Final output sent to browser
DEBUG - 2023-07-29 02:18:11 --> Total execution time: 0.0732
ERROR - 2023-07-29 02:18:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 02:18:44 --> Config Class Initialized
INFO - 2023-07-29 02:18:44 --> Hooks Class Initialized
DEBUG - 2023-07-29 02:18:44 --> UTF-8 Support Enabled
INFO - 2023-07-29 02:18:44 --> Utf8 Class Initialized
INFO - 2023-07-29 02:18:44 --> URI Class Initialized
INFO - 2023-07-29 02:18:44 --> Router Class Initialized
INFO - 2023-07-29 02:18:44 --> Output Class Initialized
INFO - 2023-07-29 02:18:44 --> Security Class Initialized
DEBUG - 2023-07-29 02:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 02:18:44 --> Input Class Initialized
INFO - 2023-07-29 02:18:44 --> Language Class Initialized
INFO - 2023-07-29 02:18:44 --> Loader Class Initialized
INFO - 2023-07-29 02:18:44 --> Helper loaded: url_helper
INFO - 2023-07-29 02:18:44 --> Helper loaded: file_helper
INFO - 2023-07-29 02:18:44 --> Helper loaded: html_helper
INFO - 2023-07-29 02:18:44 --> Helper loaded: text_helper
INFO - 2023-07-29 02:18:44 --> Helper loaded: form_helper
INFO - 2023-07-29 02:18:44 --> Helper loaded: lang_helper
INFO - 2023-07-29 02:18:44 --> Helper loaded: security_helper
INFO - 2023-07-29 02:18:44 --> Helper loaded: cookie_helper
INFO - 2023-07-29 02:18:44 --> Database Driver Class Initialized
INFO - 2023-07-29 02:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 02:18:44 --> Parser Class Initialized
INFO - 2023-07-29 02:18:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 02:18:44 --> Pagination Class Initialized
INFO - 2023-07-29 02:18:44 --> Form Validation Class Initialized
INFO - 2023-07-29 02:18:44 --> Controller Class Initialized
DEBUG - 2023-07-29 02:18:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-29 02:18:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 02:18:44 --> Model Class Initialized
DEBUG - 2023-07-29 02:18:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 02:18:44 --> Model Class Initialized
DEBUG - 2023-07-29 02:18:44 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-07-29 02:18:44 --> Model Class Initialized
INFO - 2023-07-29 02:18:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-07-29 02:18:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-29 02:18:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-29 02:18:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-29 02:18:44 --> Model Class Initialized
INFO - 2023-07-29 02:18:44 --> Model Class Initialized
INFO - 2023-07-29 02:18:44 --> Model Class Initialized
INFO - 2023-07-29 02:18:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-29 02:18:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-29 02:18:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-29 02:18:44 --> Final output sent to browser
DEBUG - 2023-07-29 02:18:44 --> Total execution time: 0.0711
ERROR - 2023-07-29 02:18:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 02:18:45 --> Config Class Initialized
INFO - 2023-07-29 02:18:45 --> Hooks Class Initialized
DEBUG - 2023-07-29 02:18:45 --> UTF-8 Support Enabled
INFO - 2023-07-29 02:18:45 --> Utf8 Class Initialized
INFO - 2023-07-29 02:18:45 --> URI Class Initialized
INFO - 2023-07-29 02:18:45 --> Router Class Initialized
INFO - 2023-07-29 02:18:45 --> Output Class Initialized
INFO - 2023-07-29 02:18:45 --> Security Class Initialized
DEBUG - 2023-07-29 02:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 02:18:45 --> Input Class Initialized
INFO - 2023-07-29 02:18:45 --> Language Class Initialized
INFO - 2023-07-29 02:18:45 --> Loader Class Initialized
INFO - 2023-07-29 02:18:45 --> Helper loaded: url_helper
INFO - 2023-07-29 02:18:45 --> Helper loaded: file_helper
INFO - 2023-07-29 02:18:45 --> Helper loaded: html_helper
INFO - 2023-07-29 02:18:45 --> Helper loaded: text_helper
INFO - 2023-07-29 02:18:45 --> Helper loaded: form_helper
INFO - 2023-07-29 02:18:45 --> Helper loaded: lang_helper
INFO - 2023-07-29 02:18:45 --> Helper loaded: security_helper
INFO - 2023-07-29 02:18:45 --> Helper loaded: cookie_helper
INFO - 2023-07-29 02:18:45 --> Database Driver Class Initialized
INFO - 2023-07-29 02:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 02:18:45 --> Parser Class Initialized
INFO - 2023-07-29 02:18:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 02:18:45 --> Pagination Class Initialized
INFO - 2023-07-29 02:18:45 --> Form Validation Class Initialized
INFO - 2023-07-29 02:18:45 --> Controller Class Initialized
DEBUG - 2023-07-29 02:18:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-29 02:18:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 02:18:45 --> Model Class Initialized
DEBUG - 2023-07-29 02:18:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 02:18:45 --> Model Class Initialized
INFO - 2023-07-29 02:18:45 --> Final output sent to browser
DEBUG - 2023-07-29 02:18:45 --> Total execution time: 0.0210
ERROR - 2023-07-29 02:18:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 02:18:46 --> Config Class Initialized
INFO - 2023-07-29 02:18:46 --> Hooks Class Initialized
DEBUG - 2023-07-29 02:18:46 --> UTF-8 Support Enabled
INFO - 2023-07-29 02:18:46 --> Utf8 Class Initialized
INFO - 2023-07-29 02:18:46 --> URI Class Initialized
INFO - 2023-07-29 02:18:46 --> Router Class Initialized
INFO - 2023-07-29 02:18:46 --> Output Class Initialized
INFO - 2023-07-29 02:18:46 --> Security Class Initialized
DEBUG - 2023-07-29 02:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 02:18:46 --> Input Class Initialized
INFO - 2023-07-29 02:18:46 --> Language Class Initialized
INFO - 2023-07-29 02:18:46 --> Loader Class Initialized
INFO - 2023-07-29 02:18:46 --> Helper loaded: url_helper
INFO - 2023-07-29 02:18:46 --> Helper loaded: file_helper
INFO - 2023-07-29 02:18:46 --> Helper loaded: html_helper
INFO - 2023-07-29 02:18:46 --> Helper loaded: text_helper
INFO - 2023-07-29 02:18:46 --> Helper loaded: form_helper
INFO - 2023-07-29 02:18:46 --> Helper loaded: lang_helper
INFO - 2023-07-29 02:18:46 --> Helper loaded: security_helper
INFO - 2023-07-29 02:18:46 --> Helper loaded: cookie_helper
INFO - 2023-07-29 02:18:46 --> Database Driver Class Initialized
INFO - 2023-07-29 02:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 02:18:46 --> Parser Class Initialized
INFO - 2023-07-29 02:18:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 02:18:46 --> Pagination Class Initialized
INFO - 2023-07-29 02:18:46 --> Form Validation Class Initialized
INFO - 2023-07-29 02:18:46 --> Controller Class Initialized
INFO - 2023-07-29 02:18:46 --> Model Class Initialized
INFO - 2023-07-29 02:18:46 --> Model Class Initialized
INFO - 2023-07-29 02:18:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-07-29 02:18:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-29 02:18:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-29 02:18:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-29 02:18:46 --> Model Class Initialized
INFO - 2023-07-29 02:18:46 --> Model Class Initialized
INFO - 2023-07-29 02:18:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-29 02:18:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-29 02:18:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-29 02:18:46 --> Final output sent to browser
DEBUG - 2023-07-29 02:18:46 --> Total execution time: 0.0604
ERROR - 2023-07-29 02:18:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 02:18:47 --> Config Class Initialized
INFO - 2023-07-29 02:18:47 --> Hooks Class Initialized
DEBUG - 2023-07-29 02:18:47 --> UTF-8 Support Enabled
INFO - 2023-07-29 02:18:47 --> Utf8 Class Initialized
INFO - 2023-07-29 02:18:47 --> URI Class Initialized
INFO - 2023-07-29 02:18:47 --> Router Class Initialized
INFO - 2023-07-29 02:18:47 --> Output Class Initialized
INFO - 2023-07-29 02:18:47 --> Security Class Initialized
DEBUG - 2023-07-29 02:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 02:18:47 --> Input Class Initialized
INFO - 2023-07-29 02:18:47 --> Language Class Initialized
INFO - 2023-07-29 02:18:47 --> Loader Class Initialized
INFO - 2023-07-29 02:18:47 --> Helper loaded: url_helper
INFO - 2023-07-29 02:18:47 --> Helper loaded: file_helper
INFO - 2023-07-29 02:18:47 --> Helper loaded: html_helper
INFO - 2023-07-29 02:18:47 --> Helper loaded: text_helper
INFO - 2023-07-29 02:18:47 --> Helper loaded: form_helper
INFO - 2023-07-29 02:18:47 --> Helper loaded: lang_helper
INFO - 2023-07-29 02:18:47 --> Helper loaded: security_helper
INFO - 2023-07-29 02:18:47 --> Helper loaded: cookie_helper
INFO - 2023-07-29 02:18:47 --> Database Driver Class Initialized
INFO - 2023-07-29 02:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 02:18:47 --> Parser Class Initialized
INFO - 2023-07-29 02:18:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 02:18:47 --> Pagination Class Initialized
INFO - 2023-07-29 02:18:47 --> Form Validation Class Initialized
INFO - 2023-07-29 02:18:47 --> Controller Class Initialized
INFO - 2023-07-29 02:18:47 --> Model Class Initialized
INFO - 2023-07-29 02:18:47 --> Model Class Initialized
INFO - 2023-07-29 02:18:47 --> Final output sent to browser
DEBUG - 2023-07-29 02:18:47 --> Total execution time: 0.0210
ERROR - 2023-07-29 02:18:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 02:18:48 --> Config Class Initialized
INFO - 2023-07-29 02:18:48 --> Hooks Class Initialized
DEBUG - 2023-07-29 02:18:48 --> UTF-8 Support Enabled
INFO - 2023-07-29 02:18:48 --> Utf8 Class Initialized
INFO - 2023-07-29 02:18:48 --> URI Class Initialized
INFO - 2023-07-29 02:18:48 --> Router Class Initialized
INFO - 2023-07-29 02:18:48 --> Output Class Initialized
INFO - 2023-07-29 02:18:48 --> Security Class Initialized
DEBUG - 2023-07-29 02:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 02:18:48 --> Input Class Initialized
INFO - 2023-07-29 02:18:48 --> Language Class Initialized
INFO - 2023-07-29 02:18:48 --> Loader Class Initialized
INFO - 2023-07-29 02:18:48 --> Helper loaded: url_helper
INFO - 2023-07-29 02:18:48 --> Helper loaded: file_helper
INFO - 2023-07-29 02:18:48 --> Helper loaded: html_helper
INFO - 2023-07-29 02:18:48 --> Helper loaded: text_helper
INFO - 2023-07-29 02:18:48 --> Helper loaded: form_helper
INFO - 2023-07-29 02:18:48 --> Helper loaded: lang_helper
INFO - 2023-07-29 02:18:48 --> Helper loaded: security_helper
INFO - 2023-07-29 02:18:48 --> Helper loaded: cookie_helper
INFO - 2023-07-29 02:18:48 --> Database Driver Class Initialized
INFO - 2023-07-29 02:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 02:18:48 --> Parser Class Initialized
INFO - 2023-07-29 02:18:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 02:18:48 --> Pagination Class Initialized
INFO - 2023-07-29 02:18:48 --> Form Validation Class Initialized
INFO - 2023-07-29 02:18:48 --> Controller Class Initialized
INFO - 2023-07-29 02:18:48 --> Model Class Initialized
INFO - 2023-07-29 02:18:48 --> Model Class Initialized
INFO - 2023-07-29 02:18:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2023-07-29 02:18:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-29 02:18:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-29 02:18:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-29 02:18:48 --> Model Class Initialized
INFO - 2023-07-29 02:18:48 --> Model Class Initialized
INFO - 2023-07-29 02:18:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-29 02:18:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-29 02:18:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-29 02:18:48 --> Final output sent to browser
DEBUG - 2023-07-29 02:18:48 --> Total execution time: 0.0657
ERROR - 2023-07-29 02:18:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 02:18:48 --> Config Class Initialized
INFO - 2023-07-29 02:18:48 --> Hooks Class Initialized
DEBUG - 2023-07-29 02:18:48 --> UTF-8 Support Enabled
INFO - 2023-07-29 02:18:48 --> Utf8 Class Initialized
INFO - 2023-07-29 02:18:48 --> URI Class Initialized
INFO - 2023-07-29 02:18:48 --> Router Class Initialized
INFO - 2023-07-29 02:18:48 --> Output Class Initialized
INFO - 2023-07-29 02:18:48 --> Security Class Initialized
DEBUG - 2023-07-29 02:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 02:18:48 --> Input Class Initialized
INFO - 2023-07-29 02:18:48 --> Language Class Initialized
INFO - 2023-07-29 02:18:48 --> Loader Class Initialized
INFO - 2023-07-29 02:18:48 --> Helper loaded: url_helper
INFO - 2023-07-29 02:18:48 --> Helper loaded: file_helper
INFO - 2023-07-29 02:18:48 --> Helper loaded: html_helper
INFO - 2023-07-29 02:18:48 --> Helper loaded: text_helper
INFO - 2023-07-29 02:18:48 --> Helper loaded: form_helper
INFO - 2023-07-29 02:18:48 --> Helper loaded: lang_helper
INFO - 2023-07-29 02:18:48 --> Helper loaded: security_helper
INFO - 2023-07-29 02:18:48 --> Helper loaded: cookie_helper
INFO - 2023-07-29 02:18:48 --> Database Driver Class Initialized
INFO - 2023-07-29 02:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 02:18:48 --> Parser Class Initialized
INFO - 2023-07-29 02:18:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 02:18:48 --> Pagination Class Initialized
INFO - 2023-07-29 02:18:48 --> Form Validation Class Initialized
INFO - 2023-07-29 02:18:48 --> Controller Class Initialized
INFO - 2023-07-29 02:18:48 --> Model Class Initialized
INFO - 2023-07-29 02:18:48 --> Model Class Initialized
INFO - 2023-07-29 02:18:48 --> Final output sent to browser
DEBUG - 2023-07-29 02:18:48 --> Total execution time: 0.0343
ERROR - 2023-07-29 02:18:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 02:18:50 --> Config Class Initialized
INFO - 2023-07-29 02:18:50 --> Hooks Class Initialized
DEBUG - 2023-07-29 02:18:50 --> UTF-8 Support Enabled
INFO - 2023-07-29 02:18:50 --> Utf8 Class Initialized
INFO - 2023-07-29 02:18:50 --> URI Class Initialized
DEBUG - 2023-07-29 02:18:50 --> No URI present. Default controller set.
INFO - 2023-07-29 02:18:50 --> Router Class Initialized
INFO - 2023-07-29 02:18:50 --> Output Class Initialized
INFO - 2023-07-29 02:18:50 --> Security Class Initialized
DEBUG - 2023-07-29 02:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 02:18:50 --> Input Class Initialized
INFO - 2023-07-29 02:18:50 --> Language Class Initialized
INFO - 2023-07-29 02:18:50 --> Loader Class Initialized
INFO - 2023-07-29 02:18:50 --> Helper loaded: url_helper
INFO - 2023-07-29 02:18:50 --> Helper loaded: file_helper
INFO - 2023-07-29 02:18:50 --> Helper loaded: html_helper
INFO - 2023-07-29 02:18:50 --> Helper loaded: text_helper
INFO - 2023-07-29 02:18:50 --> Helper loaded: form_helper
INFO - 2023-07-29 02:18:50 --> Helper loaded: lang_helper
INFO - 2023-07-29 02:18:50 --> Helper loaded: security_helper
INFO - 2023-07-29 02:18:50 --> Helper loaded: cookie_helper
INFO - 2023-07-29 02:18:50 --> Database Driver Class Initialized
INFO - 2023-07-29 02:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 02:18:50 --> Parser Class Initialized
INFO - 2023-07-29 02:18:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 02:18:50 --> Pagination Class Initialized
INFO - 2023-07-29 02:18:50 --> Form Validation Class Initialized
INFO - 2023-07-29 02:18:50 --> Controller Class Initialized
INFO - 2023-07-29 02:18:50 --> Model Class Initialized
DEBUG - 2023-07-29 02:18:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 02:18:50 --> Model Class Initialized
DEBUG - 2023-07-29 02:18:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 02:18:50 --> Model Class Initialized
INFO - 2023-07-29 02:18:50 --> Model Class Initialized
INFO - 2023-07-29 02:18:50 --> Model Class Initialized
INFO - 2023-07-29 02:18:50 --> Model Class Initialized
DEBUG - 2023-07-29 02:18:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-29 02:18:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 02:18:50 --> Model Class Initialized
INFO - 2023-07-29 02:18:50 --> Model Class Initialized
INFO - 2023-07-29 02:18:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-29 02:18:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-29 02:18:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-29 02:18:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-29 02:18:50 --> Model Class Initialized
INFO - 2023-07-29 02:18:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-29 02:18:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-29 02:18:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-29 02:18:50 --> Final output sent to browser
DEBUG - 2023-07-29 02:18:50 --> Total execution time: 0.0828
ERROR - 2023-07-29 02:18:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 02:18:52 --> Config Class Initialized
INFO - 2023-07-29 02:18:52 --> Hooks Class Initialized
DEBUG - 2023-07-29 02:18:52 --> UTF-8 Support Enabled
INFO - 2023-07-29 02:18:52 --> Utf8 Class Initialized
INFO - 2023-07-29 02:18:52 --> URI Class Initialized
INFO - 2023-07-29 02:18:52 --> Router Class Initialized
INFO - 2023-07-29 02:18:52 --> Output Class Initialized
INFO - 2023-07-29 02:18:52 --> Security Class Initialized
DEBUG - 2023-07-29 02:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 02:18:52 --> Input Class Initialized
INFO - 2023-07-29 02:18:52 --> Language Class Initialized
INFO - 2023-07-29 02:18:52 --> Loader Class Initialized
INFO - 2023-07-29 02:18:52 --> Helper loaded: url_helper
INFO - 2023-07-29 02:18:52 --> Helper loaded: file_helper
INFO - 2023-07-29 02:18:52 --> Helper loaded: html_helper
INFO - 2023-07-29 02:18:52 --> Helper loaded: text_helper
INFO - 2023-07-29 02:18:52 --> Helper loaded: form_helper
INFO - 2023-07-29 02:18:52 --> Helper loaded: lang_helper
INFO - 2023-07-29 02:18:52 --> Helper loaded: security_helper
INFO - 2023-07-29 02:18:52 --> Helper loaded: cookie_helper
INFO - 2023-07-29 02:18:52 --> Database Driver Class Initialized
INFO - 2023-07-29 02:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 02:18:52 --> Parser Class Initialized
INFO - 2023-07-29 02:18:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 02:18:52 --> Pagination Class Initialized
INFO - 2023-07-29 02:18:52 --> Form Validation Class Initialized
INFO - 2023-07-29 02:18:52 --> Controller Class Initialized
INFO - 2023-07-29 02:18:52 --> Model Class Initialized
DEBUG - 2023-07-29 02:18:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 02:18:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-29 02:18:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-29 02:18:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-29 02:18:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-29 02:18:52 --> Model Class Initialized
INFO - 2023-07-29 02:18:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-29 02:18:52 --> Final output sent to browser
DEBUG - 2023-07-29 02:18:52 --> Total execution time: 0.0276
ERROR - 2023-07-29 02:18:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 02:18:52 --> Config Class Initialized
INFO - 2023-07-29 02:18:52 --> Hooks Class Initialized
DEBUG - 2023-07-29 02:18:52 --> UTF-8 Support Enabled
INFO - 2023-07-29 02:18:52 --> Utf8 Class Initialized
INFO - 2023-07-29 02:18:52 --> URI Class Initialized
INFO - 2023-07-29 02:18:52 --> Router Class Initialized
INFO - 2023-07-29 02:18:52 --> Output Class Initialized
INFO - 2023-07-29 02:18:52 --> Security Class Initialized
DEBUG - 2023-07-29 02:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 02:18:52 --> Input Class Initialized
INFO - 2023-07-29 02:18:52 --> Language Class Initialized
INFO - 2023-07-29 02:18:52 --> Loader Class Initialized
INFO - 2023-07-29 02:18:52 --> Helper loaded: url_helper
INFO - 2023-07-29 02:18:52 --> Helper loaded: file_helper
INFO - 2023-07-29 02:18:52 --> Helper loaded: html_helper
INFO - 2023-07-29 02:18:52 --> Helper loaded: text_helper
INFO - 2023-07-29 02:18:52 --> Helper loaded: form_helper
INFO - 2023-07-29 02:18:52 --> Helper loaded: lang_helper
INFO - 2023-07-29 02:18:52 --> Helper loaded: security_helper
INFO - 2023-07-29 02:18:52 --> Helper loaded: cookie_helper
INFO - 2023-07-29 02:18:52 --> Database Driver Class Initialized
INFO - 2023-07-29 02:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 02:18:52 --> Parser Class Initialized
INFO - 2023-07-29 02:18:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 02:18:52 --> Pagination Class Initialized
INFO - 2023-07-29 02:18:52 --> Form Validation Class Initialized
INFO - 2023-07-29 02:18:52 --> Controller Class Initialized
INFO - 2023-07-29 02:18:52 --> Model Class Initialized
DEBUG - 2023-07-29 02:18:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 02:18:52 --> Model Class Initialized
DEBUG - 2023-07-29 02:18:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 02:18:52 --> Model Class Initialized
INFO - 2023-07-29 02:18:52 --> Model Class Initialized
INFO - 2023-07-29 02:18:52 --> Model Class Initialized
INFO - 2023-07-29 02:18:52 --> Model Class Initialized
DEBUG - 2023-07-29 02:18:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-29 02:18:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 02:18:52 --> Model Class Initialized
INFO - 2023-07-29 02:18:52 --> Model Class Initialized
INFO - 2023-07-29 02:18:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-29 02:18:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-29 02:18:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-29 02:18:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-29 02:18:52 --> Model Class Initialized
INFO - 2023-07-29 02:18:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-29 02:18:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-29 02:18:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-29 02:18:52 --> Final output sent to browser
DEBUG - 2023-07-29 02:18:52 --> Total execution time: 0.0934
ERROR - 2023-07-29 03:22:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 03:22:57 --> Config Class Initialized
INFO - 2023-07-29 03:22:57 --> Hooks Class Initialized
DEBUG - 2023-07-29 03:22:57 --> UTF-8 Support Enabled
INFO - 2023-07-29 03:22:57 --> Utf8 Class Initialized
INFO - 2023-07-29 03:22:57 --> URI Class Initialized
DEBUG - 2023-07-29 03:22:57 --> No URI present. Default controller set.
INFO - 2023-07-29 03:22:57 --> Router Class Initialized
INFO - 2023-07-29 03:22:57 --> Output Class Initialized
INFO - 2023-07-29 03:22:57 --> Security Class Initialized
DEBUG - 2023-07-29 03:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 03:22:57 --> Input Class Initialized
INFO - 2023-07-29 03:22:57 --> Language Class Initialized
INFO - 2023-07-29 03:22:57 --> Loader Class Initialized
INFO - 2023-07-29 03:22:57 --> Helper loaded: url_helper
INFO - 2023-07-29 03:22:57 --> Helper loaded: file_helper
INFO - 2023-07-29 03:22:57 --> Helper loaded: html_helper
INFO - 2023-07-29 03:22:57 --> Helper loaded: text_helper
INFO - 2023-07-29 03:22:57 --> Helper loaded: form_helper
INFO - 2023-07-29 03:22:57 --> Helper loaded: lang_helper
INFO - 2023-07-29 03:22:57 --> Helper loaded: security_helper
INFO - 2023-07-29 03:22:57 --> Helper loaded: cookie_helper
INFO - 2023-07-29 03:22:57 --> Database Driver Class Initialized
INFO - 2023-07-29 03:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 03:22:57 --> Parser Class Initialized
INFO - 2023-07-29 03:22:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 03:22:57 --> Pagination Class Initialized
INFO - 2023-07-29 03:22:57 --> Form Validation Class Initialized
INFO - 2023-07-29 03:22:57 --> Controller Class Initialized
INFO - 2023-07-29 03:22:57 --> Model Class Initialized
DEBUG - 2023-07-29 03:22:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-29 06:41:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 06:41:21 --> Config Class Initialized
INFO - 2023-07-29 06:41:21 --> Hooks Class Initialized
DEBUG - 2023-07-29 06:41:21 --> UTF-8 Support Enabled
INFO - 2023-07-29 06:41:21 --> Utf8 Class Initialized
INFO - 2023-07-29 06:41:21 --> URI Class Initialized
DEBUG - 2023-07-29 06:41:21 --> No URI present. Default controller set.
INFO - 2023-07-29 06:41:21 --> Router Class Initialized
INFO - 2023-07-29 06:41:21 --> Output Class Initialized
INFO - 2023-07-29 06:41:21 --> Security Class Initialized
DEBUG - 2023-07-29 06:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 06:41:21 --> Input Class Initialized
INFO - 2023-07-29 06:41:21 --> Language Class Initialized
INFO - 2023-07-29 06:41:21 --> Loader Class Initialized
INFO - 2023-07-29 06:41:21 --> Helper loaded: url_helper
INFO - 2023-07-29 06:41:21 --> Helper loaded: file_helper
INFO - 2023-07-29 06:41:21 --> Helper loaded: html_helper
INFO - 2023-07-29 06:41:21 --> Helper loaded: text_helper
INFO - 2023-07-29 06:41:21 --> Helper loaded: form_helper
INFO - 2023-07-29 06:41:21 --> Helper loaded: lang_helper
INFO - 2023-07-29 06:41:21 --> Helper loaded: security_helper
INFO - 2023-07-29 06:41:21 --> Helper loaded: cookie_helper
INFO - 2023-07-29 06:41:21 --> Database Driver Class Initialized
INFO - 2023-07-29 06:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 06:41:21 --> Parser Class Initialized
INFO - 2023-07-29 06:41:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 06:41:21 --> Pagination Class Initialized
INFO - 2023-07-29 06:41:21 --> Form Validation Class Initialized
INFO - 2023-07-29 06:41:21 --> Controller Class Initialized
INFO - 2023-07-29 06:41:21 --> Model Class Initialized
DEBUG - 2023-07-29 06:41:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-29 06:41:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 06:41:22 --> Config Class Initialized
INFO - 2023-07-29 06:41:22 --> Hooks Class Initialized
DEBUG - 2023-07-29 06:41:22 --> UTF-8 Support Enabled
INFO - 2023-07-29 06:41:22 --> Utf8 Class Initialized
INFO - 2023-07-29 06:41:22 --> URI Class Initialized
INFO - 2023-07-29 06:41:22 --> Router Class Initialized
INFO - 2023-07-29 06:41:22 --> Output Class Initialized
INFO - 2023-07-29 06:41:22 --> Security Class Initialized
DEBUG - 2023-07-29 06:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 06:41:22 --> Input Class Initialized
INFO - 2023-07-29 06:41:22 --> Language Class Initialized
INFO - 2023-07-29 06:41:22 --> Loader Class Initialized
INFO - 2023-07-29 06:41:22 --> Helper loaded: url_helper
INFO - 2023-07-29 06:41:22 --> Helper loaded: file_helper
INFO - 2023-07-29 06:41:22 --> Helper loaded: html_helper
INFO - 2023-07-29 06:41:22 --> Helper loaded: text_helper
INFO - 2023-07-29 06:41:22 --> Helper loaded: form_helper
INFO - 2023-07-29 06:41:22 --> Helper loaded: lang_helper
INFO - 2023-07-29 06:41:22 --> Helper loaded: security_helper
INFO - 2023-07-29 06:41:22 --> Helper loaded: cookie_helper
INFO - 2023-07-29 06:41:22 --> Database Driver Class Initialized
INFO - 2023-07-29 06:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 06:41:22 --> Parser Class Initialized
INFO - 2023-07-29 06:41:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 06:41:22 --> Pagination Class Initialized
INFO - 2023-07-29 06:41:22 --> Form Validation Class Initialized
INFO - 2023-07-29 06:41:22 --> Controller Class Initialized
INFO - 2023-07-29 06:41:22 --> Model Class Initialized
DEBUG - 2023-07-29 06:41:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 06:41:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-29 06:41:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-29 06:41:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-29 06:41:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-29 06:41:22 --> Model Class Initialized
INFO - 2023-07-29 06:41:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-29 06:41:22 --> Final output sent to browser
DEBUG - 2023-07-29 06:41:22 --> Total execution time: 0.0330
ERROR - 2023-07-29 06:41:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 06:41:25 --> Config Class Initialized
INFO - 2023-07-29 06:41:25 --> Hooks Class Initialized
DEBUG - 2023-07-29 06:41:25 --> UTF-8 Support Enabled
INFO - 2023-07-29 06:41:25 --> Utf8 Class Initialized
INFO - 2023-07-29 06:41:25 --> URI Class Initialized
INFO - 2023-07-29 06:41:25 --> Router Class Initialized
INFO - 2023-07-29 06:41:25 --> Output Class Initialized
INFO - 2023-07-29 06:41:25 --> Security Class Initialized
DEBUG - 2023-07-29 06:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 06:41:25 --> Input Class Initialized
INFO - 2023-07-29 06:41:25 --> Language Class Initialized
INFO - 2023-07-29 06:41:25 --> Loader Class Initialized
INFO - 2023-07-29 06:41:25 --> Helper loaded: url_helper
INFO - 2023-07-29 06:41:25 --> Helper loaded: file_helper
INFO - 2023-07-29 06:41:25 --> Helper loaded: html_helper
INFO - 2023-07-29 06:41:25 --> Helper loaded: text_helper
INFO - 2023-07-29 06:41:25 --> Helper loaded: form_helper
INFO - 2023-07-29 06:41:25 --> Helper loaded: lang_helper
INFO - 2023-07-29 06:41:25 --> Helper loaded: security_helper
INFO - 2023-07-29 06:41:25 --> Helper loaded: cookie_helper
INFO - 2023-07-29 06:41:25 --> Database Driver Class Initialized
INFO - 2023-07-29 06:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 06:41:25 --> Parser Class Initialized
INFO - 2023-07-29 06:41:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 06:41:25 --> Pagination Class Initialized
INFO - 2023-07-29 06:41:25 --> Form Validation Class Initialized
INFO - 2023-07-29 06:41:25 --> Controller Class Initialized
INFO - 2023-07-29 06:41:25 --> Model Class Initialized
DEBUG - 2023-07-29 06:41:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 06:41:25 --> Model Class Initialized
INFO - 2023-07-29 06:41:25 --> Final output sent to browser
DEBUG - 2023-07-29 06:41:25 --> Total execution time: 0.0218
ERROR - 2023-07-29 06:41:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 06:41:26 --> Config Class Initialized
INFO - 2023-07-29 06:41:26 --> Hooks Class Initialized
DEBUG - 2023-07-29 06:41:26 --> UTF-8 Support Enabled
INFO - 2023-07-29 06:41:26 --> Utf8 Class Initialized
INFO - 2023-07-29 06:41:26 --> URI Class Initialized
DEBUG - 2023-07-29 06:41:26 --> No URI present. Default controller set.
INFO - 2023-07-29 06:41:26 --> Router Class Initialized
INFO - 2023-07-29 06:41:26 --> Output Class Initialized
INFO - 2023-07-29 06:41:26 --> Security Class Initialized
DEBUG - 2023-07-29 06:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 06:41:26 --> Input Class Initialized
INFO - 2023-07-29 06:41:26 --> Language Class Initialized
INFO - 2023-07-29 06:41:26 --> Loader Class Initialized
INFO - 2023-07-29 06:41:26 --> Helper loaded: url_helper
INFO - 2023-07-29 06:41:26 --> Helper loaded: file_helper
INFO - 2023-07-29 06:41:26 --> Helper loaded: html_helper
INFO - 2023-07-29 06:41:26 --> Helper loaded: text_helper
INFO - 2023-07-29 06:41:26 --> Helper loaded: form_helper
INFO - 2023-07-29 06:41:26 --> Helper loaded: lang_helper
INFO - 2023-07-29 06:41:26 --> Helper loaded: security_helper
INFO - 2023-07-29 06:41:26 --> Helper loaded: cookie_helper
INFO - 2023-07-29 06:41:26 --> Database Driver Class Initialized
INFO - 2023-07-29 06:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 06:41:26 --> Parser Class Initialized
INFO - 2023-07-29 06:41:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 06:41:26 --> Pagination Class Initialized
INFO - 2023-07-29 06:41:26 --> Form Validation Class Initialized
INFO - 2023-07-29 06:41:26 --> Controller Class Initialized
INFO - 2023-07-29 06:41:26 --> Model Class Initialized
DEBUG - 2023-07-29 06:41:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 06:41:26 --> Model Class Initialized
DEBUG - 2023-07-29 06:41:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 06:41:26 --> Model Class Initialized
INFO - 2023-07-29 06:41:26 --> Model Class Initialized
INFO - 2023-07-29 06:41:26 --> Model Class Initialized
INFO - 2023-07-29 06:41:26 --> Model Class Initialized
DEBUG - 2023-07-29 06:41:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-29 06:41:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 06:41:26 --> Model Class Initialized
INFO - 2023-07-29 06:41:26 --> Model Class Initialized
INFO - 2023-07-29 06:41:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-29 06:41:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-29 06:41:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-29 06:41:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-29 06:41:26 --> Model Class Initialized
INFO - 2023-07-29 06:41:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-29 06:41:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-29 06:41:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-29 06:41:26 --> Final output sent to browser
DEBUG - 2023-07-29 06:41:26 --> Total execution time: 0.1820
ERROR - 2023-07-29 06:41:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 06:41:26 --> Config Class Initialized
INFO - 2023-07-29 06:41:26 --> Hooks Class Initialized
DEBUG - 2023-07-29 06:41:26 --> UTF-8 Support Enabled
INFO - 2023-07-29 06:41:26 --> Utf8 Class Initialized
INFO - 2023-07-29 06:41:26 --> URI Class Initialized
INFO - 2023-07-29 06:41:26 --> Router Class Initialized
INFO - 2023-07-29 06:41:26 --> Output Class Initialized
INFO - 2023-07-29 06:41:26 --> Security Class Initialized
DEBUG - 2023-07-29 06:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 06:41:26 --> Input Class Initialized
INFO - 2023-07-29 06:41:26 --> Language Class Initialized
INFO - 2023-07-29 06:41:26 --> Loader Class Initialized
INFO - 2023-07-29 06:41:26 --> Helper loaded: url_helper
INFO - 2023-07-29 06:41:26 --> Helper loaded: file_helper
INFO - 2023-07-29 06:41:26 --> Helper loaded: html_helper
INFO - 2023-07-29 06:41:26 --> Helper loaded: text_helper
INFO - 2023-07-29 06:41:26 --> Helper loaded: form_helper
INFO - 2023-07-29 06:41:26 --> Helper loaded: lang_helper
INFO - 2023-07-29 06:41:26 --> Helper loaded: security_helper
INFO - 2023-07-29 06:41:26 --> Helper loaded: cookie_helper
INFO - 2023-07-29 06:41:26 --> Database Driver Class Initialized
INFO - 2023-07-29 06:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 06:41:26 --> Parser Class Initialized
INFO - 2023-07-29 06:41:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 06:41:26 --> Pagination Class Initialized
INFO - 2023-07-29 06:41:26 --> Form Validation Class Initialized
INFO - 2023-07-29 06:41:26 --> Controller Class Initialized
DEBUG - 2023-07-29 06:41:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-29 06:41:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 06:41:26 --> Model Class Initialized
INFO - 2023-07-29 06:41:26 --> Final output sent to browser
DEBUG - 2023-07-29 06:41:26 --> Total execution time: 0.0155
ERROR - 2023-07-29 06:47:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 06:47:02 --> Config Class Initialized
INFO - 2023-07-29 06:47:02 --> Hooks Class Initialized
DEBUG - 2023-07-29 06:47:02 --> UTF-8 Support Enabled
INFO - 2023-07-29 06:47:02 --> Utf8 Class Initialized
INFO - 2023-07-29 06:47:02 --> URI Class Initialized
INFO - 2023-07-29 06:47:02 --> Router Class Initialized
INFO - 2023-07-29 06:47:02 --> Output Class Initialized
INFO - 2023-07-29 06:47:02 --> Security Class Initialized
DEBUG - 2023-07-29 06:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 06:47:02 --> Input Class Initialized
INFO - 2023-07-29 06:47:02 --> Language Class Initialized
INFO - 2023-07-29 06:47:02 --> Loader Class Initialized
INFO - 2023-07-29 06:47:02 --> Helper loaded: url_helper
INFO - 2023-07-29 06:47:02 --> Helper loaded: file_helper
INFO - 2023-07-29 06:47:02 --> Helper loaded: html_helper
INFO - 2023-07-29 06:47:02 --> Helper loaded: text_helper
INFO - 2023-07-29 06:47:02 --> Helper loaded: form_helper
INFO - 2023-07-29 06:47:02 --> Helper loaded: lang_helper
INFO - 2023-07-29 06:47:02 --> Helper loaded: security_helper
INFO - 2023-07-29 06:47:02 --> Helper loaded: cookie_helper
INFO - 2023-07-29 06:47:02 --> Database Driver Class Initialized
INFO - 2023-07-29 06:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 06:47:02 --> Parser Class Initialized
INFO - 2023-07-29 06:47:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 06:47:02 --> Pagination Class Initialized
INFO - 2023-07-29 06:47:02 --> Form Validation Class Initialized
INFO - 2023-07-29 06:47:02 --> Controller Class Initialized
INFO - 2023-07-29 06:47:02 --> Model Class Initialized
DEBUG - 2023-07-29 06:47:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-29 06:47:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 06:47:02 --> Model Class Initialized
DEBUG - 2023-07-29 06:47:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 06:47:02 --> Model Class Initialized
INFO - 2023-07-29 06:47:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-29 06:47:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-29 06:47:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-29 06:47:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-29 06:47:02 --> Model Class Initialized
INFO - 2023-07-29 06:47:02 --> Model Class Initialized
INFO - 2023-07-29 06:47:02 --> Model Class Initialized
INFO - 2023-07-29 06:47:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-29 06:47:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-29 06:47:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-29 06:47:02 --> Final output sent to browser
DEBUG - 2023-07-29 06:47:02 --> Total execution time: 0.1580
ERROR - 2023-07-29 06:47:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 06:47:03 --> Config Class Initialized
INFO - 2023-07-29 06:47:03 --> Hooks Class Initialized
DEBUG - 2023-07-29 06:47:03 --> UTF-8 Support Enabled
INFO - 2023-07-29 06:47:03 --> Utf8 Class Initialized
INFO - 2023-07-29 06:47:03 --> URI Class Initialized
INFO - 2023-07-29 06:47:03 --> Router Class Initialized
INFO - 2023-07-29 06:47:03 --> Output Class Initialized
INFO - 2023-07-29 06:47:03 --> Security Class Initialized
DEBUG - 2023-07-29 06:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 06:47:03 --> Input Class Initialized
INFO - 2023-07-29 06:47:03 --> Language Class Initialized
INFO - 2023-07-29 06:47:03 --> Loader Class Initialized
INFO - 2023-07-29 06:47:03 --> Helper loaded: url_helper
INFO - 2023-07-29 06:47:03 --> Helper loaded: file_helper
INFO - 2023-07-29 06:47:03 --> Helper loaded: html_helper
INFO - 2023-07-29 06:47:03 --> Helper loaded: text_helper
INFO - 2023-07-29 06:47:03 --> Helper loaded: form_helper
INFO - 2023-07-29 06:47:03 --> Helper loaded: lang_helper
INFO - 2023-07-29 06:47:03 --> Helper loaded: security_helper
INFO - 2023-07-29 06:47:03 --> Helper loaded: cookie_helper
INFO - 2023-07-29 06:47:03 --> Database Driver Class Initialized
INFO - 2023-07-29 06:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 06:47:03 --> Parser Class Initialized
INFO - 2023-07-29 06:47:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 06:47:03 --> Pagination Class Initialized
INFO - 2023-07-29 06:47:03 --> Form Validation Class Initialized
INFO - 2023-07-29 06:47:03 --> Controller Class Initialized
INFO - 2023-07-29 06:47:03 --> Model Class Initialized
DEBUG - 2023-07-29 06:47:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-29 06:47:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 06:47:03 --> Model Class Initialized
DEBUG - 2023-07-29 06:47:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 06:47:03 --> Model Class Initialized
INFO - 2023-07-29 06:47:03 --> Final output sent to browser
DEBUG - 2023-07-29 06:47:03 --> Total execution time: 0.0693
ERROR - 2023-07-29 06:47:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 06:47:07 --> Config Class Initialized
INFO - 2023-07-29 06:47:07 --> Hooks Class Initialized
DEBUG - 2023-07-29 06:47:07 --> UTF-8 Support Enabled
INFO - 2023-07-29 06:47:07 --> Utf8 Class Initialized
INFO - 2023-07-29 06:47:07 --> URI Class Initialized
INFO - 2023-07-29 06:47:07 --> Router Class Initialized
INFO - 2023-07-29 06:47:07 --> Output Class Initialized
INFO - 2023-07-29 06:47:07 --> Security Class Initialized
DEBUG - 2023-07-29 06:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 06:47:07 --> Input Class Initialized
INFO - 2023-07-29 06:47:07 --> Language Class Initialized
INFO - 2023-07-29 06:47:07 --> Loader Class Initialized
INFO - 2023-07-29 06:47:07 --> Helper loaded: url_helper
INFO - 2023-07-29 06:47:07 --> Helper loaded: file_helper
INFO - 2023-07-29 06:47:07 --> Helper loaded: html_helper
INFO - 2023-07-29 06:47:07 --> Helper loaded: text_helper
INFO - 2023-07-29 06:47:07 --> Helper loaded: form_helper
INFO - 2023-07-29 06:47:07 --> Helper loaded: lang_helper
INFO - 2023-07-29 06:47:07 --> Helper loaded: security_helper
INFO - 2023-07-29 06:47:07 --> Helper loaded: cookie_helper
INFO - 2023-07-29 06:47:07 --> Database Driver Class Initialized
INFO - 2023-07-29 06:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 06:47:07 --> Parser Class Initialized
INFO - 2023-07-29 06:47:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 06:47:07 --> Pagination Class Initialized
INFO - 2023-07-29 06:47:07 --> Form Validation Class Initialized
INFO - 2023-07-29 06:47:07 --> Controller Class Initialized
INFO - 2023-07-29 06:47:07 --> Model Class Initialized
DEBUG - 2023-07-29 06:47:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-29 06:47:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 06:47:07 --> Model Class Initialized
DEBUG - 2023-07-29 06:47:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 06:47:07 --> Model Class Initialized
INFO - 2023-07-29 06:47:07 --> Final output sent to browser
DEBUG - 2023-07-29 06:47:07 --> Total execution time: 0.4119
ERROR - 2023-07-29 06:47:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 06:47:42 --> Config Class Initialized
INFO - 2023-07-29 06:47:42 --> Hooks Class Initialized
DEBUG - 2023-07-29 06:47:42 --> UTF-8 Support Enabled
INFO - 2023-07-29 06:47:42 --> Utf8 Class Initialized
INFO - 2023-07-29 06:47:42 --> URI Class Initialized
INFO - 2023-07-29 06:47:42 --> Router Class Initialized
INFO - 2023-07-29 06:47:42 --> Output Class Initialized
INFO - 2023-07-29 06:47:42 --> Security Class Initialized
DEBUG - 2023-07-29 06:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 06:47:42 --> Input Class Initialized
INFO - 2023-07-29 06:47:42 --> Language Class Initialized
INFO - 2023-07-29 06:47:42 --> Loader Class Initialized
INFO - 2023-07-29 06:47:42 --> Helper loaded: url_helper
INFO - 2023-07-29 06:47:42 --> Helper loaded: file_helper
INFO - 2023-07-29 06:47:42 --> Helper loaded: html_helper
INFO - 2023-07-29 06:47:42 --> Helper loaded: text_helper
INFO - 2023-07-29 06:47:42 --> Helper loaded: form_helper
INFO - 2023-07-29 06:47:42 --> Helper loaded: lang_helper
INFO - 2023-07-29 06:47:42 --> Helper loaded: security_helper
INFO - 2023-07-29 06:47:42 --> Helper loaded: cookie_helper
INFO - 2023-07-29 06:47:42 --> Database Driver Class Initialized
INFO - 2023-07-29 06:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 06:47:42 --> Parser Class Initialized
INFO - 2023-07-29 06:47:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 06:47:42 --> Pagination Class Initialized
INFO - 2023-07-29 06:47:42 --> Form Validation Class Initialized
INFO - 2023-07-29 06:47:42 --> Controller Class Initialized
INFO - 2023-07-29 06:47:42 --> Model Class Initialized
DEBUG - 2023-07-29 06:47:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-29 06:47:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 06:47:42 --> Model Class Initialized
DEBUG - 2023-07-29 06:47:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 06:47:42 --> Model Class Initialized
INFO - 2023-07-29 06:47:42 --> Final output sent to browser
DEBUG - 2023-07-29 06:47:42 --> Total execution time: 0.1404
ERROR - 2023-07-29 06:47:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 06:47:44 --> Config Class Initialized
INFO - 2023-07-29 06:47:44 --> Hooks Class Initialized
DEBUG - 2023-07-29 06:47:44 --> UTF-8 Support Enabled
INFO - 2023-07-29 06:47:44 --> Utf8 Class Initialized
INFO - 2023-07-29 06:47:44 --> URI Class Initialized
INFO - 2023-07-29 06:47:44 --> Router Class Initialized
INFO - 2023-07-29 06:47:44 --> Output Class Initialized
INFO - 2023-07-29 06:47:44 --> Security Class Initialized
DEBUG - 2023-07-29 06:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 06:47:44 --> Input Class Initialized
INFO - 2023-07-29 06:47:44 --> Language Class Initialized
INFO - 2023-07-29 06:47:44 --> Loader Class Initialized
INFO - 2023-07-29 06:47:44 --> Helper loaded: url_helper
INFO - 2023-07-29 06:47:44 --> Helper loaded: file_helper
INFO - 2023-07-29 06:47:44 --> Helper loaded: html_helper
INFO - 2023-07-29 06:47:44 --> Helper loaded: text_helper
INFO - 2023-07-29 06:47:44 --> Helper loaded: form_helper
INFO - 2023-07-29 06:47:44 --> Helper loaded: lang_helper
INFO - 2023-07-29 06:47:44 --> Helper loaded: security_helper
INFO - 2023-07-29 06:47:44 --> Helper loaded: cookie_helper
INFO - 2023-07-29 06:47:44 --> Database Driver Class Initialized
INFO - 2023-07-29 06:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 06:47:44 --> Parser Class Initialized
INFO - 2023-07-29 06:47:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 06:47:44 --> Pagination Class Initialized
INFO - 2023-07-29 06:47:44 --> Form Validation Class Initialized
INFO - 2023-07-29 06:47:44 --> Controller Class Initialized
INFO - 2023-07-29 06:47:44 --> Model Class Initialized
DEBUG - 2023-07-29 06:47:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-29 06:47:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 06:47:44 --> Model Class Initialized
DEBUG - 2023-07-29 06:47:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 06:47:44 --> Model Class Initialized
INFO - 2023-07-29 06:47:45 --> Final output sent to browser
DEBUG - 2023-07-29 06:47:45 --> Total execution time: 0.1142
ERROR - 2023-07-29 06:58:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 06:58:21 --> Config Class Initialized
INFO - 2023-07-29 06:58:21 --> Hooks Class Initialized
DEBUG - 2023-07-29 06:58:21 --> UTF-8 Support Enabled
INFO - 2023-07-29 06:58:21 --> Utf8 Class Initialized
INFO - 2023-07-29 06:58:21 --> URI Class Initialized
DEBUG - 2023-07-29 06:58:21 --> No URI present. Default controller set.
INFO - 2023-07-29 06:58:21 --> Router Class Initialized
INFO - 2023-07-29 06:58:21 --> Output Class Initialized
INFO - 2023-07-29 06:58:21 --> Security Class Initialized
DEBUG - 2023-07-29 06:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 06:58:21 --> Input Class Initialized
INFO - 2023-07-29 06:58:21 --> Language Class Initialized
INFO - 2023-07-29 06:58:21 --> Loader Class Initialized
INFO - 2023-07-29 06:58:21 --> Helper loaded: url_helper
INFO - 2023-07-29 06:58:21 --> Helper loaded: file_helper
INFO - 2023-07-29 06:58:21 --> Helper loaded: html_helper
INFO - 2023-07-29 06:58:21 --> Helper loaded: text_helper
INFO - 2023-07-29 06:58:21 --> Helper loaded: form_helper
INFO - 2023-07-29 06:58:21 --> Helper loaded: lang_helper
INFO - 2023-07-29 06:58:21 --> Helper loaded: security_helper
INFO - 2023-07-29 06:58:21 --> Helper loaded: cookie_helper
INFO - 2023-07-29 06:58:21 --> Database Driver Class Initialized
INFO - 2023-07-29 06:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 06:58:21 --> Parser Class Initialized
INFO - 2023-07-29 06:58:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 06:58:21 --> Pagination Class Initialized
INFO - 2023-07-29 06:58:21 --> Form Validation Class Initialized
INFO - 2023-07-29 06:58:21 --> Controller Class Initialized
INFO - 2023-07-29 06:58:21 --> Model Class Initialized
DEBUG - 2023-07-29 06:58:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-29 07:00:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 07:00:24 --> Config Class Initialized
INFO - 2023-07-29 07:00:24 --> Hooks Class Initialized
DEBUG - 2023-07-29 07:00:24 --> UTF-8 Support Enabled
INFO - 2023-07-29 07:00:24 --> Utf8 Class Initialized
INFO - 2023-07-29 07:00:24 --> URI Class Initialized
DEBUG - 2023-07-29 07:00:24 --> No URI present. Default controller set.
INFO - 2023-07-29 07:00:24 --> Router Class Initialized
INFO - 2023-07-29 07:00:24 --> Output Class Initialized
INFO - 2023-07-29 07:00:24 --> Security Class Initialized
DEBUG - 2023-07-29 07:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 07:00:24 --> Input Class Initialized
INFO - 2023-07-29 07:00:24 --> Language Class Initialized
INFO - 2023-07-29 07:00:24 --> Loader Class Initialized
INFO - 2023-07-29 07:00:24 --> Helper loaded: url_helper
INFO - 2023-07-29 07:00:24 --> Helper loaded: file_helper
INFO - 2023-07-29 07:00:24 --> Helper loaded: html_helper
INFO - 2023-07-29 07:00:24 --> Helper loaded: text_helper
INFO - 2023-07-29 07:00:24 --> Helper loaded: form_helper
INFO - 2023-07-29 07:00:24 --> Helper loaded: lang_helper
INFO - 2023-07-29 07:00:24 --> Helper loaded: security_helper
INFO - 2023-07-29 07:00:24 --> Helper loaded: cookie_helper
INFO - 2023-07-29 07:00:24 --> Database Driver Class Initialized
INFO - 2023-07-29 07:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 07:00:24 --> Parser Class Initialized
INFO - 2023-07-29 07:00:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 07:00:24 --> Pagination Class Initialized
INFO - 2023-07-29 07:00:24 --> Form Validation Class Initialized
INFO - 2023-07-29 07:00:24 --> Controller Class Initialized
INFO - 2023-07-29 07:00:24 --> Model Class Initialized
DEBUG - 2023-07-29 07:00:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-29 07:00:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 07:00:28 --> Config Class Initialized
INFO - 2023-07-29 07:00:28 --> Hooks Class Initialized
DEBUG - 2023-07-29 07:00:28 --> UTF-8 Support Enabled
INFO - 2023-07-29 07:00:28 --> Utf8 Class Initialized
INFO - 2023-07-29 07:00:28 --> URI Class Initialized
DEBUG - 2023-07-29 07:00:28 --> No URI present. Default controller set.
INFO - 2023-07-29 07:00:28 --> Router Class Initialized
INFO - 2023-07-29 07:00:28 --> Output Class Initialized
INFO - 2023-07-29 07:00:28 --> Security Class Initialized
DEBUG - 2023-07-29 07:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 07:00:28 --> Input Class Initialized
INFO - 2023-07-29 07:00:28 --> Language Class Initialized
INFO - 2023-07-29 07:00:28 --> Loader Class Initialized
INFO - 2023-07-29 07:00:28 --> Helper loaded: url_helper
INFO - 2023-07-29 07:00:28 --> Helper loaded: file_helper
INFO - 2023-07-29 07:00:28 --> Helper loaded: html_helper
INFO - 2023-07-29 07:00:28 --> Helper loaded: text_helper
INFO - 2023-07-29 07:00:28 --> Helper loaded: form_helper
INFO - 2023-07-29 07:00:28 --> Helper loaded: lang_helper
INFO - 2023-07-29 07:00:28 --> Helper loaded: security_helper
INFO - 2023-07-29 07:00:28 --> Helper loaded: cookie_helper
INFO - 2023-07-29 07:00:28 --> Database Driver Class Initialized
INFO - 2023-07-29 07:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 07:00:28 --> Parser Class Initialized
INFO - 2023-07-29 07:00:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 07:00:28 --> Pagination Class Initialized
INFO - 2023-07-29 07:00:28 --> Form Validation Class Initialized
INFO - 2023-07-29 07:00:28 --> Controller Class Initialized
INFO - 2023-07-29 07:00:28 --> Model Class Initialized
DEBUG - 2023-07-29 07:00:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-29 08:50:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 08:50:39 --> Config Class Initialized
INFO - 2023-07-29 08:50:39 --> Hooks Class Initialized
DEBUG - 2023-07-29 08:50:39 --> UTF-8 Support Enabled
INFO - 2023-07-29 08:50:39 --> Utf8 Class Initialized
INFO - 2023-07-29 08:50:39 --> URI Class Initialized
DEBUG - 2023-07-29 08:50:39 --> No URI present. Default controller set.
INFO - 2023-07-29 08:50:39 --> Router Class Initialized
INFO - 2023-07-29 08:50:39 --> Output Class Initialized
INFO - 2023-07-29 08:50:39 --> Security Class Initialized
DEBUG - 2023-07-29 08:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 08:50:39 --> Input Class Initialized
INFO - 2023-07-29 08:50:39 --> Language Class Initialized
INFO - 2023-07-29 08:50:39 --> Loader Class Initialized
INFO - 2023-07-29 08:50:39 --> Helper loaded: url_helper
INFO - 2023-07-29 08:50:39 --> Helper loaded: file_helper
INFO - 2023-07-29 08:50:39 --> Helper loaded: html_helper
INFO - 2023-07-29 08:50:39 --> Helper loaded: text_helper
INFO - 2023-07-29 08:50:39 --> Helper loaded: form_helper
INFO - 2023-07-29 08:50:39 --> Helper loaded: lang_helper
INFO - 2023-07-29 08:50:39 --> Helper loaded: security_helper
INFO - 2023-07-29 08:50:39 --> Helper loaded: cookie_helper
INFO - 2023-07-29 08:50:39 --> Database Driver Class Initialized
INFO - 2023-07-29 08:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 08:50:39 --> Parser Class Initialized
INFO - 2023-07-29 08:50:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 08:50:39 --> Pagination Class Initialized
INFO - 2023-07-29 08:50:39 --> Form Validation Class Initialized
INFO - 2023-07-29 08:50:39 --> Controller Class Initialized
INFO - 2023-07-29 08:50:39 --> Model Class Initialized
DEBUG - 2023-07-29 08:50:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-29 08:50:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 08:50:40 --> Config Class Initialized
INFO - 2023-07-29 08:50:40 --> Hooks Class Initialized
DEBUG - 2023-07-29 08:50:40 --> UTF-8 Support Enabled
INFO - 2023-07-29 08:50:40 --> Utf8 Class Initialized
INFO - 2023-07-29 08:50:40 --> URI Class Initialized
INFO - 2023-07-29 08:50:40 --> Router Class Initialized
INFO - 2023-07-29 08:50:40 --> Output Class Initialized
INFO - 2023-07-29 08:50:40 --> Security Class Initialized
DEBUG - 2023-07-29 08:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 08:50:40 --> Input Class Initialized
INFO - 2023-07-29 08:50:40 --> Language Class Initialized
INFO - 2023-07-29 08:50:40 --> Loader Class Initialized
INFO - 2023-07-29 08:50:40 --> Helper loaded: url_helper
INFO - 2023-07-29 08:50:40 --> Helper loaded: file_helper
INFO - 2023-07-29 08:50:40 --> Helper loaded: html_helper
INFO - 2023-07-29 08:50:40 --> Helper loaded: text_helper
INFO - 2023-07-29 08:50:40 --> Helper loaded: form_helper
INFO - 2023-07-29 08:50:40 --> Helper loaded: lang_helper
INFO - 2023-07-29 08:50:40 --> Helper loaded: security_helper
INFO - 2023-07-29 08:50:40 --> Helper loaded: cookie_helper
INFO - 2023-07-29 08:50:40 --> Database Driver Class Initialized
INFO - 2023-07-29 08:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 08:50:40 --> Parser Class Initialized
INFO - 2023-07-29 08:50:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 08:50:40 --> Pagination Class Initialized
INFO - 2023-07-29 08:50:40 --> Form Validation Class Initialized
INFO - 2023-07-29 08:50:40 --> Controller Class Initialized
INFO - 2023-07-29 08:50:40 --> Model Class Initialized
DEBUG - 2023-07-29 08:50:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 08:50:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-29 08:50:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-29 08:50:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-29 08:50:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-29 08:50:40 --> Model Class Initialized
INFO - 2023-07-29 08:50:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-29 08:50:40 --> Final output sent to browser
DEBUG - 2023-07-29 08:50:40 --> Total execution time: 0.0339
ERROR - 2023-07-29 08:50:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 08:50:50 --> Config Class Initialized
INFO - 2023-07-29 08:50:50 --> Hooks Class Initialized
DEBUG - 2023-07-29 08:50:50 --> UTF-8 Support Enabled
INFO - 2023-07-29 08:50:50 --> Utf8 Class Initialized
INFO - 2023-07-29 08:50:50 --> URI Class Initialized
INFO - 2023-07-29 08:50:50 --> Router Class Initialized
INFO - 2023-07-29 08:50:50 --> Output Class Initialized
INFO - 2023-07-29 08:50:50 --> Security Class Initialized
DEBUG - 2023-07-29 08:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 08:50:50 --> Input Class Initialized
INFO - 2023-07-29 08:50:50 --> Language Class Initialized
INFO - 2023-07-29 08:50:50 --> Loader Class Initialized
INFO - 2023-07-29 08:50:50 --> Helper loaded: url_helper
INFO - 2023-07-29 08:50:50 --> Helper loaded: file_helper
INFO - 2023-07-29 08:50:50 --> Helper loaded: html_helper
INFO - 2023-07-29 08:50:50 --> Helper loaded: text_helper
INFO - 2023-07-29 08:50:50 --> Helper loaded: form_helper
INFO - 2023-07-29 08:50:50 --> Helper loaded: lang_helper
INFO - 2023-07-29 08:50:50 --> Helper loaded: security_helper
INFO - 2023-07-29 08:50:50 --> Helper loaded: cookie_helper
INFO - 2023-07-29 08:50:50 --> Database Driver Class Initialized
INFO - 2023-07-29 08:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 08:50:50 --> Parser Class Initialized
INFO - 2023-07-29 08:50:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 08:50:50 --> Pagination Class Initialized
INFO - 2023-07-29 08:50:50 --> Form Validation Class Initialized
INFO - 2023-07-29 08:50:50 --> Controller Class Initialized
INFO - 2023-07-29 08:50:50 --> Model Class Initialized
DEBUG - 2023-07-29 08:50:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 08:50:50 --> Model Class Initialized
INFO - 2023-07-29 08:50:50 --> Final output sent to browser
DEBUG - 2023-07-29 08:50:50 --> Total execution time: 0.0191
ERROR - 2023-07-29 08:50:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 08:50:53 --> Config Class Initialized
INFO - 2023-07-29 08:50:53 --> Hooks Class Initialized
DEBUG - 2023-07-29 08:50:53 --> UTF-8 Support Enabled
INFO - 2023-07-29 08:50:53 --> Utf8 Class Initialized
INFO - 2023-07-29 08:50:53 --> URI Class Initialized
DEBUG - 2023-07-29 08:50:53 --> No URI present. Default controller set.
INFO - 2023-07-29 08:50:53 --> Router Class Initialized
INFO - 2023-07-29 08:50:53 --> Output Class Initialized
INFO - 2023-07-29 08:50:53 --> Security Class Initialized
DEBUG - 2023-07-29 08:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 08:50:53 --> Input Class Initialized
INFO - 2023-07-29 08:50:53 --> Language Class Initialized
INFO - 2023-07-29 08:50:53 --> Loader Class Initialized
INFO - 2023-07-29 08:50:53 --> Helper loaded: url_helper
INFO - 2023-07-29 08:50:53 --> Helper loaded: file_helper
INFO - 2023-07-29 08:50:53 --> Helper loaded: html_helper
INFO - 2023-07-29 08:50:53 --> Helper loaded: text_helper
INFO - 2023-07-29 08:50:53 --> Helper loaded: form_helper
INFO - 2023-07-29 08:50:53 --> Helper loaded: lang_helper
INFO - 2023-07-29 08:50:53 --> Helper loaded: security_helper
INFO - 2023-07-29 08:50:53 --> Helper loaded: cookie_helper
INFO - 2023-07-29 08:50:53 --> Database Driver Class Initialized
INFO - 2023-07-29 08:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 08:50:53 --> Parser Class Initialized
INFO - 2023-07-29 08:50:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 08:50:53 --> Pagination Class Initialized
INFO - 2023-07-29 08:50:53 --> Form Validation Class Initialized
INFO - 2023-07-29 08:50:53 --> Controller Class Initialized
INFO - 2023-07-29 08:50:53 --> Model Class Initialized
DEBUG - 2023-07-29 08:50:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 08:50:53 --> Model Class Initialized
DEBUG - 2023-07-29 08:50:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 08:50:53 --> Model Class Initialized
INFO - 2023-07-29 08:50:53 --> Model Class Initialized
INFO - 2023-07-29 08:50:53 --> Model Class Initialized
INFO - 2023-07-29 08:50:53 --> Model Class Initialized
DEBUG - 2023-07-29 08:50:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-29 08:50:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 08:50:53 --> Model Class Initialized
INFO - 2023-07-29 08:50:53 --> Model Class Initialized
INFO - 2023-07-29 08:50:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-29 08:50:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-29 08:50:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-29 08:50:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-29 08:50:53 --> Model Class Initialized
INFO - 2023-07-29 08:50:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-29 08:50:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-29 08:50:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-29 08:50:53 --> Final output sent to browser
DEBUG - 2023-07-29 08:50:53 --> Total execution time: 0.0863
ERROR - 2023-07-29 08:51:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 08:51:57 --> Config Class Initialized
INFO - 2023-07-29 08:51:57 --> Hooks Class Initialized
DEBUG - 2023-07-29 08:51:57 --> UTF-8 Support Enabled
INFO - 2023-07-29 08:51:57 --> Utf8 Class Initialized
INFO - 2023-07-29 08:51:57 --> URI Class Initialized
INFO - 2023-07-29 08:51:57 --> Router Class Initialized
INFO - 2023-07-29 08:51:57 --> Output Class Initialized
INFO - 2023-07-29 08:51:57 --> Security Class Initialized
DEBUG - 2023-07-29 08:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 08:51:57 --> Input Class Initialized
INFO - 2023-07-29 08:51:57 --> Language Class Initialized
INFO - 2023-07-29 08:51:57 --> Loader Class Initialized
INFO - 2023-07-29 08:51:57 --> Helper loaded: url_helper
INFO - 2023-07-29 08:51:57 --> Helper loaded: file_helper
INFO - 2023-07-29 08:51:57 --> Helper loaded: html_helper
INFO - 2023-07-29 08:51:57 --> Helper loaded: text_helper
INFO - 2023-07-29 08:51:57 --> Helper loaded: form_helper
INFO - 2023-07-29 08:51:57 --> Helper loaded: lang_helper
INFO - 2023-07-29 08:51:57 --> Helper loaded: security_helper
INFO - 2023-07-29 08:51:57 --> Helper loaded: cookie_helper
INFO - 2023-07-29 08:51:57 --> Database Driver Class Initialized
INFO - 2023-07-29 08:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 08:51:57 --> Parser Class Initialized
INFO - 2023-07-29 08:51:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 08:51:57 --> Pagination Class Initialized
INFO - 2023-07-29 08:51:57 --> Form Validation Class Initialized
INFO - 2023-07-29 08:51:57 --> Controller Class Initialized
INFO - 2023-07-29 08:51:57 --> Model Class Initialized
DEBUG - 2023-07-29 08:51:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-29 08:51:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 08:51:57 --> Model Class Initialized
DEBUG - 2023-07-29 08:51:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 08:51:57 --> Model Class Initialized
INFO - 2023-07-29 08:51:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-29 08:51:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-29 08:51:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-29 08:51:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-29 08:51:57 --> Model Class Initialized
INFO - 2023-07-29 08:51:57 --> Model Class Initialized
INFO - 2023-07-29 08:51:57 --> Model Class Initialized
INFO - 2023-07-29 08:51:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-29 08:51:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-29 08:51:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-29 08:51:57 --> Final output sent to browser
DEBUG - 2023-07-29 08:51:57 --> Total execution time: 0.0773
ERROR - 2023-07-29 08:51:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 08:51:58 --> Config Class Initialized
INFO - 2023-07-29 08:51:58 --> Hooks Class Initialized
DEBUG - 2023-07-29 08:51:58 --> UTF-8 Support Enabled
INFO - 2023-07-29 08:51:58 --> Utf8 Class Initialized
INFO - 2023-07-29 08:51:58 --> URI Class Initialized
INFO - 2023-07-29 08:51:58 --> Router Class Initialized
INFO - 2023-07-29 08:51:58 --> Output Class Initialized
INFO - 2023-07-29 08:51:58 --> Security Class Initialized
DEBUG - 2023-07-29 08:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 08:51:58 --> Input Class Initialized
INFO - 2023-07-29 08:51:58 --> Language Class Initialized
INFO - 2023-07-29 08:51:58 --> Loader Class Initialized
INFO - 2023-07-29 08:51:58 --> Helper loaded: url_helper
INFO - 2023-07-29 08:51:58 --> Helper loaded: file_helper
INFO - 2023-07-29 08:51:58 --> Helper loaded: html_helper
INFO - 2023-07-29 08:51:58 --> Helper loaded: text_helper
INFO - 2023-07-29 08:51:58 --> Helper loaded: form_helper
INFO - 2023-07-29 08:51:58 --> Helper loaded: lang_helper
INFO - 2023-07-29 08:51:58 --> Helper loaded: security_helper
INFO - 2023-07-29 08:51:58 --> Helper loaded: cookie_helper
INFO - 2023-07-29 08:51:58 --> Database Driver Class Initialized
INFO - 2023-07-29 08:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 08:51:58 --> Parser Class Initialized
INFO - 2023-07-29 08:51:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 08:51:58 --> Pagination Class Initialized
INFO - 2023-07-29 08:51:58 --> Form Validation Class Initialized
INFO - 2023-07-29 08:51:58 --> Controller Class Initialized
INFO - 2023-07-29 08:51:58 --> Model Class Initialized
DEBUG - 2023-07-29 08:51:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-29 08:51:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 08:51:58 --> Model Class Initialized
DEBUG - 2023-07-29 08:51:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 08:51:58 --> Model Class Initialized
INFO - 2023-07-29 08:51:58 --> Final output sent to browser
DEBUG - 2023-07-29 08:51:58 --> Total execution time: 0.0236
ERROR - 2023-07-29 08:52:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 08:52:22 --> Config Class Initialized
INFO - 2023-07-29 08:52:22 --> Hooks Class Initialized
DEBUG - 2023-07-29 08:52:22 --> UTF-8 Support Enabled
INFO - 2023-07-29 08:52:22 --> Utf8 Class Initialized
INFO - 2023-07-29 08:52:22 --> URI Class Initialized
INFO - 2023-07-29 08:52:22 --> Router Class Initialized
INFO - 2023-07-29 08:52:22 --> Output Class Initialized
INFO - 2023-07-29 08:52:22 --> Security Class Initialized
DEBUG - 2023-07-29 08:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 08:52:22 --> Input Class Initialized
INFO - 2023-07-29 08:52:22 --> Language Class Initialized
INFO - 2023-07-29 08:52:22 --> Loader Class Initialized
INFO - 2023-07-29 08:52:22 --> Helper loaded: url_helper
INFO - 2023-07-29 08:52:22 --> Helper loaded: file_helper
INFO - 2023-07-29 08:52:22 --> Helper loaded: html_helper
INFO - 2023-07-29 08:52:22 --> Helper loaded: text_helper
INFO - 2023-07-29 08:52:22 --> Helper loaded: form_helper
INFO - 2023-07-29 08:52:22 --> Helper loaded: lang_helper
INFO - 2023-07-29 08:52:22 --> Helper loaded: security_helper
INFO - 2023-07-29 08:52:22 --> Helper loaded: cookie_helper
INFO - 2023-07-29 08:52:22 --> Database Driver Class Initialized
INFO - 2023-07-29 08:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 08:52:22 --> Parser Class Initialized
INFO - 2023-07-29 08:52:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 08:52:22 --> Pagination Class Initialized
INFO - 2023-07-29 08:52:22 --> Form Validation Class Initialized
INFO - 2023-07-29 08:52:22 --> Controller Class Initialized
INFO - 2023-07-29 08:52:22 --> Model Class Initialized
DEBUG - 2023-07-29 08:52:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-29 08:52:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 08:52:22 --> Model Class Initialized
DEBUG - 2023-07-29 08:52:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 08:52:22 --> Model Class Initialized
INFO - 2023-07-29 08:52:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html.php
DEBUG - 2023-07-29 08:52:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-29 08:52:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-29 08:52:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-29 08:52:22 --> Model Class Initialized
INFO - 2023-07-29 08:52:22 --> Model Class Initialized
INFO - 2023-07-29 08:52:22 --> Model Class Initialized
INFO - 2023-07-29 08:52:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-29 08:52:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-29 08:52:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-29 08:52:22 --> Final output sent to browser
DEBUG - 2023-07-29 08:52:22 --> Total execution time: 0.0853
ERROR - 2023-07-29 08:53:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 08:53:39 --> Config Class Initialized
INFO - 2023-07-29 08:53:39 --> Hooks Class Initialized
DEBUG - 2023-07-29 08:53:39 --> UTF-8 Support Enabled
INFO - 2023-07-29 08:53:39 --> Utf8 Class Initialized
INFO - 2023-07-29 08:53:39 --> URI Class Initialized
INFO - 2023-07-29 08:53:39 --> Router Class Initialized
INFO - 2023-07-29 08:53:39 --> Output Class Initialized
INFO - 2023-07-29 08:53:39 --> Security Class Initialized
DEBUG - 2023-07-29 08:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 08:53:39 --> Input Class Initialized
INFO - 2023-07-29 08:53:39 --> Language Class Initialized
INFO - 2023-07-29 08:53:39 --> Loader Class Initialized
INFO - 2023-07-29 08:53:39 --> Helper loaded: url_helper
INFO - 2023-07-29 08:53:39 --> Helper loaded: file_helper
INFO - 2023-07-29 08:53:39 --> Helper loaded: html_helper
INFO - 2023-07-29 08:53:39 --> Helper loaded: text_helper
INFO - 2023-07-29 08:53:39 --> Helper loaded: form_helper
INFO - 2023-07-29 08:53:39 --> Helper loaded: lang_helper
INFO - 2023-07-29 08:53:39 --> Helper loaded: security_helper
INFO - 2023-07-29 08:53:39 --> Helper loaded: cookie_helper
INFO - 2023-07-29 08:53:39 --> Database Driver Class Initialized
INFO - 2023-07-29 08:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 08:53:39 --> Parser Class Initialized
INFO - 2023-07-29 08:53:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 08:53:39 --> Pagination Class Initialized
INFO - 2023-07-29 08:53:39 --> Form Validation Class Initialized
INFO - 2023-07-29 08:53:39 --> Controller Class Initialized
INFO - 2023-07-29 08:53:39 --> Model Class Initialized
DEBUG - 2023-07-29 08:53:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-29 08:53:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 08:53:39 --> Model Class Initialized
DEBUG - 2023-07-29 08:53:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 08:53:39 --> Model Class Initialized
INFO - 2023-07-29 08:53:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-29 08:53:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-29 08:53:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-29 08:53:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-29 08:53:39 --> Model Class Initialized
INFO - 2023-07-29 08:53:39 --> Model Class Initialized
INFO - 2023-07-29 08:53:39 --> Model Class Initialized
INFO - 2023-07-29 08:53:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-29 08:53:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-29 08:53:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-29 08:53:40 --> Final output sent to browser
DEBUG - 2023-07-29 08:53:40 --> Total execution time: 0.0816
ERROR - 2023-07-29 08:53:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 08:53:40 --> Config Class Initialized
INFO - 2023-07-29 08:53:40 --> Hooks Class Initialized
DEBUG - 2023-07-29 08:53:40 --> UTF-8 Support Enabled
INFO - 2023-07-29 08:53:40 --> Utf8 Class Initialized
INFO - 2023-07-29 08:53:40 --> URI Class Initialized
INFO - 2023-07-29 08:53:40 --> Router Class Initialized
INFO - 2023-07-29 08:53:40 --> Output Class Initialized
INFO - 2023-07-29 08:53:40 --> Security Class Initialized
DEBUG - 2023-07-29 08:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 08:53:40 --> Input Class Initialized
INFO - 2023-07-29 08:53:40 --> Language Class Initialized
INFO - 2023-07-29 08:53:40 --> Loader Class Initialized
INFO - 2023-07-29 08:53:40 --> Helper loaded: url_helper
INFO - 2023-07-29 08:53:40 --> Helper loaded: file_helper
INFO - 2023-07-29 08:53:40 --> Helper loaded: html_helper
INFO - 2023-07-29 08:53:40 --> Helper loaded: text_helper
INFO - 2023-07-29 08:53:40 --> Helper loaded: form_helper
INFO - 2023-07-29 08:53:40 --> Helper loaded: lang_helper
INFO - 2023-07-29 08:53:40 --> Helper loaded: security_helper
INFO - 2023-07-29 08:53:40 --> Helper loaded: cookie_helper
INFO - 2023-07-29 08:53:40 --> Database Driver Class Initialized
INFO - 2023-07-29 08:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 08:53:40 --> Parser Class Initialized
INFO - 2023-07-29 08:53:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 08:53:40 --> Pagination Class Initialized
INFO - 2023-07-29 08:53:40 --> Form Validation Class Initialized
INFO - 2023-07-29 08:53:40 --> Controller Class Initialized
INFO - 2023-07-29 08:53:40 --> Model Class Initialized
DEBUG - 2023-07-29 08:53:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-29 08:53:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 08:53:40 --> Model Class Initialized
DEBUG - 2023-07-29 08:53:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 08:53:40 --> Model Class Initialized
INFO - 2023-07-29 08:53:40 --> Final output sent to browser
DEBUG - 2023-07-29 08:53:40 --> Total execution time: 0.0300
ERROR - 2023-07-29 08:53:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 08:53:42 --> Config Class Initialized
INFO - 2023-07-29 08:53:42 --> Hooks Class Initialized
DEBUG - 2023-07-29 08:53:42 --> UTF-8 Support Enabled
INFO - 2023-07-29 08:53:42 --> Utf8 Class Initialized
INFO - 2023-07-29 08:53:42 --> URI Class Initialized
DEBUG - 2023-07-29 08:53:42 --> No URI present. Default controller set.
INFO - 2023-07-29 08:53:42 --> Router Class Initialized
INFO - 2023-07-29 08:53:42 --> Output Class Initialized
INFO - 2023-07-29 08:53:42 --> Security Class Initialized
DEBUG - 2023-07-29 08:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 08:53:42 --> Input Class Initialized
INFO - 2023-07-29 08:53:42 --> Language Class Initialized
INFO - 2023-07-29 08:53:42 --> Loader Class Initialized
INFO - 2023-07-29 08:53:42 --> Helper loaded: url_helper
INFO - 2023-07-29 08:53:42 --> Helper loaded: file_helper
INFO - 2023-07-29 08:53:42 --> Helper loaded: html_helper
INFO - 2023-07-29 08:53:42 --> Helper loaded: text_helper
INFO - 2023-07-29 08:53:42 --> Helper loaded: form_helper
INFO - 2023-07-29 08:53:42 --> Helper loaded: lang_helper
INFO - 2023-07-29 08:53:42 --> Helper loaded: security_helper
INFO - 2023-07-29 08:53:42 --> Helper loaded: cookie_helper
INFO - 2023-07-29 08:53:42 --> Database Driver Class Initialized
INFO - 2023-07-29 08:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 08:53:42 --> Parser Class Initialized
INFO - 2023-07-29 08:53:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 08:53:42 --> Pagination Class Initialized
INFO - 2023-07-29 08:53:42 --> Form Validation Class Initialized
INFO - 2023-07-29 08:53:42 --> Controller Class Initialized
INFO - 2023-07-29 08:53:42 --> Model Class Initialized
DEBUG - 2023-07-29 08:53:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 08:53:42 --> Model Class Initialized
DEBUG - 2023-07-29 08:53:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 08:53:42 --> Model Class Initialized
INFO - 2023-07-29 08:53:42 --> Model Class Initialized
INFO - 2023-07-29 08:53:42 --> Model Class Initialized
INFO - 2023-07-29 08:53:42 --> Model Class Initialized
DEBUG - 2023-07-29 08:53:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-29 08:53:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 08:53:42 --> Model Class Initialized
INFO - 2023-07-29 08:53:42 --> Model Class Initialized
INFO - 2023-07-29 08:53:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-29 08:53:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-29 08:53:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-29 08:53:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-29 08:53:42 --> Model Class Initialized
INFO - 2023-07-29 08:53:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-29 08:53:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-29 08:53:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-29 08:53:42 --> Final output sent to browser
DEBUG - 2023-07-29 08:53:42 --> Total execution time: 0.0830
ERROR - 2023-07-29 08:53:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 08:53:44 --> Config Class Initialized
INFO - 2023-07-29 08:53:44 --> Hooks Class Initialized
DEBUG - 2023-07-29 08:53:44 --> UTF-8 Support Enabled
INFO - 2023-07-29 08:53:44 --> Utf8 Class Initialized
INFO - 2023-07-29 08:53:44 --> URI Class Initialized
INFO - 2023-07-29 08:53:44 --> Router Class Initialized
INFO - 2023-07-29 08:53:44 --> Output Class Initialized
INFO - 2023-07-29 08:53:44 --> Security Class Initialized
DEBUG - 2023-07-29 08:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 08:53:44 --> Input Class Initialized
INFO - 2023-07-29 08:53:44 --> Language Class Initialized
INFO - 2023-07-29 08:53:44 --> Loader Class Initialized
INFO - 2023-07-29 08:53:44 --> Helper loaded: url_helper
INFO - 2023-07-29 08:53:44 --> Helper loaded: file_helper
INFO - 2023-07-29 08:53:44 --> Helper loaded: html_helper
INFO - 2023-07-29 08:53:44 --> Helper loaded: text_helper
INFO - 2023-07-29 08:53:44 --> Helper loaded: form_helper
INFO - 2023-07-29 08:53:44 --> Helper loaded: lang_helper
INFO - 2023-07-29 08:53:44 --> Helper loaded: security_helper
INFO - 2023-07-29 08:53:44 --> Helper loaded: cookie_helper
INFO - 2023-07-29 08:53:44 --> Database Driver Class Initialized
INFO - 2023-07-29 08:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 08:53:44 --> Parser Class Initialized
INFO - 2023-07-29 08:53:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 08:53:44 --> Pagination Class Initialized
INFO - 2023-07-29 08:53:44 --> Form Validation Class Initialized
INFO - 2023-07-29 08:53:44 --> Controller Class Initialized
INFO - 2023-07-29 08:53:44 --> Model Class Initialized
DEBUG - 2023-07-29 08:53:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 08:53:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-29 08:53:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-29 08:53:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-29 08:53:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-29 08:53:44 --> Model Class Initialized
INFO - 2023-07-29 08:53:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-29 08:53:44 --> Final output sent to browser
DEBUG - 2023-07-29 08:53:44 --> Total execution time: 0.0282
ERROR - 2023-07-29 08:53:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 08:53:44 --> Config Class Initialized
INFO - 2023-07-29 08:53:44 --> Hooks Class Initialized
DEBUG - 2023-07-29 08:53:44 --> UTF-8 Support Enabled
INFO - 2023-07-29 08:53:44 --> Utf8 Class Initialized
INFO - 2023-07-29 08:53:44 --> URI Class Initialized
INFO - 2023-07-29 08:53:44 --> Router Class Initialized
INFO - 2023-07-29 08:53:44 --> Output Class Initialized
INFO - 2023-07-29 08:53:44 --> Security Class Initialized
DEBUG - 2023-07-29 08:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 08:53:44 --> Input Class Initialized
INFO - 2023-07-29 08:53:44 --> Language Class Initialized
INFO - 2023-07-29 08:53:44 --> Loader Class Initialized
INFO - 2023-07-29 08:53:44 --> Helper loaded: url_helper
INFO - 2023-07-29 08:53:44 --> Helper loaded: file_helper
INFO - 2023-07-29 08:53:44 --> Helper loaded: html_helper
INFO - 2023-07-29 08:53:44 --> Helper loaded: text_helper
INFO - 2023-07-29 08:53:44 --> Helper loaded: form_helper
INFO - 2023-07-29 08:53:44 --> Helper loaded: lang_helper
INFO - 2023-07-29 08:53:44 --> Helper loaded: security_helper
INFO - 2023-07-29 08:53:44 --> Helper loaded: cookie_helper
INFO - 2023-07-29 08:53:44 --> Database Driver Class Initialized
INFO - 2023-07-29 08:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 08:53:44 --> Parser Class Initialized
INFO - 2023-07-29 08:53:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 08:53:44 --> Pagination Class Initialized
INFO - 2023-07-29 08:53:44 --> Form Validation Class Initialized
INFO - 2023-07-29 08:53:44 --> Controller Class Initialized
INFO - 2023-07-29 08:53:44 --> Model Class Initialized
DEBUG - 2023-07-29 08:53:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 08:53:44 --> Model Class Initialized
DEBUG - 2023-07-29 08:53:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 08:53:44 --> Model Class Initialized
INFO - 2023-07-29 08:53:44 --> Model Class Initialized
INFO - 2023-07-29 08:53:44 --> Model Class Initialized
INFO - 2023-07-29 08:53:44 --> Model Class Initialized
DEBUG - 2023-07-29 08:53:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-29 08:53:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 08:53:44 --> Model Class Initialized
INFO - 2023-07-29 08:53:44 --> Model Class Initialized
INFO - 2023-07-29 08:53:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-29 08:53:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-29 08:53:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-29 08:53:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-29 08:53:44 --> Model Class Initialized
INFO - 2023-07-29 08:53:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-29 08:53:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-29 08:53:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-29 08:53:45 --> Final output sent to browser
DEBUG - 2023-07-29 08:53:45 --> Total execution time: 0.0859
ERROR - 2023-07-29 13:15:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 13:15:07 --> Config Class Initialized
INFO - 2023-07-29 13:15:07 --> Hooks Class Initialized
DEBUG - 2023-07-29 13:15:07 --> UTF-8 Support Enabled
INFO - 2023-07-29 13:15:07 --> Utf8 Class Initialized
INFO - 2023-07-29 13:15:07 --> URI Class Initialized
DEBUG - 2023-07-29 13:15:07 --> No URI present. Default controller set.
INFO - 2023-07-29 13:15:07 --> Router Class Initialized
INFO - 2023-07-29 13:15:07 --> Output Class Initialized
INFO - 2023-07-29 13:15:07 --> Security Class Initialized
DEBUG - 2023-07-29 13:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 13:15:07 --> Input Class Initialized
INFO - 2023-07-29 13:15:07 --> Language Class Initialized
INFO - 2023-07-29 13:15:07 --> Loader Class Initialized
INFO - 2023-07-29 13:15:07 --> Helper loaded: url_helper
INFO - 2023-07-29 13:15:07 --> Helper loaded: file_helper
INFO - 2023-07-29 13:15:07 --> Helper loaded: html_helper
INFO - 2023-07-29 13:15:07 --> Helper loaded: text_helper
INFO - 2023-07-29 13:15:07 --> Helper loaded: form_helper
INFO - 2023-07-29 13:15:07 --> Helper loaded: lang_helper
INFO - 2023-07-29 13:15:07 --> Helper loaded: security_helper
INFO - 2023-07-29 13:15:07 --> Helper loaded: cookie_helper
INFO - 2023-07-29 13:15:07 --> Database Driver Class Initialized
INFO - 2023-07-29 13:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 13:15:07 --> Parser Class Initialized
INFO - 2023-07-29 13:15:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 13:15:07 --> Pagination Class Initialized
INFO - 2023-07-29 13:15:07 --> Form Validation Class Initialized
INFO - 2023-07-29 13:15:07 --> Controller Class Initialized
INFO - 2023-07-29 13:15:07 --> Model Class Initialized
DEBUG - 2023-07-29 13:15:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-29 13:15:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 13:15:08 --> Config Class Initialized
INFO - 2023-07-29 13:15:08 --> Hooks Class Initialized
DEBUG - 2023-07-29 13:15:08 --> UTF-8 Support Enabled
INFO - 2023-07-29 13:15:08 --> Utf8 Class Initialized
INFO - 2023-07-29 13:15:08 --> URI Class Initialized
INFO - 2023-07-29 13:15:08 --> Router Class Initialized
INFO - 2023-07-29 13:15:08 --> Output Class Initialized
INFO - 2023-07-29 13:15:08 --> Security Class Initialized
DEBUG - 2023-07-29 13:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 13:15:08 --> Input Class Initialized
INFO - 2023-07-29 13:15:08 --> Language Class Initialized
INFO - 2023-07-29 13:15:08 --> Loader Class Initialized
INFO - 2023-07-29 13:15:08 --> Helper loaded: url_helper
INFO - 2023-07-29 13:15:08 --> Helper loaded: file_helper
INFO - 2023-07-29 13:15:08 --> Helper loaded: html_helper
INFO - 2023-07-29 13:15:08 --> Helper loaded: text_helper
INFO - 2023-07-29 13:15:08 --> Helper loaded: form_helper
INFO - 2023-07-29 13:15:08 --> Helper loaded: lang_helper
INFO - 2023-07-29 13:15:08 --> Helper loaded: security_helper
INFO - 2023-07-29 13:15:08 --> Helper loaded: cookie_helper
INFO - 2023-07-29 13:15:08 --> Database Driver Class Initialized
INFO - 2023-07-29 13:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 13:15:08 --> Parser Class Initialized
INFO - 2023-07-29 13:15:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 13:15:08 --> Pagination Class Initialized
INFO - 2023-07-29 13:15:08 --> Form Validation Class Initialized
INFO - 2023-07-29 13:15:08 --> Controller Class Initialized
INFO - 2023-07-29 13:15:08 --> Model Class Initialized
DEBUG - 2023-07-29 13:15:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 13:15:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-29 13:15:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-29 13:15:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-29 13:15:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-29 13:15:08 --> Model Class Initialized
INFO - 2023-07-29 13:15:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-29 13:15:08 --> Final output sent to browser
DEBUG - 2023-07-29 13:15:08 --> Total execution time: 0.0328
ERROR - 2023-07-29 13:35:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 13:35:55 --> Config Class Initialized
INFO - 2023-07-29 13:35:55 --> Hooks Class Initialized
DEBUG - 2023-07-29 13:35:55 --> UTF-8 Support Enabled
INFO - 2023-07-29 13:35:55 --> Utf8 Class Initialized
INFO - 2023-07-29 13:35:55 --> URI Class Initialized
DEBUG - 2023-07-29 13:35:55 --> No URI present. Default controller set.
INFO - 2023-07-29 13:35:55 --> Router Class Initialized
INFO - 2023-07-29 13:35:55 --> Output Class Initialized
INFO - 2023-07-29 13:35:55 --> Security Class Initialized
DEBUG - 2023-07-29 13:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 13:35:55 --> Input Class Initialized
INFO - 2023-07-29 13:35:55 --> Language Class Initialized
INFO - 2023-07-29 13:35:55 --> Loader Class Initialized
INFO - 2023-07-29 13:35:55 --> Helper loaded: url_helper
INFO - 2023-07-29 13:35:55 --> Helper loaded: file_helper
INFO - 2023-07-29 13:35:55 --> Helper loaded: html_helper
INFO - 2023-07-29 13:35:55 --> Helper loaded: text_helper
INFO - 2023-07-29 13:35:55 --> Helper loaded: form_helper
INFO - 2023-07-29 13:35:55 --> Helper loaded: lang_helper
INFO - 2023-07-29 13:35:55 --> Helper loaded: security_helper
INFO - 2023-07-29 13:35:55 --> Helper loaded: cookie_helper
INFO - 2023-07-29 13:35:55 --> Database Driver Class Initialized
INFO - 2023-07-29 13:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 13:35:55 --> Parser Class Initialized
INFO - 2023-07-29 13:35:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 13:35:55 --> Pagination Class Initialized
INFO - 2023-07-29 13:35:55 --> Form Validation Class Initialized
INFO - 2023-07-29 13:35:55 --> Controller Class Initialized
INFO - 2023-07-29 13:35:55 --> Model Class Initialized
DEBUG - 2023-07-29 13:35:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-29 13:35:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 13:35:55 --> Config Class Initialized
INFO - 2023-07-29 13:35:55 --> Hooks Class Initialized
DEBUG - 2023-07-29 13:35:55 --> UTF-8 Support Enabled
INFO - 2023-07-29 13:35:55 --> Utf8 Class Initialized
INFO - 2023-07-29 13:35:55 --> URI Class Initialized
INFO - 2023-07-29 13:35:55 --> Router Class Initialized
INFO - 2023-07-29 13:35:55 --> Output Class Initialized
INFO - 2023-07-29 13:35:55 --> Security Class Initialized
DEBUG - 2023-07-29 13:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 13:35:55 --> Input Class Initialized
INFO - 2023-07-29 13:35:55 --> Language Class Initialized
INFO - 2023-07-29 13:35:55 --> Loader Class Initialized
INFO - 2023-07-29 13:35:55 --> Helper loaded: url_helper
INFO - 2023-07-29 13:35:55 --> Helper loaded: file_helper
INFO - 2023-07-29 13:35:55 --> Helper loaded: html_helper
INFO - 2023-07-29 13:35:55 --> Helper loaded: text_helper
INFO - 2023-07-29 13:35:55 --> Helper loaded: form_helper
INFO - 2023-07-29 13:35:55 --> Helper loaded: lang_helper
INFO - 2023-07-29 13:35:55 --> Helper loaded: security_helper
INFO - 2023-07-29 13:35:55 --> Helper loaded: cookie_helper
INFO - 2023-07-29 13:35:55 --> Database Driver Class Initialized
INFO - 2023-07-29 13:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 13:35:55 --> Parser Class Initialized
INFO - 2023-07-29 13:35:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 13:35:55 --> Pagination Class Initialized
INFO - 2023-07-29 13:35:55 --> Form Validation Class Initialized
INFO - 2023-07-29 13:35:55 --> Controller Class Initialized
INFO - 2023-07-29 13:35:55 --> Model Class Initialized
DEBUG - 2023-07-29 13:35:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 13:35:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-29 13:35:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-29 13:35:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-29 13:35:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-29 13:35:55 --> Model Class Initialized
INFO - 2023-07-29 13:35:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-29 13:35:55 --> Final output sent to browser
DEBUG - 2023-07-29 13:35:55 --> Total execution time: 0.0293
ERROR - 2023-07-29 15:17:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 15:17:28 --> Config Class Initialized
INFO - 2023-07-29 15:17:28 --> Hooks Class Initialized
DEBUG - 2023-07-29 15:17:28 --> UTF-8 Support Enabled
INFO - 2023-07-29 15:17:28 --> Utf8 Class Initialized
INFO - 2023-07-29 15:17:28 --> URI Class Initialized
DEBUG - 2023-07-29 15:17:28 --> No URI present. Default controller set.
INFO - 2023-07-29 15:17:28 --> Router Class Initialized
INFO - 2023-07-29 15:17:28 --> Output Class Initialized
INFO - 2023-07-29 15:17:28 --> Security Class Initialized
DEBUG - 2023-07-29 15:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 15:17:28 --> Input Class Initialized
INFO - 2023-07-29 15:17:28 --> Language Class Initialized
INFO - 2023-07-29 15:17:28 --> Loader Class Initialized
INFO - 2023-07-29 15:17:28 --> Helper loaded: url_helper
INFO - 2023-07-29 15:17:28 --> Helper loaded: file_helper
INFO - 2023-07-29 15:17:28 --> Helper loaded: html_helper
INFO - 2023-07-29 15:17:28 --> Helper loaded: text_helper
INFO - 2023-07-29 15:17:28 --> Helper loaded: form_helper
INFO - 2023-07-29 15:17:28 --> Helper loaded: lang_helper
INFO - 2023-07-29 15:17:28 --> Helper loaded: security_helper
INFO - 2023-07-29 15:17:28 --> Helper loaded: cookie_helper
INFO - 2023-07-29 15:17:28 --> Database Driver Class Initialized
INFO - 2023-07-29 15:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 15:17:28 --> Parser Class Initialized
INFO - 2023-07-29 15:17:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 15:17:28 --> Pagination Class Initialized
INFO - 2023-07-29 15:17:28 --> Form Validation Class Initialized
INFO - 2023-07-29 15:17:28 --> Controller Class Initialized
INFO - 2023-07-29 15:17:28 --> Model Class Initialized
DEBUG - 2023-07-29 15:17:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-29 16:03:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 16:03:29 --> Config Class Initialized
INFO - 2023-07-29 16:03:29 --> Hooks Class Initialized
DEBUG - 2023-07-29 16:03:29 --> UTF-8 Support Enabled
INFO - 2023-07-29 16:03:29 --> Utf8 Class Initialized
INFO - 2023-07-29 16:03:29 --> URI Class Initialized
DEBUG - 2023-07-29 16:03:29 --> No URI present. Default controller set.
INFO - 2023-07-29 16:03:29 --> Router Class Initialized
INFO - 2023-07-29 16:03:29 --> Output Class Initialized
INFO - 2023-07-29 16:03:29 --> Security Class Initialized
DEBUG - 2023-07-29 16:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 16:03:29 --> Input Class Initialized
INFO - 2023-07-29 16:03:29 --> Language Class Initialized
INFO - 2023-07-29 16:03:29 --> Loader Class Initialized
INFO - 2023-07-29 16:03:29 --> Helper loaded: url_helper
INFO - 2023-07-29 16:03:29 --> Helper loaded: file_helper
INFO - 2023-07-29 16:03:29 --> Helper loaded: html_helper
INFO - 2023-07-29 16:03:29 --> Helper loaded: text_helper
INFO - 2023-07-29 16:03:29 --> Helper loaded: form_helper
INFO - 2023-07-29 16:03:29 --> Helper loaded: lang_helper
INFO - 2023-07-29 16:03:29 --> Helper loaded: security_helper
INFO - 2023-07-29 16:03:29 --> Helper loaded: cookie_helper
INFO - 2023-07-29 16:03:29 --> Database Driver Class Initialized
INFO - 2023-07-29 16:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 16:03:29 --> Parser Class Initialized
INFO - 2023-07-29 16:03:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 16:03:29 --> Pagination Class Initialized
INFO - 2023-07-29 16:03:29 --> Form Validation Class Initialized
INFO - 2023-07-29 16:03:29 --> Controller Class Initialized
INFO - 2023-07-29 16:03:29 --> Model Class Initialized
DEBUG - 2023-07-29 16:03:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-29 16:03:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 16:03:30 --> Config Class Initialized
INFO - 2023-07-29 16:03:30 --> Hooks Class Initialized
DEBUG - 2023-07-29 16:03:30 --> UTF-8 Support Enabled
INFO - 2023-07-29 16:03:30 --> Utf8 Class Initialized
INFO - 2023-07-29 16:03:30 --> URI Class Initialized
INFO - 2023-07-29 16:03:30 --> Router Class Initialized
INFO - 2023-07-29 16:03:30 --> Output Class Initialized
INFO - 2023-07-29 16:03:30 --> Security Class Initialized
DEBUG - 2023-07-29 16:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 16:03:30 --> Input Class Initialized
INFO - 2023-07-29 16:03:30 --> Language Class Initialized
INFO - 2023-07-29 16:03:30 --> Loader Class Initialized
INFO - 2023-07-29 16:03:30 --> Helper loaded: url_helper
INFO - 2023-07-29 16:03:30 --> Helper loaded: file_helper
INFO - 2023-07-29 16:03:30 --> Helper loaded: html_helper
INFO - 2023-07-29 16:03:30 --> Helper loaded: text_helper
INFO - 2023-07-29 16:03:30 --> Helper loaded: form_helper
INFO - 2023-07-29 16:03:30 --> Helper loaded: lang_helper
INFO - 2023-07-29 16:03:30 --> Helper loaded: security_helper
INFO - 2023-07-29 16:03:30 --> Helper loaded: cookie_helper
INFO - 2023-07-29 16:03:30 --> Database Driver Class Initialized
INFO - 2023-07-29 16:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 16:03:30 --> Parser Class Initialized
INFO - 2023-07-29 16:03:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 16:03:30 --> Pagination Class Initialized
INFO - 2023-07-29 16:03:30 --> Form Validation Class Initialized
INFO - 2023-07-29 16:03:30 --> Controller Class Initialized
INFO - 2023-07-29 16:03:30 --> Model Class Initialized
DEBUG - 2023-07-29 16:03:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 16:03:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-29 16:03:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-29 16:03:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-29 16:03:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-29 16:03:30 --> Model Class Initialized
INFO - 2023-07-29 16:03:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-29 16:03:30 --> Final output sent to browser
DEBUG - 2023-07-29 16:03:30 --> Total execution time: 0.0320
ERROR - 2023-07-29 16:03:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 16:03:49 --> Config Class Initialized
INFO - 2023-07-29 16:03:49 --> Hooks Class Initialized
DEBUG - 2023-07-29 16:03:49 --> UTF-8 Support Enabled
INFO - 2023-07-29 16:03:49 --> Utf8 Class Initialized
INFO - 2023-07-29 16:03:49 --> URI Class Initialized
INFO - 2023-07-29 16:03:49 --> Router Class Initialized
INFO - 2023-07-29 16:03:49 --> Output Class Initialized
INFO - 2023-07-29 16:03:49 --> Security Class Initialized
DEBUG - 2023-07-29 16:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 16:03:49 --> Input Class Initialized
INFO - 2023-07-29 16:03:49 --> Language Class Initialized
INFO - 2023-07-29 16:03:49 --> Loader Class Initialized
INFO - 2023-07-29 16:03:49 --> Helper loaded: url_helper
INFO - 2023-07-29 16:03:49 --> Helper loaded: file_helper
INFO - 2023-07-29 16:03:49 --> Helper loaded: html_helper
INFO - 2023-07-29 16:03:49 --> Helper loaded: text_helper
INFO - 2023-07-29 16:03:49 --> Helper loaded: form_helper
INFO - 2023-07-29 16:03:49 --> Helper loaded: lang_helper
INFO - 2023-07-29 16:03:49 --> Helper loaded: security_helper
INFO - 2023-07-29 16:03:49 --> Helper loaded: cookie_helper
INFO - 2023-07-29 16:03:49 --> Database Driver Class Initialized
INFO - 2023-07-29 16:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 16:03:49 --> Parser Class Initialized
INFO - 2023-07-29 16:03:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 16:03:49 --> Pagination Class Initialized
INFO - 2023-07-29 16:03:49 --> Form Validation Class Initialized
INFO - 2023-07-29 16:03:49 --> Controller Class Initialized
INFO - 2023-07-29 16:03:49 --> Model Class Initialized
DEBUG - 2023-07-29 16:03:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 16:03:49 --> Model Class Initialized
INFO - 2023-07-29 16:03:49 --> Final output sent to browser
DEBUG - 2023-07-29 16:03:49 --> Total execution time: 0.0218
ERROR - 2023-07-29 16:03:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 16:03:49 --> Config Class Initialized
INFO - 2023-07-29 16:03:49 --> Hooks Class Initialized
DEBUG - 2023-07-29 16:03:49 --> UTF-8 Support Enabled
INFO - 2023-07-29 16:03:49 --> Utf8 Class Initialized
INFO - 2023-07-29 16:03:49 --> URI Class Initialized
DEBUG - 2023-07-29 16:03:49 --> No URI present. Default controller set.
INFO - 2023-07-29 16:03:49 --> Router Class Initialized
INFO - 2023-07-29 16:03:49 --> Output Class Initialized
INFO - 2023-07-29 16:03:49 --> Security Class Initialized
DEBUG - 2023-07-29 16:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 16:03:49 --> Input Class Initialized
INFO - 2023-07-29 16:03:49 --> Language Class Initialized
INFO - 2023-07-29 16:03:49 --> Loader Class Initialized
INFO - 2023-07-29 16:03:49 --> Helper loaded: url_helper
INFO - 2023-07-29 16:03:49 --> Helper loaded: file_helper
INFO - 2023-07-29 16:03:49 --> Helper loaded: html_helper
INFO - 2023-07-29 16:03:49 --> Helper loaded: text_helper
INFO - 2023-07-29 16:03:49 --> Helper loaded: form_helper
INFO - 2023-07-29 16:03:49 --> Helper loaded: lang_helper
INFO - 2023-07-29 16:03:49 --> Helper loaded: security_helper
INFO - 2023-07-29 16:03:49 --> Helper loaded: cookie_helper
INFO - 2023-07-29 16:03:49 --> Database Driver Class Initialized
INFO - 2023-07-29 16:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 16:03:49 --> Parser Class Initialized
INFO - 2023-07-29 16:03:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 16:03:49 --> Pagination Class Initialized
INFO - 2023-07-29 16:03:49 --> Form Validation Class Initialized
INFO - 2023-07-29 16:03:49 --> Controller Class Initialized
INFO - 2023-07-29 16:03:49 --> Model Class Initialized
DEBUG - 2023-07-29 16:03:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 16:03:49 --> Model Class Initialized
DEBUG - 2023-07-29 16:03:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 16:03:49 --> Model Class Initialized
INFO - 2023-07-29 16:03:49 --> Model Class Initialized
INFO - 2023-07-29 16:03:49 --> Model Class Initialized
INFO - 2023-07-29 16:03:49 --> Model Class Initialized
DEBUG - 2023-07-29 16:03:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-29 16:03:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 16:03:49 --> Model Class Initialized
INFO - 2023-07-29 16:03:49 --> Model Class Initialized
INFO - 2023-07-29 16:03:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-29 16:03:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-29 16:03:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-29 16:03:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-29 16:03:49 --> Model Class Initialized
INFO - 2023-07-29 16:03:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-29 16:03:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-29 16:03:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-29 16:03:49 --> Final output sent to browser
DEBUG - 2023-07-29 16:03:49 --> Total execution time: 0.1777
ERROR - 2023-07-29 16:03:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 16:03:50 --> Config Class Initialized
INFO - 2023-07-29 16:03:50 --> Hooks Class Initialized
DEBUG - 2023-07-29 16:03:50 --> UTF-8 Support Enabled
INFO - 2023-07-29 16:03:50 --> Utf8 Class Initialized
INFO - 2023-07-29 16:03:50 --> URI Class Initialized
INFO - 2023-07-29 16:03:50 --> Router Class Initialized
INFO - 2023-07-29 16:03:50 --> Output Class Initialized
INFO - 2023-07-29 16:03:50 --> Security Class Initialized
DEBUG - 2023-07-29 16:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 16:03:50 --> Input Class Initialized
INFO - 2023-07-29 16:03:50 --> Language Class Initialized
INFO - 2023-07-29 16:03:50 --> Loader Class Initialized
INFO - 2023-07-29 16:03:50 --> Helper loaded: url_helper
INFO - 2023-07-29 16:03:50 --> Helper loaded: file_helper
INFO - 2023-07-29 16:03:50 --> Helper loaded: html_helper
INFO - 2023-07-29 16:03:50 --> Helper loaded: text_helper
INFO - 2023-07-29 16:03:50 --> Helper loaded: form_helper
INFO - 2023-07-29 16:03:50 --> Helper loaded: lang_helper
INFO - 2023-07-29 16:03:50 --> Helper loaded: security_helper
INFO - 2023-07-29 16:03:50 --> Helper loaded: cookie_helper
INFO - 2023-07-29 16:03:50 --> Database Driver Class Initialized
INFO - 2023-07-29 16:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 16:03:50 --> Parser Class Initialized
INFO - 2023-07-29 16:03:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 16:03:50 --> Pagination Class Initialized
INFO - 2023-07-29 16:03:50 --> Form Validation Class Initialized
INFO - 2023-07-29 16:03:50 --> Controller Class Initialized
DEBUG - 2023-07-29 16:03:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-29 16:03:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 16:03:50 --> Model Class Initialized
INFO - 2023-07-29 16:03:50 --> Final output sent to browser
DEBUG - 2023-07-29 16:03:50 --> Total execution time: 0.0131
ERROR - 2023-07-29 16:07:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 16:07:05 --> Config Class Initialized
INFO - 2023-07-29 16:07:05 --> Hooks Class Initialized
DEBUG - 2023-07-29 16:07:05 --> UTF-8 Support Enabled
INFO - 2023-07-29 16:07:05 --> Utf8 Class Initialized
INFO - 2023-07-29 16:07:05 --> URI Class Initialized
INFO - 2023-07-29 16:07:05 --> Router Class Initialized
INFO - 2023-07-29 16:07:05 --> Output Class Initialized
INFO - 2023-07-29 16:07:05 --> Security Class Initialized
DEBUG - 2023-07-29 16:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 16:07:05 --> Input Class Initialized
INFO - 2023-07-29 16:07:05 --> Language Class Initialized
INFO - 2023-07-29 16:07:05 --> Loader Class Initialized
INFO - 2023-07-29 16:07:05 --> Helper loaded: url_helper
INFO - 2023-07-29 16:07:05 --> Helper loaded: file_helper
INFO - 2023-07-29 16:07:05 --> Helper loaded: html_helper
INFO - 2023-07-29 16:07:05 --> Helper loaded: text_helper
INFO - 2023-07-29 16:07:05 --> Helper loaded: form_helper
INFO - 2023-07-29 16:07:05 --> Helper loaded: lang_helper
INFO - 2023-07-29 16:07:05 --> Helper loaded: security_helper
INFO - 2023-07-29 16:07:05 --> Helper loaded: cookie_helper
INFO - 2023-07-29 16:07:05 --> Database Driver Class Initialized
INFO - 2023-07-29 16:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 16:07:05 --> Parser Class Initialized
INFO - 2023-07-29 16:07:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 16:07:05 --> Pagination Class Initialized
INFO - 2023-07-29 16:07:05 --> Form Validation Class Initialized
INFO - 2023-07-29 16:07:05 --> Controller Class Initialized
INFO - 2023-07-29 16:07:05 --> Model Class Initialized
INFO - 2023-07-29 16:07:05 --> Model Class Initialized
INFO - 2023-07-29 16:07:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2023-07-29 16:07:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-29 16:07:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-29 16:07:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-29 16:07:05 --> Model Class Initialized
INFO - 2023-07-29 16:07:05 --> Model Class Initialized
INFO - 2023-07-29 16:07:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-29 16:07:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-29 16:07:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-29 16:07:05 --> Final output sent to browser
DEBUG - 2023-07-29 16:07:05 --> Total execution time: 0.1591
ERROR - 2023-07-29 16:07:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 16:07:06 --> Config Class Initialized
INFO - 2023-07-29 16:07:06 --> Hooks Class Initialized
DEBUG - 2023-07-29 16:07:06 --> UTF-8 Support Enabled
INFO - 2023-07-29 16:07:06 --> Utf8 Class Initialized
INFO - 2023-07-29 16:07:06 --> URI Class Initialized
INFO - 2023-07-29 16:07:06 --> Router Class Initialized
INFO - 2023-07-29 16:07:06 --> Output Class Initialized
INFO - 2023-07-29 16:07:06 --> Security Class Initialized
DEBUG - 2023-07-29 16:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 16:07:06 --> Input Class Initialized
INFO - 2023-07-29 16:07:06 --> Language Class Initialized
INFO - 2023-07-29 16:07:06 --> Loader Class Initialized
INFO - 2023-07-29 16:07:06 --> Helper loaded: url_helper
INFO - 2023-07-29 16:07:06 --> Helper loaded: file_helper
INFO - 2023-07-29 16:07:06 --> Helper loaded: html_helper
INFO - 2023-07-29 16:07:06 --> Helper loaded: text_helper
INFO - 2023-07-29 16:07:06 --> Helper loaded: form_helper
INFO - 2023-07-29 16:07:06 --> Helper loaded: lang_helper
INFO - 2023-07-29 16:07:06 --> Helper loaded: security_helper
INFO - 2023-07-29 16:07:06 --> Helper loaded: cookie_helper
INFO - 2023-07-29 16:07:06 --> Database Driver Class Initialized
INFO - 2023-07-29 16:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 16:07:06 --> Parser Class Initialized
INFO - 2023-07-29 16:07:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 16:07:06 --> Pagination Class Initialized
INFO - 2023-07-29 16:07:06 --> Form Validation Class Initialized
INFO - 2023-07-29 16:07:06 --> Controller Class Initialized
INFO - 2023-07-29 16:07:06 --> Model Class Initialized
INFO - 2023-07-29 16:07:06 --> Model Class Initialized
INFO - 2023-07-29 16:07:06 --> Final output sent to browser
DEBUG - 2023-07-29 16:07:06 --> Total execution time: 0.0368
ERROR - 2023-07-29 17:02:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 17:02:56 --> Config Class Initialized
INFO - 2023-07-29 17:02:56 --> Hooks Class Initialized
DEBUG - 2023-07-29 17:02:56 --> UTF-8 Support Enabled
INFO - 2023-07-29 17:02:56 --> Utf8 Class Initialized
INFO - 2023-07-29 17:02:56 --> URI Class Initialized
DEBUG - 2023-07-29 17:02:56 --> No URI present. Default controller set.
INFO - 2023-07-29 17:02:56 --> Router Class Initialized
INFO - 2023-07-29 17:02:56 --> Output Class Initialized
INFO - 2023-07-29 17:02:56 --> Security Class Initialized
DEBUG - 2023-07-29 17:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 17:02:56 --> Input Class Initialized
INFO - 2023-07-29 17:02:56 --> Language Class Initialized
INFO - 2023-07-29 17:02:56 --> Loader Class Initialized
INFO - 2023-07-29 17:02:56 --> Helper loaded: url_helper
INFO - 2023-07-29 17:02:56 --> Helper loaded: file_helper
INFO - 2023-07-29 17:02:56 --> Helper loaded: html_helper
INFO - 2023-07-29 17:02:56 --> Helper loaded: text_helper
INFO - 2023-07-29 17:02:56 --> Helper loaded: form_helper
INFO - 2023-07-29 17:02:56 --> Helper loaded: lang_helper
INFO - 2023-07-29 17:02:56 --> Helper loaded: security_helper
INFO - 2023-07-29 17:02:56 --> Helper loaded: cookie_helper
INFO - 2023-07-29 17:02:56 --> Database Driver Class Initialized
INFO - 2023-07-29 17:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 17:02:56 --> Parser Class Initialized
INFO - 2023-07-29 17:02:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 17:02:56 --> Pagination Class Initialized
INFO - 2023-07-29 17:02:56 --> Form Validation Class Initialized
INFO - 2023-07-29 17:02:56 --> Controller Class Initialized
INFO - 2023-07-29 17:02:56 --> Model Class Initialized
DEBUG - 2023-07-29 17:02:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-29 17:02:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-29 17:02:57 --> Config Class Initialized
INFO - 2023-07-29 17:02:57 --> Hooks Class Initialized
DEBUG - 2023-07-29 17:02:57 --> UTF-8 Support Enabled
INFO - 2023-07-29 17:02:57 --> Utf8 Class Initialized
INFO - 2023-07-29 17:02:57 --> URI Class Initialized
INFO - 2023-07-29 17:02:57 --> Router Class Initialized
INFO - 2023-07-29 17:02:57 --> Output Class Initialized
INFO - 2023-07-29 17:02:57 --> Security Class Initialized
DEBUG - 2023-07-29 17:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-29 17:02:57 --> Input Class Initialized
INFO - 2023-07-29 17:02:57 --> Language Class Initialized
INFO - 2023-07-29 17:02:57 --> Loader Class Initialized
INFO - 2023-07-29 17:02:57 --> Helper loaded: url_helper
INFO - 2023-07-29 17:02:57 --> Helper loaded: file_helper
INFO - 2023-07-29 17:02:57 --> Helper loaded: html_helper
INFO - 2023-07-29 17:02:57 --> Helper loaded: text_helper
INFO - 2023-07-29 17:02:57 --> Helper loaded: form_helper
INFO - 2023-07-29 17:02:57 --> Helper loaded: lang_helper
INFO - 2023-07-29 17:02:57 --> Helper loaded: security_helper
INFO - 2023-07-29 17:02:57 --> Helper loaded: cookie_helper
INFO - 2023-07-29 17:02:57 --> Database Driver Class Initialized
INFO - 2023-07-29 17:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-29 17:02:57 --> Parser Class Initialized
INFO - 2023-07-29 17:02:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-29 17:02:57 --> Pagination Class Initialized
INFO - 2023-07-29 17:02:57 --> Form Validation Class Initialized
INFO - 2023-07-29 17:02:57 --> Controller Class Initialized
INFO - 2023-07-29 17:02:57 --> Model Class Initialized
DEBUG - 2023-07-29 17:02:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-29 17:02:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-29 17:02:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-29 17:02:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-29 17:02:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-29 17:02:57 --> Model Class Initialized
INFO - 2023-07-29 17:02:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-29 17:02:57 --> Final output sent to browser
DEBUG - 2023-07-29 17:02:57 --> Total execution time: 0.0286
