<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-18 05:01:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 05:01:02 --> Config Class Initialized
INFO - 2023-08-18 05:01:02 --> Hooks Class Initialized
DEBUG - 2023-08-18 05:01:02 --> UTF-8 Support Enabled
INFO - 2023-08-18 05:01:02 --> Utf8 Class Initialized
INFO - 2023-08-18 05:01:02 --> URI Class Initialized
DEBUG - 2023-08-18 05:01:02 --> No URI present. Default controller set.
INFO - 2023-08-18 05:01:02 --> Router Class Initialized
INFO - 2023-08-18 05:01:02 --> Output Class Initialized
INFO - 2023-08-18 05:01:02 --> Security Class Initialized
DEBUG - 2023-08-18 05:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 05:01:02 --> Input Class Initialized
INFO - 2023-08-18 05:01:02 --> Language Class Initialized
INFO - 2023-08-18 05:01:02 --> Loader Class Initialized
INFO - 2023-08-18 05:01:02 --> Helper loaded: url_helper
INFO - 2023-08-18 05:01:02 --> Helper loaded: file_helper
INFO - 2023-08-18 05:01:02 --> Helper loaded: html_helper
INFO - 2023-08-18 05:01:02 --> Helper loaded: text_helper
INFO - 2023-08-18 05:01:02 --> Helper loaded: form_helper
INFO - 2023-08-18 05:01:02 --> Helper loaded: lang_helper
INFO - 2023-08-18 05:01:02 --> Helper loaded: security_helper
INFO - 2023-08-18 05:01:02 --> Helper loaded: cookie_helper
INFO - 2023-08-18 05:01:02 --> Database Driver Class Initialized
INFO - 2023-08-18 05:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 05:01:02 --> Parser Class Initialized
INFO - 2023-08-18 05:01:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 05:01:02 --> Pagination Class Initialized
INFO - 2023-08-18 05:01:02 --> Form Validation Class Initialized
INFO - 2023-08-18 05:01:02 --> Controller Class Initialized
INFO - 2023-08-18 05:01:02 --> Model Class Initialized
DEBUG - 2023-08-18 05:01:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-18 05:01:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 05:01:03 --> Config Class Initialized
INFO - 2023-08-18 05:01:03 --> Hooks Class Initialized
DEBUG - 2023-08-18 05:01:03 --> UTF-8 Support Enabled
INFO - 2023-08-18 05:01:03 --> Utf8 Class Initialized
INFO - 2023-08-18 05:01:03 --> URI Class Initialized
INFO - 2023-08-18 05:01:03 --> Router Class Initialized
INFO - 2023-08-18 05:01:03 --> Output Class Initialized
INFO - 2023-08-18 05:01:03 --> Security Class Initialized
DEBUG - 2023-08-18 05:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 05:01:03 --> Input Class Initialized
INFO - 2023-08-18 05:01:03 --> Language Class Initialized
INFO - 2023-08-18 05:01:03 --> Loader Class Initialized
INFO - 2023-08-18 05:01:03 --> Helper loaded: url_helper
INFO - 2023-08-18 05:01:03 --> Helper loaded: file_helper
INFO - 2023-08-18 05:01:03 --> Helper loaded: html_helper
INFO - 2023-08-18 05:01:03 --> Helper loaded: text_helper
INFO - 2023-08-18 05:01:03 --> Helper loaded: form_helper
INFO - 2023-08-18 05:01:03 --> Helper loaded: lang_helper
INFO - 2023-08-18 05:01:03 --> Helper loaded: security_helper
INFO - 2023-08-18 05:01:03 --> Helper loaded: cookie_helper
INFO - 2023-08-18 05:01:03 --> Database Driver Class Initialized
INFO - 2023-08-18 05:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 05:01:03 --> Parser Class Initialized
INFO - 2023-08-18 05:01:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 05:01:03 --> Pagination Class Initialized
INFO - 2023-08-18 05:01:03 --> Form Validation Class Initialized
INFO - 2023-08-18 05:01:03 --> Controller Class Initialized
INFO - 2023-08-18 05:01:03 --> Model Class Initialized
DEBUG - 2023-08-18 05:01:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:01:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-18 05:01:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:01:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 05:01:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 05:01:03 --> Model Class Initialized
INFO - 2023-08-18 05:01:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 05:01:03 --> Final output sent to browser
DEBUG - 2023-08-18 05:01:03 --> Total execution time: 0.0314
ERROR - 2023-08-18 05:01:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 05:01:23 --> Config Class Initialized
INFO - 2023-08-18 05:01:23 --> Hooks Class Initialized
DEBUG - 2023-08-18 05:01:23 --> UTF-8 Support Enabled
INFO - 2023-08-18 05:01:23 --> Utf8 Class Initialized
INFO - 2023-08-18 05:01:23 --> URI Class Initialized
INFO - 2023-08-18 05:01:23 --> Router Class Initialized
INFO - 2023-08-18 05:01:23 --> Output Class Initialized
INFO - 2023-08-18 05:01:23 --> Security Class Initialized
DEBUG - 2023-08-18 05:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 05:01:23 --> Input Class Initialized
INFO - 2023-08-18 05:01:23 --> Language Class Initialized
INFO - 2023-08-18 05:01:23 --> Loader Class Initialized
INFO - 2023-08-18 05:01:23 --> Helper loaded: url_helper
INFO - 2023-08-18 05:01:23 --> Helper loaded: file_helper
INFO - 2023-08-18 05:01:23 --> Helper loaded: html_helper
INFO - 2023-08-18 05:01:23 --> Helper loaded: text_helper
INFO - 2023-08-18 05:01:23 --> Helper loaded: form_helper
INFO - 2023-08-18 05:01:23 --> Helper loaded: lang_helper
INFO - 2023-08-18 05:01:23 --> Helper loaded: security_helper
INFO - 2023-08-18 05:01:23 --> Helper loaded: cookie_helper
INFO - 2023-08-18 05:01:23 --> Database Driver Class Initialized
INFO - 2023-08-18 05:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 05:01:23 --> Parser Class Initialized
INFO - 2023-08-18 05:01:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 05:01:23 --> Pagination Class Initialized
INFO - 2023-08-18 05:01:23 --> Form Validation Class Initialized
INFO - 2023-08-18 05:01:23 --> Controller Class Initialized
INFO - 2023-08-18 05:01:23 --> Model Class Initialized
DEBUG - 2023-08-18 05:01:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:01:23 --> Model Class Initialized
INFO - 2023-08-18 05:01:23 --> Final output sent to browser
DEBUG - 2023-08-18 05:01:23 --> Total execution time: 0.0215
ERROR - 2023-08-18 05:01:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 05:01:23 --> Config Class Initialized
INFO - 2023-08-18 05:01:23 --> Hooks Class Initialized
DEBUG - 2023-08-18 05:01:23 --> UTF-8 Support Enabled
INFO - 2023-08-18 05:01:23 --> Utf8 Class Initialized
INFO - 2023-08-18 05:01:23 --> URI Class Initialized
DEBUG - 2023-08-18 05:01:23 --> No URI present. Default controller set.
INFO - 2023-08-18 05:01:23 --> Router Class Initialized
INFO - 2023-08-18 05:01:23 --> Output Class Initialized
INFO - 2023-08-18 05:01:23 --> Security Class Initialized
DEBUG - 2023-08-18 05:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 05:01:23 --> Input Class Initialized
INFO - 2023-08-18 05:01:23 --> Language Class Initialized
INFO - 2023-08-18 05:01:23 --> Loader Class Initialized
INFO - 2023-08-18 05:01:23 --> Helper loaded: url_helper
INFO - 2023-08-18 05:01:23 --> Helper loaded: file_helper
INFO - 2023-08-18 05:01:23 --> Helper loaded: html_helper
INFO - 2023-08-18 05:01:23 --> Helper loaded: text_helper
INFO - 2023-08-18 05:01:23 --> Helper loaded: form_helper
INFO - 2023-08-18 05:01:23 --> Helper loaded: lang_helper
INFO - 2023-08-18 05:01:23 --> Helper loaded: security_helper
INFO - 2023-08-18 05:01:23 --> Helper loaded: cookie_helper
INFO - 2023-08-18 05:01:23 --> Database Driver Class Initialized
INFO - 2023-08-18 05:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 05:01:23 --> Parser Class Initialized
INFO - 2023-08-18 05:01:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 05:01:23 --> Pagination Class Initialized
INFO - 2023-08-18 05:01:23 --> Form Validation Class Initialized
INFO - 2023-08-18 05:01:23 --> Controller Class Initialized
INFO - 2023-08-18 05:01:23 --> Model Class Initialized
DEBUG - 2023-08-18 05:01:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:01:23 --> Model Class Initialized
DEBUG - 2023-08-18 05:01:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:01:23 --> Model Class Initialized
INFO - 2023-08-18 05:01:23 --> Model Class Initialized
INFO - 2023-08-18 05:01:23 --> Model Class Initialized
INFO - 2023-08-18 05:01:23 --> Model Class Initialized
DEBUG - 2023-08-18 05:01:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 05:01:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:01:23 --> Model Class Initialized
INFO - 2023-08-18 05:01:23 --> Model Class Initialized
INFO - 2023-08-18 05:01:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-18 05:01:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:01:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 05:01:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 05:01:23 --> Model Class Initialized
INFO - 2023-08-18 05:01:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 05:01:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 05:01:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 05:01:23 --> Final output sent to browser
DEBUG - 2023-08-18 05:01:23 --> Total execution time: 0.1000
ERROR - 2023-08-18 05:01:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 05:01:31 --> Config Class Initialized
INFO - 2023-08-18 05:01:31 --> Hooks Class Initialized
DEBUG - 2023-08-18 05:01:31 --> UTF-8 Support Enabled
INFO - 2023-08-18 05:01:31 --> Utf8 Class Initialized
INFO - 2023-08-18 05:01:31 --> URI Class Initialized
INFO - 2023-08-18 05:01:31 --> Router Class Initialized
INFO - 2023-08-18 05:01:31 --> Output Class Initialized
INFO - 2023-08-18 05:01:31 --> Security Class Initialized
DEBUG - 2023-08-18 05:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 05:01:31 --> Input Class Initialized
INFO - 2023-08-18 05:01:31 --> Language Class Initialized
INFO - 2023-08-18 05:01:31 --> Loader Class Initialized
INFO - 2023-08-18 05:01:31 --> Helper loaded: url_helper
INFO - 2023-08-18 05:01:31 --> Helper loaded: file_helper
INFO - 2023-08-18 05:01:31 --> Helper loaded: html_helper
INFO - 2023-08-18 05:01:31 --> Helper loaded: text_helper
INFO - 2023-08-18 05:01:31 --> Helper loaded: form_helper
INFO - 2023-08-18 05:01:31 --> Helper loaded: lang_helper
INFO - 2023-08-18 05:01:31 --> Helper loaded: security_helper
INFO - 2023-08-18 05:01:31 --> Helper loaded: cookie_helper
INFO - 2023-08-18 05:01:31 --> Database Driver Class Initialized
INFO - 2023-08-18 05:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 05:01:31 --> Parser Class Initialized
INFO - 2023-08-18 05:01:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 05:01:31 --> Pagination Class Initialized
INFO - 2023-08-18 05:01:31 --> Form Validation Class Initialized
INFO - 2023-08-18 05:01:31 --> Controller Class Initialized
INFO - 2023-08-18 05:01:31 --> Model Class Initialized
DEBUG - 2023-08-18 05:01:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 05:01:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:01:31 --> Model Class Initialized
DEBUG - 2023-08-18 05:01:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:01:31 --> Model Class Initialized
INFO - 2023-08-18 05:01:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-18 05:01:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:01:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 05:01:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 05:01:31 --> Model Class Initialized
INFO - 2023-08-18 05:01:31 --> Model Class Initialized
INFO - 2023-08-18 05:01:31 --> Model Class Initialized
INFO - 2023-08-18 05:01:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 05:01:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 05:01:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 05:01:31 --> Final output sent to browser
DEBUG - 2023-08-18 05:01:31 --> Total execution time: 0.0840
ERROR - 2023-08-18 05:01:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 05:01:31 --> Config Class Initialized
INFO - 2023-08-18 05:01:31 --> Hooks Class Initialized
DEBUG - 2023-08-18 05:01:31 --> UTF-8 Support Enabled
INFO - 2023-08-18 05:01:31 --> Utf8 Class Initialized
INFO - 2023-08-18 05:01:31 --> URI Class Initialized
INFO - 2023-08-18 05:01:31 --> Router Class Initialized
INFO - 2023-08-18 05:01:31 --> Output Class Initialized
INFO - 2023-08-18 05:01:31 --> Security Class Initialized
DEBUG - 2023-08-18 05:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 05:01:31 --> Input Class Initialized
INFO - 2023-08-18 05:01:31 --> Language Class Initialized
INFO - 2023-08-18 05:01:31 --> Loader Class Initialized
INFO - 2023-08-18 05:01:31 --> Helper loaded: url_helper
INFO - 2023-08-18 05:01:31 --> Helper loaded: file_helper
INFO - 2023-08-18 05:01:31 --> Helper loaded: html_helper
INFO - 2023-08-18 05:01:31 --> Helper loaded: text_helper
INFO - 2023-08-18 05:01:31 --> Helper loaded: form_helper
INFO - 2023-08-18 05:01:31 --> Helper loaded: lang_helper
INFO - 2023-08-18 05:01:31 --> Helper loaded: security_helper
INFO - 2023-08-18 05:01:31 --> Helper loaded: cookie_helper
INFO - 2023-08-18 05:01:31 --> Database Driver Class Initialized
INFO - 2023-08-18 05:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 05:01:31 --> Parser Class Initialized
INFO - 2023-08-18 05:01:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 05:01:31 --> Pagination Class Initialized
INFO - 2023-08-18 05:01:31 --> Form Validation Class Initialized
INFO - 2023-08-18 05:01:31 --> Controller Class Initialized
INFO - 2023-08-18 05:01:31 --> Model Class Initialized
DEBUG - 2023-08-18 05:01:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 05:01:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:01:31 --> Model Class Initialized
DEBUG - 2023-08-18 05:01:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:01:31 --> Model Class Initialized
INFO - 2023-08-18 05:01:31 --> Final output sent to browser
DEBUG - 2023-08-18 05:01:31 --> Total execution time: 0.0370
ERROR - 2023-08-18 05:02:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 05:02:31 --> Config Class Initialized
INFO - 2023-08-18 05:02:31 --> Hooks Class Initialized
DEBUG - 2023-08-18 05:02:31 --> UTF-8 Support Enabled
INFO - 2023-08-18 05:02:31 --> Utf8 Class Initialized
INFO - 2023-08-18 05:02:31 --> URI Class Initialized
INFO - 2023-08-18 05:02:31 --> Router Class Initialized
INFO - 2023-08-18 05:02:31 --> Output Class Initialized
INFO - 2023-08-18 05:02:31 --> Security Class Initialized
DEBUG - 2023-08-18 05:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 05:02:31 --> Input Class Initialized
INFO - 2023-08-18 05:02:31 --> Language Class Initialized
INFO - 2023-08-18 05:02:31 --> Loader Class Initialized
INFO - 2023-08-18 05:02:31 --> Helper loaded: url_helper
INFO - 2023-08-18 05:02:31 --> Helper loaded: file_helper
INFO - 2023-08-18 05:02:31 --> Helper loaded: html_helper
INFO - 2023-08-18 05:02:31 --> Helper loaded: text_helper
INFO - 2023-08-18 05:02:31 --> Helper loaded: form_helper
INFO - 2023-08-18 05:02:31 --> Helper loaded: lang_helper
INFO - 2023-08-18 05:02:31 --> Helper loaded: security_helper
INFO - 2023-08-18 05:02:31 --> Helper loaded: cookie_helper
INFO - 2023-08-18 05:02:31 --> Database Driver Class Initialized
INFO - 2023-08-18 05:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 05:02:31 --> Parser Class Initialized
INFO - 2023-08-18 05:02:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 05:02:31 --> Pagination Class Initialized
INFO - 2023-08-18 05:02:31 --> Form Validation Class Initialized
INFO - 2023-08-18 05:02:31 --> Controller Class Initialized
INFO - 2023-08-18 05:02:31 --> Model Class Initialized
DEBUG - 2023-08-18 05:02:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 05:02:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:02:31 --> Model Class Initialized
DEBUG - 2023-08-18 05:02:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:02:31 --> Model Class Initialized
INFO - 2023-08-18 05:02:31 --> Final output sent to browser
DEBUG - 2023-08-18 05:02:31 --> Total execution time: 0.0425
ERROR - 2023-08-18 05:03:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 05:03:06 --> Config Class Initialized
INFO - 2023-08-18 05:03:06 --> Hooks Class Initialized
DEBUG - 2023-08-18 05:03:06 --> UTF-8 Support Enabled
INFO - 2023-08-18 05:03:06 --> Utf8 Class Initialized
INFO - 2023-08-18 05:03:06 --> URI Class Initialized
INFO - 2023-08-18 05:03:06 --> Router Class Initialized
INFO - 2023-08-18 05:03:06 --> Output Class Initialized
INFO - 2023-08-18 05:03:06 --> Security Class Initialized
DEBUG - 2023-08-18 05:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 05:03:06 --> Input Class Initialized
INFO - 2023-08-18 05:03:06 --> Language Class Initialized
INFO - 2023-08-18 05:03:06 --> Loader Class Initialized
INFO - 2023-08-18 05:03:06 --> Helper loaded: url_helper
INFO - 2023-08-18 05:03:06 --> Helper loaded: file_helper
INFO - 2023-08-18 05:03:06 --> Helper loaded: html_helper
INFO - 2023-08-18 05:03:06 --> Helper loaded: text_helper
INFO - 2023-08-18 05:03:06 --> Helper loaded: form_helper
INFO - 2023-08-18 05:03:06 --> Helper loaded: lang_helper
INFO - 2023-08-18 05:03:06 --> Helper loaded: security_helper
INFO - 2023-08-18 05:03:06 --> Helper loaded: cookie_helper
INFO - 2023-08-18 05:03:06 --> Database Driver Class Initialized
INFO - 2023-08-18 05:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 05:03:06 --> Parser Class Initialized
INFO - 2023-08-18 05:03:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 05:03:06 --> Pagination Class Initialized
INFO - 2023-08-18 05:03:06 --> Form Validation Class Initialized
INFO - 2023-08-18 05:03:06 --> Controller Class Initialized
INFO - 2023-08-18 05:03:06 --> Model Class Initialized
DEBUG - 2023-08-18 05:03:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 05:03:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:03:06 --> Model Class Initialized
DEBUG - 2023-08-18 05:03:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:03:06 --> Model Class Initialized
INFO - 2023-08-18 05:03:06 --> Final output sent to browser
DEBUG - 2023-08-18 05:03:06 --> Total execution time: 0.0476
ERROR - 2023-08-18 05:03:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 05:03:13 --> Config Class Initialized
INFO - 2023-08-18 05:03:13 --> Hooks Class Initialized
DEBUG - 2023-08-18 05:03:13 --> UTF-8 Support Enabled
INFO - 2023-08-18 05:03:13 --> Utf8 Class Initialized
INFO - 2023-08-18 05:03:13 --> URI Class Initialized
INFO - 2023-08-18 05:03:13 --> Router Class Initialized
INFO - 2023-08-18 05:03:13 --> Output Class Initialized
INFO - 2023-08-18 05:03:13 --> Security Class Initialized
DEBUG - 2023-08-18 05:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 05:03:13 --> Input Class Initialized
INFO - 2023-08-18 05:03:13 --> Language Class Initialized
INFO - 2023-08-18 05:03:13 --> Loader Class Initialized
INFO - 2023-08-18 05:03:13 --> Helper loaded: url_helper
INFO - 2023-08-18 05:03:13 --> Helper loaded: file_helper
INFO - 2023-08-18 05:03:13 --> Helper loaded: html_helper
INFO - 2023-08-18 05:03:13 --> Helper loaded: text_helper
INFO - 2023-08-18 05:03:13 --> Helper loaded: form_helper
INFO - 2023-08-18 05:03:13 --> Helper loaded: lang_helper
INFO - 2023-08-18 05:03:13 --> Helper loaded: security_helper
INFO - 2023-08-18 05:03:13 --> Helper loaded: cookie_helper
INFO - 2023-08-18 05:03:13 --> Database Driver Class Initialized
INFO - 2023-08-18 05:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 05:03:13 --> Parser Class Initialized
INFO - 2023-08-18 05:03:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 05:03:13 --> Pagination Class Initialized
INFO - 2023-08-18 05:03:13 --> Form Validation Class Initialized
INFO - 2023-08-18 05:03:13 --> Controller Class Initialized
INFO - 2023-08-18 05:03:13 --> Model Class Initialized
DEBUG - 2023-08-18 05:03:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 05:03:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:03:13 --> Model Class Initialized
DEBUG - 2023-08-18 05:03:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:03:13 --> Model Class Initialized
INFO - 2023-08-18 05:03:13 --> Final output sent to browser
DEBUG - 2023-08-18 05:03:13 --> Total execution time: 0.0440
ERROR - 2023-08-18 05:03:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 05:03:49 --> Config Class Initialized
INFO - 2023-08-18 05:03:49 --> Hooks Class Initialized
DEBUG - 2023-08-18 05:03:49 --> UTF-8 Support Enabled
INFO - 2023-08-18 05:03:49 --> Utf8 Class Initialized
INFO - 2023-08-18 05:03:49 --> URI Class Initialized
INFO - 2023-08-18 05:03:49 --> Router Class Initialized
INFO - 2023-08-18 05:03:49 --> Output Class Initialized
INFO - 2023-08-18 05:03:49 --> Security Class Initialized
DEBUG - 2023-08-18 05:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 05:03:49 --> Input Class Initialized
INFO - 2023-08-18 05:03:49 --> Language Class Initialized
INFO - 2023-08-18 05:03:49 --> Loader Class Initialized
INFO - 2023-08-18 05:03:49 --> Helper loaded: url_helper
INFO - 2023-08-18 05:03:49 --> Helper loaded: file_helper
INFO - 2023-08-18 05:03:49 --> Helper loaded: html_helper
INFO - 2023-08-18 05:03:49 --> Helper loaded: text_helper
INFO - 2023-08-18 05:03:49 --> Helper loaded: form_helper
INFO - 2023-08-18 05:03:49 --> Helper loaded: lang_helper
INFO - 2023-08-18 05:03:49 --> Helper loaded: security_helper
INFO - 2023-08-18 05:03:49 --> Helper loaded: cookie_helper
INFO - 2023-08-18 05:03:49 --> Database Driver Class Initialized
INFO - 2023-08-18 05:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 05:03:49 --> Parser Class Initialized
INFO - 2023-08-18 05:03:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 05:03:49 --> Pagination Class Initialized
INFO - 2023-08-18 05:03:49 --> Form Validation Class Initialized
INFO - 2023-08-18 05:03:49 --> Controller Class Initialized
INFO - 2023-08-18 05:03:49 --> Model Class Initialized
DEBUG - 2023-08-18 05:03:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 05:03:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:03:49 --> Model Class Initialized
DEBUG - 2023-08-18 05:03:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:03:49 --> Model Class Initialized
INFO - 2023-08-18 05:03:49 --> Final output sent to browser
DEBUG - 2023-08-18 05:03:49 --> Total execution time: 0.0442
ERROR - 2023-08-18 05:03:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 05:03:57 --> Config Class Initialized
INFO - 2023-08-18 05:03:57 --> Hooks Class Initialized
DEBUG - 2023-08-18 05:03:57 --> UTF-8 Support Enabled
INFO - 2023-08-18 05:03:57 --> Utf8 Class Initialized
INFO - 2023-08-18 05:03:57 --> URI Class Initialized
INFO - 2023-08-18 05:03:57 --> Router Class Initialized
INFO - 2023-08-18 05:03:57 --> Output Class Initialized
INFO - 2023-08-18 05:03:57 --> Security Class Initialized
DEBUG - 2023-08-18 05:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 05:03:57 --> Input Class Initialized
INFO - 2023-08-18 05:03:57 --> Language Class Initialized
INFO - 2023-08-18 05:03:57 --> Loader Class Initialized
INFO - 2023-08-18 05:03:57 --> Helper loaded: url_helper
INFO - 2023-08-18 05:03:57 --> Helper loaded: file_helper
INFO - 2023-08-18 05:03:57 --> Helper loaded: html_helper
INFO - 2023-08-18 05:03:57 --> Helper loaded: text_helper
INFO - 2023-08-18 05:03:57 --> Helper loaded: form_helper
INFO - 2023-08-18 05:03:57 --> Helper loaded: lang_helper
INFO - 2023-08-18 05:03:57 --> Helper loaded: security_helper
INFO - 2023-08-18 05:03:57 --> Helper loaded: cookie_helper
INFO - 2023-08-18 05:03:57 --> Database Driver Class Initialized
INFO - 2023-08-18 05:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 05:03:57 --> Parser Class Initialized
INFO - 2023-08-18 05:03:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 05:03:57 --> Pagination Class Initialized
INFO - 2023-08-18 05:03:57 --> Form Validation Class Initialized
INFO - 2023-08-18 05:03:57 --> Controller Class Initialized
INFO - 2023-08-18 05:03:57 --> Model Class Initialized
DEBUG - 2023-08-18 05:03:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 05:03:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:03:57 --> Model Class Initialized
DEBUG - 2023-08-18 05:03:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:03:57 --> Model Class Initialized
INFO - 2023-08-18 05:03:57 --> Final output sent to browser
DEBUG - 2023-08-18 05:03:57 --> Total execution time: 0.0401
ERROR - 2023-08-18 05:04:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 05:04:04 --> Config Class Initialized
INFO - 2023-08-18 05:04:04 --> Hooks Class Initialized
DEBUG - 2023-08-18 05:04:04 --> UTF-8 Support Enabled
INFO - 2023-08-18 05:04:04 --> Utf8 Class Initialized
INFO - 2023-08-18 05:04:04 --> URI Class Initialized
INFO - 2023-08-18 05:04:04 --> Router Class Initialized
INFO - 2023-08-18 05:04:04 --> Output Class Initialized
INFO - 2023-08-18 05:04:04 --> Security Class Initialized
DEBUG - 2023-08-18 05:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 05:04:04 --> Input Class Initialized
INFO - 2023-08-18 05:04:04 --> Language Class Initialized
INFO - 2023-08-18 05:04:04 --> Loader Class Initialized
INFO - 2023-08-18 05:04:04 --> Helper loaded: url_helper
INFO - 2023-08-18 05:04:04 --> Helper loaded: file_helper
INFO - 2023-08-18 05:04:04 --> Helper loaded: html_helper
INFO - 2023-08-18 05:04:04 --> Helper loaded: text_helper
INFO - 2023-08-18 05:04:04 --> Helper loaded: form_helper
INFO - 2023-08-18 05:04:04 --> Helper loaded: lang_helper
INFO - 2023-08-18 05:04:04 --> Helper loaded: security_helper
INFO - 2023-08-18 05:04:04 --> Helper loaded: cookie_helper
INFO - 2023-08-18 05:04:04 --> Database Driver Class Initialized
INFO - 2023-08-18 05:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 05:04:04 --> Parser Class Initialized
INFO - 2023-08-18 05:04:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 05:04:04 --> Pagination Class Initialized
INFO - 2023-08-18 05:04:04 --> Form Validation Class Initialized
INFO - 2023-08-18 05:04:04 --> Controller Class Initialized
INFO - 2023-08-18 05:04:04 --> Model Class Initialized
DEBUG - 2023-08-18 05:04:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 05:04:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:04:04 --> Model Class Initialized
DEBUG - 2023-08-18 05:04:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:04:04 --> Model Class Initialized
INFO - 2023-08-18 05:04:04 --> Final output sent to browser
DEBUG - 2023-08-18 05:04:04 --> Total execution time: 0.0396
ERROR - 2023-08-18 05:04:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 05:04:11 --> Config Class Initialized
INFO - 2023-08-18 05:04:11 --> Hooks Class Initialized
DEBUG - 2023-08-18 05:04:11 --> UTF-8 Support Enabled
INFO - 2023-08-18 05:04:11 --> Utf8 Class Initialized
INFO - 2023-08-18 05:04:11 --> URI Class Initialized
INFO - 2023-08-18 05:04:11 --> Router Class Initialized
INFO - 2023-08-18 05:04:11 --> Output Class Initialized
INFO - 2023-08-18 05:04:11 --> Security Class Initialized
DEBUG - 2023-08-18 05:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 05:04:11 --> Input Class Initialized
INFO - 2023-08-18 05:04:11 --> Language Class Initialized
INFO - 2023-08-18 05:04:11 --> Loader Class Initialized
INFO - 2023-08-18 05:04:11 --> Helper loaded: url_helper
INFO - 2023-08-18 05:04:11 --> Helper loaded: file_helper
INFO - 2023-08-18 05:04:11 --> Helper loaded: html_helper
INFO - 2023-08-18 05:04:11 --> Helper loaded: text_helper
INFO - 2023-08-18 05:04:11 --> Helper loaded: form_helper
INFO - 2023-08-18 05:04:11 --> Helper loaded: lang_helper
INFO - 2023-08-18 05:04:11 --> Helper loaded: security_helper
INFO - 2023-08-18 05:04:11 --> Helper loaded: cookie_helper
INFO - 2023-08-18 05:04:11 --> Database Driver Class Initialized
INFO - 2023-08-18 05:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 05:04:11 --> Parser Class Initialized
INFO - 2023-08-18 05:04:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 05:04:11 --> Pagination Class Initialized
INFO - 2023-08-18 05:04:11 --> Form Validation Class Initialized
INFO - 2023-08-18 05:04:11 --> Controller Class Initialized
INFO - 2023-08-18 05:04:11 --> Model Class Initialized
DEBUG - 2023-08-18 05:04:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 05:04:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:04:11 --> Model Class Initialized
DEBUG - 2023-08-18 05:04:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:04:11 --> Model Class Initialized
INFO - 2023-08-18 05:04:11 --> Final output sent to browser
DEBUG - 2023-08-18 05:04:11 --> Total execution time: 0.0405
ERROR - 2023-08-18 05:04:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 05:04:26 --> Config Class Initialized
INFO - 2023-08-18 05:04:26 --> Hooks Class Initialized
DEBUG - 2023-08-18 05:04:26 --> UTF-8 Support Enabled
INFO - 2023-08-18 05:04:26 --> Utf8 Class Initialized
INFO - 2023-08-18 05:04:26 --> URI Class Initialized
INFO - 2023-08-18 05:04:26 --> Router Class Initialized
INFO - 2023-08-18 05:04:26 --> Output Class Initialized
INFO - 2023-08-18 05:04:26 --> Security Class Initialized
DEBUG - 2023-08-18 05:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 05:04:26 --> Input Class Initialized
INFO - 2023-08-18 05:04:26 --> Language Class Initialized
INFO - 2023-08-18 05:04:26 --> Loader Class Initialized
INFO - 2023-08-18 05:04:26 --> Helper loaded: url_helper
INFO - 2023-08-18 05:04:26 --> Helper loaded: file_helper
INFO - 2023-08-18 05:04:26 --> Helper loaded: html_helper
INFO - 2023-08-18 05:04:26 --> Helper loaded: text_helper
INFO - 2023-08-18 05:04:26 --> Helper loaded: form_helper
INFO - 2023-08-18 05:04:26 --> Helper loaded: lang_helper
INFO - 2023-08-18 05:04:26 --> Helper loaded: security_helper
INFO - 2023-08-18 05:04:26 --> Helper loaded: cookie_helper
INFO - 2023-08-18 05:04:26 --> Database Driver Class Initialized
INFO - 2023-08-18 05:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 05:04:26 --> Parser Class Initialized
INFO - 2023-08-18 05:04:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 05:04:26 --> Pagination Class Initialized
INFO - 2023-08-18 05:04:26 --> Form Validation Class Initialized
INFO - 2023-08-18 05:04:26 --> Controller Class Initialized
INFO - 2023-08-18 05:04:26 --> Model Class Initialized
DEBUG - 2023-08-18 05:04:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 05:04:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:04:26 --> Model Class Initialized
DEBUG - 2023-08-18 05:04:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:04:26 --> Model Class Initialized
INFO - 2023-08-18 05:04:26 --> Final output sent to browser
DEBUG - 2023-08-18 05:04:26 --> Total execution time: 0.0556
ERROR - 2023-08-18 05:04:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 05:04:26 --> Config Class Initialized
INFO - 2023-08-18 05:04:26 --> Hooks Class Initialized
DEBUG - 2023-08-18 05:04:26 --> UTF-8 Support Enabled
INFO - 2023-08-18 05:04:26 --> Utf8 Class Initialized
INFO - 2023-08-18 05:04:26 --> URI Class Initialized
INFO - 2023-08-18 05:04:26 --> Router Class Initialized
INFO - 2023-08-18 05:04:26 --> Output Class Initialized
INFO - 2023-08-18 05:04:26 --> Security Class Initialized
DEBUG - 2023-08-18 05:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 05:04:26 --> Input Class Initialized
INFO - 2023-08-18 05:04:26 --> Language Class Initialized
INFO - 2023-08-18 05:04:26 --> Loader Class Initialized
INFO - 2023-08-18 05:04:26 --> Helper loaded: url_helper
INFO - 2023-08-18 05:04:26 --> Helper loaded: file_helper
INFO - 2023-08-18 05:04:26 --> Helper loaded: html_helper
INFO - 2023-08-18 05:04:26 --> Helper loaded: text_helper
INFO - 2023-08-18 05:04:26 --> Helper loaded: form_helper
INFO - 2023-08-18 05:04:26 --> Helper loaded: lang_helper
INFO - 2023-08-18 05:04:26 --> Helper loaded: security_helper
INFO - 2023-08-18 05:04:26 --> Helper loaded: cookie_helper
INFO - 2023-08-18 05:04:26 --> Database Driver Class Initialized
INFO - 2023-08-18 05:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 05:04:26 --> Parser Class Initialized
INFO - 2023-08-18 05:04:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 05:04:26 --> Pagination Class Initialized
INFO - 2023-08-18 05:04:26 --> Form Validation Class Initialized
INFO - 2023-08-18 05:04:26 --> Controller Class Initialized
INFO - 2023-08-18 05:04:26 --> Model Class Initialized
DEBUG - 2023-08-18 05:04:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 05:04:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:04:26 --> Model Class Initialized
DEBUG - 2023-08-18 05:04:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:04:26 --> Model Class Initialized
INFO - 2023-08-18 05:04:26 --> Final output sent to browser
DEBUG - 2023-08-18 05:04:26 --> Total execution time: 0.0421
ERROR - 2023-08-18 05:04:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 05:04:28 --> Config Class Initialized
INFO - 2023-08-18 05:04:28 --> Hooks Class Initialized
DEBUG - 2023-08-18 05:04:28 --> UTF-8 Support Enabled
INFO - 2023-08-18 05:04:28 --> Utf8 Class Initialized
INFO - 2023-08-18 05:04:28 --> URI Class Initialized
INFO - 2023-08-18 05:04:28 --> Router Class Initialized
INFO - 2023-08-18 05:04:28 --> Output Class Initialized
INFO - 2023-08-18 05:04:28 --> Security Class Initialized
DEBUG - 2023-08-18 05:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 05:04:28 --> Input Class Initialized
INFO - 2023-08-18 05:04:28 --> Language Class Initialized
INFO - 2023-08-18 05:04:28 --> Loader Class Initialized
INFO - 2023-08-18 05:04:28 --> Helper loaded: url_helper
INFO - 2023-08-18 05:04:28 --> Helper loaded: file_helper
INFO - 2023-08-18 05:04:28 --> Helper loaded: html_helper
INFO - 2023-08-18 05:04:28 --> Helper loaded: text_helper
INFO - 2023-08-18 05:04:28 --> Helper loaded: form_helper
INFO - 2023-08-18 05:04:28 --> Helper loaded: lang_helper
INFO - 2023-08-18 05:04:28 --> Helper loaded: security_helper
INFO - 2023-08-18 05:04:28 --> Helper loaded: cookie_helper
INFO - 2023-08-18 05:04:28 --> Database Driver Class Initialized
INFO - 2023-08-18 05:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 05:04:28 --> Parser Class Initialized
INFO - 2023-08-18 05:04:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 05:04:28 --> Pagination Class Initialized
INFO - 2023-08-18 05:04:28 --> Form Validation Class Initialized
INFO - 2023-08-18 05:04:28 --> Controller Class Initialized
INFO - 2023-08-18 05:04:28 --> Model Class Initialized
DEBUG - 2023-08-18 05:04:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 05:04:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:04:28 --> Model Class Initialized
DEBUG - 2023-08-18 05:04:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:04:28 --> Model Class Initialized
INFO - 2023-08-18 05:04:28 --> Final output sent to browser
DEBUG - 2023-08-18 05:04:28 --> Total execution time: 0.0263
ERROR - 2023-08-18 05:04:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 05:04:31 --> Config Class Initialized
INFO - 2023-08-18 05:04:31 --> Hooks Class Initialized
DEBUG - 2023-08-18 05:04:31 --> UTF-8 Support Enabled
INFO - 2023-08-18 05:04:31 --> Utf8 Class Initialized
INFO - 2023-08-18 05:04:31 --> URI Class Initialized
INFO - 2023-08-18 05:04:31 --> Router Class Initialized
INFO - 2023-08-18 05:04:31 --> Output Class Initialized
INFO - 2023-08-18 05:04:31 --> Security Class Initialized
DEBUG - 2023-08-18 05:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 05:04:31 --> Input Class Initialized
INFO - 2023-08-18 05:04:31 --> Language Class Initialized
INFO - 2023-08-18 05:04:31 --> Loader Class Initialized
INFO - 2023-08-18 05:04:31 --> Helper loaded: url_helper
INFO - 2023-08-18 05:04:31 --> Helper loaded: file_helper
INFO - 2023-08-18 05:04:31 --> Helper loaded: html_helper
INFO - 2023-08-18 05:04:31 --> Helper loaded: text_helper
INFO - 2023-08-18 05:04:31 --> Helper loaded: form_helper
INFO - 2023-08-18 05:04:31 --> Helper loaded: lang_helper
INFO - 2023-08-18 05:04:31 --> Helper loaded: security_helper
INFO - 2023-08-18 05:04:31 --> Helper loaded: cookie_helper
INFO - 2023-08-18 05:04:31 --> Database Driver Class Initialized
INFO - 2023-08-18 05:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 05:04:31 --> Parser Class Initialized
INFO - 2023-08-18 05:04:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 05:04:31 --> Pagination Class Initialized
INFO - 2023-08-18 05:04:31 --> Form Validation Class Initialized
INFO - 2023-08-18 05:04:31 --> Controller Class Initialized
INFO - 2023-08-18 05:04:31 --> Model Class Initialized
DEBUG - 2023-08-18 05:04:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 05:04:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:04:31 --> Model Class Initialized
DEBUG - 2023-08-18 05:04:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:04:31 --> Model Class Initialized
INFO - 2023-08-18 05:04:31 --> Final output sent to browser
DEBUG - 2023-08-18 05:04:31 --> Total execution time: 0.0404
ERROR - 2023-08-18 05:04:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 05:04:32 --> Config Class Initialized
INFO - 2023-08-18 05:04:32 --> Hooks Class Initialized
DEBUG - 2023-08-18 05:04:32 --> UTF-8 Support Enabled
INFO - 2023-08-18 05:04:32 --> Utf8 Class Initialized
INFO - 2023-08-18 05:04:32 --> URI Class Initialized
INFO - 2023-08-18 05:04:32 --> Router Class Initialized
INFO - 2023-08-18 05:04:32 --> Output Class Initialized
INFO - 2023-08-18 05:04:32 --> Security Class Initialized
DEBUG - 2023-08-18 05:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 05:04:32 --> Input Class Initialized
INFO - 2023-08-18 05:04:32 --> Language Class Initialized
INFO - 2023-08-18 05:04:32 --> Loader Class Initialized
INFO - 2023-08-18 05:04:32 --> Helper loaded: url_helper
INFO - 2023-08-18 05:04:32 --> Helper loaded: file_helper
INFO - 2023-08-18 05:04:32 --> Helper loaded: html_helper
INFO - 2023-08-18 05:04:32 --> Helper loaded: text_helper
INFO - 2023-08-18 05:04:32 --> Helper loaded: form_helper
INFO - 2023-08-18 05:04:32 --> Helper loaded: lang_helper
INFO - 2023-08-18 05:04:32 --> Helper loaded: security_helper
INFO - 2023-08-18 05:04:32 --> Helper loaded: cookie_helper
INFO - 2023-08-18 05:04:32 --> Database Driver Class Initialized
INFO - 2023-08-18 05:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 05:04:32 --> Parser Class Initialized
INFO - 2023-08-18 05:04:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 05:04:32 --> Pagination Class Initialized
INFO - 2023-08-18 05:04:32 --> Form Validation Class Initialized
INFO - 2023-08-18 05:04:32 --> Controller Class Initialized
INFO - 2023-08-18 05:04:32 --> Model Class Initialized
DEBUG - 2023-08-18 05:04:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 05:04:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:04:32 --> Model Class Initialized
DEBUG - 2023-08-18 05:04:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:04:32 --> Model Class Initialized
INFO - 2023-08-18 05:04:32 --> Final output sent to browser
DEBUG - 2023-08-18 05:04:32 --> Total execution time: 0.0421
ERROR - 2023-08-18 05:04:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 05:04:34 --> Config Class Initialized
INFO - 2023-08-18 05:04:34 --> Hooks Class Initialized
DEBUG - 2023-08-18 05:04:34 --> UTF-8 Support Enabled
INFO - 2023-08-18 05:04:34 --> Utf8 Class Initialized
INFO - 2023-08-18 05:04:34 --> URI Class Initialized
INFO - 2023-08-18 05:04:34 --> Router Class Initialized
INFO - 2023-08-18 05:04:34 --> Output Class Initialized
INFO - 2023-08-18 05:04:34 --> Security Class Initialized
DEBUG - 2023-08-18 05:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 05:04:34 --> Input Class Initialized
INFO - 2023-08-18 05:04:34 --> Language Class Initialized
INFO - 2023-08-18 05:04:34 --> Loader Class Initialized
INFO - 2023-08-18 05:04:34 --> Helper loaded: url_helper
INFO - 2023-08-18 05:04:34 --> Helper loaded: file_helper
INFO - 2023-08-18 05:04:34 --> Helper loaded: html_helper
INFO - 2023-08-18 05:04:34 --> Helper loaded: text_helper
INFO - 2023-08-18 05:04:34 --> Helper loaded: form_helper
INFO - 2023-08-18 05:04:34 --> Helper loaded: lang_helper
INFO - 2023-08-18 05:04:34 --> Helper loaded: security_helper
INFO - 2023-08-18 05:04:34 --> Helper loaded: cookie_helper
INFO - 2023-08-18 05:04:34 --> Database Driver Class Initialized
INFO - 2023-08-18 05:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 05:04:34 --> Parser Class Initialized
INFO - 2023-08-18 05:04:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 05:04:34 --> Pagination Class Initialized
INFO - 2023-08-18 05:04:34 --> Form Validation Class Initialized
INFO - 2023-08-18 05:04:34 --> Controller Class Initialized
INFO - 2023-08-18 05:04:34 --> Model Class Initialized
DEBUG - 2023-08-18 05:04:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 05:04:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:04:34 --> Model Class Initialized
DEBUG - 2023-08-18 05:04:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:04:34 --> Model Class Initialized
INFO - 2023-08-18 05:04:34 --> Final output sent to browser
DEBUG - 2023-08-18 05:04:34 --> Total execution time: 0.0402
ERROR - 2023-08-18 05:04:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 05:04:34 --> Config Class Initialized
INFO - 2023-08-18 05:04:34 --> Hooks Class Initialized
DEBUG - 2023-08-18 05:04:34 --> UTF-8 Support Enabled
INFO - 2023-08-18 05:04:34 --> Utf8 Class Initialized
INFO - 2023-08-18 05:04:34 --> URI Class Initialized
INFO - 2023-08-18 05:04:34 --> Router Class Initialized
INFO - 2023-08-18 05:04:34 --> Output Class Initialized
INFO - 2023-08-18 05:04:34 --> Security Class Initialized
DEBUG - 2023-08-18 05:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 05:04:34 --> Input Class Initialized
INFO - 2023-08-18 05:04:34 --> Language Class Initialized
INFO - 2023-08-18 05:04:34 --> Loader Class Initialized
INFO - 2023-08-18 05:04:34 --> Helper loaded: url_helper
INFO - 2023-08-18 05:04:34 --> Helper loaded: file_helper
INFO - 2023-08-18 05:04:34 --> Helper loaded: html_helper
INFO - 2023-08-18 05:04:34 --> Helper loaded: text_helper
INFO - 2023-08-18 05:04:34 --> Helper loaded: form_helper
INFO - 2023-08-18 05:04:34 --> Helper loaded: lang_helper
INFO - 2023-08-18 05:04:34 --> Helper loaded: security_helper
INFO - 2023-08-18 05:04:34 --> Helper loaded: cookie_helper
INFO - 2023-08-18 05:04:34 --> Database Driver Class Initialized
INFO - 2023-08-18 05:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 05:04:34 --> Parser Class Initialized
INFO - 2023-08-18 05:04:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 05:04:34 --> Pagination Class Initialized
INFO - 2023-08-18 05:04:34 --> Form Validation Class Initialized
INFO - 2023-08-18 05:04:34 --> Controller Class Initialized
INFO - 2023-08-18 05:04:34 --> Model Class Initialized
DEBUG - 2023-08-18 05:04:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 05:04:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:04:34 --> Model Class Initialized
DEBUG - 2023-08-18 05:04:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:04:34 --> Model Class Initialized
INFO - 2023-08-18 05:04:34 --> Final output sent to browser
DEBUG - 2023-08-18 05:04:34 --> Total execution time: 0.0382
ERROR - 2023-08-18 05:04:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 05:04:34 --> Config Class Initialized
INFO - 2023-08-18 05:04:34 --> Hooks Class Initialized
DEBUG - 2023-08-18 05:04:34 --> UTF-8 Support Enabled
INFO - 2023-08-18 05:04:34 --> Utf8 Class Initialized
INFO - 2023-08-18 05:04:34 --> URI Class Initialized
INFO - 2023-08-18 05:04:34 --> Router Class Initialized
INFO - 2023-08-18 05:04:34 --> Output Class Initialized
INFO - 2023-08-18 05:04:34 --> Security Class Initialized
DEBUG - 2023-08-18 05:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 05:04:34 --> Input Class Initialized
INFO - 2023-08-18 05:04:34 --> Language Class Initialized
INFO - 2023-08-18 05:04:34 --> Loader Class Initialized
INFO - 2023-08-18 05:04:34 --> Helper loaded: url_helper
INFO - 2023-08-18 05:04:34 --> Helper loaded: file_helper
INFO - 2023-08-18 05:04:34 --> Helper loaded: html_helper
INFO - 2023-08-18 05:04:34 --> Helper loaded: text_helper
INFO - 2023-08-18 05:04:34 --> Helper loaded: form_helper
INFO - 2023-08-18 05:04:34 --> Helper loaded: lang_helper
INFO - 2023-08-18 05:04:34 --> Helper loaded: security_helper
INFO - 2023-08-18 05:04:34 --> Helper loaded: cookie_helper
INFO - 2023-08-18 05:04:34 --> Database Driver Class Initialized
INFO - 2023-08-18 05:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 05:04:34 --> Parser Class Initialized
INFO - 2023-08-18 05:04:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 05:04:34 --> Pagination Class Initialized
INFO - 2023-08-18 05:04:34 --> Form Validation Class Initialized
INFO - 2023-08-18 05:04:34 --> Controller Class Initialized
INFO - 2023-08-18 05:04:34 --> Model Class Initialized
DEBUG - 2023-08-18 05:04:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 05:04:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:04:34 --> Model Class Initialized
DEBUG - 2023-08-18 05:04:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:04:34 --> Model Class Initialized
INFO - 2023-08-18 05:04:34 --> Final output sent to browser
DEBUG - 2023-08-18 05:04:34 --> Total execution time: 0.0355
ERROR - 2023-08-18 05:04:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 05:04:35 --> Config Class Initialized
INFO - 2023-08-18 05:04:35 --> Hooks Class Initialized
DEBUG - 2023-08-18 05:04:35 --> UTF-8 Support Enabled
INFO - 2023-08-18 05:04:35 --> Utf8 Class Initialized
INFO - 2023-08-18 05:04:35 --> URI Class Initialized
INFO - 2023-08-18 05:04:35 --> Router Class Initialized
INFO - 2023-08-18 05:04:35 --> Output Class Initialized
INFO - 2023-08-18 05:04:35 --> Security Class Initialized
DEBUG - 2023-08-18 05:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 05:04:35 --> Input Class Initialized
INFO - 2023-08-18 05:04:35 --> Language Class Initialized
INFO - 2023-08-18 05:04:35 --> Loader Class Initialized
INFO - 2023-08-18 05:04:35 --> Helper loaded: url_helper
INFO - 2023-08-18 05:04:35 --> Helper loaded: file_helper
INFO - 2023-08-18 05:04:35 --> Helper loaded: html_helper
INFO - 2023-08-18 05:04:35 --> Helper loaded: text_helper
INFO - 2023-08-18 05:04:35 --> Helper loaded: form_helper
INFO - 2023-08-18 05:04:35 --> Helper loaded: lang_helper
INFO - 2023-08-18 05:04:35 --> Helper loaded: security_helper
INFO - 2023-08-18 05:04:35 --> Helper loaded: cookie_helper
INFO - 2023-08-18 05:04:35 --> Database Driver Class Initialized
INFO - 2023-08-18 05:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 05:04:35 --> Parser Class Initialized
INFO - 2023-08-18 05:04:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 05:04:35 --> Pagination Class Initialized
INFO - 2023-08-18 05:04:35 --> Form Validation Class Initialized
INFO - 2023-08-18 05:04:35 --> Controller Class Initialized
INFO - 2023-08-18 05:04:35 --> Model Class Initialized
DEBUG - 2023-08-18 05:04:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 05:04:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:04:35 --> Model Class Initialized
DEBUG - 2023-08-18 05:04:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:04:35 --> Model Class Initialized
INFO - 2023-08-18 05:04:35 --> Final output sent to browser
DEBUG - 2023-08-18 05:04:35 --> Total execution time: 0.0249
ERROR - 2023-08-18 05:04:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 05:04:35 --> Config Class Initialized
INFO - 2023-08-18 05:04:35 --> Hooks Class Initialized
DEBUG - 2023-08-18 05:04:35 --> UTF-8 Support Enabled
INFO - 2023-08-18 05:04:35 --> Utf8 Class Initialized
INFO - 2023-08-18 05:04:35 --> URI Class Initialized
INFO - 2023-08-18 05:04:35 --> Router Class Initialized
INFO - 2023-08-18 05:04:35 --> Output Class Initialized
INFO - 2023-08-18 05:04:35 --> Security Class Initialized
DEBUG - 2023-08-18 05:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 05:04:35 --> Input Class Initialized
INFO - 2023-08-18 05:04:35 --> Language Class Initialized
INFO - 2023-08-18 05:04:35 --> Loader Class Initialized
INFO - 2023-08-18 05:04:35 --> Helper loaded: url_helper
INFO - 2023-08-18 05:04:35 --> Helper loaded: file_helper
INFO - 2023-08-18 05:04:35 --> Helper loaded: html_helper
INFO - 2023-08-18 05:04:35 --> Helper loaded: text_helper
INFO - 2023-08-18 05:04:35 --> Helper loaded: form_helper
INFO - 2023-08-18 05:04:35 --> Helper loaded: lang_helper
INFO - 2023-08-18 05:04:35 --> Helper loaded: security_helper
INFO - 2023-08-18 05:04:35 --> Helper loaded: cookie_helper
INFO - 2023-08-18 05:04:35 --> Database Driver Class Initialized
INFO - 2023-08-18 05:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 05:04:35 --> Parser Class Initialized
INFO - 2023-08-18 05:04:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 05:04:35 --> Pagination Class Initialized
INFO - 2023-08-18 05:04:35 --> Form Validation Class Initialized
INFO - 2023-08-18 05:04:35 --> Controller Class Initialized
INFO - 2023-08-18 05:04:35 --> Model Class Initialized
DEBUG - 2023-08-18 05:04:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 05:04:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:04:35 --> Model Class Initialized
DEBUG - 2023-08-18 05:04:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:04:35 --> Model Class Initialized
INFO - 2023-08-18 05:04:35 --> Final output sent to browser
DEBUG - 2023-08-18 05:04:35 --> Total execution time: 0.0228
ERROR - 2023-08-18 05:57:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 05:57:01 --> Config Class Initialized
INFO - 2023-08-18 05:57:01 --> Hooks Class Initialized
DEBUG - 2023-08-18 05:57:01 --> UTF-8 Support Enabled
INFO - 2023-08-18 05:57:01 --> Utf8 Class Initialized
INFO - 2023-08-18 05:57:01 --> URI Class Initialized
DEBUG - 2023-08-18 05:57:01 --> No URI present. Default controller set.
INFO - 2023-08-18 05:57:01 --> Router Class Initialized
INFO - 2023-08-18 05:57:01 --> Output Class Initialized
INFO - 2023-08-18 05:57:01 --> Security Class Initialized
DEBUG - 2023-08-18 05:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 05:57:01 --> Input Class Initialized
INFO - 2023-08-18 05:57:01 --> Language Class Initialized
INFO - 2023-08-18 05:57:01 --> Loader Class Initialized
INFO - 2023-08-18 05:57:01 --> Helper loaded: url_helper
INFO - 2023-08-18 05:57:01 --> Helper loaded: file_helper
INFO - 2023-08-18 05:57:01 --> Helper loaded: html_helper
INFO - 2023-08-18 05:57:01 --> Helper loaded: text_helper
INFO - 2023-08-18 05:57:01 --> Helper loaded: form_helper
INFO - 2023-08-18 05:57:01 --> Helper loaded: lang_helper
INFO - 2023-08-18 05:57:01 --> Helper loaded: security_helper
INFO - 2023-08-18 05:57:01 --> Helper loaded: cookie_helper
INFO - 2023-08-18 05:57:01 --> Database Driver Class Initialized
INFO - 2023-08-18 05:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 05:57:01 --> Parser Class Initialized
INFO - 2023-08-18 05:57:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 05:57:01 --> Pagination Class Initialized
INFO - 2023-08-18 05:57:01 --> Form Validation Class Initialized
INFO - 2023-08-18 05:57:01 --> Controller Class Initialized
INFO - 2023-08-18 05:57:01 --> Model Class Initialized
DEBUG - 2023-08-18 05:57:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-18 05:57:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 05:57:01 --> Config Class Initialized
INFO - 2023-08-18 05:57:01 --> Hooks Class Initialized
DEBUG - 2023-08-18 05:57:01 --> UTF-8 Support Enabled
INFO - 2023-08-18 05:57:01 --> Utf8 Class Initialized
INFO - 2023-08-18 05:57:01 --> URI Class Initialized
INFO - 2023-08-18 05:57:01 --> Router Class Initialized
INFO - 2023-08-18 05:57:01 --> Output Class Initialized
INFO - 2023-08-18 05:57:01 --> Security Class Initialized
DEBUG - 2023-08-18 05:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 05:57:01 --> Input Class Initialized
INFO - 2023-08-18 05:57:01 --> Language Class Initialized
INFO - 2023-08-18 05:57:02 --> Loader Class Initialized
INFO - 2023-08-18 05:57:02 --> Helper loaded: url_helper
INFO - 2023-08-18 05:57:02 --> Helper loaded: file_helper
INFO - 2023-08-18 05:57:02 --> Helper loaded: html_helper
INFO - 2023-08-18 05:57:02 --> Helper loaded: text_helper
INFO - 2023-08-18 05:57:02 --> Helper loaded: form_helper
INFO - 2023-08-18 05:57:02 --> Helper loaded: lang_helper
INFO - 2023-08-18 05:57:02 --> Helper loaded: security_helper
INFO - 2023-08-18 05:57:02 --> Helper loaded: cookie_helper
INFO - 2023-08-18 05:57:02 --> Database Driver Class Initialized
INFO - 2023-08-18 05:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 05:57:02 --> Parser Class Initialized
INFO - 2023-08-18 05:57:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 05:57:02 --> Pagination Class Initialized
INFO - 2023-08-18 05:57:02 --> Form Validation Class Initialized
INFO - 2023-08-18 05:57:02 --> Controller Class Initialized
INFO - 2023-08-18 05:57:02 --> Model Class Initialized
DEBUG - 2023-08-18 05:57:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:57:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-18 05:57:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 05:57:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 05:57:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 05:57:02 --> Model Class Initialized
INFO - 2023-08-18 05:57:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 05:57:02 --> Final output sent to browser
DEBUG - 2023-08-18 05:57:02 --> Total execution time: 0.0326
ERROR - 2023-08-18 07:28:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:28:09 --> Config Class Initialized
INFO - 2023-08-18 07:28:09 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:28:09 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:28:09 --> Utf8 Class Initialized
INFO - 2023-08-18 07:28:09 --> URI Class Initialized
DEBUG - 2023-08-18 07:28:09 --> No URI present. Default controller set.
INFO - 2023-08-18 07:28:09 --> Router Class Initialized
INFO - 2023-08-18 07:28:09 --> Output Class Initialized
INFO - 2023-08-18 07:28:09 --> Security Class Initialized
DEBUG - 2023-08-18 07:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:28:09 --> Input Class Initialized
INFO - 2023-08-18 07:28:09 --> Language Class Initialized
INFO - 2023-08-18 07:28:09 --> Loader Class Initialized
INFO - 2023-08-18 07:28:09 --> Helper loaded: url_helper
INFO - 2023-08-18 07:28:09 --> Helper loaded: file_helper
INFO - 2023-08-18 07:28:09 --> Helper loaded: html_helper
INFO - 2023-08-18 07:28:09 --> Helper loaded: text_helper
INFO - 2023-08-18 07:28:09 --> Helper loaded: form_helper
INFO - 2023-08-18 07:28:09 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:28:09 --> Helper loaded: security_helper
INFO - 2023-08-18 07:28:09 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:28:09 --> Database Driver Class Initialized
INFO - 2023-08-18 07:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:28:09 --> Parser Class Initialized
INFO - 2023-08-18 07:28:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:28:09 --> Pagination Class Initialized
INFO - 2023-08-18 07:28:09 --> Form Validation Class Initialized
INFO - 2023-08-18 07:28:09 --> Controller Class Initialized
INFO - 2023-08-18 07:28:09 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-18 07:28:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:28:09 --> Config Class Initialized
INFO - 2023-08-18 07:28:09 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:28:09 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:28:09 --> Utf8 Class Initialized
INFO - 2023-08-18 07:28:09 --> URI Class Initialized
INFO - 2023-08-18 07:28:09 --> Router Class Initialized
INFO - 2023-08-18 07:28:09 --> Output Class Initialized
INFO - 2023-08-18 07:28:09 --> Security Class Initialized
DEBUG - 2023-08-18 07:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:28:09 --> Input Class Initialized
INFO - 2023-08-18 07:28:09 --> Language Class Initialized
INFO - 2023-08-18 07:28:09 --> Loader Class Initialized
INFO - 2023-08-18 07:28:09 --> Helper loaded: url_helper
INFO - 2023-08-18 07:28:09 --> Helper loaded: file_helper
INFO - 2023-08-18 07:28:09 --> Helper loaded: html_helper
INFO - 2023-08-18 07:28:09 --> Helper loaded: text_helper
INFO - 2023-08-18 07:28:09 --> Helper loaded: form_helper
INFO - 2023-08-18 07:28:09 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:28:09 --> Helper loaded: security_helper
INFO - 2023-08-18 07:28:09 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:28:09 --> Database Driver Class Initialized
INFO - 2023-08-18 07:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:28:09 --> Parser Class Initialized
INFO - 2023-08-18 07:28:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:28:09 --> Pagination Class Initialized
INFO - 2023-08-18 07:28:09 --> Form Validation Class Initialized
INFO - 2023-08-18 07:28:09 --> Controller Class Initialized
INFO - 2023-08-18 07:28:09 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-18 07:28:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 07:28:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 07:28:09 --> Model Class Initialized
INFO - 2023-08-18 07:28:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 07:28:09 --> Final output sent to browser
DEBUG - 2023-08-18 07:28:09 --> Total execution time: 0.0296
ERROR - 2023-08-18 07:28:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:28:12 --> Config Class Initialized
INFO - 2023-08-18 07:28:12 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:28:12 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:28:12 --> Utf8 Class Initialized
INFO - 2023-08-18 07:28:12 --> URI Class Initialized
INFO - 2023-08-18 07:28:12 --> Router Class Initialized
INFO - 2023-08-18 07:28:12 --> Output Class Initialized
INFO - 2023-08-18 07:28:12 --> Security Class Initialized
DEBUG - 2023-08-18 07:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:28:12 --> Input Class Initialized
INFO - 2023-08-18 07:28:12 --> Language Class Initialized
INFO - 2023-08-18 07:28:12 --> Loader Class Initialized
INFO - 2023-08-18 07:28:12 --> Helper loaded: url_helper
INFO - 2023-08-18 07:28:12 --> Helper loaded: file_helper
INFO - 2023-08-18 07:28:12 --> Helper loaded: html_helper
INFO - 2023-08-18 07:28:12 --> Helper loaded: text_helper
INFO - 2023-08-18 07:28:12 --> Helper loaded: form_helper
INFO - 2023-08-18 07:28:12 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:28:12 --> Helper loaded: security_helper
INFO - 2023-08-18 07:28:12 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:28:12 --> Database Driver Class Initialized
INFO - 2023-08-18 07:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:28:12 --> Parser Class Initialized
INFO - 2023-08-18 07:28:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:28:12 --> Pagination Class Initialized
INFO - 2023-08-18 07:28:12 --> Form Validation Class Initialized
INFO - 2023-08-18 07:28:12 --> Controller Class Initialized
INFO - 2023-08-18 07:28:12 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:12 --> Model Class Initialized
INFO - 2023-08-18 07:28:12 --> Final output sent to browser
DEBUG - 2023-08-18 07:28:12 --> Total execution time: 0.0184
ERROR - 2023-08-18 07:28:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:28:12 --> Config Class Initialized
INFO - 2023-08-18 07:28:12 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:28:12 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:28:12 --> Utf8 Class Initialized
INFO - 2023-08-18 07:28:12 --> URI Class Initialized
DEBUG - 2023-08-18 07:28:12 --> No URI present. Default controller set.
INFO - 2023-08-18 07:28:12 --> Router Class Initialized
INFO - 2023-08-18 07:28:12 --> Output Class Initialized
INFO - 2023-08-18 07:28:12 --> Security Class Initialized
DEBUG - 2023-08-18 07:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:28:12 --> Input Class Initialized
INFO - 2023-08-18 07:28:12 --> Language Class Initialized
INFO - 2023-08-18 07:28:12 --> Loader Class Initialized
INFO - 2023-08-18 07:28:12 --> Helper loaded: url_helper
INFO - 2023-08-18 07:28:12 --> Helper loaded: file_helper
INFO - 2023-08-18 07:28:12 --> Helper loaded: html_helper
INFO - 2023-08-18 07:28:12 --> Helper loaded: text_helper
INFO - 2023-08-18 07:28:12 --> Helper loaded: form_helper
INFO - 2023-08-18 07:28:12 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:28:12 --> Helper loaded: security_helper
INFO - 2023-08-18 07:28:12 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:28:12 --> Database Driver Class Initialized
INFO - 2023-08-18 07:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:28:12 --> Parser Class Initialized
INFO - 2023-08-18 07:28:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:28:12 --> Pagination Class Initialized
INFO - 2023-08-18 07:28:12 --> Form Validation Class Initialized
INFO - 2023-08-18 07:28:12 --> Controller Class Initialized
INFO - 2023-08-18 07:28:12 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:12 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:12 --> Model Class Initialized
INFO - 2023-08-18 07:28:12 --> Model Class Initialized
INFO - 2023-08-18 07:28:12 --> Model Class Initialized
INFO - 2023-08-18 07:28:12 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:28:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:12 --> Model Class Initialized
INFO - 2023-08-18 07:28:12 --> Model Class Initialized
INFO - 2023-08-18 07:28:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-18 07:28:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 07:28:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 07:28:12 --> Model Class Initialized
INFO - 2023-08-18 07:28:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 07:28:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 07:28:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 07:28:12 --> Final output sent to browser
DEBUG - 2023-08-18 07:28:12 --> Total execution time: 0.2127
ERROR - 2023-08-18 07:28:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:28:13 --> Config Class Initialized
INFO - 2023-08-18 07:28:13 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:28:13 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:28:13 --> Utf8 Class Initialized
INFO - 2023-08-18 07:28:13 --> URI Class Initialized
INFO - 2023-08-18 07:28:13 --> Router Class Initialized
INFO - 2023-08-18 07:28:13 --> Output Class Initialized
INFO - 2023-08-18 07:28:13 --> Security Class Initialized
DEBUG - 2023-08-18 07:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:28:13 --> Input Class Initialized
INFO - 2023-08-18 07:28:13 --> Language Class Initialized
INFO - 2023-08-18 07:28:13 --> Loader Class Initialized
INFO - 2023-08-18 07:28:13 --> Helper loaded: url_helper
INFO - 2023-08-18 07:28:13 --> Helper loaded: file_helper
INFO - 2023-08-18 07:28:13 --> Helper loaded: html_helper
INFO - 2023-08-18 07:28:13 --> Helper loaded: text_helper
INFO - 2023-08-18 07:28:13 --> Helper loaded: form_helper
INFO - 2023-08-18 07:28:13 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:28:13 --> Helper loaded: security_helper
INFO - 2023-08-18 07:28:13 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:28:13 --> Database Driver Class Initialized
INFO - 2023-08-18 07:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:28:13 --> Parser Class Initialized
INFO - 2023-08-18 07:28:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:28:13 --> Pagination Class Initialized
INFO - 2023-08-18 07:28:13 --> Form Validation Class Initialized
INFO - 2023-08-18 07:28:13 --> Controller Class Initialized
DEBUG - 2023-08-18 07:28:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:28:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:13 --> Model Class Initialized
INFO - 2023-08-18 07:28:13 --> Final output sent to browser
DEBUG - 2023-08-18 07:28:13 --> Total execution time: 0.0133
ERROR - 2023-08-18 07:28:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:28:19 --> Config Class Initialized
INFO - 2023-08-18 07:28:19 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:28:19 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:28:19 --> Utf8 Class Initialized
INFO - 2023-08-18 07:28:19 --> URI Class Initialized
INFO - 2023-08-18 07:28:19 --> Router Class Initialized
INFO - 2023-08-18 07:28:19 --> Output Class Initialized
INFO - 2023-08-18 07:28:19 --> Security Class Initialized
DEBUG - 2023-08-18 07:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:28:19 --> Input Class Initialized
INFO - 2023-08-18 07:28:19 --> Language Class Initialized
INFO - 2023-08-18 07:28:19 --> Loader Class Initialized
INFO - 2023-08-18 07:28:19 --> Helper loaded: url_helper
INFO - 2023-08-18 07:28:19 --> Helper loaded: file_helper
INFO - 2023-08-18 07:28:19 --> Helper loaded: html_helper
INFO - 2023-08-18 07:28:19 --> Helper loaded: text_helper
INFO - 2023-08-18 07:28:19 --> Helper loaded: form_helper
INFO - 2023-08-18 07:28:19 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:28:19 --> Helper loaded: security_helper
INFO - 2023-08-18 07:28:19 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:28:19 --> Database Driver Class Initialized
INFO - 2023-08-18 07:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:28:19 --> Parser Class Initialized
INFO - 2023-08-18 07:28:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:28:19 --> Pagination Class Initialized
INFO - 2023-08-18 07:28:19 --> Form Validation Class Initialized
INFO - 2023-08-18 07:28:19 --> Controller Class Initialized
INFO - 2023-08-18 07:28:19 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:28:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:19 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:19 --> Model Class Initialized
INFO - 2023-08-18 07:28:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-18 07:28:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 07:28:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 07:28:19 --> Model Class Initialized
INFO - 2023-08-18 07:28:19 --> Model Class Initialized
INFO - 2023-08-18 07:28:19 --> Model Class Initialized
INFO - 2023-08-18 07:28:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 07:28:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 07:28:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 07:28:19 --> Final output sent to browser
DEBUG - 2023-08-18 07:28:19 --> Total execution time: 0.1423
ERROR - 2023-08-18 07:28:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:28:19 --> Config Class Initialized
INFO - 2023-08-18 07:28:19 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:28:19 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:28:19 --> Utf8 Class Initialized
INFO - 2023-08-18 07:28:19 --> URI Class Initialized
INFO - 2023-08-18 07:28:19 --> Router Class Initialized
INFO - 2023-08-18 07:28:19 --> Output Class Initialized
INFO - 2023-08-18 07:28:19 --> Security Class Initialized
DEBUG - 2023-08-18 07:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:28:19 --> Input Class Initialized
INFO - 2023-08-18 07:28:19 --> Language Class Initialized
INFO - 2023-08-18 07:28:19 --> Loader Class Initialized
INFO - 2023-08-18 07:28:19 --> Helper loaded: url_helper
INFO - 2023-08-18 07:28:19 --> Helper loaded: file_helper
INFO - 2023-08-18 07:28:19 --> Helper loaded: html_helper
INFO - 2023-08-18 07:28:19 --> Helper loaded: text_helper
INFO - 2023-08-18 07:28:19 --> Helper loaded: form_helper
INFO - 2023-08-18 07:28:19 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:28:19 --> Helper loaded: security_helper
INFO - 2023-08-18 07:28:19 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:28:19 --> Database Driver Class Initialized
INFO - 2023-08-18 07:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:28:19 --> Parser Class Initialized
INFO - 2023-08-18 07:28:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:28:19 --> Pagination Class Initialized
INFO - 2023-08-18 07:28:19 --> Form Validation Class Initialized
INFO - 2023-08-18 07:28:19 --> Controller Class Initialized
INFO - 2023-08-18 07:28:19 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:28:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:19 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:19 --> Model Class Initialized
INFO - 2023-08-18 07:28:20 --> Final output sent to browser
DEBUG - 2023-08-18 07:28:20 --> Total execution time: 0.0531
ERROR - 2023-08-18 07:28:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:28:23 --> Config Class Initialized
INFO - 2023-08-18 07:28:23 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:28:23 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:28:23 --> Utf8 Class Initialized
INFO - 2023-08-18 07:28:23 --> URI Class Initialized
INFO - 2023-08-18 07:28:23 --> Router Class Initialized
INFO - 2023-08-18 07:28:23 --> Output Class Initialized
INFO - 2023-08-18 07:28:23 --> Security Class Initialized
DEBUG - 2023-08-18 07:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:28:23 --> Input Class Initialized
INFO - 2023-08-18 07:28:23 --> Language Class Initialized
INFO - 2023-08-18 07:28:23 --> Loader Class Initialized
INFO - 2023-08-18 07:28:23 --> Helper loaded: url_helper
INFO - 2023-08-18 07:28:23 --> Helper loaded: file_helper
INFO - 2023-08-18 07:28:23 --> Helper loaded: html_helper
INFO - 2023-08-18 07:28:23 --> Helper loaded: text_helper
INFO - 2023-08-18 07:28:23 --> Helper loaded: form_helper
INFO - 2023-08-18 07:28:23 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:28:23 --> Helper loaded: security_helper
INFO - 2023-08-18 07:28:23 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:28:23 --> Database Driver Class Initialized
INFO - 2023-08-18 07:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:28:23 --> Parser Class Initialized
INFO - 2023-08-18 07:28:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:28:23 --> Pagination Class Initialized
INFO - 2023-08-18 07:28:23 --> Form Validation Class Initialized
INFO - 2023-08-18 07:28:23 --> Controller Class Initialized
INFO - 2023-08-18 07:28:23 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:28:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:23 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:23 --> Model Class Initialized
INFO - 2023-08-18 07:28:23 --> Final output sent to browser
DEBUG - 2023-08-18 07:28:23 --> Total execution time: 0.5325
ERROR - 2023-08-18 07:28:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:28:36 --> Config Class Initialized
INFO - 2023-08-18 07:28:36 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:28:36 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:28:36 --> Utf8 Class Initialized
INFO - 2023-08-18 07:28:36 --> URI Class Initialized
INFO - 2023-08-18 07:28:36 --> Router Class Initialized
INFO - 2023-08-18 07:28:36 --> Output Class Initialized
INFO - 2023-08-18 07:28:36 --> Security Class Initialized
DEBUG - 2023-08-18 07:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:28:36 --> Input Class Initialized
INFO - 2023-08-18 07:28:36 --> Language Class Initialized
INFO - 2023-08-18 07:28:36 --> Loader Class Initialized
INFO - 2023-08-18 07:28:36 --> Helper loaded: url_helper
INFO - 2023-08-18 07:28:36 --> Helper loaded: file_helper
INFO - 2023-08-18 07:28:36 --> Helper loaded: html_helper
INFO - 2023-08-18 07:28:36 --> Helper loaded: text_helper
INFO - 2023-08-18 07:28:36 --> Helper loaded: form_helper
INFO - 2023-08-18 07:28:36 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:28:36 --> Helper loaded: security_helper
INFO - 2023-08-18 07:28:36 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:28:36 --> Database Driver Class Initialized
INFO - 2023-08-18 07:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:28:36 --> Parser Class Initialized
INFO - 2023-08-18 07:28:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:28:36 --> Pagination Class Initialized
INFO - 2023-08-18 07:28:36 --> Form Validation Class Initialized
INFO - 2023-08-18 07:28:36 --> Controller Class Initialized
INFO - 2023-08-18 07:28:36 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:28:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:36 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:36 --> Model Class Initialized
ERROR - 2023-08-18 07:28:36 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/edit_invoice_form.php 113
INFO - 2023-08-18 07:28:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/edit_invoice_form.php
DEBUG - 2023-08-18 07:28:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 07:28:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 07:28:36 --> Model Class Initialized
INFO - 2023-08-18 07:28:36 --> Model Class Initialized
INFO - 2023-08-18 07:28:36 --> Model Class Initialized
INFO - 2023-08-18 07:28:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 07:28:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 07:28:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 07:28:36 --> Final output sent to browser
DEBUG - 2023-08-18 07:28:36 --> Total execution time: 0.1695
ERROR - 2023-08-18 07:28:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:28:36 --> Config Class Initialized
INFO - 2023-08-18 07:28:36 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:28:36 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:28:36 --> Utf8 Class Initialized
INFO - 2023-08-18 07:28:36 --> URI Class Initialized
INFO - 2023-08-18 07:28:36 --> Router Class Initialized
INFO - 2023-08-18 07:28:36 --> Output Class Initialized
INFO - 2023-08-18 07:28:36 --> Security Class Initialized
DEBUG - 2023-08-18 07:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:28:36 --> Input Class Initialized
INFO - 2023-08-18 07:28:36 --> Language Class Initialized
INFO - 2023-08-18 07:28:36 --> Loader Class Initialized
INFO - 2023-08-18 07:28:36 --> Helper loaded: url_helper
INFO - 2023-08-18 07:28:36 --> Helper loaded: file_helper
INFO - 2023-08-18 07:28:36 --> Helper loaded: html_helper
INFO - 2023-08-18 07:28:36 --> Helper loaded: text_helper
INFO - 2023-08-18 07:28:36 --> Helper loaded: form_helper
INFO - 2023-08-18 07:28:36 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:28:36 --> Helper loaded: security_helper
INFO - 2023-08-18 07:28:36 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:28:36 --> Database Driver Class Initialized
INFO - 2023-08-18 07:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:28:36 --> Parser Class Initialized
INFO - 2023-08-18 07:28:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:28:36 --> Pagination Class Initialized
INFO - 2023-08-18 07:28:36 --> Form Validation Class Initialized
INFO - 2023-08-18 07:28:36 --> Controller Class Initialized
INFO - 2023-08-18 07:28:36 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:28:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:36 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:36 --> Model Class Initialized
INFO - 2023-08-18 07:28:36 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:28:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:36 --> Final output sent to browser
DEBUG - 2023-08-18 07:28:36 --> Total execution time: 0.0212
ERROR - 2023-08-18 07:28:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:28:44 --> Config Class Initialized
INFO - 2023-08-18 07:28:44 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:28:44 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:28:44 --> Utf8 Class Initialized
INFO - 2023-08-18 07:28:44 --> URI Class Initialized
INFO - 2023-08-18 07:28:44 --> Router Class Initialized
INFO - 2023-08-18 07:28:44 --> Output Class Initialized
INFO - 2023-08-18 07:28:44 --> Security Class Initialized
DEBUG - 2023-08-18 07:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:28:44 --> Input Class Initialized
INFO - 2023-08-18 07:28:44 --> Language Class Initialized
INFO - 2023-08-18 07:28:44 --> Loader Class Initialized
INFO - 2023-08-18 07:28:44 --> Helper loaded: url_helper
INFO - 2023-08-18 07:28:44 --> Helper loaded: file_helper
INFO - 2023-08-18 07:28:44 --> Helper loaded: html_helper
INFO - 2023-08-18 07:28:44 --> Helper loaded: text_helper
INFO - 2023-08-18 07:28:44 --> Helper loaded: form_helper
INFO - 2023-08-18 07:28:44 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:28:44 --> Helper loaded: security_helper
INFO - 2023-08-18 07:28:44 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:28:44 --> Database Driver Class Initialized
INFO - 2023-08-18 07:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:28:44 --> Parser Class Initialized
INFO - 2023-08-18 07:28:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:28:44 --> Pagination Class Initialized
INFO - 2023-08-18 07:28:44 --> Form Validation Class Initialized
INFO - 2023-08-18 07:28:44 --> Controller Class Initialized
INFO - 2023-08-18 07:28:44 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:28:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:44 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:44 --> Model Class Initialized
INFO - 2023-08-18 07:28:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-18 07:28:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 07:28:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 07:28:44 --> Model Class Initialized
INFO - 2023-08-18 07:28:44 --> Model Class Initialized
INFO - 2023-08-18 07:28:44 --> Model Class Initialized
INFO - 2023-08-18 07:28:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 07:28:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 07:28:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 07:28:44 --> Final output sent to browser
DEBUG - 2023-08-18 07:28:44 --> Total execution time: 0.1542
ERROR - 2023-08-18 07:28:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:28:44 --> Config Class Initialized
INFO - 2023-08-18 07:28:44 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:28:44 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:28:44 --> Utf8 Class Initialized
INFO - 2023-08-18 07:28:44 --> URI Class Initialized
INFO - 2023-08-18 07:28:44 --> Router Class Initialized
INFO - 2023-08-18 07:28:44 --> Output Class Initialized
INFO - 2023-08-18 07:28:44 --> Security Class Initialized
DEBUG - 2023-08-18 07:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:28:44 --> Input Class Initialized
INFO - 2023-08-18 07:28:44 --> Language Class Initialized
INFO - 2023-08-18 07:28:44 --> Loader Class Initialized
INFO - 2023-08-18 07:28:44 --> Helper loaded: url_helper
INFO - 2023-08-18 07:28:44 --> Helper loaded: file_helper
INFO - 2023-08-18 07:28:44 --> Helper loaded: html_helper
INFO - 2023-08-18 07:28:44 --> Helper loaded: text_helper
INFO - 2023-08-18 07:28:44 --> Helper loaded: form_helper
INFO - 2023-08-18 07:28:44 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:28:44 --> Helper loaded: security_helper
INFO - 2023-08-18 07:28:44 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:28:44 --> Database Driver Class Initialized
INFO - 2023-08-18 07:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:28:44 --> Parser Class Initialized
INFO - 2023-08-18 07:28:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:28:44 --> Pagination Class Initialized
INFO - 2023-08-18 07:28:44 --> Form Validation Class Initialized
INFO - 2023-08-18 07:28:44 --> Controller Class Initialized
INFO - 2023-08-18 07:28:44 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:28:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:44 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:44 --> Model Class Initialized
INFO - 2023-08-18 07:28:44 --> Final output sent to browser
DEBUG - 2023-08-18 07:28:44 --> Total execution time: 0.0579
ERROR - 2023-08-18 07:28:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:28:48 --> Config Class Initialized
INFO - 2023-08-18 07:28:48 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:28:48 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:28:48 --> Utf8 Class Initialized
INFO - 2023-08-18 07:28:48 --> URI Class Initialized
INFO - 2023-08-18 07:28:48 --> Router Class Initialized
INFO - 2023-08-18 07:28:48 --> Output Class Initialized
INFO - 2023-08-18 07:28:48 --> Security Class Initialized
DEBUG - 2023-08-18 07:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:28:48 --> Input Class Initialized
INFO - 2023-08-18 07:28:48 --> Language Class Initialized
INFO - 2023-08-18 07:28:48 --> Loader Class Initialized
INFO - 2023-08-18 07:28:48 --> Helper loaded: url_helper
INFO - 2023-08-18 07:28:48 --> Helper loaded: file_helper
INFO - 2023-08-18 07:28:48 --> Helper loaded: html_helper
INFO - 2023-08-18 07:28:48 --> Helper loaded: text_helper
INFO - 2023-08-18 07:28:48 --> Helper loaded: form_helper
INFO - 2023-08-18 07:28:48 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:28:48 --> Helper loaded: security_helper
INFO - 2023-08-18 07:28:48 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:28:48 --> Database Driver Class Initialized
INFO - 2023-08-18 07:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:28:48 --> Parser Class Initialized
INFO - 2023-08-18 07:28:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:28:48 --> Pagination Class Initialized
INFO - 2023-08-18 07:28:48 --> Form Validation Class Initialized
INFO - 2023-08-18 07:28:48 --> Controller Class Initialized
INFO - 2023-08-18 07:28:48 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:28:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:48 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:48 --> Model Class Initialized
INFO - 2023-08-18 07:28:48 --> Final output sent to browser
DEBUG - 2023-08-18 07:28:48 --> Total execution time: 0.6138
ERROR - 2023-08-18 07:28:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:28:58 --> Config Class Initialized
INFO - 2023-08-18 07:28:58 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:28:58 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:28:58 --> Utf8 Class Initialized
INFO - 2023-08-18 07:28:58 --> URI Class Initialized
INFO - 2023-08-18 07:28:58 --> Router Class Initialized
INFO - 2023-08-18 07:28:58 --> Output Class Initialized
INFO - 2023-08-18 07:28:58 --> Security Class Initialized
DEBUG - 2023-08-18 07:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:28:58 --> Input Class Initialized
INFO - 2023-08-18 07:28:58 --> Language Class Initialized
INFO - 2023-08-18 07:28:58 --> Loader Class Initialized
INFO - 2023-08-18 07:28:58 --> Helper loaded: url_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: file_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: html_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: text_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: form_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: security_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:28:58 --> Database Driver Class Initialized
INFO - 2023-08-18 07:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:28:58 --> Parser Class Initialized
INFO - 2023-08-18 07:28:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:28:58 --> Pagination Class Initialized
INFO - 2023-08-18 07:28:58 --> Form Validation Class Initialized
INFO - 2023-08-18 07:28:58 --> Controller Class Initialized
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
ERROR - 2023-08-18 07:28:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/edit_invoice_form.php 113
INFO - 2023-08-18 07:28:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/edit_invoice_form.php
DEBUG - 2023-08-18 07:28:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 07:28:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
INFO - 2023-08-18 07:28:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 07:28:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 07:28:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 07:28:58 --> Final output sent to browser
DEBUG - 2023-08-18 07:28:58 --> Total execution time: 0.1601
ERROR - 2023-08-18 07:28:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:28:58 --> Config Class Initialized
INFO - 2023-08-18 07:28:58 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:28:58 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:28:58 --> Utf8 Class Initialized
INFO - 2023-08-18 07:28:58 --> URI Class Initialized
INFO - 2023-08-18 07:28:58 --> Router Class Initialized
INFO - 2023-08-18 07:28:58 --> Output Class Initialized
ERROR - 2023-08-18 07:28:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:28:58 --> Config Class Initialized
INFO - 2023-08-18 07:28:58 --> Security Class Initialized
INFO - 2023-08-18 07:28:58 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:28:58 --> Input Class Initialized
INFO - 2023-08-18 07:28:58 --> Language Class Initialized
DEBUG - 2023-08-18 07:28:58 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:28:58 --> Utf8 Class Initialized
INFO - 2023-08-18 07:28:58 --> URI Class Initialized
INFO - 2023-08-18 07:28:58 --> Router Class Initialized
INFO - 2023-08-18 07:28:58 --> Loader Class Initialized
INFO - 2023-08-18 07:28:58 --> Output Class Initialized
INFO - 2023-08-18 07:28:58 --> Helper loaded: url_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: file_helper
INFO - 2023-08-18 07:28:58 --> Security Class Initialized
INFO - 2023-08-18 07:28:58 --> Helper loaded: html_helper
DEBUG - 2023-08-18 07:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:28:58 --> Input Class Initialized
INFO - 2023-08-18 07:28:58 --> Helper loaded: text_helper
INFO - 2023-08-18 07:28:58 --> Language Class Initialized
INFO - 2023-08-18 07:28:58 --> Helper loaded: form_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: security_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:28:58 --> Loader Class Initialized
INFO - 2023-08-18 07:28:58 --> Helper loaded: url_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: file_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: html_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: text_helper
INFO - 2023-08-18 07:28:58 --> Database Driver Class Initialized
INFO - 2023-08-18 07:28:58 --> Helper loaded: form_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: security_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:28:58 --> Parser Class Initialized
INFO - 2023-08-18 07:28:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:28:58 --> Pagination Class Initialized
INFO - 2023-08-18 07:28:58 --> Database Driver Class Initialized
INFO - 2023-08-18 07:28:58 --> Form Validation Class Initialized
INFO - 2023-08-18 07:28:58 --> Controller Class Initialized
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:58 --> Final output sent to browser
DEBUG - 2023-08-18 07:28:58 --> Total execution time: 0.0206
INFO - 2023-08-18 07:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:28:58 --> Parser Class Initialized
INFO - 2023-08-18 07:28:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:28:58 --> Pagination Class Initialized
INFO - 2023-08-18 07:28:58 --> Form Validation Class Initialized
INFO - 2023-08-18 07:28:58 --> Controller Class Initialized
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:58 --> Final output sent to browser
DEBUG - 2023-08-18 07:28:58 --> Total execution time: 0.0287
ERROR - 2023-08-18 07:28:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:28:58 --> Config Class Initialized
INFO - 2023-08-18 07:28:58 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:28:58 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:28:58 --> Utf8 Class Initialized
INFO - 2023-08-18 07:28:58 --> URI Class Initialized
INFO - 2023-08-18 07:28:58 --> Router Class Initialized
ERROR - 2023-08-18 07:28:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:28:58 --> Output Class Initialized
INFO - 2023-08-18 07:28:58 --> Config Class Initialized
INFO - 2023-08-18 07:28:58 --> Hooks Class Initialized
INFO - 2023-08-18 07:28:58 --> Security Class Initialized
DEBUG - 2023-08-18 07:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:28:58 --> Input Class Initialized
INFO - 2023-08-18 07:28:58 --> Language Class Initialized
DEBUG - 2023-08-18 07:28:58 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:28:58 --> Utf8 Class Initialized
INFO - 2023-08-18 07:28:58 --> URI Class Initialized
INFO - 2023-08-18 07:28:58 --> Router Class Initialized
INFO - 2023-08-18 07:28:58 --> Output Class Initialized
INFO - 2023-08-18 07:28:58 --> Loader Class Initialized
INFO - 2023-08-18 07:28:58 --> Security Class Initialized
INFO - 2023-08-18 07:28:58 --> Helper loaded: url_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: file_helper
DEBUG - 2023-08-18 07:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:28:58 --> Input Class Initialized
INFO - 2023-08-18 07:28:58 --> Helper loaded: html_helper
INFO - 2023-08-18 07:28:58 --> Language Class Initialized
INFO - 2023-08-18 07:28:58 --> Helper loaded: text_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: form_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: security_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:28:58 --> Loader Class Initialized
INFO - 2023-08-18 07:28:58 --> Helper loaded: url_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: file_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: html_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: text_helper
ERROR - 2023-08-18 07:28:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
ERROR - 2023-08-18 07:28:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:28:58 --> Config Class Initialized
INFO - 2023-08-18 07:28:58 --> Helper loaded: form_helper
INFO - 2023-08-18 07:28:58 --> Hooks Class Initialized
INFO - 2023-08-18 07:28:58 --> Helper loaded: lang_helper
ERROR - 2023-08-18 07:28:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:28:58 --> Database Driver Class Initialized
INFO - 2023-08-18 07:28:58 --> Helper loaded: security_helper
INFO - 2023-08-18 07:28:58 --> Config Class Initialized
INFO - 2023-08-18 07:28:58 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:28:58 --> Hooks Class Initialized
INFO - 2023-08-18 07:28:58 --> Config Class Initialized
INFO - 2023-08-18 07:28:58 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:28:58 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:28:58 --> Utf8 Class Initialized
DEBUG - 2023-08-18 07:28:58 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:28:58 --> Utf8 Class Initialized
INFO - 2023-08-18 07:28:58 --> URI Class Initialized
DEBUG - 2023-08-18 07:28:58 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:28:58 --> Utf8 Class Initialized
INFO - 2023-08-18 07:28:58 --> URI Class Initialized
INFO - 2023-08-18 07:28:58 --> Router Class Initialized
INFO - 2023-08-18 07:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:28:58 --> URI Class Initialized
INFO - 2023-08-18 07:28:58 --> Parser Class Initialized
INFO - 2023-08-18 07:28:58 --> Router Class Initialized
INFO - 2023-08-18 07:28:58 --> Router Class Initialized
INFO - 2023-08-18 07:28:58 --> Output Class Initialized
INFO - 2023-08-18 07:28:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:28:58 --> Database Driver Class Initialized
INFO - 2023-08-18 07:28:58 --> Output Class Initialized
INFO - 2023-08-18 07:28:58 --> Pagination Class Initialized
INFO - 2023-08-18 07:28:58 --> Output Class Initialized
INFO - 2023-08-18 07:28:58 --> Security Class Initialized
INFO - 2023-08-18 07:28:58 --> Security Class Initialized
DEBUG - 2023-08-18 07:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:28:58 --> Security Class Initialized
INFO - 2023-08-18 07:28:58 --> Input Class Initialized
INFO - 2023-08-18 07:28:58 --> Language Class Initialized
INFO - 2023-08-18 07:28:58 --> Form Validation Class Initialized
DEBUG - 2023-08-18 07:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:28:58 --> Input Class Initialized
INFO - 2023-08-18 07:28:58 --> Controller Class Initialized
DEBUG - 2023-08-18 07:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:28:58 --> Input Class Initialized
INFO - 2023-08-18 07:28:58 --> Language Class Initialized
INFO - 2023-08-18 07:28:58 --> Language Class Initialized
ERROR - 2023-08-18 07:28:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:28:58 --> Config Class Initialized
INFO - 2023-08-18 07:28:58 --> Hooks Class Initialized
INFO - 2023-08-18 07:28:58 --> Loader Class Initialized
INFO - 2023-08-18 07:28:58 --> Helper loaded: url_helper
INFO - 2023-08-18 07:28:58 --> Loader Class Initialized
INFO - 2023-08-18 07:28:58 --> Loader Class Initialized
INFO - 2023-08-18 07:28:58 --> Helper loaded: file_helper
DEBUG - 2023-08-18 07:28:58 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:28:58 --> Utf8 Class Initialized
INFO - 2023-08-18 07:28:58 --> Helper loaded: url_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: url_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: html_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: file_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: file_helper
INFO - 2023-08-18 07:28:58 --> URI Class Initialized
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
INFO - 2023-08-18 07:28:58 --> Helper loaded: text_helper
DEBUG - 2023-08-18 07:28:58 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:58 --> Helper loaded: html_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: html_helper
INFO - 2023-08-18 07:28:58 --> Router Class Initialized
INFO - 2023-08-18 07:28:58 --> Helper loaded: text_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: text_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: form_helper
DEBUG - 2023-08-18 07:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:58 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: security_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:28:58 --> Output Class Initialized
INFO - 2023-08-18 07:28:58 --> Helper loaded: form_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: form_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: security_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: security_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:28:58 --> Security Class Initialized
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:28:58 --> Input Class Initialized
INFO - 2023-08-18 07:28:58 --> Language Class Initialized
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:58 --> Database Driver Class Initialized
INFO - 2023-08-18 07:28:58 --> Loader Class Initialized
INFO - 2023-08-18 07:28:58 --> Database Driver Class Initialized
INFO - 2023-08-18 07:28:58 --> Database Driver Class Initialized
INFO - 2023-08-18 07:28:58 --> Helper loaded: url_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: file_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: html_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: text_helper
INFO - 2023-08-18 07:28:58 --> Final output sent to browser
INFO - 2023-08-18 07:28:58 --> Helper loaded: form_helper
DEBUG - 2023-08-18 07:28:58 --> Total execution time: 0.0222
INFO - 2023-08-18 07:28:58 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:28:58 --> Helper loaded: security_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:28:58 --> Parser Class Initialized
INFO - 2023-08-18 07:28:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:28:58 --> Pagination Class Initialized
INFO - 2023-08-18 07:28:58 --> Form Validation Class Initialized
INFO - 2023-08-18 07:28:58 --> Controller Class Initialized
ERROR - 2023-08-18 07:28:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:28:58 --> Config Class Initialized
ERROR - 2023-08-18 07:28:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:28:58 --> Hooks Class Initialized
INFO - 2023-08-18 07:28:58 --> Database Driver Class Initialized
INFO - 2023-08-18 07:28:58 --> Config Class Initialized
INFO - 2023-08-18 07:28:58 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:28:58 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:28:58 --> Utf8 Class Initialized
DEBUG - 2023-08-18 07:28:58 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:28:58 --> Utf8 Class Initialized
INFO - 2023-08-18 07:28:58 --> URI Class Initialized
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:58 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:58 --> Router Class Initialized
INFO - 2023-08-18 07:28:58 --> URI Class Initialized
DEBUG - 2023-08-18 07:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:58 --> Router Class Initialized
INFO - 2023-08-18 07:28:58 --> Output Class Initialized
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:58 --> Output Class Initialized
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
INFO - 2023-08-18 07:28:58 --> Security Class Initialized
INFO - 2023-08-18 07:28:58 --> Security Class Initialized
DEBUG - 2023-08-18 07:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:28:58 --> Input Class Initialized
INFO - 2023-08-18 07:28:58 --> Language Class Initialized
DEBUG - 2023-08-18 07:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
INFO - 2023-08-18 07:28:58 --> Input Class Initialized
DEBUG - 2023-08-18 07:28:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:58 --> Language Class Initialized
INFO - 2023-08-18 07:28:58 --> Loader Class Initialized
INFO - 2023-08-18 07:28:58 --> Helper loaded: url_helper
INFO - 2023-08-18 07:28:58 --> Loader Class Initialized
INFO - 2023-08-18 07:28:58 --> Final output sent to browser
DEBUG - 2023-08-18 07:28:58 --> Total execution time: 0.0283
INFO - 2023-08-18 07:28:58 --> Helper loaded: file_helper
INFO - 2023-08-18 07:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:28:58 --> Helper loaded: url_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: html_helper
INFO - 2023-08-18 07:28:58 --> Parser Class Initialized
INFO - 2023-08-18 07:28:58 --> Helper loaded: file_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: text_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: html_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: text_helper
INFO - 2023-08-18 07:28:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:28:58 --> Helper loaded: form_helper
INFO - 2023-08-18 07:28:58 --> Pagination Class Initialized
INFO - 2023-08-18 07:28:58 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: security_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: form_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: security_helper
INFO - 2023-08-18 07:28:58 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:28:58 --> Form Validation Class Initialized
INFO - 2023-08-18 07:28:58 --> Controller Class Initialized
INFO - 2023-08-18 07:28:58 --> Database Driver Class Initialized
INFO - 2023-08-18 07:28:58 --> Database Driver Class Initialized
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:58 --> Final output sent to browser
DEBUG - 2023-08-18 07:28:58 --> Total execution time: 0.0317
INFO - 2023-08-18 07:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:28:58 --> Parser Class Initialized
INFO - 2023-08-18 07:28:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:28:58 --> Pagination Class Initialized
INFO - 2023-08-18 07:28:58 --> Form Validation Class Initialized
INFO - 2023-08-18 07:28:58 --> Controller Class Initialized
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:58 --> Final output sent to browser
DEBUG - 2023-08-18 07:28:58 --> Total execution time: 0.0416
INFO - 2023-08-18 07:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:28:58 --> Parser Class Initialized
INFO - 2023-08-18 07:28:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:28:58 --> Pagination Class Initialized
INFO - 2023-08-18 07:28:58 --> Form Validation Class Initialized
INFO - 2023-08-18 07:28:58 --> Controller Class Initialized
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:58 --> Final output sent to browser
DEBUG - 2023-08-18 07:28:58 --> Total execution time: 0.0522
INFO - 2023-08-18 07:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:28:58 --> Parser Class Initialized
INFO - 2023-08-18 07:28:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:28:58 --> Pagination Class Initialized
INFO - 2023-08-18 07:28:58 --> Form Validation Class Initialized
INFO - 2023-08-18 07:28:58 --> Controller Class Initialized
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:58 --> Final output sent to browser
DEBUG - 2023-08-18 07:28:58 --> Total execution time: 0.0479
INFO - 2023-08-18 07:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:28:58 --> Parser Class Initialized
INFO - 2023-08-18 07:28:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:28:58 --> Pagination Class Initialized
INFO - 2023-08-18 07:28:58 --> Form Validation Class Initialized
INFO - 2023-08-18 07:28:58 --> Controller Class Initialized
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:58 --> Final output sent to browser
DEBUG - 2023-08-18 07:28:58 --> Total execution time: 0.0676
INFO - 2023-08-18 07:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:28:58 --> Parser Class Initialized
INFO - 2023-08-18 07:28:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:28:58 --> Pagination Class Initialized
INFO - 2023-08-18 07:28:58 --> Form Validation Class Initialized
INFO - 2023-08-18 07:28:58 --> Controller Class Initialized
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
INFO - 2023-08-18 07:28:58 --> Model Class Initialized
DEBUG - 2023-08-18 07:28:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:28:58 --> Final output sent to browser
DEBUG - 2023-08-18 07:28:58 --> Total execution time: 0.0679
ERROR - 2023-08-18 07:29:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:29:43 --> Config Class Initialized
INFO - 2023-08-18 07:29:43 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:29:43 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:29:43 --> Utf8 Class Initialized
INFO - 2023-08-18 07:29:43 --> URI Class Initialized
INFO - 2023-08-18 07:29:43 --> Router Class Initialized
INFO - 2023-08-18 07:29:43 --> Output Class Initialized
INFO - 2023-08-18 07:29:43 --> Security Class Initialized
DEBUG - 2023-08-18 07:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:29:43 --> Input Class Initialized
INFO - 2023-08-18 07:29:43 --> Language Class Initialized
INFO - 2023-08-18 07:29:43 --> Loader Class Initialized
INFO - 2023-08-18 07:29:43 --> Helper loaded: url_helper
INFO - 2023-08-18 07:29:43 --> Helper loaded: file_helper
INFO - 2023-08-18 07:29:43 --> Helper loaded: html_helper
INFO - 2023-08-18 07:29:43 --> Helper loaded: text_helper
INFO - 2023-08-18 07:29:43 --> Helper loaded: form_helper
INFO - 2023-08-18 07:29:43 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:29:43 --> Helper loaded: security_helper
INFO - 2023-08-18 07:29:43 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:29:43 --> Database Driver Class Initialized
INFO - 2023-08-18 07:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:29:43 --> Parser Class Initialized
INFO - 2023-08-18 07:29:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:29:43 --> Pagination Class Initialized
INFO - 2023-08-18 07:29:43 --> Form Validation Class Initialized
INFO - 2023-08-18 07:29:43 --> Controller Class Initialized
INFO - 2023-08-18 07:29:43 --> Model Class Initialized
DEBUG - 2023-08-18 07:29:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:29:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:29:43 --> Model Class Initialized
DEBUG - 2023-08-18 07:29:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:29:43 --> Model Class Initialized
INFO - 2023-08-18 07:29:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-18 07:29:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:29:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 07:29:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 07:29:43 --> Model Class Initialized
INFO - 2023-08-18 07:29:43 --> Model Class Initialized
INFO - 2023-08-18 07:29:43 --> Model Class Initialized
INFO - 2023-08-18 07:29:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 07:29:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 07:29:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 07:29:43 --> Final output sent to browser
DEBUG - 2023-08-18 07:29:43 --> Total execution time: 0.1471
ERROR - 2023-08-18 07:29:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:29:44 --> Config Class Initialized
INFO - 2023-08-18 07:29:44 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:29:44 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:29:44 --> Utf8 Class Initialized
INFO - 2023-08-18 07:29:44 --> URI Class Initialized
INFO - 2023-08-18 07:29:44 --> Router Class Initialized
INFO - 2023-08-18 07:29:44 --> Output Class Initialized
INFO - 2023-08-18 07:29:44 --> Security Class Initialized
DEBUG - 2023-08-18 07:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:29:44 --> Input Class Initialized
INFO - 2023-08-18 07:29:44 --> Language Class Initialized
INFO - 2023-08-18 07:29:44 --> Loader Class Initialized
INFO - 2023-08-18 07:29:44 --> Helper loaded: url_helper
INFO - 2023-08-18 07:29:44 --> Helper loaded: file_helper
INFO - 2023-08-18 07:29:44 --> Helper loaded: html_helper
INFO - 2023-08-18 07:29:44 --> Helper loaded: text_helper
INFO - 2023-08-18 07:29:44 --> Helper loaded: form_helper
INFO - 2023-08-18 07:29:44 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:29:44 --> Helper loaded: security_helper
INFO - 2023-08-18 07:29:44 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:29:44 --> Database Driver Class Initialized
INFO - 2023-08-18 07:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:29:44 --> Parser Class Initialized
INFO - 2023-08-18 07:29:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:29:44 --> Pagination Class Initialized
INFO - 2023-08-18 07:29:44 --> Form Validation Class Initialized
INFO - 2023-08-18 07:29:44 --> Controller Class Initialized
INFO - 2023-08-18 07:29:44 --> Model Class Initialized
DEBUG - 2023-08-18 07:29:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:29:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:29:44 --> Model Class Initialized
DEBUG - 2023-08-18 07:29:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:29:44 --> Model Class Initialized
INFO - 2023-08-18 07:29:44 --> Final output sent to browser
DEBUG - 2023-08-18 07:29:44 --> Total execution time: 0.0541
ERROR - 2023-08-18 07:29:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:29:46 --> Config Class Initialized
INFO - 2023-08-18 07:29:46 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:29:46 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:29:46 --> Utf8 Class Initialized
INFO - 2023-08-18 07:29:46 --> URI Class Initialized
DEBUG - 2023-08-18 07:29:46 --> No URI present. Default controller set.
INFO - 2023-08-18 07:29:46 --> Router Class Initialized
INFO - 2023-08-18 07:29:46 --> Output Class Initialized
INFO - 2023-08-18 07:29:46 --> Security Class Initialized
DEBUG - 2023-08-18 07:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:29:46 --> Input Class Initialized
INFO - 2023-08-18 07:29:46 --> Language Class Initialized
INFO - 2023-08-18 07:29:46 --> Loader Class Initialized
INFO - 2023-08-18 07:29:46 --> Helper loaded: url_helper
INFO - 2023-08-18 07:29:46 --> Helper loaded: file_helper
INFO - 2023-08-18 07:29:46 --> Helper loaded: html_helper
INFO - 2023-08-18 07:29:46 --> Helper loaded: text_helper
INFO - 2023-08-18 07:29:46 --> Helper loaded: form_helper
INFO - 2023-08-18 07:29:46 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:29:46 --> Helper loaded: security_helper
INFO - 2023-08-18 07:29:46 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:29:46 --> Database Driver Class Initialized
INFO - 2023-08-18 07:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:29:46 --> Parser Class Initialized
INFO - 2023-08-18 07:29:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:29:46 --> Pagination Class Initialized
INFO - 2023-08-18 07:29:46 --> Form Validation Class Initialized
INFO - 2023-08-18 07:29:46 --> Controller Class Initialized
INFO - 2023-08-18 07:29:46 --> Model Class Initialized
DEBUG - 2023-08-18 07:29:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-18 07:29:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:29:46 --> Config Class Initialized
INFO - 2023-08-18 07:29:46 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:29:46 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:29:46 --> Utf8 Class Initialized
INFO - 2023-08-18 07:29:46 --> URI Class Initialized
INFO - 2023-08-18 07:29:46 --> Router Class Initialized
INFO - 2023-08-18 07:29:46 --> Output Class Initialized
INFO - 2023-08-18 07:29:46 --> Security Class Initialized
DEBUG - 2023-08-18 07:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:29:46 --> Input Class Initialized
INFO - 2023-08-18 07:29:46 --> Language Class Initialized
INFO - 2023-08-18 07:29:46 --> Loader Class Initialized
INFO - 2023-08-18 07:29:46 --> Helper loaded: url_helper
INFO - 2023-08-18 07:29:46 --> Helper loaded: file_helper
INFO - 2023-08-18 07:29:46 --> Helper loaded: html_helper
INFO - 2023-08-18 07:29:46 --> Helper loaded: text_helper
INFO - 2023-08-18 07:29:46 --> Helper loaded: form_helper
INFO - 2023-08-18 07:29:46 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:29:46 --> Helper loaded: security_helper
INFO - 2023-08-18 07:29:46 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:29:46 --> Database Driver Class Initialized
INFO - 2023-08-18 07:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:29:46 --> Parser Class Initialized
INFO - 2023-08-18 07:29:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:29:46 --> Pagination Class Initialized
INFO - 2023-08-18 07:29:46 --> Form Validation Class Initialized
INFO - 2023-08-18 07:29:46 --> Controller Class Initialized
INFO - 2023-08-18 07:29:46 --> Model Class Initialized
DEBUG - 2023-08-18 07:29:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:29:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-18 07:29:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:29:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 07:29:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 07:29:46 --> Model Class Initialized
INFO - 2023-08-18 07:29:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 07:29:46 --> Final output sent to browser
DEBUG - 2023-08-18 07:29:46 --> Total execution time: 0.0275
ERROR - 2023-08-18 07:29:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:29:47 --> Config Class Initialized
INFO - 2023-08-18 07:29:47 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:29:47 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:29:47 --> Utf8 Class Initialized
INFO - 2023-08-18 07:29:47 --> URI Class Initialized
INFO - 2023-08-18 07:29:47 --> Router Class Initialized
INFO - 2023-08-18 07:29:47 --> Output Class Initialized
INFO - 2023-08-18 07:29:47 --> Security Class Initialized
DEBUG - 2023-08-18 07:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:29:47 --> Input Class Initialized
INFO - 2023-08-18 07:29:47 --> Language Class Initialized
INFO - 2023-08-18 07:29:47 --> Loader Class Initialized
INFO - 2023-08-18 07:29:47 --> Helper loaded: url_helper
INFO - 2023-08-18 07:29:47 --> Helper loaded: file_helper
INFO - 2023-08-18 07:29:47 --> Helper loaded: html_helper
INFO - 2023-08-18 07:29:47 --> Helper loaded: text_helper
INFO - 2023-08-18 07:29:47 --> Helper loaded: form_helper
INFO - 2023-08-18 07:29:47 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:29:47 --> Helper loaded: security_helper
INFO - 2023-08-18 07:29:47 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:29:47 --> Database Driver Class Initialized
INFO - 2023-08-18 07:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:29:47 --> Parser Class Initialized
INFO - 2023-08-18 07:29:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:29:47 --> Pagination Class Initialized
INFO - 2023-08-18 07:29:47 --> Form Validation Class Initialized
INFO - 2023-08-18 07:29:47 --> Controller Class Initialized
INFO - 2023-08-18 07:29:47 --> Model Class Initialized
DEBUG - 2023-08-18 07:29:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:29:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:29:47 --> Model Class Initialized
DEBUG - 2023-08-18 07:29:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:29:47 --> Model Class Initialized
INFO - 2023-08-18 07:29:47 --> Final output sent to browser
DEBUG - 2023-08-18 07:29:47 --> Total execution time: 0.6097
ERROR - 2023-08-18 07:29:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:29:58 --> Config Class Initialized
INFO - 2023-08-18 07:29:58 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:29:58 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:29:58 --> Utf8 Class Initialized
INFO - 2023-08-18 07:29:58 --> URI Class Initialized
INFO - 2023-08-18 07:29:58 --> Router Class Initialized
INFO - 2023-08-18 07:29:58 --> Output Class Initialized
INFO - 2023-08-18 07:29:58 --> Security Class Initialized
DEBUG - 2023-08-18 07:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:29:58 --> Input Class Initialized
INFO - 2023-08-18 07:29:58 --> Language Class Initialized
INFO - 2023-08-18 07:29:58 --> Loader Class Initialized
INFO - 2023-08-18 07:29:58 --> Helper loaded: url_helper
INFO - 2023-08-18 07:29:58 --> Helper loaded: file_helper
INFO - 2023-08-18 07:29:58 --> Helper loaded: html_helper
INFO - 2023-08-18 07:29:58 --> Helper loaded: text_helper
INFO - 2023-08-18 07:29:58 --> Helper loaded: form_helper
INFO - 2023-08-18 07:29:58 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:29:58 --> Helper loaded: security_helper
INFO - 2023-08-18 07:29:58 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:29:58 --> Database Driver Class Initialized
INFO - 2023-08-18 07:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:29:58 --> Parser Class Initialized
INFO - 2023-08-18 07:29:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:29:58 --> Pagination Class Initialized
INFO - 2023-08-18 07:29:58 --> Form Validation Class Initialized
INFO - 2023-08-18 07:29:58 --> Controller Class Initialized
INFO - 2023-08-18 07:29:58 --> Model Class Initialized
DEBUG - 2023-08-18 07:29:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:29:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:29:58 --> Model Class Initialized
DEBUG - 2023-08-18 07:29:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:29:58 --> Model Class Initialized
ERROR - 2023-08-18 07:29:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/edit_invoice_form.php 113
INFO - 2023-08-18 07:29:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/edit_invoice_form.php
DEBUG - 2023-08-18 07:29:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:29:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 07:29:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 07:29:58 --> Model Class Initialized
INFO - 2023-08-18 07:29:58 --> Model Class Initialized
INFO - 2023-08-18 07:29:58 --> Model Class Initialized
INFO - 2023-08-18 07:29:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 07:29:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 07:29:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 07:29:58 --> Final output sent to browser
DEBUG - 2023-08-18 07:29:58 --> Total execution time: 0.1497
ERROR - 2023-08-18 07:29:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:29:59 --> Config Class Initialized
INFO - 2023-08-18 07:29:59 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:29:59 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:29:59 --> Utf8 Class Initialized
INFO - 2023-08-18 07:29:59 --> URI Class Initialized
INFO - 2023-08-18 07:29:59 --> Router Class Initialized
INFO - 2023-08-18 07:29:59 --> Output Class Initialized
INFO - 2023-08-18 07:29:59 --> Security Class Initialized
DEBUG - 2023-08-18 07:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:29:59 --> Input Class Initialized
INFO - 2023-08-18 07:29:59 --> Language Class Initialized
INFO - 2023-08-18 07:29:59 --> Loader Class Initialized
INFO - 2023-08-18 07:29:59 --> Helper loaded: url_helper
INFO - 2023-08-18 07:29:59 --> Helper loaded: file_helper
INFO - 2023-08-18 07:29:59 --> Helper loaded: html_helper
INFO - 2023-08-18 07:29:59 --> Helper loaded: text_helper
INFO - 2023-08-18 07:29:59 --> Helper loaded: form_helper
INFO - 2023-08-18 07:29:59 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:29:59 --> Helper loaded: security_helper
INFO - 2023-08-18 07:29:59 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:29:59 --> Database Driver Class Initialized
INFO - 2023-08-18 07:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:29:59 --> Parser Class Initialized
INFO - 2023-08-18 07:29:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:29:59 --> Pagination Class Initialized
INFO - 2023-08-18 07:29:59 --> Form Validation Class Initialized
INFO - 2023-08-18 07:29:59 --> Controller Class Initialized
INFO - 2023-08-18 07:29:59 --> Model Class Initialized
DEBUG - 2023-08-18 07:29:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:29:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:29:59 --> Model Class Initialized
DEBUG - 2023-08-18 07:29:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:29:59 --> Model Class Initialized
INFO - 2023-08-18 07:29:59 --> Model Class Initialized
DEBUG - 2023-08-18 07:29:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:29:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:29:59 --> Final output sent to browser
DEBUG - 2023-08-18 07:29:59 --> Total execution time: 0.0202
ERROR - 2023-08-18 07:30:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:30:00 --> Config Class Initialized
INFO - 2023-08-18 07:30:00 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:30:00 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:30:00 --> Utf8 Class Initialized
INFO - 2023-08-18 07:30:00 --> URI Class Initialized
INFO - 2023-08-18 07:30:00 --> Router Class Initialized
INFO - 2023-08-18 07:30:00 --> Output Class Initialized
INFO - 2023-08-18 07:30:00 --> Security Class Initialized
DEBUG - 2023-08-18 07:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:30:00 --> Input Class Initialized
INFO - 2023-08-18 07:30:00 --> Language Class Initialized
INFO - 2023-08-18 07:30:00 --> Loader Class Initialized
INFO - 2023-08-18 07:30:00 --> Helper loaded: url_helper
INFO - 2023-08-18 07:30:00 --> Helper loaded: file_helper
INFO - 2023-08-18 07:30:00 --> Helper loaded: html_helper
INFO - 2023-08-18 07:30:00 --> Helper loaded: text_helper
INFO - 2023-08-18 07:30:00 --> Helper loaded: form_helper
INFO - 2023-08-18 07:30:00 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:30:00 --> Helper loaded: security_helper
INFO - 2023-08-18 07:30:00 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:30:00 --> Database Driver Class Initialized
INFO - 2023-08-18 07:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:30:00 --> Parser Class Initialized
INFO - 2023-08-18 07:30:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:30:00 --> Pagination Class Initialized
INFO - 2023-08-18 07:30:00 --> Form Validation Class Initialized
INFO - 2023-08-18 07:30:00 --> Controller Class Initialized
INFO - 2023-08-18 07:30:00 --> Model Class Initialized
DEBUG - 2023-08-18 07:30:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:30:00 --> Model Class Initialized
INFO - 2023-08-18 07:30:00 --> Final output sent to browser
DEBUG - 2023-08-18 07:30:00 --> Total execution time: 0.0159
ERROR - 2023-08-18 07:30:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:30:00 --> Config Class Initialized
INFO - 2023-08-18 07:30:00 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:30:00 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:30:00 --> Utf8 Class Initialized
INFO - 2023-08-18 07:30:00 --> URI Class Initialized
DEBUG - 2023-08-18 07:30:00 --> No URI present. Default controller set.
INFO - 2023-08-18 07:30:00 --> Router Class Initialized
INFO - 2023-08-18 07:30:00 --> Output Class Initialized
INFO - 2023-08-18 07:30:00 --> Security Class Initialized
DEBUG - 2023-08-18 07:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:30:00 --> Input Class Initialized
INFO - 2023-08-18 07:30:00 --> Language Class Initialized
INFO - 2023-08-18 07:30:00 --> Loader Class Initialized
INFO - 2023-08-18 07:30:00 --> Helper loaded: url_helper
INFO - 2023-08-18 07:30:00 --> Helper loaded: file_helper
INFO - 2023-08-18 07:30:00 --> Helper loaded: html_helper
INFO - 2023-08-18 07:30:00 --> Helper loaded: text_helper
INFO - 2023-08-18 07:30:00 --> Helper loaded: form_helper
INFO - 2023-08-18 07:30:00 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:30:00 --> Helper loaded: security_helper
INFO - 2023-08-18 07:30:00 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:30:00 --> Database Driver Class Initialized
INFO - 2023-08-18 07:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:30:00 --> Parser Class Initialized
INFO - 2023-08-18 07:30:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:30:00 --> Pagination Class Initialized
INFO - 2023-08-18 07:30:00 --> Form Validation Class Initialized
INFO - 2023-08-18 07:30:00 --> Controller Class Initialized
INFO - 2023-08-18 07:30:00 --> Model Class Initialized
DEBUG - 2023-08-18 07:30:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:30:00 --> Model Class Initialized
DEBUG - 2023-08-18 07:30:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:30:00 --> Model Class Initialized
INFO - 2023-08-18 07:30:00 --> Model Class Initialized
INFO - 2023-08-18 07:30:00 --> Model Class Initialized
INFO - 2023-08-18 07:30:00 --> Model Class Initialized
DEBUG - 2023-08-18 07:30:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:30:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:30:00 --> Model Class Initialized
INFO - 2023-08-18 07:30:00 --> Model Class Initialized
INFO - 2023-08-18 07:30:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-18 07:30:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:30:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 07:30:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 07:30:00 --> Model Class Initialized
INFO - 2023-08-18 07:30:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 07:30:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 07:30:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 07:30:00 --> Final output sent to browser
DEBUG - 2023-08-18 07:30:00 --> Total execution time: 0.0843
ERROR - 2023-08-18 07:30:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:30:19 --> Config Class Initialized
INFO - 2023-08-18 07:30:19 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:30:19 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:30:19 --> Utf8 Class Initialized
INFO - 2023-08-18 07:30:19 --> URI Class Initialized
INFO - 2023-08-18 07:30:19 --> Router Class Initialized
INFO - 2023-08-18 07:30:19 --> Output Class Initialized
INFO - 2023-08-18 07:30:19 --> Security Class Initialized
DEBUG - 2023-08-18 07:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:30:19 --> Input Class Initialized
INFO - 2023-08-18 07:30:19 --> Language Class Initialized
INFO - 2023-08-18 07:30:19 --> Loader Class Initialized
INFO - 2023-08-18 07:30:19 --> Helper loaded: url_helper
INFO - 2023-08-18 07:30:19 --> Helper loaded: file_helper
INFO - 2023-08-18 07:30:19 --> Helper loaded: html_helper
INFO - 2023-08-18 07:30:19 --> Helper loaded: text_helper
INFO - 2023-08-18 07:30:19 --> Helper loaded: form_helper
INFO - 2023-08-18 07:30:19 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:30:19 --> Helper loaded: security_helper
INFO - 2023-08-18 07:30:19 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:30:19 --> Database Driver Class Initialized
INFO - 2023-08-18 07:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:30:19 --> Parser Class Initialized
INFO - 2023-08-18 07:30:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:30:19 --> Pagination Class Initialized
INFO - 2023-08-18 07:30:19 --> Form Validation Class Initialized
INFO - 2023-08-18 07:30:19 --> Controller Class Initialized
INFO - 2023-08-18 07:30:19 --> Model Class Initialized
DEBUG - 2023-08-18 07:30:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:30:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:30:19 --> Model Class Initialized
DEBUG - 2023-08-18 07:30:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:30:19 --> Model Class Initialized
INFO - 2023-08-18 07:30:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-18 07:30:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:30:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 07:30:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 07:30:19 --> Model Class Initialized
INFO - 2023-08-18 07:30:19 --> Model Class Initialized
INFO - 2023-08-18 07:30:19 --> Model Class Initialized
INFO - 2023-08-18 07:30:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 07:30:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 07:30:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 07:30:19 --> Final output sent to browser
DEBUG - 2023-08-18 07:30:19 --> Total execution time: 0.0780
ERROR - 2023-08-18 07:30:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:30:20 --> Config Class Initialized
INFO - 2023-08-18 07:30:20 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:30:20 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:30:20 --> Utf8 Class Initialized
INFO - 2023-08-18 07:30:20 --> URI Class Initialized
INFO - 2023-08-18 07:30:20 --> Router Class Initialized
INFO - 2023-08-18 07:30:20 --> Output Class Initialized
INFO - 2023-08-18 07:30:20 --> Security Class Initialized
DEBUG - 2023-08-18 07:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:30:20 --> Input Class Initialized
INFO - 2023-08-18 07:30:20 --> Language Class Initialized
INFO - 2023-08-18 07:30:20 --> Loader Class Initialized
INFO - 2023-08-18 07:30:20 --> Helper loaded: url_helper
INFO - 2023-08-18 07:30:20 --> Helper loaded: file_helper
INFO - 2023-08-18 07:30:20 --> Helper loaded: html_helper
INFO - 2023-08-18 07:30:20 --> Helper loaded: text_helper
INFO - 2023-08-18 07:30:20 --> Helper loaded: form_helper
INFO - 2023-08-18 07:30:20 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:30:20 --> Helper loaded: security_helper
INFO - 2023-08-18 07:30:20 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:30:20 --> Database Driver Class Initialized
INFO - 2023-08-18 07:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:30:20 --> Parser Class Initialized
INFO - 2023-08-18 07:30:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:30:20 --> Pagination Class Initialized
INFO - 2023-08-18 07:30:20 --> Form Validation Class Initialized
INFO - 2023-08-18 07:30:20 --> Controller Class Initialized
INFO - 2023-08-18 07:30:20 --> Model Class Initialized
DEBUG - 2023-08-18 07:30:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:30:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:30:20 --> Model Class Initialized
DEBUG - 2023-08-18 07:30:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:30:20 --> Model Class Initialized
INFO - 2023-08-18 07:30:20 --> Final output sent to browser
DEBUG - 2023-08-18 07:30:20 --> Total execution time: 0.0388
ERROR - 2023-08-18 07:30:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:30:24 --> Config Class Initialized
INFO - 2023-08-18 07:30:24 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:30:24 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:30:24 --> Utf8 Class Initialized
INFO - 2023-08-18 07:30:24 --> URI Class Initialized
INFO - 2023-08-18 07:30:24 --> Router Class Initialized
INFO - 2023-08-18 07:30:24 --> Output Class Initialized
INFO - 2023-08-18 07:30:24 --> Security Class Initialized
DEBUG - 2023-08-18 07:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:30:24 --> Input Class Initialized
INFO - 2023-08-18 07:30:24 --> Language Class Initialized
INFO - 2023-08-18 07:30:24 --> Loader Class Initialized
INFO - 2023-08-18 07:30:24 --> Helper loaded: url_helper
INFO - 2023-08-18 07:30:24 --> Helper loaded: file_helper
INFO - 2023-08-18 07:30:24 --> Helper loaded: html_helper
INFO - 2023-08-18 07:30:24 --> Helper loaded: text_helper
INFO - 2023-08-18 07:30:24 --> Helper loaded: form_helper
INFO - 2023-08-18 07:30:24 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:30:24 --> Helper loaded: security_helper
INFO - 2023-08-18 07:30:24 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:30:24 --> Database Driver Class Initialized
INFO - 2023-08-18 07:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:30:24 --> Parser Class Initialized
INFO - 2023-08-18 07:30:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:30:24 --> Pagination Class Initialized
INFO - 2023-08-18 07:30:24 --> Form Validation Class Initialized
INFO - 2023-08-18 07:30:24 --> Controller Class Initialized
INFO - 2023-08-18 07:30:24 --> Model Class Initialized
DEBUG - 2023-08-18 07:30:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:30:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:30:24 --> Model Class Initialized
DEBUG - 2023-08-18 07:30:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:30:24 --> Model Class Initialized
ERROR - 2023-08-18 07:30:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:30:24 --> Config Class Initialized
INFO - 2023-08-18 07:30:24 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:30:24 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:30:24 --> Utf8 Class Initialized
INFO - 2023-08-18 07:30:24 --> URI Class Initialized
INFO - 2023-08-18 07:30:24 --> Router Class Initialized
INFO - 2023-08-18 07:30:24 --> Output Class Initialized
INFO - 2023-08-18 07:30:24 --> Security Class Initialized
DEBUG - 2023-08-18 07:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:30:24 --> Input Class Initialized
INFO - 2023-08-18 07:30:24 --> Language Class Initialized
INFO - 2023-08-18 07:30:24 --> Loader Class Initialized
INFO - 2023-08-18 07:30:24 --> Helper loaded: url_helper
INFO - 2023-08-18 07:30:24 --> Helper loaded: file_helper
INFO - 2023-08-18 07:30:24 --> Helper loaded: html_helper
INFO - 2023-08-18 07:30:24 --> Helper loaded: text_helper
INFO - 2023-08-18 07:30:24 --> Helper loaded: form_helper
INFO - 2023-08-18 07:30:24 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:30:24 --> Helper loaded: security_helper
INFO - 2023-08-18 07:30:24 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:30:24 --> Database Driver Class Initialized
INFO - 2023-08-18 07:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:30:24 --> Parser Class Initialized
INFO - 2023-08-18 07:30:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:30:24 --> Pagination Class Initialized
INFO - 2023-08-18 07:30:24 --> Form Validation Class Initialized
INFO - 2023-08-18 07:30:24 --> Controller Class Initialized
INFO - 2023-08-18 07:30:24 --> Model Class Initialized
DEBUG - 2023-08-18 07:30:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:30:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:30:24 --> Model Class Initialized
DEBUG - 2023-08-18 07:30:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:30:24 --> Model Class Initialized
DEBUG - 2023-08-18 07:30:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:30:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-18 07:30:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:30:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 07:30:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 07:30:24 --> Model Class Initialized
INFO - 2023-08-18 07:30:24 --> Model Class Initialized
INFO - 2023-08-18 07:30:24 --> Model Class Initialized
INFO - 2023-08-18 07:30:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 07:30:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 07:30:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 07:30:24 --> Final output sent to browser
DEBUG - 2023-08-18 07:30:24 --> Total execution time: 0.1373
ERROR - 2023-08-18 07:30:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:30:38 --> Config Class Initialized
INFO - 2023-08-18 07:30:38 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:30:38 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:30:38 --> Utf8 Class Initialized
INFO - 2023-08-18 07:30:38 --> URI Class Initialized
INFO - 2023-08-18 07:30:38 --> Router Class Initialized
INFO - 2023-08-18 07:30:38 --> Output Class Initialized
INFO - 2023-08-18 07:30:38 --> Security Class Initialized
DEBUG - 2023-08-18 07:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:30:38 --> Input Class Initialized
INFO - 2023-08-18 07:30:38 --> Language Class Initialized
INFO - 2023-08-18 07:30:38 --> Loader Class Initialized
INFO - 2023-08-18 07:30:38 --> Helper loaded: url_helper
INFO - 2023-08-18 07:30:38 --> Helper loaded: file_helper
INFO - 2023-08-18 07:30:38 --> Helper loaded: html_helper
INFO - 2023-08-18 07:30:38 --> Helper loaded: text_helper
INFO - 2023-08-18 07:30:38 --> Helper loaded: form_helper
INFO - 2023-08-18 07:30:38 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:30:38 --> Helper loaded: security_helper
INFO - 2023-08-18 07:30:38 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:30:38 --> Database Driver Class Initialized
INFO - 2023-08-18 07:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:30:38 --> Parser Class Initialized
INFO - 2023-08-18 07:30:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:30:38 --> Pagination Class Initialized
INFO - 2023-08-18 07:30:38 --> Form Validation Class Initialized
INFO - 2023-08-18 07:30:38 --> Controller Class Initialized
INFO - 2023-08-18 07:30:38 --> Model Class Initialized
DEBUG - 2023-08-18 07:30:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:30:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:30:38 --> Model Class Initialized
DEBUG - 2023-08-18 07:30:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:30:38 --> Model Class Initialized
INFO - 2023-08-18 07:30:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-18 07:30:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:30:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 07:30:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 07:30:38 --> Model Class Initialized
INFO - 2023-08-18 07:30:38 --> Model Class Initialized
INFO - 2023-08-18 07:30:38 --> Model Class Initialized
INFO - 2023-08-18 07:30:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 07:30:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 07:30:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 07:30:38 --> Final output sent to browser
DEBUG - 2023-08-18 07:30:38 --> Total execution time: 0.1584
ERROR - 2023-08-18 07:30:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:30:39 --> Config Class Initialized
INFO - 2023-08-18 07:30:39 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:30:39 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:30:39 --> Utf8 Class Initialized
INFO - 2023-08-18 07:30:39 --> URI Class Initialized
INFO - 2023-08-18 07:30:39 --> Router Class Initialized
INFO - 2023-08-18 07:30:39 --> Output Class Initialized
INFO - 2023-08-18 07:30:39 --> Security Class Initialized
DEBUG - 2023-08-18 07:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:30:39 --> Input Class Initialized
INFO - 2023-08-18 07:30:39 --> Language Class Initialized
INFO - 2023-08-18 07:30:39 --> Loader Class Initialized
INFO - 2023-08-18 07:30:39 --> Helper loaded: url_helper
INFO - 2023-08-18 07:30:39 --> Helper loaded: file_helper
INFO - 2023-08-18 07:30:39 --> Helper loaded: html_helper
INFO - 2023-08-18 07:30:39 --> Helper loaded: text_helper
INFO - 2023-08-18 07:30:39 --> Helper loaded: form_helper
INFO - 2023-08-18 07:30:39 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:30:39 --> Helper loaded: security_helper
INFO - 2023-08-18 07:30:39 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:30:39 --> Database Driver Class Initialized
INFO - 2023-08-18 07:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:30:39 --> Parser Class Initialized
INFO - 2023-08-18 07:30:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:30:39 --> Pagination Class Initialized
INFO - 2023-08-18 07:30:39 --> Form Validation Class Initialized
INFO - 2023-08-18 07:30:39 --> Controller Class Initialized
INFO - 2023-08-18 07:30:39 --> Model Class Initialized
DEBUG - 2023-08-18 07:30:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:30:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:30:39 --> Model Class Initialized
DEBUG - 2023-08-18 07:30:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:30:39 --> Model Class Initialized
DEBUG - 2023-08-18 07:30:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:30:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-18 07:30:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:30:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 07:30:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 07:30:39 --> Model Class Initialized
INFO - 2023-08-18 07:30:39 --> Model Class Initialized
INFO - 2023-08-18 07:30:39 --> Model Class Initialized
INFO - 2023-08-18 07:30:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 07:30:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 07:30:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 07:30:39 --> Final output sent to browser
DEBUG - 2023-08-18 07:30:39 --> Total execution time: 0.0877
ERROR - 2023-08-18 07:30:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:30:39 --> Config Class Initialized
INFO - 2023-08-18 07:30:39 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:30:39 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:30:39 --> Utf8 Class Initialized
INFO - 2023-08-18 07:30:39 --> URI Class Initialized
INFO - 2023-08-18 07:30:39 --> Router Class Initialized
INFO - 2023-08-18 07:30:39 --> Output Class Initialized
INFO - 2023-08-18 07:30:39 --> Security Class Initialized
DEBUG - 2023-08-18 07:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:30:39 --> Input Class Initialized
INFO - 2023-08-18 07:30:39 --> Language Class Initialized
INFO - 2023-08-18 07:30:39 --> Loader Class Initialized
INFO - 2023-08-18 07:30:39 --> Helper loaded: url_helper
INFO - 2023-08-18 07:30:39 --> Helper loaded: file_helper
INFO - 2023-08-18 07:30:39 --> Helper loaded: html_helper
INFO - 2023-08-18 07:30:39 --> Helper loaded: text_helper
INFO - 2023-08-18 07:30:39 --> Helper loaded: form_helper
INFO - 2023-08-18 07:30:39 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:30:39 --> Helper loaded: security_helper
INFO - 2023-08-18 07:30:39 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:30:39 --> Database Driver Class Initialized
INFO - 2023-08-18 07:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:30:39 --> Parser Class Initialized
INFO - 2023-08-18 07:30:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:30:39 --> Pagination Class Initialized
INFO - 2023-08-18 07:30:39 --> Form Validation Class Initialized
INFO - 2023-08-18 07:30:39 --> Controller Class Initialized
INFO - 2023-08-18 07:30:39 --> Model Class Initialized
DEBUG - 2023-08-18 07:30:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:30:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:30:39 --> Model Class Initialized
DEBUG - 2023-08-18 07:30:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:30:39 --> Model Class Initialized
INFO - 2023-08-18 07:30:39 --> Final output sent to browser
DEBUG - 2023-08-18 07:30:39 --> Total execution time: 0.0585
ERROR - 2023-08-18 07:30:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:30:43 --> Config Class Initialized
INFO - 2023-08-18 07:30:43 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:30:43 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:30:43 --> Utf8 Class Initialized
INFO - 2023-08-18 07:30:43 --> URI Class Initialized
INFO - 2023-08-18 07:30:43 --> Router Class Initialized
INFO - 2023-08-18 07:30:43 --> Output Class Initialized
INFO - 2023-08-18 07:30:43 --> Security Class Initialized
DEBUG - 2023-08-18 07:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:30:43 --> Input Class Initialized
INFO - 2023-08-18 07:30:43 --> Language Class Initialized
INFO - 2023-08-18 07:30:43 --> Loader Class Initialized
INFO - 2023-08-18 07:30:43 --> Helper loaded: url_helper
INFO - 2023-08-18 07:30:43 --> Helper loaded: file_helper
INFO - 2023-08-18 07:30:43 --> Helper loaded: html_helper
INFO - 2023-08-18 07:30:43 --> Helper loaded: text_helper
INFO - 2023-08-18 07:30:43 --> Helper loaded: form_helper
INFO - 2023-08-18 07:30:43 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:30:43 --> Helper loaded: security_helper
INFO - 2023-08-18 07:30:43 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:30:43 --> Database Driver Class Initialized
INFO - 2023-08-18 07:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:30:43 --> Parser Class Initialized
INFO - 2023-08-18 07:30:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:30:43 --> Pagination Class Initialized
INFO - 2023-08-18 07:30:43 --> Form Validation Class Initialized
INFO - 2023-08-18 07:30:43 --> Controller Class Initialized
INFO - 2023-08-18 07:30:43 --> Model Class Initialized
DEBUG - 2023-08-18 07:30:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:30:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:30:43 --> Model Class Initialized
DEBUG - 2023-08-18 07:30:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:30:43 --> Model Class Initialized
INFO - 2023-08-18 07:30:44 --> Final output sent to browser
DEBUG - 2023-08-18 07:30:44 --> Total execution time: 0.6024
ERROR - 2023-08-18 07:31:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:31:17 --> Config Class Initialized
INFO - 2023-08-18 07:31:17 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:31:17 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:31:17 --> Utf8 Class Initialized
INFO - 2023-08-18 07:31:17 --> URI Class Initialized
INFO - 2023-08-18 07:31:17 --> Router Class Initialized
INFO - 2023-08-18 07:31:17 --> Output Class Initialized
INFO - 2023-08-18 07:31:17 --> Security Class Initialized
DEBUG - 2023-08-18 07:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:31:17 --> Input Class Initialized
INFO - 2023-08-18 07:31:17 --> Language Class Initialized
INFO - 2023-08-18 07:31:17 --> Loader Class Initialized
INFO - 2023-08-18 07:31:17 --> Helper loaded: url_helper
INFO - 2023-08-18 07:31:17 --> Helper loaded: file_helper
INFO - 2023-08-18 07:31:17 --> Helper loaded: html_helper
INFO - 2023-08-18 07:31:17 --> Helper loaded: text_helper
INFO - 2023-08-18 07:31:17 --> Helper loaded: form_helper
INFO - 2023-08-18 07:31:17 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:31:17 --> Helper loaded: security_helper
INFO - 2023-08-18 07:31:17 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:31:17 --> Database Driver Class Initialized
INFO - 2023-08-18 07:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:31:17 --> Parser Class Initialized
INFO - 2023-08-18 07:31:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:31:17 --> Pagination Class Initialized
INFO - 2023-08-18 07:31:17 --> Form Validation Class Initialized
INFO - 2023-08-18 07:31:17 --> Controller Class Initialized
INFO - 2023-08-18 07:31:17 --> Model Class Initialized
DEBUG - 2023-08-18 07:31:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:31:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:31:17 --> Model Class Initialized
DEBUG - 2023-08-18 07:31:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:31:17 --> Model Class Initialized
ERROR - 2023-08-18 07:31:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/edit_invoice_form.php 113
INFO - 2023-08-18 07:31:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/edit_invoice_form.php
DEBUG - 2023-08-18 07:31:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:31:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 07:31:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 07:31:17 --> Model Class Initialized
INFO - 2023-08-18 07:31:17 --> Model Class Initialized
INFO - 2023-08-18 07:31:17 --> Model Class Initialized
INFO - 2023-08-18 07:31:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 07:31:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 07:31:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 07:31:18 --> Final output sent to browser
DEBUG - 2023-08-18 07:31:18 --> Total execution time: 0.2004
ERROR - 2023-08-18 07:31:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:31:18 --> Config Class Initialized
INFO - 2023-08-18 07:31:18 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:31:18 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:31:18 --> Utf8 Class Initialized
INFO - 2023-08-18 07:31:18 --> URI Class Initialized
INFO - 2023-08-18 07:31:18 --> Router Class Initialized
INFO - 2023-08-18 07:31:18 --> Output Class Initialized
INFO - 2023-08-18 07:31:18 --> Security Class Initialized
DEBUG - 2023-08-18 07:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:31:18 --> Input Class Initialized
INFO - 2023-08-18 07:31:18 --> Language Class Initialized
INFO - 2023-08-18 07:31:18 --> Loader Class Initialized
INFO - 2023-08-18 07:31:18 --> Helper loaded: url_helper
INFO - 2023-08-18 07:31:18 --> Helper loaded: file_helper
INFO - 2023-08-18 07:31:18 --> Helper loaded: html_helper
INFO - 2023-08-18 07:31:18 --> Helper loaded: text_helper
INFO - 2023-08-18 07:31:18 --> Helper loaded: form_helper
INFO - 2023-08-18 07:31:18 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:31:18 --> Helper loaded: security_helper
INFO - 2023-08-18 07:31:18 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:31:18 --> Database Driver Class Initialized
INFO - 2023-08-18 07:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:31:18 --> Parser Class Initialized
INFO - 2023-08-18 07:31:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:31:18 --> Pagination Class Initialized
INFO - 2023-08-18 07:31:18 --> Form Validation Class Initialized
INFO - 2023-08-18 07:31:18 --> Controller Class Initialized
INFO - 2023-08-18 07:31:18 --> Model Class Initialized
DEBUG - 2023-08-18 07:31:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:31:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:31:18 --> Model Class Initialized
DEBUG - 2023-08-18 07:31:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:31:18 --> Model Class Initialized
INFO - 2023-08-18 07:31:18 --> Model Class Initialized
DEBUG - 2023-08-18 07:31:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:31:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:31:18 --> Final output sent to browser
DEBUG - 2023-08-18 07:31:18 --> Total execution time: 0.0245
ERROR - 2023-08-18 07:31:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:31:40 --> Config Class Initialized
INFO - 2023-08-18 07:31:40 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:31:40 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:31:40 --> Utf8 Class Initialized
INFO - 2023-08-18 07:31:40 --> URI Class Initialized
INFO - 2023-08-18 07:31:40 --> Router Class Initialized
INFO - 2023-08-18 07:31:40 --> Output Class Initialized
INFO - 2023-08-18 07:31:40 --> Security Class Initialized
DEBUG - 2023-08-18 07:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:31:40 --> Input Class Initialized
INFO - 2023-08-18 07:31:40 --> Language Class Initialized
INFO - 2023-08-18 07:31:40 --> Loader Class Initialized
INFO - 2023-08-18 07:31:40 --> Helper loaded: url_helper
INFO - 2023-08-18 07:31:40 --> Helper loaded: file_helper
INFO - 2023-08-18 07:31:40 --> Helper loaded: html_helper
INFO - 2023-08-18 07:31:40 --> Helper loaded: text_helper
INFO - 2023-08-18 07:31:40 --> Helper loaded: form_helper
INFO - 2023-08-18 07:31:40 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:31:40 --> Helper loaded: security_helper
INFO - 2023-08-18 07:31:40 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:31:40 --> Database Driver Class Initialized
INFO - 2023-08-18 07:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:31:40 --> Parser Class Initialized
INFO - 2023-08-18 07:31:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:31:40 --> Pagination Class Initialized
INFO - 2023-08-18 07:31:40 --> Form Validation Class Initialized
INFO - 2023-08-18 07:31:40 --> Controller Class Initialized
INFO - 2023-08-18 07:31:40 --> Model Class Initialized
DEBUG - 2023-08-18 07:31:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:31:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:31:40 --> Model Class Initialized
DEBUG - 2023-08-18 07:31:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:31:40 --> Model Class Initialized
ERROR - 2023-08-18 07:31:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:31:40 --> Config Class Initialized
INFO - 2023-08-18 07:31:40 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:31:40 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:31:40 --> Utf8 Class Initialized
INFO - 2023-08-18 07:31:40 --> URI Class Initialized
INFO - 2023-08-18 07:31:40 --> Router Class Initialized
INFO - 2023-08-18 07:31:40 --> Output Class Initialized
INFO - 2023-08-18 07:31:40 --> Security Class Initialized
DEBUG - 2023-08-18 07:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:31:40 --> Input Class Initialized
INFO - 2023-08-18 07:31:40 --> Language Class Initialized
INFO - 2023-08-18 07:31:40 --> Loader Class Initialized
INFO - 2023-08-18 07:31:40 --> Helper loaded: url_helper
INFO - 2023-08-18 07:31:40 --> Helper loaded: file_helper
INFO - 2023-08-18 07:31:40 --> Helper loaded: html_helper
INFO - 2023-08-18 07:31:40 --> Helper loaded: text_helper
INFO - 2023-08-18 07:31:40 --> Helper loaded: form_helper
INFO - 2023-08-18 07:31:40 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:31:40 --> Helper loaded: security_helper
INFO - 2023-08-18 07:31:40 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:31:40 --> Database Driver Class Initialized
INFO - 2023-08-18 07:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:31:40 --> Parser Class Initialized
INFO - 2023-08-18 07:31:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:31:40 --> Pagination Class Initialized
INFO - 2023-08-18 07:31:40 --> Form Validation Class Initialized
INFO - 2023-08-18 07:31:40 --> Controller Class Initialized
INFO - 2023-08-18 07:31:40 --> Model Class Initialized
DEBUG - 2023-08-18 07:31:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:31:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:31:40 --> Model Class Initialized
DEBUG - 2023-08-18 07:31:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:31:40 --> Model Class Initialized
DEBUG - 2023-08-18 07:31:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:31:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-18 07:31:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:31:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 07:31:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 07:31:40 --> Model Class Initialized
INFO - 2023-08-18 07:31:40 --> Model Class Initialized
INFO - 2023-08-18 07:31:40 --> Model Class Initialized
INFO - 2023-08-18 07:31:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 07:31:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 07:31:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 07:31:40 --> Final output sent to browser
DEBUG - 2023-08-18 07:31:40 --> Total execution time: 0.1316
ERROR - 2023-08-18 07:31:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:31:44 --> Config Class Initialized
INFO - 2023-08-18 07:31:44 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:31:44 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:31:44 --> Utf8 Class Initialized
INFO - 2023-08-18 07:31:44 --> URI Class Initialized
DEBUG - 2023-08-18 07:31:44 --> No URI present. Default controller set.
INFO - 2023-08-18 07:31:44 --> Router Class Initialized
INFO - 2023-08-18 07:31:44 --> Output Class Initialized
INFO - 2023-08-18 07:31:44 --> Security Class Initialized
DEBUG - 2023-08-18 07:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:31:44 --> Input Class Initialized
INFO - 2023-08-18 07:31:44 --> Language Class Initialized
INFO - 2023-08-18 07:31:44 --> Loader Class Initialized
INFO - 2023-08-18 07:31:44 --> Helper loaded: url_helper
INFO - 2023-08-18 07:31:44 --> Helper loaded: file_helper
INFO - 2023-08-18 07:31:44 --> Helper loaded: html_helper
INFO - 2023-08-18 07:31:44 --> Helper loaded: text_helper
INFO - 2023-08-18 07:31:44 --> Helper loaded: form_helper
INFO - 2023-08-18 07:31:44 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:31:44 --> Helper loaded: security_helper
INFO - 2023-08-18 07:31:44 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:31:44 --> Database Driver Class Initialized
INFO - 2023-08-18 07:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:31:44 --> Parser Class Initialized
INFO - 2023-08-18 07:31:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:31:44 --> Pagination Class Initialized
INFO - 2023-08-18 07:31:44 --> Form Validation Class Initialized
INFO - 2023-08-18 07:31:44 --> Controller Class Initialized
INFO - 2023-08-18 07:31:44 --> Model Class Initialized
DEBUG - 2023-08-18 07:31:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:31:44 --> Model Class Initialized
DEBUG - 2023-08-18 07:31:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:31:44 --> Model Class Initialized
INFO - 2023-08-18 07:31:44 --> Model Class Initialized
INFO - 2023-08-18 07:31:44 --> Model Class Initialized
INFO - 2023-08-18 07:31:44 --> Model Class Initialized
DEBUG - 2023-08-18 07:31:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:31:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:31:44 --> Model Class Initialized
INFO - 2023-08-18 07:31:44 --> Model Class Initialized
INFO - 2023-08-18 07:31:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-18 07:31:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:31:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 07:31:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 07:31:44 --> Model Class Initialized
INFO - 2023-08-18 07:31:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 07:31:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 07:31:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 07:31:44 --> Final output sent to browser
DEBUG - 2023-08-18 07:31:44 --> Total execution time: 0.1745
ERROR - 2023-08-18 07:31:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:31:53 --> Config Class Initialized
INFO - 2023-08-18 07:31:53 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:31:53 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:31:53 --> Utf8 Class Initialized
INFO - 2023-08-18 07:31:53 --> URI Class Initialized
INFO - 2023-08-18 07:31:53 --> Router Class Initialized
INFO - 2023-08-18 07:31:53 --> Output Class Initialized
INFO - 2023-08-18 07:31:53 --> Security Class Initialized
DEBUG - 2023-08-18 07:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:31:53 --> Input Class Initialized
INFO - 2023-08-18 07:31:53 --> Language Class Initialized
INFO - 2023-08-18 07:31:53 --> Loader Class Initialized
INFO - 2023-08-18 07:31:53 --> Helper loaded: url_helper
INFO - 2023-08-18 07:31:53 --> Helper loaded: file_helper
INFO - 2023-08-18 07:31:53 --> Helper loaded: html_helper
INFO - 2023-08-18 07:31:53 --> Helper loaded: text_helper
INFO - 2023-08-18 07:31:53 --> Helper loaded: form_helper
INFO - 2023-08-18 07:31:53 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:31:53 --> Helper loaded: security_helper
INFO - 2023-08-18 07:31:53 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:31:53 --> Database Driver Class Initialized
INFO - 2023-08-18 07:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:31:53 --> Parser Class Initialized
INFO - 2023-08-18 07:31:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:31:53 --> Pagination Class Initialized
INFO - 2023-08-18 07:31:53 --> Form Validation Class Initialized
INFO - 2023-08-18 07:31:53 --> Controller Class Initialized
INFO - 2023-08-18 07:31:53 --> Model Class Initialized
DEBUG - 2023-08-18 07:31:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:31:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:31:53 --> Model Class Initialized
DEBUG - 2023-08-18 07:31:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:31:53 --> Model Class Initialized
INFO - 2023-08-18 07:31:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-18 07:31:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:31:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 07:31:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 07:31:53 --> Model Class Initialized
INFO - 2023-08-18 07:31:53 --> Model Class Initialized
INFO - 2023-08-18 07:31:53 --> Model Class Initialized
INFO - 2023-08-18 07:31:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 07:31:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 07:31:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 07:31:53 --> Final output sent to browser
DEBUG - 2023-08-18 07:31:53 --> Total execution time: 0.1503
ERROR - 2023-08-18 07:31:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:31:53 --> Config Class Initialized
INFO - 2023-08-18 07:31:53 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:31:53 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:31:53 --> Utf8 Class Initialized
INFO - 2023-08-18 07:31:53 --> URI Class Initialized
INFO - 2023-08-18 07:31:53 --> Router Class Initialized
INFO - 2023-08-18 07:31:53 --> Output Class Initialized
INFO - 2023-08-18 07:31:53 --> Security Class Initialized
DEBUG - 2023-08-18 07:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:31:53 --> Input Class Initialized
INFO - 2023-08-18 07:31:53 --> Language Class Initialized
INFO - 2023-08-18 07:31:53 --> Loader Class Initialized
INFO - 2023-08-18 07:31:53 --> Helper loaded: url_helper
INFO - 2023-08-18 07:31:53 --> Helper loaded: file_helper
INFO - 2023-08-18 07:31:53 --> Helper loaded: html_helper
INFO - 2023-08-18 07:31:53 --> Helper loaded: text_helper
INFO - 2023-08-18 07:31:53 --> Helper loaded: form_helper
INFO - 2023-08-18 07:31:53 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:31:53 --> Helper loaded: security_helper
INFO - 2023-08-18 07:31:53 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:31:53 --> Database Driver Class Initialized
INFO - 2023-08-18 07:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:31:53 --> Parser Class Initialized
INFO - 2023-08-18 07:31:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:31:53 --> Pagination Class Initialized
INFO - 2023-08-18 07:31:53 --> Form Validation Class Initialized
INFO - 2023-08-18 07:31:53 --> Controller Class Initialized
INFO - 2023-08-18 07:31:53 --> Model Class Initialized
DEBUG - 2023-08-18 07:31:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:31:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:31:53 --> Model Class Initialized
DEBUG - 2023-08-18 07:31:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:31:53 --> Model Class Initialized
INFO - 2023-08-18 07:31:53 --> Final output sent to browser
DEBUG - 2023-08-18 07:31:53 --> Total execution time: 0.0503
ERROR - 2023-08-18 07:31:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:31:57 --> Config Class Initialized
INFO - 2023-08-18 07:31:57 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:31:57 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:31:57 --> Utf8 Class Initialized
INFO - 2023-08-18 07:31:57 --> URI Class Initialized
INFO - 2023-08-18 07:31:57 --> Router Class Initialized
INFO - 2023-08-18 07:31:57 --> Output Class Initialized
INFO - 2023-08-18 07:31:57 --> Security Class Initialized
DEBUG - 2023-08-18 07:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:31:57 --> Input Class Initialized
INFO - 2023-08-18 07:31:57 --> Language Class Initialized
INFO - 2023-08-18 07:31:57 --> Loader Class Initialized
INFO - 2023-08-18 07:31:57 --> Helper loaded: url_helper
INFO - 2023-08-18 07:31:57 --> Helper loaded: file_helper
INFO - 2023-08-18 07:31:57 --> Helper loaded: html_helper
INFO - 2023-08-18 07:31:57 --> Helper loaded: text_helper
INFO - 2023-08-18 07:31:57 --> Helper loaded: form_helper
INFO - 2023-08-18 07:31:57 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:31:57 --> Helper loaded: security_helper
INFO - 2023-08-18 07:31:57 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:31:57 --> Database Driver Class Initialized
INFO - 2023-08-18 07:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:31:57 --> Parser Class Initialized
INFO - 2023-08-18 07:31:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:31:57 --> Pagination Class Initialized
INFO - 2023-08-18 07:31:57 --> Form Validation Class Initialized
INFO - 2023-08-18 07:31:57 --> Controller Class Initialized
INFO - 2023-08-18 07:31:57 --> Model Class Initialized
DEBUG - 2023-08-18 07:31:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:31:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:31:57 --> Model Class Initialized
DEBUG - 2023-08-18 07:31:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:31:57 --> Model Class Initialized
INFO - 2023-08-18 07:31:57 --> Final output sent to browser
DEBUG - 2023-08-18 07:31:57 --> Total execution time: 0.5229
ERROR - 2023-08-18 07:32:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:32:09 --> Config Class Initialized
INFO - 2023-08-18 07:32:09 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:32:09 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:32:09 --> Utf8 Class Initialized
INFO - 2023-08-18 07:32:09 --> URI Class Initialized
DEBUG - 2023-08-18 07:32:09 --> No URI present. Default controller set.
INFO - 2023-08-18 07:32:09 --> Router Class Initialized
INFO - 2023-08-18 07:32:09 --> Output Class Initialized
INFO - 2023-08-18 07:32:09 --> Security Class Initialized
DEBUG - 2023-08-18 07:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:32:09 --> Input Class Initialized
INFO - 2023-08-18 07:32:09 --> Language Class Initialized
INFO - 2023-08-18 07:32:09 --> Loader Class Initialized
INFO - 2023-08-18 07:32:09 --> Helper loaded: url_helper
INFO - 2023-08-18 07:32:09 --> Helper loaded: file_helper
INFO - 2023-08-18 07:32:09 --> Helper loaded: html_helper
INFO - 2023-08-18 07:32:09 --> Helper loaded: text_helper
INFO - 2023-08-18 07:32:09 --> Helper loaded: form_helper
INFO - 2023-08-18 07:32:09 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:32:09 --> Helper loaded: security_helper
INFO - 2023-08-18 07:32:09 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:32:09 --> Database Driver Class Initialized
INFO - 2023-08-18 07:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:32:09 --> Parser Class Initialized
INFO - 2023-08-18 07:32:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:32:09 --> Pagination Class Initialized
INFO - 2023-08-18 07:32:09 --> Form Validation Class Initialized
INFO - 2023-08-18 07:32:09 --> Controller Class Initialized
INFO - 2023-08-18 07:32:09 --> Model Class Initialized
DEBUG - 2023-08-18 07:32:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:32:09 --> Model Class Initialized
DEBUG - 2023-08-18 07:32:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:32:09 --> Model Class Initialized
INFO - 2023-08-18 07:32:09 --> Model Class Initialized
INFO - 2023-08-18 07:32:09 --> Model Class Initialized
INFO - 2023-08-18 07:32:09 --> Model Class Initialized
DEBUG - 2023-08-18 07:32:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:32:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:32:09 --> Model Class Initialized
INFO - 2023-08-18 07:32:09 --> Model Class Initialized
INFO - 2023-08-18 07:32:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-18 07:32:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:32:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 07:32:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 07:32:09 --> Model Class Initialized
INFO - 2023-08-18 07:32:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 07:32:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 07:32:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 07:32:10 --> Final output sent to browser
DEBUG - 2023-08-18 07:32:10 --> Total execution time: 0.1895
ERROR - 2023-08-18 07:32:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:32:22 --> Config Class Initialized
INFO - 2023-08-18 07:32:22 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:32:22 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:32:22 --> Utf8 Class Initialized
INFO - 2023-08-18 07:32:22 --> URI Class Initialized
INFO - 2023-08-18 07:32:22 --> Router Class Initialized
INFO - 2023-08-18 07:32:22 --> Output Class Initialized
INFO - 2023-08-18 07:32:22 --> Security Class Initialized
DEBUG - 2023-08-18 07:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:32:22 --> Input Class Initialized
INFO - 2023-08-18 07:32:22 --> Language Class Initialized
INFO - 2023-08-18 07:32:22 --> Loader Class Initialized
INFO - 2023-08-18 07:32:22 --> Helper loaded: url_helper
INFO - 2023-08-18 07:32:22 --> Helper loaded: file_helper
INFO - 2023-08-18 07:32:22 --> Helper loaded: html_helper
INFO - 2023-08-18 07:32:22 --> Helper loaded: text_helper
INFO - 2023-08-18 07:32:22 --> Helper loaded: form_helper
INFO - 2023-08-18 07:32:22 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:32:22 --> Helper loaded: security_helper
INFO - 2023-08-18 07:32:22 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:32:22 --> Database Driver Class Initialized
INFO - 2023-08-18 07:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:32:22 --> Parser Class Initialized
INFO - 2023-08-18 07:32:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:32:22 --> Pagination Class Initialized
INFO - 2023-08-18 07:32:22 --> Form Validation Class Initialized
INFO - 2023-08-18 07:32:22 --> Controller Class Initialized
INFO - 2023-08-18 07:32:22 --> Model Class Initialized
DEBUG - 2023-08-18 07:32:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:32:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:32:22 --> Model Class Initialized
DEBUG - 2023-08-18 07:32:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:32:22 --> Model Class Initialized
INFO - 2023-08-18 07:32:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-18 07:32:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:32:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 07:32:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 07:32:22 --> Model Class Initialized
INFO - 2023-08-18 07:32:22 --> Model Class Initialized
INFO - 2023-08-18 07:32:22 --> Model Class Initialized
INFO - 2023-08-18 07:32:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 07:32:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 07:32:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 07:32:22 --> Final output sent to browser
DEBUG - 2023-08-18 07:32:22 --> Total execution time: 0.1379
ERROR - 2023-08-18 07:32:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:32:23 --> Config Class Initialized
INFO - 2023-08-18 07:32:23 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:32:23 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:32:23 --> Utf8 Class Initialized
INFO - 2023-08-18 07:32:23 --> URI Class Initialized
INFO - 2023-08-18 07:32:23 --> Router Class Initialized
INFO - 2023-08-18 07:32:23 --> Output Class Initialized
INFO - 2023-08-18 07:32:23 --> Security Class Initialized
DEBUG - 2023-08-18 07:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:32:23 --> Input Class Initialized
INFO - 2023-08-18 07:32:23 --> Language Class Initialized
INFO - 2023-08-18 07:32:23 --> Loader Class Initialized
INFO - 2023-08-18 07:32:23 --> Helper loaded: url_helper
INFO - 2023-08-18 07:32:23 --> Helper loaded: file_helper
INFO - 2023-08-18 07:32:23 --> Helper loaded: html_helper
INFO - 2023-08-18 07:32:23 --> Helper loaded: text_helper
INFO - 2023-08-18 07:32:23 --> Helper loaded: form_helper
INFO - 2023-08-18 07:32:23 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:32:23 --> Helper loaded: security_helper
INFO - 2023-08-18 07:32:23 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:32:23 --> Database Driver Class Initialized
INFO - 2023-08-18 07:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:32:23 --> Parser Class Initialized
INFO - 2023-08-18 07:32:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:32:23 --> Pagination Class Initialized
INFO - 2023-08-18 07:32:23 --> Form Validation Class Initialized
INFO - 2023-08-18 07:32:23 --> Controller Class Initialized
INFO - 2023-08-18 07:32:23 --> Model Class Initialized
DEBUG - 2023-08-18 07:32:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:32:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:32:23 --> Model Class Initialized
DEBUG - 2023-08-18 07:32:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:32:23 --> Model Class Initialized
INFO - 2023-08-18 07:32:23 --> Final output sent to browser
DEBUG - 2023-08-18 07:32:23 --> Total execution time: 0.0563
ERROR - 2023-08-18 07:32:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:32:30 --> Config Class Initialized
INFO - 2023-08-18 07:32:30 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:32:30 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:32:30 --> Utf8 Class Initialized
INFO - 2023-08-18 07:32:30 --> URI Class Initialized
DEBUG - 2023-08-18 07:32:30 --> No URI present. Default controller set.
INFO - 2023-08-18 07:32:30 --> Router Class Initialized
INFO - 2023-08-18 07:32:30 --> Output Class Initialized
INFO - 2023-08-18 07:32:30 --> Security Class Initialized
DEBUG - 2023-08-18 07:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:32:30 --> Input Class Initialized
INFO - 2023-08-18 07:32:30 --> Language Class Initialized
INFO - 2023-08-18 07:32:30 --> Loader Class Initialized
INFO - 2023-08-18 07:32:30 --> Helper loaded: url_helper
INFO - 2023-08-18 07:32:30 --> Helper loaded: file_helper
INFO - 2023-08-18 07:32:30 --> Helper loaded: html_helper
INFO - 2023-08-18 07:32:30 --> Helper loaded: text_helper
INFO - 2023-08-18 07:32:30 --> Helper loaded: form_helper
INFO - 2023-08-18 07:32:30 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:32:30 --> Helper loaded: security_helper
INFO - 2023-08-18 07:32:30 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:32:30 --> Database Driver Class Initialized
INFO - 2023-08-18 07:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:32:30 --> Parser Class Initialized
INFO - 2023-08-18 07:32:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:32:30 --> Pagination Class Initialized
INFO - 2023-08-18 07:32:30 --> Form Validation Class Initialized
INFO - 2023-08-18 07:32:30 --> Controller Class Initialized
INFO - 2023-08-18 07:32:30 --> Model Class Initialized
DEBUG - 2023-08-18 07:32:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:32:30 --> Model Class Initialized
DEBUG - 2023-08-18 07:32:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:32:30 --> Model Class Initialized
INFO - 2023-08-18 07:32:30 --> Model Class Initialized
INFO - 2023-08-18 07:32:30 --> Model Class Initialized
INFO - 2023-08-18 07:32:30 --> Model Class Initialized
DEBUG - 2023-08-18 07:32:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:32:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:32:30 --> Model Class Initialized
INFO - 2023-08-18 07:32:30 --> Model Class Initialized
INFO - 2023-08-18 07:32:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-18 07:32:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:32:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 07:32:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 07:32:30 --> Model Class Initialized
INFO - 2023-08-18 07:32:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 07:32:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 07:32:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 07:32:30 --> Final output sent to browser
DEBUG - 2023-08-18 07:32:30 --> Total execution time: 0.1803
ERROR - 2023-08-18 07:35:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:35:17 --> Config Class Initialized
INFO - 2023-08-18 07:35:17 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:35:17 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:35:17 --> Utf8 Class Initialized
INFO - 2023-08-18 07:35:17 --> URI Class Initialized
DEBUG - 2023-08-18 07:35:17 --> No URI present. Default controller set.
INFO - 2023-08-18 07:35:17 --> Router Class Initialized
INFO - 2023-08-18 07:35:17 --> Output Class Initialized
INFO - 2023-08-18 07:35:17 --> Security Class Initialized
DEBUG - 2023-08-18 07:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:35:17 --> Input Class Initialized
INFO - 2023-08-18 07:35:17 --> Language Class Initialized
INFO - 2023-08-18 07:35:17 --> Loader Class Initialized
INFO - 2023-08-18 07:35:17 --> Helper loaded: url_helper
INFO - 2023-08-18 07:35:17 --> Helper loaded: file_helper
INFO - 2023-08-18 07:35:17 --> Helper loaded: html_helper
INFO - 2023-08-18 07:35:17 --> Helper loaded: text_helper
INFO - 2023-08-18 07:35:17 --> Helper loaded: form_helper
INFO - 2023-08-18 07:35:17 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:35:17 --> Helper loaded: security_helper
INFO - 2023-08-18 07:35:17 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:35:17 --> Database Driver Class Initialized
INFO - 2023-08-18 07:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:35:17 --> Parser Class Initialized
INFO - 2023-08-18 07:35:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:35:17 --> Pagination Class Initialized
INFO - 2023-08-18 07:35:17 --> Form Validation Class Initialized
INFO - 2023-08-18 07:35:17 --> Controller Class Initialized
INFO - 2023-08-18 07:35:17 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:17 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:17 --> Model Class Initialized
INFO - 2023-08-18 07:35:17 --> Model Class Initialized
INFO - 2023-08-18 07:35:17 --> Model Class Initialized
INFO - 2023-08-18 07:35:17 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:35:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:17 --> Model Class Initialized
INFO - 2023-08-18 07:35:17 --> Model Class Initialized
INFO - 2023-08-18 07:35:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-18 07:35:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 07:35:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 07:35:17 --> Model Class Initialized
INFO - 2023-08-18 07:35:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 07:35:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 07:35:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 07:35:17 --> Final output sent to browser
DEBUG - 2023-08-18 07:35:17 --> Total execution time: 0.0943
ERROR - 2023-08-18 07:35:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:35:23 --> Config Class Initialized
INFO - 2023-08-18 07:35:23 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:35:23 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:35:23 --> Utf8 Class Initialized
INFO - 2023-08-18 07:35:23 --> URI Class Initialized
INFO - 2023-08-18 07:35:23 --> Router Class Initialized
INFO - 2023-08-18 07:35:23 --> Output Class Initialized
INFO - 2023-08-18 07:35:23 --> Security Class Initialized
DEBUG - 2023-08-18 07:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:35:23 --> Input Class Initialized
INFO - 2023-08-18 07:35:23 --> Language Class Initialized
INFO - 2023-08-18 07:35:23 --> Loader Class Initialized
INFO - 2023-08-18 07:35:23 --> Helper loaded: url_helper
INFO - 2023-08-18 07:35:23 --> Helper loaded: file_helper
INFO - 2023-08-18 07:35:23 --> Helper loaded: html_helper
INFO - 2023-08-18 07:35:23 --> Helper loaded: text_helper
INFO - 2023-08-18 07:35:23 --> Helper loaded: form_helper
INFO - 2023-08-18 07:35:23 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:35:23 --> Helper loaded: security_helper
INFO - 2023-08-18 07:35:23 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:35:23 --> Database Driver Class Initialized
INFO - 2023-08-18 07:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:35:23 --> Parser Class Initialized
INFO - 2023-08-18 07:35:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:35:23 --> Pagination Class Initialized
INFO - 2023-08-18 07:35:23 --> Form Validation Class Initialized
INFO - 2023-08-18 07:35:23 --> Controller Class Initialized
INFO - 2023-08-18 07:35:23 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:35:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:23 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:23 --> Model Class Initialized
INFO - 2023-08-18 07:35:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-18 07:35:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 07:35:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 07:35:23 --> Model Class Initialized
INFO - 2023-08-18 07:35:23 --> Model Class Initialized
INFO - 2023-08-18 07:35:23 --> Model Class Initialized
INFO - 2023-08-18 07:35:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 07:35:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 07:35:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 07:35:23 --> Final output sent to browser
DEBUG - 2023-08-18 07:35:23 --> Total execution time: 0.0760
ERROR - 2023-08-18 07:35:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:35:24 --> Config Class Initialized
INFO - 2023-08-18 07:35:24 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:35:24 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:35:24 --> Utf8 Class Initialized
INFO - 2023-08-18 07:35:24 --> URI Class Initialized
INFO - 2023-08-18 07:35:24 --> Router Class Initialized
INFO - 2023-08-18 07:35:24 --> Output Class Initialized
INFO - 2023-08-18 07:35:24 --> Security Class Initialized
DEBUG - 2023-08-18 07:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:35:24 --> Input Class Initialized
INFO - 2023-08-18 07:35:24 --> Language Class Initialized
INFO - 2023-08-18 07:35:24 --> Loader Class Initialized
INFO - 2023-08-18 07:35:24 --> Helper loaded: url_helper
INFO - 2023-08-18 07:35:24 --> Helper loaded: file_helper
INFO - 2023-08-18 07:35:24 --> Helper loaded: html_helper
INFO - 2023-08-18 07:35:24 --> Helper loaded: text_helper
INFO - 2023-08-18 07:35:24 --> Helper loaded: form_helper
INFO - 2023-08-18 07:35:24 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:35:24 --> Helper loaded: security_helper
INFO - 2023-08-18 07:35:24 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:35:24 --> Database Driver Class Initialized
INFO - 2023-08-18 07:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:35:24 --> Parser Class Initialized
INFO - 2023-08-18 07:35:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:35:24 --> Pagination Class Initialized
INFO - 2023-08-18 07:35:24 --> Form Validation Class Initialized
INFO - 2023-08-18 07:35:24 --> Controller Class Initialized
INFO - 2023-08-18 07:35:24 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:35:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:24 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:24 --> Model Class Initialized
INFO - 2023-08-18 07:35:24 --> Final output sent to browser
DEBUG - 2023-08-18 07:35:24 --> Total execution time: 0.0358
ERROR - 2023-08-18 07:35:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:35:30 --> Config Class Initialized
INFO - 2023-08-18 07:35:30 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:35:30 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:35:30 --> Utf8 Class Initialized
INFO - 2023-08-18 07:35:30 --> URI Class Initialized
INFO - 2023-08-18 07:35:30 --> Router Class Initialized
INFO - 2023-08-18 07:35:30 --> Output Class Initialized
INFO - 2023-08-18 07:35:30 --> Security Class Initialized
DEBUG - 2023-08-18 07:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:35:30 --> Input Class Initialized
INFO - 2023-08-18 07:35:30 --> Language Class Initialized
INFO - 2023-08-18 07:35:30 --> Loader Class Initialized
INFO - 2023-08-18 07:35:30 --> Helper loaded: url_helper
INFO - 2023-08-18 07:35:30 --> Helper loaded: file_helper
INFO - 2023-08-18 07:35:30 --> Helper loaded: html_helper
INFO - 2023-08-18 07:35:30 --> Helper loaded: text_helper
INFO - 2023-08-18 07:35:30 --> Helper loaded: form_helper
INFO - 2023-08-18 07:35:30 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:35:30 --> Helper loaded: security_helper
INFO - 2023-08-18 07:35:30 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:35:30 --> Database Driver Class Initialized
INFO - 2023-08-18 07:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:35:30 --> Parser Class Initialized
INFO - 2023-08-18 07:35:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:35:30 --> Pagination Class Initialized
INFO - 2023-08-18 07:35:30 --> Form Validation Class Initialized
INFO - 2023-08-18 07:35:30 --> Controller Class Initialized
INFO - 2023-08-18 07:35:30 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:35:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:30 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:30 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-18 07:35:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 07:35:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 07:35:30 --> Model Class Initialized
INFO - 2023-08-18 07:35:30 --> Model Class Initialized
INFO - 2023-08-18 07:35:30 --> Model Class Initialized
INFO - 2023-08-18 07:35:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 07:35:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 07:35:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 07:35:30 --> Final output sent to browser
DEBUG - 2023-08-18 07:35:30 --> Total execution time: 0.0844
ERROR - 2023-08-18 07:35:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:35:32 --> Config Class Initialized
INFO - 2023-08-18 07:35:32 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:35:32 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:35:32 --> Utf8 Class Initialized
INFO - 2023-08-18 07:35:32 --> URI Class Initialized
DEBUG - 2023-08-18 07:35:32 --> No URI present. Default controller set.
INFO - 2023-08-18 07:35:32 --> Router Class Initialized
INFO - 2023-08-18 07:35:32 --> Output Class Initialized
INFO - 2023-08-18 07:35:32 --> Security Class Initialized
DEBUG - 2023-08-18 07:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:35:32 --> Input Class Initialized
INFO - 2023-08-18 07:35:32 --> Language Class Initialized
INFO - 2023-08-18 07:35:32 --> Loader Class Initialized
INFO - 2023-08-18 07:35:32 --> Helper loaded: url_helper
INFO - 2023-08-18 07:35:32 --> Helper loaded: file_helper
INFO - 2023-08-18 07:35:32 --> Helper loaded: html_helper
INFO - 2023-08-18 07:35:32 --> Helper loaded: text_helper
INFO - 2023-08-18 07:35:32 --> Helper loaded: form_helper
INFO - 2023-08-18 07:35:32 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:35:32 --> Helper loaded: security_helper
INFO - 2023-08-18 07:35:32 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:35:32 --> Database Driver Class Initialized
INFO - 2023-08-18 07:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:35:32 --> Parser Class Initialized
INFO - 2023-08-18 07:35:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:35:32 --> Pagination Class Initialized
INFO - 2023-08-18 07:35:32 --> Form Validation Class Initialized
INFO - 2023-08-18 07:35:32 --> Controller Class Initialized
INFO - 2023-08-18 07:35:32 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:32 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:32 --> Model Class Initialized
INFO - 2023-08-18 07:35:32 --> Model Class Initialized
INFO - 2023-08-18 07:35:32 --> Model Class Initialized
INFO - 2023-08-18 07:35:32 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:35:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:32 --> Model Class Initialized
INFO - 2023-08-18 07:35:32 --> Model Class Initialized
INFO - 2023-08-18 07:35:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-18 07:35:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 07:35:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 07:35:32 --> Model Class Initialized
INFO - 2023-08-18 07:35:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 07:35:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 07:35:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 07:35:32 --> Final output sent to browser
DEBUG - 2023-08-18 07:35:32 --> Total execution time: 0.1879
ERROR - 2023-08-18 07:35:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:35:39 --> Config Class Initialized
INFO - 2023-08-18 07:35:39 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:35:39 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:35:39 --> Utf8 Class Initialized
INFO - 2023-08-18 07:35:39 --> URI Class Initialized
INFO - 2023-08-18 07:35:39 --> Router Class Initialized
INFO - 2023-08-18 07:35:39 --> Output Class Initialized
INFO - 2023-08-18 07:35:39 --> Security Class Initialized
DEBUG - 2023-08-18 07:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:35:39 --> Input Class Initialized
INFO - 2023-08-18 07:35:39 --> Language Class Initialized
INFO - 2023-08-18 07:35:39 --> Loader Class Initialized
INFO - 2023-08-18 07:35:39 --> Helper loaded: url_helper
INFO - 2023-08-18 07:35:39 --> Helper loaded: file_helper
INFO - 2023-08-18 07:35:39 --> Helper loaded: html_helper
INFO - 2023-08-18 07:35:39 --> Helper loaded: text_helper
INFO - 2023-08-18 07:35:39 --> Helper loaded: form_helper
INFO - 2023-08-18 07:35:39 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:35:39 --> Helper loaded: security_helper
INFO - 2023-08-18 07:35:39 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:35:39 --> Database Driver Class Initialized
INFO - 2023-08-18 07:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:35:39 --> Parser Class Initialized
INFO - 2023-08-18 07:35:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:35:39 --> Pagination Class Initialized
INFO - 2023-08-18 07:35:39 --> Form Validation Class Initialized
INFO - 2023-08-18 07:35:39 --> Controller Class Initialized
INFO - 2023-08-18 07:35:39 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:35:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:39 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:39 --> Model Class Initialized
INFO - 2023-08-18 07:35:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-18 07:35:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 07:35:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 07:35:39 --> Model Class Initialized
INFO - 2023-08-18 07:35:39 --> Model Class Initialized
INFO - 2023-08-18 07:35:39 --> Model Class Initialized
INFO - 2023-08-18 07:35:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 07:35:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 07:35:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 07:35:39 --> Final output sent to browser
DEBUG - 2023-08-18 07:35:39 --> Total execution time: 0.1428
ERROR - 2023-08-18 07:35:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:35:39 --> Config Class Initialized
INFO - 2023-08-18 07:35:39 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:35:39 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:35:39 --> Utf8 Class Initialized
INFO - 2023-08-18 07:35:39 --> URI Class Initialized
INFO - 2023-08-18 07:35:39 --> Router Class Initialized
INFO - 2023-08-18 07:35:39 --> Output Class Initialized
INFO - 2023-08-18 07:35:39 --> Security Class Initialized
DEBUG - 2023-08-18 07:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:35:39 --> Input Class Initialized
INFO - 2023-08-18 07:35:39 --> Language Class Initialized
INFO - 2023-08-18 07:35:39 --> Loader Class Initialized
INFO - 2023-08-18 07:35:39 --> Helper loaded: url_helper
INFO - 2023-08-18 07:35:39 --> Helper loaded: file_helper
INFO - 2023-08-18 07:35:39 --> Helper loaded: html_helper
INFO - 2023-08-18 07:35:39 --> Helper loaded: text_helper
INFO - 2023-08-18 07:35:39 --> Helper loaded: form_helper
INFO - 2023-08-18 07:35:39 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:35:39 --> Helper loaded: security_helper
INFO - 2023-08-18 07:35:39 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:35:39 --> Database Driver Class Initialized
INFO - 2023-08-18 07:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:35:39 --> Parser Class Initialized
INFO - 2023-08-18 07:35:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:35:39 --> Pagination Class Initialized
INFO - 2023-08-18 07:35:39 --> Form Validation Class Initialized
INFO - 2023-08-18 07:35:39 --> Controller Class Initialized
INFO - 2023-08-18 07:35:39 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:35:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:39 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:39 --> Model Class Initialized
INFO - 2023-08-18 07:35:39 --> Final output sent to browser
DEBUG - 2023-08-18 07:35:39 --> Total execution time: 0.0557
ERROR - 2023-08-18 07:35:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:35:44 --> Config Class Initialized
INFO - 2023-08-18 07:35:44 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:35:44 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:35:44 --> Utf8 Class Initialized
INFO - 2023-08-18 07:35:44 --> URI Class Initialized
INFO - 2023-08-18 07:35:44 --> Router Class Initialized
INFO - 2023-08-18 07:35:44 --> Output Class Initialized
INFO - 2023-08-18 07:35:44 --> Security Class Initialized
DEBUG - 2023-08-18 07:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:35:44 --> Input Class Initialized
INFO - 2023-08-18 07:35:44 --> Language Class Initialized
INFO - 2023-08-18 07:35:44 --> Loader Class Initialized
INFO - 2023-08-18 07:35:44 --> Helper loaded: url_helper
INFO - 2023-08-18 07:35:44 --> Helper loaded: file_helper
INFO - 2023-08-18 07:35:44 --> Helper loaded: html_helper
INFO - 2023-08-18 07:35:44 --> Helper loaded: text_helper
INFO - 2023-08-18 07:35:44 --> Helper loaded: form_helper
INFO - 2023-08-18 07:35:44 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:35:44 --> Helper loaded: security_helper
INFO - 2023-08-18 07:35:44 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:35:44 --> Database Driver Class Initialized
INFO - 2023-08-18 07:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:35:44 --> Parser Class Initialized
INFO - 2023-08-18 07:35:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:35:44 --> Pagination Class Initialized
INFO - 2023-08-18 07:35:44 --> Form Validation Class Initialized
INFO - 2023-08-18 07:35:44 --> Controller Class Initialized
INFO - 2023-08-18 07:35:44 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:35:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:44 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:44 --> Model Class Initialized
INFO - 2023-08-18 07:35:45 --> Final output sent to browser
DEBUG - 2023-08-18 07:35:45 --> Total execution time: 0.6034
ERROR - 2023-08-18 07:35:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:35:51 --> Config Class Initialized
INFO - 2023-08-18 07:35:51 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:35:51 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:35:51 --> Utf8 Class Initialized
INFO - 2023-08-18 07:35:51 --> URI Class Initialized
INFO - 2023-08-18 07:35:51 --> Router Class Initialized
INFO - 2023-08-18 07:35:51 --> Output Class Initialized
INFO - 2023-08-18 07:35:51 --> Security Class Initialized
DEBUG - 2023-08-18 07:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:35:51 --> Input Class Initialized
INFO - 2023-08-18 07:35:51 --> Language Class Initialized
INFO - 2023-08-18 07:35:51 --> Loader Class Initialized
INFO - 2023-08-18 07:35:51 --> Helper loaded: url_helper
INFO - 2023-08-18 07:35:51 --> Helper loaded: file_helper
INFO - 2023-08-18 07:35:51 --> Helper loaded: html_helper
INFO - 2023-08-18 07:35:51 --> Helper loaded: text_helper
INFO - 2023-08-18 07:35:51 --> Helper loaded: form_helper
INFO - 2023-08-18 07:35:51 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:35:51 --> Helper loaded: security_helper
INFO - 2023-08-18 07:35:51 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:35:51 --> Database Driver Class Initialized
INFO - 2023-08-18 07:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:35:51 --> Parser Class Initialized
INFO - 2023-08-18 07:35:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:35:51 --> Pagination Class Initialized
INFO - 2023-08-18 07:35:51 --> Form Validation Class Initialized
INFO - 2023-08-18 07:35:51 --> Controller Class Initialized
INFO - 2023-08-18 07:35:51 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:35:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:51 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:51 --> Model Class Initialized
ERROR - 2023-08-18 07:35:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/edit_invoice_form.php 113
INFO - 2023-08-18 07:35:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/edit_invoice_form.php
DEBUG - 2023-08-18 07:35:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 07:35:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 07:35:51 --> Model Class Initialized
INFO - 2023-08-18 07:35:51 --> Model Class Initialized
INFO - 2023-08-18 07:35:51 --> Model Class Initialized
INFO - 2023-08-18 07:35:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 07:35:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 07:35:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 07:35:51 --> Final output sent to browser
DEBUG - 2023-08-18 07:35:51 --> Total execution time: 0.1817
ERROR - 2023-08-18 07:35:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:35:51 --> Config Class Initialized
INFO - 2023-08-18 07:35:51 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:35:51 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:35:51 --> Utf8 Class Initialized
INFO - 2023-08-18 07:35:51 --> URI Class Initialized
INFO - 2023-08-18 07:35:51 --> Router Class Initialized
INFO - 2023-08-18 07:35:51 --> Output Class Initialized
ERROR - 2023-08-18 07:35:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:35:51 --> Security Class Initialized
INFO - 2023-08-18 07:35:51 --> Config Class Initialized
DEBUG - 2023-08-18 07:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:35:51 --> Hooks Class Initialized
INFO - 2023-08-18 07:35:51 --> Input Class Initialized
INFO - 2023-08-18 07:35:51 --> Language Class Initialized
DEBUG - 2023-08-18 07:35:51 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:35:51 --> Utf8 Class Initialized
INFO - 2023-08-18 07:35:51 --> URI Class Initialized
INFO - 2023-08-18 07:35:51 --> Loader Class Initialized
INFO - 2023-08-18 07:35:51 --> Router Class Initialized
INFO - 2023-08-18 07:35:51 --> Helper loaded: url_helper
INFO - 2023-08-18 07:35:51 --> Output Class Initialized
INFO - 2023-08-18 07:35:51 --> Helper loaded: file_helper
INFO - 2023-08-18 07:35:51 --> Helper loaded: html_helper
INFO - 2023-08-18 07:35:51 --> Security Class Initialized
INFO - 2023-08-18 07:35:51 --> Helper loaded: text_helper
DEBUG - 2023-08-18 07:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:35:51 --> Input Class Initialized
INFO - 2023-08-18 07:35:51 --> Helper loaded: form_helper
INFO - 2023-08-18 07:35:51 --> Language Class Initialized
INFO - 2023-08-18 07:35:51 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:35:51 --> Helper loaded: security_helper
INFO - 2023-08-18 07:35:51 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:35:51 --> Loader Class Initialized
INFO - 2023-08-18 07:35:51 --> Helper loaded: url_helper
INFO - 2023-08-18 07:35:51 --> Helper loaded: file_helper
INFO - 2023-08-18 07:35:51 --> Helper loaded: html_helper
INFO - 2023-08-18 07:35:51 --> Database Driver Class Initialized
INFO - 2023-08-18 07:35:51 --> Helper loaded: text_helper
INFO - 2023-08-18 07:35:51 --> Helper loaded: form_helper
INFO - 2023-08-18 07:35:51 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:35:51 --> Helper loaded: security_helper
INFO - 2023-08-18 07:35:51 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:35:51 --> Parser Class Initialized
INFO - 2023-08-18 07:35:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:35:51 --> Pagination Class Initialized
INFO - 2023-08-18 07:35:51 --> Form Validation Class Initialized
INFO - 2023-08-18 07:35:51 --> Controller Class Initialized
INFO - 2023-08-18 07:35:51 --> Database Driver Class Initialized
INFO - 2023-08-18 07:35:51 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:35:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:51 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:51 --> Model Class Initialized
INFO - 2023-08-18 07:35:51 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:35:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:51 --> Final output sent to browser
DEBUG - 2023-08-18 07:35:51 --> Total execution time: 0.0196
INFO - 2023-08-18 07:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:35:51 --> Parser Class Initialized
INFO - 2023-08-18 07:35:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:35:51 --> Pagination Class Initialized
INFO - 2023-08-18 07:35:51 --> Form Validation Class Initialized
INFO - 2023-08-18 07:35:51 --> Controller Class Initialized
INFO - 2023-08-18 07:35:51 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:35:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:51 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:51 --> Model Class Initialized
INFO - 2023-08-18 07:35:51 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:35:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:52 --> Final output sent to browser
DEBUG - 2023-08-18 07:35:52 --> Total execution time: 0.0271
ERROR - 2023-08-18 07:35:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:35:52 --> Config Class Initialized
INFO - 2023-08-18 07:35:52 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:35:52 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:35:52 --> Utf8 Class Initialized
INFO - 2023-08-18 07:35:52 --> URI Class Initialized
INFO - 2023-08-18 07:35:52 --> Router Class Initialized
INFO - 2023-08-18 07:35:52 --> Output Class Initialized
INFO - 2023-08-18 07:35:52 --> Security Class Initialized
DEBUG - 2023-08-18 07:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:35:52 --> Input Class Initialized
INFO - 2023-08-18 07:35:52 --> Language Class Initialized
INFO - 2023-08-18 07:35:52 --> Loader Class Initialized
INFO - 2023-08-18 07:35:52 --> Helper loaded: url_helper
INFO - 2023-08-18 07:35:52 --> Helper loaded: file_helper
INFO - 2023-08-18 07:35:52 --> Helper loaded: html_helper
INFO - 2023-08-18 07:35:52 --> Helper loaded: text_helper
INFO - 2023-08-18 07:35:52 --> Helper loaded: form_helper
INFO - 2023-08-18 07:35:52 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:35:52 --> Helper loaded: security_helper
INFO - 2023-08-18 07:35:52 --> Helper loaded: cookie_helper
ERROR - 2023-08-18 07:35:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:35:52 --> Config Class Initialized
INFO - 2023-08-18 07:35:52 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:35:52 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:35:52 --> Utf8 Class Initialized
INFO - 2023-08-18 07:35:52 --> Database Driver Class Initialized
INFO - 2023-08-18 07:35:52 --> URI Class Initialized
ERROR - 2023-08-18 07:35:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:35:52 --> Router Class Initialized
INFO - 2023-08-18 07:35:52 --> Config Class Initialized
INFO - 2023-08-18 07:35:52 --> Hooks Class Initialized
INFO - 2023-08-18 07:35:52 --> Output Class Initialized
INFO - 2023-08-18 07:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:35:52 --> Security Class Initialized
INFO - 2023-08-18 07:35:52 --> Parser Class Initialized
DEBUG - 2023-08-18 07:35:52 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:35:52 --> Utf8 Class Initialized
DEBUG - 2023-08-18 07:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:35:52 --> Input Class Initialized
ERROR - 2023-08-18 07:35:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:35:52 --> Language Class Initialized
INFO - 2023-08-18 07:35:52 --> URI Class Initialized
INFO - 2023-08-18 07:35:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:35:52 --> Pagination Class Initialized
INFO - 2023-08-18 07:35:52 --> Router Class Initialized
INFO - 2023-08-18 07:35:52 --> Config Class Initialized
INFO - 2023-08-18 07:35:52 --> Hooks Class Initialized
INFO - 2023-08-18 07:35:52 --> Form Validation Class Initialized
INFO - 2023-08-18 07:35:52 --> Output Class Initialized
INFO - 2023-08-18 07:35:52 --> Controller Class Initialized
DEBUG - 2023-08-18 07:35:52 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:35:52 --> Utf8 Class Initialized
INFO - 2023-08-18 07:35:52 --> Loader Class Initialized
INFO - 2023-08-18 07:35:52 --> Security Class Initialized
INFO - 2023-08-18 07:35:52 --> URI Class Initialized
INFO - 2023-08-18 07:35:52 --> Helper loaded: url_helper
DEBUG - 2023-08-18 07:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:35:52 --> Input Class Initialized
INFO - 2023-08-18 07:35:52 --> Helper loaded: file_helper
INFO - 2023-08-18 07:35:52 --> Language Class Initialized
INFO - 2023-08-18 07:35:52 --> Router Class Initialized
INFO - 2023-08-18 07:35:52 --> Helper loaded: html_helper
INFO - 2023-08-18 07:35:52 --> Helper loaded: text_helper
INFO - 2023-08-18 07:35:52 --> Output Class Initialized
INFO - 2023-08-18 07:35:52 --> Helper loaded: form_helper
INFO - 2023-08-18 07:35:52 --> Security Class Initialized
INFO - 2023-08-18 07:35:52 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:35:52 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:52 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:52 --> Helper loaded: security_helper
INFO - 2023-08-18 07:35:52 --> Helper loaded: cookie_helper
DEBUG - 2023-08-18 07:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:35:52 --> Loader Class Initialized
INFO - 2023-08-18 07:35:52 --> Input Class Initialized
DEBUG - 2023-08-18 07:35:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:52 --> Language Class Initialized
INFO - 2023-08-18 07:35:52 --> Helper loaded: url_helper
INFO - 2023-08-18 07:35:52 --> Helper loaded: file_helper
INFO - 2023-08-18 07:35:52 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:52 --> Helper loaded: html_helper
INFO - 2023-08-18 07:35:52 --> Model Class Initialized
INFO - 2023-08-18 07:35:52 --> Helper loaded: text_helper
INFO - 2023-08-18 07:35:52 --> Helper loaded: form_helper
INFO - 2023-08-18 07:35:52 --> Loader Class Initialized
INFO - 2023-08-18 07:35:52 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:35:52 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:52 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:52 --> Helper loaded: security_helper
DEBUG - 2023-08-18 07:35:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:52 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:35:52 --> Database Driver Class Initialized
INFO - 2023-08-18 07:35:52 --> Helper loaded: url_helper
INFO - 2023-08-18 07:35:52 --> Helper loaded: file_helper
INFO - 2023-08-18 07:35:52 --> Helper loaded: html_helper
INFO - 2023-08-18 07:35:52 --> Helper loaded: text_helper
INFO - 2023-08-18 07:35:52 --> Helper loaded: form_helper
ERROR - 2023-08-18 07:35:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:35:52 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:35:52 --> Helper loaded: security_helper
INFO - 2023-08-18 07:35:52 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:35:52 --> Config Class Initialized
INFO - 2023-08-18 07:35:52 --> Hooks Class Initialized
INFO - 2023-08-18 07:35:52 --> Final output sent to browser
DEBUG - 2023-08-18 07:35:52 --> Total execution time: 0.0211
INFO - 2023-08-18 07:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:35:52 --> Database Driver Class Initialized
INFO - 2023-08-18 07:35:52 --> Parser Class Initialized
DEBUG - 2023-08-18 07:35:52 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:35:52 --> Utf8 Class Initialized
INFO - 2023-08-18 07:35:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:35:52 --> Pagination Class Initialized
INFO - 2023-08-18 07:35:52 --> URI Class Initialized
INFO - 2023-08-18 07:35:52 --> Router Class Initialized
INFO - 2023-08-18 07:35:52 --> Form Validation Class Initialized
ERROR - 2023-08-18 07:35:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:35:52 --> Controller Class Initialized
INFO - 2023-08-18 07:35:52 --> Database Driver Class Initialized
INFO - 2023-08-18 07:35:52 --> Config Class Initialized
INFO - 2023-08-18 07:35:52 --> Output Class Initialized
INFO - 2023-08-18 07:35:52 --> Hooks Class Initialized
INFO - 2023-08-18 07:35:52 --> Security Class Initialized
ERROR - 2023-08-18 07:35:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
DEBUG - 2023-08-18 07:35:52 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:35:52 --> Utf8 Class Initialized
DEBUG - 2023-08-18 07:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:35:52 --> Input Class Initialized
INFO - 2023-08-18 07:35:52 --> Language Class Initialized
INFO - 2023-08-18 07:35:52 --> Config Class Initialized
INFO - 2023-08-18 07:35:52 --> Hooks Class Initialized
INFO - 2023-08-18 07:35:52 --> URI Class Initialized
INFO - 2023-08-18 07:35:52 --> Router Class Initialized
INFO - 2023-08-18 07:35:52 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:35:52 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:35:52 --> Utf8 Class Initialized
DEBUG - 2023-08-18 07:35:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:52 --> Output Class Initialized
INFO - 2023-08-18 07:35:52 --> URI Class Initialized
INFO - 2023-08-18 07:35:52 --> Loader Class Initialized
INFO - 2023-08-18 07:35:52 --> Security Class Initialized
INFO - 2023-08-18 07:35:52 --> Router Class Initialized
INFO - 2023-08-18 07:35:52 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:52 --> Model Class Initialized
INFO - 2023-08-18 07:35:52 --> Helper loaded: url_helper
DEBUG - 2023-08-18 07:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:35:52 --> Input Class Initialized
INFO - 2023-08-18 07:35:52 --> Helper loaded: file_helper
INFO - 2023-08-18 07:35:52 --> Output Class Initialized
INFO - 2023-08-18 07:35:52 --> Language Class Initialized
INFO - 2023-08-18 07:35:52 --> Helper loaded: html_helper
INFO - 2023-08-18 07:35:52 --> Model Class Initialized
INFO - 2023-08-18 07:35:52 --> Security Class Initialized
DEBUG - 2023-08-18 07:35:52 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:52 --> Helper loaded: text_helper
DEBUG - 2023-08-18 07:35:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:35:52 --> Input Class Initialized
INFO - 2023-08-18 07:35:52 --> Helper loaded: form_helper
INFO - 2023-08-18 07:35:52 --> Language Class Initialized
INFO - 2023-08-18 07:35:52 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:35:52 --> Helper loaded: security_helper
INFO - 2023-08-18 07:35:52 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:35:52 --> Loader Class Initialized
INFO - 2023-08-18 07:35:52 --> Helper loaded: url_helper
INFO - 2023-08-18 07:35:52 --> Final output sent to browser
INFO - 2023-08-18 07:35:52 --> Helper loaded: file_helper
DEBUG - 2023-08-18 07:35:52 --> Total execution time: 0.0208
INFO - 2023-08-18 07:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:35:52 --> Helper loaded: html_helper
INFO - 2023-08-18 07:35:52 --> Parser Class Initialized
INFO - 2023-08-18 07:35:52 --> Loader Class Initialized
INFO - 2023-08-18 07:35:52 --> Helper loaded: text_helper
INFO - 2023-08-18 07:35:52 --> Helper loaded: url_helper
INFO - 2023-08-18 07:35:52 --> Helper loaded: form_helper
INFO - 2023-08-18 07:35:52 --> Helper loaded: file_helper
INFO - 2023-08-18 07:35:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:35:52 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:35:52 --> Pagination Class Initialized
INFO - 2023-08-18 07:35:52 --> Helper loaded: security_helper
INFO - 2023-08-18 07:35:52 --> Helper loaded: html_helper
INFO - 2023-08-18 07:35:52 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:35:52 --> Database Driver Class Initialized
INFO - 2023-08-18 07:35:52 --> Helper loaded: text_helper
INFO - 2023-08-18 07:35:52 --> Form Validation Class Initialized
INFO - 2023-08-18 07:35:52 --> Helper loaded: form_helper
INFO - 2023-08-18 07:35:52 --> Controller Class Initialized
INFO - 2023-08-18 07:35:52 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:35:52 --> Helper loaded: security_helper
INFO - 2023-08-18 07:35:52 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:35:52 --> Database Driver Class Initialized
ERROR - 2023-08-18 07:35:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:35:52 --> Config Class Initialized
INFO - 2023-08-18 07:35:52 --> Hooks Class Initialized
INFO - 2023-08-18 07:35:52 --> Database Driver Class Initialized
INFO - 2023-08-18 07:35:52 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:35:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:35:52 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:35:52 --> Utf8 Class Initialized
INFO - 2023-08-18 07:35:52 --> URI Class Initialized
INFO - 2023-08-18 07:35:52 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:52 --> Router Class Initialized
INFO - 2023-08-18 07:35:52 --> Model Class Initialized
INFO - 2023-08-18 07:35:52 --> Output Class Initialized
INFO - 2023-08-18 07:35:52 --> Model Class Initialized
INFO - 2023-08-18 07:35:52 --> Security Class Initialized
DEBUG - 2023-08-18 07:35:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:35:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:35:52 --> Input Class Initialized
INFO - 2023-08-18 07:35:52 --> Language Class Initialized
INFO - 2023-08-18 07:35:52 --> Loader Class Initialized
INFO - 2023-08-18 07:35:52 --> Helper loaded: url_helper
INFO - 2023-08-18 07:35:52 --> Helper loaded: file_helper
INFO - 2023-08-18 07:35:52 --> Helper loaded: html_helper
INFO - 2023-08-18 07:35:52 --> Final output sent to browser
DEBUG - 2023-08-18 07:35:52 --> Total execution time: 0.0300
INFO - 2023-08-18 07:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:35:52 --> Helper loaded: text_helper
INFO - 2023-08-18 07:35:52 --> Parser Class Initialized
INFO - 2023-08-18 07:35:52 --> Helper loaded: form_helper
INFO - 2023-08-18 07:35:52 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:35:52 --> Helper loaded: security_helper
INFO - 2023-08-18 07:35:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:35:52 --> Pagination Class Initialized
INFO - 2023-08-18 07:35:52 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:35:52 --> Form Validation Class Initialized
INFO - 2023-08-18 07:35:52 --> Controller Class Initialized
INFO - 2023-08-18 07:35:52 --> Database Driver Class Initialized
INFO - 2023-08-18 07:35:52 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:35:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:52 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:52 --> Model Class Initialized
INFO - 2023-08-18 07:35:52 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:35:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:52 --> Final output sent to browser
DEBUG - 2023-08-18 07:35:52 --> Total execution time: 0.0383
INFO - 2023-08-18 07:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:35:52 --> Parser Class Initialized
INFO - 2023-08-18 07:35:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:35:52 --> Pagination Class Initialized
INFO - 2023-08-18 07:35:52 --> Form Validation Class Initialized
INFO - 2023-08-18 07:35:52 --> Controller Class Initialized
INFO - 2023-08-18 07:35:52 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:35:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:52 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:52 --> Model Class Initialized
INFO - 2023-08-18 07:35:52 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:35:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:52 --> Final output sent to browser
DEBUG - 2023-08-18 07:35:52 --> Total execution time: 0.0359
INFO - 2023-08-18 07:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:35:52 --> Parser Class Initialized
INFO - 2023-08-18 07:35:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:35:52 --> Pagination Class Initialized
INFO - 2023-08-18 07:35:52 --> Form Validation Class Initialized
INFO - 2023-08-18 07:35:52 --> Controller Class Initialized
INFO - 2023-08-18 07:35:52 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:35:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:52 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:52 --> Model Class Initialized
INFO - 2023-08-18 07:35:52 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:35:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:52 --> Final output sent to browser
DEBUG - 2023-08-18 07:35:52 --> Total execution time: 0.0507
INFO - 2023-08-18 07:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:35:52 --> Parser Class Initialized
INFO - 2023-08-18 07:35:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:35:52 --> Pagination Class Initialized
INFO - 2023-08-18 07:35:52 --> Form Validation Class Initialized
INFO - 2023-08-18 07:35:52 --> Controller Class Initialized
INFO - 2023-08-18 07:35:52 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:35:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:52 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:52 --> Model Class Initialized
INFO - 2023-08-18 07:35:52 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:35:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:52 --> Final output sent to browser
DEBUG - 2023-08-18 07:35:52 --> Total execution time: 0.0459
INFO - 2023-08-18 07:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:35:52 --> Parser Class Initialized
INFO - 2023-08-18 07:35:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:35:52 --> Pagination Class Initialized
INFO - 2023-08-18 07:35:52 --> Form Validation Class Initialized
INFO - 2023-08-18 07:35:52 --> Controller Class Initialized
INFO - 2023-08-18 07:35:52 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:35:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:52 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:52 --> Model Class Initialized
INFO - 2023-08-18 07:35:52 --> Model Class Initialized
DEBUG - 2023-08-18 07:35:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:35:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:35:52 --> Final output sent to browser
DEBUG - 2023-08-18 07:35:52 --> Total execution time: 0.0671
ERROR - 2023-08-18 07:36:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:36:03 --> Config Class Initialized
INFO - 2023-08-18 07:36:03 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:36:03 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:36:03 --> Utf8 Class Initialized
INFO - 2023-08-18 07:36:03 --> URI Class Initialized
INFO - 2023-08-18 07:36:03 --> Router Class Initialized
INFO - 2023-08-18 07:36:03 --> Output Class Initialized
INFO - 2023-08-18 07:36:03 --> Security Class Initialized
DEBUG - 2023-08-18 07:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:36:03 --> Input Class Initialized
INFO - 2023-08-18 07:36:03 --> Language Class Initialized
INFO - 2023-08-18 07:36:03 --> Loader Class Initialized
INFO - 2023-08-18 07:36:03 --> Helper loaded: url_helper
INFO - 2023-08-18 07:36:03 --> Helper loaded: file_helper
INFO - 2023-08-18 07:36:03 --> Helper loaded: html_helper
INFO - 2023-08-18 07:36:03 --> Helper loaded: text_helper
INFO - 2023-08-18 07:36:03 --> Helper loaded: form_helper
INFO - 2023-08-18 07:36:03 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:36:03 --> Helper loaded: security_helper
INFO - 2023-08-18 07:36:03 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:36:03 --> Database Driver Class Initialized
INFO - 2023-08-18 07:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:36:03 --> Parser Class Initialized
INFO - 2023-08-18 07:36:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:36:03 --> Pagination Class Initialized
INFO - 2023-08-18 07:36:03 --> Form Validation Class Initialized
INFO - 2023-08-18 07:36:03 --> Controller Class Initialized
INFO - 2023-08-18 07:36:03 --> Model Class Initialized
DEBUG - 2023-08-18 07:36:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:36:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:36:03 --> Model Class Initialized
DEBUG - 2023-08-18 07:36:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:36:03 --> Model Class Initialized
INFO - 2023-08-18 07:36:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-18 07:36:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:36:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 07:36:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 07:36:03 --> Model Class Initialized
INFO - 2023-08-18 07:36:03 --> Model Class Initialized
INFO - 2023-08-18 07:36:03 --> Model Class Initialized
INFO - 2023-08-18 07:36:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 07:36:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 07:36:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 07:36:03 --> Final output sent to browser
DEBUG - 2023-08-18 07:36:03 --> Total execution time: 0.1378
ERROR - 2023-08-18 07:36:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:36:03 --> Config Class Initialized
INFO - 2023-08-18 07:36:03 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:36:03 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:36:03 --> Utf8 Class Initialized
INFO - 2023-08-18 07:36:03 --> URI Class Initialized
INFO - 2023-08-18 07:36:03 --> Router Class Initialized
INFO - 2023-08-18 07:36:03 --> Output Class Initialized
INFO - 2023-08-18 07:36:03 --> Security Class Initialized
DEBUG - 2023-08-18 07:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:36:03 --> Input Class Initialized
INFO - 2023-08-18 07:36:03 --> Language Class Initialized
INFO - 2023-08-18 07:36:03 --> Loader Class Initialized
INFO - 2023-08-18 07:36:03 --> Helper loaded: url_helper
INFO - 2023-08-18 07:36:03 --> Helper loaded: file_helper
INFO - 2023-08-18 07:36:03 --> Helper loaded: html_helper
INFO - 2023-08-18 07:36:03 --> Helper loaded: text_helper
INFO - 2023-08-18 07:36:03 --> Helper loaded: form_helper
INFO - 2023-08-18 07:36:03 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:36:03 --> Helper loaded: security_helper
INFO - 2023-08-18 07:36:03 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:36:03 --> Database Driver Class Initialized
INFO - 2023-08-18 07:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:36:03 --> Parser Class Initialized
INFO - 2023-08-18 07:36:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:36:03 --> Pagination Class Initialized
INFO - 2023-08-18 07:36:03 --> Form Validation Class Initialized
INFO - 2023-08-18 07:36:03 --> Controller Class Initialized
INFO - 2023-08-18 07:36:03 --> Model Class Initialized
DEBUG - 2023-08-18 07:36:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:36:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:36:03 --> Model Class Initialized
DEBUG - 2023-08-18 07:36:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:36:03 --> Model Class Initialized
INFO - 2023-08-18 07:36:03 --> Final output sent to browser
DEBUG - 2023-08-18 07:36:03 --> Total execution time: 0.0531
ERROR - 2023-08-18 07:36:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:36:10 --> Config Class Initialized
INFO - 2023-08-18 07:36:10 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:36:10 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:36:10 --> Utf8 Class Initialized
INFO - 2023-08-18 07:36:10 --> URI Class Initialized
INFO - 2023-08-18 07:36:10 --> Router Class Initialized
INFO - 2023-08-18 07:36:10 --> Output Class Initialized
INFO - 2023-08-18 07:36:10 --> Security Class Initialized
DEBUG - 2023-08-18 07:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:36:10 --> Input Class Initialized
INFO - 2023-08-18 07:36:10 --> Language Class Initialized
INFO - 2023-08-18 07:36:10 --> Loader Class Initialized
INFO - 2023-08-18 07:36:10 --> Helper loaded: url_helper
INFO - 2023-08-18 07:36:10 --> Helper loaded: file_helper
INFO - 2023-08-18 07:36:10 --> Helper loaded: html_helper
INFO - 2023-08-18 07:36:10 --> Helper loaded: text_helper
INFO - 2023-08-18 07:36:10 --> Helper loaded: form_helper
INFO - 2023-08-18 07:36:10 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:36:10 --> Helper loaded: security_helper
INFO - 2023-08-18 07:36:10 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:36:10 --> Database Driver Class Initialized
INFO - 2023-08-18 07:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:36:10 --> Parser Class Initialized
INFO - 2023-08-18 07:36:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:36:10 --> Pagination Class Initialized
INFO - 2023-08-18 07:36:10 --> Form Validation Class Initialized
INFO - 2023-08-18 07:36:10 --> Controller Class Initialized
INFO - 2023-08-18 07:36:10 --> Model Class Initialized
DEBUG - 2023-08-18 07:36:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:36:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:36:10 --> Model Class Initialized
DEBUG - 2023-08-18 07:36:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:36:10 --> Model Class Initialized
INFO - 2023-08-18 07:36:11 --> Final output sent to browser
DEBUG - 2023-08-18 07:36:11 --> Total execution time: 0.5150
ERROR - 2023-08-18 07:36:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:36:16 --> Config Class Initialized
INFO - 2023-08-18 07:36:16 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:36:16 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:36:16 --> Utf8 Class Initialized
INFO - 2023-08-18 07:36:16 --> URI Class Initialized
INFO - 2023-08-18 07:36:16 --> Router Class Initialized
INFO - 2023-08-18 07:36:16 --> Output Class Initialized
INFO - 2023-08-18 07:36:16 --> Security Class Initialized
DEBUG - 2023-08-18 07:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:36:16 --> Input Class Initialized
INFO - 2023-08-18 07:36:16 --> Language Class Initialized
INFO - 2023-08-18 07:36:16 --> Loader Class Initialized
INFO - 2023-08-18 07:36:16 --> Helper loaded: url_helper
INFO - 2023-08-18 07:36:16 --> Helper loaded: file_helper
INFO - 2023-08-18 07:36:16 --> Helper loaded: html_helper
INFO - 2023-08-18 07:36:16 --> Helper loaded: text_helper
INFO - 2023-08-18 07:36:16 --> Helper loaded: form_helper
INFO - 2023-08-18 07:36:16 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:36:16 --> Helper loaded: security_helper
INFO - 2023-08-18 07:36:16 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:36:16 --> Database Driver Class Initialized
INFO - 2023-08-18 07:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:36:16 --> Parser Class Initialized
INFO - 2023-08-18 07:36:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:36:16 --> Pagination Class Initialized
INFO - 2023-08-18 07:36:16 --> Form Validation Class Initialized
INFO - 2023-08-18 07:36:16 --> Controller Class Initialized
INFO - 2023-08-18 07:36:16 --> Model Class Initialized
DEBUG - 2023-08-18 07:36:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:36:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:36:16 --> Model Class Initialized
DEBUG - 2023-08-18 07:36:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:36:16 --> Model Class Initialized
DEBUG - 2023-08-18 07:36:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:36:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-18 07:36:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:36:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 07:36:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 07:36:16 --> Model Class Initialized
INFO - 2023-08-18 07:36:16 --> Model Class Initialized
INFO - 2023-08-18 07:36:16 --> Model Class Initialized
INFO - 2023-08-18 07:36:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 07:36:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 07:36:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 07:36:16 --> Final output sent to browser
DEBUG - 2023-08-18 07:36:16 --> Total execution time: 0.1630
ERROR - 2023-08-18 07:38:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:38:43 --> Config Class Initialized
INFO - 2023-08-18 07:38:43 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:38:43 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:38:43 --> Utf8 Class Initialized
INFO - 2023-08-18 07:38:43 --> URI Class Initialized
INFO - 2023-08-18 07:38:43 --> Router Class Initialized
INFO - 2023-08-18 07:38:43 --> Output Class Initialized
INFO - 2023-08-18 07:38:43 --> Security Class Initialized
DEBUG - 2023-08-18 07:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:38:43 --> Input Class Initialized
INFO - 2023-08-18 07:38:43 --> Language Class Initialized
INFO - 2023-08-18 07:38:43 --> Loader Class Initialized
INFO - 2023-08-18 07:38:43 --> Helper loaded: url_helper
INFO - 2023-08-18 07:38:43 --> Helper loaded: file_helper
INFO - 2023-08-18 07:38:43 --> Helper loaded: html_helper
INFO - 2023-08-18 07:38:43 --> Helper loaded: text_helper
INFO - 2023-08-18 07:38:43 --> Helper loaded: form_helper
INFO - 2023-08-18 07:38:43 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:38:43 --> Helper loaded: security_helper
INFO - 2023-08-18 07:38:43 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:38:43 --> Database Driver Class Initialized
INFO - 2023-08-18 07:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:38:43 --> Parser Class Initialized
INFO - 2023-08-18 07:38:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:38:43 --> Pagination Class Initialized
INFO - 2023-08-18 07:38:43 --> Form Validation Class Initialized
INFO - 2023-08-18 07:38:43 --> Controller Class Initialized
INFO - 2023-08-18 07:38:43 --> Model Class Initialized
DEBUG - 2023-08-18 07:38:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:38:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:38:43 --> Model Class Initialized
DEBUG - 2023-08-18 07:38:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:38:43 --> Model Class Initialized
INFO - 2023-08-18 07:38:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-18 07:38:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:38:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 07:38:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 07:38:43 --> Model Class Initialized
INFO - 2023-08-18 07:38:43 --> Model Class Initialized
INFO - 2023-08-18 07:38:43 --> Model Class Initialized
INFO - 2023-08-18 07:38:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 07:38:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 07:38:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 07:38:43 --> Final output sent to browser
DEBUG - 2023-08-18 07:38:43 --> Total execution time: 0.0875
ERROR - 2023-08-18 07:38:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:38:44 --> Config Class Initialized
INFO - 2023-08-18 07:38:44 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:38:44 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:38:44 --> Utf8 Class Initialized
INFO - 2023-08-18 07:38:44 --> URI Class Initialized
INFO - 2023-08-18 07:38:44 --> Router Class Initialized
INFO - 2023-08-18 07:38:44 --> Output Class Initialized
INFO - 2023-08-18 07:38:44 --> Security Class Initialized
DEBUG - 2023-08-18 07:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:38:44 --> Input Class Initialized
INFO - 2023-08-18 07:38:44 --> Language Class Initialized
INFO - 2023-08-18 07:38:44 --> Loader Class Initialized
INFO - 2023-08-18 07:38:44 --> Helper loaded: url_helper
INFO - 2023-08-18 07:38:44 --> Helper loaded: file_helper
INFO - 2023-08-18 07:38:44 --> Helper loaded: html_helper
INFO - 2023-08-18 07:38:44 --> Helper loaded: text_helper
INFO - 2023-08-18 07:38:44 --> Helper loaded: form_helper
INFO - 2023-08-18 07:38:44 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:38:44 --> Helper loaded: security_helper
INFO - 2023-08-18 07:38:44 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:38:44 --> Database Driver Class Initialized
INFO - 2023-08-18 07:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:38:44 --> Parser Class Initialized
INFO - 2023-08-18 07:38:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:38:44 --> Pagination Class Initialized
INFO - 2023-08-18 07:38:44 --> Form Validation Class Initialized
INFO - 2023-08-18 07:38:44 --> Controller Class Initialized
INFO - 2023-08-18 07:38:44 --> Model Class Initialized
DEBUG - 2023-08-18 07:38:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:38:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:38:44 --> Model Class Initialized
DEBUG - 2023-08-18 07:38:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:38:44 --> Model Class Initialized
INFO - 2023-08-18 07:38:44 --> Final output sent to browser
DEBUG - 2023-08-18 07:38:44 --> Total execution time: 0.0363
ERROR - 2023-08-18 07:38:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:38:48 --> Config Class Initialized
INFO - 2023-08-18 07:38:48 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:38:48 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:38:48 --> Utf8 Class Initialized
INFO - 2023-08-18 07:38:48 --> URI Class Initialized
INFO - 2023-08-18 07:38:48 --> Router Class Initialized
INFO - 2023-08-18 07:38:48 --> Output Class Initialized
INFO - 2023-08-18 07:38:48 --> Security Class Initialized
DEBUG - 2023-08-18 07:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:38:48 --> Input Class Initialized
INFO - 2023-08-18 07:38:48 --> Language Class Initialized
INFO - 2023-08-18 07:38:48 --> Loader Class Initialized
INFO - 2023-08-18 07:38:48 --> Helper loaded: url_helper
INFO - 2023-08-18 07:38:48 --> Helper loaded: file_helper
INFO - 2023-08-18 07:38:48 --> Helper loaded: html_helper
INFO - 2023-08-18 07:38:48 --> Helper loaded: text_helper
INFO - 2023-08-18 07:38:48 --> Helper loaded: form_helper
INFO - 2023-08-18 07:38:48 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:38:48 --> Helper loaded: security_helper
INFO - 2023-08-18 07:38:48 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:38:48 --> Database Driver Class Initialized
INFO - 2023-08-18 07:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:38:48 --> Parser Class Initialized
INFO - 2023-08-18 07:38:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:38:48 --> Pagination Class Initialized
INFO - 2023-08-18 07:38:48 --> Form Validation Class Initialized
INFO - 2023-08-18 07:38:48 --> Controller Class Initialized
INFO - 2023-08-18 07:38:48 --> Model Class Initialized
DEBUG - 2023-08-18 07:38:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:38:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:38:48 --> Model Class Initialized
DEBUG - 2023-08-18 07:38:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:38:48 --> Model Class Initialized
INFO - 2023-08-18 07:38:48 --> Final output sent to browser
DEBUG - 2023-08-18 07:38:48 --> Total execution time: 0.0377
ERROR - 2023-08-18 07:38:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:38:52 --> Config Class Initialized
INFO - 2023-08-18 07:38:52 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:38:52 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:38:52 --> Utf8 Class Initialized
INFO - 2023-08-18 07:38:52 --> URI Class Initialized
INFO - 2023-08-18 07:38:52 --> Router Class Initialized
INFO - 2023-08-18 07:38:52 --> Output Class Initialized
INFO - 2023-08-18 07:38:52 --> Security Class Initialized
DEBUG - 2023-08-18 07:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:38:52 --> Input Class Initialized
INFO - 2023-08-18 07:38:52 --> Language Class Initialized
INFO - 2023-08-18 07:38:52 --> Loader Class Initialized
INFO - 2023-08-18 07:38:52 --> Helper loaded: url_helper
INFO - 2023-08-18 07:38:52 --> Helper loaded: file_helper
INFO - 2023-08-18 07:38:52 --> Helper loaded: html_helper
INFO - 2023-08-18 07:38:52 --> Helper loaded: text_helper
INFO - 2023-08-18 07:38:52 --> Helper loaded: form_helper
INFO - 2023-08-18 07:38:52 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:38:52 --> Helper loaded: security_helper
INFO - 2023-08-18 07:38:52 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:38:52 --> Database Driver Class Initialized
INFO - 2023-08-18 07:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:38:52 --> Parser Class Initialized
INFO - 2023-08-18 07:38:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:38:52 --> Pagination Class Initialized
INFO - 2023-08-18 07:38:52 --> Form Validation Class Initialized
INFO - 2023-08-18 07:38:52 --> Controller Class Initialized
INFO - 2023-08-18 07:38:52 --> Model Class Initialized
DEBUG - 2023-08-18 07:38:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:38:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:38:52 --> Model Class Initialized
DEBUG - 2023-08-18 07:38:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:38:52 --> Model Class Initialized
INFO - 2023-08-18 07:38:52 --> Final output sent to browser
DEBUG - 2023-08-18 07:38:52 --> Total execution time: 0.0359
ERROR - 2023-08-18 07:38:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:38:57 --> Config Class Initialized
INFO - 2023-08-18 07:38:57 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:38:57 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:38:57 --> Utf8 Class Initialized
INFO - 2023-08-18 07:38:57 --> URI Class Initialized
INFO - 2023-08-18 07:38:57 --> Router Class Initialized
INFO - 2023-08-18 07:38:57 --> Output Class Initialized
INFO - 2023-08-18 07:38:57 --> Security Class Initialized
DEBUG - 2023-08-18 07:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:38:57 --> Input Class Initialized
INFO - 2023-08-18 07:38:57 --> Language Class Initialized
INFO - 2023-08-18 07:38:57 --> Loader Class Initialized
INFO - 2023-08-18 07:38:57 --> Helper loaded: url_helper
INFO - 2023-08-18 07:38:57 --> Helper loaded: file_helper
INFO - 2023-08-18 07:38:57 --> Helper loaded: html_helper
INFO - 2023-08-18 07:38:57 --> Helper loaded: text_helper
INFO - 2023-08-18 07:38:57 --> Helper loaded: form_helper
INFO - 2023-08-18 07:38:57 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:38:57 --> Helper loaded: security_helper
INFO - 2023-08-18 07:38:57 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:38:57 --> Database Driver Class Initialized
INFO - 2023-08-18 07:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:38:57 --> Parser Class Initialized
INFO - 2023-08-18 07:38:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:38:57 --> Pagination Class Initialized
INFO - 2023-08-18 07:38:57 --> Form Validation Class Initialized
INFO - 2023-08-18 07:38:57 --> Controller Class Initialized
INFO - 2023-08-18 07:38:57 --> Model Class Initialized
DEBUG - 2023-08-18 07:38:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:38:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:38:57 --> Model Class Initialized
DEBUG - 2023-08-18 07:38:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:38:57 --> Model Class Initialized
INFO - 2023-08-18 07:38:57 --> Final output sent to browser
DEBUG - 2023-08-18 07:38:57 --> Total execution time: 0.0364
ERROR - 2023-08-18 07:38:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:38:59 --> Config Class Initialized
INFO - 2023-08-18 07:38:59 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:38:59 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:38:59 --> Utf8 Class Initialized
INFO - 2023-08-18 07:38:59 --> URI Class Initialized
INFO - 2023-08-18 07:38:59 --> Router Class Initialized
INFO - 2023-08-18 07:38:59 --> Output Class Initialized
INFO - 2023-08-18 07:38:59 --> Security Class Initialized
DEBUG - 2023-08-18 07:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:38:59 --> Input Class Initialized
INFO - 2023-08-18 07:38:59 --> Language Class Initialized
INFO - 2023-08-18 07:38:59 --> Loader Class Initialized
INFO - 2023-08-18 07:38:59 --> Helper loaded: url_helper
INFO - 2023-08-18 07:38:59 --> Helper loaded: file_helper
INFO - 2023-08-18 07:38:59 --> Helper loaded: html_helper
INFO - 2023-08-18 07:38:59 --> Helper loaded: text_helper
INFO - 2023-08-18 07:38:59 --> Helper loaded: form_helper
INFO - 2023-08-18 07:38:59 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:38:59 --> Helper loaded: security_helper
INFO - 2023-08-18 07:38:59 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:38:59 --> Database Driver Class Initialized
INFO - 2023-08-18 07:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:38:59 --> Parser Class Initialized
INFO - 2023-08-18 07:38:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:38:59 --> Pagination Class Initialized
INFO - 2023-08-18 07:38:59 --> Form Validation Class Initialized
INFO - 2023-08-18 07:38:59 --> Controller Class Initialized
INFO - 2023-08-18 07:38:59 --> Model Class Initialized
DEBUG - 2023-08-18 07:38:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:38:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:38:59 --> Model Class Initialized
DEBUG - 2023-08-18 07:38:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:38:59 --> Model Class Initialized
INFO - 2023-08-18 07:38:59 --> Final output sent to browser
DEBUG - 2023-08-18 07:38:59 --> Total execution time: 0.0399
ERROR - 2023-08-18 07:39:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:39:07 --> Config Class Initialized
INFO - 2023-08-18 07:39:07 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:39:07 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:39:07 --> Utf8 Class Initialized
INFO - 2023-08-18 07:39:07 --> URI Class Initialized
INFO - 2023-08-18 07:39:07 --> Router Class Initialized
INFO - 2023-08-18 07:39:07 --> Output Class Initialized
INFO - 2023-08-18 07:39:07 --> Security Class Initialized
DEBUG - 2023-08-18 07:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:39:07 --> Input Class Initialized
INFO - 2023-08-18 07:39:07 --> Language Class Initialized
INFO - 2023-08-18 07:39:07 --> Loader Class Initialized
INFO - 2023-08-18 07:39:07 --> Helper loaded: url_helper
INFO - 2023-08-18 07:39:07 --> Helper loaded: file_helper
INFO - 2023-08-18 07:39:07 --> Helper loaded: html_helper
INFO - 2023-08-18 07:39:07 --> Helper loaded: text_helper
INFO - 2023-08-18 07:39:07 --> Helper loaded: form_helper
INFO - 2023-08-18 07:39:07 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:39:07 --> Helper loaded: security_helper
INFO - 2023-08-18 07:39:07 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:39:07 --> Database Driver Class Initialized
INFO - 2023-08-18 07:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:39:07 --> Parser Class Initialized
INFO - 2023-08-18 07:39:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:39:07 --> Pagination Class Initialized
INFO - 2023-08-18 07:39:07 --> Form Validation Class Initialized
INFO - 2023-08-18 07:39:07 --> Controller Class Initialized
INFO - 2023-08-18 07:39:07 --> Model Class Initialized
DEBUG - 2023-08-18 07:39:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:39:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:39:07 --> Model Class Initialized
DEBUG - 2023-08-18 07:39:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:39:07 --> Model Class Initialized
DEBUG - 2023-08-18 07:39:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:39:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-18 07:39:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:39:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 07:39:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 07:39:07 --> Model Class Initialized
INFO - 2023-08-18 07:39:07 --> Model Class Initialized
INFO - 2023-08-18 07:39:07 --> Model Class Initialized
INFO - 2023-08-18 07:39:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 07:39:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 07:39:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 07:39:07 --> Final output sent to browser
DEBUG - 2023-08-18 07:39:07 --> Total execution time: 0.0802
ERROR - 2023-08-18 07:39:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:39:20 --> Config Class Initialized
INFO - 2023-08-18 07:39:20 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:39:20 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:39:20 --> Utf8 Class Initialized
INFO - 2023-08-18 07:39:20 --> URI Class Initialized
DEBUG - 2023-08-18 07:39:20 --> No URI present. Default controller set.
INFO - 2023-08-18 07:39:20 --> Router Class Initialized
INFO - 2023-08-18 07:39:20 --> Output Class Initialized
INFO - 2023-08-18 07:39:20 --> Security Class Initialized
DEBUG - 2023-08-18 07:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:39:20 --> Input Class Initialized
INFO - 2023-08-18 07:39:20 --> Language Class Initialized
INFO - 2023-08-18 07:39:20 --> Loader Class Initialized
INFO - 2023-08-18 07:39:20 --> Helper loaded: url_helper
INFO - 2023-08-18 07:39:20 --> Helper loaded: file_helper
INFO - 2023-08-18 07:39:20 --> Helper loaded: html_helper
INFO - 2023-08-18 07:39:20 --> Helper loaded: text_helper
INFO - 2023-08-18 07:39:20 --> Helper loaded: form_helper
INFO - 2023-08-18 07:39:20 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:39:20 --> Helper loaded: security_helper
INFO - 2023-08-18 07:39:20 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:39:20 --> Database Driver Class Initialized
INFO - 2023-08-18 07:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:39:20 --> Parser Class Initialized
INFO - 2023-08-18 07:39:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:39:20 --> Pagination Class Initialized
INFO - 2023-08-18 07:39:20 --> Form Validation Class Initialized
INFO - 2023-08-18 07:39:20 --> Controller Class Initialized
INFO - 2023-08-18 07:39:20 --> Model Class Initialized
DEBUG - 2023-08-18 07:39:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-18 07:39:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:39:22 --> Config Class Initialized
INFO - 2023-08-18 07:39:22 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:39:22 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:39:22 --> Utf8 Class Initialized
INFO - 2023-08-18 07:39:22 --> URI Class Initialized
INFO - 2023-08-18 07:39:22 --> Router Class Initialized
INFO - 2023-08-18 07:39:22 --> Output Class Initialized
INFO - 2023-08-18 07:39:22 --> Security Class Initialized
DEBUG - 2023-08-18 07:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:39:22 --> Input Class Initialized
INFO - 2023-08-18 07:39:22 --> Language Class Initialized
INFO - 2023-08-18 07:39:22 --> Loader Class Initialized
INFO - 2023-08-18 07:39:22 --> Helper loaded: url_helper
INFO - 2023-08-18 07:39:22 --> Helper loaded: file_helper
INFO - 2023-08-18 07:39:22 --> Helper loaded: html_helper
INFO - 2023-08-18 07:39:22 --> Helper loaded: text_helper
INFO - 2023-08-18 07:39:22 --> Helper loaded: form_helper
INFO - 2023-08-18 07:39:22 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:39:22 --> Helper loaded: security_helper
INFO - 2023-08-18 07:39:22 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:39:22 --> Database Driver Class Initialized
INFO - 2023-08-18 07:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:39:22 --> Parser Class Initialized
INFO - 2023-08-18 07:39:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:39:22 --> Pagination Class Initialized
INFO - 2023-08-18 07:39:22 --> Form Validation Class Initialized
INFO - 2023-08-18 07:39:22 --> Controller Class Initialized
INFO - 2023-08-18 07:39:22 --> Model Class Initialized
DEBUG - 2023-08-18 07:39:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:39:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-18 07:39:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:39:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 07:39:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 07:39:22 --> Model Class Initialized
INFO - 2023-08-18 07:39:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 07:39:22 --> Final output sent to browser
DEBUG - 2023-08-18 07:39:22 --> Total execution time: 0.0304
ERROR - 2023-08-18 07:39:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:39:45 --> Config Class Initialized
INFO - 2023-08-18 07:39:45 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:39:45 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:39:45 --> Utf8 Class Initialized
INFO - 2023-08-18 07:39:45 --> URI Class Initialized
INFO - 2023-08-18 07:39:45 --> Router Class Initialized
INFO - 2023-08-18 07:39:45 --> Output Class Initialized
INFO - 2023-08-18 07:39:45 --> Security Class Initialized
DEBUG - 2023-08-18 07:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:39:45 --> Input Class Initialized
INFO - 2023-08-18 07:39:45 --> Language Class Initialized
INFO - 2023-08-18 07:39:45 --> Loader Class Initialized
INFO - 2023-08-18 07:39:45 --> Helper loaded: url_helper
INFO - 2023-08-18 07:39:45 --> Helper loaded: file_helper
INFO - 2023-08-18 07:39:45 --> Helper loaded: html_helper
INFO - 2023-08-18 07:39:45 --> Helper loaded: text_helper
INFO - 2023-08-18 07:39:45 --> Helper loaded: form_helper
INFO - 2023-08-18 07:39:45 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:39:45 --> Helper loaded: security_helper
INFO - 2023-08-18 07:39:45 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:39:45 --> Database Driver Class Initialized
INFO - 2023-08-18 07:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:39:45 --> Parser Class Initialized
INFO - 2023-08-18 07:39:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:39:45 --> Pagination Class Initialized
INFO - 2023-08-18 07:39:45 --> Form Validation Class Initialized
INFO - 2023-08-18 07:39:45 --> Controller Class Initialized
INFO - 2023-08-18 07:39:45 --> Model Class Initialized
DEBUG - 2023-08-18 07:39:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:39:45 --> Model Class Initialized
INFO - 2023-08-18 07:39:45 --> Final output sent to browser
DEBUG - 2023-08-18 07:39:45 --> Total execution time: 0.0197
ERROR - 2023-08-18 07:39:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:39:45 --> Config Class Initialized
INFO - 2023-08-18 07:39:45 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:39:45 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:39:45 --> Utf8 Class Initialized
INFO - 2023-08-18 07:39:45 --> URI Class Initialized
DEBUG - 2023-08-18 07:39:45 --> No URI present. Default controller set.
INFO - 2023-08-18 07:39:45 --> Router Class Initialized
INFO - 2023-08-18 07:39:45 --> Output Class Initialized
INFO - 2023-08-18 07:39:45 --> Security Class Initialized
DEBUG - 2023-08-18 07:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:39:45 --> Input Class Initialized
INFO - 2023-08-18 07:39:45 --> Language Class Initialized
INFO - 2023-08-18 07:39:45 --> Loader Class Initialized
INFO - 2023-08-18 07:39:45 --> Helper loaded: url_helper
INFO - 2023-08-18 07:39:45 --> Helper loaded: file_helper
INFO - 2023-08-18 07:39:45 --> Helper loaded: html_helper
INFO - 2023-08-18 07:39:45 --> Helper loaded: text_helper
INFO - 2023-08-18 07:39:45 --> Helper loaded: form_helper
INFO - 2023-08-18 07:39:45 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:39:45 --> Helper loaded: security_helper
INFO - 2023-08-18 07:39:45 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:39:45 --> Database Driver Class Initialized
INFO - 2023-08-18 07:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:39:45 --> Parser Class Initialized
INFO - 2023-08-18 07:39:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:39:45 --> Pagination Class Initialized
INFO - 2023-08-18 07:39:45 --> Form Validation Class Initialized
INFO - 2023-08-18 07:39:45 --> Controller Class Initialized
INFO - 2023-08-18 07:39:45 --> Model Class Initialized
DEBUG - 2023-08-18 07:39:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:39:45 --> Model Class Initialized
DEBUG - 2023-08-18 07:39:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:39:45 --> Model Class Initialized
INFO - 2023-08-18 07:39:45 --> Model Class Initialized
INFO - 2023-08-18 07:39:45 --> Model Class Initialized
INFO - 2023-08-18 07:39:45 --> Model Class Initialized
DEBUG - 2023-08-18 07:39:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:39:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:39:45 --> Model Class Initialized
INFO - 2023-08-18 07:39:45 --> Model Class Initialized
INFO - 2023-08-18 07:39:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-18 07:39:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:39:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 07:39:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 07:39:45 --> Model Class Initialized
INFO - 2023-08-18 07:39:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 07:39:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 07:39:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 07:39:45 --> Final output sent to browser
DEBUG - 2023-08-18 07:39:45 --> Total execution time: 0.0793
ERROR - 2023-08-18 07:39:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:39:51 --> Config Class Initialized
INFO - 2023-08-18 07:39:51 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:39:51 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:39:51 --> Utf8 Class Initialized
INFO - 2023-08-18 07:39:51 --> URI Class Initialized
INFO - 2023-08-18 07:39:51 --> Router Class Initialized
INFO - 2023-08-18 07:39:51 --> Output Class Initialized
INFO - 2023-08-18 07:39:51 --> Security Class Initialized
DEBUG - 2023-08-18 07:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:39:51 --> Input Class Initialized
INFO - 2023-08-18 07:39:51 --> Language Class Initialized
INFO - 2023-08-18 07:39:51 --> Loader Class Initialized
INFO - 2023-08-18 07:39:51 --> Helper loaded: url_helper
INFO - 2023-08-18 07:39:51 --> Helper loaded: file_helper
INFO - 2023-08-18 07:39:51 --> Helper loaded: html_helper
INFO - 2023-08-18 07:39:51 --> Helper loaded: text_helper
INFO - 2023-08-18 07:39:51 --> Helper loaded: form_helper
INFO - 2023-08-18 07:39:51 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:39:51 --> Helper loaded: security_helper
INFO - 2023-08-18 07:39:51 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:39:51 --> Database Driver Class Initialized
INFO - 2023-08-18 07:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:39:51 --> Parser Class Initialized
INFO - 2023-08-18 07:39:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:39:51 --> Pagination Class Initialized
INFO - 2023-08-18 07:39:51 --> Form Validation Class Initialized
INFO - 2023-08-18 07:39:51 --> Controller Class Initialized
INFO - 2023-08-18 07:39:51 --> Model Class Initialized
DEBUG - 2023-08-18 07:39:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:39:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-18 07:39:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:39:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 07:39:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 07:39:51 --> Model Class Initialized
INFO - 2023-08-18 07:39:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 07:39:51 --> Final output sent to browser
DEBUG - 2023-08-18 07:39:51 --> Total execution time: 0.0326
ERROR - 2023-08-18 07:40:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:40:01 --> Config Class Initialized
INFO - 2023-08-18 07:40:01 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:40:01 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:40:01 --> Utf8 Class Initialized
INFO - 2023-08-18 07:40:01 --> URI Class Initialized
INFO - 2023-08-18 07:40:01 --> Router Class Initialized
INFO - 2023-08-18 07:40:01 --> Output Class Initialized
INFO - 2023-08-18 07:40:01 --> Security Class Initialized
DEBUG - 2023-08-18 07:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:40:01 --> Input Class Initialized
INFO - 2023-08-18 07:40:01 --> Language Class Initialized
INFO - 2023-08-18 07:40:01 --> Loader Class Initialized
INFO - 2023-08-18 07:40:01 --> Helper loaded: url_helper
INFO - 2023-08-18 07:40:01 --> Helper loaded: file_helper
INFO - 2023-08-18 07:40:01 --> Helper loaded: html_helper
INFO - 2023-08-18 07:40:01 --> Helper loaded: text_helper
INFO - 2023-08-18 07:40:01 --> Helper loaded: form_helper
INFO - 2023-08-18 07:40:01 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:40:01 --> Helper loaded: security_helper
INFO - 2023-08-18 07:40:01 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:40:01 --> Database Driver Class Initialized
INFO - 2023-08-18 07:40:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:40:01 --> Parser Class Initialized
INFO - 2023-08-18 07:40:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:40:01 --> Pagination Class Initialized
INFO - 2023-08-18 07:40:01 --> Form Validation Class Initialized
INFO - 2023-08-18 07:40:01 --> Controller Class Initialized
INFO - 2023-08-18 07:40:01 --> Model Class Initialized
DEBUG - 2023-08-18 07:40:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:40:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:40:01 --> Model Class Initialized
DEBUG - 2023-08-18 07:40:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:40:01 --> Model Class Initialized
INFO - 2023-08-18 07:40:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-18 07:40:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:40:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 07:40:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 07:40:01 --> Model Class Initialized
INFO - 2023-08-18 07:40:01 --> Model Class Initialized
INFO - 2023-08-18 07:40:01 --> Model Class Initialized
INFO - 2023-08-18 07:40:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 07:40:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 07:40:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 07:40:01 --> Final output sent to browser
DEBUG - 2023-08-18 07:40:01 --> Total execution time: 0.0911
ERROR - 2023-08-18 07:40:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:40:02 --> Config Class Initialized
INFO - 2023-08-18 07:40:02 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:40:02 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:40:02 --> Utf8 Class Initialized
INFO - 2023-08-18 07:40:02 --> URI Class Initialized
INFO - 2023-08-18 07:40:02 --> Router Class Initialized
INFO - 2023-08-18 07:40:02 --> Output Class Initialized
INFO - 2023-08-18 07:40:02 --> Security Class Initialized
DEBUG - 2023-08-18 07:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:40:02 --> Input Class Initialized
INFO - 2023-08-18 07:40:02 --> Language Class Initialized
INFO - 2023-08-18 07:40:02 --> Loader Class Initialized
INFO - 2023-08-18 07:40:02 --> Helper loaded: url_helper
INFO - 2023-08-18 07:40:02 --> Helper loaded: file_helper
INFO - 2023-08-18 07:40:02 --> Helper loaded: html_helper
INFO - 2023-08-18 07:40:02 --> Helper loaded: text_helper
INFO - 2023-08-18 07:40:02 --> Helper loaded: form_helper
INFO - 2023-08-18 07:40:02 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:40:02 --> Helper loaded: security_helper
INFO - 2023-08-18 07:40:02 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:40:02 --> Database Driver Class Initialized
INFO - 2023-08-18 07:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:40:02 --> Parser Class Initialized
INFO - 2023-08-18 07:40:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:40:02 --> Pagination Class Initialized
INFO - 2023-08-18 07:40:02 --> Form Validation Class Initialized
INFO - 2023-08-18 07:40:02 --> Controller Class Initialized
INFO - 2023-08-18 07:40:02 --> Model Class Initialized
DEBUG - 2023-08-18 07:40:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:40:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:40:02 --> Model Class Initialized
DEBUG - 2023-08-18 07:40:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:40:02 --> Model Class Initialized
INFO - 2023-08-18 07:40:02 --> Final output sent to browser
DEBUG - 2023-08-18 07:40:02 --> Total execution time: 0.0354
ERROR - 2023-08-18 07:40:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:40:13 --> Config Class Initialized
INFO - 2023-08-18 07:40:13 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:40:13 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:40:13 --> Utf8 Class Initialized
INFO - 2023-08-18 07:40:13 --> URI Class Initialized
INFO - 2023-08-18 07:40:13 --> Router Class Initialized
INFO - 2023-08-18 07:40:13 --> Output Class Initialized
INFO - 2023-08-18 07:40:13 --> Security Class Initialized
DEBUG - 2023-08-18 07:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:40:13 --> Input Class Initialized
INFO - 2023-08-18 07:40:13 --> Language Class Initialized
INFO - 2023-08-18 07:40:13 --> Loader Class Initialized
INFO - 2023-08-18 07:40:13 --> Helper loaded: url_helper
INFO - 2023-08-18 07:40:13 --> Helper loaded: file_helper
INFO - 2023-08-18 07:40:13 --> Helper loaded: html_helper
INFO - 2023-08-18 07:40:13 --> Helper loaded: text_helper
INFO - 2023-08-18 07:40:13 --> Helper loaded: form_helper
INFO - 2023-08-18 07:40:13 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:40:13 --> Helper loaded: security_helper
INFO - 2023-08-18 07:40:13 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:40:13 --> Database Driver Class Initialized
INFO - 2023-08-18 07:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:40:13 --> Parser Class Initialized
INFO - 2023-08-18 07:40:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:40:13 --> Pagination Class Initialized
INFO - 2023-08-18 07:40:13 --> Form Validation Class Initialized
INFO - 2023-08-18 07:40:13 --> Controller Class Initialized
INFO - 2023-08-18 07:40:13 --> Model Class Initialized
DEBUG - 2023-08-18 07:40:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:40:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:40:13 --> Model Class Initialized
DEBUG - 2023-08-18 07:40:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:40:13 --> Model Class Initialized
DEBUG - 2023-08-18 07:40:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:40:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-18 07:40:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:40:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 07:40:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 07:40:13 --> Model Class Initialized
INFO - 2023-08-18 07:40:13 --> Model Class Initialized
INFO - 2023-08-18 07:40:13 --> Model Class Initialized
INFO - 2023-08-18 07:40:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 07:40:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 07:40:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 07:40:13 --> Final output sent to browser
DEBUG - 2023-08-18 07:40:13 --> Total execution time: 0.0808
ERROR - 2023-08-18 07:40:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:40:36 --> Config Class Initialized
INFO - 2023-08-18 07:40:36 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:40:36 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:40:36 --> Utf8 Class Initialized
INFO - 2023-08-18 07:40:36 --> URI Class Initialized
INFO - 2023-08-18 07:40:36 --> Router Class Initialized
INFO - 2023-08-18 07:40:36 --> Output Class Initialized
INFO - 2023-08-18 07:40:36 --> Security Class Initialized
DEBUG - 2023-08-18 07:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:40:36 --> Input Class Initialized
INFO - 2023-08-18 07:40:36 --> Language Class Initialized
INFO - 2023-08-18 07:40:36 --> Loader Class Initialized
INFO - 2023-08-18 07:40:36 --> Helper loaded: url_helper
INFO - 2023-08-18 07:40:36 --> Helper loaded: file_helper
INFO - 2023-08-18 07:40:36 --> Helper loaded: html_helper
INFO - 2023-08-18 07:40:36 --> Helper loaded: text_helper
INFO - 2023-08-18 07:40:36 --> Helper loaded: form_helper
INFO - 2023-08-18 07:40:36 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:40:36 --> Helper loaded: security_helper
INFO - 2023-08-18 07:40:36 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:40:36 --> Database Driver Class Initialized
INFO - 2023-08-18 07:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:40:36 --> Parser Class Initialized
INFO - 2023-08-18 07:40:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:40:36 --> Pagination Class Initialized
INFO - 2023-08-18 07:40:36 --> Form Validation Class Initialized
INFO - 2023-08-18 07:40:36 --> Controller Class Initialized
INFO - 2023-08-18 07:40:36 --> Model Class Initialized
DEBUG - 2023-08-18 07:40:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:40:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:40:36 --> Model Class Initialized
DEBUG - 2023-08-18 07:40:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:40:36 --> Model Class Initialized
INFO - 2023-08-18 07:40:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-18 07:40:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:40:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 07:40:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 07:40:36 --> Model Class Initialized
INFO - 2023-08-18 07:40:36 --> Model Class Initialized
INFO - 2023-08-18 07:40:36 --> Model Class Initialized
INFO - 2023-08-18 07:40:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 07:40:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 07:40:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 07:40:36 --> Final output sent to browser
DEBUG - 2023-08-18 07:40:36 --> Total execution time: 0.0723
ERROR - 2023-08-18 07:40:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:40:37 --> Config Class Initialized
INFO - 2023-08-18 07:40:37 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:40:37 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:40:37 --> Utf8 Class Initialized
INFO - 2023-08-18 07:40:37 --> URI Class Initialized
INFO - 2023-08-18 07:40:37 --> Router Class Initialized
INFO - 2023-08-18 07:40:37 --> Output Class Initialized
INFO - 2023-08-18 07:40:37 --> Security Class Initialized
DEBUG - 2023-08-18 07:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:40:37 --> Input Class Initialized
INFO - 2023-08-18 07:40:37 --> Language Class Initialized
INFO - 2023-08-18 07:40:37 --> Loader Class Initialized
INFO - 2023-08-18 07:40:37 --> Helper loaded: url_helper
INFO - 2023-08-18 07:40:37 --> Helper loaded: file_helper
INFO - 2023-08-18 07:40:37 --> Helper loaded: html_helper
INFO - 2023-08-18 07:40:37 --> Helper loaded: text_helper
INFO - 2023-08-18 07:40:37 --> Helper loaded: form_helper
INFO - 2023-08-18 07:40:37 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:40:37 --> Helper loaded: security_helper
INFO - 2023-08-18 07:40:37 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:40:37 --> Database Driver Class Initialized
INFO - 2023-08-18 07:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:40:37 --> Parser Class Initialized
INFO - 2023-08-18 07:40:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:40:37 --> Pagination Class Initialized
INFO - 2023-08-18 07:40:37 --> Form Validation Class Initialized
INFO - 2023-08-18 07:40:37 --> Controller Class Initialized
INFO - 2023-08-18 07:40:37 --> Model Class Initialized
DEBUG - 2023-08-18 07:40:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:40:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:40:37 --> Model Class Initialized
DEBUG - 2023-08-18 07:40:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:40:37 --> Model Class Initialized
INFO - 2023-08-18 07:40:37 --> Final output sent to browser
DEBUG - 2023-08-18 07:40:37 --> Total execution time: 0.0275
ERROR - 2023-08-18 07:40:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:40:40 --> Config Class Initialized
INFO - 2023-08-18 07:40:40 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:40:40 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:40:40 --> Utf8 Class Initialized
INFO - 2023-08-18 07:40:40 --> URI Class Initialized
INFO - 2023-08-18 07:40:40 --> Router Class Initialized
INFO - 2023-08-18 07:40:40 --> Output Class Initialized
INFO - 2023-08-18 07:40:40 --> Security Class Initialized
DEBUG - 2023-08-18 07:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:40:40 --> Input Class Initialized
INFO - 2023-08-18 07:40:40 --> Language Class Initialized
INFO - 2023-08-18 07:40:40 --> Loader Class Initialized
INFO - 2023-08-18 07:40:40 --> Helper loaded: url_helper
INFO - 2023-08-18 07:40:40 --> Helper loaded: file_helper
INFO - 2023-08-18 07:40:40 --> Helper loaded: html_helper
INFO - 2023-08-18 07:40:40 --> Helper loaded: text_helper
INFO - 2023-08-18 07:40:40 --> Helper loaded: form_helper
INFO - 2023-08-18 07:40:40 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:40:40 --> Helper loaded: security_helper
INFO - 2023-08-18 07:40:40 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:40:40 --> Database Driver Class Initialized
INFO - 2023-08-18 07:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:40:40 --> Parser Class Initialized
INFO - 2023-08-18 07:40:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:40:40 --> Pagination Class Initialized
INFO - 2023-08-18 07:40:40 --> Form Validation Class Initialized
INFO - 2023-08-18 07:40:40 --> Controller Class Initialized
INFO - 2023-08-18 07:40:40 --> Model Class Initialized
DEBUG - 2023-08-18 07:40:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:40:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:40:40 --> Model Class Initialized
DEBUG - 2023-08-18 07:40:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:40:40 --> Model Class Initialized
DEBUG - 2023-08-18 07:40:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:40:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-18 07:40:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:40:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 07:40:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 07:40:40 --> Model Class Initialized
INFO - 2023-08-18 07:40:40 --> Model Class Initialized
INFO - 2023-08-18 07:40:40 --> Model Class Initialized
INFO - 2023-08-18 07:40:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 07:40:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 07:40:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 07:40:40 --> Final output sent to browser
DEBUG - 2023-08-18 07:40:40 --> Total execution time: 0.0711
ERROR - 2023-08-18 07:40:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:40:52 --> Config Class Initialized
INFO - 2023-08-18 07:40:52 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:40:52 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:40:52 --> Utf8 Class Initialized
INFO - 2023-08-18 07:40:52 --> URI Class Initialized
INFO - 2023-08-18 07:40:52 --> Router Class Initialized
INFO - 2023-08-18 07:40:52 --> Output Class Initialized
INFO - 2023-08-18 07:40:52 --> Security Class Initialized
DEBUG - 2023-08-18 07:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:40:52 --> Input Class Initialized
INFO - 2023-08-18 07:40:52 --> Language Class Initialized
INFO - 2023-08-18 07:40:52 --> Loader Class Initialized
INFO - 2023-08-18 07:40:52 --> Helper loaded: url_helper
INFO - 2023-08-18 07:40:52 --> Helper loaded: file_helper
INFO - 2023-08-18 07:40:52 --> Helper loaded: html_helper
INFO - 2023-08-18 07:40:52 --> Helper loaded: text_helper
INFO - 2023-08-18 07:40:52 --> Helper loaded: form_helper
INFO - 2023-08-18 07:40:52 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:40:52 --> Helper loaded: security_helper
INFO - 2023-08-18 07:40:52 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:40:52 --> Database Driver Class Initialized
INFO - 2023-08-18 07:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:40:52 --> Parser Class Initialized
INFO - 2023-08-18 07:40:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:40:52 --> Pagination Class Initialized
INFO - 2023-08-18 07:40:52 --> Form Validation Class Initialized
INFO - 2023-08-18 07:40:52 --> Controller Class Initialized
INFO - 2023-08-18 07:40:52 --> Model Class Initialized
DEBUG - 2023-08-18 07:40:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:40:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:40:52 --> Model Class Initialized
DEBUG - 2023-08-18 07:40:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:40:52 --> Model Class Initialized
INFO - 2023-08-18 07:40:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-18 07:40:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:40:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 07:40:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 07:40:52 --> Model Class Initialized
INFO - 2023-08-18 07:40:52 --> Model Class Initialized
INFO - 2023-08-18 07:40:52 --> Model Class Initialized
INFO - 2023-08-18 07:40:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 07:40:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 07:40:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 07:40:52 --> Final output sent to browser
DEBUG - 2023-08-18 07:40:52 --> Total execution time: 0.0874
ERROR - 2023-08-18 07:40:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:40:52 --> Config Class Initialized
INFO - 2023-08-18 07:40:52 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:40:52 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:40:52 --> Utf8 Class Initialized
INFO - 2023-08-18 07:40:52 --> URI Class Initialized
INFO - 2023-08-18 07:40:52 --> Router Class Initialized
INFO - 2023-08-18 07:40:52 --> Output Class Initialized
INFO - 2023-08-18 07:40:52 --> Security Class Initialized
DEBUG - 2023-08-18 07:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:40:52 --> Input Class Initialized
INFO - 2023-08-18 07:40:52 --> Language Class Initialized
INFO - 2023-08-18 07:40:52 --> Loader Class Initialized
INFO - 2023-08-18 07:40:52 --> Helper loaded: url_helper
INFO - 2023-08-18 07:40:52 --> Helper loaded: file_helper
INFO - 2023-08-18 07:40:52 --> Helper loaded: html_helper
INFO - 2023-08-18 07:40:52 --> Helper loaded: text_helper
INFO - 2023-08-18 07:40:52 --> Helper loaded: form_helper
INFO - 2023-08-18 07:40:52 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:40:52 --> Helper loaded: security_helper
INFO - 2023-08-18 07:40:52 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:40:52 --> Database Driver Class Initialized
INFO - 2023-08-18 07:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:40:52 --> Parser Class Initialized
INFO - 2023-08-18 07:40:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:40:52 --> Pagination Class Initialized
INFO - 2023-08-18 07:40:52 --> Form Validation Class Initialized
INFO - 2023-08-18 07:40:52 --> Controller Class Initialized
INFO - 2023-08-18 07:40:52 --> Model Class Initialized
DEBUG - 2023-08-18 07:40:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:40:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:40:52 --> Model Class Initialized
DEBUG - 2023-08-18 07:40:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:40:52 --> Model Class Initialized
INFO - 2023-08-18 07:40:52 --> Final output sent to browser
DEBUG - 2023-08-18 07:40:52 --> Total execution time: 0.0316
ERROR - 2023-08-18 07:40:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 07:40:55 --> Config Class Initialized
INFO - 2023-08-18 07:40:55 --> Hooks Class Initialized
DEBUG - 2023-08-18 07:40:55 --> UTF-8 Support Enabled
INFO - 2023-08-18 07:40:55 --> Utf8 Class Initialized
INFO - 2023-08-18 07:40:55 --> URI Class Initialized
INFO - 2023-08-18 07:40:55 --> Router Class Initialized
INFO - 2023-08-18 07:40:55 --> Output Class Initialized
INFO - 2023-08-18 07:40:55 --> Security Class Initialized
DEBUG - 2023-08-18 07:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 07:40:55 --> Input Class Initialized
INFO - 2023-08-18 07:40:55 --> Language Class Initialized
INFO - 2023-08-18 07:40:55 --> Loader Class Initialized
INFO - 2023-08-18 07:40:55 --> Helper loaded: url_helper
INFO - 2023-08-18 07:40:55 --> Helper loaded: file_helper
INFO - 2023-08-18 07:40:55 --> Helper loaded: html_helper
INFO - 2023-08-18 07:40:55 --> Helper loaded: text_helper
INFO - 2023-08-18 07:40:55 --> Helper loaded: form_helper
INFO - 2023-08-18 07:40:55 --> Helper loaded: lang_helper
INFO - 2023-08-18 07:40:55 --> Helper loaded: security_helper
INFO - 2023-08-18 07:40:55 --> Helper loaded: cookie_helper
INFO - 2023-08-18 07:40:55 --> Database Driver Class Initialized
INFO - 2023-08-18 07:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 07:40:55 --> Parser Class Initialized
INFO - 2023-08-18 07:40:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 07:40:55 --> Pagination Class Initialized
INFO - 2023-08-18 07:40:55 --> Form Validation Class Initialized
INFO - 2023-08-18 07:40:55 --> Controller Class Initialized
INFO - 2023-08-18 07:40:55 --> Model Class Initialized
DEBUG - 2023-08-18 07:40:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 07:40:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:40:55 --> Model Class Initialized
DEBUG - 2023-08-18 07:40:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:40:55 --> Model Class Initialized
DEBUG - 2023-08-18 07:40:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:40:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-18 07:40:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 07:40:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 07:40:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 07:40:55 --> Model Class Initialized
INFO - 2023-08-18 07:40:55 --> Model Class Initialized
INFO - 2023-08-18 07:40:55 --> Model Class Initialized
INFO - 2023-08-18 07:40:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 07:40:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 07:40:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 07:40:55 --> Final output sent to browser
DEBUG - 2023-08-18 07:40:55 --> Total execution time: 0.0699
ERROR - 2023-08-18 08:01:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 08:01:12 --> Config Class Initialized
INFO - 2023-08-18 08:01:12 --> Hooks Class Initialized
DEBUG - 2023-08-18 08:01:12 --> UTF-8 Support Enabled
INFO - 2023-08-18 08:01:12 --> Utf8 Class Initialized
INFO - 2023-08-18 08:01:12 --> URI Class Initialized
DEBUG - 2023-08-18 08:01:12 --> No URI present. Default controller set.
INFO - 2023-08-18 08:01:12 --> Router Class Initialized
INFO - 2023-08-18 08:01:12 --> Output Class Initialized
INFO - 2023-08-18 08:01:12 --> Security Class Initialized
DEBUG - 2023-08-18 08:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 08:01:12 --> Input Class Initialized
INFO - 2023-08-18 08:01:12 --> Language Class Initialized
INFO - 2023-08-18 08:01:12 --> Loader Class Initialized
INFO - 2023-08-18 08:01:12 --> Helper loaded: url_helper
INFO - 2023-08-18 08:01:12 --> Helper loaded: file_helper
INFO - 2023-08-18 08:01:12 --> Helper loaded: html_helper
INFO - 2023-08-18 08:01:12 --> Helper loaded: text_helper
INFO - 2023-08-18 08:01:12 --> Helper loaded: form_helper
INFO - 2023-08-18 08:01:12 --> Helper loaded: lang_helper
INFO - 2023-08-18 08:01:12 --> Helper loaded: security_helper
INFO - 2023-08-18 08:01:12 --> Helper loaded: cookie_helper
INFO - 2023-08-18 08:01:12 --> Database Driver Class Initialized
INFO - 2023-08-18 08:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 08:01:12 --> Parser Class Initialized
INFO - 2023-08-18 08:01:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 08:01:12 --> Pagination Class Initialized
INFO - 2023-08-18 08:01:12 --> Form Validation Class Initialized
INFO - 2023-08-18 08:01:12 --> Controller Class Initialized
INFO - 2023-08-18 08:01:12 --> Model Class Initialized
DEBUG - 2023-08-18 08:01:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-18 08:01:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 08:01:12 --> Config Class Initialized
INFO - 2023-08-18 08:01:12 --> Hooks Class Initialized
DEBUG - 2023-08-18 08:01:12 --> UTF-8 Support Enabled
INFO - 2023-08-18 08:01:12 --> Utf8 Class Initialized
INFO - 2023-08-18 08:01:12 --> URI Class Initialized
INFO - 2023-08-18 08:01:12 --> Router Class Initialized
INFO - 2023-08-18 08:01:12 --> Output Class Initialized
INFO - 2023-08-18 08:01:12 --> Security Class Initialized
DEBUG - 2023-08-18 08:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 08:01:12 --> Input Class Initialized
INFO - 2023-08-18 08:01:12 --> Language Class Initialized
INFO - 2023-08-18 08:01:12 --> Loader Class Initialized
INFO - 2023-08-18 08:01:12 --> Helper loaded: url_helper
INFO - 2023-08-18 08:01:12 --> Helper loaded: file_helper
INFO - 2023-08-18 08:01:12 --> Helper loaded: html_helper
INFO - 2023-08-18 08:01:12 --> Helper loaded: text_helper
INFO - 2023-08-18 08:01:12 --> Helper loaded: form_helper
INFO - 2023-08-18 08:01:12 --> Helper loaded: lang_helper
INFO - 2023-08-18 08:01:12 --> Helper loaded: security_helper
INFO - 2023-08-18 08:01:12 --> Helper loaded: cookie_helper
INFO - 2023-08-18 08:01:12 --> Database Driver Class Initialized
INFO - 2023-08-18 08:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 08:01:12 --> Parser Class Initialized
INFO - 2023-08-18 08:01:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 08:01:12 --> Pagination Class Initialized
INFO - 2023-08-18 08:01:12 --> Form Validation Class Initialized
INFO - 2023-08-18 08:01:12 --> Controller Class Initialized
INFO - 2023-08-18 08:01:12 --> Model Class Initialized
DEBUG - 2023-08-18 08:01:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 08:01:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-18 08:01:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 08:01:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 08:01:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 08:01:12 --> Model Class Initialized
INFO - 2023-08-18 08:01:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 08:01:12 --> Final output sent to browser
DEBUG - 2023-08-18 08:01:12 --> Total execution time: 0.0324
ERROR - 2023-08-18 08:21:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 08:21:58 --> Config Class Initialized
INFO - 2023-08-18 08:21:58 --> Hooks Class Initialized
DEBUG - 2023-08-18 08:21:58 --> UTF-8 Support Enabled
INFO - 2023-08-18 08:21:58 --> Utf8 Class Initialized
INFO - 2023-08-18 08:21:58 --> URI Class Initialized
DEBUG - 2023-08-18 08:21:58 --> No URI present. Default controller set.
INFO - 2023-08-18 08:21:58 --> Router Class Initialized
INFO - 2023-08-18 08:21:58 --> Output Class Initialized
INFO - 2023-08-18 08:21:58 --> Security Class Initialized
DEBUG - 2023-08-18 08:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 08:21:58 --> Input Class Initialized
INFO - 2023-08-18 08:21:58 --> Language Class Initialized
INFO - 2023-08-18 08:21:58 --> Loader Class Initialized
INFO - 2023-08-18 08:21:58 --> Helper loaded: url_helper
INFO - 2023-08-18 08:21:58 --> Helper loaded: file_helper
INFO - 2023-08-18 08:21:58 --> Helper loaded: html_helper
INFO - 2023-08-18 08:21:58 --> Helper loaded: text_helper
INFO - 2023-08-18 08:21:58 --> Helper loaded: form_helper
INFO - 2023-08-18 08:21:58 --> Helper loaded: lang_helper
INFO - 2023-08-18 08:21:58 --> Helper loaded: security_helper
INFO - 2023-08-18 08:21:58 --> Helper loaded: cookie_helper
INFO - 2023-08-18 08:21:58 --> Database Driver Class Initialized
INFO - 2023-08-18 08:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 08:21:58 --> Parser Class Initialized
INFO - 2023-08-18 08:21:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 08:21:58 --> Pagination Class Initialized
INFO - 2023-08-18 08:21:58 --> Form Validation Class Initialized
INFO - 2023-08-18 08:21:58 --> Controller Class Initialized
INFO - 2023-08-18 08:21:58 --> Model Class Initialized
DEBUG - 2023-08-18 08:21:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-18 08:21:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 08:21:58 --> Config Class Initialized
INFO - 2023-08-18 08:21:58 --> Hooks Class Initialized
DEBUG - 2023-08-18 08:21:58 --> UTF-8 Support Enabled
INFO - 2023-08-18 08:21:58 --> Utf8 Class Initialized
INFO - 2023-08-18 08:21:58 --> URI Class Initialized
INFO - 2023-08-18 08:21:58 --> Router Class Initialized
INFO - 2023-08-18 08:21:58 --> Output Class Initialized
INFO - 2023-08-18 08:21:58 --> Security Class Initialized
DEBUG - 2023-08-18 08:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 08:21:58 --> Input Class Initialized
INFO - 2023-08-18 08:21:58 --> Language Class Initialized
INFO - 2023-08-18 08:21:58 --> Loader Class Initialized
INFO - 2023-08-18 08:21:58 --> Helper loaded: url_helper
INFO - 2023-08-18 08:21:58 --> Helper loaded: file_helper
INFO - 2023-08-18 08:21:58 --> Helper loaded: html_helper
INFO - 2023-08-18 08:21:58 --> Helper loaded: text_helper
INFO - 2023-08-18 08:21:58 --> Helper loaded: form_helper
INFO - 2023-08-18 08:21:58 --> Helper loaded: lang_helper
INFO - 2023-08-18 08:21:58 --> Helper loaded: security_helper
INFO - 2023-08-18 08:21:58 --> Helper loaded: cookie_helper
INFO - 2023-08-18 08:21:58 --> Database Driver Class Initialized
INFO - 2023-08-18 08:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 08:21:58 --> Parser Class Initialized
INFO - 2023-08-18 08:21:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 08:21:58 --> Pagination Class Initialized
INFO - 2023-08-18 08:21:58 --> Form Validation Class Initialized
INFO - 2023-08-18 08:21:58 --> Controller Class Initialized
INFO - 2023-08-18 08:21:58 --> Model Class Initialized
DEBUG - 2023-08-18 08:21:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 08:21:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-18 08:21:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 08:21:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 08:21:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 08:21:58 --> Model Class Initialized
INFO - 2023-08-18 08:21:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 08:21:58 --> Final output sent to browser
DEBUG - 2023-08-18 08:21:58 --> Total execution time: 0.0297
ERROR - 2023-08-18 08:22:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 08:22:08 --> Config Class Initialized
INFO - 2023-08-18 08:22:08 --> Hooks Class Initialized
DEBUG - 2023-08-18 08:22:08 --> UTF-8 Support Enabled
INFO - 2023-08-18 08:22:08 --> Utf8 Class Initialized
INFO - 2023-08-18 08:22:08 --> URI Class Initialized
INFO - 2023-08-18 08:22:08 --> Router Class Initialized
INFO - 2023-08-18 08:22:08 --> Output Class Initialized
INFO - 2023-08-18 08:22:08 --> Security Class Initialized
DEBUG - 2023-08-18 08:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 08:22:08 --> Input Class Initialized
INFO - 2023-08-18 08:22:08 --> Language Class Initialized
INFO - 2023-08-18 08:22:08 --> Loader Class Initialized
INFO - 2023-08-18 08:22:08 --> Helper loaded: url_helper
INFO - 2023-08-18 08:22:08 --> Helper loaded: file_helper
INFO - 2023-08-18 08:22:08 --> Helper loaded: html_helper
INFO - 2023-08-18 08:22:08 --> Helper loaded: text_helper
INFO - 2023-08-18 08:22:08 --> Helper loaded: form_helper
INFO - 2023-08-18 08:22:08 --> Helper loaded: lang_helper
INFO - 2023-08-18 08:22:08 --> Helper loaded: security_helper
INFO - 2023-08-18 08:22:08 --> Helper loaded: cookie_helper
INFO - 2023-08-18 08:22:08 --> Database Driver Class Initialized
INFO - 2023-08-18 08:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 08:22:08 --> Parser Class Initialized
INFO - 2023-08-18 08:22:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 08:22:08 --> Pagination Class Initialized
INFO - 2023-08-18 08:22:08 --> Form Validation Class Initialized
INFO - 2023-08-18 08:22:08 --> Controller Class Initialized
INFO - 2023-08-18 08:22:08 --> Model Class Initialized
DEBUG - 2023-08-18 08:22:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 08:22:08 --> Model Class Initialized
INFO - 2023-08-18 08:22:08 --> Final output sent to browser
DEBUG - 2023-08-18 08:22:08 --> Total execution time: 0.0172
ERROR - 2023-08-18 08:22:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 08:22:08 --> Config Class Initialized
INFO - 2023-08-18 08:22:08 --> Hooks Class Initialized
DEBUG - 2023-08-18 08:22:08 --> UTF-8 Support Enabled
INFO - 2023-08-18 08:22:08 --> Utf8 Class Initialized
INFO - 2023-08-18 08:22:08 --> URI Class Initialized
DEBUG - 2023-08-18 08:22:08 --> No URI present. Default controller set.
INFO - 2023-08-18 08:22:08 --> Router Class Initialized
INFO - 2023-08-18 08:22:08 --> Output Class Initialized
INFO - 2023-08-18 08:22:08 --> Security Class Initialized
DEBUG - 2023-08-18 08:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 08:22:08 --> Input Class Initialized
INFO - 2023-08-18 08:22:08 --> Language Class Initialized
INFO - 2023-08-18 08:22:08 --> Loader Class Initialized
INFO - 2023-08-18 08:22:08 --> Helper loaded: url_helper
INFO - 2023-08-18 08:22:08 --> Helper loaded: file_helper
INFO - 2023-08-18 08:22:08 --> Helper loaded: html_helper
INFO - 2023-08-18 08:22:08 --> Helper loaded: text_helper
INFO - 2023-08-18 08:22:08 --> Helper loaded: form_helper
INFO - 2023-08-18 08:22:08 --> Helper loaded: lang_helper
INFO - 2023-08-18 08:22:08 --> Helper loaded: security_helper
INFO - 2023-08-18 08:22:08 --> Helper loaded: cookie_helper
INFO - 2023-08-18 08:22:08 --> Database Driver Class Initialized
INFO - 2023-08-18 08:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 08:22:08 --> Parser Class Initialized
INFO - 2023-08-18 08:22:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 08:22:08 --> Pagination Class Initialized
INFO - 2023-08-18 08:22:08 --> Form Validation Class Initialized
INFO - 2023-08-18 08:22:08 --> Controller Class Initialized
INFO - 2023-08-18 08:22:08 --> Model Class Initialized
DEBUG - 2023-08-18 08:22:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 08:22:08 --> Model Class Initialized
DEBUG - 2023-08-18 08:22:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 08:22:08 --> Model Class Initialized
INFO - 2023-08-18 08:22:08 --> Model Class Initialized
INFO - 2023-08-18 08:22:08 --> Model Class Initialized
INFO - 2023-08-18 08:22:08 --> Model Class Initialized
DEBUG - 2023-08-18 08:22:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 08:22:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 08:22:08 --> Model Class Initialized
INFO - 2023-08-18 08:22:08 --> Model Class Initialized
INFO - 2023-08-18 08:22:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-18 08:22:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 08:22:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 08:22:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 08:22:08 --> Model Class Initialized
INFO - 2023-08-18 08:22:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 08:22:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 08:22:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 08:22:08 --> Final output sent to browser
DEBUG - 2023-08-18 08:22:08 --> Total execution time: 0.0803
ERROR - 2023-08-18 08:22:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 08:22:23 --> Config Class Initialized
INFO - 2023-08-18 08:22:23 --> Hooks Class Initialized
DEBUG - 2023-08-18 08:22:23 --> UTF-8 Support Enabled
INFO - 2023-08-18 08:22:23 --> Utf8 Class Initialized
INFO - 2023-08-18 08:22:23 --> URI Class Initialized
INFO - 2023-08-18 08:22:23 --> Router Class Initialized
INFO - 2023-08-18 08:22:23 --> Output Class Initialized
INFO - 2023-08-18 08:22:23 --> Security Class Initialized
DEBUG - 2023-08-18 08:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 08:22:23 --> Input Class Initialized
INFO - 2023-08-18 08:22:23 --> Language Class Initialized
INFO - 2023-08-18 08:22:23 --> Loader Class Initialized
INFO - 2023-08-18 08:22:23 --> Helper loaded: url_helper
INFO - 2023-08-18 08:22:23 --> Helper loaded: file_helper
INFO - 2023-08-18 08:22:23 --> Helper loaded: html_helper
INFO - 2023-08-18 08:22:23 --> Helper loaded: text_helper
INFO - 2023-08-18 08:22:23 --> Helper loaded: form_helper
INFO - 2023-08-18 08:22:23 --> Helper loaded: lang_helper
INFO - 2023-08-18 08:22:23 --> Helper loaded: security_helper
INFO - 2023-08-18 08:22:23 --> Helper loaded: cookie_helper
INFO - 2023-08-18 08:22:23 --> Database Driver Class Initialized
INFO - 2023-08-18 08:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 08:22:23 --> Parser Class Initialized
INFO - 2023-08-18 08:22:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 08:22:23 --> Pagination Class Initialized
INFO - 2023-08-18 08:22:23 --> Form Validation Class Initialized
INFO - 2023-08-18 08:22:23 --> Controller Class Initialized
INFO - 2023-08-18 08:22:23 --> Model Class Initialized
DEBUG - 2023-08-18 08:22:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 08:22:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 08:22:23 --> Model Class Initialized
DEBUG - 2023-08-18 08:22:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 08:22:23 --> Model Class Initialized
INFO - 2023-08-18 08:22:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-18 08:22:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 08:22:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 08:22:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 08:22:24 --> Model Class Initialized
INFO - 2023-08-18 08:22:24 --> Model Class Initialized
INFO - 2023-08-18 08:22:24 --> Model Class Initialized
INFO - 2023-08-18 08:22:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 08:22:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 08:22:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 08:22:24 --> Final output sent to browser
DEBUG - 2023-08-18 08:22:24 --> Total execution time: 0.0690
ERROR - 2023-08-18 08:22:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 08:22:24 --> Config Class Initialized
INFO - 2023-08-18 08:22:24 --> Hooks Class Initialized
DEBUG - 2023-08-18 08:22:24 --> UTF-8 Support Enabled
INFO - 2023-08-18 08:22:24 --> Utf8 Class Initialized
INFO - 2023-08-18 08:22:24 --> URI Class Initialized
INFO - 2023-08-18 08:22:24 --> Router Class Initialized
INFO - 2023-08-18 08:22:24 --> Output Class Initialized
INFO - 2023-08-18 08:22:24 --> Security Class Initialized
DEBUG - 2023-08-18 08:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 08:22:24 --> Input Class Initialized
INFO - 2023-08-18 08:22:24 --> Language Class Initialized
INFO - 2023-08-18 08:22:24 --> Loader Class Initialized
INFO - 2023-08-18 08:22:24 --> Helper loaded: url_helper
INFO - 2023-08-18 08:22:24 --> Helper loaded: file_helper
INFO - 2023-08-18 08:22:24 --> Helper loaded: html_helper
INFO - 2023-08-18 08:22:24 --> Helper loaded: text_helper
INFO - 2023-08-18 08:22:24 --> Helper loaded: form_helper
INFO - 2023-08-18 08:22:24 --> Helper loaded: lang_helper
INFO - 2023-08-18 08:22:24 --> Helper loaded: security_helper
INFO - 2023-08-18 08:22:24 --> Helper loaded: cookie_helper
INFO - 2023-08-18 08:22:24 --> Database Driver Class Initialized
INFO - 2023-08-18 08:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 08:22:24 --> Parser Class Initialized
INFO - 2023-08-18 08:22:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 08:22:24 --> Pagination Class Initialized
INFO - 2023-08-18 08:22:24 --> Form Validation Class Initialized
INFO - 2023-08-18 08:22:24 --> Controller Class Initialized
INFO - 2023-08-18 08:22:24 --> Model Class Initialized
DEBUG - 2023-08-18 08:22:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 08:22:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 08:22:24 --> Model Class Initialized
DEBUG - 2023-08-18 08:22:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 08:22:24 --> Model Class Initialized
INFO - 2023-08-18 08:22:24 --> Final output sent to browser
DEBUG - 2023-08-18 08:22:24 --> Total execution time: 0.0232
ERROR - 2023-08-18 08:22:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 08:22:48 --> Config Class Initialized
INFO - 2023-08-18 08:22:48 --> Hooks Class Initialized
DEBUG - 2023-08-18 08:22:48 --> UTF-8 Support Enabled
INFO - 2023-08-18 08:22:48 --> Utf8 Class Initialized
INFO - 2023-08-18 08:22:48 --> URI Class Initialized
DEBUG - 2023-08-18 08:22:48 --> No URI present. Default controller set.
INFO - 2023-08-18 08:22:48 --> Router Class Initialized
INFO - 2023-08-18 08:22:48 --> Output Class Initialized
INFO - 2023-08-18 08:22:48 --> Security Class Initialized
DEBUG - 2023-08-18 08:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 08:22:48 --> Input Class Initialized
INFO - 2023-08-18 08:22:48 --> Language Class Initialized
INFO - 2023-08-18 08:22:48 --> Loader Class Initialized
INFO - 2023-08-18 08:22:48 --> Helper loaded: url_helper
INFO - 2023-08-18 08:22:48 --> Helper loaded: file_helper
INFO - 2023-08-18 08:22:48 --> Helper loaded: html_helper
INFO - 2023-08-18 08:22:48 --> Helper loaded: text_helper
INFO - 2023-08-18 08:22:48 --> Helper loaded: form_helper
INFO - 2023-08-18 08:22:48 --> Helper loaded: lang_helper
INFO - 2023-08-18 08:22:48 --> Helper loaded: security_helper
INFO - 2023-08-18 08:22:48 --> Helper loaded: cookie_helper
INFO - 2023-08-18 08:22:48 --> Database Driver Class Initialized
INFO - 2023-08-18 08:22:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 08:22:48 --> Parser Class Initialized
INFO - 2023-08-18 08:22:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 08:22:48 --> Pagination Class Initialized
INFO - 2023-08-18 08:22:48 --> Form Validation Class Initialized
INFO - 2023-08-18 08:22:48 --> Controller Class Initialized
INFO - 2023-08-18 08:22:48 --> Model Class Initialized
DEBUG - 2023-08-18 08:22:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 08:22:48 --> Model Class Initialized
DEBUG - 2023-08-18 08:22:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 08:22:48 --> Model Class Initialized
INFO - 2023-08-18 08:22:48 --> Model Class Initialized
INFO - 2023-08-18 08:22:48 --> Model Class Initialized
INFO - 2023-08-18 08:22:48 --> Model Class Initialized
DEBUG - 2023-08-18 08:22:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 08:22:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 08:22:48 --> Model Class Initialized
INFO - 2023-08-18 08:22:48 --> Model Class Initialized
INFO - 2023-08-18 08:22:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-18 08:22:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 08:22:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 08:22:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 08:22:48 --> Model Class Initialized
INFO - 2023-08-18 08:22:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 08:22:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 08:22:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 08:22:48 --> Final output sent to browser
DEBUG - 2023-08-18 08:22:48 --> Total execution time: 0.0861
ERROR - 2023-08-18 08:22:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 08:22:54 --> Config Class Initialized
INFO - 2023-08-18 08:22:54 --> Hooks Class Initialized
DEBUG - 2023-08-18 08:22:54 --> UTF-8 Support Enabled
INFO - 2023-08-18 08:22:54 --> Utf8 Class Initialized
INFO - 2023-08-18 08:22:54 --> URI Class Initialized
INFO - 2023-08-18 08:22:54 --> Router Class Initialized
INFO - 2023-08-18 08:22:54 --> Output Class Initialized
INFO - 2023-08-18 08:22:54 --> Security Class Initialized
DEBUG - 2023-08-18 08:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 08:22:54 --> Input Class Initialized
INFO - 2023-08-18 08:22:54 --> Language Class Initialized
INFO - 2023-08-18 08:22:54 --> Loader Class Initialized
INFO - 2023-08-18 08:22:54 --> Helper loaded: url_helper
INFO - 2023-08-18 08:22:54 --> Helper loaded: file_helper
INFO - 2023-08-18 08:22:54 --> Helper loaded: html_helper
INFO - 2023-08-18 08:22:54 --> Helper loaded: text_helper
INFO - 2023-08-18 08:22:54 --> Helper loaded: form_helper
INFO - 2023-08-18 08:22:54 --> Helper loaded: lang_helper
INFO - 2023-08-18 08:22:54 --> Helper loaded: security_helper
INFO - 2023-08-18 08:22:54 --> Helper loaded: cookie_helper
INFO - 2023-08-18 08:22:54 --> Database Driver Class Initialized
INFO - 2023-08-18 08:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 08:22:54 --> Parser Class Initialized
INFO - 2023-08-18 08:22:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 08:22:54 --> Pagination Class Initialized
INFO - 2023-08-18 08:22:54 --> Form Validation Class Initialized
INFO - 2023-08-18 08:22:54 --> Controller Class Initialized
INFO - 2023-08-18 08:22:54 --> Model Class Initialized
DEBUG - 2023-08-18 08:22:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 08:22:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 08:22:54 --> Model Class Initialized
DEBUG - 2023-08-18 08:22:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 08:22:54 --> Model Class Initialized
INFO - 2023-08-18 08:22:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-08-18 08:22:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 08:22:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 08:22:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 08:22:55 --> Model Class Initialized
INFO - 2023-08-18 08:22:55 --> Model Class Initialized
INFO - 2023-08-18 08:22:55 --> Model Class Initialized
INFO - 2023-08-18 08:22:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 08:22:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 08:22:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 08:22:55 --> Final output sent to browser
DEBUG - 2023-08-18 08:22:55 --> Total execution time: 0.0697
ERROR - 2023-08-18 08:22:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 08:22:55 --> Config Class Initialized
INFO - 2023-08-18 08:22:55 --> Hooks Class Initialized
DEBUG - 2023-08-18 08:22:55 --> UTF-8 Support Enabled
INFO - 2023-08-18 08:22:55 --> Utf8 Class Initialized
INFO - 2023-08-18 08:22:55 --> URI Class Initialized
INFO - 2023-08-18 08:22:55 --> Router Class Initialized
INFO - 2023-08-18 08:22:55 --> Output Class Initialized
INFO - 2023-08-18 08:22:55 --> Security Class Initialized
DEBUG - 2023-08-18 08:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 08:22:55 --> Input Class Initialized
INFO - 2023-08-18 08:22:55 --> Language Class Initialized
INFO - 2023-08-18 08:22:55 --> Loader Class Initialized
INFO - 2023-08-18 08:22:55 --> Helper loaded: url_helper
INFO - 2023-08-18 08:22:55 --> Helper loaded: file_helper
INFO - 2023-08-18 08:22:55 --> Helper loaded: html_helper
INFO - 2023-08-18 08:22:55 --> Helper loaded: text_helper
INFO - 2023-08-18 08:22:55 --> Helper loaded: form_helper
INFO - 2023-08-18 08:22:55 --> Helper loaded: lang_helper
INFO - 2023-08-18 08:22:55 --> Helper loaded: security_helper
INFO - 2023-08-18 08:22:55 --> Helper loaded: cookie_helper
INFO - 2023-08-18 08:22:55 --> Database Driver Class Initialized
INFO - 2023-08-18 08:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 08:22:55 --> Parser Class Initialized
INFO - 2023-08-18 08:22:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 08:22:55 --> Pagination Class Initialized
INFO - 2023-08-18 08:22:55 --> Form Validation Class Initialized
INFO - 2023-08-18 08:22:55 --> Controller Class Initialized
INFO - 2023-08-18 08:22:55 --> Model Class Initialized
DEBUG - 2023-08-18 08:22:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 08:22:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 08:22:55 --> Model Class Initialized
DEBUG - 2023-08-18 08:22:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 08:22:55 --> Model Class Initialized
INFO - 2023-08-18 08:22:55 --> Final output sent to browser
DEBUG - 2023-08-18 08:22:55 --> Total execution time: 0.0208
ERROR - 2023-08-18 08:23:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 08:23:01 --> Config Class Initialized
INFO - 2023-08-18 08:23:01 --> Hooks Class Initialized
DEBUG - 2023-08-18 08:23:01 --> UTF-8 Support Enabled
INFO - 2023-08-18 08:23:01 --> Utf8 Class Initialized
INFO - 2023-08-18 08:23:01 --> URI Class Initialized
DEBUG - 2023-08-18 08:23:01 --> No URI present. Default controller set.
INFO - 2023-08-18 08:23:01 --> Router Class Initialized
INFO - 2023-08-18 08:23:01 --> Output Class Initialized
INFO - 2023-08-18 08:23:01 --> Security Class Initialized
DEBUG - 2023-08-18 08:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 08:23:01 --> Input Class Initialized
INFO - 2023-08-18 08:23:01 --> Language Class Initialized
INFO - 2023-08-18 08:23:01 --> Loader Class Initialized
INFO - 2023-08-18 08:23:01 --> Helper loaded: url_helper
INFO - 2023-08-18 08:23:01 --> Helper loaded: file_helper
INFO - 2023-08-18 08:23:01 --> Helper loaded: html_helper
INFO - 2023-08-18 08:23:01 --> Helper loaded: text_helper
INFO - 2023-08-18 08:23:01 --> Helper loaded: form_helper
INFO - 2023-08-18 08:23:01 --> Helper loaded: lang_helper
INFO - 2023-08-18 08:23:01 --> Helper loaded: security_helper
INFO - 2023-08-18 08:23:01 --> Helper loaded: cookie_helper
INFO - 2023-08-18 08:23:01 --> Database Driver Class Initialized
INFO - 2023-08-18 08:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 08:23:01 --> Parser Class Initialized
INFO - 2023-08-18 08:23:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 08:23:01 --> Pagination Class Initialized
INFO - 2023-08-18 08:23:01 --> Form Validation Class Initialized
INFO - 2023-08-18 08:23:01 --> Controller Class Initialized
INFO - 2023-08-18 08:23:01 --> Model Class Initialized
DEBUG - 2023-08-18 08:23:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 08:23:01 --> Model Class Initialized
DEBUG - 2023-08-18 08:23:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 08:23:01 --> Model Class Initialized
INFO - 2023-08-18 08:23:01 --> Model Class Initialized
INFO - 2023-08-18 08:23:01 --> Model Class Initialized
INFO - 2023-08-18 08:23:01 --> Model Class Initialized
DEBUG - 2023-08-18 08:23:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 08:23:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 08:23:01 --> Model Class Initialized
INFO - 2023-08-18 08:23:01 --> Model Class Initialized
INFO - 2023-08-18 08:23:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-18 08:23:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 08:23:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 08:23:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 08:23:01 --> Model Class Initialized
INFO - 2023-08-18 08:23:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 08:23:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 08:23:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 08:23:01 --> Final output sent to browser
DEBUG - 2023-08-18 08:23:01 --> Total execution time: 0.0773
ERROR - 2023-08-18 09:58:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 09:58:42 --> Config Class Initialized
INFO - 2023-08-18 09:58:42 --> Hooks Class Initialized
DEBUG - 2023-08-18 09:58:42 --> UTF-8 Support Enabled
INFO - 2023-08-18 09:58:42 --> Utf8 Class Initialized
INFO - 2023-08-18 09:58:42 --> URI Class Initialized
DEBUG - 2023-08-18 09:58:42 --> No URI present. Default controller set.
INFO - 2023-08-18 09:58:42 --> Router Class Initialized
INFO - 2023-08-18 09:58:42 --> Output Class Initialized
INFO - 2023-08-18 09:58:42 --> Security Class Initialized
DEBUG - 2023-08-18 09:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 09:58:42 --> Input Class Initialized
INFO - 2023-08-18 09:58:42 --> Language Class Initialized
INFO - 2023-08-18 09:58:42 --> Loader Class Initialized
INFO - 2023-08-18 09:58:42 --> Helper loaded: url_helper
INFO - 2023-08-18 09:58:42 --> Helper loaded: file_helper
INFO - 2023-08-18 09:58:42 --> Helper loaded: html_helper
INFO - 2023-08-18 09:58:42 --> Helper loaded: text_helper
INFO - 2023-08-18 09:58:42 --> Helper loaded: form_helper
INFO - 2023-08-18 09:58:42 --> Helper loaded: lang_helper
INFO - 2023-08-18 09:58:42 --> Helper loaded: security_helper
INFO - 2023-08-18 09:58:42 --> Helper loaded: cookie_helper
INFO - 2023-08-18 09:58:42 --> Database Driver Class Initialized
INFO - 2023-08-18 09:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 09:58:42 --> Parser Class Initialized
INFO - 2023-08-18 09:58:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 09:58:42 --> Pagination Class Initialized
INFO - 2023-08-18 09:58:42 --> Form Validation Class Initialized
INFO - 2023-08-18 09:58:42 --> Controller Class Initialized
INFO - 2023-08-18 09:58:42 --> Model Class Initialized
DEBUG - 2023-08-18 09:58:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-18 09:58:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 09:58:43 --> Config Class Initialized
INFO - 2023-08-18 09:58:43 --> Hooks Class Initialized
DEBUG - 2023-08-18 09:58:43 --> UTF-8 Support Enabled
INFO - 2023-08-18 09:58:43 --> Utf8 Class Initialized
INFO - 2023-08-18 09:58:43 --> URI Class Initialized
INFO - 2023-08-18 09:58:43 --> Router Class Initialized
INFO - 2023-08-18 09:58:43 --> Output Class Initialized
INFO - 2023-08-18 09:58:43 --> Security Class Initialized
DEBUG - 2023-08-18 09:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 09:58:43 --> Input Class Initialized
INFO - 2023-08-18 09:58:43 --> Language Class Initialized
INFO - 2023-08-18 09:58:43 --> Loader Class Initialized
INFO - 2023-08-18 09:58:43 --> Helper loaded: url_helper
INFO - 2023-08-18 09:58:43 --> Helper loaded: file_helper
INFO - 2023-08-18 09:58:43 --> Helper loaded: html_helper
INFO - 2023-08-18 09:58:43 --> Helper loaded: text_helper
INFO - 2023-08-18 09:58:43 --> Helper loaded: form_helper
INFO - 2023-08-18 09:58:43 --> Helper loaded: lang_helper
INFO - 2023-08-18 09:58:43 --> Helper loaded: security_helper
INFO - 2023-08-18 09:58:43 --> Helper loaded: cookie_helper
INFO - 2023-08-18 09:58:43 --> Database Driver Class Initialized
INFO - 2023-08-18 09:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 09:58:43 --> Parser Class Initialized
INFO - 2023-08-18 09:58:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 09:58:43 --> Pagination Class Initialized
INFO - 2023-08-18 09:58:43 --> Form Validation Class Initialized
INFO - 2023-08-18 09:58:43 --> Controller Class Initialized
INFO - 2023-08-18 09:58:43 --> Model Class Initialized
DEBUG - 2023-08-18 09:58:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 09:58:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-18 09:58:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 09:58:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 09:58:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 09:58:43 --> Model Class Initialized
INFO - 2023-08-18 09:58:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 09:58:43 --> Final output sent to browser
DEBUG - 2023-08-18 09:58:43 --> Total execution time: 0.0329
ERROR - 2023-08-18 11:03:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 11:03:47 --> Config Class Initialized
INFO - 2023-08-18 11:03:47 --> Hooks Class Initialized
DEBUG - 2023-08-18 11:03:47 --> UTF-8 Support Enabled
INFO - 2023-08-18 11:03:47 --> Utf8 Class Initialized
INFO - 2023-08-18 11:03:47 --> URI Class Initialized
DEBUG - 2023-08-18 11:03:47 --> No URI present. Default controller set.
INFO - 2023-08-18 11:03:47 --> Router Class Initialized
INFO - 2023-08-18 11:03:47 --> Output Class Initialized
INFO - 2023-08-18 11:03:47 --> Security Class Initialized
DEBUG - 2023-08-18 11:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 11:03:47 --> Input Class Initialized
INFO - 2023-08-18 11:03:47 --> Language Class Initialized
INFO - 2023-08-18 11:03:47 --> Loader Class Initialized
INFO - 2023-08-18 11:03:47 --> Helper loaded: url_helper
INFO - 2023-08-18 11:03:47 --> Helper loaded: file_helper
INFO - 2023-08-18 11:03:47 --> Helper loaded: html_helper
INFO - 2023-08-18 11:03:47 --> Helper loaded: text_helper
INFO - 2023-08-18 11:03:47 --> Helper loaded: form_helper
INFO - 2023-08-18 11:03:47 --> Helper loaded: lang_helper
INFO - 2023-08-18 11:03:47 --> Helper loaded: security_helper
INFO - 2023-08-18 11:03:47 --> Helper loaded: cookie_helper
INFO - 2023-08-18 11:03:47 --> Database Driver Class Initialized
INFO - 2023-08-18 11:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 11:03:47 --> Parser Class Initialized
INFO - 2023-08-18 11:03:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 11:03:47 --> Pagination Class Initialized
INFO - 2023-08-18 11:03:47 --> Form Validation Class Initialized
INFO - 2023-08-18 11:03:47 --> Controller Class Initialized
INFO - 2023-08-18 11:03:47 --> Model Class Initialized
DEBUG - 2023-08-18 11:03:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-18 11:03:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 11:03:47 --> Config Class Initialized
INFO - 2023-08-18 11:03:47 --> Hooks Class Initialized
DEBUG - 2023-08-18 11:03:47 --> UTF-8 Support Enabled
INFO - 2023-08-18 11:03:47 --> Utf8 Class Initialized
INFO - 2023-08-18 11:03:47 --> URI Class Initialized
INFO - 2023-08-18 11:03:47 --> Router Class Initialized
INFO - 2023-08-18 11:03:47 --> Output Class Initialized
INFO - 2023-08-18 11:03:47 --> Security Class Initialized
DEBUG - 2023-08-18 11:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 11:03:47 --> Input Class Initialized
INFO - 2023-08-18 11:03:47 --> Language Class Initialized
INFO - 2023-08-18 11:03:47 --> Loader Class Initialized
INFO - 2023-08-18 11:03:47 --> Helper loaded: url_helper
INFO - 2023-08-18 11:03:47 --> Helper loaded: file_helper
INFO - 2023-08-18 11:03:47 --> Helper loaded: html_helper
INFO - 2023-08-18 11:03:47 --> Helper loaded: text_helper
INFO - 2023-08-18 11:03:47 --> Helper loaded: form_helper
INFO - 2023-08-18 11:03:47 --> Helper loaded: lang_helper
INFO - 2023-08-18 11:03:47 --> Helper loaded: security_helper
INFO - 2023-08-18 11:03:47 --> Helper loaded: cookie_helper
INFO - 2023-08-18 11:03:47 --> Database Driver Class Initialized
INFO - 2023-08-18 11:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 11:03:47 --> Parser Class Initialized
INFO - 2023-08-18 11:03:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 11:03:47 --> Pagination Class Initialized
INFO - 2023-08-18 11:03:47 --> Form Validation Class Initialized
INFO - 2023-08-18 11:03:47 --> Controller Class Initialized
INFO - 2023-08-18 11:03:47 --> Model Class Initialized
DEBUG - 2023-08-18 11:03:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 11:03:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-18 11:03:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 11:03:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 11:03:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 11:03:47 --> Model Class Initialized
INFO - 2023-08-18 11:03:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 11:03:47 --> Final output sent to browser
DEBUG - 2023-08-18 11:03:47 --> Total execution time: 0.0359
ERROR - 2023-08-18 11:12:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 11:12:03 --> Config Class Initialized
INFO - 2023-08-18 11:12:03 --> Hooks Class Initialized
DEBUG - 2023-08-18 11:12:03 --> UTF-8 Support Enabled
INFO - 2023-08-18 11:12:03 --> Utf8 Class Initialized
INFO - 2023-08-18 11:12:03 --> URI Class Initialized
DEBUG - 2023-08-18 11:12:03 --> No URI present. Default controller set.
INFO - 2023-08-18 11:12:03 --> Router Class Initialized
INFO - 2023-08-18 11:12:03 --> Output Class Initialized
INFO - 2023-08-18 11:12:03 --> Security Class Initialized
DEBUG - 2023-08-18 11:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 11:12:04 --> Input Class Initialized
INFO - 2023-08-18 11:12:04 --> Language Class Initialized
INFO - 2023-08-18 11:12:04 --> Loader Class Initialized
INFO - 2023-08-18 11:12:04 --> Helper loaded: url_helper
INFO - 2023-08-18 11:12:04 --> Helper loaded: file_helper
INFO - 2023-08-18 11:12:04 --> Helper loaded: html_helper
INFO - 2023-08-18 11:12:04 --> Helper loaded: text_helper
INFO - 2023-08-18 11:12:04 --> Helper loaded: form_helper
INFO - 2023-08-18 11:12:04 --> Helper loaded: lang_helper
INFO - 2023-08-18 11:12:04 --> Helper loaded: security_helper
INFO - 2023-08-18 11:12:04 --> Helper loaded: cookie_helper
INFO - 2023-08-18 11:12:04 --> Database Driver Class Initialized
INFO - 2023-08-18 11:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 11:12:04 --> Parser Class Initialized
INFO - 2023-08-18 11:12:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 11:12:04 --> Pagination Class Initialized
INFO - 2023-08-18 11:12:04 --> Form Validation Class Initialized
INFO - 2023-08-18 11:12:04 --> Controller Class Initialized
INFO - 2023-08-18 11:12:04 --> Model Class Initialized
DEBUG - 2023-08-18 11:12:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-18 11:12:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 11:12:04 --> Config Class Initialized
INFO - 2023-08-18 11:12:04 --> Hooks Class Initialized
DEBUG - 2023-08-18 11:12:04 --> UTF-8 Support Enabled
INFO - 2023-08-18 11:12:04 --> Utf8 Class Initialized
INFO - 2023-08-18 11:12:04 --> URI Class Initialized
INFO - 2023-08-18 11:12:04 --> Router Class Initialized
INFO - 2023-08-18 11:12:04 --> Output Class Initialized
INFO - 2023-08-18 11:12:04 --> Security Class Initialized
DEBUG - 2023-08-18 11:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 11:12:04 --> Input Class Initialized
INFO - 2023-08-18 11:12:04 --> Language Class Initialized
INFO - 2023-08-18 11:12:04 --> Loader Class Initialized
INFO - 2023-08-18 11:12:04 --> Helper loaded: url_helper
INFO - 2023-08-18 11:12:04 --> Helper loaded: file_helper
INFO - 2023-08-18 11:12:04 --> Helper loaded: html_helper
INFO - 2023-08-18 11:12:04 --> Helper loaded: text_helper
INFO - 2023-08-18 11:12:04 --> Helper loaded: form_helper
INFO - 2023-08-18 11:12:04 --> Helper loaded: lang_helper
INFO - 2023-08-18 11:12:04 --> Helper loaded: security_helper
INFO - 2023-08-18 11:12:04 --> Helper loaded: cookie_helper
INFO - 2023-08-18 11:12:04 --> Database Driver Class Initialized
INFO - 2023-08-18 11:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 11:12:04 --> Parser Class Initialized
INFO - 2023-08-18 11:12:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 11:12:04 --> Pagination Class Initialized
INFO - 2023-08-18 11:12:04 --> Form Validation Class Initialized
INFO - 2023-08-18 11:12:04 --> Controller Class Initialized
INFO - 2023-08-18 11:12:04 --> Model Class Initialized
DEBUG - 2023-08-18 11:12:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 11:12:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-18 11:12:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 11:12:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 11:12:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 11:12:04 --> Model Class Initialized
INFO - 2023-08-18 11:12:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 11:12:04 --> Final output sent to browser
DEBUG - 2023-08-18 11:12:04 --> Total execution time: 0.0302
ERROR - 2023-08-18 11:12:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 11:12:19 --> Config Class Initialized
INFO - 2023-08-18 11:12:19 --> Hooks Class Initialized
DEBUG - 2023-08-18 11:12:19 --> UTF-8 Support Enabled
INFO - 2023-08-18 11:12:19 --> Utf8 Class Initialized
INFO - 2023-08-18 11:12:19 --> URI Class Initialized
INFO - 2023-08-18 11:12:19 --> Router Class Initialized
INFO - 2023-08-18 11:12:19 --> Output Class Initialized
INFO - 2023-08-18 11:12:19 --> Security Class Initialized
DEBUG - 2023-08-18 11:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 11:12:19 --> Input Class Initialized
INFO - 2023-08-18 11:12:19 --> Language Class Initialized
INFO - 2023-08-18 11:12:19 --> Loader Class Initialized
INFO - 2023-08-18 11:12:19 --> Helper loaded: url_helper
INFO - 2023-08-18 11:12:19 --> Helper loaded: file_helper
INFO - 2023-08-18 11:12:19 --> Helper loaded: html_helper
INFO - 2023-08-18 11:12:19 --> Helper loaded: text_helper
INFO - 2023-08-18 11:12:19 --> Helper loaded: form_helper
INFO - 2023-08-18 11:12:19 --> Helper loaded: lang_helper
INFO - 2023-08-18 11:12:19 --> Helper loaded: security_helper
INFO - 2023-08-18 11:12:19 --> Helper loaded: cookie_helper
INFO - 2023-08-18 11:12:19 --> Database Driver Class Initialized
INFO - 2023-08-18 11:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 11:12:19 --> Parser Class Initialized
INFO - 2023-08-18 11:12:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 11:12:19 --> Pagination Class Initialized
INFO - 2023-08-18 11:12:19 --> Form Validation Class Initialized
INFO - 2023-08-18 11:12:19 --> Controller Class Initialized
INFO - 2023-08-18 11:12:19 --> Model Class Initialized
DEBUG - 2023-08-18 11:12:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 11:12:19 --> Model Class Initialized
INFO - 2023-08-18 11:12:19 --> Final output sent to browser
DEBUG - 2023-08-18 11:12:19 --> Total execution time: 0.0207
ERROR - 2023-08-18 11:12:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 11:12:20 --> Config Class Initialized
INFO - 2023-08-18 11:12:20 --> Hooks Class Initialized
DEBUG - 2023-08-18 11:12:20 --> UTF-8 Support Enabled
INFO - 2023-08-18 11:12:20 --> Utf8 Class Initialized
INFO - 2023-08-18 11:12:20 --> URI Class Initialized
DEBUG - 2023-08-18 11:12:20 --> No URI present. Default controller set.
INFO - 2023-08-18 11:12:20 --> Router Class Initialized
INFO - 2023-08-18 11:12:20 --> Output Class Initialized
INFO - 2023-08-18 11:12:20 --> Security Class Initialized
DEBUG - 2023-08-18 11:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 11:12:20 --> Input Class Initialized
INFO - 2023-08-18 11:12:20 --> Language Class Initialized
INFO - 2023-08-18 11:12:20 --> Loader Class Initialized
INFO - 2023-08-18 11:12:20 --> Helper loaded: url_helper
INFO - 2023-08-18 11:12:20 --> Helper loaded: file_helper
INFO - 2023-08-18 11:12:20 --> Helper loaded: html_helper
INFO - 2023-08-18 11:12:20 --> Helper loaded: text_helper
INFO - 2023-08-18 11:12:20 --> Helper loaded: form_helper
INFO - 2023-08-18 11:12:20 --> Helper loaded: lang_helper
INFO - 2023-08-18 11:12:20 --> Helper loaded: security_helper
INFO - 2023-08-18 11:12:20 --> Helper loaded: cookie_helper
INFO - 2023-08-18 11:12:20 --> Database Driver Class Initialized
INFO - 2023-08-18 11:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 11:12:20 --> Parser Class Initialized
INFO - 2023-08-18 11:12:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 11:12:20 --> Pagination Class Initialized
INFO - 2023-08-18 11:12:20 --> Form Validation Class Initialized
INFO - 2023-08-18 11:12:20 --> Controller Class Initialized
INFO - 2023-08-18 11:12:20 --> Model Class Initialized
DEBUG - 2023-08-18 11:12:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 11:12:20 --> Model Class Initialized
DEBUG - 2023-08-18 11:12:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 11:12:20 --> Model Class Initialized
INFO - 2023-08-18 11:12:20 --> Model Class Initialized
INFO - 2023-08-18 11:12:20 --> Model Class Initialized
INFO - 2023-08-18 11:12:20 --> Model Class Initialized
DEBUG - 2023-08-18 11:12:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 11:12:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 11:12:20 --> Model Class Initialized
INFO - 2023-08-18 11:12:20 --> Model Class Initialized
INFO - 2023-08-18 11:12:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-18 11:12:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 11:12:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 11:12:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 11:12:20 --> Model Class Initialized
INFO - 2023-08-18 11:12:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 11:12:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 11:12:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 11:12:20 --> Final output sent to browser
DEBUG - 2023-08-18 11:12:20 --> Total execution time: 0.0928
ERROR - 2023-08-18 11:12:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 11:12:34 --> Config Class Initialized
INFO - 2023-08-18 11:12:34 --> Hooks Class Initialized
DEBUG - 2023-08-18 11:12:34 --> UTF-8 Support Enabled
INFO - 2023-08-18 11:12:34 --> Utf8 Class Initialized
INFO - 2023-08-18 11:12:34 --> URI Class Initialized
INFO - 2023-08-18 11:12:34 --> Router Class Initialized
INFO - 2023-08-18 11:12:34 --> Output Class Initialized
INFO - 2023-08-18 11:12:34 --> Security Class Initialized
DEBUG - 2023-08-18 11:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 11:12:34 --> Input Class Initialized
INFO - 2023-08-18 11:12:34 --> Language Class Initialized
INFO - 2023-08-18 11:12:34 --> Loader Class Initialized
INFO - 2023-08-18 11:12:34 --> Helper loaded: url_helper
INFO - 2023-08-18 11:12:34 --> Helper loaded: file_helper
INFO - 2023-08-18 11:12:34 --> Helper loaded: html_helper
INFO - 2023-08-18 11:12:34 --> Helper loaded: text_helper
INFO - 2023-08-18 11:12:34 --> Helper loaded: form_helper
INFO - 2023-08-18 11:12:34 --> Helper loaded: lang_helper
INFO - 2023-08-18 11:12:34 --> Helper loaded: security_helper
INFO - 2023-08-18 11:12:34 --> Helper loaded: cookie_helper
INFO - 2023-08-18 11:12:34 --> Database Driver Class Initialized
INFO - 2023-08-18 11:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 11:12:34 --> Parser Class Initialized
INFO - 2023-08-18 11:12:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 11:12:34 --> Pagination Class Initialized
INFO - 2023-08-18 11:12:34 --> Form Validation Class Initialized
INFO - 2023-08-18 11:12:34 --> Controller Class Initialized
INFO - 2023-08-18 11:12:34 --> Model Class Initialized
DEBUG - 2023-08-18 11:12:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 11:12:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 11:12:34 --> Model Class Initialized
DEBUG - 2023-08-18 11:12:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 11:12:34 --> Model Class Initialized
INFO - 2023-08-18 11:12:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-18 11:12:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 11:12:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 11:12:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 11:12:34 --> Model Class Initialized
INFO - 2023-08-18 11:12:34 --> Model Class Initialized
INFO - 2023-08-18 11:12:34 --> Model Class Initialized
INFO - 2023-08-18 11:12:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 11:12:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 11:12:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 11:12:34 --> Final output sent to browser
DEBUG - 2023-08-18 11:12:34 --> Total execution time: 0.0784
ERROR - 2023-08-18 11:12:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 11:12:35 --> Config Class Initialized
INFO - 2023-08-18 11:12:35 --> Hooks Class Initialized
DEBUG - 2023-08-18 11:12:35 --> UTF-8 Support Enabled
INFO - 2023-08-18 11:12:35 --> Utf8 Class Initialized
INFO - 2023-08-18 11:12:35 --> URI Class Initialized
INFO - 2023-08-18 11:12:35 --> Router Class Initialized
INFO - 2023-08-18 11:12:35 --> Output Class Initialized
INFO - 2023-08-18 11:12:35 --> Security Class Initialized
DEBUG - 2023-08-18 11:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 11:12:35 --> Input Class Initialized
INFO - 2023-08-18 11:12:35 --> Language Class Initialized
INFO - 2023-08-18 11:12:35 --> Loader Class Initialized
INFO - 2023-08-18 11:12:35 --> Helper loaded: url_helper
INFO - 2023-08-18 11:12:35 --> Helper loaded: file_helper
INFO - 2023-08-18 11:12:35 --> Helper loaded: html_helper
INFO - 2023-08-18 11:12:35 --> Helper loaded: text_helper
INFO - 2023-08-18 11:12:35 --> Helper loaded: form_helper
INFO - 2023-08-18 11:12:35 --> Helper loaded: lang_helper
INFO - 2023-08-18 11:12:35 --> Helper loaded: security_helper
INFO - 2023-08-18 11:12:35 --> Helper loaded: cookie_helper
INFO - 2023-08-18 11:12:35 --> Database Driver Class Initialized
INFO - 2023-08-18 11:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 11:12:35 --> Parser Class Initialized
INFO - 2023-08-18 11:12:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 11:12:35 --> Pagination Class Initialized
INFO - 2023-08-18 11:12:35 --> Form Validation Class Initialized
INFO - 2023-08-18 11:12:35 --> Controller Class Initialized
INFO - 2023-08-18 11:12:35 --> Model Class Initialized
DEBUG - 2023-08-18 11:12:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 11:12:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 11:12:35 --> Model Class Initialized
DEBUG - 2023-08-18 11:12:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 11:12:35 --> Model Class Initialized
INFO - 2023-08-18 11:12:35 --> Final output sent to browser
DEBUG - 2023-08-18 11:12:35 --> Total execution time: 0.0240
ERROR - 2023-08-18 11:13:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 11:13:26 --> Config Class Initialized
INFO - 2023-08-18 11:13:26 --> Hooks Class Initialized
DEBUG - 2023-08-18 11:13:26 --> UTF-8 Support Enabled
INFO - 2023-08-18 11:13:26 --> Utf8 Class Initialized
INFO - 2023-08-18 11:13:26 --> URI Class Initialized
DEBUG - 2023-08-18 11:13:26 --> No URI present. Default controller set.
INFO - 2023-08-18 11:13:26 --> Router Class Initialized
INFO - 2023-08-18 11:13:26 --> Output Class Initialized
INFO - 2023-08-18 11:13:26 --> Security Class Initialized
DEBUG - 2023-08-18 11:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 11:13:26 --> Input Class Initialized
INFO - 2023-08-18 11:13:26 --> Language Class Initialized
INFO - 2023-08-18 11:13:26 --> Loader Class Initialized
INFO - 2023-08-18 11:13:26 --> Helper loaded: url_helper
INFO - 2023-08-18 11:13:26 --> Helper loaded: file_helper
INFO - 2023-08-18 11:13:26 --> Helper loaded: html_helper
INFO - 2023-08-18 11:13:26 --> Helper loaded: text_helper
INFO - 2023-08-18 11:13:26 --> Helper loaded: form_helper
INFO - 2023-08-18 11:13:26 --> Helper loaded: lang_helper
INFO - 2023-08-18 11:13:26 --> Helper loaded: security_helper
INFO - 2023-08-18 11:13:26 --> Helper loaded: cookie_helper
INFO - 2023-08-18 11:13:26 --> Database Driver Class Initialized
INFO - 2023-08-18 11:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 11:13:26 --> Parser Class Initialized
INFO - 2023-08-18 11:13:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 11:13:26 --> Pagination Class Initialized
INFO - 2023-08-18 11:13:26 --> Form Validation Class Initialized
INFO - 2023-08-18 11:13:26 --> Controller Class Initialized
INFO - 2023-08-18 11:13:26 --> Model Class Initialized
DEBUG - 2023-08-18 11:13:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 11:13:26 --> Model Class Initialized
DEBUG - 2023-08-18 11:13:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 11:13:26 --> Model Class Initialized
INFO - 2023-08-18 11:13:26 --> Model Class Initialized
INFO - 2023-08-18 11:13:26 --> Model Class Initialized
INFO - 2023-08-18 11:13:26 --> Model Class Initialized
DEBUG - 2023-08-18 11:13:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 11:13:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 11:13:26 --> Model Class Initialized
INFO - 2023-08-18 11:13:26 --> Model Class Initialized
INFO - 2023-08-18 11:13:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-18 11:13:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 11:13:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 11:13:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 11:13:27 --> Model Class Initialized
INFO - 2023-08-18 11:13:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 11:13:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 11:13:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 11:13:27 --> Final output sent to browser
DEBUG - 2023-08-18 11:13:27 --> Total execution time: 0.0843
ERROR - 2023-08-18 13:00:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 13:00:10 --> Config Class Initialized
INFO - 2023-08-18 13:00:10 --> Hooks Class Initialized
DEBUG - 2023-08-18 13:00:10 --> UTF-8 Support Enabled
INFO - 2023-08-18 13:00:10 --> Utf8 Class Initialized
INFO - 2023-08-18 13:00:10 --> URI Class Initialized
DEBUG - 2023-08-18 13:00:10 --> No URI present. Default controller set.
INFO - 2023-08-18 13:00:10 --> Router Class Initialized
INFO - 2023-08-18 13:00:10 --> Output Class Initialized
INFO - 2023-08-18 13:00:10 --> Security Class Initialized
DEBUG - 2023-08-18 13:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 13:00:10 --> Input Class Initialized
INFO - 2023-08-18 13:00:10 --> Language Class Initialized
INFO - 2023-08-18 13:00:10 --> Loader Class Initialized
INFO - 2023-08-18 13:00:10 --> Helper loaded: url_helper
INFO - 2023-08-18 13:00:10 --> Helper loaded: file_helper
INFO - 2023-08-18 13:00:10 --> Helper loaded: html_helper
INFO - 2023-08-18 13:00:10 --> Helper loaded: text_helper
INFO - 2023-08-18 13:00:10 --> Helper loaded: form_helper
INFO - 2023-08-18 13:00:10 --> Helper loaded: lang_helper
INFO - 2023-08-18 13:00:10 --> Helper loaded: security_helper
INFO - 2023-08-18 13:00:10 --> Helper loaded: cookie_helper
INFO - 2023-08-18 13:00:10 --> Database Driver Class Initialized
INFO - 2023-08-18 13:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 13:00:10 --> Parser Class Initialized
INFO - 2023-08-18 13:00:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 13:00:10 --> Pagination Class Initialized
INFO - 2023-08-18 13:00:10 --> Form Validation Class Initialized
INFO - 2023-08-18 13:00:10 --> Controller Class Initialized
INFO - 2023-08-18 13:00:10 --> Model Class Initialized
DEBUG - 2023-08-18 13:00:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-18 13:00:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 13:00:10 --> Config Class Initialized
INFO - 2023-08-18 13:00:10 --> Hooks Class Initialized
DEBUG - 2023-08-18 13:00:10 --> UTF-8 Support Enabled
INFO - 2023-08-18 13:00:10 --> Utf8 Class Initialized
INFO - 2023-08-18 13:00:10 --> URI Class Initialized
INFO - 2023-08-18 13:00:10 --> Router Class Initialized
INFO - 2023-08-18 13:00:10 --> Output Class Initialized
INFO - 2023-08-18 13:00:10 --> Security Class Initialized
DEBUG - 2023-08-18 13:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 13:00:10 --> Input Class Initialized
INFO - 2023-08-18 13:00:10 --> Language Class Initialized
INFO - 2023-08-18 13:00:10 --> Loader Class Initialized
INFO - 2023-08-18 13:00:10 --> Helper loaded: url_helper
INFO - 2023-08-18 13:00:10 --> Helper loaded: file_helper
INFO - 2023-08-18 13:00:10 --> Helper loaded: html_helper
INFO - 2023-08-18 13:00:10 --> Helper loaded: text_helper
INFO - 2023-08-18 13:00:10 --> Helper loaded: form_helper
INFO - 2023-08-18 13:00:10 --> Helper loaded: lang_helper
INFO - 2023-08-18 13:00:10 --> Helper loaded: security_helper
INFO - 2023-08-18 13:00:10 --> Helper loaded: cookie_helper
INFO - 2023-08-18 13:00:10 --> Database Driver Class Initialized
INFO - 2023-08-18 13:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 13:00:10 --> Parser Class Initialized
INFO - 2023-08-18 13:00:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 13:00:10 --> Pagination Class Initialized
INFO - 2023-08-18 13:00:10 --> Form Validation Class Initialized
INFO - 2023-08-18 13:00:10 --> Controller Class Initialized
INFO - 2023-08-18 13:00:10 --> Model Class Initialized
DEBUG - 2023-08-18 13:00:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 13:00:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-18 13:00:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 13:00:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 13:00:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 13:00:10 --> Model Class Initialized
INFO - 2023-08-18 13:00:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 13:00:10 --> Final output sent to browser
DEBUG - 2023-08-18 13:00:10 --> Total execution time: 0.0457
ERROR - 2023-08-18 13:00:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 13:00:22 --> Config Class Initialized
INFO - 2023-08-18 13:00:22 --> Hooks Class Initialized
DEBUG - 2023-08-18 13:00:22 --> UTF-8 Support Enabled
INFO - 2023-08-18 13:00:22 --> Utf8 Class Initialized
INFO - 2023-08-18 13:00:22 --> URI Class Initialized
INFO - 2023-08-18 13:00:22 --> Router Class Initialized
INFO - 2023-08-18 13:00:22 --> Output Class Initialized
INFO - 2023-08-18 13:00:22 --> Security Class Initialized
DEBUG - 2023-08-18 13:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 13:00:22 --> Input Class Initialized
INFO - 2023-08-18 13:00:22 --> Language Class Initialized
INFO - 2023-08-18 13:00:22 --> Loader Class Initialized
INFO - 2023-08-18 13:00:22 --> Helper loaded: url_helper
INFO - 2023-08-18 13:00:22 --> Helper loaded: file_helper
INFO - 2023-08-18 13:00:22 --> Helper loaded: html_helper
INFO - 2023-08-18 13:00:22 --> Helper loaded: text_helper
INFO - 2023-08-18 13:00:22 --> Helper loaded: form_helper
INFO - 2023-08-18 13:00:22 --> Helper loaded: lang_helper
INFO - 2023-08-18 13:00:22 --> Helper loaded: security_helper
INFO - 2023-08-18 13:00:22 --> Helper loaded: cookie_helper
INFO - 2023-08-18 13:00:22 --> Database Driver Class Initialized
INFO - 2023-08-18 13:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 13:00:22 --> Parser Class Initialized
INFO - 2023-08-18 13:00:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 13:00:22 --> Pagination Class Initialized
INFO - 2023-08-18 13:00:22 --> Form Validation Class Initialized
INFO - 2023-08-18 13:00:22 --> Controller Class Initialized
INFO - 2023-08-18 13:00:22 --> Model Class Initialized
DEBUG - 2023-08-18 13:00:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 13:00:22 --> Model Class Initialized
INFO - 2023-08-18 13:00:22 --> Final output sent to browser
DEBUG - 2023-08-18 13:00:22 --> Total execution time: 0.0200
ERROR - 2023-08-18 13:00:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 13:00:22 --> Config Class Initialized
INFO - 2023-08-18 13:00:22 --> Hooks Class Initialized
DEBUG - 2023-08-18 13:00:22 --> UTF-8 Support Enabled
INFO - 2023-08-18 13:00:22 --> Utf8 Class Initialized
INFO - 2023-08-18 13:00:22 --> URI Class Initialized
DEBUG - 2023-08-18 13:00:22 --> No URI present. Default controller set.
INFO - 2023-08-18 13:00:22 --> Router Class Initialized
INFO - 2023-08-18 13:00:22 --> Output Class Initialized
INFO - 2023-08-18 13:00:22 --> Security Class Initialized
DEBUG - 2023-08-18 13:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 13:00:22 --> Input Class Initialized
INFO - 2023-08-18 13:00:22 --> Language Class Initialized
INFO - 2023-08-18 13:00:22 --> Loader Class Initialized
INFO - 2023-08-18 13:00:22 --> Helper loaded: url_helper
INFO - 2023-08-18 13:00:22 --> Helper loaded: file_helper
INFO - 2023-08-18 13:00:22 --> Helper loaded: html_helper
INFO - 2023-08-18 13:00:22 --> Helper loaded: text_helper
INFO - 2023-08-18 13:00:22 --> Helper loaded: form_helper
INFO - 2023-08-18 13:00:22 --> Helper loaded: lang_helper
INFO - 2023-08-18 13:00:22 --> Helper loaded: security_helper
INFO - 2023-08-18 13:00:22 --> Helper loaded: cookie_helper
INFO - 2023-08-18 13:00:22 --> Database Driver Class Initialized
INFO - 2023-08-18 13:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 13:00:22 --> Parser Class Initialized
INFO - 2023-08-18 13:00:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 13:00:22 --> Pagination Class Initialized
INFO - 2023-08-18 13:00:22 --> Form Validation Class Initialized
INFO - 2023-08-18 13:00:22 --> Controller Class Initialized
INFO - 2023-08-18 13:00:22 --> Model Class Initialized
DEBUG - 2023-08-18 13:00:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 13:00:22 --> Model Class Initialized
DEBUG - 2023-08-18 13:00:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 13:00:22 --> Model Class Initialized
INFO - 2023-08-18 13:00:22 --> Model Class Initialized
INFO - 2023-08-18 13:00:22 --> Model Class Initialized
INFO - 2023-08-18 13:00:22 --> Model Class Initialized
DEBUG - 2023-08-18 13:00:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 13:00:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 13:00:22 --> Model Class Initialized
INFO - 2023-08-18 13:00:22 --> Model Class Initialized
INFO - 2023-08-18 13:00:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-18 13:00:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 13:00:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 13:00:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 13:00:22 --> Model Class Initialized
INFO - 2023-08-18 13:00:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 13:00:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 13:00:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 13:00:22 --> Final output sent to browser
DEBUG - 2023-08-18 13:00:22 --> Total execution time: 0.0887
ERROR - 2023-08-18 13:01:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 13:01:10 --> Config Class Initialized
INFO - 2023-08-18 13:01:10 --> Hooks Class Initialized
DEBUG - 2023-08-18 13:01:10 --> UTF-8 Support Enabled
INFO - 2023-08-18 13:01:10 --> Utf8 Class Initialized
INFO - 2023-08-18 13:01:10 --> URI Class Initialized
INFO - 2023-08-18 13:01:10 --> Router Class Initialized
INFO - 2023-08-18 13:01:10 --> Output Class Initialized
INFO - 2023-08-18 13:01:10 --> Security Class Initialized
DEBUG - 2023-08-18 13:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 13:01:10 --> Input Class Initialized
INFO - 2023-08-18 13:01:10 --> Language Class Initialized
INFO - 2023-08-18 13:01:10 --> Loader Class Initialized
INFO - 2023-08-18 13:01:10 --> Helper loaded: url_helper
INFO - 2023-08-18 13:01:10 --> Helper loaded: file_helper
INFO - 2023-08-18 13:01:10 --> Helper loaded: html_helper
INFO - 2023-08-18 13:01:10 --> Helper loaded: text_helper
INFO - 2023-08-18 13:01:10 --> Helper loaded: form_helper
INFO - 2023-08-18 13:01:10 --> Helper loaded: lang_helper
INFO - 2023-08-18 13:01:10 --> Helper loaded: security_helper
INFO - 2023-08-18 13:01:10 --> Helper loaded: cookie_helper
INFO - 2023-08-18 13:01:10 --> Database Driver Class Initialized
INFO - 2023-08-18 13:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 13:01:10 --> Parser Class Initialized
INFO - 2023-08-18 13:01:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 13:01:10 --> Pagination Class Initialized
INFO - 2023-08-18 13:01:10 --> Form Validation Class Initialized
INFO - 2023-08-18 13:01:10 --> Controller Class Initialized
INFO - 2023-08-18 13:01:10 --> Model Class Initialized
INFO - 2023-08-18 13:01:10 --> Model Class Initialized
INFO - 2023-08-18 13:01:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2023-08-18 13:01:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 13:01:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 13:01:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 13:01:10 --> Model Class Initialized
INFO - 2023-08-18 13:01:10 --> Model Class Initialized
INFO - 2023-08-18 13:01:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 13:01:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 13:01:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 13:01:11 --> Final output sent to browser
DEBUG - 2023-08-18 13:01:11 --> Total execution time: 0.0894
ERROR - 2023-08-18 13:01:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 13:01:11 --> Config Class Initialized
INFO - 2023-08-18 13:01:11 --> Hooks Class Initialized
DEBUG - 2023-08-18 13:01:11 --> UTF-8 Support Enabled
INFO - 2023-08-18 13:01:11 --> Utf8 Class Initialized
INFO - 2023-08-18 13:01:11 --> URI Class Initialized
INFO - 2023-08-18 13:01:11 --> Router Class Initialized
INFO - 2023-08-18 13:01:11 --> Output Class Initialized
INFO - 2023-08-18 13:01:11 --> Security Class Initialized
DEBUG - 2023-08-18 13:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 13:01:11 --> Input Class Initialized
INFO - 2023-08-18 13:01:11 --> Language Class Initialized
INFO - 2023-08-18 13:01:11 --> Loader Class Initialized
INFO - 2023-08-18 13:01:11 --> Helper loaded: url_helper
INFO - 2023-08-18 13:01:11 --> Helper loaded: file_helper
INFO - 2023-08-18 13:01:11 --> Helper loaded: html_helper
INFO - 2023-08-18 13:01:11 --> Helper loaded: text_helper
INFO - 2023-08-18 13:01:11 --> Helper loaded: form_helper
INFO - 2023-08-18 13:01:11 --> Helper loaded: lang_helper
INFO - 2023-08-18 13:01:11 --> Helper loaded: security_helper
INFO - 2023-08-18 13:01:11 --> Helper loaded: cookie_helper
INFO - 2023-08-18 13:01:11 --> Database Driver Class Initialized
INFO - 2023-08-18 13:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 13:01:11 --> Parser Class Initialized
INFO - 2023-08-18 13:01:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 13:01:11 --> Pagination Class Initialized
INFO - 2023-08-18 13:01:11 --> Form Validation Class Initialized
INFO - 2023-08-18 13:01:11 --> Controller Class Initialized
INFO - 2023-08-18 13:01:11 --> Model Class Initialized
INFO - 2023-08-18 13:01:12 --> Model Class Initialized
INFO - 2023-08-18 13:01:12 --> Final output sent to browser
DEBUG - 2023-08-18 13:01:12 --> Total execution time: 0.0421
ERROR - 2023-08-18 13:01:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 13:01:15 --> Config Class Initialized
INFO - 2023-08-18 13:01:15 --> Hooks Class Initialized
DEBUG - 2023-08-18 13:01:15 --> UTF-8 Support Enabled
INFO - 2023-08-18 13:01:15 --> Utf8 Class Initialized
INFO - 2023-08-18 13:01:15 --> URI Class Initialized
DEBUG - 2023-08-18 13:01:15 --> No URI present. Default controller set.
INFO - 2023-08-18 13:01:15 --> Router Class Initialized
INFO - 2023-08-18 13:01:15 --> Output Class Initialized
INFO - 2023-08-18 13:01:15 --> Security Class Initialized
DEBUG - 2023-08-18 13:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 13:01:15 --> Input Class Initialized
INFO - 2023-08-18 13:01:15 --> Language Class Initialized
INFO - 2023-08-18 13:01:15 --> Loader Class Initialized
INFO - 2023-08-18 13:01:15 --> Helper loaded: url_helper
INFO - 2023-08-18 13:01:15 --> Helper loaded: file_helper
INFO - 2023-08-18 13:01:15 --> Helper loaded: html_helper
INFO - 2023-08-18 13:01:15 --> Helper loaded: text_helper
INFO - 2023-08-18 13:01:15 --> Helper loaded: form_helper
INFO - 2023-08-18 13:01:15 --> Helper loaded: lang_helper
INFO - 2023-08-18 13:01:15 --> Helper loaded: security_helper
INFO - 2023-08-18 13:01:15 --> Helper loaded: cookie_helper
INFO - 2023-08-18 13:01:15 --> Database Driver Class Initialized
INFO - 2023-08-18 13:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 13:01:15 --> Parser Class Initialized
INFO - 2023-08-18 13:01:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 13:01:15 --> Pagination Class Initialized
INFO - 2023-08-18 13:01:15 --> Form Validation Class Initialized
INFO - 2023-08-18 13:01:15 --> Controller Class Initialized
INFO - 2023-08-18 13:01:15 --> Model Class Initialized
DEBUG - 2023-08-18 13:01:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 13:01:15 --> Model Class Initialized
DEBUG - 2023-08-18 13:01:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 13:01:15 --> Model Class Initialized
INFO - 2023-08-18 13:01:15 --> Model Class Initialized
INFO - 2023-08-18 13:01:15 --> Model Class Initialized
INFO - 2023-08-18 13:01:15 --> Model Class Initialized
DEBUG - 2023-08-18 13:01:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 13:01:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 13:01:15 --> Model Class Initialized
INFO - 2023-08-18 13:01:15 --> Model Class Initialized
INFO - 2023-08-18 13:01:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-18 13:01:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 13:01:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 13:01:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 13:01:15 --> Model Class Initialized
INFO - 2023-08-18 13:01:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 13:01:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 13:01:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 13:01:15 --> Final output sent to browser
DEBUG - 2023-08-18 13:01:15 --> Total execution time: 0.0816
ERROR - 2023-08-18 13:01:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 13:01:26 --> Config Class Initialized
INFO - 2023-08-18 13:01:26 --> Hooks Class Initialized
DEBUG - 2023-08-18 13:01:26 --> UTF-8 Support Enabled
INFO - 2023-08-18 13:01:26 --> Utf8 Class Initialized
INFO - 2023-08-18 13:01:26 --> URI Class Initialized
INFO - 2023-08-18 13:01:26 --> Router Class Initialized
INFO - 2023-08-18 13:01:26 --> Output Class Initialized
INFO - 2023-08-18 13:01:26 --> Security Class Initialized
DEBUG - 2023-08-18 13:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 13:01:26 --> Input Class Initialized
INFO - 2023-08-18 13:01:26 --> Language Class Initialized
INFO - 2023-08-18 13:01:26 --> Loader Class Initialized
INFO - 2023-08-18 13:01:26 --> Helper loaded: url_helper
INFO - 2023-08-18 13:01:26 --> Helper loaded: file_helper
INFO - 2023-08-18 13:01:26 --> Helper loaded: html_helper
INFO - 2023-08-18 13:01:26 --> Helper loaded: text_helper
INFO - 2023-08-18 13:01:26 --> Helper loaded: form_helper
INFO - 2023-08-18 13:01:26 --> Helper loaded: lang_helper
INFO - 2023-08-18 13:01:26 --> Helper loaded: security_helper
INFO - 2023-08-18 13:01:26 --> Helper loaded: cookie_helper
INFO - 2023-08-18 13:01:26 --> Database Driver Class Initialized
INFO - 2023-08-18 13:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 13:01:26 --> Parser Class Initialized
INFO - 2023-08-18 13:01:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 13:01:26 --> Pagination Class Initialized
INFO - 2023-08-18 13:01:26 --> Form Validation Class Initialized
INFO - 2023-08-18 13:01:26 --> Controller Class Initialized
INFO - 2023-08-18 13:01:26 --> Model Class Initialized
INFO - 2023-08-18 13:01:26 --> Model Class Initialized
INFO - 2023-08-18 13:01:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-08-18 13:01:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 13:01:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 13:01:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 13:01:26 --> Model Class Initialized
INFO - 2023-08-18 13:01:26 --> Model Class Initialized
INFO - 2023-08-18 13:01:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 13:01:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 13:01:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 13:01:26 --> Final output sent to browser
DEBUG - 2023-08-18 13:01:26 --> Total execution time: 0.0644
ERROR - 2023-08-18 13:01:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 13:01:27 --> Config Class Initialized
INFO - 2023-08-18 13:01:27 --> Hooks Class Initialized
DEBUG - 2023-08-18 13:01:27 --> UTF-8 Support Enabled
INFO - 2023-08-18 13:01:27 --> Utf8 Class Initialized
INFO - 2023-08-18 13:01:27 --> URI Class Initialized
INFO - 2023-08-18 13:01:27 --> Router Class Initialized
INFO - 2023-08-18 13:01:27 --> Output Class Initialized
INFO - 2023-08-18 13:01:27 --> Security Class Initialized
DEBUG - 2023-08-18 13:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 13:01:27 --> Input Class Initialized
INFO - 2023-08-18 13:01:27 --> Language Class Initialized
INFO - 2023-08-18 13:01:27 --> Loader Class Initialized
INFO - 2023-08-18 13:01:27 --> Helper loaded: url_helper
INFO - 2023-08-18 13:01:27 --> Helper loaded: file_helper
INFO - 2023-08-18 13:01:27 --> Helper loaded: html_helper
INFO - 2023-08-18 13:01:27 --> Helper loaded: text_helper
INFO - 2023-08-18 13:01:27 --> Helper loaded: form_helper
INFO - 2023-08-18 13:01:27 --> Helper loaded: lang_helper
INFO - 2023-08-18 13:01:27 --> Helper loaded: security_helper
INFO - 2023-08-18 13:01:27 --> Helper loaded: cookie_helper
INFO - 2023-08-18 13:01:27 --> Database Driver Class Initialized
INFO - 2023-08-18 13:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 13:01:27 --> Parser Class Initialized
INFO - 2023-08-18 13:01:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 13:01:27 --> Pagination Class Initialized
INFO - 2023-08-18 13:01:27 --> Form Validation Class Initialized
INFO - 2023-08-18 13:01:27 --> Controller Class Initialized
INFO - 2023-08-18 13:01:27 --> Model Class Initialized
INFO - 2023-08-18 13:01:27 --> Model Class Initialized
INFO - 2023-08-18 13:01:27 --> Final output sent to browser
DEBUG - 2023-08-18 13:01:27 --> Total execution time: 0.0250
ERROR - 2023-08-18 13:02:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 13:02:19 --> Config Class Initialized
INFO - 2023-08-18 13:02:19 --> Hooks Class Initialized
DEBUG - 2023-08-18 13:02:19 --> UTF-8 Support Enabled
INFO - 2023-08-18 13:02:19 --> Utf8 Class Initialized
INFO - 2023-08-18 13:02:19 --> URI Class Initialized
DEBUG - 2023-08-18 13:02:19 --> No URI present. Default controller set.
INFO - 2023-08-18 13:02:19 --> Router Class Initialized
INFO - 2023-08-18 13:02:19 --> Output Class Initialized
INFO - 2023-08-18 13:02:19 --> Security Class Initialized
DEBUG - 2023-08-18 13:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 13:02:19 --> Input Class Initialized
INFO - 2023-08-18 13:02:19 --> Language Class Initialized
INFO - 2023-08-18 13:02:19 --> Loader Class Initialized
INFO - 2023-08-18 13:02:19 --> Helper loaded: url_helper
INFO - 2023-08-18 13:02:19 --> Helper loaded: file_helper
INFO - 2023-08-18 13:02:19 --> Helper loaded: html_helper
INFO - 2023-08-18 13:02:19 --> Helper loaded: text_helper
INFO - 2023-08-18 13:02:19 --> Helper loaded: form_helper
INFO - 2023-08-18 13:02:19 --> Helper loaded: lang_helper
INFO - 2023-08-18 13:02:19 --> Helper loaded: security_helper
INFO - 2023-08-18 13:02:19 --> Helper loaded: cookie_helper
INFO - 2023-08-18 13:02:19 --> Database Driver Class Initialized
INFO - 2023-08-18 13:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 13:02:19 --> Parser Class Initialized
INFO - 2023-08-18 13:02:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 13:02:19 --> Pagination Class Initialized
INFO - 2023-08-18 13:02:19 --> Form Validation Class Initialized
INFO - 2023-08-18 13:02:19 --> Controller Class Initialized
INFO - 2023-08-18 13:02:19 --> Model Class Initialized
DEBUG - 2023-08-18 13:02:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 13:02:19 --> Model Class Initialized
DEBUG - 2023-08-18 13:02:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 13:02:19 --> Model Class Initialized
INFO - 2023-08-18 13:02:19 --> Model Class Initialized
INFO - 2023-08-18 13:02:19 --> Model Class Initialized
INFO - 2023-08-18 13:02:19 --> Model Class Initialized
DEBUG - 2023-08-18 13:02:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 13:02:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 13:02:19 --> Model Class Initialized
INFO - 2023-08-18 13:02:19 --> Model Class Initialized
INFO - 2023-08-18 13:02:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-18 13:02:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 13:02:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 13:02:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 13:02:19 --> Model Class Initialized
INFO - 2023-08-18 13:02:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 13:02:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 13:02:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 13:02:19 --> Final output sent to browser
DEBUG - 2023-08-18 13:02:19 --> Total execution time: 0.0848
ERROR - 2023-08-18 13:02:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 13:02:25 --> Config Class Initialized
INFO - 2023-08-18 13:02:25 --> Hooks Class Initialized
DEBUG - 2023-08-18 13:02:25 --> UTF-8 Support Enabled
INFO - 2023-08-18 13:02:25 --> Utf8 Class Initialized
INFO - 2023-08-18 13:02:25 --> URI Class Initialized
INFO - 2023-08-18 13:02:25 --> Router Class Initialized
INFO - 2023-08-18 13:02:25 --> Output Class Initialized
INFO - 2023-08-18 13:02:25 --> Security Class Initialized
DEBUG - 2023-08-18 13:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 13:02:25 --> Input Class Initialized
INFO - 2023-08-18 13:02:25 --> Language Class Initialized
INFO - 2023-08-18 13:02:25 --> Loader Class Initialized
INFO - 2023-08-18 13:02:25 --> Helper loaded: url_helper
INFO - 2023-08-18 13:02:25 --> Helper loaded: file_helper
INFO - 2023-08-18 13:02:25 --> Helper loaded: html_helper
INFO - 2023-08-18 13:02:25 --> Helper loaded: text_helper
INFO - 2023-08-18 13:02:25 --> Helper loaded: form_helper
INFO - 2023-08-18 13:02:25 --> Helper loaded: lang_helper
INFO - 2023-08-18 13:02:25 --> Helper loaded: security_helper
INFO - 2023-08-18 13:02:25 --> Helper loaded: cookie_helper
INFO - 2023-08-18 13:02:25 --> Database Driver Class Initialized
INFO - 2023-08-18 13:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 13:02:25 --> Parser Class Initialized
INFO - 2023-08-18 13:02:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 13:02:25 --> Pagination Class Initialized
INFO - 2023-08-18 13:02:25 --> Form Validation Class Initialized
INFO - 2023-08-18 13:02:25 --> Controller Class Initialized
INFO - 2023-08-18 13:02:25 --> Model Class Initialized
INFO - 2023-08-18 13:02:25 --> Model Class Initialized
INFO - 2023-08-18 13:02:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2023-08-18 13:02:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 13:02:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 13:02:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 13:02:25 --> Model Class Initialized
INFO - 2023-08-18 13:02:25 --> Model Class Initialized
INFO - 2023-08-18 13:02:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 13:02:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 13:02:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 13:02:25 --> Final output sent to browser
DEBUG - 2023-08-18 13:02:25 --> Total execution time: 0.0653
ERROR - 2023-08-18 13:02:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 13:02:26 --> Config Class Initialized
INFO - 2023-08-18 13:02:26 --> Hooks Class Initialized
DEBUG - 2023-08-18 13:02:26 --> UTF-8 Support Enabled
INFO - 2023-08-18 13:02:26 --> Utf8 Class Initialized
INFO - 2023-08-18 13:02:26 --> URI Class Initialized
INFO - 2023-08-18 13:02:26 --> Router Class Initialized
INFO - 2023-08-18 13:02:26 --> Output Class Initialized
INFO - 2023-08-18 13:02:26 --> Security Class Initialized
DEBUG - 2023-08-18 13:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 13:02:26 --> Input Class Initialized
INFO - 2023-08-18 13:02:26 --> Language Class Initialized
INFO - 2023-08-18 13:02:26 --> Loader Class Initialized
INFO - 2023-08-18 13:02:26 --> Helper loaded: url_helper
INFO - 2023-08-18 13:02:26 --> Helper loaded: file_helper
INFO - 2023-08-18 13:02:26 --> Helper loaded: html_helper
INFO - 2023-08-18 13:02:26 --> Helper loaded: text_helper
INFO - 2023-08-18 13:02:26 --> Helper loaded: form_helper
INFO - 2023-08-18 13:02:26 --> Helper loaded: lang_helper
INFO - 2023-08-18 13:02:26 --> Helper loaded: security_helper
INFO - 2023-08-18 13:02:26 --> Helper loaded: cookie_helper
INFO - 2023-08-18 13:02:26 --> Database Driver Class Initialized
INFO - 2023-08-18 13:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 13:02:26 --> Parser Class Initialized
INFO - 2023-08-18 13:02:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 13:02:26 --> Pagination Class Initialized
INFO - 2023-08-18 13:02:26 --> Form Validation Class Initialized
INFO - 2023-08-18 13:02:26 --> Controller Class Initialized
INFO - 2023-08-18 13:02:26 --> Model Class Initialized
INFO - 2023-08-18 13:02:26 --> Model Class Initialized
INFO - 2023-08-18 13:02:26 --> Final output sent to browser
DEBUG - 2023-08-18 13:02:26 --> Total execution time: 0.0427
ERROR - 2023-08-18 13:02:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 13:02:30 --> Config Class Initialized
INFO - 2023-08-18 13:02:30 --> Hooks Class Initialized
DEBUG - 2023-08-18 13:02:30 --> UTF-8 Support Enabled
INFO - 2023-08-18 13:02:30 --> Utf8 Class Initialized
INFO - 2023-08-18 13:02:30 --> URI Class Initialized
DEBUG - 2023-08-18 13:02:30 --> No URI present. Default controller set.
INFO - 2023-08-18 13:02:30 --> Router Class Initialized
INFO - 2023-08-18 13:02:30 --> Output Class Initialized
INFO - 2023-08-18 13:02:30 --> Security Class Initialized
DEBUG - 2023-08-18 13:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 13:02:30 --> Input Class Initialized
INFO - 2023-08-18 13:02:30 --> Language Class Initialized
INFO - 2023-08-18 13:02:30 --> Loader Class Initialized
INFO - 2023-08-18 13:02:30 --> Helper loaded: url_helper
INFO - 2023-08-18 13:02:30 --> Helper loaded: file_helper
INFO - 2023-08-18 13:02:30 --> Helper loaded: html_helper
INFO - 2023-08-18 13:02:30 --> Helper loaded: text_helper
INFO - 2023-08-18 13:02:30 --> Helper loaded: form_helper
INFO - 2023-08-18 13:02:30 --> Helper loaded: lang_helper
INFO - 2023-08-18 13:02:30 --> Helper loaded: security_helper
INFO - 2023-08-18 13:02:30 --> Helper loaded: cookie_helper
INFO - 2023-08-18 13:02:30 --> Database Driver Class Initialized
INFO - 2023-08-18 13:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 13:02:30 --> Parser Class Initialized
INFO - 2023-08-18 13:02:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 13:02:30 --> Pagination Class Initialized
INFO - 2023-08-18 13:02:30 --> Form Validation Class Initialized
INFO - 2023-08-18 13:02:30 --> Controller Class Initialized
INFO - 2023-08-18 13:02:30 --> Model Class Initialized
DEBUG - 2023-08-18 13:02:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 13:02:30 --> Model Class Initialized
DEBUG - 2023-08-18 13:02:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 13:02:30 --> Model Class Initialized
INFO - 2023-08-18 13:02:30 --> Model Class Initialized
INFO - 2023-08-18 13:02:30 --> Model Class Initialized
INFO - 2023-08-18 13:02:30 --> Model Class Initialized
DEBUG - 2023-08-18 13:02:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 13:02:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 13:02:30 --> Model Class Initialized
INFO - 2023-08-18 13:02:30 --> Model Class Initialized
INFO - 2023-08-18 13:02:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-18 13:02:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 13:02:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 13:02:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 13:02:30 --> Model Class Initialized
INFO - 2023-08-18 13:02:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 13:02:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 13:02:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 13:02:30 --> Final output sent to browser
DEBUG - 2023-08-18 13:02:30 --> Total execution time: 0.0791
ERROR - 2023-08-18 13:02:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 13:02:47 --> Config Class Initialized
INFO - 2023-08-18 13:02:47 --> Hooks Class Initialized
DEBUG - 2023-08-18 13:02:47 --> UTF-8 Support Enabled
INFO - 2023-08-18 13:02:47 --> Utf8 Class Initialized
INFO - 2023-08-18 13:02:47 --> URI Class Initialized
INFO - 2023-08-18 13:02:47 --> Router Class Initialized
INFO - 2023-08-18 13:02:47 --> Output Class Initialized
INFO - 2023-08-18 13:02:47 --> Security Class Initialized
DEBUG - 2023-08-18 13:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 13:02:47 --> Input Class Initialized
INFO - 2023-08-18 13:02:47 --> Language Class Initialized
INFO - 2023-08-18 13:02:47 --> Loader Class Initialized
INFO - 2023-08-18 13:02:47 --> Helper loaded: url_helper
INFO - 2023-08-18 13:02:47 --> Helper loaded: file_helper
INFO - 2023-08-18 13:02:47 --> Helper loaded: html_helper
INFO - 2023-08-18 13:02:47 --> Helper loaded: text_helper
INFO - 2023-08-18 13:02:47 --> Helper loaded: form_helper
INFO - 2023-08-18 13:02:47 --> Helper loaded: lang_helper
INFO - 2023-08-18 13:02:47 --> Helper loaded: security_helper
INFO - 2023-08-18 13:02:47 --> Helper loaded: cookie_helper
INFO - 2023-08-18 13:02:47 --> Database Driver Class Initialized
INFO - 2023-08-18 13:02:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 13:02:47 --> Parser Class Initialized
INFO - 2023-08-18 13:02:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 13:02:47 --> Pagination Class Initialized
INFO - 2023-08-18 13:02:47 --> Form Validation Class Initialized
INFO - 2023-08-18 13:02:47 --> Controller Class Initialized
DEBUG - 2023-08-18 13:02:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 13:02:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 13:02:47 --> Model Class Initialized
DEBUG - 2023-08-18 13:02:47 --> Lgift class already loaded. Second attempt ignored.
INFO - 2023-08-18 13:02:47 --> Model Class Initialized
DEBUG - 2023-08-18 13:02:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 13:02:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 13:02:47 --> Model Class Initialized
DEBUG - 2023-08-18 13:02:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 13:02:47 --> Model Class Initialized
INFO - 2023-08-18 13:02:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/gift.php
DEBUG - 2023-08-18 13:02:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 13:02:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 13:02:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 13:02:47 --> Model Class Initialized
INFO - 2023-08-18 13:02:47 --> Model Class Initialized
INFO - 2023-08-18 13:02:47 --> Model Class Initialized
INFO - 2023-08-18 13:02:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 13:02:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 13:02:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 13:02:47 --> Final output sent to browser
DEBUG - 2023-08-18 13:02:47 --> Total execution time: 0.0742
ERROR - 2023-08-18 13:02:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 13:02:48 --> Config Class Initialized
INFO - 2023-08-18 13:02:48 --> Hooks Class Initialized
DEBUG - 2023-08-18 13:02:48 --> UTF-8 Support Enabled
INFO - 2023-08-18 13:02:48 --> Utf8 Class Initialized
INFO - 2023-08-18 13:02:48 --> URI Class Initialized
INFO - 2023-08-18 13:02:48 --> Router Class Initialized
INFO - 2023-08-18 13:02:48 --> Output Class Initialized
INFO - 2023-08-18 13:02:48 --> Security Class Initialized
DEBUG - 2023-08-18 13:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 13:02:48 --> Input Class Initialized
INFO - 2023-08-18 13:02:48 --> Language Class Initialized
INFO - 2023-08-18 13:02:48 --> Loader Class Initialized
INFO - 2023-08-18 13:02:48 --> Helper loaded: url_helper
INFO - 2023-08-18 13:02:48 --> Helper loaded: file_helper
INFO - 2023-08-18 13:02:48 --> Helper loaded: html_helper
INFO - 2023-08-18 13:02:48 --> Helper loaded: text_helper
INFO - 2023-08-18 13:02:48 --> Helper loaded: form_helper
INFO - 2023-08-18 13:02:48 --> Helper loaded: lang_helper
INFO - 2023-08-18 13:02:48 --> Helper loaded: security_helper
INFO - 2023-08-18 13:02:48 --> Helper loaded: cookie_helper
INFO - 2023-08-18 13:02:48 --> Database Driver Class Initialized
INFO - 2023-08-18 13:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 13:02:48 --> Parser Class Initialized
INFO - 2023-08-18 13:02:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 13:02:48 --> Pagination Class Initialized
INFO - 2023-08-18 13:02:48 --> Form Validation Class Initialized
INFO - 2023-08-18 13:02:48 --> Controller Class Initialized
DEBUG - 2023-08-18 13:02:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 13:02:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 13:02:48 --> Model Class Initialized
INFO - 2023-08-18 13:02:48 --> Final output sent to browser
DEBUG - 2023-08-18 13:02:48 --> Total execution time: 0.0177
ERROR - 2023-08-18 13:09:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 13:09:57 --> Config Class Initialized
INFO - 2023-08-18 13:09:57 --> Hooks Class Initialized
DEBUG - 2023-08-18 13:09:57 --> UTF-8 Support Enabled
INFO - 2023-08-18 13:09:57 --> Utf8 Class Initialized
INFO - 2023-08-18 13:09:57 --> URI Class Initialized
DEBUG - 2023-08-18 13:09:57 --> No URI present. Default controller set.
INFO - 2023-08-18 13:09:57 --> Router Class Initialized
INFO - 2023-08-18 13:09:57 --> Output Class Initialized
INFO - 2023-08-18 13:09:57 --> Security Class Initialized
DEBUG - 2023-08-18 13:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 13:09:57 --> Input Class Initialized
INFO - 2023-08-18 13:09:57 --> Language Class Initialized
INFO - 2023-08-18 13:09:57 --> Loader Class Initialized
INFO - 2023-08-18 13:09:57 --> Helper loaded: url_helper
INFO - 2023-08-18 13:09:57 --> Helper loaded: file_helper
INFO - 2023-08-18 13:09:57 --> Helper loaded: html_helper
INFO - 2023-08-18 13:09:57 --> Helper loaded: text_helper
INFO - 2023-08-18 13:09:57 --> Helper loaded: form_helper
INFO - 2023-08-18 13:09:57 --> Helper loaded: lang_helper
INFO - 2023-08-18 13:09:57 --> Helper loaded: security_helper
INFO - 2023-08-18 13:09:57 --> Helper loaded: cookie_helper
INFO - 2023-08-18 13:09:57 --> Database Driver Class Initialized
INFO - 2023-08-18 13:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 13:09:57 --> Parser Class Initialized
INFO - 2023-08-18 13:09:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 13:09:57 --> Pagination Class Initialized
INFO - 2023-08-18 13:09:57 --> Form Validation Class Initialized
INFO - 2023-08-18 13:09:57 --> Controller Class Initialized
INFO - 2023-08-18 13:09:57 --> Model Class Initialized
DEBUG - 2023-08-18 13:09:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 13:09:57 --> Model Class Initialized
DEBUG - 2023-08-18 13:09:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 13:09:57 --> Model Class Initialized
INFO - 2023-08-18 13:09:57 --> Model Class Initialized
INFO - 2023-08-18 13:09:57 --> Model Class Initialized
INFO - 2023-08-18 13:09:57 --> Model Class Initialized
DEBUG - 2023-08-18 13:09:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 13:09:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 13:09:57 --> Model Class Initialized
INFO - 2023-08-18 13:09:57 --> Model Class Initialized
INFO - 2023-08-18 13:09:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-18 13:09:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 13:09:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 13:09:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 13:09:57 --> Model Class Initialized
INFO - 2023-08-18 13:09:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 13:09:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 13:09:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 13:09:57 --> Final output sent to browser
DEBUG - 2023-08-18 13:09:57 --> Total execution time: 0.0852
ERROR - 2023-08-18 14:28:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 14:28:01 --> Config Class Initialized
INFO - 2023-08-18 14:28:01 --> Hooks Class Initialized
DEBUG - 2023-08-18 14:28:01 --> UTF-8 Support Enabled
INFO - 2023-08-18 14:28:01 --> Utf8 Class Initialized
INFO - 2023-08-18 14:28:01 --> URI Class Initialized
DEBUG - 2023-08-18 14:28:01 --> No URI present. Default controller set.
INFO - 2023-08-18 14:28:01 --> Router Class Initialized
INFO - 2023-08-18 14:28:01 --> Output Class Initialized
INFO - 2023-08-18 14:28:01 --> Security Class Initialized
DEBUG - 2023-08-18 14:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 14:28:01 --> Input Class Initialized
INFO - 2023-08-18 14:28:01 --> Language Class Initialized
INFO - 2023-08-18 14:28:01 --> Loader Class Initialized
INFO - 2023-08-18 14:28:01 --> Helper loaded: url_helper
INFO - 2023-08-18 14:28:01 --> Helper loaded: file_helper
INFO - 2023-08-18 14:28:01 --> Helper loaded: html_helper
INFO - 2023-08-18 14:28:01 --> Helper loaded: text_helper
INFO - 2023-08-18 14:28:01 --> Helper loaded: form_helper
INFO - 2023-08-18 14:28:01 --> Helper loaded: lang_helper
INFO - 2023-08-18 14:28:01 --> Helper loaded: security_helper
INFO - 2023-08-18 14:28:01 --> Helper loaded: cookie_helper
INFO - 2023-08-18 14:28:01 --> Database Driver Class Initialized
INFO - 2023-08-18 14:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 14:28:01 --> Parser Class Initialized
INFO - 2023-08-18 14:28:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 14:28:01 --> Pagination Class Initialized
INFO - 2023-08-18 14:28:01 --> Form Validation Class Initialized
INFO - 2023-08-18 14:28:01 --> Controller Class Initialized
INFO - 2023-08-18 14:28:01 --> Model Class Initialized
DEBUG - 2023-08-18 14:28:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-18 14:28:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 14:28:01 --> Config Class Initialized
INFO - 2023-08-18 14:28:01 --> Hooks Class Initialized
DEBUG - 2023-08-18 14:28:01 --> UTF-8 Support Enabled
INFO - 2023-08-18 14:28:01 --> Utf8 Class Initialized
INFO - 2023-08-18 14:28:01 --> URI Class Initialized
INFO - 2023-08-18 14:28:01 --> Router Class Initialized
INFO - 2023-08-18 14:28:01 --> Output Class Initialized
INFO - 2023-08-18 14:28:01 --> Security Class Initialized
DEBUG - 2023-08-18 14:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 14:28:01 --> Input Class Initialized
INFO - 2023-08-18 14:28:01 --> Language Class Initialized
INFO - 2023-08-18 14:28:01 --> Loader Class Initialized
INFO - 2023-08-18 14:28:01 --> Helper loaded: url_helper
INFO - 2023-08-18 14:28:01 --> Helper loaded: file_helper
INFO - 2023-08-18 14:28:01 --> Helper loaded: html_helper
INFO - 2023-08-18 14:28:01 --> Helper loaded: text_helper
INFO - 2023-08-18 14:28:01 --> Helper loaded: form_helper
INFO - 2023-08-18 14:28:01 --> Helper loaded: lang_helper
INFO - 2023-08-18 14:28:01 --> Helper loaded: security_helper
INFO - 2023-08-18 14:28:01 --> Helper loaded: cookie_helper
INFO - 2023-08-18 14:28:01 --> Database Driver Class Initialized
INFO - 2023-08-18 14:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 14:28:01 --> Parser Class Initialized
INFO - 2023-08-18 14:28:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 14:28:01 --> Pagination Class Initialized
INFO - 2023-08-18 14:28:01 --> Form Validation Class Initialized
INFO - 2023-08-18 14:28:01 --> Controller Class Initialized
INFO - 2023-08-18 14:28:01 --> Model Class Initialized
DEBUG - 2023-08-18 14:28:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 14:28:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-18 14:28:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 14:28:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 14:28:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 14:28:01 --> Model Class Initialized
INFO - 2023-08-18 14:28:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 14:28:01 --> Final output sent to browser
DEBUG - 2023-08-18 14:28:01 --> Total execution time: 0.0372
ERROR - 2023-08-18 14:28:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 14:28:19 --> Config Class Initialized
INFO - 2023-08-18 14:28:19 --> Hooks Class Initialized
DEBUG - 2023-08-18 14:28:19 --> UTF-8 Support Enabled
INFO - 2023-08-18 14:28:19 --> Utf8 Class Initialized
INFO - 2023-08-18 14:28:19 --> URI Class Initialized
INFO - 2023-08-18 14:28:19 --> Router Class Initialized
INFO - 2023-08-18 14:28:19 --> Output Class Initialized
INFO - 2023-08-18 14:28:19 --> Security Class Initialized
DEBUG - 2023-08-18 14:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 14:28:19 --> Input Class Initialized
INFO - 2023-08-18 14:28:19 --> Language Class Initialized
INFO - 2023-08-18 14:28:19 --> Loader Class Initialized
INFO - 2023-08-18 14:28:19 --> Helper loaded: url_helper
INFO - 2023-08-18 14:28:19 --> Helper loaded: file_helper
INFO - 2023-08-18 14:28:19 --> Helper loaded: html_helper
INFO - 2023-08-18 14:28:19 --> Helper loaded: text_helper
INFO - 2023-08-18 14:28:19 --> Helper loaded: form_helper
INFO - 2023-08-18 14:28:19 --> Helper loaded: lang_helper
INFO - 2023-08-18 14:28:19 --> Helper loaded: security_helper
INFO - 2023-08-18 14:28:19 --> Helper loaded: cookie_helper
INFO - 2023-08-18 14:28:19 --> Database Driver Class Initialized
INFO - 2023-08-18 14:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 14:28:19 --> Parser Class Initialized
INFO - 2023-08-18 14:28:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 14:28:19 --> Pagination Class Initialized
INFO - 2023-08-18 14:28:19 --> Form Validation Class Initialized
INFO - 2023-08-18 14:28:19 --> Controller Class Initialized
INFO - 2023-08-18 14:28:19 --> Model Class Initialized
DEBUG - 2023-08-18 14:28:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 14:28:19 --> Model Class Initialized
INFO - 2023-08-18 14:28:19 --> Final output sent to browser
DEBUG - 2023-08-18 14:28:19 --> Total execution time: 0.0200
ERROR - 2023-08-18 14:28:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 14:28:20 --> Config Class Initialized
INFO - 2023-08-18 14:28:20 --> Hooks Class Initialized
DEBUG - 2023-08-18 14:28:20 --> UTF-8 Support Enabled
INFO - 2023-08-18 14:28:20 --> Utf8 Class Initialized
INFO - 2023-08-18 14:28:20 --> URI Class Initialized
DEBUG - 2023-08-18 14:28:20 --> No URI present. Default controller set.
INFO - 2023-08-18 14:28:20 --> Router Class Initialized
INFO - 2023-08-18 14:28:20 --> Output Class Initialized
INFO - 2023-08-18 14:28:20 --> Security Class Initialized
DEBUG - 2023-08-18 14:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 14:28:20 --> Input Class Initialized
INFO - 2023-08-18 14:28:20 --> Language Class Initialized
INFO - 2023-08-18 14:28:20 --> Loader Class Initialized
INFO - 2023-08-18 14:28:20 --> Helper loaded: url_helper
INFO - 2023-08-18 14:28:20 --> Helper loaded: file_helper
INFO - 2023-08-18 14:28:20 --> Helper loaded: html_helper
INFO - 2023-08-18 14:28:20 --> Helper loaded: text_helper
INFO - 2023-08-18 14:28:20 --> Helper loaded: form_helper
INFO - 2023-08-18 14:28:20 --> Helper loaded: lang_helper
INFO - 2023-08-18 14:28:20 --> Helper loaded: security_helper
INFO - 2023-08-18 14:28:20 --> Helper loaded: cookie_helper
INFO - 2023-08-18 14:28:20 --> Database Driver Class Initialized
INFO - 2023-08-18 14:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 14:28:20 --> Parser Class Initialized
INFO - 2023-08-18 14:28:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 14:28:20 --> Pagination Class Initialized
INFO - 2023-08-18 14:28:20 --> Form Validation Class Initialized
INFO - 2023-08-18 14:28:20 --> Controller Class Initialized
INFO - 2023-08-18 14:28:20 --> Model Class Initialized
DEBUG - 2023-08-18 14:28:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 14:28:20 --> Model Class Initialized
DEBUG - 2023-08-18 14:28:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 14:28:20 --> Model Class Initialized
INFO - 2023-08-18 14:28:20 --> Model Class Initialized
INFO - 2023-08-18 14:28:20 --> Model Class Initialized
INFO - 2023-08-18 14:28:20 --> Model Class Initialized
DEBUG - 2023-08-18 14:28:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 14:28:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 14:28:20 --> Model Class Initialized
INFO - 2023-08-18 14:28:20 --> Model Class Initialized
INFO - 2023-08-18 14:28:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-18 14:28:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 14:28:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 14:28:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 14:28:20 --> Model Class Initialized
INFO - 2023-08-18 14:28:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 14:28:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 14:28:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 14:28:20 --> Final output sent to browser
DEBUG - 2023-08-18 14:28:20 --> Total execution time: 0.0822
ERROR - 2023-08-18 14:28:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 14:28:30 --> Config Class Initialized
INFO - 2023-08-18 14:28:30 --> Hooks Class Initialized
DEBUG - 2023-08-18 14:28:30 --> UTF-8 Support Enabled
INFO - 2023-08-18 14:28:30 --> Utf8 Class Initialized
INFO - 2023-08-18 14:28:30 --> URI Class Initialized
INFO - 2023-08-18 14:28:30 --> Router Class Initialized
INFO - 2023-08-18 14:28:30 --> Output Class Initialized
INFO - 2023-08-18 14:28:30 --> Security Class Initialized
DEBUG - 2023-08-18 14:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 14:28:30 --> Input Class Initialized
INFO - 2023-08-18 14:28:30 --> Language Class Initialized
INFO - 2023-08-18 14:28:30 --> Loader Class Initialized
INFO - 2023-08-18 14:28:30 --> Helper loaded: url_helper
INFO - 2023-08-18 14:28:30 --> Helper loaded: file_helper
INFO - 2023-08-18 14:28:30 --> Helper loaded: html_helper
INFO - 2023-08-18 14:28:30 --> Helper loaded: text_helper
INFO - 2023-08-18 14:28:30 --> Helper loaded: form_helper
INFO - 2023-08-18 14:28:30 --> Helper loaded: lang_helper
INFO - 2023-08-18 14:28:30 --> Helper loaded: security_helper
INFO - 2023-08-18 14:28:30 --> Helper loaded: cookie_helper
INFO - 2023-08-18 14:28:30 --> Database Driver Class Initialized
INFO - 2023-08-18 14:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 14:28:30 --> Parser Class Initialized
INFO - 2023-08-18 14:28:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 14:28:30 --> Pagination Class Initialized
INFO - 2023-08-18 14:28:30 --> Form Validation Class Initialized
INFO - 2023-08-18 14:28:30 --> Controller Class Initialized
INFO - 2023-08-18 14:28:30 --> Model Class Initialized
DEBUG - 2023-08-18 14:28:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 14:28:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 14:28:30 --> Model Class Initialized
DEBUG - 2023-08-18 14:28:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 14:28:30 --> Model Class Initialized
INFO - 2023-08-18 14:28:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-18 14:28:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 14:28:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 14:28:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 14:28:30 --> Model Class Initialized
INFO - 2023-08-18 14:28:30 --> Model Class Initialized
INFO - 2023-08-18 14:28:30 --> Model Class Initialized
INFO - 2023-08-18 14:28:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 14:28:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 14:28:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 14:28:30 --> Final output sent to browser
DEBUG - 2023-08-18 14:28:30 --> Total execution time: 0.0664
ERROR - 2023-08-18 14:28:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 14:28:31 --> Config Class Initialized
INFO - 2023-08-18 14:28:31 --> Hooks Class Initialized
DEBUG - 2023-08-18 14:28:31 --> UTF-8 Support Enabled
INFO - 2023-08-18 14:28:31 --> Utf8 Class Initialized
INFO - 2023-08-18 14:28:31 --> URI Class Initialized
INFO - 2023-08-18 14:28:31 --> Router Class Initialized
INFO - 2023-08-18 14:28:31 --> Output Class Initialized
INFO - 2023-08-18 14:28:31 --> Security Class Initialized
DEBUG - 2023-08-18 14:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 14:28:31 --> Input Class Initialized
INFO - 2023-08-18 14:28:31 --> Language Class Initialized
INFO - 2023-08-18 14:28:31 --> Loader Class Initialized
INFO - 2023-08-18 14:28:31 --> Helper loaded: url_helper
INFO - 2023-08-18 14:28:31 --> Helper loaded: file_helper
INFO - 2023-08-18 14:28:31 --> Helper loaded: html_helper
INFO - 2023-08-18 14:28:31 --> Helper loaded: text_helper
INFO - 2023-08-18 14:28:31 --> Helper loaded: form_helper
INFO - 2023-08-18 14:28:31 --> Helper loaded: lang_helper
INFO - 2023-08-18 14:28:31 --> Helper loaded: security_helper
INFO - 2023-08-18 14:28:31 --> Helper loaded: cookie_helper
INFO - 2023-08-18 14:28:31 --> Database Driver Class Initialized
INFO - 2023-08-18 14:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 14:28:31 --> Parser Class Initialized
INFO - 2023-08-18 14:28:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 14:28:31 --> Pagination Class Initialized
INFO - 2023-08-18 14:28:31 --> Form Validation Class Initialized
INFO - 2023-08-18 14:28:31 --> Controller Class Initialized
INFO - 2023-08-18 14:28:31 --> Model Class Initialized
DEBUG - 2023-08-18 14:28:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 14:28:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 14:28:31 --> Model Class Initialized
DEBUG - 2023-08-18 14:28:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 14:28:31 --> Model Class Initialized
INFO - 2023-08-18 14:28:31 --> Final output sent to browser
DEBUG - 2023-08-18 14:28:31 --> Total execution time: 0.0262
ERROR - 2023-08-18 15:30:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:30:31 --> Config Class Initialized
INFO - 2023-08-18 15:30:31 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:30:31 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:30:31 --> Utf8 Class Initialized
INFO - 2023-08-18 15:30:31 --> URI Class Initialized
DEBUG - 2023-08-18 15:30:31 --> No URI present. Default controller set.
INFO - 2023-08-18 15:30:31 --> Router Class Initialized
INFO - 2023-08-18 15:30:31 --> Output Class Initialized
INFO - 2023-08-18 15:30:31 --> Security Class Initialized
DEBUG - 2023-08-18 15:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:30:31 --> Input Class Initialized
INFO - 2023-08-18 15:30:31 --> Language Class Initialized
INFO - 2023-08-18 15:30:31 --> Loader Class Initialized
INFO - 2023-08-18 15:30:31 --> Helper loaded: url_helper
INFO - 2023-08-18 15:30:31 --> Helper loaded: file_helper
INFO - 2023-08-18 15:30:31 --> Helper loaded: html_helper
INFO - 2023-08-18 15:30:31 --> Helper loaded: text_helper
INFO - 2023-08-18 15:30:31 --> Helper loaded: form_helper
INFO - 2023-08-18 15:30:31 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:30:31 --> Helper loaded: security_helper
INFO - 2023-08-18 15:30:31 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:30:31 --> Database Driver Class Initialized
INFO - 2023-08-18 15:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:30:31 --> Parser Class Initialized
INFO - 2023-08-18 15:30:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:30:31 --> Pagination Class Initialized
INFO - 2023-08-18 15:30:31 --> Form Validation Class Initialized
INFO - 2023-08-18 15:30:31 --> Controller Class Initialized
INFO - 2023-08-18 15:30:31 --> Model Class Initialized
DEBUG - 2023-08-18 15:30:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-18 15:30:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:30:31 --> Config Class Initialized
INFO - 2023-08-18 15:30:31 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:30:31 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:30:31 --> Utf8 Class Initialized
INFO - 2023-08-18 15:30:31 --> URI Class Initialized
INFO - 2023-08-18 15:30:31 --> Router Class Initialized
INFO - 2023-08-18 15:30:31 --> Output Class Initialized
INFO - 2023-08-18 15:30:31 --> Security Class Initialized
DEBUG - 2023-08-18 15:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:30:31 --> Input Class Initialized
INFO - 2023-08-18 15:30:31 --> Language Class Initialized
INFO - 2023-08-18 15:30:31 --> Loader Class Initialized
INFO - 2023-08-18 15:30:31 --> Helper loaded: url_helper
INFO - 2023-08-18 15:30:31 --> Helper loaded: file_helper
INFO - 2023-08-18 15:30:31 --> Helper loaded: html_helper
INFO - 2023-08-18 15:30:31 --> Helper loaded: text_helper
INFO - 2023-08-18 15:30:31 --> Helper loaded: form_helper
INFO - 2023-08-18 15:30:31 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:30:31 --> Helper loaded: security_helper
INFO - 2023-08-18 15:30:31 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:30:31 --> Database Driver Class Initialized
INFO - 2023-08-18 15:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:30:31 --> Parser Class Initialized
INFO - 2023-08-18 15:30:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:30:31 --> Pagination Class Initialized
INFO - 2023-08-18 15:30:31 --> Form Validation Class Initialized
INFO - 2023-08-18 15:30:31 --> Controller Class Initialized
INFO - 2023-08-18 15:30:31 --> Model Class Initialized
DEBUG - 2023-08-18 15:30:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:30:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-18 15:30:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:30:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 15:30:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 15:30:31 --> Model Class Initialized
INFO - 2023-08-18 15:30:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 15:30:31 --> Final output sent to browser
DEBUG - 2023-08-18 15:30:31 --> Total execution time: 0.0310
ERROR - 2023-08-18 15:34:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:34:05 --> Config Class Initialized
INFO - 2023-08-18 15:34:05 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:34:05 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:34:05 --> Utf8 Class Initialized
INFO - 2023-08-18 15:34:05 --> URI Class Initialized
DEBUG - 2023-08-18 15:34:05 --> No URI present. Default controller set.
INFO - 2023-08-18 15:34:05 --> Router Class Initialized
INFO - 2023-08-18 15:34:05 --> Output Class Initialized
INFO - 2023-08-18 15:34:05 --> Security Class Initialized
DEBUG - 2023-08-18 15:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:34:05 --> Input Class Initialized
INFO - 2023-08-18 15:34:05 --> Language Class Initialized
INFO - 2023-08-18 15:34:05 --> Loader Class Initialized
INFO - 2023-08-18 15:34:05 --> Helper loaded: url_helper
INFO - 2023-08-18 15:34:05 --> Helper loaded: file_helper
INFO - 2023-08-18 15:34:05 --> Helper loaded: html_helper
INFO - 2023-08-18 15:34:05 --> Helper loaded: text_helper
INFO - 2023-08-18 15:34:05 --> Helper loaded: form_helper
INFO - 2023-08-18 15:34:05 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:34:05 --> Helper loaded: security_helper
INFO - 2023-08-18 15:34:05 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:34:05 --> Database Driver Class Initialized
INFO - 2023-08-18 15:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:34:05 --> Parser Class Initialized
INFO - 2023-08-18 15:34:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:34:05 --> Pagination Class Initialized
INFO - 2023-08-18 15:34:05 --> Form Validation Class Initialized
INFO - 2023-08-18 15:34:05 --> Controller Class Initialized
INFO - 2023-08-18 15:34:05 --> Model Class Initialized
DEBUG - 2023-08-18 15:34:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-18 15:34:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:34:06 --> Config Class Initialized
INFO - 2023-08-18 15:34:06 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:34:06 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:34:06 --> Utf8 Class Initialized
INFO - 2023-08-18 15:34:06 --> URI Class Initialized
INFO - 2023-08-18 15:34:06 --> Router Class Initialized
INFO - 2023-08-18 15:34:06 --> Output Class Initialized
INFO - 2023-08-18 15:34:06 --> Security Class Initialized
DEBUG - 2023-08-18 15:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:34:06 --> Input Class Initialized
INFO - 2023-08-18 15:34:06 --> Language Class Initialized
INFO - 2023-08-18 15:34:06 --> Loader Class Initialized
INFO - 2023-08-18 15:34:06 --> Helper loaded: url_helper
INFO - 2023-08-18 15:34:06 --> Helper loaded: file_helper
INFO - 2023-08-18 15:34:06 --> Helper loaded: html_helper
INFO - 2023-08-18 15:34:06 --> Helper loaded: text_helper
INFO - 2023-08-18 15:34:06 --> Helper loaded: form_helper
INFO - 2023-08-18 15:34:06 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:34:06 --> Helper loaded: security_helper
INFO - 2023-08-18 15:34:06 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:34:06 --> Database Driver Class Initialized
INFO - 2023-08-18 15:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:34:06 --> Parser Class Initialized
INFO - 2023-08-18 15:34:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:34:06 --> Pagination Class Initialized
INFO - 2023-08-18 15:34:06 --> Form Validation Class Initialized
INFO - 2023-08-18 15:34:06 --> Controller Class Initialized
INFO - 2023-08-18 15:34:06 --> Model Class Initialized
DEBUG - 2023-08-18 15:34:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:34:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-18 15:34:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:34:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 15:34:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 15:34:06 --> Model Class Initialized
INFO - 2023-08-18 15:34:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 15:34:06 --> Final output sent to browser
DEBUG - 2023-08-18 15:34:06 --> Total execution time: 0.0402
ERROR - 2023-08-18 15:34:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:34:23 --> Config Class Initialized
INFO - 2023-08-18 15:34:23 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:34:23 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:34:23 --> Utf8 Class Initialized
INFO - 2023-08-18 15:34:23 --> URI Class Initialized
INFO - 2023-08-18 15:34:23 --> Router Class Initialized
INFO - 2023-08-18 15:34:23 --> Output Class Initialized
INFO - 2023-08-18 15:34:23 --> Security Class Initialized
DEBUG - 2023-08-18 15:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:34:23 --> Input Class Initialized
INFO - 2023-08-18 15:34:23 --> Language Class Initialized
INFO - 2023-08-18 15:34:23 --> Loader Class Initialized
INFO - 2023-08-18 15:34:23 --> Helper loaded: url_helper
INFO - 2023-08-18 15:34:23 --> Helper loaded: file_helper
INFO - 2023-08-18 15:34:23 --> Helper loaded: html_helper
INFO - 2023-08-18 15:34:23 --> Helper loaded: text_helper
INFO - 2023-08-18 15:34:23 --> Helper loaded: form_helper
INFO - 2023-08-18 15:34:23 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:34:23 --> Helper loaded: security_helper
INFO - 2023-08-18 15:34:23 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:34:23 --> Database Driver Class Initialized
INFO - 2023-08-18 15:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:34:23 --> Parser Class Initialized
INFO - 2023-08-18 15:34:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:34:23 --> Pagination Class Initialized
INFO - 2023-08-18 15:34:23 --> Form Validation Class Initialized
INFO - 2023-08-18 15:34:23 --> Controller Class Initialized
INFO - 2023-08-18 15:34:23 --> Model Class Initialized
DEBUG - 2023-08-18 15:34:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:34:23 --> Model Class Initialized
INFO - 2023-08-18 15:34:23 --> Final output sent to browser
DEBUG - 2023-08-18 15:34:23 --> Total execution time: 0.0195
ERROR - 2023-08-18 15:34:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:34:23 --> Config Class Initialized
INFO - 2023-08-18 15:34:23 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:34:23 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:34:23 --> Utf8 Class Initialized
INFO - 2023-08-18 15:34:23 --> URI Class Initialized
DEBUG - 2023-08-18 15:34:23 --> No URI present. Default controller set.
INFO - 2023-08-18 15:34:23 --> Router Class Initialized
INFO - 2023-08-18 15:34:23 --> Output Class Initialized
INFO - 2023-08-18 15:34:23 --> Security Class Initialized
DEBUG - 2023-08-18 15:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:34:23 --> Input Class Initialized
INFO - 2023-08-18 15:34:23 --> Language Class Initialized
INFO - 2023-08-18 15:34:23 --> Loader Class Initialized
INFO - 2023-08-18 15:34:23 --> Helper loaded: url_helper
INFO - 2023-08-18 15:34:23 --> Helper loaded: file_helper
INFO - 2023-08-18 15:34:23 --> Helper loaded: html_helper
INFO - 2023-08-18 15:34:23 --> Helper loaded: text_helper
INFO - 2023-08-18 15:34:23 --> Helper loaded: form_helper
INFO - 2023-08-18 15:34:23 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:34:23 --> Helper loaded: security_helper
INFO - 2023-08-18 15:34:23 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:34:23 --> Database Driver Class Initialized
INFO - 2023-08-18 15:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:34:23 --> Parser Class Initialized
INFO - 2023-08-18 15:34:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:34:23 --> Pagination Class Initialized
INFO - 2023-08-18 15:34:23 --> Form Validation Class Initialized
INFO - 2023-08-18 15:34:23 --> Controller Class Initialized
INFO - 2023-08-18 15:34:23 --> Model Class Initialized
DEBUG - 2023-08-18 15:34:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:34:23 --> Model Class Initialized
DEBUG - 2023-08-18 15:34:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:34:23 --> Model Class Initialized
INFO - 2023-08-18 15:34:23 --> Model Class Initialized
INFO - 2023-08-18 15:34:23 --> Model Class Initialized
INFO - 2023-08-18 15:34:23 --> Model Class Initialized
DEBUG - 2023-08-18 15:34:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:34:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:34:23 --> Model Class Initialized
INFO - 2023-08-18 15:34:23 --> Model Class Initialized
INFO - 2023-08-18 15:34:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-18 15:34:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:34:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 15:34:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 15:34:23 --> Model Class Initialized
INFO - 2023-08-18 15:34:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 15:34:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 15:34:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 15:34:23 --> Final output sent to browser
DEBUG - 2023-08-18 15:34:23 --> Total execution time: 0.0949
ERROR - 2023-08-18 15:34:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:34:35 --> Config Class Initialized
INFO - 2023-08-18 15:34:35 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:34:35 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:34:35 --> Utf8 Class Initialized
INFO - 2023-08-18 15:34:35 --> URI Class Initialized
INFO - 2023-08-18 15:34:35 --> Router Class Initialized
INFO - 2023-08-18 15:34:35 --> Output Class Initialized
INFO - 2023-08-18 15:34:35 --> Security Class Initialized
DEBUG - 2023-08-18 15:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:34:35 --> Input Class Initialized
INFO - 2023-08-18 15:34:35 --> Language Class Initialized
INFO - 2023-08-18 15:34:35 --> Loader Class Initialized
INFO - 2023-08-18 15:34:35 --> Helper loaded: url_helper
INFO - 2023-08-18 15:34:35 --> Helper loaded: file_helper
INFO - 2023-08-18 15:34:35 --> Helper loaded: html_helper
INFO - 2023-08-18 15:34:35 --> Helper loaded: text_helper
INFO - 2023-08-18 15:34:35 --> Helper loaded: form_helper
INFO - 2023-08-18 15:34:35 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:34:35 --> Helper loaded: security_helper
INFO - 2023-08-18 15:34:35 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:34:35 --> Database Driver Class Initialized
INFO - 2023-08-18 15:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:34:35 --> Parser Class Initialized
INFO - 2023-08-18 15:34:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:34:35 --> Pagination Class Initialized
INFO - 2023-08-18 15:34:35 --> Form Validation Class Initialized
INFO - 2023-08-18 15:34:35 --> Controller Class Initialized
INFO - 2023-08-18 15:34:35 --> Model Class Initialized
DEBUG - 2023-08-18 15:34:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:34:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:34:35 --> Model Class Initialized
DEBUG - 2023-08-18 15:34:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:34:35 --> Model Class Initialized
INFO - 2023-08-18 15:34:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-18 15:34:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:34:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 15:34:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 15:34:35 --> Model Class Initialized
INFO - 2023-08-18 15:34:35 --> Model Class Initialized
INFO - 2023-08-18 15:34:35 --> Model Class Initialized
INFO - 2023-08-18 15:34:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 15:34:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 15:34:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 15:34:35 --> Final output sent to browser
DEBUG - 2023-08-18 15:34:35 --> Total execution time: 0.0921
ERROR - 2023-08-18 15:34:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:34:36 --> Config Class Initialized
INFO - 2023-08-18 15:34:36 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:34:36 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:34:36 --> Utf8 Class Initialized
INFO - 2023-08-18 15:34:36 --> URI Class Initialized
INFO - 2023-08-18 15:34:36 --> Router Class Initialized
INFO - 2023-08-18 15:34:36 --> Output Class Initialized
INFO - 2023-08-18 15:34:36 --> Security Class Initialized
DEBUG - 2023-08-18 15:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:34:36 --> Input Class Initialized
INFO - 2023-08-18 15:34:36 --> Language Class Initialized
INFO - 2023-08-18 15:34:36 --> Loader Class Initialized
INFO - 2023-08-18 15:34:36 --> Helper loaded: url_helper
INFO - 2023-08-18 15:34:36 --> Helper loaded: file_helper
INFO - 2023-08-18 15:34:36 --> Helper loaded: html_helper
INFO - 2023-08-18 15:34:36 --> Helper loaded: text_helper
INFO - 2023-08-18 15:34:36 --> Helper loaded: form_helper
INFO - 2023-08-18 15:34:36 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:34:36 --> Helper loaded: security_helper
INFO - 2023-08-18 15:34:36 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:34:36 --> Database Driver Class Initialized
INFO - 2023-08-18 15:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:34:36 --> Parser Class Initialized
INFO - 2023-08-18 15:34:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:34:36 --> Pagination Class Initialized
INFO - 2023-08-18 15:34:36 --> Form Validation Class Initialized
INFO - 2023-08-18 15:34:36 --> Controller Class Initialized
INFO - 2023-08-18 15:34:36 --> Model Class Initialized
DEBUG - 2023-08-18 15:34:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:34:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:34:36 --> Model Class Initialized
DEBUG - 2023-08-18 15:34:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:34:36 --> Model Class Initialized
INFO - 2023-08-18 15:34:37 --> Final output sent to browser
DEBUG - 2023-08-18 15:34:37 --> Total execution time: 0.0461
ERROR - 2023-08-18 15:35:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:35:20 --> Config Class Initialized
INFO - 2023-08-18 15:35:20 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:35:20 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:35:20 --> Utf8 Class Initialized
INFO - 2023-08-18 15:35:20 --> URI Class Initialized
INFO - 2023-08-18 15:35:20 --> Router Class Initialized
INFO - 2023-08-18 15:35:20 --> Output Class Initialized
INFO - 2023-08-18 15:35:20 --> Security Class Initialized
DEBUG - 2023-08-18 15:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:35:20 --> Input Class Initialized
INFO - 2023-08-18 15:35:20 --> Language Class Initialized
INFO - 2023-08-18 15:35:20 --> Loader Class Initialized
INFO - 2023-08-18 15:35:20 --> Helper loaded: url_helper
INFO - 2023-08-18 15:35:20 --> Helper loaded: file_helper
INFO - 2023-08-18 15:35:20 --> Helper loaded: html_helper
INFO - 2023-08-18 15:35:20 --> Helper loaded: text_helper
INFO - 2023-08-18 15:35:20 --> Helper loaded: form_helper
INFO - 2023-08-18 15:35:20 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:35:20 --> Helper loaded: security_helper
INFO - 2023-08-18 15:35:20 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:35:20 --> Database Driver Class Initialized
INFO - 2023-08-18 15:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:35:20 --> Parser Class Initialized
INFO - 2023-08-18 15:35:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:35:20 --> Pagination Class Initialized
INFO - 2023-08-18 15:35:20 --> Form Validation Class Initialized
INFO - 2023-08-18 15:35:20 --> Controller Class Initialized
INFO - 2023-08-18 15:35:20 --> Model Class Initialized
DEBUG - 2023-08-18 15:35:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:35:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:35:20 --> Model Class Initialized
DEBUG - 2023-08-18 15:35:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:35:20 --> Model Class Initialized
INFO - 2023-08-18 15:35:20 --> Final output sent to browser
DEBUG - 2023-08-18 15:35:20 --> Total execution time: 0.0418
ERROR - 2023-08-18 15:35:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:35:23 --> Config Class Initialized
INFO - 2023-08-18 15:35:23 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:35:23 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:35:23 --> Utf8 Class Initialized
INFO - 2023-08-18 15:35:23 --> URI Class Initialized
DEBUG - 2023-08-18 15:35:23 --> No URI present. Default controller set.
INFO - 2023-08-18 15:35:23 --> Router Class Initialized
INFO - 2023-08-18 15:35:23 --> Output Class Initialized
INFO - 2023-08-18 15:35:23 --> Security Class Initialized
DEBUG - 2023-08-18 15:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:35:23 --> Input Class Initialized
INFO - 2023-08-18 15:35:23 --> Language Class Initialized
INFO - 2023-08-18 15:35:23 --> Loader Class Initialized
INFO - 2023-08-18 15:35:23 --> Helper loaded: url_helper
INFO - 2023-08-18 15:35:23 --> Helper loaded: file_helper
INFO - 2023-08-18 15:35:23 --> Helper loaded: html_helper
INFO - 2023-08-18 15:35:23 --> Helper loaded: text_helper
INFO - 2023-08-18 15:35:23 --> Helper loaded: form_helper
INFO - 2023-08-18 15:35:23 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:35:23 --> Helper loaded: security_helper
INFO - 2023-08-18 15:35:23 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:35:23 --> Database Driver Class Initialized
INFO - 2023-08-18 15:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:35:23 --> Parser Class Initialized
INFO - 2023-08-18 15:35:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:35:23 --> Pagination Class Initialized
INFO - 2023-08-18 15:35:23 --> Form Validation Class Initialized
INFO - 2023-08-18 15:35:23 --> Controller Class Initialized
INFO - 2023-08-18 15:35:23 --> Model Class Initialized
DEBUG - 2023-08-18 15:35:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-18 15:35:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:35:23 --> Config Class Initialized
INFO - 2023-08-18 15:35:23 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:35:23 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:35:23 --> Utf8 Class Initialized
INFO - 2023-08-18 15:35:23 --> URI Class Initialized
INFO - 2023-08-18 15:35:23 --> Router Class Initialized
INFO - 2023-08-18 15:35:23 --> Output Class Initialized
INFO - 2023-08-18 15:35:23 --> Security Class Initialized
DEBUG - 2023-08-18 15:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:35:23 --> Input Class Initialized
INFO - 2023-08-18 15:35:23 --> Language Class Initialized
INFO - 2023-08-18 15:35:23 --> Loader Class Initialized
INFO - 2023-08-18 15:35:23 --> Helper loaded: url_helper
INFO - 2023-08-18 15:35:23 --> Helper loaded: file_helper
INFO - 2023-08-18 15:35:23 --> Helper loaded: html_helper
INFO - 2023-08-18 15:35:23 --> Helper loaded: text_helper
INFO - 2023-08-18 15:35:23 --> Helper loaded: form_helper
INFO - 2023-08-18 15:35:23 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:35:23 --> Helper loaded: security_helper
INFO - 2023-08-18 15:35:23 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:35:23 --> Database Driver Class Initialized
INFO - 2023-08-18 15:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:35:23 --> Parser Class Initialized
INFO - 2023-08-18 15:35:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:35:23 --> Pagination Class Initialized
INFO - 2023-08-18 15:35:23 --> Form Validation Class Initialized
INFO - 2023-08-18 15:35:23 --> Controller Class Initialized
INFO - 2023-08-18 15:35:23 --> Model Class Initialized
DEBUG - 2023-08-18 15:35:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:35:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-18 15:35:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:35:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 15:35:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 15:35:23 --> Model Class Initialized
INFO - 2023-08-18 15:35:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 15:35:23 --> Final output sent to browser
DEBUG - 2023-08-18 15:35:23 --> Total execution time: 0.0305
ERROR - 2023-08-18 15:35:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:35:29 --> Config Class Initialized
INFO - 2023-08-18 15:35:29 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:35:29 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:35:29 --> Utf8 Class Initialized
INFO - 2023-08-18 15:35:29 --> URI Class Initialized
DEBUG - 2023-08-18 15:35:29 --> No URI present. Default controller set.
INFO - 2023-08-18 15:35:29 --> Router Class Initialized
INFO - 2023-08-18 15:35:29 --> Output Class Initialized
INFO - 2023-08-18 15:35:29 --> Security Class Initialized
DEBUG - 2023-08-18 15:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:35:29 --> Input Class Initialized
INFO - 2023-08-18 15:35:29 --> Language Class Initialized
INFO - 2023-08-18 15:35:29 --> Loader Class Initialized
INFO - 2023-08-18 15:35:29 --> Helper loaded: url_helper
INFO - 2023-08-18 15:35:29 --> Helper loaded: file_helper
INFO - 2023-08-18 15:35:29 --> Helper loaded: html_helper
INFO - 2023-08-18 15:35:29 --> Helper loaded: text_helper
INFO - 2023-08-18 15:35:29 --> Helper loaded: form_helper
INFO - 2023-08-18 15:35:29 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:35:29 --> Helper loaded: security_helper
INFO - 2023-08-18 15:35:29 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:35:29 --> Database Driver Class Initialized
INFO - 2023-08-18 15:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:35:29 --> Parser Class Initialized
INFO - 2023-08-18 15:35:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:35:29 --> Pagination Class Initialized
INFO - 2023-08-18 15:35:29 --> Form Validation Class Initialized
INFO - 2023-08-18 15:35:29 --> Controller Class Initialized
INFO - 2023-08-18 15:35:29 --> Model Class Initialized
DEBUG - 2023-08-18 15:35:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:35:29 --> Model Class Initialized
DEBUG - 2023-08-18 15:35:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:35:29 --> Model Class Initialized
INFO - 2023-08-18 15:35:29 --> Model Class Initialized
INFO - 2023-08-18 15:35:29 --> Model Class Initialized
INFO - 2023-08-18 15:35:29 --> Model Class Initialized
DEBUG - 2023-08-18 15:35:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:35:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:35:29 --> Model Class Initialized
INFO - 2023-08-18 15:35:29 --> Model Class Initialized
INFO - 2023-08-18 15:35:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-18 15:35:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:35:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 15:35:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 15:35:29 --> Model Class Initialized
INFO - 2023-08-18 15:35:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 15:35:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 15:35:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 15:35:29 --> Final output sent to browser
DEBUG - 2023-08-18 15:35:29 --> Total execution time: 0.0956
ERROR - 2023-08-18 15:36:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:36:11 --> Config Class Initialized
INFO - 2023-08-18 15:36:11 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:36:11 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:36:11 --> Utf8 Class Initialized
INFO - 2023-08-18 15:36:11 --> URI Class Initialized
INFO - 2023-08-18 15:36:11 --> Router Class Initialized
INFO - 2023-08-18 15:36:11 --> Output Class Initialized
INFO - 2023-08-18 15:36:11 --> Security Class Initialized
DEBUG - 2023-08-18 15:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:36:11 --> Input Class Initialized
INFO - 2023-08-18 15:36:11 --> Language Class Initialized
INFO - 2023-08-18 15:36:11 --> Loader Class Initialized
INFO - 2023-08-18 15:36:11 --> Helper loaded: url_helper
INFO - 2023-08-18 15:36:11 --> Helper loaded: file_helper
INFO - 2023-08-18 15:36:11 --> Helper loaded: html_helper
INFO - 2023-08-18 15:36:11 --> Helper loaded: text_helper
INFO - 2023-08-18 15:36:11 --> Helper loaded: form_helper
INFO - 2023-08-18 15:36:11 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:36:11 --> Helper loaded: security_helper
INFO - 2023-08-18 15:36:11 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:36:11 --> Database Driver Class Initialized
INFO - 2023-08-18 15:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:36:11 --> Parser Class Initialized
INFO - 2023-08-18 15:36:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:36:11 --> Pagination Class Initialized
INFO - 2023-08-18 15:36:11 --> Form Validation Class Initialized
INFO - 2023-08-18 15:36:11 --> Controller Class Initialized
INFO - 2023-08-18 15:36:11 --> Model Class Initialized
DEBUG - 2023-08-18 15:36:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:36:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:36:11 --> Model Class Initialized
DEBUG - 2023-08-18 15:36:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:36:11 --> Model Class Initialized
INFO - 2023-08-18 15:36:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-08-18 15:36:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:36:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 15:36:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 15:36:11 --> Model Class Initialized
INFO - 2023-08-18 15:36:11 --> Model Class Initialized
INFO - 2023-08-18 15:36:11 --> Model Class Initialized
INFO - 2023-08-18 15:36:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 15:36:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 15:36:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 15:36:11 --> Final output sent to browser
DEBUG - 2023-08-18 15:36:11 --> Total execution time: 0.1122
ERROR - 2023-08-18 15:36:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:36:16 --> Config Class Initialized
INFO - 2023-08-18 15:36:16 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:36:16 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:36:16 --> Utf8 Class Initialized
INFO - 2023-08-18 15:36:16 --> URI Class Initialized
INFO - 2023-08-18 15:36:16 --> Router Class Initialized
INFO - 2023-08-18 15:36:16 --> Output Class Initialized
INFO - 2023-08-18 15:36:16 --> Security Class Initialized
DEBUG - 2023-08-18 15:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:36:16 --> Input Class Initialized
INFO - 2023-08-18 15:36:16 --> Language Class Initialized
INFO - 2023-08-18 15:36:16 --> Loader Class Initialized
INFO - 2023-08-18 15:36:16 --> Helper loaded: url_helper
INFO - 2023-08-18 15:36:16 --> Helper loaded: file_helper
INFO - 2023-08-18 15:36:16 --> Helper loaded: html_helper
INFO - 2023-08-18 15:36:16 --> Helper loaded: text_helper
INFO - 2023-08-18 15:36:16 --> Helper loaded: form_helper
INFO - 2023-08-18 15:36:16 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:36:16 --> Helper loaded: security_helper
INFO - 2023-08-18 15:36:16 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:36:16 --> Database Driver Class Initialized
INFO - 2023-08-18 15:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:36:16 --> Parser Class Initialized
INFO - 2023-08-18 15:36:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:36:16 --> Pagination Class Initialized
INFO - 2023-08-18 15:36:16 --> Form Validation Class Initialized
INFO - 2023-08-18 15:36:16 --> Controller Class Initialized
INFO - 2023-08-18 15:36:16 --> Model Class Initialized
DEBUG - 2023-08-18 15:36:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:36:16 --> Final output sent to browser
DEBUG - 2023-08-18 15:36:16 --> Total execution time: 0.0179
ERROR - 2023-08-18 15:36:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:36:17 --> Config Class Initialized
INFO - 2023-08-18 15:36:17 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:36:17 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:36:17 --> Utf8 Class Initialized
INFO - 2023-08-18 15:36:17 --> URI Class Initialized
INFO - 2023-08-18 15:36:17 --> Router Class Initialized
INFO - 2023-08-18 15:36:17 --> Output Class Initialized
INFO - 2023-08-18 15:36:17 --> Security Class Initialized
DEBUG - 2023-08-18 15:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:36:17 --> Input Class Initialized
INFO - 2023-08-18 15:36:17 --> Language Class Initialized
INFO - 2023-08-18 15:36:17 --> Loader Class Initialized
INFO - 2023-08-18 15:36:17 --> Helper loaded: url_helper
INFO - 2023-08-18 15:36:17 --> Helper loaded: file_helper
INFO - 2023-08-18 15:36:17 --> Helper loaded: html_helper
INFO - 2023-08-18 15:36:17 --> Helper loaded: text_helper
INFO - 2023-08-18 15:36:17 --> Helper loaded: form_helper
INFO - 2023-08-18 15:36:17 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:36:17 --> Helper loaded: security_helper
INFO - 2023-08-18 15:36:17 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:36:17 --> Database Driver Class Initialized
INFO - 2023-08-18 15:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:36:17 --> Parser Class Initialized
INFO - 2023-08-18 15:36:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:36:17 --> Pagination Class Initialized
INFO - 2023-08-18 15:36:17 --> Form Validation Class Initialized
INFO - 2023-08-18 15:36:17 --> Controller Class Initialized
INFO - 2023-08-18 15:36:17 --> Model Class Initialized
DEBUG - 2023-08-18 15:36:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:36:17 --> Final output sent to browser
DEBUG - 2023-08-18 15:36:17 --> Total execution time: 0.0182
ERROR - 2023-08-18 15:36:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:36:17 --> Config Class Initialized
INFO - 2023-08-18 15:36:17 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:36:17 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:36:17 --> Utf8 Class Initialized
INFO - 2023-08-18 15:36:17 --> URI Class Initialized
INFO - 2023-08-18 15:36:17 --> Router Class Initialized
INFO - 2023-08-18 15:36:17 --> Output Class Initialized
INFO - 2023-08-18 15:36:17 --> Security Class Initialized
DEBUG - 2023-08-18 15:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:36:17 --> Input Class Initialized
INFO - 2023-08-18 15:36:17 --> Language Class Initialized
INFO - 2023-08-18 15:36:17 --> Loader Class Initialized
INFO - 2023-08-18 15:36:17 --> Helper loaded: url_helper
INFO - 2023-08-18 15:36:17 --> Helper loaded: file_helper
INFO - 2023-08-18 15:36:17 --> Helper loaded: html_helper
INFO - 2023-08-18 15:36:17 --> Helper loaded: text_helper
INFO - 2023-08-18 15:36:17 --> Helper loaded: form_helper
INFO - 2023-08-18 15:36:17 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:36:17 --> Helper loaded: security_helper
INFO - 2023-08-18 15:36:17 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:36:17 --> Database Driver Class Initialized
INFO - 2023-08-18 15:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:36:17 --> Parser Class Initialized
INFO - 2023-08-18 15:36:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:36:17 --> Pagination Class Initialized
INFO - 2023-08-18 15:36:17 --> Form Validation Class Initialized
INFO - 2023-08-18 15:36:17 --> Controller Class Initialized
INFO - 2023-08-18 15:36:17 --> Model Class Initialized
DEBUG - 2023-08-18 15:36:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:36:17 --> Final output sent to browser
DEBUG - 2023-08-18 15:36:17 --> Total execution time: 0.0164
ERROR - 2023-08-18 15:36:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:36:19 --> Config Class Initialized
INFO - 2023-08-18 15:36:19 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:36:19 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:36:19 --> Utf8 Class Initialized
INFO - 2023-08-18 15:36:19 --> URI Class Initialized
INFO - 2023-08-18 15:36:19 --> Router Class Initialized
INFO - 2023-08-18 15:36:19 --> Output Class Initialized
INFO - 2023-08-18 15:36:19 --> Security Class Initialized
DEBUG - 2023-08-18 15:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:36:19 --> Input Class Initialized
INFO - 2023-08-18 15:36:19 --> Language Class Initialized
INFO - 2023-08-18 15:36:19 --> Loader Class Initialized
INFO - 2023-08-18 15:36:19 --> Helper loaded: url_helper
INFO - 2023-08-18 15:36:19 --> Helper loaded: file_helper
INFO - 2023-08-18 15:36:19 --> Helper loaded: html_helper
INFO - 2023-08-18 15:36:19 --> Helper loaded: text_helper
INFO - 2023-08-18 15:36:19 --> Helper loaded: form_helper
INFO - 2023-08-18 15:36:19 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:36:19 --> Helper loaded: security_helper
INFO - 2023-08-18 15:36:19 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:36:19 --> Database Driver Class Initialized
INFO - 2023-08-18 15:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:36:19 --> Parser Class Initialized
INFO - 2023-08-18 15:36:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:36:19 --> Pagination Class Initialized
INFO - 2023-08-18 15:36:19 --> Form Validation Class Initialized
INFO - 2023-08-18 15:36:19 --> Controller Class Initialized
INFO - 2023-08-18 15:36:19 --> Final output sent to browser
DEBUG - 2023-08-18 15:36:19 --> Total execution time: 0.0162
ERROR - 2023-08-18 15:36:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:36:31 --> Config Class Initialized
INFO - 2023-08-18 15:36:31 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:36:31 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:36:31 --> Utf8 Class Initialized
INFO - 2023-08-18 15:36:31 --> URI Class Initialized
INFO - 2023-08-18 15:36:31 --> Router Class Initialized
INFO - 2023-08-18 15:36:31 --> Output Class Initialized
INFO - 2023-08-18 15:36:31 --> Security Class Initialized
DEBUG - 2023-08-18 15:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:36:31 --> Input Class Initialized
INFO - 2023-08-18 15:36:31 --> Language Class Initialized
INFO - 2023-08-18 15:36:31 --> Loader Class Initialized
INFO - 2023-08-18 15:36:31 --> Helper loaded: url_helper
INFO - 2023-08-18 15:36:31 --> Helper loaded: file_helper
INFO - 2023-08-18 15:36:31 --> Helper loaded: html_helper
INFO - 2023-08-18 15:36:31 --> Helper loaded: text_helper
INFO - 2023-08-18 15:36:31 --> Helper loaded: form_helper
INFO - 2023-08-18 15:36:31 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:36:31 --> Helper loaded: security_helper
INFO - 2023-08-18 15:36:31 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:36:31 --> Database Driver Class Initialized
INFO - 2023-08-18 15:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:36:31 --> Parser Class Initialized
INFO - 2023-08-18 15:36:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:36:31 --> Pagination Class Initialized
INFO - 2023-08-18 15:36:31 --> Form Validation Class Initialized
INFO - 2023-08-18 15:36:31 --> Controller Class Initialized
INFO - 2023-08-18 15:36:31 --> Model Class Initialized
DEBUG - 2023-08-18 15:36:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:36:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:36:31 --> Model Class Initialized
DEBUG - 2023-08-18 15:36:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:36:31 --> Model Class Initialized
INFO - 2023-08-18 15:36:31 --> Final output sent to browser
DEBUG - 2023-08-18 15:36:31 --> Total execution time: 0.0581
ERROR - 2023-08-18 15:36:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:36:31 --> Config Class Initialized
INFO - 2023-08-18 15:36:31 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:36:31 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:36:31 --> Utf8 Class Initialized
INFO - 2023-08-18 15:36:31 --> URI Class Initialized
INFO - 2023-08-18 15:36:31 --> Router Class Initialized
INFO - 2023-08-18 15:36:31 --> Output Class Initialized
INFO - 2023-08-18 15:36:31 --> Security Class Initialized
DEBUG - 2023-08-18 15:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:36:31 --> Input Class Initialized
INFO - 2023-08-18 15:36:31 --> Language Class Initialized
INFO - 2023-08-18 15:36:31 --> Loader Class Initialized
INFO - 2023-08-18 15:36:31 --> Helper loaded: url_helper
INFO - 2023-08-18 15:36:31 --> Helper loaded: file_helper
INFO - 2023-08-18 15:36:31 --> Helper loaded: html_helper
INFO - 2023-08-18 15:36:31 --> Helper loaded: text_helper
INFO - 2023-08-18 15:36:31 --> Helper loaded: form_helper
INFO - 2023-08-18 15:36:31 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:36:31 --> Helper loaded: security_helper
INFO - 2023-08-18 15:36:31 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:36:31 --> Database Driver Class Initialized
INFO - 2023-08-18 15:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:36:31 --> Parser Class Initialized
INFO - 2023-08-18 15:36:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:36:31 --> Pagination Class Initialized
INFO - 2023-08-18 15:36:31 --> Form Validation Class Initialized
INFO - 2023-08-18 15:36:31 --> Controller Class Initialized
INFO - 2023-08-18 15:36:31 --> Model Class Initialized
DEBUG - 2023-08-18 15:36:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:36:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:36:31 --> Model Class Initialized
DEBUG - 2023-08-18 15:36:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:36:31 --> Model Class Initialized
INFO - 2023-08-18 15:36:31 --> Final output sent to browser
DEBUG - 2023-08-18 15:36:31 --> Total execution time: 0.0555
ERROR - 2023-08-18 15:36:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:36:31 --> Config Class Initialized
INFO - 2023-08-18 15:36:31 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:36:31 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:36:31 --> Utf8 Class Initialized
INFO - 2023-08-18 15:36:31 --> URI Class Initialized
INFO - 2023-08-18 15:36:31 --> Router Class Initialized
INFO - 2023-08-18 15:36:31 --> Output Class Initialized
INFO - 2023-08-18 15:36:31 --> Security Class Initialized
DEBUG - 2023-08-18 15:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:36:31 --> Input Class Initialized
INFO - 2023-08-18 15:36:31 --> Language Class Initialized
INFO - 2023-08-18 15:36:31 --> Loader Class Initialized
INFO - 2023-08-18 15:36:31 --> Helper loaded: url_helper
INFO - 2023-08-18 15:36:31 --> Helper loaded: file_helper
INFO - 2023-08-18 15:36:31 --> Helper loaded: html_helper
INFO - 2023-08-18 15:36:31 --> Helper loaded: text_helper
INFO - 2023-08-18 15:36:31 --> Helper loaded: form_helper
INFO - 2023-08-18 15:36:31 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:36:31 --> Helper loaded: security_helper
INFO - 2023-08-18 15:36:31 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:36:31 --> Database Driver Class Initialized
INFO - 2023-08-18 15:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:36:31 --> Parser Class Initialized
INFO - 2023-08-18 15:36:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:36:31 --> Pagination Class Initialized
INFO - 2023-08-18 15:36:31 --> Form Validation Class Initialized
INFO - 2023-08-18 15:36:31 --> Controller Class Initialized
INFO - 2023-08-18 15:36:31 --> Model Class Initialized
DEBUG - 2023-08-18 15:36:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:36:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:36:31 --> Model Class Initialized
DEBUG - 2023-08-18 15:36:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:36:31 --> Model Class Initialized
INFO - 2023-08-18 15:36:31 --> Final output sent to browser
DEBUG - 2023-08-18 15:36:31 --> Total execution time: 0.0649
ERROR - 2023-08-18 15:37:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:37:03 --> Config Class Initialized
INFO - 2023-08-18 15:37:03 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:37:03 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:37:03 --> Utf8 Class Initialized
INFO - 2023-08-18 15:37:03 --> URI Class Initialized
INFO - 2023-08-18 15:37:03 --> Router Class Initialized
INFO - 2023-08-18 15:37:03 --> Output Class Initialized
INFO - 2023-08-18 15:37:03 --> Security Class Initialized
DEBUG - 2023-08-18 15:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:37:03 --> Input Class Initialized
INFO - 2023-08-18 15:37:03 --> Language Class Initialized
INFO - 2023-08-18 15:37:03 --> Loader Class Initialized
INFO - 2023-08-18 15:37:03 --> Helper loaded: url_helper
INFO - 2023-08-18 15:37:03 --> Helper loaded: file_helper
INFO - 2023-08-18 15:37:03 --> Helper loaded: html_helper
INFO - 2023-08-18 15:37:03 --> Helper loaded: text_helper
INFO - 2023-08-18 15:37:03 --> Helper loaded: form_helper
INFO - 2023-08-18 15:37:03 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:37:03 --> Helper loaded: security_helper
INFO - 2023-08-18 15:37:03 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:37:03 --> Database Driver Class Initialized
INFO - 2023-08-18 15:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:37:03 --> Parser Class Initialized
INFO - 2023-08-18 15:37:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:37:03 --> Pagination Class Initialized
INFO - 2023-08-18 15:37:03 --> Form Validation Class Initialized
INFO - 2023-08-18 15:37:03 --> Controller Class Initialized
INFO - 2023-08-18 15:37:03 --> Model Class Initialized
DEBUG - 2023-08-18 15:37:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:37:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:37:03 --> Model Class Initialized
DEBUG - 2023-08-18 15:37:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:37:03 --> Model Class Initialized
INFO - 2023-08-18 15:37:03 --> Final output sent to browser
DEBUG - 2023-08-18 15:37:03 --> Total execution time: 0.0611
ERROR - 2023-08-18 15:37:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:37:04 --> Config Class Initialized
INFO - 2023-08-18 15:37:04 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:37:04 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:37:04 --> Utf8 Class Initialized
INFO - 2023-08-18 15:37:04 --> URI Class Initialized
INFO - 2023-08-18 15:37:04 --> Router Class Initialized
INFO - 2023-08-18 15:37:04 --> Output Class Initialized
INFO - 2023-08-18 15:37:04 --> Security Class Initialized
DEBUG - 2023-08-18 15:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:37:04 --> Input Class Initialized
INFO - 2023-08-18 15:37:04 --> Language Class Initialized
INFO - 2023-08-18 15:37:04 --> Loader Class Initialized
INFO - 2023-08-18 15:37:04 --> Helper loaded: url_helper
INFO - 2023-08-18 15:37:04 --> Helper loaded: file_helper
INFO - 2023-08-18 15:37:04 --> Helper loaded: html_helper
INFO - 2023-08-18 15:37:04 --> Helper loaded: text_helper
INFO - 2023-08-18 15:37:04 --> Helper loaded: form_helper
INFO - 2023-08-18 15:37:04 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:37:04 --> Helper loaded: security_helper
INFO - 2023-08-18 15:37:04 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:37:04 --> Database Driver Class Initialized
INFO - 2023-08-18 15:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:37:04 --> Parser Class Initialized
INFO - 2023-08-18 15:37:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:37:04 --> Pagination Class Initialized
INFO - 2023-08-18 15:37:04 --> Form Validation Class Initialized
INFO - 2023-08-18 15:37:04 --> Controller Class Initialized
INFO - 2023-08-18 15:37:04 --> Model Class Initialized
DEBUG - 2023-08-18 15:37:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:37:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:37:04 --> Model Class Initialized
DEBUG - 2023-08-18 15:37:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:37:04 --> Model Class Initialized
INFO - 2023-08-18 15:37:04 --> Final output sent to browser
DEBUG - 2023-08-18 15:37:04 --> Total execution time: 0.0226
ERROR - 2023-08-18 15:37:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:37:05 --> Config Class Initialized
INFO - 2023-08-18 15:37:05 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:37:05 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:37:05 --> Utf8 Class Initialized
INFO - 2023-08-18 15:37:05 --> URI Class Initialized
INFO - 2023-08-18 15:37:05 --> Router Class Initialized
INFO - 2023-08-18 15:37:05 --> Output Class Initialized
INFO - 2023-08-18 15:37:05 --> Security Class Initialized
DEBUG - 2023-08-18 15:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:37:05 --> Input Class Initialized
INFO - 2023-08-18 15:37:05 --> Language Class Initialized
INFO - 2023-08-18 15:37:05 --> Loader Class Initialized
INFO - 2023-08-18 15:37:05 --> Helper loaded: url_helper
INFO - 2023-08-18 15:37:05 --> Helper loaded: file_helper
INFO - 2023-08-18 15:37:05 --> Helper loaded: html_helper
INFO - 2023-08-18 15:37:05 --> Helper loaded: text_helper
INFO - 2023-08-18 15:37:05 --> Helper loaded: form_helper
INFO - 2023-08-18 15:37:05 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:37:05 --> Helper loaded: security_helper
INFO - 2023-08-18 15:37:05 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:37:05 --> Database Driver Class Initialized
INFO - 2023-08-18 15:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:37:05 --> Parser Class Initialized
INFO - 2023-08-18 15:37:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:37:05 --> Pagination Class Initialized
INFO - 2023-08-18 15:37:05 --> Form Validation Class Initialized
INFO - 2023-08-18 15:37:05 --> Controller Class Initialized
INFO - 2023-08-18 15:37:05 --> Model Class Initialized
DEBUG - 2023-08-18 15:37:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:37:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:37:05 --> Model Class Initialized
DEBUG - 2023-08-18 15:37:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:37:05 --> Model Class Initialized
INFO - 2023-08-18 15:37:05 --> Final output sent to browser
DEBUG - 2023-08-18 15:37:05 --> Total execution time: 0.0189
ERROR - 2023-08-18 15:37:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:37:05 --> Config Class Initialized
INFO - 2023-08-18 15:37:05 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:37:05 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:37:05 --> Utf8 Class Initialized
INFO - 2023-08-18 15:37:05 --> URI Class Initialized
INFO - 2023-08-18 15:37:05 --> Router Class Initialized
INFO - 2023-08-18 15:37:05 --> Output Class Initialized
INFO - 2023-08-18 15:37:05 --> Security Class Initialized
DEBUG - 2023-08-18 15:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:37:05 --> Input Class Initialized
INFO - 2023-08-18 15:37:05 --> Language Class Initialized
INFO - 2023-08-18 15:37:05 --> Loader Class Initialized
INFO - 2023-08-18 15:37:05 --> Helper loaded: url_helper
INFO - 2023-08-18 15:37:05 --> Helper loaded: file_helper
INFO - 2023-08-18 15:37:05 --> Helper loaded: html_helper
INFO - 2023-08-18 15:37:05 --> Helper loaded: text_helper
INFO - 2023-08-18 15:37:05 --> Helper loaded: form_helper
INFO - 2023-08-18 15:37:05 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:37:05 --> Helper loaded: security_helper
INFO - 2023-08-18 15:37:05 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:37:05 --> Database Driver Class Initialized
INFO - 2023-08-18 15:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:37:05 --> Parser Class Initialized
INFO - 2023-08-18 15:37:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:37:05 --> Pagination Class Initialized
INFO - 2023-08-18 15:37:05 --> Form Validation Class Initialized
INFO - 2023-08-18 15:37:05 --> Controller Class Initialized
INFO - 2023-08-18 15:37:05 --> Model Class Initialized
DEBUG - 2023-08-18 15:37:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:37:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:37:05 --> Model Class Initialized
DEBUG - 2023-08-18 15:37:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:37:05 --> Model Class Initialized
INFO - 2023-08-18 15:37:05 --> Final output sent to browser
DEBUG - 2023-08-18 15:37:05 --> Total execution time: 0.0198
ERROR - 2023-08-18 15:37:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:37:06 --> Config Class Initialized
INFO - 2023-08-18 15:37:06 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:37:06 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:37:06 --> Utf8 Class Initialized
INFO - 2023-08-18 15:37:06 --> URI Class Initialized
INFO - 2023-08-18 15:37:06 --> Router Class Initialized
INFO - 2023-08-18 15:37:06 --> Output Class Initialized
INFO - 2023-08-18 15:37:06 --> Security Class Initialized
DEBUG - 2023-08-18 15:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:37:06 --> Input Class Initialized
INFO - 2023-08-18 15:37:06 --> Language Class Initialized
INFO - 2023-08-18 15:37:06 --> Loader Class Initialized
INFO - 2023-08-18 15:37:06 --> Helper loaded: url_helper
INFO - 2023-08-18 15:37:06 --> Helper loaded: file_helper
INFO - 2023-08-18 15:37:06 --> Helper loaded: html_helper
INFO - 2023-08-18 15:37:06 --> Helper loaded: text_helper
INFO - 2023-08-18 15:37:06 --> Helper loaded: form_helper
INFO - 2023-08-18 15:37:06 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:37:06 --> Helper loaded: security_helper
INFO - 2023-08-18 15:37:06 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:37:06 --> Database Driver Class Initialized
INFO - 2023-08-18 15:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:37:06 --> Parser Class Initialized
INFO - 2023-08-18 15:37:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:37:06 --> Pagination Class Initialized
INFO - 2023-08-18 15:37:06 --> Form Validation Class Initialized
INFO - 2023-08-18 15:37:06 --> Controller Class Initialized
INFO - 2023-08-18 15:37:06 --> Model Class Initialized
DEBUG - 2023-08-18 15:37:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:37:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:37:06 --> Model Class Initialized
DEBUG - 2023-08-18 15:37:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:37:06 --> Model Class Initialized
INFO - 2023-08-18 15:37:06 --> Final output sent to browser
DEBUG - 2023-08-18 15:37:06 --> Total execution time: 0.0218
ERROR - 2023-08-18 15:37:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:37:24 --> Config Class Initialized
INFO - 2023-08-18 15:37:24 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:37:24 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:37:24 --> Utf8 Class Initialized
INFO - 2023-08-18 15:37:24 --> URI Class Initialized
INFO - 2023-08-18 15:37:24 --> Router Class Initialized
INFO - 2023-08-18 15:37:24 --> Output Class Initialized
INFO - 2023-08-18 15:37:24 --> Security Class Initialized
DEBUG - 2023-08-18 15:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:37:24 --> Input Class Initialized
INFO - 2023-08-18 15:37:24 --> Language Class Initialized
INFO - 2023-08-18 15:37:24 --> Loader Class Initialized
INFO - 2023-08-18 15:37:24 --> Helper loaded: url_helper
INFO - 2023-08-18 15:37:24 --> Helper loaded: file_helper
INFO - 2023-08-18 15:37:24 --> Helper loaded: html_helper
INFO - 2023-08-18 15:37:24 --> Helper loaded: text_helper
INFO - 2023-08-18 15:37:24 --> Helper loaded: form_helper
INFO - 2023-08-18 15:37:24 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:37:24 --> Helper loaded: security_helper
INFO - 2023-08-18 15:37:24 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:37:24 --> Database Driver Class Initialized
INFO - 2023-08-18 15:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:37:24 --> Parser Class Initialized
INFO - 2023-08-18 15:37:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:37:24 --> Pagination Class Initialized
INFO - 2023-08-18 15:37:24 --> Form Validation Class Initialized
INFO - 2023-08-18 15:37:24 --> Controller Class Initialized
INFO - 2023-08-18 15:37:24 --> Model Class Initialized
DEBUG - 2023-08-18 15:37:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:37:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:37:24 --> Model Class Initialized
DEBUG - 2023-08-18 15:37:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:37:24 --> Model Class Initialized
INFO - 2023-08-18 15:37:24 --> Final output sent to browser
DEBUG - 2023-08-18 15:37:24 --> Total execution time: 0.0606
ERROR - 2023-08-18 15:37:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:37:28 --> Config Class Initialized
INFO - 2023-08-18 15:37:28 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:37:28 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:37:28 --> Utf8 Class Initialized
INFO - 2023-08-18 15:37:28 --> URI Class Initialized
INFO - 2023-08-18 15:37:28 --> Router Class Initialized
INFO - 2023-08-18 15:37:28 --> Output Class Initialized
INFO - 2023-08-18 15:37:28 --> Security Class Initialized
DEBUG - 2023-08-18 15:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:37:28 --> Input Class Initialized
INFO - 2023-08-18 15:37:28 --> Language Class Initialized
INFO - 2023-08-18 15:37:28 --> Loader Class Initialized
INFO - 2023-08-18 15:37:28 --> Helper loaded: url_helper
INFO - 2023-08-18 15:37:28 --> Helper loaded: file_helper
INFO - 2023-08-18 15:37:28 --> Helper loaded: html_helper
INFO - 2023-08-18 15:37:28 --> Helper loaded: text_helper
INFO - 2023-08-18 15:37:28 --> Helper loaded: form_helper
INFO - 2023-08-18 15:37:28 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:37:28 --> Helper loaded: security_helper
INFO - 2023-08-18 15:37:28 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:37:28 --> Database Driver Class Initialized
INFO - 2023-08-18 15:37:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:37:28 --> Parser Class Initialized
INFO - 2023-08-18 15:37:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:37:28 --> Pagination Class Initialized
INFO - 2023-08-18 15:37:28 --> Form Validation Class Initialized
INFO - 2023-08-18 15:37:28 --> Controller Class Initialized
INFO - 2023-08-18 15:37:28 --> Model Class Initialized
DEBUG - 2023-08-18 15:37:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:37:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:37:28 --> Model Class Initialized
DEBUG - 2023-08-18 15:37:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:37:28 --> Model Class Initialized
INFO - 2023-08-18 15:37:28 --> Final output sent to browser
DEBUG - 2023-08-18 15:37:28 --> Total execution time: 0.0590
ERROR - 2023-08-18 15:37:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:37:28 --> Config Class Initialized
INFO - 2023-08-18 15:37:28 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:37:28 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:37:28 --> Utf8 Class Initialized
INFO - 2023-08-18 15:37:28 --> URI Class Initialized
INFO - 2023-08-18 15:37:28 --> Router Class Initialized
INFO - 2023-08-18 15:37:28 --> Output Class Initialized
INFO - 2023-08-18 15:37:28 --> Security Class Initialized
DEBUG - 2023-08-18 15:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:37:28 --> Input Class Initialized
INFO - 2023-08-18 15:37:28 --> Language Class Initialized
INFO - 2023-08-18 15:37:28 --> Loader Class Initialized
INFO - 2023-08-18 15:37:28 --> Helper loaded: url_helper
INFO - 2023-08-18 15:37:28 --> Helper loaded: file_helper
INFO - 2023-08-18 15:37:28 --> Helper loaded: html_helper
INFO - 2023-08-18 15:37:28 --> Helper loaded: text_helper
INFO - 2023-08-18 15:37:28 --> Helper loaded: form_helper
INFO - 2023-08-18 15:37:28 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:37:28 --> Helper loaded: security_helper
INFO - 2023-08-18 15:37:28 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:37:28 --> Database Driver Class Initialized
INFO - 2023-08-18 15:37:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:37:28 --> Parser Class Initialized
INFO - 2023-08-18 15:37:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:37:28 --> Pagination Class Initialized
INFO - 2023-08-18 15:37:28 --> Form Validation Class Initialized
INFO - 2023-08-18 15:37:28 --> Controller Class Initialized
INFO - 2023-08-18 15:37:28 --> Model Class Initialized
DEBUG - 2023-08-18 15:37:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:37:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:37:28 --> Model Class Initialized
DEBUG - 2023-08-18 15:37:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:37:28 --> Model Class Initialized
INFO - 2023-08-18 15:37:28 --> Final output sent to browser
DEBUG - 2023-08-18 15:37:28 --> Total execution time: 0.0534
ERROR - 2023-08-18 15:37:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:37:29 --> Config Class Initialized
INFO - 2023-08-18 15:37:29 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:37:29 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:37:29 --> Utf8 Class Initialized
INFO - 2023-08-18 15:37:29 --> URI Class Initialized
INFO - 2023-08-18 15:37:29 --> Router Class Initialized
INFO - 2023-08-18 15:37:29 --> Output Class Initialized
INFO - 2023-08-18 15:37:29 --> Security Class Initialized
DEBUG - 2023-08-18 15:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:37:29 --> Input Class Initialized
INFO - 2023-08-18 15:37:29 --> Language Class Initialized
INFO - 2023-08-18 15:37:29 --> Loader Class Initialized
INFO - 2023-08-18 15:37:29 --> Helper loaded: url_helper
INFO - 2023-08-18 15:37:29 --> Helper loaded: file_helper
INFO - 2023-08-18 15:37:29 --> Helper loaded: html_helper
INFO - 2023-08-18 15:37:29 --> Helper loaded: text_helper
INFO - 2023-08-18 15:37:29 --> Helper loaded: form_helper
INFO - 2023-08-18 15:37:29 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:37:29 --> Helper loaded: security_helper
INFO - 2023-08-18 15:37:29 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:37:29 --> Database Driver Class Initialized
INFO - 2023-08-18 15:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:37:29 --> Parser Class Initialized
INFO - 2023-08-18 15:37:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:37:29 --> Pagination Class Initialized
INFO - 2023-08-18 15:37:29 --> Form Validation Class Initialized
INFO - 2023-08-18 15:37:29 --> Controller Class Initialized
INFO - 2023-08-18 15:37:29 --> Model Class Initialized
DEBUG - 2023-08-18 15:37:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:37:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:37:29 --> Model Class Initialized
DEBUG - 2023-08-18 15:37:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:37:29 --> Model Class Initialized
INFO - 2023-08-18 15:37:29 --> Final output sent to browser
DEBUG - 2023-08-18 15:37:29 --> Total execution time: 0.0540
ERROR - 2023-08-18 15:39:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:39:18 --> Config Class Initialized
INFO - 2023-08-18 15:39:18 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:39:18 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:39:18 --> Utf8 Class Initialized
INFO - 2023-08-18 15:39:18 --> URI Class Initialized
INFO - 2023-08-18 15:39:18 --> Router Class Initialized
INFO - 2023-08-18 15:39:18 --> Output Class Initialized
INFO - 2023-08-18 15:39:18 --> Security Class Initialized
DEBUG - 2023-08-18 15:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:39:18 --> Input Class Initialized
INFO - 2023-08-18 15:39:18 --> Language Class Initialized
INFO - 2023-08-18 15:39:18 --> Loader Class Initialized
INFO - 2023-08-18 15:39:18 --> Helper loaded: url_helper
INFO - 2023-08-18 15:39:18 --> Helper loaded: file_helper
INFO - 2023-08-18 15:39:18 --> Helper loaded: html_helper
INFO - 2023-08-18 15:39:18 --> Helper loaded: text_helper
INFO - 2023-08-18 15:39:18 --> Helper loaded: form_helper
INFO - 2023-08-18 15:39:18 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:39:18 --> Helper loaded: security_helper
INFO - 2023-08-18 15:39:18 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:39:18 --> Database Driver Class Initialized
INFO - 2023-08-18 15:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:39:18 --> Parser Class Initialized
INFO - 2023-08-18 15:39:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:39:18 --> Pagination Class Initialized
INFO - 2023-08-18 15:39:18 --> Form Validation Class Initialized
INFO - 2023-08-18 15:39:18 --> Controller Class Initialized
INFO - 2023-08-18 15:39:18 --> Model Class Initialized
DEBUG - 2023-08-18 15:39:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:39:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:39:18 --> Model Class Initialized
DEBUG - 2023-08-18 15:39:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:39:18 --> Model Class Initialized
INFO - 2023-08-18 15:39:18 --> Final output sent to browser
DEBUG - 2023-08-18 15:39:18 --> Total execution time: 0.0317
ERROR - 2023-08-18 15:39:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:39:19 --> Config Class Initialized
INFO - 2023-08-18 15:39:19 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:39:19 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:39:19 --> Utf8 Class Initialized
INFO - 2023-08-18 15:39:19 --> URI Class Initialized
INFO - 2023-08-18 15:39:19 --> Router Class Initialized
INFO - 2023-08-18 15:39:19 --> Output Class Initialized
INFO - 2023-08-18 15:39:19 --> Security Class Initialized
DEBUG - 2023-08-18 15:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:39:19 --> Input Class Initialized
INFO - 2023-08-18 15:39:19 --> Language Class Initialized
INFO - 2023-08-18 15:39:19 --> Loader Class Initialized
INFO - 2023-08-18 15:39:19 --> Helper loaded: url_helper
INFO - 2023-08-18 15:39:19 --> Helper loaded: file_helper
INFO - 2023-08-18 15:39:19 --> Helper loaded: html_helper
INFO - 2023-08-18 15:39:19 --> Helper loaded: text_helper
INFO - 2023-08-18 15:39:19 --> Helper loaded: form_helper
INFO - 2023-08-18 15:39:19 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:39:19 --> Helper loaded: security_helper
INFO - 2023-08-18 15:39:19 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:39:19 --> Database Driver Class Initialized
INFO - 2023-08-18 15:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:39:19 --> Parser Class Initialized
INFO - 2023-08-18 15:39:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:39:19 --> Pagination Class Initialized
INFO - 2023-08-18 15:39:19 --> Form Validation Class Initialized
INFO - 2023-08-18 15:39:19 --> Controller Class Initialized
INFO - 2023-08-18 15:39:19 --> Model Class Initialized
DEBUG - 2023-08-18 15:39:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:39:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:39:19 --> Model Class Initialized
DEBUG - 2023-08-18 15:39:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:39:19 --> Model Class Initialized
INFO - 2023-08-18 15:39:19 --> Final output sent to browser
DEBUG - 2023-08-18 15:39:19 --> Total execution time: 0.0540
ERROR - 2023-08-18 15:39:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:39:20 --> Config Class Initialized
INFO - 2023-08-18 15:39:20 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:39:20 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:39:20 --> Utf8 Class Initialized
INFO - 2023-08-18 15:39:20 --> URI Class Initialized
INFO - 2023-08-18 15:39:20 --> Router Class Initialized
INFO - 2023-08-18 15:39:20 --> Output Class Initialized
INFO - 2023-08-18 15:39:20 --> Security Class Initialized
DEBUG - 2023-08-18 15:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:39:20 --> Input Class Initialized
INFO - 2023-08-18 15:39:20 --> Language Class Initialized
INFO - 2023-08-18 15:39:20 --> Loader Class Initialized
INFO - 2023-08-18 15:39:20 --> Helper loaded: url_helper
INFO - 2023-08-18 15:39:20 --> Helper loaded: file_helper
INFO - 2023-08-18 15:39:20 --> Helper loaded: html_helper
INFO - 2023-08-18 15:39:20 --> Helper loaded: text_helper
INFO - 2023-08-18 15:39:20 --> Helper loaded: form_helper
INFO - 2023-08-18 15:39:20 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:39:20 --> Helper loaded: security_helper
INFO - 2023-08-18 15:39:20 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:39:20 --> Database Driver Class Initialized
INFO - 2023-08-18 15:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:39:20 --> Parser Class Initialized
INFO - 2023-08-18 15:39:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:39:20 --> Pagination Class Initialized
INFO - 2023-08-18 15:39:20 --> Form Validation Class Initialized
INFO - 2023-08-18 15:39:20 --> Controller Class Initialized
INFO - 2023-08-18 15:39:20 --> Model Class Initialized
DEBUG - 2023-08-18 15:39:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:39:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:39:20 --> Model Class Initialized
DEBUG - 2023-08-18 15:39:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:39:20 --> Model Class Initialized
INFO - 2023-08-18 15:39:20 --> Final output sent to browser
DEBUG - 2023-08-18 15:39:20 --> Total execution time: 0.0215
ERROR - 2023-08-18 15:39:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:39:22 --> Config Class Initialized
INFO - 2023-08-18 15:39:22 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:39:22 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:39:22 --> Utf8 Class Initialized
INFO - 2023-08-18 15:39:22 --> URI Class Initialized
INFO - 2023-08-18 15:39:22 --> Router Class Initialized
INFO - 2023-08-18 15:39:22 --> Output Class Initialized
INFO - 2023-08-18 15:39:22 --> Security Class Initialized
DEBUG - 2023-08-18 15:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:39:22 --> Input Class Initialized
INFO - 2023-08-18 15:39:22 --> Language Class Initialized
INFO - 2023-08-18 15:39:22 --> Loader Class Initialized
INFO - 2023-08-18 15:39:22 --> Helper loaded: url_helper
INFO - 2023-08-18 15:39:22 --> Helper loaded: file_helper
INFO - 2023-08-18 15:39:22 --> Helper loaded: html_helper
INFO - 2023-08-18 15:39:22 --> Helper loaded: text_helper
INFO - 2023-08-18 15:39:22 --> Helper loaded: form_helper
INFO - 2023-08-18 15:39:22 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:39:22 --> Helper loaded: security_helper
INFO - 2023-08-18 15:39:22 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:39:22 --> Database Driver Class Initialized
INFO - 2023-08-18 15:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:39:22 --> Parser Class Initialized
INFO - 2023-08-18 15:39:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:39:22 --> Pagination Class Initialized
INFO - 2023-08-18 15:39:22 --> Form Validation Class Initialized
INFO - 2023-08-18 15:39:22 --> Controller Class Initialized
INFO - 2023-08-18 15:39:22 --> Model Class Initialized
DEBUG - 2023-08-18 15:39:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:39:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:39:22 --> Model Class Initialized
INFO - 2023-08-18 15:39:22 --> Model Class Initialized
INFO - 2023-08-18 15:39:22 --> Final output sent to browser
DEBUG - 2023-08-18 15:39:22 --> Total execution time: 0.0203
ERROR - 2023-08-18 15:39:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:39:24 --> Config Class Initialized
INFO - 2023-08-18 15:39:24 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:39:24 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:39:24 --> Utf8 Class Initialized
INFO - 2023-08-18 15:39:24 --> URI Class Initialized
INFO - 2023-08-18 15:39:24 --> Router Class Initialized
INFO - 2023-08-18 15:39:24 --> Output Class Initialized
INFO - 2023-08-18 15:39:24 --> Security Class Initialized
DEBUG - 2023-08-18 15:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:39:24 --> Input Class Initialized
INFO - 2023-08-18 15:39:24 --> Language Class Initialized
INFO - 2023-08-18 15:39:24 --> Loader Class Initialized
INFO - 2023-08-18 15:39:24 --> Helper loaded: url_helper
INFO - 2023-08-18 15:39:24 --> Helper loaded: file_helper
INFO - 2023-08-18 15:39:24 --> Helper loaded: html_helper
INFO - 2023-08-18 15:39:24 --> Helper loaded: text_helper
INFO - 2023-08-18 15:39:24 --> Helper loaded: form_helper
INFO - 2023-08-18 15:39:24 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:39:24 --> Helper loaded: security_helper
INFO - 2023-08-18 15:39:24 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:39:24 --> Database Driver Class Initialized
INFO - 2023-08-18 15:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:39:24 --> Parser Class Initialized
INFO - 2023-08-18 15:39:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:39:24 --> Pagination Class Initialized
INFO - 2023-08-18 15:39:24 --> Form Validation Class Initialized
INFO - 2023-08-18 15:39:24 --> Controller Class Initialized
INFO - 2023-08-18 15:39:24 --> Model Class Initialized
DEBUG - 2023-08-18 15:39:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:39:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:39:24 --> Model Class Initialized
INFO - 2023-08-18 15:39:24 --> Final output sent to browser
DEBUG - 2023-08-18 15:39:24 --> Total execution time: 0.0159
ERROR - 2023-08-18 15:39:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:39:25 --> Config Class Initialized
INFO - 2023-08-18 15:39:25 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:39:25 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:39:25 --> Utf8 Class Initialized
INFO - 2023-08-18 15:39:25 --> URI Class Initialized
INFO - 2023-08-18 15:39:25 --> Router Class Initialized
INFO - 2023-08-18 15:39:25 --> Output Class Initialized
INFO - 2023-08-18 15:39:25 --> Security Class Initialized
DEBUG - 2023-08-18 15:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:39:25 --> Input Class Initialized
INFO - 2023-08-18 15:39:25 --> Language Class Initialized
INFO - 2023-08-18 15:39:25 --> Loader Class Initialized
INFO - 2023-08-18 15:39:25 --> Helper loaded: url_helper
INFO - 2023-08-18 15:39:25 --> Helper loaded: file_helper
INFO - 2023-08-18 15:39:25 --> Helper loaded: html_helper
INFO - 2023-08-18 15:39:25 --> Helper loaded: text_helper
INFO - 2023-08-18 15:39:25 --> Helper loaded: form_helper
INFO - 2023-08-18 15:39:25 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:39:25 --> Helper loaded: security_helper
INFO - 2023-08-18 15:39:25 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:39:25 --> Database Driver Class Initialized
INFO - 2023-08-18 15:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:39:25 --> Parser Class Initialized
INFO - 2023-08-18 15:39:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:39:25 --> Pagination Class Initialized
INFO - 2023-08-18 15:39:25 --> Form Validation Class Initialized
INFO - 2023-08-18 15:39:25 --> Controller Class Initialized
INFO - 2023-08-18 15:39:25 --> Model Class Initialized
DEBUG - 2023-08-18 15:39:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:39:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:39:25 --> Model Class Initialized
INFO - 2023-08-18 15:39:25 --> Final output sent to browser
DEBUG - 2023-08-18 15:39:25 --> Total execution time: 0.0169
ERROR - 2023-08-18 15:39:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:39:41 --> Config Class Initialized
INFO - 2023-08-18 15:39:41 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:39:41 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:39:41 --> Utf8 Class Initialized
INFO - 2023-08-18 15:39:41 --> URI Class Initialized
INFO - 2023-08-18 15:39:41 --> Router Class Initialized
INFO - 2023-08-18 15:39:41 --> Output Class Initialized
INFO - 2023-08-18 15:39:41 --> Security Class Initialized
DEBUG - 2023-08-18 15:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:39:41 --> Input Class Initialized
INFO - 2023-08-18 15:39:41 --> Language Class Initialized
INFO - 2023-08-18 15:39:41 --> Loader Class Initialized
INFO - 2023-08-18 15:39:41 --> Helper loaded: url_helper
INFO - 2023-08-18 15:39:41 --> Helper loaded: file_helper
INFO - 2023-08-18 15:39:41 --> Helper loaded: html_helper
INFO - 2023-08-18 15:39:41 --> Helper loaded: text_helper
INFO - 2023-08-18 15:39:41 --> Helper loaded: form_helper
INFO - 2023-08-18 15:39:41 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:39:41 --> Helper loaded: security_helper
INFO - 2023-08-18 15:39:41 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:39:41 --> Database Driver Class Initialized
INFO - 2023-08-18 15:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:39:41 --> Parser Class Initialized
INFO - 2023-08-18 15:39:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:39:41 --> Pagination Class Initialized
INFO - 2023-08-18 15:39:41 --> Form Validation Class Initialized
INFO - 2023-08-18 15:39:41 --> Controller Class Initialized
INFO - 2023-08-18 15:39:41 --> Model Class Initialized
DEBUG - 2023-08-18 15:39:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:39:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:39:41 --> Model Class Initialized
INFO - 2023-08-18 15:39:41 --> Final output sent to browser
DEBUG - 2023-08-18 15:39:41 --> Total execution time: 0.0197
ERROR - 2023-08-18 15:42:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:42:03 --> Config Class Initialized
INFO - 2023-08-18 15:42:03 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:42:03 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:42:03 --> Utf8 Class Initialized
INFO - 2023-08-18 15:42:03 --> URI Class Initialized
INFO - 2023-08-18 15:42:03 --> Router Class Initialized
INFO - 2023-08-18 15:42:03 --> Output Class Initialized
INFO - 2023-08-18 15:42:03 --> Security Class Initialized
DEBUG - 2023-08-18 15:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:42:03 --> Input Class Initialized
INFO - 2023-08-18 15:42:03 --> Language Class Initialized
INFO - 2023-08-18 15:42:03 --> Loader Class Initialized
INFO - 2023-08-18 15:42:03 --> Helper loaded: url_helper
INFO - 2023-08-18 15:42:03 --> Helper loaded: file_helper
INFO - 2023-08-18 15:42:03 --> Helper loaded: html_helper
INFO - 2023-08-18 15:42:03 --> Helper loaded: text_helper
INFO - 2023-08-18 15:42:03 --> Helper loaded: form_helper
INFO - 2023-08-18 15:42:03 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:42:03 --> Helper loaded: security_helper
INFO - 2023-08-18 15:42:03 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:42:03 --> Database Driver Class Initialized
INFO - 2023-08-18 15:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:42:03 --> Parser Class Initialized
INFO - 2023-08-18 15:42:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:42:03 --> Pagination Class Initialized
INFO - 2023-08-18 15:42:03 --> Form Validation Class Initialized
INFO - 2023-08-18 15:42:03 --> Controller Class Initialized
INFO - 2023-08-18 15:42:03 --> Model Class Initialized
DEBUG - 2023-08-18 15:42:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:42:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:42:03 --> Model Class Initialized
DEBUG - 2023-08-18 15:42:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:42:03 --> Model Class Initialized
INFO - 2023-08-18 15:42:03 --> Final output sent to browser
DEBUG - 2023-08-18 15:42:03 --> Total execution time: 0.0579
ERROR - 2023-08-18 15:42:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:42:03 --> Config Class Initialized
INFO - 2023-08-18 15:42:03 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:42:03 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:42:03 --> Utf8 Class Initialized
INFO - 2023-08-18 15:42:03 --> URI Class Initialized
INFO - 2023-08-18 15:42:03 --> Router Class Initialized
INFO - 2023-08-18 15:42:03 --> Output Class Initialized
INFO - 2023-08-18 15:42:03 --> Security Class Initialized
DEBUG - 2023-08-18 15:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:42:03 --> Input Class Initialized
INFO - 2023-08-18 15:42:03 --> Language Class Initialized
INFO - 2023-08-18 15:42:03 --> Loader Class Initialized
INFO - 2023-08-18 15:42:03 --> Helper loaded: url_helper
INFO - 2023-08-18 15:42:03 --> Helper loaded: file_helper
INFO - 2023-08-18 15:42:03 --> Helper loaded: html_helper
INFO - 2023-08-18 15:42:03 --> Helper loaded: text_helper
INFO - 2023-08-18 15:42:03 --> Helper loaded: form_helper
INFO - 2023-08-18 15:42:03 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:42:03 --> Helper loaded: security_helper
INFO - 2023-08-18 15:42:03 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:42:03 --> Database Driver Class Initialized
INFO - 2023-08-18 15:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:42:03 --> Parser Class Initialized
INFO - 2023-08-18 15:42:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:42:03 --> Pagination Class Initialized
INFO - 2023-08-18 15:42:03 --> Form Validation Class Initialized
INFO - 2023-08-18 15:42:03 --> Controller Class Initialized
INFO - 2023-08-18 15:42:03 --> Model Class Initialized
DEBUG - 2023-08-18 15:42:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:42:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:42:03 --> Model Class Initialized
DEBUG - 2023-08-18 15:42:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:42:03 --> Model Class Initialized
INFO - 2023-08-18 15:42:03 --> Final output sent to browser
DEBUG - 2023-08-18 15:42:03 --> Total execution time: 0.0551
ERROR - 2023-08-18 15:42:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:42:19 --> Config Class Initialized
INFO - 2023-08-18 15:42:19 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:42:19 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:42:19 --> Utf8 Class Initialized
INFO - 2023-08-18 15:42:19 --> URI Class Initialized
INFO - 2023-08-18 15:42:19 --> Router Class Initialized
INFO - 2023-08-18 15:42:19 --> Output Class Initialized
INFO - 2023-08-18 15:42:19 --> Security Class Initialized
DEBUG - 2023-08-18 15:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:42:19 --> Input Class Initialized
INFO - 2023-08-18 15:42:19 --> Language Class Initialized
INFO - 2023-08-18 15:42:19 --> Loader Class Initialized
INFO - 2023-08-18 15:42:19 --> Helper loaded: url_helper
INFO - 2023-08-18 15:42:19 --> Helper loaded: file_helper
INFO - 2023-08-18 15:42:19 --> Helper loaded: html_helper
INFO - 2023-08-18 15:42:19 --> Helper loaded: text_helper
INFO - 2023-08-18 15:42:19 --> Helper loaded: form_helper
INFO - 2023-08-18 15:42:19 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:42:19 --> Helper loaded: security_helper
INFO - 2023-08-18 15:42:19 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:42:19 --> Database Driver Class Initialized
INFO - 2023-08-18 15:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:42:19 --> Parser Class Initialized
INFO - 2023-08-18 15:42:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:42:19 --> Pagination Class Initialized
INFO - 2023-08-18 15:42:19 --> Form Validation Class Initialized
INFO - 2023-08-18 15:42:19 --> Controller Class Initialized
INFO - 2023-08-18 15:42:19 --> Model Class Initialized
DEBUG - 2023-08-18 15:42:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:42:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:42:19 --> Model Class Initialized
DEBUG - 2023-08-18 15:42:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:42:19 --> Model Class Initialized
INFO - 2023-08-18 15:42:19 --> Final output sent to browser
DEBUG - 2023-08-18 15:42:19 --> Total execution time: 0.0227
ERROR - 2023-08-18 15:42:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:42:21 --> Config Class Initialized
INFO - 2023-08-18 15:42:21 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:42:21 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:42:21 --> Utf8 Class Initialized
INFO - 2023-08-18 15:42:21 --> URI Class Initialized
INFO - 2023-08-18 15:42:21 --> Router Class Initialized
INFO - 2023-08-18 15:42:21 --> Output Class Initialized
INFO - 2023-08-18 15:42:21 --> Security Class Initialized
DEBUG - 2023-08-18 15:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:42:21 --> Input Class Initialized
INFO - 2023-08-18 15:42:21 --> Language Class Initialized
INFO - 2023-08-18 15:42:21 --> Loader Class Initialized
INFO - 2023-08-18 15:42:21 --> Helper loaded: url_helper
INFO - 2023-08-18 15:42:21 --> Helper loaded: file_helper
INFO - 2023-08-18 15:42:21 --> Helper loaded: html_helper
INFO - 2023-08-18 15:42:21 --> Helper loaded: text_helper
INFO - 2023-08-18 15:42:21 --> Helper loaded: form_helper
INFO - 2023-08-18 15:42:21 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:42:21 --> Helper loaded: security_helper
INFO - 2023-08-18 15:42:21 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:42:21 --> Database Driver Class Initialized
INFO - 2023-08-18 15:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:42:21 --> Parser Class Initialized
INFO - 2023-08-18 15:42:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:42:21 --> Pagination Class Initialized
INFO - 2023-08-18 15:42:21 --> Form Validation Class Initialized
INFO - 2023-08-18 15:42:21 --> Controller Class Initialized
INFO - 2023-08-18 15:42:21 --> Model Class Initialized
DEBUG - 2023-08-18 15:42:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:42:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:42:21 --> Model Class Initialized
DEBUG - 2023-08-18 15:42:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:42:21 --> Model Class Initialized
INFO - 2023-08-18 15:42:21 --> Final output sent to browser
DEBUG - 2023-08-18 15:42:21 --> Total execution time: 0.0557
ERROR - 2023-08-18 15:42:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:42:22 --> Config Class Initialized
INFO - 2023-08-18 15:42:22 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:42:22 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:42:22 --> Utf8 Class Initialized
INFO - 2023-08-18 15:42:22 --> URI Class Initialized
INFO - 2023-08-18 15:42:22 --> Router Class Initialized
INFO - 2023-08-18 15:42:22 --> Output Class Initialized
INFO - 2023-08-18 15:42:22 --> Security Class Initialized
DEBUG - 2023-08-18 15:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:42:22 --> Input Class Initialized
INFO - 2023-08-18 15:42:22 --> Language Class Initialized
INFO - 2023-08-18 15:42:22 --> Loader Class Initialized
INFO - 2023-08-18 15:42:22 --> Helper loaded: url_helper
INFO - 2023-08-18 15:42:22 --> Helper loaded: file_helper
INFO - 2023-08-18 15:42:22 --> Helper loaded: html_helper
INFO - 2023-08-18 15:42:22 --> Helper loaded: text_helper
INFO - 2023-08-18 15:42:22 --> Helper loaded: form_helper
INFO - 2023-08-18 15:42:22 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:42:22 --> Helper loaded: security_helper
INFO - 2023-08-18 15:42:22 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:42:22 --> Database Driver Class Initialized
INFO - 2023-08-18 15:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:42:22 --> Parser Class Initialized
INFO - 2023-08-18 15:42:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:42:22 --> Pagination Class Initialized
INFO - 2023-08-18 15:42:22 --> Form Validation Class Initialized
INFO - 2023-08-18 15:42:22 --> Controller Class Initialized
INFO - 2023-08-18 15:42:22 --> Model Class Initialized
DEBUG - 2023-08-18 15:42:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:42:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:42:22 --> Model Class Initialized
DEBUG - 2023-08-18 15:42:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:42:22 --> Model Class Initialized
INFO - 2023-08-18 15:42:22 --> Final output sent to browser
DEBUG - 2023-08-18 15:42:22 --> Total execution time: 0.0211
ERROR - 2023-08-18 15:42:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:42:24 --> Config Class Initialized
INFO - 2023-08-18 15:42:24 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:42:24 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:42:24 --> Utf8 Class Initialized
INFO - 2023-08-18 15:42:24 --> URI Class Initialized
INFO - 2023-08-18 15:42:24 --> Router Class Initialized
INFO - 2023-08-18 15:42:24 --> Output Class Initialized
INFO - 2023-08-18 15:42:24 --> Security Class Initialized
DEBUG - 2023-08-18 15:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:42:24 --> Input Class Initialized
INFO - 2023-08-18 15:42:24 --> Language Class Initialized
INFO - 2023-08-18 15:42:24 --> Loader Class Initialized
INFO - 2023-08-18 15:42:24 --> Helper loaded: url_helper
INFO - 2023-08-18 15:42:24 --> Helper loaded: file_helper
INFO - 2023-08-18 15:42:24 --> Helper loaded: html_helper
INFO - 2023-08-18 15:42:24 --> Helper loaded: text_helper
INFO - 2023-08-18 15:42:24 --> Helper loaded: form_helper
INFO - 2023-08-18 15:42:24 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:42:24 --> Helper loaded: security_helper
INFO - 2023-08-18 15:42:24 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:42:24 --> Database Driver Class Initialized
INFO - 2023-08-18 15:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:42:24 --> Parser Class Initialized
INFO - 2023-08-18 15:42:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:42:24 --> Pagination Class Initialized
INFO - 2023-08-18 15:42:24 --> Form Validation Class Initialized
INFO - 2023-08-18 15:42:24 --> Controller Class Initialized
INFO - 2023-08-18 15:42:24 --> Model Class Initialized
DEBUG - 2023-08-18 15:42:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:42:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:42:24 --> Model Class Initialized
INFO - 2023-08-18 15:42:24 --> Model Class Initialized
INFO - 2023-08-18 15:42:24 --> Final output sent to browser
DEBUG - 2023-08-18 15:42:24 --> Total execution time: 0.0202
ERROR - 2023-08-18 15:42:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:42:37 --> Config Class Initialized
INFO - 2023-08-18 15:42:37 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:42:37 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:42:37 --> Utf8 Class Initialized
INFO - 2023-08-18 15:42:37 --> URI Class Initialized
INFO - 2023-08-18 15:42:37 --> Router Class Initialized
INFO - 2023-08-18 15:42:37 --> Output Class Initialized
INFO - 2023-08-18 15:42:37 --> Security Class Initialized
DEBUG - 2023-08-18 15:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:42:37 --> Input Class Initialized
INFO - 2023-08-18 15:42:37 --> Language Class Initialized
INFO - 2023-08-18 15:42:37 --> Loader Class Initialized
INFO - 2023-08-18 15:42:37 --> Helper loaded: url_helper
INFO - 2023-08-18 15:42:37 --> Helper loaded: file_helper
INFO - 2023-08-18 15:42:37 --> Helper loaded: html_helper
INFO - 2023-08-18 15:42:37 --> Helper loaded: text_helper
INFO - 2023-08-18 15:42:37 --> Helper loaded: form_helper
INFO - 2023-08-18 15:42:37 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:42:37 --> Helper loaded: security_helper
INFO - 2023-08-18 15:42:37 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:42:37 --> Database Driver Class Initialized
INFO - 2023-08-18 15:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:42:37 --> Parser Class Initialized
INFO - 2023-08-18 15:42:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:42:37 --> Pagination Class Initialized
INFO - 2023-08-18 15:42:37 --> Form Validation Class Initialized
INFO - 2023-08-18 15:42:37 --> Controller Class Initialized
INFO - 2023-08-18 15:42:37 --> Model Class Initialized
DEBUG - 2023-08-18 15:42:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:42:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:42:37 --> Model Class Initialized
INFO - 2023-08-18 15:42:37 --> Final output sent to browser
DEBUG - 2023-08-18 15:42:37 --> Total execution time: 0.0201
ERROR - 2023-08-18 15:50:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:50:45 --> Config Class Initialized
INFO - 2023-08-18 15:50:45 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:50:45 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:50:45 --> Utf8 Class Initialized
INFO - 2023-08-18 15:50:45 --> URI Class Initialized
INFO - 2023-08-18 15:50:45 --> Router Class Initialized
INFO - 2023-08-18 15:50:45 --> Output Class Initialized
INFO - 2023-08-18 15:50:45 --> Security Class Initialized
DEBUG - 2023-08-18 15:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:50:45 --> Input Class Initialized
INFO - 2023-08-18 15:50:45 --> Language Class Initialized
INFO - 2023-08-18 15:50:45 --> Loader Class Initialized
INFO - 2023-08-18 15:50:45 --> Helper loaded: url_helper
INFO - 2023-08-18 15:50:45 --> Helper loaded: file_helper
INFO - 2023-08-18 15:50:45 --> Helper loaded: html_helper
INFO - 2023-08-18 15:50:45 --> Helper loaded: text_helper
INFO - 2023-08-18 15:50:45 --> Helper loaded: form_helper
INFO - 2023-08-18 15:50:45 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:50:45 --> Helper loaded: security_helper
INFO - 2023-08-18 15:50:45 --> Helper loaded: cookie_helper
ERROR - 2023-08-18 15:50:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:50:45 --> Config Class Initialized
INFO - 2023-08-18 15:50:45 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:50:45 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:50:45 --> Utf8 Class Initialized
INFO - 2023-08-18 15:50:45 --> URI Class Initialized
INFO - 2023-08-18 15:50:45 --> Router Class Initialized
INFO - 2023-08-18 15:50:45 --> Database Driver Class Initialized
INFO - 2023-08-18 15:50:45 --> Output Class Initialized
INFO - 2023-08-18 15:50:45 --> Security Class Initialized
DEBUG - 2023-08-18 15:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:50:45 --> Input Class Initialized
INFO - 2023-08-18 15:50:45 --> Language Class Initialized
INFO - 2023-08-18 15:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:50:45 --> Parser Class Initialized
INFO - 2023-08-18 15:50:45 --> Loader Class Initialized
INFO - 2023-08-18 15:50:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:50:45 --> Pagination Class Initialized
INFO - 2023-08-18 15:50:45 --> Helper loaded: url_helper
INFO - 2023-08-18 15:50:45 --> Helper loaded: file_helper
INFO - 2023-08-18 15:50:45 --> Helper loaded: html_helper
INFO - 2023-08-18 15:50:45 --> Form Validation Class Initialized
INFO - 2023-08-18 15:50:45 --> Controller Class Initialized
INFO - 2023-08-18 15:50:45 --> Helper loaded: text_helper
INFO - 2023-08-18 15:50:45 --> Helper loaded: form_helper
INFO - 2023-08-18 15:50:45 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:50:45 --> Helper loaded: security_helper
INFO - 2023-08-18 15:50:45 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:50:45 --> Model Class Initialized
DEBUG - 2023-08-18 15:50:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:50:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:50:45 --> Database Driver Class Initialized
INFO - 2023-08-18 15:50:45 --> Model Class Initialized
DEBUG - 2023-08-18 15:50:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:50:45 --> Model Class Initialized
INFO - 2023-08-18 15:50:45 --> Final output sent to browser
DEBUG - 2023-08-18 15:50:45 --> Total execution time: 0.0614
INFO - 2023-08-18 15:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:50:45 --> Parser Class Initialized
INFO - 2023-08-18 15:50:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:50:45 --> Pagination Class Initialized
INFO - 2023-08-18 15:50:45 --> Form Validation Class Initialized
INFO - 2023-08-18 15:50:45 --> Controller Class Initialized
INFO - 2023-08-18 15:50:45 --> Model Class Initialized
DEBUG - 2023-08-18 15:50:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:50:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:50:45 --> Model Class Initialized
DEBUG - 2023-08-18 15:50:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:50:45 --> Model Class Initialized
INFO - 2023-08-18 15:50:45 --> Final output sent to browser
DEBUG - 2023-08-18 15:50:45 --> Total execution time: 0.0619
ERROR - 2023-08-18 15:50:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:50:45 --> Config Class Initialized
INFO - 2023-08-18 15:50:45 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:50:45 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:50:45 --> Utf8 Class Initialized
INFO - 2023-08-18 15:50:45 --> URI Class Initialized
INFO - 2023-08-18 15:50:45 --> Router Class Initialized
INFO - 2023-08-18 15:50:45 --> Output Class Initialized
INFO - 2023-08-18 15:50:45 --> Security Class Initialized
DEBUG - 2023-08-18 15:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:50:45 --> Input Class Initialized
INFO - 2023-08-18 15:50:45 --> Language Class Initialized
INFO - 2023-08-18 15:50:45 --> Loader Class Initialized
INFO - 2023-08-18 15:50:45 --> Helper loaded: url_helper
INFO - 2023-08-18 15:50:45 --> Helper loaded: file_helper
INFO - 2023-08-18 15:50:45 --> Helper loaded: html_helper
INFO - 2023-08-18 15:50:45 --> Helper loaded: text_helper
INFO - 2023-08-18 15:50:45 --> Helper loaded: form_helper
INFO - 2023-08-18 15:50:45 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:50:45 --> Helper loaded: security_helper
INFO - 2023-08-18 15:50:45 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:50:45 --> Database Driver Class Initialized
INFO - 2023-08-18 15:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:50:45 --> Parser Class Initialized
INFO - 2023-08-18 15:50:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:50:45 --> Pagination Class Initialized
INFO - 2023-08-18 15:50:45 --> Form Validation Class Initialized
INFO - 2023-08-18 15:50:45 --> Controller Class Initialized
INFO - 2023-08-18 15:50:45 --> Model Class Initialized
DEBUG - 2023-08-18 15:50:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:50:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:50:45 --> Model Class Initialized
DEBUG - 2023-08-18 15:50:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:50:45 --> Model Class Initialized
INFO - 2023-08-18 15:50:45 --> Final output sent to browser
DEBUG - 2023-08-18 15:50:45 --> Total execution time: 0.0179
ERROR - 2023-08-18 15:50:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:50:47 --> Config Class Initialized
INFO - 2023-08-18 15:50:47 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:50:47 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:50:47 --> Utf8 Class Initialized
INFO - 2023-08-18 15:50:47 --> URI Class Initialized
INFO - 2023-08-18 15:50:47 --> Router Class Initialized
INFO - 2023-08-18 15:50:47 --> Output Class Initialized
INFO - 2023-08-18 15:50:47 --> Security Class Initialized
DEBUG - 2023-08-18 15:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:50:47 --> Input Class Initialized
INFO - 2023-08-18 15:50:47 --> Language Class Initialized
INFO - 2023-08-18 15:50:47 --> Loader Class Initialized
INFO - 2023-08-18 15:50:47 --> Helper loaded: url_helper
INFO - 2023-08-18 15:50:47 --> Helper loaded: file_helper
INFO - 2023-08-18 15:50:47 --> Helper loaded: html_helper
INFO - 2023-08-18 15:50:47 --> Helper loaded: text_helper
INFO - 2023-08-18 15:50:47 --> Helper loaded: form_helper
INFO - 2023-08-18 15:50:47 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:50:47 --> Helper loaded: security_helper
INFO - 2023-08-18 15:50:47 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:50:47 --> Database Driver Class Initialized
INFO - 2023-08-18 15:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:50:47 --> Parser Class Initialized
INFO - 2023-08-18 15:50:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:50:47 --> Pagination Class Initialized
INFO - 2023-08-18 15:50:47 --> Form Validation Class Initialized
INFO - 2023-08-18 15:50:47 --> Controller Class Initialized
INFO - 2023-08-18 15:50:47 --> Model Class Initialized
DEBUG - 2023-08-18 15:50:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:50:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:50:47 --> Model Class Initialized
DEBUG - 2023-08-18 15:50:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:50:47 --> Model Class Initialized
INFO - 2023-08-18 15:50:47 --> Final output sent to browser
DEBUG - 2023-08-18 15:50:47 --> Total execution time: 0.0192
ERROR - 2023-08-18 15:50:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:50:48 --> Config Class Initialized
INFO - 2023-08-18 15:50:48 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:50:48 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:50:48 --> Utf8 Class Initialized
INFO - 2023-08-18 15:50:48 --> URI Class Initialized
INFO - 2023-08-18 15:50:48 --> Router Class Initialized
INFO - 2023-08-18 15:50:48 --> Output Class Initialized
INFO - 2023-08-18 15:50:48 --> Security Class Initialized
DEBUG - 2023-08-18 15:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:50:48 --> Input Class Initialized
INFO - 2023-08-18 15:50:48 --> Language Class Initialized
INFO - 2023-08-18 15:50:48 --> Loader Class Initialized
INFO - 2023-08-18 15:50:48 --> Helper loaded: url_helper
INFO - 2023-08-18 15:50:48 --> Helper loaded: file_helper
INFO - 2023-08-18 15:50:48 --> Helper loaded: html_helper
INFO - 2023-08-18 15:50:48 --> Helper loaded: text_helper
INFO - 2023-08-18 15:50:48 --> Helper loaded: form_helper
INFO - 2023-08-18 15:50:48 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:50:48 --> Helper loaded: security_helper
INFO - 2023-08-18 15:50:48 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:50:48 --> Database Driver Class Initialized
INFO - 2023-08-18 15:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:50:48 --> Parser Class Initialized
INFO - 2023-08-18 15:50:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:50:48 --> Pagination Class Initialized
INFO - 2023-08-18 15:50:48 --> Form Validation Class Initialized
INFO - 2023-08-18 15:50:48 --> Controller Class Initialized
INFO - 2023-08-18 15:50:48 --> Model Class Initialized
DEBUG - 2023-08-18 15:50:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:50:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:50:48 --> Model Class Initialized
DEBUG - 2023-08-18 15:50:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:50:48 --> Model Class Initialized
INFO - 2023-08-18 15:50:49 --> Final output sent to browser
DEBUG - 2023-08-18 15:50:49 --> Total execution time: 0.0587
ERROR - 2023-08-18 15:50:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:50:51 --> Config Class Initialized
INFO - 2023-08-18 15:50:51 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:50:51 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:50:51 --> Utf8 Class Initialized
INFO - 2023-08-18 15:50:51 --> URI Class Initialized
INFO - 2023-08-18 15:50:51 --> Router Class Initialized
INFO - 2023-08-18 15:50:51 --> Output Class Initialized
INFO - 2023-08-18 15:50:51 --> Security Class Initialized
DEBUG - 2023-08-18 15:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:50:51 --> Input Class Initialized
INFO - 2023-08-18 15:50:51 --> Language Class Initialized
INFO - 2023-08-18 15:50:51 --> Loader Class Initialized
INFO - 2023-08-18 15:50:51 --> Helper loaded: url_helper
INFO - 2023-08-18 15:50:51 --> Helper loaded: file_helper
INFO - 2023-08-18 15:50:51 --> Helper loaded: html_helper
INFO - 2023-08-18 15:50:51 --> Helper loaded: text_helper
INFO - 2023-08-18 15:50:51 --> Helper loaded: form_helper
INFO - 2023-08-18 15:50:51 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:50:51 --> Helper loaded: security_helper
INFO - 2023-08-18 15:50:51 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:50:51 --> Database Driver Class Initialized
INFO - 2023-08-18 15:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:50:51 --> Parser Class Initialized
INFO - 2023-08-18 15:50:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:50:51 --> Pagination Class Initialized
INFO - 2023-08-18 15:50:51 --> Form Validation Class Initialized
INFO - 2023-08-18 15:50:51 --> Controller Class Initialized
INFO - 2023-08-18 15:50:51 --> Model Class Initialized
DEBUG - 2023-08-18 15:50:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:50:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:50:51 --> Model Class Initialized
DEBUG - 2023-08-18 15:50:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:50:51 --> Model Class Initialized
INFO - 2023-08-18 15:50:51 --> Final output sent to browser
DEBUG - 2023-08-18 15:50:51 --> Total execution time: 0.0182
ERROR - 2023-08-18 15:50:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:50:53 --> Config Class Initialized
INFO - 2023-08-18 15:50:53 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:50:53 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:50:53 --> Utf8 Class Initialized
INFO - 2023-08-18 15:50:53 --> URI Class Initialized
INFO - 2023-08-18 15:50:53 --> Router Class Initialized
INFO - 2023-08-18 15:50:53 --> Output Class Initialized
INFO - 2023-08-18 15:50:53 --> Security Class Initialized
DEBUG - 2023-08-18 15:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:50:53 --> Input Class Initialized
INFO - 2023-08-18 15:50:53 --> Language Class Initialized
INFO - 2023-08-18 15:50:53 --> Loader Class Initialized
INFO - 2023-08-18 15:50:53 --> Helper loaded: url_helper
INFO - 2023-08-18 15:50:53 --> Helper loaded: file_helper
INFO - 2023-08-18 15:50:53 --> Helper loaded: html_helper
INFO - 2023-08-18 15:50:53 --> Helper loaded: text_helper
INFO - 2023-08-18 15:50:53 --> Helper loaded: form_helper
INFO - 2023-08-18 15:50:53 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:50:53 --> Helper loaded: security_helper
INFO - 2023-08-18 15:50:53 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:50:53 --> Database Driver Class Initialized
INFO - 2023-08-18 15:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:50:53 --> Parser Class Initialized
INFO - 2023-08-18 15:50:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:50:53 --> Pagination Class Initialized
INFO - 2023-08-18 15:50:53 --> Form Validation Class Initialized
INFO - 2023-08-18 15:50:53 --> Controller Class Initialized
INFO - 2023-08-18 15:50:53 --> Model Class Initialized
DEBUG - 2023-08-18 15:50:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:50:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:50:53 --> Model Class Initialized
DEBUG - 2023-08-18 15:50:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:50:53 --> Model Class Initialized
INFO - 2023-08-18 15:50:53 --> Final output sent to browser
DEBUG - 2023-08-18 15:50:53 --> Total execution time: 0.0175
ERROR - 2023-08-18 15:50:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:50:56 --> Config Class Initialized
INFO - 2023-08-18 15:50:56 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:50:56 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:50:56 --> Utf8 Class Initialized
INFO - 2023-08-18 15:50:56 --> URI Class Initialized
INFO - 2023-08-18 15:50:56 --> Router Class Initialized
INFO - 2023-08-18 15:50:56 --> Output Class Initialized
INFO - 2023-08-18 15:50:56 --> Security Class Initialized
DEBUG - 2023-08-18 15:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:50:56 --> Input Class Initialized
INFO - 2023-08-18 15:50:56 --> Language Class Initialized
INFO - 2023-08-18 15:50:56 --> Loader Class Initialized
INFO - 2023-08-18 15:50:56 --> Helper loaded: url_helper
INFO - 2023-08-18 15:50:56 --> Helper loaded: file_helper
INFO - 2023-08-18 15:50:56 --> Helper loaded: html_helper
INFO - 2023-08-18 15:50:56 --> Helper loaded: text_helper
INFO - 2023-08-18 15:50:56 --> Helper loaded: form_helper
INFO - 2023-08-18 15:50:56 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:50:56 --> Helper loaded: security_helper
INFO - 2023-08-18 15:50:56 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:50:56 --> Database Driver Class Initialized
INFO - 2023-08-18 15:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:50:56 --> Parser Class Initialized
INFO - 2023-08-18 15:50:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:50:56 --> Pagination Class Initialized
INFO - 2023-08-18 15:50:56 --> Form Validation Class Initialized
INFO - 2023-08-18 15:50:56 --> Controller Class Initialized
INFO - 2023-08-18 15:50:56 --> Model Class Initialized
DEBUG - 2023-08-18 15:50:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:50:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:50:56 --> Model Class Initialized
DEBUG - 2023-08-18 15:50:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:50:56 --> Model Class Initialized
INFO - 2023-08-18 15:50:56 --> Final output sent to browser
DEBUG - 2023-08-18 15:50:56 --> Total execution time: 0.0182
ERROR - 2023-08-18 15:50:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:50:56 --> Config Class Initialized
INFO - 2023-08-18 15:50:56 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:50:56 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:50:56 --> Utf8 Class Initialized
INFO - 2023-08-18 15:50:56 --> URI Class Initialized
INFO - 2023-08-18 15:50:56 --> Router Class Initialized
INFO - 2023-08-18 15:50:56 --> Output Class Initialized
INFO - 2023-08-18 15:50:56 --> Security Class Initialized
DEBUG - 2023-08-18 15:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:50:56 --> Input Class Initialized
INFO - 2023-08-18 15:50:56 --> Language Class Initialized
INFO - 2023-08-18 15:50:56 --> Loader Class Initialized
INFO - 2023-08-18 15:50:56 --> Helper loaded: url_helper
INFO - 2023-08-18 15:50:56 --> Helper loaded: file_helper
INFO - 2023-08-18 15:50:56 --> Helper loaded: html_helper
INFO - 2023-08-18 15:50:56 --> Helper loaded: text_helper
INFO - 2023-08-18 15:50:56 --> Helper loaded: form_helper
INFO - 2023-08-18 15:50:56 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:50:56 --> Helper loaded: security_helper
INFO - 2023-08-18 15:50:56 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:50:56 --> Database Driver Class Initialized
INFO - 2023-08-18 15:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:50:56 --> Parser Class Initialized
INFO - 2023-08-18 15:50:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:50:56 --> Pagination Class Initialized
INFO - 2023-08-18 15:50:56 --> Form Validation Class Initialized
INFO - 2023-08-18 15:50:56 --> Controller Class Initialized
INFO - 2023-08-18 15:50:56 --> Model Class Initialized
DEBUG - 2023-08-18 15:50:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:50:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:50:56 --> Model Class Initialized
DEBUG - 2023-08-18 15:50:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:50:56 --> Model Class Initialized
INFO - 2023-08-18 15:50:56 --> Final output sent to browser
DEBUG - 2023-08-18 15:50:56 --> Total execution time: 0.0566
ERROR - 2023-08-18 15:50:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:50:57 --> Config Class Initialized
INFO - 2023-08-18 15:50:57 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:50:57 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:50:57 --> Utf8 Class Initialized
INFO - 2023-08-18 15:50:57 --> URI Class Initialized
INFO - 2023-08-18 15:50:57 --> Router Class Initialized
INFO - 2023-08-18 15:50:57 --> Output Class Initialized
INFO - 2023-08-18 15:50:57 --> Security Class Initialized
DEBUG - 2023-08-18 15:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:50:57 --> Input Class Initialized
INFO - 2023-08-18 15:50:57 --> Language Class Initialized
INFO - 2023-08-18 15:50:57 --> Loader Class Initialized
INFO - 2023-08-18 15:50:57 --> Helper loaded: url_helper
INFO - 2023-08-18 15:50:57 --> Helper loaded: file_helper
INFO - 2023-08-18 15:50:57 --> Helper loaded: html_helper
INFO - 2023-08-18 15:50:57 --> Helper loaded: text_helper
INFO - 2023-08-18 15:50:57 --> Helper loaded: form_helper
INFO - 2023-08-18 15:50:57 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:50:57 --> Helper loaded: security_helper
INFO - 2023-08-18 15:50:57 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:50:57 --> Database Driver Class Initialized
INFO - 2023-08-18 15:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:50:57 --> Parser Class Initialized
INFO - 2023-08-18 15:50:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:50:57 --> Pagination Class Initialized
INFO - 2023-08-18 15:50:57 --> Form Validation Class Initialized
INFO - 2023-08-18 15:50:57 --> Controller Class Initialized
INFO - 2023-08-18 15:50:57 --> Model Class Initialized
DEBUG - 2023-08-18 15:50:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:50:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:50:57 --> Model Class Initialized
DEBUG - 2023-08-18 15:50:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:50:57 --> Model Class Initialized
INFO - 2023-08-18 15:50:57 --> Final output sent to browser
DEBUG - 2023-08-18 15:50:57 --> Total execution time: 0.0623
ERROR - 2023-08-18 15:50:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:50:58 --> Config Class Initialized
INFO - 2023-08-18 15:50:58 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:50:58 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:50:58 --> Utf8 Class Initialized
INFO - 2023-08-18 15:50:58 --> URI Class Initialized
INFO - 2023-08-18 15:50:58 --> Router Class Initialized
INFO - 2023-08-18 15:50:58 --> Output Class Initialized
INFO - 2023-08-18 15:50:58 --> Security Class Initialized
DEBUG - 2023-08-18 15:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:50:58 --> Input Class Initialized
INFO - 2023-08-18 15:50:58 --> Language Class Initialized
INFO - 2023-08-18 15:50:58 --> Loader Class Initialized
INFO - 2023-08-18 15:50:58 --> Helper loaded: url_helper
INFO - 2023-08-18 15:50:58 --> Helper loaded: file_helper
INFO - 2023-08-18 15:50:58 --> Helper loaded: html_helper
INFO - 2023-08-18 15:50:58 --> Helper loaded: text_helper
INFO - 2023-08-18 15:50:58 --> Helper loaded: form_helper
INFO - 2023-08-18 15:50:58 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:50:58 --> Helper loaded: security_helper
INFO - 2023-08-18 15:50:58 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:50:58 --> Database Driver Class Initialized
INFO - 2023-08-18 15:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:50:58 --> Parser Class Initialized
INFO - 2023-08-18 15:50:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:50:58 --> Pagination Class Initialized
INFO - 2023-08-18 15:50:58 --> Form Validation Class Initialized
INFO - 2023-08-18 15:50:58 --> Controller Class Initialized
INFO - 2023-08-18 15:50:58 --> Model Class Initialized
DEBUG - 2023-08-18 15:50:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:50:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:50:58 --> Model Class Initialized
DEBUG - 2023-08-18 15:50:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:50:58 --> Model Class Initialized
INFO - 2023-08-18 15:50:58 --> Final output sent to browser
DEBUG - 2023-08-18 15:50:58 --> Total execution time: 0.0550
ERROR - 2023-08-18 15:50:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:50:59 --> Config Class Initialized
INFO - 2023-08-18 15:50:59 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:50:59 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:50:59 --> Utf8 Class Initialized
INFO - 2023-08-18 15:50:59 --> URI Class Initialized
INFO - 2023-08-18 15:50:59 --> Router Class Initialized
INFO - 2023-08-18 15:50:59 --> Output Class Initialized
INFO - 2023-08-18 15:50:59 --> Security Class Initialized
DEBUG - 2023-08-18 15:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:50:59 --> Input Class Initialized
INFO - 2023-08-18 15:50:59 --> Language Class Initialized
INFO - 2023-08-18 15:50:59 --> Loader Class Initialized
INFO - 2023-08-18 15:50:59 --> Helper loaded: url_helper
INFO - 2023-08-18 15:50:59 --> Helper loaded: file_helper
INFO - 2023-08-18 15:50:59 --> Helper loaded: html_helper
INFO - 2023-08-18 15:50:59 --> Helper loaded: text_helper
INFO - 2023-08-18 15:50:59 --> Helper loaded: form_helper
INFO - 2023-08-18 15:50:59 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:50:59 --> Helper loaded: security_helper
INFO - 2023-08-18 15:50:59 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:50:59 --> Database Driver Class Initialized
INFO - 2023-08-18 15:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:50:59 --> Parser Class Initialized
INFO - 2023-08-18 15:50:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:50:59 --> Pagination Class Initialized
INFO - 2023-08-18 15:50:59 --> Form Validation Class Initialized
INFO - 2023-08-18 15:50:59 --> Controller Class Initialized
INFO - 2023-08-18 15:50:59 --> Model Class Initialized
DEBUG - 2023-08-18 15:50:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:50:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:50:59 --> Model Class Initialized
DEBUG - 2023-08-18 15:50:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:50:59 --> Model Class Initialized
INFO - 2023-08-18 15:50:59 --> Final output sent to browser
DEBUG - 2023-08-18 15:50:59 --> Total execution time: 0.0522
ERROR - 2023-08-18 15:50:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:50:59 --> Config Class Initialized
INFO - 2023-08-18 15:50:59 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:50:59 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:50:59 --> Utf8 Class Initialized
INFO - 2023-08-18 15:50:59 --> URI Class Initialized
INFO - 2023-08-18 15:50:59 --> Router Class Initialized
INFO - 2023-08-18 15:50:59 --> Output Class Initialized
INFO - 2023-08-18 15:50:59 --> Security Class Initialized
DEBUG - 2023-08-18 15:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:50:59 --> Input Class Initialized
INFO - 2023-08-18 15:50:59 --> Language Class Initialized
INFO - 2023-08-18 15:50:59 --> Loader Class Initialized
INFO - 2023-08-18 15:50:59 --> Helper loaded: url_helper
INFO - 2023-08-18 15:50:59 --> Helper loaded: file_helper
INFO - 2023-08-18 15:50:59 --> Helper loaded: html_helper
INFO - 2023-08-18 15:50:59 --> Helper loaded: text_helper
INFO - 2023-08-18 15:50:59 --> Helper loaded: form_helper
INFO - 2023-08-18 15:50:59 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:50:59 --> Helper loaded: security_helper
INFO - 2023-08-18 15:50:59 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:50:59 --> Database Driver Class Initialized
INFO - 2023-08-18 15:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:50:59 --> Parser Class Initialized
INFO - 2023-08-18 15:50:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:50:59 --> Pagination Class Initialized
INFO - 2023-08-18 15:50:59 --> Form Validation Class Initialized
INFO - 2023-08-18 15:50:59 --> Controller Class Initialized
INFO - 2023-08-18 15:50:59 --> Model Class Initialized
DEBUG - 2023-08-18 15:50:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:50:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:50:59 --> Model Class Initialized
DEBUG - 2023-08-18 15:50:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:50:59 --> Model Class Initialized
INFO - 2023-08-18 15:50:59 --> Final output sent to browser
DEBUG - 2023-08-18 15:50:59 --> Total execution time: 0.0536
ERROR - 2023-08-18 15:51:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:51:03 --> Config Class Initialized
INFO - 2023-08-18 15:51:03 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:51:03 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:51:03 --> Utf8 Class Initialized
INFO - 2023-08-18 15:51:03 --> URI Class Initialized
INFO - 2023-08-18 15:51:03 --> Router Class Initialized
INFO - 2023-08-18 15:51:03 --> Output Class Initialized
INFO - 2023-08-18 15:51:03 --> Security Class Initialized
DEBUG - 2023-08-18 15:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:51:03 --> Input Class Initialized
INFO - 2023-08-18 15:51:03 --> Language Class Initialized
INFO - 2023-08-18 15:51:03 --> Loader Class Initialized
INFO - 2023-08-18 15:51:03 --> Helper loaded: url_helper
INFO - 2023-08-18 15:51:03 --> Helper loaded: file_helper
INFO - 2023-08-18 15:51:03 --> Helper loaded: html_helper
INFO - 2023-08-18 15:51:03 --> Helper loaded: text_helper
INFO - 2023-08-18 15:51:03 --> Helper loaded: form_helper
INFO - 2023-08-18 15:51:03 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:51:03 --> Helper loaded: security_helper
INFO - 2023-08-18 15:51:03 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:51:03 --> Database Driver Class Initialized
INFO - 2023-08-18 15:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:51:03 --> Parser Class Initialized
INFO - 2023-08-18 15:51:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:51:03 --> Pagination Class Initialized
INFO - 2023-08-18 15:51:03 --> Form Validation Class Initialized
INFO - 2023-08-18 15:51:03 --> Controller Class Initialized
INFO - 2023-08-18 15:51:03 --> Model Class Initialized
DEBUG - 2023-08-18 15:51:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:51:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:51:03 --> Model Class Initialized
DEBUG - 2023-08-18 15:51:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:51:03 --> Model Class Initialized
INFO - 2023-08-18 15:51:03 --> Final output sent to browser
DEBUG - 2023-08-18 15:51:03 --> Total execution time: 0.0244
ERROR - 2023-08-18 15:51:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:51:06 --> Config Class Initialized
INFO - 2023-08-18 15:51:06 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:51:06 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:51:06 --> Utf8 Class Initialized
INFO - 2023-08-18 15:51:06 --> URI Class Initialized
INFO - 2023-08-18 15:51:06 --> Router Class Initialized
INFO - 2023-08-18 15:51:06 --> Output Class Initialized
INFO - 2023-08-18 15:51:06 --> Security Class Initialized
DEBUG - 2023-08-18 15:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:51:06 --> Input Class Initialized
INFO - 2023-08-18 15:51:06 --> Language Class Initialized
INFO - 2023-08-18 15:51:06 --> Loader Class Initialized
INFO - 2023-08-18 15:51:06 --> Helper loaded: url_helper
INFO - 2023-08-18 15:51:06 --> Helper loaded: file_helper
INFO - 2023-08-18 15:51:06 --> Helper loaded: html_helper
INFO - 2023-08-18 15:51:06 --> Helper loaded: text_helper
INFO - 2023-08-18 15:51:06 --> Helper loaded: form_helper
INFO - 2023-08-18 15:51:06 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:51:06 --> Helper loaded: security_helper
INFO - 2023-08-18 15:51:06 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:51:06 --> Database Driver Class Initialized
INFO - 2023-08-18 15:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:51:06 --> Parser Class Initialized
INFO - 2023-08-18 15:51:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:51:06 --> Pagination Class Initialized
INFO - 2023-08-18 15:51:06 --> Form Validation Class Initialized
INFO - 2023-08-18 15:51:06 --> Controller Class Initialized
INFO - 2023-08-18 15:51:06 --> Model Class Initialized
DEBUG - 2023-08-18 15:51:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:51:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:51:06 --> Model Class Initialized
DEBUG - 2023-08-18 15:51:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:51:06 --> Model Class Initialized
INFO - 2023-08-18 15:51:06 --> Final output sent to browser
DEBUG - 2023-08-18 15:51:06 --> Total execution time: 0.0179
ERROR - 2023-08-18 15:51:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:51:09 --> Config Class Initialized
INFO - 2023-08-18 15:51:09 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:51:09 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:51:09 --> Utf8 Class Initialized
INFO - 2023-08-18 15:51:09 --> URI Class Initialized
INFO - 2023-08-18 15:51:09 --> Router Class Initialized
INFO - 2023-08-18 15:51:09 --> Output Class Initialized
INFO - 2023-08-18 15:51:09 --> Security Class Initialized
DEBUG - 2023-08-18 15:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:51:09 --> Input Class Initialized
INFO - 2023-08-18 15:51:09 --> Language Class Initialized
INFO - 2023-08-18 15:51:09 --> Loader Class Initialized
INFO - 2023-08-18 15:51:09 --> Helper loaded: url_helper
INFO - 2023-08-18 15:51:09 --> Helper loaded: file_helper
INFO - 2023-08-18 15:51:09 --> Helper loaded: html_helper
INFO - 2023-08-18 15:51:09 --> Helper loaded: text_helper
INFO - 2023-08-18 15:51:09 --> Helper loaded: form_helper
INFO - 2023-08-18 15:51:09 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:51:09 --> Helper loaded: security_helper
INFO - 2023-08-18 15:51:09 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:51:09 --> Database Driver Class Initialized
INFO - 2023-08-18 15:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:51:09 --> Parser Class Initialized
INFO - 2023-08-18 15:51:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:51:09 --> Pagination Class Initialized
INFO - 2023-08-18 15:51:09 --> Form Validation Class Initialized
INFO - 2023-08-18 15:51:09 --> Controller Class Initialized
INFO - 2023-08-18 15:51:09 --> Model Class Initialized
DEBUG - 2023-08-18 15:51:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:51:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:51:09 --> Model Class Initialized
DEBUG - 2023-08-18 15:51:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:51:09 --> Model Class Initialized
INFO - 2023-08-18 15:51:09 --> Final output sent to browser
DEBUG - 2023-08-18 15:51:09 --> Total execution time: 0.0220
ERROR - 2023-08-18 15:51:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:51:17 --> Config Class Initialized
INFO - 2023-08-18 15:51:17 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:51:17 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:51:17 --> Utf8 Class Initialized
INFO - 2023-08-18 15:51:17 --> URI Class Initialized
INFO - 2023-08-18 15:51:17 --> Router Class Initialized
INFO - 2023-08-18 15:51:17 --> Output Class Initialized
INFO - 2023-08-18 15:51:17 --> Security Class Initialized
DEBUG - 2023-08-18 15:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:51:17 --> Input Class Initialized
INFO - 2023-08-18 15:51:17 --> Language Class Initialized
INFO - 2023-08-18 15:51:17 --> Loader Class Initialized
INFO - 2023-08-18 15:51:17 --> Helper loaded: url_helper
INFO - 2023-08-18 15:51:17 --> Helper loaded: file_helper
INFO - 2023-08-18 15:51:17 --> Helper loaded: html_helper
INFO - 2023-08-18 15:51:17 --> Helper loaded: text_helper
INFO - 2023-08-18 15:51:17 --> Helper loaded: form_helper
INFO - 2023-08-18 15:51:17 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:51:17 --> Helper loaded: security_helper
INFO - 2023-08-18 15:51:17 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:51:17 --> Database Driver Class Initialized
INFO - 2023-08-18 15:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:51:17 --> Parser Class Initialized
INFO - 2023-08-18 15:51:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:51:17 --> Pagination Class Initialized
INFO - 2023-08-18 15:51:17 --> Form Validation Class Initialized
INFO - 2023-08-18 15:51:17 --> Controller Class Initialized
INFO - 2023-08-18 15:51:17 --> Model Class Initialized
DEBUG - 2023-08-18 15:51:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:51:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:51:17 --> Model Class Initialized
INFO - 2023-08-18 15:51:17 --> Model Class Initialized
INFO - 2023-08-18 15:51:17 --> Final output sent to browser
DEBUG - 2023-08-18 15:51:17 --> Total execution time: 0.0194
ERROR - 2023-08-18 15:51:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:51:20 --> Config Class Initialized
INFO - 2023-08-18 15:51:20 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:51:20 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:51:20 --> Utf8 Class Initialized
INFO - 2023-08-18 15:51:20 --> URI Class Initialized
INFO - 2023-08-18 15:51:20 --> Router Class Initialized
INFO - 2023-08-18 15:51:20 --> Output Class Initialized
INFO - 2023-08-18 15:51:20 --> Security Class Initialized
DEBUG - 2023-08-18 15:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:51:20 --> Input Class Initialized
INFO - 2023-08-18 15:51:20 --> Language Class Initialized
INFO - 2023-08-18 15:51:20 --> Loader Class Initialized
INFO - 2023-08-18 15:51:20 --> Helper loaded: url_helper
INFO - 2023-08-18 15:51:20 --> Helper loaded: file_helper
INFO - 2023-08-18 15:51:20 --> Helper loaded: html_helper
INFO - 2023-08-18 15:51:20 --> Helper loaded: text_helper
INFO - 2023-08-18 15:51:20 --> Helper loaded: form_helper
INFO - 2023-08-18 15:51:20 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:51:20 --> Helper loaded: security_helper
INFO - 2023-08-18 15:51:20 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:51:20 --> Database Driver Class Initialized
INFO - 2023-08-18 15:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:51:20 --> Parser Class Initialized
INFO - 2023-08-18 15:51:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:51:20 --> Pagination Class Initialized
INFO - 2023-08-18 15:51:20 --> Form Validation Class Initialized
INFO - 2023-08-18 15:51:20 --> Controller Class Initialized
INFO - 2023-08-18 15:51:20 --> Model Class Initialized
DEBUG - 2023-08-18 15:51:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:51:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:51:20 --> Model Class Initialized
INFO - 2023-08-18 15:51:20 --> Final output sent to browser
DEBUG - 2023-08-18 15:51:20 --> Total execution time: 0.0157
ERROR - 2023-08-18 15:51:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:51:47 --> Config Class Initialized
INFO - 2023-08-18 15:51:47 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:51:47 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:51:47 --> Utf8 Class Initialized
INFO - 2023-08-18 15:51:47 --> URI Class Initialized
INFO - 2023-08-18 15:51:47 --> Router Class Initialized
INFO - 2023-08-18 15:51:47 --> Output Class Initialized
INFO - 2023-08-18 15:51:47 --> Security Class Initialized
DEBUG - 2023-08-18 15:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:51:47 --> Input Class Initialized
INFO - 2023-08-18 15:51:47 --> Language Class Initialized
INFO - 2023-08-18 15:51:47 --> Loader Class Initialized
INFO - 2023-08-18 15:51:47 --> Helper loaded: url_helper
INFO - 2023-08-18 15:51:47 --> Helper loaded: file_helper
INFO - 2023-08-18 15:51:47 --> Helper loaded: html_helper
INFO - 2023-08-18 15:51:47 --> Helper loaded: text_helper
INFO - 2023-08-18 15:51:47 --> Helper loaded: form_helper
INFO - 2023-08-18 15:51:47 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:51:47 --> Helper loaded: security_helper
INFO - 2023-08-18 15:51:47 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:51:47 --> Database Driver Class Initialized
INFO - 2023-08-18 15:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:51:47 --> Parser Class Initialized
INFO - 2023-08-18 15:51:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:51:47 --> Pagination Class Initialized
INFO - 2023-08-18 15:51:47 --> Form Validation Class Initialized
INFO - 2023-08-18 15:51:47 --> Controller Class Initialized
INFO - 2023-08-18 15:51:47 --> Model Class Initialized
DEBUG - 2023-08-18 15:51:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:51:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:51:47 --> Model Class Initialized
DEBUG - 2023-08-18 15:51:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:51:47 --> Model Class Initialized
INFO - 2023-08-18 15:51:47 --> Final output sent to browser
DEBUG - 2023-08-18 15:51:47 --> Total execution time: 0.0619
ERROR - 2023-08-18 15:51:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:51:48 --> Config Class Initialized
INFO - 2023-08-18 15:51:48 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:51:48 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:51:48 --> Utf8 Class Initialized
INFO - 2023-08-18 15:51:48 --> URI Class Initialized
INFO - 2023-08-18 15:51:48 --> Router Class Initialized
INFO - 2023-08-18 15:51:48 --> Output Class Initialized
INFO - 2023-08-18 15:51:48 --> Security Class Initialized
DEBUG - 2023-08-18 15:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:51:48 --> Input Class Initialized
INFO - 2023-08-18 15:51:48 --> Language Class Initialized
INFO - 2023-08-18 15:51:48 --> Loader Class Initialized
INFO - 2023-08-18 15:51:48 --> Helper loaded: url_helper
INFO - 2023-08-18 15:51:48 --> Helper loaded: file_helper
INFO - 2023-08-18 15:51:48 --> Helper loaded: html_helper
INFO - 2023-08-18 15:51:48 --> Helper loaded: text_helper
INFO - 2023-08-18 15:51:48 --> Helper loaded: form_helper
INFO - 2023-08-18 15:51:48 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:51:48 --> Helper loaded: security_helper
INFO - 2023-08-18 15:51:48 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:51:48 --> Database Driver Class Initialized
INFO - 2023-08-18 15:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:51:48 --> Parser Class Initialized
INFO - 2023-08-18 15:51:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:51:48 --> Pagination Class Initialized
INFO - 2023-08-18 15:51:48 --> Form Validation Class Initialized
INFO - 2023-08-18 15:51:48 --> Controller Class Initialized
INFO - 2023-08-18 15:51:48 --> Model Class Initialized
DEBUG - 2023-08-18 15:51:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:51:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:51:48 --> Model Class Initialized
DEBUG - 2023-08-18 15:51:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:51:48 --> Model Class Initialized
INFO - 2023-08-18 15:51:48 --> Final output sent to browser
DEBUG - 2023-08-18 15:51:48 --> Total execution time: 0.0545
ERROR - 2023-08-18 15:51:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:51:49 --> Config Class Initialized
INFO - 2023-08-18 15:51:49 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:51:49 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:51:49 --> Utf8 Class Initialized
INFO - 2023-08-18 15:51:49 --> URI Class Initialized
INFO - 2023-08-18 15:51:49 --> Router Class Initialized
INFO - 2023-08-18 15:51:49 --> Output Class Initialized
INFO - 2023-08-18 15:51:49 --> Security Class Initialized
DEBUG - 2023-08-18 15:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:51:49 --> Input Class Initialized
INFO - 2023-08-18 15:51:49 --> Language Class Initialized
INFO - 2023-08-18 15:51:49 --> Loader Class Initialized
INFO - 2023-08-18 15:51:49 --> Helper loaded: url_helper
INFO - 2023-08-18 15:51:49 --> Helper loaded: file_helper
INFO - 2023-08-18 15:51:49 --> Helper loaded: html_helper
INFO - 2023-08-18 15:51:49 --> Helper loaded: text_helper
INFO - 2023-08-18 15:51:49 --> Helper loaded: form_helper
INFO - 2023-08-18 15:51:49 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:51:49 --> Helper loaded: security_helper
INFO - 2023-08-18 15:51:49 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:51:49 --> Database Driver Class Initialized
INFO - 2023-08-18 15:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:51:49 --> Parser Class Initialized
INFO - 2023-08-18 15:51:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:51:49 --> Pagination Class Initialized
INFO - 2023-08-18 15:51:49 --> Form Validation Class Initialized
INFO - 2023-08-18 15:51:49 --> Controller Class Initialized
INFO - 2023-08-18 15:51:49 --> Model Class Initialized
DEBUG - 2023-08-18 15:51:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:51:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:51:49 --> Model Class Initialized
DEBUG - 2023-08-18 15:51:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:51:49 --> Model Class Initialized
INFO - 2023-08-18 15:51:49 --> Final output sent to browser
DEBUG - 2023-08-18 15:51:49 --> Total execution time: 0.0542
ERROR - 2023-08-18 15:51:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:51:50 --> Config Class Initialized
INFO - 2023-08-18 15:51:50 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:51:50 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:51:50 --> Utf8 Class Initialized
INFO - 2023-08-18 15:51:50 --> URI Class Initialized
INFO - 2023-08-18 15:51:50 --> Router Class Initialized
INFO - 2023-08-18 15:51:50 --> Output Class Initialized
INFO - 2023-08-18 15:51:50 --> Security Class Initialized
DEBUG - 2023-08-18 15:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:51:50 --> Input Class Initialized
INFO - 2023-08-18 15:51:50 --> Language Class Initialized
INFO - 2023-08-18 15:51:50 --> Loader Class Initialized
INFO - 2023-08-18 15:51:50 --> Helper loaded: url_helper
INFO - 2023-08-18 15:51:50 --> Helper loaded: file_helper
INFO - 2023-08-18 15:51:50 --> Helper loaded: html_helper
INFO - 2023-08-18 15:51:50 --> Helper loaded: text_helper
INFO - 2023-08-18 15:51:50 --> Helper loaded: form_helper
INFO - 2023-08-18 15:51:50 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:51:50 --> Helper loaded: security_helper
INFO - 2023-08-18 15:51:50 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:51:50 --> Database Driver Class Initialized
INFO - 2023-08-18 15:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:51:50 --> Parser Class Initialized
INFO - 2023-08-18 15:51:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:51:50 --> Pagination Class Initialized
INFO - 2023-08-18 15:51:50 --> Form Validation Class Initialized
INFO - 2023-08-18 15:51:50 --> Controller Class Initialized
INFO - 2023-08-18 15:51:50 --> Model Class Initialized
DEBUG - 2023-08-18 15:51:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:51:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:51:50 --> Model Class Initialized
DEBUG - 2023-08-18 15:51:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:51:50 --> Model Class Initialized
INFO - 2023-08-18 15:51:50 --> Final output sent to browser
DEBUG - 2023-08-18 15:51:50 --> Total execution time: 0.0550
ERROR - 2023-08-18 15:51:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:51:50 --> Config Class Initialized
INFO - 2023-08-18 15:51:50 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:51:50 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:51:50 --> Utf8 Class Initialized
INFO - 2023-08-18 15:51:50 --> URI Class Initialized
INFO - 2023-08-18 15:51:50 --> Router Class Initialized
INFO - 2023-08-18 15:51:50 --> Output Class Initialized
INFO - 2023-08-18 15:51:50 --> Security Class Initialized
DEBUG - 2023-08-18 15:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:51:50 --> Input Class Initialized
INFO - 2023-08-18 15:51:50 --> Language Class Initialized
INFO - 2023-08-18 15:51:50 --> Loader Class Initialized
INFO - 2023-08-18 15:51:50 --> Helper loaded: url_helper
INFO - 2023-08-18 15:51:50 --> Helper loaded: file_helper
INFO - 2023-08-18 15:51:50 --> Helper loaded: html_helper
INFO - 2023-08-18 15:51:50 --> Helper loaded: text_helper
INFO - 2023-08-18 15:51:50 --> Helper loaded: form_helper
INFO - 2023-08-18 15:51:50 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:51:50 --> Helper loaded: security_helper
INFO - 2023-08-18 15:51:50 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:51:50 --> Database Driver Class Initialized
INFO - 2023-08-18 15:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:51:50 --> Parser Class Initialized
INFO - 2023-08-18 15:51:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:51:50 --> Pagination Class Initialized
INFO - 2023-08-18 15:51:50 --> Form Validation Class Initialized
INFO - 2023-08-18 15:51:50 --> Controller Class Initialized
INFO - 2023-08-18 15:51:50 --> Model Class Initialized
DEBUG - 2023-08-18 15:51:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:51:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:51:50 --> Model Class Initialized
DEBUG - 2023-08-18 15:51:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:51:50 --> Model Class Initialized
INFO - 2023-08-18 15:51:50 --> Final output sent to browser
DEBUG - 2023-08-18 15:51:50 --> Total execution time: 0.0565
ERROR - 2023-08-18 15:51:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:51:53 --> Config Class Initialized
INFO - 2023-08-18 15:51:53 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:51:53 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:51:53 --> Utf8 Class Initialized
INFO - 2023-08-18 15:51:53 --> URI Class Initialized
INFO - 2023-08-18 15:51:53 --> Router Class Initialized
INFO - 2023-08-18 15:51:53 --> Output Class Initialized
INFO - 2023-08-18 15:51:53 --> Security Class Initialized
DEBUG - 2023-08-18 15:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:51:53 --> Input Class Initialized
INFO - 2023-08-18 15:51:53 --> Language Class Initialized
INFO - 2023-08-18 15:51:53 --> Loader Class Initialized
INFO - 2023-08-18 15:51:53 --> Helper loaded: url_helper
INFO - 2023-08-18 15:51:53 --> Helper loaded: file_helper
INFO - 2023-08-18 15:51:53 --> Helper loaded: html_helper
INFO - 2023-08-18 15:51:53 --> Helper loaded: text_helper
INFO - 2023-08-18 15:51:53 --> Helper loaded: form_helper
INFO - 2023-08-18 15:51:53 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:51:53 --> Helper loaded: security_helper
INFO - 2023-08-18 15:51:53 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:51:53 --> Database Driver Class Initialized
INFO - 2023-08-18 15:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:51:53 --> Parser Class Initialized
INFO - 2023-08-18 15:51:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:51:53 --> Pagination Class Initialized
INFO - 2023-08-18 15:51:53 --> Form Validation Class Initialized
INFO - 2023-08-18 15:51:53 --> Controller Class Initialized
INFO - 2023-08-18 15:51:53 --> Model Class Initialized
DEBUG - 2023-08-18 15:51:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:51:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:51:53 --> Model Class Initialized
DEBUG - 2023-08-18 15:51:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:51:53 --> Model Class Initialized
INFO - 2023-08-18 15:51:53 --> Final output sent to browser
DEBUG - 2023-08-18 15:51:53 --> Total execution time: 0.0200
ERROR - 2023-08-18 15:51:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:51:56 --> Config Class Initialized
INFO - 2023-08-18 15:51:56 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:51:56 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:51:56 --> Utf8 Class Initialized
INFO - 2023-08-18 15:51:56 --> URI Class Initialized
INFO - 2023-08-18 15:51:56 --> Router Class Initialized
INFO - 2023-08-18 15:51:56 --> Output Class Initialized
INFO - 2023-08-18 15:51:56 --> Security Class Initialized
DEBUG - 2023-08-18 15:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:51:56 --> Input Class Initialized
INFO - 2023-08-18 15:51:56 --> Language Class Initialized
INFO - 2023-08-18 15:51:56 --> Loader Class Initialized
INFO - 2023-08-18 15:51:56 --> Helper loaded: url_helper
INFO - 2023-08-18 15:51:56 --> Helper loaded: file_helper
INFO - 2023-08-18 15:51:56 --> Helper loaded: html_helper
INFO - 2023-08-18 15:51:56 --> Helper loaded: text_helper
INFO - 2023-08-18 15:51:56 --> Helper loaded: form_helper
INFO - 2023-08-18 15:51:56 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:51:56 --> Helper loaded: security_helper
INFO - 2023-08-18 15:51:56 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:51:56 --> Database Driver Class Initialized
INFO - 2023-08-18 15:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:51:56 --> Parser Class Initialized
INFO - 2023-08-18 15:51:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:51:56 --> Pagination Class Initialized
INFO - 2023-08-18 15:51:56 --> Form Validation Class Initialized
INFO - 2023-08-18 15:51:56 --> Controller Class Initialized
INFO - 2023-08-18 15:51:56 --> Model Class Initialized
DEBUG - 2023-08-18 15:51:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:51:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:51:56 --> Model Class Initialized
INFO - 2023-08-18 15:51:56 --> Model Class Initialized
INFO - 2023-08-18 15:51:56 --> Final output sent to browser
DEBUG - 2023-08-18 15:51:56 --> Total execution time: 0.0193
ERROR - 2023-08-18 15:51:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:51:58 --> Config Class Initialized
INFO - 2023-08-18 15:51:58 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:51:58 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:51:58 --> Utf8 Class Initialized
INFO - 2023-08-18 15:51:58 --> URI Class Initialized
INFO - 2023-08-18 15:51:58 --> Router Class Initialized
INFO - 2023-08-18 15:51:58 --> Output Class Initialized
INFO - 2023-08-18 15:51:58 --> Security Class Initialized
DEBUG - 2023-08-18 15:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:51:58 --> Input Class Initialized
INFO - 2023-08-18 15:51:58 --> Language Class Initialized
INFO - 2023-08-18 15:51:58 --> Loader Class Initialized
INFO - 2023-08-18 15:51:58 --> Helper loaded: url_helper
INFO - 2023-08-18 15:51:58 --> Helper loaded: file_helper
INFO - 2023-08-18 15:51:58 --> Helper loaded: html_helper
INFO - 2023-08-18 15:51:58 --> Helper loaded: text_helper
INFO - 2023-08-18 15:51:58 --> Helper loaded: form_helper
INFO - 2023-08-18 15:51:58 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:51:58 --> Helper loaded: security_helper
INFO - 2023-08-18 15:51:58 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:51:58 --> Database Driver Class Initialized
INFO - 2023-08-18 15:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:51:58 --> Parser Class Initialized
INFO - 2023-08-18 15:51:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:51:58 --> Pagination Class Initialized
INFO - 2023-08-18 15:51:58 --> Form Validation Class Initialized
INFO - 2023-08-18 15:51:58 --> Controller Class Initialized
INFO - 2023-08-18 15:51:58 --> Model Class Initialized
DEBUG - 2023-08-18 15:51:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:51:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:51:58 --> Model Class Initialized
INFO - 2023-08-18 15:51:58 --> Final output sent to browser
DEBUG - 2023-08-18 15:51:58 --> Total execution time: 0.0168
ERROR - 2023-08-18 15:52:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:52:34 --> Config Class Initialized
INFO - 2023-08-18 15:52:34 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:52:34 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:52:34 --> Utf8 Class Initialized
INFO - 2023-08-18 15:52:34 --> URI Class Initialized
INFO - 2023-08-18 15:52:34 --> Router Class Initialized
INFO - 2023-08-18 15:52:34 --> Output Class Initialized
INFO - 2023-08-18 15:52:34 --> Security Class Initialized
DEBUG - 2023-08-18 15:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:52:34 --> Input Class Initialized
INFO - 2023-08-18 15:52:34 --> Language Class Initialized
INFO - 2023-08-18 15:52:34 --> Loader Class Initialized
INFO - 2023-08-18 15:52:34 --> Helper loaded: url_helper
INFO - 2023-08-18 15:52:34 --> Helper loaded: file_helper
INFO - 2023-08-18 15:52:34 --> Helper loaded: html_helper
INFO - 2023-08-18 15:52:34 --> Helper loaded: text_helper
INFO - 2023-08-18 15:52:34 --> Helper loaded: form_helper
INFO - 2023-08-18 15:52:34 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:52:34 --> Helper loaded: security_helper
INFO - 2023-08-18 15:52:34 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:52:34 --> Database Driver Class Initialized
INFO - 2023-08-18 15:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:52:34 --> Parser Class Initialized
INFO - 2023-08-18 15:52:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:52:34 --> Pagination Class Initialized
INFO - 2023-08-18 15:52:34 --> Form Validation Class Initialized
INFO - 2023-08-18 15:52:34 --> Controller Class Initialized
INFO - 2023-08-18 15:52:34 --> Model Class Initialized
DEBUG - 2023-08-18 15:52:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:52:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:52:34 --> Model Class Initialized
DEBUG - 2023-08-18 15:52:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:52:34 --> Model Class Initialized
INFO - 2023-08-18 15:52:34 --> Final output sent to browser
DEBUG - 2023-08-18 15:52:34 --> Total execution time: 0.0561
ERROR - 2023-08-18 15:52:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:52:34 --> Config Class Initialized
INFO - 2023-08-18 15:52:34 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:52:34 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:52:34 --> Utf8 Class Initialized
INFO - 2023-08-18 15:52:34 --> URI Class Initialized
INFO - 2023-08-18 15:52:34 --> Router Class Initialized
INFO - 2023-08-18 15:52:34 --> Output Class Initialized
INFO - 2023-08-18 15:52:34 --> Security Class Initialized
DEBUG - 2023-08-18 15:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:52:34 --> Input Class Initialized
INFO - 2023-08-18 15:52:34 --> Language Class Initialized
INFO - 2023-08-18 15:52:34 --> Loader Class Initialized
INFO - 2023-08-18 15:52:34 --> Helper loaded: url_helper
INFO - 2023-08-18 15:52:34 --> Helper loaded: file_helper
INFO - 2023-08-18 15:52:34 --> Helper loaded: html_helper
INFO - 2023-08-18 15:52:34 --> Helper loaded: text_helper
INFO - 2023-08-18 15:52:34 --> Helper loaded: form_helper
INFO - 2023-08-18 15:52:34 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:52:34 --> Helper loaded: security_helper
INFO - 2023-08-18 15:52:34 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:52:34 --> Database Driver Class Initialized
INFO - 2023-08-18 15:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:52:34 --> Parser Class Initialized
INFO - 2023-08-18 15:52:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:52:34 --> Pagination Class Initialized
INFO - 2023-08-18 15:52:34 --> Form Validation Class Initialized
INFO - 2023-08-18 15:52:34 --> Controller Class Initialized
INFO - 2023-08-18 15:52:34 --> Model Class Initialized
DEBUG - 2023-08-18 15:52:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:52:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:52:34 --> Model Class Initialized
DEBUG - 2023-08-18 15:52:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:52:34 --> Model Class Initialized
INFO - 2023-08-18 15:52:34 --> Final output sent to browser
DEBUG - 2023-08-18 15:52:34 --> Total execution time: 0.0557
ERROR - 2023-08-18 15:52:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:52:35 --> Config Class Initialized
INFO - 2023-08-18 15:52:35 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:52:35 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:52:35 --> Utf8 Class Initialized
INFO - 2023-08-18 15:52:35 --> URI Class Initialized
INFO - 2023-08-18 15:52:35 --> Router Class Initialized
INFO - 2023-08-18 15:52:35 --> Output Class Initialized
INFO - 2023-08-18 15:52:35 --> Security Class Initialized
DEBUG - 2023-08-18 15:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:52:35 --> Input Class Initialized
INFO - 2023-08-18 15:52:35 --> Language Class Initialized
INFO - 2023-08-18 15:52:35 --> Loader Class Initialized
INFO - 2023-08-18 15:52:35 --> Helper loaded: url_helper
INFO - 2023-08-18 15:52:35 --> Helper loaded: file_helper
INFO - 2023-08-18 15:52:35 --> Helper loaded: html_helper
INFO - 2023-08-18 15:52:35 --> Helper loaded: text_helper
INFO - 2023-08-18 15:52:35 --> Helper loaded: form_helper
INFO - 2023-08-18 15:52:35 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:52:35 --> Helper loaded: security_helper
INFO - 2023-08-18 15:52:35 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:52:35 --> Database Driver Class Initialized
INFO - 2023-08-18 15:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:52:35 --> Parser Class Initialized
INFO - 2023-08-18 15:52:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:52:35 --> Pagination Class Initialized
INFO - 2023-08-18 15:52:35 --> Form Validation Class Initialized
INFO - 2023-08-18 15:52:35 --> Controller Class Initialized
INFO - 2023-08-18 15:52:35 --> Model Class Initialized
DEBUG - 2023-08-18 15:52:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:52:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:52:35 --> Model Class Initialized
DEBUG - 2023-08-18 15:52:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:52:35 --> Model Class Initialized
INFO - 2023-08-18 15:52:35 --> Final output sent to browser
DEBUG - 2023-08-18 15:52:35 --> Total execution time: 0.0577
ERROR - 2023-08-18 15:52:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:52:36 --> Config Class Initialized
INFO - 2023-08-18 15:52:36 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:52:36 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:52:36 --> Utf8 Class Initialized
INFO - 2023-08-18 15:52:36 --> URI Class Initialized
INFO - 2023-08-18 15:52:36 --> Router Class Initialized
INFO - 2023-08-18 15:52:36 --> Output Class Initialized
INFO - 2023-08-18 15:52:36 --> Security Class Initialized
DEBUG - 2023-08-18 15:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:52:36 --> Input Class Initialized
INFO - 2023-08-18 15:52:36 --> Language Class Initialized
INFO - 2023-08-18 15:52:36 --> Loader Class Initialized
INFO - 2023-08-18 15:52:36 --> Helper loaded: url_helper
INFO - 2023-08-18 15:52:36 --> Helper loaded: file_helper
INFO - 2023-08-18 15:52:36 --> Helper loaded: html_helper
INFO - 2023-08-18 15:52:36 --> Helper loaded: text_helper
INFO - 2023-08-18 15:52:36 --> Helper loaded: form_helper
INFO - 2023-08-18 15:52:36 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:52:36 --> Helper loaded: security_helper
INFO - 2023-08-18 15:52:36 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:52:36 --> Database Driver Class Initialized
INFO - 2023-08-18 15:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:52:36 --> Parser Class Initialized
INFO - 2023-08-18 15:52:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:52:36 --> Pagination Class Initialized
INFO - 2023-08-18 15:52:36 --> Form Validation Class Initialized
INFO - 2023-08-18 15:52:36 --> Controller Class Initialized
INFO - 2023-08-18 15:52:36 --> Model Class Initialized
DEBUG - 2023-08-18 15:52:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:52:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:52:36 --> Model Class Initialized
DEBUG - 2023-08-18 15:52:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:52:36 --> Model Class Initialized
INFO - 2023-08-18 15:52:36 --> Final output sent to browser
DEBUG - 2023-08-18 15:52:36 --> Total execution time: 0.0225
ERROR - 2023-08-18 15:52:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:52:40 --> Config Class Initialized
INFO - 2023-08-18 15:52:40 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:52:40 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:52:40 --> Utf8 Class Initialized
INFO - 2023-08-18 15:52:40 --> URI Class Initialized
INFO - 2023-08-18 15:52:40 --> Router Class Initialized
INFO - 2023-08-18 15:52:40 --> Output Class Initialized
INFO - 2023-08-18 15:52:40 --> Security Class Initialized
DEBUG - 2023-08-18 15:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:52:40 --> Input Class Initialized
INFO - 2023-08-18 15:52:40 --> Language Class Initialized
INFO - 2023-08-18 15:52:40 --> Loader Class Initialized
INFO - 2023-08-18 15:52:40 --> Helper loaded: url_helper
INFO - 2023-08-18 15:52:40 --> Helper loaded: file_helper
INFO - 2023-08-18 15:52:40 --> Helper loaded: html_helper
INFO - 2023-08-18 15:52:40 --> Helper loaded: text_helper
INFO - 2023-08-18 15:52:40 --> Helper loaded: form_helper
INFO - 2023-08-18 15:52:40 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:52:40 --> Helper loaded: security_helper
INFO - 2023-08-18 15:52:40 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:52:40 --> Database Driver Class Initialized
INFO - 2023-08-18 15:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:52:40 --> Parser Class Initialized
INFO - 2023-08-18 15:52:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:52:40 --> Pagination Class Initialized
INFO - 2023-08-18 15:52:40 --> Form Validation Class Initialized
INFO - 2023-08-18 15:52:40 --> Controller Class Initialized
INFO - 2023-08-18 15:52:40 --> Model Class Initialized
DEBUG - 2023-08-18 15:52:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:52:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:52:40 --> Model Class Initialized
INFO - 2023-08-18 15:52:40 --> Model Class Initialized
INFO - 2023-08-18 15:52:40 --> Final output sent to browser
DEBUG - 2023-08-18 15:52:40 --> Total execution time: 0.0197
ERROR - 2023-08-18 15:52:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:52:43 --> Config Class Initialized
INFO - 2023-08-18 15:52:43 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:52:43 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:52:43 --> Utf8 Class Initialized
INFO - 2023-08-18 15:52:43 --> URI Class Initialized
INFO - 2023-08-18 15:52:43 --> Router Class Initialized
INFO - 2023-08-18 15:52:43 --> Output Class Initialized
INFO - 2023-08-18 15:52:43 --> Security Class Initialized
DEBUG - 2023-08-18 15:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:52:43 --> Input Class Initialized
INFO - 2023-08-18 15:52:43 --> Language Class Initialized
INFO - 2023-08-18 15:52:43 --> Loader Class Initialized
INFO - 2023-08-18 15:52:43 --> Helper loaded: url_helper
INFO - 2023-08-18 15:52:43 --> Helper loaded: file_helper
INFO - 2023-08-18 15:52:43 --> Helper loaded: html_helper
INFO - 2023-08-18 15:52:43 --> Helper loaded: text_helper
INFO - 2023-08-18 15:52:43 --> Helper loaded: form_helper
INFO - 2023-08-18 15:52:43 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:52:43 --> Helper loaded: security_helper
INFO - 2023-08-18 15:52:43 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:52:43 --> Database Driver Class Initialized
INFO - 2023-08-18 15:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:52:43 --> Parser Class Initialized
INFO - 2023-08-18 15:52:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:52:43 --> Pagination Class Initialized
INFO - 2023-08-18 15:52:43 --> Form Validation Class Initialized
INFO - 2023-08-18 15:52:43 --> Controller Class Initialized
INFO - 2023-08-18 15:52:43 --> Model Class Initialized
DEBUG - 2023-08-18 15:52:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:52:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:52:43 --> Model Class Initialized
INFO - 2023-08-18 15:52:43 --> Final output sent to browser
DEBUG - 2023-08-18 15:52:43 --> Total execution time: 0.0211
ERROR - 2023-08-18 15:57:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:57:07 --> Config Class Initialized
INFO - 2023-08-18 15:57:07 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:57:07 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:57:07 --> Utf8 Class Initialized
INFO - 2023-08-18 15:57:07 --> URI Class Initialized
INFO - 2023-08-18 15:57:07 --> Router Class Initialized
INFO - 2023-08-18 15:57:07 --> Output Class Initialized
INFO - 2023-08-18 15:57:07 --> Security Class Initialized
DEBUG - 2023-08-18 15:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:57:07 --> Input Class Initialized
INFO - 2023-08-18 15:57:07 --> Language Class Initialized
INFO - 2023-08-18 15:57:07 --> Loader Class Initialized
INFO - 2023-08-18 15:57:07 --> Helper loaded: url_helper
INFO - 2023-08-18 15:57:07 --> Helper loaded: file_helper
INFO - 2023-08-18 15:57:07 --> Helper loaded: html_helper
INFO - 2023-08-18 15:57:07 --> Helper loaded: text_helper
INFO - 2023-08-18 15:57:07 --> Helper loaded: form_helper
INFO - 2023-08-18 15:57:07 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:57:07 --> Helper loaded: security_helper
INFO - 2023-08-18 15:57:07 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:57:07 --> Database Driver Class Initialized
INFO - 2023-08-18 15:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:57:07 --> Parser Class Initialized
INFO - 2023-08-18 15:57:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:57:07 --> Pagination Class Initialized
INFO - 2023-08-18 15:57:07 --> Form Validation Class Initialized
INFO - 2023-08-18 15:57:07 --> Controller Class Initialized
INFO - 2023-08-18 15:57:07 --> Model Class Initialized
DEBUG - 2023-08-18 15:57:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:57:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:57:07 --> Model Class Initialized
DEBUG - 2023-08-18 15:57:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:57:07 --> Model Class Initialized
ERROR - 2023-08-18 15:57:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:57:07 --> Config Class Initialized
INFO - 2023-08-18 15:57:07 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:57:07 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:57:07 --> Utf8 Class Initialized
INFO - 2023-08-18 15:57:07 --> URI Class Initialized
INFO - 2023-08-18 15:57:07 --> Router Class Initialized
INFO - 2023-08-18 15:57:07 --> Output Class Initialized
INFO - 2023-08-18 15:57:07 --> Security Class Initialized
DEBUG - 2023-08-18 15:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:57:07 --> Input Class Initialized
INFO - 2023-08-18 15:57:07 --> Language Class Initialized
INFO - 2023-08-18 15:57:07 --> Loader Class Initialized
INFO - 2023-08-18 15:57:07 --> Helper loaded: url_helper
INFO - 2023-08-18 15:57:07 --> Helper loaded: file_helper
INFO - 2023-08-18 15:57:07 --> Helper loaded: html_helper
INFO - 2023-08-18 15:57:07 --> Helper loaded: text_helper
INFO - 2023-08-18 15:57:07 --> Helper loaded: form_helper
INFO - 2023-08-18 15:57:07 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:57:07 --> Helper loaded: security_helper
INFO - 2023-08-18 15:57:07 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:57:07 --> Database Driver Class Initialized
INFO - 2023-08-18 15:57:07 --> Final output sent to browser
DEBUG - 2023-08-18 15:57:07 --> Total execution time: 0.0617
INFO - 2023-08-18 15:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:57:07 --> Parser Class Initialized
INFO - 2023-08-18 15:57:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:57:07 --> Pagination Class Initialized
INFO - 2023-08-18 15:57:07 --> Form Validation Class Initialized
INFO - 2023-08-18 15:57:07 --> Controller Class Initialized
INFO - 2023-08-18 15:57:07 --> Model Class Initialized
DEBUG - 2023-08-18 15:57:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:57:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:57:07 --> Model Class Initialized
DEBUG - 2023-08-18 15:57:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:57:07 --> Model Class Initialized
INFO - 2023-08-18 15:57:07 --> Final output sent to browser
DEBUG - 2023-08-18 15:57:07 --> Total execution time: 0.0887
ERROR - 2023-08-18 15:57:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:57:07 --> Config Class Initialized
INFO - 2023-08-18 15:57:07 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:57:07 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:57:07 --> Utf8 Class Initialized
INFO - 2023-08-18 15:57:07 --> URI Class Initialized
INFO - 2023-08-18 15:57:07 --> Router Class Initialized
INFO - 2023-08-18 15:57:07 --> Output Class Initialized
INFO - 2023-08-18 15:57:07 --> Security Class Initialized
DEBUG - 2023-08-18 15:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:57:07 --> Input Class Initialized
INFO - 2023-08-18 15:57:07 --> Language Class Initialized
INFO - 2023-08-18 15:57:07 --> Loader Class Initialized
INFO - 2023-08-18 15:57:07 --> Helper loaded: url_helper
INFO - 2023-08-18 15:57:07 --> Helper loaded: file_helper
INFO - 2023-08-18 15:57:07 --> Helper loaded: html_helper
INFO - 2023-08-18 15:57:07 --> Helper loaded: text_helper
INFO - 2023-08-18 15:57:07 --> Helper loaded: form_helper
INFO - 2023-08-18 15:57:07 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:57:07 --> Helper loaded: security_helper
INFO - 2023-08-18 15:57:07 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:57:07 --> Database Driver Class Initialized
INFO - 2023-08-18 15:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:57:07 --> Parser Class Initialized
INFO - 2023-08-18 15:57:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:57:07 --> Pagination Class Initialized
INFO - 2023-08-18 15:57:07 --> Form Validation Class Initialized
INFO - 2023-08-18 15:57:07 --> Controller Class Initialized
INFO - 2023-08-18 15:57:07 --> Model Class Initialized
DEBUG - 2023-08-18 15:57:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:57:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:57:07 --> Model Class Initialized
DEBUG - 2023-08-18 15:57:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:57:07 --> Model Class Initialized
INFO - 2023-08-18 15:57:07 --> Final output sent to browser
DEBUG - 2023-08-18 15:57:07 --> Total execution time: 0.0564
ERROR - 2023-08-18 15:57:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:57:07 --> Config Class Initialized
INFO - 2023-08-18 15:57:07 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:57:07 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:57:07 --> Utf8 Class Initialized
INFO - 2023-08-18 15:57:07 --> URI Class Initialized
INFO - 2023-08-18 15:57:07 --> Router Class Initialized
INFO - 2023-08-18 15:57:07 --> Output Class Initialized
INFO - 2023-08-18 15:57:07 --> Security Class Initialized
DEBUG - 2023-08-18 15:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:57:07 --> Input Class Initialized
INFO - 2023-08-18 15:57:07 --> Language Class Initialized
INFO - 2023-08-18 15:57:07 --> Loader Class Initialized
INFO - 2023-08-18 15:57:07 --> Helper loaded: url_helper
INFO - 2023-08-18 15:57:07 --> Helper loaded: file_helper
INFO - 2023-08-18 15:57:07 --> Helper loaded: html_helper
INFO - 2023-08-18 15:57:07 --> Helper loaded: text_helper
INFO - 2023-08-18 15:57:07 --> Helper loaded: form_helper
INFO - 2023-08-18 15:57:07 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:57:07 --> Helper loaded: security_helper
INFO - 2023-08-18 15:57:07 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:57:07 --> Database Driver Class Initialized
INFO - 2023-08-18 15:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:57:07 --> Parser Class Initialized
INFO - 2023-08-18 15:57:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:57:07 --> Pagination Class Initialized
INFO - 2023-08-18 15:57:07 --> Form Validation Class Initialized
INFO - 2023-08-18 15:57:07 --> Controller Class Initialized
INFO - 2023-08-18 15:57:07 --> Model Class Initialized
DEBUG - 2023-08-18 15:57:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:57:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:57:07 --> Model Class Initialized
DEBUG - 2023-08-18 15:57:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:57:07 --> Model Class Initialized
INFO - 2023-08-18 15:57:07 --> Final output sent to browser
DEBUG - 2023-08-18 15:57:07 --> Total execution time: 0.0555
ERROR - 2023-08-18 15:57:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:57:09 --> Config Class Initialized
INFO - 2023-08-18 15:57:09 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:57:09 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:57:09 --> Utf8 Class Initialized
INFO - 2023-08-18 15:57:09 --> URI Class Initialized
INFO - 2023-08-18 15:57:09 --> Router Class Initialized
INFO - 2023-08-18 15:57:09 --> Output Class Initialized
INFO - 2023-08-18 15:57:09 --> Security Class Initialized
DEBUG - 2023-08-18 15:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:57:09 --> Input Class Initialized
INFO - 2023-08-18 15:57:09 --> Language Class Initialized
INFO - 2023-08-18 15:57:09 --> Loader Class Initialized
INFO - 2023-08-18 15:57:09 --> Helper loaded: url_helper
INFO - 2023-08-18 15:57:09 --> Helper loaded: file_helper
INFO - 2023-08-18 15:57:09 --> Helper loaded: html_helper
INFO - 2023-08-18 15:57:09 --> Helper loaded: text_helper
INFO - 2023-08-18 15:57:09 --> Helper loaded: form_helper
INFO - 2023-08-18 15:57:09 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:57:09 --> Helper loaded: security_helper
INFO - 2023-08-18 15:57:09 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:57:09 --> Database Driver Class Initialized
INFO - 2023-08-18 15:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:57:09 --> Parser Class Initialized
INFO - 2023-08-18 15:57:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:57:09 --> Pagination Class Initialized
INFO - 2023-08-18 15:57:09 --> Form Validation Class Initialized
INFO - 2023-08-18 15:57:09 --> Controller Class Initialized
INFO - 2023-08-18 15:57:09 --> Model Class Initialized
DEBUG - 2023-08-18 15:57:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:57:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:57:09 --> Model Class Initialized
DEBUG - 2023-08-18 15:57:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:57:09 --> Model Class Initialized
INFO - 2023-08-18 15:57:09 --> Final output sent to browser
DEBUG - 2023-08-18 15:57:09 --> Total execution time: 0.0200
ERROR - 2023-08-18 15:57:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:57:10 --> Config Class Initialized
INFO - 2023-08-18 15:57:10 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:57:10 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:57:10 --> Utf8 Class Initialized
INFO - 2023-08-18 15:57:10 --> URI Class Initialized
INFO - 2023-08-18 15:57:10 --> Router Class Initialized
INFO - 2023-08-18 15:57:10 --> Output Class Initialized
INFO - 2023-08-18 15:57:10 --> Security Class Initialized
DEBUG - 2023-08-18 15:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:57:10 --> Input Class Initialized
INFO - 2023-08-18 15:57:10 --> Language Class Initialized
INFO - 2023-08-18 15:57:10 --> Loader Class Initialized
INFO - 2023-08-18 15:57:10 --> Helper loaded: url_helper
INFO - 2023-08-18 15:57:10 --> Helper loaded: file_helper
INFO - 2023-08-18 15:57:10 --> Helper loaded: html_helper
INFO - 2023-08-18 15:57:10 --> Helper loaded: text_helper
INFO - 2023-08-18 15:57:10 --> Helper loaded: form_helper
INFO - 2023-08-18 15:57:10 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:57:10 --> Helper loaded: security_helper
INFO - 2023-08-18 15:57:10 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:57:10 --> Database Driver Class Initialized
INFO - 2023-08-18 15:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:57:10 --> Parser Class Initialized
INFO - 2023-08-18 15:57:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:57:10 --> Pagination Class Initialized
INFO - 2023-08-18 15:57:10 --> Form Validation Class Initialized
INFO - 2023-08-18 15:57:10 --> Controller Class Initialized
INFO - 2023-08-18 15:57:10 --> Model Class Initialized
DEBUG - 2023-08-18 15:57:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:57:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:57:10 --> Model Class Initialized
INFO - 2023-08-18 15:57:10 --> Model Class Initialized
INFO - 2023-08-18 15:57:10 --> Final output sent to browser
DEBUG - 2023-08-18 15:57:10 --> Total execution time: 0.0246
ERROR - 2023-08-18 15:57:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:57:12 --> Config Class Initialized
INFO - 2023-08-18 15:57:12 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:57:12 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:57:12 --> Utf8 Class Initialized
INFO - 2023-08-18 15:57:12 --> URI Class Initialized
INFO - 2023-08-18 15:57:12 --> Router Class Initialized
INFO - 2023-08-18 15:57:12 --> Output Class Initialized
INFO - 2023-08-18 15:57:12 --> Security Class Initialized
DEBUG - 2023-08-18 15:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:57:12 --> Input Class Initialized
INFO - 2023-08-18 15:57:12 --> Language Class Initialized
INFO - 2023-08-18 15:57:12 --> Loader Class Initialized
INFO - 2023-08-18 15:57:12 --> Helper loaded: url_helper
INFO - 2023-08-18 15:57:12 --> Helper loaded: file_helper
INFO - 2023-08-18 15:57:12 --> Helper loaded: html_helper
INFO - 2023-08-18 15:57:12 --> Helper loaded: text_helper
INFO - 2023-08-18 15:57:12 --> Helper loaded: form_helper
INFO - 2023-08-18 15:57:12 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:57:12 --> Helper loaded: security_helper
INFO - 2023-08-18 15:57:12 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:57:12 --> Database Driver Class Initialized
INFO - 2023-08-18 15:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:57:12 --> Parser Class Initialized
INFO - 2023-08-18 15:57:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:57:12 --> Pagination Class Initialized
INFO - 2023-08-18 15:57:12 --> Form Validation Class Initialized
INFO - 2023-08-18 15:57:12 --> Controller Class Initialized
INFO - 2023-08-18 15:57:12 --> Model Class Initialized
DEBUG - 2023-08-18 15:57:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:57:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:57:12 --> Model Class Initialized
INFO - 2023-08-18 15:57:12 --> Final output sent to browser
DEBUG - 2023-08-18 15:57:12 --> Total execution time: 0.0173
ERROR - 2023-08-18 15:58:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:58:11 --> Config Class Initialized
INFO - 2023-08-18 15:58:11 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:58:11 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:58:11 --> Utf8 Class Initialized
INFO - 2023-08-18 15:58:11 --> URI Class Initialized
INFO - 2023-08-18 15:58:11 --> Router Class Initialized
INFO - 2023-08-18 15:58:11 --> Output Class Initialized
INFO - 2023-08-18 15:58:11 --> Security Class Initialized
DEBUG - 2023-08-18 15:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:58:11 --> Input Class Initialized
INFO - 2023-08-18 15:58:11 --> Language Class Initialized
INFO - 2023-08-18 15:58:11 --> Loader Class Initialized
INFO - 2023-08-18 15:58:11 --> Helper loaded: url_helper
INFO - 2023-08-18 15:58:11 --> Helper loaded: file_helper
INFO - 2023-08-18 15:58:11 --> Helper loaded: html_helper
INFO - 2023-08-18 15:58:11 --> Helper loaded: text_helper
INFO - 2023-08-18 15:58:11 --> Helper loaded: form_helper
INFO - 2023-08-18 15:58:11 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:58:11 --> Helper loaded: security_helper
INFO - 2023-08-18 15:58:11 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:58:11 --> Database Driver Class Initialized
INFO - 2023-08-18 15:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:58:11 --> Parser Class Initialized
INFO - 2023-08-18 15:58:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:58:11 --> Pagination Class Initialized
INFO - 2023-08-18 15:58:11 --> Form Validation Class Initialized
INFO - 2023-08-18 15:58:11 --> Controller Class Initialized
INFO - 2023-08-18 15:58:11 --> Model Class Initialized
DEBUG - 2023-08-18 15:58:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:58:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:58:11 --> Model Class Initialized
DEBUG - 2023-08-18 15:58:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:58:11 --> Model Class Initialized
INFO - 2023-08-18 15:58:11 --> Final output sent to browser
DEBUG - 2023-08-18 15:58:11 --> Total execution time: 0.0220
ERROR - 2023-08-18 15:58:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:58:11 --> Config Class Initialized
INFO - 2023-08-18 15:58:11 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:58:11 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:58:11 --> Utf8 Class Initialized
INFO - 2023-08-18 15:58:11 --> URI Class Initialized
INFO - 2023-08-18 15:58:11 --> Router Class Initialized
INFO - 2023-08-18 15:58:11 --> Output Class Initialized
INFO - 2023-08-18 15:58:11 --> Security Class Initialized
DEBUG - 2023-08-18 15:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:58:11 --> Input Class Initialized
INFO - 2023-08-18 15:58:11 --> Language Class Initialized
INFO - 2023-08-18 15:58:11 --> Loader Class Initialized
INFO - 2023-08-18 15:58:11 --> Helper loaded: url_helper
INFO - 2023-08-18 15:58:11 --> Helper loaded: file_helper
INFO - 2023-08-18 15:58:11 --> Helper loaded: html_helper
INFO - 2023-08-18 15:58:11 --> Helper loaded: text_helper
INFO - 2023-08-18 15:58:11 --> Helper loaded: form_helper
INFO - 2023-08-18 15:58:11 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:58:11 --> Helper loaded: security_helper
INFO - 2023-08-18 15:58:11 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:58:11 --> Database Driver Class Initialized
INFO - 2023-08-18 15:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:58:11 --> Parser Class Initialized
INFO - 2023-08-18 15:58:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:58:11 --> Pagination Class Initialized
INFO - 2023-08-18 15:58:11 --> Form Validation Class Initialized
INFO - 2023-08-18 15:58:11 --> Controller Class Initialized
INFO - 2023-08-18 15:58:11 --> Model Class Initialized
DEBUG - 2023-08-18 15:58:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:58:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:58:11 --> Model Class Initialized
DEBUG - 2023-08-18 15:58:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:58:11 --> Model Class Initialized
INFO - 2023-08-18 15:58:11 --> Final output sent to browser
DEBUG - 2023-08-18 15:58:11 --> Total execution time: 0.0197
ERROR - 2023-08-18 15:58:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:58:12 --> Config Class Initialized
INFO - 2023-08-18 15:58:12 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:58:12 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:58:12 --> Utf8 Class Initialized
INFO - 2023-08-18 15:58:12 --> URI Class Initialized
INFO - 2023-08-18 15:58:12 --> Router Class Initialized
INFO - 2023-08-18 15:58:12 --> Output Class Initialized
INFO - 2023-08-18 15:58:12 --> Security Class Initialized
DEBUG - 2023-08-18 15:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:58:12 --> Input Class Initialized
INFO - 2023-08-18 15:58:12 --> Language Class Initialized
INFO - 2023-08-18 15:58:12 --> Loader Class Initialized
INFO - 2023-08-18 15:58:12 --> Helper loaded: url_helper
INFO - 2023-08-18 15:58:12 --> Helper loaded: file_helper
INFO - 2023-08-18 15:58:12 --> Helper loaded: html_helper
INFO - 2023-08-18 15:58:12 --> Helper loaded: text_helper
INFO - 2023-08-18 15:58:12 --> Helper loaded: form_helper
INFO - 2023-08-18 15:58:12 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:58:12 --> Helper loaded: security_helper
INFO - 2023-08-18 15:58:12 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:58:12 --> Database Driver Class Initialized
INFO - 2023-08-18 15:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:58:12 --> Parser Class Initialized
INFO - 2023-08-18 15:58:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:58:12 --> Pagination Class Initialized
INFO - 2023-08-18 15:58:12 --> Form Validation Class Initialized
INFO - 2023-08-18 15:58:12 --> Controller Class Initialized
INFO - 2023-08-18 15:58:12 --> Model Class Initialized
DEBUG - 2023-08-18 15:58:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:58:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:58:12 --> Model Class Initialized
DEBUG - 2023-08-18 15:58:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:58:12 --> Model Class Initialized
INFO - 2023-08-18 15:58:12 --> Final output sent to browser
DEBUG - 2023-08-18 15:58:12 --> Total execution time: 0.0179
ERROR - 2023-08-18 15:58:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:58:18 --> Config Class Initialized
INFO - 2023-08-18 15:58:18 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:58:18 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:58:18 --> Utf8 Class Initialized
INFO - 2023-08-18 15:58:18 --> URI Class Initialized
INFO - 2023-08-18 15:58:18 --> Router Class Initialized
INFO - 2023-08-18 15:58:18 --> Output Class Initialized
INFO - 2023-08-18 15:58:18 --> Security Class Initialized
DEBUG - 2023-08-18 15:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:58:18 --> Input Class Initialized
INFO - 2023-08-18 15:58:18 --> Language Class Initialized
INFO - 2023-08-18 15:58:18 --> Loader Class Initialized
INFO - 2023-08-18 15:58:18 --> Helper loaded: url_helper
INFO - 2023-08-18 15:58:18 --> Helper loaded: file_helper
INFO - 2023-08-18 15:58:18 --> Helper loaded: html_helper
INFO - 2023-08-18 15:58:18 --> Helper loaded: text_helper
INFO - 2023-08-18 15:58:18 --> Helper loaded: form_helper
INFO - 2023-08-18 15:58:18 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:58:18 --> Helper loaded: security_helper
INFO - 2023-08-18 15:58:18 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:58:18 --> Database Driver Class Initialized
INFO - 2023-08-18 15:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:58:18 --> Parser Class Initialized
INFO - 2023-08-18 15:58:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:58:18 --> Pagination Class Initialized
INFO - 2023-08-18 15:58:18 --> Form Validation Class Initialized
INFO - 2023-08-18 15:58:18 --> Controller Class Initialized
INFO - 2023-08-18 15:58:18 --> Model Class Initialized
DEBUG - 2023-08-18 15:58:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:58:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:58:18 --> Model Class Initialized
DEBUG - 2023-08-18 15:58:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:58:18 --> Model Class Initialized
INFO - 2023-08-18 15:58:18 --> Final output sent to browser
DEBUG - 2023-08-18 15:58:18 --> Total execution time: 0.0682
ERROR - 2023-08-18 15:58:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:58:19 --> Config Class Initialized
INFO - 2023-08-18 15:58:19 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:58:19 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:58:19 --> Utf8 Class Initialized
INFO - 2023-08-18 15:58:19 --> URI Class Initialized
INFO - 2023-08-18 15:58:19 --> Router Class Initialized
INFO - 2023-08-18 15:58:19 --> Output Class Initialized
INFO - 2023-08-18 15:58:19 --> Security Class Initialized
DEBUG - 2023-08-18 15:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:58:19 --> Input Class Initialized
INFO - 2023-08-18 15:58:19 --> Language Class Initialized
INFO - 2023-08-18 15:58:19 --> Loader Class Initialized
INFO - 2023-08-18 15:58:19 --> Helper loaded: url_helper
INFO - 2023-08-18 15:58:19 --> Helper loaded: file_helper
INFO - 2023-08-18 15:58:19 --> Helper loaded: html_helper
INFO - 2023-08-18 15:58:19 --> Helper loaded: text_helper
INFO - 2023-08-18 15:58:19 --> Helper loaded: form_helper
INFO - 2023-08-18 15:58:19 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:58:19 --> Helper loaded: security_helper
INFO - 2023-08-18 15:58:19 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:58:19 --> Database Driver Class Initialized
INFO - 2023-08-18 15:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:58:19 --> Parser Class Initialized
INFO - 2023-08-18 15:58:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:58:19 --> Pagination Class Initialized
INFO - 2023-08-18 15:58:19 --> Form Validation Class Initialized
INFO - 2023-08-18 15:58:19 --> Controller Class Initialized
INFO - 2023-08-18 15:58:19 --> Model Class Initialized
DEBUG - 2023-08-18 15:58:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:58:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:58:19 --> Model Class Initialized
DEBUG - 2023-08-18 15:58:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:58:19 --> Model Class Initialized
INFO - 2023-08-18 15:58:19 --> Final output sent to browser
DEBUG - 2023-08-18 15:58:19 --> Total execution time: 0.0552
ERROR - 2023-08-18 15:58:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:58:20 --> Config Class Initialized
INFO - 2023-08-18 15:58:20 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:58:20 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:58:20 --> Utf8 Class Initialized
INFO - 2023-08-18 15:58:20 --> URI Class Initialized
INFO - 2023-08-18 15:58:20 --> Router Class Initialized
INFO - 2023-08-18 15:58:20 --> Output Class Initialized
INFO - 2023-08-18 15:58:20 --> Security Class Initialized
DEBUG - 2023-08-18 15:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:58:20 --> Input Class Initialized
INFO - 2023-08-18 15:58:20 --> Language Class Initialized
INFO - 2023-08-18 15:58:20 --> Loader Class Initialized
INFO - 2023-08-18 15:58:20 --> Helper loaded: url_helper
INFO - 2023-08-18 15:58:20 --> Helper loaded: file_helper
INFO - 2023-08-18 15:58:20 --> Helper loaded: html_helper
INFO - 2023-08-18 15:58:20 --> Helper loaded: text_helper
INFO - 2023-08-18 15:58:20 --> Helper loaded: form_helper
INFO - 2023-08-18 15:58:20 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:58:20 --> Helper loaded: security_helper
INFO - 2023-08-18 15:58:20 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:58:20 --> Database Driver Class Initialized
INFO - 2023-08-18 15:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:58:20 --> Parser Class Initialized
INFO - 2023-08-18 15:58:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:58:20 --> Pagination Class Initialized
INFO - 2023-08-18 15:58:20 --> Form Validation Class Initialized
INFO - 2023-08-18 15:58:20 --> Controller Class Initialized
INFO - 2023-08-18 15:58:20 --> Model Class Initialized
DEBUG - 2023-08-18 15:58:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:58:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:58:20 --> Model Class Initialized
DEBUG - 2023-08-18 15:58:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:58:20 --> Model Class Initialized
INFO - 2023-08-18 15:58:20 --> Final output sent to browser
DEBUG - 2023-08-18 15:58:20 --> Total execution time: 0.0517
ERROR - 2023-08-18 15:58:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:58:21 --> Config Class Initialized
INFO - 2023-08-18 15:58:21 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:58:21 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:58:21 --> Utf8 Class Initialized
INFO - 2023-08-18 15:58:21 --> URI Class Initialized
INFO - 2023-08-18 15:58:21 --> Router Class Initialized
INFO - 2023-08-18 15:58:21 --> Output Class Initialized
INFO - 2023-08-18 15:58:21 --> Security Class Initialized
DEBUG - 2023-08-18 15:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:58:21 --> Input Class Initialized
INFO - 2023-08-18 15:58:21 --> Language Class Initialized
INFO - 2023-08-18 15:58:21 --> Loader Class Initialized
INFO - 2023-08-18 15:58:21 --> Helper loaded: url_helper
INFO - 2023-08-18 15:58:21 --> Helper loaded: file_helper
INFO - 2023-08-18 15:58:21 --> Helper loaded: html_helper
INFO - 2023-08-18 15:58:21 --> Helper loaded: text_helper
INFO - 2023-08-18 15:58:21 --> Helper loaded: form_helper
INFO - 2023-08-18 15:58:21 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:58:21 --> Helper loaded: security_helper
INFO - 2023-08-18 15:58:21 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:58:21 --> Database Driver Class Initialized
INFO - 2023-08-18 15:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:58:21 --> Parser Class Initialized
INFO - 2023-08-18 15:58:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:58:21 --> Pagination Class Initialized
INFO - 2023-08-18 15:58:21 --> Form Validation Class Initialized
INFO - 2023-08-18 15:58:21 --> Controller Class Initialized
INFO - 2023-08-18 15:58:21 --> Model Class Initialized
DEBUG - 2023-08-18 15:58:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:58:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:58:21 --> Model Class Initialized
DEBUG - 2023-08-18 15:58:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:58:21 --> Model Class Initialized
INFO - 2023-08-18 15:58:21 --> Final output sent to browser
DEBUG - 2023-08-18 15:58:21 --> Total execution time: 0.0518
ERROR - 2023-08-18 15:58:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:58:21 --> Config Class Initialized
INFO - 2023-08-18 15:58:21 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:58:21 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:58:21 --> Utf8 Class Initialized
INFO - 2023-08-18 15:58:21 --> URI Class Initialized
INFO - 2023-08-18 15:58:21 --> Router Class Initialized
INFO - 2023-08-18 15:58:21 --> Output Class Initialized
INFO - 2023-08-18 15:58:21 --> Security Class Initialized
DEBUG - 2023-08-18 15:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:58:21 --> Input Class Initialized
INFO - 2023-08-18 15:58:21 --> Language Class Initialized
INFO - 2023-08-18 15:58:21 --> Loader Class Initialized
INFO - 2023-08-18 15:58:21 --> Helper loaded: url_helper
INFO - 2023-08-18 15:58:21 --> Helper loaded: file_helper
INFO - 2023-08-18 15:58:21 --> Helper loaded: html_helper
INFO - 2023-08-18 15:58:21 --> Helper loaded: text_helper
INFO - 2023-08-18 15:58:21 --> Helper loaded: form_helper
INFO - 2023-08-18 15:58:21 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:58:21 --> Helper loaded: security_helper
INFO - 2023-08-18 15:58:21 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:58:21 --> Database Driver Class Initialized
INFO - 2023-08-18 15:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:58:21 --> Parser Class Initialized
INFO - 2023-08-18 15:58:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:58:21 --> Pagination Class Initialized
INFO - 2023-08-18 15:58:21 --> Form Validation Class Initialized
INFO - 2023-08-18 15:58:21 --> Controller Class Initialized
INFO - 2023-08-18 15:58:21 --> Model Class Initialized
DEBUG - 2023-08-18 15:58:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:58:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:58:21 --> Model Class Initialized
DEBUG - 2023-08-18 15:58:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:58:21 --> Model Class Initialized
INFO - 2023-08-18 15:58:21 --> Final output sent to browser
DEBUG - 2023-08-18 15:58:21 --> Total execution time: 0.0202
ERROR - 2023-08-18 15:58:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:58:25 --> Config Class Initialized
INFO - 2023-08-18 15:58:25 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:58:25 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:58:25 --> Utf8 Class Initialized
INFO - 2023-08-18 15:58:25 --> URI Class Initialized
INFO - 2023-08-18 15:58:25 --> Router Class Initialized
INFO - 2023-08-18 15:58:25 --> Output Class Initialized
INFO - 2023-08-18 15:58:25 --> Security Class Initialized
DEBUG - 2023-08-18 15:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:58:25 --> Input Class Initialized
INFO - 2023-08-18 15:58:25 --> Language Class Initialized
INFO - 2023-08-18 15:58:25 --> Loader Class Initialized
INFO - 2023-08-18 15:58:25 --> Helper loaded: url_helper
INFO - 2023-08-18 15:58:25 --> Helper loaded: file_helper
INFO - 2023-08-18 15:58:25 --> Helper loaded: html_helper
INFO - 2023-08-18 15:58:25 --> Helper loaded: text_helper
INFO - 2023-08-18 15:58:25 --> Helper loaded: form_helper
INFO - 2023-08-18 15:58:25 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:58:25 --> Helper loaded: security_helper
INFO - 2023-08-18 15:58:25 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:58:25 --> Database Driver Class Initialized
INFO - 2023-08-18 15:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:58:25 --> Parser Class Initialized
INFO - 2023-08-18 15:58:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:58:25 --> Pagination Class Initialized
INFO - 2023-08-18 15:58:25 --> Form Validation Class Initialized
INFO - 2023-08-18 15:58:25 --> Controller Class Initialized
INFO - 2023-08-18 15:58:25 --> Model Class Initialized
DEBUG - 2023-08-18 15:58:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:58:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:58:25 --> Model Class Initialized
DEBUG - 2023-08-18 15:58:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:58:25 --> Model Class Initialized
INFO - 2023-08-18 15:58:25 --> Final output sent to browser
DEBUG - 2023-08-18 15:58:25 --> Total execution time: 0.0528
ERROR - 2023-08-18 15:58:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:58:28 --> Config Class Initialized
INFO - 2023-08-18 15:58:28 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:58:28 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:58:28 --> Utf8 Class Initialized
INFO - 2023-08-18 15:58:28 --> URI Class Initialized
INFO - 2023-08-18 15:58:28 --> Router Class Initialized
INFO - 2023-08-18 15:58:28 --> Output Class Initialized
INFO - 2023-08-18 15:58:28 --> Security Class Initialized
DEBUG - 2023-08-18 15:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:58:28 --> Input Class Initialized
INFO - 2023-08-18 15:58:28 --> Language Class Initialized
INFO - 2023-08-18 15:58:28 --> Loader Class Initialized
INFO - 2023-08-18 15:58:28 --> Helper loaded: url_helper
INFO - 2023-08-18 15:58:28 --> Helper loaded: file_helper
INFO - 2023-08-18 15:58:28 --> Helper loaded: html_helper
INFO - 2023-08-18 15:58:28 --> Helper loaded: text_helper
INFO - 2023-08-18 15:58:28 --> Helper loaded: form_helper
INFO - 2023-08-18 15:58:28 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:58:28 --> Helper loaded: security_helper
INFO - 2023-08-18 15:58:28 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:58:28 --> Database Driver Class Initialized
INFO - 2023-08-18 15:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:58:28 --> Parser Class Initialized
INFO - 2023-08-18 15:58:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:58:28 --> Pagination Class Initialized
INFO - 2023-08-18 15:58:28 --> Form Validation Class Initialized
INFO - 2023-08-18 15:58:28 --> Controller Class Initialized
INFO - 2023-08-18 15:58:28 --> Model Class Initialized
DEBUG - 2023-08-18 15:58:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:58:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:58:28 --> Model Class Initialized
DEBUG - 2023-08-18 15:58:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:58:28 --> Model Class Initialized
INFO - 2023-08-18 15:58:28 --> Final output sent to browser
DEBUG - 2023-08-18 15:58:28 --> Total execution time: 0.0291
ERROR - 2023-08-18 15:58:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:58:28 --> Config Class Initialized
INFO - 2023-08-18 15:58:28 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:58:28 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:58:28 --> Utf8 Class Initialized
INFO - 2023-08-18 15:58:28 --> URI Class Initialized
INFO - 2023-08-18 15:58:28 --> Router Class Initialized
INFO - 2023-08-18 15:58:28 --> Output Class Initialized
INFO - 2023-08-18 15:58:28 --> Security Class Initialized
DEBUG - 2023-08-18 15:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:58:28 --> Input Class Initialized
INFO - 2023-08-18 15:58:28 --> Language Class Initialized
INFO - 2023-08-18 15:58:28 --> Loader Class Initialized
INFO - 2023-08-18 15:58:28 --> Helper loaded: url_helper
INFO - 2023-08-18 15:58:28 --> Helper loaded: file_helper
INFO - 2023-08-18 15:58:28 --> Helper loaded: html_helper
INFO - 2023-08-18 15:58:28 --> Helper loaded: text_helper
INFO - 2023-08-18 15:58:28 --> Helper loaded: form_helper
INFO - 2023-08-18 15:58:28 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:58:28 --> Helper loaded: security_helper
INFO - 2023-08-18 15:58:28 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:58:28 --> Database Driver Class Initialized
INFO - 2023-08-18 15:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:58:28 --> Parser Class Initialized
INFO - 2023-08-18 15:58:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:58:28 --> Pagination Class Initialized
INFO - 2023-08-18 15:58:28 --> Form Validation Class Initialized
INFO - 2023-08-18 15:58:28 --> Controller Class Initialized
INFO - 2023-08-18 15:58:28 --> Model Class Initialized
DEBUG - 2023-08-18 15:58:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:58:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:58:28 --> Model Class Initialized
DEBUG - 2023-08-18 15:58:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:58:28 --> Model Class Initialized
INFO - 2023-08-18 15:58:29 --> Final output sent to browser
DEBUG - 2023-08-18 15:58:29 --> Total execution time: 0.0241
ERROR - 2023-08-18 15:59:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:59:13 --> Config Class Initialized
INFO - 2023-08-18 15:59:13 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:59:13 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:59:13 --> Utf8 Class Initialized
INFO - 2023-08-18 15:59:13 --> URI Class Initialized
INFO - 2023-08-18 15:59:13 --> Router Class Initialized
INFO - 2023-08-18 15:59:13 --> Output Class Initialized
INFO - 2023-08-18 15:59:13 --> Security Class Initialized
DEBUG - 2023-08-18 15:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:59:13 --> Input Class Initialized
INFO - 2023-08-18 15:59:13 --> Language Class Initialized
INFO - 2023-08-18 15:59:13 --> Loader Class Initialized
INFO - 2023-08-18 15:59:13 --> Helper loaded: url_helper
INFO - 2023-08-18 15:59:13 --> Helper loaded: file_helper
INFO - 2023-08-18 15:59:13 --> Helper loaded: html_helper
INFO - 2023-08-18 15:59:13 --> Helper loaded: text_helper
INFO - 2023-08-18 15:59:13 --> Helper loaded: form_helper
INFO - 2023-08-18 15:59:13 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:59:13 --> Helper loaded: security_helper
INFO - 2023-08-18 15:59:13 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:59:13 --> Database Driver Class Initialized
INFO - 2023-08-18 15:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:59:13 --> Parser Class Initialized
INFO - 2023-08-18 15:59:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:59:13 --> Pagination Class Initialized
INFO - 2023-08-18 15:59:13 --> Form Validation Class Initialized
INFO - 2023-08-18 15:59:13 --> Controller Class Initialized
INFO - 2023-08-18 15:59:13 --> Model Class Initialized
DEBUG - 2023-08-18 15:59:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:59:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:59:13 --> Model Class Initialized
INFO - 2023-08-18 15:59:13 --> Model Class Initialized
INFO - 2023-08-18 15:59:13 --> Final output sent to browser
DEBUG - 2023-08-18 15:59:13 --> Total execution time: 0.0212
ERROR - 2023-08-18 15:59:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:59:17 --> Config Class Initialized
INFO - 2023-08-18 15:59:17 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:59:17 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:59:17 --> Utf8 Class Initialized
INFO - 2023-08-18 15:59:17 --> URI Class Initialized
INFO - 2023-08-18 15:59:17 --> Router Class Initialized
INFO - 2023-08-18 15:59:17 --> Output Class Initialized
INFO - 2023-08-18 15:59:17 --> Security Class Initialized
DEBUG - 2023-08-18 15:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:59:17 --> Input Class Initialized
INFO - 2023-08-18 15:59:17 --> Language Class Initialized
INFO - 2023-08-18 15:59:17 --> Loader Class Initialized
INFO - 2023-08-18 15:59:17 --> Helper loaded: url_helper
INFO - 2023-08-18 15:59:17 --> Helper loaded: file_helper
INFO - 2023-08-18 15:59:17 --> Helper loaded: html_helper
INFO - 2023-08-18 15:59:17 --> Helper loaded: text_helper
INFO - 2023-08-18 15:59:17 --> Helper loaded: form_helper
INFO - 2023-08-18 15:59:17 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:59:17 --> Helper loaded: security_helper
INFO - 2023-08-18 15:59:17 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:59:17 --> Database Driver Class Initialized
INFO - 2023-08-18 15:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:59:17 --> Parser Class Initialized
INFO - 2023-08-18 15:59:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:59:17 --> Pagination Class Initialized
INFO - 2023-08-18 15:59:17 --> Form Validation Class Initialized
INFO - 2023-08-18 15:59:17 --> Controller Class Initialized
INFO - 2023-08-18 15:59:17 --> Model Class Initialized
DEBUG - 2023-08-18 15:59:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:59:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:59:17 --> Model Class Initialized
INFO - 2023-08-18 15:59:17 --> Final output sent to browser
DEBUG - 2023-08-18 15:59:17 --> Total execution time: 0.0180
ERROR - 2023-08-18 15:59:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:59:44 --> Config Class Initialized
INFO - 2023-08-18 15:59:44 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:59:44 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:59:44 --> Utf8 Class Initialized
INFO - 2023-08-18 15:59:44 --> URI Class Initialized
INFO - 2023-08-18 15:59:44 --> Router Class Initialized
INFO - 2023-08-18 15:59:44 --> Output Class Initialized
INFO - 2023-08-18 15:59:44 --> Security Class Initialized
DEBUG - 2023-08-18 15:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:59:44 --> Input Class Initialized
INFO - 2023-08-18 15:59:44 --> Language Class Initialized
INFO - 2023-08-18 15:59:44 --> Loader Class Initialized
INFO - 2023-08-18 15:59:44 --> Helper loaded: url_helper
INFO - 2023-08-18 15:59:44 --> Helper loaded: file_helper
INFO - 2023-08-18 15:59:44 --> Helper loaded: html_helper
INFO - 2023-08-18 15:59:44 --> Helper loaded: text_helper
INFO - 2023-08-18 15:59:44 --> Helper loaded: form_helper
INFO - 2023-08-18 15:59:44 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:59:44 --> Helper loaded: security_helper
INFO - 2023-08-18 15:59:44 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:59:44 --> Database Driver Class Initialized
INFO - 2023-08-18 15:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:59:44 --> Parser Class Initialized
INFO - 2023-08-18 15:59:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:59:44 --> Pagination Class Initialized
INFO - 2023-08-18 15:59:44 --> Form Validation Class Initialized
INFO - 2023-08-18 15:59:44 --> Controller Class Initialized
INFO - 2023-08-18 15:59:44 --> Model Class Initialized
DEBUG - 2023-08-18 15:59:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:59:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:59:44 --> Model Class Initialized
DEBUG - 2023-08-18 15:59:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:59:44 --> Model Class Initialized
INFO - 2023-08-18 15:59:44 --> Final output sent to browser
DEBUG - 2023-08-18 15:59:44 --> Total execution time: 0.0583
ERROR - 2023-08-18 15:59:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:59:45 --> Config Class Initialized
INFO - 2023-08-18 15:59:45 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:59:45 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:59:45 --> Utf8 Class Initialized
INFO - 2023-08-18 15:59:45 --> URI Class Initialized
INFO - 2023-08-18 15:59:45 --> Router Class Initialized
INFO - 2023-08-18 15:59:45 --> Output Class Initialized
INFO - 2023-08-18 15:59:45 --> Security Class Initialized
DEBUG - 2023-08-18 15:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:59:45 --> Input Class Initialized
INFO - 2023-08-18 15:59:45 --> Language Class Initialized
INFO - 2023-08-18 15:59:45 --> Loader Class Initialized
INFO - 2023-08-18 15:59:45 --> Helper loaded: url_helper
INFO - 2023-08-18 15:59:45 --> Helper loaded: file_helper
INFO - 2023-08-18 15:59:45 --> Helper loaded: html_helper
INFO - 2023-08-18 15:59:45 --> Helper loaded: text_helper
INFO - 2023-08-18 15:59:45 --> Helper loaded: form_helper
INFO - 2023-08-18 15:59:45 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:59:45 --> Helper loaded: security_helper
INFO - 2023-08-18 15:59:45 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:59:45 --> Database Driver Class Initialized
INFO - 2023-08-18 15:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:59:45 --> Parser Class Initialized
INFO - 2023-08-18 15:59:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:59:45 --> Pagination Class Initialized
INFO - 2023-08-18 15:59:45 --> Form Validation Class Initialized
INFO - 2023-08-18 15:59:45 --> Controller Class Initialized
INFO - 2023-08-18 15:59:45 --> Model Class Initialized
DEBUG - 2023-08-18 15:59:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:59:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:59:45 --> Model Class Initialized
DEBUG - 2023-08-18 15:59:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:59:45 --> Model Class Initialized
INFO - 2023-08-18 15:59:45 --> Final output sent to browser
DEBUG - 2023-08-18 15:59:45 --> Total execution time: 0.0571
ERROR - 2023-08-18 15:59:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:59:46 --> Config Class Initialized
INFO - 2023-08-18 15:59:46 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:59:46 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:59:46 --> Utf8 Class Initialized
INFO - 2023-08-18 15:59:46 --> URI Class Initialized
INFO - 2023-08-18 15:59:46 --> Router Class Initialized
INFO - 2023-08-18 15:59:46 --> Output Class Initialized
INFO - 2023-08-18 15:59:46 --> Security Class Initialized
DEBUG - 2023-08-18 15:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:59:46 --> Input Class Initialized
INFO - 2023-08-18 15:59:46 --> Language Class Initialized
INFO - 2023-08-18 15:59:46 --> Loader Class Initialized
INFO - 2023-08-18 15:59:46 --> Helper loaded: url_helper
INFO - 2023-08-18 15:59:46 --> Helper loaded: file_helper
INFO - 2023-08-18 15:59:46 --> Helper loaded: html_helper
INFO - 2023-08-18 15:59:46 --> Helper loaded: text_helper
INFO - 2023-08-18 15:59:46 --> Helper loaded: form_helper
INFO - 2023-08-18 15:59:46 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:59:46 --> Helper loaded: security_helper
INFO - 2023-08-18 15:59:46 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:59:46 --> Database Driver Class Initialized
INFO - 2023-08-18 15:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:59:46 --> Parser Class Initialized
INFO - 2023-08-18 15:59:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:59:46 --> Pagination Class Initialized
INFO - 2023-08-18 15:59:46 --> Form Validation Class Initialized
INFO - 2023-08-18 15:59:46 --> Controller Class Initialized
INFO - 2023-08-18 15:59:46 --> Model Class Initialized
DEBUG - 2023-08-18 15:59:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:59:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:59:46 --> Model Class Initialized
DEBUG - 2023-08-18 15:59:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:59:46 --> Model Class Initialized
INFO - 2023-08-18 15:59:46 --> Final output sent to browser
DEBUG - 2023-08-18 15:59:46 --> Total execution time: 0.0531
ERROR - 2023-08-18 15:59:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:59:46 --> Config Class Initialized
INFO - 2023-08-18 15:59:46 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:59:46 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:59:46 --> Utf8 Class Initialized
INFO - 2023-08-18 15:59:46 --> URI Class Initialized
INFO - 2023-08-18 15:59:46 --> Router Class Initialized
INFO - 2023-08-18 15:59:46 --> Output Class Initialized
INFO - 2023-08-18 15:59:46 --> Security Class Initialized
DEBUG - 2023-08-18 15:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:59:46 --> Input Class Initialized
INFO - 2023-08-18 15:59:46 --> Language Class Initialized
INFO - 2023-08-18 15:59:46 --> Loader Class Initialized
INFO - 2023-08-18 15:59:46 --> Helper loaded: url_helper
INFO - 2023-08-18 15:59:46 --> Helper loaded: file_helper
INFO - 2023-08-18 15:59:46 --> Helper loaded: html_helper
INFO - 2023-08-18 15:59:46 --> Helper loaded: text_helper
INFO - 2023-08-18 15:59:46 --> Helper loaded: form_helper
INFO - 2023-08-18 15:59:46 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:59:46 --> Helper loaded: security_helper
INFO - 2023-08-18 15:59:46 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:59:46 --> Database Driver Class Initialized
INFO - 2023-08-18 15:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:59:46 --> Parser Class Initialized
INFO - 2023-08-18 15:59:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:59:46 --> Pagination Class Initialized
INFO - 2023-08-18 15:59:46 --> Form Validation Class Initialized
INFO - 2023-08-18 15:59:46 --> Controller Class Initialized
INFO - 2023-08-18 15:59:46 --> Model Class Initialized
DEBUG - 2023-08-18 15:59:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:59:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:59:46 --> Model Class Initialized
DEBUG - 2023-08-18 15:59:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:59:46 --> Model Class Initialized
INFO - 2023-08-18 15:59:46 --> Final output sent to browser
DEBUG - 2023-08-18 15:59:46 --> Total execution time: 0.0196
ERROR - 2023-08-18 15:59:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:59:48 --> Config Class Initialized
INFO - 2023-08-18 15:59:48 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:59:48 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:59:48 --> Utf8 Class Initialized
INFO - 2023-08-18 15:59:48 --> URI Class Initialized
INFO - 2023-08-18 15:59:48 --> Router Class Initialized
INFO - 2023-08-18 15:59:48 --> Output Class Initialized
INFO - 2023-08-18 15:59:48 --> Security Class Initialized
DEBUG - 2023-08-18 15:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:59:48 --> Input Class Initialized
INFO - 2023-08-18 15:59:48 --> Language Class Initialized
INFO - 2023-08-18 15:59:48 --> Loader Class Initialized
INFO - 2023-08-18 15:59:48 --> Helper loaded: url_helper
INFO - 2023-08-18 15:59:48 --> Helper loaded: file_helper
INFO - 2023-08-18 15:59:48 --> Helper loaded: html_helper
INFO - 2023-08-18 15:59:48 --> Helper loaded: text_helper
INFO - 2023-08-18 15:59:48 --> Helper loaded: form_helper
INFO - 2023-08-18 15:59:48 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:59:48 --> Helper loaded: security_helper
INFO - 2023-08-18 15:59:48 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:59:48 --> Database Driver Class Initialized
INFO - 2023-08-18 15:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:59:48 --> Parser Class Initialized
INFO - 2023-08-18 15:59:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:59:48 --> Pagination Class Initialized
INFO - 2023-08-18 15:59:48 --> Form Validation Class Initialized
INFO - 2023-08-18 15:59:48 --> Controller Class Initialized
INFO - 2023-08-18 15:59:48 --> Model Class Initialized
DEBUG - 2023-08-18 15:59:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:59:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:59:48 --> Model Class Initialized
INFO - 2023-08-18 15:59:48 --> Model Class Initialized
INFO - 2023-08-18 15:59:48 --> Final output sent to browser
DEBUG - 2023-08-18 15:59:48 --> Total execution time: 0.0180
ERROR - 2023-08-18 15:59:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 15:59:50 --> Config Class Initialized
INFO - 2023-08-18 15:59:50 --> Hooks Class Initialized
DEBUG - 2023-08-18 15:59:50 --> UTF-8 Support Enabled
INFO - 2023-08-18 15:59:50 --> Utf8 Class Initialized
INFO - 2023-08-18 15:59:50 --> URI Class Initialized
INFO - 2023-08-18 15:59:50 --> Router Class Initialized
INFO - 2023-08-18 15:59:50 --> Output Class Initialized
INFO - 2023-08-18 15:59:50 --> Security Class Initialized
DEBUG - 2023-08-18 15:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 15:59:50 --> Input Class Initialized
INFO - 2023-08-18 15:59:50 --> Language Class Initialized
INFO - 2023-08-18 15:59:50 --> Loader Class Initialized
INFO - 2023-08-18 15:59:50 --> Helper loaded: url_helper
INFO - 2023-08-18 15:59:50 --> Helper loaded: file_helper
INFO - 2023-08-18 15:59:50 --> Helper loaded: html_helper
INFO - 2023-08-18 15:59:50 --> Helper loaded: text_helper
INFO - 2023-08-18 15:59:50 --> Helper loaded: form_helper
INFO - 2023-08-18 15:59:50 --> Helper loaded: lang_helper
INFO - 2023-08-18 15:59:50 --> Helper loaded: security_helper
INFO - 2023-08-18 15:59:50 --> Helper loaded: cookie_helper
INFO - 2023-08-18 15:59:50 --> Database Driver Class Initialized
INFO - 2023-08-18 15:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 15:59:50 --> Parser Class Initialized
INFO - 2023-08-18 15:59:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 15:59:50 --> Pagination Class Initialized
INFO - 2023-08-18 15:59:50 --> Form Validation Class Initialized
INFO - 2023-08-18 15:59:50 --> Controller Class Initialized
INFO - 2023-08-18 15:59:50 --> Model Class Initialized
DEBUG - 2023-08-18 15:59:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 15:59:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 15:59:50 --> Model Class Initialized
INFO - 2023-08-18 15:59:50 --> Final output sent to browser
DEBUG - 2023-08-18 15:59:50 --> Total execution time: 0.0159
ERROR - 2023-08-18 16:00:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 16:00:24 --> Config Class Initialized
INFO - 2023-08-18 16:00:24 --> Hooks Class Initialized
DEBUG - 2023-08-18 16:00:24 --> UTF-8 Support Enabled
INFO - 2023-08-18 16:00:24 --> Utf8 Class Initialized
INFO - 2023-08-18 16:00:24 --> URI Class Initialized
INFO - 2023-08-18 16:00:24 --> Router Class Initialized
INFO - 2023-08-18 16:00:24 --> Output Class Initialized
INFO - 2023-08-18 16:00:24 --> Security Class Initialized
DEBUG - 2023-08-18 16:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 16:00:24 --> Input Class Initialized
INFO - 2023-08-18 16:00:24 --> Language Class Initialized
INFO - 2023-08-18 16:00:24 --> Loader Class Initialized
INFO - 2023-08-18 16:00:24 --> Helper loaded: url_helper
INFO - 2023-08-18 16:00:24 --> Helper loaded: file_helper
INFO - 2023-08-18 16:00:24 --> Helper loaded: html_helper
INFO - 2023-08-18 16:00:24 --> Helper loaded: text_helper
INFO - 2023-08-18 16:00:24 --> Helper loaded: form_helper
INFO - 2023-08-18 16:00:24 --> Helper loaded: lang_helper
INFO - 2023-08-18 16:00:24 --> Helper loaded: security_helper
INFO - 2023-08-18 16:00:24 --> Helper loaded: cookie_helper
INFO - 2023-08-18 16:00:24 --> Database Driver Class Initialized
INFO - 2023-08-18 16:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 16:00:24 --> Parser Class Initialized
INFO - 2023-08-18 16:00:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 16:00:24 --> Pagination Class Initialized
INFO - 2023-08-18 16:00:24 --> Form Validation Class Initialized
INFO - 2023-08-18 16:00:24 --> Controller Class Initialized
INFO - 2023-08-18 16:00:24 --> Model Class Initialized
DEBUG - 2023-08-18 16:00:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 16:00:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:00:24 --> Model Class Initialized
DEBUG - 2023-08-18 16:00:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:00:24 --> Model Class Initialized
INFO - 2023-08-18 16:00:24 --> Final output sent to browser
DEBUG - 2023-08-18 16:00:24 --> Total execution time: 0.0573
ERROR - 2023-08-18 16:00:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 16:00:24 --> Config Class Initialized
INFO - 2023-08-18 16:00:24 --> Hooks Class Initialized
DEBUG - 2023-08-18 16:00:24 --> UTF-8 Support Enabled
INFO - 2023-08-18 16:00:24 --> Utf8 Class Initialized
INFO - 2023-08-18 16:00:24 --> URI Class Initialized
INFO - 2023-08-18 16:00:24 --> Router Class Initialized
INFO - 2023-08-18 16:00:24 --> Output Class Initialized
INFO - 2023-08-18 16:00:24 --> Security Class Initialized
DEBUG - 2023-08-18 16:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 16:00:24 --> Input Class Initialized
INFO - 2023-08-18 16:00:24 --> Language Class Initialized
INFO - 2023-08-18 16:00:24 --> Loader Class Initialized
INFO - 2023-08-18 16:00:24 --> Helper loaded: url_helper
INFO - 2023-08-18 16:00:24 --> Helper loaded: file_helper
INFO - 2023-08-18 16:00:24 --> Helper loaded: html_helper
INFO - 2023-08-18 16:00:24 --> Helper loaded: text_helper
INFO - 2023-08-18 16:00:24 --> Helper loaded: form_helper
INFO - 2023-08-18 16:00:24 --> Helper loaded: lang_helper
INFO - 2023-08-18 16:00:24 --> Helper loaded: security_helper
INFO - 2023-08-18 16:00:24 --> Helper loaded: cookie_helper
INFO - 2023-08-18 16:00:24 --> Database Driver Class Initialized
INFO - 2023-08-18 16:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 16:00:24 --> Parser Class Initialized
INFO - 2023-08-18 16:00:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 16:00:24 --> Pagination Class Initialized
INFO - 2023-08-18 16:00:24 --> Form Validation Class Initialized
INFO - 2023-08-18 16:00:24 --> Controller Class Initialized
INFO - 2023-08-18 16:00:24 --> Model Class Initialized
DEBUG - 2023-08-18 16:00:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 16:00:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:00:24 --> Model Class Initialized
DEBUG - 2023-08-18 16:00:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:00:24 --> Model Class Initialized
INFO - 2023-08-18 16:00:24 --> Final output sent to browser
DEBUG - 2023-08-18 16:00:24 --> Total execution time: 0.0564
ERROR - 2023-08-18 16:00:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 16:00:24 --> Config Class Initialized
INFO - 2023-08-18 16:00:24 --> Hooks Class Initialized
DEBUG - 2023-08-18 16:00:24 --> UTF-8 Support Enabled
INFO - 2023-08-18 16:00:24 --> Utf8 Class Initialized
INFO - 2023-08-18 16:00:24 --> URI Class Initialized
INFO - 2023-08-18 16:00:24 --> Router Class Initialized
INFO - 2023-08-18 16:00:24 --> Output Class Initialized
INFO - 2023-08-18 16:00:24 --> Security Class Initialized
DEBUG - 2023-08-18 16:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 16:00:24 --> Input Class Initialized
INFO - 2023-08-18 16:00:24 --> Language Class Initialized
INFO - 2023-08-18 16:00:24 --> Loader Class Initialized
INFO - 2023-08-18 16:00:24 --> Helper loaded: url_helper
INFO - 2023-08-18 16:00:24 --> Helper loaded: file_helper
INFO - 2023-08-18 16:00:24 --> Helper loaded: html_helper
INFO - 2023-08-18 16:00:24 --> Helper loaded: text_helper
INFO - 2023-08-18 16:00:24 --> Helper loaded: form_helper
INFO - 2023-08-18 16:00:24 --> Helper loaded: lang_helper
INFO - 2023-08-18 16:00:24 --> Helper loaded: security_helper
INFO - 2023-08-18 16:00:24 --> Helper loaded: cookie_helper
INFO - 2023-08-18 16:00:24 --> Database Driver Class Initialized
INFO - 2023-08-18 16:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 16:00:24 --> Parser Class Initialized
INFO - 2023-08-18 16:00:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 16:00:24 --> Pagination Class Initialized
INFO - 2023-08-18 16:00:24 --> Form Validation Class Initialized
INFO - 2023-08-18 16:00:24 --> Controller Class Initialized
INFO - 2023-08-18 16:00:24 --> Model Class Initialized
DEBUG - 2023-08-18 16:00:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 16:00:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:00:24 --> Model Class Initialized
DEBUG - 2023-08-18 16:00:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:00:24 --> Model Class Initialized
INFO - 2023-08-18 16:00:24 --> Final output sent to browser
DEBUG - 2023-08-18 16:00:24 --> Total execution time: 0.0204
ERROR - 2023-08-18 16:00:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 16:00:30 --> Config Class Initialized
INFO - 2023-08-18 16:00:30 --> Hooks Class Initialized
DEBUG - 2023-08-18 16:00:30 --> UTF-8 Support Enabled
INFO - 2023-08-18 16:00:30 --> Utf8 Class Initialized
INFO - 2023-08-18 16:00:30 --> URI Class Initialized
INFO - 2023-08-18 16:00:30 --> Router Class Initialized
INFO - 2023-08-18 16:00:30 --> Output Class Initialized
INFO - 2023-08-18 16:00:30 --> Security Class Initialized
DEBUG - 2023-08-18 16:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 16:00:30 --> Input Class Initialized
INFO - 2023-08-18 16:00:30 --> Language Class Initialized
INFO - 2023-08-18 16:00:30 --> Loader Class Initialized
INFO - 2023-08-18 16:00:30 --> Helper loaded: url_helper
INFO - 2023-08-18 16:00:30 --> Helper loaded: file_helper
INFO - 2023-08-18 16:00:30 --> Helper loaded: html_helper
INFO - 2023-08-18 16:00:30 --> Helper loaded: text_helper
INFO - 2023-08-18 16:00:30 --> Helper loaded: form_helper
INFO - 2023-08-18 16:00:30 --> Helper loaded: lang_helper
INFO - 2023-08-18 16:00:30 --> Helper loaded: security_helper
INFO - 2023-08-18 16:00:30 --> Helper loaded: cookie_helper
INFO - 2023-08-18 16:00:30 --> Database Driver Class Initialized
INFO - 2023-08-18 16:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 16:00:30 --> Parser Class Initialized
INFO - 2023-08-18 16:00:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 16:00:30 --> Pagination Class Initialized
INFO - 2023-08-18 16:00:30 --> Form Validation Class Initialized
INFO - 2023-08-18 16:00:30 --> Controller Class Initialized
INFO - 2023-08-18 16:00:30 --> Model Class Initialized
DEBUG - 2023-08-18 16:00:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 16:00:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:00:30 --> Model Class Initialized
DEBUG - 2023-08-18 16:00:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:00:30 --> Model Class Initialized
INFO - 2023-08-18 16:00:30 --> Final output sent to browser
DEBUG - 2023-08-18 16:00:30 --> Total execution time: 0.0564
ERROR - 2023-08-18 16:00:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 16:00:45 --> Config Class Initialized
INFO - 2023-08-18 16:00:45 --> Hooks Class Initialized
DEBUG - 2023-08-18 16:00:45 --> UTF-8 Support Enabled
INFO - 2023-08-18 16:00:45 --> Utf8 Class Initialized
INFO - 2023-08-18 16:00:45 --> URI Class Initialized
INFO - 2023-08-18 16:00:45 --> Router Class Initialized
INFO - 2023-08-18 16:00:45 --> Output Class Initialized
INFO - 2023-08-18 16:00:45 --> Security Class Initialized
DEBUG - 2023-08-18 16:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 16:00:45 --> Input Class Initialized
INFO - 2023-08-18 16:00:45 --> Language Class Initialized
INFO - 2023-08-18 16:00:45 --> Loader Class Initialized
INFO - 2023-08-18 16:00:45 --> Helper loaded: url_helper
INFO - 2023-08-18 16:00:45 --> Helper loaded: file_helper
INFO - 2023-08-18 16:00:45 --> Helper loaded: html_helper
INFO - 2023-08-18 16:00:45 --> Helper loaded: text_helper
INFO - 2023-08-18 16:00:45 --> Helper loaded: form_helper
INFO - 2023-08-18 16:00:45 --> Helper loaded: lang_helper
INFO - 2023-08-18 16:00:45 --> Helper loaded: security_helper
INFO - 2023-08-18 16:00:45 --> Helper loaded: cookie_helper
INFO - 2023-08-18 16:00:45 --> Database Driver Class Initialized
INFO - 2023-08-18 16:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 16:00:45 --> Parser Class Initialized
INFO - 2023-08-18 16:00:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 16:00:45 --> Pagination Class Initialized
INFO - 2023-08-18 16:00:45 --> Form Validation Class Initialized
INFO - 2023-08-18 16:00:45 --> Controller Class Initialized
INFO - 2023-08-18 16:00:45 --> Model Class Initialized
DEBUG - 2023-08-18 16:00:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 16:00:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:00:45 --> Model Class Initialized
INFO - 2023-08-18 16:00:45 --> Model Class Initialized
INFO - 2023-08-18 16:00:45 --> Final output sent to browser
DEBUG - 2023-08-18 16:00:45 --> Total execution time: 0.0223
ERROR - 2023-08-18 16:00:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 16:00:48 --> Config Class Initialized
INFO - 2023-08-18 16:00:48 --> Hooks Class Initialized
DEBUG - 2023-08-18 16:00:48 --> UTF-8 Support Enabled
INFO - 2023-08-18 16:00:48 --> Utf8 Class Initialized
INFO - 2023-08-18 16:00:48 --> URI Class Initialized
INFO - 2023-08-18 16:00:48 --> Router Class Initialized
INFO - 2023-08-18 16:00:48 --> Output Class Initialized
INFO - 2023-08-18 16:00:48 --> Security Class Initialized
DEBUG - 2023-08-18 16:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 16:00:48 --> Input Class Initialized
INFO - 2023-08-18 16:00:48 --> Language Class Initialized
INFO - 2023-08-18 16:00:48 --> Loader Class Initialized
INFO - 2023-08-18 16:00:48 --> Helper loaded: url_helper
INFO - 2023-08-18 16:00:48 --> Helper loaded: file_helper
INFO - 2023-08-18 16:00:48 --> Helper loaded: html_helper
INFO - 2023-08-18 16:00:48 --> Helper loaded: text_helper
INFO - 2023-08-18 16:00:48 --> Helper loaded: form_helper
INFO - 2023-08-18 16:00:48 --> Helper loaded: lang_helper
INFO - 2023-08-18 16:00:48 --> Helper loaded: security_helper
INFO - 2023-08-18 16:00:48 --> Helper loaded: cookie_helper
INFO - 2023-08-18 16:00:48 --> Database Driver Class Initialized
INFO - 2023-08-18 16:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 16:00:48 --> Parser Class Initialized
INFO - 2023-08-18 16:00:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 16:00:48 --> Pagination Class Initialized
INFO - 2023-08-18 16:00:48 --> Form Validation Class Initialized
INFO - 2023-08-18 16:00:48 --> Controller Class Initialized
INFO - 2023-08-18 16:00:48 --> Model Class Initialized
DEBUG - 2023-08-18 16:00:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 16:00:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:00:48 --> Model Class Initialized
INFO - 2023-08-18 16:00:48 --> Final output sent to browser
DEBUG - 2023-08-18 16:00:48 --> Total execution time: 0.0170
ERROR - 2023-08-18 16:02:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 16:02:11 --> Config Class Initialized
INFO - 2023-08-18 16:02:11 --> Hooks Class Initialized
DEBUG - 2023-08-18 16:02:11 --> UTF-8 Support Enabled
INFO - 2023-08-18 16:02:11 --> Utf8 Class Initialized
INFO - 2023-08-18 16:02:11 --> URI Class Initialized
INFO - 2023-08-18 16:02:11 --> Router Class Initialized
INFO - 2023-08-18 16:02:11 --> Output Class Initialized
INFO - 2023-08-18 16:02:11 --> Security Class Initialized
DEBUG - 2023-08-18 16:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 16:02:11 --> Input Class Initialized
INFO - 2023-08-18 16:02:11 --> Language Class Initialized
INFO - 2023-08-18 16:02:11 --> Loader Class Initialized
INFO - 2023-08-18 16:02:11 --> Helper loaded: url_helper
INFO - 2023-08-18 16:02:11 --> Helper loaded: file_helper
INFO - 2023-08-18 16:02:11 --> Helper loaded: html_helper
INFO - 2023-08-18 16:02:11 --> Helper loaded: text_helper
INFO - 2023-08-18 16:02:11 --> Helper loaded: form_helper
INFO - 2023-08-18 16:02:11 --> Helper loaded: lang_helper
INFO - 2023-08-18 16:02:11 --> Helper loaded: security_helper
INFO - 2023-08-18 16:02:11 --> Helper loaded: cookie_helper
INFO - 2023-08-18 16:02:11 --> Database Driver Class Initialized
INFO - 2023-08-18 16:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 16:02:11 --> Parser Class Initialized
INFO - 2023-08-18 16:02:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 16:02:11 --> Pagination Class Initialized
INFO - 2023-08-18 16:02:11 --> Form Validation Class Initialized
INFO - 2023-08-18 16:02:11 --> Controller Class Initialized
INFO - 2023-08-18 16:02:11 --> Model Class Initialized
DEBUG - 2023-08-18 16:02:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 16:02:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:02:11 --> Model Class Initialized
DEBUG - 2023-08-18 16:02:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:02:11 --> Model Class Initialized
INFO - 2023-08-18 16:02:11 --> Final output sent to browser
DEBUG - 2023-08-18 16:02:11 --> Total execution time: 0.0208
ERROR - 2023-08-18 16:02:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 16:02:12 --> Config Class Initialized
INFO - 2023-08-18 16:02:12 --> Hooks Class Initialized
DEBUG - 2023-08-18 16:02:12 --> UTF-8 Support Enabled
INFO - 2023-08-18 16:02:12 --> Utf8 Class Initialized
INFO - 2023-08-18 16:02:12 --> URI Class Initialized
INFO - 2023-08-18 16:02:12 --> Router Class Initialized
INFO - 2023-08-18 16:02:12 --> Output Class Initialized
INFO - 2023-08-18 16:02:12 --> Security Class Initialized
DEBUG - 2023-08-18 16:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 16:02:12 --> Input Class Initialized
INFO - 2023-08-18 16:02:12 --> Language Class Initialized
INFO - 2023-08-18 16:02:12 --> Loader Class Initialized
INFO - 2023-08-18 16:02:12 --> Helper loaded: url_helper
INFO - 2023-08-18 16:02:12 --> Helper loaded: file_helper
INFO - 2023-08-18 16:02:12 --> Helper loaded: html_helper
INFO - 2023-08-18 16:02:12 --> Helper loaded: text_helper
INFO - 2023-08-18 16:02:12 --> Helper loaded: form_helper
INFO - 2023-08-18 16:02:12 --> Helper loaded: lang_helper
INFO - 2023-08-18 16:02:12 --> Helper loaded: security_helper
INFO - 2023-08-18 16:02:12 --> Helper loaded: cookie_helper
INFO - 2023-08-18 16:02:12 --> Database Driver Class Initialized
INFO - 2023-08-18 16:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 16:02:12 --> Parser Class Initialized
INFO - 2023-08-18 16:02:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 16:02:12 --> Pagination Class Initialized
INFO - 2023-08-18 16:02:12 --> Form Validation Class Initialized
INFO - 2023-08-18 16:02:12 --> Controller Class Initialized
INFO - 2023-08-18 16:02:12 --> Model Class Initialized
DEBUG - 2023-08-18 16:02:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 16:02:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:02:12 --> Model Class Initialized
DEBUG - 2023-08-18 16:02:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:02:12 --> Model Class Initialized
INFO - 2023-08-18 16:02:12 --> Final output sent to browser
DEBUG - 2023-08-18 16:02:12 --> Total execution time: 0.0665
ERROR - 2023-08-18 16:02:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 16:02:16 --> Config Class Initialized
INFO - 2023-08-18 16:02:16 --> Hooks Class Initialized
DEBUG - 2023-08-18 16:02:16 --> UTF-8 Support Enabled
INFO - 2023-08-18 16:02:16 --> Utf8 Class Initialized
INFO - 2023-08-18 16:02:16 --> URI Class Initialized
INFO - 2023-08-18 16:02:16 --> Router Class Initialized
INFO - 2023-08-18 16:02:16 --> Output Class Initialized
INFO - 2023-08-18 16:02:16 --> Security Class Initialized
DEBUG - 2023-08-18 16:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 16:02:16 --> Input Class Initialized
INFO - 2023-08-18 16:02:17 --> Language Class Initialized
INFO - 2023-08-18 16:02:17 --> Loader Class Initialized
INFO - 2023-08-18 16:02:17 --> Helper loaded: url_helper
INFO - 2023-08-18 16:02:17 --> Helper loaded: file_helper
INFO - 2023-08-18 16:02:17 --> Helper loaded: html_helper
INFO - 2023-08-18 16:02:17 --> Helper loaded: text_helper
INFO - 2023-08-18 16:02:17 --> Helper loaded: form_helper
INFO - 2023-08-18 16:02:17 --> Helper loaded: lang_helper
INFO - 2023-08-18 16:02:17 --> Helper loaded: security_helper
INFO - 2023-08-18 16:02:17 --> Helper loaded: cookie_helper
INFO - 2023-08-18 16:02:17 --> Database Driver Class Initialized
INFO - 2023-08-18 16:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 16:02:17 --> Parser Class Initialized
INFO - 2023-08-18 16:02:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 16:02:17 --> Pagination Class Initialized
INFO - 2023-08-18 16:02:17 --> Form Validation Class Initialized
INFO - 2023-08-18 16:02:17 --> Controller Class Initialized
INFO - 2023-08-18 16:02:17 --> Model Class Initialized
DEBUG - 2023-08-18 16:02:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 16:02:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:02:17 --> Model Class Initialized
DEBUG - 2023-08-18 16:02:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:02:17 --> Model Class Initialized
INFO - 2023-08-18 16:02:17 --> Final output sent to browser
DEBUG - 2023-08-18 16:02:17 --> Total execution time: 0.0250
ERROR - 2023-08-18 16:02:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 16:02:18 --> Config Class Initialized
INFO - 2023-08-18 16:02:18 --> Hooks Class Initialized
DEBUG - 2023-08-18 16:02:18 --> UTF-8 Support Enabled
INFO - 2023-08-18 16:02:18 --> Utf8 Class Initialized
INFO - 2023-08-18 16:02:18 --> URI Class Initialized
INFO - 2023-08-18 16:02:18 --> Router Class Initialized
INFO - 2023-08-18 16:02:18 --> Output Class Initialized
INFO - 2023-08-18 16:02:18 --> Security Class Initialized
DEBUG - 2023-08-18 16:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 16:02:18 --> Input Class Initialized
INFO - 2023-08-18 16:02:18 --> Language Class Initialized
INFO - 2023-08-18 16:02:18 --> Loader Class Initialized
INFO - 2023-08-18 16:02:18 --> Helper loaded: url_helper
INFO - 2023-08-18 16:02:18 --> Helper loaded: file_helper
INFO - 2023-08-18 16:02:18 --> Helper loaded: html_helper
INFO - 2023-08-18 16:02:18 --> Helper loaded: text_helper
INFO - 2023-08-18 16:02:18 --> Helper loaded: form_helper
INFO - 2023-08-18 16:02:18 --> Helper loaded: lang_helper
INFO - 2023-08-18 16:02:18 --> Helper loaded: security_helper
INFO - 2023-08-18 16:02:18 --> Helper loaded: cookie_helper
INFO - 2023-08-18 16:02:18 --> Database Driver Class Initialized
INFO - 2023-08-18 16:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 16:02:18 --> Parser Class Initialized
INFO - 2023-08-18 16:02:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 16:02:18 --> Pagination Class Initialized
INFO - 2023-08-18 16:02:18 --> Form Validation Class Initialized
INFO - 2023-08-18 16:02:18 --> Controller Class Initialized
INFO - 2023-08-18 16:02:18 --> Model Class Initialized
DEBUG - 2023-08-18 16:02:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 16:02:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:02:18 --> Model Class Initialized
DEBUG - 2023-08-18 16:02:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:02:18 --> Model Class Initialized
INFO - 2023-08-18 16:02:18 --> Final output sent to browser
DEBUG - 2023-08-18 16:02:18 --> Total execution time: 0.0597
ERROR - 2023-08-18 16:02:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 16:02:22 --> Config Class Initialized
INFO - 2023-08-18 16:02:22 --> Hooks Class Initialized
DEBUG - 2023-08-18 16:02:22 --> UTF-8 Support Enabled
INFO - 2023-08-18 16:02:22 --> Utf8 Class Initialized
INFO - 2023-08-18 16:02:22 --> URI Class Initialized
INFO - 2023-08-18 16:02:22 --> Router Class Initialized
INFO - 2023-08-18 16:02:22 --> Output Class Initialized
INFO - 2023-08-18 16:02:22 --> Security Class Initialized
DEBUG - 2023-08-18 16:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 16:02:22 --> Input Class Initialized
INFO - 2023-08-18 16:02:22 --> Language Class Initialized
INFO - 2023-08-18 16:02:22 --> Loader Class Initialized
INFO - 2023-08-18 16:02:22 --> Helper loaded: url_helper
INFO - 2023-08-18 16:02:22 --> Helper loaded: file_helper
INFO - 2023-08-18 16:02:22 --> Helper loaded: html_helper
INFO - 2023-08-18 16:02:22 --> Helper loaded: text_helper
INFO - 2023-08-18 16:02:22 --> Helper loaded: form_helper
INFO - 2023-08-18 16:02:22 --> Helper loaded: lang_helper
INFO - 2023-08-18 16:02:22 --> Helper loaded: security_helper
INFO - 2023-08-18 16:02:22 --> Helper loaded: cookie_helper
INFO - 2023-08-18 16:02:22 --> Database Driver Class Initialized
INFO - 2023-08-18 16:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 16:02:22 --> Parser Class Initialized
INFO - 2023-08-18 16:02:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 16:02:22 --> Pagination Class Initialized
INFO - 2023-08-18 16:02:22 --> Form Validation Class Initialized
INFO - 2023-08-18 16:02:22 --> Controller Class Initialized
INFO - 2023-08-18 16:02:22 --> Model Class Initialized
DEBUG - 2023-08-18 16:02:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 16:02:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:02:22 --> Model Class Initialized
DEBUG - 2023-08-18 16:02:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:02:22 --> Model Class Initialized
INFO - 2023-08-18 16:02:22 --> Final output sent to browser
DEBUG - 2023-08-18 16:02:22 --> Total execution time: 0.0587
ERROR - 2023-08-18 16:02:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 16:02:22 --> Config Class Initialized
INFO - 2023-08-18 16:02:22 --> Hooks Class Initialized
DEBUG - 2023-08-18 16:02:22 --> UTF-8 Support Enabled
INFO - 2023-08-18 16:02:22 --> Utf8 Class Initialized
INFO - 2023-08-18 16:02:22 --> URI Class Initialized
INFO - 2023-08-18 16:02:22 --> Router Class Initialized
INFO - 2023-08-18 16:02:22 --> Output Class Initialized
INFO - 2023-08-18 16:02:22 --> Security Class Initialized
DEBUG - 2023-08-18 16:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 16:02:22 --> Input Class Initialized
INFO - 2023-08-18 16:02:22 --> Language Class Initialized
INFO - 2023-08-18 16:02:22 --> Loader Class Initialized
INFO - 2023-08-18 16:02:22 --> Helper loaded: url_helper
INFO - 2023-08-18 16:02:22 --> Helper loaded: file_helper
INFO - 2023-08-18 16:02:22 --> Helper loaded: html_helper
INFO - 2023-08-18 16:02:22 --> Helper loaded: text_helper
INFO - 2023-08-18 16:02:22 --> Helper loaded: form_helper
INFO - 2023-08-18 16:02:22 --> Helper loaded: lang_helper
INFO - 2023-08-18 16:02:22 --> Helper loaded: security_helper
INFO - 2023-08-18 16:02:22 --> Helper loaded: cookie_helper
INFO - 2023-08-18 16:02:22 --> Database Driver Class Initialized
INFO - 2023-08-18 16:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 16:02:22 --> Parser Class Initialized
INFO - 2023-08-18 16:02:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 16:02:22 --> Pagination Class Initialized
INFO - 2023-08-18 16:02:22 --> Form Validation Class Initialized
INFO - 2023-08-18 16:02:22 --> Controller Class Initialized
INFO - 2023-08-18 16:02:22 --> Model Class Initialized
DEBUG - 2023-08-18 16:02:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 16:02:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:02:22 --> Model Class Initialized
DEBUG - 2023-08-18 16:02:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:02:22 --> Model Class Initialized
INFO - 2023-08-18 16:02:22 --> Final output sent to browser
DEBUG - 2023-08-18 16:02:22 --> Total execution time: 0.0620
ERROR - 2023-08-18 16:02:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 16:02:22 --> Config Class Initialized
INFO - 2023-08-18 16:02:22 --> Hooks Class Initialized
DEBUG - 2023-08-18 16:02:22 --> UTF-8 Support Enabled
INFO - 2023-08-18 16:02:22 --> Utf8 Class Initialized
INFO - 2023-08-18 16:02:22 --> URI Class Initialized
INFO - 2023-08-18 16:02:22 --> Router Class Initialized
INFO - 2023-08-18 16:02:22 --> Output Class Initialized
INFO - 2023-08-18 16:02:22 --> Security Class Initialized
DEBUG - 2023-08-18 16:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 16:02:22 --> Input Class Initialized
INFO - 2023-08-18 16:02:22 --> Language Class Initialized
INFO - 2023-08-18 16:02:22 --> Loader Class Initialized
INFO - 2023-08-18 16:02:22 --> Helper loaded: url_helper
INFO - 2023-08-18 16:02:22 --> Helper loaded: file_helper
INFO - 2023-08-18 16:02:22 --> Helper loaded: html_helper
INFO - 2023-08-18 16:02:22 --> Helper loaded: text_helper
INFO - 2023-08-18 16:02:22 --> Helper loaded: form_helper
INFO - 2023-08-18 16:02:22 --> Helper loaded: lang_helper
INFO - 2023-08-18 16:02:22 --> Helper loaded: security_helper
INFO - 2023-08-18 16:02:22 --> Helper loaded: cookie_helper
INFO - 2023-08-18 16:02:22 --> Database Driver Class Initialized
INFO - 2023-08-18 16:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 16:02:22 --> Parser Class Initialized
INFO - 2023-08-18 16:02:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 16:02:22 --> Pagination Class Initialized
INFO - 2023-08-18 16:02:22 --> Form Validation Class Initialized
INFO - 2023-08-18 16:02:22 --> Controller Class Initialized
INFO - 2023-08-18 16:02:22 --> Model Class Initialized
DEBUG - 2023-08-18 16:02:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 16:02:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:02:22 --> Model Class Initialized
DEBUG - 2023-08-18 16:02:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:02:22 --> Model Class Initialized
INFO - 2023-08-18 16:02:23 --> Final output sent to browser
DEBUG - 2023-08-18 16:02:23 --> Total execution time: 0.0579
ERROR - 2023-08-18 16:02:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 16:02:23 --> Config Class Initialized
INFO - 2023-08-18 16:02:23 --> Hooks Class Initialized
DEBUG - 2023-08-18 16:02:23 --> UTF-8 Support Enabled
INFO - 2023-08-18 16:02:23 --> Utf8 Class Initialized
INFO - 2023-08-18 16:02:23 --> URI Class Initialized
INFO - 2023-08-18 16:02:23 --> Router Class Initialized
INFO - 2023-08-18 16:02:23 --> Output Class Initialized
INFO - 2023-08-18 16:02:23 --> Security Class Initialized
DEBUG - 2023-08-18 16:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 16:02:23 --> Input Class Initialized
INFO - 2023-08-18 16:02:23 --> Language Class Initialized
INFO - 2023-08-18 16:02:23 --> Loader Class Initialized
INFO - 2023-08-18 16:02:23 --> Helper loaded: url_helper
INFO - 2023-08-18 16:02:23 --> Helper loaded: file_helper
INFO - 2023-08-18 16:02:23 --> Helper loaded: html_helper
INFO - 2023-08-18 16:02:23 --> Helper loaded: text_helper
INFO - 2023-08-18 16:02:23 --> Helper loaded: form_helper
INFO - 2023-08-18 16:02:23 --> Helper loaded: lang_helper
INFO - 2023-08-18 16:02:23 --> Helper loaded: security_helper
INFO - 2023-08-18 16:02:23 --> Helper loaded: cookie_helper
INFO - 2023-08-18 16:02:23 --> Database Driver Class Initialized
INFO - 2023-08-18 16:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 16:02:23 --> Parser Class Initialized
INFO - 2023-08-18 16:02:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 16:02:23 --> Pagination Class Initialized
INFO - 2023-08-18 16:02:23 --> Form Validation Class Initialized
INFO - 2023-08-18 16:02:23 --> Controller Class Initialized
INFO - 2023-08-18 16:02:23 --> Model Class Initialized
DEBUG - 2023-08-18 16:02:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 16:02:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:02:23 --> Model Class Initialized
DEBUG - 2023-08-18 16:02:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:02:23 --> Model Class Initialized
INFO - 2023-08-18 16:02:23 --> Final output sent to browser
DEBUG - 2023-08-18 16:02:23 --> Total execution time: 0.0526
ERROR - 2023-08-18 16:02:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 16:02:25 --> Config Class Initialized
INFO - 2023-08-18 16:02:25 --> Hooks Class Initialized
DEBUG - 2023-08-18 16:02:25 --> UTF-8 Support Enabled
INFO - 2023-08-18 16:02:25 --> Utf8 Class Initialized
INFO - 2023-08-18 16:02:25 --> URI Class Initialized
INFO - 2023-08-18 16:02:25 --> Router Class Initialized
INFO - 2023-08-18 16:02:25 --> Output Class Initialized
INFO - 2023-08-18 16:02:25 --> Security Class Initialized
DEBUG - 2023-08-18 16:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 16:02:25 --> Input Class Initialized
INFO - 2023-08-18 16:02:25 --> Language Class Initialized
INFO - 2023-08-18 16:02:25 --> Loader Class Initialized
INFO - 2023-08-18 16:02:25 --> Helper loaded: url_helper
INFO - 2023-08-18 16:02:25 --> Helper loaded: file_helper
INFO - 2023-08-18 16:02:25 --> Helper loaded: html_helper
INFO - 2023-08-18 16:02:25 --> Helper loaded: text_helper
INFO - 2023-08-18 16:02:25 --> Helper loaded: form_helper
INFO - 2023-08-18 16:02:25 --> Helper loaded: lang_helper
INFO - 2023-08-18 16:02:25 --> Helper loaded: security_helper
INFO - 2023-08-18 16:02:25 --> Helper loaded: cookie_helper
INFO - 2023-08-18 16:02:25 --> Database Driver Class Initialized
INFO - 2023-08-18 16:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 16:02:25 --> Parser Class Initialized
INFO - 2023-08-18 16:02:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 16:02:25 --> Pagination Class Initialized
INFO - 2023-08-18 16:02:25 --> Form Validation Class Initialized
INFO - 2023-08-18 16:02:25 --> Controller Class Initialized
INFO - 2023-08-18 16:02:25 --> Model Class Initialized
DEBUG - 2023-08-18 16:02:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 16:02:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:02:25 --> Model Class Initialized
DEBUG - 2023-08-18 16:02:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:02:25 --> Model Class Initialized
INFO - 2023-08-18 16:02:25 --> Final output sent to browser
DEBUG - 2023-08-18 16:02:25 --> Total execution time: 0.0194
ERROR - 2023-08-18 16:02:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 16:02:28 --> Config Class Initialized
INFO - 2023-08-18 16:02:28 --> Hooks Class Initialized
DEBUG - 2023-08-18 16:02:28 --> UTF-8 Support Enabled
INFO - 2023-08-18 16:02:28 --> Utf8 Class Initialized
INFO - 2023-08-18 16:02:28 --> URI Class Initialized
INFO - 2023-08-18 16:02:28 --> Router Class Initialized
INFO - 2023-08-18 16:02:28 --> Output Class Initialized
INFO - 2023-08-18 16:02:28 --> Security Class Initialized
DEBUG - 2023-08-18 16:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 16:02:28 --> Input Class Initialized
INFO - 2023-08-18 16:02:28 --> Language Class Initialized
INFO - 2023-08-18 16:02:28 --> Loader Class Initialized
INFO - 2023-08-18 16:02:28 --> Helper loaded: url_helper
INFO - 2023-08-18 16:02:28 --> Helper loaded: file_helper
INFO - 2023-08-18 16:02:28 --> Helper loaded: html_helper
INFO - 2023-08-18 16:02:28 --> Helper loaded: text_helper
INFO - 2023-08-18 16:02:28 --> Helper loaded: form_helper
INFO - 2023-08-18 16:02:28 --> Helper loaded: lang_helper
INFO - 2023-08-18 16:02:28 --> Helper loaded: security_helper
INFO - 2023-08-18 16:02:28 --> Helper loaded: cookie_helper
INFO - 2023-08-18 16:02:28 --> Database Driver Class Initialized
INFO - 2023-08-18 16:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 16:02:28 --> Parser Class Initialized
INFO - 2023-08-18 16:02:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 16:02:28 --> Pagination Class Initialized
INFO - 2023-08-18 16:02:28 --> Form Validation Class Initialized
INFO - 2023-08-18 16:02:28 --> Controller Class Initialized
INFO - 2023-08-18 16:02:28 --> Model Class Initialized
DEBUG - 2023-08-18 16:02:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 16:02:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:02:28 --> Model Class Initialized
DEBUG - 2023-08-18 16:02:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:02:28 --> Model Class Initialized
INFO - 2023-08-18 16:02:28 --> Final output sent to browser
DEBUG - 2023-08-18 16:02:28 --> Total execution time: 0.0531
ERROR - 2023-08-18 16:02:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 16:02:29 --> Config Class Initialized
INFO - 2023-08-18 16:02:29 --> Hooks Class Initialized
DEBUG - 2023-08-18 16:02:29 --> UTF-8 Support Enabled
INFO - 2023-08-18 16:02:29 --> Utf8 Class Initialized
INFO - 2023-08-18 16:02:29 --> URI Class Initialized
INFO - 2023-08-18 16:02:29 --> Router Class Initialized
INFO - 2023-08-18 16:02:29 --> Output Class Initialized
INFO - 2023-08-18 16:02:29 --> Security Class Initialized
DEBUG - 2023-08-18 16:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 16:02:29 --> Input Class Initialized
INFO - 2023-08-18 16:02:29 --> Language Class Initialized
INFO - 2023-08-18 16:02:29 --> Loader Class Initialized
INFO - 2023-08-18 16:02:29 --> Helper loaded: url_helper
INFO - 2023-08-18 16:02:29 --> Helper loaded: file_helper
INFO - 2023-08-18 16:02:29 --> Helper loaded: html_helper
INFO - 2023-08-18 16:02:29 --> Helper loaded: text_helper
INFO - 2023-08-18 16:02:29 --> Helper loaded: form_helper
INFO - 2023-08-18 16:02:29 --> Helper loaded: lang_helper
INFO - 2023-08-18 16:02:29 --> Helper loaded: security_helper
INFO - 2023-08-18 16:02:29 --> Helper loaded: cookie_helper
INFO - 2023-08-18 16:02:29 --> Database Driver Class Initialized
INFO - 2023-08-18 16:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 16:02:29 --> Parser Class Initialized
INFO - 2023-08-18 16:02:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 16:02:29 --> Pagination Class Initialized
INFO - 2023-08-18 16:02:29 --> Form Validation Class Initialized
INFO - 2023-08-18 16:02:29 --> Controller Class Initialized
INFO - 2023-08-18 16:02:29 --> Model Class Initialized
DEBUG - 2023-08-18 16:02:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 16:02:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:02:29 --> Model Class Initialized
DEBUG - 2023-08-18 16:02:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:02:29 --> Model Class Initialized
INFO - 2023-08-18 16:02:29 --> Final output sent to browser
DEBUG - 2023-08-18 16:02:29 --> Total execution time: 0.0321
ERROR - 2023-08-18 16:02:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 16:02:31 --> Config Class Initialized
INFO - 2023-08-18 16:02:31 --> Hooks Class Initialized
DEBUG - 2023-08-18 16:02:31 --> UTF-8 Support Enabled
INFO - 2023-08-18 16:02:31 --> Utf8 Class Initialized
INFO - 2023-08-18 16:02:31 --> URI Class Initialized
INFO - 2023-08-18 16:02:31 --> Router Class Initialized
INFO - 2023-08-18 16:02:31 --> Output Class Initialized
INFO - 2023-08-18 16:02:31 --> Security Class Initialized
DEBUG - 2023-08-18 16:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 16:02:31 --> Input Class Initialized
INFO - 2023-08-18 16:02:31 --> Language Class Initialized
INFO - 2023-08-18 16:02:31 --> Loader Class Initialized
INFO - 2023-08-18 16:02:31 --> Helper loaded: url_helper
INFO - 2023-08-18 16:02:31 --> Helper loaded: file_helper
INFO - 2023-08-18 16:02:31 --> Helper loaded: html_helper
INFO - 2023-08-18 16:02:31 --> Helper loaded: text_helper
INFO - 2023-08-18 16:02:31 --> Helper loaded: form_helper
INFO - 2023-08-18 16:02:31 --> Helper loaded: lang_helper
INFO - 2023-08-18 16:02:31 --> Helper loaded: security_helper
INFO - 2023-08-18 16:02:31 --> Helper loaded: cookie_helper
INFO - 2023-08-18 16:02:31 --> Database Driver Class Initialized
INFO - 2023-08-18 16:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 16:02:31 --> Parser Class Initialized
INFO - 2023-08-18 16:02:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 16:02:31 --> Pagination Class Initialized
INFO - 2023-08-18 16:02:31 --> Form Validation Class Initialized
INFO - 2023-08-18 16:02:31 --> Controller Class Initialized
INFO - 2023-08-18 16:02:31 --> Model Class Initialized
DEBUG - 2023-08-18 16:02:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 16:02:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:02:31 --> Model Class Initialized
DEBUG - 2023-08-18 16:02:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:02:31 --> Model Class Initialized
INFO - 2023-08-18 16:02:31 --> Final output sent to browser
DEBUG - 2023-08-18 16:02:31 --> Total execution time: 0.0173
ERROR - 2023-08-18 16:02:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 16:02:32 --> Config Class Initialized
INFO - 2023-08-18 16:02:32 --> Hooks Class Initialized
DEBUG - 2023-08-18 16:02:32 --> UTF-8 Support Enabled
INFO - 2023-08-18 16:02:32 --> Utf8 Class Initialized
INFO - 2023-08-18 16:02:32 --> URI Class Initialized
INFO - 2023-08-18 16:02:32 --> Router Class Initialized
INFO - 2023-08-18 16:02:32 --> Output Class Initialized
INFO - 2023-08-18 16:02:32 --> Security Class Initialized
DEBUG - 2023-08-18 16:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 16:02:32 --> Input Class Initialized
INFO - 2023-08-18 16:02:32 --> Language Class Initialized
INFO - 2023-08-18 16:02:32 --> Loader Class Initialized
INFO - 2023-08-18 16:02:32 --> Helper loaded: url_helper
INFO - 2023-08-18 16:02:32 --> Helper loaded: file_helper
INFO - 2023-08-18 16:02:32 --> Helper loaded: html_helper
INFO - 2023-08-18 16:02:32 --> Helper loaded: text_helper
INFO - 2023-08-18 16:02:32 --> Helper loaded: form_helper
INFO - 2023-08-18 16:02:32 --> Helper loaded: lang_helper
INFO - 2023-08-18 16:02:32 --> Helper loaded: security_helper
INFO - 2023-08-18 16:02:32 --> Helper loaded: cookie_helper
INFO - 2023-08-18 16:02:32 --> Database Driver Class Initialized
INFO - 2023-08-18 16:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 16:02:32 --> Parser Class Initialized
INFO - 2023-08-18 16:02:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 16:02:32 --> Pagination Class Initialized
INFO - 2023-08-18 16:02:32 --> Form Validation Class Initialized
INFO - 2023-08-18 16:02:32 --> Controller Class Initialized
INFO - 2023-08-18 16:02:32 --> Model Class Initialized
DEBUG - 2023-08-18 16:02:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 16:02:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:02:32 --> Model Class Initialized
DEBUG - 2023-08-18 16:02:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:02:32 --> Model Class Initialized
INFO - 2023-08-18 16:02:32 --> Final output sent to browser
DEBUG - 2023-08-18 16:02:32 --> Total execution time: 0.0290
ERROR - 2023-08-18 16:02:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 16:02:34 --> Config Class Initialized
INFO - 2023-08-18 16:02:34 --> Hooks Class Initialized
DEBUG - 2023-08-18 16:02:34 --> UTF-8 Support Enabled
INFO - 2023-08-18 16:02:34 --> Utf8 Class Initialized
INFO - 2023-08-18 16:02:34 --> URI Class Initialized
INFO - 2023-08-18 16:02:34 --> Router Class Initialized
INFO - 2023-08-18 16:02:34 --> Output Class Initialized
INFO - 2023-08-18 16:02:34 --> Security Class Initialized
DEBUG - 2023-08-18 16:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 16:02:34 --> Input Class Initialized
INFO - 2023-08-18 16:02:34 --> Language Class Initialized
INFO - 2023-08-18 16:02:34 --> Loader Class Initialized
INFO - 2023-08-18 16:02:34 --> Helper loaded: url_helper
INFO - 2023-08-18 16:02:34 --> Helper loaded: file_helper
INFO - 2023-08-18 16:02:34 --> Helper loaded: html_helper
INFO - 2023-08-18 16:02:34 --> Helper loaded: text_helper
INFO - 2023-08-18 16:02:34 --> Helper loaded: form_helper
INFO - 2023-08-18 16:02:34 --> Helper loaded: lang_helper
INFO - 2023-08-18 16:02:34 --> Helper loaded: security_helper
INFO - 2023-08-18 16:02:34 --> Helper loaded: cookie_helper
INFO - 2023-08-18 16:02:34 --> Database Driver Class Initialized
INFO - 2023-08-18 16:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 16:02:34 --> Parser Class Initialized
INFO - 2023-08-18 16:02:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 16:02:34 --> Pagination Class Initialized
INFO - 2023-08-18 16:02:34 --> Form Validation Class Initialized
INFO - 2023-08-18 16:02:34 --> Controller Class Initialized
INFO - 2023-08-18 16:02:34 --> Model Class Initialized
DEBUG - 2023-08-18 16:02:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 16:02:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:02:34 --> Model Class Initialized
DEBUG - 2023-08-18 16:02:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:02:34 --> Model Class Initialized
INFO - 2023-08-18 16:02:34 --> Final output sent to browser
DEBUG - 2023-08-18 16:02:34 --> Total execution time: 0.0207
ERROR - 2023-08-18 16:02:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 16:02:48 --> Config Class Initialized
INFO - 2023-08-18 16:02:48 --> Hooks Class Initialized
DEBUG - 2023-08-18 16:02:48 --> UTF-8 Support Enabled
INFO - 2023-08-18 16:02:48 --> Utf8 Class Initialized
INFO - 2023-08-18 16:02:48 --> URI Class Initialized
INFO - 2023-08-18 16:02:48 --> Router Class Initialized
INFO - 2023-08-18 16:02:48 --> Output Class Initialized
INFO - 2023-08-18 16:02:48 --> Security Class Initialized
DEBUG - 2023-08-18 16:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 16:02:48 --> Input Class Initialized
INFO - 2023-08-18 16:02:48 --> Language Class Initialized
INFO - 2023-08-18 16:02:48 --> Loader Class Initialized
INFO - 2023-08-18 16:02:48 --> Helper loaded: url_helper
INFO - 2023-08-18 16:02:48 --> Helper loaded: file_helper
INFO - 2023-08-18 16:02:48 --> Helper loaded: html_helper
INFO - 2023-08-18 16:02:48 --> Helper loaded: text_helper
INFO - 2023-08-18 16:02:48 --> Helper loaded: form_helper
INFO - 2023-08-18 16:02:48 --> Helper loaded: lang_helper
INFO - 2023-08-18 16:02:48 --> Helper loaded: security_helper
INFO - 2023-08-18 16:02:48 --> Helper loaded: cookie_helper
INFO - 2023-08-18 16:02:48 --> Database Driver Class Initialized
INFO - 2023-08-18 16:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 16:02:48 --> Parser Class Initialized
INFO - 2023-08-18 16:02:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 16:02:48 --> Pagination Class Initialized
INFO - 2023-08-18 16:02:48 --> Form Validation Class Initialized
INFO - 2023-08-18 16:02:48 --> Controller Class Initialized
INFO - 2023-08-18 16:02:48 --> Model Class Initialized
DEBUG - 2023-08-18 16:02:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 16:02:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:02:48 --> Model Class Initialized
INFO - 2023-08-18 16:02:48 --> Model Class Initialized
INFO - 2023-08-18 16:02:48 --> Final output sent to browser
DEBUG - 2023-08-18 16:02:48 --> Total execution time: 0.0243
ERROR - 2023-08-18 16:02:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 16:02:52 --> Config Class Initialized
INFO - 2023-08-18 16:02:52 --> Hooks Class Initialized
DEBUG - 2023-08-18 16:02:52 --> UTF-8 Support Enabled
INFO - 2023-08-18 16:02:52 --> Utf8 Class Initialized
INFO - 2023-08-18 16:02:52 --> URI Class Initialized
INFO - 2023-08-18 16:02:52 --> Router Class Initialized
INFO - 2023-08-18 16:02:52 --> Output Class Initialized
INFO - 2023-08-18 16:02:52 --> Security Class Initialized
DEBUG - 2023-08-18 16:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 16:02:52 --> Input Class Initialized
INFO - 2023-08-18 16:02:52 --> Language Class Initialized
INFO - 2023-08-18 16:02:52 --> Loader Class Initialized
INFO - 2023-08-18 16:02:52 --> Helper loaded: url_helper
INFO - 2023-08-18 16:02:52 --> Helper loaded: file_helper
INFO - 2023-08-18 16:02:52 --> Helper loaded: html_helper
INFO - 2023-08-18 16:02:52 --> Helper loaded: text_helper
INFO - 2023-08-18 16:02:52 --> Helper loaded: form_helper
INFO - 2023-08-18 16:02:52 --> Helper loaded: lang_helper
INFO - 2023-08-18 16:02:52 --> Helper loaded: security_helper
INFO - 2023-08-18 16:02:52 --> Helper loaded: cookie_helper
INFO - 2023-08-18 16:02:52 --> Database Driver Class Initialized
INFO - 2023-08-18 16:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 16:02:52 --> Parser Class Initialized
INFO - 2023-08-18 16:02:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 16:02:52 --> Pagination Class Initialized
INFO - 2023-08-18 16:02:52 --> Form Validation Class Initialized
INFO - 2023-08-18 16:02:52 --> Controller Class Initialized
INFO - 2023-08-18 16:02:52 --> Model Class Initialized
DEBUG - 2023-08-18 16:02:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 16:02:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:02:52 --> Model Class Initialized
INFO - 2023-08-18 16:02:52 --> Final output sent to browser
DEBUG - 2023-08-18 16:02:52 --> Total execution time: 0.0176
ERROR - 2023-08-18 16:03:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 16:03:47 --> Config Class Initialized
INFO - 2023-08-18 16:03:47 --> Hooks Class Initialized
DEBUG - 2023-08-18 16:03:47 --> UTF-8 Support Enabled
INFO - 2023-08-18 16:03:47 --> Utf8 Class Initialized
INFO - 2023-08-18 16:03:47 --> URI Class Initialized
INFO - 2023-08-18 16:03:47 --> Router Class Initialized
INFO - 2023-08-18 16:03:47 --> Output Class Initialized
INFO - 2023-08-18 16:03:47 --> Security Class Initialized
DEBUG - 2023-08-18 16:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 16:03:47 --> Input Class Initialized
INFO - 2023-08-18 16:03:47 --> Language Class Initialized
INFO - 2023-08-18 16:03:47 --> Loader Class Initialized
INFO - 2023-08-18 16:03:47 --> Helper loaded: url_helper
INFO - 2023-08-18 16:03:47 --> Helper loaded: file_helper
INFO - 2023-08-18 16:03:47 --> Helper loaded: html_helper
INFO - 2023-08-18 16:03:47 --> Helper loaded: text_helper
INFO - 2023-08-18 16:03:47 --> Helper loaded: form_helper
INFO - 2023-08-18 16:03:47 --> Helper loaded: lang_helper
INFO - 2023-08-18 16:03:47 --> Helper loaded: security_helper
INFO - 2023-08-18 16:03:47 --> Helper loaded: cookie_helper
INFO - 2023-08-18 16:03:47 --> Database Driver Class Initialized
INFO - 2023-08-18 16:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 16:03:47 --> Parser Class Initialized
INFO - 2023-08-18 16:03:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 16:03:47 --> Pagination Class Initialized
INFO - 2023-08-18 16:03:47 --> Form Validation Class Initialized
INFO - 2023-08-18 16:03:47 --> Controller Class Initialized
INFO - 2023-08-18 16:03:47 --> Model Class Initialized
DEBUG - 2023-08-18 16:03:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 16:03:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:03:47 --> Model Class Initialized
DEBUG - 2023-08-18 16:03:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:03:47 --> Model Class Initialized
INFO - 2023-08-18 16:03:47 --> Final output sent to browser
DEBUG - 2023-08-18 16:03:47 --> Total execution time: 0.0561
ERROR - 2023-08-18 16:03:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 16:03:49 --> Config Class Initialized
INFO - 2023-08-18 16:03:49 --> Hooks Class Initialized
DEBUG - 2023-08-18 16:03:49 --> UTF-8 Support Enabled
INFO - 2023-08-18 16:03:49 --> Utf8 Class Initialized
INFO - 2023-08-18 16:03:49 --> URI Class Initialized
INFO - 2023-08-18 16:03:49 --> Router Class Initialized
INFO - 2023-08-18 16:03:49 --> Output Class Initialized
INFO - 2023-08-18 16:03:49 --> Security Class Initialized
DEBUG - 2023-08-18 16:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 16:03:49 --> Input Class Initialized
INFO - 2023-08-18 16:03:49 --> Language Class Initialized
INFO - 2023-08-18 16:03:49 --> Loader Class Initialized
INFO - 2023-08-18 16:03:49 --> Helper loaded: url_helper
INFO - 2023-08-18 16:03:49 --> Helper loaded: file_helper
INFO - 2023-08-18 16:03:49 --> Helper loaded: html_helper
INFO - 2023-08-18 16:03:49 --> Helper loaded: text_helper
INFO - 2023-08-18 16:03:49 --> Helper loaded: form_helper
INFO - 2023-08-18 16:03:49 --> Helper loaded: lang_helper
INFO - 2023-08-18 16:03:49 --> Helper loaded: security_helper
INFO - 2023-08-18 16:03:49 --> Helper loaded: cookie_helper
INFO - 2023-08-18 16:03:49 --> Database Driver Class Initialized
INFO - 2023-08-18 16:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 16:03:49 --> Parser Class Initialized
INFO - 2023-08-18 16:03:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 16:03:49 --> Pagination Class Initialized
INFO - 2023-08-18 16:03:49 --> Form Validation Class Initialized
INFO - 2023-08-18 16:03:49 --> Controller Class Initialized
INFO - 2023-08-18 16:03:49 --> Model Class Initialized
DEBUG - 2023-08-18 16:03:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 16:03:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:03:49 --> Model Class Initialized
DEBUG - 2023-08-18 16:03:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:03:49 --> Model Class Initialized
INFO - 2023-08-18 16:03:49 --> Final output sent to browser
DEBUG - 2023-08-18 16:03:49 --> Total execution time: 0.0553
ERROR - 2023-08-18 16:03:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 16:03:49 --> Config Class Initialized
INFO - 2023-08-18 16:03:49 --> Hooks Class Initialized
DEBUG - 2023-08-18 16:03:49 --> UTF-8 Support Enabled
INFO - 2023-08-18 16:03:49 --> Utf8 Class Initialized
INFO - 2023-08-18 16:03:49 --> URI Class Initialized
INFO - 2023-08-18 16:03:49 --> Router Class Initialized
INFO - 2023-08-18 16:03:49 --> Output Class Initialized
INFO - 2023-08-18 16:03:49 --> Security Class Initialized
DEBUG - 2023-08-18 16:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 16:03:49 --> Input Class Initialized
INFO - 2023-08-18 16:03:49 --> Language Class Initialized
INFO - 2023-08-18 16:03:49 --> Loader Class Initialized
INFO - 2023-08-18 16:03:49 --> Helper loaded: url_helper
INFO - 2023-08-18 16:03:49 --> Helper loaded: file_helper
INFO - 2023-08-18 16:03:49 --> Helper loaded: html_helper
INFO - 2023-08-18 16:03:49 --> Helper loaded: text_helper
INFO - 2023-08-18 16:03:49 --> Helper loaded: form_helper
INFO - 2023-08-18 16:03:49 --> Helper loaded: lang_helper
INFO - 2023-08-18 16:03:49 --> Helper loaded: security_helper
INFO - 2023-08-18 16:03:49 --> Helper loaded: cookie_helper
INFO - 2023-08-18 16:03:49 --> Database Driver Class Initialized
INFO - 2023-08-18 16:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 16:03:49 --> Parser Class Initialized
INFO - 2023-08-18 16:03:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 16:03:49 --> Pagination Class Initialized
INFO - 2023-08-18 16:03:49 --> Form Validation Class Initialized
INFO - 2023-08-18 16:03:49 --> Controller Class Initialized
INFO - 2023-08-18 16:03:49 --> Model Class Initialized
DEBUG - 2023-08-18 16:03:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 16:03:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:03:49 --> Model Class Initialized
DEBUG - 2023-08-18 16:03:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:03:49 --> Model Class Initialized
INFO - 2023-08-18 16:03:49 --> Final output sent to browser
DEBUG - 2023-08-18 16:03:49 --> Total execution time: 0.0562
ERROR - 2023-08-18 16:03:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 16:03:53 --> Config Class Initialized
INFO - 2023-08-18 16:03:53 --> Hooks Class Initialized
DEBUG - 2023-08-18 16:03:53 --> UTF-8 Support Enabled
INFO - 2023-08-18 16:03:53 --> Utf8 Class Initialized
INFO - 2023-08-18 16:03:53 --> URI Class Initialized
INFO - 2023-08-18 16:03:53 --> Router Class Initialized
INFO - 2023-08-18 16:03:53 --> Output Class Initialized
INFO - 2023-08-18 16:03:53 --> Security Class Initialized
DEBUG - 2023-08-18 16:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 16:03:53 --> Input Class Initialized
INFO - 2023-08-18 16:03:53 --> Language Class Initialized
INFO - 2023-08-18 16:03:53 --> Loader Class Initialized
INFO - 2023-08-18 16:03:53 --> Helper loaded: url_helper
INFO - 2023-08-18 16:03:53 --> Helper loaded: file_helper
INFO - 2023-08-18 16:03:53 --> Helper loaded: html_helper
INFO - 2023-08-18 16:03:53 --> Helper loaded: text_helper
INFO - 2023-08-18 16:03:53 --> Helper loaded: form_helper
INFO - 2023-08-18 16:03:53 --> Helper loaded: lang_helper
INFO - 2023-08-18 16:03:53 --> Helper loaded: security_helper
INFO - 2023-08-18 16:03:53 --> Helper loaded: cookie_helper
INFO - 2023-08-18 16:03:53 --> Database Driver Class Initialized
INFO - 2023-08-18 16:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 16:03:53 --> Parser Class Initialized
INFO - 2023-08-18 16:03:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 16:03:53 --> Pagination Class Initialized
INFO - 2023-08-18 16:03:53 --> Form Validation Class Initialized
INFO - 2023-08-18 16:03:53 --> Controller Class Initialized
INFO - 2023-08-18 16:03:53 --> Model Class Initialized
DEBUG - 2023-08-18 16:03:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 16:03:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:03:53 --> Model Class Initialized
DEBUG - 2023-08-18 16:03:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:03:53 --> Model Class Initialized
INFO - 2023-08-18 16:03:53 --> Final output sent to browser
DEBUG - 2023-08-18 16:03:53 --> Total execution time: 0.0288
ERROR - 2023-08-18 16:03:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 16:03:57 --> Config Class Initialized
INFO - 2023-08-18 16:03:57 --> Hooks Class Initialized
DEBUG - 2023-08-18 16:03:57 --> UTF-8 Support Enabled
INFO - 2023-08-18 16:03:57 --> Utf8 Class Initialized
INFO - 2023-08-18 16:03:57 --> URI Class Initialized
INFO - 2023-08-18 16:03:57 --> Router Class Initialized
INFO - 2023-08-18 16:03:57 --> Output Class Initialized
INFO - 2023-08-18 16:03:57 --> Security Class Initialized
DEBUG - 2023-08-18 16:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 16:03:57 --> Input Class Initialized
INFO - 2023-08-18 16:03:57 --> Language Class Initialized
INFO - 2023-08-18 16:03:57 --> Loader Class Initialized
INFO - 2023-08-18 16:03:57 --> Helper loaded: url_helper
INFO - 2023-08-18 16:03:57 --> Helper loaded: file_helper
INFO - 2023-08-18 16:03:57 --> Helper loaded: html_helper
INFO - 2023-08-18 16:03:57 --> Helper loaded: text_helper
INFO - 2023-08-18 16:03:57 --> Helper loaded: form_helper
INFO - 2023-08-18 16:03:57 --> Helper loaded: lang_helper
INFO - 2023-08-18 16:03:57 --> Helper loaded: security_helper
INFO - 2023-08-18 16:03:57 --> Helper loaded: cookie_helper
INFO - 2023-08-18 16:03:57 --> Database Driver Class Initialized
INFO - 2023-08-18 16:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 16:03:57 --> Parser Class Initialized
INFO - 2023-08-18 16:03:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 16:03:57 --> Pagination Class Initialized
INFO - 2023-08-18 16:03:57 --> Form Validation Class Initialized
INFO - 2023-08-18 16:03:57 --> Controller Class Initialized
INFO - 2023-08-18 16:03:57 --> Model Class Initialized
DEBUG - 2023-08-18 16:03:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 16:03:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:03:57 --> Model Class Initialized
INFO - 2023-08-18 16:03:57 --> Model Class Initialized
INFO - 2023-08-18 16:03:57 --> Final output sent to browser
DEBUG - 2023-08-18 16:03:57 --> Total execution time: 0.0192
ERROR - 2023-08-18 16:04:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 16:04:01 --> Config Class Initialized
INFO - 2023-08-18 16:04:01 --> Hooks Class Initialized
DEBUG - 2023-08-18 16:04:01 --> UTF-8 Support Enabled
INFO - 2023-08-18 16:04:01 --> Utf8 Class Initialized
INFO - 2023-08-18 16:04:01 --> URI Class Initialized
INFO - 2023-08-18 16:04:01 --> Router Class Initialized
INFO - 2023-08-18 16:04:01 --> Output Class Initialized
INFO - 2023-08-18 16:04:01 --> Security Class Initialized
DEBUG - 2023-08-18 16:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 16:04:01 --> Input Class Initialized
INFO - 2023-08-18 16:04:01 --> Language Class Initialized
INFO - 2023-08-18 16:04:01 --> Loader Class Initialized
INFO - 2023-08-18 16:04:01 --> Helper loaded: url_helper
INFO - 2023-08-18 16:04:01 --> Helper loaded: file_helper
INFO - 2023-08-18 16:04:01 --> Helper loaded: html_helper
INFO - 2023-08-18 16:04:01 --> Helper loaded: text_helper
INFO - 2023-08-18 16:04:01 --> Helper loaded: form_helper
INFO - 2023-08-18 16:04:01 --> Helper loaded: lang_helper
INFO - 2023-08-18 16:04:01 --> Helper loaded: security_helper
INFO - 2023-08-18 16:04:01 --> Helper loaded: cookie_helper
INFO - 2023-08-18 16:04:01 --> Database Driver Class Initialized
INFO - 2023-08-18 16:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 16:04:01 --> Parser Class Initialized
INFO - 2023-08-18 16:04:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 16:04:01 --> Pagination Class Initialized
INFO - 2023-08-18 16:04:01 --> Form Validation Class Initialized
INFO - 2023-08-18 16:04:01 --> Controller Class Initialized
INFO - 2023-08-18 16:04:01 --> Model Class Initialized
DEBUG - 2023-08-18 16:04:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 16:04:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:04:01 --> Model Class Initialized
INFO - 2023-08-18 16:04:01 --> Final output sent to browser
DEBUG - 2023-08-18 16:04:01 --> Total execution time: 0.0180
ERROR - 2023-08-18 16:05:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 16:05:18 --> Config Class Initialized
INFO - 2023-08-18 16:05:18 --> Hooks Class Initialized
DEBUG - 2023-08-18 16:05:18 --> UTF-8 Support Enabled
INFO - 2023-08-18 16:05:18 --> Utf8 Class Initialized
INFO - 2023-08-18 16:05:18 --> URI Class Initialized
INFO - 2023-08-18 16:05:18 --> Router Class Initialized
INFO - 2023-08-18 16:05:18 --> Output Class Initialized
INFO - 2023-08-18 16:05:18 --> Security Class Initialized
DEBUG - 2023-08-18 16:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 16:05:18 --> Input Class Initialized
INFO - 2023-08-18 16:05:18 --> Language Class Initialized
INFO - 2023-08-18 16:05:18 --> Loader Class Initialized
INFO - 2023-08-18 16:05:18 --> Helper loaded: url_helper
INFO - 2023-08-18 16:05:18 --> Helper loaded: file_helper
INFO - 2023-08-18 16:05:18 --> Helper loaded: html_helper
INFO - 2023-08-18 16:05:18 --> Helper loaded: text_helper
INFO - 2023-08-18 16:05:18 --> Helper loaded: form_helper
INFO - 2023-08-18 16:05:18 --> Helper loaded: lang_helper
INFO - 2023-08-18 16:05:18 --> Helper loaded: security_helper
INFO - 2023-08-18 16:05:18 --> Helper loaded: cookie_helper
INFO - 2023-08-18 16:05:18 --> Database Driver Class Initialized
INFO - 2023-08-18 16:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 16:05:18 --> Parser Class Initialized
INFO - 2023-08-18 16:05:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 16:05:18 --> Pagination Class Initialized
INFO - 2023-08-18 16:05:18 --> Form Validation Class Initialized
INFO - 2023-08-18 16:05:18 --> Controller Class Initialized
INFO - 2023-08-18 16:05:18 --> Model Class Initialized
DEBUG - 2023-08-18 16:05:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 16:05:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:05:18 --> Model Class Initialized
DEBUG - 2023-08-18 16:05:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:05:18 --> Model Class Initialized
INFO - 2023-08-18 16:05:18 --> Email Class Initialized
DEBUG - 2023-08-18 16:05:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:05:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-18 16:05:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2023-08-18 16:05:18 --> Language file loaded: language/english/email_lang.php
INFO - 2023-08-18 16:05:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2023-08-18 16:05:18 --> Final output sent to browser
DEBUG - 2023-08-18 16:05:18 --> Total execution time: 0.5566
ERROR - 2023-08-18 16:05:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 16:05:28 --> Config Class Initialized
INFO - 2023-08-18 16:05:28 --> Hooks Class Initialized
DEBUG - 2023-08-18 16:05:28 --> UTF-8 Support Enabled
INFO - 2023-08-18 16:05:28 --> Utf8 Class Initialized
INFO - 2023-08-18 16:05:28 --> URI Class Initialized
INFO - 2023-08-18 16:05:28 --> Router Class Initialized
INFO - 2023-08-18 16:05:28 --> Output Class Initialized
INFO - 2023-08-18 16:05:28 --> Security Class Initialized
DEBUG - 2023-08-18 16:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 16:05:28 --> Input Class Initialized
INFO - 2023-08-18 16:05:28 --> Language Class Initialized
INFO - 2023-08-18 16:05:28 --> Loader Class Initialized
INFO - 2023-08-18 16:05:28 --> Helper loaded: url_helper
INFO - 2023-08-18 16:05:28 --> Helper loaded: file_helper
INFO - 2023-08-18 16:05:28 --> Helper loaded: html_helper
INFO - 2023-08-18 16:05:28 --> Helper loaded: text_helper
INFO - 2023-08-18 16:05:28 --> Helper loaded: form_helper
INFO - 2023-08-18 16:05:28 --> Helper loaded: lang_helper
INFO - 2023-08-18 16:05:28 --> Helper loaded: security_helper
INFO - 2023-08-18 16:05:28 --> Helper loaded: cookie_helper
INFO - 2023-08-18 16:05:28 --> Database Driver Class Initialized
INFO - 2023-08-18 16:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 16:05:28 --> Parser Class Initialized
INFO - 2023-08-18 16:05:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 16:05:28 --> Pagination Class Initialized
INFO - 2023-08-18 16:05:28 --> Form Validation Class Initialized
INFO - 2023-08-18 16:05:28 --> Controller Class Initialized
INFO - 2023-08-18 16:05:28 --> Model Class Initialized
DEBUG - 2023-08-18 16:05:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-18 16:05:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:05:28 --> Model Class Initialized
DEBUG - 2023-08-18 16:05:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:05:28 --> Model Class Initialized
INFO - 2023-08-18 16:05:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_manual.php
DEBUG - 2023-08-18 16:05:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 16:05:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 16:05:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 16:05:28 --> Model Class Initialized
INFO - 2023-08-18 16:05:28 --> Model Class Initialized
INFO - 2023-08-18 16:05:28 --> Model Class Initialized
INFO - 2023-08-18 16:05:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-18 16:05:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-18 16:05:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 16:05:28 --> Final output sent to browser
DEBUG - 2023-08-18 16:05:28 --> Total execution time: 0.1082
ERROR - 2023-08-18 17:22:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 17:22:59 --> Config Class Initialized
INFO - 2023-08-18 17:22:59 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:22:59 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:22:59 --> Utf8 Class Initialized
INFO - 2023-08-18 17:22:59 --> URI Class Initialized
DEBUG - 2023-08-18 17:22:59 --> No URI present. Default controller set.
INFO - 2023-08-18 17:22:59 --> Router Class Initialized
INFO - 2023-08-18 17:22:59 --> Output Class Initialized
INFO - 2023-08-18 17:22:59 --> Security Class Initialized
DEBUG - 2023-08-18 17:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:22:59 --> Input Class Initialized
INFO - 2023-08-18 17:22:59 --> Language Class Initialized
INFO - 2023-08-18 17:22:59 --> Loader Class Initialized
INFO - 2023-08-18 17:22:59 --> Helper loaded: url_helper
INFO - 2023-08-18 17:22:59 --> Helper loaded: file_helper
INFO - 2023-08-18 17:22:59 --> Helper loaded: html_helper
INFO - 2023-08-18 17:22:59 --> Helper loaded: text_helper
INFO - 2023-08-18 17:22:59 --> Helper loaded: form_helper
INFO - 2023-08-18 17:22:59 --> Helper loaded: lang_helper
INFO - 2023-08-18 17:22:59 --> Helper loaded: security_helper
INFO - 2023-08-18 17:22:59 --> Helper loaded: cookie_helper
INFO - 2023-08-18 17:22:59 --> Database Driver Class Initialized
INFO - 2023-08-18 17:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:22:59 --> Parser Class Initialized
INFO - 2023-08-18 17:22:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 17:22:59 --> Pagination Class Initialized
INFO - 2023-08-18 17:22:59 --> Form Validation Class Initialized
INFO - 2023-08-18 17:22:59 --> Controller Class Initialized
INFO - 2023-08-18 17:22:59 --> Model Class Initialized
DEBUG - 2023-08-18 17:22:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-18 17:23:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 17:23:00 --> Config Class Initialized
INFO - 2023-08-18 17:23:00 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:23:00 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:23:00 --> Utf8 Class Initialized
INFO - 2023-08-18 17:23:00 --> URI Class Initialized
INFO - 2023-08-18 17:23:00 --> Router Class Initialized
INFO - 2023-08-18 17:23:00 --> Output Class Initialized
INFO - 2023-08-18 17:23:00 --> Security Class Initialized
DEBUG - 2023-08-18 17:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:23:00 --> Input Class Initialized
INFO - 2023-08-18 17:23:00 --> Language Class Initialized
INFO - 2023-08-18 17:23:00 --> Loader Class Initialized
INFO - 2023-08-18 17:23:00 --> Helper loaded: url_helper
INFO - 2023-08-18 17:23:00 --> Helper loaded: file_helper
INFO - 2023-08-18 17:23:00 --> Helper loaded: html_helper
INFO - 2023-08-18 17:23:00 --> Helper loaded: text_helper
INFO - 2023-08-18 17:23:00 --> Helper loaded: form_helper
INFO - 2023-08-18 17:23:00 --> Helper loaded: lang_helper
INFO - 2023-08-18 17:23:00 --> Helper loaded: security_helper
INFO - 2023-08-18 17:23:00 --> Helper loaded: cookie_helper
INFO - 2023-08-18 17:23:00 --> Database Driver Class Initialized
INFO - 2023-08-18 17:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:23:00 --> Parser Class Initialized
INFO - 2023-08-18 17:23:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 17:23:00 --> Pagination Class Initialized
INFO - 2023-08-18 17:23:00 --> Form Validation Class Initialized
INFO - 2023-08-18 17:23:00 --> Controller Class Initialized
INFO - 2023-08-18 17:23:00 --> Model Class Initialized
DEBUG - 2023-08-18 17:23:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 17:23:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-18 17:23:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 17:23:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 17:23:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 17:23:00 --> Model Class Initialized
INFO - 2023-08-18 17:23:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 17:23:00 --> Final output sent to browser
DEBUG - 2023-08-18 17:23:00 --> Total execution time: 0.0301
ERROR - 2023-08-18 17:23:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 17:23:15 --> Config Class Initialized
INFO - 2023-08-18 17:23:15 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:23:15 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:23:15 --> Utf8 Class Initialized
INFO - 2023-08-18 17:23:15 --> URI Class Initialized
INFO - 2023-08-18 17:23:15 --> Router Class Initialized
INFO - 2023-08-18 17:23:15 --> Output Class Initialized
INFO - 2023-08-18 17:23:15 --> Security Class Initialized
DEBUG - 2023-08-18 17:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:23:15 --> Input Class Initialized
INFO - 2023-08-18 17:23:15 --> Language Class Initialized
INFO - 2023-08-18 17:23:15 --> Loader Class Initialized
INFO - 2023-08-18 17:23:15 --> Helper loaded: url_helper
INFO - 2023-08-18 17:23:15 --> Helper loaded: file_helper
INFO - 2023-08-18 17:23:15 --> Helper loaded: html_helper
INFO - 2023-08-18 17:23:15 --> Helper loaded: text_helper
INFO - 2023-08-18 17:23:15 --> Helper loaded: form_helper
INFO - 2023-08-18 17:23:15 --> Helper loaded: lang_helper
INFO - 2023-08-18 17:23:15 --> Helper loaded: security_helper
INFO - 2023-08-18 17:23:15 --> Helper loaded: cookie_helper
INFO - 2023-08-18 17:23:15 --> Database Driver Class Initialized
INFO - 2023-08-18 17:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:23:15 --> Parser Class Initialized
INFO - 2023-08-18 17:23:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 17:23:15 --> Pagination Class Initialized
INFO - 2023-08-18 17:23:15 --> Form Validation Class Initialized
INFO - 2023-08-18 17:23:15 --> Controller Class Initialized
INFO - 2023-08-18 17:23:15 --> Model Class Initialized
DEBUG - 2023-08-18 17:23:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 17:23:15 --> Model Class Initialized
INFO - 2023-08-18 17:23:15 --> Final output sent to browser
DEBUG - 2023-08-18 17:23:15 --> Total execution time: 0.0213
ERROR - 2023-08-18 17:23:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 17:23:15 --> Config Class Initialized
INFO - 2023-08-18 17:23:15 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:23:15 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:23:15 --> Utf8 Class Initialized
INFO - 2023-08-18 17:23:15 --> URI Class Initialized
INFO - 2023-08-18 17:23:15 --> Router Class Initialized
INFO - 2023-08-18 17:23:15 --> Output Class Initialized
INFO - 2023-08-18 17:23:15 --> Security Class Initialized
DEBUG - 2023-08-18 17:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:23:15 --> Input Class Initialized
INFO - 2023-08-18 17:23:15 --> Language Class Initialized
INFO - 2023-08-18 17:23:15 --> Loader Class Initialized
INFO - 2023-08-18 17:23:15 --> Helper loaded: url_helper
INFO - 2023-08-18 17:23:15 --> Helper loaded: file_helper
INFO - 2023-08-18 17:23:15 --> Helper loaded: html_helper
INFO - 2023-08-18 17:23:15 --> Helper loaded: text_helper
INFO - 2023-08-18 17:23:15 --> Helper loaded: form_helper
INFO - 2023-08-18 17:23:15 --> Helper loaded: lang_helper
INFO - 2023-08-18 17:23:15 --> Helper loaded: security_helper
INFO - 2023-08-18 17:23:15 --> Helper loaded: cookie_helper
INFO - 2023-08-18 17:23:15 --> Database Driver Class Initialized
INFO - 2023-08-18 17:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:23:15 --> Parser Class Initialized
INFO - 2023-08-18 17:23:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 17:23:15 --> Pagination Class Initialized
INFO - 2023-08-18 17:23:15 --> Form Validation Class Initialized
INFO - 2023-08-18 17:23:15 --> Controller Class Initialized
INFO - 2023-08-18 17:23:15 --> Model Class Initialized
DEBUG - 2023-08-18 17:23:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 17:23:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-18 17:23:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 17:23:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 17:23:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 17:23:15 --> Model Class Initialized
INFO - 2023-08-18 17:23:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 17:23:15 --> Final output sent to browser
DEBUG - 2023-08-18 17:23:15 --> Total execution time: 0.0294
ERROR - 2023-08-18 17:23:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 17:23:37 --> Config Class Initialized
INFO - 2023-08-18 17:23:37 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:23:37 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:23:37 --> Utf8 Class Initialized
INFO - 2023-08-18 17:23:37 --> URI Class Initialized
INFO - 2023-08-18 17:23:37 --> Router Class Initialized
INFO - 2023-08-18 17:23:37 --> Output Class Initialized
INFO - 2023-08-18 17:23:37 --> Security Class Initialized
DEBUG - 2023-08-18 17:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:23:37 --> Input Class Initialized
INFO - 2023-08-18 17:23:37 --> Language Class Initialized
INFO - 2023-08-18 17:23:37 --> Loader Class Initialized
INFO - 2023-08-18 17:23:37 --> Helper loaded: url_helper
INFO - 2023-08-18 17:23:37 --> Helper loaded: file_helper
INFO - 2023-08-18 17:23:37 --> Helper loaded: html_helper
INFO - 2023-08-18 17:23:37 --> Helper loaded: text_helper
INFO - 2023-08-18 17:23:37 --> Helper loaded: form_helper
INFO - 2023-08-18 17:23:37 --> Helper loaded: lang_helper
INFO - 2023-08-18 17:23:37 --> Helper loaded: security_helper
INFO - 2023-08-18 17:23:37 --> Helper loaded: cookie_helper
INFO - 2023-08-18 17:23:37 --> Database Driver Class Initialized
INFO - 2023-08-18 17:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:23:37 --> Parser Class Initialized
INFO - 2023-08-18 17:23:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 17:23:37 --> Pagination Class Initialized
INFO - 2023-08-18 17:23:37 --> Form Validation Class Initialized
INFO - 2023-08-18 17:23:37 --> Controller Class Initialized
INFO - 2023-08-18 17:23:37 --> Model Class Initialized
DEBUG - 2023-08-18 17:23:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 17:23:37 --> Model Class Initialized
INFO - 2023-08-18 17:23:37 --> Final output sent to browser
DEBUG - 2023-08-18 17:23:37 --> Total execution time: 0.0204
ERROR - 2023-08-18 17:23:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 17:23:37 --> Config Class Initialized
INFO - 2023-08-18 17:23:37 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:23:37 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:23:37 --> Utf8 Class Initialized
INFO - 2023-08-18 17:23:37 --> URI Class Initialized
INFO - 2023-08-18 17:23:37 --> Router Class Initialized
INFO - 2023-08-18 17:23:37 --> Output Class Initialized
INFO - 2023-08-18 17:23:37 --> Security Class Initialized
DEBUG - 2023-08-18 17:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:23:37 --> Input Class Initialized
INFO - 2023-08-18 17:23:37 --> Language Class Initialized
INFO - 2023-08-18 17:23:37 --> Loader Class Initialized
INFO - 2023-08-18 17:23:37 --> Helper loaded: url_helper
INFO - 2023-08-18 17:23:37 --> Helper loaded: file_helper
INFO - 2023-08-18 17:23:37 --> Helper loaded: html_helper
INFO - 2023-08-18 17:23:37 --> Helper loaded: text_helper
INFO - 2023-08-18 17:23:37 --> Helper loaded: form_helper
INFO - 2023-08-18 17:23:37 --> Helper loaded: lang_helper
INFO - 2023-08-18 17:23:37 --> Helper loaded: security_helper
INFO - 2023-08-18 17:23:37 --> Helper loaded: cookie_helper
INFO - 2023-08-18 17:23:37 --> Database Driver Class Initialized
INFO - 2023-08-18 17:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:23:37 --> Parser Class Initialized
INFO - 2023-08-18 17:23:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 17:23:37 --> Pagination Class Initialized
INFO - 2023-08-18 17:23:37 --> Form Validation Class Initialized
INFO - 2023-08-18 17:23:37 --> Controller Class Initialized
INFO - 2023-08-18 17:23:37 --> Model Class Initialized
DEBUG - 2023-08-18 17:23:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 17:23:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-18 17:23:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 17:23:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 17:23:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 17:23:37 --> Model Class Initialized
INFO - 2023-08-18 17:23:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 17:23:37 --> Final output sent to browser
DEBUG - 2023-08-18 17:23:37 --> Total execution time: 0.0369
ERROR - 2023-08-18 17:24:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 17:24:36 --> Config Class Initialized
INFO - 2023-08-18 17:24:36 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:24:36 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:24:36 --> Utf8 Class Initialized
INFO - 2023-08-18 17:24:36 --> URI Class Initialized
INFO - 2023-08-18 17:24:36 --> Router Class Initialized
INFO - 2023-08-18 17:24:36 --> Output Class Initialized
INFO - 2023-08-18 17:24:36 --> Security Class Initialized
DEBUG - 2023-08-18 17:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:24:36 --> Input Class Initialized
INFO - 2023-08-18 17:24:36 --> Language Class Initialized
INFO - 2023-08-18 17:24:36 --> Loader Class Initialized
INFO - 2023-08-18 17:24:36 --> Helper loaded: url_helper
INFO - 2023-08-18 17:24:36 --> Helper loaded: file_helper
INFO - 2023-08-18 17:24:36 --> Helper loaded: html_helper
INFO - 2023-08-18 17:24:36 --> Helper loaded: text_helper
INFO - 2023-08-18 17:24:36 --> Helper loaded: form_helper
INFO - 2023-08-18 17:24:36 --> Helper loaded: lang_helper
INFO - 2023-08-18 17:24:36 --> Helper loaded: security_helper
INFO - 2023-08-18 17:24:36 --> Helper loaded: cookie_helper
INFO - 2023-08-18 17:24:36 --> Database Driver Class Initialized
INFO - 2023-08-18 17:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:24:36 --> Parser Class Initialized
INFO - 2023-08-18 17:24:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 17:24:36 --> Pagination Class Initialized
INFO - 2023-08-18 17:24:36 --> Form Validation Class Initialized
INFO - 2023-08-18 17:24:36 --> Controller Class Initialized
INFO - 2023-08-18 17:24:36 --> Model Class Initialized
DEBUG - 2023-08-18 17:24:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 17:24:36 --> Model Class Initialized
INFO - 2023-08-18 17:24:36 --> Final output sent to browser
DEBUG - 2023-08-18 17:24:36 --> Total execution time: 0.0238
ERROR - 2023-08-18 17:24:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 17:24:37 --> Config Class Initialized
INFO - 2023-08-18 17:24:37 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:24:37 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:24:37 --> Utf8 Class Initialized
INFO - 2023-08-18 17:24:37 --> URI Class Initialized
INFO - 2023-08-18 17:24:37 --> Router Class Initialized
INFO - 2023-08-18 17:24:37 --> Output Class Initialized
INFO - 2023-08-18 17:24:37 --> Security Class Initialized
DEBUG - 2023-08-18 17:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:24:37 --> Input Class Initialized
INFO - 2023-08-18 17:24:37 --> Language Class Initialized
INFO - 2023-08-18 17:24:37 --> Loader Class Initialized
INFO - 2023-08-18 17:24:37 --> Helper loaded: url_helper
INFO - 2023-08-18 17:24:37 --> Helper loaded: file_helper
INFO - 2023-08-18 17:24:37 --> Helper loaded: html_helper
INFO - 2023-08-18 17:24:37 --> Helper loaded: text_helper
INFO - 2023-08-18 17:24:37 --> Helper loaded: form_helper
INFO - 2023-08-18 17:24:37 --> Helper loaded: lang_helper
INFO - 2023-08-18 17:24:37 --> Helper loaded: security_helper
INFO - 2023-08-18 17:24:37 --> Helper loaded: cookie_helper
INFO - 2023-08-18 17:24:37 --> Database Driver Class Initialized
INFO - 2023-08-18 17:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:24:37 --> Parser Class Initialized
INFO - 2023-08-18 17:24:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 17:24:37 --> Pagination Class Initialized
INFO - 2023-08-18 17:24:37 --> Form Validation Class Initialized
INFO - 2023-08-18 17:24:37 --> Controller Class Initialized
INFO - 2023-08-18 17:24:37 --> Model Class Initialized
DEBUG - 2023-08-18 17:24:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 17:24:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-18 17:24:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 17:24:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 17:24:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 17:24:37 --> Model Class Initialized
INFO - 2023-08-18 17:24:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 17:24:37 --> Final output sent to browser
DEBUG - 2023-08-18 17:24:37 --> Total execution time: 0.0291
ERROR - 2023-08-18 17:24:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 17:24:39 --> Config Class Initialized
INFO - 2023-08-18 17:24:39 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:24:39 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:24:39 --> Utf8 Class Initialized
INFO - 2023-08-18 17:24:39 --> URI Class Initialized
INFO - 2023-08-18 17:24:39 --> Router Class Initialized
INFO - 2023-08-18 17:24:39 --> Output Class Initialized
INFO - 2023-08-18 17:24:39 --> Security Class Initialized
DEBUG - 2023-08-18 17:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:24:39 --> Input Class Initialized
INFO - 2023-08-18 17:24:39 --> Language Class Initialized
INFO - 2023-08-18 17:24:39 --> Loader Class Initialized
INFO - 2023-08-18 17:24:39 --> Helper loaded: url_helper
INFO - 2023-08-18 17:24:39 --> Helper loaded: file_helper
INFO - 2023-08-18 17:24:39 --> Helper loaded: html_helper
INFO - 2023-08-18 17:24:39 --> Helper loaded: text_helper
INFO - 2023-08-18 17:24:39 --> Helper loaded: form_helper
INFO - 2023-08-18 17:24:39 --> Helper loaded: lang_helper
INFO - 2023-08-18 17:24:39 --> Helper loaded: security_helper
INFO - 2023-08-18 17:24:39 --> Helper loaded: cookie_helper
INFO - 2023-08-18 17:24:39 --> Database Driver Class Initialized
INFO - 2023-08-18 17:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:24:39 --> Parser Class Initialized
INFO - 2023-08-18 17:24:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 17:24:39 --> Pagination Class Initialized
INFO - 2023-08-18 17:24:39 --> Form Validation Class Initialized
INFO - 2023-08-18 17:24:39 --> Controller Class Initialized
INFO - 2023-08-18 17:24:39 --> Model Class Initialized
DEBUG - 2023-08-18 17:24:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 17:24:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-18 17:24:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 17:24:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 17:24:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 17:24:39 --> Model Class Initialized
INFO - 2023-08-18 17:24:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 17:24:39 --> Final output sent to browser
DEBUG - 2023-08-18 17:24:39 --> Total execution time: 0.0270
ERROR - 2023-08-18 17:25:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 17:25:09 --> Config Class Initialized
INFO - 2023-08-18 17:25:09 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:25:09 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:25:09 --> Utf8 Class Initialized
INFO - 2023-08-18 17:25:09 --> URI Class Initialized
INFO - 2023-08-18 17:25:09 --> Router Class Initialized
INFO - 2023-08-18 17:25:09 --> Output Class Initialized
INFO - 2023-08-18 17:25:09 --> Security Class Initialized
DEBUG - 2023-08-18 17:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:25:09 --> Input Class Initialized
INFO - 2023-08-18 17:25:09 --> Language Class Initialized
INFO - 2023-08-18 17:25:09 --> Loader Class Initialized
INFO - 2023-08-18 17:25:09 --> Helper loaded: url_helper
INFO - 2023-08-18 17:25:09 --> Helper loaded: file_helper
INFO - 2023-08-18 17:25:09 --> Helper loaded: html_helper
INFO - 2023-08-18 17:25:09 --> Helper loaded: text_helper
INFO - 2023-08-18 17:25:09 --> Helper loaded: form_helper
INFO - 2023-08-18 17:25:09 --> Helper loaded: lang_helper
INFO - 2023-08-18 17:25:09 --> Helper loaded: security_helper
INFO - 2023-08-18 17:25:09 --> Helper loaded: cookie_helper
INFO - 2023-08-18 17:25:09 --> Database Driver Class Initialized
INFO - 2023-08-18 17:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:25:09 --> Parser Class Initialized
INFO - 2023-08-18 17:25:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 17:25:09 --> Pagination Class Initialized
INFO - 2023-08-18 17:25:09 --> Form Validation Class Initialized
INFO - 2023-08-18 17:25:09 --> Controller Class Initialized
INFO - 2023-08-18 17:25:09 --> Model Class Initialized
DEBUG - 2023-08-18 17:25:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 17:25:09 --> Model Class Initialized
INFO - 2023-08-18 17:25:09 --> Final output sent to browser
DEBUG - 2023-08-18 17:25:09 --> Total execution time: 0.0203
ERROR - 2023-08-18 17:25:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 17:25:10 --> Config Class Initialized
INFO - 2023-08-18 17:25:10 --> Hooks Class Initialized
DEBUG - 2023-08-18 17:25:10 --> UTF-8 Support Enabled
INFO - 2023-08-18 17:25:10 --> Utf8 Class Initialized
INFO - 2023-08-18 17:25:10 --> URI Class Initialized
INFO - 2023-08-18 17:25:10 --> Router Class Initialized
INFO - 2023-08-18 17:25:10 --> Output Class Initialized
INFO - 2023-08-18 17:25:10 --> Security Class Initialized
DEBUG - 2023-08-18 17:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 17:25:10 --> Input Class Initialized
INFO - 2023-08-18 17:25:10 --> Language Class Initialized
INFO - 2023-08-18 17:25:10 --> Loader Class Initialized
INFO - 2023-08-18 17:25:10 --> Helper loaded: url_helper
INFO - 2023-08-18 17:25:10 --> Helper loaded: file_helper
INFO - 2023-08-18 17:25:10 --> Helper loaded: html_helper
INFO - 2023-08-18 17:25:10 --> Helper loaded: text_helper
INFO - 2023-08-18 17:25:10 --> Helper loaded: form_helper
INFO - 2023-08-18 17:25:10 --> Helper loaded: lang_helper
INFO - 2023-08-18 17:25:10 --> Helper loaded: security_helper
INFO - 2023-08-18 17:25:10 --> Helper loaded: cookie_helper
INFO - 2023-08-18 17:25:10 --> Database Driver Class Initialized
INFO - 2023-08-18 17:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 17:25:10 --> Parser Class Initialized
INFO - 2023-08-18 17:25:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 17:25:10 --> Pagination Class Initialized
INFO - 2023-08-18 17:25:10 --> Form Validation Class Initialized
INFO - 2023-08-18 17:25:10 --> Controller Class Initialized
INFO - 2023-08-18 17:25:10 --> Model Class Initialized
DEBUG - 2023-08-18 17:25:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-18 17:25:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-18 17:25:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-18 17:25:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-18 17:25:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-18 17:25:10 --> Model Class Initialized
INFO - 2023-08-18 17:25:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-18 17:25:10 --> Final output sent to browser
DEBUG - 2023-08-18 17:25:10 --> Total execution time: 0.0321
ERROR - 2023-08-18 21:21:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-18 21:21:33 --> Config Class Initialized
INFO - 2023-08-18 21:21:33 --> Hooks Class Initialized
DEBUG - 2023-08-18 21:21:33 --> UTF-8 Support Enabled
INFO - 2023-08-18 21:21:33 --> Utf8 Class Initialized
INFO - 2023-08-18 21:21:33 --> URI Class Initialized
DEBUG - 2023-08-18 21:21:33 --> No URI present. Default controller set.
INFO - 2023-08-18 21:21:33 --> Router Class Initialized
INFO - 2023-08-18 21:21:33 --> Output Class Initialized
INFO - 2023-08-18 21:21:33 --> Security Class Initialized
DEBUG - 2023-08-18 21:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 21:21:33 --> Input Class Initialized
INFO - 2023-08-18 21:21:33 --> Language Class Initialized
INFO - 2023-08-18 21:21:33 --> Loader Class Initialized
INFO - 2023-08-18 21:21:33 --> Helper loaded: url_helper
INFO - 2023-08-18 21:21:33 --> Helper loaded: file_helper
INFO - 2023-08-18 21:21:33 --> Helper loaded: html_helper
INFO - 2023-08-18 21:21:33 --> Helper loaded: text_helper
INFO - 2023-08-18 21:21:33 --> Helper loaded: form_helper
INFO - 2023-08-18 21:21:33 --> Helper loaded: lang_helper
INFO - 2023-08-18 21:21:33 --> Helper loaded: security_helper
INFO - 2023-08-18 21:21:33 --> Helper loaded: cookie_helper
INFO - 2023-08-18 21:21:33 --> Database Driver Class Initialized
INFO - 2023-08-18 21:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 21:21:33 --> Parser Class Initialized
INFO - 2023-08-18 21:21:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-18 21:21:33 --> Pagination Class Initialized
INFO - 2023-08-18 21:21:33 --> Form Validation Class Initialized
INFO - 2023-08-18 21:21:33 --> Controller Class Initialized
INFO - 2023-08-18 21:21:33 --> Model Class Initialized
DEBUG - 2023-08-18 21:21:33 --> Session class already loaded. Second attempt ignored.
