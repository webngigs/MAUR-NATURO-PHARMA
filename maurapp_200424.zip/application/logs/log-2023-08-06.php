<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-06 06:22:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 06:22:59 --> Config Class Initialized
INFO - 2023-08-06 06:22:59 --> Hooks Class Initialized
DEBUG - 2023-08-06 06:22:59 --> UTF-8 Support Enabled
INFO - 2023-08-06 06:22:59 --> Utf8 Class Initialized
INFO - 2023-08-06 06:22:59 --> URI Class Initialized
DEBUG - 2023-08-06 06:22:59 --> No URI present. Default controller set.
INFO - 2023-08-06 06:22:59 --> Router Class Initialized
INFO - 2023-08-06 06:22:59 --> Output Class Initialized
INFO - 2023-08-06 06:22:59 --> Security Class Initialized
DEBUG - 2023-08-06 06:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 06:22:59 --> Input Class Initialized
INFO - 2023-08-06 06:22:59 --> Language Class Initialized
INFO - 2023-08-06 06:22:59 --> Loader Class Initialized
INFO - 2023-08-06 06:22:59 --> Helper loaded: url_helper
INFO - 2023-08-06 06:22:59 --> Helper loaded: file_helper
INFO - 2023-08-06 06:22:59 --> Helper loaded: html_helper
INFO - 2023-08-06 06:22:59 --> Helper loaded: text_helper
INFO - 2023-08-06 06:22:59 --> Helper loaded: form_helper
INFO - 2023-08-06 06:22:59 --> Helper loaded: lang_helper
INFO - 2023-08-06 06:22:59 --> Helper loaded: security_helper
INFO - 2023-08-06 06:22:59 --> Helper loaded: cookie_helper
INFO - 2023-08-06 06:22:59 --> Database Driver Class Initialized
INFO - 2023-08-06 06:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 06:22:59 --> Parser Class Initialized
INFO - 2023-08-06 06:22:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 06:22:59 --> Pagination Class Initialized
INFO - 2023-08-06 06:22:59 --> Form Validation Class Initialized
INFO - 2023-08-06 06:22:59 --> Controller Class Initialized
INFO - 2023-08-06 06:22:59 --> Model Class Initialized
DEBUG - 2023-08-06 06:22:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-06 06:23:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 06:23:00 --> Config Class Initialized
INFO - 2023-08-06 06:23:00 --> Hooks Class Initialized
DEBUG - 2023-08-06 06:23:00 --> UTF-8 Support Enabled
INFO - 2023-08-06 06:23:00 --> Utf8 Class Initialized
INFO - 2023-08-06 06:23:00 --> URI Class Initialized
INFO - 2023-08-06 06:23:00 --> Router Class Initialized
INFO - 2023-08-06 06:23:00 --> Output Class Initialized
INFO - 2023-08-06 06:23:00 --> Security Class Initialized
DEBUG - 2023-08-06 06:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 06:23:00 --> Input Class Initialized
INFO - 2023-08-06 06:23:00 --> Language Class Initialized
INFO - 2023-08-06 06:23:00 --> Loader Class Initialized
INFO - 2023-08-06 06:23:00 --> Helper loaded: url_helper
INFO - 2023-08-06 06:23:00 --> Helper loaded: file_helper
INFO - 2023-08-06 06:23:00 --> Helper loaded: html_helper
INFO - 2023-08-06 06:23:00 --> Helper loaded: text_helper
INFO - 2023-08-06 06:23:00 --> Helper loaded: form_helper
INFO - 2023-08-06 06:23:00 --> Helper loaded: lang_helper
INFO - 2023-08-06 06:23:00 --> Helper loaded: security_helper
INFO - 2023-08-06 06:23:00 --> Helper loaded: cookie_helper
INFO - 2023-08-06 06:23:00 --> Database Driver Class Initialized
INFO - 2023-08-06 06:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 06:23:00 --> Parser Class Initialized
INFO - 2023-08-06 06:23:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 06:23:00 --> Pagination Class Initialized
INFO - 2023-08-06 06:23:00 --> Form Validation Class Initialized
INFO - 2023-08-06 06:23:00 --> Controller Class Initialized
INFO - 2023-08-06 06:23:00 --> Model Class Initialized
DEBUG - 2023-08-06 06:23:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:23:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-06 06:23:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:23:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 06:23:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 06:23:00 --> Model Class Initialized
INFO - 2023-08-06 06:23:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 06:23:00 --> Final output sent to browser
DEBUG - 2023-08-06 06:23:00 --> Total execution time: 0.0311
ERROR - 2023-08-06 06:23:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 06:23:11 --> Config Class Initialized
INFO - 2023-08-06 06:23:11 --> Hooks Class Initialized
DEBUG - 2023-08-06 06:23:11 --> UTF-8 Support Enabled
INFO - 2023-08-06 06:23:11 --> Utf8 Class Initialized
INFO - 2023-08-06 06:23:11 --> URI Class Initialized
DEBUG - 2023-08-06 06:23:11 --> No URI present. Default controller set.
INFO - 2023-08-06 06:23:11 --> Router Class Initialized
INFO - 2023-08-06 06:23:11 --> Output Class Initialized
INFO - 2023-08-06 06:23:11 --> Security Class Initialized
DEBUG - 2023-08-06 06:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 06:23:11 --> Input Class Initialized
INFO - 2023-08-06 06:23:11 --> Language Class Initialized
INFO - 2023-08-06 06:23:11 --> Loader Class Initialized
INFO - 2023-08-06 06:23:11 --> Helper loaded: url_helper
INFO - 2023-08-06 06:23:11 --> Helper loaded: file_helper
INFO - 2023-08-06 06:23:11 --> Helper loaded: html_helper
INFO - 2023-08-06 06:23:11 --> Helper loaded: text_helper
INFO - 2023-08-06 06:23:11 --> Helper loaded: form_helper
INFO - 2023-08-06 06:23:11 --> Helper loaded: lang_helper
INFO - 2023-08-06 06:23:11 --> Helper loaded: security_helper
INFO - 2023-08-06 06:23:11 --> Helper loaded: cookie_helper
INFO - 2023-08-06 06:23:11 --> Database Driver Class Initialized
INFO - 2023-08-06 06:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 06:23:11 --> Parser Class Initialized
INFO - 2023-08-06 06:23:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 06:23:11 --> Pagination Class Initialized
INFO - 2023-08-06 06:23:11 --> Form Validation Class Initialized
INFO - 2023-08-06 06:23:11 --> Controller Class Initialized
INFO - 2023-08-06 06:23:11 --> Model Class Initialized
DEBUG - 2023-08-06 06:23:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-06 06:23:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 06:23:11 --> Config Class Initialized
INFO - 2023-08-06 06:23:11 --> Hooks Class Initialized
DEBUG - 2023-08-06 06:23:11 --> UTF-8 Support Enabled
INFO - 2023-08-06 06:23:11 --> Utf8 Class Initialized
INFO - 2023-08-06 06:23:11 --> URI Class Initialized
INFO - 2023-08-06 06:23:11 --> Router Class Initialized
INFO - 2023-08-06 06:23:11 --> Output Class Initialized
INFO - 2023-08-06 06:23:11 --> Security Class Initialized
DEBUG - 2023-08-06 06:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 06:23:11 --> Input Class Initialized
INFO - 2023-08-06 06:23:11 --> Language Class Initialized
INFO - 2023-08-06 06:23:11 --> Loader Class Initialized
INFO - 2023-08-06 06:23:11 --> Helper loaded: url_helper
INFO - 2023-08-06 06:23:11 --> Helper loaded: file_helper
INFO - 2023-08-06 06:23:11 --> Helper loaded: html_helper
INFO - 2023-08-06 06:23:11 --> Helper loaded: text_helper
INFO - 2023-08-06 06:23:11 --> Helper loaded: form_helper
INFO - 2023-08-06 06:23:11 --> Helper loaded: lang_helper
INFO - 2023-08-06 06:23:11 --> Helper loaded: security_helper
INFO - 2023-08-06 06:23:11 --> Helper loaded: cookie_helper
INFO - 2023-08-06 06:23:11 --> Database Driver Class Initialized
INFO - 2023-08-06 06:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 06:23:11 --> Parser Class Initialized
INFO - 2023-08-06 06:23:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 06:23:11 --> Pagination Class Initialized
INFO - 2023-08-06 06:23:11 --> Form Validation Class Initialized
INFO - 2023-08-06 06:23:11 --> Controller Class Initialized
INFO - 2023-08-06 06:23:11 --> Model Class Initialized
DEBUG - 2023-08-06 06:23:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:23:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-06 06:23:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:23:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 06:23:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 06:23:11 --> Model Class Initialized
INFO - 2023-08-06 06:23:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 06:23:11 --> Final output sent to browser
DEBUG - 2023-08-06 06:23:11 --> Total execution time: 0.0343
ERROR - 2023-08-06 06:23:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 06:23:15 --> Config Class Initialized
INFO - 2023-08-06 06:23:15 --> Hooks Class Initialized
DEBUG - 2023-08-06 06:23:15 --> UTF-8 Support Enabled
INFO - 2023-08-06 06:23:15 --> Utf8 Class Initialized
INFO - 2023-08-06 06:23:15 --> URI Class Initialized
INFO - 2023-08-06 06:23:15 --> Router Class Initialized
INFO - 2023-08-06 06:23:15 --> Output Class Initialized
INFO - 2023-08-06 06:23:15 --> Security Class Initialized
DEBUG - 2023-08-06 06:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 06:23:15 --> Input Class Initialized
INFO - 2023-08-06 06:23:15 --> Language Class Initialized
INFO - 2023-08-06 06:23:15 --> Loader Class Initialized
INFO - 2023-08-06 06:23:15 --> Helper loaded: url_helper
INFO - 2023-08-06 06:23:15 --> Helper loaded: file_helper
INFO - 2023-08-06 06:23:15 --> Helper loaded: html_helper
INFO - 2023-08-06 06:23:15 --> Helper loaded: text_helper
INFO - 2023-08-06 06:23:15 --> Helper loaded: form_helper
INFO - 2023-08-06 06:23:15 --> Helper loaded: lang_helper
INFO - 2023-08-06 06:23:15 --> Helper loaded: security_helper
INFO - 2023-08-06 06:23:15 --> Helper loaded: cookie_helper
INFO - 2023-08-06 06:23:15 --> Database Driver Class Initialized
INFO - 2023-08-06 06:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 06:23:15 --> Parser Class Initialized
INFO - 2023-08-06 06:23:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 06:23:15 --> Pagination Class Initialized
INFO - 2023-08-06 06:23:15 --> Form Validation Class Initialized
INFO - 2023-08-06 06:23:15 --> Controller Class Initialized
INFO - 2023-08-06 06:23:15 --> Model Class Initialized
DEBUG - 2023-08-06 06:23:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:23:15 --> Model Class Initialized
INFO - 2023-08-06 06:23:15 --> Final output sent to browser
DEBUG - 2023-08-06 06:23:15 --> Total execution time: 0.0181
ERROR - 2023-08-06 06:23:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 06:23:15 --> Config Class Initialized
INFO - 2023-08-06 06:23:15 --> Hooks Class Initialized
DEBUG - 2023-08-06 06:23:15 --> UTF-8 Support Enabled
INFO - 2023-08-06 06:23:15 --> Utf8 Class Initialized
INFO - 2023-08-06 06:23:15 --> URI Class Initialized
DEBUG - 2023-08-06 06:23:15 --> No URI present. Default controller set.
INFO - 2023-08-06 06:23:15 --> Router Class Initialized
INFO - 2023-08-06 06:23:15 --> Output Class Initialized
INFO - 2023-08-06 06:23:15 --> Security Class Initialized
DEBUG - 2023-08-06 06:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 06:23:15 --> Input Class Initialized
INFO - 2023-08-06 06:23:15 --> Language Class Initialized
INFO - 2023-08-06 06:23:15 --> Loader Class Initialized
INFO - 2023-08-06 06:23:15 --> Helper loaded: url_helper
INFO - 2023-08-06 06:23:15 --> Helper loaded: file_helper
INFO - 2023-08-06 06:23:15 --> Helper loaded: html_helper
INFO - 2023-08-06 06:23:15 --> Helper loaded: text_helper
INFO - 2023-08-06 06:23:15 --> Helper loaded: form_helper
INFO - 2023-08-06 06:23:15 --> Helper loaded: lang_helper
INFO - 2023-08-06 06:23:15 --> Helper loaded: security_helper
INFO - 2023-08-06 06:23:15 --> Helper loaded: cookie_helper
INFO - 2023-08-06 06:23:15 --> Database Driver Class Initialized
INFO - 2023-08-06 06:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 06:23:15 --> Parser Class Initialized
INFO - 2023-08-06 06:23:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 06:23:15 --> Pagination Class Initialized
INFO - 2023-08-06 06:23:15 --> Form Validation Class Initialized
INFO - 2023-08-06 06:23:15 --> Controller Class Initialized
INFO - 2023-08-06 06:23:15 --> Model Class Initialized
DEBUG - 2023-08-06 06:23:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:23:15 --> Model Class Initialized
DEBUG - 2023-08-06 06:23:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:23:15 --> Model Class Initialized
INFO - 2023-08-06 06:23:15 --> Model Class Initialized
INFO - 2023-08-06 06:23:15 --> Model Class Initialized
INFO - 2023-08-06 06:23:15 --> Model Class Initialized
DEBUG - 2023-08-06 06:23:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 06:23:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:23:15 --> Model Class Initialized
INFO - 2023-08-06 06:23:15 --> Model Class Initialized
INFO - 2023-08-06 06:23:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-06 06:23:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:23:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 06:23:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 06:23:15 --> Model Class Initialized
INFO - 2023-08-06 06:23:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-06 06:23:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-06 06:23:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 06:23:15 --> Final output sent to browser
DEBUG - 2023-08-06 06:23:15 --> Total execution time: 0.2165
ERROR - 2023-08-06 06:23:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 06:23:16 --> Config Class Initialized
INFO - 2023-08-06 06:23:16 --> Hooks Class Initialized
DEBUG - 2023-08-06 06:23:16 --> UTF-8 Support Enabled
INFO - 2023-08-06 06:23:16 --> Utf8 Class Initialized
INFO - 2023-08-06 06:23:16 --> URI Class Initialized
INFO - 2023-08-06 06:23:16 --> Router Class Initialized
INFO - 2023-08-06 06:23:16 --> Output Class Initialized
INFO - 2023-08-06 06:23:16 --> Security Class Initialized
DEBUG - 2023-08-06 06:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 06:23:16 --> Input Class Initialized
INFO - 2023-08-06 06:23:16 --> Language Class Initialized
INFO - 2023-08-06 06:23:16 --> Loader Class Initialized
INFO - 2023-08-06 06:23:16 --> Helper loaded: url_helper
INFO - 2023-08-06 06:23:16 --> Helper loaded: file_helper
INFO - 2023-08-06 06:23:16 --> Helper loaded: html_helper
INFO - 2023-08-06 06:23:16 --> Helper loaded: text_helper
INFO - 2023-08-06 06:23:16 --> Helper loaded: form_helper
INFO - 2023-08-06 06:23:16 --> Helper loaded: lang_helper
INFO - 2023-08-06 06:23:16 --> Helper loaded: security_helper
INFO - 2023-08-06 06:23:16 --> Helper loaded: cookie_helper
INFO - 2023-08-06 06:23:16 --> Database Driver Class Initialized
INFO - 2023-08-06 06:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 06:23:16 --> Parser Class Initialized
INFO - 2023-08-06 06:23:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 06:23:16 --> Pagination Class Initialized
INFO - 2023-08-06 06:23:16 --> Form Validation Class Initialized
INFO - 2023-08-06 06:23:16 --> Controller Class Initialized
DEBUG - 2023-08-06 06:23:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 06:23:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:23:16 --> Model Class Initialized
INFO - 2023-08-06 06:23:16 --> Final output sent to browser
DEBUG - 2023-08-06 06:23:16 --> Total execution time: 0.0143
ERROR - 2023-08-06 06:23:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 06:23:25 --> Config Class Initialized
INFO - 2023-08-06 06:23:25 --> Hooks Class Initialized
DEBUG - 2023-08-06 06:23:25 --> UTF-8 Support Enabled
INFO - 2023-08-06 06:23:25 --> Utf8 Class Initialized
INFO - 2023-08-06 06:23:25 --> URI Class Initialized
INFO - 2023-08-06 06:23:25 --> Router Class Initialized
INFO - 2023-08-06 06:23:25 --> Output Class Initialized
INFO - 2023-08-06 06:23:25 --> Security Class Initialized
DEBUG - 2023-08-06 06:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 06:23:25 --> Input Class Initialized
INFO - 2023-08-06 06:23:25 --> Language Class Initialized
INFO - 2023-08-06 06:23:25 --> Loader Class Initialized
INFO - 2023-08-06 06:23:25 --> Helper loaded: url_helper
INFO - 2023-08-06 06:23:25 --> Helper loaded: file_helper
INFO - 2023-08-06 06:23:25 --> Helper loaded: html_helper
INFO - 2023-08-06 06:23:25 --> Helper loaded: text_helper
INFO - 2023-08-06 06:23:25 --> Helper loaded: form_helper
INFO - 2023-08-06 06:23:25 --> Helper loaded: lang_helper
INFO - 2023-08-06 06:23:25 --> Helper loaded: security_helper
INFO - 2023-08-06 06:23:25 --> Helper loaded: cookie_helper
INFO - 2023-08-06 06:23:25 --> Database Driver Class Initialized
INFO - 2023-08-06 06:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 06:23:25 --> Parser Class Initialized
INFO - 2023-08-06 06:23:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 06:23:25 --> Pagination Class Initialized
INFO - 2023-08-06 06:23:25 --> Form Validation Class Initialized
INFO - 2023-08-06 06:23:25 --> Controller Class Initialized
INFO - 2023-08-06 06:23:25 --> Model Class Initialized
DEBUG - 2023-08-06 06:23:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 06:23:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:23:25 --> Model Class Initialized
DEBUG - 2023-08-06 06:23:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:23:25 --> Model Class Initialized
INFO - 2023-08-06 06:23:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-06 06:23:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:23:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 06:23:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 06:23:25 --> Model Class Initialized
INFO - 2023-08-06 06:23:25 --> Model Class Initialized
INFO - 2023-08-06 06:23:25 --> Model Class Initialized
INFO - 2023-08-06 06:23:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-06 06:23:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-06 06:23:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 06:23:25 --> Final output sent to browser
DEBUG - 2023-08-06 06:23:25 --> Total execution time: 0.1520
ERROR - 2023-08-06 06:23:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 06:23:25 --> Config Class Initialized
INFO - 2023-08-06 06:23:25 --> Hooks Class Initialized
DEBUG - 2023-08-06 06:23:25 --> UTF-8 Support Enabled
INFO - 2023-08-06 06:23:25 --> Utf8 Class Initialized
INFO - 2023-08-06 06:23:25 --> URI Class Initialized
INFO - 2023-08-06 06:23:25 --> Router Class Initialized
INFO - 2023-08-06 06:23:25 --> Output Class Initialized
INFO - 2023-08-06 06:23:25 --> Security Class Initialized
DEBUG - 2023-08-06 06:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 06:23:25 --> Input Class Initialized
INFO - 2023-08-06 06:23:25 --> Language Class Initialized
INFO - 2023-08-06 06:23:25 --> Loader Class Initialized
INFO - 2023-08-06 06:23:25 --> Helper loaded: url_helper
INFO - 2023-08-06 06:23:25 --> Helper loaded: file_helper
INFO - 2023-08-06 06:23:25 --> Helper loaded: html_helper
INFO - 2023-08-06 06:23:25 --> Helper loaded: text_helper
INFO - 2023-08-06 06:23:25 --> Helper loaded: form_helper
INFO - 2023-08-06 06:23:25 --> Helper loaded: lang_helper
INFO - 2023-08-06 06:23:25 --> Helper loaded: security_helper
INFO - 2023-08-06 06:23:25 --> Helper loaded: cookie_helper
INFO - 2023-08-06 06:23:25 --> Database Driver Class Initialized
INFO - 2023-08-06 06:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 06:23:25 --> Parser Class Initialized
INFO - 2023-08-06 06:23:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 06:23:25 --> Pagination Class Initialized
INFO - 2023-08-06 06:23:25 --> Form Validation Class Initialized
INFO - 2023-08-06 06:23:25 --> Controller Class Initialized
INFO - 2023-08-06 06:23:25 --> Model Class Initialized
DEBUG - 2023-08-06 06:23:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 06:23:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:23:25 --> Model Class Initialized
DEBUG - 2023-08-06 06:23:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:23:25 --> Model Class Initialized
INFO - 2023-08-06 06:23:25 --> Final output sent to browser
DEBUG - 2023-08-06 06:23:25 --> Total execution time: 0.0614
ERROR - 2023-08-06 06:23:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 06:23:34 --> Config Class Initialized
INFO - 2023-08-06 06:23:34 --> Hooks Class Initialized
DEBUG - 2023-08-06 06:23:34 --> UTF-8 Support Enabled
INFO - 2023-08-06 06:23:34 --> Utf8 Class Initialized
INFO - 2023-08-06 06:23:34 --> URI Class Initialized
INFO - 2023-08-06 06:23:34 --> Router Class Initialized
INFO - 2023-08-06 06:23:34 --> Output Class Initialized
INFO - 2023-08-06 06:23:34 --> Security Class Initialized
DEBUG - 2023-08-06 06:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 06:23:34 --> Input Class Initialized
INFO - 2023-08-06 06:23:34 --> Language Class Initialized
INFO - 2023-08-06 06:23:34 --> Loader Class Initialized
INFO - 2023-08-06 06:23:34 --> Helper loaded: url_helper
INFO - 2023-08-06 06:23:34 --> Helper loaded: file_helper
INFO - 2023-08-06 06:23:34 --> Helper loaded: html_helper
INFO - 2023-08-06 06:23:34 --> Helper loaded: text_helper
INFO - 2023-08-06 06:23:34 --> Helper loaded: form_helper
INFO - 2023-08-06 06:23:34 --> Helper loaded: lang_helper
INFO - 2023-08-06 06:23:34 --> Helper loaded: security_helper
INFO - 2023-08-06 06:23:34 --> Helper loaded: cookie_helper
INFO - 2023-08-06 06:23:34 --> Database Driver Class Initialized
INFO - 2023-08-06 06:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 06:23:34 --> Parser Class Initialized
INFO - 2023-08-06 06:23:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 06:23:34 --> Pagination Class Initialized
INFO - 2023-08-06 06:23:34 --> Form Validation Class Initialized
INFO - 2023-08-06 06:23:34 --> Controller Class Initialized
DEBUG - 2023-08-06 06:23:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 06:23:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:23:34 --> Model Class Initialized
DEBUG - 2023-08-06 06:23:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:23:34 --> Model Class Initialized
DEBUG - 2023-08-06 06:23:34 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:23:34 --> Model Class Initialized
INFO - 2023-08-06 06:23:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-08-06 06:23:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:23:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 06:23:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 06:23:34 --> Model Class Initialized
INFO - 2023-08-06 06:23:34 --> Model Class Initialized
INFO - 2023-08-06 06:23:34 --> Model Class Initialized
INFO - 2023-08-06 06:23:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-06 06:23:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-06 06:23:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 06:23:34 --> Final output sent to browser
DEBUG - 2023-08-06 06:23:34 --> Total execution time: 0.1450
ERROR - 2023-08-06 06:23:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 06:23:35 --> Config Class Initialized
INFO - 2023-08-06 06:23:35 --> Hooks Class Initialized
DEBUG - 2023-08-06 06:23:35 --> UTF-8 Support Enabled
INFO - 2023-08-06 06:23:35 --> Utf8 Class Initialized
INFO - 2023-08-06 06:23:35 --> URI Class Initialized
INFO - 2023-08-06 06:23:35 --> Router Class Initialized
INFO - 2023-08-06 06:23:35 --> Output Class Initialized
INFO - 2023-08-06 06:23:35 --> Security Class Initialized
DEBUG - 2023-08-06 06:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 06:23:35 --> Input Class Initialized
INFO - 2023-08-06 06:23:35 --> Language Class Initialized
INFO - 2023-08-06 06:23:35 --> Loader Class Initialized
INFO - 2023-08-06 06:23:35 --> Helper loaded: url_helper
INFO - 2023-08-06 06:23:35 --> Helper loaded: file_helper
INFO - 2023-08-06 06:23:35 --> Helper loaded: html_helper
INFO - 2023-08-06 06:23:35 --> Helper loaded: text_helper
INFO - 2023-08-06 06:23:35 --> Helper loaded: form_helper
INFO - 2023-08-06 06:23:35 --> Helper loaded: lang_helper
INFO - 2023-08-06 06:23:35 --> Helper loaded: security_helper
INFO - 2023-08-06 06:23:35 --> Helper loaded: cookie_helper
INFO - 2023-08-06 06:23:35 --> Database Driver Class Initialized
INFO - 2023-08-06 06:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 06:23:35 --> Parser Class Initialized
INFO - 2023-08-06 06:23:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 06:23:35 --> Pagination Class Initialized
INFO - 2023-08-06 06:23:35 --> Form Validation Class Initialized
INFO - 2023-08-06 06:23:35 --> Controller Class Initialized
DEBUG - 2023-08-06 06:23:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 06:23:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:23:35 --> Model Class Initialized
DEBUG - 2023-08-06 06:23:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:23:35 --> Model Class Initialized
INFO - 2023-08-06 06:23:35 --> Final output sent to browser
DEBUG - 2023-08-06 06:23:35 --> Total execution time: 0.0427
ERROR - 2023-08-06 06:23:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 06:23:48 --> Config Class Initialized
INFO - 2023-08-06 06:23:48 --> Hooks Class Initialized
DEBUG - 2023-08-06 06:23:48 --> UTF-8 Support Enabled
INFO - 2023-08-06 06:23:48 --> Utf8 Class Initialized
INFO - 2023-08-06 06:23:48 --> URI Class Initialized
INFO - 2023-08-06 06:23:48 --> Router Class Initialized
INFO - 2023-08-06 06:23:48 --> Output Class Initialized
INFO - 2023-08-06 06:23:48 --> Security Class Initialized
DEBUG - 2023-08-06 06:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 06:23:48 --> Input Class Initialized
INFO - 2023-08-06 06:23:48 --> Language Class Initialized
INFO - 2023-08-06 06:23:48 --> Loader Class Initialized
INFO - 2023-08-06 06:23:48 --> Helper loaded: url_helper
INFO - 2023-08-06 06:23:48 --> Helper loaded: file_helper
INFO - 2023-08-06 06:23:48 --> Helper loaded: html_helper
INFO - 2023-08-06 06:23:48 --> Helper loaded: text_helper
INFO - 2023-08-06 06:23:48 --> Helper loaded: form_helper
INFO - 2023-08-06 06:23:48 --> Helper loaded: lang_helper
INFO - 2023-08-06 06:23:48 --> Helper loaded: security_helper
INFO - 2023-08-06 06:23:48 --> Helper loaded: cookie_helper
INFO - 2023-08-06 06:23:48 --> Database Driver Class Initialized
INFO - 2023-08-06 06:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 06:23:48 --> Parser Class Initialized
INFO - 2023-08-06 06:23:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 06:23:48 --> Pagination Class Initialized
INFO - 2023-08-06 06:23:48 --> Form Validation Class Initialized
INFO - 2023-08-06 06:23:48 --> Controller Class Initialized
DEBUG - 2023-08-06 06:23:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 06:23:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:23:48 --> Model Class Initialized
DEBUG - 2023-08-06 06:23:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:23:48 --> Model Class Initialized
INFO - 2023-08-06 06:23:48 --> Final output sent to browser
DEBUG - 2023-08-06 06:23:48 --> Total execution time: 0.1437
ERROR - 2023-08-06 06:23:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 06:23:55 --> Config Class Initialized
INFO - 2023-08-06 06:23:55 --> Hooks Class Initialized
DEBUG - 2023-08-06 06:23:55 --> UTF-8 Support Enabled
INFO - 2023-08-06 06:23:55 --> Utf8 Class Initialized
INFO - 2023-08-06 06:23:55 --> URI Class Initialized
INFO - 2023-08-06 06:23:55 --> Router Class Initialized
INFO - 2023-08-06 06:23:55 --> Output Class Initialized
INFO - 2023-08-06 06:23:55 --> Security Class Initialized
DEBUG - 2023-08-06 06:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 06:23:55 --> Input Class Initialized
INFO - 2023-08-06 06:23:55 --> Language Class Initialized
INFO - 2023-08-06 06:23:55 --> Loader Class Initialized
INFO - 2023-08-06 06:23:55 --> Helper loaded: url_helper
INFO - 2023-08-06 06:23:55 --> Helper loaded: file_helper
INFO - 2023-08-06 06:23:55 --> Helper loaded: html_helper
INFO - 2023-08-06 06:23:55 --> Helper loaded: text_helper
INFO - 2023-08-06 06:23:55 --> Helper loaded: form_helper
INFO - 2023-08-06 06:23:55 --> Helper loaded: lang_helper
INFO - 2023-08-06 06:23:55 --> Helper loaded: security_helper
INFO - 2023-08-06 06:23:55 --> Helper loaded: cookie_helper
INFO - 2023-08-06 06:23:55 --> Database Driver Class Initialized
INFO - 2023-08-06 06:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 06:23:55 --> Parser Class Initialized
INFO - 2023-08-06 06:23:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 06:23:55 --> Pagination Class Initialized
INFO - 2023-08-06 06:23:55 --> Form Validation Class Initialized
INFO - 2023-08-06 06:23:55 --> Controller Class Initialized
DEBUG - 2023-08-06 06:23:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 06:23:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:23:55 --> Model Class Initialized
DEBUG - 2023-08-06 06:23:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:23:55 --> Model Class Initialized
INFO - 2023-08-06 06:23:55 --> Final output sent to browser
DEBUG - 2023-08-06 06:23:55 --> Total execution time: 0.1392
ERROR - 2023-08-06 06:23:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 06:23:56 --> Config Class Initialized
INFO - 2023-08-06 06:23:56 --> Hooks Class Initialized
DEBUG - 2023-08-06 06:23:56 --> UTF-8 Support Enabled
INFO - 2023-08-06 06:23:56 --> Utf8 Class Initialized
INFO - 2023-08-06 06:23:56 --> URI Class Initialized
INFO - 2023-08-06 06:23:56 --> Router Class Initialized
INFO - 2023-08-06 06:23:56 --> Output Class Initialized
INFO - 2023-08-06 06:23:56 --> Security Class Initialized
DEBUG - 2023-08-06 06:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 06:23:56 --> Input Class Initialized
INFO - 2023-08-06 06:23:56 --> Language Class Initialized
INFO - 2023-08-06 06:23:56 --> Loader Class Initialized
INFO - 2023-08-06 06:23:56 --> Helper loaded: url_helper
INFO - 2023-08-06 06:23:56 --> Helper loaded: file_helper
INFO - 2023-08-06 06:23:56 --> Helper loaded: html_helper
INFO - 2023-08-06 06:23:56 --> Helper loaded: text_helper
INFO - 2023-08-06 06:23:56 --> Helper loaded: form_helper
INFO - 2023-08-06 06:23:56 --> Helper loaded: lang_helper
INFO - 2023-08-06 06:23:56 --> Helper loaded: security_helper
INFO - 2023-08-06 06:23:56 --> Helper loaded: cookie_helper
INFO - 2023-08-06 06:23:56 --> Database Driver Class Initialized
INFO - 2023-08-06 06:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 06:23:56 --> Parser Class Initialized
INFO - 2023-08-06 06:23:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 06:23:56 --> Pagination Class Initialized
INFO - 2023-08-06 06:23:56 --> Form Validation Class Initialized
INFO - 2023-08-06 06:23:56 --> Controller Class Initialized
DEBUG - 2023-08-06 06:23:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 06:23:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:23:56 --> Model Class Initialized
DEBUG - 2023-08-06 06:23:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:23:56 --> Model Class Initialized
INFO - 2023-08-06 06:23:56 --> Final output sent to browser
DEBUG - 2023-08-06 06:23:56 --> Total execution time: 0.0934
ERROR - 2023-08-06 06:23:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 06:23:57 --> Config Class Initialized
INFO - 2023-08-06 06:23:57 --> Hooks Class Initialized
DEBUG - 2023-08-06 06:23:57 --> UTF-8 Support Enabled
INFO - 2023-08-06 06:23:57 --> Utf8 Class Initialized
INFO - 2023-08-06 06:23:57 --> URI Class Initialized
INFO - 2023-08-06 06:23:57 --> Router Class Initialized
INFO - 2023-08-06 06:23:57 --> Output Class Initialized
INFO - 2023-08-06 06:23:57 --> Security Class Initialized
DEBUG - 2023-08-06 06:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 06:23:57 --> Input Class Initialized
INFO - 2023-08-06 06:23:57 --> Language Class Initialized
INFO - 2023-08-06 06:23:57 --> Loader Class Initialized
INFO - 2023-08-06 06:23:57 --> Helper loaded: url_helper
INFO - 2023-08-06 06:23:57 --> Helper loaded: file_helper
INFO - 2023-08-06 06:23:57 --> Helper loaded: html_helper
INFO - 2023-08-06 06:23:57 --> Helper loaded: text_helper
INFO - 2023-08-06 06:23:57 --> Helper loaded: form_helper
INFO - 2023-08-06 06:23:57 --> Helper loaded: lang_helper
INFO - 2023-08-06 06:23:57 --> Helper loaded: security_helper
INFO - 2023-08-06 06:23:57 --> Helper loaded: cookie_helper
INFO - 2023-08-06 06:23:57 --> Database Driver Class Initialized
INFO - 2023-08-06 06:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 06:23:57 --> Parser Class Initialized
INFO - 2023-08-06 06:23:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 06:23:57 --> Pagination Class Initialized
INFO - 2023-08-06 06:23:57 --> Form Validation Class Initialized
INFO - 2023-08-06 06:23:57 --> Controller Class Initialized
DEBUG - 2023-08-06 06:23:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 06:23:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:23:57 --> Model Class Initialized
DEBUG - 2023-08-06 06:23:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:23:57 --> Model Class Initialized
INFO - 2023-08-06 06:23:57 --> Final output sent to browser
DEBUG - 2023-08-06 06:23:57 --> Total execution time: 0.1102
ERROR - 2023-08-06 06:23:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 06:23:57 --> Config Class Initialized
INFO - 2023-08-06 06:23:57 --> Hooks Class Initialized
DEBUG - 2023-08-06 06:23:57 --> UTF-8 Support Enabled
INFO - 2023-08-06 06:23:57 --> Utf8 Class Initialized
INFO - 2023-08-06 06:23:57 --> URI Class Initialized
INFO - 2023-08-06 06:23:57 --> Router Class Initialized
INFO - 2023-08-06 06:23:57 --> Output Class Initialized
INFO - 2023-08-06 06:23:57 --> Security Class Initialized
DEBUG - 2023-08-06 06:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 06:23:57 --> Input Class Initialized
INFO - 2023-08-06 06:23:57 --> Language Class Initialized
INFO - 2023-08-06 06:23:57 --> Loader Class Initialized
INFO - 2023-08-06 06:23:57 --> Helper loaded: url_helper
INFO - 2023-08-06 06:23:57 --> Helper loaded: file_helper
INFO - 2023-08-06 06:23:57 --> Helper loaded: html_helper
INFO - 2023-08-06 06:23:57 --> Helper loaded: text_helper
INFO - 2023-08-06 06:23:57 --> Helper loaded: form_helper
INFO - 2023-08-06 06:23:57 --> Helper loaded: lang_helper
INFO - 2023-08-06 06:23:57 --> Helper loaded: security_helper
INFO - 2023-08-06 06:23:57 --> Helper loaded: cookie_helper
INFO - 2023-08-06 06:23:57 --> Database Driver Class Initialized
INFO - 2023-08-06 06:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 06:23:57 --> Parser Class Initialized
INFO - 2023-08-06 06:23:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 06:23:57 --> Pagination Class Initialized
INFO - 2023-08-06 06:23:57 --> Form Validation Class Initialized
INFO - 2023-08-06 06:23:57 --> Controller Class Initialized
DEBUG - 2023-08-06 06:23:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 06:23:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:23:57 --> Model Class Initialized
DEBUG - 2023-08-06 06:23:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:23:57 --> Model Class Initialized
INFO - 2023-08-06 06:23:57 --> Final output sent to browser
DEBUG - 2023-08-06 06:23:57 --> Total execution time: 0.1010
ERROR - 2023-08-06 06:23:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 06:23:59 --> Config Class Initialized
INFO - 2023-08-06 06:23:59 --> Hooks Class Initialized
DEBUG - 2023-08-06 06:23:59 --> UTF-8 Support Enabled
INFO - 2023-08-06 06:23:59 --> Utf8 Class Initialized
INFO - 2023-08-06 06:23:59 --> URI Class Initialized
INFO - 2023-08-06 06:23:59 --> Router Class Initialized
INFO - 2023-08-06 06:23:59 --> Output Class Initialized
INFO - 2023-08-06 06:23:59 --> Security Class Initialized
DEBUG - 2023-08-06 06:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 06:23:59 --> Input Class Initialized
INFO - 2023-08-06 06:23:59 --> Language Class Initialized
INFO - 2023-08-06 06:23:59 --> Loader Class Initialized
INFO - 2023-08-06 06:23:59 --> Helper loaded: url_helper
INFO - 2023-08-06 06:23:59 --> Helper loaded: file_helper
INFO - 2023-08-06 06:23:59 --> Helper loaded: html_helper
INFO - 2023-08-06 06:23:59 --> Helper loaded: text_helper
INFO - 2023-08-06 06:23:59 --> Helper loaded: form_helper
INFO - 2023-08-06 06:23:59 --> Helper loaded: lang_helper
INFO - 2023-08-06 06:23:59 --> Helper loaded: security_helper
INFO - 2023-08-06 06:23:59 --> Helper loaded: cookie_helper
INFO - 2023-08-06 06:23:59 --> Database Driver Class Initialized
INFO - 2023-08-06 06:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 06:23:59 --> Parser Class Initialized
INFO - 2023-08-06 06:23:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 06:23:59 --> Pagination Class Initialized
INFO - 2023-08-06 06:23:59 --> Form Validation Class Initialized
INFO - 2023-08-06 06:23:59 --> Controller Class Initialized
DEBUG - 2023-08-06 06:23:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 06:23:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:23:59 --> Model Class Initialized
DEBUG - 2023-08-06 06:23:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:23:59 --> Model Class Initialized
INFO - 2023-08-06 06:23:59 --> Final output sent to browser
DEBUG - 2023-08-06 06:23:59 --> Total execution time: 0.0279
ERROR - 2023-08-06 06:24:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 06:24:00 --> Config Class Initialized
INFO - 2023-08-06 06:24:00 --> Hooks Class Initialized
DEBUG - 2023-08-06 06:24:00 --> UTF-8 Support Enabled
INFO - 2023-08-06 06:24:00 --> Utf8 Class Initialized
INFO - 2023-08-06 06:24:00 --> URI Class Initialized
INFO - 2023-08-06 06:24:00 --> Router Class Initialized
INFO - 2023-08-06 06:24:00 --> Output Class Initialized
INFO - 2023-08-06 06:24:00 --> Security Class Initialized
DEBUG - 2023-08-06 06:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 06:24:00 --> Input Class Initialized
INFO - 2023-08-06 06:24:00 --> Language Class Initialized
INFO - 2023-08-06 06:24:00 --> Loader Class Initialized
INFO - 2023-08-06 06:24:00 --> Helper loaded: url_helper
INFO - 2023-08-06 06:24:00 --> Helper loaded: file_helper
INFO - 2023-08-06 06:24:00 --> Helper loaded: html_helper
INFO - 2023-08-06 06:24:00 --> Helper loaded: text_helper
INFO - 2023-08-06 06:24:00 --> Helper loaded: form_helper
INFO - 2023-08-06 06:24:00 --> Helper loaded: lang_helper
INFO - 2023-08-06 06:24:00 --> Helper loaded: security_helper
INFO - 2023-08-06 06:24:00 --> Helper loaded: cookie_helper
INFO - 2023-08-06 06:24:00 --> Database Driver Class Initialized
INFO - 2023-08-06 06:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 06:24:00 --> Parser Class Initialized
INFO - 2023-08-06 06:24:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 06:24:00 --> Pagination Class Initialized
INFO - 2023-08-06 06:24:00 --> Form Validation Class Initialized
INFO - 2023-08-06 06:24:00 --> Controller Class Initialized
DEBUG - 2023-08-06 06:24:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 06:24:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:24:00 --> Model Class Initialized
DEBUG - 2023-08-06 06:24:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:24:00 --> Model Class Initialized
INFO - 2023-08-06 06:24:00 --> Final output sent to browser
DEBUG - 2023-08-06 06:24:00 --> Total execution time: 0.0234
ERROR - 2023-08-06 06:24:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 06:24:14 --> Config Class Initialized
INFO - 2023-08-06 06:24:14 --> Hooks Class Initialized
DEBUG - 2023-08-06 06:24:14 --> UTF-8 Support Enabled
INFO - 2023-08-06 06:24:14 --> Utf8 Class Initialized
INFO - 2023-08-06 06:24:14 --> URI Class Initialized
DEBUG - 2023-08-06 06:24:14 --> No URI present. Default controller set.
INFO - 2023-08-06 06:24:14 --> Router Class Initialized
INFO - 2023-08-06 06:24:14 --> Output Class Initialized
INFO - 2023-08-06 06:24:14 --> Security Class Initialized
DEBUG - 2023-08-06 06:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 06:24:14 --> Input Class Initialized
INFO - 2023-08-06 06:24:14 --> Language Class Initialized
INFO - 2023-08-06 06:24:14 --> Loader Class Initialized
INFO - 2023-08-06 06:24:14 --> Helper loaded: url_helper
INFO - 2023-08-06 06:24:14 --> Helper loaded: file_helper
INFO - 2023-08-06 06:24:14 --> Helper loaded: html_helper
INFO - 2023-08-06 06:24:14 --> Helper loaded: text_helper
INFO - 2023-08-06 06:24:14 --> Helper loaded: form_helper
INFO - 2023-08-06 06:24:14 --> Helper loaded: lang_helper
INFO - 2023-08-06 06:24:14 --> Helper loaded: security_helper
INFO - 2023-08-06 06:24:14 --> Helper loaded: cookie_helper
INFO - 2023-08-06 06:24:14 --> Database Driver Class Initialized
INFO - 2023-08-06 06:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 06:24:14 --> Parser Class Initialized
INFO - 2023-08-06 06:24:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 06:24:14 --> Pagination Class Initialized
INFO - 2023-08-06 06:24:14 --> Form Validation Class Initialized
INFO - 2023-08-06 06:24:14 --> Controller Class Initialized
INFO - 2023-08-06 06:24:14 --> Model Class Initialized
DEBUG - 2023-08-06 06:24:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:24:14 --> Model Class Initialized
DEBUG - 2023-08-06 06:24:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:24:14 --> Model Class Initialized
INFO - 2023-08-06 06:24:14 --> Model Class Initialized
INFO - 2023-08-06 06:24:14 --> Model Class Initialized
INFO - 2023-08-06 06:24:14 --> Model Class Initialized
DEBUG - 2023-08-06 06:24:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 06:24:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:24:14 --> Model Class Initialized
INFO - 2023-08-06 06:24:14 --> Model Class Initialized
INFO - 2023-08-06 06:24:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-06 06:24:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:24:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 06:24:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 06:24:14 --> Model Class Initialized
INFO - 2023-08-06 06:24:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-06 06:24:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-06 06:24:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 06:24:14 --> Final output sent to browser
DEBUG - 2023-08-06 06:24:14 --> Total execution time: 0.2110
ERROR - 2023-08-06 06:24:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 06:24:34 --> Config Class Initialized
INFO - 2023-08-06 06:24:34 --> Hooks Class Initialized
DEBUG - 2023-08-06 06:24:34 --> UTF-8 Support Enabled
INFO - 2023-08-06 06:24:34 --> Utf8 Class Initialized
INFO - 2023-08-06 06:24:34 --> URI Class Initialized
INFO - 2023-08-06 06:24:34 --> Router Class Initialized
INFO - 2023-08-06 06:24:34 --> Output Class Initialized
INFO - 2023-08-06 06:24:34 --> Security Class Initialized
DEBUG - 2023-08-06 06:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 06:24:34 --> Input Class Initialized
INFO - 2023-08-06 06:24:34 --> Language Class Initialized
INFO - 2023-08-06 06:24:34 --> Loader Class Initialized
INFO - 2023-08-06 06:24:34 --> Helper loaded: url_helper
INFO - 2023-08-06 06:24:34 --> Helper loaded: file_helper
INFO - 2023-08-06 06:24:34 --> Helper loaded: html_helper
INFO - 2023-08-06 06:24:34 --> Helper loaded: text_helper
INFO - 2023-08-06 06:24:34 --> Helper loaded: form_helper
INFO - 2023-08-06 06:24:34 --> Helper loaded: lang_helper
INFO - 2023-08-06 06:24:34 --> Helper loaded: security_helper
INFO - 2023-08-06 06:24:34 --> Helper loaded: cookie_helper
INFO - 2023-08-06 06:24:34 --> Database Driver Class Initialized
INFO - 2023-08-06 06:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 06:24:34 --> Parser Class Initialized
INFO - 2023-08-06 06:24:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 06:24:34 --> Pagination Class Initialized
INFO - 2023-08-06 06:24:34 --> Form Validation Class Initialized
INFO - 2023-08-06 06:24:34 --> Controller Class Initialized
INFO - 2023-08-06 06:24:34 --> Model Class Initialized
DEBUG - 2023-08-06 06:24:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 06:24:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:24:34 --> Model Class Initialized
DEBUG - 2023-08-06 06:24:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:24:34 --> Model Class Initialized
INFO - 2023-08-06 06:24:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-06 06:24:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:24:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 06:24:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 06:24:34 --> Model Class Initialized
INFO - 2023-08-06 06:24:34 --> Model Class Initialized
INFO - 2023-08-06 06:24:34 --> Model Class Initialized
INFO - 2023-08-06 06:24:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-06 06:24:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-06 06:24:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 06:24:34 --> Final output sent to browser
DEBUG - 2023-08-06 06:24:34 --> Total execution time: 0.1538
ERROR - 2023-08-06 06:24:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 06:24:35 --> Config Class Initialized
INFO - 2023-08-06 06:24:35 --> Hooks Class Initialized
DEBUG - 2023-08-06 06:24:35 --> UTF-8 Support Enabled
INFO - 2023-08-06 06:24:35 --> Utf8 Class Initialized
INFO - 2023-08-06 06:24:35 --> URI Class Initialized
INFO - 2023-08-06 06:24:35 --> Router Class Initialized
INFO - 2023-08-06 06:24:35 --> Output Class Initialized
INFO - 2023-08-06 06:24:35 --> Security Class Initialized
DEBUG - 2023-08-06 06:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 06:24:35 --> Input Class Initialized
INFO - 2023-08-06 06:24:35 --> Language Class Initialized
INFO - 2023-08-06 06:24:35 --> Loader Class Initialized
INFO - 2023-08-06 06:24:35 --> Helper loaded: url_helper
INFO - 2023-08-06 06:24:35 --> Helper loaded: file_helper
INFO - 2023-08-06 06:24:35 --> Helper loaded: html_helper
INFO - 2023-08-06 06:24:35 --> Helper loaded: text_helper
INFO - 2023-08-06 06:24:35 --> Helper loaded: form_helper
INFO - 2023-08-06 06:24:35 --> Helper loaded: lang_helper
INFO - 2023-08-06 06:24:35 --> Helper loaded: security_helper
INFO - 2023-08-06 06:24:35 --> Helper loaded: cookie_helper
INFO - 2023-08-06 06:24:35 --> Database Driver Class Initialized
INFO - 2023-08-06 06:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 06:24:35 --> Parser Class Initialized
INFO - 2023-08-06 06:24:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 06:24:35 --> Pagination Class Initialized
INFO - 2023-08-06 06:24:35 --> Form Validation Class Initialized
INFO - 2023-08-06 06:24:35 --> Controller Class Initialized
INFO - 2023-08-06 06:24:35 --> Model Class Initialized
DEBUG - 2023-08-06 06:24:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 06:24:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:24:35 --> Model Class Initialized
DEBUG - 2023-08-06 06:24:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:24:35 --> Model Class Initialized
INFO - 2023-08-06 06:24:35 --> Final output sent to browser
DEBUG - 2023-08-06 06:24:35 --> Total execution time: 0.0601
ERROR - 2023-08-06 06:24:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 06:24:41 --> Config Class Initialized
INFO - 2023-08-06 06:24:41 --> Hooks Class Initialized
DEBUG - 2023-08-06 06:24:41 --> UTF-8 Support Enabled
INFO - 2023-08-06 06:24:41 --> Utf8 Class Initialized
INFO - 2023-08-06 06:24:41 --> URI Class Initialized
INFO - 2023-08-06 06:24:41 --> Router Class Initialized
INFO - 2023-08-06 06:24:41 --> Output Class Initialized
INFO - 2023-08-06 06:24:41 --> Security Class Initialized
DEBUG - 2023-08-06 06:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 06:24:41 --> Input Class Initialized
INFO - 2023-08-06 06:24:41 --> Language Class Initialized
INFO - 2023-08-06 06:24:41 --> Loader Class Initialized
INFO - 2023-08-06 06:24:41 --> Helper loaded: url_helper
INFO - 2023-08-06 06:24:41 --> Helper loaded: file_helper
INFO - 2023-08-06 06:24:41 --> Helper loaded: html_helper
INFO - 2023-08-06 06:24:41 --> Helper loaded: text_helper
INFO - 2023-08-06 06:24:41 --> Helper loaded: form_helper
INFO - 2023-08-06 06:24:41 --> Helper loaded: lang_helper
INFO - 2023-08-06 06:24:41 --> Helper loaded: security_helper
INFO - 2023-08-06 06:24:41 --> Helper loaded: cookie_helper
INFO - 2023-08-06 06:24:41 --> Database Driver Class Initialized
INFO - 2023-08-06 06:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 06:24:41 --> Parser Class Initialized
INFO - 2023-08-06 06:24:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 06:24:41 --> Pagination Class Initialized
INFO - 2023-08-06 06:24:41 --> Form Validation Class Initialized
INFO - 2023-08-06 06:24:41 --> Controller Class Initialized
INFO - 2023-08-06 06:24:41 --> Model Class Initialized
DEBUG - 2023-08-06 06:24:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 06:24:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:24:41 --> Model Class Initialized
DEBUG - 2023-08-06 06:24:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:24:41 --> Model Class Initialized
INFO - 2023-08-06 06:24:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-06 06:24:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:24:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 06:24:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 06:24:41 --> Model Class Initialized
INFO - 2023-08-06 06:24:41 --> Model Class Initialized
INFO - 2023-08-06 06:24:41 --> Model Class Initialized
INFO - 2023-08-06 06:24:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-06 06:24:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-06 06:24:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 06:24:41 --> Final output sent to browser
DEBUG - 2023-08-06 06:24:41 --> Total execution time: 0.1521
ERROR - 2023-08-06 06:24:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 06:24:41 --> Config Class Initialized
INFO - 2023-08-06 06:24:41 --> Hooks Class Initialized
DEBUG - 2023-08-06 06:24:41 --> UTF-8 Support Enabled
INFO - 2023-08-06 06:24:41 --> Utf8 Class Initialized
INFO - 2023-08-06 06:24:41 --> URI Class Initialized
INFO - 2023-08-06 06:24:41 --> Router Class Initialized
INFO - 2023-08-06 06:24:41 --> Output Class Initialized
INFO - 2023-08-06 06:24:41 --> Security Class Initialized
DEBUG - 2023-08-06 06:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 06:24:41 --> Input Class Initialized
INFO - 2023-08-06 06:24:41 --> Language Class Initialized
INFO - 2023-08-06 06:24:41 --> Loader Class Initialized
INFO - 2023-08-06 06:24:41 --> Helper loaded: url_helper
INFO - 2023-08-06 06:24:41 --> Helper loaded: file_helper
INFO - 2023-08-06 06:24:41 --> Helper loaded: html_helper
INFO - 2023-08-06 06:24:41 --> Helper loaded: text_helper
INFO - 2023-08-06 06:24:41 --> Helper loaded: form_helper
INFO - 2023-08-06 06:24:41 --> Helper loaded: lang_helper
INFO - 2023-08-06 06:24:41 --> Helper loaded: security_helper
INFO - 2023-08-06 06:24:41 --> Helper loaded: cookie_helper
INFO - 2023-08-06 06:24:41 --> Database Driver Class Initialized
INFO - 2023-08-06 06:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 06:24:41 --> Parser Class Initialized
INFO - 2023-08-06 06:24:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 06:24:41 --> Pagination Class Initialized
INFO - 2023-08-06 06:24:41 --> Form Validation Class Initialized
INFO - 2023-08-06 06:24:41 --> Controller Class Initialized
INFO - 2023-08-06 06:24:41 --> Model Class Initialized
DEBUG - 2023-08-06 06:24:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 06:24:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:24:41 --> Model Class Initialized
DEBUG - 2023-08-06 06:24:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:24:41 --> Model Class Initialized
INFO - 2023-08-06 06:24:41 --> Final output sent to browser
DEBUG - 2023-08-06 06:24:41 --> Total execution time: 0.0586
ERROR - 2023-08-06 06:24:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 06:24:45 --> Config Class Initialized
INFO - 2023-08-06 06:24:45 --> Hooks Class Initialized
DEBUG - 2023-08-06 06:24:45 --> UTF-8 Support Enabled
INFO - 2023-08-06 06:24:45 --> Utf8 Class Initialized
INFO - 2023-08-06 06:24:45 --> URI Class Initialized
INFO - 2023-08-06 06:24:45 --> Router Class Initialized
INFO - 2023-08-06 06:24:45 --> Output Class Initialized
INFO - 2023-08-06 06:24:45 --> Security Class Initialized
DEBUG - 2023-08-06 06:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 06:24:45 --> Input Class Initialized
INFO - 2023-08-06 06:24:45 --> Language Class Initialized
INFO - 2023-08-06 06:24:45 --> Loader Class Initialized
INFO - 2023-08-06 06:24:45 --> Helper loaded: url_helper
INFO - 2023-08-06 06:24:45 --> Helper loaded: file_helper
INFO - 2023-08-06 06:24:45 --> Helper loaded: html_helper
INFO - 2023-08-06 06:24:45 --> Helper loaded: text_helper
INFO - 2023-08-06 06:24:45 --> Helper loaded: form_helper
INFO - 2023-08-06 06:24:45 --> Helper loaded: lang_helper
INFO - 2023-08-06 06:24:45 --> Helper loaded: security_helper
INFO - 2023-08-06 06:24:45 --> Helper loaded: cookie_helper
INFO - 2023-08-06 06:24:45 --> Database Driver Class Initialized
INFO - 2023-08-06 06:24:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 06:24:45 --> Parser Class Initialized
INFO - 2023-08-06 06:24:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 06:24:45 --> Pagination Class Initialized
INFO - 2023-08-06 06:24:45 --> Form Validation Class Initialized
INFO - 2023-08-06 06:24:45 --> Controller Class Initialized
INFO - 2023-08-06 06:24:45 --> Model Class Initialized
DEBUG - 2023-08-06 06:24:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 06:24:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:24:45 --> Model Class Initialized
DEBUG - 2023-08-06 06:24:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:24:45 --> Model Class Initialized
INFO - 2023-08-06 06:24:45 --> Final output sent to browser
DEBUG - 2023-08-06 06:24:45 --> Total execution time: 0.4606
ERROR - 2023-08-06 06:24:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 06:24:56 --> Config Class Initialized
INFO - 2023-08-06 06:24:56 --> Hooks Class Initialized
DEBUG - 2023-08-06 06:24:56 --> UTF-8 Support Enabled
INFO - 2023-08-06 06:24:56 --> Utf8 Class Initialized
INFO - 2023-08-06 06:24:56 --> URI Class Initialized
DEBUG - 2023-08-06 06:24:56 --> No URI present. Default controller set.
INFO - 2023-08-06 06:24:56 --> Router Class Initialized
INFO - 2023-08-06 06:24:56 --> Output Class Initialized
INFO - 2023-08-06 06:24:56 --> Security Class Initialized
DEBUG - 2023-08-06 06:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 06:24:56 --> Input Class Initialized
INFO - 2023-08-06 06:24:56 --> Language Class Initialized
INFO - 2023-08-06 06:24:56 --> Loader Class Initialized
INFO - 2023-08-06 06:24:56 --> Helper loaded: url_helper
INFO - 2023-08-06 06:24:56 --> Helper loaded: file_helper
INFO - 2023-08-06 06:24:56 --> Helper loaded: html_helper
INFO - 2023-08-06 06:24:56 --> Helper loaded: text_helper
INFO - 2023-08-06 06:24:56 --> Helper loaded: form_helper
INFO - 2023-08-06 06:24:56 --> Helper loaded: lang_helper
INFO - 2023-08-06 06:24:56 --> Helper loaded: security_helper
INFO - 2023-08-06 06:24:56 --> Helper loaded: cookie_helper
INFO - 2023-08-06 06:24:56 --> Database Driver Class Initialized
INFO - 2023-08-06 06:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 06:24:56 --> Parser Class Initialized
INFO - 2023-08-06 06:24:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 06:24:56 --> Pagination Class Initialized
INFO - 2023-08-06 06:24:56 --> Form Validation Class Initialized
INFO - 2023-08-06 06:24:56 --> Controller Class Initialized
INFO - 2023-08-06 06:24:56 --> Model Class Initialized
DEBUG - 2023-08-06 06:24:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-06 06:24:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 06:24:56 --> Config Class Initialized
INFO - 2023-08-06 06:24:56 --> Hooks Class Initialized
DEBUG - 2023-08-06 06:24:56 --> UTF-8 Support Enabled
INFO - 2023-08-06 06:24:56 --> Utf8 Class Initialized
INFO - 2023-08-06 06:24:56 --> URI Class Initialized
INFO - 2023-08-06 06:24:56 --> Router Class Initialized
INFO - 2023-08-06 06:24:56 --> Output Class Initialized
INFO - 2023-08-06 06:24:56 --> Security Class Initialized
DEBUG - 2023-08-06 06:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 06:24:56 --> Input Class Initialized
INFO - 2023-08-06 06:24:56 --> Language Class Initialized
INFO - 2023-08-06 06:24:56 --> Loader Class Initialized
INFO - 2023-08-06 06:24:56 --> Helper loaded: url_helper
INFO - 2023-08-06 06:24:56 --> Helper loaded: file_helper
INFO - 2023-08-06 06:24:56 --> Helper loaded: html_helper
INFO - 2023-08-06 06:24:56 --> Helper loaded: text_helper
INFO - 2023-08-06 06:24:56 --> Helper loaded: form_helper
INFO - 2023-08-06 06:24:56 --> Helper loaded: lang_helper
INFO - 2023-08-06 06:24:56 --> Helper loaded: security_helper
INFO - 2023-08-06 06:24:56 --> Helper loaded: cookie_helper
INFO - 2023-08-06 06:24:56 --> Database Driver Class Initialized
INFO - 2023-08-06 06:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 06:24:56 --> Parser Class Initialized
INFO - 2023-08-06 06:24:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 06:24:56 --> Pagination Class Initialized
INFO - 2023-08-06 06:24:56 --> Form Validation Class Initialized
INFO - 2023-08-06 06:24:56 --> Controller Class Initialized
INFO - 2023-08-06 06:24:56 --> Model Class Initialized
DEBUG - 2023-08-06 06:24:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:24:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-06 06:24:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:24:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 06:24:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 06:24:57 --> Model Class Initialized
INFO - 2023-08-06 06:24:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 06:24:57 --> Final output sent to browser
DEBUG - 2023-08-06 06:24:57 --> Total execution time: 0.0285
ERROR - 2023-08-06 06:25:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 06:25:00 --> Config Class Initialized
INFO - 2023-08-06 06:25:00 --> Hooks Class Initialized
DEBUG - 2023-08-06 06:25:00 --> UTF-8 Support Enabled
INFO - 2023-08-06 06:25:00 --> Utf8 Class Initialized
INFO - 2023-08-06 06:25:00 --> URI Class Initialized
INFO - 2023-08-06 06:25:00 --> Router Class Initialized
INFO - 2023-08-06 06:25:00 --> Output Class Initialized
INFO - 2023-08-06 06:25:00 --> Security Class Initialized
DEBUG - 2023-08-06 06:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 06:25:00 --> Input Class Initialized
INFO - 2023-08-06 06:25:00 --> Language Class Initialized
INFO - 2023-08-06 06:25:00 --> Loader Class Initialized
INFO - 2023-08-06 06:25:00 --> Helper loaded: url_helper
INFO - 2023-08-06 06:25:00 --> Helper loaded: file_helper
INFO - 2023-08-06 06:25:00 --> Helper loaded: html_helper
INFO - 2023-08-06 06:25:00 --> Helper loaded: text_helper
INFO - 2023-08-06 06:25:00 --> Helper loaded: form_helper
INFO - 2023-08-06 06:25:00 --> Helper loaded: lang_helper
INFO - 2023-08-06 06:25:00 --> Helper loaded: security_helper
INFO - 2023-08-06 06:25:00 --> Helper loaded: cookie_helper
INFO - 2023-08-06 06:25:00 --> Database Driver Class Initialized
INFO - 2023-08-06 06:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 06:25:00 --> Parser Class Initialized
INFO - 2023-08-06 06:25:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 06:25:00 --> Pagination Class Initialized
INFO - 2023-08-06 06:25:00 --> Form Validation Class Initialized
INFO - 2023-08-06 06:25:00 --> Controller Class Initialized
INFO - 2023-08-06 06:25:00 --> Model Class Initialized
DEBUG - 2023-08-06 06:25:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:25:00 --> Model Class Initialized
INFO - 2023-08-06 06:25:00 --> Final output sent to browser
DEBUG - 2023-08-06 06:25:00 --> Total execution time: 0.0174
ERROR - 2023-08-06 06:25:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 06:25:00 --> Config Class Initialized
INFO - 2023-08-06 06:25:00 --> Hooks Class Initialized
DEBUG - 2023-08-06 06:25:00 --> UTF-8 Support Enabled
INFO - 2023-08-06 06:25:00 --> Utf8 Class Initialized
INFO - 2023-08-06 06:25:00 --> URI Class Initialized
DEBUG - 2023-08-06 06:25:00 --> No URI present. Default controller set.
INFO - 2023-08-06 06:25:00 --> Router Class Initialized
INFO - 2023-08-06 06:25:00 --> Output Class Initialized
INFO - 2023-08-06 06:25:00 --> Security Class Initialized
DEBUG - 2023-08-06 06:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 06:25:00 --> Input Class Initialized
INFO - 2023-08-06 06:25:00 --> Language Class Initialized
INFO - 2023-08-06 06:25:00 --> Loader Class Initialized
INFO - 2023-08-06 06:25:00 --> Helper loaded: url_helper
INFO - 2023-08-06 06:25:00 --> Helper loaded: file_helper
INFO - 2023-08-06 06:25:00 --> Helper loaded: html_helper
INFO - 2023-08-06 06:25:00 --> Helper loaded: text_helper
INFO - 2023-08-06 06:25:00 --> Helper loaded: form_helper
INFO - 2023-08-06 06:25:00 --> Helper loaded: lang_helper
INFO - 2023-08-06 06:25:00 --> Helper loaded: security_helper
INFO - 2023-08-06 06:25:00 --> Helper loaded: cookie_helper
INFO - 2023-08-06 06:25:00 --> Database Driver Class Initialized
INFO - 2023-08-06 06:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 06:25:00 --> Parser Class Initialized
INFO - 2023-08-06 06:25:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 06:25:00 --> Pagination Class Initialized
INFO - 2023-08-06 06:25:00 --> Form Validation Class Initialized
INFO - 2023-08-06 06:25:00 --> Controller Class Initialized
INFO - 2023-08-06 06:25:00 --> Model Class Initialized
DEBUG - 2023-08-06 06:25:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:25:00 --> Model Class Initialized
DEBUG - 2023-08-06 06:25:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:25:00 --> Model Class Initialized
INFO - 2023-08-06 06:25:00 --> Model Class Initialized
INFO - 2023-08-06 06:25:00 --> Model Class Initialized
INFO - 2023-08-06 06:25:00 --> Model Class Initialized
DEBUG - 2023-08-06 06:25:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 06:25:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:25:00 --> Model Class Initialized
INFO - 2023-08-06 06:25:00 --> Model Class Initialized
INFO - 2023-08-06 06:25:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-06 06:25:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:25:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 06:25:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 06:25:00 --> Model Class Initialized
INFO - 2023-08-06 06:25:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-06 06:25:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-06 06:25:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 06:25:00 --> Final output sent to browser
DEBUG - 2023-08-06 06:25:00 --> Total execution time: 0.0811
ERROR - 2023-08-06 06:25:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 06:25:25 --> Config Class Initialized
INFO - 2023-08-06 06:25:25 --> Hooks Class Initialized
DEBUG - 2023-08-06 06:25:25 --> UTF-8 Support Enabled
INFO - 2023-08-06 06:25:25 --> Utf8 Class Initialized
INFO - 2023-08-06 06:25:25 --> URI Class Initialized
DEBUG - 2023-08-06 06:25:25 --> No URI present. Default controller set.
INFO - 2023-08-06 06:25:25 --> Router Class Initialized
INFO - 2023-08-06 06:25:25 --> Output Class Initialized
INFO - 2023-08-06 06:25:25 --> Security Class Initialized
DEBUG - 2023-08-06 06:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 06:25:25 --> Input Class Initialized
INFO - 2023-08-06 06:25:25 --> Language Class Initialized
INFO - 2023-08-06 06:25:25 --> Loader Class Initialized
INFO - 2023-08-06 06:25:25 --> Helper loaded: url_helper
INFO - 2023-08-06 06:25:25 --> Helper loaded: file_helper
INFO - 2023-08-06 06:25:25 --> Helper loaded: html_helper
INFO - 2023-08-06 06:25:25 --> Helper loaded: text_helper
INFO - 2023-08-06 06:25:25 --> Helper loaded: form_helper
INFO - 2023-08-06 06:25:25 --> Helper loaded: lang_helper
INFO - 2023-08-06 06:25:25 --> Helper loaded: security_helper
INFO - 2023-08-06 06:25:25 --> Helper loaded: cookie_helper
INFO - 2023-08-06 06:25:25 --> Database Driver Class Initialized
INFO - 2023-08-06 06:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 06:25:25 --> Parser Class Initialized
INFO - 2023-08-06 06:25:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 06:25:25 --> Pagination Class Initialized
INFO - 2023-08-06 06:25:25 --> Form Validation Class Initialized
INFO - 2023-08-06 06:25:25 --> Controller Class Initialized
INFO - 2023-08-06 06:25:25 --> Model Class Initialized
DEBUG - 2023-08-06 06:25:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:25:25 --> Model Class Initialized
DEBUG - 2023-08-06 06:25:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:25:25 --> Model Class Initialized
INFO - 2023-08-06 06:25:25 --> Model Class Initialized
INFO - 2023-08-06 06:25:25 --> Model Class Initialized
INFO - 2023-08-06 06:25:25 --> Model Class Initialized
DEBUG - 2023-08-06 06:25:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 06:25:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:25:25 --> Model Class Initialized
INFO - 2023-08-06 06:25:25 --> Model Class Initialized
INFO - 2023-08-06 06:25:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-06 06:25:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:25:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 06:25:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 06:25:25 --> Model Class Initialized
INFO - 2023-08-06 06:25:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-06 06:25:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-06 06:25:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 06:25:25 --> Final output sent to browser
DEBUG - 2023-08-06 06:25:25 --> Total execution time: 0.0918
ERROR - 2023-08-06 06:26:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 06:26:24 --> Config Class Initialized
INFO - 2023-08-06 06:26:24 --> Hooks Class Initialized
DEBUG - 2023-08-06 06:26:24 --> UTF-8 Support Enabled
INFO - 2023-08-06 06:26:24 --> Utf8 Class Initialized
INFO - 2023-08-06 06:26:24 --> URI Class Initialized
DEBUG - 2023-08-06 06:26:24 --> No URI present. Default controller set.
INFO - 2023-08-06 06:26:24 --> Router Class Initialized
INFO - 2023-08-06 06:26:24 --> Output Class Initialized
INFO - 2023-08-06 06:26:24 --> Security Class Initialized
DEBUG - 2023-08-06 06:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 06:26:24 --> Input Class Initialized
INFO - 2023-08-06 06:26:24 --> Language Class Initialized
INFO - 2023-08-06 06:26:24 --> Loader Class Initialized
INFO - 2023-08-06 06:26:24 --> Helper loaded: url_helper
INFO - 2023-08-06 06:26:24 --> Helper loaded: file_helper
INFO - 2023-08-06 06:26:24 --> Helper loaded: html_helper
INFO - 2023-08-06 06:26:24 --> Helper loaded: text_helper
INFO - 2023-08-06 06:26:24 --> Helper loaded: form_helper
INFO - 2023-08-06 06:26:24 --> Helper loaded: lang_helper
INFO - 2023-08-06 06:26:24 --> Helper loaded: security_helper
INFO - 2023-08-06 06:26:24 --> Helper loaded: cookie_helper
INFO - 2023-08-06 06:26:24 --> Database Driver Class Initialized
INFO - 2023-08-06 06:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 06:26:24 --> Parser Class Initialized
INFO - 2023-08-06 06:26:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 06:26:24 --> Pagination Class Initialized
INFO - 2023-08-06 06:26:24 --> Form Validation Class Initialized
INFO - 2023-08-06 06:26:24 --> Controller Class Initialized
INFO - 2023-08-06 06:26:24 --> Model Class Initialized
DEBUG - 2023-08-06 06:26:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-06 06:26:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 06:26:28 --> Config Class Initialized
INFO - 2023-08-06 06:26:28 --> Hooks Class Initialized
DEBUG - 2023-08-06 06:26:28 --> UTF-8 Support Enabled
INFO - 2023-08-06 06:26:28 --> Utf8 Class Initialized
INFO - 2023-08-06 06:26:28 --> URI Class Initialized
INFO - 2023-08-06 06:26:28 --> Router Class Initialized
INFO - 2023-08-06 06:26:28 --> Output Class Initialized
INFO - 2023-08-06 06:26:28 --> Security Class Initialized
DEBUG - 2023-08-06 06:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 06:26:28 --> Input Class Initialized
INFO - 2023-08-06 06:26:28 --> Language Class Initialized
INFO - 2023-08-06 06:26:28 --> Loader Class Initialized
INFO - 2023-08-06 06:26:28 --> Helper loaded: url_helper
INFO - 2023-08-06 06:26:28 --> Helper loaded: file_helper
INFO - 2023-08-06 06:26:28 --> Helper loaded: html_helper
INFO - 2023-08-06 06:26:28 --> Helper loaded: text_helper
INFO - 2023-08-06 06:26:28 --> Helper loaded: form_helper
INFO - 2023-08-06 06:26:28 --> Helper loaded: lang_helper
INFO - 2023-08-06 06:26:28 --> Helper loaded: security_helper
INFO - 2023-08-06 06:26:28 --> Helper loaded: cookie_helper
INFO - 2023-08-06 06:26:28 --> Database Driver Class Initialized
INFO - 2023-08-06 06:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 06:26:28 --> Parser Class Initialized
INFO - 2023-08-06 06:26:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 06:26:28 --> Pagination Class Initialized
INFO - 2023-08-06 06:26:28 --> Form Validation Class Initialized
INFO - 2023-08-06 06:26:28 --> Controller Class Initialized
INFO - 2023-08-06 06:26:28 --> Model Class Initialized
DEBUG - 2023-08-06 06:26:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:26:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-06 06:26:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:26:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 06:26:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 06:26:28 --> Model Class Initialized
INFO - 2023-08-06 06:26:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 06:26:28 --> Final output sent to browser
DEBUG - 2023-08-06 06:26:28 --> Total execution time: 0.0309
ERROR - 2023-08-06 06:30:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 06:30:57 --> Config Class Initialized
INFO - 2023-08-06 06:30:57 --> Hooks Class Initialized
DEBUG - 2023-08-06 06:30:57 --> UTF-8 Support Enabled
INFO - 2023-08-06 06:30:57 --> Utf8 Class Initialized
INFO - 2023-08-06 06:30:57 --> URI Class Initialized
DEBUG - 2023-08-06 06:30:57 --> No URI present. Default controller set.
INFO - 2023-08-06 06:30:57 --> Router Class Initialized
INFO - 2023-08-06 06:30:57 --> Output Class Initialized
INFO - 2023-08-06 06:30:57 --> Security Class Initialized
DEBUG - 2023-08-06 06:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 06:30:57 --> Input Class Initialized
INFO - 2023-08-06 06:30:57 --> Language Class Initialized
INFO - 2023-08-06 06:30:57 --> Loader Class Initialized
INFO - 2023-08-06 06:30:57 --> Helper loaded: url_helper
INFO - 2023-08-06 06:30:57 --> Helper loaded: file_helper
INFO - 2023-08-06 06:30:57 --> Helper loaded: html_helper
INFO - 2023-08-06 06:30:57 --> Helper loaded: text_helper
INFO - 2023-08-06 06:30:57 --> Helper loaded: form_helper
INFO - 2023-08-06 06:30:57 --> Helper loaded: lang_helper
INFO - 2023-08-06 06:30:57 --> Helper loaded: security_helper
INFO - 2023-08-06 06:30:57 --> Helper loaded: cookie_helper
INFO - 2023-08-06 06:30:57 --> Database Driver Class Initialized
INFO - 2023-08-06 06:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 06:30:57 --> Parser Class Initialized
INFO - 2023-08-06 06:30:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 06:30:57 --> Pagination Class Initialized
INFO - 2023-08-06 06:30:57 --> Form Validation Class Initialized
INFO - 2023-08-06 06:30:57 --> Controller Class Initialized
INFO - 2023-08-06 06:30:57 --> Model Class Initialized
DEBUG - 2023-08-06 06:30:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:30:57 --> Model Class Initialized
DEBUG - 2023-08-06 06:30:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:30:57 --> Model Class Initialized
INFO - 2023-08-06 06:30:57 --> Model Class Initialized
INFO - 2023-08-06 06:30:57 --> Model Class Initialized
INFO - 2023-08-06 06:30:57 --> Model Class Initialized
DEBUG - 2023-08-06 06:30:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 06:30:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:30:57 --> Model Class Initialized
INFO - 2023-08-06 06:30:57 --> Model Class Initialized
INFO - 2023-08-06 06:30:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-06 06:30:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:30:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 06:30:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 06:30:57 --> Model Class Initialized
INFO - 2023-08-06 06:30:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-06 06:30:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-06 06:30:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 06:30:57 --> Final output sent to browser
DEBUG - 2023-08-06 06:30:57 --> Total execution time: 0.1865
ERROR - 2023-08-06 06:31:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 06:31:10 --> Config Class Initialized
INFO - 2023-08-06 06:31:10 --> Hooks Class Initialized
DEBUG - 2023-08-06 06:31:10 --> UTF-8 Support Enabled
INFO - 2023-08-06 06:31:10 --> Utf8 Class Initialized
INFO - 2023-08-06 06:31:10 --> URI Class Initialized
INFO - 2023-08-06 06:31:10 --> Router Class Initialized
INFO - 2023-08-06 06:31:10 --> Output Class Initialized
INFO - 2023-08-06 06:31:10 --> Security Class Initialized
DEBUG - 2023-08-06 06:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 06:31:10 --> Input Class Initialized
INFO - 2023-08-06 06:31:10 --> Language Class Initialized
INFO - 2023-08-06 06:31:10 --> Loader Class Initialized
INFO - 2023-08-06 06:31:10 --> Helper loaded: url_helper
INFO - 2023-08-06 06:31:10 --> Helper loaded: file_helper
INFO - 2023-08-06 06:31:10 --> Helper loaded: html_helper
INFO - 2023-08-06 06:31:10 --> Helper loaded: text_helper
INFO - 2023-08-06 06:31:10 --> Helper loaded: form_helper
INFO - 2023-08-06 06:31:10 --> Helper loaded: lang_helper
INFO - 2023-08-06 06:31:10 --> Helper loaded: security_helper
INFO - 2023-08-06 06:31:10 --> Helper loaded: cookie_helper
INFO - 2023-08-06 06:31:10 --> Database Driver Class Initialized
INFO - 2023-08-06 06:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 06:31:10 --> Parser Class Initialized
INFO - 2023-08-06 06:31:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 06:31:10 --> Pagination Class Initialized
INFO - 2023-08-06 06:31:10 --> Form Validation Class Initialized
INFO - 2023-08-06 06:31:10 --> Controller Class Initialized
INFO - 2023-08-06 06:31:10 --> Model Class Initialized
DEBUG - 2023-08-06 06:31:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 06:31:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:31:10 --> Model Class Initialized
DEBUG - 2023-08-06 06:31:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:31:10 --> Model Class Initialized
INFO - 2023-08-06 06:31:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-06 06:31:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:31:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 06:31:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 06:31:10 --> Model Class Initialized
INFO - 2023-08-06 06:31:10 --> Model Class Initialized
INFO - 2023-08-06 06:31:10 --> Model Class Initialized
INFO - 2023-08-06 06:31:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-06 06:31:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-06 06:31:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 06:31:10 --> Final output sent to browser
DEBUG - 2023-08-06 06:31:10 --> Total execution time: 0.0765
ERROR - 2023-08-06 06:31:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 06:31:10 --> Config Class Initialized
INFO - 2023-08-06 06:31:10 --> Hooks Class Initialized
DEBUG - 2023-08-06 06:31:10 --> UTF-8 Support Enabled
INFO - 2023-08-06 06:31:10 --> Utf8 Class Initialized
INFO - 2023-08-06 06:31:10 --> URI Class Initialized
INFO - 2023-08-06 06:31:10 --> Router Class Initialized
INFO - 2023-08-06 06:31:10 --> Output Class Initialized
INFO - 2023-08-06 06:31:10 --> Security Class Initialized
DEBUG - 2023-08-06 06:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 06:31:10 --> Input Class Initialized
INFO - 2023-08-06 06:31:10 --> Language Class Initialized
INFO - 2023-08-06 06:31:10 --> Loader Class Initialized
INFO - 2023-08-06 06:31:10 --> Helper loaded: url_helper
INFO - 2023-08-06 06:31:10 --> Helper loaded: file_helper
INFO - 2023-08-06 06:31:10 --> Helper loaded: html_helper
INFO - 2023-08-06 06:31:10 --> Helper loaded: text_helper
INFO - 2023-08-06 06:31:10 --> Helper loaded: form_helper
INFO - 2023-08-06 06:31:10 --> Helper loaded: lang_helper
INFO - 2023-08-06 06:31:10 --> Helper loaded: security_helper
INFO - 2023-08-06 06:31:10 --> Helper loaded: cookie_helper
INFO - 2023-08-06 06:31:10 --> Database Driver Class Initialized
INFO - 2023-08-06 06:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 06:31:10 --> Parser Class Initialized
INFO - 2023-08-06 06:31:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 06:31:10 --> Pagination Class Initialized
INFO - 2023-08-06 06:31:10 --> Form Validation Class Initialized
INFO - 2023-08-06 06:31:10 --> Controller Class Initialized
INFO - 2023-08-06 06:31:10 --> Model Class Initialized
DEBUG - 2023-08-06 06:31:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 06:31:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:31:10 --> Model Class Initialized
DEBUG - 2023-08-06 06:31:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:31:10 --> Model Class Initialized
INFO - 2023-08-06 06:31:10 --> Final output sent to browser
DEBUG - 2023-08-06 06:31:10 --> Total execution time: 0.0385
ERROR - 2023-08-06 06:31:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 06:31:25 --> Config Class Initialized
INFO - 2023-08-06 06:31:25 --> Hooks Class Initialized
DEBUG - 2023-08-06 06:31:25 --> UTF-8 Support Enabled
INFO - 2023-08-06 06:31:25 --> Utf8 Class Initialized
INFO - 2023-08-06 06:31:25 --> URI Class Initialized
INFO - 2023-08-06 06:31:25 --> Router Class Initialized
INFO - 2023-08-06 06:31:25 --> Output Class Initialized
INFO - 2023-08-06 06:31:25 --> Security Class Initialized
DEBUG - 2023-08-06 06:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 06:31:25 --> Input Class Initialized
INFO - 2023-08-06 06:31:25 --> Language Class Initialized
INFO - 2023-08-06 06:31:25 --> Loader Class Initialized
INFO - 2023-08-06 06:31:25 --> Helper loaded: url_helper
INFO - 2023-08-06 06:31:25 --> Helper loaded: file_helper
INFO - 2023-08-06 06:31:25 --> Helper loaded: html_helper
INFO - 2023-08-06 06:31:25 --> Helper loaded: text_helper
INFO - 2023-08-06 06:31:25 --> Helper loaded: form_helper
INFO - 2023-08-06 06:31:25 --> Helper loaded: lang_helper
INFO - 2023-08-06 06:31:25 --> Helper loaded: security_helper
INFO - 2023-08-06 06:31:25 --> Helper loaded: cookie_helper
INFO - 2023-08-06 06:31:25 --> Database Driver Class Initialized
INFO - 2023-08-06 06:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 06:31:25 --> Parser Class Initialized
INFO - 2023-08-06 06:31:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 06:31:25 --> Pagination Class Initialized
INFO - 2023-08-06 06:31:25 --> Form Validation Class Initialized
INFO - 2023-08-06 06:31:25 --> Controller Class Initialized
INFO - 2023-08-06 06:31:25 --> Model Class Initialized
DEBUG - 2023-08-06 06:31:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 06:31:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:31:25 --> Model Class Initialized
DEBUG - 2023-08-06 06:31:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:31:25 --> Model Class Initialized
INFO - 2023-08-06 06:31:25 --> Final output sent to browser
DEBUG - 2023-08-06 06:31:25 --> Total execution time: 0.0422
ERROR - 2023-08-06 06:31:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 06:31:27 --> Config Class Initialized
INFO - 2023-08-06 06:31:27 --> Hooks Class Initialized
DEBUG - 2023-08-06 06:31:27 --> UTF-8 Support Enabled
INFO - 2023-08-06 06:31:27 --> Utf8 Class Initialized
INFO - 2023-08-06 06:31:27 --> URI Class Initialized
INFO - 2023-08-06 06:31:27 --> Router Class Initialized
INFO - 2023-08-06 06:31:27 --> Output Class Initialized
INFO - 2023-08-06 06:31:27 --> Security Class Initialized
DEBUG - 2023-08-06 06:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 06:31:27 --> Input Class Initialized
INFO - 2023-08-06 06:31:27 --> Language Class Initialized
INFO - 2023-08-06 06:31:27 --> Loader Class Initialized
INFO - 2023-08-06 06:31:27 --> Helper loaded: url_helper
INFO - 2023-08-06 06:31:27 --> Helper loaded: file_helper
INFO - 2023-08-06 06:31:27 --> Helper loaded: html_helper
INFO - 2023-08-06 06:31:27 --> Helper loaded: text_helper
INFO - 2023-08-06 06:31:27 --> Helper loaded: form_helper
INFO - 2023-08-06 06:31:27 --> Helper loaded: lang_helper
INFO - 2023-08-06 06:31:27 --> Helper loaded: security_helper
INFO - 2023-08-06 06:31:27 --> Helper loaded: cookie_helper
INFO - 2023-08-06 06:31:27 --> Database Driver Class Initialized
INFO - 2023-08-06 06:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 06:31:27 --> Parser Class Initialized
INFO - 2023-08-06 06:31:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 06:31:27 --> Pagination Class Initialized
INFO - 2023-08-06 06:31:27 --> Form Validation Class Initialized
INFO - 2023-08-06 06:31:27 --> Controller Class Initialized
INFO - 2023-08-06 06:31:27 --> Model Class Initialized
DEBUG - 2023-08-06 06:31:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 06:31:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:31:27 --> Model Class Initialized
DEBUG - 2023-08-06 06:31:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 06:31:27 --> Model Class Initialized
INFO - 2023-08-06 06:31:27 --> Final output sent to browser
DEBUG - 2023-08-06 06:31:27 --> Total execution time: 0.0372
ERROR - 2023-08-06 07:56:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 07:56:24 --> Config Class Initialized
INFO - 2023-08-06 07:56:24 --> Hooks Class Initialized
DEBUG - 2023-08-06 07:56:24 --> UTF-8 Support Enabled
INFO - 2023-08-06 07:56:24 --> Utf8 Class Initialized
INFO - 2023-08-06 07:56:24 --> URI Class Initialized
DEBUG - 2023-08-06 07:56:24 --> No URI present. Default controller set.
INFO - 2023-08-06 07:56:24 --> Router Class Initialized
INFO - 2023-08-06 07:56:24 --> Output Class Initialized
INFO - 2023-08-06 07:56:24 --> Security Class Initialized
DEBUG - 2023-08-06 07:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 07:56:24 --> Input Class Initialized
INFO - 2023-08-06 07:56:24 --> Language Class Initialized
INFO - 2023-08-06 07:56:24 --> Loader Class Initialized
INFO - 2023-08-06 07:56:24 --> Helper loaded: url_helper
INFO - 2023-08-06 07:56:24 --> Helper loaded: file_helper
INFO - 2023-08-06 07:56:24 --> Helper loaded: html_helper
INFO - 2023-08-06 07:56:24 --> Helper loaded: text_helper
INFO - 2023-08-06 07:56:24 --> Helper loaded: form_helper
INFO - 2023-08-06 07:56:24 --> Helper loaded: lang_helper
INFO - 2023-08-06 07:56:24 --> Helper loaded: security_helper
INFO - 2023-08-06 07:56:24 --> Helper loaded: cookie_helper
INFO - 2023-08-06 07:56:24 --> Database Driver Class Initialized
INFO - 2023-08-06 07:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 07:56:24 --> Parser Class Initialized
INFO - 2023-08-06 07:56:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 07:56:24 --> Pagination Class Initialized
INFO - 2023-08-06 07:56:24 --> Form Validation Class Initialized
INFO - 2023-08-06 07:56:24 --> Controller Class Initialized
INFO - 2023-08-06 07:56:24 --> Model Class Initialized
DEBUG - 2023-08-06 07:56:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-06 07:56:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 07:56:25 --> Config Class Initialized
INFO - 2023-08-06 07:56:25 --> Hooks Class Initialized
DEBUG - 2023-08-06 07:56:25 --> UTF-8 Support Enabled
INFO - 2023-08-06 07:56:25 --> Utf8 Class Initialized
INFO - 2023-08-06 07:56:25 --> URI Class Initialized
INFO - 2023-08-06 07:56:25 --> Router Class Initialized
INFO - 2023-08-06 07:56:25 --> Output Class Initialized
INFO - 2023-08-06 07:56:25 --> Security Class Initialized
DEBUG - 2023-08-06 07:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 07:56:25 --> Input Class Initialized
INFO - 2023-08-06 07:56:25 --> Language Class Initialized
INFO - 2023-08-06 07:56:25 --> Loader Class Initialized
INFO - 2023-08-06 07:56:25 --> Helper loaded: url_helper
INFO - 2023-08-06 07:56:25 --> Helper loaded: file_helper
INFO - 2023-08-06 07:56:25 --> Helper loaded: html_helper
INFO - 2023-08-06 07:56:25 --> Helper loaded: text_helper
INFO - 2023-08-06 07:56:25 --> Helper loaded: form_helper
INFO - 2023-08-06 07:56:25 --> Helper loaded: lang_helper
INFO - 2023-08-06 07:56:25 --> Helper loaded: security_helper
INFO - 2023-08-06 07:56:25 --> Helper loaded: cookie_helper
INFO - 2023-08-06 07:56:25 --> Database Driver Class Initialized
INFO - 2023-08-06 07:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 07:56:25 --> Parser Class Initialized
INFO - 2023-08-06 07:56:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 07:56:25 --> Pagination Class Initialized
INFO - 2023-08-06 07:56:25 --> Form Validation Class Initialized
INFO - 2023-08-06 07:56:25 --> Controller Class Initialized
INFO - 2023-08-06 07:56:25 --> Model Class Initialized
DEBUG - 2023-08-06 07:56:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 07:56:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-06 07:56:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 07:56:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 07:56:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 07:56:25 --> Model Class Initialized
INFO - 2023-08-06 07:56:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 07:56:25 --> Final output sent to browser
DEBUG - 2023-08-06 07:56:25 --> Total execution time: 0.0344
ERROR - 2023-08-06 07:57:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 07:57:29 --> Config Class Initialized
INFO - 2023-08-06 07:57:29 --> Hooks Class Initialized
DEBUG - 2023-08-06 07:57:29 --> UTF-8 Support Enabled
INFO - 2023-08-06 07:57:29 --> Utf8 Class Initialized
INFO - 2023-08-06 07:57:29 --> URI Class Initialized
INFO - 2023-08-06 07:57:29 --> Router Class Initialized
INFO - 2023-08-06 07:57:29 --> Output Class Initialized
INFO - 2023-08-06 07:57:29 --> Security Class Initialized
DEBUG - 2023-08-06 07:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 07:57:29 --> Input Class Initialized
INFO - 2023-08-06 07:57:29 --> Language Class Initialized
INFO - 2023-08-06 07:57:29 --> Loader Class Initialized
INFO - 2023-08-06 07:57:29 --> Helper loaded: url_helper
INFO - 2023-08-06 07:57:29 --> Helper loaded: file_helper
INFO - 2023-08-06 07:57:29 --> Helper loaded: html_helper
INFO - 2023-08-06 07:57:29 --> Helper loaded: text_helper
INFO - 2023-08-06 07:57:29 --> Helper loaded: form_helper
INFO - 2023-08-06 07:57:29 --> Helper loaded: lang_helper
INFO - 2023-08-06 07:57:29 --> Helper loaded: security_helper
INFO - 2023-08-06 07:57:29 --> Helper loaded: cookie_helper
INFO - 2023-08-06 07:57:29 --> Database Driver Class Initialized
INFO - 2023-08-06 07:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 07:57:29 --> Parser Class Initialized
INFO - 2023-08-06 07:57:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 07:57:29 --> Pagination Class Initialized
INFO - 2023-08-06 07:57:29 --> Form Validation Class Initialized
INFO - 2023-08-06 07:57:29 --> Controller Class Initialized
INFO - 2023-08-06 07:57:29 --> Model Class Initialized
DEBUG - 2023-08-06 07:57:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 07:57:29 --> Model Class Initialized
INFO - 2023-08-06 07:57:29 --> Final output sent to browser
DEBUG - 2023-08-06 07:57:29 --> Total execution time: 0.0216
ERROR - 2023-08-06 07:57:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 07:57:29 --> Config Class Initialized
INFO - 2023-08-06 07:57:29 --> Hooks Class Initialized
DEBUG - 2023-08-06 07:57:29 --> UTF-8 Support Enabled
INFO - 2023-08-06 07:57:29 --> Utf8 Class Initialized
INFO - 2023-08-06 07:57:29 --> URI Class Initialized
INFO - 2023-08-06 07:57:29 --> Router Class Initialized
INFO - 2023-08-06 07:57:29 --> Output Class Initialized
INFO - 2023-08-06 07:57:29 --> Security Class Initialized
DEBUG - 2023-08-06 07:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 07:57:29 --> Input Class Initialized
INFO - 2023-08-06 07:57:29 --> Language Class Initialized
INFO - 2023-08-06 07:57:29 --> Loader Class Initialized
INFO - 2023-08-06 07:57:29 --> Helper loaded: url_helper
INFO - 2023-08-06 07:57:29 --> Helper loaded: file_helper
INFO - 2023-08-06 07:57:29 --> Helper loaded: html_helper
INFO - 2023-08-06 07:57:29 --> Helper loaded: text_helper
INFO - 2023-08-06 07:57:29 --> Helper loaded: form_helper
INFO - 2023-08-06 07:57:29 --> Helper loaded: lang_helper
INFO - 2023-08-06 07:57:29 --> Helper loaded: security_helper
INFO - 2023-08-06 07:57:29 --> Helper loaded: cookie_helper
INFO - 2023-08-06 07:57:29 --> Database Driver Class Initialized
INFO - 2023-08-06 07:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 07:57:29 --> Parser Class Initialized
INFO - 2023-08-06 07:57:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 07:57:29 --> Pagination Class Initialized
INFO - 2023-08-06 07:57:29 --> Form Validation Class Initialized
INFO - 2023-08-06 07:57:29 --> Controller Class Initialized
INFO - 2023-08-06 07:57:29 --> Model Class Initialized
DEBUG - 2023-08-06 07:57:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 07:57:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-06 07:57:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 07:57:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 07:57:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 07:57:29 --> Model Class Initialized
INFO - 2023-08-06 07:57:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 07:57:29 --> Final output sent to browser
DEBUG - 2023-08-06 07:57:29 --> Total execution time: 0.0292
ERROR - 2023-08-06 07:58:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 07:58:01 --> Config Class Initialized
INFO - 2023-08-06 07:58:01 --> Hooks Class Initialized
DEBUG - 2023-08-06 07:58:01 --> UTF-8 Support Enabled
INFO - 2023-08-06 07:58:01 --> Utf8 Class Initialized
INFO - 2023-08-06 07:58:01 --> URI Class Initialized
INFO - 2023-08-06 07:58:01 --> Router Class Initialized
INFO - 2023-08-06 07:58:01 --> Output Class Initialized
INFO - 2023-08-06 07:58:01 --> Security Class Initialized
DEBUG - 2023-08-06 07:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 07:58:01 --> Input Class Initialized
INFO - 2023-08-06 07:58:01 --> Language Class Initialized
INFO - 2023-08-06 07:58:01 --> Loader Class Initialized
INFO - 2023-08-06 07:58:01 --> Helper loaded: url_helper
INFO - 2023-08-06 07:58:01 --> Helper loaded: file_helper
INFO - 2023-08-06 07:58:01 --> Helper loaded: html_helper
INFO - 2023-08-06 07:58:01 --> Helper loaded: text_helper
INFO - 2023-08-06 07:58:01 --> Helper loaded: form_helper
INFO - 2023-08-06 07:58:01 --> Helper loaded: lang_helper
INFO - 2023-08-06 07:58:01 --> Helper loaded: security_helper
INFO - 2023-08-06 07:58:01 --> Helper loaded: cookie_helper
INFO - 2023-08-06 07:58:01 --> Database Driver Class Initialized
INFO - 2023-08-06 07:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 07:58:01 --> Parser Class Initialized
INFO - 2023-08-06 07:58:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 07:58:01 --> Pagination Class Initialized
INFO - 2023-08-06 07:58:01 --> Form Validation Class Initialized
INFO - 2023-08-06 07:58:01 --> Controller Class Initialized
INFO - 2023-08-06 07:58:01 --> Model Class Initialized
DEBUG - 2023-08-06 07:58:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 07:58:01 --> Model Class Initialized
INFO - 2023-08-06 07:58:01 --> Final output sent to browser
DEBUG - 2023-08-06 07:58:01 --> Total execution time: 0.0190
ERROR - 2023-08-06 07:58:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 07:58:02 --> Config Class Initialized
INFO - 2023-08-06 07:58:02 --> Hooks Class Initialized
DEBUG - 2023-08-06 07:58:02 --> UTF-8 Support Enabled
INFO - 2023-08-06 07:58:02 --> Utf8 Class Initialized
INFO - 2023-08-06 07:58:02 --> URI Class Initialized
INFO - 2023-08-06 07:58:02 --> Router Class Initialized
INFO - 2023-08-06 07:58:02 --> Output Class Initialized
INFO - 2023-08-06 07:58:02 --> Security Class Initialized
DEBUG - 2023-08-06 07:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 07:58:02 --> Input Class Initialized
INFO - 2023-08-06 07:58:02 --> Language Class Initialized
INFO - 2023-08-06 07:58:02 --> Loader Class Initialized
INFO - 2023-08-06 07:58:02 --> Helper loaded: url_helper
INFO - 2023-08-06 07:58:02 --> Helper loaded: file_helper
INFO - 2023-08-06 07:58:02 --> Helper loaded: html_helper
INFO - 2023-08-06 07:58:02 --> Helper loaded: text_helper
INFO - 2023-08-06 07:58:02 --> Helper loaded: form_helper
INFO - 2023-08-06 07:58:02 --> Helper loaded: lang_helper
INFO - 2023-08-06 07:58:02 --> Helper loaded: security_helper
INFO - 2023-08-06 07:58:02 --> Helper loaded: cookie_helper
INFO - 2023-08-06 07:58:02 --> Database Driver Class Initialized
INFO - 2023-08-06 07:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 07:58:02 --> Parser Class Initialized
INFO - 2023-08-06 07:58:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 07:58:02 --> Pagination Class Initialized
INFO - 2023-08-06 07:58:02 --> Form Validation Class Initialized
INFO - 2023-08-06 07:58:02 --> Controller Class Initialized
INFO - 2023-08-06 07:58:02 --> Model Class Initialized
DEBUG - 2023-08-06 07:58:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 07:58:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-06 07:58:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 07:58:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 07:58:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 07:58:02 --> Model Class Initialized
INFO - 2023-08-06 07:58:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 07:58:02 --> Final output sent to browser
DEBUG - 2023-08-06 07:58:02 --> Total execution time: 0.0310
ERROR - 2023-08-06 09:04:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 09:04:40 --> Config Class Initialized
INFO - 2023-08-06 09:04:40 --> Hooks Class Initialized
DEBUG - 2023-08-06 09:04:40 --> UTF-8 Support Enabled
INFO - 2023-08-06 09:04:40 --> Utf8 Class Initialized
INFO - 2023-08-06 09:04:40 --> URI Class Initialized
DEBUG - 2023-08-06 09:04:40 --> No URI present. Default controller set.
INFO - 2023-08-06 09:04:40 --> Router Class Initialized
INFO - 2023-08-06 09:04:40 --> Output Class Initialized
INFO - 2023-08-06 09:04:40 --> Security Class Initialized
DEBUG - 2023-08-06 09:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 09:04:40 --> Input Class Initialized
INFO - 2023-08-06 09:04:40 --> Language Class Initialized
INFO - 2023-08-06 09:04:40 --> Loader Class Initialized
INFO - 2023-08-06 09:04:40 --> Helper loaded: url_helper
INFO - 2023-08-06 09:04:40 --> Helper loaded: file_helper
INFO - 2023-08-06 09:04:40 --> Helper loaded: html_helper
INFO - 2023-08-06 09:04:40 --> Helper loaded: text_helper
INFO - 2023-08-06 09:04:40 --> Helper loaded: form_helper
INFO - 2023-08-06 09:04:40 --> Helper loaded: lang_helper
INFO - 2023-08-06 09:04:40 --> Helper loaded: security_helper
INFO - 2023-08-06 09:04:40 --> Helper loaded: cookie_helper
INFO - 2023-08-06 09:04:40 --> Database Driver Class Initialized
INFO - 2023-08-06 09:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 09:04:40 --> Parser Class Initialized
INFO - 2023-08-06 09:04:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 09:04:40 --> Pagination Class Initialized
INFO - 2023-08-06 09:04:40 --> Form Validation Class Initialized
INFO - 2023-08-06 09:04:40 --> Controller Class Initialized
INFO - 2023-08-06 09:04:40 --> Model Class Initialized
DEBUG - 2023-08-06 09:04:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-06 09:04:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 09:04:40 --> Config Class Initialized
INFO - 2023-08-06 09:04:40 --> Hooks Class Initialized
DEBUG - 2023-08-06 09:04:40 --> UTF-8 Support Enabled
INFO - 2023-08-06 09:04:40 --> Utf8 Class Initialized
INFO - 2023-08-06 09:04:40 --> URI Class Initialized
INFO - 2023-08-06 09:04:40 --> Router Class Initialized
INFO - 2023-08-06 09:04:40 --> Output Class Initialized
INFO - 2023-08-06 09:04:40 --> Security Class Initialized
DEBUG - 2023-08-06 09:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 09:04:40 --> Input Class Initialized
INFO - 2023-08-06 09:04:40 --> Language Class Initialized
INFO - 2023-08-06 09:04:40 --> Loader Class Initialized
INFO - 2023-08-06 09:04:40 --> Helper loaded: url_helper
INFO - 2023-08-06 09:04:40 --> Helper loaded: file_helper
INFO - 2023-08-06 09:04:40 --> Helper loaded: html_helper
INFO - 2023-08-06 09:04:40 --> Helper loaded: text_helper
INFO - 2023-08-06 09:04:40 --> Helper loaded: form_helper
INFO - 2023-08-06 09:04:40 --> Helper loaded: lang_helper
INFO - 2023-08-06 09:04:40 --> Helper loaded: security_helper
INFO - 2023-08-06 09:04:40 --> Helper loaded: cookie_helper
INFO - 2023-08-06 09:04:40 --> Database Driver Class Initialized
INFO - 2023-08-06 09:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 09:04:40 --> Parser Class Initialized
INFO - 2023-08-06 09:04:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 09:04:40 --> Pagination Class Initialized
INFO - 2023-08-06 09:04:40 --> Form Validation Class Initialized
INFO - 2023-08-06 09:04:40 --> Controller Class Initialized
INFO - 2023-08-06 09:04:40 --> Model Class Initialized
DEBUG - 2023-08-06 09:04:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 09:04:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-06 09:04:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 09:04:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 09:04:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 09:04:40 --> Model Class Initialized
INFO - 2023-08-06 09:04:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 09:04:40 --> Final output sent to browser
DEBUG - 2023-08-06 09:04:40 --> Total execution time: 0.0343
ERROR - 2023-08-06 11:23:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 11:23:04 --> Config Class Initialized
INFO - 2023-08-06 11:23:04 --> Hooks Class Initialized
DEBUG - 2023-08-06 11:23:04 --> UTF-8 Support Enabled
INFO - 2023-08-06 11:23:04 --> Utf8 Class Initialized
INFO - 2023-08-06 11:23:04 --> URI Class Initialized
DEBUG - 2023-08-06 11:23:04 --> No URI present. Default controller set.
INFO - 2023-08-06 11:23:04 --> Router Class Initialized
INFO - 2023-08-06 11:23:04 --> Output Class Initialized
INFO - 2023-08-06 11:23:04 --> Security Class Initialized
DEBUG - 2023-08-06 11:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 11:23:04 --> Input Class Initialized
INFO - 2023-08-06 11:23:04 --> Language Class Initialized
INFO - 2023-08-06 11:23:04 --> Loader Class Initialized
INFO - 2023-08-06 11:23:04 --> Helper loaded: url_helper
INFO - 2023-08-06 11:23:04 --> Helper loaded: file_helper
INFO - 2023-08-06 11:23:04 --> Helper loaded: html_helper
INFO - 2023-08-06 11:23:04 --> Helper loaded: text_helper
INFO - 2023-08-06 11:23:04 --> Helper loaded: form_helper
INFO - 2023-08-06 11:23:04 --> Helper loaded: lang_helper
INFO - 2023-08-06 11:23:04 --> Helper loaded: security_helper
INFO - 2023-08-06 11:23:04 --> Helper loaded: cookie_helper
INFO - 2023-08-06 11:23:04 --> Database Driver Class Initialized
INFO - 2023-08-06 11:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 11:23:04 --> Parser Class Initialized
INFO - 2023-08-06 11:23:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 11:23:04 --> Pagination Class Initialized
INFO - 2023-08-06 11:23:04 --> Form Validation Class Initialized
INFO - 2023-08-06 11:23:04 --> Controller Class Initialized
INFO - 2023-08-06 11:23:04 --> Model Class Initialized
DEBUG - 2023-08-06 11:23:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-06 11:23:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 11:23:04 --> Config Class Initialized
INFO - 2023-08-06 11:23:04 --> Hooks Class Initialized
DEBUG - 2023-08-06 11:23:04 --> UTF-8 Support Enabled
INFO - 2023-08-06 11:23:04 --> Utf8 Class Initialized
INFO - 2023-08-06 11:23:04 --> URI Class Initialized
INFO - 2023-08-06 11:23:04 --> Router Class Initialized
INFO - 2023-08-06 11:23:04 --> Output Class Initialized
INFO - 2023-08-06 11:23:04 --> Security Class Initialized
DEBUG - 2023-08-06 11:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 11:23:04 --> Input Class Initialized
INFO - 2023-08-06 11:23:04 --> Language Class Initialized
INFO - 2023-08-06 11:23:04 --> Loader Class Initialized
INFO - 2023-08-06 11:23:04 --> Helper loaded: url_helper
INFO - 2023-08-06 11:23:04 --> Helper loaded: file_helper
INFO - 2023-08-06 11:23:04 --> Helper loaded: html_helper
INFO - 2023-08-06 11:23:04 --> Helper loaded: text_helper
INFO - 2023-08-06 11:23:04 --> Helper loaded: form_helper
INFO - 2023-08-06 11:23:04 --> Helper loaded: lang_helper
INFO - 2023-08-06 11:23:04 --> Helper loaded: security_helper
INFO - 2023-08-06 11:23:04 --> Helper loaded: cookie_helper
INFO - 2023-08-06 11:23:04 --> Database Driver Class Initialized
INFO - 2023-08-06 11:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 11:23:04 --> Parser Class Initialized
INFO - 2023-08-06 11:23:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 11:23:04 --> Pagination Class Initialized
INFO - 2023-08-06 11:23:04 --> Form Validation Class Initialized
INFO - 2023-08-06 11:23:04 --> Controller Class Initialized
INFO - 2023-08-06 11:23:04 --> Model Class Initialized
DEBUG - 2023-08-06 11:23:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 11:23:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-06 11:23:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 11:23:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 11:23:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 11:23:04 --> Model Class Initialized
INFO - 2023-08-06 11:23:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 11:23:04 --> Final output sent to browser
DEBUG - 2023-08-06 11:23:04 --> Total execution time: 0.0439
ERROR - 2023-08-06 12:23:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 12:23:00 --> Config Class Initialized
INFO - 2023-08-06 12:23:00 --> Hooks Class Initialized
DEBUG - 2023-08-06 12:23:00 --> UTF-8 Support Enabled
INFO - 2023-08-06 12:23:00 --> Utf8 Class Initialized
INFO - 2023-08-06 12:23:00 --> URI Class Initialized
DEBUG - 2023-08-06 12:23:00 --> No URI present. Default controller set.
INFO - 2023-08-06 12:23:00 --> Router Class Initialized
INFO - 2023-08-06 12:23:00 --> Output Class Initialized
INFO - 2023-08-06 12:23:00 --> Security Class Initialized
DEBUG - 2023-08-06 12:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 12:23:00 --> Input Class Initialized
INFO - 2023-08-06 12:23:00 --> Language Class Initialized
INFO - 2023-08-06 12:23:00 --> Loader Class Initialized
INFO - 2023-08-06 12:23:00 --> Helper loaded: url_helper
INFO - 2023-08-06 12:23:00 --> Helper loaded: file_helper
INFO - 2023-08-06 12:23:00 --> Helper loaded: html_helper
INFO - 2023-08-06 12:23:00 --> Helper loaded: text_helper
INFO - 2023-08-06 12:23:00 --> Helper loaded: form_helper
INFO - 2023-08-06 12:23:00 --> Helper loaded: lang_helper
INFO - 2023-08-06 12:23:00 --> Helper loaded: security_helper
INFO - 2023-08-06 12:23:00 --> Helper loaded: cookie_helper
INFO - 2023-08-06 12:23:00 --> Database Driver Class Initialized
INFO - 2023-08-06 12:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 12:23:00 --> Parser Class Initialized
INFO - 2023-08-06 12:23:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 12:23:00 --> Pagination Class Initialized
INFO - 2023-08-06 12:23:00 --> Form Validation Class Initialized
INFO - 2023-08-06 12:23:00 --> Controller Class Initialized
INFO - 2023-08-06 12:23:00 --> Model Class Initialized
DEBUG - 2023-08-06 12:23:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-06 12:23:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 12:23:00 --> Config Class Initialized
INFO - 2023-08-06 12:23:00 --> Hooks Class Initialized
DEBUG - 2023-08-06 12:23:00 --> UTF-8 Support Enabled
INFO - 2023-08-06 12:23:00 --> Utf8 Class Initialized
INFO - 2023-08-06 12:23:00 --> URI Class Initialized
INFO - 2023-08-06 12:23:00 --> Router Class Initialized
INFO - 2023-08-06 12:23:00 --> Output Class Initialized
INFO - 2023-08-06 12:23:00 --> Security Class Initialized
DEBUG - 2023-08-06 12:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 12:23:00 --> Input Class Initialized
INFO - 2023-08-06 12:23:00 --> Language Class Initialized
INFO - 2023-08-06 12:23:00 --> Loader Class Initialized
INFO - 2023-08-06 12:23:00 --> Helper loaded: url_helper
INFO - 2023-08-06 12:23:00 --> Helper loaded: file_helper
INFO - 2023-08-06 12:23:00 --> Helper loaded: html_helper
INFO - 2023-08-06 12:23:00 --> Helper loaded: text_helper
INFO - 2023-08-06 12:23:00 --> Helper loaded: form_helper
INFO - 2023-08-06 12:23:00 --> Helper loaded: lang_helper
INFO - 2023-08-06 12:23:00 --> Helper loaded: security_helper
INFO - 2023-08-06 12:23:00 --> Helper loaded: cookie_helper
INFO - 2023-08-06 12:23:00 --> Database Driver Class Initialized
INFO - 2023-08-06 12:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 12:23:00 --> Parser Class Initialized
INFO - 2023-08-06 12:23:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 12:23:00 --> Pagination Class Initialized
INFO - 2023-08-06 12:23:00 --> Form Validation Class Initialized
INFO - 2023-08-06 12:23:00 --> Controller Class Initialized
INFO - 2023-08-06 12:23:00 --> Model Class Initialized
DEBUG - 2023-08-06 12:23:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:23:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-06 12:23:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:23:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 12:23:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 12:23:00 --> Model Class Initialized
INFO - 2023-08-06 12:23:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 12:23:00 --> Final output sent to browser
DEBUG - 2023-08-06 12:23:00 --> Total execution time: 0.0349
ERROR - 2023-08-06 12:23:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 12:23:14 --> Config Class Initialized
INFO - 2023-08-06 12:23:14 --> Hooks Class Initialized
DEBUG - 2023-08-06 12:23:14 --> UTF-8 Support Enabled
INFO - 2023-08-06 12:23:14 --> Utf8 Class Initialized
INFO - 2023-08-06 12:23:14 --> URI Class Initialized
INFO - 2023-08-06 12:23:14 --> Router Class Initialized
INFO - 2023-08-06 12:23:14 --> Output Class Initialized
INFO - 2023-08-06 12:23:14 --> Security Class Initialized
DEBUG - 2023-08-06 12:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 12:23:14 --> Input Class Initialized
INFO - 2023-08-06 12:23:14 --> Language Class Initialized
INFO - 2023-08-06 12:23:14 --> Loader Class Initialized
INFO - 2023-08-06 12:23:14 --> Helper loaded: url_helper
INFO - 2023-08-06 12:23:14 --> Helper loaded: file_helper
INFO - 2023-08-06 12:23:14 --> Helper loaded: html_helper
INFO - 2023-08-06 12:23:14 --> Helper loaded: text_helper
INFO - 2023-08-06 12:23:14 --> Helper loaded: form_helper
INFO - 2023-08-06 12:23:14 --> Helper loaded: lang_helper
INFO - 2023-08-06 12:23:14 --> Helper loaded: security_helper
INFO - 2023-08-06 12:23:14 --> Helper loaded: cookie_helper
INFO - 2023-08-06 12:23:14 --> Database Driver Class Initialized
INFO - 2023-08-06 12:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 12:23:14 --> Parser Class Initialized
INFO - 2023-08-06 12:23:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 12:23:14 --> Pagination Class Initialized
INFO - 2023-08-06 12:23:14 --> Form Validation Class Initialized
INFO - 2023-08-06 12:23:14 --> Controller Class Initialized
INFO - 2023-08-06 12:23:14 --> Model Class Initialized
DEBUG - 2023-08-06 12:23:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:23:14 --> Model Class Initialized
INFO - 2023-08-06 12:23:14 --> Final output sent to browser
DEBUG - 2023-08-06 12:23:14 --> Total execution time: 0.0214
ERROR - 2023-08-06 12:23:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 12:23:15 --> Config Class Initialized
INFO - 2023-08-06 12:23:15 --> Hooks Class Initialized
DEBUG - 2023-08-06 12:23:15 --> UTF-8 Support Enabled
INFO - 2023-08-06 12:23:15 --> Utf8 Class Initialized
INFO - 2023-08-06 12:23:15 --> URI Class Initialized
DEBUG - 2023-08-06 12:23:15 --> No URI present. Default controller set.
INFO - 2023-08-06 12:23:15 --> Router Class Initialized
INFO - 2023-08-06 12:23:15 --> Output Class Initialized
INFO - 2023-08-06 12:23:15 --> Security Class Initialized
DEBUG - 2023-08-06 12:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 12:23:15 --> Input Class Initialized
INFO - 2023-08-06 12:23:15 --> Language Class Initialized
INFO - 2023-08-06 12:23:15 --> Loader Class Initialized
INFO - 2023-08-06 12:23:15 --> Helper loaded: url_helper
INFO - 2023-08-06 12:23:15 --> Helper loaded: file_helper
INFO - 2023-08-06 12:23:15 --> Helper loaded: html_helper
INFO - 2023-08-06 12:23:15 --> Helper loaded: text_helper
INFO - 2023-08-06 12:23:15 --> Helper loaded: form_helper
INFO - 2023-08-06 12:23:15 --> Helper loaded: lang_helper
INFO - 2023-08-06 12:23:15 --> Helper loaded: security_helper
INFO - 2023-08-06 12:23:15 --> Helper loaded: cookie_helper
INFO - 2023-08-06 12:23:15 --> Database Driver Class Initialized
INFO - 2023-08-06 12:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 12:23:15 --> Parser Class Initialized
INFO - 2023-08-06 12:23:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 12:23:15 --> Pagination Class Initialized
INFO - 2023-08-06 12:23:15 --> Form Validation Class Initialized
INFO - 2023-08-06 12:23:15 --> Controller Class Initialized
INFO - 2023-08-06 12:23:15 --> Model Class Initialized
DEBUG - 2023-08-06 12:23:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:23:15 --> Model Class Initialized
DEBUG - 2023-08-06 12:23:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:23:15 --> Model Class Initialized
INFO - 2023-08-06 12:23:15 --> Model Class Initialized
INFO - 2023-08-06 12:23:15 --> Model Class Initialized
INFO - 2023-08-06 12:23:15 --> Model Class Initialized
DEBUG - 2023-08-06 12:23:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 12:23:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:23:15 --> Model Class Initialized
INFO - 2023-08-06 12:23:15 --> Model Class Initialized
INFO - 2023-08-06 12:23:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-06 12:23:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:23:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 12:23:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 12:23:15 --> Model Class Initialized
INFO - 2023-08-06 12:23:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-06 12:23:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-06 12:23:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 12:23:15 --> Final output sent to browser
DEBUG - 2023-08-06 12:23:15 --> Total execution time: 0.1075
ERROR - 2023-08-06 12:23:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 12:23:32 --> Config Class Initialized
INFO - 2023-08-06 12:23:32 --> Hooks Class Initialized
DEBUG - 2023-08-06 12:23:32 --> UTF-8 Support Enabled
INFO - 2023-08-06 12:23:32 --> Utf8 Class Initialized
INFO - 2023-08-06 12:23:32 --> URI Class Initialized
INFO - 2023-08-06 12:23:32 --> Router Class Initialized
INFO - 2023-08-06 12:23:32 --> Output Class Initialized
INFO - 2023-08-06 12:23:32 --> Security Class Initialized
DEBUG - 2023-08-06 12:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 12:23:32 --> Input Class Initialized
INFO - 2023-08-06 12:23:32 --> Language Class Initialized
INFO - 2023-08-06 12:23:32 --> Loader Class Initialized
INFO - 2023-08-06 12:23:32 --> Helper loaded: url_helper
INFO - 2023-08-06 12:23:32 --> Helper loaded: file_helper
INFO - 2023-08-06 12:23:32 --> Helper loaded: html_helper
INFO - 2023-08-06 12:23:32 --> Helper loaded: text_helper
INFO - 2023-08-06 12:23:32 --> Helper loaded: form_helper
INFO - 2023-08-06 12:23:32 --> Helper loaded: lang_helper
INFO - 2023-08-06 12:23:32 --> Helper loaded: security_helper
INFO - 2023-08-06 12:23:32 --> Helper loaded: cookie_helper
INFO - 2023-08-06 12:23:32 --> Database Driver Class Initialized
INFO - 2023-08-06 12:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 12:23:32 --> Parser Class Initialized
INFO - 2023-08-06 12:23:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 12:23:32 --> Pagination Class Initialized
INFO - 2023-08-06 12:23:32 --> Form Validation Class Initialized
INFO - 2023-08-06 12:23:32 --> Controller Class Initialized
DEBUG - 2023-08-06 12:23:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 12:23:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:23:32 --> Model Class Initialized
DEBUG - 2023-08-06 12:23:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:23:32 --> Model Class Initialized
DEBUG - 2023-08-06 12:23:32 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:23:32 --> Model Class Initialized
INFO - 2023-08-06 12:23:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-08-06 12:23:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:23:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 12:23:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 12:23:32 --> Model Class Initialized
INFO - 2023-08-06 12:23:32 --> Model Class Initialized
INFO - 2023-08-06 12:23:32 --> Model Class Initialized
INFO - 2023-08-06 12:23:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-06 12:23:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-06 12:23:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 12:23:32 --> Final output sent to browser
DEBUG - 2023-08-06 12:23:32 --> Total execution time: 0.0876
ERROR - 2023-08-06 12:23:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 12:23:33 --> Config Class Initialized
INFO - 2023-08-06 12:23:33 --> Hooks Class Initialized
DEBUG - 2023-08-06 12:23:33 --> UTF-8 Support Enabled
INFO - 2023-08-06 12:23:33 --> Utf8 Class Initialized
INFO - 2023-08-06 12:23:33 --> URI Class Initialized
INFO - 2023-08-06 12:23:33 --> Router Class Initialized
INFO - 2023-08-06 12:23:33 --> Output Class Initialized
INFO - 2023-08-06 12:23:33 --> Security Class Initialized
DEBUG - 2023-08-06 12:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 12:23:33 --> Input Class Initialized
INFO - 2023-08-06 12:23:33 --> Language Class Initialized
INFO - 2023-08-06 12:23:33 --> Loader Class Initialized
INFO - 2023-08-06 12:23:33 --> Helper loaded: url_helper
INFO - 2023-08-06 12:23:33 --> Helper loaded: file_helper
INFO - 2023-08-06 12:23:33 --> Helper loaded: html_helper
INFO - 2023-08-06 12:23:33 --> Helper loaded: text_helper
INFO - 2023-08-06 12:23:33 --> Helper loaded: form_helper
INFO - 2023-08-06 12:23:33 --> Helper loaded: lang_helper
INFO - 2023-08-06 12:23:33 --> Helper loaded: security_helper
INFO - 2023-08-06 12:23:33 --> Helper loaded: cookie_helper
INFO - 2023-08-06 12:23:33 --> Database Driver Class Initialized
INFO - 2023-08-06 12:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 12:23:33 --> Parser Class Initialized
INFO - 2023-08-06 12:23:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 12:23:33 --> Pagination Class Initialized
INFO - 2023-08-06 12:23:33 --> Form Validation Class Initialized
INFO - 2023-08-06 12:23:33 --> Controller Class Initialized
DEBUG - 2023-08-06 12:23:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 12:23:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:23:33 --> Model Class Initialized
DEBUG - 2023-08-06 12:23:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:23:33 --> Model Class Initialized
INFO - 2023-08-06 12:23:33 --> Final output sent to browser
DEBUG - 2023-08-06 12:23:33 --> Total execution time: 0.0214
ERROR - 2023-08-06 12:23:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 12:23:54 --> Config Class Initialized
INFO - 2023-08-06 12:23:54 --> Hooks Class Initialized
DEBUG - 2023-08-06 12:23:54 --> UTF-8 Support Enabled
INFO - 2023-08-06 12:23:54 --> Utf8 Class Initialized
INFO - 2023-08-06 12:23:54 --> URI Class Initialized
INFO - 2023-08-06 12:23:54 --> Router Class Initialized
INFO - 2023-08-06 12:23:54 --> Output Class Initialized
INFO - 2023-08-06 12:23:54 --> Security Class Initialized
DEBUG - 2023-08-06 12:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 12:23:54 --> Input Class Initialized
INFO - 2023-08-06 12:23:54 --> Language Class Initialized
INFO - 2023-08-06 12:23:54 --> Loader Class Initialized
INFO - 2023-08-06 12:23:54 --> Helper loaded: url_helper
INFO - 2023-08-06 12:23:54 --> Helper loaded: file_helper
INFO - 2023-08-06 12:23:54 --> Helper loaded: html_helper
INFO - 2023-08-06 12:23:54 --> Helper loaded: text_helper
INFO - 2023-08-06 12:23:54 --> Helper loaded: form_helper
INFO - 2023-08-06 12:23:54 --> Helper loaded: lang_helper
INFO - 2023-08-06 12:23:54 --> Helper loaded: security_helper
INFO - 2023-08-06 12:23:54 --> Helper loaded: cookie_helper
INFO - 2023-08-06 12:23:54 --> Database Driver Class Initialized
INFO - 2023-08-06 12:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 12:23:54 --> Parser Class Initialized
INFO - 2023-08-06 12:23:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 12:23:54 --> Pagination Class Initialized
INFO - 2023-08-06 12:23:54 --> Form Validation Class Initialized
INFO - 2023-08-06 12:23:54 --> Controller Class Initialized
DEBUG - 2023-08-06 12:23:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 12:23:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:23:54 --> Model Class Initialized
DEBUG - 2023-08-06 12:23:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:23:54 --> Model Class Initialized
INFO - 2023-08-06 12:23:54 --> Final output sent to browser
DEBUG - 2023-08-06 12:23:54 --> Total execution time: 0.0244
ERROR - 2023-08-06 12:24:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 12:24:04 --> Config Class Initialized
INFO - 2023-08-06 12:24:04 --> Hooks Class Initialized
DEBUG - 2023-08-06 12:24:04 --> UTF-8 Support Enabled
INFO - 2023-08-06 12:24:04 --> Utf8 Class Initialized
INFO - 2023-08-06 12:24:04 --> URI Class Initialized
INFO - 2023-08-06 12:24:04 --> Router Class Initialized
INFO - 2023-08-06 12:24:04 --> Output Class Initialized
INFO - 2023-08-06 12:24:04 --> Security Class Initialized
DEBUG - 2023-08-06 12:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 12:24:04 --> Input Class Initialized
INFO - 2023-08-06 12:24:04 --> Language Class Initialized
INFO - 2023-08-06 12:24:04 --> Loader Class Initialized
INFO - 2023-08-06 12:24:04 --> Helper loaded: url_helper
INFO - 2023-08-06 12:24:04 --> Helper loaded: file_helper
INFO - 2023-08-06 12:24:04 --> Helper loaded: html_helper
INFO - 2023-08-06 12:24:04 --> Helper loaded: text_helper
INFO - 2023-08-06 12:24:04 --> Helper loaded: form_helper
INFO - 2023-08-06 12:24:04 --> Helper loaded: lang_helper
INFO - 2023-08-06 12:24:04 --> Helper loaded: security_helper
INFO - 2023-08-06 12:24:04 --> Helper loaded: cookie_helper
INFO - 2023-08-06 12:24:04 --> Database Driver Class Initialized
INFO - 2023-08-06 12:24:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 12:24:04 --> Parser Class Initialized
INFO - 2023-08-06 12:24:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 12:24:04 --> Pagination Class Initialized
INFO - 2023-08-06 12:24:04 --> Form Validation Class Initialized
INFO - 2023-08-06 12:24:04 --> Controller Class Initialized
DEBUG - 2023-08-06 12:24:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 12:24:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:24:04 --> Model Class Initialized
DEBUG - 2023-08-06 12:24:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:24:04 --> Model Class Initialized
INFO - 2023-08-06 12:24:04 --> Final output sent to browser
DEBUG - 2023-08-06 12:24:04 --> Total execution time: 0.0221
ERROR - 2023-08-06 12:27:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 12:27:50 --> Config Class Initialized
INFO - 2023-08-06 12:27:50 --> Hooks Class Initialized
DEBUG - 2023-08-06 12:27:50 --> UTF-8 Support Enabled
INFO - 2023-08-06 12:27:50 --> Utf8 Class Initialized
INFO - 2023-08-06 12:27:50 --> URI Class Initialized
INFO - 2023-08-06 12:27:50 --> Router Class Initialized
INFO - 2023-08-06 12:27:50 --> Output Class Initialized
INFO - 2023-08-06 12:27:50 --> Security Class Initialized
DEBUG - 2023-08-06 12:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 12:27:50 --> Input Class Initialized
INFO - 2023-08-06 12:27:50 --> Language Class Initialized
INFO - 2023-08-06 12:27:50 --> Loader Class Initialized
INFO - 2023-08-06 12:27:50 --> Helper loaded: url_helper
INFO - 2023-08-06 12:27:50 --> Helper loaded: file_helper
INFO - 2023-08-06 12:27:50 --> Helper loaded: html_helper
INFO - 2023-08-06 12:27:50 --> Helper loaded: text_helper
INFO - 2023-08-06 12:27:50 --> Helper loaded: form_helper
INFO - 2023-08-06 12:27:50 --> Helper loaded: lang_helper
INFO - 2023-08-06 12:27:50 --> Helper loaded: security_helper
INFO - 2023-08-06 12:27:50 --> Helper loaded: cookie_helper
INFO - 2023-08-06 12:27:50 --> Database Driver Class Initialized
INFO - 2023-08-06 12:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 12:27:50 --> Parser Class Initialized
INFO - 2023-08-06 12:27:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 12:27:50 --> Pagination Class Initialized
INFO - 2023-08-06 12:27:50 --> Form Validation Class Initialized
INFO - 2023-08-06 12:27:50 --> Controller Class Initialized
DEBUG - 2023-08-06 12:27:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 12:27:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:27:50 --> Model Class Initialized
DEBUG - 2023-08-06 12:27:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:27:50 --> Model Class Initialized
INFO - 2023-08-06 12:27:50 --> Final output sent to browser
DEBUG - 2023-08-06 12:27:50 --> Total execution time: 0.0241
ERROR - 2023-08-06 12:28:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 12:28:09 --> Config Class Initialized
INFO - 2023-08-06 12:28:09 --> Hooks Class Initialized
DEBUG - 2023-08-06 12:28:09 --> UTF-8 Support Enabled
INFO - 2023-08-06 12:28:09 --> Utf8 Class Initialized
INFO - 2023-08-06 12:28:09 --> URI Class Initialized
INFO - 2023-08-06 12:28:09 --> Router Class Initialized
INFO - 2023-08-06 12:28:09 --> Output Class Initialized
INFO - 2023-08-06 12:28:09 --> Security Class Initialized
DEBUG - 2023-08-06 12:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 12:28:09 --> Input Class Initialized
INFO - 2023-08-06 12:28:09 --> Language Class Initialized
INFO - 2023-08-06 12:28:09 --> Loader Class Initialized
INFO - 2023-08-06 12:28:09 --> Helper loaded: url_helper
INFO - 2023-08-06 12:28:09 --> Helper loaded: file_helper
INFO - 2023-08-06 12:28:09 --> Helper loaded: html_helper
INFO - 2023-08-06 12:28:09 --> Helper loaded: text_helper
INFO - 2023-08-06 12:28:09 --> Helper loaded: form_helper
INFO - 2023-08-06 12:28:09 --> Helper loaded: lang_helper
INFO - 2023-08-06 12:28:09 --> Helper loaded: security_helper
INFO - 2023-08-06 12:28:09 --> Helper loaded: cookie_helper
INFO - 2023-08-06 12:28:09 --> Database Driver Class Initialized
INFO - 2023-08-06 12:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 12:28:09 --> Parser Class Initialized
INFO - 2023-08-06 12:28:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 12:28:09 --> Pagination Class Initialized
INFO - 2023-08-06 12:28:09 --> Form Validation Class Initialized
INFO - 2023-08-06 12:28:09 --> Controller Class Initialized
DEBUG - 2023-08-06 12:28:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 12:28:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:28:09 --> Model Class Initialized
DEBUG - 2023-08-06 12:28:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:28:09 --> Model Class Initialized
INFO - 2023-08-06 12:28:09 --> Final output sent to browser
DEBUG - 2023-08-06 12:28:09 --> Total execution time: 0.0242
ERROR - 2023-08-06 12:28:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 12:28:20 --> Config Class Initialized
INFO - 2023-08-06 12:28:20 --> Hooks Class Initialized
DEBUG - 2023-08-06 12:28:20 --> UTF-8 Support Enabled
INFO - 2023-08-06 12:28:20 --> Utf8 Class Initialized
INFO - 2023-08-06 12:28:20 --> URI Class Initialized
INFO - 2023-08-06 12:28:20 --> Router Class Initialized
INFO - 2023-08-06 12:28:20 --> Output Class Initialized
INFO - 2023-08-06 12:28:20 --> Security Class Initialized
DEBUG - 2023-08-06 12:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 12:28:20 --> Input Class Initialized
INFO - 2023-08-06 12:28:20 --> Language Class Initialized
INFO - 2023-08-06 12:28:20 --> Loader Class Initialized
INFO - 2023-08-06 12:28:20 --> Helper loaded: url_helper
INFO - 2023-08-06 12:28:20 --> Helper loaded: file_helper
INFO - 2023-08-06 12:28:20 --> Helper loaded: html_helper
INFO - 2023-08-06 12:28:20 --> Helper loaded: text_helper
INFO - 2023-08-06 12:28:20 --> Helper loaded: form_helper
INFO - 2023-08-06 12:28:20 --> Helper loaded: lang_helper
INFO - 2023-08-06 12:28:20 --> Helper loaded: security_helper
INFO - 2023-08-06 12:28:20 --> Helper loaded: cookie_helper
INFO - 2023-08-06 12:28:20 --> Database Driver Class Initialized
INFO - 2023-08-06 12:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 12:28:20 --> Parser Class Initialized
INFO - 2023-08-06 12:28:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 12:28:20 --> Pagination Class Initialized
INFO - 2023-08-06 12:28:20 --> Form Validation Class Initialized
INFO - 2023-08-06 12:28:20 --> Controller Class Initialized
DEBUG - 2023-08-06 12:28:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 12:28:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:28:20 --> Model Class Initialized
DEBUG - 2023-08-06 12:28:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:28:20 --> Model Class Initialized
INFO - 2023-08-06 12:28:20 --> Final output sent to browser
DEBUG - 2023-08-06 12:28:20 --> Total execution time: 0.0197
ERROR - 2023-08-06 12:30:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 12:30:37 --> Config Class Initialized
INFO - 2023-08-06 12:30:37 --> Hooks Class Initialized
DEBUG - 2023-08-06 12:30:37 --> UTF-8 Support Enabled
INFO - 2023-08-06 12:30:37 --> Utf8 Class Initialized
INFO - 2023-08-06 12:30:37 --> URI Class Initialized
DEBUG - 2023-08-06 12:30:37 --> No URI present. Default controller set.
INFO - 2023-08-06 12:30:37 --> Router Class Initialized
INFO - 2023-08-06 12:30:37 --> Output Class Initialized
INFO - 2023-08-06 12:30:37 --> Security Class Initialized
DEBUG - 2023-08-06 12:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 12:30:37 --> Input Class Initialized
INFO - 2023-08-06 12:30:37 --> Language Class Initialized
INFO - 2023-08-06 12:30:37 --> Loader Class Initialized
INFO - 2023-08-06 12:30:37 --> Helper loaded: url_helper
INFO - 2023-08-06 12:30:37 --> Helper loaded: file_helper
INFO - 2023-08-06 12:30:37 --> Helper loaded: html_helper
INFO - 2023-08-06 12:30:37 --> Helper loaded: text_helper
INFO - 2023-08-06 12:30:37 --> Helper loaded: form_helper
INFO - 2023-08-06 12:30:37 --> Helper loaded: lang_helper
INFO - 2023-08-06 12:30:37 --> Helper loaded: security_helper
INFO - 2023-08-06 12:30:37 --> Helper loaded: cookie_helper
INFO - 2023-08-06 12:30:37 --> Database Driver Class Initialized
INFO - 2023-08-06 12:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 12:30:37 --> Parser Class Initialized
INFO - 2023-08-06 12:30:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 12:30:37 --> Pagination Class Initialized
INFO - 2023-08-06 12:30:37 --> Form Validation Class Initialized
INFO - 2023-08-06 12:30:37 --> Controller Class Initialized
INFO - 2023-08-06 12:30:37 --> Model Class Initialized
DEBUG - 2023-08-06 12:30:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:30:37 --> Model Class Initialized
DEBUG - 2023-08-06 12:30:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:30:37 --> Model Class Initialized
INFO - 2023-08-06 12:30:37 --> Model Class Initialized
INFO - 2023-08-06 12:30:37 --> Model Class Initialized
INFO - 2023-08-06 12:30:37 --> Model Class Initialized
DEBUG - 2023-08-06 12:30:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 12:30:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:30:37 --> Model Class Initialized
INFO - 2023-08-06 12:30:37 --> Model Class Initialized
INFO - 2023-08-06 12:30:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-06 12:30:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:30:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 12:30:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 12:30:37 --> Model Class Initialized
INFO - 2023-08-06 12:30:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-06 12:30:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-06 12:30:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 12:30:37 --> Final output sent to browser
DEBUG - 2023-08-06 12:30:37 --> Total execution time: 0.0955
ERROR - 2023-08-06 12:35:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 12:35:54 --> Config Class Initialized
INFO - 2023-08-06 12:35:54 --> Hooks Class Initialized
DEBUG - 2023-08-06 12:35:54 --> UTF-8 Support Enabled
INFO - 2023-08-06 12:35:54 --> Utf8 Class Initialized
INFO - 2023-08-06 12:35:54 --> URI Class Initialized
INFO - 2023-08-06 12:35:54 --> Router Class Initialized
INFO - 2023-08-06 12:35:54 --> Output Class Initialized
INFO - 2023-08-06 12:35:54 --> Security Class Initialized
DEBUG - 2023-08-06 12:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 12:35:54 --> Input Class Initialized
INFO - 2023-08-06 12:35:54 --> Language Class Initialized
INFO - 2023-08-06 12:35:54 --> Loader Class Initialized
INFO - 2023-08-06 12:35:54 --> Helper loaded: url_helper
INFO - 2023-08-06 12:35:54 --> Helper loaded: file_helper
INFO - 2023-08-06 12:35:54 --> Helper loaded: html_helper
INFO - 2023-08-06 12:35:54 --> Helper loaded: text_helper
INFO - 2023-08-06 12:35:54 --> Helper loaded: form_helper
INFO - 2023-08-06 12:35:54 --> Helper loaded: lang_helper
INFO - 2023-08-06 12:35:54 --> Helper loaded: security_helper
INFO - 2023-08-06 12:35:54 --> Helper loaded: cookie_helper
INFO - 2023-08-06 12:35:54 --> Database Driver Class Initialized
INFO - 2023-08-06 12:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 12:35:54 --> Parser Class Initialized
INFO - 2023-08-06 12:35:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 12:35:54 --> Pagination Class Initialized
INFO - 2023-08-06 12:35:54 --> Form Validation Class Initialized
INFO - 2023-08-06 12:35:54 --> Controller Class Initialized
INFO - 2023-08-06 12:35:54 --> Model Class Initialized
DEBUG - 2023-08-06 12:35:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 12:35:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:35:54 --> Model Class Initialized
DEBUG - 2023-08-06 12:35:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:35:54 --> Model Class Initialized
INFO - 2023-08-06 12:35:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-06 12:35:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:35:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 12:35:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 12:35:54 --> Model Class Initialized
INFO - 2023-08-06 12:35:54 --> Model Class Initialized
INFO - 2023-08-06 12:35:54 --> Model Class Initialized
INFO - 2023-08-06 12:35:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-06 12:35:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-06 12:35:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 12:35:54 --> Final output sent to browser
DEBUG - 2023-08-06 12:35:54 --> Total execution time: 0.0834
ERROR - 2023-08-06 12:35:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 12:35:55 --> Config Class Initialized
INFO - 2023-08-06 12:35:55 --> Hooks Class Initialized
DEBUG - 2023-08-06 12:35:55 --> UTF-8 Support Enabled
INFO - 2023-08-06 12:35:55 --> Utf8 Class Initialized
INFO - 2023-08-06 12:35:55 --> URI Class Initialized
INFO - 2023-08-06 12:35:55 --> Router Class Initialized
INFO - 2023-08-06 12:35:55 --> Output Class Initialized
INFO - 2023-08-06 12:35:55 --> Security Class Initialized
DEBUG - 2023-08-06 12:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 12:35:55 --> Input Class Initialized
INFO - 2023-08-06 12:35:55 --> Language Class Initialized
INFO - 2023-08-06 12:35:55 --> Loader Class Initialized
INFO - 2023-08-06 12:35:55 --> Helper loaded: url_helper
INFO - 2023-08-06 12:35:55 --> Helper loaded: file_helper
INFO - 2023-08-06 12:35:55 --> Helper loaded: html_helper
INFO - 2023-08-06 12:35:55 --> Helper loaded: text_helper
INFO - 2023-08-06 12:35:55 --> Helper loaded: form_helper
INFO - 2023-08-06 12:35:55 --> Helper loaded: lang_helper
INFO - 2023-08-06 12:35:55 --> Helper loaded: security_helper
INFO - 2023-08-06 12:35:55 --> Helper loaded: cookie_helper
INFO - 2023-08-06 12:35:55 --> Database Driver Class Initialized
INFO - 2023-08-06 12:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 12:35:55 --> Parser Class Initialized
INFO - 2023-08-06 12:35:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 12:35:55 --> Pagination Class Initialized
INFO - 2023-08-06 12:35:55 --> Form Validation Class Initialized
INFO - 2023-08-06 12:35:55 --> Controller Class Initialized
INFO - 2023-08-06 12:35:55 --> Model Class Initialized
DEBUG - 2023-08-06 12:35:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 12:35:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:35:55 --> Model Class Initialized
DEBUG - 2023-08-06 12:35:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:35:55 --> Model Class Initialized
INFO - 2023-08-06 12:35:55 --> Final output sent to browser
DEBUG - 2023-08-06 12:35:55 --> Total execution time: 0.0391
ERROR - 2023-08-06 12:36:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 12:36:07 --> Config Class Initialized
INFO - 2023-08-06 12:36:07 --> Hooks Class Initialized
DEBUG - 2023-08-06 12:36:07 --> UTF-8 Support Enabled
INFO - 2023-08-06 12:36:07 --> Utf8 Class Initialized
INFO - 2023-08-06 12:36:07 --> URI Class Initialized
INFO - 2023-08-06 12:36:07 --> Router Class Initialized
INFO - 2023-08-06 12:36:07 --> Output Class Initialized
INFO - 2023-08-06 12:36:07 --> Security Class Initialized
DEBUG - 2023-08-06 12:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 12:36:07 --> Input Class Initialized
INFO - 2023-08-06 12:36:07 --> Language Class Initialized
INFO - 2023-08-06 12:36:07 --> Loader Class Initialized
INFO - 2023-08-06 12:36:07 --> Helper loaded: url_helper
INFO - 2023-08-06 12:36:07 --> Helper loaded: file_helper
INFO - 2023-08-06 12:36:07 --> Helper loaded: html_helper
INFO - 2023-08-06 12:36:07 --> Helper loaded: text_helper
INFO - 2023-08-06 12:36:07 --> Helper loaded: form_helper
INFO - 2023-08-06 12:36:07 --> Helper loaded: lang_helper
INFO - 2023-08-06 12:36:07 --> Helper loaded: security_helper
INFO - 2023-08-06 12:36:07 --> Helper loaded: cookie_helper
INFO - 2023-08-06 12:36:07 --> Database Driver Class Initialized
INFO - 2023-08-06 12:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 12:36:07 --> Parser Class Initialized
INFO - 2023-08-06 12:36:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 12:36:07 --> Pagination Class Initialized
INFO - 2023-08-06 12:36:07 --> Form Validation Class Initialized
INFO - 2023-08-06 12:36:07 --> Controller Class Initialized
INFO - 2023-08-06 12:36:07 --> Model Class Initialized
DEBUG - 2023-08-06 12:36:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 12:36:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:36:07 --> Model Class Initialized
DEBUG - 2023-08-06 12:36:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:36:07 --> Model Class Initialized
DEBUG - 2023-08-06 12:36:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:36:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-06 12:36:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:36:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 12:36:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 12:36:07 --> Model Class Initialized
INFO - 2023-08-06 12:36:07 --> Model Class Initialized
INFO - 2023-08-06 12:36:07 --> Model Class Initialized
INFO - 2023-08-06 12:36:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-06 12:36:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-06 12:36:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 12:36:07 --> Final output sent to browser
DEBUG - 2023-08-06 12:36:07 --> Total execution time: 0.0925
ERROR - 2023-08-06 12:37:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 12:37:35 --> Config Class Initialized
INFO - 2023-08-06 12:37:35 --> Hooks Class Initialized
DEBUG - 2023-08-06 12:37:35 --> UTF-8 Support Enabled
INFO - 2023-08-06 12:37:35 --> Utf8 Class Initialized
INFO - 2023-08-06 12:37:35 --> URI Class Initialized
INFO - 2023-08-06 12:37:35 --> Router Class Initialized
INFO - 2023-08-06 12:37:35 --> Output Class Initialized
INFO - 2023-08-06 12:37:35 --> Security Class Initialized
DEBUG - 2023-08-06 12:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 12:37:35 --> Input Class Initialized
INFO - 2023-08-06 12:37:35 --> Language Class Initialized
INFO - 2023-08-06 12:37:35 --> Loader Class Initialized
INFO - 2023-08-06 12:37:35 --> Helper loaded: url_helper
INFO - 2023-08-06 12:37:35 --> Helper loaded: file_helper
INFO - 2023-08-06 12:37:35 --> Helper loaded: html_helper
INFO - 2023-08-06 12:37:35 --> Helper loaded: text_helper
INFO - 2023-08-06 12:37:35 --> Helper loaded: form_helper
INFO - 2023-08-06 12:37:35 --> Helper loaded: lang_helper
INFO - 2023-08-06 12:37:35 --> Helper loaded: security_helper
INFO - 2023-08-06 12:37:35 --> Helper loaded: cookie_helper
INFO - 2023-08-06 12:37:35 --> Database Driver Class Initialized
INFO - 2023-08-06 12:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 12:37:35 --> Parser Class Initialized
INFO - 2023-08-06 12:37:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 12:37:35 --> Pagination Class Initialized
INFO - 2023-08-06 12:37:35 --> Form Validation Class Initialized
INFO - 2023-08-06 12:37:35 --> Controller Class Initialized
INFO - 2023-08-06 12:37:35 --> Model Class Initialized
DEBUG - 2023-08-06 12:37:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 12:37:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:37:35 --> Model Class Initialized
DEBUG - 2023-08-06 12:37:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:37:35 --> Model Class Initialized
INFO - 2023-08-06 12:37:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-06 12:37:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:37:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 12:37:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 12:37:35 --> Model Class Initialized
INFO - 2023-08-06 12:37:35 --> Model Class Initialized
INFO - 2023-08-06 12:37:35 --> Model Class Initialized
INFO - 2023-08-06 12:37:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-06 12:37:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-06 12:37:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 12:37:35 --> Final output sent to browser
DEBUG - 2023-08-06 12:37:35 --> Total execution time: 0.0860
ERROR - 2023-08-06 12:37:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 12:37:36 --> Config Class Initialized
INFO - 2023-08-06 12:37:36 --> Hooks Class Initialized
DEBUG - 2023-08-06 12:37:36 --> UTF-8 Support Enabled
INFO - 2023-08-06 12:37:36 --> Utf8 Class Initialized
INFO - 2023-08-06 12:37:36 --> URI Class Initialized
INFO - 2023-08-06 12:37:36 --> Router Class Initialized
INFO - 2023-08-06 12:37:36 --> Output Class Initialized
INFO - 2023-08-06 12:37:36 --> Security Class Initialized
DEBUG - 2023-08-06 12:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 12:37:36 --> Input Class Initialized
INFO - 2023-08-06 12:37:36 --> Language Class Initialized
INFO - 2023-08-06 12:37:36 --> Loader Class Initialized
INFO - 2023-08-06 12:37:36 --> Helper loaded: url_helper
INFO - 2023-08-06 12:37:36 --> Helper loaded: file_helper
INFO - 2023-08-06 12:37:36 --> Helper loaded: html_helper
INFO - 2023-08-06 12:37:36 --> Helper loaded: text_helper
INFO - 2023-08-06 12:37:36 --> Helper loaded: form_helper
INFO - 2023-08-06 12:37:36 --> Helper loaded: lang_helper
INFO - 2023-08-06 12:37:36 --> Helper loaded: security_helper
INFO - 2023-08-06 12:37:36 --> Helper loaded: cookie_helper
INFO - 2023-08-06 12:37:36 --> Database Driver Class Initialized
INFO - 2023-08-06 12:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 12:37:36 --> Parser Class Initialized
INFO - 2023-08-06 12:37:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 12:37:36 --> Pagination Class Initialized
INFO - 2023-08-06 12:37:36 --> Form Validation Class Initialized
INFO - 2023-08-06 12:37:36 --> Controller Class Initialized
INFO - 2023-08-06 12:37:36 --> Model Class Initialized
DEBUG - 2023-08-06 12:37:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 12:37:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:37:36 --> Model Class Initialized
DEBUG - 2023-08-06 12:37:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:37:36 --> Model Class Initialized
INFO - 2023-08-06 12:37:37 --> Final output sent to browser
DEBUG - 2023-08-06 12:37:37 --> Total execution time: 0.0398
ERROR - 2023-08-06 12:37:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 12:37:43 --> Config Class Initialized
INFO - 2023-08-06 12:37:43 --> Hooks Class Initialized
DEBUG - 2023-08-06 12:37:43 --> UTF-8 Support Enabled
INFO - 2023-08-06 12:37:43 --> Utf8 Class Initialized
INFO - 2023-08-06 12:37:43 --> URI Class Initialized
INFO - 2023-08-06 12:37:43 --> Router Class Initialized
INFO - 2023-08-06 12:37:43 --> Output Class Initialized
INFO - 2023-08-06 12:37:43 --> Security Class Initialized
DEBUG - 2023-08-06 12:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 12:37:43 --> Input Class Initialized
INFO - 2023-08-06 12:37:43 --> Language Class Initialized
INFO - 2023-08-06 12:37:43 --> Loader Class Initialized
INFO - 2023-08-06 12:37:43 --> Helper loaded: url_helper
INFO - 2023-08-06 12:37:43 --> Helper loaded: file_helper
INFO - 2023-08-06 12:37:43 --> Helper loaded: html_helper
INFO - 2023-08-06 12:37:43 --> Helper loaded: text_helper
INFO - 2023-08-06 12:37:43 --> Helper loaded: form_helper
INFO - 2023-08-06 12:37:43 --> Helper loaded: lang_helper
INFO - 2023-08-06 12:37:43 --> Helper loaded: security_helper
INFO - 2023-08-06 12:37:43 --> Helper loaded: cookie_helper
INFO - 2023-08-06 12:37:43 --> Database Driver Class Initialized
INFO - 2023-08-06 12:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 12:37:43 --> Parser Class Initialized
INFO - 2023-08-06 12:37:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 12:37:43 --> Pagination Class Initialized
INFO - 2023-08-06 12:37:43 --> Form Validation Class Initialized
INFO - 2023-08-06 12:37:43 --> Controller Class Initialized
INFO - 2023-08-06 12:37:43 --> Model Class Initialized
DEBUG - 2023-08-06 12:37:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 12:37:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:37:43 --> Model Class Initialized
DEBUG - 2023-08-06 12:37:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:37:43 --> Model Class Initialized
INFO - 2023-08-06 12:37:43 --> Final output sent to browser
DEBUG - 2023-08-06 12:37:43 --> Total execution time: 0.0395
ERROR - 2023-08-06 12:37:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 12:37:50 --> Config Class Initialized
INFO - 2023-08-06 12:37:50 --> Hooks Class Initialized
DEBUG - 2023-08-06 12:37:50 --> UTF-8 Support Enabled
INFO - 2023-08-06 12:37:50 --> Utf8 Class Initialized
INFO - 2023-08-06 12:37:50 --> URI Class Initialized
INFO - 2023-08-06 12:37:50 --> Router Class Initialized
INFO - 2023-08-06 12:37:50 --> Output Class Initialized
INFO - 2023-08-06 12:37:50 --> Security Class Initialized
DEBUG - 2023-08-06 12:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 12:37:50 --> Input Class Initialized
INFO - 2023-08-06 12:37:50 --> Language Class Initialized
INFO - 2023-08-06 12:37:50 --> Loader Class Initialized
INFO - 2023-08-06 12:37:50 --> Helper loaded: url_helper
INFO - 2023-08-06 12:37:50 --> Helper loaded: file_helper
INFO - 2023-08-06 12:37:50 --> Helper loaded: html_helper
INFO - 2023-08-06 12:37:50 --> Helper loaded: text_helper
INFO - 2023-08-06 12:37:50 --> Helper loaded: form_helper
INFO - 2023-08-06 12:37:50 --> Helper loaded: lang_helper
INFO - 2023-08-06 12:37:50 --> Helper loaded: security_helper
INFO - 2023-08-06 12:37:50 --> Helper loaded: cookie_helper
INFO - 2023-08-06 12:37:50 --> Database Driver Class Initialized
INFO - 2023-08-06 12:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 12:37:50 --> Parser Class Initialized
INFO - 2023-08-06 12:37:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 12:37:50 --> Pagination Class Initialized
INFO - 2023-08-06 12:37:50 --> Form Validation Class Initialized
INFO - 2023-08-06 12:37:50 --> Controller Class Initialized
INFO - 2023-08-06 12:37:50 --> Model Class Initialized
DEBUG - 2023-08-06 12:37:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 12:37:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:37:50 --> Model Class Initialized
DEBUG - 2023-08-06 12:37:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:37:50 --> Model Class Initialized
DEBUG - 2023-08-06 12:37:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:37:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-06 12:37:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 12:37:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 12:37:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 12:37:50 --> Model Class Initialized
INFO - 2023-08-06 12:37:50 --> Model Class Initialized
INFO - 2023-08-06 12:37:50 --> Model Class Initialized
INFO - 2023-08-06 12:37:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-06 12:37:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-06 12:37:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 12:37:50 --> Final output sent to browser
DEBUG - 2023-08-06 12:37:50 --> Total execution time: 0.0945
ERROR - 2023-08-06 13:22:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 13:22:03 --> Config Class Initialized
INFO - 2023-08-06 13:22:03 --> Hooks Class Initialized
DEBUG - 2023-08-06 13:22:03 --> UTF-8 Support Enabled
INFO - 2023-08-06 13:22:03 --> Utf8 Class Initialized
INFO - 2023-08-06 13:22:03 --> URI Class Initialized
DEBUG - 2023-08-06 13:22:03 --> No URI present. Default controller set.
INFO - 2023-08-06 13:22:03 --> Router Class Initialized
INFO - 2023-08-06 13:22:03 --> Output Class Initialized
INFO - 2023-08-06 13:22:03 --> Security Class Initialized
DEBUG - 2023-08-06 13:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 13:22:03 --> Input Class Initialized
INFO - 2023-08-06 13:22:03 --> Language Class Initialized
INFO - 2023-08-06 13:22:03 --> Loader Class Initialized
INFO - 2023-08-06 13:22:03 --> Helper loaded: url_helper
INFO - 2023-08-06 13:22:03 --> Helper loaded: file_helper
INFO - 2023-08-06 13:22:03 --> Helper loaded: html_helper
INFO - 2023-08-06 13:22:03 --> Helper loaded: text_helper
INFO - 2023-08-06 13:22:03 --> Helper loaded: form_helper
INFO - 2023-08-06 13:22:03 --> Helper loaded: lang_helper
INFO - 2023-08-06 13:22:03 --> Helper loaded: security_helper
INFO - 2023-08-06 13:22:03 --> Helper loaded: cookie_helper
INFO - 2023-08-06 13:22:03 --> Database Driver Class Initialized
INFO - 2023-08-06 13:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 13:22:03 --> Parser Class Initialized
INFO - 2023-08-06 13:22:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 13:22:03 --> Pagination Class Initialized
INFO - 2023-08-06 13:22:03 --> Form Validation Class Initialized
INFO - 2023-08-06 13:22:03 --> Controller Class Initialized
INFO - 2023-08-06 13:22:03 --> Model Class Initialized
DEBUG - 2023-08-06 13:22:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-06 13:22:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 13:22:03 --> Config Class Initialized
INFO - 2023-08-06 13:22:03 --> Hooks Class Initialized
DEBUG - 2023-08-06 13:22:03 --> UTF-8 Support Enabled
INFO - 2023-08-06 13:22:03 --> Utf8 Class Initialized
INFO - 2023-08-06 13:22:03 --> URI Class Initialized
INFO - 2023-08-06 13:22:03 --> Router Class Initialized
INFO - 2023-08-06 13:22:03 --> Output Class Initialized
INFO - 2023-08-06 13:22:03 --> Security Class Initialized
DEBUG - 2023-08-06 13:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 13:22:03 --> Input Class Initialized
INFO - 2023-08-06 13:22:03 --> Language Class Initialized
INFO - 2023-08-06 13:22:03 --> Loader Class Initialized
INFO - 2023-08-06 13:22:03 --> Helper loaded: url_helper
INFO - 2023-08-06 13:22:03 --> Helper loaded: file_helper
INFO - 2023-08-06 13:22:03 --> Helper loaded: html_helper
INFO - 2023-08-06 13:22:03 --> Helper loaded: text_helper
INFO - 2023-08-06 13:22:03 --> Helper loaded: form_helper
INFO - 2023-08-06 13:22:03 --> Helper loaded: lang_helper
INFO - 2023-08-06 13:22:03 --> Helper loaded: security_helper
INFO - 2023-08-06 13:22:03 --> Helper loaded: cookie_helper
INFO - 2023-08-06 13:22:03 --> Database Driver Class Initialized
INFO - 2023-08-06 13:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 13:22:03 --> Parser Class Initialized
INFO - 2023-08-06 13:22:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 13:22:03 --> Pagination Class Initialized
INFO - 2023-08-06 13:22:03 --> Form Validation Class Initialized
INFO - 2023-08-06 13:22:03 --> Controller Class Initialized
INFO - 2023-08-06 13:22:03 --> Model Class Initialized
DEBUG - 2023-08-06 13:22:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:22:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-06 13:22:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:22:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 13:22:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 13:22:03 --> Model Class Initialized
INFO - 2023-08-06 13:22:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 13:22:03 --> Final output sent to browser
DEBUG - 2023-08-06 13:22:03 --> Total execution time: 0.0322
ERROR - 2023-08-06 13:22:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 13:22:25 --> Config Class Initialized
INFO - 2023-08-06 13:22:25 --> Hooks Class Initialized
DEBUG - 2023-08-06 13:22:25 --> UTF-8 Support Enabled
INFO - 2023-08-06 13:22:25 --> Utf8 Class Initialized
INFO - 2023-08-06 13:22:25 --> URI Class Initialized
DEBUG - 2023-08-06 13:22:25 --> No URI present. Default controller set.
INFO - 2023-08-06 13:22:25 --> Router Class Initialized
INFO - 2023-08-06 13:22:25 --> Output Class Initialized
INFO - 2023-08-06 13:22:25 --> Security Class Initialized
DEBUG - 2023-08-06 13:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 13:22:25 --> Input Class Initialized
INFO - 2023-08-06 13:22:25 --> Language Class Initialized
INFO - 2023-08-06 13:22:25 --> Loader Class Initialized
INFO - 2023-08-06 13:22:25 --> Helper loaded: url_helper
INFO - 2023-08-06 13:22:25 --> Helper loaded: file_helper
INFO - 2023-08-06 13:22:25 --> Helper loaded: html_helper
INFO - 2023-08-06 13:22:25 --> Helper loaded: text_helper
INFO - 2023-08-06 13:22:25 --> Helper loaded: form_helper
INFO - 2023-08-06 13:22:25 --> Helper loaded: lang_helper
INFO - 2023-08-06 13:22:25 --> Helper loaded: security_helper
INFO - 2023-08-06 13:22:25 --> Helper loaded: cookie_helper
INFO - 2023-08-06 13:22:25 --> Database Driver Class Initialized
INFO - 2023-08-06 13:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 13:22:25 --> Parser Class Initialized
INFO - 2023-08-06 13:22:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 13:22:25 --> Pagination Class Initialized
INFO - 2023-08-06 13:22:25 --> Form Validation Class Initialized
INFO - 2023-08-06 13:22:25 --> Controller Class Initialized
INFO - 2023-08-06 13:22:25 --> Model Class Initialized
DEBUG - 2023-08-06 13:22:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-06 13:22:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 13:22:26 --> Config Class Initialized
INFO - 2023-08-06 13:22:26 --> Hooks Class Initialized
DEBUG - 2023-08-06 13:22:26 --> UTF-8 Support Enabled
INFO - 2023-08-06 13:22:26 --> Utf8 Class Initialized
INFO - 2023-08-06 13:22:26 --> URI Class Initialized
INFO - 2023-08-06 13:22:26 --> Router Class Initialized
INFO - 2023-08-06 13:22:26 --> Output Class Initialized
INFO - 2023-08-06 13:22:26 --> Security Class Initialized
DEBUG - 2023-08-06 13:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 13:22:26 --> Input Class Initialized
INFO - 2023-08-06 13:22:26 --> Language Class Initialized
INFO - 2023-08-06 13:22:26 --> Loader Class Initialized
INFO - 2023-08-06 13:22:26 --> Helper loaded: url_helper
INFO - 2023-08-06 13:22:26 --> Helper loaded: file_helper
INFO - 2023-08-06 13:22:26 --> Helper loaded: html_helper
INFO - 2023-08-06 13:22:26 --> Helper loaded: text_helper
INFO - 2023-08-06 13:22:26 --> Helper loaded: form_helper
INFO - 2023-08-06 13:22:26 --> Helper loaded: lang_helper
INFO - 2023-08-06 13:22:26 --> Helper loaded: security_helper
INFO - 2023-08-06 13:22:26 --> Helper loaded: cookie_helper
INFO - 2023-08-06 13:22:26 --> Database Driver Class Initialized
INFO - 2023-08-06 13:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 13:22:26 --> Parser Class Initialized
INFO - 2023-08-06 13:22:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 13:22:26 --> Pagination Class Initialized
INFO - 2023-08-06 13:22:26 --> Form Validation Class Initialized
INFO - 2023-08-06 13:22:26 --> Controller Class Initialized
INFO - 2023-08-06 13:22:26 --> Model Class Initialized
DEBUG - 2023-08-06 13:22:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:22:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-06 13:22:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:22:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 13:22:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 13:22:26 --> Model Class Initialized
INFO - 2023-08-06 13:22:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 13:22:26 --> Final output sent to browser
DEBUG - 2023-08-06 13:22:26 --> Total execution time: 0.0319
ERROR - 2023-08-06 13:22:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 13:22:44 --> Config Class Initialized
INFO - 2023-08-06 13:22:44 --> Hooks Class Initialized
DEBUG - 2023-08-06 13:22:44 --> UTF-8 Support Enabled
INFO - 2023-08-06 13:22:44 --> Utf8 Class Initialized
INFO - 2023-08-06 13:22:44 --> URI Class Initialized
INFO - 2023-08-06 13:22:44 --> Router Class Initialized
INFO - 2023-08-06 13:22:44 --> Output Class Initialized
INFO - 2023-08-06 13:22:44 --> Security Class Initialized
DEBUG - 2023-08-06 13:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 13:22:44 --> Input Class Initialized
INFO - 2023-08-06 13:22:44 --> Language Class Initialized
INFO - 2023-08-06 13:22:44 --> Loader Class Initialized
INFO - 2023-08-06 13:22:44 --> Helper loaded: url_helper
INFO - 2023-08-06 13:22:44 --> Helper loaded: file_helper
INFO - 2023-08-06 13:22:44 --> Helper loaded: html_helper
INFO - 2023-08-06 13:22:44 --> Helper loaded: text_helper
INFO - 2023-08-06 13:22:44 --> Helper loaded: form_helper
INFO - 2023-08-06 13:22:44 --> Helper loaded: lang_helper
INFO - 2023-08-06 13:22:44 --> Helper loaded: security_helper
INFO - 2023-08-06 13:22:44 --> Helper loaded: cookie_helper
INFO - 2023-08-06 13:22:44 --> Database Driver Class Initialized
INFO - 2023-08-06 13:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 13:22:44 --> Parser Class Initialized
INFO - 2023-08-06 13:22:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 13:22:44 --> Pagination Class Initialized
INFO - 2023-08-06 13:22:44 --> Form Validation Class Initialized
INFO - 2023-08-06 13:22:44 --> Controller Class Initialized
INFO - 2023-08-06 13:22:44 --> Model Class Initialized
DEBUG - 2023-08-06 13:22:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:22:44 --> Model Class Initialized
INFO - 2023-08-06 13:22:44 --> Final output sent to browser
DEBUG - 2023-08-06 13:22:44 --> Total execution time: 0.0207
ERROR - 2023-08-06 13:22:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 13:22:44 --> Config Class Initialized
INFO - 2023-08-06 13:22:44 --> Hooks Class Initialized
DEBUG - 2023-08-06 13:22:44 --> UTF-8 Support Enabled
INFO - 2023-08-06 13:22:44 --> Utf8 Class Initialized
INFO - 2023-08-06 13:22:44 --> URI Class Initialized
DEBUG - 2023-08-06 13:22:44 --> No URI present. Default controller set.
INFO - 2023-08-06 13:22:44 --> Router Class Initialized
INFO - 2023-08-06 13:22:44 --> Output Class Initialized
INFO - 2023-08-06 13:22:44 --> Security Class Initialized
DEBUG - 2023-08-06 13:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 13:22:44 --> Input Class Initialized
INFO - 2023-08-06 13:22:44 --> Language Class Initialized
INFO - 2023-08-06 13:22:44 --> Loader Class Initialized
INFO - 2023-08-06 13:22:44 --> Helper loaded: url_helper
INFO - 2023-08-06 13:22:44 --> Helper loaded: file_helper
INFO - 2023-08-06 13:22:44 --> Helper loaded: html_helper
INFO - 2023-08-06 13:22:44 --> Helper loaded: text_helper
INFO - 2023-08-06 13:22:44 --> Helper loaded: form_helper
INFO - 2023-08-06 13:22:44 --> Helper loaded: lang_helper
INFO - 2023-08-06 13:22:44 --> Helper loaded: security_helper
INFO - 2023-08-06 13:22:44 --> Helper loaded: cookie_helper
INFO - 2023-08-06 13:22:44 --> Database Driver Class Initialized
INFO - 2023-08-06 13:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 13:22:44 --> Parser Class Initialized
INFO - 2023-08-06 13:22:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 13:22:44 --> Pagination Class Initialized
INFO - 2023-08-06 13:22:44 --> Form Validation Class Initialized
INFO - 2023-08-06 13:22:44 --> Controller Class Initialized
INFO - 2023-08-06 13:22:44 --> Model Class Initialized
DEBUG - 2023-08-06 13:22:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:22:44 --> Model Class Initialized
DEBUG - 2023-08-06 13:22:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:22:44 --> Model Class Initialized
INFO - 2023-08-06 13:22:44 --> Model Class Initialized
INFO - 2023-08-06 13:22:44 --> Model Class Initialized
INFO - 2023-08-06 13:22:44 --> Model Class Initialized
DEBUG - 2023-08-06 13:22:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 13:22:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:22:44 --> Model Class Initialized
INFO - 2023-08-06 13:22:44 --> Model Class Initialized
INFO - 2023-08-06 13:22:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-06 13:22:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:22:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 13:22:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 13:22:45 --> Model Class Initialized
INFO - 2023-08-06 13:22:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-06 13:22:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-06 13:22:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 13:22:45 --> Final output sent to browser
DEBUG - 2023-08-06 13:22:45 --> Total execution time: 0.0804
ERROR - 2023-08-06 13:22:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 13:22:58 --> Config Class Initialized
INFO - 2023-08-06 13:22:58 --> Hooks Class Initialized
DEBUG - 2023-08-06 13:22:58 --> UTF-8 Support Enabled
INFO - 2023-08-06 13:22:58 --> Utf8 Class Initialized
INFO - 2023-08-06 13:22:58 --> URI Class Initialized
INFO - 2023-08-06 13:22:58 --> Router Class Initialized
INFO - 2023-08-06 13:22:58 --> Output Class Initialized
INFO - 2023-08-06 13:22:58 --> Security Class Initialized
DEBUG - 2023-08-06 13:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 13:22:58 --> Input Class Initialized
INFO - 2023-08-06 13:22:58 --> Language Class Initialized
INFO - 2023-08-06 13:22:58 --> Loader Class Initialized
INFO - 2023-08-06 13:22:58 --> Helper loaded: url_helper
INFO - 2023-08-06 13:22:58 --> Helper loaded: file_helper
INFO - 2023-08-06 13:22:58 --> Helper loaded: html_helper
INFO - 2023-08-06 13:22:58 --> Helper loaded: text_helper
INFO - 2023-08-06 13:22:58 --> Helper loaded: form_helper
INFO - 2023-08-06 13:22:58 --> Helper loaded: lang_helper
INFO - 2023-08-06 13:22:58 --> Helper loaded: security_helper
INFO - 2023-08-06 13:22:58 --> Helper loaded: cookie_helper
INFO - 2023-08-06 13:22:58 --> Database Driver Class Initialized
INFO - 2023-08-06 13:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 13:22:58 --> Parser Class Initialized
INFO - 2023-08-06 13:22:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 13:22:58 --> Pagination Class Initialized
INFO - 2023-08-06 13:22:58 --> Form Validation Class Initialized
INFO - 2023-08-06 13:22:58 --> Controller Class Initialized
INFO - 2023-08-06 13:22:58 --> Model Class Initialized
DEBUG - 2023-08-06 13:22:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 13:22:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:22:58 --> Model Class Initialized
DEBUG - 2023-08-06 13:22:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:22:58 --> Model Class Initialized
INFO - 2023-08-06 13:22:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-06 13:22:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:22:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 13:22:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 13:22:58 --> Model Class Initialized
INFO - 2023-08-06 13:22:58 --> Model Class Initialized
INFO - 2023-08-06 13:22:58 --> Model Class Initialized
INFO - 2023-08-06 13:22:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-06 13:22:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-06 13:22:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 13:22:58 --> Final output sent to browser
DEBUG - 2023-08-06 13:22:58 --> Total execution time: 0.0842
ERROR - 2023-08-06 13:23:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 13:23:00 --> Config Class Initialized
INFO - 2023-08-06 13:23:00 --> Hooks Class Initialized
DEBUG - 2023-08-06 13:23:00 --> UTF-8 Support Enabled
INFO - 2023-08-06 13:23:00 --> Utf8 Class Initialized
INFO - 2023-08-06 13:23:00 --> URI Class Initialized
INFO - 2023-08-06 13:23:00 --> Router Class Initialized
INFO - 2023-08-06 13:23:00 --> Output Class Initialized
INFO - 2023-08-06 13:23:00 --> Security Class Initialized
DEBUG - 2023-08-06 13:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 13:23:00 --> Input Class Initialized
INFO - 2023-08-06 13:23:00 --> Language Class Initialized
INFO - 2023-08-06 13:23:00 --> Loader Class Initialized
INFO - 2023-08-06 13:23:00 --> Helper loaded: url_helper
INFO - 2023-08-06 13:23:00 --> Helper loaded: file_helper
INFO - 2023-08-06 13:23:00 --> Helper loaded: html_helper
INFO - 2023-08-06 13:23:00 --> Helper loaded: text_helper
INFO - 2023-08-06 13:23:00 --> Helper loaded: form_helper
INFO - 2023-08-06 13:23:00 --> Helper loaded: lang_helper
INFO - 2023-08-06 13:23:00 --> Helper loaded: security_helper
INFO - 2023-08-06 13:23:00 --> Helper loaded: cookie_helper
INFO - 2023-08-06 13:23:00 --> Database Driver Class Initialized
INFO - 2023-08-06 13:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 13:23:00 --> Parser Class Initialized
INFO - 2023-08-06 13:23:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 13:23:00 --> Pagination Class Initialized
INFO - 2023-08-06 13:23:00 --> Form Validation Class Initialized
INFO - 2023-08-06 13:23:00 --> Controller Class Initialized
INFO - 2023-08-06 13:23:00 --> Model Class Initialized
DEBUG - 2023-08-06 13:23:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 13:23:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:23:00 --> Model Class Initialized
DEBUG - 2023-08-06 13:23:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:23:00 --> Model Class Initialized
INFO - 2023-08-06 13:23:00 --> Final output sent to browser
DEBUG - 2023-08-06 13:23:00 --> Total execution time: 0.0279
ERROR - 2023-08-06 13:23:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 13:23:23 --> Config Class Initialized
INFO - 2023-08-06 13:23:23 --> Hooks Class Initialized
DEBUG - 2023-08-06 13:23:23 --> UTF-8 Support Enabled
INFO - 2023-08-06 13:23:23 --> Utf8 Class Initialized
INFO - 2023-08-06 13:23:23 --> URI Class Initialized
INFO - 2023-08-06 13:23:23 --> Router Class Initialized
INFO - 2023-08-06 13:23:23 --> Output Class Initialized
INFO - 2023-08-06 13:23:23 --> Security Class Initialized
DEBUG - 2023-08-06 13:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 13:23:23 --> Input Class Initialized
INFO - 2023-08-06 13:23:23 --> Language Class Initialized
INFO - 2023-08-06 13:23:23 --> Loader Class Initialized
INFO - 2023-08-06 13:23:23 --> Helper loaded: url_helper
INFO - 2023-08-06 13:23:23 --> Helper loaded: file_helper
INFO - 2023-08-06 13:23:23 --> Helper loaded: html_helper
INFO - 2023-08-06 13:23:23 --> Helper loaded: text_helper
INFO - 2023-08-06 13:23:23 --> Helper loaded: form_helper
INFO - 2023-08-06 13:23:23 --> Helper loaded: lang_helper
INFO - 2023-08-06 13:23:23 --> Helper loaded: security_helper
INFO - 2023-08-06 13:23:23 --> Helper loaded: cookie_helper
INFO - 2023-08-06 13:23:23 --> Database Driver Class Initialized
INFO - 2023-08-06 13:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 13:23:23 --> Parser Class Initialized
INFO - 2023-08-06 13:23:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 13:23:23 --> Pagination Class Initialized
INFO - 2023-08-06 13:23:23 --> Form Validation Class Initialized
INFO - 2023-08-06 13:23:23 --> Controller Class Initialized
INFO - 2023-08-06 13:23:23 --> Model Class Initialized
DEBUG - 2023-08-06 13:23:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 13:23:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:23:23 --> Model Class Initialized
DEBUG - 2023-08-06 13:23:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:23:23 --> Model Class Initialized
INFO - 2023-08-06 13:23:23 --> Final output sent to browser
DEBUG - 2023-08-06 13:23:23 --> Total execution time: 0.0290
ERROR - 2023-08-06 13:23:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 13:23:27 --> Config Class Initialized
INFO - 2023-08-06 13:23:27 --> Hooks Class Initialized
DEBUG - 2023-08-06 13:23:27 --> UTF-8 Support Enabled
INFO - 2023-08-06 13:23:27 --> Utf8 Class Initialized
INFO - 2023-08-06 13:23:27 --> URI Class Initialized
INFO - 2023-08-06 13:23:27 --> Router Class Initialized
INFO - 2023-08-06 13:23:27 --> Output Class Initialized
INFO - 2023-08-06 13:23:27 --> Security Class Initialized
DEBUG - 2023-08-06 13:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 13:23:27 --> Input Class Initialized
INFO - 2023-08-06 13:23:27 --> Language Class Initialized
INFO - 2023-08-06 13:23:27 --> Loader Class Initialized
INFO - 2023-08-06 13:23:27 --> Helper loaded: url_helper
INFO - 2023-08-06 13:23:27 --> Helper loaded: file_helper
INFO - 2023-08-06 13:23:27 --> Helper loaded: html_helper
INFO - 2023-08-06 13:23:27 --> Helper loaded: text_helper
INFO - 2023-08-06 13:23:27 --> Helper loaded: form_helper
INFO - 2023-08-06 13:23:27 --> Helper loaded: lang_helper
INFO - 2023-08-06 13:23:27 --> Helper loaded: security_helper
INFO - 2023-08-06 13:23:27 --> Helper loaded: cookie_helper
INFO - 2023-08-06 13:23:27 --> Database Driver Class Initialized
INFO - 2023-08-06 13:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 13:23:27 --> Parser Class Initialized
INFO - 2023-08-06 13:23:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 13:23:27 --> Pagination Class Initialized
INFO - 2023-08-06 13:23:27 --> Form Validation Class Initialized
INFO - 2023-08-06 13:23:27 --> Controller Class Initialized
INFO - 2023-08-06 13:23:27 --> Model Class Initialized
DEBUG - 2023-08-06 13:23:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 13:23:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:23:27 --> Model Class Initialized
DEBUG - 2023-08-06 13:23:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:23:27 --> Model Class Initialized
INFO - 2023-08-06 13:23:27 --> Final output sent to browser
DEBUG - 2023-08-06 13:23:27 --> Total execution time: 0.0267
ERROR - 2023-08-06 13:23:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 13:23:44 --> Config Class Initialized
INFO - 2023-08-06 13:23:44 --> Hooks Class Initialized
DEBUG - 2023-08-06 13:23:44 --> UTF-8 Support Enabled
INFO - 2023-08-06 13:23:44 --> Utf8 Class Initialized
INFO - 2023-08-06 13:23:44 --> URI Class Initialized
INFO - 2023-08-06 13:23:44 --> Router Class Initialized
INFO - 2023-08-06 13:23:44 --> Output Class Initialized
INFO - 2023-08-06 13:23:44 --> Security Class Initialized
DEBUG - 2023-08-06 13:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 13:23:44 --> Input Class Initialized
INFO - 2023-08-06 13:23:44 --> Language Class Initialized
INFO - 2023-08-06 13:23:44 --> Loader Class Initialized
INFO - 2023-08-06 13:23:44 --> Helper loaded: url_helper
INFO - 2023-08-06 13:23:44 --> Helper loaded: file_helper
INFO - 2023-08-06 13:23:44 --> Helper loaded: html_helper
INFO - 2023-08-06 13:23:44 --> Helper loaded: text_helper
INFO - 2023-08-06 13:23:44 --> Helper loaded: form_helper
INFO - 2023-08-06 13:23:44 --> Helper loaded: lang_helper
INFO - 2023-08-06 13:23:44 --> Helper loaded: security_helper
INFO - 2023-08-06 13:23:44 --> Helper loaded: cookie_helper
INFO - 2023-08-06 13:23:44 --> Database Driver Class Initialized
INFO - 2023-08-06 13:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 13:23:44 --> Parser Class Initialized
INFO - 2023-08-06 13:23:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 13:23:44 --> Pagination Class Initialized
INFO - 2023-08-06 13:23:44 --> Form Validation Class Initialized
INFO - 2023-08-06 13:23:44 --> Controller Class Initialized
INFO - 2023-08-06 13:23:44 --> Model Class Initialized
DEBUG - 2023-08-06 13:23:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 13:23:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:23:44 --> Model Class Initialized
DEBUG - 2023-08-06 13:23:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:23:44 --> Model Class Initialized
INFO - 2023-08-06 13:23:44 --> Final output sent to browser
DEBUG - 2023-08-06 13:23:44 --> Total execution time: 0.0296
ERROR - 2023-08-06 13:23:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 13:23:50 --> Config Class Initialized
INFO - 2023-08-06 13:23:50 --> Hooks Class Initialized
DEBUG - 2023-08-06 13:23:50 --> UTF-8 Support Enabled
INFO - 2023-08-06 13:23:50 --> Utf8 Class Initialized
INFO - 2023-08-06 13:23:50 --> URI Class Initialized
INFO - 2023-08-06 13:23:50 --> Router Class Initialized
INFO - 2023-08-06 13:23:50 --> Output Class Initialized
INFO - 2023-08-06 13:23:50 --> Security Class Initialized
DEBUG - 2023-08-06 13:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 13:23:50 --> Input Class Initialized
INFO - 2023-08-06 13:23:50 --> Language Class Initialized
INFO - 2023-08-06 13:23:50 --> Loader Class Initialized
INFO - 2023-08-06 13:23:50 --> Helper loaded: url_helper
INFO - 2023-08-06 13:23:50 --> Helper loaded: file_helper
INFO - 2023-08-06 13:23:50 --> Helper loaded: html_helper
INFO - 2023-08-06 13:23:50 --> Helper loaded: text_helper
INFO - 2023-08-06 13:23:50 --> Helper loaded: form_helper
INFO - 2023-08-06 13:23:50 --> Helper loaded: lang_helper
INFO - 2023-08-06 13:23:50 --> Helper loaded: security_helper
INFO - 2023-08-06 13:23:50 --> Helper loaded: cookie_helper
INFO - 2023-08-06 13:23:50 --> Database Driver Class Initialized
INFO - 2023-08-06 13:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 13:23:50 --> Parser Class Initialized
INFO - 2023-08-06 13:23:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 13:23:50 --> Pagination Class Initialized
INFO - 2023-08-06 13:23:50 --> Form Validation Class Initialized
INFO - 2023-08-06 13:23:50 --> Controller Class Initialized
INFO - 2023-08-06 13:23:50 --> Model Class Initialized
DEBUG - 2023-08-06 13:23:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 13:23:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:23:50 --> Model Class Initialized
DEBUG - 2023-08-06 13:23:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:23:50 --> Model Class Initialized
INFO - 2023-08-06 13:23:50 --> Final output sent to browser
DEBUG - 2023-08-06 13:23:50 --> Total execution time: 0.0271
ERROR - 2023-08-06 13:24:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 13:24:36 --> Config Class Initialized
INFO - 2023-08-06 13:24:36 --> Hooks Class Initialized
DEBUG - 2023-08-06 13:24:36 --> UTF-8 Support Enabled
INFO - 2023-08-06 13:24:36 --> Utf8 Class Initialized
INFO - 2023-08-06 13:24:36 --> URI Class Initialized
DEBUG - 2023-08-06 13:24:36 --> No URI present. Default controller set.
INFO - 2023-08-06 13:24:36 --> Router Class Initialized
INFO - 2023-08-06 13:24:36 --> Output Class Initialized
INFO - 2023-08-06 13:24:36 --> Security Class Initialized
DEBUG - 2023-08-06 13:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 13:24:36 --> Input Class Initialized
INFO - 2023-08-06 13:24:36 --> Language Class Initialized
INFO - 2023-08-06 13:24:36 --> Loader Class Initialized
INFO - 2023-08-06 13:24:36 --> Helper loaded: url_helper
INFO - 2023-08-06 13:24:36 --> Helper loaded: file_helper
INFO - 2023-08-06 13:24:36 --> Helper loaded: html_helper
INFO - 2023-08-06 13:24:36 --> Helper loaded: text_helper
INFO - 2023-08-06 13:24:36 --> Helper loaded: form_helper
INFO - 2023-08-06 13:24:36 --> Helper loaded: lang_helper
INFO - 2023-08-06 13:24:36 --> Helper loaded: security_helper
INFO - 2023-08-06 13:24:36 --> Helper loaded: cookie_helper
INFO - 2023-08-06 13:24:36 --> Database Driver Class Initialized
INFO - 2023-08-06 13:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 13:24:36 --> Parser Class Initialized
INFO - 2023-08-06 13:24:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 13:24:36 --> Pagination Class Initialized
INFO - 2023-08-06 13:24:36 --> Form Validation Class Initialized
INFO - 2023-08-06 13:24:36 --> Controller Class Initialized
INFO - 2023-08-06 13:24:36 --> Model Class Initialized
DEBUG - 2023-08-06 13:24:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:24:36 --> Model Class Initialized
DEBUG - 2023-08-06 13:24:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:24:36 --> Model Class Initialized
INFO - 2023-08-06 13:24:36 --> Model Class Initialized
INFO - 2023-08-06 13:24:36 --> Model Class Initialized
INFO - 2023-08-06 13:24:36 --> Model Class Initialized
DEBUG - 2023-08-06 13:24:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 13:24:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:24:36 --> Model Class Initialized
INFO - 2023-08-06 13:24:36 --> Model Class Initialized
INFO - 2023-08-06 13:24:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-06 13:24:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:24:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 13:24:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 13:24:36 --> Model Class Initialized
INFO - 2023-08-06 13:24:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-06 13:24:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-06 13:24:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 13:24:36 --> Final output sent to browser
DEBUG - 2023-08-06 13:24:36 --> Total execution time: 0.0811
ERROR - 2023-08-06 13:24:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 13:24:59 --> Config Class Initialized
INFO - 2023-08-06 13:24:59 --> Hooks Class Initialized
DEBUG - 2023-08-06 13:24:59 --> UTF-8 Support Enabled
INFO - 2023-08-06 13:24:59 --> Utf8 Class Initialized
INFO - 2023-08-06 13:24:59 --> URI Class Initialized
DEBUG - 2023-08-06 13:24:59 --> No URI present. Default controller set.
INFO - 2023-08-06 13:24:59 --> Router Class Initialized
INFO - 2023-08-06 13:24:59 --> Output Class Initialized
INFO - 2023-08-06 13:24:59 --> Security Class Initialized
DEBUG - 2023-08-06 13:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 13:24:59 --> Input Class Initialized
INFO - 2023-08-06 13:24:59 --> Language Class Initialized
INFO - 2023-08-06 13:24:59 --> Loader Class Initialized
INFO - 2023-08-06 13:24:59 --> Helper loaded: url_helper
INFO - 2023-08-06 13:24:59 --> Helper loaded: file_helper
INFO - 2023-08-06 13:24:59 --> Helper loaded: html_helper
INFO - 2023-08-06 13:24:59 --> Helper loaded: text_helper
INFO - 2023-08-06 13:24:59 --> Helper loaded: form_helper
INFO - 2023-08-06 13:24:59 --> Helper loaded: lang_helper
INFO - 2023-08-06 13:24:59 --> Helper loaded: security_helper
INFO - 2023-08-06 13:24:59 --> Helper loaded: cookie_helper
INFO - 2023-08-06 13:24:59 --> Database Driver Class Initialized
INFO - 2023-08-06 13:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 13:24:59 --> Parser Class Initialized
INFO - 2023-08-06 13:24:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 13:24:59 --> Pagination Class Initialized
INFO - 2023-08-06 13:24:59 --> Form Validation Class Initialized
INFO - 2023-08-06 13:24:59 --> Controller Class Initialized
INFO - 2023-08-06 13:24:59 --> Model Class Initialized
DEBUG - 2023-08-06 13:24:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:24:59 --> Model Class Initialized
DEBUG - 2023-08-06 13:24:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:24:59 --> Model Class Initialized
INFO - 2023-08-06 13:24:59 --> Model Class Initialized
INFO - 2023-08-06 13:24:59 --> Model Class Initialized
INFO - 2023-08-06 13:24:59 --> Model Class Initialized
DEBUG - 2023-08-06 13:24:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 13:24:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:24:59 --> Model Class Initialized
INFO - 2023-08-06 13:24:59 --> Model Class Initialized
INFO - 2023-08-06 13:24:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-06 13:24:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:24:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 13:24:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 13:24:59 --> Model Class Initialized
INFO - 2023-08-06 13:24:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-06 13:24:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-06 13:24:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 13:24:59 --> Final output sent to browser
DEBUG - 2023-08-06 13:24:59 --> Total execution time: 0.0838
ERROR - 2023-08-06 13:25:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 13:25:09 --> Config Class Initialized
INFO - 2023-08-06 13:25:09 --> Hooks Class Initialized
DEBUG - 2023-08-06 13:25:09 --> UTF-8 Support Enabled
INFO - 2023-08-06 13:25:09 --> Utf8 Class Initialized
INFO - 2023-08-06 13:25:09 --> URI Class Initialized
INFO - 2023-08-06 13:25:09 --> Router Class Initialized
INFO - 2023-08-06 13:25:09 --> Output Class Initialized
INFO - 2023-08-06 13:25:09 --> Security Class Initialized
DEBUG - 2023-08-06 13:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 13:25:09 --> Input Class Initialized
INFO - 2023-08-06 13:25:09 --> Language Class Initialized
INFO - 2023-08-06 13:25:09 --> Loader Class Initialized
INFO - 2023-08-06 13:25:09 --> Helper loaded: url_helper
INFO - 2023-08-06 13:25:09 --> Helper loaded: file_helper
INFO - 2023-08-06 13:25:09 --> Helper loaded: html_helper
INFO - 2023-08-06 13:25:09 --> Helper loaded: text_helper
INFO - 2023-08-06 13:25:09 --> Helper loaded: form_helper
INFO - 2023-08-06 13:25:09 --> Helper loaded: lang_helper
INFO - 2023-08-06 13:25:09 --> Helper loaded: security_helper
INFO - 2023-08-06 13:25:09 --> Helper loaded: cookie_helper
INFO - 2023-08-06 13:25:09 --> Database Driver Class Initialized
INFO - 2023-08-06 13:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 13:25:09 --> Parser Class Initialized
INFO - 2023-08-06 13:25:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 13:25:09 --> Pagination Class Initialized
INFO - 2023-08-06 13:25:09 --> Form Validation Class Initialized
INFO - 2023-08-06 13:25:09 --> Controller Class Initialized
INFO - 2023-08-06 13:25:09 --> Model Class Initialized
DEBUG - 2023-08-06 13:25:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:25:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-06 13:25:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:25:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 13:25:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 13:25:09 --> Model Class Initialized
INFO - 2023-08-06 13:25:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 13:25:09 --> Final output sent to browser
DEBUG - 2023-08-06 13:25:09 --> Total execution time: 0.0267
ERROR - 2023-08-06 13:25:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 13:25:09 --> Config Class Initialized
INFO - 2023-08-06 13:25:09 --> Hooks Class Initialized
DEBUG - 2023-08-06 13:25:09 --> UTF-8 Support Enabled
INFO - 2023-08-06 13:25:09 --> Utf8 Class Initialized
INFO - 2023-08-06 13:25:09 --> URI Class Initialized
INFO - 2023-08-06 13:25:09 --> Router Class Initialized
INFO - 2023-08-06 13:25:09 --> Output Class Initialized
INFO - 2023-08-06 13:25:09 --> Security Class Initialized
DEBUG - 2023-08-06 13:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 13:25:09 --> Input Class Initialized
INFO - 2023-08-06 13:25:09 --> Language Class Initialized
INFO - 2023-08-06 13:25:09 --> Loader Class Initialized
INFO - 2023-08-06 13:25:09 --> Helper loaded: url_helper
INFO - 2023-08-06 13:25:09 --> Helper loaded: file_helper
INFO - 2023-08-06 13:25:09 --> Helper loaded: html_helper
INFO - 2023-08-06 13:25:09 --> Helper loaded: text_helper
INFO - 2023-08-06 13:25:09 --> Helper loaded: form_helper
INFO - 2023-08-06 13:25:09 --> Helper loaded: lang_helper
INFO - 2023-08-06 13:25:09 --> Helper loaded: security_helper
INFO - 2023-08-06 13:25:09 --> Helper loaded: cookie_helper
INFO - 2023-08-06 13:25:09 --> Database Driver Class Initialized
INFO - 2023-08-06 13:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 13:25:09 --> Parser Class Initialized
INFO - 2023-08-06 13:25:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 13:25:09 --> Pagination Class Initialized
INFO - 2023-08-06 13:25:09 --> Form Validation Class Initialized
INFO - 2023-08-06 13:25:09 --> Controller Class Initialized
INFO - 2023-08-06 13:25:09 --> Model Class Initialized
DEBUG - 2023-08-06 13:25:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:25:09 --> Model Class Initialized
DEBUG - 2023-08-06 13:25:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:25:09 --> Model Class Initialized
INFO - 2023-08-06 13:25:09 --> Model Class Initialized
INFO - 2023-08-06 13:25:09 --> Model Class Initialized
INFO - 2023-08-06 13:25:09 --> Model Class Initialized
DEBUG - 2023-08-06 13:25:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 13:25:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:25:09 --> Model Class Initialized
INFO - 2023-08-06 13:25:09 --> Model Class Initialized
INFO - 2023-08-06 13:25:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-06 13:25:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:25:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 13:25:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 13:25:09 --> Model Class Initialized
INFO - 2023-08-06 13:25:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-06 13:25:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-06 13:25:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 13:25:09 --> Final output sent to browser
DEBUG - 2023-08-06 13:25:09 --> Total execution time: 0.0704
ERROR - 2023-08-06 13:25:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 13:25:25 --> Config Class Initialized
INFO - 2023-08-06 13:25:25 --> Hooks Class Initialized
DEBUG - 2023-08-06 13:25:25 --> UTF-8 Support Enabled
INFO - 2023-08-06 13:25:25 --> Utf8 Class Initialized
INFO - 2023-08-06 13:25:25 --> URI Class Initialized
INFO - 2023-08-06 13:25:25 --> Router Class Initialized
INFO - 2023-08-06 13:25:25 --> Output Class Initialized
INFO - 2023-08-06 13:25:25 --> Security Class Initialized
DEBUG - 2023-08-06 13:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 13:25:25 --> Input Class Initialized
INFO - 2023-08-06 13:25:25 --> Language Class Initialized
INFO - 2023-08-06 13:25:25 --> Loader Class Initialized
INFO - 2023-08-06 13:25:25 --> Helper loaded: url_helper
INFO - 2023-08-06 13:25:25 --> Helper loaded: file_helper
INFO - 2023-08-06 13:25:25 --> Helper loaded: html_helper
INFO - 2023-08-06 13:25:25 --> Helper loaded: text_helper
INFO - 2023-08-06 13:25:25 --> Helper loaded: form_helper
INFO - 2023-08-06 13:25:25 --> Helper loaded: lang_helper
INFO - 2023-08-06 13:25:25 --> Helper loaded: security_helper
INFO - 2023-08-06 13:25:25 --> Helper loaded: cookie_helper
INFO - 2023-08-06 13:25:25 --> Database Driver Class Initialized
INFO - 2023-08-06 13:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 13:25:25 --> Parser Class Initialized
INFO - 2023-08-06 13:25:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 13:25:25 --> Pagination Class Initialized
INFO - 2023-08-06 13:25:25 --> Form Validation Class Initialized
INFO - 2023-08-06 13:25:25 --> Controller Class Initialized
DEBUG - 2023-08-06 13:25:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 13:25:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:25:25 --> Model Class Initialized
DEBUG - 2023-08-06 13:25:25 --> Lgift class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:25:25 --> Model Class Initialized
DEBUG - 2023-08-06 13:25:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 13:25:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:25:25 --> Model Class Initialized
DEBUG - 2023-08-06 13:25:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:25:25 --> Model Class Initialized
INFO - 2023-08-06 13:25:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/gift.php
DEBUG - 2023-08-06 13:25:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:25:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 13:25:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 13:25:25 --> Model Class Initialized
INFO - 2023-08-06 13:25:25 --> Model Class Initialized
INFO - 2023-08-06 13:25:25 --> Model Class Initialized
INFO - 2023-08-06 13:25:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-06 13:25:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-06 13:25:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 13:25:25 --> Final output sent to browser
DEBUG - 2023-08-06 13:25:25 --> Total execution time: 0.0651
ERROR - 2023-08-06 13:25:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 13:25:26 --> Config Class Initialized
INFO - 2023-08-06 13:25:26 --> Hooks Class Initialized
DEBUG - 2023-08-06 13:25:26 --> UTF-8 Support Enabled
INFO - 2023-08-06 13:25:26 --> Utf8 Class Initialized
INFO - 2023-08-06 13:25:26 --> URI Class Initialized
INFO - 2023-08-06 13:25:26 --> Router Class Initialized
INFO - 2023-08-06 13:25:26 --> Output Class Initialized
INFO - 2023-08-06 13:25:26 --> Security Class Initialized
DEBUG - 2023-08-06 13:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 13:25:26 --> Input Class Initialized
INFO - 2023-08-06 13:25:26 --> Language Class Initialized
INFO - 2023-08-06 13:25:26 --> Loader Class Initialized
INFO - 2023-08-06 13:25:26 --> Helper loaded: url_helper
INFO - 2023-08-06 13:25:26 --> Helper loaded: file_helper
INFO - 2023-08-06 13:25:26 --> Helper loaded: html_helper
INFO - 2023-08-06 13:25:26 --> Helper loaded: text_helper
INFO - 2023-08-06 13:25:26 --> Helper loaded: form_helper
INFO - 2023-08-06 13:25:26 --> Helper loaded: lang_helper
INFO - 2023-08-06 13:25:26 --> Helper loaded: security_helper
INFO - 2023-08-06 13:25:26 --> Helper loaded: cookie_helper
INFO - 2023-08-06 13:25:26 --> Database Driver Class Initialized
INFO - 2023-08-06 13:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 13:25:26 --> Parser Class Initialized
INFO - 2023-08-06 13:25:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 13:25:26 --> Pagination Class Initialized
INFO - 2023-08-06 13:25:26 --> Form Validation Class Initialized
INFO - 2023-08-06 13:25:26 --> Controller Class Initialized
DEBUG - 2023-08-06 13:25:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 13:25:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:25:26 --> Model Class Initialized
INFO - 2023-08-06 13:25:26 --> Final output sent to browser
DEBUG - 2023-08-06 13:25:26 --> Total execution time: 0.0170
ERROR - 2023-08-06 13:26:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 13:26:09 --> Config Class Initialized
INFO - 2023-08-06 13:26:09 --> Hooks Class Initialized
DEBUG - 2023-08-06 13:26:09 --> UTF-8 Support Enabled
INFO - 2023-08-06 13:26:09 --> Utf8 Class Initialized
INFO - 2023-08-06 13:26:09 --> URI Class Initialized
INFO - 2023-08-06 13:26:09 --> Router Class Initialized
INFO - 2023-08-06 13:26:09 --> Output Class Initialized
INFO - 2023-08-06 13:26:09 --> Security Class Initialized
DEBUG - 2023-08-06 13:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 13:26:09 --> Input Class Initialized
INFO - 2023-08-06 13:26:09 --> Language Class Initialized
INFO - 2023-08-06 13:26:09 --> Loader Class Initialized
INFO - 2023-08-06 13:26:09 --> Helper loaded: url_helper
INFO - 2023-08-06 13:26:09 --> Helper loaded: file_helper
INFO - 2023-08-06 13:26:09 --> Helper loaded: html_helper
INFO - 2023-08-06 13:26:09 --> Helper loaded: text_helper
INFO - 2023-08-06 13:26:09 --> Helper loaded: form_helper
INFO - 2023-08-06 13:26:09 --> Helper loaded: lang_helper
INFO - 2023-08-06 13:26:09 --> Helper loaded: security_helper
INFO - 2023-08-06 13:26:09 --> Helper loaded: cookie_helper
INFO - 2023-08-06 13:26:09 --> Database Driver Class Initialized
INFO - 2023-08-06 13:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 13:26:09 --> Parser Class Initialized
INFO - 2023-08-06 13:26:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 13:26:09 --> Pagination Class Initialized
INFO - 2023-08-06 13:26:09 --> Form Validation Class Initialized
INFO - 2023-08-06 13:26:09 --> Controller Class Initialized
INFO - 2023-08-06 13:26:09 --> Model Class Initialized
DEBUG - 2023-08-06 13:26:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:26:09 --> Model Class Initialized
DEBUG - 2023-08-06 13:26:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:26:09 --> Model Class Initialized
INFO - 2023-08-06 13:26:09 --> Model Class Initialized
INFO - 2023-08-06 13:26:09 --> Model Class Initialized
INFO - 2023-08-06 13:26:09 --> Model Class Initialized
DEBUG - 2023-08-06 13:26:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 13:26:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:26:09 --> Model Class Initialized
INFO - 2023-08-06 13:26:09 --> Model Class Initialized
INFO - 2023-08-06 13:26:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-06 13:26:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:26:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 13:26:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 13:26:09 --> Model Class Initialized
INFO - 2023-08-06 13:26:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-06 13:26:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-06 13:26:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 13:26:09 --> Final output sent to browser
DEBUG - 2023-08-06 13:26:09 --> Total execution time: 0.0758
ERROR - 2023-08-06 13:43:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 13:43:17 --> Config Class Initialized
INFO - 2023-08-06 13:43:17 --> Hooks Class Initialized
DEBUG - 2023-08-06 13:43:17 --> UTF-8 Support Enabled
INFO - 2023-08-06 13:43:17 --> Utf8 Class Initialized
INFO - 2023-08-06 13:43:17 --> URI Class Initialized
DEBUG - 2023-08-06 13:43:17 --> No URI present. Default controller set.
INFO - 2023-08-06 13:43:17 --> Router Class Initialized
INFO - 2023-08-06 13:43:17 --> Output Class Initialized
INFO - 2023-08-06 13:43:17 --> Security Class Initialized
DEBUG - 2023-08-06 13:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 13:43:17 --> Input Class Initialized
INFO - 2023-08-06 13:43:17 --> Language Class Initialized
INFO - 2023-08-06 13:43:17 --> Loader Class Initialized
INFO - 2023-08-06 13:43:17 --> Helper loaded: url_helper
INFO - 2023-08-06 13:43:17 --> Helper loaded: file_helper
INFO - 2023-08-06 13:43:17 --> Helper loaded: html_helper
INFO - 2023-08-06 13:43:17 --> Helper loaded: text_helper
INFO - 2023-08-06 13:43:17 --> Helper loaded: form_helper
INFO - 2023-08-06 13:43:17 --> Helper loaded: lang_helper
INFO - 2023-08-06 13:43:17 --> Helper loaded: security_helper
INFO - 2023-08-06 13:43:17 --> Helper loaded: cookie_helper
INFO - 2023-08-06 13:43:17 --> Database Driver Class Initialized
INFO - 2023-08-06 13:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 13:43:17 --> Parser Class Initialized
INFO - 2023-08-06 13:43:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 13:43:17 --> Pagination Class Initialized
INFO - 2023-08-06 13:43:17 --> Form Validation Class Initialized
INFO - 2023-08-06 13:43:17 --> Controller Class Initialized
INFO - 2023-08-06 13:43:17 --> Model Class Initialized
DEBUG - 2023-08-06 13:43:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-06 13:43:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 13:43:18 --> Config Class Initialized
INFO - 2023-08-06 13:43:18 --> Hooks Class Initialized
DEBUG - 2023-08-06 13:43:18 --> UTF-8 Support Enabled
INFO - 2023-08-06 13:43:18 --> Utf8 Class Initialized
INFO - 2023-08-06 13:43:18 --> URI Class Initialized
INFO - 2023-08-06 13:43:18 --> Router Class Initialized
INFO - 2023-08-06 13:43:18 --> Output Class Initialized
INFO - 2023-08-06 13:43:18 --> Security Class Initialized
DEBUG - 2023-08-06 13:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 13:43:18 --> Input Class Initialized
INFO - 2023-08-06 13:43:18 --> Language Class Initialized
INFO - 2023-08-06 13:43:18 --> Loader Class Initialized
INFO - 2023-08-06 13:43:18 --> Helper loaded: url_helper
INFO - 2023-08-06 13:43:18 --> Helper loaded: file_helper
INFO - 2023-08-06 13:43:18 --> Helper loaded: html_helper
INFO - 2023-08-06 13:43:18 --> Helper loaded: text_helper
INFO - 2023-08-06 13:43:18 --> Helper loaded: form_helper
INFO - 2023-08-06 13:43:18 --> Helper loaded: lang_helper
INFO - 2023-08-06 13:43:18 --> Helper loaded: security_helper
INFO - 2023-08-06 13:43:18 --> Helper loaded: cookie_helper
INFO - 2023-08-06 13:43:18 --> Database Driver Class Initialized
INFO - 2023-08-06 13:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 13:43:18 --> Parser Class Initialized
INFO - 2023-08-06 13:43:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 13:43:18 --> Pagination Class Initialized
INFO - 2023-08-06 13:43:18 --> Form Validation Class Initialized
INFO - 2023-08-06 13:43:18 --> Controller Class Initialized
INFO - 2023-08-06 13:43:18 --> Model Class Initialized
DEBUG - 2023-08-06 13:43:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:43:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-06 13:43:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:43:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 13:43:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 13:43:18 --> Model Class Initialized
INFO - 2023-08-06 13:43:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 13:43:18 --> Final output sent to browser
DEBUG - 2023-08-06 13:43:18 --> Total execution time: 0.0373
ERROR - 2023-08-06 13:43:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 13:43:43 --> Config Class Initialized
INFO - 2023-08-06 13:43:43 --> Hooks Class Initialized
DEBUG - 2023-08-06 13:43:43 --> UTF-8 Support Enabled
INFO - 2023-08-06 13:43:43 --> Utf8 Class Initialized
INFO - 2023-08-06 13:43:43 --> URI Class Initialized
INFO - 2023-08-06 13:43:43 --> Router Class Initialized
INFO - 2023-08-06 13:43:43 --> Output Class Initialized
INFO - 2023-08-06 13:43:43 --> Security Class Initialized
DEBUG - 2023-08-06 13:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 13:43:43 --> Input Class Initialized
INFO - 2023-08-06 13:43:43 --> Language Class Initialized
INFO - 2023-08-06 13:43:43 --> Loader Class Initialized
INFO - 2023-08-06 13:43:43 --> Helper loaded: url_helper
INFO - 2023-08-06 13:43:43 --> Helper loaded: file_helper
INFO - 2023-08-06 13:43:43 --> Helper loaded: html_helper
INFO - 2023-08-06 13:43:43 --> Helper loaded: text_helper
INFO - 2023-08-06 13:43:43 --> Helper loaded: form_helper
INFO - 2023-08-06 13:43:43 --> Helper loaded: lang_helper
INFO - 2023-08-06 13:43:43 --> Helper loaded: security_helper
INFO - 2023-08-06 13:43:43 --> Helper loaded: cookie_helper
INFO - 2023-08-06 13:43:43 --> Database Driver Class Initialized
INFO - 2023-08-06 13:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 13:43:43 --> Parser Class Initialized
INFO - 2023-08-06 13:43:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 13:43:43 --> Pagination Class Initialized
INFO - 2023-08-06 13:43:43 --> Form Validation Class Initialized
INFO - 2023-08-06 13:43:43 --> Controller Class Initialized
INFO - 2023-08-06 13:43:43 --> Model Class Initialized
DEBUG - 2023-08-06 13:43:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:43:43 --> Model Class Initialized
INFO - 2023-08-06 13:43:43 --> Final output sent to browser
DEBUG - 2023-08-06 13:43:43 --> Total execution time: 0.0221
ERROR - 2023-08-06 13:43:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 13:43:44 --> Config Class Initialized
INFO - 2023-08-06 13:43:44 --> Hooks Class Initialized
DEBUG - 2023-08-06 13:43:44 --> UTF-8 Support Enabled
INFO - 2023-08-06 13:43:44 --> Utf8 Class Initialized
INFO - 2023-08-06 13:43:44 --> URI Class Initialized
DEBUG - 2023-08-06 13:43:44 --> No URI present. Default controller set.
INFO - 2023-08-06 13:43:44 --> Router Class Initialized
INFO - 2023-08-06 13:43:44 --> Output Class Initialized
INFO - 2023-08-06 13:43:44 --> Security Class Initialized
DEBUG - 2023-08-06 13:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 13:43:44 --> Input Class Initialized
INFO - 2023-08-06 13:43:44 --> Language Class Initialized
INFO - 2023-08-06 13:43:44 --> Loader Class Initialized
INFO - 2023-08-06 13:43:44 --> Helper loaded: url_helper
INFO - 2023-08-06 13:43:44 --> Helper loaded: file_helper
INFO - 2023-08-06 13:43:44 --> Helper loaded: html_helper
INFO - 2023-08-06 13:43:44 --> Helper loaded: text_helper
INFO - 2023-08-06 13:43:44 --> Helper loaded: form_helper
INFO - 2023-08-06 13:43:44 --> Helper loaded: lang_helper
INFO - 2023-08-06 13:43:44 --> Helper loaded: security_helper
INFO - 2023-08-06 13:43:44 --> Helper loaded: cookie_helper
INFO - 2023-08-06 13:43:44 --> Database Driver Class Initialized
INFO - 2023-08-06 13:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 13:43:44 --> Parser Class Initialized
INFO - 2023-08-06 13:43:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 13:43:44 --> Pagination Class Initialized
INFO - 2023-08-06 13:43:44 --> Form Validation Class Initialized
INFO - 2023-08-06 13:43:44 --> Controller Class Initialized
INFO - 2023-08-06 13:43:44 --> Model Class Initialized
DEBUG - 2023-08-06 13:43:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:43:44 --> Model Class Initialized
DEBUG - 2023-08-06 13:43:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:43:44 --> Model Class Initialized
INFO - 2023-08-06 13:43:44 --> Model Class Initialized
INFO - 2023-08-06 13:43:44 --> Model Class Initialized
INFO - 2023-08-06 13:43:44 --> Model Class Initialized
DEBUG - 2023-08-06 13:43:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 13:43:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:43:44 --> Model Class Initialized
INFO - 2023-08-06 13:43:44 --> Model Class Initialized
INFO - 2023-08-06 13:43:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-06 13:43:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:43:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 13:43:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 13:43:44 --> Model Class Initialized
INFO - 2023-08-06 13:43:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-06 13:43:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-06 13:43:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 13:43:44 --> Final output sent to browser
DEBUG - 2023-08-06 13:43:44 --> Total execution time: 0.0883
ERROR - 2023-08-06 13:44:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 13:44:27 --> Config Class Initialized
INFO - 2023-08-06 13:44:27 --> Hooks Class Initialized
DEBUG - 2023-08-06 13:44:27 --> UTF-8 Support Enabled
INFO - 2023-08-06 13:44:27 --> Utf8 Class Initialized
INFO - 2023-08-06 13:44:27 --> URI Class Initialized
INFO - 2023-08-06 13:44:27 --> Router Class Initialized
INFO - 2023-08-06 13:44:27 --> Output Class Initialized
INFO - 2023-08-06 13:44:27 --> Security Class Initialized
DEBUG - 2023-08-06 13:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 13:44:27 --> Input Class Initialized
INFO - 2023-08-06 13:44:27 --> Language Class Initialized
INFO - 2023-08-06 13:44:27 --> Loader Class Initialized
INFO - 2023-08-06 13:44:27 --> Helper loaded: url_helper
INFO - 2023-08-06 13:44:27 --> Helper loaded: file_helper
INFO - 2023-08-06 13:44:27 --> Helper loaded: html_helper
INFO - 2023-08-06 13:44:27 --> Helper loaded: text_helper
INFO - 2023-08-06 13:44:27 --> Helper loaded: form_helper
INFO - 2023-08-06 13:44:27 --> Helper loaded: lang_helper
INFO - 2023-08-06 13:44:27 --> Helper loaded: security_helper
INFO - 2023-08-06 13:44:27 --> Helper loaded: cookie_helper
INFO - 2023-08-06 13:44:27 --> Database Driver Class Initialized
INFO - 2023-08-06 13:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 13:44:27 --> Parser Class Initialized
INFO - 2023-08-06 13:44:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 13:44:27 --> Pagination Class Initialized
INFO - 2023-08-06 13:44:27 --> Form Validation Class Initialized
INFO - 2023-08-06 13:44:27 --> Controller Class Initialized
INFO - 2023-08-06 13:44:27 --> Model Class Initialized
DEBUG - 2023-08-06 13:44:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 13:44:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:44:27 --> Model Class Initialized
DEBUG - 2023-08-06 13:44:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:44:27 --> Model Class Initialized
INFO - 2023-08-06 13:44:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-06 13:44:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:44:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 13:44:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 13:44:27 --> Model Class Initialized
INFO - 2023-08-06 13:44:27 --> Model Class Initialized
INFO - 2023-08-06 13:44:27 --> Model Class Initialized
INFO - 2023-08-06 13:44:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-06 13:44:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-06 13:44:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 13:44:27 --> Final output sent to browser
DEBUG - 2023-08-06 13:44:27 --> Total execution time: 0.0682
ERROR - 2023-08-06 13:44:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 13:44:32 --> Config Class Initialized
INFO - 2023-08-06 13:44:32 --> Hooks Class Initialized
DEBUG - 2023-08-06 13:44:32 --> UTF-8 Support Enabled
INFO - 2023-08-06 13:44:32 --> Utf8 Class Initialized
INFO - 2023-08-06 13:44:32 --> URI Class Initialized
INFO - 2023-08-06 13:44:32 --> Router Class Initialized
INFO - 2023-08-06 13:44:32 --> Output Class Initialized
INFO - 2023-08-06 13:44:32 --> Security Class Initialized
DEBUG - 2023-08-06 13:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 13:44:32 --> Input Class Initialized
INFO - 2023-08-06 13:44:32 --> Language Class Initialized
INFO - 2023-08-06 13:44:32 --> Loader Class Initialized
INFO - 2023-08-06 13:44:32 --> Helper loaded: url_helper
INFO - 2023-08-06 13:44:32 --> Helper loaded: file_helper
INFO - 2023-08-06 13:44:32 --> Helper loaded: html_helper
INFO - 2023-08-06 13:44:32 --> Helper loaded: text_helper
INFO - 2023-08-06 13:44:32 --> Helper loaded: form_helper
INFO - 2023-08-06 13:44:32 --> Helper loaded: lang_helper
INFO - 2023-08-06 13:44:32 --> Helper loaded: security_helper
INFO - 2023-08-06 13:44:32 --> Helper loaded: cookie_helper
INFO - 2023-08-06 13:44:32 --> Database Driver Class Initialized
INFO - 2023-08-06 13:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 13:44:32 --> Parser Class Initialized
INFO - 2023-08-06 13:44:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 13:44:32 --> Pagination Class Initialized
INFO - 2023-08-06 13:44:32 --> Form Validation Class Initialized
INFO - 2023-08-06 13:44:32 --> Controller Class Initialized
INFO - 2023-08-06 13:44:32 --> Model Class Initialized
DEBUG - 2023-08-06 13:44:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 13:44:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:44:33 --> Model Class Initialized
DEBUG - 2023-08-06 13:44:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:44:33 --> Model Class Initialized
INFO - 2023-08-06 13:44:33 --> Final output sent to browser
DEBUG - 2023-08-06 13:44:33 --> Total execution time: 0.0241
ERROR - 2023-08-06 13:44:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 13:44:35 --> Config Class Initialized
INFO - 2023-08-06 13:44:35 --> Hooks Class Initialized
DEBUG - 2023-08-06 13:44:35 --> UTF-8 Support Enabled
INFO - 2023-08-06 13:44:35 --> Utf8 Class Initialized
INFO - 2023-08-06 13:44:35 --> URI Class Initialized
DEBUG - 2023-08-06 13:44:35 --> No URI present. Default controller set.
INFO - 2023-08-06 13:44:35 --> Router Class Initialized
INFO - 2023-08-06 13:44:35 --> Output Class Initialized
INFO - 2023-08-06 13:44:35 --> Security Class Initialized
DEBUG - 2023-08-06 13:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 13:44:35 --> Input Class Initialized
INFO - 2023-08-06 13:44:35 --> Language Class Initialized
INFO - 2023-08-06 13:44:35 --> Loader Class Initialized
INFO - 2023-08-06 13:44:35 --> Helper loaded: url_helper
INFO - 2023-08-06 13:44:35 --> Helper loaded: file_helper
INFO - 2023-08-06 13:44:35 --> Helper loaded: html_helper
INFO - 2023-08-06 13:44:35 --> Helper loaded: text_helper
INFO - 2023-08-06 13:44:35 --> Helper loaded: form_helper
INFO - 2023-08-06 13:44:35 --> Helper loaded: lang_helper
INFO - 2023-08-06 13:44:35 --> Helper loaded: security_helper
INFO - 2023-08-06 13:44:35 --> Helper loaded: cookie_helper
INFO - 2023-08-06 13:44:35 --> Database Driver Class Initialized
INFO - 2023-08-06 13:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 13:44:35 --> Parser Class Initialized
INFO - 2023-08-06 13:44:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 13:44:35 --> Pagination Class Initialized
INFO - 2023-08-06 13:44:35 --> Form Validation Class Initialized
INFO - 2023-08-06 13:44:35 --> Controller Class Initialized
INFO - 2023-08-06 13:44:35 --> Model Class Initialized
DEBUG - 2023-08-06 13:44:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:44:35 --> Model Class Initialized
DEBUG - 2023-08-06 13:44:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:44:35 --> Model Class Initialized
INFO - 2023-08-06 13:44:35 --> Model Class Initialized
INFO - 2023-08-06 13:44:35 --> Model Class Initialized
INFO - 2023-08-06 13:44:35 --> Model Class Initialized
DEBUG - 2023-08-06 13:44:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 13:44:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:44:35 --> Model Class Initialized
INFO - 2023-08-06 13:44:35 --> Model Class Initialized
INFO - 2023-08-06 13:44:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-06 13:44:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:44:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 13:44:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 13:44:35 --> Model Class Initialized
INFO - 2023-08-06 13:44:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-06 13:44:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-06 13:44:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 13:44:35 --> Final output sent to browser
DEBUG - 2023-08-06 13:44:35 --> Total execution time: 0.0748
ERROR - 2023-08-06 13:44:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 13:44:37 --> Config Class Initialized
INFO - 2023-08-06 13:44:37 --> Hooks Class Initialized
DEBUG - 2023-08-06 13:44:37 --> UTF-8 Support Enabled
INFO - 2023-08-06 13:44:37 --> Utf8 Class Initialized
INFO - 2023-08-06 13:44:37 --> URI Class Initialized
INFO - 2023-08-06 13:44:37 --> Router Class Initialized
INFO - 2023-08-06 13:44:37 --> Output Class Initialized
INFO - 2023-08-06 13:44:37 --> Security Class Initialized
DEBUG - 2023-08-06 13:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 13:44:37 --> Input Class Initialized
INFO - 2023-08-06 13:44:37 --> Language Class Initialized
INFO - 2023-08-06 13:44:37 --> Loader Class Initialized
INFO - 2023-08-06 13:44:37 --> Helper loaded: url_helper
INFO - 2023-08-06 13:44:37 --> Helper loaded: file_helper
INFO - 2023-08-06 13:44:37 --> Helper loaded: html_helper
INFO - 2023-08-06 13:44:37 --> Helper loaded: text_helper
INFO - 2023-08-06 13:44:37 --> Helper loaded: form_helper
INFO - 2023-08-06 13:44:37 --> Helper loaded: lang_helper
INFO - 2023-08-06 13:44:37 --> Helper loaded: security_helper
INFO - 2023-08-06 13:44:37 --> Helper loaded: cookie_helper
INFO - 2023-08-06 13:44:37 --> Database Driver Class Initialized
INFO - 2023-08-06 13:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 13:44:37 --> Parser Class Initialized
INFO - 2023-08-06 13:44:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 13:44:37 --> Pagination Class Initialized
INFO - 2023-08-06 13:44:37 --> Form Validation Class Initialized
INFO - 2023-08-06 13:44:37 --> Controller Class Initialized
INFO - 2023-08-06 13:44:37 --> Model Class Initialized
DEBUG - 2023-08-06 13:44:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:44:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-06 13:44:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:44:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 13:44:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 13:44:37 --> Model Class Initialized
INFO - 2023-08-06 13:44:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 13:44:37 --> Final output sent to browser
DEBUG - 2023-08-06 13:44:37 --> Total execution time: 0.0281
ERROR - 2023-08-06 13:44:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 13:44:38 --> Config Class Initialized
INFO - 2023-08-06 13:44:38 --> Hooks Class Initialized
DEBUG - 2023-08-06 13:44:38 --> UTF-8 Support Enabled
INFO - 2023-08-06 13:44:38 --> Utf8 Class Initialized
INFO - 2023-08-06 13:44:38 --> URI Class Initialized
INFO - 2023-08-06 13:44:38 --> Router Class Initialized
INFO - 2023-08-06 13:44:38 --> Output Class Initialized
INFO - 2023-08-06 13:44:38 --> Security Class Initialized
DEBUG - 2023-08-06 13:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 13:44:38 --> Input Class Initialized
INFO - 2023-08-06 13:44:38 --> Language Class Initialized
INFO - 2023-08-06 13:44:38 --> Loader Class Initialized
INFO - 2023-08-06 13:44:38 --> Helper loaded: url_helper
INFO - 2023-08-06 13:44:38 --> Helper loaded: file_helper
INFO - 2023-08-06 13:44:38 --> Helper loaded: html_helper
INFO - 2023-08-06 13:44:38 --> Helper loaded: text_helper
INFO - 2023-08-06 13:44:38 --> Helper loaded: form_helper
INFO - 2023-08-06 13:44:38 --> Helper loaded: lang_helper
INFO - 2023-08-06 13:44:38 --> Helper loaded: security_helper
INFO - 2023-08-06 13:44:38 --> Helper loaded: cookie_helper
INFO - 2023-08-06 13:44:38 --> Database Driver Class Initialized
INFO - 2023-08-06 13:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 13:44:38 --> Parser Class Initialized
INFO - 2023-08-06 13:44:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 13:44:38 --> Pagination Class Initialized
INFO - 2023-08-06 13:44:38 --> Form Validation Class Initialized
INFO - 2023-08-06 13:44:38 --> Controller Class Initialized
INFO - 2023-08-06 13:44:38 --> Model Class Initialized
DEBUG - 2023-08-06 13:44:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:44:38 --> Model Class Initialized
DEBUG - 2023-08-06 13:44:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:44:38 --> Model Class Initialized
INFO - 2023-08-06 13:44:38 --> Model Class Initialized
INFO - 2023-08-06 13:44:38 --> Model Class Initialized
INFO - 2023-08-06 13:44:38 --> Model Class Initialized
DEBUG - 2023-08-06 13:44:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 13:44:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:44:38 --> Model Class Initialized
INFO - 2023-08-06 13:44:38 --> Model Class Initialized
INFO - 2023-08-06 13:44:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-06 13:44:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 13:44:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 13:44:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 13:44:38 --> Model Class Initialized
INFO - 2023-08-06 13:44:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-06 13:44:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-06 13:44:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 13:44:38 --> Final output sent to browser
DEBUG - 2023-08-06 13:44:38 --> Total execution time: 0.0807
ERROR - 2023-08-06 15:54:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 15:54:30 --> Config Class Initialized
INFO - 2023-08-06 15:54:30 --> Hooks Class Initialized
DEBUG - 2023-08-06 15:54:30 --> UTF-8 Support Enabled
INFO - 2023-08-06 15:54:30 --> Utf8 Class Initialized
INFO - 2023-08-06 15:54:30 --> URI Class Initialized
DEBUG - 2023-08-06 15:54:30 --> No URI present. Default controller set.
INFO - 2023-08-06 15:54:30 --> Router Class Initialized
INFO - 2023-08-06 15:54:30 --> Output Class Initialized
INFO - 2023-08-06 15:54:30 --> Security Class Initialized
DEBUG - 2023-08-06 15:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 15:54:30 --> Input Class Initialized
INFO - 2023-08-06 15:54:30 --> Language Class Initialized
INFO - 2023-08-06 15:54:30 --> Loader Class Initialized
INFO - 2023-08-06 15:54:30 --> Helper loaded: url_helper
INFO - 2023-08-06 15:54:30 --> Helper loaded: file_helper
INFO - 2023-08-06 15:54:30 --> Helper loaded: html_helper
INFO - 2023-08-06 15:54:30 --> Helper loaded: text_helper
INFO - 2023-08-06 15:54:30 --> Helper loaded: form_helper
INFO - 2023-08-06 15:54:30 --> Helper loaded: lang_helper
INFO - 2023-08-06 15:54:30 --> Helper loaded: security_helper
INFO - 2023-08-06 15:54:30 --> Helper loaded: cookie_helper
INFO - 2023-08-06 15:54:30 --> Database Driver Class Initialized
INFO - 2023-08-06 15:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 15:54:30 --> Parser Class Initialized
INFO - 2023-08-06 15:54:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 15:54:30 --> Pagination Class Initialized
INFO - 2023-08-06 15:54:30 --> Form Validation Class Initialized
INFO - 2023-08-06 15:54:30 --> Controller Class Initialized
INFO - 2023-08-06 15:54:30 --> Model Class Initialized
DEBUG - 2023-08-06 15:54:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-06 15:54:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 15:54:31 --> Config Class Initialized
INFO - 2023-08-06 15:54:31 --> Hooks Class Initialized
DEBUG - 2023-08-06 15:54:31 --> UTF-8 Support Enabled
INFO - 2023-08-06 15:54:31 --> Utf8 Class Initialized
INFO - 2023-08-06 15:54:31 --> URI Class Initialized
INFO - 2023-08-06 15:54:31 --> Router Class Initialized
INFO - 2023-08-06 15:54:31 --> Output Class Initialized
INFO - 2023-08-06 15:54:31 --> Security Class Initialized
DEBUG - 2023-08-06 15:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 15:54:31 --> Input Class Initialized
INFO - 2023-08-06 15:54:31 --> Language Class Initialized
INFO - 2023-08-06 15:54:31 --> Loader Class Initialized
INFO - 2023-08-06 15:54:31 --> Helper loaded: url_helper
INFO - 2023-08-06 15:54:31 --> Helper loaded: file_helper
INFO - 2023-08-06 15:54:31 --> Helper loaded: html_helper
INFO - 2023-08-06 15:54:31 --> Helper loaded: text_helper
INFO - 2023-08-06 15:54:31 --> Helper loaded: form_helper
INFO - 2023-08-06 15:54:31 --> Helper loaded: lang_helper
INFO - 2023-08-06 15:54:31 --> Helper loaded: security_helper
INFO - 2023-08-06 15:54:31 --> Helper loaded: cookie_helper
INFO - 2023-08-06 15:54:31 --> Database Driver Class Initialized
INFO - 2023-08-06 15:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 15:54:31 --> Parser Class Initialized
INFO - 2023-08-06 15:54:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 15:54:31 --> Pagination Class Initialized
INFO - 2023-08-06 15:54:31 --> Form Validation Class Initialized
INFO - 2023-08-06 15:54:31 --> Controller Class Initialized
INFO - 2023-08-06 15:54:31 --> Model Class Initialized
DEBUG - 2023-08-06 15:54:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 15:54:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-06 15:54:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 15:54:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 15:54:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 15:54:31 --> Model Class Initialized
INFO - 2023-08-06 15:54:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 15:54:31 --> Final output sent to browser
DEBUG - 2023-08-06 15:54:31 --> Total execution time: 0.0321
ERROR - 2023-08-06 15:54:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 15:54:50 --> Config Class Initialized
INFO - 2023-08-06 15:54:50 --> Hooks Class Initialized
DEBUG - 2023-08-06 15:54:50 --> UTF-8 Support Enabled
INFO - 2023-08-06 15:54:50 --> Utf8 Class Initialized
INFO - 2023-08-06 15:54:50 --> URI Class Initialized
INFO - 2023-08-06 15:54:50 --> Router Class Initialized
INFO - 2023-08-06 15:54:50 --> Output Class Initialized
INFO - 2023-08-06 15:54:50 --> Security Class Initialized
DEBUG - 2023-08-06 15:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 15:54:50 --> Input Class Initialized
INFO - 2023-08-06 15:54:50 --> Language Class Initialized
INFO - 2023-08-06 15:54:50 --> Loader Class Initialized
INFO - 2023-08-06 15:54:50 --> Helper loaded: url_helper
INFO - 2023-08-06 15:54:50 --> Helper loaded: file_helper
INFO - 2023-08-06 15:54:50 --> Helper loaded: html_helper
INFO - 2023-08-06 15:54:50 --> Helper loaded: text_helper
INFO - 2023-08-06 15:54:50 --> Helper loaded: form_helper
INFO - 2023-08-06 15:54:50 --> Helper loaded: lang_helper
INFO - 2023-08-06 15:54:50 --> Helper loaded: security_helper
INFO - 2023-08-06 15:54:50 --> Helper loaded: cookie_helper
INFO - 2023-08-06 15:54:50 --> Database Driver Class Initialized
INFO - 2023-08-06 15:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 15:54:50 --> Parser Class Initialized
INFO - 2023-08-06 15:54:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 15:54:50 --> Pagination Class Initialized
INFO - 2023-08-06 15:54:50 --> Form Validation Class Initialized
INFO - 2023-08-06 15:54:50 --> Controller Class Initialized
INFO - 2023-08-06 15:54:50 --> Model Class Initialized
DEBUG - 2023-08-06 15:54:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 15:54:50 --> Model Class Initialized
INFO - 2023-08-06 15:54:50 --> Final output sent to browser
DEBUG - 2023-08-06 15:54:50 --> Total execution time: 0.0189
ERROR - 2023-08-06 15:54:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 15:54:55 --> Config Class Initialized
INFO - 2023-08-06 15:54:55 --> Hooks Class Initialized
DEBUG - 2023-08-06 15:54:55 --> UTF-8 Support Enabled
INFO - 2023-08-06 15:54:55 --> Utf8 Class Initialized
INFO - 2023-08-06 15:54:55 --> URI Class Initialized
DEBUG - 2023-08-06 15:54:55 --> No URI present. Default controller set.
INFO - 2023-08-06 15:54:55 --> Router Class Initialized
INFO - 2023-08-06 15:54:55 --> Output Class Initialized
INFO - 2023-08-06 15:54:55 --> Security Class Initialized
DEBUG - 2023-08-06 15:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 15:54:55 --> Input Class Initialized
INFO - 2023-08-06 15:54:55 --> Language Class Initialized
INFO - 2023-08-06 15:54:55 --> Loader Class Initialized
INFO - 2023-08-06 15:54:55 --> Helper loaded: url_helper
INFO - 2023-08-06 15:54:55 --> Helper loaded: file_helper
INFO - 2023-08-06 15:54:55 --> Helper loaded: html_helper
INFO - 2023-08-06 15:54:55 --> Helper loaded: text_helper
INFO - 2023-08-06 15:54:55 --> Helper loaded: form_helper
INFO - 2023-08-06 15:54:55 --> Helper loaded: lang_helper
INFO - 2023-08-06 15:54:55 --> Helper loaded: security_helper
INFO - 2023-08-06 15:54:55 --> Helper loaded: cookie_helper
INFO - 2023-08-06 15:54:55 --> Database Driver Class Initialized
INFO - 2023-08-06 15:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 15:54:55 --> Parser Class Initialized
INFO - 2023-08-06 15:54:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 15:54:55 --> Pagination Class Initialized
INFO - 2023-08-06 15:54:55 --> Form Validation Class Initialized
INFO - 2023-08-06 15:54:56 --> Controller Class Initialized
INFO - 2023-08-06 15:54:56 --> Model Class Initialized
DEBUG - 2023-08-06 15:54:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 15:54:56 --> Model Class Initialized
DEBUG - 2023-08-06 15:54:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 15:54:56 --> Model Class Initialized
INFO - 2023-08-06 15:54:56 --> Model Class Initialized
INFO - 2023-08-06 15:54:56 --> Model Class Initialized
INFO - 2023-08-06 15:54:56 --> Model Class Initialized
DEBUG - 2023-08-06 15:54:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-06 15:54:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-06 15:54:56 --> Model Class Initialized
INFO - 2023-08-06 15:54:56 --> Model Class Initialized
INFO - 2023-08-06 15:54:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-06 15:54:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 15:54:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 15:54:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 15:54:56 --> Model Class Initialized
INFO - 2023-08-06 15:54:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-06 15:54:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-06 15:54:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 15:54:56 --> Final output sent to browser
DEBUG - 2023-08-06 15:54:56 --> Total execution time: 0.0753
ERROR - 2023-08-06 15:55:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 15:55:17 --> Config Class Initialized
INFO - 2023-08-06 15:55:17 --> Hooks Class Initialized
DEBUG - 2023-08-06 15:55:17 --> UTF-8 Support Enabled
INFO - 2023-08-06 15:55:17 --> Utf8 Class Initialized
INFO - 2023-08-06 15:55:17 --> URI Class Initialized
INFO - 2023-08-06 15:55:17 --> Router Class Initialized
INFO - 2023-08-06 15:55:17 --> Output Class Initialized
INFO - 2023-08-06 15:55:17 --> Security Class Initialized
DEBUG - 2023-08-06 15:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 15:55:17 --> Input Class Initialized
INFO - 2023-08-06 15:55:17 --> Language Class Initialized
INFO - 2023-08-06 15:55:17 --> Loader Class Initialized
INFO - 2023-08-06 15:55:17 --> Helper loaded: url_helper
INFO - 2023-08-06 15:55:17 --> Helper loaded: file_helper
INFO - 2023-08-06 15:55:17 --> Helper loaded: html_helper
INFO - 2023-08-06 15:55:17 --> Helper loaded: text_helper
INFO - 2023-08-06 15:55:17 --> Helper loaded: form_helper
INFO - 2023-08-06 15:55:17 --> Helper loaded: lang_helper
INFO - 2023-08-06 15:55:17 --> Helper loaded: security_helper
INFO - 2023-08-06 15:55:17 --> Helper loaded: cookie_helper
INFO - 2023-08-06 15:55:17 --> Database Driver Class Initialized
INFO - 2023-08-06 15:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 15:55:17 --> Parser Class Initialized
INFO - 2023-08-06 15:55:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 15:55:17 --> Pagination Class Initialized
INFO - 2023-08-06 15:55:17 --> Form Validation Class Initialized
INFO - 2023-08-06 15:55:17 --> Controller Class Initialized
INFO - 2023-08-06 15:55:17 --> Model Class Initialized
INFO - 2023-08-06 15:55:17 --> Model Class Initialized
INFO - 2023-08-06 15:55:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-08-06 15:55:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 15:55:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 15:55:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 15:55:17 --> Model Class Initialized
INFO - 2023-08-06 15:55:17 --> Model Class Initialized
INFO - 2023-08-06 15:55:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-06 15:55:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-06 15:55:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 15:55:17 --> Final output sent to browser
DEBUG - 2023-08-06 15:55:17 --> Total execution time: 0.0636
ERROR - 2023-08-06 15:55:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 15:55:23 --> Config Class Initialized
INFO - 2023-08-06 15:55:23 --> Hooks Class Initialized
DEBUG - 2023-08-06 15:55:23 --> UTF-8 Support Enabled
INFO - 2023-08-06 15:55:23 --> Utf8 Class Initialized
INFO - 2023-08-06 15:55:23 --> URI Class Initialized
INFO - 2023-08-06 15:55:23 --> Router Class Initialized
INFO - 2023-08-06 15:55:23 --> Output Class Initialized
INFO - 2023-08-06 15:55:23 --> Security Class Initialized
DEBUG - 2023-08-06 15:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 15:55:23 --> Input Class Initialized
INFO - 2023-08-06 15:55:23 --> Language Class Initialized
INFO - 2023-08-06 15:55:23 --> Loader Class Initialized
INFO - 2023-08-06 15:55:23 --> Helper loaded: url_helper
INFO - 2023-08-06 15:55:23 --> Helper loaded: file_helper
INFO - 2023-08-06 15:55:23 --> Helper loaded: html_helper
INFO - 2023-08-06 15:55:23 --> Helper loaded: text_helper
INFO - 2023-08-06 15:55:23 --> Helper loaded: form_helper
INFO - 2023-08-06 15:55:23 --> Helper loaded: lang_helper
INFO - 2023-08-06 15:55:23 --> Helper loaded: security_helper
INFO - 2023-08-06 15:55:23 --> Helper loaded: cookie_helper
INFO - 2023-08-06 15:55:23 --> Database Driver Class Initialized
INFO - 2023-08-06 15:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 15:55:23 --> Parser Class Initialized
INFO - 2023-08-06 15:55:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 15:55:23 --> Pagination Class Initialized
INFO - 2023-08-06 15:55:23 --> Form Validation Class Initialized
INFO - 2023-08-06 15:55:23 --> Controller Class Initialized
INFO - 2023-08-06 15:55:23 --> Model Class Initialized
INFO - 2023-08-06 15:55:23 --> Model Class Initialized
INFO - 2023-08-06 15:55:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-08-06 15:55:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-06 15:55:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-06 15:55:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-06 15:55:23 --> Model Class Initialized
INFO - 2023-08-06 15:55:23 --> Model Class Initialized
INFO - 2023-08-06 15:55:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-06 15:55:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-06 15:55:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-06 15:55:23 --> Final output sent to browser
DEBUG - 2023-08-06 15:55:23 --> Total execution time: 0.0586
ERROR - 2023-08-06 15:55:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 15:55:30 --> Config Class Initialized
INFO - 2023-08-06 15:55:30 --> Hooks Class Initialized
DEBUG - 2023-08-06 15:55:30 --> UTF-8 Support Enabled
INFO - 2023-08-06 15:55:30 --> Utf8 Class Initialized
INFO - 2023-08-06 15:55:30 --> URI Class Initialized
INFO - 2023-08-06 15:55:30 --> Router Class Initialized
INFO - 2023-08-06 15:55:30 --> Output Class Initialized
INFO - 2023-08-06 15:55:30 --> Security Class Initialized
DEBUG - 2023-08-06 15:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 15:55:30 --> Input Class Initialized
INFO - 2023-08-06 15:55:30 --> Language Class Initialized
INFO - 2023-08-06 15:55:30 --> Loader Class Initialized
INFO - 2023-08-06 15:55:30 --> Helper loaded: url_helper
INFO - 2023-08-06 15:55:30 --> Helper loaded: file_helper
INFO - 2023-08-06 15:55:30 --> Helper loaded: html_helper
INFO - 2023-08-06 15:55:30 --> Helper loaded: text_helper
INFO - 2023-08-06 15:55:30 --> Helper loaded: form_helper
INFO - 2023-08-06 15:55:30 --> Helper loaded: lang_helper
INFO - 2023-08-06 15:55:30 --> Helper loaded: security_helper
INFO - 2023-08-06 15:55:30 --> Helper loaded: cookie_helper
INFO - 2023-08-06 15:55:30 --> Database Driver Class Initialized
INFO - 2023-08-06 15:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 15:55:30 --> Parser Class Initialized
INFO - 2023-08-06 15:55:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 15:55:30 --> Pagination Class Initialized
INFO - 2023-08-06 15:55:30 --> Form Validation Class Initialized
INFO - 2023-08-06 15:55:30 --> Controller Class Initialized
INFO - 2023-08-06 15:55:30 --> Model Class Initialized
INFO - 2023-08-06 15:55:30 --> Model Class Initialized
INFO - 2023-08-06 15:55:30 --> Final output sent to browser
DEBUG - 2023-08-06 15:55:30 --> Total execution time: 0.0259
ERROR - 2023-08-06 18:21:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-06 18:21:05 --> Config Class Initialized
INFO - 2023-08-06 18:21:05 --> Hooks Class Initialized
DEBUG - 2023-08-06 18:21:05 --> UTF-8 Support Enabled
INFO - 2023-08-06 18:21:05 --> Utf8 Class Initialized
INFO - 2023-08-06 18:21:05 --> URI Class Initialized
DEBUG - 2023-08-06 18:21:05 --> No URI present. Default controller set.
INFO - 2023-08-06 18:21:05 --> Router Class Initialized
INFO - 2023-08-06 18:21:05 --> Output Class Initialized
INFO - 2023-08-06 18:21:05 --> Security Class Initialized
DEBUG - 2023-08-06 18:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-06 18:21:05 --> Input Class Initialized
INFO - 2023-08-06 18:21:05 --> Language Class Initialized
INFO - 2023-08-06 18:21:05 --> Loader Class Initialized
INFO - 2023-08-06 18:21:05 --> Helper loaded: url_helper
INFO - 2023-08-06 18:21:05 --> Helper loaded: file_helper
INFO - 2023-08-06 18:21:05 --> Helper loaded: html_helper
INFO - 2023-08-06 18:21:05 --> Helper loaded: text_helper
INFO - 2023-08-06 18:21:05 --> Helper loaded: form_helper
INFO - 2023-08-06 18:21:05 --> Helper loaded: lang_helper
INFO - 2023-08-06 18:21:05 --> Helper loaded: security_helper
INFO - 2023-08-06 18:21:05 --> Helper loaded: cookie_helper
INFO - 2023-08-06 18:21:05 --> Database Driver Class Initialized
INFO - 2023-08-06 18:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-06 18:21:05 --> Parser Class Initialized
INFO - 2023-08-06 18:21:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-06 18:21:05 --> Pagination Class Initialized
INFO - 2023-08-06 18:21:05 --> Form Validation Class Initialized
INFO - 2023-08-06 18:21:05 --> Controller Class Initialized
INFO - 2023-08-06 18:21:05 --> Model Class Initialized
DEBUG - 2023-08-06 18:21:05 --> Session class already loaded. Second attempt ignored.
