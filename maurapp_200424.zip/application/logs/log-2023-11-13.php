<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-13 05:06:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-13 05:06:04 --> Config Class Initialized
INFO - 2023-11-13 05:06:04 --> Hooks Class Initialized
DEBUG - 2023-11-13 05:06:04 --> UTF-8 Support Enabled
INFO - 2023-11-13 05:06:04 --> Utf8 Class Initialized
INFO - 2023-11-13 05:06:04 --> URI Class Initialized
INFO - 2023-11-13 05:06:04 --> Router Class Initialized
INFO - 2023-11-13 05:06:04 --> Output Class Initialized
INFO - 2023-11-13 05:06:04 --> Security Class Initialized
DEBUG - 2023-11-13 05:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-13 05:06:04 --> Input Class Initialized
INFO - 2023-11-13 05:06:04 --> Language Class Initialized
ERROR - 2023-11-13 05:06:04 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-11-13 12:46:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-13 12:46:27 --> Config Class Initialized
INFO - 2023-11-13 12:46:27 --> Hooks Class Initialized
DEBUG - 2023-11-13 12:46:27 --> UTF-8 Support Enabled
INFO - 2023-11-13 12:46:27 --> Utf8 Class Initialized
INFO - 2023-11-13 12:46:27 --> URI Class Initialized
DEBUG - 2023-11-13 12:46:27 --> No URI present. Default controller set.
INFO - 2023-11-13 12:46:27 --> Router Class Initialized
INFO - 2023-11-13 12:46:27 --> Output Class Initialized
INFO - 2023-11-13 12:46:27 --> Security Class Initialized
DEBUG - 2023-11-13 12:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-13 12:46:27 --> Input Class Initialized
INFO - 2023-11-13 12:46:27 --> Language Class Initialized
INFO - 2023-11-13 12:46:27 --> Loader Class Initialized
INFO - 2023-11-13 12:46:27 --> Helper loaded: url_helper
INFO - 2023-11-13 12:46:27 --> Helper loaded: file_helper
INFO - 2023-11-13 12:46:27 --> Helper loaded: html_helper
INFO - 2023-11-13 12:46:27 --> Helper loaded: text_helper
INFO - 2023-11-13 12:46:27 --> Helper loaded: form_helper
INFO - 2023-11-13 12:46:27 --> Helper loaded: lang_helper
INFO - 2023-11-13 12:46:27 --> Helper loaded: security_helper
INFO - 2023-11-13 12:46:27 --> Helper loaded: cookie_helper
INFO - 2023-11-13 12:46:27 --> Database Driver Class Initialized
INFO - 2023-11-13 12:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-13 12:46:27 --> Parser Class Initialized
INFO - 2023-11-13 12:46:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-13 12:46:27 --> Pagination Class Initialized
INFO - 2023-11-13 12:46:27 --> Form Validation Class Initialized
INFO - 2023-11-13 12:46:27 --> Controller Class Initialized
INFO - 2023-11-13 12:46:27 --> Model Class Initialized
DEBUG - 2023-11-13 12:46:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-13 14:55:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-13 14:55:21 --> Config Class Initialized
INFO - 2023-11-13 14:55:21 --> Hooks Class Initialized
DEBUG - 2023-11-13 14:55:21 --> UTF-8 Support Enabled
INFO - 2023-11-13 14:55:21 --> Utf8 Class Initialized
INFO - 2023-11-13 14:55:21 --> URI Class Initialized
DEBUG - 2023-11-13 14:55:21 --> No URI present. Default controller set.
INFO - 2023-11-13 14:55:21 --> Router Class Initialized
INFO - 2023-11-13 14:55:21 --> Output Class Initialized
INFO - 2023-11-13 14:55:21 --> Security Class Initialized
DEBUG - 2023-11-13 14:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-13 14:55:21 --> Input Class Initialized
INFO - 2023-11-13 14:55:21 --> Language Class Initialized
INFO - 2023-11-13 14:55:21 --> Loader Class Initialized
INFO - 2023-11-13 14:55:21 --> Helper loaded: url_helper
INFO - 2023-11-13 14:55:21 --> Helper loaded: file_helper
INFO - 2023-11-13 14:55:21 --> Helper loaded: html_helper
INFO - 2023-11-13 14:55:21 --> Helper loaded: text_helper
INFO - 2023-11-13 14:55:21 --> Helper loaded: form_helper
INFO - 2023-11-13 14:55:21 --> Helper loaded: lang_helper
INFO - 2023-11-13 14:55:21 --> Helper loaded: security_helper
INFO - 2023-11-13 14:55:21 --> Helper loaded: cookie_helper
INFO - 2023-11-13 14:55:21 --> Database Driver Class Initialized
INFO - 2023-11-13 14:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-13 14:55:21 --> Parser Class Initialized
INFO - 2023-11-13 14:55:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-13 14:55:21 --> Pagination Class Initialized
INFO - 2023-11-13 14:55:21 --> Form Validation Class Initialized
INFO - 2023-11-13 14:55:21 --> Controller Class Initialized
INFO - 2023-11-13 14:55:21 --> Model Class Initialized
DEBUG - 2023-11-13 14:55:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-13 14:55:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-13 14:55:22 --> Config Class Initialized
INFO - 2023-11-13 14:55:22 --> Hooks Class Initialized
DEBUG - 2023-11-13 14:55:22 --> UTF-8 Support Enabled
INFO - 2023-11-13 14:55:22 --> Utf8 Class Initialized
INFO - 2023-11-13 14:55:22 --> URI Class Initialized
INFO - 2023-11-13 14:55:22 --> Router Class Initialized
INFO - 2023-11-13 14:55:22 --> Output Class Initialized
INFO - 2023-11-13 14:55:22 --> Security Class Initialized
DEBUG - 2023-11-13 14:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-13 14:55:22 --> Input Class Initialized
INFO - 2023-11-13 14:55:22 --> Language Class Initialized
INFO - 2023-11-13 14:55:22 --> Loader Class Initialized
INFO - 2023-11-13 14:55:22 --> Helper loaded: url_helper
INFO - 2023-11-13 14:55:22 --> Helper loaded: file_helper
INFO - 2023-11-13 14:55:22 --> Helper loaded: html_helper
INFO - 2023-11-13 14:55:22 --> Helper loaded: text_helper
INFO - 2023-11-13 14:55:22 --> Helper loaded: form_helper
INFO - 2023-11-13 14:55:22 --> Helper loaded: lang_helper
INFO - 2023-11-13 14:55:22 --> Helper loaded: security_helper
INFO - 2023-11-13 14:55:22 --> Helper loaded: cookie_helper
INFO - 2023-11-13 14:55:22 --> Database Driver Class Initialized
INFO - 2023-11-13 14:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-13 14:55:22 --> Parser Class Initialized
INFO - 2023-11-13 14:55:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-13 14:55:22 --> Pagination Class Initialized
INFO - 2023-11-13 14:55:22 --> Form Validation Class Initialized
INFO - 2023-11-13 14:55:22 --> Controller Class Initialized
INFO - 2023-11-13 14:55:22 --> Model Class Initialized
DEBUG - 2023-11-13 14:55:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-13 14:55:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-13 14:55:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-13 14:55:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-13 14:55:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-13 14:55:22 --> Model Class Initialized
INFO - 2023-11-13 14:55:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-13 14:55:22 --> Final output sent to browser
DEBUG - 2023-11-13 14:55:22 --> Total execution time: 0.0381
ERROR - 2023-11-13 15:36:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-13 15:36:06 --> Config Class Initialized
INFO - 2023-11-13 15:36:06 --> Hooks Class Initialized
DEBUG - 2023-11-13 15:36:06 --> UTF-8 Support Enabled
INFO - 2023-11-13 15:36:06 --> Utf8 Class Initialized
INFO - 2023-11-13 15:36:06 --> URI Class Initialized
INFO - 2023-11-13 15:36:06 --> Router Class Initialized
INFO - 2023-11-13 15:36:06 --> Output Class Initialized
INFO - 2023-11-13 15:36:06 --> Security Class Initialized
DEBUG - 2023-11-13 15:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-13 15:36:06 --> Input Class Initialized
INFO - 2023-11-13 15:36:06 --> Language Class Initialized
ERROR - 2023-11-13 15:36:06 --> 404 Page Not Found: Well-known/assetlinks.json
