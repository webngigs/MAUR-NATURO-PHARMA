<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-20 04:07:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-20 04:07:02 --> Config Class Initialized
INFO - 2023-11-20 04:07:02 --> Hooks Class Initialized
DEBUG - 2023-11-20 04:07:02 --> UTF-8 Support Enabled
INFO - 2023-11-20 04:07:02 --> Utf8 Class Initialized
INFO - 2023-11-20 04:07:02 --> URI Class Initialized
INFO - 2023-11-20 04:07:02 --> Router Class Initialized
INFO - 2023-11-20 04:07:02 --> Output Class Initialized
INFO - 2023-11-20 04:07:02 --> Security Class Initialized
DEBUG - 2023-11-20 04:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 04:07:02 --> Input Class Initialized
INFO - 2023-11-20 04:07:02 --> Language Class Initialized
ERROR - 2023-11-20 04:07:02 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-11-20 12:47:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-20 12:47:13 --> Config Class Initialized
INFO - 2023-11-20 12:47:13 --> Hooks Class Initialized
DEBUG - 2023-11-20 12:47:13 --> UTF-8 Support Enabled
INFO - 2023-11-20 12:47:13 --> Utf8 Class Initialized
INFO - 2023-11-20 12:47:13 --> URI Class Initialized
DEBUG - 2023-11-20 12:47:13 --> No URI present. Default controller set.
INFO - 2023-11-20 12:47:13 --> Router Class Initialized
INFO - 2023-11-20 12:47:13 --> Output Class Initialized
INFO - 2023-11-20 12:47:13 --> Security Class Initialized
DEBUG - 2023-11-20 12:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 12:47:13 --> Input Class Initialized
INFO - 2023-11-20 12:47:13 --> Language Class Initialized
INFO - 2023-11-20 12:47:13 --> Loader Class Initialized
INFO - 2023-11-20 12:47:13 --> Helper loaded: url_helper
INFO - 2023-11-20 12:47:13 --> Helper loaded: file_helper
INFO - 2023-11-20 12:47:13 --> Helper loaded: html_helper
INFO - 2023-11-20 12:47:13 --> Helper loaded: text_helper
INFO - 2023-11-20 12:47:13 --> Helper loaded: form_helper
INFO - 2023-11-20 12:47:13 --> Helper loaded: lang_helper
INFO - 2023-11-20 12:47:13 --> Helper loaded: security_helper
INFO - 2023-11-20 12:47:13 --> Helper loaded: cookie_helper
INFO - 2023-11-20 12:47:13 --> Database Driver Class Initialized
INFO - 2023-11-20 12:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 12:47:13 --> Parser Class Initialized
INFO - 2023-11-20 12:47:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-20 12:47:13 --> Pagination Class Initialized
INFO - 2023-11-20 12:47:13 --> Form Validation Class Initialized
INFO - 2023-11-20 12:47:13 --> Controller Class Initialized
INFO - 2023-11-20 12:47:13 --> Model Class Initialized
DEBUG - 2023-11-20 12:47:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-20 12:47:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-20 12:47:13 --> Config Class Initialized
INFO - 2023-11-20 12:47:13 --> Hooks Class Initialized
DEBUG - 2023-11-20 12:47:13 --> UTF-8 Support Enabled
INFO - 2023-11-20 12:47:13 --> Utf8 Class Initialized
INFO - 2023-11-20 12:47:13 --> URI Class Initialized
INFO - 2023-11-20 12:47:13 --> Router Class Initialized
INFO - 2023-11-20 12:47:13 --> Output Class Initialized
INFO - 2023-11-20 12:47:13 --> Security Class Initialized
DEBUG - 2023-11-20 12:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 12:47:13 --> Input Class Initialized
INFO - 2023-11-20 12:47:13 --> Language Class Initialized
INFO - 2023-11-20 12:47:13 --> Loader Class Initialized
INFO - 2023-11-20 12:47:13 --> Helper loaded: url_helper
INFO - 2023-11-20 12:47:13 --> Helper loaded: file_helper
INFO - 2023-11-20 12:47:13 --> Helper loaded: html_helper
INFO - 2023-11-20 12:47:13 --> Helper loaded: text_helper
INFO - 2023-11-20 12:47:13 --> Helper loaded: form_helper
INFO - 2023-11-20 12:47:13 --> Helper loaded: lang_helper
INFO - 2023-11-20 12:47:13 --> Helper loaded: security_helper
INFO - 2023-11-20 12:47:13 --> Helper loaded: cookie_helper
INFO - 2023-11-20 12:47:13 --> Database Driver Class Initialized
INFO - 2023-11-20 12:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 12:47:13 --> Parser Class Initialized
INFO - 2023-11-20 12:47:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-20 12:47:13 --> Pagination Class Initialized
INFO - 2023-11-20 12:47:13 --> Form Validation Class Initialized
INFO - 2023-11-20 12:47:13 --> Controller Class Initialized
INFO - 2023-11-20 12:47:13 --> Model Class Initialized
DEBUG - 2023-11-20 12:47:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-20 12:47:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-20 12:47:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-20 12:47:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-20 12:47:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-20 12:47:13 --> Model Class Initialized
INFO - 2023-11-20 12:47:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-20 12:47:13 --> Final output sent to browser
DEBUG - 2023-11-20 12:47:13 --> Total execution time: 0.0332
ERROR - 2023-11-20 12:47:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-20 12:47:38 --> Config Class Initialized
INFO - 2023-11-20 12:47:38 --> Hooks Class Initialized
DEBUG - 2023-11-20 12:47:38 --> UTF-8 Support Enabled
INFO - 2023-11-20 12:47:38 --> Utf8 Class Initialized
INFO - 2023-11-20 12:47:38 --> URI Class Initialized
INFO - 2023-11-20 12:47:38 --> Router Class Initialized
INFO - 2023-11-20 12:47:38 --> Output Class Initialized
INFO - 2023-11-20 12:47:38 --> Security Class Initialized
DEBUG - 2023-11-20 12:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 12:47:38 --> Input Class Initialized
INFO - 2023-11-20 12:47:38 --> Language Class Initialized
INFO - 2023-11-20 12:47:38 --> Loader Class Initialized
INFO - 2023-11-20 12:47:38 --> Helper loaded: url_helper
INFO - 2023-11-20 12:47:38 --> Helper loaded: file_helper
INFO - 2023-11-20 12:47:38 --> Helper loaded: html_helper
INFO - 2023-11-20 12:47:38 --> Helper loaded: text_helper
INFO - 2023-11-20 12:47:38 --> Helper loaded: form_helper
INFO - 2023-11-20 12:47:38 --> Helper loaded: lang_helper
INFO - 2023-11-20 12:47:38 --> Helper loaded: security_helper
INFO - 2023-11-20 12:47:38 --> Helper loaded: cookie_helper
INFO - 2023-11-20 12:47:38 --> Database Driver Class Initialized
INFO - 2023-11-20 12:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 12:47:38 --> Parser Class Initialized
INFO - 2023-11-20 12:47:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-20 12:47:38 --> Pagination Class Initialized
INFO - 2023-11-20 12:47:38 --> Form Validation Class Initialized
INFO - 2023-11-20 12:47:38 --> Controller Class Initialized
INFO - 2023-11-20 12:47:38 --> Model Class Initialized
DEBUG - 2023-11-20 12:47:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-20 12:47:38 --> Model Class Initialized
INFO - 2023-11-20 12:47:38 --> Final output sent to browser
DEBUG - 2023-11-20 12:47:38 --> Total execution time: 0.0206
ERROR - 2023-11-20 12:47:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-20 12:47:38 --> Config Class Initialized
INFO - 2023-11-20 12:47:38 --> Hooks Class Initialized
DEBUG - 2023-11-20 12:47:38 --> UTF-8 Support Enabled
INFO - 2023-11-20 12:47:38 --> Utf8 Class Initialized
INFO - 2023-11-20 12:47:38 --> URI Class Initialized
INFO - 2023-11-20 12:47:38 --> Router Class Initialized
INFO - 2023-11-20 12:47:38 --> Output Class Initialized
INFO - 2023-11-20 12:47:38 --> Security Class Initialized
DEBUG - 2023-11-20 12:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 12:47:38 --> Input Class Initialized
INFO - 2023-11-20 12:47:38 --> Language Class Initialized
INFO - 2023-11-20 12:47:38 --> Loader Class Initialized
INFO - 2023-11-20 12:47:38 --> Helper loaded: url_helper
INFO - 2023-11-20 12:47:38 --> Helper loaded: file_helper
INFO - 2023-11-20 12:47:38 --> Helper loaded: html_helper
INFO - 2023-11-20 12:47:38 --> Helper loaded: text_helper
INFO - 2023-11-20 12:47:38 --> Helper loaded: form_helper
INFO - 2023-11-20 12:47:38 --> Helper loaded: lang_helper
INFO - 2023-11-20 12:47:38 --> Helper loaded: security_helper
INFO - 2023-11-20 12:47:38 --> Helper loaded: cookie_helper
INFO - 2023-11-20 12:47:38 --> Database Driver Class Initialized
INFO - 2023-11-20 12:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 12:47:38 --> Parser Class Initialized
INFO - 2023-11-20 12:47:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-20 12:47:38 --> Pagination Class Initialized
INFO - 2023-11-20 12:47:38 --> Form Validation Class Initialized
INFO - 2023-11-20 12:47:38 --> Controller Class Initialized
INFO - 2023-11-20 12:47:38 --> Model Class Initialized
DEBUG - 2023-11-20 12:47:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-20 12:47:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-20 12:47:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-20 12:47:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-20 12:47:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-20 12:47:38 --> Model Class Initialized
INFO - 2023-11-20 12:47:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-20 12:47:38 --> Final output sent to browser
DEBUG - 2023-11-20 12:47:38 --> Total execution time: 0.0294
ERROR - 2023-11-20 12:48:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-20 12:48:08 --> Config Class Initialized
INFO - 2023-11-20 12:48:08 --> Hooks Class Initialized
DEBUG - 2023-11-20 12:48:08 --> UTF-8 Support Enabled
INFO - 2023-11-20 12:48:08 --> Utf8 Class Initialized
INFO - 2023-11-20 12:48:08 --> URI Class Initialized
INFO - 2023-11-20 12:48:08 --> Router Class Initialized
INFO - 2023-11-20 12:48:08 --> Output Class Initialized
INFO - 2023-11-20 12:48:08 --> Security Class Initialized
DEBUG - 2023-11-20 12:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 12:48:08 --> Input Class Initialized
INFO - 2023-11-20 12:48:08 --> Language Class Initialized
INFO - 2023-11-20 12:48:08 --> Loader Class Initialized
INFO - 2023-11-20 12:48:08 --> Helper loaded: url_helper
INFO - 2023-11-20 12:48:08 --> Helper loaded: file_helper
INFO - 2023-11-20 12:48:08 --> Helper loaded: html_helper
INFO - 2023-11-20 12:48:08 --> Helper loaded: text_helper
INFO - 2023-11-20 12:48:08 --> Helper loaded: form_helper
INFO - 2023-11-20 12:48:08 --> Helper loaded: lang_helper
INFO - 2023-11-20 12:48:08 --> Helper loaded: security_helper
INFO - 2023-11-20 12:48:08 --> Helper loaded: cookie_helper
INFO - 2023-11-20 12:48:08 --> Database Driver Class Initialized
INFO - 2023-11-20 12:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 12:48:08 --> Parser Class Initialized
INFO - 2023-11-20 12:48:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-20 12:48:08 --> Pagination Class Initialized
INFO - 2023-11-20 12:48:08 --> Form Validation Class Initialized
INFO - 2023-11-20 12:48:08 --> Controller Class Initialized
INFO - 2023-11-20 12:48:08 --> Model Class Initialized
DEBUG - 2023-11-20 12:48:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-20 12:48:08 --> Model Class Initialized
INFO - 2023-11-20 12:48:08 --> Final output sent to browser
DEBUG - 2023-11-20 12:48:08 --> Total execution time: 0.0207
ERROR - 2023-11-20 12:48:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-20 12:48:08 --> Config Class Initialized
INFO - 2023-11-20 12:48:08 --> Hooks Class Initialized
DEBUG - 2023-11-20 12:48:08 --> UTF-8 Support Enabled
INFO - 2023-11-20 12:48:08 --> Utf8 Class Initialized
INFO - 2023-11-20 12:48:08 --> URI Class Initialized
INFO - 2023-11-20 12:48:08 --> Router Class Initialized
INFO - 2023-11-20 12:48:08 --> Output Class Initialized
INFO - 2023-11-20 12:48:08 --> Security Class Initialized
DEBUG - 2023-11-20 12:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 12:48:08 --> Input Class Initialized
INFO - 2023-11-20 12:48:08 --> Language Class Initialized
INFO - 2023-11-20 12:48:08 --> Loader Class Initialized
INFO - 2023-11-20 12:48:08 --> Helper loaded: url_helper
INFO - 2023-11-20 12:48:08 --> Helper loaded: file_helper
INFO - 2023-11-20 12:48:08 --> Helper loaded: html_helper
INFO - 2023-11-20 12:48:08 --> Helper loaded: text_helper
INFO - 2023-11-20 12:48:08 --> Helper loaded: form_helper
INFO - 2023-11-20 12:48:08 --> Helper loaded: lang_helper
INFO - 2023-11-20 12:48:08 --> Helper loaded: security_helper
INFO - 2023-11-20 12:48:08 --> Helper loaded: cookie_helper
INFO - 2023-11-20 12:48:08 --> Database Driver Class Initialized
INFO - 2023-11-20 12:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 12:48:08 --> Parser Class Initialized
INFO - 2023-11-20 12:48:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-20 12:48:08 --> Pagination Class Initialized
INFO - 2023-11-20 12:48:08 --> Form Validation Class Initialized
INFO - 2023-11-20 12:48:08 --> Controller Class Initialized
INFO - 2023-11-20 12:48:08 --> Model Class Initialized
DEBUG - 2023-11-20 12:48:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-20 12:48:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-20 12:48:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-20 12:48:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-20 12:48:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-20 12:48:08 --> Model Class Initialized
INFO - 2023-11-20 12:48:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-20 12:48:08 --> Final output sent to browser
DEBUG - 2023-11-20 12:48:08 --> Total execution time: 0.0300
ERROR - 2023-11-20 15:37:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-20 15:37:04 --> Config Class Initialized
INFO - 2023-11-20 15:37:04 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:37:04 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:37:04 --> Utf8 Class Initialized
INFO - 2023-11-20 15:37:04 --> URI Class Initialized
INFO - 2023-11-20 15:37:04 --> Router Class Initialized
INFO - 2023-11-20 15:37:04 --> Output Class Initialized
INFO - 2023-11-20 15:37:04 --> Security Class Initialized
DEBUG - 2023-11-20 15:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:37:04 --> Input Class Initialized
INFO - 2023-11-20 15:37:04 --> Language Class Initialized
ERROR - 2023-11-20 15:37:04 --> 404 Page Not Found: Well-known/assetlinks.json
