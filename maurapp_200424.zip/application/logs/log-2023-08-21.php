<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-21 01:13:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 01:13:10 --> Config Class Initialized
INFO - 2023-08-21 01:13:10 --> Hooks Class Initialized
DEBUG - 2023-08-21 01:13:10 --> UTF-8 Support Enabled
INFO - 2023-08-21 01:13:10 --> Utf8 Class Initialized
INFO - 2023-08-21 01:13:10 --> URI Class Initialized
DEBUG - 2023-08-21 01:13:10 --> No URI present. Default controller set.
INFO - 2023-08-21 01:13:10 --> Router Class Initialized
INFO - 2023-08-21 01:13:10 --> Output Class Initialized
INFO - 2023-08-21 01:13:10 --> Security Class Initialized
DEBUG - 2023-08-21 01:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 01:13:10 --> Input Class Initialized
INFO - 2023-08-21 01:13:10 --> Language Class Initialized
INFO - 2023-08-21 01:13:10 --> Loader Class Initialized
INFO - 2023-08-21 01:13:10 --> Helper loaded: url_helper
INFO - 2023-08-21 01:13:10 --> Helper loaded: file_helper
INFO - 2023-08-21 01:13:10 --> Helper loaded: html_helper
INFO - 2023-08-21 01:13:10 --> Helper loaded: text_helper
INFO - 2023-08-21 01:13:10 --> Helper loaded: form_helper
INFO - 2023-08-21 01:13:10 --> Helper loaded: lang_helper
INFO - 2023-08-21 01:13:10 --> Helper loaded: security_helper
INFO - 2023-08-21 01:13:10 --> Helper loaded: cookie_helper
INFO - 2023-08-21 01:13:10 --> Database Driver Class Initialized
INFO - 2023-08-21 01:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 01:13:10 --> Parser Class Initialized
INFO - 2023-08-21 01:13:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 01:13:10 --> Pagination Class Initialized
INFO - 2023-08-21 01:13:10 --> Form Validation Class Initialized
INFO - 2023-08-21 01:13:10 --> Controller Class Initialized
INFO - 2023-08-21 01:13:10 --> Model Class Initialized
DEBUG - 2023-08-21 01:13:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-21 01:13:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 01:13:11 --> Config Class Initialized
INFO - 2023-08-21 01:13:11 --> Hooks Class Initialized
DEBUG - 2023-08-21 01:13:11 --> UTF-8 Support Enabled
INFO - 2023-08-21 01:13:11 --> Utf8 Class Initialized
INFO - 2023-08-21 01:13:11 --> URI Class Initialized
INFO - 2023-08-21 01:13:11 --> Router Class Initialized
INFO - 2023-08-21 01:13:11 --> Output Class Initialized
INFO - 2023-08-21 01:13:11 --> Security Class Initialized
DEBUG - 2023-08-21 01:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 01:13:11 --> Input Class Initialized
INFO - 2023-08-21 01:13:11 --> Language Class Initialized
INFO - 2023-08-21 01:13:11 --> Loader Class Initialized
INFO - 2023-08-21 01:13:11 --> Helper loaded: url_helper
INFO - 2023-08-21 01:13:11 --> Helper loaded: file_helper
INFO - 2023-08-21 01:13:11 --> Helper loaded: html_helper
INFO - 2023-08-21 01:13:11 --> Helper loaded: text_helper
INFO - 2023-08-21 01:13:11 --> Helper loaded: form_helper
INFO - 2023-08-21 01:13:11 --> Helper loaded: lang_helper
INFO - 2023-08-21 01:13:11 --> Helper loaded: security_helper
INFO - 2023-08-21 01:13:11 --> Helper loaded: cookie_helper
INFO - 2023-08-21 01:13:11 --> Database Driver Class Initialized
INFO - 2023-08-21 01:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 01:13:11 --> Parser Class Initialized
INFO - 2023-08-21 01:13:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 01:13:11 --> Pagination Class Initialized
INFO - 2023-08-21 01:13:11 --> Form Validation Class Initialized
INFO - 2023-08-21 01:13:11 --> Controller Class Initialized
INFO - 2023-08-21 01:13:11 --> Model Class Initialized
DEBUG - 2023-08-21 01:13:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 01:13:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-21 01:13:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 01:13:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 01:13:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 01:13:11 --> Model Class Initialized
INFO - 2023-08-21 01:13:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 01:13:11 --> Final output sent to browser
DEBUG - 2023-08-21 01:13:11 --> Total execution time: 0.0337
ERROR - 2023-08-21 07:01:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:01:34 --> Config Class Initialized
INFO - 2023-08-21 07:01:34 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:01:34 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:01:34 --> Utf8 Class Initialized
INFO - 2023-08-21 07:01:34 --> URI Class Initialized
DEBUG - 2023-08-21 07:01:34 --> No URI present. Default controller set.
INFO - 2023-08-21 07:01:34 --> Router Class Initialized
INFO - 2023-08-21 07:01:34 --> Output Class Initialized
INFO - 2023-08-21 07:01:34 --> Security Class Initialized
DEBUG - 2023-08-21 07:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:01:34 --> Input Class Initialized
INFO - 2023-08-21 07:01:34 --> Language Class Initialized
INFO - 2023-08-21 07:01:34 --> Loader Class Initialized
INFO - 2023-08-21 07:01:34 --> Helper loaded: url_helper
INFO - 2023-08-21 07:01:34 --> Helper loaded: file_helper
INFO - 2023-08-21 07:01:34 --> Helper loaded: html_helper
INFO - 2023-08-21 07:01:34 --> Helper loaded: text_helper
INFO - 2023-08-21 07:01:34 --> Helper loaded: form_helper
INFO - 2023-08-21 07:01:34 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:01:34 --> Helper loaded: security_helper
INFO - 2023-08-21 07:01:34 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:01:34 --> Database Driver Class Initialized
INFO - 2023-08-21 07:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:01:34 --> Parser Class Initialized
INFO - 2023-08-21 07:01:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:01:34 --> Pagination Class Initialized
INFO - 2023-08-21 07:01:34 --> Form Validation Class Initialized
INFO - 2023-08-21 07:01:34 --> Controller Class Initialized
INFO - 2023-08-21 07:01:34 --> Model Class Initialized
DEBUG - 2023-08-21 07:01:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-21 07:01:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:01:35 --> Config Class Initialized
INFO - 2023-08-21 07:01:35 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:01:35 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:01:35 --> Utf8 Class Initialized
INFO - 2023-08-21 07:01:35 --> URI Class Initialized
INFO - 2023-08-21 07:01:35 --> Router Class Initialized
INFO - 2023-08-21 07:01:35 --> Output Class Initialized
INFO - 2023-08-21 07:01:35 --> Security Class Initialized
DEBUG - 2023-08-21 07:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:01:35 --> Input Class Initialized
INFO - 2023-08-21 07:01:35 --> Language Class Initialized
INFO - 2023-08-21 07:01:35 --> Loader Class Initialized
INFO - 2023-08-21 07:01:35 --> Helper loaded: url_helper
INFO - 2023-08-21 07:01:35 --> Helper loaded: file_helper
INFO - 2023-08-21 07:01:35 --> Helper loaded: html_helper
INFO - 2023-08-21 07:01:35 --> Helper loaded: text_helper
INFO - 2023-08-21 07:01:35 --> Helper loaded: form_helper
INFO - 2023-08-21 07:01:35 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:01:35 --> Helper loaded: security_helper
INFO - 2023-08-21 07:01:35 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:01:35 --> Database Driver Class Initialized
INFO - 2023-08-21 07:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:01:35 --> Parser Class Initialized
INFO - 2023-08-21 07:01:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:01:35 --> Pagination Class Initialized
INFO - 2023-08-21 07:01:35 --> Form Validation Class Initialized
INFO - 2023-08-21 07:01:35 --> Controller Class Initialized
INFO - 2023-08-21 07:01:35 --> Model Class Initialized
DEBUG - 2023-08-21 07:01:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:01:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-21 07:01:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:01:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 07:01:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 07:01:35 --> Model Class Initialized
INFO - 2023-08-21 07:01:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 07:01:35 --> Final output sent to browser
DEBUG - 2023-08-21 07:01:35 --> Total execution time: 0.3417
ERROR - 2023-08-21 07:01:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:01:40 --> Config Class Initialized
INFO - 2023-08-21 07:01:40 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:01:41 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:01:41 --> Utf8 Class Initialized
INFO - 2023-08-21 07:01:41 --> URI Class Initialized
INFO - 2023-08-21 07:01:41 --> Router Class Initialized
INFO - 2023-08-21 07:01:41 --> Output Class Initialized
INFO - 2023-08-21 07:01:41 --> Security Class Initialized
DEBUG - 2023-08-21 07:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:01:41 --> Input Class Initialized
INFO - 2023-08-21 07:01:41 --> Language Class Initialized
INFO - 2023-08-21 07:01:41 --> Loader Class Initialized
INFO - 2023-08-21 07:01:41 --> Helper loaded: url_helper
INFO - 2023-08-21 07:01:41 --> Helper loaded: file_helper
INFO - 2023-08-21 07:01:41 --> Helper loaded: html_helper
INFO - 2023-08-21 07:01:41 --> Helper loaded: text_helper
INFO - 2023-08-21 07:01:41 --> Helper loaded: form_helper
INFO - 2023-08-21 07:01:41 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:01:41 --> Helper loaded: security_helper
INFO - 2023-08-21 07:01:41 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:01:41 --> Database Driver Class Initialized
INFO - 2023-08-21 07:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:01:41 --> Parser Class Initialized
INFO - 2023-08-21 07:01:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:01:41 --> Pagination Class Initialized
INFO - 2023-08-21 07:01:41 --> Form Validation Class Initialized
INFO - 2023-08-21 07:01:41 --> Controller Class Initialized
INFO - 2023-08-21 07:01:41 --> Model Class Initialized
DEBUG - 2023-08-21 07:01:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:01:41 --> Model Class Initialized
INFO - 2023-08-21 07:01:41 --> Final output sent to browser
DEBUG - 2023-08-21 07:01:41 --> Total execution time: 0.0199
ERROR - 2023-08-21 07:01:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:01:41 --> Config Class Initialized
INFO - 2023-08-21 07:01:41 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:01:41 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:01:41 --> Utf8 Class Initialized
INFO - 2023-08-21 07:01:41 --> URI Class Initialized
DEBUG - 2023-08-21 07:01:41 --> No URI present. Default controller set.
INFO - 2023-08-21 07:01:41 --> Router Class Initialized
INFO - 2023-08-21 07:01:41 --> Output Class Initialized
INFO - 2023-08-21 07:01:41 --> Security Class Initialized
DEBUG - 2023-08-21 07:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:01:41 --> Input Class Initialized
INFO - 2023-08-21 07:01:41 --> Language Class Initialized
INFO - 2023-08-21 07:01:41 --> Loader Class Initialized
INFO - 2023-08-21 07:01:41 --> Helper loaded: url_helper
INFO - 2023-08-21 07:01:41 --> Helper loaded: file_helper
INFO - 2023-08-21 07:01:41 --> Helper loaded: html_helper
INFO - 2023-08-21 07:01:41 --> Helper loaded: text_helper
INFO - 2023-08-21 07:01:41 --> Helper loaded: form_helper
INFO - 2023-08-21 07:01:41 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:01:41 --> Helper loaded: security_helper
INFO - 2023-08-21 07:01:41 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:01:41 --> Database Driver Class Initialized
INFO - 2023-08-21 07:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:01:41 --> Parser Class Initialized
INFO - 2023-08-21 07:01:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:01:41 --> Pagination Class Initialized
INFO - 2023-08-21 07:01:41 --> Form Validation Class Initialized
INFO - 2023-08-21 07:01:41 --> Controller Class Initialized
INFO - 2023-08-21 07:01:41 --> Model Class Initialized
DEBUG - 2023-08-21 07:01:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:01:41 --> Model Class Initialized
DEBUG - 2023-08-21 07:01:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:01:41 --> Model Class Initialized
INFO - 2023-08-21 07:01:41 --> Model Class Initialized
INFO - 2023-08-21 07:01:41 --> Model Class Initialized
INFO - 2023-08-21 07:01:41 --> Model Class Initialized
DEBUG - 2023-08-21 07:01:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:01:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:01:41 --> Model Class Initialized
INFO - 2023-08-21 07:01:41 --> Model Class Initialized
INFO - 2023-08-21 07:01:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-21 07:01:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:01:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 07:01:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 07:01:41 --> Model Class Initialized
INFO - 2023-08-21 07:01:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 07:01:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 07:01:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 07:01:41 --> Final output sent to browser
DEBUG - 2023-08-21 07:01:41 --> Total execution time: 0.0947
ERROR - 2023-08-21 07:01:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:01:45 --> Config Class Initialized
INFO - 2023-08-21 07:01:45 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:01:45 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:01:45 --> Utf8 Class Initialized
INFO - 2023-08-21 07:01:45 --> URI Class Initialized
DEBUG - 2023-08-21 07:01:45 --> No URI present. Default controller set.
INFO - 2023-08-21 07:01:45 --> Router Class Initialized
INFO - 2023-08-21 07:01:45 --> Output Class Initialized
INFO - 2023-08-21 07:01:45 --> Security Class Initialized
DEBUG - 2023-08-21 07:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:01:45 --> Input Class Initialized
INFO - 2023-08-21 07:01:45 --> Language Class Initialized
INFO - 2023-08-21 07:01:45 --> Loader Class Initialized
INFO - 2023-08-21 07:01:45 --> Helper loaded: url_helper
INFO - 2023-08-21 07:01:45 --> Helper loaded: file_helper
INFO - 2023-08-21 07:01:45 --> Helper loaded: html_helper
INFO - 2023-08-21 07:01:45 --> Helper loaded: text_helper
INFO - 2023-08-21 07:01:45 --> Helper loaded: form_helper
INFO - 2023-08-21 07:01:45 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:01:45 --> Helper loaded: security_helper
INFO - 2023-08-21 07:01:45 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:01:45 --> Database Driver Class Initialized
INFO - 2023-08-21 07:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:01:45 --> Parser Class Initialized
INFO - 2023-08-21 07:01:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:01:45 --> Pagination Class Initialized
INFO - 2023-08-21 07:01:45 --> Form Validation Class Initialized
INFO - 2023-08-21 07:01:45 --> Controller Class Initialized
INFO - 2023-08-21 07:01:45 --> Model Class Initialized
DEBUG - 2023-08-21 07:01:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:01:45 --> Model Class Initialized
DEBUG - 2023-08-21 07:01:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:01:45 --> Model Class Initialized
INFO - 2023-08-21 07:01:45 --> Model Class Initialized
INFO - 2023-08-21 07:01:45 --> Model Class Initialized
INFO - 2023-08-21 07:01:45 --> Model Class Initialized
DEBUG - 2023-08-21 07:01:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:01:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:01:45 --> Model Class Initialized
INFO - 2023-08-21 07:01:45 --> Model Class Initialized
INFO - 2023-08-21 07:01:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-21 07:01:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:01:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 07:01:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 07:01:45 --> Model Class Initialized
INFO - 2023-08-21 07:01:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 07:01:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 07:01:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 07:01:45 --> Final output sent to browser
DEBUG - 2023-08-21 07:01:45 --> Total execution time: 0.0880
ERROR - 2023-08-21 07:01:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:01:56 --> Config Class Initialized
INFO - 2023-08-21 07:01:56 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:01:56 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:01:56 --> Utf8 Class Initialized
INFO - 2023-08-21 07:01:56 --> URI Class Initialized
INFO - 2023-08-21 07:01:56 --> Router Class Initialized
INFO - 2023-08-21 07:01:56 --> Output Class Initialized
INFO - 2023-08-21 07:01:56 --> Security Class Initialized
DEBUG - 2023-08-21 07:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:01:56 --> Input Class Initialized
INFO - 2023-08-21 07:01:56 --> Language Class Initialized
INFO - 2023-08-21 07:01:56 --> Loader Class Initialized
INFO - 2023-08-21 07:01:56 --> Helper loaded: url_helper
INFO - 2023-08-21 07:01:56 --> Helper loaded: file_helper
INFO - 2023-08-21 07:01:56 --> Helper loaded: html_helper
INFO - 2023-08-21 07:01:56 --> Helper loaded: text_helper
INFO - 2023-08-21 07:01:56 --> Helper loaded: form_helper
INFO - 2023-08-21 07:01:56 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:01:56 --> Helper loaded: security_helper
INFO - 2023-08-21 07:01:56 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:01:56 --> Database Driver Class Initialized
INFO - 2023-08-21 07:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:01:56 --> Parser Class Initialized
INFO - 2023-08-21 07:01:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:01:56 --> Pagination Class Initialized
INFO - 2023-08-21 07:01:56 --> Form Validation Class Initialized
INFO - 2023-08-21 07:01:56 --> Controller Class Initialized
INFO - 2023-08-21 07:01:56 --> Model Class Initialized
DEBUG - 2023-08-21 07:01:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:01:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:01:56 --> Model Class Initialized
DEBUG - 2023-08-21 07:01:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:01:56 --> Model Class Initialized
INFO - 2023-08-21 07:01:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-21 07:01:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:01:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 07:01:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 07:01:56 --> Model Class Initialized
INFO - 2023-08-21 07:01:56 --> Model Class Initialized
INFO - 2023-08-21 07:01:56 --> Model Class Initialized
INFO - 2023-08-21 07:01:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 07:01:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 07:01:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 07:01:56 --> Final output sent to browser
DEBUG - 2023-08-21 07:01:56 --> Total execution time: 0.0780
ERROR - 2023-08-21 07:01:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:01:57 --> Config Class Initialized
INFO - 2023-08-21 07:01:57 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:01:57 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:01:57 --> Utf8 Class Initialized
INFO - 2023-08-21 07:01:57 --> URI Class Initialized
INFO - 2023-08-21 07:01:57 --> Router Class Initialized
INFO - 2023-08-21 07:01:57 --> Output Class Initialized
INFO - 2023-08-21 07:01:57 --> Security Class Initialized
DEBUG - 2023-08-21 07:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:01:57 --> Input Class Initialized
INFO - 2023-08-21 07:01:57 --> Language Class Initialized
INFO - 2023-08-21 07:01:57 --> Loader Class Initialized
INFO - 2023-08-21 07:01:57 --> Helper loaded: url_helper
INFO - 2023-08-21 07:01:57 --> Helper loaded: file_helper
INFO - 2023-08-21 07:01:57 --> Helper loaded: html_helper
INFO - 2023-08-21 07:01:57 --> Helper loaded: text_helper
INFO - 2023-08-21 07:01:57 --> Helper loaded: form_helper
INFO - 2023-08-21 07:01:57 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:01:57 --> Helper loaded: security_helper
INFO - 2023-08-21 07:01:57 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:01:57 --> Database Driver Class Initialized
INFO - 2023-08-21 07:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:01:57 --> Parser Class Initialized
INFO - 2023-08-21 07:01:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:01:57 --> Pagination Class Initialized
INFO - 2023-08-21 07:01:57 --> Form Validation Class Initialized
INFO - 2023-08-21 07:01:57 --> Controller Class Initialized
INFO - 2023-08-21 07:01:57 --> Model Class Initialized
DEBUG - 2023-08-21 07:01:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:01:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:01:57 --> Model Class Initialized
DEBUG - 2023-08-21 07:01:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:01:57 --> Model Class Initialized
INFO - 2023-08-21 07:01:57 --> Final output sent to browser
DEBUG - 2023-08-21 07:01:57 --> Total execution time: 0.0356
ERROR - 2023-08-21 07:01:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:01:59 --> Config Class Initialized
INFO - 2023-08-21 07:01:59 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:01:59 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:01:59 --> Utf8 Class Initialized
INFO - 2023-08-21 07:01:59 --> URI Class Initialized
DEBUG - 2023-08-21 07:01:59 --> No URI present. Default controller set.
INFO - 2023-08-21 07:01:59 --> Router Class Initialized
INFO - 2023-08-21 07:01:59 --> Output Class Initialized
INFO - 2023-08-21 07:01:59 --> Security Class Initialized
DEBUG - 2023-08-21 07:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:01:59 --> Input Class Initialized
INFO - 2023-08-21 07:01:59 --> Language Class Initialized
INFO - 2023-08-21 07:01:59 --> Loader Class Initialized
INFO - 2023-08-21 07:01:59 --> Helper loaded: url_helper
INFO - 2023-08-21 07:01:59 --> Helper loaded: file_helper
INFO - 2023-08-21 07:01:59 --> Helper loaded: html_helper
INFO - 2023-08-21 07:01:59 --> Helper loaded: text_helper
INFO - 2023-08-21 07:01:59 --> Helper loaded: form_helper
INFO - 2023-08-21 07:01:59 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:01:59 --> Helper loaded: security_helper
INFO - 2023-08-21 07:01:59 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:01:59 --> Database Driver Class Initialized
INFO - 2023-08-21 07:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:01:59 --> Parser Class Initialized
INFO - 2023-08-21 07:01:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:01:59 --> Pagination Class Initialized
INFO - 2023-08-21 07:01:59 --> Form Validation Class Initialized
INFO - 2023-08-21 07:01:59 --> Controller Class Initialized
INFO - 2023-08-21 07:01:59 --> Model Class Initialized
DEBUG - 2023-08-21 07:01:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:01:59 --> Model Class Initialized
DEBUG - 2023-08-21 07:01:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:01:59 --> Model Class Initialized
INFO - 2023-08-21 07:01:59 --> Model Class Initialized
INFO - 2023-08-21 07:01:59 --> Model Class Initialized
INFO - 2023-08-21 07:01:59 --> Model Class Initialized
DEBUG - 2023-08-21 07:01:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:01:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:01:59 --> Model Class Initialized
INFO - 2023-08-21 07:01:59 --> Model Class Initialized
INFO - 2023-08-21 07:01:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-21 07:01:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:01:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 07:01:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 07:01:59 --> Model Class Initialized
INFO - 2023-08-21 07:01:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 07:01:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 07:01:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 07:01:59 --> Final output sent to browser
DEBUG - 2023-08-21 07:01:59 --> Total execution time: 0.0855
ERROR - 2023-08-21 07:02:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:02:12 --> Config Class Initialized
INFO - 2023-08-21 07:02:12 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:02:12 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:02:12 --> Utf8 Class Initialized
INFO - 2023-08-21 07:02:12 --> URI Class Initialized
DEBUG - 2023-08-21 07:02:12 --> No URI present. Default controller set.
INFO - 2023-08-21 07:02:12 --> Router Class Initialized
INFO - 2023-08-21 07:02:12 --> Output Class Initialized
INFO - 2023-08-21 07:02:12 --> Security Class Initialized
DEBUG - 2023-08-21 07:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:02:12 --> Input Class Initialized
INFO - 2023-08-21 07:02:12 --> Language Class Initialized
INFO - 2023-08-21 07:02:12 --> Loader Class Initialized
INFO - 2023-08-21 07:02:12 --> Helper loaded: url_helper
INFO - 2023-08-21 07:02:12 --> Helper loaded: file_helper
INFO - 2023-08-21 07:02:12 --> Helper loaded: html_helper
INFO - 2023-08-21 07:02:12 --> Helper loaded: text_helper
INFO - 2023-08-21 07:02:12 --> Helper loaded: form_helper
INFO - 2023-08-21 07:02:12 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:02:12 --> Helper loaded: security_helper
INFO - 2023-08-21 07:02:12 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:02:12 --> Database Driver Class Initialized
INFO - 2023-08-21 07:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:02:12 --> Parser Class Initialized
INFO - 2023-08-21 07:02:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:02:12 --> Pagination Class Initialized
INFO - 2023-08-21 07:02:12 --> Form Validation Class Initialized
INFO - 2023-08-21 07:02:12 --> Controller Class Initialized
INFO - 2023-08-21 07:02:12 --> Model Class Initialized
DEBUG - 2023-08-21 07:02:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-21 07:02:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:02:12 --> Config Class Initialized
INFO - 2023-08-21 07:02:12 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:02:12 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:02:12 --> Utf8 Class Initialized
INFO - 2023-08-21 07:02:12 --> URI Class Initialized
INFO - 2023-08-21 07:02:12 --> Router Class Initialized
INFO - 2023-08-21 07:02:12 --> Output Class Initialized
INFO - 2023-08-21 07:02:12 --> Security Class Initialized
DEBUG - 2023-08-21 07:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:02:12 --> Input Class Initialized
INFO - 2023-08-21 07:02:12 --> Language Class Initialized
INFO - 2023-08-21 07:02:12 --> Loader Class Initialized
INFO - 2023-08-21 07:02:12 --> Helper loaded: url_helper
INFO - 2023-08-21 07:02:12 --> Helper loaded: file_helper
INFO - 2023-08-21 07:02:12 --> Helper loaded: html_helper
INFO - 2023-08-21 07:02:12 --> Helper loaded: text_helper
INFO - 2023-08-21 07:02:12 --> Helper loaded: form_helper
INFO - 2023-08-21 07:02:12 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:02:12 --> Helper loaded: security_helper
INFO - 2023-08-21 07:02:12 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:02:12 --> Database Driver Class Initialized
INFO - 2023-08-21 07:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:02:12 --> Parser Class Initialized
INFO - 2023-08-21 07:02:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:02:12 --> Pagination Class Initialized
INFO - 2023-08-21 07:02:12 --> Form Validation Class Initialized
INFO - 2023-08-21 07:02:12 --> Controller Class Initialized
INFO - 2023-08-21 07:02:12 --> Model Class Initialized
DEBUG - 2023-08-21 07:02:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:02:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-21 07:02:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:02:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 07:02:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 07:02:12 --> Model Class Initialized
INFO - 2023-08-21 07:02:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 07:02:12 --> Final output sent to browser
DEBUG - 2023-08-21 07:02:12 --> Total execution time: 0.0324
ERROR - 2023-08-21 07:02:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:02:15 --> Config Class Initialized
INFO - 2023-08-21 07:02:15 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:02:15 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:02:15 --> Utf8 Class Initialized
INFO - 2023-08-21 07:02:15 --> URI Class Initialized
INFO - 2023-08-21 07:02:15 --> Router Class Initialized
INFO - 2023-08-21 07:02:15 --> Output Class Initialized
INFO - 2023-08-21 07:02:15 --> Security Class Initialized
DEBUG - 2023-08-21 07:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:02:15 --> Input Class Initialized
INFO - 2023-08-21 07:02:15 --> Language Class Initialized
INFO - 2023-08-21 07:02:15 --> Loader Class Initialized
INFO - 2023-08-21 07:02:15 --> Helper loaded: url_helper
INFO - 2023-08-21 07:02:15 --> Helper loaded: file_helper
INFO - 2023-08-21 07:02:15 --> Helper loaded: html_helper
INFO - 2023-08-21 07:02:15 --> Helper loaded: text_helper
INFO - 2023-08-21 07:02:15 --> Helper loaded: form_helper
INFO - 2023-08-21 07:02:15 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:02:15 --> Helper loaded: security_helper
INFO - 2023-08-21 07:02:15 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:02:15 --> Database Driver Class Initialized
INFO - 2023-08-21 07:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:02:15 --> Parser Class Initialized
INFO - 2023-08-21 07:02:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:02:15 --> Pagination Class Initialized
INFO - 2023-08-21 07:02:15 --> Form Validation Class Initialized
INFO - 2023-08-21 07:02:15 --> Controller Class Initialized
INFO - 2023-08-21 07:02:15 --> Model Class Initialized
DEBUG - 2023-08-21 07:02:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:02:15 --> Model Class Initialized
INFO - 2023-08-21 07:02:15 --> Final output sent to browser
DEBUG - 2023-08-21 07:02:15 --> Total execution time: 0.0187
ERROR - 2023-08-21 07:02:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:02:15 --> Config Class Initialized
INFO - 2023-08-21 07:02:15 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:02:15 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:02:15 --> Utf8 Class Initialized
INFO - 2023-08-21 07:02:15 --> URI Class Initialized
DEBUG - 2023-08-21 07:02:15 --> No URI present. Default controller set.
INFO - 2023-08-21 07:02:15 --> Router Class Initialized
INFO - 2023-08-21 07:02:15 --> Output Class Initialized
INFO - 2023-08-21 07:02:15 --> Security Class Initialized
DEBUG - 2023-08-21 07:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:02:15 --> Input Class Initialized
INFO - 2023-08-21 07:02:15 --> Language Class Initialized
INFO - 2023-08-21 07:02:15 --> Loader Class Initialized
INFO - 2023-08-21 07:02:15 --> Helper loaded: url_helper
INFO - 2023-08-21 07:02:15 --> Helper loaded: file_helper
INFO - 2023-08-21 07:02:15 --> Helper loaded: html_helper
INFO - 2023-08-21 07:02:15 --> Helper loaded: text_helper
INFO - 2023-08-21 07:02:15 --> Helper loaded: form_helper
INFO - 2023-08-21 07:02:15 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:02:15 --> Helper loaded: security_helper
INFO - 2023-08-21 07:02:15 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:02:15 --> Database Driver Class Initialized
INFO - 2023-08-21 07:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:02:15 --> Parser Class Initialized
INFO - 2023-08-21 07:02:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:02:15 --> Pagination Class Initialized
INFO - 2023-08-21 07:02:15 --> Form Validation Class Initialized
INFO - 2023-08-21 07:02:15 --> Controller Class Initialized
INFO - 2023-08-21 07:02:15 --> Model Class Initialized
DEBUG - 2023-08-21 07:02:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:02:15 --> Model Class Initialized
DEBUG - 2023-08-21 07:02:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:02:15 --> Model Class Initialized
INFO - 2023-08-21 07:02:15 --> Model Class Initialized
INFO - 2023-08-21 07:02:15 --> Model Class Initialized
INFO - 2023-08-21 07:02:15 --> Model Class Initialized
DEBUG - 2023-08-21 07:02:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:02:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:02:15 --> Model Class Initialized
INFO - 2023-08-21 07:02:15 --> Model Class Initialized
INFO - 2023-08-21 07:02:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-21 07:02:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:02:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 07:02:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 07:02:15 --> Model Class Initialized
INFO - 2023-08-21 07:02:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 07:02:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 07:02:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 07:02:15 --> Final output sent to browser
DEBUG - 2023-08-21 07:02:15 --> Total execution time: 0.1808
ERROR - 2023-08-21 07:02:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:02:16 --> Config Class Initialized
INFO - 2023-08-21 07:02:16 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:02:16 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:02:16 --> Utf8 Class Initialized
INFO - 2023-08-21 07:02:16 --> URI Class Initialized
INFO - 2023-08-21 07:02:16 --> Router Class Initialized
INFO - 2023-08-21 07:02:16 --> Output Class Initialized
INFO - 2023-08-21 07:02:16 --> Security Class Initialized
DEBUG - 2023-08-21 07:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:02:16 --> Input Class Initialized
INFO - 2023-08-21 07:02:16 --> Language Class Initialized
INFO - 2023-08-21 07:02:16 --> Loader Class Initialized
INFO - 2023-08-21 07:02:16 --> Helper loaded: url_helper
INFO - 2023-08-21 07:02:16 --> Helper loaded: file_helper
INFO - 2023-08-21 07:02:16 --> Helper loaded: html_helper
INFO - 2023-08-21 07:02:16 --> Helper loaded: text_helper
INFO - 2023-08-21 07:02:16 --> Helper loaded: form_helper
INFO - 2023-08-21 07:02:16 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:02:16 --> Helper loaded: security_helper
INFO - 2023-08-21 07:02:16 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:02:16 --> Database Driver Class Initialized
INFO - 2023-08-21 07:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:02:16 --> Parser Class Initialized
INFO - 2023-08-21 07:02:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:02:16 --> Pagination Class Initialized
INFO - 2023-08-21 07:02:16 --> Form Validation Class Initialized
INFO - 2023-08-21 07:02:16 --> Controller Class Initialized
DEBUG - 2023-08-21 07:02:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:02:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:02:16 --> Model Class Initialized
INFO - 2023-08-21 07:02:16 --> Final output sent to browser
DEBUG - 2023-08-21 07:02:16 --> Total execution time: 0.0180
ERROR - 2023-08-21 07:04:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:04:02 --> Config Class Initialized
INFO - 2023-08-21 07:04:02 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:04:02 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:04:02 --> Utf8 Class Initialized
INFO - 2023-08-21 07:04:02 --> URI Class Initialized
INFO - 2023-08-21 07:04:02 --> Router Class Initialized
INFO - 2023-08-21 07:04:02 --> Output Class Initialized
INFO - 2023-08-21 07:04:02 --> Security Class Initialized
DEBUG - 2023-08-21 07:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:04:02 --> Input Class Initialized
INFO - 2023-08-21 07:04:02 --> Language Class Initialized
INFO - 2023-08-21 07:04:02 --> Loader Class Initialized
INFO - 2023-08-21 07:04:02 --> Helper loaded: url_helper
INFO - 2023-08-21 07:04:02 --> Helper loaded: file_helper
INFO - 2023-08-21 07:04:02 --> Helper loaded: html_helper
INFO - 2023-08-21 07:04:02 --> Helper loaded: text_helper
INFO - 2023-08-21 07:04:02 --> Helper loaded: form_helper
INFO - 2023-08-21 07:04:02 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:04:02 --> Helper loaded: security_helper
INFO - 2023-08-21 07:04:02 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:04:02 --> Database Driver Class Initialized
INFO - 2023-08-21 07:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:04:02 --> Parser Class Initialized
INFO - 2023-08-21 07:04:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:04:02 --> Pagination Class Initialized
INFO - 2023-08-21 07:04:02 --> Form Validation Class Initialized
INFO - 2023-08-21 07:04:02 --> Controller Class Initialized
INFO - 2023-08-21 07:04:02 --> Model Class Initialized
DEBUG - 2023-08-21 07:04:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:04:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:04:02 --> Model Class Initialized
DEBUG - 2023-08-21 07:04:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:04:02 --> Model Class Initialized
INFO - 2023-08-21 07:04:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-21 07:04:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:04:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 07:04:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 07:04:02 --> Model Class Initialized
INFO - 2023-08-21 07:04:02 --> Model Class Initialized
INFO - 2023-08-21 07:04:02 --> Model Class Initialized
INFO - 2023-08-21 07:04:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 07:04:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 07:04:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 07:04:02 --> Final output sent to browser
DEBUG - 2023-08-21 07:04:02 --> Total execution time: 0.0820
ERROR - 2023-08-21 07:04:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:04:03 --> Config Class Initialized
INFO - 2023-08-21 07:04:03 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:04:03 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:04:03 --> Utf8 Class Initialized
INFO - 2023-08-21 07:04:03 --> URI Class Initialized
INFO - 2023-08-21 07:04:03 --> Router Class Initialized
INFO - 2023-08-21 07:04:03 --> Output Class Initialized
INFO - 2023-08-21 07:04:03 --> Security Class Initialized
DEBUG - 2023-08-21 07:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:04:03 --> Input Class Initialized
INFO - 2023-08-21 07:04:03 --> Language Class Initialized
INFO - 2023-08-21 07:04:03 --> Loader Class Initialized
INFO - 2023-08-21 07:04:03 --> Helper loaded: url_helper
INFO - 2023-08-21 07:04:03 --> Helper loaded: file_helper
INFO - 2023-08-21 07:04:03 --> Helper loaded: html_helper
INFO - 2023-08-21 07:04:03 --> Helper loaded: text_helper
INFO - 2023-08-21 07:04:03 --> Helper loaded: form_helper
INFO - 2023-08-21 07:04:03 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:04:03 --> Helper loaded: security_helper
INFO - 2023-08-21 07:04:03 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:04:03 --> Database Driver Class Initialized
INFO - 2023-08-21 07:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:04:03 --> Parser Class Initialized
INFO - 2023-08-21 07:04:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:04:03 --> Pagination Class Initialized
INFO - 2023-08-21 07:04:03 --> Form Validation Class Initialized
INFO - 2023-08-21 07:04:03 --> Controller Class Initialized
INFO - 2023-08-21 07:04:03 --> Model Class Initialized
DEBUG - 2023-08-21 07:04:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:04:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:04:03 --> Model Class Initialized
DEBUG - 2023-08-21 07:04:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:04:03 --> Model Class Initialized
INFO - 2023-08-21 07:04:03 --> Final output sent to browser
DEBUG - 2023-08-21 07:04:03 --> Total execution time: 0.0397
ERROR - 2023-08-21 07:11:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:11:50 --> Config Class Initialized
INFO - 2023-08-21 07:11:50 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:11:50 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:11:50 --> Utf8 Class Initialized
INFO - 2023-08-21 07:11:50 --> URI Class Initialized
INFO - 2023-08-21 07:11:50 --> Router Class Initialized
INFO - 2023-08-21 07:11:50 --> Output Class Initialized
INFO - 2023-08-21 07:11:50 --> Security Class Initialized
DEBUG - 2023-08-21 07:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:11:50 --> Input Class Initialized
INFO - 2023-08-21 07:11:50 --> Language Class Initialized
INFO - 2023-08-21 07:11:50 --> Loader Class Initialized
INFO - 2023-08-21 07:11:50 --> Helper loaded: url_helper
INFO - 2023-08-21 07:11:50 --> Helper loaded: file_helper
INFO - 2023-08-21 07:11:50 --> Helper loaded: html_helper
INFO - 2023-08-21 07:11:50 --> Helper loaded: text_helper
INFO - 2023-08-21 07:11:50 --> Helper loaded: form_helper
INFO - 2023-08-21 07:11:50 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:11:50 --> Helper loaded: security_helper
INFO - 2023-08-21 07:11:50 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:11:50 --> Database Driver Class Initialized
INFO - 2023-08-21 07:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:11:50 --> Parser Class Initialized
INFO - 2023-08-21 07:11:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:11:50 --> Pagination Class Initialized
INFO - 2023-08-21 07:11:50 --> Form Validation Class Initialized
INFO - 2023-08-21 07:11:50 --> Controller Class Initialized
INFO - 2023-08-21 07:11:50 --> Model Class Initialized
DEBUG - 2023-08-21 07:11:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:11:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:11:50 --> Model Class Initialized
DEBUG - 2023-08-21 07:11:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:11:50 --> Model Class Initialized
INFO - 2023-08-21 07:11:51 --> Final output sent to browser
DEBUG - 2023-08-21 07:11:51 --> Total execution time: 0.1069
ERROR - 2023-08-21 07:12:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:12:02 --> Config Class Initialized
INFO - 2023-08-21 07:12:02 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:12:02 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:12:02 --> Utf8 Class Initialized
INFO - 2023-08-21 07:12:02 --> URI Class Initialized
DEBUG - 2023-08-21 07:12:02 --> No URI present. Default controller set.
INFO - 2023-08-21 07:12:02 --> Router Class Initialized
INFO - 2023-08-21 07:12:02 --> Output Class Initialized
INFO - 2023-08-21 07:12:02 --> Security Class Initialized
DEBUG - 2023-08-21 07:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:12:02 --> Input Class Initialized
INFO - 2023-08-21 07:12:02 --> Language Class Initialized
INFO - 2023-08-21 07:12:02 --> Loader Class Initialized
INFO - 2023-08-21 07:12:02 --> Helper loaded: url_helper
INFO - 2023-08-21 07:12:02 --> Helper loaded: file_helper
INFO - 2023-08-21 07:12:02 --> Helper loaded: html_helper
INFO - 2023-08-21 07:12:02 --> Helper loaded: text_helper
INFO - 2023-08-21 07:12:02 --> Helper loaded: form_helper
INFO - 2023-08-21 07:12:02 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:12:02 --> Helper loaded: security_helper
INFO - 2023-08-21 07:12:02 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:12:02 --> Database Driver Class Initialized
INFO - 2023-08-21 07:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:12:02 --> Parser Class Initialized
INFO - 2023-08-21 07:12:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:12:02 --> Pagination Class Initialized
INFO - 2023-08-21 07:12:02 --> Form Validation Class Initialized
INFO - 2023-08-21 07:12:02 --> Controller Class Initialized
INFO - 2023-08-21 07:12:02 --> Model Class Initialized
DEBUG - 2023-08-21 07:12:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:12:02 --> Model Class Initialized
DEBUG - 2023-08-21 07:12:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:12:02 --> Model Class Initialized
INFO - 2023-08-21 07:12:02 --> Model Class Initialized
INFO - 2023-08-21 07:12:02 --> Model Class Initialized
INFO - 2023-08-21 07:12:02 --> Model Class Initialized
DEBUG - 2023-08-21 07:12:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:12:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:12:02 --> Model Class Initialized
INFO - 2023-08-21 07:12:02 --> Model Class Initialized
INFO - 2023-08-21 07:12:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-21 07:12:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:12:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 07:12:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 07:12:02 --> Model Class Initialized
INFO - 2023-08-21 07:12:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 07:12:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 07:12:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 07:12:02 --> Final output sent to browser
DEBUG - 2023-08-21 07:12:02 --> Total execution time: 0.0888
ERROR - 2023-08-21 07:14:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:14:02 --> Config Class Initialized
INFO - 2023-08-21 07:14:02 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:14:02 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:14:02 --> Utf8 Class Initialized
INFO - 2023-08-21 07:14:02 --> URI Class Initialized
DEBUG - 2023-08-21 07:14:02 --> No URI present. Default controller set.
INFO - 2023-08-21 07:14:02 --> Router Class Initialized
INFO - 2023-08-21 07:14:02 --> Output Class Initialized
INFO - 2023-08-21 07:14:02 --> Security Class Initialized
DEBUG - 2023-08-21 07:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:14:02 --> Input Class Initialized
INFO - 2023-08-21 07:14:02 --> Language Class Initialized
INFO - 2023-08-21 07:14:02 --> Loader Class Initialized
INFO - 2023-08-21 07:14:02 --> Helper loaded: url_helper
INFO - 2023-08-21 07:14:02 --> Helper loaded: file_helper
INFO - 2023-08-21 07:14:02 --> Helper loaded: html_helper
INFO - 2023-08-21 07:14:02 --> Helper loaded: text_helper
INFO - 2023-08-21 07:14:02 --> Helper loaded: form_helper
INFO - 2023-08-21 07:14:02 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:14:02 --> Helper loaded: security_helper
INFO - 2023-08-21 07:14:02 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:14:02 --> Database Driver Class Initialized
INFO - 2023-08-21 07:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:14:02 --> Parser Class Initialized
INFO - 2023-08-21 07:14:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:14:02 --> Pagination Class Initialized
INFO - 2023-08-21 07:14:02 --> Form Validation Class Initialized
INFO - 2023-08-21 07:14:02 --> Controller Class Initialized
INFO - 2023-08-21 07:14:02 --> Model Class Initialized
DEBUG - 2023-08-21 07:14:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-21 07:14:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:14:03 --> Config Class Initialized
INFO - 2023-08-21 07:14:03 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:14:03 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:14:03 --> Utf8 Class Initialized
INFO - 2023-08-21 07:14:03 --> URI Class Initialized
INFO - 2023-08-21 07:14:03 --> Router Class Initialized
INFO - 2023-08-21 07:14:03 --> Output Class Initialized
INFO - 2023-08-21 07:14:03 --> Security Class Initialized
DEBUG - 2023-08-21 07:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:14:03 --> Input Class Initialized
INFO - 2023-08-21 07:14:03 --> Language Class Initialized
INFO - 2023-08-21 07:14:03 --> Loader Class Initialized
INFO - 2023-08-21 07:14:03 --> Helper loaded: url_helper
INFO - 2023-08-21 07:14:03 --> Helper loaded: file_helper
INFO - 2023-08-21 07:14:03 --> Helper loaded: html_helper
INFO - 2023-08-21 07:14:03 --> Helper loaded: text_helper
INFO - 2023-08-21 07:14:03 --> Helper loaded: form_helper
INFO - 2023-08-21 07:14:03 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:14:03 --> Helper loaded: security_helper
INFO - 2023-08-21 07:14:03 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:14:03 --> Database Driver Class Initialized
INFO - 2023-08-21 07:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:14:03 --> Parser Class Initialized
INFO - 2023-08-21 07:14:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:14:03 --> Pagination Class Initialized
INFO - 2023-08-21 07:14:03 --> Form Validation Class Initialized
INFO - 2023-08-21 07:14:03 --> Controller Class Initialized
INFO - 2023-08-21 07:14:03 --> Model Class Initialized
DEBUG - 2023-08-21 07:14:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:14:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-21 07:14:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:14:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 07:14:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 07:14:03 --> Model Class Initialized
INFO - 2023-08-21 07:14:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 07:14:03 --> Final output sent to browser
DEBUG - 2023-08-21 07:14:03 --> Total execution time: 0.0297
ERROR - 2023-08-21 07:14:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:14:16 --> Config Class Initialized
INFO - 2023-08-21 07:14:16 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:14:16 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:14:16 --> Utf8 Class Initialized
INFO - 2023-08-21 07:14:16 --> URI Class Initialized
INFO - 2023-08-21 07:14:16 --> Router Class Initialized
INFO - 2023-08-21 07:14:16 --> Output Class Initialized
INFO - 2023-08-21 07:14:16 --> Security Class Initialized
DEBUG - 2023-08-21 07:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:14:16 --> Input Class Initialized
INFO - 2023-08-21 07:14:16 --> Language Class Initialized
INFO - 2023-08-21 07:14:16 --> Loader Class Initialized
INFO - 2023-08-21 07:14:16 --> Helper loaded: url_helper
INFO - 2023-08-21 07:14:16 --> Helper loaded: file_helper
INFO - 2023-08-21 07:14:16 --> Helper loaded: html_helper
INFO - 2023-08-21 07:14:16 --> Helper loaded: text_helper
INFO - 2023-08-21 07:14:16 --> Helper loaded: form_helper
INFO - 2023-08-21 07:14:16 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:14:16 --> Helper loaded: security_helper
INFO - 2023-08-21 07:14:16 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:14:16 --> Database Driver Class Initialized
INFO - 2023-08-21 07:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:14:16 --> Parser Class Initialized
INFO - 2023-08-21 07:14:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:14:16 --> Pagination Class Initialized
INFO - 2023-08-21 07:14:16 --> Form Validation Class Initialized
INFO - 2023-08-21 07:14:16 --> Controller Class Initialized
INFO - 2023-08-21 07:14:16 --> Model Class Initialized
DEBUG - 2023-08-21 07:14:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:14:16 --> Model Class Initialized
INFO - 2023-08-21 07:14:16 --> Final output sent to browser
DEBUG - 2023-08-21 07:14:16 --> Total execution time: 0.0218
ERROR - 2023-08-21 07:14:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:14:17 --> Config Class Initialized
INFO - 2023-08-21 07:14:17 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:14:17 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:14:17 --> Utf8 Class Initialized
INFO - 2023-08-21 07:14:17 --> URI Class Initialized
DEBUG - 2023-08-21 07:14:17 --> No URI present. Default controller set.
INFO - 2023-08-21 07:14:17 --> Router Class Initialized
INFO - 2023-08-21 07:14:17 --> Output Class Initialized
INFO - 2023-08-21 07:14:17 --> Security Class Initialized
DEBUG - 2023-08-21 07:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:14:17 --> Input Class Initialized
INFO - 2023-08-21 07:14:17 --> Language Class Initialized
INFO - 2023-08-21 07:14:17 --> Loader Class Initialized
INFO - 2023-08-21 07:14:17 --> Helper loaded: url_helper
INFO - 2023-08-21 07:14:17 --> Helper loaded: file_helper
INFO - 2023-08-21 07:14:17 --> Helper loaded: html_helper
INFO - 2023-08-21 07:14:17 --> Helper loaded: text_helper
INFO - 2023-08-21 07:14:17 --> Helper loaded: form_helper
INFO - 2023-08-21 07:14:17 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:14:17 --> Helper loaded: security_helper
INFO - 2023-08-21 07:14:17 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:14:17 --> Database Driver Class Initialized
INFO - 2023-08-21 07:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:14:17 --> Parser Class Initialized
INFO - 2023-08-21 07:14:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:14:17 --> Pagination Class Initialized
INFO - 2023-08-21 07:14:17 --> Form Validation Class Initialized
INFO - 2023-08-21 07:14:17 --> Controller Class Initialized
INFO - 2023-08-21 07:14:17 --> Model Class Initialized
DEBUG - 2023-08-21 07:14:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:14:17 --> Model Class Initialized
DEBUG - 2023-08-21 07:14:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:14:17 --> Model Class Initialized
INFO - 2023-08-21 07:14:17 --> Model Class Initialized
INFO - 2023-08-21 07:14:17 --> Model Class Initialized
INFO - 2023-08-21 07:14:17 --> Model Class Initialized
DEBUG - 2023-08-21 07:14:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:14:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:14:17 --> Model Class Initialized
INFO - 2023-08-21 07:14:17 --> Model Class Initialized
INFO - 2023-08-21 07:14:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-21 07:14:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:14:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 07:14:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 07:14:17 --> Model Class Initialized
INFO - 2023-08-21 07:14:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 07:14:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 07:14:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 07:14:17 --> Final output sent to browser
DEBUG - 2023-08-21 07:14:17 --> Total execution time: 0.1090
ERROR - 2023-08-21 07:14:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:14:47 --> Config Class Initialized
INFO - 2023-08-21 07:14:47 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:14:47 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:14:47 --> Utf8 Class Initialized
INFO - 2023-08-21 07:14:47 --> URI Class Initialized
INFO - 2023-08-21 07:14:47 --> Router Class Initialized
INFO - 2023-08-21 07:14:47 --> Output Class Initialized
INFO - 2023-08-21 07:14:47 --> Security Class Initialized
DEBUG - 2023-08-21 07:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:14:47 --> Input Class Initialized
INFO - 2023-08-21 07:14:47 --> Language Class Initialized
INFO - 2023-08-21 07:14:47 --> Loader Class Initialized
INFO - 2023-08-21 07:14:47 --> Helper loaded: url_helper
INFO - 2023-08-21 07:14:47 --> Helper loaded: file_helper
INFO - 2023-08-21 07:14:47 --> Helper loaded: html_helper
INFO - 2023-08-21 07:14:47 --> Helper loaded: text_helper
INFO - 2023-08-21 07:14:47 --> Helper loaded: form_helper
INFO - 2023-08-21 07:14:47 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:14:47 --> Helper loaded: security_helper
INFO - 2023-08-21 07:14:47 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:14:47 --> Database Driver Class Initialized
INFO - 2023-08-21 07:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:14:47 --> Parser Class Initialized
INFO - 2023-08-21 07:14:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:14:47 --> Pagination Class Initialized
INFO - 2023-08-21 07:14:47 --> Form Validation Class Initialized
INFO - 2023-08-21 07:14:47 --> Controller Class Initialized
INFO - 2023-08-21 07:14:47 --> Model Class Initialized
DEBUG - 2023-08-21 07:14:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:14:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:14:47 --> Model Class Initialized
DEBUG - 2023-08-21 07:14:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:14:47 --> Model Class Initialized
INFO - 2023-08-21 07:14:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-21 07:14:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:14:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 07:14:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 07:14:47 --> Model Class Initialized
INFO - 2023-08-21 07:14:47 --> Model Class Initialized
INFO - 2023-08-21 07:14:47 --> Model Class Initialized
INFO - 2023-08-21 07:14:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 07:14:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 07:14:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 07:14:47 --> Final output sent to browser
DEBUG - 2023-08-21 07:14:47 --> Total execution time: 0.0845
ERROR - 2023-08-21 07:14:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:14:48 --> Config Class Initialized
INFO - 2023-08-21 07:14:48 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:14:48 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:14:48 --> Utf8 Class Initialized
INFO - 2023-08-21 07:14:48 --> URI Class Initialized
INFO - 2023-08-21 07:14:48 --> Router Class Initialized
INFO - 2023-08-21 07:14:48 --> Output Class Initialized
INFO - 2023-08-21 07:14:48 --> Security Class Initialized
DEBUG - 2023-08-21 07:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:14:48 --> Input Class Initialized
INFO - 2023-08-21 07:14:48 --> Language Class Initialized
INFO - 2023-08-21 07:14:48 --> Loader Class Initialized
INFO - 2023-08-21 07:14:48 --> Helper loaded: url_helper
INFO - 2023-08-21 07:14:48 --> Helper loaded: file_helper
INFO - 2023-08-21 07:14:48 --> Helper loaded: html_helper
INFO - 2023-08-21 07:14:48 --> Helper loaded: text_helper
INFO - 2023-08-21 07:14:48 --> Helper loaded: form_helper
INFO - 2023-08-21 07:14:48 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:14:48 --> Helper loaded: security_helper
INFO - 2023-08-21 07:14:48 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:14:48 --> Database Driver Class Initialized
INFO - 2023-08-21 07:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:14:48 --> Parser Class Initialized
INFO - 2023-08-21 07:14:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:14:48 --> Pagination Class Initialized
INFO - 2023-08-21 07:14:48 --> Form Validation Class Initialized
INFO - 2023-08-21 07:14:48 --> Controller Class Initialized
INFO - 2023-08-21 07:14:48 --> Model Class Initialized
DEBUG - 2023-08-21 07:14:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:14:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:14:48 --> Model Class Initialized
DEBUG - 2023-08-21 07:14:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:14:48 --> Model Class Initialized
INFO - 2023-08-21 07:14:48 --> Final output sent to browser
DEBUG - 2023-08-21 07:14:48 --> Total execution time: 0.0383
ERROR - 2023-08-21 07:19:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:19:06 --> Config Class Initialized
INFO - 2023-08-21 07:19:06 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:19:06 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:19:06 --> Utf8 Class Initialized
INFO - 2023-08-21 07:19:06 --> URI Class Initialized
INFO - 2023-08-21 07:19:06 --> Router Class Initialized
INFO - 2023-08-21 07:19:06 --> Output Class Initialized
INFO - 2023-08-21 07:19:06 --> Security Class Initialized
DEBUG - 2023-08-21 07:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:19:06 --> Input Class Initialized
INFO - 2023-08-21 07:19:06 --> Language Class Initialized
INFO - 2023-08-21 07:19:06 --> Loader Class Initialized
INFO - 2023-08-21 07:19:06 --> Helper loaded: url_helper
INFO - 2023-08-21 07:19:06 --> Helper loaded: file_helper
INFO - 2023-08-21 07:19:06 --> Helper loaded: html_helper
INFO - 2023-08-21 07:19:06 --> Helper loaded: text_helper
INFO - 2023-08-21 07:19:06 --> Helper loaded: form_helper
INFO - 2023-08-21 07:19:06 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:19:06 --> Helper loaded: security_helper
INFO - 2023-08-21 07:19:06 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:19:06 --> Database Driver Class Initialized
INFO - 2023-08-21 07:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:19:06 --> Parser Class Initialized
INFO - 2023-08-21 07:19:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:19:06 --> Pagination Class Initialized
INFO - 2023-08-21 07:19:06 --> Form Validation Class Initialized
INFO - 2023-08-21 07:19:06 --> Controller Class Initialized
INFO - 2023-08-21 07:19:06 --> Model Class Initialized
DEBUG - 2023-08-21 07:19:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:19:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:19:06 --> Model Class Initialized
DEBUG - 2023-08-21 07:19:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:19:06 --> Model Class Initialized
INFO - 2023-08-21 07:19:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-08-21 07:19:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:19:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 07:19:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 07:19:06 --> Model Class Initialized
INFO - 2023-08-21 07:19:06 --> Model Class Initialized
INFO - 2023-08-21 07:19:06 --> Model Class Initialized
INFO - 2023-08-21 07:19:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 07:19:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 07:19:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 07:19:06 --> Final output sent to browser
DEBUG - 2023-08-21 07:19:06 --> Total execution time: 0.0983
ERROR - 2023-08-21 07:19:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:19:07 --> Config Class Initialized
INFO - 2023-08-21 07:19:07 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:19:07 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:19:07 --> Utf8 Class Initialized
INFO - 2023-08-21 07:19:07 --> URI Class Initialized
INFO - 2023-08-21 07:19:07 --> Router Class Initialized
INFO - 2023-08-21 07:19:07 --> Output Class Initialized
INFO - 2023-08-21 07:19:07 --> Security Class Initialized
DEBUG - 2023-08-21 07:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:19:07 --> Input Class Initialized
INFO - 2023-08-21 07:19:07 --> Language Class Initialized
INFO - 2023-08-21 07:19:07 --> Loader Class Initialized
INFO - 2023-08-21 07:19:07 --> Helper loaded: url_helper
INFO - 2023-08-21 07:19:07 --> Helper loaded: file_helper
INFO - 2023-08-21 07:19:07 --> Helper loaded: html_helper
INFO - 2023-08-21 07:19:07 --> Helper loaded: text_helper
INFO - 2023-08-21 07:19:07 --> Helper loaded: form_helper
INFO - 2023-08-21 07:19:07 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:19:07 --> Helper loaded: security_helper
INFO - 2023-08-21 07:19:07 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:19:07 --> Database Driver Class Initialized
INFO - 2023-08-21 07:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:19:07 --> Parser Class Initialized
INFO - 2023-08-21 07:19:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:19:08 --> Pagination Class Initialized
INFO - 2023-08-21 07:19:08 --> Form Validation Class Initialized
INFO - 2023-08-21 07:19:08 --> Controller Class Initialized
INFO - 2023-08-21 07:19:08 --> Model Class Initialized
DEBUG - 2023-08-21 07:19:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:19:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:19:08 --> Model Class Initialized
DEBUG - 2023-08-21 07:19:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:19:08 --> Model Class Initialized
INFO - 2023-08-21 07:19:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-08-21 07:19:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:19:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 07:19:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 07:19:08 --> Model Class Initialized
INFO - 2023-08-21 07:19:08 --> Model Class Initialized
INFO - 2023-08-21 07:19:08 --> Model Class Initialized
INFO - 2023-08-21 07:19:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 07:19:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 07:19:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 07:19:08 --> Final output sent to browser
DEBUG - 2023-08-21 07:19:08 --> Total execution time: 0.0904
ERROR - 2023-08-21 07:23:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:23:17 --> Config Class Initialized
INFO - 2023-08-21 07:23:17 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:23:17 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:23:17 --> Utf8 Class Initialized
INFO - 2023-08-21 07:23:17 --> URI Class Initialized
INFO - 2023-08-21 07:23:17 --> Router Class Initialized
INFO - 2023-08-21 07:23:17 --> Output Class Initialized
INFO - 2023-08-21 07:23:17 --> Security Class Initialized
DEBUG - 2023-08-21 07:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:23:17 --> Input Class Initialized
INFO - 2023-08-21 07:23:17 --> Language Class Initialized
INFO - 2023-08-21 07:23:17 --> Loader Class Initialized
INFO - 2023-08-21 07:23:17 --> Helper loaded: url_helper
INFO - 2023-08-21 07:23:17 --> Helper loaded: file_helper
INFO - 2023-08-21 07:23:17 --> Helper loaded: html_helper
INFO - 2023-08-21 07:23:17 --> Helper loaded: text_helper
INFO - 2023-08-21 07:23:17 --> Helper loaded: form_helper
INFO - 2023-08-21 07:23:17 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:23:17 --> Helper loaded: security_helper
INFO - 2023-08-21 07:23:17 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:23:17 --> Database Driver Class Initialized
INFO - 2023-08-21 07:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:23:17 --> Parser Class Initialized
INFO - 2023-08-21 07:23:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:23:17 --> Pagination Class Initialized
INFO - 2023-08-21 07:23:17 --> Form Validation Class Initialized
INFO - 2023-08-21 07:23:17 --> Controller Class Initialized
INFO - 2023-08-21 07:23:17 --> Model Class Initialized
DEBUG - 2023-08-21 07:23:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:23:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:23:17 --> Model Class Initialized
DEBUG - 2023-08-21 07:23:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:23:17 --> Model Class Initialized
INFO - 2023-08-21 07:23:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-08-21 07:23:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:23:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 07:23:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 07:23:17 --> Model Class Initialized
INFO - 2023-08-21 07:23:17 --> Model Class Initialized
INFO - 2023-08-21 07:23:17 --> Model Class Initialized
INFO - 2023-08-21 07:23:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 07:23:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 07:23:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 07:23:17 --> Final output sent to browser
DEBUG - 2023-08-21 07:23:17 --> Total execution time: 0.0974
ERROR - 2023-08-21 07:23:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:23:22 --> Config Class Initialized
INFO - 2023-08-21 07:23:22 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:23:22 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:23:22 --> Utf8 Class Initialized
INFO - 2023-08-21 07:23:22 --> URI Class Initialized
INFO - 2023-08-21 07:23:22 --> Router Class Initialized
INFO - 2023-08-21 07:23:22 --> Output Class Initialized
INFO - 2023-08-21 07:23:22 --> Security Class Initialized
DEBUG - 2023-08-21 07:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:23:22 --> Input Class Initialized
INFO - 2023-08-21 07:23:22 --> Language Class Initialized
INFO - 2023-08-21 07:23:22 --> Loader Class Initialized
INFO - 2023-08-21 07:23:22 --> Helper loaded: url_helper
INFO - 2023-08-21 07:23:22 --> Helper loaded: file_helper
INFO - 2023-08-21 07:23:22 --> Helper loaded: html_helper
INFO - 2023-08-21 07:23:22 --> Helper loaded: text_helper
INFO - 2023-08-21 07:23:22 --> Helper loaded: form_helper
INFO - 2023-08-21 07:23:22 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:23:22 --> Helper loaded: security_helper
INFO - 2023-08-21 07:23:22 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:23:22 --> Database Driver Class Initialized
INFO - 2023-08-21 07:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:23:22 --> Parser Class Initialized
INFO - 2023-08-21 07:23:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:23:22 --> Pagination Class Initialized
INFO - 2023-08-21 07:23:22 --> Form Validation Class Initialized
INFO - 2023-08-21 07:23:22 --> Controller Class Initialized
INFO - 2023-08-21 07:23:22 --> Model Class Initialized
DEBUG - 2023-08-21 07:23:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:23:22 --> Final output sent to browser
DEBUG - 2023-08-21 07:23:22 --> Total execution time: 0.0162
ERROR - 2023-08-21 07:23:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:23:29 --> Config Class Initialized
INFO - 2023-08-21 07:23:29 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:23:29 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:23:29 --> Utf8 Class Initialized
INFO - 2023-08-21 07:23:29 --> URI Class Initialized
INFO - 2023-08-21 07:23:29 --> Router Class Initialized
INFO - 2023-08-21 07:23:29 --> Output Class Initialized
INFO - 2023-08-21 07:23:29 --> Security Class Initialized
DEBUG - 2023-08-21 07:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:23:29 --> Input Class Initialized
INFO - 2023-08-21 07:23:29 --> Language Class Initialized
INFO - 2023-08-21 07:23:29 --> Loader Class Initialized
INFO - 2023-08-21 07:23:29 --> Helper loaded: url_helper
INFO - 2023-08-21 07:23:29 --> Helper loaded: file_helper
INFO - 2023-08-21 07:23:29 --> Helper loaded: html_helper
INFO - 2023-08-21 07:23:29 --> Helper loaded: text_helper
INFO - 2023-08-21 07:23:29 --> Helper loaded: form_helper
INFO - 2023-08-21 07:23:29 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:23:29 --> Helper loaded: security_helper
INFO - 2023-08-21 07:23:29 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:23:29 --> Database Driver Class Initialized
INFO - 2023-08-21 07:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:23:29 --> Parser Class Initialized
INFO - 2023-08-21 07:23:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:23:29 --> Pagination Class Initialized
INFO - 2023-08-21 07:23:29 --> Form Validation Class Initialized
INFO - 2023-08-21 07:23:29 --> Controller Class Initialized
INFO - 2023-08-21 07:23:29 --> Final output sent to browser
DEBUG - 2023-08-21 07:23:29 --> Total execution time: 0.0141
ERROR - 2023-08-21 07:23:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:23:32 --> Config Class Initialized
INFO - 2023-08-21 07:23:32 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:23:32 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:23:32 --> Utf8 Class Initialized
INFO - 2023-08-21 07:23:32 --> URI Class Initialized
INFO - 2023-08-21 07:23:32 --> Router Class Initialized
INFO - 2023-08-21 07:23:32 --> Output Class Initialized
INFO - 2023-08-21 07:23:32 --> Security Class Initialized
DEBUG - 2023-08-21 07:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:23:32 --> Input Class Initialized
INFO - 2023-08-21 07:23:32 --> Language Class Initialized
INFO - 2023-08-21 07:23:32 --> Loader Class Initialized
INFO - 2023-08-21 07:23:32 --> Helper loaded: url_helper
INFO - 2023-08-21 07:23:32 --> Helper loaded: file_helper
INFO - 2023-08-21 07:23:32 --> Helper loaded: html_helper
INFO - 2023-08-21 07:23:32 --> Helper loaded: text_helper
INFO - 2023-08-21 07:23:32 --> Helper loaded: form_helper
INFO - 2023-08-21 07:23:32 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:23:32 --> Helper loaded: security_helper
INFO - 2023-08-21 07:23:32 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:23:32 --> Database Driver Class Initialized
INFO - 2023-08-21 07:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:23:32 --> Parser Class Initialized
INFO - 2023-08-21 07:23:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:23:32 --> Pagination Class Initialized
INFO - 2023-08-21 07:23:32 --> Form Validation Class Initialized
INFO - 2023-08-21 07:23:32 --> Controller Class Initialized
INFO - 2023-08-21 07:23:32 --> Model Class Initialized
DEBUG - 2023-08-21 07:23:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:23:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:23:32 --> Model Class Initialized
DEBUG - 2023-08-21 07:23:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:23:32 --> Model Class Initialized
INFO - 2023-08-21 07:23:32 --> Final output sent to browser
DEBUG - 2023-08-21 07:23:32 --> Total execution time: 0.0575
ERROR - 2023-08-21 07:23:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:23:33 --> Config Class Initialized
INFO - 2023-08-21 07:23:33 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:23:33 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:23:33 --> Utf8 Class Initialized
INFO - 2023-08-21 07:23:33 --> URI Class Initialized
INFO - 2023-08-21 07:23:33 --> Router Class Initialized
INFO - 2023-08-21 07:23:33 --> Output Class Initialized
INFO - 2023-08-21 07:23:33 --> Security Class Initialized
DEBUG - 2023-08-21 07:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:23:33 --> Input Class Initialized
INFO - 2023-08-21 07:23:33 --> Language Class Initialized
INFO - 2023-08-21 07:23:33 --> Loader Class Initialized
INFO - 2023-08-21 07:23:33 --> Helper loaded: url_helper
INFO - 2023-08-21 07:23:33 --> Helper loaded: file_helper
INFO - 2023-08-21 07:23:33 --> Helper loaded: html_helper
INFO - 2023-08-21 07:23:33 --> Helper loaded: text_helper
INFO - 2023-08-21 07:23:33 --> Helper loaded: form_helper
INFO - 2023-08-21 07:23:33 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:23:33 --> Helper loaded: security_helper
INFO - 2023-08-21 07:23:33 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:23:33 --> Database Driver Class Initialized
INFO - 2023-08-21 07:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:23:33 --> Parser Class Initialized
INFO - 2023-08-21 07:23:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:23:33 --> Pagination Class Initialized
INFO - 2023-08-21 07:23:33 --> Form Validation Class Initialized
INFO - 2023-08-21 07:23:33 --> Controller Class Initialized
INFO - 2023-08-21 07:23:33 --> Model Class Initialized
DEBUG - 2023-08-21 07:23:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:23:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:23:33 --> Model Class Initialized
DEBUG - 2023-08-21 07:23:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:23:33 --> Model Class Initialized
INFO - 2023-08-21 07:23:33 --> Final output sent to browser
DEBUG - 2023-08-21 07:23:33 --> Total execution time: 0.0550
ERROR - 2023-08-21 07:23:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:23:33 --> Config Class Initialized
INFO - 2023-08-21 07:23:33 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:23:33 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:23:33 --> Utf8 Class Initialized
INFO - 2023-08-21 07:23:33 --> URI Class Initialized
INFO - 2023-08-21 07:23:33 --> Router Class Initialized
INFO - 2023-08-21 07:23:33 --> Output Class Initialized
INFO - 2023-08-21 07:23:33 --> Security Class Initialized
DEBUG - 2023-08-21 07:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:23:33 --> Input Class Initialized
INFO - 2023-08-21 07:23:33 --> Language Class Initialized
INFO - 2023-08-21 07:23:33 --> Loader Class Initialized
INFO - 2023-08-21 07:23:33 --> Helper loaded: url_helper
INFO - 2023-08-21 07:23:33 --> Helper loaded: file_helper
INFO - 2023-08-21 07:23:33 --> Helper loaded: html_helper
INFO - 2023-08-21 07:23:33 --> Helper loaded: text_helper
INFO - 2023-08-21 07:23:33 --> Helper loaded: form_helper
INFO - 2023-08-21 07:23:33 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:23:33 --> Helper loaded: security_helper
INFO - 2023-08-21 07:23:33 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:23:33 --> Database Driver Class Initialized
INFO - 2023-08-21 07:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:23:33 --> Parser Class Initialized
INFO - 2023-08-21 07:23:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:23:33 --> Pagination Class Initialized
INFO - 2023-08-21 07:23:33 --> Form Validation Class Initialized
INFO - 2023-08-21 07:23:33 --> Controller Class Initialized
INFO - 2023-08-21 07:23:33 --> Model Class Initialized
DEBUG - 2023-08-21 07:23:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:23:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:23:33 --> Model Class Initialized
DEBUG - 2023-08-21 07:23:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:23:33 --> Model Class Initialized
INFO - 2023-08-21 07:23:33 --> Final output sent to browser
DEBUG - 2023-08-21 07:23:33 --> Total execution time: 0.0539
ERROR - 2023-08-21 07:23:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:23:33 --> Config Class Initialized
INFO - 2023-08-21 07:23:33 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:23:33 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:23:33 --> Utf8 Class Initialized
INFO - 2023-08-21 07:23:33 --> URI Class Initialized
INFO - 2023-08-21 07:23:33 --> Router Class Initialized
INFO - 2023-08-21 07:23:33 --> Output Class Initialized
INFO - 2023-08-21 07:23:33 --> Security Class Initialized
DEBUG - 2023-08-21 07:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:23:33 --> Input Class Initialized
INFO - 2023-08-21 07:23:33 --> Language Class Initialized
INFO - 2023-08-21 07:23:33 --> Loader Class Initialized
INFO - 2023-08-21 07:23:33 --> Helper loaded: url_helper
INFO - 2023-08-21 07:23:33 --> Helper loaded: file_helper
INFO - 2023-08-21 07:23:33 --> Helper loaded: html_helper
INFO - 2023-08-21 07:23:33 --> Helper loaded: text_helper
INFO - 2023-08-21 07:23:33 --> Helper loaded: form_helper
INFO - 2023-08-21 07:23:33 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:23:33 --> Helper loaded: security_helper
INFO - 2023-08-21 07:23:33 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:23:33 --> Database Driver Class Initialized
INFO - 2023-08-21 07:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:23:33 --> Parser Class Initialized
INFO - 2023-08-21 07:23:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:23:33 --> Pagination Class Initialized
INFO - 2023-08-21 07:23:34 --> Form Validation Class Initialized
INFO - 2023-08-21 07:23:34 --> Controller Class Initialized
INFO - 2023-08-21 07:23:34 --> Model Class Initialized
DEBUG - 2023-08-21 07:23:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:23:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:23:34 --> Model Class Initialized
DEBUG - 2023-08-21 07:23:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:23:34 --> Model Class Initialized
INFO - 2023-08-21 07:23:34 --> Final output sent to browser
DEBUG - 2023-08-21 07:23:34 --> Total execution time: 0.0584
ERROR - 2023-08-21 07:23:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:23:39 --> Config Class Initialized
INFO - 2023-08-21 07:23:39 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:23:39 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:23:39 --> Utf8 Class Initialized
INFO - 2023-08-21 07:23:39 --> URI Class Initialized
INFO - 2023-08-21 07:23:39 --> Router Class Initialized
INFO - 2023-08-21 07:23:39 --> Output Class Initialized
INFO - 2023-08-21 07:23:39 --> Security Class Initialized
DEBUG - 2023-08-21 07:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:23:39 --> Input Class Initialized
INFO - 2023-08-21 07:23:39 --> Language Class Initialized
INFO - 2023-08-21 07:23:39 --> Loader Class Initialized
INFO - 2023-08-21 07:23:39 --> Helper loaded: url_helper
INFO - 2023-08-21 07:23:39 --> Helper loaded: file_helper
INFO - 2023-08-21 07:23:39 --> Helper loaded: html_helper
INFO - 2023-08-21 07:23:39 --> Helper loaded: text_helper
INFO - 2023-08-21 07:23:39 --> Helper loaded: form_helper
INFO - 2023-08-21 07:23:39 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:23:39 --> Helper loaded: security_helper
INFO - 2023-08-21 07:23:39 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:23:39 --> Database Driver Class Initialized
INFO - 2023-08-21 07:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:23:39 --> Parser Class Initialized
INFO - 2023-08-21 07:23:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:23:39 --> Pagination Class Initialized
INFO - 2023-08-21 07:23:39 --> Form Validation Class Initialized
INFO - 2023-08-21 07:23:39 --> Controller Class Initialized
INFO - 2023-08-21 07:23:39 --> Model Class Initialized
DEBUG - 2023-08-21 07:23:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:23:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:23:39 --> Model Class Initialized
DEBUG - 2023-08-21 07:23:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:23:39 --> Model Class Initialized
INFO - 2023-08-21 07:23:39 --> Final output sent to browser
DEBUG - 2023-08-21 07:23:39 --> Total execution time: 0.0185
ERROR - 2023-08-21 07:23:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:23:39 --> Config Class Initialized
INFO - 2023-08-21 07:23:39 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:23:39 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:23:39 --> Utf8 Class Initialized
INFO - 2023-08-21 07:23:39 --> URI Class Initialized
INFO - 2023-08-21 07:23:39 --> Router Class Initialized
INFO - 2023-08-21 07:23:39 --> Output Class Initialized
INFO - 2023-08-21 07:23:39 --> Security Class Initialized
DEBUG - 2023-08-21 07:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:23:39 --> Input Class Initialized
INFO - 2023-08-21 07:23:39 --> Language Class Initialized
INFO - 2023-08-21 07:23:39 --> Loader Class Initialized
INFO - 2023-08-21 07:23:39 --> Helper loaded: url_helper
INFO - 2023-08-21 07:23:39 --> Helper loaded: file_helper
INFO - 2023-08-21 07:23:39 --> Helper loaded: html_helper
INFO - 2023-08-21 07:23:39 --> Helper loaded: text_helper
INFO - 2023-08-21 07:23:39 --> Helper loaded: form_helper
INFO - 2023-08-21 07:23:39 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:23:39 --> Helper loaded: security_helper
INFO - 2023-08-21 07:23:39 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:23:39 --> Database Driver Class Initialized
INFO - 2023-08-21 07:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:23:39 --> Parser Class Initialized
INFO - 2023-08-21 07:23:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:23:39 --> Pagination Class Initialized
INFO - 2023-08-21 07:23:39 --> Form Validation Class Initialized
INFO - 2023-08-21 07:23:39 --> Controller Class Initialized
INFO - 2023-08-21 07:23:39 --> Model Class Initialized
DEBUG - 2023-08-21 07:23:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:23:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:23:39 --> Model Class Initialized
DEBUG - 2023-08-21 07:23:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:23:39 --> Model Class Initialized
INFO - 2023-08-21 07:23:39 --> Final output sent to browser
DEBUG - 2023-08-21 07:23:39 --> Total execution time: 0.0188
ERROR - 2023-08-21 07:23:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:23:41 --> Config Class Initialized
INFO - 2023-08-21 07:23:41 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:23:41 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:23:41 --> Utf8 Class Initialized
INFO - 2023-08-21 07:23:41 --> URI Class Initialized
INFO - 2023-08-21 07:23:41 --> Router Class Initialized
INFO - 2023-08-21 07:23:41 --> Output Class Initialized
INFO - 2023-08-21 07:23:41 --> Security Class Initialized
DEBUG - 2023-08-21 07:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:23:41 --> Input Class Initialized
INFO - 2023-08-21 07:23:41 --> Language Class Initialized
INFO - 2023-08-21 07:23:41 --> Loader Class Initialized
INFO - 2023-08-21 07:23:41 --> Helper loaded: url_helper
INFO - 2023-08-21 07:23:41 --> Helper loaded: file_helper
INFO - 2023-08-21 07:23:41 --> Helper loaded: html_helper
INFO - 2023-08-21 07:23:41 --> Helper loaded: text_helper
INFO - 2023-08-21 07:23:41 --> Helper loaded: form_helper
INFO - 2023-08-21 07:23:41 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:23:41 --> Helper loaded: security_helper
INFO - 2023-08-21 07:23:41 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:23:41 --> Database Driver Class Initialized
INFO - 2023-08-21 07:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:23:41 --> Parser Class Initialized
INFO - 2023-08-21 07:23:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:23:41 --> Pagination Class Initialized
INFO - 2023-08-21 07:23:41 --> Form Validation Class Initialized
INFO - 2023-08-21 07:23:41 --> Controller Class Initialized
INFO - 2023-08-21 07:23:41 --> Model Class Initialized
DEBUG - 2023-08-21 07:23:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:23:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:23:41 --> Model Class Initialized
DEBUG - 2023-08-21 07:23:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:23:41 --> Model Class Initialized
INFO - 2023-08-21 07:23:41 --> Final output sent to browser
DEBUG - 2023-08-21 07:23:41 --> Total execution time: 0.0179
ERROR - 2023-08-21 07:23:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:23:42 --> Config Class Initialized
INFO - 2023-08-21 07:23:42 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:23:42 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:23:42 --> Utf8 Class Initialized
INFO - 2023-08-21 07:23:42 --> URI Class Initialized
INFO - 2023-08-21 07:23:42 --> Router Class Initialized
INFO - 2023-08-21 07:23:42 --> Output Class Initialized
INFO - 2023-08-21 07:23:42 --> Security Class Initialized
DEBUG - 2023-08-21 07:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:23:42 --> Input Class Initialized
INFO - 2023-08-21 07:23:42 --> Language Class Initialized
INFO - 2023-08-21 07:23:42 --> Loader Class Initialized
INFO - 2023-08-21 07:23:42 --> Helper loaded: url_helper
INFO - 2023-08-21 07:23:42 --> Helper loaded: file_helper
INFO - 2023-08-21 07:23:42 --> Helper loaded: html_helper
INFO - 2023-08-21 07:23:42 --> Helper loaded: text_helper
INFO - 2023-08-21 07:23:42 --> Helper loaded: form_helper
INFO - 2023-08-21 07:23:42 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:23:42 --> Helper loaded: security_helper
INFO - 2023-08-21 07:23:42 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:23:42 --> Database Driver Class Initialized
INFO - 2023-08-21 07:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:23:42 --> Parser Class Initialized
INFO - 2023-08-21 07:23:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:23:42 --> Pagination Class Initialized
INFO - 2023-08-21 07:23:42 --> Form Validation Class Initialized
INFO - 2023-08-21 07:23:42 --> Controller Class Initialized
INFO - 2023-08-21 07:23:42 --> Model Class Initialized
DEBUG - 2023-08-21 07:23:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:23:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:23:42 --> Model Class Initialized
DEBUG - 2023-08-21 07:23:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:23:42 --> Model Class Initialized
INFO - 2023-08-21 07:23:42 --> Final output sent to browser
DEBUG - 2023-08-21 07:23:42 --> Total execution time: 0.0254
ERROR - 2023-08-21 07:23:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:23:43 --> Config Class Initialized
INFO - 2023-08-21 07:23:43 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:23:43 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:23:43 --> Utf8 Class Initialized
INFO - 2023-08-21 07:23:43 --> URI Class Initialized
INFO - 2023-08-21 07:23:43 --> Router Class Initialized
INFO - 2023-08-21 07:23:43 --> Output Class Initialized
INFO - 2023-08-21 07:23:43 --> Security Class Initialized
DEBUG - 2023-08-21 07:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:23:43 --> Input Class Initialized
INFO - 2023-08-21 07:23:43 --> Language Class Initialized
INFO - 2023-08-21 07:23:43 --> Loader Class Initialized
INFO - 2023-08-21 07:23:43 --> Helper loaded: url_helper
INFO - 2023-08-21 07:23:43 --> Helper loaded: file_helper
INFO - 2023-08-21 07:23:43 --> Helper loaded: html_helper
INFO - 2023-08-21 07:23:43 --> Helper loaded: text_helper
INFO - 2023-08-21 07:23:43 --> Helper loaded: form_helper
INFO - 2023-08-21 07:23:43 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:23:43 --> Helper loaded: security_helper
INFO - 2023-08-21 07:23:43 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:23:43 --> Database Driver Class Initialized
INFO - 2023-08-21 07:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:23:43 --> Parser Class Initialized
INFO - 2023-08-21 07:23:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:23:43 --> Pagination Class Initialized
INFO - 2023-08-21 07:23:43 --> Form Validation Class Initialized
INFO - 2023-08-21 07:23:43 --> Controller Class Initialized
INFO - 2023-08-21 07:23:43 --> Model Class Initialized
DEBUG - 2023-08-21 07:23:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:23:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:23:43 --> Model Class Initialized
DEBUG - 2023-08-21 07:23:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:23:43 --> Model Class Initialized
INFO - 2023-08-21 07:23:43 --> Final output sent to browser
DEBUG - 2023-08-21 07:23:43 --> Total execution time: 0.0230
ERROR - 2023-08-21 07:23:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:23:43 --> Config Class Initialized
INFO - 2023-08-21 07:23:43 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:23:43 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:23:43 --> Utf8 Class Initialized
INFO - 2023-08-21 07:23:43 --> URI Class Initialized
INFO - 2023-08-21 07:23:43 --> Router Class Initialized
INFO - 2023-08-21 07:23:43 --> Output Class Initialized
INFO - 2023-08-21 07:23:43 --> Security Class Initialized
DEBUG - 2023-08-21 07:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:23:43 --> Input Class Initialized
INFO - 2023-08-21 07:23:43 --> Language Class Initialized
INFO - 2023-08-21 07:23:43 --> Loader Class Initialized
INFO - 2023-08-21 07:23:43 --> Helper loaded: url_helper
INFO - 2023-08-21 07:23:43 --> Helper loaded: file_helper
INFO - 2023-08-21 07:23:43 --> Helper loaded: html_helper
INFO - 2023-08-21 07:23:43 --> Helper loaded: text_helper
INFO - 2023-08-21 07:23:43 --> Helper loaded: form_helper
INFO - 2023-08-21 07:23:43 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:23:43 --> Helper loaded: security_helper
INFO - 2023-08-21 07:23:43 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:23:43 --> Database Driver Class Initialized
INFO - 2023-08-21 07:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:23:43 --> Parser Class Initialized
INFO - 2023-08-21 07:23:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:23:43 --> Pagination Class Initialized
INFO - 2023-08-21 07:23:43 --> Form Validation Class Initialized
INFO - 2023-08-21 07:23:43 --> Controller Class Initialized
INFO - 2023-08-21 07:23:43 --> Model Class Initialized
DEBUG - 2023-08-21 07:23:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:23:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:23:43 --> Model Class Initialized
DEBUG - 2023-08-21 07:23:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:23:43 --> Model Class Initialized
INFO - 2023-08-21 07:23:43 --> Final output sent to browser
DEBUG - 2023-08-21 07:23:43 --> Total execution time: 0.0285
ERROR - 2023-08-21 07:23:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:23:43 --> Config Class Initialized
INFO - 2023-08-21 07:23:43 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:23:43 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:23:43 --> Utf8 Class Initialized
INFO - 2023-08-21 07:23:43 --> URI Class Initialized
INFO - 2023-08-21 07:23:43 --> Router Class Initialized
INFO - 2023-08-21 07:23:43 --> Output Class Initialized
INFO - 2023-08-21 07:23:43 --> Security Class Initialized
DEBUG - 2023-08-21 07:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:23:43 --> Input Class Initialized
INFO - 2023-08-21 07:23:43 --> Language Class Initialized
INFO - 2023-08-21 07:23:43 --> Loader Class Initialized
INFO - 2023-08-21 07:23:43 --> Helper loaded: url_helper
INFO - 2023-08-21 07:23:43 --> Helper loaded: file_helper
INFO - 2023-08-21 07:23:43 --> Helper loaded: html_helper
INFO - 2023-08-21 07:23:43 --> Helper loaded: text_helper
INFO - 2023-08-21 07:23:43 --> Helper loaded: form_helper
INFO - 2023-08-21 07:23:43 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:23:43 --> Helper loaded: security_helper
INFO - 2023-08-21 07:23:43 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:23:43 --> Database Driver Class Initialized
INFO - 2023-08-21 07:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:23:43 --> Parser Class Initialized
INFO - 2023-08-21 07:23:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:23:43 --> Pagination Class Initialized
INFO - 2023-08-21 07:23:43 --> Form Validation Class Initialized
INFO - 2023-08-21 07:23:43 --> Controller Class Initialized
INFO - 2023-08-21 07:23:43 --> Model Class Initialized
DEBUG - 2023-08-21 07:23:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:23:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:23:43 --> Model Class Initialized
DEBUG - 2023-08-21 07:23:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:23:43 --> Model Class Initialized
INFO - 2023-08-21 07:23:43 --> Final output sent to browser
DEBUG - 2023-08-21 07:23:43 --> Total execution time: 0.0588
ERROR - 2023-08-21 07:23:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:23:49 --> Config Class Initialized
INFO - 2023-08-21 07:23:49 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:23:49 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:23:49 --> Utf8 Class Initialized
INFO - 2023-08-21 07:23:49 --> URI Class Initialized
INFO - 2023-08-21 07:23:49 --> Router Class Initialized
INFO - 2023-08-21 07:23:49 --> Output Class Initialized
INFO - 2023-08-21 07:23:49 --> Security Class Initialized
DEBUG - 2023-08-21 07:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:23:49 --> Input Class Initialized
INFO - 2023-08-21 07:23:49 --> Language Class Initialized
INFO - 2023-08-21 07:23:49 --> Loader Class Initialized
INFO - 2023-08-21 07:23:49 --> Helper loaded: url_helper
INFO - 2023-08-21 07:23:49 --> Helper loaded: file_helper
INFO - 2023-08-21 07:23:49 --> Helper loaded: html_helper
INFO - 2023-08-21 07:23:49 --> Helper loaded: text_helper
INFO - 2023-08-21 07:23:49 --> Helper loaded: form_helper
INFO - 2023-08-21 07:23:49 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:23:49 --> Helper loaded: security_helper
INFO - 2023-08-21 07:23:49 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:23:49 --> Database Driver Class Initialized
INFO - 2023-08-21 07:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:23:49 --> Parser Class Initialized
INFO - 2023-08-21 07:23:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:23:49 --> Pagination Class Initialized
INFO - 2023-08-21 07:23:49 --> Form Validation Class Initialized
INFO - 2023-08-21 07:23:49 --> Controller Class Initialized
INFO - 2023-08-21 07:23:49 --> Model Class Initialized
DEBUG - 2023-08-21 07:23:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:23:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:23:49 --> Model Class Initialized
DEBUG - 2023-08-21 07:23:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:23:49 --> Model Class Initialized
INFO - 2023-08-21 07:23:49 --> Final output sent to browser
DEBUG - 2023-08-21 07:23:49 --> Total execution time: 0.0201
ERROR - 2023-08-21 07:23:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:23:51 --> Config Class Initialized
INFO - 2023-08-21 07:23:51 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:23:51 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:23:51 --> Utf8 Class Initialized
INFO - 2023-08-21 07:23:51 --> URI Class Initialized
INFO - 2023-08-21 07:23:51 --> Router Class Initialized
INFO - 2023-08-21 07:23:51 --> Output Class Initialized
INFO - 2023-08-21 07:23:51 --> Security Class Initialized
DEBUG - 2023-08-21 07:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:23:51 --> Input Class Initialized
INFO - 2023-08-21 07:23:51 --> Language Class Initialized
INFO - 2023-08-21 07:23:51 --> Loader Class Initialized
INFO - 2023-08-21 07:23:51 --> Helper loaded: url_helper
INFO - 2023-08-21 07:23:51 --> Helper loaded: file_helper
INFO - 2023-08-21 07:23:51 --> Helper loaded: html_helper
INFO - 2023-08-21 07:23:51 --> Helper loaded: text_helper
INFO - 2023-08-21 07:23:51 --> Helper loaded: form_helper
INFO - 2023-08-21 07:23:51 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:23:51 --> Helper loaded: security_helper
INFO - 2023-08-21 07:23:51 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:23:51 --> Database Driver Class Initialized
INFO - 2023-08-21 07:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:23:51 --> Parser Class Initialized
INFO - 2023-08-21 07:23:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:23:51 --> Pagination Class Initialized
INFO - 2023-08-21 07:23:51 --> Form Validation Class Initialized
INFO - 2023-08-21 07:23:51 --> Controller Class Initialized
INFO - 2023-08-21 07:23:51 --> Model Class Initialized
DEBUG - 2023-08-21 07:23:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:23:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:23:51 --> Model Class Initialized
DEBUG - 2023-08-21 07:23:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:23:51 --> Model Class Initialized
INFO - 2023-08-21 07:23:51 --> Final output sent to browser
DEBUG - 2023-08-21 07:23:51 --> Total execution time: 0.0527
ERROR - 2023-08-21 07:23:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:23:57 --> Config Class Initialized
INFO - 2023-08-21 07:23:57 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:23:57 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:23:57 --> Utf8 Class Initialized
INFO - 2023-08-21 07:23:57 --> URI Class Initialized
INFO - 2023-08-21 07:23:57 --> Router Class Initialized
INFO - 2023-08-21 07:23:57 --> Output Class Initialized
INFO - 2023-08-21 07:23:57 --> Security Class Initialized
DEBUG - 2023-08-21 07:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:23:57 --> Input Class Initialized
INFO - 2023-08-21 07:23:57 --> Language Class Initialized
INFO - 2023-08-21 07:23:57 --> Loader Class Initialized
INFO - 2023-08-21 07:23:57 --> Helper loaded: url_helper
INFO - 2023-08-21 07:23:57 --> Helper loaded: file_helper
INFO - 2023-08-21 07:23:57 --> Helper loaded: html_helper
INFO - 2023-08-21 07:23:57 --> Helper loaded: text_helper
INFO - 2023-08-21 07:23:57 --> Helper loaded: form_helper
INFO - 2023-08-21 07:23:57 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:23:57 --> Helper loaded: security_helper
INFO - 2023-08-21 07:23:57 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:23:57 --> Database Driver Class Initialized
INFO - 2023-08-21 07:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:23:57 --> Parser Class Initialized
INFO - 2023-08-21 07:23:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:23:57 --> Pagination Class Initialized
INFO - 2023-08-21 07:23:57 --> Form Validation Class Initialized
INFO - 2023-08-21 07:23:57 --> Controller Class Initialized
INFO - 2023-08-21 07:23:57 --> Model Class Initialized
DEBUG - 2023-08-21 07:23:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:23:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:23:57 --> Model Class Initialized
DEBUG - 2023-08-21 07:23:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:23:57 --> Model Class Initialized
INFO - 2023-08-21 07:23:57 --> Final output sent to browser
DEBUG - 2023-08-21 07:23:57 --> Total execution time: 0.0194
ERROR - 2023-08-21 07:23:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:23:57 --> Config Class Initialized
INFO - 2023-08-21 07:23:57 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:23:57 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:23:57 --> Utf8 Class Initialized
INFO - 2023-08-21 07:23:57 --> URI Class Initialized
INFO - 2023-08-21 07:23:57 --> Router Class Initialized
INFO - 2023-08-21 07:23:57 --> Output Class Initialized
INFO - 2023-08-21 07:23:57 --> Security Class Initialized
DEBUG - 2023-08-21 07:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:23:57 --> Input Class Initialized
INFO - 2023-08-21 07:23:57 --> Language Class Initialized
INFO - 2023-08-21 07:23:57 --> Loader Class Initialized
INFO - 2023-08-21 07:23:57 --> Helper loaded: url_helper
INFO - 2023-08-21 07:23:57 --> Helper loaded: file_helper
INFO - 2023-08-21 07:23:57 --> Helper loaded: html_helper
INFO - 2023-08-21 07:23:57 --> Helper loaded: text_helper
INFO - 2023-08-21 07:23:57 --> Helper loaded: form_helper
INFO - 2023-08-21 07:23:57 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:23:57 --> Helper loaded: security_helper
INFO - 2023-08-21 07:23:57 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:23:57 --> Database Driver Class Initialized
INFO - 2023-08-21 07:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:23:57 --> Parser Class Initialized
INFO - 2023-08-21 07:23:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:23:57 --> Pagination Class Initialized
INFO - 2023-08-21 07:23:57 --> Form Validation Class Initialized
INFO - 2023-08-21 07:23:57 --> Controller Class Initialized
INFO - 2023-08-21 07:23:57 --> Model Class Initialized
DEBUG - 2023-08-21 07:23:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:23:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:23:57 --> Model Class Initialized
DEBUG - 2023-08-21 07:23:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:23:57 --> Model Class Initialized
INFO - 2023-08-21 07:23:57 --> Final output sent to browser
DEBUG - 2023-08-21 07:23:57 --> Total execution time: 0.0184
ERROR - 2023-08-21 07:24:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:24:00 --> Config Class Initialized
INFO - 2023-08-21 07:24:00 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:24:00 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:24:00 --> Utf8 Class Initialized
INFO - 2023-08-21 07:24:00 --> URI Class Initialized
INFO - 2023-08-21 07:24:00 --> Router Class Initialized
INFO - 2023-08-21 07:24:00 --> Output Class Initialized
INFO - 2023-08-21 07:24:00 --> Security Class Initialized
DEBUG - 2023-08-21 07:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:24:00 --> Input Class Initialized
INFO - 2023-08-21 07:24:00 --> Language Class Initialized
INFO - 2023-08-21 07:24:00 --> Loader Class Initialized
INFO - 2023-08-21 07:24:00 --> Helper loaded: url_helper
INFO - 2023-08-21 07:24:00 --> Helper loaded: file_helper
INFO - 2023-08-21 07:24:00 --> Helper loaded: html_helper
INFO - 2023-08-21 07:24:00 --> Helper loaded: text_helper
INFO - 2023-08-21 07:24:00 --> Helper loaded: form_helper
INFO - 2023-08-21 07:24:00 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:24:00 --> Helper loaded: security_helper
INFO - 2023-08-21 07:24:00 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:24:00 --> Database Driver Class Initialized
INFO - 2023-08-21 07:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:24:00 --> Parser Class Initialized
INFO - 2023-08-21 07:24:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:24:00 --> Pagination Class Initialized
INFO - 2023-08-21 07:24:00 --> Form Validation Class Initialized
INFO - 2023-08-21 07:24:00 --> Controller Class Initialized
INFO - 2023-08-21 07:24:00 --> Model Class Initialized
DEBUG - 2023-08-21 07:24:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:24:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:24:00 --> Model Class Initialized
INFO - 2023-08-21 07:24:00 --> Model Class Initialized
INFO - 2023-08-21 07:24:00 --> Final output sent to browser
DEBUG - 2023-08-21 07:24:00 --> Total execution time: 0.0198
ERROR - 2023-08-21 07:24:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:24:02 --> Config Class Initialized
INFO - 2023-08-21 07:24:02 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:24:02 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:24:02 --> Utf8 Class Initialized
INFO - 2023-08-21 07:24:02 --> URI Class Initialized
INFO - 2023-08-21 07:24:02 --> Router Class Initialized
INFO - 2023-08-21 07:24:02 --> Output Class Initialized
INFO - 2023-08-21 07:24:02 --> Security Class Initialized
DEBUG - 2023-08-21 07:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:24:02 --> Input Class Initialized
INFO - 2023-08-21 07:24:02 --> Language Class Initialized
INFO - 2023-08-21 07:24:02 --> Loader Class Initialized
INFO - 2023-08-21 07:24:02 --> Helper loaded: url_helper
INFO - 2023-08-21 07:24:02 --> Helper loaded: file_helper
INFO - 2023-08-21 07:24:02 --> Helper loaded: html_helper
INFO - 2023-08-21 07:24:02 --> Helper loaded: text_helper
INFO - 2023-08-21 07:24:02 --> Helper loaded: form_helper
INFO - 2023-08-21 07:24:02 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:24:02 --> Helper loaded: security_helper
INFO - 2023-08-21 07:24:02 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:24:02 --> Database Driver Class Initialized
INFO - 2023-08-21 07:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:24:02 --> Parser Class Initialized
INFO - 2023-08-21 07:24:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:24:02 --> Pagination Class Initialized
INFO - 2023-08-21 07:24:02 --> Form Validation Class Initialized
INFO - 2023-08-21 07:24:02 --> Controller Class Initialized
INFO - 2023-08-21 07:24:02 --> Model Class Initialized
DEBUG - 2023-08-21 07:24:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:24:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:24:02 --> Model Class Initialized
INFO - 2023-08-21 07:24:02 --> Final output sent to browser
DEBUG - 2023-08-21 07:24:02 --> Total execution time: 0.0210
ERROR - 2023-08-21 07:25:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:25:08 --> Config Class Initialized
INFO - 2023-08-21 07:25:08 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:25:08 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:25:08 --> Utf8 Class Initialized
INFO - 2023-08-21 07:25:08 --> URI Class Initialized
INFO - 2023-08-21 07:25:08 --> Router Class Initialized
INFO - 2023-08-21 07:25:08 --> Output Class Initialized
INFO - 2023-08-21 07:25:08 --> Security Class Initialized
DEBUG - 2023-08-21 07:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:25:08 --> Input Class Initialized
INFO - 2023-08-21 07:25:08 --> Language Class Initialized
INFO - 2023-08-21 07:25:08 --> Loader Class Initialized
INFO - 2023-08-21 07:25:08 --> Helper loaded: url_helper
INFO - 2023-08-21 07:25:08 --> Helper loaded: file_helper
INFO - 2023-08-21 07:25:08 --> Helper loaded: html_helper
INFO - 2023-08-21 07:25:08 --> Helper loaded: text_helper
INFO - 2023-08-21 07:25:08 --> Helper loaded: form_helper
INFO - 2023-08-21 07:25:08 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:25:08 --> Helper loaded: security_helper
INFO - 2023-08-21 07:25:08 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:25:08 --> Database Driver Class Initialized
INFO - 2023-08-21 07:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:25:08 --> Parser Class Initialized
INFO - 2023-08-21 07:25:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:25:08 --> Pagination Class Initialized
INFO - 2023-08-21 07:25:08 --> Form Validation Class Initialized
INFO - 2023-08-21 07:25:08 --> Controller Class Initialized
INFO - 2023-08-21 07:25:08 --> Model Class Initialized
DEBUG - 2023-08-21 07:25:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:25:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:25:08 --> Model Class Initialized
DEBUG - 2023-08-21 07:25:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:25:08 --> Model Class Initialized
INFO - 2023-08-21 07:25:08 --> Email Class Initialized
DEBUG - 2023-08-21 07:25:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:25:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-21 07:25:08 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2023-08-21 07:25:08 --> Language file loaded: language/english/email_lang.php
INFO - 2023-08-21 07:25:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2023-08-21 07:25:08 --> Final output sent to browser
DEBUG - 2023-08-21 07:25:08 --> Total execution time: 0.4911
ERROR - 2023-08-21 07:25:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:25:11 --> Config Class Initialized
INFO - 2023-08-21 07:25:11 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:25:11 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:25:11 --> Utf8 Class Initialized
INFO - 2023-08-21 07:25:11 --> URI Class Initialized
INFO - 2023-08-21 07:25:11 --> Router Class Initialized
INFO - 2023-08-21 07:25:11 --> Output Class Initialized
INFO - 2023-08-21 07:25:11 --> Security Class Initialized
DEBUG - 2023-08-21 07:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:25:11 --> Input Class Initialized
INFO - 2023-08-21 07:25:11 --> Language Class Initialized
INFO - 2023-08-21 07:25:11 --> Loader Class Initialized
INFO - 2023-08-21 07:25:11 --> Helper loaded: url_helper
INFO - 2023-08-21 07:25:11 --> Helper loaded: file_helper
INFO - 2023-08-21 07:25:11 --> Helper loaded: html_helper
INFO - 2023-08-21 07:25:11 --> Helper loaded: text_helper
INFO - 2023-08-21 07:25:11 --> Helper loaded: form_helper
INFO - 2023-08-21 07:25:11 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:25:11 --> Helper loaded: security_helper
INFO - 2023-08-21 07:25:11 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:25:11 --> Database Driver Class Initialized
INFO - 2023-08-21 07:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:25:11 --> Parser Class Initialized
INFO - 2023-08-21 07:25:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:25:11 --> Pagination Class Initialized
INFO - 2023-08-21 07:25:11 --> Form Validation Class Initialized
INFO - 2023-08-21 07:25:11 --> Controller Class Initialized
INFO - 2023-08-21 07:25:11 --> Model Class Initialized
DEBUG - 2023-08-21 07:25:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:25:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:25:11 --> Model Class Initialized
DEBUG - 2023-08-21 07:25:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:25:11 --> Model Class Initialized
INFO - 2023-08-21 07:25:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-08-21 07:25:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:25:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 07:25:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 07:25:11 --> Model Class Initialized
INFO - 2023-08-21 07:25:11 --> Model Class Initialized
INFO - 2023-08-21 07:25:11 --> Model Class Initialized
INFO - 2023-08-21 07:25:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 07:25:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 07:25:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 07:25:11 --> Final output sent to browser
DEBUG - 2023-08-21 07:25:11 --> Total execution time: 0.0936
ERROR - 2023-08-21 07:25:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:25:15 --> Config Class Initialized
INFO - 2023-08-21 07:25:15 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:25:15 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:25:15 --> Utf8 Class Initialized
INFO - 2023-08-21 07:25:15 --> URI Class Initialized
INFO - 2023-08-21 07:25:15 --> Router Class Initialized
INFO - 2023-08-21 07:25:15 --> Output Class Initialized
INFO - 2023-08-21 07:25:15 --> Security Class Initialized
DEBUG - 2023-08-21 07:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:25:15 --> Input Class Initialized
INFO - 2023-08-21 07:25:15 --> Language Class Initialized
INFO - 2023-08-21 07:25:15 --> Loader Class Initialized
INFO - 2023-08-21 07:25:15 --> Helper loaded: url_helper
INFO - 2023-08-21 07:25:15 --> Helper loaded: file_helper
INFO - 2023-08-21 07:25:15 --> Helper loaded: html_helper
INFO - 2023-08-21 07:25:15 --> Helper loaded: text_helper
INFO - 2023-08-21 07:25:15 --> Helper loaded: form_helper
INFO - 2023-08-21 07:25:15 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:25:15 --> Helper loaded: security_helper
INFO - 2023-08-21 07:25:15 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:25:15 --> Database Driver Class Initialized
INFO - 2023-08-21 07:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:25:15 --> Parser Class Initialized
INFO - 2023-08-21 07:25:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:25:15 --> Pagination Class Initialized
INFO - 2023-08-21 07:25:15 --> Form Validation Class Initialized
INFO - 2023-08-21 07:25:15 --> Controller Class Initialized
INFO - 2023-08-21 07:25:15 --> Model Class Initialized
DEBUG - 2023-08-21 07:25:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:25:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:25:15 --> Model Class Initialized
DEBUG - 2023-08-21 07:25:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:25:15 --> Model Class Initialized
INFO - 2023-08-21 07:25:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-21 07:25:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:25:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 07:25:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 07:25:15 --> Model Class Initialized
INFO - 2023-08-21 07:25:15 --> Model Class Initialized
INFO - 2023-08-21 07:25:15 --> Model Class Initialized
INFO - 2023-08-21 07:25:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 07:25:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 07:25:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 07:25:15 --> Final output sent to browser
DEBUG - 2023-08-21 07:25:15 --> Total execution time: 0.0723
ERROR - 2023-08-21 07:25:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:25:16 --> Config Class Initialized
INFO - 2023-08-21 07:25:16 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:25:16 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:25:16 --> Utf8 Class Initialized
INFO - 2023-08-21 07:25:16 --> URI Class Initialized
INFO - 2023-08-21 07:25:16 --> Router Class Initialized
INFO - 2023-08-21 07:25:16 --> Output Class Initialized
INFO - 2023-08-21 07:25:16 --> Security Class Initialized
DEBUG - 2023-08-21 07:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:25:16 --> Input Class Initialized
INFO - 2023-08-21 07:25:16 --> Language Class Initialized
INFO - 2023-08-21 07:25:16 --> Loader Class Initialized
INFO - 2023-08-21 07:25:16 --> Helper loaded: url_helper
INFO - 2023-08-21 07:25:16 --> Helper loaded: file_helper
INFO - 2023-08-21 07:25:16 --> Helper loaded: html_helper
INFO - 2023-08-21 07:25:16 --> Helper loaded: text_helper
INFO - 2023-08-21 07:25:16 --> Helper loaded: form_helper
INFO - 2023-08-21 07:25:16 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:25:16 --> Helper loaded: security_helper
INFO - 2023-08-21 07:25:16 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:25:16 --> Database Driver Class Initialized
INFO - 2023-08-21 07:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:25:16 --> Parser Class Initialized
INFO - 2023-08-21 07:25:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:25:16 --> Pagination Class Initialized
INFO - 2023-08-21 07:25:16 --> Form Validation Class Initialized
INFO - 2023-08-21 07:25:16 --> Controller Class Initialized
INFO - 2023-08-21 07:25:16 --> Model Class Initialized
DEBUG - 2023-08-21 07:25:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:25:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:25:16 --> Model Class Initialized
DEBUG - 2023-08-21 07:25:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:25:16 --> Model Class Initialized
INFO - 2023-08-21 07:25:16 --> Final output sent to browser
DEBUG - 2023-08-21 07:25:16 --> Total execution time: 0.0357
ERROR - 2023-08-21 07:25:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:25:19 --> Config Class Initialized
INFO - 2023-08-21 07:25:19 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:25:19 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:25:19 --> Utf8 Class Initialized
INFO - 2023-08-21 07:25:19 --> URI Class Initialized
INFO - 2023-08-21 07:25:19 --> Router Class Initialized
INFO - 2023-08-21 07:25:19 --> Output Class Initialized
INFO - 2023-08-21 07:25:19 --> Security Class Initialized
DEBUG - 2023-08-21 07:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:25:19 --> Input Class Initialized
INFO - 2023-08-21 07:25:19 --> Language Class Initialized
INFO - 2023-08-21 07:25:19 --> Loader Class Initialized
INFO - 2023-08-21 07:25:19 --> Helper loaded: url_helper
INFO - 2023-08-21 07:25:19 --> Helper loaded: file_helper
INFO - 2023-08-21 07:25:19 --> Helper loaded: html_helper
INFO - 2023-08-21 07:25:19 --> Helper loaded: text_helper
INFO - 2023-08-21 07:25:19 --> Helper loaded: form_helper
INFO - 2023-08-21 07:25:19 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:25:19 --> Helper loaded: security_helper
INFO - 2023-08-21 07:25:19 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:25:19 --> Database Driver Class Initialized
INFO - 2023-08-21 07:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:25:19 --> Parser Class Initialized
INFO - 2023-08-21 07:25:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:25:19 --> Pagination Class Initialized
INFO - 2023-08-21 07:25:19 --> Form Validation Class Initialized
INFO - 2023-08-21 07:25:19 --> Controller Class Initialized
INFO - 2023-08-21 07:25:19 --> Model Class Initialized
DEBUG - 2023-08-21 07:25:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:25:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:25:19 --> Model Class Initialized
DEBUG - 2023-08-21 07:25:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:25:19 --> Model Class Initialized
DEBUG - 2023-08-21 07:25:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:25:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-21 07:25:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:25:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 07:25:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 07:25:19 --> Model Class Initialized
INFO - 2023-08-21 07:25:19 --> Model Class Initialized
INFO - 2023-08-21 07:25:19 --> Model Class Initialized
INFO - 2023-08-21 07:25:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 07:25:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 07:25:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 07:25:19 --> Final output sent to browser
DEBUG - 2023-08-21 07:25:19 --> Total execution time: 0.0774
ERROR - 2023-08-21 07:26:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:26:01 --> Config Class Initialized
INFO - 2023-08-21 07:26:01 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:26:01 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:26:01 --> Utf8 Class Initialized
INFO - 2023-08-21 07:26:01 --> URI Class Initialized
INFO - 2023-08-21 07:26:01 --> Router Class Initialized
INFO - 2023-08-21 07:26:01 --> Output Class Initialized
INFO - 2023-08-21 07:26:01 --> Security Class Initialized
DEBUG - 2023-08-21 07:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:26:01 --> Input Class Initialized
INFO - 2023-08-21 07:26:01 --> Language Class Initialized
INFO - 2023-08-21 07:26:01 --> Loader Class Initialized
INFO - 2023-08-21 07:26:01 --> Helper loaded: url_helper
INFO - 2023-08-21 07:26:01 --> Helper loaded: file_helper
INFO - 2023-08-21 07:26:01 --> Helper loaded: html_helper
INFO - 2023-08-21 07:26:01 --> Helper loaded: text_helper
INFO - 2023-08-21 07:26:01 --> Helper loaded: form_helper
INFO - 2023-08-21 07:26:01 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:26:01 --> Helper loaded: security_helper
INFO - 2023-08-21 07:26:01 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:26:01 --> Database Driver Class Initialized
INFO - 2023-08-21 07:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:26:01 --> Parser Class Initialized
INFO - 2023-08-21 07:26:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:26:01 --> Pagination Class Initialized
INFO - 2023-08-21 07:26:01 --> Form Validation Class Initialized
INFO - 2023-08-21 07:26:01 --> Controller Class Initialized
INFO - 2023-08-21 07:26:01 --> Model Class Initialized
DEBUG - 2023-08-21 07:26:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:26:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:26:01 --> Model Class Initialized
DEBUG - 2023-08-21 07:26:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:26:01 --> Model Class Initialized
INFO - 2023-08-21 07:26:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-21 07:26:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:26:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 07:26:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 07:26:01 --> Model Class Initialized
INFO - 2023-08-21 07:26:01 --> Model Class Initialized
INFO - 2023-08-21 07:26:01 --> Model Class Initialized
INFO - 2023-08-21 07:26:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 07:26:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 07:26:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 07:26:01 --> Final output sent to browser
DEBUG - 2023-08-21 07:26:01 --> Total execution time: 0.0790
ERROR - 2023-08-21 07:26:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:26:01 --> Config Class Initialized
INFO - 2023-08-21 07:26:01 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:26:01 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:26:01 --> Utf8 Class Initialized
INFO - 2023-08-21 07:26:01 --> URI Class Initialized
INFO - 2023-08-21 07:26:01 --> Router Class Initialized
INFO - 2023-08-21 07:26:01 --> Output Class Initialized
INFO - 2023-08-21 07:26:01 --> Security Class Initialized
DEBUG - 2023-08-21 07:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:26:01 --> Input Class Initialized
INFO - 2023-08-21 07:26:01 --> Language Class Initialized
INFO - 2023-08-21 07:26:01 --> Loader Class Initialized
INFO - 2023-08-21 07:26:01 --> Helper loaded: url_helper
INFO - 2023-08-21 07:26:01 --> Helper loaded: file_helper
INFO - 2023-08-21 07:26:01 --> Helper loaded: html_helper
INFO - 2023-08-21 07:26:01 --> Helper loaded: text_helper
INFO - 2023-08-21 07:26:01 --> Helper loaded: form_helper
INFO - 2023-08-21 07:26:01 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:26:01 --> Helper loaded: security_helper
INFO - 2023-08-21 07:26:01 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:26:01 --> Database Driver Class Initialized
INFO - 2023-08-21 07:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:26:01 --> Parser Class Initialized
INFO - 2023-08-21 07:26:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:26:01 --> Pagination Class Initialized
INFO - 2023-08-21 07:26:01 --> Form Validation Class Initialized
INFO - 2023-08-21 07:26:01 --> Controller Class Initialized
INFO - 2023-08-21 07:26:01 --> Model Class Initialized
DEBUG - 2023-08-21 07:26:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:26:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:26:01 --> Model Class Initialized
DEBUG - 2023-08-21 07:26:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:26:01 --> Model Class Initialized
INFO - 2023-08-21 07:26:01 --> Final output sent to browser
DEBUG - 2023-08-21 07:26:01 --> Total execution time: 0.0354
ERROR - 2023-08-21 07:26:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:26:41 --> Config Class Initialized
INFO - 2023-08-21 07:26:41 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:26:41 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:26:41 --> Utf8 Class Initialized
INFO - 2023-08-21 07:26:41 --> URI Class Initialized
DEBUG - 2023-08-21 07:26:41 --> No URI present. Default controller set.
INFO - 2023-08-21 07:26:41 --> Router Class Initialized
INFO - 2023-08-21 07:26:41 --> Output Class Initialized
INFO - 2023-08-21 07:26:41 --> Security Class Initialized
DEBUG - 2023-08-21 07:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:26:41 --> Input Class Initialized
INFO - 2023-08-21 07:26:41 --> Language Class Initialized
INFO - 2023-08-21 07:26:41 --> Loader Class Initialized
INFO - 2023-08-21 07:26:41 --> Helper loaded: url_helper
INFO - 2023-08-21 07:26:41 --> Helper loaded: file_helper
INFO - 2023-08-21 07:26:41 --> Helper loaded: html_helper
INFO - 2023-08-21 07:26:41 --> Helper loaded: text_helper
INFO - 2023-08-21 07:26:41 --> Helper loaded: form_helper
INFO - 2023-08-21 07:26:41 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:26:41 --> Helper loaded: security_helper
INFO - 2023-08-21 07:26:41 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:26:41 --> Database Driver Class Initialized
INFO - 2023-08-21 07:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:26:41 --> Parser Class Initialized
INFO - 2023-08-21 07:26:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:26:41 --> Pagination Class Initialized
INFO - 2023-08-21 07:26:41 --> Form Validation Class Initialized
INFO - 2023-08-21 07:26:41 --> Controller Class Initialized
INFO - 2023-08-21 07:26:41 --> Model Class Initialized
DEBUG - 2023-08-21 07:26:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:26:41 --> Model Class Initialized
DEBUG - 2023-08-21 07:26:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:26:41 --> Model Class Initialized
INFO - 2023-08-21 07:26:41 --> Model Class Initialized
INFO - 2023-08-21 07:26:41 --> Model Class Initialized
INFO - 2023-08-21 07:26:41 --> Model Class Initialized
DEBUG - 2023-08-21 07:26:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:26:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:26:41 --> Model Class Initialized
INFO - 2023-08-21 07:26:41 --> Model Class Initialized
INFO - 2023-08-21 07:26:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-21 07:26:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:26:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 07:26:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 07:26:41 --> Model Class Initialized
INFO - 2023-08-21 07:26:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 07:26:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 07:26:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 07:26:41 --> Final output sent to browser
DEBUG - 2023-08-21 07:26:41 --> Total execution time: 0.0949
ERROR - 2023-08-21 07:26:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:26:54 --> Config Class Initialized
INFO - 2023-08-21 07:26:54 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:26:54 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:26:54 --> Utf8 Class Initialized
INFO - 2023-08-21 07:26:54 --> URI Class Initialized
INFO - 2023-08-21 07:26:54 --> Router Class Initialized
INFO - 2023-08-21 07:26:54 --> Output Class Initialized
INFO - 2023-08-21 07:26:54 --> Security Class Initialized
DEBUG - 2023-08-21 07:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:26:54 --> Input Class Initialized
INFO - 2023-08-21 07:26:54 --> Language Class Initialized
INFO - 2023-08-21 07:26:54 --> Loader Class Initialized
INFO - 2023-08-21 07:26:54 --> Helper loaded: url_helper
INFO - 2023-08-21 07:26:54 --> Helper loaded: file_helper
INFO - 2023-08-21 07:26:54 --> Helper loaded: html_helper
INFO - 2023-08-21 07:26:54 --> Helper loaded: text_helper
INFO - 2023-08-21 07:26:54 --> Helper loaded: form_helper
INFO - 2023-08-21 07:26:54 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:26:54 --> Helper loaded: security_helper
INFO - 2023-08-21 07:26:54 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:26:54 --> Database Driver Class Initialized
INFO - 2023-08-21 07:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:26:54 --> Parser Class Initialized
INFO - 2023-08-21 07:26:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:26:54 --> Pagination Class Initialized
INFO - 2023-08-21 07:26:54 --> Form Validation Class Initialized
INFO - 2023-08-21 07:26:54 --> Controller Class Initialized
INFO - 2023-08-21 07:26:54 --> Model Class Initialized
DEBUG - 2023-08-21 07:26:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:26:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:26:54 --> Model Class Initialized
DEBUG - 2023-08-21 07:26:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:26:54 --> Model Class Initialized
INFO - 2023-08-21 07:26:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-21 07:26:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:26:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 07:26:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 07:26:54 --> Model Class Initialized
INFO - 2023-08-21 07:26:54 --> Model Class Initialized
INFO - 2023-08-21 07:26:54 --> Model Class Initialized
INFO - 2023-08-21 07:26:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 07:26:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 07:26:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 07:26:54 --> Final output sent to browser
DEBUG - 2023-08-21 07:26:54 --> Total execution time: 0.0775
ERROR - 2023-08-21 07:26:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:26:55 --> Config Class Initialized
INFO - 2023-08-21 07:26:55 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:26:55 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:26:55 --> Utf8 Class Initialized
INFO - 2023-08-21 07:26:55 --> URI Class Initialized
INFO - 2023-08-21 07:26:55 --> Router Class Initialized
INFO - 2023-08-21 07:26:55 --> Output Class Initialized
INFO - 2023-08-21 07:26:55 --> Security Class Initialized
DEBUG - 2023-08-21 07:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:26:55 --> Input Class Initialized
INFO - 2023-08-21 07:26:55 --> Language Class Initialized
INFO - 2023-08-21 07:26:55 --> Loader Class Initialized
INFO - 2023-08-21 07:26:55 --> Helper loaded: url_helper
INFO - 2023-08-21 07:26:55 --> Helper loaded: file_helper
INFO - 2023-08-21 07:26:55 --> Helper loaded: html_helper
INFO - 2023-08-21 07:26:55 --> Helper loaded: text_helper
INFO - 2023-08-21 07:26:55 --> Helper loaded: form_helper
INFO - 2023-08-21 07:26:55 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:26:55 --> Helper loaded: security_helper
INFO - 2023-08-21 07:26:55 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:26:55 --> Database Driver Class Initialized
INFO - 2023-08-21 07:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:26:55 --> Parser Class Initialized
INFO - 2023-08-21 07:26:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:26:55 --> Pagination Class Initialized
INFO - 2023-08-21 07:26:55 --> Form Validation Class Initialized
INFO - 2023-08-21 07:26:55 --> Controller Class Initialized
INFO - 2023-08-21 07:26:55 --> Model Class Initialized
DEBUG - 2023-08-21 07:26:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:26:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:26:55 --> Model Class Initialized
DEBUG - 2023-08-21 07:26:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:26:55 --> Model Class Initialized
INFO - 2023-08-21 07:26:55 --> Final output sent to browser
DEBUG - 2023-08-21 07:26:55 --> Total execution time: 0.0379
ERROR - 2023-08-21 07:27:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:27:11 --> Config Class Initialized
INFO - 2023-08-21 07:27:11 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:27:11 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:27:11 --> Utf8 Class Initialized
INFO - 2023-08-21 07:27:11 --> URI Class Initialized
INFO - 2023-08-21 07:27:11 --> Router Class Initialized
INFO - 2023-08-21 07:27:11 --> Output Class Initialized
INFO - 2023-08-21 07:27:11 --> Security Class Initialized
DEBUG - 2023-08-21 07:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:27:11 --> Input Class Initialized
INFO - 2023-08-21 07:27:11 --> Language Class Initialized
INFO - 2023-08-21 07:27:11 --> Loader Class Initialized
INFO - 2023-08-21 07:27:11 --> Helper loaded: url_helper
INFO - 2023-08-21 07:27:11 --> Helper loaded: file_helper
INFO - 2023-08-21 07:27:11 --> Helper loaded: html_helper
INFO - 2023-08-21 07:27:11 --> Helper loaded: text_helper
INFO - 2023-08-21 07:27:11 --> Helper loaded: form_helper
INFO - 2023-08-21 07:27:11 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:27:11 --> Helper loaded: security_helper
INFO - 2023-08-21 07:27:11 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:27:11 --> Database Driver Class Initialized
INFO - 2023-08-21 07:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:27:11 --> Parser Class Initialized
INFO - 2023-08-21 07:27:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:27:11 --> Pagination Class Initialized
INFO - 2023-08-21 07:27:11 --> Form Validation Class Initialized
INFO - 2023-08-21 07:27:11 --> Controller Class Initialized
INFO - 2023-08-21 07:27:11 --> Model Class Initialized
DEBUG - 2023-08-21 07:27:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:27:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:27:11 --> Model Class Initialized
DEBUG - 2023-08-21 07:27:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:27:11 --> Model Class Initialized
DEBUG - 2023-08-21 07:27:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:27:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-21 07:27:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:27:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 07:27:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 07:27:12 --> Model Class Initialized
INFO - 2023-08-21 07:27:12 --> Model Class Initialized
INFO - 2023-08-21 07:27:12 --> Model Class Initialized
INFO - 2023-08-21 07:27:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 07:27:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 07:27:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 07:27:12 --> Final output sent to browser
DEBUG - 2023-08-21 07:27:12 --> Total execution time: 0.0903
ERROR - 2023-08-21 07:27:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:27:30 --> Config Class Initialized
INFO - 2023-08-21 07:27:30 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:27:30 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:27:30 --> Utf8 Class Initialized
INFO - 2023-08-21 07:27:30 --> URI Class Initialized
INFO - 2023-08-21 07:27:30 --> Router Class Initialized
INFO - 2023-08-21 07:27:30 --> Output Class Initialized
INFO - 2023-08-21 07:27:30 --> Security Class Initialized
DEBUG - 2023-08-21 07:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:27:30 --> Input Class Initialized
INFO - 2023-08-21 07:27:30 --> Language Class Initialized
INFO - 2023-08-21 07:27:30 --> Loader Class Initialized
INFO - 2023-08-21 07:27:30 --> Helper loaded: url_helper
INFO - 2023-08-21 07:27:30 --> Helper loaded: file_helper
INFO - 2023-08-21 07:27:30 --> Helper loaded: html_helper
INFO - 2023-08-21 07:27:30 --> Helper loaded: text_helper
INFO - 2023-08-21 07:27:30 --> Helper loaded: form_helper
INFO - 2023-08-21 07:27:30 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:27:30 --> Helper loaded: security_helper
INFO - 2023-08-21 07:27:30 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:27:30 --> Database Driver Class Initialized
INFO - 2023-08-21 07:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:27:30 --> Parser Class Initialized
INFO - 2023-08-21 07:27:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:27:30 --> Pagination Class Initialized
INFO - 2023-08-21 07:27:30 --> Form Validation Class Initialized
INFO - 2023-08-21 07:27:30 --> Controller Class Initialized
INFO - 2023-08-21 07:27:30 --> Model Class Initialized
DEBUG - 2023-08-21 07:27:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:27:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:27:30 --> Model Class Initialized
DEBUG - 2023-08-21 07:27:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:27:30 --> Model Class Initialized
INFO - 2023-08-21 07:27:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-21 07:27:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:27:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 07:27:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 07:27:30 --> Model Class Initialized
INFO - 2023-08-21 07:27:30 --> Model Class Initialized
INFO - 2023-08-21 07:27:30 --> Model Class Initialized
INFO - 2023-08-21 07:27:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 07:27:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 07:27:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 07:27:30 --> Final output sent to browser
DEBUG - 2023-08-21 07:27:30 --> Total execution time: 0.0814
ERROR - 2023-08-21 07:27:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:27:30 --> Config Class Initialized
INFO - 2023-08-21 07:27:30 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:27:30 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:27:30 --> Utf8 Class Initialized
INFO - 2023-08-21 07:27:30 --> URI Class Initialized
INFO - 2023-08-21 07:27:30 --> Router Class Initialized
INFO - 2023-08-21 07:27:30 --> Output Class Initialized
INFO - 2023-08-21 07:27:30 --> Security Class Initialized
DEBUG - 2023-08-21 07:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:27:30 --> Input Class Initialized
INFO - 2023-08-21 07:27:30 --> Language Class Initialized
INFO - 2023-08-21 07:27:30 --> Loader Class Initialized
INFO - 2023-08-21 07:27:30 --> Helper loaded: url_helper
INFO - 2023-08-21 07:27:30 --> Helper loaded: file_helper
INFO - 2023-08-21 07:27:30 --> Helper loaded: html_helper
INFO - 2023-08-21 07:27:30 --> Helper loaded: text_helper
INFO - 2023-08-21 07:27:30 --> Helper loaded: form_helper
INFO - 2023-08-21 07:27:30 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:27:30 --> Helper loaded: security_helper
INFO - 2023-08-21 07:27:30 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:27:30 --> Database Driver Class Initialized
INFO - 2023-08-21 07:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:27:30 --> Parser Class Initialized
INFO - 2023-08-21 07:27:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:27:30 --> Pagination Class Initialized
INFO - 2023-08-21 07:27:30 --> Form Validation Class Initialized
INFO - 2023-08-21 07:27:30 --> Controller Class Initialized
INFO - 2023-08-21 07:27:30 --> Model Class Initialized
DEBUG - 2023-08-21 07:27:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:27:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:27:30 --> Model Class Initialized
DEBUG - 2023-08-21 07:27:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:27:30 --> Model Class Initialized
INFO - 2023-08-21 07:27:30 --> Final output sent to browser
DEBUG - 2023-08-21 07:27:30 --> Total execution time: 0.0450
ERROR - 2023-08-21 07:27:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:27:55 --> Config Class Initialized
INFO - 2023-08-21 07:27:55 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:27:55 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:27:55 --> Utf8 Class Initialized
INFO - 2023-08-21 07:27:55 --> URI Class Initialized
INFO - 2023-08-21 07:27:55 --> Router Class Initialized
INFO - 2023-08-21 07:27:55 --> Output Class Initialized
INFO - 2023-08-21 07:27:55 --> Security Class Initialized
DEBUG - 2023-08-21 07:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:27:55 --> Input Class Initialized
INFO - 2023-08-21 07:27:55 --> Language Class Initialized
INFO - 2023-08-21 07:27:55 --> Loader Class Initialized
INFO - 2023-08-21 07:27:55 --> Helper loaded: url_helper
INFO - 2023-08-21 07:27:55 --> Helper loaded: file_helper
INFO - 2023-08-21 07:27:55 --> Helper loaded: html_helper
INFO - 2023-08-21 07:27:55 --> Helper loaded: text_helper
INFO - 2023-08-21 07:27:55 --> Helper loaded: form_helper
INFO - 2023-08-21 07:27:55 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:27:55 --> Helper loaded: security_helper
INFO - 2023-08-21 07:27:55 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:27:55 --> Database Driver Class Initialized
INFO - 2023-08-21 07:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:27:55 --> Parser Class Initialized
INFO - 2023-08-21 07:27:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:27:55 --> Pagination Class Initialized
INFO - 2023-08-21 07:27:55 --> Form Validation Class Initialized
INFO - 2023-08-21 07:27:55 --> Controller Class Initialized
INFO - 2023-08-21 07:27:55 --> Model Class Initialized
DEBUG - 2023-08-21 07:27:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:27:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:27:55 --> Model Class Initialized
DEBUG - 2023-08-21 07:27:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:27:55 --> Model Class Initialized
DEBUG - 2023-08-21 07:27:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:27:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-21 07:27:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:27:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 07:27:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 07:27:55 --> Model Class Initialized
INFO - 2023-08-21 07:27:55 --> Model Class Initialized
INFO - 2023-08-21 07:27:55 --> Model Class Initialized
INFO - 2023-08-21 07:27:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 07:27:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 07:27:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 07:27:55 --> Final output sent to browser
DEBUG - 2023-08-21 07:27:55 --> Total execution time: 0.0867
ERROR - 2023-08-21 07:28:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:28:04 --> Config Class Initialized
INFO - 2023-08-21 07:28:04 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:28:04 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:28:04 --> Utf8 Class Initialized
INFO - 2023-08-21 07:28:04 --> URI Class Initialized
INFO - 2023-08-21 07:28:04 --> Router Class Initialized
INFO - 2023-08-21 07:28:04 --> Output Class Initialized
INFO - 2023-08-21 07:28:04 --> Security Class Initialized
DEBUG - 2023-08-21 07:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:28:04 --> Input Class Initialized
INFO - 2023-08-21 07:28:04 --> Language Class Initialized
INFO - 2023-08-21 07:28:04 --> Loader Class Initialized
INFO - 2023-08-21 07:28:04 --> Helper loaded: url_helper
INFO - 2023-08-21 07:28:04 --> Helper loaded: file_helper
INFO - 2023-08-21 07:28:04 --> Helper loaded: html_helper
INFO - 2023-08-21 07:28:04 --> Helper loaded: text_helper
INFO - 2023-08-21 07:28:04 --> Helper loaded: form_helper
INFO - 2023-08-21 07:28:04 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:28:04 --> Helper loaded: security_helper
INFO - 2023-08-21 07:28:04 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:28:04 --> Database Driver Class Initialized
INFO - 2023-08-21 07:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:28:04 --> Parser Class Initialized
INFO - 2023-08-21 07:28:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:28:04 --> Pagination Class Initialized
INFO - 2023-08-21 07:28:04 --> Form Validation Class Initialized
INFO - 2023-08-21 07:28:04 --> Controller Class Initialized
INFO - 2023-08-21 07:28:04 --> Model Class Initialized
DEBUG - 2023-08-21 07:28:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:28:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:28:04 --> Model Class Initialized
DEBUG - 2023-08-21 07:28:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:28:04 --> Model Class Initialized
DEBUG - 2023-08-21 07:28:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:28:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-21 07:28:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:28:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 07:28:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 07:28:04 --> Model Class Initialized
INFO - 2023-08-21 07:28:04 --> Model Class Initialized
INFO - 2023-08-21 07:28:04 --> Model Class Initialized
INFO - 2023-08-21 07:28:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 07:28:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 07:28:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 07:28:04 --> Final output sent to browser
DEBUG - 2023-08-21 07:28:04 --> Total execution time: 0.0890
ERROR - 2023-08-21 07:30:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:30:29 --> Config Class Initialized
INFO - 2023-08-21 07:30:29 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:30:29 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:30:29 --> Utf8 Class Initialized
INFO - 2023-08-21 07:30:29 --> URI Class Initialized
DEBUG - 2023-08-21 07:30:29 --> No URI present. Default controller set.
INFO - 2023-08-21 07:30:29 --> Router Class Initialized
INFO - 2023-08-21 07:30:29 --> Output Class Initialized
INFO - 2023-08-21 07:30:29 --> Security Class Initialized
DEBUG - 2023-08-21 07:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:30:29 --> Input Class Initialized
INFO - 2023-08-21 07:30:29 --> Language Class Initialized
INFO - 2023-08-21 07:30:29 --> Loader Class Initialized
INFO - 2023-08-21 07:30:29 --> Helper loaded: url_helper
INFO - 2023-08-21 07:30:29 --> Helper loaded: file_helper
INFO - 2023-08-21 07:30:29 --> Helper loaded: html_helper
INFO - 2023-08-21 07:30:29 --> Helper loaded: text_helper
INFO - 2023-08-21 07:30:29 --> Helper loaded: form_helper
INFO - 2023-08-21 07:30:29 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:30:29 --> Helper loaded: security_helper
INFO - 2023-08-21 07:30:29 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:30:29 --> Database Driver Class Initialized
INFO - 2023-08-21 07:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:30:29 --> Parser Class Initialized
INFO - 2023-08-21 07:30:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:30:29 --> Pagination Class Initialized
INFO - 2023-08-21 07:30:29 --> Form Validation Class Initialized
INFO - 2023-08-21 07:30:29 --> Controller Class Initialized
INFO - 2023-08-21 07:30:29 --> Model Class Initialized
DEBUG - 2023-08-21 07:30:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:30:29 --> Model Class Initialized
DEBUG - 2023-08-21 07:30:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:30:29 --> Model Class Initialized
INFO - 2023-08-21 07:30:29 --> Model Class Initialized
INFO - 2023-08-21 07:30:29 --> Model Class Initialized
INFO - 2023-08-21 07:30:29 --> Model Class Initialized
DEBUG - 2023-08-21 07:30:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:30:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:30:29 --> Model Class Initialized
INFO - 2023-08-21 07:30:29 --> Model Class Initialized
INFO - 2023-08-21 07:30:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-21 07:30:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:30:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 07:30:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 07:30:29 --> Model Class Initialized
INFO - 2023-08-21 07:30:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 07:30:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 07:30:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 07:30:29 --> Final output sent to browser
DEBUG - 2023-08-21 07:30:29 --> Total execution time: 0.0983
ERROR - 2023-08-21 07:31:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:31:00 --> Config Class Initialized
INFO - 2023-08-21 07:31:00 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:31:00 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:31:00 --> Utf8 Class Initialized
INFO - 2023-08-21 07:31:00 --> URI Class Initialized
INFO - 2023-08-21 07:31:00 --> Router Class Initialized
INFO - 2023-08-21 07:31:00 --> Output Class Initialized
INFO - 2023-08-21 07:31:00 --> Security Class Initialized
DEBUG - 2023-08-21 07:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:31:00 --> Input Class Initialized
INFO - 2023-08-21 07:31:00 --> Language Class Initialized
INFO - 2023-08-21 07:31:00 --> Loader Class Initialized
INFO - 2023-08-21 07:31:00 --> Helper loaded: url_helper
INFO - 2023-08-21 07:31:00 --> Helper loaded: file_helper
INFO - 2023-08-21 07:31:00 --> Helper loaded: html_helper
INFO - 2023-08-21 07:31:00 --> Helper loaded: text_helper
INFO - 2023-08-21 07:31:00 --> Helper loaded: form_helper
INFO - 2023-08-21 07:31:00 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:31:00 --> Helper loaded: security_helper
INFO - 2023-08-21 07:31:00 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:31:00 --> Database Driver Class Initialized
INFO - 2023-08-21 07:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:31:00 --> Parser Class Initialized
INFO - 2023-08-21 07:31:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:31:00 --> Pagination Class Initialized
INFO - 2023-08-21 07:31:00 --> Form Validation Class Initialized
INFO - 2023-08-21 07:31:00 --> Controller Class Initialized
INFO - 2023-08-21 07:31:00 --> Model Class Initialized
DEBUG - 2023-08-21 07:31:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:31:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:31:00 --> Model Class Initialized
DEBUG - 2023-08-21 07:31:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:31:00 --> Model Class Initialized
INFO - 2023-08-21 07:31:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-21 07:31:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:31:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 07:31:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 07:31:00 --> Model Class Initialized
INFO - 2023-08-21 07:31:00 --> Model Class Initialized
INFO - 2023-08-21 07:31:00 --> Model Class Initialized
INFO - 2023-08-21 07:31:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 07:31:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 07:31:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 07:31:00 --> Final output sent to browser
DEBUG - 2023-08-21 07:31:00 --> Total execution time: 0.1434
ERROR - 2023-08-21 07:31:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:31:01 --> Config Class Initialized
INFO - 2023-08-21 07:31:01 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:31:01 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:31:01 --> Utf8 Class Initialized
INFO - 2023-08-21 07:31:01 --> URI Class Initialized
INFO - 2023-08-21 07:31:01 --> Router Class Initialized
INFO - 2023-08-21 07:31:01 --> Output Class Initialized
INFO - 2023-08-21 07:31:01 --> Security Class Initialized
DEBUG - 2023-08-21 07:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:31:01 --> Input Class Initialized
INFO - 2023-08-21 07:31:01 --> Language Class Initialized
INFO - 2023-08-21 07:31:01 --> Loader Class Initialized
INFO - 2023-08-21 07:31:01 --> Helper loaded: url_helper
INFO - 2023-08-21 07:31:01 --> Helper loaded: file_helper
INFO - 2023-08-21 07:31:01 --> Helper loaded: html_helper
INFO - 2023-08-21 07:31:01 --> Helper loaded: text_helper
INFO - 2023-08-21 07:31:01 --> Helper loaded: form_helper
INFO - 2023-08-21 07:31:01 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:31:01 --> Helper loaded: security_helper
INFO - 2023-08-21 07:31:01 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:31:01 --> Database Driver Class Initialized
INFO - 2023-08-21 07:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:31:01 --> Parser Class Initialized
INFO - 2023-08-21 07:31:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:31:01 --> Pagination Class Initialized
INFO - 2023-08-21 07:31:01 --> Form Validation Class Initialized
INFO - 2023-08-21 07:31:01 --> Controller Class Initialized
INFO - 2023-08-21 07:31:01 --> Model Class Initialized
DEBUG - 2023-08-21 07:31:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:31:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:31:01 --> Model Class Initialized
DEBUG - 2023-08-21 07:31:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:31:01 --> Model Class Initialized
INFO - 2023-08-21 07:31:01 --> Final output sent to browser
DEBUG - 2023-08-21 07:31:01 --> Total execution time: 0.0555
ERROR - 2023-08-21 07:31:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:31:06 --> Config Class Initialized
INFO - 2023-08-21 07:31:06 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:31:06 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:31:06 --> Utf8 Class Initialized
INFO - 2023-08-21 07:31:06 --> URI Class Initialized
INFO - 2023-08-21 07:31:06 --> Router Class Initialized
INFO - 2023-08-21 07:31:06 --> Output Class Initialized
INFO - 2023-08-21 07:31:06 --> Security Class Initialized
DEBUG - 2023-08-21 07:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:31:06 --> Input Class Initialized
INFO - 2023-08-21 07:31:06 --> Language Class Initialized
INFO - 2023-08-21 07:31:06 --> Loader Class Initialized
INFO - 2023-08-21 07:31:06 --> Helper loaded: url_helper
INFO - 2023-08-21 07:31:06 --> Helper loaded: file_helper
INFO - 2023-08-21 07:31:06 --> Helper loaded: html_helper
INFO - 2023-08-21 07:31:06 --> Helper loaded: text_helper
INFO - 2023-08-21 07:31:06 --> Helper loaded: form_helper
INFO - 2023-08-21 07:31:06 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:31:06 --> Helper loaded: security_helper
INFO - 2023-08-21 07:31:06 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:31:06 --> Database Driver Class Initialized
INFO - 2023-08-21 07:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:31:06 --> Parser Class Initialized
INFO - 2023-08-21 07:31:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:31:06 --> Pagination Class Initialized
INFO - 2023-08-21 07:31:06 --> Form Validation Class Initialized
INFO - 2023-08-21 07:31:06 --> Controller Class Initialized
INFO - 2023-08-21 07:31:06 --> Model Class Initialized
DEBUG - 2023-08-21 07:31:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:31:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:31:06 --> Model Class Initialized
DEBUG - 2023-08-21 07:31:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:31:06 --> Model Class Initialized
INFO - 2023-08-21 07:31:07 --> Final output sent to browser
DEBUG - 2023-08-21 07:31:07 --> Total execution time: 0.5115
ERROR - 2023-08-21 07:31:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:31:14 --> Config Class Initialized
INFO - 2023-08-21 07:31:14 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:31:14 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:31:14 --> Utf8 Class Initialized
INFO - 2023-08-21 07:31:14 --> URI Class Initialized
DEBUG - 2023-08-21 07:31:14 --> No URI present. Default controller set.
INFO - 2023-08-21 07:31:14 --> Router Class Initialized
INFO - 2023-08-21 07:31:14 --> Output Class Initialized
INFO - 2023-08-21 07:31:14 --> Security Class Initialized
DEBUG - 2023-08-21 07:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:31:14 --> Input Class Initialized
INFO - 2023-08-21 07:31:14 --> Language Class Initialized
INFO - 2023-08-21 07:31:14 --> Loader Class Initialized
INFO - 2023-08-21 07:31:14 --> Helper loaded: url_helper
INFO - 2023-08-21 07:31:14 --> Helper loaded: file_helper
INFO - 2023-08-21 07:31:14 --> Helper loaded: html_helper
INFO - 2023-08-21 07:31:14 --> Helper loaded: text_helper
INFO - 2023-08-21 07:31:14 --> Helper loaded: form_helper
INFO - 2023-08-21 07:31:14 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:31:14 --> Helper loaded: security_helper
INFO - 2023-08-21 07:31:14 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:31:14 --> Database Driver Class Initialized
INFO - 2023-08-21 07:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:31:14 --> Parser Class Initialized
INFO - 2023-08-21 07:31:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:31:14 --> Pagination Class Initialized
INFO - 2023-08-21 07:31:14 --> Form Validation Class Initialized
INFO - 2023-08-21 07:31:14 --> Controller Class Initialized
INFO - 2023-08-21 07:31:14 --> Model Class Initialized
DEBUG - 2023-08-21 07:31:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:31:14 --> Model Class Initialized
DEBUG - 2023-08-21 07:31:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:31:14 --> Model Class Initialized
INFO - 2023-08-21 07:31:14 --> Model Class Initialized
INFO - 2023-08-21 07:31:14 --> Model Class Initialized
INFO - 2023-08-21 07:31:14 --> Model Class Initialized
DEBUG - 2023-08-21 07:31:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:31:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:31:14 --> Model Class Initialized
INFO - 2023-08-21 07:31:14 --> Model Class Initialized
INFO - 2023-08-21 07:31:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-21 07:31:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:31:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 07:31:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 07:31:14 --> Model Class Initialized
INFO - 2023-08-21 07:31:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 07:31:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 07:31:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 07:31:14 --> Final output sent to browser
DEBUG - 2023-08-21 07:31:14 --> Total execution time: 0.1826
ERROR - 2023-08-21 07:31:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:31:24 --> Config Class Initialized
INFO - 2023-08-21 07:31:24 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:31:24 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:31:24 --> Utf8 Class Initialized
INFO - 2023-08-21 07:31:24 --> URI Class Initialized
INFO - 2023-08-21 07:31:24 --> Router Class Initialized
INFO - 2023-08-21 07:31:24 --> Output Class Initialized
INFO - 2023-08-21 07:31:24 --> Security Class Initialized
DEBUG - 2023-08-21 07:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:31:24 --> Input Class Initialized
INFO - 2023-08-21 07:31:24 --> Language Class Initialized
INFO - 2023-08-21 07:31:24 --> Loader Class Initialized
INFO - 2023-08-21 07:31:24 --> Helper loaded: url_helper
INFO - 2023-08-21 07:31:24 --> Helper loaded: file_helper
INFO - 2023-08-21 07:31:24 --> Helper loaded: html_helper
INFO - 2023-08-21 07:31:24 --> Helper loaded: text_helper
INFO - 2023-08-21 07:31:24 --> Helper loaded: form_helper
INFO - 2023-08-21 07:31:24 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:31:24 --> Helper loaded: security_helper
INFO - 2023-08-21 07:31:24 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:31:24 --> Database Driver Class Initialized
INFO - 2023-08-21 07:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:31:24 --> Parser Class Initialized
INFO - 2023-08-21 07:31:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:31:24 --> Pagination Class Initialized
INFO - 2023-08-21 07:31:24 --> Form Validation Class Initialized
INFO - 2023-08-21 07:31:24 --> Controller Class Initialized
INFO - 2023-08-21 07:31:24 --> Model Class Initialized
DEBUG - 2023-08-21 07:31:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:31:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:31:24 --> Model Class Initialized
DEBUG - 2023-08-21 07:31:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:31:24 --> Model Class Initialized
INFO - 2023-08-21 07:31:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-21 07:31:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:31:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 07:31:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 07:31:24 --> Model Class Initialized
INFO - 2023-08-21 07:31:24 --> Model Class Initialized
INFO - 2023-08-21 07:31:24 --> Model Class Initialized
INFO - 2023-08-21 07:31:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 07:31:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 07:31:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 07:31:24 --> Final output sent to browser
DEBUG - 2023-08-21 07:31:24 --> Total execution time: 0.1449
ERROR - 2023-08-21 07:31:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:31:25 --> Config Class Initialized
INFO - 2023-08-21 07:31:25 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:31:25 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:31:25 --> Utf8 Class Initialized
INFO - 2023-08-21 07:31:25 --> URI Class Initialized
INFO - 2023-08-21 07:31:25 --> Router Class Initialized
INFO - 2023-08-21 07:31:25 --> Output Class Initialized
INFO - 2023-08-21 07:31:25 --> Security Class Initialized
DEBUG - 2023-08-21 07:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:31:25 --> Input Class Initialized
INFO - 2023-08-21 07:31:25 --> Language Class Initialized
INFO - 2023-08-21 07:31:25 --> Loader Class Initialized
INFO - 2023-08-21 07:31:25 --> Helper loaded: url_helper
INFO - 2023-08-21 07:31:25 --> Helper loaded: file_helper
INFO - 2023-08-21 07:31:25 --> Helper loaded: html_helper
INFO - 2023-08-21 07:31:25 --> Helper loaded: text_helper
INFO - 2023-08-21 07:31:25 --> Helper loaded: form_helper
INFO - 2023-08-21 07:31:25 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:31:25 --> Helper loaded: security_helper
INFO - 2023-08-21 07:31:25 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:31:25 --> Database Driver Class Initialized
INFO - 2023-08-21 07:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:31:25 --> Parser Class Initialized
INFO - 2023-08-21 07:31:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:31:25 --> Pagination Class Initialized
INFO - 2023-08-21 07:31:25 --> Form Validation Class Initialized
INFO - 2023-08-21 07:31:25 --> Controller Class Initialized
INFO - 2023-08-21 07:31:25 --> Model Class Initialized
DEBUG - 2023-08-21 07:31:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:31:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:31:25 --> Model Class Initialized
DEBUG - 2023-08-21 07:31:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:31:25 --> Model Class Initialized
INFO - 2023-08-21 07:31:25 --> Final output sent to browser
DEBUG - 2023-08-21 07:31:25 --> Total execution time: 0.0585
ERROR - 2023-08-21 07:32:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:32:15 --> Config Class Initialized
INFO - 2023-08-21 07:32:15 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:32:15 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:32:15 --> Utf8 Class Initialized
INFO - 2023-08-21 07:32:15 --> URI Class Initialized
DEBUG - 2023-08-21 07:32:15 --> No URI present. Default controller set.
INFO - 2023-08-21 07:32:15 --> Router Class Initialized
INFO - 2023-08-21 07:32:15 --> Output Class Initialized
INFO - 2023-08-21 07:32:15 --> Security Class Initialized
DEBUG - 2023-08-21 07:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:32:15 --> Input Class Initialized
INFO - 2023-08-21 07:32:15 --> Language Class Initialized
INFO - 2023-08-21 07:32:15 --> Loader Class Initialized
INFO - 2023-08-21 07:32:15 --> Helper loaded: url_helper
INFO - 2023-08-21 07:32:15 --> Helper loaded: file_helper
INFO - 2023-08-21 07:32:15 --> Helper loaded: html_helper
INFO - 2023-08-21 07:32:15 --> Helper loaded: text_helper
INFO - 2023-08-21 07:32:15 --> Helper loaded: form_helper
INFO - 2023-08-21 07:32:15 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:32:15 --> Helper loaded: security_helper
INFO - 2023-08-21 07:32:15 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:32:15 --> Database Driver Class Initialized
INFO - 2023-08-21 07:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:32:15 --> Parser Class Initialized
INFO - 2023-08-21 07:32:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:32:15 --> Pagination Class Initialized
INFO - 2023-08-21 07:32:15 --> Form Validation Class Initialized
INFO - 2023-08-21 07:32:15 --> Controller Class Initialized
INFO - 2023-08-21 07:32:15 --> Model Class Initialized
DEBUG - 2023-08-21 07:32:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:32:15 --> Model Class Initialized
DEBUG - 2023-08-21 07:32:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:32:15 --> Model Class Initialized
INFO - 2023-08-21 07:32:15 --> Model Class Initialized
INFO - 2023-08-21 07:32:15 --> Model Class Initialized
INFO - 2023-08-21 07:32:15 --> Model Class Initialized
DEBUG - 2023-08-21 07:32:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:32:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:32:15 --> Model Class Initialized
INFO - 2023-08-21 07:32:15 --> Model Class Initialized
INFO - 2023-08-21 07:32:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-21 07:32:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:32:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 07:32:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 07:32:15 --> Model Class Initialized
INFO - 2023-08-21 07:32:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 07:32:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 07:32:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 07:32:15 --> Final output sent to browser
DEBUG - 2023-08-21 07:32:15 --> Total execution time: 0.1891
ERROR - 2023-08-21 07:35:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:35:41 --> Config Class Initialized
INFO - 2023-08-21 07:35:41 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:35:41 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:35:41 --> Utf8 Class Initialized
INFO - 2023-08-21 07:35:41 --> URI Class Initialized
DEBUG - 2023-08-21 07:35:41 --> No URI present. Default controller set.
INFO - 2023-08-21 07:35:41 --> Router Class Initialized
INFO - 2023-08-21 07:35:41 --> Output Class Initialized
INFO - 2023-08-21 07:35:41 --> Security Class Initialized
DEBUG - 2023-08-21 07:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:35:41 --> Input Class Initialized
INFO - 2023-08-21 07:35:41 --> Language Class Initialized
INFO - 2023-08-21 07:35:41 --> Loader Class Initialized
INFO - 2023-08-21 07:35:41 --> Helper loaded: url_helper
INFO - 2023-08-21 07:35:41 --> Helper loaded: file_helper
INFO - 2023-08-21 07:35:41 --> Helper loaded: html_helper
INFO - 2023-08-21 07:35:41 --> Helper loaded: text_helper
INFO - 2023-08-21 07:35:41 --> Helper loaded: form_helper
INFO - 2023-08-21 07:35:41 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:35:41 --> Helper loaded: security_helper
INFO - 2023-08-21 07:35:41 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:35:41 --> Database Driver Class Initialized
INFO - 2023-08-21 07:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:35:41 --> Parser Class Initialized
INFO - 2023-08-21 07:35:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:35:41 --> Pagination Class Initialized
INFO - 2023-08-21 07:35:41 --> Form Validation Class Initialized
INFO - 2023-08-21 07:35:41 --> Controller Class Initialized
INFO - 2023-08-21 07:35:41 --> Model Class Initialized
DEBUG - 2023-08-21 07:35:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:35:41 --> Model Class Initialized
DEBUG - 2023-08-21 07:35:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:35:41 --> Model Class Initialized
INFO - 2023-08-21 07:35:41 --> Model Class Initialized
INFO - 2023-08-21 07:35:41 --> Model Class Initialized
INFO - 2023-08-21 07:35:41 --> Model Class Initialized
DEBUG - 2023-08-21 07:35:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:35:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:35:41 --> Model Class Initialized
INFO - 2023-08-21 07:35:41 --> Model Class Initialized
INFO - 2023-08-21 07:35:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-21 07:35:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:35:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 07:35:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 07:35:41 --> Model Class Initialized
INFO - 2023-08-21 07:35:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 07:35:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 07:35:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 07:35:41 --> Final output sent to browser
DEBUG - 2023-08-21 07:35:41 --> Total execution time: 0.0946
ERROR - 2023-08-21 07:35:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:35:45 --> Config Class Initialized
INFO - 2023-08-21 07:35:45 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:35:45 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:35:45 --> Utf8 Class Initialized
INFO - 2023-08-21 07:35:45 --> URI Class Initialized
INFO - 2023-08-21 07:35:45 --> Router Class Initialized
INFO - 2023-08-21 07:35:45 --> Output Class Initialized
INFO - 2023-08-21 07:35:45 --> Security Class Initialized
DEBUG - 2023-08-21 07:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:35:45 --> Input Class Initialized
INFO - 2023-08-21 07:35:45 --> Language Class Initialized
INFO - 2023-08-21 07:35:45 --> Loader Class Initialized
INFO - 2023-08-21 07:35:45 --> Helper loaded: url_helper
INFO - 2023-08-21 07:35:45 --> Helper loaded: file_helper
INFO - 2023-08-21 07:35:45 --> Helper loaded: html_helper
INFO - 2023-08-21 07:35:45 --> Helper loaded: text_helper
INFO - 2023-08-21 07:35:45 --> Helper loaded: form_helper
INFO - 2023-08-21 07:35:45 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:35:45 --> Helper loaded: security_helper
INFO - 2023-08-21 07:35:45 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:35:45 --> Database Driver Class Initialized
INFO - 2023-08-21 07:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:35:45 --> Parser Class Initialized
INFO - 2023-08-21 07:35:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:35:45 --> Pagination Class Initialized
INFO - 2023-08-21 07:35:45 --> Form Validation Class Initialized
INFO - 2023-08-21 07:35:45 --> Controller Class Initialized
INFO - 2023-08-21 07:35:45 --> Model Class Initialized
DEBUG - 2023-08-21 07:35:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:35:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:35:45 --> Model Class Initialized
DEBUG - 2023-08-21 07:35:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:35:45 --> Model Class Initialized
INFO - 2023-08-21 07:35:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-21 07:35:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:35:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 07:35:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 07:35:45 --> Model Class Initialized
INFO - 2023-08-21 07:35:45 --> Model Class Initialized
INFO - 2023-08-21 07:35:45 --> Model Class Initialized
INFO - 2023-08-21 07:35:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 07:35:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 07:35:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 07:35:45 --> Final output sent to browser
DEBUG - 2023-08-21 07:35:45 --> Total execution time: 0.0777
ERROR - 2023-08-21 07:35:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:35:45 --> Config Class Initialized
INFO - 2023-08-21 07:35:45 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:35:45 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:35:45 --> Utf8 Class Initialized
INFO - 2023-08-21 07:35:45 --> URI Class Initialized
INFO - 2023-08-21 07:35:45 --> Router Class Initialized
INFO - 2023-08-21 07:35:45 --> Output Class Initialized
INFO - 2023-08-21 07:35:45 --> Security Class Initialized
DEBUG - 2023-08-21 07:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:35:45 --> Input Class Initialized
INFO - 2023-08-21 07:35:45 --> Language Class Initialized
INFO - 2023-08-21 07:35:45 --> Loader Class Initialized
INFO - 2023-08-21 07:35:45 --> Helper loaded: url_helper
INFO - 2023-08-21 07:35:45 --> Helper loaded: file_helper
INFO - 2023-08-21 07:35:45 --> Helper loaded: html_helper
INFO - 2023-08-21 07:35:45 --> Helper loaded: text_helper
INFO - 2023-08-21 07:35:45 --> Helper loaded: form_helper
INFO - 2023-08-21 07:35:45 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:35:45 --> Helper loaded: security_helper
INFO - 2023-08-21 07:35:45 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:35:45 --> Database Driver Class Initialized
INFO - 2023-08-21 07:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:35:45 --> Parser Class Initialized
INFO - 2023-08-21 07:35:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:35:45 --> Pagination Class Initialized
INFO - 2023-08-21 07:35:45 --> Form Validation Class Initialized
INFO - 2023-08-21 07:35:45 --> Controller Class Initialized
INFO - 2023-08-21 07:35:45 --> Model Class Initialized
DEBUG - 2023-08-21 07:35:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:35:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:35:45 --> Model Class Initialized
DEBUG - 2023-08-21 07:35:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:35:45 --> Model Class Initialized
INFO - 2023-08-21 07:35:45 --> Final output sent to browser
DEBUG - 2023-08-21 07:35:45 --> Total execution time: 0.0371
ERROR - 2023-08-21 07:35:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:35:50 --> Config Class Initialized
INFO - 2023-08-21 07:35:50 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:35:50 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:35:50 --> Utf8 Class Initialized
INFO - 2023-08-21 07:35:50 --> URI Class Initialized
INFO - 2023-08-21 07:35:50 --> Router Class Initialized
INFO - 2023-08-21 07:35:50 --> Output Class Initialized
INFO - 2023-08-21 07:35:50 --> Security Class Initialized
DEBUG - 2023-08-21 07:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:35:50 --> Input Class Initialized
INFO - 2023-08-21 07:35:50 --> Language Class Initialized
INFO - 2023-08-21 07:35:50 --> Loader Class Initialized
INFO - 2023-08-21 07:35:50 --> Helper loaded: url_helper
INFO - 2023-08-21 07:35:50 --> Helper loaded: file_helper
INFO - 2023-08-21 07:35:50 --> Helper loaded: html_helper
INFO - 2023-08-21 07:35:50 --> Helper loaded: text_helper
INFO - 2023-08-21 07:35:50 --> Helper loaded: form_helper
INFO - 2023-08-21 07:35:50 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:35:50 --> Helper loaded: security_helper
INFO - 2023-08-21 07:35:50 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:35:50 --> Database Driver Class Initialized
INFO - 2023-08-21 07:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:35:50 --> Parser Class Initialized
INFO - 2023-08-21 07:35:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:35:50 --> Pagination Class Initialized
INFO - 2023-08-21 07:35:50 --> Form Validation Class Initialized
INFO - 2023-08-21 07:35:50 --> Controller Class Initialized
INFO - 2023-08-21 07:35:50 --> Model Class Initialized
DEBUG - 2023-08-21 07:35:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:35:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:35:50 --> Model Class Initialized
DEBUG - 2023-08-21 07:35:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:35:50 --> Model Class Initialized
INFO - 2023-08-21 07:35:50 --> Final output sent to browser
DEBUG - 2023-08-21 07:35:50 --> Total execution time: 0.0393
ERROR - 2023-08-21 07:35:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:35:51 --> Config Class Initialized
INFO - 2023-08-21 07:35:51 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:35:51 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:35:51 --> Utf8 Class Initialized
INFO - 2023-08-21 07:35:51 --> URI Class Initialized
INFO - 2023-08-21 07:35:51 --> Router Class Initialized
INFO - 2023-08-21 07:35:51 --> Output Class Initialized
INFO - 2023-08-21 07:35:51 --> Security Class Initialized
DEBUG - 2023-08-21 07:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:35:51 --> Input Class Initialized
INFO - 2023-08-21 07:35:51 --> Language Class Initialized
INFO - 2023-08-21 07:35:51 --> Loader Class Initialized
INFO - 2023-08-21 07:35:51 --> Helper loaded: url_helper
INFO - 2023-08-21 07:35:51 --> Helper loaded: file_helper
INFO - 2023-08-21 07:35:51 --> Helper loaded: html_helper
INFO - 2023-08-21 07:35:51 --> Helper loaded: text_helper
INFO - 2023-08-21 07:35:51 --> Helper loaded: form_helper
INFO - 2023-08-21 07:35:51 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:35:51 --> Helper loaded: security_helper
INFO - 2023-08-21 07:35:51 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:35:51 --> Database Driver Class Initialized
INFO - 2023-08-21 07:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:35:51 --> Parser Class Initialized
INFO - 2023-08-21 07:35:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:35:51 --> Pagination Class Initialized
INFO - 2023-08-21 07:35:51 --> Form Validation Class Initialized
INFO - 2023-08-21 07:35:51 --> Controller Class Initialized
INFO - 2023-08-21 07:35:51 --> Model Class Initialized
DEBUG - 2023-08-21 07:35:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:35:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:35:51 --> Model Class Initialized
DEBUG - 2023-08-21 07:35:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:35:51 --> Model Class Initialized
INFO - 2023-08-21 07:35:51 --> Final output sent to browser
DEBUG - 2023-08-21 07:35:51 --> Total execution time: 0.0371
ERROR - 2023-08-21 07:35:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:35:55 --> Config Class Initialized
INFO - 2023-08-21 07:35:55 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:35:55 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:35:55 --> Utf8 Class Initialized
INFO - 2023-08-21 07:35:55 --> URI Class Initialized
INFO - 2023-08-21 07:35:55 --> Router Class Initialized
INFO - 2023-08-21 07:35:56 --> Output Class Initialized
INFO - 2023-08-21 07:35:56 --> Security Class Initialized
DEBUG - 2023-08-21 07:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:35:56 --> Input Class Initialized
INFO - 2023-08-21 07:35:56 --> Language Class Initialized
INFO - 2023-08-21 07:35:56 --> Loader Class Initialized
INFO - 2023-08-21 07:35:56 --> Helper loaded: url_helper
INFO - 2023-08-21 07:35:56 --> Helper loaded: file_helper
INFO - 2023-08-21 07:35:56 --> Helper loaded: html_helper
INFO - 2023-08-21 07:35:56 --> Helper loaded: text_helper
INFO - 2023-08-21 07:35:56 --> Helper loaded: form_helper
INFO - 2023-08-21 07:35:56 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:35:56 --> Helper loaded: security_helper
INFO - 2023-08-21 07:35:56 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:35:56 --> Database Driver Class Initialized
INFO - 2023-08-21 07:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:35:56 --> Parser Class Initialized
INFO - 2023-08-21 07:35:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:35:56 --> Pagination Class Initialized
INFO - 2023-08-21 07:35:56 --> Form Validation Class Initialized
INFO - 2023-08-21 07:35:56 --> Controller Class Initialized
INFO - 2023-08-21 07:35:56 --> Model Class Initialized
DEBUG - 2023-08-21 07:35:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:35:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:35:56 --> Model Class Initialized
DEBUG - 2023-08-21 07:35:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:35:56 --> Model Class Initialized
INFO - 2023-08-21 07:35:56 --> Final output sent to browser
DEBUG - 2023-08-21 07:35:56 --> Total execution time: 0.0272
ERROR - 2023-08-21 07:35:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:35:56 --> Config Class Initialized
INFO - 2023-08-21 07:35:56 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:35:56 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:35:56 --> Utf8 Class Initialized
INFO - 2023-08-21 07:35:56 --> URI Class Initialized
INFO - 2023-08-21 07:35:56 --> Router Class Initialized
INFO - 2023-08-21 07:35:56 --> Output Class Initialized
INFO - 2023-08-21 07:35:56 --> Security Class Initialized
DEBUG - 2023-08-21 07:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:35:56 --> Input Class Initialized
INFO - 2023-08-21 07:35:56 --> Language Class Initialized
INFO - 2023-08-21 07:35:56 --> Loader Class Initialized
INFO - 2023-08-21 07:35:56 --> Helper loaded: url_helper
INFO - 2023-08-21 07:35:56 --> Helper loaded: file_helper
INFO - 2023-08-21 07:35:56 --> Helper loaded: html_helper
INFO - 2023-08-21 07:35:56 --> Helper loaded: text_helper
INFO - 2023-08-21 07:35:56 --> Helper loaded: form_helper
INFO - 2023-08-21 07:35:56 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:35:56 --> Helper loaded: security_helper
INFO - 2023-08-21 07:35:56 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:35:56 --> Database Driver Class Initialized
INFO - 2023-08-21 07:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:35:56 --> Parser Class Initialized
INFO - 2023-08-21 07:35:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:35:56 --> Pagination Class Initialized
INFO - 2023-08-21 07:35:56 --> Form Validation Class Initialized
INFO - 2023-08-21 07:35:56 --> Controller Class Initialized
INFO - 2023-08-21 07:35:56 --> Model Class Initialized
DEBUG - 2023-08-21 07:35:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:35:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:35:56 --> Model Class Initialized
DEBUG - 2023-08-21 07:35:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:35:56 --> Model Class Initialized
INFO - 2023-08-21 07:35:56 --> Final output sent to browser
DEBUG - 2023-08-21 07:35:56 --> Total execution time: 0.0298
ERROR - 2023-08-21 07:35:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:35:56 --> Config Class Initialized
INFO - 2023-08-21 07:35:56 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:35:56 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:35:56 --> Utf8 Class Initialized
INFO - 2023-08-21 07:35:56 --> URI Class Initialized
INFO - 2023-08-21 07:35:56 --> Router Class Initialized
INFO - 2023-08-21 07:35:56 --> Output Class Initialized
INFO - 2023-08-21 07:35:56 --> Security Class Initialized
DEBUG - 2023-08-21 07:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:35:56 --> Input Class Initialized
INFO - 2023-08-21 07:35:56 --> Language Class Initialized
INFO - 2023-08-21 07:35:56 --> Loader Class Initialized
INFO - 2023-08-21 07:35:56 --> Helper loaded: url_helper
INFO - 2023-08-21 07:35:56 --> Helper loaded: file_helper
INFO - 2023-08-21 07:35:56 --> Helper loaded: html_helper
INFO - 2023-08-21 07:35:56 --> Helper loaded: text_helper
INFO - 2023-08-21 07:35:56 --> Helper loaded: form_helper
INFO - 2023-08-21 07:35:56 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:35:56 --> Helper loaded: security_helper
INFO - 2023-08-21 07:35:56 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:35:56 --> Database Driver Class Initialized
INFO - 2023-08-21 07:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:35:56 --> Parser Class Initialized
INFO - 2023-08-21 07:35:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:35:56 --> Pagination Class Initialized
INFO - 2023-08-21 07:35:56 --> Form Validation Class Initialized
INFO - 2023-08-21 07:35:56 --> Controller Class Initialized
INFO - 2023-08-21 07:35:56 --> Model Class Initialized
DEBUG - 2023-08-21 07:35:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:35:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:35:57 --> Model Class Initialized
DEBUG - 2023-08-21 07:35:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:35:57 --> Model Class Initialized
INFO - 2023-08-21 07:35:57 --> Final output sent to browser
DEBUG - 2023-08-21 07:35:57 --> Total execution time: 0.0270
ERROR - 2023-08-21 07:36:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:36:02 --> Config Class Initialized
INFO - 2023-08-21 07:36:02 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:36:02 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:36:02 --> Utf8 Class Initialized
INFO - 2023-08-21 07:36:02 --> URI Class Initialized
INFO - 2023-08-21 07:36:02 --> Router Class Initialized
INFO - 2023-08-21 07:36:02 --> Output Class Initialized
INFO - 2023-08-21 07:36:02 --> Security Class Initialized
DEBUG - 2023-08-21 07:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:36:02 --> Input Class Initialized
INFO - 2023-08-21 07:36:02 --> Language Class Initialized
INFO - 2023-08-21 07:36:02 --> Loader Class Initialized
INFO - 2023-08-21 07:36:02 --> Helper loaded: url_helper
INFO - 2023-08-21 07:36:02 --> Helper loaded: file_helper
INFO - 2023-08-21 07:36:02 --> Helper loaded: html_helper
INFO - 2023-08-21 07:36:02 --> Helper loaded: text_helper
INFO - 2023-08-21 07:36:02 --> Helper loaded: form_helper
INFO - 2023-08-21 07:36:02 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:36:02 --> Helper loaded: security_helper
INFO - 2023-08-21 07:36:02 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:36:02 --> Database Driver Class Initialized
INFO - 2023-08-21 07:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:36:02 --> Parser Class Initialized
INFO - 2023-08-21 07:36:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:36:02 --> Pagination Class Initialized
INFO - 2023-08-21 07:36:02 --> Form Validation Class Initialized
INFO - 2023-08-21 07:36:02 --> Controller Class Initialized
INFO - 2023-08-21 07:36:02 --> Model Class Initialized
DEBUG - 2023-08-21 07:36:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:36:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:36:02 --> Model Class Initialized
DEBUG - 2023-08-21 07:36:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:36:02 --> Model Class Initialized
INFO - 2023-08-21 07:36:02 --> Final output sent to browser
DEBUG - 2023-08-21 07:36:02 --> Total execution time: 0.0266
ERROR - 2023-08-21 07:36:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:36:03 --> Config Class Initialized
INFO - 2023-08-21 07:36:03 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:36:03 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:36:03 --> Utf8 Class Initialized
INFO - 2023-08-21 07:36:03 --> URI Class Initialized
INFO - 2023-08-21 07:36:03 --> Router Class Initialized
INFO - 2023-08-21 07:36:03 --> Output Class Initialized
INFO - 2023-08-21 07:36:03 --> Security Class Initialized
DEBUG - 2023-08-21 07:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:36:03 --> Input Class Initialized
INFO - 2023-08-21 07:36:03 --> Language Class Initialized
INFO - 2023-08-21 07:36:03 --> Loader Class Initialized
INFO - 2023-08-21 07:36:03 --> Helper loaded: url_helper
INFO - 2023-08-21 07:36:03 --> Helper loaded: file_helper
INFO - 2023-08-21 07:36:03 --> Helper loaded: html_helper
INFO - 2023-08-21 07:36:03 --> Helper loaded: text_helper
INFO - 2023-08-21 07:36:03 --> Helper loaded: form_helper
INFO - 2023-08-21 07:36:03 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:36:03 --> Helper loaded: security_helper
INFO - 2023-08-21 07:36:03 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:36:03 --> Database Driver Class Initialized
INFO - 2023-08-21 07:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:36:03 --> Parser Class Initialized
INFO - 2023-08-21 07:36:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:36:03 --> Pagination Class Initialized
INFO - 2023-08-21 07:36:03 --> Form Validation Class Initialized
INFO - 2023-08-21 07:36:03 --> Controller Class Initialized
INFO - 2023-08-21 07:36:03 --> Model Class Initialized
DEBUG - 2023-08-21 07:36:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:36:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:36:03 --> Model Class Initialized
DEBUG - 2023-08-21 07:36:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:36:03 --> Model Class Initialized
DEBUG - 2023-08-21 07:36:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:36:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-21 07:36:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:36:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 07:36:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 07:36:03 --> Model Class Initialized
INFO - 2023-08-21 07:36:03 --> Model Class Initialized
INFO - 2023-08-21 07:36:03 --> Model Class Initialized
INFO - 2023-08-21 07:36:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 07:36:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 07:36:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 07:36:03 --> Final output sent to browser
DEBUG - 2023-08-21 07:36:03 --> Total execution time: 0.0875
ERROR - 2023-08-21 07:37:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:37:58 --> Config Class Initialized
INFO - 2023-08-21 07:37:58 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:37:58 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:37:58 --> Utf8 Class Initialized
INFO - 2023-08-21 07:37:58 --> URI Class Initialized
INFO - 2023-08-21 07:37:58 --> Router Class Initialized
INFO - 2023-08-21 07:37:58 --> Output Class Initialized
INFO - 2023-08-21 07:37:58 --> Security Class Initialized
DEBUG - 2023-08-21 07:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:37:58 --> Input Class Initialized
INFO - 2023-08-21 07:37:58 --> Language Class Initialized
INFO - 2023-08-21 07:37:58 --> Loader Class Initialized
INFO - 2023-08-21 07:37:58 --> Helper loaded: url_helper
INFO - 2023-08-21 07:37:58 --> Helper loaded: file_helper
INFO - 2023-08-21 07:37:58 --> Helper loaded: html_helper
INFO - 2023-08-21 07:37:58 --> Helper loaded: text_helper
INFO - 2023-08-21 07:37:58 --> Helper loaded: form_helper
INFO - 2023-08-21 07:37:58 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:37:58 --> Helper loaded: security_helper
INFO - 2023-08-21 07:37:58 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:37:58 --> Database Driver Class Initialized
INFO - 2023-08-21 07:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:37:58 --> Parser Class Initialized
INFO - 2023-08-21 07:37:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:37:58 --> Pagination Class Initialized
INFO - 2023-08-21 07:37:58 --> Form Validation Class Initialized
INFO - 2023-08-21 07:37:58 --> Controller Class Initialized
INFO - 2023-08-21 07:37:58 --> Model Class Initialized
DEBUG - 2023-08-21 07:37:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:37:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:37:58 --> Model Class Initialized
DEBUG - 2023-08-21 07:37:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:37:58 --> Model Class Initialized
INFO - 2023-08-21 07:37:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-21 07:37:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:37:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 07:37:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 07:37:58 --> Model Class Initialized
INFO - 2023-08-21 07:37:58 --> Model Class Initialized
INFO - 2023-08-21 07:37:58 --> Model Class Initialized
INFO - 2023-08-21 07:37:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 07:37:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 07:37:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 07:37:58 --> Final output sent to browser
DEBUG - 2023-08-21 07:37:58 --> Total execution time: 0.0766
ERROR - 2023-08-21 07:37:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:37:59 --> Config Class Initialized
INFO - 2023-08-21 07:37:59 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:37:59 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:37:59 --> Utf8 Class Initialized
INFO - 2023-08-21 07:37:59 --> URI Class Initialized
INFO - 2023-08-21 07:37:59 --> Router Class Initialized
INFO - 2023-08-21 07:37:59 --> Output Class Initialized
INFO - 2023-08-21 07:37:59 --> Security Class Initialized
DEBUG - 2023-08-21 07:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:37:59 --> Input Class Initialized
INFO - 2023-08-21 07:37:59 --> Language Class Initialized
INFO - 2023-08-21 07:37:59 --> Loader Class Initialized
INFO - 2023-08-21 07:37:59 --> Helper loaded: url_helper
INFO - 2023-08-21 07:37:59 --> Helper loaded: file_helper
INFO - 2023-08-21 07:37:59 --> Helper loaded: html_helper
INFO - 2023-08-21 07:37:59 --> Helper loaded: text_helper
INFO - 2023-08-21 07:37:59 --> Helper loaded: form_helper
INFO - 2023-08-21 07:37:59 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:37:59 --> Helper loaded: security_helper
INFO - 2023-08-21 07:37:59 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:37:59 --> Database Driver Class Initialized
INFO - 2023-08-21 07:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:37:59 --> Parser Class Initialized
INFO - 2023-08-21 07:37:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:37:59 --> Pagination Class Initialized
INFO - 2023-08-21 07:37:59 --> Form Validation Class Initialized
INFO - 2023-08-21 07:37:59 --> Controller Class Initialized
INFO - 2023-08-21 07:37:59 --> Model Class Initialized
DEBUG - 2023-08-21 07:37:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:37:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:37:59 --> Model Class Initialized
DEBUG - 2023-08-21 07:37:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:37:59 --> Model Class Initialized
INFO - 2023-08-21 07:37:59 --> Final output sent to browser
DEBUG - 2023-08-21 07:37:59 --> Total execution time: 0.0387
ERROR - 2023-08-21 07:38:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:38:02 --> Config Class Initialized
INFO - 2023-08-21 07:38:02 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:38:02 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:38:02 --> Utf8 Class Initialized
INFO - 2023-08-21 07:38:02 --> URI Class Initialized
INFO - 2023-08-21 07:38:02 --> Router Class Initialized
INFO - 2023-08-21 07:38:02 --> Output Class Initialized
INFO - 2023-08-21 07:38:02 --> Security Class Initialized
DEBUG - 2023-08-21 07:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:38:02 --> Input Class Initialized
INFO - 2023-08-21 07:38:02 --> Language Class Initialized
INFO - 2023-08-21 07:38:02 --> Loader Class Initialized
INFO - 2023-08-21 07:38:02 --> Helper loaded: url_helper
INFO - 2023-08-21 07:38:02 --> Helper loaded: file_helper
INFO - 2023-08-21 07:38:02 --> Helper loaded: html_helper
INFO - 2023-08-21 07:38:02 --> Helper loaded: text_helper
INFO - 2023-08-21 07:38:02 --> Helper loaded: form_helper
INFO - 2023-08-21 07:38:02 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:38:02 --> Helper loaded: security_helper
INFO - 2023-08-21 07:38:02 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:38:02 --> Database Driver Class Initialized
INFO - 2023-08-21 07:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:38:02 --> Parser Class Initialized
INFO - 2023-08-21 07:38:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:38:02 --> Pagination Class Initialized
INFO - 2023-08-21 07:38:02 --> Form Validation Class Initialized
INFO - 2023-08-21 07:38:02 --> Controller Class Initialized
INFO - 2023-08-21 07:38:02 --> Model Class Initialized
DEBUG - 2023-08-21 07:38:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:38:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:38:02 --> Model Class Initialized
DEBUG - 2023-08-21 07:38:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:38:02 --> Model Class Initialized
INFO - 2023-08-21 07:38:02 --> Final output sent to browser
DEBUG - 2023-08-21 07:38:02 --> Total execution time: 0.0408
ERROR - 2023-08-21 07:38:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:38:03 --> Config Class Initialized
INFO - 2023-08-21 07:38:03 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:38:03 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:38:03 --> Utf8 Class Initialized
INFO - 2023-08-21 07:38:03 --> URI Class Initialized
INFO - 2023-08-21 07:38:03 --> Router Class Initialized
INFO - 2023-08-21 07:38:03 --> Output Class Initialized
INFO - 2023-08-21 07:38:03 --> Security Class Initialized
DEBUG - 2023-08-21 07:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:38:03 --> Input Class Initialized
INFO - 2023-08-21 07:38:03 --> Language Class Initialized
INFO - 2023-08-21 07:38:03 --> Loader Class Initialized
INFO - 2023-08-21 07:38:03 --> Helper loaded: url_helper
INFO - 2023-08-21 07:38:03 --> Helper loaded: file_helper
INFO - 2023-08-21 07:38:03 --> Helper loaded: html_helper
INFO - 2023-08-21 07:38:03 --> Helper loaded: text_helper
INFO - 2023-08-21 07:38:03 --> Helper loaded: form_helper
INFO - 2023-08-21 07:38:03 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:38:03 --> Helper loaded: security_helper
INFO - 2023-08-21 07:38:03 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:38:03 --> Database Driver Class Initialized
INFO - 2023-08-21 07:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:38:03 --> Parser Class Initialized
INFO - 2023-08-21 07:38:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:38:03 --> Pagination Class Initialized
INFO - 2023-08-21 07:38:03 --> Form Validation Class Initialized
INFO - 2023-08-21 07:38:03 --> Controller Class Initialized
INFO - 2023-08-21 07:38:03 --> Model Class Initialized
DEBUG - 2023-08-21 07:38:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:38:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:38:03 --> Model Class Initialized
DEBUG - 2023-08-21 07:38:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:38:03 --> Model Class Initialized
INFO - 2023-08-21 07:38:03 --> Final output sent to browser
DEBUG - 2023-08-21 07:38:03 --> Total execution time: 0.0351
ERROR - 2023-08-21 07:38:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:38:03 --> Config Class Initialized
INFO - 2023-08-21 07:38:03 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:38:03 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:38:03 --> Utf8 Class Initialized
INFO - 2023-08-21 07:38:03 --> URI Class Initialized
INFO - 2023-08-21 07:38:03 --> Router Class Initialized
INFO - 2023-08-21 07:38:03 --> Output Class Initialized
INFO - 2023-08-21 07:38:03 --> Security Class Initialized
DEBUG - 2023-08-21 07:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:38:03 --> Input Class Initialized
INFO - 2023-08-21 07:38:03 --> Language Class Initialized
INFO - 2023-08-21 07:38:03 --> Loader Class Initialized
INFO - 2023-08-21 07:38:03 --> Helper loaded: url_helper
INFO - 2023-08-21 07:38:03 --> Helper loaded: file_helper
INFO - 2023-08-21 07:38:03 --> Helper loaded: html_helper
INFO - 2023-08-21 07:38:03 --> Helper loaded: text_helper
INFO - 2023-08-21 07:38:03 --> Helper loaded: form_helper
INFO - 2023-08-21 07:38:03 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:38:03 --> Helper loaded: security_helper
INFO - 2023-08-21 07:38:03 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:38:03 --> Database Driver Class Initialized
INFO - 2023-08-21 07:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:38:03 --> Parser Class Initialized
INFO - 2023-08-21 07:38:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:38:03 --> Pagination Class Initialized
INFO - 2023-08-21 07:38:03 --> Form Validation Class Initialized
INFO - 2023-08-21 07:38:03 --> Controller Class Initialized
INFO - 2023-08-21 07:38:03 --> Model Class Initialized
DEBUG - 2023-08-21 07:38:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:38:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:38:03 --> Model Class Initialized
DEBUG - 2023-08-21 07:38:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:38:03 --> Model Class Initialized
INFO - 2023-08-21 07:38:03 --> Final output sent to browser
DEBUG - 2023-08-21 07:38:03 --> Total execution time: 0.0318
ERROR - 2023-08-21 07:38:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:38:06 --> Config Class Initialized
INFO - 2023-08-21 07:38:06 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:38:06 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:38:06 --> Utf8 Class Initialized
INFO - 2023-08-21 07:38:06 --> URI Class Initialized
INFO - 2023-08-21 07:38:06 --> Router Class Initialized
INFO - 2023-08-21 07:38:06 --> Output Class Initialized
INFO - 2023-08-21 07:38:06 --> Security Class Initialized
DEBUG - 2023-08-21 07:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:38:06 --> Input Class Initialized
INFO - 2023-08-21 07:38:06 --> Language Class Initialized
INFO - 2023-08-21 07:38:06 --> Loader Class Initialized
INFO - 2023-08-21 07:38:06 --> Helper loaded: url_helper
INFO - 2023-08-21 07:38:06 --> Helper loaded: file_helper
INFO - 2023-08-21 07:38:06 --> Helper loaded: html_helper
INFO - 2023-08-21 07:38:06 --> Helper loaded: text_helper
INFO - 2023-08-21 07:38:06 --> Helper loaded: form_helper
INFO - 2023-08-21 07:38:06 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:38:06 --> Helper loaded: security_helper
INFO - 2023-08-21 07:38:06 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:38:06 --> Database Driver Class Initialized
INFO - 2023-08-21 07:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:38:06 --> Parser Class Initialized
INFO - 2023-08-21 07:38:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:38:06 --> Pagination Class Initialized
INFO - 2023-08-21 07:38:06 --> Form Validation Class Initialized
INFO - 2023-08-21 07:38:06 --> Controller Class Initialized
INFO - 2023-08-21 07:38:06 --> Model Class Initialized
DEBUG - 2023-08-21 07:38:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:38:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:38:06 --> Model Class Initialized
DEBUG - 2023-08-21 07:38:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:38:06 --> Model Class Initialized
INFO - 2023-08-21 07:38:06 --> Final output sent to browser
DEBUG - 2023-08-21 07:38:06 --> Total execution time: 0.0203
ERROR - 2023-08-21 07:38:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:38:09 --> Config Class Initialized
INFO - 2023-08-21 07:38:09 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:38:09 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:38:09 --> Utf8 Class Initialized
INFO - 2023-08-21 07:38:09 --> URI Class Initialized
INFO - 2023-08-21 07:38:09 --> Router Class Initialized
INFO - 2023-08-21 07:38:09 --> Output Class Initialized
INFO - 2023-08-21 07:38:09 --> Security Class Initialized
DEBUG - 2023-08-21 07:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:38:09 --> Input Class Initialized
INFO - 2023-08-21 07:38:09 --> Language Class Initialized
INFO - 2023-08-21 07:38:09 --> Loader Class Initialized
INFO - 2023-08-21 07:38:09 --> Helper loaded: url_helper
INFO - 2023-08-21 07:38:09 --> Helper loaded: file_helper
INFO - 2023-08-21 07:38:09 --> Helper loaded: html_helper
INFO - 2023-08-21 07:38:09 --> Helper loaded: text_helper
INFO - 2023-08-21 07:38:09 --> Helper loaded: form_helper
INFO - 2023-08-21 07:38:09 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:38:09 --> Helper loaded: security_helper
INFO - 2023-08-21 07:38:09 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:38:09 --> Database Driver Class Initialized
INFO - 2023-08-21 07:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:38:09 --> Parser Class Initialized
INFO - 2023-08-21 07:38:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:38:09 --> Pagination Class Initialized
INFO - 2023-08-21 07:38:09 --> Form Validation Class Initialized
INFO - 2023-08-21 07:38:09 --> Controller Class Initialized
INFO - 2023-08-21 07:38:09 --> Model Class Initialized
DEBUG - 2023-08-21 07:38:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:38:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:38:09 --> Model Class Initialized
DEBUG - 2023-08-21 07:38:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:38:09 --> Model Class Initialized
INFO - 2023-08-21 07:38:09 --> Final output sent to browser
DEBUG - 2023-08-21 07:38:09 --> Total execution time: 0.0327
ERROR - 2023-08-21 07:38:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:38:12 --> Config Class Initialized
INFO - 2023-08-21 07:38:12 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:38:12 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:38:12 --> Utf8 Class Initialized
INFO - 2023-08-21 07:38:12 --> URI Class Initialized
INFO - 2023-08-21 07:38:12 --> Router Class Initialized
INFO - 2023-08-21 07:38:12 --> Output Class Initialized
INFO - 2023-08-21 07:38:12 --> Security Class Initialized
DEBUG - 2023-08-21 07:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:38:12 --> Input Class Initialized
INFO - 2023-08-21 07:38:12 --> Language Class Initialized
INFO - 2023-08-21 07:38:12 --> Loader Class Initialized
INFO - 2023-08-21 07:38:12 --> Helper loaded: url_helper
INFO - 2023-08-21 07:38:12 --> Helper loaded: file_helper
INFO - 2023-08-21 07:38:12 --> Helper loaded: html_helper
INFO - 2023-08-21 07:38:12 --> Helper loaded: text_helper
INFO - 2023-08-21 07:38:12 --> Helper loaded: form_helper
INFO - 2023-08-21 07:38:12 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:38:12 --> Helper loaded: security_helper
INFO - 2023-08-21 07:38:12 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:38:12 --> Database Driver Class Initialized
INFO - 2023-08-21 07:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:38:12 --> Parser Class Initialized
INFO - 2023-08-21 07:38:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:38:12 --> Pagination Class Initialized
INFO - 2023-08-21 07:38:12 --> Form Validation Class Initialized
INFO - 2023-08-21 07:38:12 --> Controller Class Initialized
INFO - 2023-08-21 07:38:12 --> Model Class Initialized
DEBUG - 2023-08-21 07:38:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:38:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:38:12 --> Model Class Initialized
DEBUG - 2023-08-21 07:38:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:38:12 --> Model Class Initialized
INFO - 2023-08-21 07:38:12 --> Final output sent to browser
DEBUG - 2023-08-21 07:38:12 --> Total execution time: 0.0254
ERROR - 2023-08-21 07:38:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:38:22 --> Config Class Initialized
INFO - 2023-08-21 07:38:22 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:38:22 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:38:22 --> Utf8 Class Initialized
INFO - 2023-08-21 07:38:22 --> URI Class Initialized
INFO - 2023-08-21 07:38:22 --> Router Class Initialized
INFO - 2023-08-21 07:38:22 --> Output Class Initialized
INFO - 2023-08-21 07:38:22 --> Security Class Initialized
DEBUG - 2023-08-21 07:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:38:22 --> Input Class Initialized
INFO - 2023-08-21 07:38:22 --> Language Class Initialized
INFO - 2023-08-21 07:38:22 --> Loader Class Initialized
INFO - 2023-08-21 07:38:22 --> Helper loaded: url_helper
INFO - 2023-08-21 07:38:22 --> Helper loaded: file_helper
INFO - 2023-08-21 07:38:22 --> Helper loaded: html_helper
INFO - 2023-08-21 07:38:22 --> Helper loaded: text_helper
INFO - 2023-08-21 07:38:22 --> Helper loaded: form_helper
INFO - 2023-08-21 07:38:22 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:38:22 --> Helper loaded: security_helper
INFO - 2023-08-21 07:38:22 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:38:22 --> Database Driver Class Initialized
INFO - 2023-08-21 07:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:38:22 --> Parser Class Initialized
INFO - 2023-08-21 07:38:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:38:22 --> Pagination Class Initialized
INFO - 2023-08-21 07:38:22 --> Form Validation Class Initialized
INFO - 2023-08-21 07:38:22 --> Controller Class Initialized
INFO - 2023-08-21 07:38:22 --> Model Class Initialized
DEBUG - 2023-08-21 07:38:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:38:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:38:22 --> Model Class Initialized
DEBUG - 2023-08-21 07:38:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:38:22 --> Model Class Initialized
INFO - 2023-08-21 07:38:22 --> Final output sent to browser
DEBUG - 2023-08-21 07:38:22 --> Total execution time: 0.0255
ERROR - 2023-08-21 07:38:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:38:23 --> Config Class Initialized
INFO - 2023-08-21 07:38:23 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:38:23 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:38:23 --> Utf8 Class Initialized
INFO - 2023-08-21 07:38:23 --> URI Class Initialized
INFO - 2023-08-21 07:38:23 --> Router Class Initialized
INFO - 2023-08-21 07:38:23 --> Output Class Initialized
INFO - 2023-08-21 07:38:23 --> Security Class Initialized
DEBUG - 2023-08-21 07:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:38:23 --> Input Class Initialized
INFO - 2023-08-21 07:38:23 --> Language Class Initialized
INFO - 2023-08-21 07:38:23 --> Loader Class Initialized
INFO - 2023-08-21 07:38:23 --> Helper loaded: url_helper
INFO - 2023-08-21 07:38:23 --> Helper loaded: file_helper
INFO - 2023-08-21 07:38:23 --> Helper loaded: html_helper
INFO - 2023-08-21 07:38:23 --> Helper loaded: text_helper
INFO - 2023-08-21 07:38:23 --> Helper loaded: form_helper
INFO - 2023-08-21 07:38:23 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:38:23 --> Helper loaded: security_helper
INFO - 2023-08-21 07:38:23 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:38:23 --> Database Driver Class Initialized
INFO - 2023-08-21 07:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:38:23 --> Parser Class Initialized
INFO - 2023-08-21 07:38:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:38:23 --> Pagination Class Initialized
INFO - 2023-08-21 07:38:23 --> Form Validation Class Initialized
INFO - 2023-08-21 07:38:23 --> Controller Class Initialized
INFO - 2023-08-21 07:38:23 --> Model Class Initialized
DEBUG - 2023-08-21 07:38:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:38:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:38:23 --> Model Class Initialized
DEBUG - 2023-08-21 07:38:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:38:23 --> Model Class Initialized
INFO - 2023-08-21 07:38:23 --> Final output sent to browser
DEBUG - 2023-08-21 07:38:23 --> Total execution time: 0.0268
ERROR - 2023-08-21 07:39:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:39:52 --> Config Class Initialized
INFO - 2023-08-21 07:39:52 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:39:52 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:39:52 --> Utf8 Class Initialized
INFO - 2023-08-21 07:39:52 --> URI Class Initialized
INFO - 2023-08-21 07:39:52 --> Router Class Initialized
INFO - 2023-08-21 07:39:52 --> Output Class Initialized
INFO - 2023-08-21 07:39:52 --> Security Class Initialized
DEBUG - 2023-08-21 07:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:39:52 --> Input Class Initialized
INFO - 2023-08-21 07:39:52 --> Language Class Initialized
INFO - 2023-08-21 07:39:52 --> Loader Class Initialized
INFO - 2023-08-21 07:39:52 --> Helper loaded: url_helper
INFO - 2023-08-21 07:39:52 --> Helper loaded: file_helper
INFO - 2023-08-21 07:39:52 --> Helper loaded: html_helper
INFO - 2023-08-21 07:39:52 --> Helper loaded: text_helper
INFO - 2023-08-21 07:39:52 --> Helper loaded: form_helper
INFO - 2023-08-21 07:39:52 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:39:52 --> Helper loaded: security_helper
INFO - 2023-08-21 07:39:52 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:39:52 --> Database Driver Class Initialized
INFO - 2023-08-21 07:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:39:52 --> Parser Class Initialized
INFO - 2023-08-21 07:39:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:39:52 --> Pagination Class Initialized
INFO - 2023-08-21 07:39:52 --> Form Validation Class Initialized
INFO - 2023-08-21 07:39:52 --> Controller Class Initialized
INFO - 2023-08-21 07:39:52 --> Model Class Initialized
DEBUG - 2023-08-21 07:39:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:39:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:39:52 --> Model Class Initialized
DEBUG - 2023-08-21 07:39:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:39:52 --> Model Class Initialized
DEBUG - 2023-08-21 07:39:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:39:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-21 07:39:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:39:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 07:39:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 07:39:52 --> Model Class Initialized
INFO - 2023-08-21 07:39:52 --> Model Class Initialized
INFO - 2023-08-21 07:39:52 --> Model Class Initialized
INFO - 2023-08-21 07:39:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 07:39:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 07:39:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 07:39:52 --> Final output sent to browser
DEBUG - 2023-08-21 07:39:52 --> Total execution time: 0.0825
ERROR - 2023-08-21 07:40:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:40:00 --> Config Class Initialized
INFO - 2023-08-21 07:40:00 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:40:00 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:40:00 --> Utf8 Class Initialized
INFO - 2023-08-21 07:40:00 --> URI Class Initialized
INFO - 2023-08-21 07:40:00 --> Router Class Initialized
INFO - 2023-08-21 07:40:00 --> Output Class Initialized
INFO - 2023-08-21 07:40:00 --> Security Class Initialized
DEBUG - 2023-08-21 07:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:40:00 --> Input Class Initialized
INFO - 2023-08-21 07:40:00 --> Language Class Initialized
INFO - 2023-08-21 07:40:00 --> Loader Class Initialized
INFO - 2023-08-21 07:40:00 --> Helper loaded: url_helper
INFO - 2023-08-21 07:40:00 --> Helper loaded: file_helper
INFO - 2023-08-21 07:40:00 --> Helper loaded: html_helper
INFO - 2023-08-21 07:40:00 --> Helper loaded: text_helper
INFO - 2023-08-21 07:40:00 --> Helper loaded: form_helper
INFO - 2023-08-21 07:40:00 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:40:00 --> Helper loaded: security_helper
INFO - 2023-08-21 07:40:00 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:40:00 --> Database Driver Class Initialized
INFO - 2023-08-21 07:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:40:00 --> Parser Class Initialized
INFO - 2023-08-21 07:40:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:40:00 --> Pagination Class Initialized
INFO - 2023-08-21 07:40:00 --> Form Validation Class Initialized
INFO - 2023-08-21 07:40:00 --> Controller Class Initialized
INFO - 2023-08-21 07:40:00 --> Model Class Initialized
DEBUG - 2023-08-21 07:40:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:40:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:40:00 --> Model Class Initialized
DEBUG - 2023-08-21 07:40:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:40:00 --> Model Class Initialized
INFO - 2023-08-21 07:40:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-21 07:40:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:40:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 07:40:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 07:40:00 --> Model Class Initialized
INFO - 2023-08-21 07:40:00 --> Model Class Initialized
INFO - 2023-08-21 07:40:00 --> Model Class Initialized
INFO - 2023-08-21 07:40:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 07:40:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 07:40:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 07:40:00 --> Final output sent to browser
DEBUG - 2023-08-21 07:40:00 --> Total execution time: 0.0731
ERROR - 2023-08-21 07:40:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:40:00 --> Config Class Initialized
INFO - 2023-08-21 07:40:00 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:40:00 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:40:00 --> Utf8 Class Initialized
INFO - 2023-08-21 07:40:00 --> URI Class Initialized
INFO - 2023-08-21 07:40:00 --> Router Class Initialized
INFO - 2023-08-21 07:40:00 --> Output Class Initialized
INFO - 2023-08-21 07:40:00 --> Security Class Initialized
DEBUG - 2023-08-21 07:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:40:00 --> Input Class Initialized
INFO - 2023-08-21 07:40:00 --> Language Class Initialized
INFO - 2023-08-21 07:40:00 --> Loader Class Initialized
INFO - 2023-08-21 07:40:00 --> Helper loaded: url_helper
INFO - 2023-08-21 07:40:00 --> Helper loaded: file_helper
INFO - 2023-08-21 07:40:00 --> Helper loaded: html_helper
INFO - 2023-08-21 07:40:00 --> Helper loaded: text_helper
INFO - 2023-08-21 07:40:00 --> Helper loaded: form_helper
INFO - 2023-08-21 07:40:00 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:40:00 --> Helper loaded: security_helper
INFO - 2023-08-21 07:40:00 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:40:00 --> Database Driver Class Initialized
INFO - 2023-08-21 07:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:40:00 --> Parser Class Initialized
INFO - 2023-08-21 07:40:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:40:00 --> Pagination Class Initialized
INFO - 2023-08-21 07:40:00 --> Form Validation Class Initialized
INFO - 2023-08-21 07:40:00 --> Controller Class Initialized
INFO - 2023-08-21 07:40:00 --> Model Class Initialized
DEBUG - 2023-08-21 07:40:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:40:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:40:00 --> Model Class Initialized
DEBUG - 2023-08-21 07:40:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:40:00 --> Model Class Initialized
INFO - 2023-08-21 07:40:00 --> Final output sent to browser
DEBUG - 2023-08-21 07:40:00 --> Total execution time: 0.0365
ERROR - 2023-08-21 07:40:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 07:40:03 --> Config Class Initialized
INFO - 2023-08-21 07:40:03 --> Hooks Class Initialized
DEBUG - 2023-08-21 07:40:03 --> UTF-8 Support Enabled
INFO - 2023-08-21 07:40:03 --> Utf8 Class Initialized
INFO - 2023-08-21 07:40:03 --> URI Class Initialized
INFO - 2023-08-21 07:40:03 --> Router Class Initialized
INFO - 2023-08-21 07:40:03 --> Output Class Initialized
INFO - 2023-08-21 07:40:03 --> Security Class Initialized
DEBUG - 2023-08-21 07:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 07:40:03 --> Input Class Initialized
INFO - 2023-08-21 07:40:03 --> Language Class Initialized
INFO - 2023-08-21 07:40:03 --> Loader Class Initialized
INFO - 2023-08-21 07:40:03 --> Helper loaded: url_helper
INFO - 2023-08-21 07:40:03 --> Helper loaded: file_helper
INFO - 2023-08-21 07:40:03 --> Helper loaded: html_helper
INFO - 2023-08-21 07:40:03 --> Helper loaded: text_helper
INFO - 2023-08-21 07:40:03 --> Helper loaded: form_helper
INFO - 2023-08-21 07:40:03 --> Helper loaded: lang_helper
INFO - 2023-08-21 07:40:03 --> Helper loaded: security_helper
INFO - 2023-08-21 07:40:03 --> Helper loaded: cookie_helper
INFO - 2023-08-21 07:40:03 --> Database Driver Class Initialized
INFO - 2023-08-21 07:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 07:40:03 --> Parser Class Initialized
INFO - 2023-08-21 07:40:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 07:40:03 --> Pagination Class Initialized
INFO - 2023-08-21 07:40:03 --> Form Validation Class Initialized
INFO - 2023-08-21 07:40:03 --> Controller Class Initialized
INFO - 2023-08-21 07:40:03 --> Model Class Initialized
DEBUG - 2023-08-21 07:40:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 07:40:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:40:03 --> Model Class Initialized
DEBUG - 2023-08-21 07:40:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 07:40:03 --> Model Class Initialized
INFO - 2023-08-21 07:40:03 --> Final output sent to browser
DEBUG - 2023-08-21 07:40:03 --> Total execution time: 0.1008
ERROR - 2023-08-21 08:08:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:08:15 --> Config Class Initialized
INFO - 2023-08-21 08:08:15 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:08:15 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:08:15 --> Utf8 Class Initialized
INFO - 2023-08-21 08:08:15 --> URI Class Initialized
DEBUG - 2023-08-21 08:08:15 --> No URI present. Default controller set.
INFO - 2023-08-21 08:08:15 --> Router Class Initialized
INFO - 2023-08-21 08:08:15 --> Output Class Initialized
INFO - 2023-08-21 08:08:15 --> Security Class Initialized
DEBUG - 2023-08-21 08:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:08:15 --> Input Class Initialized
INFO - 2023-08-21 08:08:15 --> Language Class Initialized
INFO - 2023-08-21 08:08:15 --> Loader Class Initialized
INFO - 2023-08-21 08:08:15 --> Helper loaded: url_helper
INFO - 2023-08-21 08:08:15 --> Helper loaded: file_helper
INFO - 2023-08-21 08:08:15 --> Helper loaded: html_helper
INFO - 2023-08-21 08:08:15 --> Helper loaded: text_helper
INFO - 2023-08-21 08:08:15 --> Helper loaded: form_helper
INFO - 2023-08-21 08:08:15 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:08:15 --> Helper loaded: security_helper
INFO - 2023-08-21 08:08:15 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:08:15 --> Database Driver Class Initialized
INFO - 2023-08-21 08:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:08:15 --> Parser Class Initialized
INFO - 2023-08-21 08:08:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:08:15 --> Pagination Class Initialized
INFO - 2023-08-21 08:08:15 --> Form Validation Class Initialized
INFO - 2023-08-21 08:08:15 --> Controller Class Initialized
INFO - 2023-08-21 08:08:15 --> Model Class Initialized
DEBUG - 2023-08-21 08:08:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:08:15 --> Model Class Initialized
DEBUG - 2023-08-21 08:08:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:08:15 --> Model Class Initialized
INFO - 2023-08-21 08:08:15 --> Model Class Initialized
INFO - 2023-08-21 08:08:15 --> Model Class Initialized
INFO - 2023-08-21 08:08:15 --> Model Class Initialized
DEBUG - 2023-08-21 08:08:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:08:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:08:15 --> Model Class Initialized
INFO - 2023-08-21 08:08:15 --> Model Class Initialized
INFO - 2023-08-21 08:08:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-21 08:08:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:08:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 08:08:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 08:08:15 --> Model Class Initialized
INFO - 2023-08-21 08:08:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 08:08:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 08:08:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 08:08:15 --> Final output sent to browser
DEBUG - 2023-08-21 08:08:15 --> Total execution time: 0.1025
ERROR - 2023-08-21 08:08:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:08:20 --> Config Class Initialized
INFO - 2023-08-21 08:08:20 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:08:20 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:08:20 --> Utf8 Class Initialized
INFO - 2023-08-21 08:08:20 --> URI Class Initialized
INFO - 2023-08-21 08:08:20 --> Router Class Initialized
INFO - 2023-08-21 08:08:20 --> Output Class Initialized
INFO - 2023-08-21 08:08:20 --> Security Class Initialized
DEBUG - 2023-08-21 08:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:08:20 --> Input Class Initialized
INFO - 2023-08-21 08:08:20 --> Language Class Initialized
INFO - 2023-08-21 08:08:20 --> Loader Class Initialized
INFO - 2023-08-21 08:08:20 --> Helper loaded: url_helper
INFO - 2023-08-21 08:08:20 --> Helper loaded: file_helper
INFO - 2023-08-21 08:08:20 --> Helper loaded: html_helper
INFO - 2023-08-21 08:08:20 --> Helper loaded: text_helper
INFO - 2023-08-21 08:08:20 --> Helper loaded: form_helper
INFO - 2023-08-21 08:08:20 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:08:20 --> Helper loaded: security_helper
INFO - 2023-08-21 08:08:20 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:08:20 --> Database Driver Class Initialized
INFO - 2023-08-21 08:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:08:20 --> Parser Class Initialized
INFO - 2023-08-21 08:08:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:08:20 --> Pagination Class Initialized
INFO - 2023-08-21 08:08:20 --> Form Validation Class Initialized
INFO - 2023-08-21 08:08:20 --> Controller Class Initialized
DEBUG - 2023-08-21 08:08:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:08:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:08:20 --> Model Class Initialized
DEBUG - 2023-08-21 08:08:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:08:20 --> Model Class Initialized
DEBUG - 2023-08-21 08:08:20 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:08:20 --> Model Class Initialized
INFO - 2023-08-21 08:08:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-08-21 08:08:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:08:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 08:08:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 08:08:20 --> Model Class Initialized
INFO - 2023-08-21 08:08:20 --> Model Class Initialized
INFO - 2023-08-21 08:08:20 --> Model Class Initialized
INFO - 2023-08-21 08:08:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 08:08:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 08:08:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 08:08:20 --> Final output sent to browser
DEBUG - 2023-08-21 08:08:20 --> Total execution time: 0.0689
ERROR - 2023-08-21 08:08:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:08:20 --> Config Class Initialized
INFO - 2023-08-21 08:08:20 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:08:20 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:08:20 --> Utf8 Class Initialized
INFO - 2023-08-21 08:08:20 --> URI Class Initialized
INFO - 2023-08-21 08:08:20 --> Router Class Initialized
INFO - 2023-08-21 08:08:20 --> Output Class Initialized
INFO - 2023-08-21 08:08:20 --> Security Class Initialized
DEBUG - 2023-08-21 08:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:08:20 --> Input Class Initialized
INFO - 2023-08-21 08:08:20 --> Language Class Initialized
INFO - 2023-08-21 08:08:20 --> Loader Class Initialized
INFO - 2023-08-21 08:08:20 --> Helper loaded: url_helper
INFO - 2023-08-21 08:08:20 --> Helper loaded: file_helper
INFO - 2023-08-21 08:08:20 --> Helper loaded: html_helper
INFO - 2023-08-21 08:08:20 --> Helper loaded: text_helper
INFO - 2023-08-21 08:08:20 --> Helper loaded: form_helper
INFO - 2023-08-21 08:08:20 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:08:20 --> Helper loaded: security_helper
INFO - 2023-08-21 08:08:20 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:08:21 --> Database Driver Class Initialized
INFO - 2023-08-21 08:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:08:21 --> Parser Class Initialized
INFO - 2023-08-21 08:08:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:08:21 --> Pagination Class Initialized
INFO - 2023-08-21 08:08:21 --> Form Validation Class Initialized
INFO - 2023-08-21 08:08:21 --> Controller Class Initialized
DEBUG - 2023-08-21 08:08:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:08:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:08:21 --> Model Class Initialized
DEBUG - 2023-08-21 08:08:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:08:21 --> Model Class Initialized
INFO - 2023-08-21 08:08:21 --> Final output sent to browser
DEBUG - 2023-08-21 08:08:21 --> Total execution time: 0.0283
ERROR - 2023-08-21 08:08:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:08:24 --> Config Class Initialized
INFO - 2023-08-21 08:08:24 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:08:24 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:08:24 --> Utf8 Class Initialized
INFO - 2023-08-21 08:08:24 --> URI Class Initialized
INFO - 2023-08-21 08:08:24 --> Router Class Initialized
INFO - 2023-08-21 08:08:24 --> Output Class Initialized
INFO - 2023-08-21 08:08:24 --> Security Class Initialized
DEBUG - 2023-08-21 08:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:08:24 --> Input Class Initialized
INFO - 2023-08-21 08:08:24 --> Language Class Initialized
INFO - 2023-08-21 08:08:24 --> Loader Class Initialized
INFO - 2023-08-21 08:08:24 --> Helper loaded: url_helper
INFO - 2023-08-21 08:08:24 --> Helper loaded: file_helper
INFO - 2023-08-21 08:08:24 --> Helper loaded: html_helper
INFO - 2023-08-21 08:08:24 --> Helper loaded: text_helper
INFO - 2023-08-21 08:08:24 --> Helper loaded: form_helper
INFO - 2023-08-21 08:08:24 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:08:24 --> Helper loaded: security_helper
INFO - 2023-08-21 08:08:24 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:08:24 --> Database Driver Class Initialized
INFO - 2023-08-21 08:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:08:24 --> Parser Class Initialized
INFO - 2023-08-21 08:08:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:08:24 --> Pagination Class Initialized
INFO - 2023-08-21 08:08:24 --> Form Validation Class Initialized
INFO - 2023-08-21 08:08:24 --> Controller Class Initialized
DEBUG - 2023-08-21 08:08:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:08:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:08:24 --> Model Class Initialized
DEBUG - 2023-08-21 08:08:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:08:24 --> Model Class Initialized
INFO - 2023-08-21 08:08:24 --> Final output sent to browser
DEBUG - 2023-08-21 08:08:24 --> Total execution time: 0.0265
ERROR - 2023-08-21 08:08:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:08:56 --> Config Class Initialized
INFO - 2023-08-21 08:08:56 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:08:56 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:08:56 --> Utf8 Class Initialized
INFO - 2023-08-21 08:08:56 --> URI Class Initialized
INFO - 2023-08-21 08:08:56 --> Router Class Initialized
INFO - 2023-08-21 08:08:56 --> Output Class Initialized
INFO - 2023-08-21 08:08:56 --> Security Class Initialized
DEBUG - 2023-08-21 08:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:08:56 --> Input Class Initialized
INFO - 2023-08-21 08:08:56 --> Language Class Initialized
INFO - 2023-08-21 08:08:56 --> Loader Class Initialized
INFO - 2023-08-21 08:08:56 --> Helper loaded: url_helper
INFO - 2023-08-21 08:08:56 --> Helper loaded: file_helper
INFO - 2023-08-21 08:08:56 --> Helper loaded: html_helper
INFO - 2023-08-21 08:08:56 --> Helper loaded: text_helper
INFO - 2023-08-21 08:08:56 --> Helper loaded: form_helper
INFO - 2023-08-21 08:08:56 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:08:56 --> Helper loaded: security_helper
INFO - 2023-08-21 08:08:56 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:08:56 --> Database Driver Class Initialized
INFO - 2023-08-21 08:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:08:56 --> Parser Class Initialized
INFO - 2023-08-21 08:08:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:08:56 --> Pagination Class Initialized
INFO - 2023-08-21 08:08:56 --> Form Validation Class Initialized
INFO - 2023-08-21 08:08:56 --> Controller Class Initialized
DEBUG - 2023-08-21 08:08:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:08:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:08:56 --> Model Class Initialized
DEBUG - 2023-08-21 08:08:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:08:56 --> Model Class Initialized
INFO - 2023-08-21 08:08:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/view_customer.php
DEBUG - 2023-08-21 08:08:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:08:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 08:08:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 08:08:56 --> Model Class Initialized
INFO - 2023-08-21 08:08:56 --> Model Class Initialized
INFO - 2023-08-21 08:08:56 --> Model Class Initialized
INFO - 2023-08-21 08:08:56 --> Model Class Initialized
INFO - 2023-08-21 08:08:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 08:08:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 08:08:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 08:08:56 --> Final output sent to browser
DEBUG - 2023-08-21 08:08:56 --> Total execution time: 0.0781
ERROR - 2023-08-21 08:10:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:10:58 --> Config Class Initialized
INFO - 2023-08-21 08:10:58 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:10:58 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:10:58 --> Utf8 Class Initialized
INFO - 2023-08-21 08:10:58 --> URI Class Initialized
DEBUG - 2023-08-21 08:10:58 --> No URI present. Default controller set.
INFO - 2023-08-21 08:10:58 --> Router Class Initialized
INFO - 2023-08-21 08:10:58 --> Output Class Initialized
INFO - 2023-08-21 08:10:58 --> Security Class Initialized
DEBUG - 2023-08-21 08:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:10:58 --> Input Class Initialized
INFO - 2023-08-21 08:10:58 --> Language Class Initialized
INFO - 2023-08-21 08:10:58 --> Loader Class Initialized
INFO - 2023-08-21 08:10:58 --> Helper loaded: url_helper
INFO - 2023-08-21 08:10:58 --> Helper loaded: file_helper
INFO - 2023-08-21 08:10:58 --> Helper loaded: html_helper
INFO - 2023-08-21 08:10:58 --> Helper loaded: text_helper
INFO - 2023-08-21 08:10:58 --> Helper loaded: form_helper
INFO - 2023-08-21 08:10:58 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:10:58 --> Helper loaded: security_helper
INFO - 2023-08-21 08:10:58 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:10:58 --> Database Driver Class Initialized
INFO - 2023-08-21 08:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:10:58 --> Parser Class Initialized
INFO - 2023-08-21 08:10:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:10:58 --> Pagination Class Initialized
INFO - 2023-08-21 08:10:58 --> Form Validation Class Initialized
INFO - 2023-08-21 08:10:58 --> Controller Class Initialized
INFO - 2023-08-21 08:10:58 --> Model Class Initialized
DEBUG - 2023-08-21 08:10:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:10:58 --> Model Class Initialized
DEBUG - 2023-08-21 08:10:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:10:58 --> Model Class Initialized
INFO - 2023-08-21 08:10:58 --> Model Class Initialized
INFO - 2023-08-21 08:10:58 --> Model Class Initialized
INFO - 2023-08-21 08:10:58 --> Model Class Initialized
DEBUG - 2023-08-21 08:10:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:10:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:10:58 --> Model Class Initialized
INFO - 2023-08-21 08:10:58 --> Model Class Initialized
INFO - 2023-08-21 08:10:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-21 08:10:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:10:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 08:10:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 08:10:58 --> Model Class Initialized
INFO - 2023-08-21 08:10:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 08:10:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 08:10:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 08:10:58 --> Final output sent to browser
DEBUG - 2023-08-21 08:10:58 --> Total execution time: 0.1843
ERROR - 2023-08-21 08:11:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:11:14 --> Config Class Initialized
INFO - 2023-08-21 08:11:14 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:11:14 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:11:14 --> Utf8 Class Initialized
INFO - 2023-08-21 08:11:14 --> URI Class Initialized
DEBUG - 2023-08-21 08:11:14 --> No URI present. Default controller set.
INFO - 2023-08-21 08:11:14 --> Router Class Initialized
INFO - 2023-08-21 08:11:14 --> Output Class Initialized
INFO - 2023-08-21 08:11:14 --> Security Class Initialized
DEBUG - 2023-08-21 08:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:11:14 --> Input Class Initialized
INFO - 2023-08-21 08:11:14 --> Language Class Initialized
INFO - 2023-08-21 08:11:14 --> Loader Class Initialized
INFO - 2023-08-21 08:11:14 --> Helper loaded: url_helper
INFO - 2023-08-21 08:11:14 --> Helper loaded: file_helper
INFO - 2023-08-21 08:11:14 --> Helper loaded: html_helper
INFO - 2023-08-21 08:11:14 --> Helper loaded: text_helper
INFO - 2023-08-21 08:11:14 --> Helper loaded: form_helper
INFO - 2023-08-21 08:11:14 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:11:14 --> Helper loaded: security_helper
INFO - 2023-08-21 08:11:14 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:11:14 --> Database Driver Class Initialized
INFO - 2023-08-21 08:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:11:14 --> Parser Class Initialized
INFO - 2023-08-21 08:11:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:11:14 --> Pagination Class Initialized
INFO - 2023-08-21 08:11:14 --> Form Validation Class Initialized
INFO - 2023-08-21 08:11:14 --> Controller Class Initialized
INFO - 2023-08-21 08:11:14 --> Model Class Initialized
DEBUG - 2023-08-21 08:11:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:11:14 --> Model Class Initialized
DEBUG - 2023-08-21 08:11:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:11:14 --> Model Class Initialized
INFO - 2023-08-21 08:11:14 --> Model Class Initialized
INFO - 2023-08-21 08:11:14 --> Model Class Initialized
INFO - 2023-08-21 08:11:14 --> Model Class Initialized
DEBUG - 2023-08-21 08:11:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:11:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:11:14 --> Model Class Initialized
INFO - 2023-08-21 08:11:14 --> Model Class Initialized
INFO - 2023-08-21 08:11:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-21 08:11:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:11:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 08:11:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 08:11:14 --> Model Class Initialized
INFO - 2023-08-21 08:11:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 08:11:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 08:11:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 08:11:14 --> Final output sent to browser
DEBUG - 2023-08-21 08:11:14 --> Total execution time: 0.0915
ERROR - 2023-08-21 08:11:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:11:42 --> Config Class Initialized
INFO - 2023-08-21 08:11:42 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:11:42 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:11:42 --> Utf8 Class Initialized
INFO - 2023-08-21 08:11:42 --> URI Class Initialized
INFO - 2023-08-21 08:11:42 --> Router Class Initialized
INFO - 2023-08-21 08:11:42 --> Output Class Initialized
INFO - 2023-08-21 08:11:42 --> Security Class Initialized
DEBUG - 2023-08-21 08:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:11:42 --> Input Class Initialized
INFO - 2023-08-21 08:11:42 --> Language Class Initialized
INFO - 2023-08-21 08:11:42 --> Loader Class Initialized
INFO - 2023-08-21 08:11:42 --> Helper loaded: url_helper
INFO - 2023-08-21 08:11:42 --> Helper loaded: file_helper
INFO - 2023-08-21 08:11:42 --> Helper loaded: html_helper
INFO - 2023-08-21 08:11:42 --> Helper loaded: text_helper
INFO - 2023-08-21 08:11:42 --> Helper loaded: form_helper
INFO - 2023-08-21 08:11:42 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:11:42 --> Helper loaded: security_helper
INFO - 2023-08-21 08:11:42 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:11:42 --> Database Driver Class Initialized
INFO - 2023-08-21 08:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:11:42 --> Parser Class Initialized
INFO - 2023-08-21 08:11:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:11:42 --> Pagination Class Initialized
INFO - 2023-08-21 08:11:42 --> Form Validation Class Initialized
INFO - 2023-08-21 08:11:42 --> Controller Class Initialized
INFO - 2023-08-21 08:11:42 --> Model Class Initialized
DEBUG - 2023-08-21 08:11:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:11:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:11:42 --> Model Class Initialized
DEBUG - 2023-08-21 08:11:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:11:42 --> Model Class Initialized
INFO - 2023-08-21 08:11:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-21 08:11:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:11:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 08:11:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 08:11:42 --> Model Class Initialized
INFO - 2023-08-21 08:11:42 --> Model Class Initialized
INFO - 2023-08-21 08:11:42 --> Model Class Initialized
INFO - 2023-08-21 08:11:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 08:11:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 08:11:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 08:11:42 --> Final output sent to browser
DEBUG - 2023-08-21 08:11:42 --> Total execution time: 0.0783
ERROR - 2023-08-21 08:11:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:11:42 --> Config Class Initialized
INFO - 2023-08-21 08:11:42 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:11:42 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:11:42 --> Utf8 Class Initialized
INFO - 2023-08-21 08:11:42 --> URI Class Initialized
INFO - 2023-08-21 08:11:42 --> Router Class Initialized
INFO - 2023-08-21 08:11:42 --> Output Class Initialized
INFO - 2023-08-21 08:11:42 --> Security Class Initialized
DEBUG - 2023-08-21 08:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:11:42 --> Input Class Initialized
INFO - 2023-08-21 08:11:42 --> Language Class Initialized
INFO - 2023-08-21 08:11:42 --> Loader Class Initialized
INFO - 2023-08-21 08:11:42 --> Helper loaded: url_helper
INFO - 2023-08-21 08:11:42 --> Helper loaded: file_helper
INFO - 2023-08-21 08:11:42 --> Helper loaded: html_helper
INFO - 2023-08-21 08:11:42 --> Helper loaded: text_helper
INFO - 2023-08-21 08:11:42 --> Helper loaded: form_helper
INFO - 2023-08-21 08:11:42 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:11:42 --> Helper loaded: security_helper
INFO - 2023-08-21 08:11:42 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:11:42 --> Database Driver Class Initialized
INFO - 2023-08-21 08:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:11:42 --> Parser Class Initialized
INFO - 2023-08-21 08:11:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:11:42 --> Pagination Class Initialized
INFO - 2023-08-21 08:11:42 --> Form Validation Class Initialized
INFO - 2023-08-21 08:11:42 --> Controller Class Initialized
INFO - 2023-08-21 08:11:42 --> Model Class Initialized
DEBUG - 2023-08-21 08:11:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:11:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:11:42 --> Model Class Initialized
DEBUG - 2023-08-21 08:11:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:11:42 --> Model Class Initialized
INFO - 2023-08-21 08:11:42 --> Final output sent to browser
DEBUG - 2023-08-21 08:11:42 --> Total execution time: 0.0377
ERROR - 2023-08-21 08:11:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:11:48 --> Config Class Initialized
INFO - 2023-08-21 08:11:48 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:11:48 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:11:48 --> Utf8 Class Initialized
INFO - 2023-08-21 08:11:48 --> URI Class Initialized
INFO - 2023-08-21 08:11:48 --> Router Class Initialized
INFO - 2023-08-21 08:11:48 --> Output Class Initialized
INFO - 2023-08-21 08:11:48 --> Security Class Initialized
DEBUG - 2023-08-21 08:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:11:48 --> Input Class Initialized
INFO - 2023-08-21 08:11:48 --> Language Class Initialized
INFO - 2023-08-21 08:11:48 --> Loader Class Initialized
INFO - 2023-08-21 08:11:48 --> Helper loaded: url_helper
INFO - 2023-08-21 08:11:48 --> Helper loaded: file_helper
INFO - 2023-08-21 08:11:48 --> Helper loaded: html_helper
INFO - 2023-08-21 08:11:48 --> Helper loaded: text_helper
INFO - 2023-08-21 08:11:48 --> Helper loaded: form_helper
INFO - 2023-08-21 08:11:48 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:11:48 --> Helper loaded: security_helper
INFO - 2023-08-21 08:11:48 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:11:48 --> Database Driver Class Initialized
INFO - 2023-08-21 08:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:11:48 --> Parser Class Initialized
INFO - 2023-08-21 08:11:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:11:48 --> Pagination Class Initialized
INFO - 2023-08-21 08:11:48 --> Form Validation Class Initialized
INFO - 2023-08-21 08:11:48 --> Controller Class Initialized
INFO - 2023-08-21 08:11:48 --> Model Class Initialized
DEBUG - 2023-08-21 08:11:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:11:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:11:48 --> Model Class Initialized
DEBUG - 2023-08-21 08:11:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:11:48 --> Model Class Initialized
INFO - 2023-08-21 08:11:49 --> Final output sent to browser
DEBUG - 2023-08-21 08:11:49 --> Total execution time: 0.1085
ERROR - 2023-08-21 08:12:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:12:11 --> Config Class Initialized
INFO - 2023-08-21 08:12:11 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:12:11 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:12:11 --> Utf8 Class Initialized
INFO - 2023-08-21 08:12:11 --> URI Class Initialized
INFO - 2023-08-21 08:12:11 --> Router Class Initialized
INFO - 2023-08-21 08:12:11 --> Output Class Initialized
INFO - 2023-08-21 08:12:11 --> Security Class Initialized
DEBUG - 2023-08-21 08:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:12:11 --> Input Class Initialized
INFO - 2023-08-21 08:12:11 --> Language Class Initialized
INFO - 2023-08-21 08:12:11 --> Loader Class Initialized
INFO - 2023-08-21 08:12:11 --> Helper loaded: url_helper
INFO - 2023-08-21 08:12:11 --> Helper loaded: file_helper
INFO - 2023-08-21 08:12:11 --> Helper loaded: html_helper
INFO - 2023-08-21 08:12:11 --> Helper loaded: text_helper
INFO - 2023-08-21 08:12:11 --> Helper loaded: form_helper
INFO - 2023-08-21 08:12:11 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:12:11 --> Helper loaded: security_helper
INFO - 2023-08-21 08:12:11 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:12:11 --> Database Driver Class Initialized
INFO - 2023-08-21 08:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:12:11 --> Parser Class Initialized
INFO - 2023-08-21 08:12:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:12:11 --> Pagination Class Initialized
INFO - 2023-08-21 08:12:11 --> Form Validation Class Initialized
INFO - 2023-08-21 08:12:11 --> Controller Class Initialized
INFO - 2023-08-21 08:12:11 --> Model Class Initialized
DEBUG - 2023-08-21 08:12:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:12:11 --> Final output sent to browser
DEBUG - 2023-08-21 08:12:11 --> Total execution time: 0.0145
ERROR - 2023-08-21 08:12:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:12:11 --> Config Class Initialized
INFO - 2023-08-21 08:12:11 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:12:11 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:12:11 --> Utf8 Class Initialized
INFO - 2023-08-21 08:12:11 --> URI Class Initialized
INFO - 2023-08-21 08:12:11 --> Router Class Initialized
INFO - 2023-08-21 08:12:11 --> Output Class Initialized
INFO - 2023-08-21 08:12:11 --> Security Class Initialized
DEBUG - 2023-08-21 08:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:12:11 --> Input Class Initialized
INFO - 2023-08-21 08:12:11 --> Language Class Initialized
INFO - 2023-08-21 08:12:11 --> Loader Class Initialized
INFO - 2023-08-21 08:12:11 --> Helper loaded: url_helper
INFO - 2023-08-21 08:12:11 --> Helper loaded: file_helper
INFO - 2023-08-21 08:12:11 --> Helper loaded: html_helper
INFO - 2023-08-21 08:12:11 --> Helper loaded: text_helper
INFO - 2023-08-21 08:12:11 --> Helper loaded: form_helper
INFO - 2023-08-21 08:12:11 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:12:11 --> Helper loaded: security_helper
INFO - 2023-08-21 08:12:11 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:12:11 --> Database Driver Class Initialized
INFO - 2023-08-21 08:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:12:11 --> Parser Class Initialized
INFO - 2023-08-21 08:12:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:12:11 --> Pagination Class Initialized
INFO - 2023-08-21 08:12:11 --> Form Validation Class Initialized
INFO - 2023-08-21 08:12:11 --> Controller Class Initialized
INFO - 2023-08-21 08:12:11 --> Model Class Initialized
DEBUG - 2023-08-21 08:12:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:12:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-21 08:12:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:12:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 08:12:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 08:12:11 --> Model Class Initialized
INFO - 2023-08-21 08:12:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 08:12:11 --> Final output sent to browser
DEBUG - 2023-08-21 08:12:11 --> Total execution time: 0.0293
ERROR - 2023-08-21 08:12:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:12:18 --> Config Class Initialized
INFO - 2023-08-21 08:12:18 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:12:18 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:12:18 --> Utf8 Class Initialized
INFO - 2023-08-21 08:12:18 --> URI Class Initialized
INFO - 2023-08-21 08:12:18 --> Router Class Initialized
INFO - 2023-08-21 08:12:18 --> Output Class Initialized
INFO - 2023-08-21 08:12:18 --> Security Class Initialized
DEBUG - 2023-08-21 08:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:12:18 --> Input Class Initialized
INFO - 2023-08-21 08:12:18 --> Language Class Initialized
INFO - 2023-08-21 08:12:18 --> Loader Class Initialized
INFO - 2023-08-21 08:12:18 --> Helper loaded: url_helper
INFO - 2023-08-21 08:12:18 --> Helper loaded: file_helper
INFO - 2023-08-21 08:12:18 --> Helper loaded: html_helper
INFO - 2023-08-21 08:12:18 --> Helper loaded: text_helper
INFO - 2023-08-21 08:12:18 --> Helper loaded: form_helper
INFO - 2023-08-21 08:12:18 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:12:18 --> Helper loaded: security_helper
INFO - 2023-08-21 08:12:18 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:12:18 --> Database Driver Class Initialized
INFO - 2023-08-21 08:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:12:18 --> Parser Class Initialized
INFO - 2023-08-21 08:12:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:12:18 --> Pagination Class Initialized
INFO - 2023-08-21 08:12:18 --> Form Validation Class Initialized
INFO - 2023-08-21 08:12:18 --> Controller Class Initialized
INFO - 2023-08-21 08:12:18 --> Model Class Initialized
DEBUG - 2023-08-21 08:12:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:12:18 --> Model Class Initialized
INFO - 2023-08-21 08:12:18 --> Final output sent to browser
DEBUG - 2023-08-21 08:12:18 --> Total execution time: 0.0170
ERROR - 2023-08-21 08:12:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:12:18 --> Config Class Initialized
INFO - 2023-08-21 08:12:18 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:12:18 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:12:18 --> Utf8 Class Initialized
INFO - 2023-08-21 08:12:18 --> URI Class Initialized
DEBUG - 2023-08-21 08:12:18 --> No URI present. Default controller set.
INFO - 2023-08-21 08:12:18 --> Router Class Initialized
INFO - 2023-08-21 08:12:18 --> Output Class Initialized
INFO - 2023-08-21 08:12:18 --> Security Class Initialized
DEBUG - 2023-08-21 08:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:12:18 --> Input Class Initialized
INFO - 2023-08-21 08:12:18 --> Language Class Initialized
INFO - 2023-08-21 08:12:18 --> Loader Class Initialized
INFO - 2023-08-21 08:12:18 --> Helper loaded: url_helper
INFO - 2023-08-21 08:12:18 --> Helper loaded: file_helper
INFO - 2023-08-21 08:12:18 --> Helper loaded: html_helper
INFO - 2023-08-21 08:12:18 --> Helper loaded: text_helper
INFO - 2023-08-21 08:12:18 --> Helper loaded: form_helper
INFO - 2023-08-21 08:12:18 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:12:18 --> Helper loaded: security_helper
INFO - 2023-08-21 08:12:18 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:12:18 --> Database Driver Class Initialized
INFO - 2023-08-21 08:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:12:18 --> Parser Class Initialized
INFO - 2023-08-21 08:12:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:12:18 --> Pagination Class Initialized
INFO - 2023-08-21 08:12:18 --> Form Validation Class Initialized
INFO - 2023-08-21 08:12:18 --> Controller Class Initialized
INFO - 2023-08-21 08:12:18 --> Model Class Initialized
DEBUG - 2023-08-21 08:12:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:12:18 --> Model Class Initialized
DEBUG - 2023-08-21 08:12:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:12:18 --> Model Class Initialized
INFO - 2023-08-21 08:12:18 --> Model Class Initialized
INFO - 2023-08-21 08:12:18 --> Model Class Initialized
INFO - 2023-08-21 08:12:18 --> Model Class Initialized
DEBUG - 2023-08-21 08:12:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:12:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:12:18 --> Model Class Initialized
INFO - 2023-08-21 08:12:18 --> Model Class Initialized
INFO - 2023-08-21 08:12:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-21 08:12:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:12:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 08:12:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 08:12:18 --> Model Class Initialized
INFO - 2023-08-21 08:12:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 08:12:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 08:12:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 08:12:18 --> Final output sent to browser
DEBUG - 2023-08-21 08:12:18 --> Total execution time: 0.0867
ERROR - 2023-08-21 08:12:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:12:35 --> Config Class Initialized
INFO - 2023-08-21 08:12:35 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:12:35 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:12:35 --> Utf8 Class Initialized
INFO - 2023-08-21 08:12:35 --> URI Class Initialized
INFO - 2023-08-21 08:12:35 --> Router Class Initialized
INFO - 2023-08-21 08:12:35 --> Output Class Initialized
INFO - 2023-08-21 08:12:35 --> Security Class Initialized
DEBUG - 2023-08-21 08:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:12:35 --> Input Class Initialized
INFO - 2023-08-21 08:12:35 --> Language Class Initialized
INFO - 2023-08-21 08:12:35 --> Loader Class Initialized
INFO - 2023-08-21 08:12:35 --> Helper loaded: url_helper
INFO - 2023-08-21 08:12:35 --> Helper loaded: file_helper
INFO - 2023-08-21 08:12:35 --> Helper loaded: html_helper
INFO - 2023-08-21 08:12:35 --> Helper loaded: text_helper
INFO - 2023-08-21 08:12:35 --> Helper loaded: form_helper
INFO - 2023-08-21 08:12:35 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:12:35 --> Helper loaded: security_helper
INFO - 2023-08-21 08:12:35 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:12:35 --> Database Driver Class Initialized
INFO - 2023-08-21 08:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:12:35 --> Parser Class Initialized
INFO - 2023-08-21 08:12:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:12:35 --> Pagination Class Initialized
INFO - 2023-08-21 08:12:35 --> Form Validation Class Initialized
INFO - 2023-08-21 08:12:35 --> Controller Class Initialized
INFO - 2023-08-21 08:12:35 --> Model Class Initialized
DEBUG - 2023-08-21 08:12:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:12:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:12:35 --> Model Class Initialized
DEBUG - 2023-08-21 08:12:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:12:35 --> Model Class Initialized
INFO - 2023-08-21 08:12:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-21 08:12:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:12:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 08:12:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 08:12:35 --> Model Class Initialized
INFO - 2023-08-21 08:12:35 --> Model Class Initialized
INFO - 2023-08-21 08:12:35 --> Model Class Initialized
INFO - 2023-08-21 08:12:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 08:12:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 08:12:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 08:12:35 --> Final output sent to browser
DEBUG - 2023-08-21 08:12:35 --> Total execution time: 0.0791
ERROR - 2023-08-21 08:12:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:12:36 --> Config Class Initialized
INFO - 2023-08-21 08:12:36 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:12:36 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:12:36 --> Utf8 Class Initialized
INFO - 2023-08-21 08:12:36 --> URI Class Initialized
INFO - 2023-08-21 08:12:36 --> Router Class Initialized
INFO - 2023-08-21 08:12:36 --> Output Class Initialized
INFO - 2023-08-21 08:12:36 --> Security Class Initialized
DEBUG - 2023-08-21 08:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:12:36 --> Input Class Initialized
INFO - 2023-08-21 08:12:36 --> Language Class Initialized
INFO - 2023-08-21 08:12:36 --> Loader Class Initialized
INFO - 2023-08-21 08:12:36 --> Helper loaded: url_helper
INFO - 2023-08-21 08:12:36 --> Helper loaded: file_helper
INFO - 2023-08-21 08:12:36 --> Helper loaded: html_helper
INFO - 2023-08-21 08:12:36 --> Helper loaded: text_helper
INFO - 2023-08-21 08:12:36 --> Helper loaded: form_helper
INFO - 2023-08-21 08:12:36 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:12:36 --> Helper loaded: security_helper
INFO - 2023-08-21 08:12:36 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:12:36 --> Database Driver Class Initialized
INFO - 2023-08-21 08:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:12:36 --> Parser Class Initialized
INFO - 2023-08-21 08:12:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:12:36 --> Pagination Class Initialized
INFO - 2023-08-21 08:12:36 --> Form Validation Class Initialized
INFO - 2023-08-21 08:12:36 --> Controller Class Initialized
INFO - 2023-08-21 08:12:36 --> Model Class Initialized
DEBUG - 2023-08-21 08:12:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:12:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:12:36 --> Model Class Initialized
DEBUG - 2023-08-21 08:12:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:12:36 --> Model Class Initialized
INFO - 2023-08-21 08:12:36 --> Final output sent to browser
DEBUG - 2023-08-21 08:12:36 --> Total execution time: 0.0393
ERROR - 2023-08-21 08:12:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:12:45 --> Config Class Initialized
INFO - 2023-08-21 08:12:45 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:12:45 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:12:45 --> Utf8 Class Initialized
INFO - 2023-08-21 08:12:45 --> URI Class Initialized
INFO - 2023-08-21 08:12:45 --> Router Class Initialized
INFO - 2023-08-21 08:12:45 --> Output Class Initialized
INFO - 2023-08-21 08:12:45 --> Security Class Initialized
DEBUG - 2023-08-21 08:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:12:45 --> Input Class Initialized
INFO - 2023-08-21 08:12:45 --> Language Class Initialized
INFO - 2023-08-21 08:12:45 --> Loader Class Initialized
INFO - 2023-08-21 08:12:45 --> Helper loaded: url_helper
INFO - 2023-08-21 08:12:45 --> Helper loaded: file_helper
INFO - 2023-08-21 08:12:45 --> Helper loaded: html_helper
INFO - 2023-08-21 08:12:45 --> Helper loaded: text_helper
INFO - 2023-08-21 08:12:45 --> Helper loaded: form_helper
INFO - 2023-08-21 08:12:45 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:12:45 --> Helper loaded: security_helper
INFO - 2023-08-21 08:12:45 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:12:45 --> Database Driver Class Initialized
INFO - 2023-08-21 08:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:12:45 --> Parser Class Initialized
INFO - 2023-08-21 08:12:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:12:45 --> Pagination Class Initialized
INFO - 2023-08-21 08:12:45 --> Form Validation Class Initialized
INFO - 2023-08-21 08:12:45 --> Controller Class Initialized
INFO - 2023-08-21 08:12:45 --> Model Class Initialized
DEBUG - 2023-08-21 08:12:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:12:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:12:45 --> Model Class Initialized
DEBUG - 2023-08-21 08:12:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:12:45 --> Model Class Initialized
INFO - 2023-08-21 08:12:45 --> Final output sent to browser
DEBUG - 2023-08-21 08:12:45 --> Total execution time: 0.0455
ERROR - 2023-08-21 08:12:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:12:46 --> Config Class Initialized
INFO - 2023-08-21 08:12:46 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:12:46 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:12:46 --> Utf8 Class Initialized
INFO - 2023-08-21 08:12:46 --> URI Class Initialized
INFO - 2023-08-21 08:12:46 --> Router Class Initialized
INFO - 2023-08-21 08:12:46 --> Output Class Initialized
INFO - 2023-08-21 08:12:46 --> Security Class Initialized
DEBUG - 2023-08-21 08:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:12:46 --> Input Class Initialized
INFO - 2023-08-21 08:12:46 --> Language Class Initialized
INFO - 2023-08-21 08:12:46 --> Loader Class Initialized
INFO - 2023-08-21 08:12:46 --> Helper loaded: url_helper
INFO - 2023-08-21 08:12:46 --> Helper loaded: file_helper
INFO - 2023-08-21 08:12:46 --> Helper loaded: html_helper
INFO - 2023-08-21 08:12:46 --> Helper loaded: text_helper
INFO - 2023-08-21 08:12:46 --> Helper loaded: form_helper
INFO - 2023-08-21 08:12:46 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:12:46 --> Helper loaded: security_helper
INFO - 2023-08-21 08:12:46 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:12:46 --> Database Driver Class Initialized
INFO - 2023-08-21 08:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:12:46 --> Parser Class Initialized
INFO - 2023-08-21 08:12:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:12:46 --> Pagination Class Initialized
INFO - 2023-08-21 08:12:46 --> Form Validation Class Initialized
INFO - 2023-08-21 08:12:46 --> Controller Class Initialized
INFO - 2023-08-21 08:12:46 --> Model Class Initialized
DEBUG - 2023-08-21 08:12:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:12:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:12:46 --> Model Class Initialized
DEBUG - 2023-08-21 08:12:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:12:46 --> Model Class Initialized
INFO - 2023-08-21 08:12:46 --> Final output sent to browser
DEBUG - 2023-08-21 08:12:46 --> Total execution time: 0.0398
ERROR - 2023-08-21 08:12:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:12:51 --> Config Class Initialized
INFO - 2023-08-21 08:12:51 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:12:51 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:12:51 --> Utf8 Class Initialized
INFO - 2023-08-21 08:12:51 --> URI Class Initialized
INFO - 2023-08-21 08:12:51 --> Router Class Initialized
INFO - 2023-08-21 08:12:51 --> Output Class Initialized
INFO - 2023-08-21 08:12:51 --> Security Class Initialized
DEBUG - 2023-08-21 08:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:12:51 --> Input Class Initialized
INFO - 2023-08-21 08:12:51 --> Language Class Initialized
INFO - 2023-08-21 08:12:51 --> Loader Class Initialized
INFO - 2023-08-21 08:12:51 --> Helper loaded: url_helper
INFO - 2023-08-21 08:12:51 --> Helper loaded: file_helper
INFO - 2023-08-21 08:12:51 --> Helper loaded: html_helper
INFO - 2023-08-21 08:12:51 --> Helper loaded: text_helper
INFO - 2023-08-21 08:12:51 --> Helper loaded: form_helper
INFO - 2023-08-21 08:12:51 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:12:51 --> Helper loaded: security_helper
INFO - 2023-08-21 08:12:51 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:12:51 --> Database Driver Class Initialized
INFO - 2023-08-21 08:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:12:51 --> Parser Class Initialized
INFO - 2023-08-21 08:12:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:12:51 --> Pagination Class Initialized
INFO - 2023-08-21 08:12:51 --> Form Validation Class Initialized
INFO - 2023-08-21 08:12:51 --> Controller Class Initialized
INFO - 2023-08-21 08:12:51 --> Model Class Initialized
DEBUG - 2023-08-21 08:12:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:12:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:12:51 --> Model Class Initialized
DEBUG - 2023-08-21 08:12:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:12:51 --> Model Class Initialized
INFO - 2023-08-21 08:12:51 --> Final output sent to browser
DEBUG - 2023-08-21 08:12:51 --> Total execution time: 0.0739
ERROR - 2023-08-21 08:38:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:38:20 --> Config Class Initialized
INFO - 2023-08-21 08:38:20 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:38:20 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:38:20 --> Utf8 Class Initialized
INFO - 2023-08-21 08:38:20 --> URI Class Initialized
DEBUG - 2023-08-21 08:38:20 --> No URI present. Default controller set.
INFO - 2023-08-21 08:38:20 --> Router Class Initialized
INFO - 2023-08-21 08:38:20 --> Output Class Initialized
INFO - 2023-08-21 08:38:20 --> Security Class Initialized
DEBUG - 2023-08-21 08:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:38:20 --> Input Class Initialized
INFO - 2023-08-21 08:38:20 --> Language Class Initialized
INFO - 2023-08-21 08:38:20 --> Loader Class Initialized
INFO - 2023-08-21 08:38:20 --> Helper loaded: url_helper
INFO - 2023-08-21 08:38:20 --> Helper loaded: file_helper
INFO - 2023-08-21 08:38:20 --> Helper loaded: html_helper
INFO - 2023-08-21 08:38:20 --> Helper loaded: text_helper
INFO - 2023-08-21 08:38:20 --> Helper loaded: form_helper
INFO - 2023-08-21 08:38:20 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:38:20 --> Helper loaded: security_helper
INFO - 2023-08-21 08:38:20 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:38:20 --> Database Driver Class Initialized
INFO - 2023-08-21 08:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:38:20 --> Parser Class Initialized
INFO - 2023-08-21 08:38:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:38:20 --> Pagination Class Initialized
INFO - 2023-08-21 08:38:20 --> Form Validation Class Initialized
INFO - 2023-08-21 08:38:20 --> Controller Class Initialized
INFO - 2023-08-21 08:38:20 --> Model Class Initialized
DEBUG - 2023-08-21 08:38:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-21 08:38:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:38:22 --> Config Class Initialized
INFO - 2023-08-21 08:38:22 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:38:22 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:38:22 --> Utf8 Class Initialized
INFO - 2023-08-21 08:38:22 --> URI Class Initialized
DEBUG - 2023-08-21 08:38:22 --> No URI present. Default controller set.
INFO - 2023-08-21 08:38:22 --> Router Class Initialized
INFO - 2023-08-21 08:38:22 --> Output Class Initialized
INFO - 2023-08-21 08:38:22 --> Security Class Initialized
DEBUG - 2023-08-21 08:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:38:22 --> Input Class Initialized
INFO - 2023-08-21 08:38:22 --> Language Class Initialized
INFO - 2023-08-21 08:38:22 --> Loader Class Initialized
INFO - 2023-08-21 08:38:22 --> Helper loaded: url_helper
INFO - 2023-08-21 08:38:22 --> Helper loaded: file_helper
INFO - 2023-08-21 08:38:22 --> Helper loaded: html_helper
INFO - 2023-08-21 08:38:22 --> Helper loaded: text_helper
INFO - 2023-08-21 08:38:22 --> Helper loaded: form_helper
INFO - 2023-08-21 08:38:22 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:38:22 --> Helper loaded: security_helper
INFO - 2023-08-21 08:38:22 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:38:22 --> Database Driver Class Initialized
INFO - 2023-08-21 08:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:38:22 --> Parser Class Initialized
INFO - 2023-08-21 08:38:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:38:22 --> Pagination Class Initialized
INFO - 2023-08-21 08:38:22 --> Form Validation Class Initialized
INFO - 2023-08-21 08:38:22 --> Controller Class Initialized
INFO - 2023-08-21 08:38:22 --> Model Class Initialized
DEBUG - 2023-08-21 08:38:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-21 08:38:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:38:22 --> Config Class Initialized
INFO - 2023-08-21 08:38:22 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:38:22 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:38:22 --> Utf8 Class Initialized
INFO - 2023-08-21 08:38:22 --> URI Class Initialized
DEBUG - 2023-08-21 08:38:22 --> No URI present. Default controller set.
INFO - 2023-08-21 08:38:22 --> Router Class Initialized
INFO - 2023-08-21 08:38:22 --> Output Class Initialized
INFO - 2023-08-21 08:38:22 --> Security Class Initialized
DEBUG - 2023-08-21 08:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:38:22 --> Input Class Initialized
INFO - 2023-08-21 08:38:22 --> Language Class Initialized
INFO - 2023-08-21 08:38:22 --> Loader Class Initialized
INFO - 2023-08-21 08:38:22 --> Helper loaded: url_helper
INFO - 2023-08-21 08:38:22 --> Helper loaded: file_helper
INFO - 2023-08-21 08:38:22 --> Helper loaded: html_helper
INFO - 2023-08-21 08:38:22 --> Helper loaded: text_helper
INFO - 2023-08-21 08:38:22 --> Helper loaded: form_helper
INFO - 2023-08-21 08:38:22 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:38:22 --> Helper loaded: security_helper
INFO - 2023-08-21 08:38:22 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:38:22 --> Database Driver Class Initialized
INFO - 2023-08-21 08:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:38:22 --> Parser Class Initialized
INFO - 2023-08-21 08:38:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:38:22 --> Pagination Class Initialized
INFO - 2023-08-21 08:38:22 --> Form Validation Class Initialized
INFO - 2023-08-21 08:38:22 --> Controller Class Initialized
INFO - 2023-08-21 08:38:22 --> Model Class Initialized
DEBUG - 2023-08-21 08:38:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-21 08:38:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:38:23 --> Config Class Initialized
INFO - 2023-08-21 08:38:23 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:38:23 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:38:23 --> Utf8 Class Initialized
INFO - 2023-08-21 08:38:23 --> URI Class Initialized
DEBUG - 2023-08-21 08:38:23 --> No URI present. Default controller set.
INFO - 2023-08-21 08:38:23 --> Router Class Initialized
INFO - 2023-08-21 08:38:23 --> Output Class Initialized
INFO - 2023-08-21 08:38:23 --> Security Class Initialized
DEBUG - 2023-08-21 08:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:38:23 --> Input Class Initialized
INFO - 2023-08-21 08:38:23 --> Language Class Initialized
INFO - 2023-08-21 08:38:23 --> Loader Class Initialized
INFO - 2023-08-21 08:38:23 --> Helper loaded: url_helper
INFO - 2023-08-21 08:38:23 --> Helper loaded: file_helper
INFO - 2023-08-21 08:38:23 --> Helper loaded: html_helper
INFO - 2023-08-21 08:38:23 --> Helper loaded: text_helper
INFO - 2023-08-21 08:38:23 --> Helper loaded: form_helper
INFO - 2023-08-21 08:38:23 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:38:23 --> Helper loaded: security_helper
INFO - 2023-08-21 08:38:23 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:38:23 --> Database Driver Class Initialized
INFO - 2023-08-21 08:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:38:23 --> Parser Class Initialized
INFO - 2023-08-21 08:38:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:38:23 --> Pagination Class Initialized
INFO - 2023-08-21 08:38:23 --> Form Validation Class Initialized
INFO - 2023-08-21 08:38:23 --> Controller Class Initialized
INFO - 2023-08-21 08:38:23 --> Model Class Initialized
DEBUG - 2023-08-21 08:38:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-21 08:41:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:41:24 --> Config Class Initialized
INFO - 2023-08-21 08:41:24 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:41:24 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:41:24 --> Utf8 Class Initialized
INFO - 2023-08-21 08:41:24 --> URI Class Initialized
INFO - 2023-08-21 08:41:24 --> Router Class Initialized
INFO - 2023-08-21 08:41:24 --> Output Class Initialized
INFO - 2023-08-21 08:41:24 --> Security Class Initialized
DEBUG - 2023-08-21 08:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:41:24 --> Input Class Initialized
INFO - 2023-08-21 08:41:24 --> Language Class Initialized
INFO - 2023-08-21 08:41:24 --> Loader Class Initialized
INFO - 2023-08-21 08:41:24 --> Helper loaded: url_helper
INFO - 2023-08-21 08:41:24 --> Helper loaded: file_helper
INFO - 2023-08-21 08:41:24 --> Helper loaded: html_helper
INFO - 2023-08-21 08:41:24 --> Helper loaded: text_helper
INFO - 2023-08-21 08:41:24 --> Helper loaded: form_helper
INFO - 2023-08-21 08:41:24 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:41:24 --> Helper loaded: security_helper
INFO - 2023-08-21 08:41:24 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:41:24 --> Database Driver Class Initialized
INFO - 2023-08-21 08:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:41:24 --> Parser Class Initialized
INFO - 2023-08-21 08:41:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:41:24 --> Pagination Class Initialized
INFO - 2023-08-21 08:41:24 --> Form Validation Class Initialized
INFO - 2023-08-21 08:41:24 --> Controller Class Initialized
INFO - 2023-08-21 08:41:24 --> Model Class Initialized
DEBUG - 2023-08-21 08:41:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:41:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:41:24 --> Model Class Initialized
DEBUG - 2023-08-21 08:41:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:41:24 --> Model Class Initialized
INFO - 2023-08-21 08:41:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-21 08:41:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:41:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 08:41:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 08:41:24 --> Model Class Initialized
INFO - 2023-08-21 08:41:24 --> Model Class Initialized
INFO - 2023-08-21 08:41:24 --> Model Class Initialized
INFO - 2023-08-21 08:41:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 08:41:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 08:41:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 08:41:24 --> Final output sent to browser
DEBUG - 2023-08-21 08:41:24 --> Total execution time: 0.0799
ERROR - 2023-08-21 08:41:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:41:25 --> Config Class Initialized
INFO - 2023-08-21 08:41:25 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:41:25 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:41:25 --> Utf8 Class Initialized
INFO - 2023-08-21 08:41:25 --> URI Class Initialized
INFO - 2023-08-21 08:41:25 --> Router Class Initialized
INFO - 2023-08-21 08:41:25 --> Output Class Initialized
INFO - 2023-08-21 08:41:25 --> Security Class Initialized
DEBUG - 2023-08-21 08:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:41:25 --> Input Class Initialized
INFO - 2023-08-21 08:41:25 --> Language Class Initialized
INFO - 2023-08-21 08:41:25 --> Loader Class Initialized
INFO - 2023-08-21 08:41:25 --> Helper loaded: url_helper
INFO - 2023-08-21 08:41:25 --> Helper loaded: file_helper
INFO - 2023-08-21 08:41:25 --> Helper loaded: html_helper
INFO - 2023-08-21 08:41:25 --> Helper loaded: text_helper
INFO - 2023-08-21 08:41:25 --> Helper loaded: form_helper
INFO - 2023-08-21 08:41:25 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:41:25 --> Helper loaded: security_helper
INFO - 2023-08-21 08:41:25 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:41:25 --> Database Driver Class Initialized
INFO - 2023-08-21 08:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:41:25 --> Parser Class Initialized
INFO - 2023-08-21 08:41:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:41:25 --> Pagination Class Initialized
INFO - 2023-08-21 08:41:25 --> Form Validation Class Initialized
INFO - 2023-08-21 08:41:25 --> Controller Class Initialized
INFO - 2023-08-21 08:41:25 --> Model Class Initialized
DEBUG - 2023-08-21 08:41:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:41:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:41:25 --> Model Class Initialized
DEBUG - 2023-08-21 08:41:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:41:25 --> Model Class Initialized
INFO - 2023-08-21 08:41:25 --> Final output sent to browser
DEBUG - 2023-08-21 08:41:25 --> Total execution time: 0.0408
ERROR - 2023-08-21 08:41:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:41:28 --> Config Class Initialized
INFO - 2023-08-21 08:41:28 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:41:28 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:41:28 --> Utf8 Class Initialized
INFO - 2023-08-21 08:41:28 --> URI Class Initialized
INFO - 2023-08-21 08:41:28 --> Router Class Initialized
INFO - 2023-08-21 08:41:28 --> Output Class Initialized
INFO - 2023-08-21 08:41:28 --> Security Class Initialized
DEBUG - 2023-08-21 08:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:41:28 --> Input Class Initialized
INFO - 2023-08-21 08:41:28 --> Language Class Initialized
INFO - 2023-08-21 08:41:28 --> Loader Class Initialized
INFO - 2023-08-21 08:41:28 --> Helper loaded: url_helper
INFO - 2023-08-21 08:41:28 --> Helper loaded: file_helper
INFO - 2023-08-21 08:41:28 --> Helper loaded: html_helper
INFO - 2023-08-21 08:41:28 --> Helper loaded: text_helper
INFO - 2023-08-21 08:41:28 --> Helper loaded: form_helper
INFO - 2023-08-21 08:41:28 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:41:28 --> Helper loaded: security_helper
INFO - 2023-08-21 08:41:28 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:41:28 --> Database Driver Class Initialized
INFO - 2023-08-21 08:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:41:28 --> Parser Class Initialized
INFO - 2023-08-21 08:41:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:41:28 --> Pagination Class Initialized
INFO - 2023-08-21 08:41:28 --> Form Validation Class Initialized
INFO - 2023-08-21 08:41:28 --> Controller Class Initialized
INFO - 2023-08-21 08:41:28 --> Model Class Initialized
DEBUG - 2023-08-21 08:41:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:41:28 --> Final output sent to browser
DEBUG - 2023-08-21 08:41:28 --> Total execution time: 0.0148
ERROR - 2023-08-21 08:41:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:41:28 --> Config Class Initialized
INFO - 2023-08-21 08:41:28 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:41:28 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:41:28 --> Utf8 Class Initialized
INFO - 2023-08-21 08:41:28 --> URI Class Initialized
INFO - 2023-08-21 08:41:28 --> Router Class Initialized
INFO - 2023-08-21 08:41:28 --> Output Class Initialized
INFO - 2023-08-21 08:41:28 --> Security Class Initialized
DEBUG - 2023-08-21 08:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:41:28 --> Input Class Initialized
INFO - 2023-08-21 08:41:28 --> Language Class Initialized
INFO - 2023-08-21 08:41:28 --> Loader Class Initialized
INFO - 2023-08-21 08:41:28 --> Helper loaded: url_helper
INFO - 2023-08-21 08:41:28 --> Helper loaded: file_helper
INFO - 2023-08-21 08:41:28 --> Helper loaded: html_helper
INFO - 2023-08-21 08:41:28 --> Helper loaded: text_helper
INFO - 2023-08-21 08:41:28 --> Helper loaded: form_helper
INFO - 2023-08-21 08:41:28 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:41:28 --> Helper loaded: security_helper
INFO - 2023-08-21 08:41:28 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:41:28 --> Database Driver Class Initialized
INFO - 2023-08-21 08:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:41:28 --> Parser Class Initialized
INFO - 2023-08-21 08:41:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:41:28 --> Pagination Class Initialized
INFO - 2023-08-21 08:41:28 --> Form Validation Class Initialized
INFO - 2023-08-21 08:41:28 --> Controller Class Initialized
INFO - 2023-08-21 08:41:28 --> Model Class Initialized
DEBUG - 2023-08-21 08:41:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:41:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-21 08:41:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:41:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 08:41:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 08:41:28 --> Model Class Initialized
INFO - 2023-08-21 08:41:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 08:41:28 --> Final output sent to browser
DEBUG - 2023-08-21 08:41:28 --> Total execution time: 0.0281
ERROR - 2023-08-21 08:41:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:41:33 --> Config Class Initialized
INFO - 2023-08-21 08:41:33 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:41:33 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:41:33 --> Utf8 Class Initialized
INFO - 2023-08-21 08:41:33 --> URI Class Initialized
INFO - 2023-08-21 08:41:33 --> Router Class Initialized
INFO - 2023-08-21 08:41:33 --> Output Class Initialized
INFO - 2023-08-21 08:41:33 --> Security Class Initialized
DEBUG - 2023-08-21 08:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:41:33 --> Input Class Initialized
INFO - 2023-08-21 08:41:33 --> Language Class Initialized
INFO - 2023-08-21 08:41:33 --> Loader Class Initialized
INFO - 2023-08-21 08:41:33 --> Helper loaded: url_helper
INFO - 2023-08-21 08:41:33 --> Helper loaded: file_helper
INFO - 2023-08-21 08:41:33 --> Helper loaded: html_helper
INFO - 2023-08-21 08:41:33 --> Helper loaded: text_helper
INFO - 2023-08-21 08:41:33 --> Helper loaded: form_helper
INFO - 2023-08-21 08:41:33 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:41:33 --> Helper loaded: security_helper
INFO - 2023-08-21 08:41:33 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:41:33 --> Database Driver Class Initialized
INFO - 2023-08-21 08:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:41:33 --> Parser Class Initialized
INFO - 2023-08-21 08:41:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:41:33 --> Pagination Class Initialized
INFO - 2023-08-21 08:41:33 --> Form Validation Class Initialized
INFO - 2023-08-21 08:41:33 --> Controller Class Initialized
INFO - 2023-08-21 08:41:33 --> Model Class Initialized
DEBUG - 2023-08-21 08:41:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:41:33 --> Model Class Initialized
INFO - 2023-08-21 08:41:33 --> Final output sent to browser
DEBUG - 2023-08-21 08:41:33 --> Total execution time: 0.0162
ERROR - 2023-08-21 08:41:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:41:34 --> Config Class Initialized
INFO - 2023-08-21 08:41:34 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:41:34 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:41:34 --> Utf8 Class Initialized
INFO - 2023-08-21 08:41:34 --> URI Class Initialized
DEBUG - 2023-08-21 08:41:34 --> No URI present. Default controller set.
INFO - 2023-08-21 08:41:34 --> Router Class Initialized
INFO - 2023-08-21 08:41:34 --> Output Class Initialized
INFO - 2023-08-21 08:41:34 --> Security Class Initialized
DEBUG - 2023-08-21 08:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:41:34 --> Input Class Initialized
INFO - 2023-08-21 08:41:34 --> Language Class Initialized
INFO - 2023-08-21 08:41:34 --> Loader Class Initialized
INFO - 2023-08-21 08:41:34 --> Helper loaded: url_helper
INFO - 2023-08-21 08:41:34 --> Helper loaded: file_helper
INFO - 2023-08-21 08:41:34 --> Helper loaded: html_helper
INFO - 2023-08-21 08:41:34 --> Helper loaded: text_helper
INFO - 2023-08-21 08:41:34 --> Helper loaded: form_helper
INFO - 2023-08-21 08:41:34 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:41:34 --> Helper loaded: security_helper
INFO - 2023-08-21 08:41:34 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:41:34 --> Database Driver Class Initialized
INFO - 2023-08-21 08:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:41:34 --> Parser Class Initialized
INFO - 2023-08-21 08:41:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:41:34 --> Pagination Class Initialized
INFO - 2023-08-21 08:41:34 --> Form Validation Class Initialized
INFO - 2023-08-21 08:41:34 --> Controller Class Initialized
INFO - 2023-08-21 08:41:34 --> Model Class Initialized
DEBUG - 2023-08-21 08:41:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:41:34 --> Model Class Initialized
DEBUG - 2023-08-21 08:41:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:41:34 --> Model Class Initialized
INFO - 2023-08-21 08:41:34 --> Model Class Initialized
INFO - 2023-08-21 08:41:34 --> Model Class Initialized
INFO - 2023-08-21 08:41:34 --> Model Class Initialized
DEBUG - 2023-08-21 08:41:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:41:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:41:34 --> Model Class Initialized
INFO - 2023-08-21 08:41:34 --> Model Class Initialized
INFO - 2023-08-21 08:41:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-21 08:41:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:41:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 08:41:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 08:41:34 --> Model Class Initialized
INFO - 2023-08-21 08:41:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 08:41:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 08:41:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 08:41:34 --> Final output sent to browser
DEBUG - 2023-08-21 08:41:34 --> Total execution time: 0.0884
ERROR - 2023-08-21 08:41:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:41:37 --> Config Class Initialized
INFO - 2023-08-21 08:41:37 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:41:37 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:41:37 --> Utf8 Class Initialized
INFO - 2023-08-21 08:41:37 --> URI Class Initialized
INFO - 2023-08-21 08:41:37 --> Router Class Initialized
INFO - 2023-08-21 08:41:37 --> Output Class Initialized
INFO - 2023-08-21 08:41:37 --> Security Class Initialized
DEBUG - 2023-08-21 08:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:41:37 --> Input Class Initialized
INFO - 2023-08-21 08:41:37 --> Language Class Initialized
INFO - 2023-08-21 08:41:37 --> Loader Class Initialized
INFO - 2023-08-21 08:41:37 --> Helper loaded: url_helper
INFO - 2023-08-21 08:41:37 --> Helper loaded: file_helper
INFO - 2023-08-21 08:41:37 --> Helper loaded: html_helper
INFO - 2023-08-21 08:41:37 --> Helper loaded: text_helper
INFO - 2023-08-21 08:41:37 --> Helper loaded: form_helper
INFO - 2023-08-21 08:41:37 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:41:37 --> Helper loaded: security_helper
INFO - 2023-08-21 08:41:37 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:41:37 --> Database Driver Class Initialized
INFO - 2023-08-21 08:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:41:37 --> Parser Class Initialized
INFO - 2023-08-21 08:41:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:41:37 --> Pagination Class Initialized
INFO - 2023-08-21 08:41:37 --> Form Validation Class Initialized
INFO - 2023-08-21 08:41:37 --> Controller Class Initialized
INFO - 2023-08-21 08:41:37 --> Model Class Initialized
DEBUG - 2023-08-21 08:41:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:41:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:41:37 --> Model Class Initialized
DEBUG - 2023-08-21 08:41:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:41:37 --> Model Class Initialized
INFO - 2023-08-21 08:41:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-21 08:41:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:41:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 08:41:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 08:41:37 --> Model Class Initialized
INFO - 2023-08-21 08:41:37 --> Model Class Initialized
INFO - 2023-08-21 08:41:37 --> Model Class Initialized
INFO - 2023-08-21 08:41:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 08:41:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 08:41:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 08:41:37 --> Final output sent to browser
DEBUG - 2023-08-21 08:41:37 --> Total execution time: 0.0748
ERROR - 2023-08-21 08:41:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:41:38 --> Config Class Initialized
INFO - 2023-08-21 08:41:38 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:41:38 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:41:38 --> Utf8 Class Initialized
INFO - 2023-08-21 08:41:38 --> URI Class Initialized
INFO - 2023-08-21 08:41:38 --> Router Class Initialized
INFO - 2023-08-21 08:41:38 --> Output Class Initialized
INFO - 2023-08-21 08:41:38 --> Security Class Initialized
DEBUG - 2023-08-21 08:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:41:38 --> Input Class Initialized
INFO - 2023-08-21 08:41:38 --> Language Class Initialized
INFO - 2023-08-21 08:41:38 --> Loader Class Initialized
INFO - 2023-08-21 08:41:38 --> Helper loaded: url_helper
INFO - 2023-08-21 08:41:38 --> Helper loaded: file_helper
INFO - 2023-08-21 08:41:38 --> Helper loaded: html_helper
INFO - 2023-08-21 08:41:38 --> Helper loaded: text_helper
INFO - 2023-08-21 08:41:38 --> Helper loaded: form_helper
INFO - 2023-08-21 08:41:38 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:41:38 --> Helper loaded: security_helper
INFO - 2023-08-21 08:41:38 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:41:38 --> Database Driver Class Initialized
INFO - 2023-08-21 08:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:41:38 --> Parser Class Initialized
INFO - 2023-08-21 08:41:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:41:38 --> Pagination Class Initialized
INFO - 2023-08-21 08:41:38 --> Form Validation Class Initialized
INFO - 2023-08-21 08:41:38 --> Controller Class Initialized
INFO - 2023-08-21 08:41:38 --> Model Class Initialized
DEBUG - 2023-08-21 08:41:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:41:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:41:38 --> Model Class Initialized
DEBUG - 2023-08-21 08:41:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:41:38 --> Model Class Initialized
INFO - 2023-08-21 08:41:38 --> Final output sent to browser
DEBUG - 2023-08-21 08:41:38 --> Total execution time: 0.0389
ERROR - 2023-08-21 08:41:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:41:41 --> Config Class Initialized
INFO - 2023-08-21 08:41:41 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:41:41 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:41:41 --> Utf8 Class Initialized
INFO - 2023-08-21 08:41:41 --> URI Class Initialized
INFO - 2023-08-21 08:41:41 --> Router Class Initialized
INFO - 2023-08-21 08:41:41 --> Output Class Initialized
INFO - 2023-08-21 08:41:41 --> Security Class Initialized
DEBUG - 2023-08-21 08:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:41:41 --> Input Class Initialized
INFO - 2023-08-21 08:41:41 --> Language Class Initialized
INFO - 2023-08-21 08:41:41 --> Loader Class Initialized
INFO - 2023-08-21 08:41:41 --> Helper loaded: url_helper
INFO - 2023-08-21 08:41:41 --> Helper loaded: file_helper
INFO - 2023-08-21 08:41:41 --> Helper loaded: html_helper
INFO - 2023-08-21 08:41:41 --> Helper loaded: text_helper
INFO - 2023-08-21 08:41:41 --> Helper loaded: form_helper
INFO - 2023-08-21 08:41:41 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:41:41 --> Helper loaded: security_helper
INFO - 2023-08-21 08:41:41 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:41:41 --> Database Driver Class Initialized
INFO - 2023-08-21 08:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:41:41 --> Parser Class Initialized
INFO - 2023-08-21 08:41:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:41:41 --> Pagination Class Initialized
INFO - 2023-08-21 08:41:41 --> Form Validation Class Initialized
INFO - 2023-08-21 08:41:41 --> Controller Class Initialized
INFO - 2023-08-21 08:41:41 --> Model Class Initialized
DEBUG - 2023-08-21 08:41:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:41:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:41:41 --> Model Class Initialized
DEBUG - 2023-08-21 08:41:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:41:41 --> Model Class Initialized
INFO - 2023-08-21 08:41:41 --> Final output sent to browser
DEBUG - 2023-08-21 08:41:41 --> Total execution time: 0.0373
ERROR - 2023-08-21 08:41:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:41:42 --> Config Class Initialized
INFO - 2023-08-21 08:41:42 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:41:42 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:41:42 --> Utf8 Class Initialized
INFO - 2023-08-21 08:41:42 --> URI Class Initialized
INFO - 2023-08-21 08:41:42 --> Router Class Initialized
INFO - 2023-08-21 08:41:42 --> Output Class Initialized
INFO - 2023-08-21 08:41:42 --> Security Class Initialized
DEBUG - 2023-08-21 08:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:41:42 --> Input Class Initialized
INFO - 2023-08-21 08:41:42 --> Language Class Initialized
INFO - 2023-08-21 08:41:42 --> Loader Class Initialized
INFO - 2023-08-21 08:41:42 --> Helper loaded: url_helper
INFO - 2023-08-21 08:41:42 --> Helper loaded: file_helper
INFO - 2023-08-21 08:41:42 --> Helper loaded: html_helper
INFO - 2023-08-21 08:41:42 --> Helper loaded: text_helper
INFO - 2023-08-21 08:41:42 --> Helper loaded: form_helper
INFO - 2023-08-21 08:41:42 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:41:42 --> Helper loaded: security_helper
INFO - 2023-08-21 08:41:42 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:41:42 --> Database Driver Class Initialized
INFO - 2023-08-21 08:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:41:42 --> Parser Class Initialized
INFO - 2023-08-21 08:41:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:41:42 --> Pagination Class Initialized
INFO - 2023-08-21 08:41:42 --> Form Validation Class Initialized
INFO - 2023-08-21 08:41:42 --> Controller Class Initialized
INFO - 2023-08-21 08:41:42 --> Model Class Initialized
DEBUG - 2023-08-21 08:41:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:41:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:41:42 --> Model Class Initialized
DEBUG - 2023-08-21 08:41:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:41:42 --> Model Class Initialized
INFO - 2023-08-21 08:41:42 --> Final output sent to browser
DEBUG - 2023-08-21 08:41:42 --> Total execution time: 0.0312
ERROR - 2023-08-21 08:41:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:41:47 --> Config Class Initialized
INFO - 2023-08-21 08:41:47 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:41:47 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:41:47 --> Utf8 Class Initialized
INFO - 2023-08-21 08:41:47 --> URI Class Initialized
INFO - 2023-08-21 08:41:47 --> Router Class Initialized
INFO - 2023-08-21 08:41:47 --> Output Class Initialized
INFO - 2023-08-21 08:41:47 --> Security Class Initialized
DEBUG - 2023-08-21 08:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:41:47 --> Input Class Initialized
INFO - 2023-08-21 08:41:47 --> Language Class Initialized
INFO - 2023-08-21 08:41:47 --> Loader Class Initialized
INFO - 2023-08-21 08:41:47 --> Helper loaded: url_helper
INFO - 2023-08-21 08:41:47 --> Helper loaded: file_helper
INFO - 2023-08-21 08:41:47 --> Helper loaded: html_helper
INFO - 2023-08-21 08:41:47 --> Helper loaded: text_helper
INFO - 2023-08-21 08:41:47 --> Helper loaded: form_helper
INFO - 2023-08-21 08:41:47 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:41:47 --> Helper loaded: security_helper
INFO - 2023-08-21 08:41:47 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:41:47 --> Database Driver Class Initialized
INFO - 2023-08-21 08:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:41:47 --> Parser Class Initialized
INFO - 2023-08-21 08:41:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:41:47 --> Pagination Class Initialized
INFO - 2023-08-21 08:41:47 --> Form Validation Class Initialized
INFO - 2023-08-21 08:41:47 --> Controller Class Initialized
INFO - 2023-08-21 08:41:47 --> Model Class Initialized
DEBUG - 2023-08-21 08:41:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:41:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:41:47 --> Model Class Initialized
DEBUG - 2023-08-21 08:41:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:41:47 --> Model Class Initialized
DEBUG - 2023-08-21 08:41:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:41:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-21 08:41:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:41:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 08:41:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 08:41:47 --> Model Class Initialized
INFO - 2023-08-21 08:41:47 --> Model Class Initialized
INFO - 2023-08-21 08:41:47 --> Model Class Initialized
INFO - 2023-08-21 08:41:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 08:41:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 08:41:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 08:41:47 --> Final output sent to browser
DEBUG - 2023-08-21 08:41:47 --> Total execution time: 0.0847
ERROR - 2023-08-21 08:43:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:43:16 --> Config Class Initialized
INFO - 2023-08-21 08:43:16 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:43:16 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:43:16 --> Utf8 Class Initialized
INFO - 2023-08-21 08:43:16 --> URI Class Initialized
DEBUG - 2023-08-21 08:43:16 --> No URI present. Default controller set.
INFO - 2023-08-21 08:43:16 --> Router Class Initialized
INFO - 2023-08-21 08:43:16 --> Output Class Initialized
INFO - 2023-08-21 08:43:16 --> Security Class Initialized
DEBUG - 2023-08-21 08:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:43:16 --> Input Class Initialized
INFO - 2023-08-21 08:43:16 --> Language Class Initialized
INFO - 2023-08-21 08:43:16 --> Loader Class Initialized
INFO - 2023-08-21 08:43:16 --> Helper loaded: url_helper
INFO - 2023-08-21 08:43:16 --> Helper loaded: file_helper
INFO - 2023-08-21 08:43:16 --> Helper loaded: html_helper
INFO - 2023-08-21 08:43:16 --> Helper loaded: text_helper
INFO - 2023-08-21 08:43:16 --> Helper loaded: form_helper
INFO - 2023-08-21 08:43:16 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:43:16 --> Helper loaded: security_helper
INFO - 2023-08-21 08:43:16 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:43:16 --> Database Driver Class Initialized
INFO - 2023-08-21 08:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:43:16 --> Parser Class Initialized
INFO - 2023-08-21 08:43:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:43:16 --> Pagination Class Initialized
INFO - 2023-08-21 08:43:16 --> Form Validation Class Initialized
INFO - 2023-08-21 08:43:16 --> Controller Class Initialized
INFO - 2023-08-21 08:43:16 --> Model Class Initialized
DEBUG - 2023-08-21 08:43:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:43:16 --> Model Class Initialized
DEBUG - 2023-08-21 08:43:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:43:16 --> Model Class Initialized
INFO - 2023-08-21 08:43:16 --> Model Class Initialized
INFO - 2023-08-21 08:43:16 --> Model Class Initialized
INFO - 2023-08-21 08:43:16 --> Model Class Initialized
DEBUG - 2023-08-21 08:43:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:43:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:43:16 --> Model Class Initialized
INFO - 2023-08-21 08:43:16 --> Model Class Initialized
INFO - 2023-08-21 08:43:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-21 08:43:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:43:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 08:43:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 08:43:16 --> Model Class Initialized
INFO - 2023-08-21 08:43:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 08:43:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 08:43:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 08:43:16 --> Final output sent to browser
DEBUG - 2023-08-21 08:43:16 --> Total execution time: 0.0971
ERROR - 2023-08-21 08:43:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:43:23 --> Config Class Initialized
INFO - 2023-08-21 08:43:23 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:43:23 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:43:23 --> Utf8 Class Initialized
INFO - 2023-08-21 08:43:23 --> URI Class Initialized
INFO - 2023-08-21 08:43:23 --> Router Class Initialized
INFO - 2023-08-21 08:43:23 --> Output Class Initialized
INFO - 2023-08-21 08:43:23 --> Security Class Initialized
DEBUG - 2023-08-21 08:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:43:23 --> Input Class Initialized
INFO - 2023-08-21 08:43:23 --> Language Class Initialized
INFO - 2023-08-21 08:43:23 --> Loader Class Initialized
INFO - 2023-08-21 08:43:23 --> Helper loaded: url_helper
INFO - 2023-08-21 08:43:23 --> Helper loaded: file_helper
INFO - 2023-08-21 08:43:23 --> Helper loaded: html_helper
INFO - 2023-08-21 08:43:23 --> Helper loaded: text_helper
INFO - 2023-08-21 08:43:23 --> Helper loaded: form_helper
INFO - 2023-08-21 08:43:23 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:43:23 --> Helper loaded: security_helper
INFO - 2023-08-21 08:43:23 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:43:23 --> Database Driver Class Initialized
INFO - 2023-08-21 08:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:43:23 --> Parser Class Initialized
INFO - 2023-08-21 08:43:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:43:23 --> Pagination Class Initialized
INFO - 2023-08-21 08:43:23 --> Form Validation Class Initialized
INFO - 2023-08-21 08:43:23 --> Controller Class Initialized
INFO - 2023-08-21 08:43:23 --> Model Class Initialized
DEBUG - 2023-08-21 08:43:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:43:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:43:23 --> Model Class Initialized
DEBUG - 2023-08-21 08:43:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:43:23 --> Model Class Initialized
INFO - 2023-08-21 08:43:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-21 08:43:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:43:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 08:43:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 08:43:23 --> Model Class Initialized
INFO - 2023-08-21 08:43:23 --> Model Class Initialized
INFO - 2023-08-21 08:43:23 --> Model Class Initialized
INFO - 2023-08-21 08:43:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 08:43:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 08:43:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 08:43:23 --> Final output sent to browser
DEBUG - 2023-08-21 08:43:23 --> Total execution time: 0.0780
ERROR - 2023-08-21 08:43:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:43:24 --> Config Class Initialized
INFO - 2023-08-21 08:43:24 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:43:24 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:43:24 --> Utf8 Class Initialized
INFO - 2023-08-21 08:43:24 --> URI Class Initialized
INFO - 2023-08-21 08:43:24 --> Router Class Initialized
INFO - 2023-08-21 08:43:24 --> Output Class Initialized
INFO - 2023-08-21 08:43:24 --> Security Class Initialized
DEBUG - 2023-08-21 08:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:43:24 --> Input Class Initialized
INFO - 2023-08-21 08:43:24 --> Language Class Initialized
INFO - 2023-08-21 08:43:24 --> Loader Class Initialized
INFO - 2023-08-21 08:43:24 --> Helper loaded: url_helper
INFO - 2023-08-21 08:43:24 --> Helper loaded: file_helper
INFO - 2023-08-21 08:43:24 --> Helper loaded: html_helper
INFO - 2023-08-21 08:43:24 --> Helper loaded: text_helper
INFO - 2023-08-21 08:43:24 --> Helper loaded: form_helper
INFO - 2023-08-21 08:43:24 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:43:24 --> Helper loaded: security_helper
INFO - 2023-08-21 08:43:24 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:43:24 --> Database Driver Class Initialized
INFO - 2023-08-21 08:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:43:24 --> Parser Class Initialized
INFO - 2023-08-21 08:43:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:43:24 --> Pagination Class Initialized
INFO - 2023-08-21 08:43:24 --> Form Validation Class Initialized
INFO - 2023-08-21 08:43:24 --> Controller Class Initialized
INFO - 2023-08-21 08:43:24 --> Model Class Initialized
DEBUG - 2023-08-21 08:43:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:43:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:43:24 --> Model Class Initialized
DEBUG - 2023-08-21 08:43:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:43:24 --> Model Class Initialized
INFO - 2023-08-21 08:43:24 --> Final output sent to browser
DEBUG - 2023-08-21 08:43:24 --> Total execution time: 0.0386
ERROR - 2023-08-21 08:43:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:43:30 --> Config Class Initialized
INFO - 2023-08-21 08:43:30 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:43:30 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:43:30 --> Utf8 Class Initialized
INFO - 2023-08-21 08:43:30 --> URI Class Initialized
INFO - 2023-08-21 08:43:30 --> Router Class Initialized
INFO - 2023-08-21 08:43:30 --> Output Class Initialized
INFO - 2023-08-21 08:43:30 --> Security Class Initialized
DEBUG - 2023-08-21 08:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:43:30 --> Input Class Initialized
INFO - 2023-08-21 08:43:30 --> Language Class Initialized
INFO - 2023-08-21 08:43:30 --> Loader Class Initialized
INFO - 2023-08-21 08:43:30 --> Helper loaded: url_helper
INFO - 2023-08-21 08:43:30 --> Helper loaded: file_helper
INFO - 2023-08-21 08:43:30 --> Helper loaded: html_helper
INFO - 2023-08-21 08:43:30 --> Helper loaded: text_helper
INFO - 2023-08-21 08:43:30 --> Helper loaded: form_helper
INFO - 2023-08-21 08:43:30 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:43:30 --> Helper loaded: security_helper
INFO - 2023-08-21 08:43:30 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:43:30 --> Database Driver Class Initialized
INFO - 2023-08-21 08:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:43:30 --> Parser Class Initialized
INFO - 2023-08-21 08:43:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:43:30 --> Pagination Class Initialized
INFO - 2023-08-21 08:43:30 --> Form Validation Class Initialized
INFO - 2023-08-21 08:43:30 --> Controller Class Initialized
INFO - 2023-08-21 08:43:30 --> Model Class Initialized
DEBUG - 2023-08-21 08:43:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:43:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:43:30 --> Model Class Initialized
DEBUG - 2023-08-21 08:43:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:43:30 --> Model Class Initialized
INFO - 2023-08-21 08:43:30 --> Final output sent to browser
DEBUG - 2023-08-21 08:43:30 --> Total execution time: 0.0980
ERROR - 2023-08-21 08:50:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:50:49 --> Config Class Initialized
INFO - 2023-08-21 08:50:49 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:50:49 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:50:49 --> Utf8 Class Initialized
INFO - 2023-08-21 08:50:49 --> URI Class Initialized
DEBUG - 2023-08-21 08:50:49 --> No URI present. Default controller set.
INFO - 2023-08-21 08:50:49 --> Router Class Initialized
INFO - 2023-08-21 08:50:49 --> Output Class Initialized
INFO - 2023-08-21 08:50:49 --> Security Class Initialized
DEBUG - 2023-08-21 08:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:50:49 --> Input Class Initialized
INFO - 2023-08-21 08:50:49 --> Language Class Initialized
INFO - 2023-08-21 08:50:49 --> Loader Class Initialized
INFO - 2023-08-21 08:50:49 --> Helper loaded: url_helper
INFO - 2023-08-21 08:50:49 --> Helper loaded: file_helper
INFO - 2023-08-21 08:50:49 --> Helper loaded: html_helper
INFO - 2023-08-21 08:50:49 --> Helper loaded: text_helper
INFO - 2023-08-21 08:50:49 --> Helper loaded: form_helper
INFO - 2023-08-21 08:50:49 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:50:49 --> Helper loaded: security_helper
INFO - 2023-08-21 08:50:49 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:50:49 --> Database Driver Class Initialized
INFO - 2023-08-21 08:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:50:49 --> Parser Class Initialized
INFO - 2023-08-21 08:50:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:50:49 --> Pagination Class Initialized
INFO - 2023-08-21 08:50:49 --> Form Validation Class Initialized
INFO - 2023-08-21 08:50:49 --> Controller Class Initialized
INFO - 2023-08-21 08:50:49 --> Model Class Initialized
DEBUG - 2023-08-21 08:50:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-21 08:50:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:50:50 --> Config Class Initialized
INFO - 2023-08-21 08:50:50 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:50:50 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:50:50 --> Utf8 Class Initialized
INFO - 2023-08-21 08:50:50 --> URI Class Initialized
INFO - 2023-08-21 08:50:50 --> Router Class Initialized
INFO - 2023-08-21 08:50:50 --> Output Class Initialized
INFO - 2023-08-21 08:50:50 --> Security Class Initialized
DEBUG - 2023-08-21 08:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:50:50 --> Input Class Initialized
INFO - 2023-08-21 08:50:50 --> Language Class Initialized
INFO - 2023-08-21 08:50:50 --> Loader Class Initialized
INFO - 2023-08-21 08:50:50 --> Helper loaded: url_helper
INFO - 2023-08-21 08:50:50 --> Helper loaded: file_helper
INFO - 2023-08-21 08:50:50 --> Helper loaded: html_helper
INFO - 2023-08-21 08:50:50 --> Helper loaded: text_helper
INFO - 2023-08-21 08:50:50 --> Helper loaded: form_helper
INFO - 2023-08-21 08:50:50 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:50:50 --> Helper loaded: security_helper
INFO - 2023-08-21 08:50:50 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:50:50 --> Database Driver Class Initialized
INFO - 2023-08-21 08:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:50:50 --> Parser Class Initialized
INFO - 2023-08-21 08:50:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:50:50 --> Pagination Class Initialized
INFO - 2023-08-21 08:50:50 --> Form Validation Class Initialized
INFO - 2023-08-21 08:50:50 --> Controller Class Initialized
INFO - 2023-08-21 08:50:50 --> Model Class Initialized
DEBUG - 2023-08-21 08:50:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:50:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-21 08:50:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:50:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 08:50:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 08:50:50 --> Model Class Initialized
INFO - 2023-08-21 08:50:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 08:50:50 --> Final output sent to browser
DEBUG - 2023-08-21 08:50:50 --> Total execution time: 0.0310
ERROR - 2023-08-21 08:51:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:51:03 --> Config Class Initialized
INFO - 2023-08-21 08:51:03 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:51:03 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:51:03 --> Utf8 Class Initialized
INFO - 2023-08-21 08:51:03 --> URI Class Initialized
INFO - 2023-08-21 08:51:03 --> Router Class Initialized
INFO - 2023-08-21 08:51:03 --> Output Class Initialized
INFO - 2023-08-21 08:51:03 --> Security Class Initialized
DEBUG - 2023-08-21 08:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:51:03 --> Input Class Initialized
INFO - 2023-08-21 08:51:03 --> Language Class Initialized
INFO - 2023-08-21 08:51:03 --> Loader Class Initialized
INFO - 2023-08-21 08:51:03 --> Helper loaded: url_helper
INFO - 2023-08-21 08:51:03 --> Helper loaded: file_helper
INFO - 2023-08-21 08:51:03 --> Helper loaded: html_helper
INFO - 2023-08-21 08:51:03 --> Helper loaded: text_helper
INFO - 2023-08-21 08:51:03 --> Helper loaded: form_helper
INFO - 2023-08-21 08:51:03 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:51:03 --> Helper loaded: security_helper
INFO - 2023-08-21 08:51:03 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:51:03 --> Database Driver Class Initialized
INFO - 2023-08-21 08:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:51:03 --> Parser Class Initialized
INFO - 2023-08-21 08:51:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:51:03 --> Pagination Class Initialized
INFO - 2023-08-21 08:51:03 --> Form Validation Class Initialized
INFO - 2023-08-21 08:51:03 --> Controller Class Initialized
INFO - 2023-08-21 08:51:03 --> Model Class Initialized
DEBUG - 2023-08-21 08:51:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:51:03 --> Model Class Initialized
INFO - 2023-08-21 08:51:03 --> Final output sent to browser
DEBUG - 2023-08-21 08:51:03 --> Total execution time: 0.0195
ERROR - 2023-08-21 08:51:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:51:03 --> Config Class Initialized
INFO - 2023-08-21 08:51:03 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:51:03 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:51:03 --> Utf8 Class Initialized
INFO - 2023-08-21 08:51:03 --> URI Class Initialized
DEBUG - 2023-08-21 08:51:03 --> No URI present. Default controller set.
INFO - 2023-08-21 08:51:03 --> Router Class Initialized
INFO - 2023-08-21 08:51:03 --> Output Class Initialized
INFO - 2023-08-21 08:51:03 --> Security Class Initialized
DEBUG - 2023-08-21 08:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:51:03 --> Input Class Initialized
INFO - 2023-08-21 08:51:03 --> Language Class Initialized
INFO - 2023-08-21 08:51:03 --> Loader Class Initialized
INFO - 2023-08-21 08:51:03 --> Helper loaded: url_helper
INFO - 2023-08-21 08:51:03 --> Helper loaded: file_helper
INFO - 2023-08-21 08:51:03 --> Helper loaded: html_helper
INFO - 2023-08-21 08:51:03 --> Helper loaded: text_helper
INFO - 2023-08-21 08:51:03 --> Helper loaded: form_helper
INFO - 2023-08-21 08:51:03 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:51:03 --> Helper loaded: security_helper
INFO - 2023-08-21 08:51:03 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:51:03 --> Database Driver Class Initialized
INFO - 2023-08-21 08:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:51:03 --> Parser Class Initialized
INFO - 2023-08-21 08:51:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:51:03 --> Pagination Class Initialized
INFO - 2023-08-21 08:51:03 --> Form Validation Class Initialized
INFO - 2023-08-21 08:51:03 --> Controller Class Initialized
INFO - 2023-08-21 08:51:03 --> Model Class Initialized
DEBUG - 2023-08-21 08:51:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:51:03 --> Model Class Initialized
DEBUG - 2023-08-21 08:51:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:51:03 --> Model Class Initialized
INFO - 2023-08-21 08:51:03 --> Model Class Initialized
INFO - 2023-08-21 08:51:03 --> Model Class Initialized
INFO - 2023-08-21 08:51:03 --> Model Class Initialized
DEBUG - 2023-08-21 08:51:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:51:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:51:03 --> Model Class Initialized
INFO - 2023-08-21 08:51:03 --> Model Class Initialized
INFO - 2023-08-21 08:51:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-21 08:51:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:51:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 08:51:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 08:51:03 --> Model Class Initialized
INFO - 2023-08-21 08:51:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 08:51:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 08:51:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 08:51:03 --> Final output sent to browser
DEBUG - 2023-08-21 08:51:03 --> Total execution time: 0.0930
ERROR - 2023-08-21 08:51:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:51:24 --> Config Class Initialized
INFO - 2023-08-21 08:51:24 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:51:24 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:51:24 --> Utf8 Class Initialized
INFO - 2023-08-21 08:51:24 --> URI Class Initialized
INFO - 2023-08-21 08:51:24 --> Router Class Initialized
INFO - 2023-08-21 08:51:24 --> Output Class Initialized
INFO - 2023-08-21 08:51:24 --> Security Class Initialized
DEBUG - 2023-08-21 08:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:51:24 --> Input Class Initialized
INFO - 2023-08-21 08:51:24 --> Language Class Initialized
INFO - 2023-08-21 08:51:24 --> Loader Class Initialized
INFO - 2023-08-21 08:51:24 --> Helper loaded: url_helper
INFO - 2023-08-21 08:51:24 --> Helper loaded: file_helper
INFO - 2023-08-21 08:51:24 --> Helper loaded: html_helper
INFO - 2023-08-21 08:51:24 --> Helper loaded: text_helper
INFO - 2023-08-21 08:51:24 --> Helper loaded: form_helper
INFO - 2023-08-21 08:51:24 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:51:24 --> Helper loaded: security_helper
INFO - 2023-08-21 08:51:24 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:51:24 --> Database Driver Class Initialized
INFO - 2023-08-21 08:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:51:24 --> Parser Class Initialized
INFO - 2023-08-21 08:51:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:51:24 --> Pagination Class Initialized
INFO - 2023-08-21 08:51:24 --> Form Validation Class Initialized
INFO - 2023-08-21 08:51:24 --> Controller Class Initialized
DEBUG - 2023-08-21 08:51:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:51:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:51:24 --> Model Class Initialized
DEBUG - 2023-08-21 08:51:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:51:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:51:24 --> Ltarget class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:51:24 --> Model Class Initialized
DEBUG - 2023-08-21 08:51:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:51:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:51:24 --> Model Class Initialized
DEBUG - 2023-08-21 08:51:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:51:24 --> Model Class Initialized
INFO - 2023-08-21 08:51:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/target/target.php
DEBUG - 2023-08-21 08:51:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:51:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 08:51:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 08:51:24 --> Model Class Initialized
INFO - 2023-08-21 08:51:24 --> Model Class Initialized
INFO - 2023-08-21 08:51:24 --> Model Class Initialized
INFO - 2023-08-21 08:51:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 08:51:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 08:51:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 08:51:24 --> Final output sent to browser
DEBUG - 2023-08-21 08:51:24 --> Total execution time: 0.0755
ERROR - 2023-08-21 08:51:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:51:25 --> Config Class Initialized
INFO - 2023-08-21 08:51:25 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:51:25 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:51:25 --> Utf8 Class Initialized
INFO - 2023-08-21 08:51:25 --> URI Class Initialized
INFO - 2023-08-21 08:51:25 --> Router Class Initialized
INFO - 2023-08-21 08:51:25 --> Output Class Initialized
INFO - 2023-08-21 08:51:25 --> Security Class Initialized
DEBUG - 2023-08-21 08:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:51:25 --> Input Class Initialized
INFO - 2023-08-21 08:51:25 --> Language Class Initialized
INFO - 2023-08-21 08:51:25 --> Loader Class Initialized
INFO - 2023-08-21 08:51:25 --> Helper loaded: url_helper
INFO - 2023-08-21 08:51:25 --> Helper loaded: file_helper
INFO - 2023-08-21 08:51:25 --> Helper loaded: html_helper
INFO - 2023-08-21 08:51:25 --> Helper loaded: text_helper
INFO - 2023-08-21 08:51:25 --> Helper loaded: form_helper
INFO - 2023-08-21 08:51:25 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:51:25 --> Helper loaded: security_helper
INFO - 2023-08-21 08:51:25 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:51:25 --> Database Driver Class Initialized
INFO - 2023-08-21 08:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:51:25 --> Parser Class Initialized
INFO - 2023-08-21 08:51:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:51:25 --> Pagination Class Initialized
INFO - 2023-08-21 08:51:25 --> Form Validation Class Initialized
INFO - 2023-08-21 08:51:25 --> Controller Class Initialized
DEBUG - 2023-08-21 08:51:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:51:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:51:25 --> Model Class Initialized
DEBUG - 2023-08-21 08:51:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:51:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:51:25 --> Model Class Initialized
DEBUG - 2023-08-21 08:51:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:51:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:51:25 --> Model Class Initialized
DEBUG - 2023-08-21 08:51:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:51:25 --> Model Class Initialized
INFO - 2023-08-21 08:51:25 --> Final output sent to browser
DEBUG - 2023-08-21 08:51:25 --> Total execution time: 0.0200
ERROR - 2023-08-21 08:52:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:52:19 --> Config Class Initialized
INFO - 2023-08-21 08:52:19 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:52:19 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:52:19 --> Utf8 Class Initialized
INFO - 2023-08-21 08:52:19 --> URI Class Initialized
DEBUG - 2023-08-21 08:52:19 --> No URI present. Default controller set.
INFO - 2023-08-21 08:52:19 --> Router Class Initialized
INFO - 2023-08-21 08:52:19 --> Output Class Initialized
INFO - 2023-08-21 08:52:19 --> Security Class Initialized
DEBUG - 2023-08-21 08:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:52:19 --> Input Class Initialized
INFO - 2023-08-21 08:52:19 --> Language Class Initialized
INFO - 2023-08-21 08:52:19 --> Loader Class Initialized
INFO - 2023-08-21 08:52:19 --> Helper loaded: url_helper
INFO - 2023-08-21 08:52:19 --> Helper loaded: file_helper
INFO - 2023-08-21 08:52:19 --> Helper loaded: html_helper
INFO - 2023-08-21 08:52:19 --> Helper loaded: text_helper
INFO - 2023-08-21 08:52:19 --> Helper loaded: form_helper
INFO - 2023-08-21 08:52:19 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:52:19 --> Helper loaded: security_helper
INFO - 2023-08-21 08:52:19 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:52:19 --> Database Driver Class Initialized
INFO - 2023-08-21 08:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:52:19 --> Parser Class Initialized
INFO - 2023-08-21 08:52:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:52:19 --> Pagination Class Initialized
INFO - 2023-08-21 08:52:19 --> Form Validation Class Initialized
INFO - 2023-08-21 08:52:19 --> Controller Class Initialized
INFO - 2023-08-21 08:52:19 --> Model Class Initialized
DEBUG - 2023-08-21 08:52:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:52:19 --> Model Class Initialized
DEBUG - 2023-08-21 08:52:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:52:19 --> Model Class Initialized
INFO - 2023-08-21 08:52:19 --> Model Class Initialized
INFO - 2023-08-21 08:52:19 --> Model Class Initialized
INFO - 2023-08-21 08:52:19 --> Model Class Initialized
DEBUG - 2023-08-21 08:52:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:52:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:52:19 --> Model Class Initialized
INFO - 2023-08-21 08:52:19 --> Model Class Initialized
INFO - 2023-08-21 08:52:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-21 08:52:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:52:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 08:52:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 08:52:19 --> Model Class Initialized
INFO - 2023-08-21 08:52:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 08:52:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 08:52:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 08:52:19 --> Final output sent to browser
DEBUG - 2023-08-21 08:52:19 --> Total execution time: 0.1022
ERROR - 2023-08-21 08:52:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:52:27 --> Config Class Initialized
INFO - 2023-08-21 08:52:27 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:52:27 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:52:27 --> Utf8 Class Initialized
INFO - 2023-08-21 08:52:27 --> URI Class Initialized
INFO - 2023-08-21 08:52:27 --> Router Class Initialized
INFO - 2023-08-21 08:52:27 --> Output Class Initialized
INFO - 2023-08-21 08:52:27 --> Security Class Initialized
DEBUG - 2023-08-21 08:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:52:27 --> Input Class Initialized
INFO - 2023-08-21 08:52:27 --> Language Class Initialized
INFO - 2023-08-21 08:52:27 --> Loader Class Initialized
INFO - 2023-08-21 08:52:27 --> Helper loaded: url_helper
INFO - 2023-08-21 08:52:27 --> Helper loaded: file_helper
INFO - 2023-08-21 08:52:27 --> Helper loaded: html_helper
INFO - 2023-08-21 08:52:27 --> Helper loaded: text_helper
INFO - 2023-08-21 08:52:27 --> Helper loaded: form_helper
INFO - 2023-08-21 08:52:27 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:52:27 --> Helper loaded: security_helper
INFO - 2023-08-21 08:52:27 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:52:27 --> Database Driver Class Initialized
INFO - 2023-08-21 08:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:52:27 --> Parser Class Initialized
INFO - 2023-08-21 08:52:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:52:27 --> Pagination Class Initialized
INFO - 2023-08-21 08:52:27 --> Form Validation Class Initialized
INFO - 2023-08-21 08:52:27 --> Controller Class Initialized
INFO - 2023-08-21 08:52:27 --> Model Class Initialized
DEBUG - 2023-08-21 08:52:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:52:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:52:27 --> Model Class Initialized
DEBUG - 2023-08-21 08:52:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:52:27 --> Model Class Initialized
INFO - 2023-08-21 08:52:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-21 08:52:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:52:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 08:52:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 08:52:27 --> Model Class Initialized
INFO - 2023-08-21 08:52:27 --> Model Class Initialized
INFO - 2023-08-21 08:52:27 --> Model Class Initialized
INFO - 2023-08-21 08:52:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 08:52:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 08:52:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 08:52:27 --> Final output sent to browser
DEBUG - 2023-08-21 08:52:27 --> Total execution time: 0.0745
ERROR - 2023-08-21 08:52:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:52:27 --> Config Class Initialized
INFO - 2023-08-21 08:52:27 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:52:27 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:52:27 --> Utf8 Class Initialized
INFO - 2023-08-21 08:52:27 --> URI Class Initialized
INFO - 2023-08-21 08:52:27 --> Router Class Initialized
INFO - 2023-08-21 08:52:27 --> Output Class Initialized
INFO - 2023-08-21 08:52:27 --> Security Class Initialized
DEBUG - 2023-08-21 08:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:52:27 --> Input Class Initialized
INFO - 2023-08-21 08:52:27 --> Language Class Initialized
INFO - 2023-08-21 08:52:27 --> Loader Class Initialized
INFO - 2023-08-21 08:52:27 --> Helper loaded: url_helper
INFO - 2023-08-21 08:52:27 --> Helper loaded: file_helper
INFO - 2023-08-21 08:52:27 --> Helper loaded: html_helper
INFO - 2023-08-21 08:52:27 --> Helper loaded: text_helper
INFO - 2023-08-21 08:52:27 --> Helper loaded: form_helper
INFO - 2023-08-21 08:52:27 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:52:27 --> Helper loaded: security_helper
INFO - 2023-08-21 08:52:27 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:52:27 --> Database Driver Class Initialized
INFO - 2023-08-21 08:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:52:27 --> Parser Class Initialized
INFO - 2023-08-21 08:52:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:52:27 --> Pagination Class Initialized
INFO - 2023-08-21 08:52:27 --> Form Validation Class Initialized
INFO - 2023-08-21 08:52:27 --> Controller Class Initialized
INFO - 2023-08-21 08:52:27 --> Model Class Initialized
DEBUG - 2023-08-21 08:52:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:52:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:52:27 --> Model Class Initialized
DEBUG - 2023-08-21 08:52:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:52:27 --> Model Class Initialized
INFO - 2023-08-21 08:52:27 --> Final output sent to browser
DEBUG - 2023-08-21 08:52:27 --> Total execution time: 0.0367
ERROR - 2023-08-21 08:53:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:53:00 --> Config Class Initialized
INFO - 2023-08-21 08:53:00 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:53:00 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:53:00 --> Utf8 Class Initialized
INFO - 2023-08-21 08:53:00 --> URI Class Initialized
INFO - 2023-08-21 08:53:00 --> Router Class Initialized
INFO - 2023-08-21 08:53:00 --> Output Class Initialized
INFO - 2023-08-21 08:53:00 --> Security Class Initialized
DEBUG - 2023-08-21 08:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:53:00 --> Input Class Initialized
INFO - 2023-08-21 08:53:00 --> Language Class Initialized
INFO - 2023-08-21 08:53:00 --> Loader Class Initialized
INFO - 2023-08-21 08:53:00 --> Helper loaded: url_helper
INFO - 2023-08-21 08:53:00 --> Helper loaded: file_helper
INFO - 2023-08-21 08:53:00 --> Helper loaded: html_helper
INFO - 2023-08-21 08:53:00 --> Helper loaded: text_helper
INFO - 2023-08-21 08:53:00 --> Helper loaded: form_helper
INFO - 2023-08-21 08:53:00 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:53:00 --> Helper loaded: security_helper
INFO - 2023-08-21 08:53:00 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:53:00 --> Database Driver Class Initialized
INFO - 2023-08-21 08:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:53:00 --> Parser Class Initialized
INFO - 2023-08-21 08:53:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:53:00 --> Pagination Class Initialized
INFO - 2023-08-21 08:53:00 --> Form Validation Class Initialized
INFO - 2023-08-21 08:53:00 --> Controller Class Initialized
INFO - 2023-08-21 08:53:00 --> Model Class Initialized
DEBUG - 2023-08-21 08:53:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:53:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:53:00 --> Model Class Initialized
INFO - 2023-08-21 08:53:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-08-21 08:53:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:53:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 08:53:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 08:53:00 --> Model Class Initialized
INFO - 2023-08-21 08:53:00 --> Model Class Initialized
INFO - 2023-08-21 08:53:00 --> Model Class Initialized
INFO - 2023-08-21 08:53:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 08:53:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 08:53:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 08:53:00 --> Final output sent to browser
DEBUG - 2023-08-21 08:53:00 --> Total execution time: 0.0829
ERROR - 2023-08-21 08:53:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:53:02 --> Config Class Initialized
INFO - 2023-08-21 08:53:02 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:53:02 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:53:02 --> Utf8 Class Initialized
INFO - 2023-08-21 08:53:02 --> URI Class Initialized
INFO - 2023-08-21 08:53:02 --> Router Class Initialized
INFO - 2023-08-21 08:53:02 --> Output Class Initialized
INFO - 2023-08-21 08:53:02 --> Security Class Initialized
DEBUG - 2023-08-21 08:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:53:02 --> Input Class Initialized
INFO - 2023-08-21 08:53:02 --> Language Class Initialized
INFO - 2023-08-21 08:53:02 --> Loader Class Initialized
INFO - 2023-08-21 08:53:02 --> Helper loaded: url_helper
INFO - 2023-08-21 08:53:02 --> Helper loaded: file_helper
INFO - 2023-08-21 08:53:02 --> Helper loaded: html_helper
INFO - 2023-08-21 08:53:02 --> Helper loaded: text_helper
INFO - 2023-08-21 08:53:02 --> Helper loaded: form_helper
INFO - 2023-08-21 08:53:02 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:53:02 --> Helper loaded: security_helper
INFO - 2023-08-21 08:53:02 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:53:02 --> Database Driver Class Initialized
INFO - 2023-08-21 08:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:53:02 --> Parser Class Initialized
INFO - 2023-08-21 08:53:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:53:02 --> Pagination Class Initialized
INFO - 2023-08-21 08:53:02 --> Form Validation Class Initialized
INFO - 2023-08-21 08:53:02 --> Controller Class Initialized
INFO - 2023-08-21 08:53:02 --> Model Class Initialized
DEBUG - 2023-08-21 08:53:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:53:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:53:02 --> Model Class Initialized
INFO - 2023-08-21 08:53:02 --> Final output sent to browser
DEBUG - 2023-08-21 08:53:02 --> Total execution time: 0.0197
ERROR - 2023-08-21 08:53:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:53:16 --> Config Class Initialized
INFO - 2023-08-21 08:53:16 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:53:16 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:53:16 --> Utf8 Class Initialized
INFO - 2023-08-21 08:53:16 --> URI Class Initialized
INFO - 2023-08-21 08:53:16 --> Router Class Initialized
INFO - 2023-08-21 08:53:16 --> Output Class Initialized
INFO - 2023-08-21 08:53:16 --> Security Class Initialized
DEBUG - 2023-08-21 08:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:53:16 --> Input Class Initialized
INFO - 2023-08-21 08:53:16 --> Language Class Initialized
INFO - 2023-08-21 08:53:16 --> Loader Class Initialized
INFO - 2023-08-21 08:53:16 --> Helper loaded: url_helper
INFO - 2023-08-21 08:53:16 --> Helper loaded: file_helper
INFO - 2023-08-21 08:53:16 --> Helper loaded: html_helper
INFO - 2023-08-21 08:53:16 --> Helper loaded: text_helper
INFO - 2023-08-21 08:53:16 --> Helper loaded: form_helper
INFO - 2023-08-21 08:53:16 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:53:16 --> Helper loaded: security_helper
INFO - 2023-08-21 08:53:16 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:53:16 --> Database Driver Class Initialized
INFO - 2023-08-21 08:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:53:16 --> Parser Class Initialized
INFO - 2023-08-21 08:53:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:53:16 --> Pagination Class Initialized
INFO - 2023-08-21 08:53:16 --> Form Validation Class Initialized
INFO - 2023-08-21 08:53:16 --> Controller Class Initialized
INFO - 2023-08-21 08:53:16 --> Model Class Initialized
DEBUG - 2023-08-21 08:53:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:53:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:53:16 --> Model Class Initialized
INFO - 2023-08-21 08:53:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-08-21 08:53:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:53:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 08:53:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 08:53:16 --> Model Class Initialized
INFO - 2023-08-21 08:53:16 --> Model Class Initialized
INFO - 2023-08-21 08:53:16 --> Model Class Initialized
INFO - 2023-08-21 08:53:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 08:53:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 08:53:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 08:53:16 --> Final output sent to browser
DEBUG - 2023-08-21 08:53:16 --> Total execution time: 0.0778
ERROR - 2023-08-21 08:53:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:53:17 --> Config Class Initialized
INFO - 2023-08-21 08:53:17 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:53:17 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:53:17 --> Utf8 Class Initialized
INFO - 2023-08-21 08:53:17 --> URI Class Initialized
INFO - 2023-08-21 08:53:17 --> Router Class Initialized
INFO - 2023-08-21 08:53:17 --> Output Class Initialized
INFO - 2023-08-21 08:53:17 --> Security Class Initialized
DEBUG - 2023-08-21 08:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:53:17 --> Input Class Initialized
INFO - 2023-08-21 08:53:17 --> Language Class Initialized
INFO - 2023-08-21 08:53:17 --> Loader Class Initialized
INFO - 2023-08-21 08:53:17 --> Helper loaded: url_helper
INFO - 2023-08-21 08:53:17 --> Helper loaded: file_helper
INFO - 2023-08-21 08:53:17 --> Helper loaded: html_helper
INFO - 2023-08-21 08:53:17 --> Helper loaded: text_helper
INFO - 2023-08-21 08:53:17 --> Helper loaded: form_helper
INFO - 2023-08-21 08:53:17 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:53:17 --> Helper loaded: security_helper
INFO - 2023-08-21 08:53:17 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:53:17 --> Database Driver Class Initialized
INFO - 2023-08-21 08:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:53:17 --> Parser Class Initialized
INFO - 2023-08-21 08:53:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:53:17 --> Pagination Class Initialized
INFO - 2023-08-21 08:53:17 --> Form Validation Class Initialized
INFO - 2023-08-21 08:53:17 --> Controller Class Initialized
INFO - 2023-08-21 08:53:17 --> Model Class Initialized
DEBUG - 2023-08-21 08:53:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:53:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:53:17 --> Model Class Initialized
INFO - 2023-08-21 08:53:17 --> Final output sent to browser
DEBUG - 2023-08-21 08:53:17 --> Total execution time: 0.0275
ERROR - 2023-08-21 08:53:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:53:31 --> Config Class Initialized
INFO - 2023-08-21 08:53:31 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:53:31 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:53:31 --> Utf8 Class Initialized
INFO - 2023-08-21 08:53:31 --> URI Class Initialized
INFO - 2023-08-21 08:53:31 --> Router Class Initialized
INFO - 2023-08-21 08:53:31 --> Output Class Initialized
INFO - 2023-08-21 08:53:31 --> Security Class Initialized
DEBUG - 2023-08-21 08:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:53:31 --> Input Class Initialized
INFO - 2023-08-21 08:53:31 --> Language Class Initialized
INFO - 2023-08-21 08:53:31 --> Loader Class Initialized
INFO - 2023-08-21 08:53:31 --> Helper loaded: url_helper
INFO - 2023-08-21 08:53:31 --> Helper loaded: file_helper
INFO - 2023-08-21 08:53:31 --> Helper loaded: html_helper
INFO - 2023-08-21 08:53:31 --> Helper loaded: text_helper
INFO - 2023-08-21 08:53:31 --> Helper loaded: form_helper
INFO - 2023-08-21 08:53:31 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:53:31 --> Helper loaded: security_helper
INFO - 2023-08-21 08:53:31 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:53:31 --> Database Driver Class Initialized
INFO - 2023-08-21 08:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:53:31 --> Parser Class Initialized
INFO - 2023-08-21 08:53:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:53:31 --> Pagination Class Initialized
INFO - 2023-08-21 08:53:31 --> Form Validation Class Initialized
INFO - 2023-08-21 08:53:31 --> Controller Class Initialized
INFO - 2023-08-21 08:53:31 --> Model Class Initialized
DEBUG - 2023-08-21 08:53:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:53:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:53:31 --> Model Class Initialized
INFO - 2023-08-21 08:53:31 --> Final output sent to browser
DEBUG - 2023-08-21 08:53:31 --> Total execution time: 0.0322
ERROR - 2023-08-21 08:53:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:53:37 --> Config Class Initialized
INFO - 2023-08-21 08:53:37 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:53:37 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:53:37 --> Utf8 Class Initialized
INFO - 2023-08-21 08:53:37 --> URI Class Initialized
INFO - 2023-08-21 08:53:37 --> Router Class Initialized
INFO - 2023-08-21 08:53:37 --> Output Class Initialized
INFO - 2023-08-21 08:53:37 --> Security Class Initialized
DEBUG - 2023-08-21 08:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:53:37 --> Input Class Initialized
INFO - 2023-08-21 08:53:37 --> Language Class Initialized
INFO - 2023-08-21 08:53:37 --> Loader Class Initialized
INFO - 2023-08-21 08:53:37 --> Helper loaded: url_helper
INFO - 2023-08-21 08:53:37 --> Helper loaded: file_helper
INFO - 2023-08-21 08:53:37 --> Helper loaded: html_helper
INFO - 2023-08-21 08:53:37 --> Helper loaded: text_helper
INFO - 2023-08-21 08:53:37 --> Helper loaded: form_helper
INFO - 2023-08-21 08:53:37 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:53:37 --> Helper loaded: security_helper
INFO - 2023-08-21 08:53:37 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:53:37 --> Database Driver Class Initialized
INFO - 2023-08-21 08:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:53:37 --> Parser Class Initialized
INFO - 2023-08-21 08:53:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:53:37 --> Pagination Class Initialized
INFO - 2023-08-21 08:53:37 --> Form Validation Class Initialized
INFO - 2023-08-21 08:53:37 --> Controller Class Initialized
INFO - 2023-08-21 08:53:37 --> Model Class Initialized
DEBUG - 2023-08-21 08:53:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:53:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:53:37 --> Model Class Initialized
INFO - 2023-08-21 08:53:37 --> Final output sent to browser
DEBUG - 2023-08-21 08:53:37 --> Total execution time: 0.0293
ERROR - 2023-08-21 08:54:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:54:00 --> Config Class Initialized
INFO - 2023-08-21 08:54:00 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:54:00 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:54:00 --> Utf8 Class Initialized
INFO - 2023-08-21 08:54:00 --> URI Class Initialized
INFO - 2023-08-21 08:54:00 --> Router Class Initialized
INFO - 2023-08-21 08:54:00 --> Output Class Initialized
INFO - 2023-08-21 08:54:00 --> Security Class Initialized
DEBUG - 2023-08-21 08:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:54:00 --> Input Class Initialized
INFO - 2023-08-21 08:54:00 --> Language Class Initialized
INFO - 2023-08-21 08:54:00 --> Loader Class Initialized
INFO - 2023-08-21 08:54:00 --> Helper loaded: url_helper
INFO - 2023-08-21 08:54:00 --> Helper loaded: file_helper
INFO - 2023-08-21 08:54:00 --> Helper loaded: html_helper
INFO - 2023-08-21 08:54:00 --> Helper loaded: text_helper
INFO - 2023-08-21 08:54:00 --> Helper loaded: form_helper
INFO - 2023-08-21 08:54:00 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:54:00 --> Helper loaded: security_helper
INFO - 2023-08-21 08:54:00 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:54:00 --> Database Driver Class Initialized
INFO - 2023-08-21 08:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:54:00 --> Parser Class Initialized
INFO - 2023-08-21 08:54:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:54:00 --> Pagination Class Initialized
INFO - 2023-08-21 08:54:00 --> Form Validation Class Initialized
INFO - 2023-08-21 08:54:00 --> Controller Class Initialized
INFO - 2023-08-21 08:54:00 --> Model Class Initialized
DEBUG - 2023-08-21 08:54:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:54:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:54:00 --> Model Class Initialized
INFO - 2023-08-21 08:54:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-08-21 08:54:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:54:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 08:54:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 08:54:00 --> Model Class Initialized
INFO - 2023-08-21 08:54:00 --> Model Class Initialized
INFO - 2023-08-21 08:54:00 --> Model Class Initialized
INFO - 2023-08-21 08:54:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 08:54:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 08:54:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 08:54:00 --> Final output sent to browser
DEBUG - 2023-08-21 08:54:00 --> Total execution time: 0.1102
ERROR - 2023-08-21 08:54:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:54:01 --> Config Class Initialized
INFO - 2023-08-21 08:54:01 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:54:01 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:54:01 --> Utf8 Class Initialized
INFO - 2023-08-21 08:54:01 --> URI Class Initialized
INFO - 2023-08-21 08:54:01 --> Router Class Initialized
INFO - 2023-08-21 08:54:01 --> Output Class Initialized
INFO - 2023-08-21 08:54:01 --> Security Class Initialized
DEBUG - 2023-08-21 08:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:54:01 --> Input Class Initialized
INFO - 2023-08-21 08:54:01 --> Language Class Initialized
INFO - 2023-08-21 08:54:01 --> Loader Class Initialized
INFO - 2023-08-21 08:54:01 --> Helper loaded: url_helper
INFO - 2023-08-21 08:54:01 --> Helper loaded: file_helper
INFO - 2023-08-21 08:54:01 --> Helper loaded: html_helper
INFO - 2023-08-21 08:54:01 --> Helper loaded: text_helper
INFO - 2023-08-21 08:54:01 --> Helper loaded: form_helper
INFO - 2023-08-21 08:54:01 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:54:01 --> Helper loaded: security_helper
INFO - 2023-08-21 08:54:01 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:54:01 --> Database Driver Class Initialized
INFO - 2023-08-21 08:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:54:01 --> Parser Class Initialized
INFO - 2023-08-21 08:54:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:54:01 --> Pagination Class Initialized
INFO - 2023-08-21 08:54:01 --> Form Validation Class Initialized
INFO - 2023-08-21 08:54:01 --> Controller Class Initialized
INFO - 2023-08-21 08:54:01 --> Model Class Initialized
DEBUG - 2023-08-21 08:54:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:54:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:54:01 --> Model Class Initialized
INFO - 2023-08-21 08:54:01 --> Final output sent to browser
DEBUG - 2023-08-21 08:54:01 --> Total execution time: 0.0188
ERROR - 2023-08-21 08:54:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:54:05 --> Config Class Initialized
INFO - 2023-08-21 08:54:05 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:54:05 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:54:05 --> Utf8 Class Initialized
INFO - 2023-08-21 08:54:05 --> URI Class Initialized
INFO - 2023-08-21 08:54:05 --> Router Class Initialized
INFO - 2023-08-21 08:54:05 --> Output Class Initialized
INFO - 2023-08-21 08:54:05 --> Security Class Initialized
DEBUG - 2023-08-21 08:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:54:05 --> Input Class Initialized
INFO - 2023-08-21 08:54:05 --> Language Class Initialized
INFO - 2023-08-21 08:54:05 --> Loader Class Initialized
INFO - 2023-08-21 08:54:05 --> Helper loaded: url_helper
INFO - 2023-08-21 08:54:05 --> Helper loaded: file_helper
INFO - 2023-08-21 08:54:05 --> Helper loaded: html_helper
INFO - 2023-08-21 08:54:05 --> Helper loaded: text_helper
INFO - 2023-08-21 08:54:05 --> Helper loaded: form_helper
INFO - 2023-08-21 08:54:05 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:54:05 --> Helper loaded: security_helper
INFO - 2023-08-21 08:54:05 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:54:05 --> Database Driver Class Initialized
INFO - 2023-08-21 08:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:54:05 --> Parser Class Initialized
INFO - 2023-08-21 08:54:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:54:05 --> Pagination Class Initialized
INFO - 2023-08-21 08:54:05 --> Form Validation Class Initialized
INFO - 2023-08-21 08:54:05 --> Controller Class Initialized
INFO - 2023-08-21 08:54:05 --> Model Class Initialized
DEBUG - 2023-08-21 08:54:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:54:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:54:05 --> Model Class Initialized
DEBUG - 2023-08-21 08:54:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:54:05 --> Model Class Initialized
INFO - 2023-08-21 08:54:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-21 08:54:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:54:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 08:54:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 08:54:05 --> Model Class Initialized
INFO - 2023-08-21 08:54:05 --> Model Class Initialized
INFO - 2023-08-21 08:54:05 --> Model Class Initialized
INFO - 2023-08-21 08:54:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 08:54:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 08:54:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 08:54:05 --> Final output sent to browser
DEBUG - 2023-08-21 08:54:05 --> Total execution time: 0.0937
ERROR - 2023-08-21 08:54:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:54:06 --> Config Class Initialized
INFO - 2023-08-21 08:54:06 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:54:06 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:54:06 --> Utf8 Class Initialized
INFO - 2023-08-21 08:54:06 --> URI Class Initialized
INFO - 2023-08-21 08:54:06 --> Router Class Initialized
INFO - 2023-08-21 08:54:06 --> Output Class Initialized
INFO - 2023-08-21 08:54:06 --> Security Class Initialized
DEBUG - 2023-08-21 08:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:54:06 --> Input Class Initialized
INFO - 2023-08-21 08:54:06 --> Language Class Initialized
INFO - 2023-08-21 08:54:06 --> Loader Class Initialized
INFO - 2023-08-21 08:54:06 --> Helper loaded: url_helper
INFO - 2023-08-21 08:54:06 --> Helper loaded: file_helper
INFO - 2023-08-21 08:54:06 --> Helper loaded: html_helper
INFO - 2023-08-21 08:54:06 --> Helper loaded: text_helper
INFO - 2023-08-21 08:54:06 --> Helper loaded: form_helper
INFO - 2023-08-21 08:54:06 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:54:06 --> Helper loaded: security_helper
INFO - 2023-08-21 08:54:06 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:54:06 --> Database Driver Class Initialized
INFO - 2023-08-21 08:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:54:06 --> Parser Class Initialized
INFO - 2023-08-21 08:54:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:54:06 --> Pagination Class Initialized
INFO - 2023-08-21 08:54:06 --> Form Validation Class Initialized
INFO - 2023-08-21 08:54:06 --> Controller Class Initialized
INFO - 2023-08-21 08:54:06 --> Model Class Initialized
DEBUG - 2023-08-21 08:54:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:54:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:54:06 --> Model Class Initialized
DEBUG - 2023-08-21 08:54:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:54:06 --> Model Class Initialized
INFO - 2023-08-21 08:54:06 --> Final output sent to browser
DEBUG - 2023-08-21 08:54:06 --> Total execution time: 0.0413
ERROR - 2023-08-21 08:54:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:54:10 --> Config Class Initialized
INFO - 2023-08-21 08:54:10 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:54:10 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:54:10 --> Utf8 Class Initialized
INFO - 2023-08-21 08:54:10 --> URI Class Initialized
DEBUG - 2023-08-21 08:54:10 --> No URI present. Default controller set.
INFO - 2023-08-21 08:54:10 --> Router Class Initialized
INFO - 2023-08-21 08:54:10 --> Output Class Initialized
INFO - 2023-08-21 08:54:10 --> Security Class Initialized
DEBUG - 2023-08-21 08:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:54:10 --> Input Class Initialized
INFO - 2023-08-21 08:54:10 --> Language Class Initialized
INFO - 2023-08-21 08:54:10 --> Loader Class Initialized
INFO - 2023-08-21 08:54:10 --> Helper loaded: url_helper
INFO - 2023-08-21 08:54:10 --> Helper loaded: file_helper
INFO - 2023-08-21 08:54:10 --> Helper loaded: html_helper
INFO - 2023-08-21 08:54:10 --> Helper loaded: text_helper
INFO - 2023-08-21 08:54:10 --> Helper loaded: form_helper
INFO - 2023-08-21 08:54:10 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:54:10 --> Helper loaded: security_helper
INFO - 2023-08-21 08:54:10 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:54:10 --> Database Driver Class Initialized
INFO - 2023-08-21 08:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:54:10 --> Parser Class Initialized
INFO - 2023-08-21 08:54:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:54:10 --> Pagination Class Initialized
INFO - 2023-08-21 08:54:10 --> Form Validation Class Initialized
INFO - 2023-08-21 08:54:10 --> Controller Class Initialized
INFO - 2023-08-21 08:54:10 --> Model Class Initialized
DEBUG - 2023-08-21 08:54:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:54:10 --> Model Class Initialized
DEBUG - 2023-08-21 08:54:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:54:10 --> Model Class Initialized
INFO - 2023-08-21 08:54:10 --> Model Class Initialized
INFO - 2023-08-21 08:54:10 --> Model Class Initialized
INFO - 2023-08-21 08:54:10 --> Model Class Initialized
DEBUG - 2023-08-21 08:54:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:54:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:54:10 --> Model Class Initialized
INFO - 2023-08-21 08:54:10 --> Model Class Initialized
INFO - 2023-08-21 08:54:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-21 08:54:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:54:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 08:54:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 08:54:10 --> Model Class Initialized
INFO - 2023-08-21 08:54:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 08:54:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 08:54:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 08:54:10 --> Final output sent to browser
DEBUG - 2023-08-21 08:54:10 --> Total execution time: 0.0967
ERROR - 2023-08-21 08:54:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:54:27 --> Config Class Initialized
INFO - 2023-08-21 08:54:27 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:54:27 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:54:27 --> Utf8 Class Initialized
INFO - 2023-08-21 08:54:27 --> URI Class Initialized
INFO - 2023-08-21 08:54:27 --> Router Class Initialized
INFO - 2023-08-21 08:54:27 --> Output Class Initialized
INFO - 2023-08-21 08:54:27 --> Security Class Initialized
DEBUG - 2023-08-21 08:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:54:27 --> Input Class Initialized
INFO - 2023-08-21 08:54:27 --> Language Class Initialized
INFO - 2023-08-21 08:54:27 --> Loader Class Initialized
INFO - 2023-08-21 08:54:27 --> Helper loaded: url_helper
INFO - 2023-08-21 08:54:27 --> Helper loaded: file_helper
INFO - 2023-08-21 08:54:27 --> Helper loaded: html_helper
INFO - 2023-08-21 08:54:27 --> Helper loaded: text_helper
INFO - 2023-08-21 08:54:27 --> Helper loaded: form_helper
INFO - 2023-08-21 08:54:27 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:54:27 --> Helper loaded: security_helper
INFO - 2023-08-21 08:54:27 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:54:27 --> Database Driver Class Initialized
INFO - 2023-08-21 08:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:54:27 --> Parser Class Initialized
INFO - 2023-08-21 08:54:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:54:27 --> Pagination Class Initialized
INFO - 2023-08-21 08:54:27 --> Form Validation Class Initialized
INFO - 2023-08-21 08:54:27 --> Controller Class Initialized
INFO - 2023-08-21 08:54:27 --> Model Class Initialized
DEBUG - 2023-08-21 08:54:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:54:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:54:27 --> Model Class Initialized
DEBUG - 2023-08-21 08:54:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:54:27 --> Model Class Initialized
INFO - 2023-08-21 08:54:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-08-21 08:54:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:54:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 08:54:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 08:54:27 --> Model Class Initialized
INFO - 2023-08-21 08:54:27 --> Model Class Initialized
INFO - 2023-08-21 08:54:27 --> Model Class Initialized
INFO - 2023-08-21 08:54:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 08:54:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 08:54:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 08:54:27 --> Final output sent to browser
DEBUG - 2023-08-21 08:54:27 --> Total execution time: 0.0800
ERROR - 2023-08-21 08:54:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:54:28 --> Config Class Initialized
INFO - 2023-08-21 08:54:28 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:54:28 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:54:28 --> Utf8 Class Initialized
INFO - 2023-08-21 08:54:28 --> URI Class Initialized
INFO - 2023-08-21 08:54:28 --> Router Class Initialized
INFO - 2023-08-21 08:54:28 --> Output Class Initialized
INFO - 2023-08-21 08:54:28 --> Security Class Initialized
DEBUG - 2023-08-21 08:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:54:28 --> Input Class Initialized
INFO - 2023-08-21 08:54:28 --> Language Class Initialized
INFO - 2023-08-21 08:54:28 --> Loader Class Initialized
INFO - 2023-08-21 08:54:28 --> Helper loaded: url_helper
INFO - 2023-08-21 08:54:28 --> Helper loaded: file_helper
INFO - 2023-08-21 08:54:28 --> Helper loaded: html_helper
INFO - 2023-08-21 08:54:28 --> Helper loaded: text_helper
INFO - 2023-08-21 08:54:28 --> Helper loaded: form_helper
INFO - 2023-08-21 08:54:28 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:54:28 --> Helper loaded: security_helper
INFO - 2023-08-21 08:54:28 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:54:28 --> Database Driver Class Initialized
INFO - 2023-08-21 08:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:54:28 --> Parser Class Initialized
INFO - 2023-08-21 08:54:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:54:28 --> Pagination Class Initialized
INFO - 2023-08-21 08:54:28 --> Form Validation Class Initialized
INFO - 2023-08-21 08:54:28 --> Controller Class Initialized
INFO - 2023-08-21 08:54:28 --> Model Class Initialized
DEBUG - 2023-08-21 08:54:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:54:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:54:28 --> Model Class Initialized
DEBUG - 2023-08-21 08:54:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:54:28 --> Model Class Initialized
INFO - 2023-08-21 08:54:28 --> Final output sent to browser
DEBUG - 2023-08-21 08:54:28 --> Total execution time: 0.0485
ERROR - 2023-08-21 08:55:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 08:55:16 --> Config Class Initialized
INFO - 2023-08-21 08:55:16 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:55:16 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:55:16 --> Utf8 Class Initialized
INFO - 2023-08-21 08:55:16 --> URI Class Initialized
DEBUG - 2023-08-21 08:55:16 --> No URI present. Default controller set.
INFO - 2023-08-21 08:55:16 --> Router Class Initialized
INFO - 2023-08-21 08:55:16 --> Output Class Initialized
INFO - 2023-08-21 08:55:16 --> Security Class Initialized
DEBUG - 2023-08-21 08:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:55:16 --> Input Class Initialized
INFO - 2023-08-21 08:55:16 --> Language Class Initialized
INFO - 2023-08-21 08:55:16 --> Loader Class Initialized
INFO - 2023-08-21 08:55:16 --> Helper loaded: url_helper
INFO - 2023-08-21 08:55:16 --> Helper loaded: file_helper
INFO - 2023-08-21 08:55:16 --> Helper loaded: html_helper
INFO - 2023-08-21 08:55:16 --> Helper loaded: text_helper
INFO - 2023-08-21 08:55:16 --> Helper loaded: form_helper
INFO - 2023-08-21 08:55:16 --> Helper loaded: lang_helper
INFO - 2023-08-21 08:55:16 --> Helper loaded: security_helper
INFO - 2023-08-21 08:55:16 --> Helper loaded: cookie_helper
INFO - 2023-08-21 08:55:16 --> Database Driver Class Initialized
INFO - 2023-08-21 08:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:55:16 --> Parser Class Initialized
INFO - 2023-08-21 08:55:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 08:55:16 --> Pagination Class Initialized
INFO - 2023-08-21 08:55:16 --> Form Validation Class Initialized
INFO - 2023-08-21 08:55:16 --> Controller Class Initialized
INFO - 2023-08-21 08:55:16 --> Model Class Initialized
DEBUG - 2023-08-21 08:55:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:55:16 --> Model Class Initialized
DEBUG - 2023-08-21 08:55:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:55:16 --> Model Class Initialized
INFO - 2023-08-21 08:55:16 --> Model Class Initialized
INFO - 2023-08-21 08:55:16 --> Model Class Initialized
INFO - 2023-08-21 08:55:16 --> Model Class Initialized
DEBUG - 2023-08-21 08:55:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 08:55:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:55:16 --> Model Class Initialized
INFO - 2023-08-21 08:55:16 --> Model Class Initialized
INFO - 2023-08-21 08:55:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-21 08:55:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 08:55:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 08:55:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 08:55:16 --> Model Class Initialized
INFO - 2023-08-21 08:55:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 08:55:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 08:55:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 08:55:16 --> Final output sent to browser
DEBUG - 2023-08-21 08:55:16 --> Total execution time: 0.0964
ERROR - 2023-08-21 09:16:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 09:16:01 --> Config Class Initialized
INFO - 2023-08-21 09:16:01 --> Hooks Class Initialized
DEBUG - 2023-08-21 09:16:01 --> UTF-8 Support Enabled
INFO - 2023-08-21 09:16:01 --> Utf8 Class Initialized
INFO - 2023-08-21 09:16:01 --> URI Class Initialized
DEBUG - 2023-08-21 09:16:01 --> No URI present. Default controller set.
INFO - 2023-08-21 09:16:01 --> Router Class Initialized
INFO - 2023-08-21 09:16:01 --> Output Class Initialized
INFO - 2023-08-21 09:16:01 --> Security Class Initialized
DEBUG - 2023-08-21 09:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 09:16:01 --> Input Class Initialized
INFO - 2023-08-21 09:16:01 --> Language Class Initialized
INFO - 2023-08-21 09:16:01 --> Loader Class Initialized
INFO - 2023-08-21 09:16:01 --> Helper loaded: url_helper
INFO - 2023-08-21 09:16:01 --> Helper loaded: file_helper
INFO - 2023-08-21 09:16:01 --> Helper loaded: html_helper
INFO - 2023-08-21 09:16:01 --> Helper loaded: text_helper
INFO - 2023-08-21 09:16:01 --> Helper loaded: form_helper
INFO - 2023-08-21 09:16:01 --> Helper loaded: lang_helper
INFO - 2023-08-21 09:16:01 --> Helper loaded: security_helper
INFO - 2023-08-21 09:16:01 --> Helper loaded: cookie_helper
INFO - 2023-08-21 09:16:01 --> Database Driver Class Initialized
INFO - 2023-08-21 09:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 09:16:01 --> Parser Class Initialized
INFO - 2023-08-21 09:16:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 09:16:01 --> Pagination Class Initialized
INFO - 2023-08-21 09:16:01 --> Form Validation Class Initialized
INFO - 2023-08-21 09:16:01 --> Controller Class Initialized
INFO - 2023-08-21 09:16:01 --> Model Class Initialized
DEBUG - 2023-08-21 09:16:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 09:16:01 --> Model Class Initialized
DEBUG - 2023-08-21 09:16:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 09:16:01 --> Model Class Initialized
INFO - 2023-08-21 09:16:01 --> Model Class Initialized
INFO - 2023-08-21 09:16:01 --> Model Class Initialized
INFO - 2023-08-21 09:16:01 --> Model Class Initialized
DEBUG - 2023-08-21 09:16:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 09:16:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 09:16:01 --> Model Class Initialized
INFO - 2023-08-21 09:16:01 --> Model Class Initialized
INFO - 2023-08-21 09:16:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-21 09:16:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 09:16:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 09:16:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 09:16:02 --> Model Class Initialized
INFO - 2023-08-21 09:16:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 09:16:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 09:16:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 09:16:02 --> Final output sent to browser
DEBUG - 2023-08-21 09:16:02 --> Total execution time: 0.2139
ERROR - 2023-08-21 15:55:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 15:55:15 --> Config Class Initialized
INFO - 2023-08-21 15:55:15 --> Hooks Class Initialized
DEBUG - 2023-08-21 15:55:15 --> UTF-8 Support Enabled
INFO - 2023-08-21 15:55:15 --> Utf8 Class Initialized
INFO - 2023-08-21 15:55:15 --> URI Class Initialized
DEBUG - 2023-08-21 15:55:15 --> No URI present. Default controller set.
INFO - 2023-08-21 15:55:15 --> Router Class Initialized
INFO - 2023-08-21 15:55:15 --> Output Class Initialized
INFO - 2023-08-21 15:55:15 --> Security Class Initialized
DEBUG - 2023-08-21 15:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 15:55:15 --> Input Class Initialized
INFO - 2023-08-21 15:55:15 --> Language Class Initialized
INFO - 2023-08-21 15:55:15 --> Loader Class Initialized
INFO - 2023-08-21 15:55:15 --> Helper loaded: url_helper
INFO - 2023-08-21 15:55:15 --> Helper loaded: file_helper
INFO - 2023-08-21 15:55:15 --> Helper loaded: html_helper
INFO - 2023-08-21 15:55:15 --> Helper loaded: text_helper
INFO - 2023-08-21 15:55:15 --> Helper loaded: form_helper
INFO - 2023-08-21 15:55:15 --> Helper loaded: lang_helper
INFO - 2023-08-21 15:55:15 --> Helper loaded: security_helper
INFO - 2023-08-21 15:55:15 --> Helper loaded: cookie_helper
INFO - 2023-08-21 15:55:15 --> Database Driver Class Initialized
INFO - 2023-08-21 15:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 15:55:15 --> Parser Class Initialized
INFO - 2023-08-21 15:55:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 15:55:15 --> Pagination Class Initialized
INFO - 2023-08-21 15:55:15 --> Form Validation Class Initialized
INFO - 2023-08-21 15:55:15 --> Controller Class Initialized
INFO - 2023-08-21 15:55:15 --> Model Class Initialized
DEBUG - 2023-08-21 15:55:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-21 15:55:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 15:55:16 --> Config Class Initialized
INFO - 2023-08-21 15:55:16 --> Hooks Class Initialized
DEBUG - 2023-08-21 15:55:16 --> UTF-8 Support Enabled
INFO - 2023-08-21 15:55:16 --> Utf8 Class Initialized
INFO - 2023-08-21 15:55:16 --> URI Class Initialized
INFO - 2023-08-21 15:55:16 --> Router Class Initialized
INFO - 2023-08-21 15:55:16 --> Output Class Initialized
INFO - 2023-08-21 15:55:16 --> Security Class Initialized
DEBUG - 2023-08-21 15:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 15:55:16 --> Input Class Initialized
INFO - 2023-08-21 15:55:16 --> Language Class Initialized
INFO - 2023-08-21 15:55:16 --> Loader Class Initialized
INFO - 2023-08-21 15:55:16 --> Helper loaded: url_helper
INFO - 2023-08-21 15:55:16 --> Helper loaded: file_helper
INFO - 2023-08-21 15:55:16 --> Helper loaded: html_helper
INFO - 2023-08-21 15:55:16 --> Helper loaded: text_helper
INFO - 2023-08-21 15:55:16 --> Helper loaded: form_helper
INFO - 2023-08-21 15:55:16 --> Helper loaded: lang_helper
INFO - 2023-08-21 15:55:16 --> Helper loaded: security_helper
INFO - 2023-08-21 15:55:16 --> Helper loaded: cookie_helper
INFO - 2023-08-21 15:55:16 --> Database Driver Class Initialized
INFO - 2023-08-21 15:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 15:55:16 --> Parser Class Initialized
INFO - 2023-08-21 15:55:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 15:55:16 --> Pagination Class Initialized
INFO - 2023-08-21 15:55:16 --> Form Validation Class Initialized
INFO - 2023-08-21 15:55:16 --> Controller Class Initialized
INFO - 2023-08-21 15:55:16 --> Model Class Initialized
DEBUG - 2023-08-21 15:55:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:55:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-21 15:55:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:55:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 15:55:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 15:55:16 --> Model Class Initialized
INFO - 2023-08-21 15:55:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 15:55:16 --> Final output sent to browser
DEBUG - 2023-08-21 15:55:16 --> Total execution time: 0.0387
ERROR - 2023-08-21 15:55:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 15:55:25 --> Config Class Initialized
INFO - 2023-08-21 15:55:25 --> Hooks Class Initialized
DEBUG - 2023-08-21 15:55:25 --> UTF-8 Support Enabled
INFO - 2023-08-21 15:55:25 --> Utf8 Class Initialized
INFO - 2023-08-21 15:55:25 --> URI Class Initialized
DEBUG - 2023-08-21 15:55:25 --> No URI present. Default controller set.
INFO - 2023-08-21 15:55:25 --> Router Class Initialized
INFO - 2023-08-21 15:55:25 --> Output Class Initialized
INFO - 2023-08-21 15:55:25 --> Security Class Initialized
DEBUG - 2023-08-21 15:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 15:55:25 --> Input Class Initialized
INFO - 2023-08-21 15:55:25 --> Language Class Initialized
INFO - 2023-08-21 15:55:25 --> Loader Class Initialized
INFO - 2023-08-21 15:55:25 --> Helper loaded: url_helper
INFO - 2023-08-21 15:55:25 --> Helper loaded: file_helper
INFO - 2023-08-21 15:55:25 --> Helper loaded: html_helper
INFO - 2023-08-21 15:55:25 --> Helper loaded: text_helper
INFO - 2023-08-21 15:55:25 --> Helper loaded: form_helper
INFO - 2023-08-21 15:55:25 --> Helper loaded: lang_helper
INFO - 2023-08-21 15:55:25 --> Helper loaded: security_helper
INFO - 2023-08-21 15:55:25 --> Helper loaded: cookie_helper
INFO - 2023-08-21 15:55:25 --> Database Driver Class Initialized
INFO - 2023-08-21 15:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 15:55:25 --> Parser Class Initialized
INFO - 2023-08-21 15:55:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 15:55:25 --> Pagination Class Initialized
INFO - 2023-08-21 15:55:25 --> Form Validation Class Initialized
INFO - 2023-08-21 15:55:25 --> Controller Class Initialized
INFO - 2023-08-21 15:55:25 --> Model Class Initialized
DEBUG - 2023-08-21 15:55:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-21 15:55:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 15:55:26 --> Config Class Initialized
INFO - 2023-08-21 15:55:26 --> Hooks Class Initialized
DEBUG - 2023-08-21 15:55:26 --> UTF-8 Support Enabled
INFO - 2023-08-21 15:55:26 --> Utf8 Class Initialized
INFO - 2023-08-21 15:55:26 --> URI Class Initialized
INFO - 2023-08-21 15:55:26 --> Router Class Initialized
INFO - 2023-08-21 15:55:26 --> Output Class Initialized
INFO - 2023-08-21 15:55:26 --> Security Class Initialized
DEBUG - 2023-08-21 15:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 15:55:26 --> Input Class Initialized
INFO - 2023-08-21 15:55:26 --> Language Class Initialized
INFO - 2023-08-21 15:55:26 --> Loader Class Initialized
INFO - 2023-08-21 15:55:26 --> Helper loaded: url_helper
INFO - 2023-08-21 15:55:26 --> Helper loaded: file_helper
INFO - 2023-08-21 15:55:26 --> Helper loaded: html_helper
INFO - 2023-08-21 15:55:26 --> Helper loaded: text_helper
INFO - 2023-08-21 15:55:26 --> Helper loaded: form_helper
INFO - 2023-08-21 15:55:26 --> Helper loaded: lang_helper
INFO - 2023-08-21 15:55:26 --> Helper loaded: security_helper
INFO - 2023-08-21 15:55:26 --> Helper loaded: cookie_helper
INFO - 2023-08-21 15:55:26 --> Database Driver Class Initialized
INFO - 2023-08-21 15:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 15:55:26 --> Parser Class Initialized
INFO - 2023-08-21 15:55:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 15:55:26 --> Pagination Class Initialized
INFO - 2023-08-21 15:55:26 --> Form Validation Class Initialized
INFO - 2023-08-21 15:55:26 --> Controller Class Initialized
INFO - 2023-08-21 15:55:26 --> Model Class Initialized
DEBUG - 2023-08-21 15:55:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:55:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-21 15:55:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:55:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 15:55:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 15:55:26 --> Model Class Initialized
INFO - 2023-08-21 15:55:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 15:55:26 --> Final output sent to browser
DEBUG - 2023-08-21 15:55:26 --> Total execution time: 0.0284
ERROR - 2023-08-21 15:55:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 15:55:29 --> Config Class Initialized
INFO - 2023-08-21 15:55:29 --> Hooks Class Initialized
DEBUG - 2023-08-21 15:55:29 --> UTF-8 Support Enabled
INFO - 2023-08-21 15:55:29 --> Utf8 Class Initialized
INFO - 2023-08-21 15:55:29 --> URI Class Initialized
INFO - 2023-08-21 15:55:29 --> Router Class Initialized
INFO - 2023-08-21 15:55:29 --> Output Class Initialized
INFO - 2023-08-21 15:55:29 --> Security Class Initialized
DEBUG - 2023-08-21 15:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 15:55:29 --> Input Class Initialized
INFO - 2023-08-21 15:55:29 --> Language Class Initialized
INFO - 2023-08-21 15:55:29 --> Loader Class Initialized
INFO - 2023-08-21 15:55:29 --> Helper loaded: url_helper
INFO - 2023-08-21 15:55:29 --> Helper loaded: file_helper
INFO - 2023-08-21 15:55:29 --> Helper loaded: html_helper
INFO - 2023-08-21 15:55:29 --> Helper loaded: text_helper
INFO - 2023-08-21 15:55:29 --> Helper loaded: form_helper
INFO - 2023-08-21 15:55:29 --> Helper loaded: lang_helper
INFO - 2023-08-21 15:55:29 --> Helper loaded: security_helper
INFO - 2023-08-21 15:55:29 --> Helper loaded: cookie_helper
INFO - 2023-08-21 15:55:29 --> Database Driver Class Initialized
INFO - 2023-08-21 15:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 15:55:29 --> Parser Class Initialized
INFO - 2023-08-21 15:55:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 15:55:29 --> Pagination Class Initialized
INFO - 2023-08-21 15:55:29 --> Form Validation Class Initialized
INFO - 2023-08-21 15:55:29 --> Controller Class Initialized
INFO - 2023-08-21 15:55:29 --> Model Class Initialized
DEBUG - 2023-08-21 15:55:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:55:29 --> Model Class Initialized
INFO - 2023-08-21 15:55:29 --> Final output sent to browser
DEBUG - 2023-08-21 15:55:29 --> Total execution time: 0.0198
ERROR - 2023-08-21 15:55:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 15:55:30 --> Config Class Initialized
INFO - 2023-08-21 15:55:30 --> Hooks Class Initialized
DEBUG - 2023-08-21 15:55:30 --> UTF-8 Support Enabled
INFO - 2023-08-21 15:55:30 --> Utf8 Class Initialized
INFO - 2023-08-21 15:55:30 --> URI Class Initialized
DEBUG - 2023-08-21 15:55:30 --> No URI present. Default controller set.
INFO - 2023-08-21 15:55:30 --> Router Class Initialized
INFO - 2023-08-21 15:55:30 --> Output Class Initialized
INFO - 2023-08-21 15:55:30 --> Security Class Initialized
DEBUG - 2023-08-21 15:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 15:55:30 --> Input Class Initialized
INFO - 2023-08-21 15:55:30 --> Language Class Initialized
INFO - 2023-08-21 15:55:30 --> Loader Class Initialized
INFO - 2023-08-21 15:55:30 --> Helper loaded: url_helper
INFO - 2023-08-21 15:55:30 --> Helper loaded: file_helper
INFO - 2023-08-21 15:55:30 --> Helper loaded: html_helper
INFO - 2023-08-21 15:55:30 --> Helper loaded: text_helper
INFO - 2023-08-21 15:55:30 --> Helper loaded: form_helper
INFO - 2023-08-21 15:55:30 --> Helper loaded: lang_helper
INFO - 2023-08-21 15:55:30 --> Helper loaded: security_helper
INFO - 2023-08-21 15:55:30 --> Helper loaded: cookie_helper
INFO - 2023-08-21 15:55:30 --> Database Driver Class Initialized
INFO - 2023-08-21 15:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 15:55:30 --> Parser Class Initialized
INFO - 2023-08-21 15:55:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 15:55:30 --> Pagination Class Initialized
INFO - 2023-08-21 15:55:30 --> Form Validation Class Initialized
INFO - 2023-08-21 15:55:30 --> Controller Class Initialized
INFO - 2023-08-21 15:55:30 --> Model Class Initialized
DEBUG - 2023-08-21 15:55:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:55:30 --> Model Class Initialized
DEBUG - 2023-08-21 15:55:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:55:30 --> Model Class Initialized
INFO - 2023-08-21 15:55:30 --> Model Class Initialized
INFO - 2023-08-21 15:55:30 --> Model Class Initialized
INFO - 2023-08-21 15:55:30 --> Model Class Initialized
DEBUG - 2023-08-21 15:55:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 15:55:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:55:30 --> Model Class Initialized
INFO - 2023-08-21 15:55:30 --> Model Class Initialized
INFO - 2023-08-21 15:55:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-21 15:55:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:55:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 15:55:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 15:55:30 --> Model Class Initialized
INFO - 2023-08-21 15:55:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 15:55:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 15:55:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 15:55:30 --> Final output sent to browser
DEBUG - 2023-08-21 15:55:30 --> Total execution time: 0.0943
ERROR - 2023-08-21 15:56:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 15:56:19 --> Config Class Initialized
INFO - 2023-08-21 15:56:19 --> Hooks Class Initialized
DEBUG - 2023-08-21 15:56:19 --> UTF-8 Support Enabled
INFO - 2023-08-21 15:56:19 --> Utf8 Class Initialized
INFO - 2023-08-21 15:56:19 --> URI Class Initialized
INFO - 2023-08-21 15:56:19 --> Router Class Initialized
INFO - 2023-08-21 15:56:19 --> Output Class Initialized
INFO - 2023-08-21 15:56:19 --> Security Class Initialized
DEBUG - 2023-08-21 15:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 15:56:19 --> Input Class Initialized
INFO - 2023-08-21 15:56:19 --> Language Class Initialized
INFO - 2023-08-21 15:56:19 --> Loader Class Initialized
INFO - 2023-08-21 15:56:19 --> Helper loaded: url_helper
INFO - 2023-08-21 15:56:19 --> Helper loaded: file_helper
INFO - 2023-08-21 15:56:19 --> Helper loaded: html_helper
INFO - 2023-08-21 15:56:19 --> Helper loaded: text_helper
INFO - 2023-08-21 15:56:19 --> Helper loaded: form_helper
INFO - 2023-08-21 15:56:19 --> Helper loaded: lang_helper
INFO - 2023-08-21 15:56:19 --> Helper loaded: security_helper
INFO - 2023-08-21 15:56:19 --> Helper loaded: cookie_helper
INFO - 2023-08-21 15:56:19 --> Database Driver Class Initialized
INFO - 2023-08-21 15:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 15:56:19 --> Parser Class Initialized
INFO - 2023-08-21 15:56:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 15:56:19 --> Pagination Class Initialized
INFO - 2023-08-21 15:56:19 --> Form Validation Class Initialized
INFO - 2023-08-21 15:56:19 --> Controller Class Initialized
INFO - 2023-08-21 15:56:19 --> Model Class Initialized
DEBUG - 2023-08-21 15:56:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 15:56:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:56:19 --> Model Class Initialized
DEBUG - 2023-08-21 15:56:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:56:19 --> Model Class Initialized
INFO - 2023-08-21 15:56:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-21 15:56:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:56:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 15:56:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 15:56:19 --> Model Class Initialized
INFO - 2023-08-21 15:56:19 --> Model Class Initialized
INFO - 2023-08-21 15:56:19 --> Model Class Initialized
INFO - 2023-08-21 15:56:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 15:56:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 15:56:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 15:56:20 --> Final output sent to browser
DEBUG - 2023-08-21 15:56:20 --> Total execution time: 0.0883
ERROR - 2023-08-21 15:56:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 15:56:20 --> Config Class Initialized
INFO - 2023-08-21 15:56:20 --> Hooks Class Initialized
DEBUG - 2023-08-21 15:56:20 --> UTF-8 Support Enabled
INFO - 2023-08-21 15:56:20 --> Utf8 Class Initialized
INFO - 2023-08-21 15:56:20 --> URI Class Initialized
INFO - 2023-08-21 15:56:20 --> Router Class Initialized
INFO - 2023-08-21 15:56:20 --> Output Class Initialized
INFO - 2023-08-21 15:56:20 --> Security Class Initialized
DEBUG - 2023-08-21 15:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 15:56:20 --> Input Class Initialized
INFO - 2023-08-21 15:56:20 --> Language Class Initialized
INFO - 2023-08-21 15:56:20 --> Loader Class Initialized
INFO - 2023-08-21 15:56:20 --> Helper loaded: url_helper
INFO - 2023-08-21 15:56:20 --> Helper loaded: file_helper
INFO - 2023-08-21 15:56:20 --> Helper loaded: html_helper
INFO - 2023-08-21 15:56:20 --> Helper loaded: text_helper
INFO - 2023-08-21 15:56:20 --> Helper loaded: form_helper
INFO - 2023-08-21 15:56:20 --> Helper loaded: lang_helper
INFO - 2023-08-21 15:56:20 --> Helper loaded: security_helper
INFO - 2023-08-21 15:56:20 --> Helper loaded: cookie_helper
INFO - 2023-08-21 15:56:20 --> Database Driver Class Initialized
INFO - 2023-08-21 15:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 15:56:20 --> Parser Class Initialized
INFO - 2023-08-21 15:56:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 15:56:20 --> Pagination Class Initialized
INFO - 2023-08-21 15:56:20 --> Form Validation Class Initialized
INFO - 2023-08-21 15:56:20 --> Controller Class Initialized
INFO - 2023-08-21 15:56:20 --> Model Class Initialized
DEBUG - 2023-08-21 15:56:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 15:56:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:56:20 --> Model Class Initialized
DEBUG - 2023-08-21 15:56:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:56:20 --> Model Class Initialized
INFO - 2023-08-21 15:56:20 --> Final output sent to browser
DEBUG - 2023-08-21 15:56:20 --> Total execution time: 0.0368
ERROR - 2023-08-21 15:56:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 15:56:52 --> Config Class Initialized
INFO - 2023-08-21 15:56:52 --> Hooks Class Initialized
DEBUG - 2023-08-21 15:56:52 --> UTF-8 Support Enabled
INFO - 2023-08-21 15:56:52 --> Utf8 Class Initialized
INFO - 2023-08-21 15:56:52 --> URI Class Initialized
DEBUG - 2023-08-21 15:56:52 --> No URI present. Default controller set.
INFO - 2023-08-21 15:56:52 --> Router Class Initialized
INFO - 2023-08-21 15:56:52 --> Output Class Initialized
INFO - 2023-08-21 15:56:52 --> Security Class Initialized
DEBUG - 2023-08-21 15:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 15:56:52 --> Input Class Initialized
INFO - 2023-08-21 15:56:52 --> Language Class Initialized
INFO - 2023-08-21 15:56:52 --> Loader Class Initialized
INFO - 2023-08-21 15:56:52 --> Helper loaded: url_helper
INFO - 2023-08-21 15:56:52 --> Helper loaded: file_helper
INFO - 2023-08-21 15:56:52 --> Helper loaded: html_helper
INFO - 2023-08-21 15:56:52 --> Helper loaded: text_helper
INFO - 2023-08-21 15:56:52 --> Helper loaded: form_helper
INFO - 2023-08-21 15:56:52 --> Helper loaded: lang_helper
INFO - 2023-08-21 15:56:52 --> Helper loaded: security_helper
INFO - 2023-08-21 15:56:52 --> Helper loaded: cookie_helper
INFO - 2023-08-21 15:56:52 --> Database Driver Class Initialized
INFO - 2023-08-21 15:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 15:56:52 --> Parser Class Initialized
INFO - 2023-08-21 15:56:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 15:56:52 --> Pagination Class Initialized
INFO - 2023-08-21 15:56:52 --> Form Validation Class Initialized
INFO - 2023-08-21 15:56:52 --> Controller Class Initialized
INFO - 2023-08-21 15:56:52 --> Model Class Initialized
DEBUG - 2023-08-21 15:56:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:56:52 --> Model Class Initialized
DEBUG - 2023-08-21 15:56:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:56:52 --> Model Class Initialized
INFO - 2023-08-21 15:56:52 --> Model Class Initialized
INFO - 2023-08-21 15:56:52 --> Model Class Initialized
INFO - 2023-08-21 15:56:52 --> Model Class Initialized
DEBUG - 2023-08-21 15:56:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 15:56:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:56:52 --> Model Class Initialized
INFO - 2023-08-21 15:56:52 --> Model Class Initialized
INFO - 2023-08-21 15:56:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-21 15:56:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:56:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 15:56:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 15:56:52 --> Model Class Initialized
INFO - 2023-08-21 15:56:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 15:56:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 15:56:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 15:56:52 --> Final output sent to browser
DEBUG - 2023-08-21 15:56:52 --> Total execution time: 0.1007
ERROR - 2023-08-21 15:57:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 15:57:03 --> Config Class Initialized
INFO - 2023-08-21 15:57:03 --> Hooks Class Initialized
DEBUG - 2023-08-21 15:57:03 --> UTF-8 Support Enabled
INFO - 2023-08-21 15:57:03 --> Utf8 Class Initialized
INFO - 2023-08-21 15:57:03 --> URI Class Initialized
INFO - 2023-08-21 15:57:03 --> Router Class Initialized
INFO - 2023-08-21 15:57:03 --> Output Class Initialized
INFO - 2023-08-21 15:57:03 --> Security Class Initialized
DEBUG - 2023-08-21 15:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 15:57:03 --> Input Class Initialized
INFO - 2023-08-21 15:57:03 --> Language Class Initialized
INFO - 2023-08-21 15:57:03 --> Loader Class Initialized
INFO - 2023-08-21 15:57:03 --> Helper loaded: url_helper
INFO - 2023-08-21 15:57:03 --> Helper loaded: file_helper
INFO - 2023-08-21 15:57:03 --> Helper loaded: html_helper
INFO - 2023-08-21 15:57:03 --> Helper loaded: text_helper
INFO - 2023-08-21 15:57:03 --> Helper loaded: form_helper
INFO - 2023-08-21 15:57:03 --> Helper loaded: lang_helper
INFO - 2023-08-21 15:57:03 --> Helper loaded: security_helper
INFO - 2023-08-21 15:57:03 --> Helper loaded: cookie_helper
INFO - 2023-08-21 15:57:03 --> Database Driver Class Initialized
INFO - 2023-08-21 15:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 15:57:03 --> Parser Class Initialized
INFO - 2023-08-21 15:57:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 15:57:03 --> Pagination Class Initialized
INFO - 2023-08-21 15:57:03 --> Form Validation Class Initialized
INFO - 2023-08-21 15:57:03 --> Controller Class Initialized
INFO - 2023-08-21 15:57:03 --> Model Class Initialized
DEBUG - 2023-08-21 15:57:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 15:57:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:57:03 --> Model Class Initialized
DEBUG - 2023-08-21 15:57:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:57:03 --> Model Class Initialized
INFO - 2023-08-21 15:57:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-21 15:57:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:57:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 15:57:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 15:57:03 --> Model Class Initialized
INFO - 2023-08-21 15:57:03 --> Model Class Initialized
INFO - 2023-08-21 15:57:03 --> Model Class Initialized
INFO - 2023-08-21 15:57:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 15:57:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 15:57:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 15:57:03 --> Final output sent to browser
DEBUG - 2023-08-21 15:57:03 --> Total execution time: 0.0771
ERROR - 2023-08-21 15:57:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 15:57:03 --> Config Class Initialized
INFO - 2023-08-21 15:57:03 --> Hooks Class Initialized
DEBUG - 2023-08-21 15:57:03 --> UTF-8 Support Enabled
INFO - 2023-08-21 15:57:03 --> Utf8 Class Initialized
INFO - 2023-08-21 15:57:03 --> URI Class Initialized
INFO - 2023-08-21 15:57:03 --> Router Class Initialized
INFO - 2023-08-21 15:57:03 --> Output Class Initialized
INFO - 2023-08-21 15:57:03 --> Security Class Initialized
DEBUG - 2023-08-21 15:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 15:57:03 --> Input Class Initialized
INFO - 2023-08-21 15:57:03 --> Language Class Initialized
INFO - 2023-08-21 15:57:03 --> Loader Class Initialized
INFO - 2023-08-21 15:57:03 --> Helper loaded: url_helper
INFO - 2023-08-21 15:57:03 --> Helper loaded: file_helper
INFO - 2023-08-21 15:57:03 --> Helper loaded: html_helper
INFO - 2023-08-21 15:57:03 --> Helper loaded: text_helper
INFO - 2023-08-21 15:57:03 --> Helper loaded: form_helper
INFO - 2023-08-21 15:57:03 --> Helper loaded: lang_helper
INFO - 2023-08-21 15:57:03 --> Helper loaded: security_helper
INFO - 2023-08-21 15:57:03 --> Helper loaded: cookie_helper
INFO - 2023-08-21 15:57:03 --> Database Driver Class Initialized
INFO - 2023-08-21 15:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 15:57:03 --> Parser Class Initialized
INFO - 2023-08-21 15:57:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 15:57:03 --> Pagination Class Initialized
INFO - 2023-08-21 15:57:03 --> Form Validation Class Initialized
INFO - 2023-08-21 15:57:03 --> Controller Class Initialized
INFO - 2023-08-21 15:57:03 --> Model Class Initialized
DEBUG - 2023-08-21 15:57:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 15:57:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:57:03 --> Model Class Initialized
DEBUG - 2023-08-21 15:57:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:57:03 --> Model Class Initialized
INFO - 2023-08-21 15:57:03 --> Final output sent to browser
DEBUG - 2023-08-21 15:57:03 --> Total execution time: 0.0366
ERROR - 2023-08-21 15:57:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 15:57:10 --> Config Class Initialized
INFO - 2023-08-21 15:57:10 --> Hooks Class Initialized
DEBUG - 2023-08-21 15:57:10 --> UTF-8 Support Enabled
INFO - 2023-08-21 15:57:10 --> Utf8 Class Initialized
INFO - 2023-08-21 15:57:10 --> URI Class Initialized
INFO - 2023-08-21 15:57:10 --> Router Class Initialized
INFO - 2023-08-21 15:57:10 --> Output Class Initialized
INFO - 2023-08-21 15:57:10 --> Security Class Initialized
DEBUG - 2023-08-21 15:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 15:57:10 --> Input Class Initialized
INFO - 2023-08-21 15:57:10 --> Language Class Initialized
INFO - 2023-08-21 15:57:10 --> Loader Class Initialized
INFO - 2023-08-21 15:57:10 --> Helper loaded: url_helper
INFO - 2023-08-21 15:57:10 --> Helper loaded: file_helper
INFO - 2023-08-21 15:57:10 --> Helper loaded: html_helper
INFO - 2023-08-21 15:57:10 --> Helper loaded: text_helper
INFO - 2023-08-21 15:57:10 --> Helper loaded: form_helper
INFO - 2023-08-21 15:57:10 --> Helper loaded: lang_helper
INFO - 2023-08-21 15:57:10 --> Helper loaded: security_helper
INFO - 2023-08-21 15:57:10 --> Helper loaded: cookie_helper
INFO - 2023-08-21 15:57:10 --> Database Driver Class Initialized
INFO - 2023-08-21 15:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 15:57:10 --> Parser Class Initialized
INFO - 2023-08-21 15:57:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 15:57:10 --> Pagination Class Initialized
INFO - 2023-08-21 15:57:10 --> Form Validation Class Initialized
INFO - 2023-08-21 15:57:10 --> Controller Class Initialized
INFO - 2023-08-21 15:57:10 --> Model Class Initialized
DEBUG - 2023-08-21 15:57:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 15:57:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:57:10 --> Model Class Initialized
DEBUG - 2023-08-21 15:57:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:57:10 --> Model Class Initialized
INFO - 2023-08-21 15:57:10 --> Final output sent to browser
DEBUG - 2023-08-21 15:57:10 --> Total execution time: 0.0985
ERROR - 2023-08-21 15:57:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 15:57:28 --> Config Class Initialized
INFO - 2023-08-21 15:57:28 --> Hooks Class Initialized
DEBUG - 2023-08-21 15:57:28 --> UTF-8 Support Enabled
INFO - 2023-08-21 15:57:28 --> Utf8 Class Initialized
INFO - 2023-08-21 15:57:28 --> URI Class Initialized
DEBUG - 2023-08-21 15:57:28 --> No URI present. Default controller set.
INFO - 2023-08-21 15:57:28 --> Router Class Initialized
INFO - 2023-08-21 15:57:28 --> Output Class Initialized
INFO - 2023-08-21 15:57:28 --> Security Class Initialized
DEBUG - 2023-08-21 15:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 15:57:28 --> Input Class Initialized
INFO - 2023-08-21 15:57:28 --> Language Class Initialized
INFO - 2023-08-21 15:57:28 --> Loader Class Initialized
INFO - 2023-08-21 15:57:28 --> Helper loaded: url_helper
INFO - 2023-08-21 15:57:28 --> Helper loaded: file_helper
INFO - 2023-08-21 15:57:28 --> Helper loaded: html_helper
INFO - 2023-08-21 15:57:28 --> Helper loaded: text_helper
INFO - 2023-08-21 15:57:28 --> Helper loaded: form_helper
INFO - 2023-08-21 15:57:28 --> Helper loaded: lang_helper
INFO - 2023-08-21 15:57:28 --> Helper loaded: security_helper
INFO - 2023-08-21 15:57:28 --> Helper loaded: cookie_helper
INFO - 2023-08-21 15:57:28 --> Database Driver Class Initialized
INFO - 2023-08-21 15:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 15:57:28 --> Parser Class Initialized
INFO - 2023-08-21 15:57:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 15:57:28 --> Pagination Class Initialized
INFO - 2023-08-21 15:57:28 --> Form Validation Class Initialized
INFO - 2023-08-21 15:57:28 --> Controller Class Initialized
INFO - 2023-08-21 15:57:28 --> Model Class Initialized
DEBUG - 2023-08-21 15:57:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:57:28 --> Model Class Initialized
DEBUG - 2023-08-21 15:57:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:57:28 --> Model Class Initialized
INFO - 2023-08-21 15:57:28 --> Model Class Initialized
INFO - 2023-08-21 15:57:28 --> Model Class Initialized
INFO - 2023-08-21 15:57:28 --> Model Class Initialized
DEBUG - 2023-08-21 15:57:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 15:57:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:57:28 --> Model Class Initialized
INFO - 2023-08-21 15:57:28 --> Model Class Initialized
INFO - 2023-08-21 15:57:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-21 15:57:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:57:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 15:57:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 15:57:28 --> Model Class Initialized
INFO - 2023-08-21 15:57:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 15:57:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 15:57:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 15:57:29 --> Final output sent to browser
DEBUG - 2023-08-21 15:57:29 --> Total execution time: 0.0904
ERROR - 2023-08-21 15:57:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 15:57:36 --> Config Class Initialized
INFO - 2023-08-21 15:57:36 --> Hooks Class Initialized
DEBUG - 2023-08-21 15:57:36 --> UTF-8 Support Enabled
INFO - 2023-08-21 15:57:36 --> Utf8 Class Initialized
INFO - 2023-08-21 15:57:36 --> URI Class Initialized
DEBUG - 2023-08-21 15:57:36 --> No URI present. Default controller set.
INFO - 2023-08-21 15:57:36 --> Router Class Initialized
INFO - 2023-08-21 15:57:36 --> Output Class Initialized
INFO - 2023-08-21 15:57:36 --> Security Class Initialized
DEBUG - 2023-08-21 15:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 15:57:36 --> Input Class Initialized
INFO - 2023-08-21 15:57:36 --> Language Class Initialized
INFO - 2023-08-21 15:57:36 --> Loader Class Initialized
INFO - 2023-08-21 15:57:36 --> Helper loaded: url_helper
INFO - 2023-08-21 15:57:36 --> Helper loaded: file_helper
INFO - 2023-08-21 15:57:36 --> Helper loaded: html_helper
INFO - 2023-08-21 15:57:36 --> Helper loaded: text_helper
INFO - 2023-08-21 15:57:36 --> Helper loaded: form_helper
INFO - 2023-08-21 15:57:36 --> Helper loaded: lang_helper
INFO - 2023-08-21 15:57:36 --> Helper loaded: security_helper
INFO - 2023-08-21 15:57:36 --> Helper loaded: cookie_helper
INFO - 2023-08-21 15:57:36 --> Database Driver Class Initialized
INFO - 2023-08-21 15:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 15:57:36 --> Parser Class Initialized
INFO - 2023-08-21 15:57:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 15:57:36 --> Pagination Class Initialized
INFO - 2023-08-21 15:57:36 --> Form Validation Class Initialized
INFO - 2023-08-21 15:57:36 --> Controller Class Initialized
INFO - 2023-08-21 15:57:36 --> Model Class Initialized
DEBUG - 2023-08-21 15:57:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:57:36 --> Model Class Initialized
DEBUG - 2023-08-21 15:57:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:57:36 --> Model Class Initialized
INFO - 2023-08-21 15:57:36 --> Model Class Initialized
INFO - 2023-08-21 15:57:36 --> Model Class Initialized
INFO - 2023-08-21 15:57:36 --> Model Class Initialized
DEBUG - 2023-08-21 15:57:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 15:57:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:57:36 --> Model Class Initialized
INFO - 2023-08-21 15:57:36 --> Model Class Initialized
INFO - 2023-08-21 15:57:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-21 15:57:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:57:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 15:57:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 15:57:36 --> Model Class Initialized
INFO - 2023-08-21 15:57:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 15:57:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 15:57:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 15:57:36 --> Final output sent to browser
DEBUG - 2023-08-21 15:57:36 --> Total execution time: 0.0956
ERROR - 2023-08-21 15:57:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 15:57:59 --> Config Class Initialized
INFO - 2023-08-21 15:57:59 --> Hooks Class Initialized
DEBUG - 2023-08-21 15:57:59 --> UTF-8 Support Enabled
INFO - 2023-08-21 15:57:59 --> Utf8 Class Initialized
INFO - 2023-08-21 15:57:59 --> URI Class Initialized
INFO - 2023-08-21 15:57:59 --> Router Class Initialized
INFO - 2023-08-21 15:57:59 --> Output Class Initialized
INFO - 2023-08-21 15:57:59 --> Security Class Initialized
DEBUG - 2023-08-21 15:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 15:57:59 --> Input Class Initialized
INFO - 2023-08-21 15:57:59 --> Language Class Initialized
INFO - 2023-08-21 15:57:59 --> Loader Class Initialized
INFO - 2023-08-21 15:57:59 --> Helper loaded: url_helper
INFO - 2023-08-21 15:57:59 --> Helper loaded: file_helper
INFO - 2023-08-21 15:57:59 --> Helper loaded: html_helper
INFO - 2023-08-21 15:57:59 --> Helper loaded: text_helper
INFO - 2023-08-21 15:57:59 --> Helper loaded: form_helper
INFO - 2023-08-21 15:57:59 --> Helper loaded: lang_helper
INFO - 2023-08-21 15:57:59 --> Helper loaded: security_helper
INFO - 2023-08-21 15:57:59 --> Helper loaded: cookie_helper
INFO - 2023-08-21 15:57:59 --> Database Driver Class Initialized
INFO - 2023-08-21 15:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 15:57:59 --> Parser Class Initialized
INFO - 2023-08-21 15:57:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 15:57:59 --> Pagination Class Initialized
INFO - 2023-08-21 15:57:59 --> Form Validation Class Initialized
INFO - 2023-08-21 15:57:59 --> Controller Class Initialized
INFO - 2023-08-21 15:57:59 --> Model Class Initialized
DEBUG - 2023-08-21 15:57:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 15:57:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:57:59 --> Model Class Initialized
DEBUG - 2023-08-21 15:57:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:57:59 --> Model Class Initialized
INFO - 2023-08-21 15:57:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-21 15:57:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:57:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 15:57:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 15:57:59 --> Model Class Initialized
INFO - 2023-08-21 15:57:59 --> Model Class Initialized
INFO - 2023-08-21 15:57:59 --> Model Class Initialized
INFO - 2023-08-21 15:57:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 15:57:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 15:57:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 15:57:59 --> Final output sent to browser
DEBUG - 2023-08-21 15:57:59 --> Total execution time: 0.1040
ERROR - 2023-08-21 15:57:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 15:57:59 --> Config Class Initialized
INFO - 2023-08-21 15:57:59 --> Hooks Class Initialized
DEBUG - 2023-08-21 15:57:59 --> UTF-8 Support Enabled
INFO - 2023-08-21 15:57:59 --> Utf8 Class Initialized
INFO - 2023-08-21 15:57:59 --> URI Class Initialized
INFO - 2023-08-21 15:57:59 --> Router Class Initialized
INFO - 2023-08-21 15:57:59 --> Output Class Initialized
INFO - 2023-08-21 15:57:59 --> Security Class Initialized
DEBUG - 2023-08-21 15:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 15:57:59 --> Input Class Initialized
INFO - 2023-08-21 15:57:59 --> Language Class Initialized
INFO - 2023-08-21 15:57:59 --> Loader Class Initialized
INFO - 2023-08-21 15:57:59 --> Helper loaded: url_helper
INFO - 2023-08-21 15:57:59 --> Helper loaded: file_helper
INFO - 2023-08-21 15:57:59 --> Helper loaded: html_helper
INFO - 2023-08-21 15:57:59 --> Helper loaded: text_helper
INFO - 2023-08-21 15:57:59 --> Helper loaded: form_helper
INFO - 2023-08-21 15:57:59 --> Helper loaded: lang_helper
INFO - 2023-08-21 15:57:59 --> Helper loaded: security_helper
INFO - 2023-08-21 15:57:59 --> Helper loaded: cookie_helper
INFO - 2023-08-21 15:57:59 --> Database Driver Class Initialized
INFO - 2023-08-21 15:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 15:57:59 --> Parser Class Initialized
INFO - 2023-08-21 15:57:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 15:57:59 --> Pagination Class Initialized
INFO - 2023-08-21 15:57:59 --> Form Validation Class Initialized
INFO - 2023-08-21 15:57:59 --> Controller Class Initialized
INFO - 2023-08-21 15:57:59 --> Model Class Initialized
DEBUG - 2023-08-21 15:57:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 15:57:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:57:59 --> Model Class Initialized
DEBUG - 2023-08-21 15:57:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:57:59 --> Model Class Initialized
INFO - 2023-08-21 15:57:59 --> Final output sent to browser
DEBUG - 2023-08-21 15:57:59 --> Total execution time: 0.0430
ERROR - 2023-08-21 15:58:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 15:58:03 --> Config Class Initialized
INFO - 2023-08-21 15:58:03 --> Hooks Class Initialized
DEBUG - 2023-08-21 15:58:03 --> UTF-8 Support Enabled
INFO - 2023-08-21 15:58:03 --> Utf8 Class Initialized
INFO - 2023-08-21 15:58:03 --> URI Class Initialized
INFO - 2023-08-21 15:58:03 --> Router Class Initialized
INFO - 2023-08-21 15:58:03 --> Output Class Initialized
INFO - 2023-08-21 15:58:03 --> Security Class Initialized
DEBUG - 2023-08-21 15:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 15:58:03 --> Input Class Initialized
INFO - 2023-08-21 15:58:03 --> Language Class Initialized
INFO - 2023-08-21 15:58:03 --> Loader Class Initialized
INFO - 2023-08-21 15:58:03 --> Helper loaded: url_helper
INFO - 2023-08-21 15:58:03 --> Helper loaded: file_helper
INFO - 2023-08-21 15:58:03 --> Helper loaded: html_helper
INFO - 2023-08-21 15:58:03 --> Helper loaded: text_helper
INFO - 2023-08-21 15:58:03 --> Helper loaded: form_helper
INFO - 2023-08-21 15:58:03 --> Helper loaded: lang_helper
INFO - 2023-08-21 15:58:03 --> Helper loaded: security_helper
INFO - 2023-08-21 15:58:03 --> Helper loaded: cookie_helper
INFO - 2023-08-21 15:58:03 --> Database Driver Class Initialized
INFO - 2023-08-21 15:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 15:58:03 --> Parser Class Initialized
INFO - 2023-08-21 15:58:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 15:58:03 --> Pagination Class Initialized
INFO - 2023-08-21 15:58:03 --> Form Validation Class Initialized
INFO - 2023-08-21 15:58:03 --> Controller Class Initialized
INFO - 2023-08-21 15:58:03 --> Model Class Initialized
DEBUG - 2023-08-21 15:58:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 15:58:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:58:03 --> Model Class Initialized
DEBUG - 2023-08-21 15:58:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:58:03 --> Model Class Initialized
INFO - 2023-08-21 15:58:03 --> Final output sent to browser
DEBUG - 2023-08-21 15:58:03 --> Total execution time: 0.1120
ERROR - 2023-08-21 15:58:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 15:58:51 --> Config Class Initialized
INFO - 2023-08-21 15:58:51 --> Hooks Class Initialized
DEBUG - 2023-08-21 15:58:51 --> UTF-8 Support Enabled
INFO - 2023-08-21 15:58:51 --> Utf8 Class Initialized
INFO - 2023-08-21 15:58:51 --> URI Class Initialized
INFO - 2023-08-21 15:58:51 --> Router Class Initialized
INFO - 2023-08-21 15:58:51 --> Output Class Initialized
INFO - 2023-08-21 15:58:51 --> Security Class Initialized
DEBUG - 2023-08-21 15:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 15:58:51 --> Input Class Initialized
INFO - 2023-08-21 15:58:51 --> Language Class Initialized
INFO - 2023-08-21 15:58:51 --> Loader Class Initialized
INFO - 2023-08-21 15:58:51 --> Helper loaded: url_helper
INFO - 2023-08-21 15:58:51 --> Helper loaded: file_helper
INFO - 2023-08-21 15:58:51 --> Helper loaded: html_helper
INFO - 2023-08-21 15:58:51 --> Helper loaded: text_helper
INFO - 2023-08-21 15:58:51 --> Helper loaded: form_helper
INFO - 2023-08-21 15:58:51 --> Helper loaded: lang_helper
INFO - 2023-08-21 15:58:51 --> Helper loaded: security_helper
INFO - 2023-08-21 15:58:51 --> Helper loaded: cookie_helper
INFO - 2023-08-21 15:58:51 --> Database Driver Class Initialized
INFO - 2023-08-21 15:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 15:58:51 --> Parser Class Initialized
INFO - 2023-08-21 15:58:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 15:58:51 --> Pagination Class Initialized
INFO - 2023-08-21 15:58:51 --> Form Validation Class Initialized
INFO - 2023-08-21 15:58:51 --> Controller Class Initialized
INFO - 2023-08-21 15:58:51 --> Model Class Initialized
DEBUG - 2023-08-21 15:58:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 15:58:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:58:51 --> Model Class Initialized
DEBUG - 2023-08-21 15:58:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:58:51 --> Model Class Initialized
INFO - 2023-08-21 15:58:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-21 15:58:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:58:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 15:58:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 15:58:51 --> Model Class Initialized
INFO - 2023-08-21 15:58:51 --> Model Class Initialized
INFO - 2023-08-21 15:58:51 --> Model Class Initialized
INFO - 2023-08-21 15:58:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 15:58:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 15:58:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 15:58:51 --> Final output sent to browser
DEBUG - 2023-08-21 15:58:51 --> Total execution time: 0.0931
ERROR - 2023-08-21 15:58:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 15:58:52 --> Config Class Initialized
INFO - 2023-08-21 15:58:52 --> Hooks Class Initialized
DEBUG - 2023-08-21 15:58:52 --> UTF-8 Support Enabled
INFO - 2023-08-21 15:58:52 --> Utf8 Class Initialized
INFO - 2023-08-21 15:58:52 --> URI Class Initialized
INFO - 2023-08-21 15:58:52 --> Router Class Initialized
INFO - 2023-08-21 15:58:52 --> Output Class Initialized
INFO - 2023-08-21 15:58:52 --> Security Class Initialized
DEBUG - 2023-08-21 15:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 15:58:52 --> Input Class Initialized
INFO - 2023-08-21 15:58:52 --> Language Class Initialized
INFO - 2023-08-21 15:58:52 --> Loader Class Initialized
INFO - 2023-08-21 15:58:52 --> Helper loaded: url_helper
INFO - 2023-08-21 15:58:52 --> Helper loaded: file_helper
INFO - 2023-08-21 15:58:52 --> Helper loaded: html_helper
INFO - 2023-08-21 15:58:52 --> Helper loaded: text_helper
INFO - 2023-08-21 15:58:52 --> Helper loaded: form_helper
INFO - 2023-08-21 15:58:52 --> Helper loaded: lang_helper
INFO - 2023-08-21 15:58:52 --> Helper loaded: security_helper
INFO - 2023-08-21 15:58:52 --> Helper loaded: cookie_helper
INFO - 2023-08-21 15:58:52 --> Database Driver Class Initialized
INFO - 2023-08-21 15:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 15:58:52 --> Parser Class Initialized
INFO - 2023-08-21 15:58:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 15:58:52 --> Pagination Class Initialized
INFO - 2023-08-21 15:58:52 --> Form Validation Class Initialized
INFO - 2023-08-21 15:58:52 --> Controller Class Initialized
INFO - 2023-08-21 15:58:52 --> Model Class Initialized
DEBUG - 2023-08-21 15:58:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 15:58:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:58:52 --> Model Class Initialized
DEBUG - 2023-08-21 15:58:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:58:52 --> Model Class Initialized
INFO - 2023-08-21 15:58:52 --> Final output sent to browser
DEBUG - 2023-08-21 15:58:52 --> Total execution time: 0.0402
ERROR - 2023-08-21 15:58:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 15:58:56 --> Config Class Initialized
INFO - 2023-08-21 15:58:56 --> Hooks Class Initialized
DEBUG - 2023-08-21 15:58:56 --> UTF-8 Support Enabled
INFO - 2023-08-21 15:58:56 --> Utf8 Class Initialized
INFO - 2023-08-21 15:58:56 --> URI Class Initialized
INFO - 2023-08-21 15:58:56 --> Router Class Initialized
INFO - 2023-08-21 15:58:56 --> Output Class Initialized
INFO - 2023-08-21 15:58:56 --> Security Class Initialized
DEBUG - 2023-08-21 15:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 15:58:56 --> Input Class Initialized
INFO - 2023-08-21 15:58:56 --> Language Class Initialized
INFO - 2023-08-21 15:58:56 --> Loader Class Initialized
INFO - 2023-08-21 15:58:56 --> Helper loaded: url_helper
INFO - 2023-08-21 15:58:56 --> Helper loaded: file_helper
INFO - 2023-08-21 15:58:56 --> Helper loaded: html_helper
INFO - 2023-08-21 15:58:56 --> Helper loaded: text_helper
INFO - 2023-08-21 15:58:56 --> Helper loaded: form_helper
INFO - 2023-08-21 15:58:56 --> Helper loaded: lang_helper
INFO - 2023-08-21 15:58:56 --> Helper loaded: security_helper
INFO - 2023-08-21 15:58:56 --> Helper loaded: cookie_helper
INFO - 2023-08-21 15:58:56 --> Database Driver Class Initialized
INFO - 2023-08-21 15:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 15:58:56 --> Parser Class Initialized
INFO - 2023-08-21 15:58:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 15:58:56 --> Pagination Class Initialized
INFO - 2023-08-21 15:58:56 --> Form Validation Class Initialized
INFO - 2023-08-21 15:58:56 --> Controller Class Initialized
INFO - 2023-08-21 15:58:56 --> Model Class Initialized
DEBUG - 2023-08-21 15:58:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 15:58:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:58:56 --> Model Class Initialized
DEBUG - 2023-08-21 15:58:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:58:56 --> Model Class Initialized
INFO - 2023-08-21 15:58:56 --> Final output sent to browser
DEBUG - 2023-08-21 15:58:56 --> Total execution time: 0.0438
ERROR - 2023-08-21 15:58:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 15:58:57 --> Config Class Initialized
INFO - 2023-08-21 15:58:57 --> Hooks Class Initialized
DEBUG - 2023-08-21 15:58:57 --> UTF-8 Support Enabled
INFO - 2023-08-21 15:58:57 --> Utf8 Class Initialized
INFO - 2023-08-21 15:58:57 --> URI Class Initialized
INFO - 2023-08-21 15:58:57 --> Router Class Initialized
INFO - 2023-08-21 15:58:57 --> Output Class Initialized
INFO - 2023-08-21 15:58:57 --> Security Class Initialized
DEBUG - 2023-08-21 15:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 15:58:57 --> Input Class Initialized
INFO - 2023-08-21 15:58:57 --> Language Class Initialized
INFO - 2023-08-21 15:58:57 --> Loader Class Initialized
INFO - 2023-08-21 15:58:57 --> Helper loaded: url_helper
INFO - 2023-08-21 15:58:57 --> Helper loaded: file_helper
INFO - 2023-08-21 15:58:57 --> Helper loaded: html_helper
INFO - 2023-08-21 15:58:57 --> Helper loaded: text_helper
INFO - 2023-08-21 15:58:57 --> Helper loaded: form_helper
INFO - 2023-08-21 15:58:57 --> Helper loaded: lang_helper
INFO - 2023-08-21 15:58:57 --> Helper loaded: security_helper
INFO - 2023-08-21 15:58:57 --> Helper loaded: cookie_helper
INFO - 2023-08-21 15:58:57 --> Database Driver Class Initialized
INFO - 2023-08-21 15:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 15:58:57 --> Parser Class Initialized
INFO - 2023-08-21 15:58:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 15:58:57 --> Pagination Class Initialized
INFO - 2023-08-21 15:58:57 --> Form Validation Class Initialized
INFO - 2023-08-21 15:58:57 --> Controller Class Initialized
INFO - 2023-08-21 15:58:57 --> Model Class Initialized
DEBUG - 2023-08-21 15:58:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 15:58:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:58:57 --> Model Class Initialized
DEBUG - 2023-08-21 15:58:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:58:57 --> Model Class Initialized
INFO - 2023-08-21 15:58:57 --> Final output sent to browser
DEBUG - 2023-08-21 15:58:57 --> Total execution time: 0.0249
ERROR - 2023-08-21 15:58:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 15:58:59 --> Config Class Initialized
INFO - 2023-08-21 15:58:59 --> Hooks Class Initialized
DEBUG - 2023-08-21 15:58:59 --> UTF-8 Support Enabled
INFO - 2023-08-21 15:58:59 --> Utf8 Class Initialized
INFO - 2023-08-21 15:58:59 --> URI Class Initialized
INFO - 2023-08-21 15:58:59 --> Router Class Initialized
INFO - 2023-08-21 15:58:59 --> Output Class Initialized
INFO - 2023-08-21 15:58:59 --> Security Class Initialized
DEBUG - 2023-08-21 15:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 15:58:59 --> Input Class Initialized
INFO - 2023-08-21 15:58:59 --> Language Class Initialized
INFO - 2023-08-21 15:58:59 --> Loader Class Initialized
INFO - 2023-08-21 15:58:59 --> Helper loaded: url_helper
INFO - 2023-08-21 15:58:59 --> Helper loaded: file_helper
INFO - 2023-08-21 15:58:59 --> Helper loaded: html_helper
INFO - 2023-08-21 15:58:59 --> Helper loaded: text_helper
INFO - 2023-08-21 15:58:59 --> Helper loaded: form_helper
INFO - 2023-08-21 15:58:59 --> Helper loaded: lang_helper
INFO - 2023-08-21 15:58:59 --> Helper loaded: security_helper
INFO - 2023-08-21 15:58:59 --> Helper loaded: cookie_helper
INFO - 2023-08-21 15:58:59 --> Database Driver Class Initialized
INFO - 2023-08-21 15:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 15:58:59 --> Parser Class Initialized
INFO - 2023-08-21 15:58:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 15:58:59 --> Pagination Class Initialized
INFO - 2023-08-21 15:58:59 --> Form Validation Class Initialized
INFO - 2023-08-21 15:58:59 --> Controller Class Initialized
INFO - 2023-08-21 15:58:59 --> Model Class Initialized
DEBUG - 2023-08-21 15:58:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 15:58:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:58:59 --> Model Class Initialized
DEBUG - 2023-08-21 15:58:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:58:59 --> Model Class Initialized
INFO - 2023-08-21 15:58:59 --> Final output sent to browser
DEBUG - 2023-08-21 15:58:59 --> Total execution time: 0.0409
ERROR - 2023-08-21 15:59:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 15:59:05 --> Config Class Initialized
INFO - 2023-08-21 15:59:05 --> Hooks Class Initialized
DEBUG - 2023-08-21 15:59:05 --> UTF-8 Support Enabled
INFO - 2023-08-21 15:59:05 --> Utf8 Class Initialized
INFO - 2023-08-21 15:59:05 --> URI Class Initialized
INFO - 2023-08-21 15:59:05 --> Router Class Initialized
INFO - 2023-08-21 15:59:05 --> Output Class Initialized
INFO - 2023-08-21 15:59:05 --> Security Class Initialized
DEBUG - 2023-08-21 15:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 15:59:05 --> Input Class Initialized
INFO - 2023-08-21 15:59:05 --> Language Class Initialized
INFO - 2023-08-21 15:59:05 --> Loader Class Initialized
INFO - 2023-08-21 15:59:05 --> Helper loaded: url_helper
INFO - 2023-08-21 15:59:05 --> Helper loaded: file_helper
INFO - 2023-08-21 15:59:05 --> Helper loaded: html_helper
INFO - 2023-08-21 15:59:05 --> Helper loaded: text_helper
INFO - 2023-08-21 15:59:05 --> Helper loaded: form_helper
INFO - 2023-08-21 15:59:05 --> Helper loaded: lang_helper
INFO - 2023-08-21 15:59:05 --> Helper loaded: security_helper
INFO - 2023-08-21 15:59:05 --> Helper loaded: cookie_helper
INFO - 2023-08-21 15:59:05 --> Database Driver Class Initialized
INFO - 2023-08-21 15:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 15:59:05 --> Parser Class Initialized
INFO - 2023-08-21 15:59:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 15:59:05 --> Pagination Class Initialized
INFO - 2023-08-21 15:59:05 --> Form Validation Class Initialized
INFO - 2023-08-21 15:59:05 --> Controller Class Initialized
INFO - 2023-08-21 15:59:05 --> Model Class Initialized
DEBUG - 2023-08-21 15:59:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 15:59:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:59:05 --> Model Class Initialized
DEBUG - 2023-08-21 15:59:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:59:05 --> Model Class Initialized
DEBUG - 2023-08-21 15:59:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:59:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-21 15:59:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:59:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 15:59:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 15:59:05 --> Model Class Initialized
INFO - 2023-08-21 15:59:05 --> Model Class Initialized
INFO - 2023-08-21 15:59:05 --> Model Class Initialized
INFO - 2023-08-21 15:59:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 15:59:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 15:59:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 15:59:05 --> Final output sent to browser
DEBUG - 2023-08-21 15:59:05 --> Total execution time: 0.1048
ERROR - 2023-08-21 15:59:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 15:59:38 --> Config Class Initialized
INFO - 2023-08-21 15:59:38 --> Hooks Class Initialized
DEBUG - 2023-08-21 15:59:38 --> UTF-8 Support Enabled
INFO - 2023-08-21 15:59:38 --> Utf8 Class Initialized
INFO - 2023-08-21 15:59:38 --> URI Class Initialized
INFO - 2023-08-21 15:59:38 --> Router Class Initialized
INFO - 2023-08-21 15:59:38 --> Output Class Initialized
INFO - 2023-08-21 15:59:38 --> Security Class Initialized
DEBUG - 2023-08-21 15:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 15:59:38 --> Input Class Initialized
INFO - 2023-08-21 15:59:38 --> Language Class Initialized
INFO - 2023-08-21 15:59:38 --> Loader Class Initialized
INFO - 2023-08-21 15:59:38 --> Helper loaded: url_helper
INFO - 2023-08-21 15:59:38 --> Helper loaded: file_helper
INFO - 2023-08-21 15:59:38 --> Helper loaded: html_helper
INFO - 2023-08-21 15:59:38 --> Helper loaded: text_helper
INFO - 2023-08-21 15:59:38 --> Helper loaded: form_helper
INFO - 2023-08-21 15:59:38 --> Helper loaded: lang_helper
INFO - 2023-08-21 15:59:38 --> Helper loaded: security_helper
INFO - 2023-08-21 15:59:38 --> Helper loaded: cookie_helper
INFO - 2023-08-21 15:59:38 --> Database Driver Class Initialized
INFO - 2023-08-21 15:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 15:59:38 --> Parser Class Initialized
INFO - 2023-08-21 15:59:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 15:59:38 --> Pagination Class Initialized
INFO - 2023-08-21 15:59:38 --> Form Validation Class Initialized
INFO - 2023-08-21 15:59:38 --> Controller Class Initialized
INFO - 2023-08-21 15:59:38 --> Model Class Initialized
DEBUG - 2023-08-21 15:59:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:59:38 --> Model Class Initialized
INFO - 2023-08-21 15:59:38 --> Final output sent to browser
DEBUG - 2023-08-21 15:59:38 --> Total execution time: 0.0188
ERROR - 2023-08-21 15:59:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 15:59:38 --> Config Class Initialized
INFO - 2023-08-21 15:59:38 --> Hooks Class Initialized
DEBUG - 2023-08-21 15:59:38 --> UTF-8 Support Enabled
INFO - 2023-08-21 15:59:38 --> Utf8 Class Initialized
INFO - 2023-08-21 15:59:38 --> URI Class Initialized
DEBUG - 2023-08-21 15:59:38 --> No URI present. Default controller set.
INFO - 2023-08-21 15:59:38 --> Router Class Initialized
INFO - 2023-08-21 15:59:38 --> Output Class Initialized
INFO - 2023-08-21 15:59:38 --> Security Class Initialized
DEBUG - 2023-08-21 15:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 15:59:38 --> Input Class Initialized
INFO - 2023-08-21 15:59:38 --> Language Class Initialized
INFO - 2023-08-21 15:59:38 --> Loader Class Initialized
INFO - 2023-08-21 15:59:38 --> Helper loaded: url_helper
INFO - 2023-08-21 15:59:38 --> Helper loaded: file_helper
INFO - 2023-08-21 15:59:38 --> Helper loaded: html_helper
INFO - 2023-08-21 15:59:38 --> Helper loaded: text_helper
INFO - 2023-08-21 15:59:38 --> Helper loaded: form_helper
INFO - 2023-08-21 15:59:38 --> Helper loaded: lang_helper
INFO - 2023-08-21 15:59:38 --> Helper loaded: security_helper
INFO - 2023-08-21 15:59:38 --> Helper loaded: cookie_helper
INFO - 2023-08-21 15:59:38 --> Database Driver Class Initialized
INFO - 2023-08-21 15:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 15:59:38 --> Parser Class Initialized
INFO - 2023-08-21 15:59:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 15:59:38 --> Pagination Class Initialized
INFO - 2023-08-21 15:59:38 --> Form Validation Class Initialized
INFO - 2023-08-21 15:59:38 --> Controller Class Initialized
INFO - 2023-08-21 15:59:38 --> Model Class Initialized
DEBUG - 2023-08-21 15:59:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:59:38 --> Model Class Initialized
DEBUG - 2023-08-21 15:59:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:59:38 --> Model Class Initialized
INFO - 2023-08-21 15:59:38 --> Model Class Initialized
INFO - 2023-08-21 15:59:38 --> Model Class Initialized
INFO - 2023-08-21 15:59:38 --> Model Class Initialized
DEBUG - 2023-08-21 15:59:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 15:59:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:59:38 --> Model Class Initialized
INFO - 2023-08-21 15:59:38 --> Model Class Initialized
INFO - 2023-08-21 15:59:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-21 15:59:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:59:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 15:59:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 15:59:39 --> Model Class Initialized
INFO - 2023-08-21 15:59:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 15:59:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 15:59:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 15:59:39 --> Final output sent to browser
DEBUG - 2023-08-21 15:59:39 --> Total execution time: 0.1908
ERROR - 2023-08-21 15:59:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 15:59:39 --> Config Class Initialized
INFO - 2023-08-21 15:59:39 --> Hooks Class Initialized
DEBUG - 2023-08-21 15:59:39 --> UTF-8 Support Enabled
INFO - 2023-08-21 15:59:39 --> Utf8 Class Initialized
INFO - 2023-08-21 15:59:39 --> URI Class Initialized
INFO - 2023-08-21 15:59:39 --> Router Class Initialized
INFO - 2023-08-21 15:59:39 --> Output Class Initialized
INFO - 2023-08-21 15:59:39 --> Security Class Initialized
DEBUG - 2023-08-21 15:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 15:59:39 --> Input Class Initialized
INFO - 2023-08-21 15:59:39 --> Language Class Initialized
INFO - 2023-08-21 15:59:39 --> Loader Class Initialized
INFO - 2023-08-21 15:59:39 --> Helper loaded: url_helper
INFO - 2023-08-21 15:59:39 --> Helper loaded: file_helper
INFO - 2023-08-21 15:59:39 --> Helper loaded: html_helper
INFO - 2023-08-21 15:59:39 --> Helper loaded: text_helper
INFO - 2023-08-21 15:59:39 --> Helper loaded: form_helper
INFO - 2023-08-21 15:59:39 --> Helper loaded: lang_helper
INFO - 2023-08-21 15:59:39 --> Helper loaded: security_helper
INFO - 2023-08-21 15:59:39 --> Helper loaded: cookie_helper
INFO - 2023-08-21 15:59:39 --> Database Driver Class Initialized
INFO - 2023-08-21 15:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 15:59:39 --> Parser Class Initialized
INFO - 2023-08-21 15:59:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 15:59:39 --> Pagination Class Initialized
INFO - 2023-08-21 15:59:39 --> Form Validation Class Initialized
INFO - 2023-08-21 15:59:39 --> Controller Class Initialized
DEBUG - 2023-08-21 15:59:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 15:59:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:59:39 --> Model Class Initialized
INFO - 2023-08-21 15:59:39 --> Final output sent to browser
DEBUG - 2023-08-21 15:59:39 --> Total execution time: 0.0134
ERROR - 2023-08-21 15:59:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 15:59:46 --> Config Class Initialized
INFO - 2023-08-21 15:59:46 --> Hooks Class Initialized
DEBUG - 2023-08-21 15:59:46 --> UTF-8 Support Enabled
INFO - 2023-08-21 15:59:46 --> Utf8 Class Initialized
INFO - 2023-08-21 15:59:46 --> URI Class Initialized
INFO - 2023-08-21 15:59:46 --> Router Class Initialized
INFO - 2023-08-21 15:59:46 --> Output Class Initialized
INFO - 2023-08-21 15:59:46 --> Security Class Initialized
DEBUG - 2023-08-21 15:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 15:59:46 --> Input Class Initialized
INFO - 2023-08-21 15:59:46 --> Language Class Initialized
INFO - 2023-08-21 15:59:46 --> Loader Class Initialized
INFO - 2023-08-21 15:59:46 --> Helper loaded: url_helper
INFO - 2023-08-21 15:59:46 --> Helper loaded: file_helper
INFO - 2023-08-21 15:59:46 --> Helper loaded: html_helper
INFO - 2023-08-21 15:59:46 --> Helper loaded: text_helper
INFO - 2023-08-21 15:59:46 --> Helper loaded: form_helper
INFO - 2023-08-21 15:59:46 --> Helper loaded: lang_helper
INFO - 2023-08-21 15:59:46 --> Helper loaded: security_helper
INFO - 2023-08-21 15:59:46 --> Helper loaded: cookie_helper
INFO - 2023-08-21 15:59:46 --> Database Driver Class Initialized
INFO - 2023-08-21 15:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 15:59:46 --> Parser Class Initialized
INFO - 2023-08-21 15:59:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 15:59:46 --> Pagination Class Initialized
INFO - 2023-08-21 15:59:46 --> Form Validation Class Initialized
INFO - 2023-08-21 15:59:46 --> Controller Class Initialized
INFO - 2023-08-21 15:59:46 --> Model Class Initialized
DEBUG - 2023-08-21 15:59:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 15:59:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:59:46 --> Model Class Initialized
DEBUG - 2023-08-21 15:59:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:59:46 --> Model Class Initialized
INFO - 2023-08-21 15:59:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-21 15:59:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:59:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 15:59:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 15:59:46 --> Model Class Initialized
INFO - 2023-08-21 15:59:46 --> Model Class Initialized
INFO - 2023-08-21 15:59:46 --> Model Class Initialized
INFO - 2023-08-21 15:59:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 15:59:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 15:59:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 15:59:46 --> Final output sent to browser
DEBUG - 2023-08-21 15:59:46 --> Total execution time: 0.1623
ERROR - 2023-08-21 15:59:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 15:59:47 --> Config Class Initialized
INFO - 2023-08-21 15:59:47 --> Hooks Class Initialized
DEBUG - 2023-08-21 15:59:47 --> UTF-8 Support Enabled
INFO - 2023-08-21 15:59:47 --> Utf8 Class Initialized
INFO - 2023-08-21 15:59:47 --> URI Class Initialized
INFO - 2023-08-21 15:59:47 --> Router Class Initialized
INFO - 2023-08-21 15:59:47 --> Output Class Initialized
INFO - 2023-08-21 15:59:47 --> Security Class Initialized
DEBUG - 2023-08-21 15:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 15:59:47 --> Input Class Initialized
INFO - 2023-08-21 15:59:47 --> Language Class Initialized
INFO - 2023-08-21 15:59:47 --> Loader Class Initialized
INFO - 2023-08-21 15:59:47 --> Helper loaded: url_helper
INFO - 2023-08-21 15:59:47 --> Helper loaded: file_helper
INFO - 2023-08-21 15:59:47 --> Helper loaded: html_helper
INFO - 2023-08-21 15:59:47 --> Helper loaded: text_helper
INFO - 2023-08-21 15:59:47 --> Helper loaded: form_helper
INFO - 2023-08-21 15:59:47 --> Helper loaded: lang_helper
INFO - 2023-08-21 15:59:47 --> Helper loaded: security_helper
INFO - 2023-08-21 15:59:47 --> Helper loaded: cookie_helper
INFO - 2023-08-21 15:59:47 --> Database Driver Class Initialized
INFO - 2023-08-21 15:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 15:59:47 --> Parser Class Initialized
INFO - 2023-08-21 15:59:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 15:59:47 --> Pagination Class Initialized
INFO - 2023-08-21 15:59:47 --> Form Validation Class Initialized
INFO - 2023-08-21 15:59:47 --> Controller Class Initialized
INFO - 2023-08-21 15:59:47 --> Model Class Initialized
DEBUG - 2023-08-21 15:59:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 15:59:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:59:47 --> Model Class Initialized
DEBUG - 2023-08-21 15:59:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:59:47 --> Model Class Initialized
INFO - 2023-08-21 15:59:47 --> Final output sent to browser
DEBUG - 2023-08-21 15:59:47 --> Total execution time: 0.0599
ERROR - 2023-08-21 15:59:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 15:59:50 --> Config Class Initialized
INFO - 2023-08-21 15:59:50 --> Hooks Class Initialized
DEBUG - 2023-08-21 15:59:50 --> UTF-8 Support Enabled
INFO - 2023-08-21 15:59:50 --> Utf8 Class Initialized
INFO - 2023-08-21 15:59:50 --> URI Class Initialized
INFO - 2023-08-21 15:59:50 --> Router Class Initialized
INFO - 2023-08-21 15:59:50 --> Output Class Initialized
INFO - 2023-08-21 15:59:50 --> Security Class Initialized
DEBUG - 2023-08-21 15:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 15:59:50 --> Input Class Initialized
INFO - 2023-08-21 15:59:50 --> Language Class Initialized
INFO - 2023-08-21 15:59:50 --> Loader Class Initialized
INFO - 2023-08-21 15:59:50 --> Helper loaded: url_helper
INFO - 2023-08-21 15:59:50 --> Helper loaded: file_helper
INFO - 2023-08-21 15:59:50 --> Helper loaded: html_helper
INFO - 2023-08-21 15:59:50 --> Helper loaded: text_helper
INFO - 2023-08-21 15:59:50 --> Helper loaded: form_helper
INFO - 2023-08-21 15:59:50 --> Helper loaded: lang_helper
INFO - 2023-08-21 15:59:50 --> Helper loaded: security_helper
INFO - 2023-08-21 15:59:50 --> Helper loaded: cookie_helper
INFO - 2023-08-21 15:59:50 --> Database Driver Class Initialized
INFO - 2023-08-21 15:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 15:59:50 --> Parser Class Initialized
INFO - 2023-08-21 15:59:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 15:59:50 --> Pagination Class Initialized
INFO - 2023-08-21 15:59:50 --> Form Validation Class Initialized
INFO - 2023-08-21 15:59:50 --> Controller Class Initialized
INFO - 2023-08-21 15:59:50 --> Model Class Initialized
DEBUG - 2023-08-21 15:59:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 15:59:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:59:50 --> Model Class Initialized
DEBUG - 2023-08-21 15:59:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:59:50 --> Model Class Initialized
INFO - 2023-08-21 15:59:50 --> Final output sent to browser
DEBUG - 2023-08-21 15:59:50 --> Total execution time: 0.0851
ERROR - 2023-08-21 15:59:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 15:59:51 --> Config Class Initialized
INFO - 2023-08-21 15:59:51 --> Hooks Class Initialized
DEBUG - 2023-08-21 15:59:51 --> UTF-8 Support Enabled
INFO - 2023-08-21 15:59:51 --> Utf8 Class Initialized
INFO - 2023-08-21 15:59:51 --> URI Class Initialized
INFO - 2023-08-21 15:59:51 --> Router Class Initialized
INFO - 2023-08-21 15:59:51 --> Output Class Initialized
INFO - 2023-08-21 15:59:51 --> Security Class Initialized
DEBUG - 2023-08-21 15:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 15:59:51 --> Input Class Initialized
INFO - 2023-08-21 15:59:51 --> Language Class Initialized
INFO - 2023-08-21 15:59:51 --> Loader Class Initialized
INFO - 2023-08-21 15:59:51 --> Helper loaded: url_helper
INFO - 2023-08-21 15:59:51 --> Helper loaded: file_helper
INFO - 2023-08-21 15:59:51 --> Helper loaded: html_helper
INFO - 2023-08-21 15:59:51 --> Helper loaded: text_helper
INFO - 2023-08-21 15:59:51 --> Helper loaded: form_helper
INFO - 2023-08-21 15:59:51 --> Helper loaded: lang_helper
INFO - 2023-08-21 15:59:51 --> Helper loaded: security_helper
INFO - 2023-08-21 15:59:51 --> Helper loaded: cookie_helper
INFO - 2023-08-21 15:59:51 --> Database Driver Class Initialized
INFO - 2023-08-21 15:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 15:59:51 --> Parser Class Initialized
INFO - 2023-08-21 15:59:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 15:59:51 --> Pagination Class Initialized
INFO - 2023-08-21 15:59:51 --> Form Validation Class Initialized
INFO - 2023-08-21 15:59:51 --> Controller Class Initialized
INFO - 2023-08-21 15:59:51 --> Model Class Initialized
DEBUG - 2023-08-21 15:59:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 15:59:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:59:51 --> Model Class Initialized
DEBUG - 2023-08-21 15:59:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:59:51 --> Model Class Initialized
INFO - 2023-08-21 15:59:51 --> Final output sent to browser
DEBUG - 2023-08-21 15:59:51 --> Total execution time: 0.0232
ERROR - 2023-08-21 15:59:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 15:59:52 --> Config Class Initialized
INFO - 2023-08-21 15:59:52 --> Hooks Class Initialized
DEBUG - 2023-08-21 15:59:52 --> UTF-8 Support Enabled
INFO - 2023-08-21 15:59:52 --> Utf8 Class Initialized
INFO - 2023-08-21 15:59:52 --> URI Class Initialized
INFO - 2023-08-21 15:59:52 --> Router Class Initialized
INFO - 2023-08-21 15:59:52 --> Output Class Initialized
INFO - 2023-08-21 15:59:52 --> Security Class Initialized
DEBUG - 2023-08-21 15:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 15:59:52 --> Input Class Initialized
INFO - 2023-08-21 15:59:52 --> Language Class Initialized
INFO - 2023-08-21 15:59:52 --> Loader Class Initialized
INFO - 2023-08-21 15:59:52 --> Helper loaded: url_helper
INFO - 2023-08-21 15:59:52 --> Helper loaded: file_helper
INFO - 2023-08-21 15:59:52 --> Helper loaded: html_helper
INFO - 2023-08-21 15:59:52 --> Helper loaded: text_helper
INFO - 2023-08-21 15:59:52 --> Helper loaded: form_helper
INFO - 2023-08-21 15:59:52 --> Helper loaded: lang_helper
INFO - 2023-08-21 15:59:52 --> Helper loaded: security_helper
INFO - 2023-08-21 15:59:52 --> Helper loaded: cookie_helper
INFO - 2023-08-21 15:59:52 --> Database Driver Class Initialized
INFO - 2023-08-21 15:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 15:59:52 --> Parser Class Initialized
INFO - 2023-08-21 15:59:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 15:59:52 --> Pagination Class Initialized
INFO - 2023-08-21 15:59:52 --> Form Validation Class Initialized
INFO - 2023-08-21 15:59:52 --> Controller Class Initialized
INFO - 2023-08-21 15:59:52 --> Model Class Initialized
DEBUG - 2023-08-21 15:59:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 15:59:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:59:52 --> Model Class Initialized
DEBUG - 2023-08-21 15:59:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:59:52 --> Model Class Initialized
INFO - 2023-08-21 15:59:52 --> Final output sent to browser
DEBUG - 2023-08-21 15:59:52 --> Total execution time: 0.0570
ERROR - 2023-08-21 15:59:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 15:59:53 --> Config Class Initialized
INFO - 2023-08-21 15:59:53 --> Hooks Class Initialized
DEBUG - 2023-08-21 15:59:53 --> UTF-8 Support Enabled
INFO - 2023-08-21 15:59:53 --> Utf8 Class Initialized
INFO - 2023-08-21 15:59:53 --> URI Class Initialized
INFO - 2023-08-21 15:59:53 --> Router Class Initialized
INFO - 2023-08-21 15:59:53 --> Output Class Initialized
INFO - 2023-08-21 15:59:53 --> Security Class Initialized
DEBUG - 2023-08-21 15:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 15:59:53 --> Input Class Initialized
INFO - 2023-08-21 15:59:53 --> Language Class Initialized
INFO - 2023-08-21 15:59:53 --> Loader Class Initialized
INFO - 2023-08-21 15:59:53 --> Helper loaded: url_helper
INFO - 2023-08-21 15:59:53 --> Helper loaded: file_helper
INFO - 2023-08-21 15:59:53 --> Helper loaded: html_helper
INFO - 2023-08-21 15:59:53 --> Helper loaded: text_helper
INFO - 2023-08-21 15:59:53 --> Helper loaded: form_helper
INFO - 2023-08-21 15:59:53 --> Helper loaded: lang_helper
INFO - 2023-08-21 15:59:53 --> Helper loaded: security_helper
INFO - 2023-08-21 15:59:53 --> Helper loaded: cookie_helper
INFO - 2023-08-21 15:59:53 --> Database Driver Class Initialized
INFO - 2023-08-21 15:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 15:59:53 --> Parser Class Initialized
INFO - 2023-08-21 15:59:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 15:59:53 --> Pagination Class Initialized
INFO - 2023-08-21 15:59:53 --> Form Validation Class Initialized
INFO - 2023-08-21 15:59:53 --> Controller Class Initialized
INFO - 2023-08-21 15:59:53 --> Model Class Initialized
DEBUG - 2023-08-21 15:59:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 15:59:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:59:53 --> Model Class Initialized
DEBUG - 2023-08-21 15:59:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:59:53 --> Model Class Initialized
INFO - 2023-08-21 15:59:53 --> Final output sent to browser
DEBUG - 2023-08-21 15:59:53 --> Total execution time: 0.0615
ERROR - 2023-08-21 15:59:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 15:59:54 --> Config Class Initialized
INFO - 2023-08-21 15:59:54 --> Hooks Class Initialized
DEBUG - 2023-08-21 15:59:54 --> UTF-8 Support Enabled
INFO - 2023-08-21 15:59:54 --> Utf8 Class Initialized
INFO - 2023-08-21 15:59:54 --> URI Class Initialized
INFO - 2023-08-21 15:59:54 --> Router Class Initialized
INFO - 2023-08-21 15:59:54 --> Output Class Initialized
INFO - 2023-08-21 15:59:54 --> Security Class Initialized
DEBUG - 2023-08-21 15:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 15:59:54 --> Input Class Initialized
INFO - 2023-08-21 15:59:54 --> Language Class Initialized
INFO - 2023-08-21 15:59:54 --> Loader Class Initialized
INFO - 2023-08-21 15:59:54 --> Helper loaded: url_helper
INFO - 2023-08-21 15:59:54 --> Helper loaded: file_helper
INFO - 2023-08-21 15:59:54 --> Helper loaded: html_helper
INFO - 2023-08-21 15:59:54 --> Helper loaded: text_helper
INFO - 2023-08-21 15:59:54 --> Helper loaded: form_helper
INFO - 2023-08-21 15:59:54 --> Helper loaded: lang_helper
INFO - 2023-08-21 15:59:54 --> Helper loaded: security_helper
INFO - 2023-08-21 15:59:54 --> Helper loaded: cookie_helper
INFO - 2023-08-21 15:59:54 --> Database Driver Class Initialized
INFO - 2023-08-21 15:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 15:59:54 --> Parser Class Initialized
INFO - 2023-08-21 15:59:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 15:59:54 --> Pagination Class Initialized
INFO - 2023-08-21 15:59:54 --> Form Validation Class Initialized
INFO - 2023-08-21 15:59:54 --> Controller Class Initialized
INFO - 2023-08-21 15:59:54 --> Model Class Initialized
DEBUG - 2023-08-21 15:59:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 15:59:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:59:54 --> Model Class Initialized
DEBUG - 2023-08-21 15:59:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:59:54 --> Model Class Initialized
INFO - 2023-08-21 15:59:54 --> Final output sent to browser
DEBUG - 2023-08-21 15:59:54 --> Total execution time: 0.0277
ERROR - 2023-08-21 15:59:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 15:59:54 --> Config Class Initialized
INFO - 2023-08-21 15:59:54 --> Hooks Class Initialized
DEBUG - 2023-08-21 15:59:54 --> UTF-8 Support Enabled
INFO - 2023-08-21 15:59:54 --> Utf8 Class Initialized
INFO - 2023-08-21 15:59:54 --> URI Class Initialized
INFO - 2023-08-21 15:59:54 --> Router Class Initialized
INFO - 2023-08-21 15:59:54 --> Output Class Initialized
INFO - 2023-08-21 15:59:54 --> Security Class Initialized
DEBUG - 2023-08-21 15:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 15:59:54 --> Input Class Initialized
INFO - 2023-08-21 15:59:54 --> Language Class Initialized
INFO - 2023-08-21 15:59:54 --> Loader Class Initialized
INFO - 2023-08-21 15:59:54 --> Helper loaded: url_helper
INFO - 2023-08-21 15:59:54 --> Helper loaded: file_helper
INFO - 2023-08-21 15:59:54 --> Helper loaded: html_helper
INFO - 2023-08-21 15:59:54 --> Helper loaded: text_helper
INFO - 2023-08-21 15:59:54 --> Helper loaded: form_helper
INFO - 2023-08-21 15:59:54 --> Helper loaded: lang_helper
INFO - 2023-08-21 15:59:54 --> Helper loaded: security_helper
INFO - 2023-08-21 15:59:54 --> Helper loaded: cookie_helper
INFO - 2023-08-21 15:59:54 --> Database Driver Class Initialized
INFO - 2023-08-21 15:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 15:59:54 --> Parser Class Initialized
INFO - 2023-08-21 15:59:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 15:59:54 --> Pagination Class Initialized
INFO - 2023-08-21 15:59:54 --> Form Validation Class Initialized
INFO - 2023-08-21 15:59:54 --> Controller Class Initialized
INFO - 2023-08-21 15:59:54 --> Model Class Initialized
DEBUG - 2023-08-21 15:59:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 15:59:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:59:54 --> Model Class Initialized
DEBUG - 2023-08-21 15:59:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:59:54 --> Model Class Initialized
INFO - 2023-08-21 15:59:55 --> Final output sent to browser
DEBUG - 2023-08-21 15:59:55 --> Total execution time: 0.0634
ERROR - 2023-08-21 15:59:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 15:59:55 --> Config Class Initialized
INFO - 2023-08-21 15:59:55 --> Hooks Class Initialized
DEBUG - 2023-08-21 15:59:55 --> UTF-8 Support Enabled
INFO - 2023-08-21 15:59:55 --> Utf8 Class Initialized
INFO - 2023-08-21 15:59:55 --> URI Class Initialized
INFO - 2023-08-21 15:59:55 --> Router Class Initialized
INFO - 2023-08-21 15:59:55 --> Output Class Initialized
INFO - 2023-08-21 15:59:55 --> Security Class Initialized
DEBUG - 2023-08-21 15:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 15:59:55 --> Input Class Initialized
INFO - 2023-08-21 15:59:55 --> Language Class Initialized
INFO - 2023-08-21 15:59:55 --> Loader Class Initialized
INFO - 2023-08-21 15:59:55 --> Helper loaded: url_helper
INFO - 2023-08-21 15:59:55 --> Helper loaded: file_helper
INFO - 2023-08-21 15:59:55 --> Helper loaded: html_helper
INFO - 2023-08-21 15:59:55 --> Helper loaded: text_helper
INFO - 2023-08-21 15:59:55 --> Helper loaded: form_helper
INFO - 2023-08-21 15:59:55 --> Helper loaded: lang_helper
INFO - 2023-08-21 15:59:55 --> Helper loaded: security_helper
INFO - 2023-08-21 15:59:55 --> Helper loaded: cookie_helper
INFO - 2023-08-21 15:59:55 --> Database Driver Class Initialized
INFO - 2023-08-21 15:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 15:59:55 --> Parser Class Initialized
INFO - 2023-08-21 15:59:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 15:59:55 --> Pagination Class Initialized
INFO - 2023-08-21 15:59:55 --> Form Validation Class Initialized
INFO - 2023-08-21 15:59:55 --> Controller Class Initialized
INFO - 2023-08-21 15:59:55 --> Model Class Initialized
DEBUG - 2023-08-21 15:59:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 15:59:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:59:55 --> Model Class Initialized
DEBUG - 2023-08-21 15:59:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:59:55 --> Model Class Initialized
INFO - 2023-08-21 15:59:55 --> Final output sent to browser
DEBUG - 2023-08-21 15:59:55 --> Total execution time: 0.0600
ERROR - 2023-08-21 15:59:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 15:59:56 --> Config Class Initialized
INFO - 2023-08-21 15:59:56 --> Hooks Class Initialized
DEBUG - 2023-08-21 15:59:56 --> UTF-8 Support Enabled
INFO - 2023-08-21 15:59:56 --> Utf8 Class Initialized
INFO - 2023-08-21 15:59:56 --> URI Class Initialized
INFO - 2023-08-21 15:59:56 --> Router Class Initialized
INFO - 2023-08-21 15:59:56 --> Output Class Initialized
INFO - 2023-08-21 15:59:56 --> Security Class Initialized
DEBUG - 2023-08-21 15:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 15:59:56 --> Input Class Initialized
INFO - 2023-08-21 15:59:56 --> Language Class Initialized
INFO - 2023-08-21 15:59:56 --> Loader Class Initialized
INFO - 2023-08-21 15:59:56 --> Helper loaded: url_helper
INFO - 2023-08-21 15:59:56 --> Helper loaded: file_helper
INFO - 2023-08-21 15:59:56 --> Helper loaded: html_helper
INFO - 2023-08-21 15:59:56 --> Helper loaded: text_helper
INFO - 2023-08-21 15:59:56 --> Helper loaded: form_helper
INFO - 2023-08-21 15:59:56 --> Helper loaded: lang_helper
INFO - 2023-08-21 15:59:56 --> Helper loaded: security_helper
INFO - 2023-08-21 15:59:56 --> Helper loaded: cookie_helper
INFO - 2023-08-21 15:59:56 --> Database Driver Class Initialized
INFO - 2023-08-21 15:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 15:59:56 --> Parser Class Initialized
INFO - 2023-08-21 15:59:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 15:59:56 --> Pagination Class Initialized
INFO - 2023-08-21 15:59:56 --> Form Validation Class Initialized
INFO - 2023-08-21 15:59:56 --> Controller Class Initialized
INFO - 2023-08-21 15:59:56 --> Model Class Initialized
DEBUG - 2023-08-21 15:59:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 15:59:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:59:56 --> Model Class Initialized
DEBUG - 2023-08-21 15:59:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:59:56 --> Model Class Initialized
INFO - 2023-08-21 15:59:56 --> Final output sent to browser
DEBUG - 2023-08-21 15:59:56 --> Total execution time: 0.0622
ERROR - 2023-08-21 15:59:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 15:59:56 --> Config Class Initialized
INFO - 2023-08-21 15:59:56 --> Hooks Class Initialized
DEBUG - 2023-08-21 15:59:56 --> UTF-8 Support Enabled
INFO - 2023-08-21 15:59:56 --> Utf8 Class Initialized
INFO - 2023-08-21 15:59:56 --> URI Class Initialized
INFO - 2023-08-21 15:59:56 --> Router Class Initialized
INFO - 2023-08-21 15:59:56 --> Output Class Initialized
INFO - 2023-08-21 15:59:56 --> Security Class Initialized
DEBUG - 2023-08-21 15:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 15:59:56 --> Input Class Initialized
INFO - 2023-08-21 15:59:56 --> Language Class Initialized
INFO - 2023-08-21 15:59:56 --> Loader Class Initialized
INFO - 2023-08-21 15:59:56 --> Helper loaded: url_helper
INFO - 2023-08-21 15:59:56 --> Helper loaded: file_helper
INFO - 2023-08-21 15:59:56 --> Helper loaded: html_helper
INFO - 2023-08-21 15:59:56 --> Helper loaded: text_helper
INFO - 2023-08-21 15:59:56 --> Helper loaded: form_helper
INFO - 2023-08-21 15:59:56 --> Helper loaded: lang_helper
INFO - 2023-08-21 15:59:56 --> Helper loaded: security_helper
INFO - 2023-08-21 15:59:56 --> Helper loaded: cookie_helper
INFO - 2023-08-21 15:59:56 --> Database Driver Class Initialized
INFO - 2023-08-21 15:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 15:59:56 --> Parser Class Initialized
INFO - 2023-08-21 15:59:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 15:59:56 --> Pagination Class Initialized
INFO - 2023-08-21 15:59:56 --> Form Validation Class Initialized
INFO - 2023-08-21 15:59:56 --> Controller Class Initialized
INFO - 2023-08-21 15:59:56 --> Model Class Initialized
DEBUG - 2023-08-21 15:59:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 15:59:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:59:56 --> Model Class Initialized
DEBUG - 2023-08-21 15:59:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:59:56 --> Model Class Initialized
INFO - 2023-08-21 15:59:56 --> Final output sent to browser
DEBUG - 2023-08-21 15:59:56 --> Total execution time: 0.0625
ERROR - 2023-08-21 15:59:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 15:59:57 --> Config Class Initialized
INFO - 2023-08-21 15:59:57 --> Hooks Class Initialized
DEBUG - 2023-08-21 15:59:57 --> UTF-8 Support Enabled
INFO - 2023-08-21 15:59:57 --> Utf8 Class Initialized
INFO - 2023-08-21 15:59:57 --> URI Class Initialized
INFO - 2023-08-21 15:59:57 --> Router Class Initialized
INFO - 2023-08-21 15:59:57 --> Output Class Initialized
INFO - 2023-08-21 15:59:57 --> Security Class Initialized
DEBUG - 2023-08-21 15:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 15:59:57 --> Input Class Initialized
INFO - 2023-08-21 15:59:57 --> Language Class Initialized
INFO - 2023-08-21 15:59:57 --> Loader Class Initialized
INFO - 2023-08-21 15:59:57 --> Helper loaded: url_helper
INFO - 2023-08-21 15:59:57 --> Helper loaded: file_helper
INFO - 2023-08-21 15:59:57 --> Helper loaded: html_helper
INFO - 2023-08-21 15:59:57 --> Helper loaded: text_helper
INFO - 2023-08-21 15:59:57 --> Helper loaded: form_helper
INFO - 2023-08-21 15:59:57 --> Helper loaded: lang_helper
INFO - 2023-08-21 15:59:57 --> Helper loaded: security_helper
INFO - 2023-08-21 15:59:57 --> Helper loaded: cookie_helper
INFO - 2023-08-21 15:59:57 --> Database Driver Class Initialized
INFO - 2023-08-21 15:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 15:59:57 --> Parser Class Initialized
INFO - 2023-08-21 15:59:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 15:59:57 --> Pagination Class Initialized
INFO - 2023-08-21 15:59:57 --> Form Validation Class Initialized
INFO - 2023-08-21 15:59:57 --> Controller Class Initialized
INFO - 2023-08-21 15:59:57 --> Model Class Initialized
DEBUG - 2023-08-21 15:59:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 15:59:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:59:57 --> Model Class Initialized
DEBUG - 2023-08-21 15:59:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 15:59:57 --> Model Class Initialized
INFO - 2023-08-21 15:59:57 --> Final output sent to browser
DEBUG - 2023-08-21 15:59:57 --> Total execution time: 0.0292
ERROR - 2023-08-21 16:00:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:00:01 --> Config Class Initialized
INFO - 2023-08-21 16:00:01 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:00:01 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:00:01 --> Utf8 Class Initialized
INFO - 2023-08-21 16:00:01 --> URI Class Initialized
INFO - 2023-08-21 16:00:01 --> Router Class Initialized
INFO - 2023-08-21 16:00:01 --> Output Class Initialized
INFO - 2023-08-21 16:00:01 --> Security Class Initialized
DEBUG - 2023-08-21 16:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:00:01 --> Input Class Initialized
INFO - 2023-08-21 16:00:01 --> Language Class Initialized
INFO - 2023-08-21 16:00:01 --> Loader Class Initialized
INFO - 2023-08-21 16:00:01 --> Helper loaded: url_helper
INFO - 2023-08-21 16:00:01 --> Helper loaded: file_helper
INFO - 2023-08-21 16:00:01 --> Helper loaded: html_helper
INFO - 2023-08-21 16:00:01 --> Helper loaded: text_helper
INFO - 2023-08-21 16:00:01 --> Helper loaded: form_helper
INFO - 2023-08-21 16:00:01 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:00:01 --> Helper loaded: security_helper
INFO - 2023-08-21 16:00:01 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:00:01 --> Database Driver Class Initialized
INFO - 2023-08-21 16:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:00:01 --> Parser Class Initialized
INFO - 2023-08-21 16:00:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:00:01 --> Pagination Class Initialized
INFO - 2023-08-21 16:00:01 --> Form Validation Class Initialized
INFO - 2023-08-21 16:00:01 --> Controller Class Initialized
INFO - 2023-08-21 16:00:01 --> Model Class Initialized
DEBUG - 2023-08-21 16:00:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 16:00:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:00:01 --> Model Class Initialized
DEBUG - 2023-08-21 16:00:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:00:01 --> Model Class Initialized
DEBUG - 2023-08-21 16:00:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:00:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-21 16:00:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:00:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 16:00:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 16:00:01 --> Model Class Initialized
INFO - 2023-08-21 16:00:01 --> Model Class Initialized
INFO - 2023-08-21 16:00:01 --> Model Class Initialized
INFO - 2023-08-21 16:00:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 16:00:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 16:00:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 16:00:01 --> Final output sent to browser
DEBUG - 2023-08-21 16:00:01 --> Total execution time: 0.1638
ERROR - 2023-08-21 16:19:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:19:03 --> Config Class Initialized
INFO - 2023-08-21 16:19:03 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:19:03 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:19:03 --> Utf8 Class Initialized
INFO - 2023-08-21 16:19:03 --> URI Class Initialized
DEBUG - 2023-08-21 16:19:03 --> No URI present. Default controller set.
INFO - 2023-08-21 16:19:03 --> Router Class Initialized
INFO - 2023-08-21 16:19:03 --> Output Class Initialized
INFO - 2023-08-21 16:19:03 --> Security Class Initialized
DEBUG - 2023-08-21 16:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:19:03 --> Input Class Initialized
INFO - 2023-08-21 16:19:03 --> Language Class Initialized
INFO - 2023-08-21 16:19:03 --> Loader Class Initialized
INFO - 2023-08-21 16:19:03 --> Helper loaded: url_helper
INFO - 2023-08-21 16:19:03 --> Helper loaded: file_helper
INFO - 2023-08-21 16:19:03 --> Helper loaded: html_helper
INFO - 2023-08-21 16:19:03 --> Helper loaded: text_helper
INFO - 2023-08-21 16:19:03 --> Helper loaded: form_helper
INFO - 2023-08-21 16:19:03 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:19:03 --> Helper loaded: security_helper
INFO - 2023-08-21 16:19:03 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:19:03 --> Database Driver Class Initialized
INFO - 2023-08-21 16:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:19:03 --> Parser Class Initialized
INFO - 2023-08-21 16:19:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:19:03 --> Pagination Class Initialized
INFO - 2023-08-21 16:19:03 --> Form Validation Class Initialized
INFO - 2023-08-21 16:19:03 --> Controller Class Initialized
INFO - 2023-08-21 16:19:03 --> Model Class Initialized
DEBUG - 2023-08-21 16:19:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:19:03 --> Model Class Initialized
DEBUG - 2023-08-21 16:19:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:19:03 --> Model Class Initialized
INFO - 2023-08-21 16:19:03 --> Model Class Initialized
INFO - 2023-08-21 16:19:03 --> Model Class Initialized
INFO - 2023-08-21 16:19:03 --> Model Class Initialized
DEBUG - 2023-08-21 16:19:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 16:19:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:19:03 --> Model Class Initialized
INFO - 2023-08-21 16:19:03 --> Model Class Initialized
INFO - 2023-08-21 16:19:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-21 16:19:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:19:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 16:19:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 16:19:03 --> Model Class Initialized
INFO - 2023-08-21 16:19:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 16:19:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 16:19:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 16:19:04 --> Final output sent to browser
DEBUG - 2023-08-21 16:19:04 --> Total execution time: 0.2074
ERROR - 2023-08-21 16:20:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:20:38 --> Config Class Initialized
INFO - 2023-08-21 16:20:38 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:20:38 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:20:38 --> Utf8 Class Initialized
INFO - 2023-08-21 16:20:38 --> URI Class Initialized
INFO - 2023-08-21 16:20:38 --> Router Class Initialized
INFO - 2023-08-21 16:20:38 --> Output Class Initialized
INFO - 2023-08-21 16:20:38 --> Security Class Initialized
DEBUG - 2023-08-21 16:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:20:38 --> Input Class Initialized
INFO - 2023-08-21 16:20:38 --> Language Class Initialized
INFO - 2023-08-21 16:20:38 --> Loader Class Initialized
INFO - 2023-08-21 16:20:38 --> Helper loaded: url_helper
INFO - 2023-08-21 16:20:38 --> Helper loaded: file_helper
INFO - 2023-08-21 16:20:38 --> Helper loaded: html_helper
INFO - 2023-08-21 16:20:38 --> Helper loaded: text_helper
INFO - 2023-08-21 16:20:38 --> Helper loaded: form_helper
INFO - 2023-08-21 16:20:38 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:20:38 --> Helper loaded: security_helper
INFO - 2023-08-21 16:20:38 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:20:38 --> Database Driver Class Initialized
INFO - 2023-08-21 16:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:20:38 --> Parser Class Initialized
INFO - 2023-08-21 16:20:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:20:38 --> Pagination Class Initialized
INFO - 2023-08-21 16:20:38 --> Form Validation Class Initialized
INFO - 2023-08-21 16:20:38 --> Controller Class Initialized
DEBUG - 2023-08-21 16:20:38 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:20:38 --> Model Class Initialized
INFO - 2023-08-21 16:20:38 --> Model Class Initialized
INFO - 2023-08-21 16:20:38 --> Model Class Initialized
INFO - 2023-08-21 16:20:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product.php
DEBUG - 2023-08-21 16:20:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:20:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 16:20:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 16:20:38 --> Model Class Initialized
INFO - 2023-08-21 16:20:38 --> Model Class Initialized
INFO - 2023-08-21 16:20:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 16:20:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 16:20:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 16:20:38 --> Final output sent to browser
DEBUG - 2023-08-21 16:20:38 --> Total execution time: 0.1596
ERROR - 2023-08-21 16:20:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:20:39 --> Config Class Initialized
INFO - 2023-08-21 16:20:39 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:20:39 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:20:39 --> Utf8 Class Initialized
INFO - 2023-08-21 16:20:39 --> URI Class Initialized
INFO - 2023-08-21 16:20:39 --> Router Class Initialized
INFO - 2023-08-21 16:20:39 --> Output Class Initialized
INFO - 2023-08-21 16:20:39 --> Security Class Initialized
DEBUG - 2023-08-21 16:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:20:39 --> Input Class Initialized
INFO - 2023-08-21 16:20:39 --> Language Class Initialized
INFO - 2023-08-21 16:20:39 --> Loader Class Initialized
INFO - 2023-08-21 16:20:39 --> Helper loaded: url_helper
INFO - 2023-08-21 16:20:39 --> Helper loaded: file_helper
INFO - 2023-08-21 16:20:39 --> Helper loaded: html_helper
INFO - 2023-08-21 16:20:39 --> Helper loaded: text_helper
INFO - 2023-08-21 16:20:39 --> Helper loaded: form_helper
INFO - 2023-08-21 16:20:39 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:20:39 --> Helper loaded: security_helper
INFO - 2023-08-21 16:20:39 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:20:39 --> Database Driver Class Initialized
INFO - 2023-08-21 16:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:20:39 --> Parser Class Initialized
INFO - 2023-08-21 16:20:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:20:39 --> Pagination Class Initialized
INFO - 2023-08-21 16:20:39 --> Form Validation Class Initialized
INFO - 2023-08-21 16:20:39 --> Controller Class Initialized
DEBUG - 2023-08-21 16:20:39 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:20:39 --> Model Class Initialized
INFO - 2023-08-21 16:20:39 --> Model Class Initialized
INFO - 2023-08-21 16:20:40 --> Final output sent to browser
DEBUG - 2023-08-21 16:20:40 --> Total execution time: 0.0449
ERROR - 2023-08-21 16:20:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:20:46 --> Config Class Initialized
INFO - 2023-08-21 16:20:46 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:20:46 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:20:46 --> Utf8 Class Initialized
INFO - 2023-08-21 16:20:46 --> URI Class Initialized
INFO - 2023-08-21 16:20:46 --> Router Class Initialized
INFO - 2023-08-21 16:20:46 --> Output Class Initialized
INFO - 2023-08-21 16:20:46 --> Security Class Initialized
DEBUG - 2023-08-21 16:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:20:46 --> Input Class Initialized
INFO - 2023-08-21 16:20:46 --> Language Class Initialized
INFO - 2023-08-21 16:20:46 --> Loader Class Initialized
INFO - 2023-08-21 16:20:46 --> Helper loaded: url_helper
INFO - 2023-08-21 16:20:46 --> Helper loaded: file_helper
INFO - 2023-08-21 16:20:46 --> Helper loaded: html_helper
INFO - 2023-08-21 16:20:46 --> Helper loaded: text_helper
INFO - 2023-08-21 16:20:46 --> Helper loaded: form_helper
INFO - 2023-08-21 16:20:46 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:20:46 --> Helper loaded: security_helper
INFO - 2023-08-21 16:20:46 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:20:46 --> Database Driver Class Initialized
INFO - 2023-08-21 16:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:20:46 --> Parser Class Initialized
INFO - 2023-08-21 16:20:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:20:46 --> Pagination Class Initialized
INFO - 2023-08-21 16:20:46 --> Form Validation Class Initialized
INFO - 2023-08-21 16:20:46 --> Controller Class Initialized
DEBUG - 2023-08-21 16:20:46 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:20:46 --> Model Class Initialized
INFO - 2023-08-21 16:20:46 --> Model Class Initialized
INFO - 2023-08-21 16:20:46 --> Model Class Initialized
INFO - 2023-08-21 16:20:46 --> Model Class Initialized
INFO - 2023-08-21 16:20:46 --> Model Class Initialized
INFO - 2023-08-21 16:20:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/add_product_form.php
DEBUG - 2023-08-21 16:20:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:20:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 16:20:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 16:20:47 --> Model Class Initialized
INFO - 2023-08-21 16:20:47 --> Model Class Initialized
INFO - 2023-08-21 16:20:47 --> Model Class Initialized
INFO - 2023-08-21 16:20:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 16:20:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 16:20:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 16:20:47 --> Final output sent to browser
DEBUG - 2023-08-21 16:20:47 --> Total execution time: 0.1853
ERROR - 2023-08-21 16:28:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:28:01 --> Config Class Initialized
INFO - 2023-08-21 16:28:01 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:28:01 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:28:01 --> Utf8 Class Initialized
INFO - 2023-08-21 16:28:01 --> URI Class Initialized
INFO - 2023-08-21 16:28:01 --> Router Class Initialized
INFO - 2023-08-21 16:28:01 --> Output Class Initialized
INFO - 2023-08-21 16:28:01 --> Security Class Initialized
DEBUG - 2023-08-21 16:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:28:01 --> Input Class Initialized
INFO - 2023-08-21 16:28:01 --> Language Class Initialized
INFO - 2023-08-21 16:28:01 --> Loader Class Initialized
INFO - 2023-08-21 16:28:01 --> Helper loaded: url_helper
INFO - 2023-08-21 16:28:01 --> Helper loaded: file_helper
INFO - 2023-08-21 16:28:01 --> Helper loaded: html_helper
INFO - 2023-08-21 16:28:01 --> Helper loaded: text_helper
INFO - 2023-08-21 16:28:01 --> Helper loaded: form_helper
INFO - 2023-08-21 16:28:01 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:28:01 --> Helper loaded: security_helper
INFO - 2023-08-21 16:28:01 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:28:01 --> Database Driver Class Initialized
INFO - 2023-08-21 16:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:28:01 --> Parser Class Initialized
INFO - 2023-08-21 16:28:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:28:01 --> Pagination Class Initialized
INFO - 2023-08-21 16:28:01 --> Form Validation Class Initialized
INFO - 2023-08-21 16:28:01 --> Controller Class Initialized
DEBUG - 2023-08-21 16:28:01 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:28:01 --> Model Class Initialized
INFO - 2023-08-21 16:28:01 --> Model Class Initialized
INFO - 2023-08-21 16:28:01 --> Final output sent to browser
DEBUG - 2023-08-21 16:28:01 --> Total execution time: 0.0252
ERROR - 2023-08-21 16:28:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:28:08 --> Config Class Initialized
INFO - 2023-08-21 16:28:08 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:28:08 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:28:08 --> Utf8 Class Initialized
INFO - 2023-08-21 16:28:08 --> URI Class Initialized
INFO - 2023-08-21 16:28:08 --> Router Class Initialized
INFO - 2023-08-21 16:28:08 --> Output Class Initialized
INFO - 2023-08-21 16:28:08 --> Security Class Initialized
DEBUG - 2023-08-21 16:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:28:08 --> Input Class Initialized
INFO - 2023-08-21 16:28:08 --> Language Class Initialized
INFO - 2023-08-21 16:28:08 --> Loader Class Initialized
INFO - 2023-08-21 16:28:08 --> Helper loaded: url_helper
INFO - 2023-08-21 16:28:08 --> Helper loaded: file_helper
INFO - 2023-08-21 16:28:08 --> Helper loaded: html_helper
INFO - 2023-08-21 16:28:08 --> Helper loaded: text_helper
INFO - 2023-08-21 16:28:08 --> Helper loaded: form_helper
INFO - 2023-08-21 16:28:08 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:28:08 --> Helper loaded: security_helper
INFO - 2023-08-21 16:28:08 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:28:08 --> Database Driver Class Initialized
INFO - 2023-08-21 16:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:28:08 --> Parser Class Initialized
INFO - 2023-08-21 16:28:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:28:08 --> Pagination Class Initialized
INFO - 2023-08-21 16:28:08 --> Form Validation Class Initialized
INFO - 2023-08-21 16:28:08 --> Controller Class Initialized
DEBUG - 2023-08-21 16:28:08 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:28:08 --> Model Class Initialized
INFO - 2023-08-21 16:28:08 --> Model Class Initialized
INFO - 2023-08-21 16:28:08 --> Final output sent to browser
DEBUG - 2023-08-21 16:28:08 --> Total execution time: 0.0202
ERROR - 2023-08-21 16:28:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:28:25 --> Config Class Initialized
INFO - 2023-08-21 16:28:25 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:28:25 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:28:25 --> Utf8 Class Initialized
INFO - 2023-08-21 16:28:25 --> URI Class Initialized
DEBUG - 2023-08-21 16:28:25 --> No URI present. Default controller set.
INFO - 2023-08-21 16:28:25 --> Router Class Initialized
INFO - 2023-08-21 16:28:25 --> Output Class Initialized
INFO - 2023-08-21 16:28:25 --> Security Class Initialized
DEBUG - 2023-08-21 16:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:28:25 --> Input Class Initialized
INFO - 2023-08-21 16:28:25 --> Language Class Initialized
INFO - 2023-08-21 16:28:25 --> Loader Class Initialized
INFO - 2023-08-21 16:28:25 --> Helper loaded: url_helper
INFO - 2023-08-21 16:28:25 --> Helper loaded: file_helper
INFO - 2023-08-21 16:28:25 --> Helper loaded: html_helper
INFO - 2023-08-21 16:28:25 --> Helper loaded: text_helper
INFO - 2023-08-21 16:28:25 --> Helper loaded: form_helper
INFO - 2023-08-21 16:28:25 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:28:25 --> Helper loaded: security_helper
INFO - 2023-08-21 16:28:25 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:28:25 --> Database Driver Class Initialized
INFO - 2023-08-21 16:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:28:25 --> Parser Class Initialized
INFO - 2023-08-21 16:28:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:28:25 --> Pagination Class Initialized
INFO - 2023-08-21 16:28:25 --> Form Validation Class Initialized
INFO - 2023-08-21 16:28:25 --> Controller Class Initialized
INFO - 2023-08-21 16:28:25 --> Model Class Initialized
DEBUG - 2023-08-21 16:28:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:28:25 --> Model Class Initialized
DEBUG - 2023-08-21 16:28:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:28:25 --> Model Class Initialized
INFO - 2023-08-21 16:28:25 --> Model Class Initialized
INFO - 2023-08-21 16:28:25 --> Model Class Initialized
INFO - 2023-08-21 16:28:25 --> Model Class Initialized
DEBUG - 2023-08-21 16:28:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 16:28:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:28:25 --> Model Class Initialized
INFO - 2023-08-21 16:28:25 --> Model Class Initialized
INFO - 2023-08-21 16:28:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-21 16:28:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:28:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 16:28:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 16:28:25 --> Model Class Initialized
INFO - 2023-08-21 16:28:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 16:28:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 16:28:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 16:28:25 --> Final output sent to browser
DEBUG - 2023-08-21 16:28:25 --> Total execution time: 0.1942
ERROR - 2023-08-21 16:28:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:28:33 --> Config Class Initialized
INFO - 2023-08-21 16:28:33 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:28:33 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:28:33 --> Utf8 Class Initialized
INFO - 2023-08-21 16:28:33 --> URI Class Initialized
INFO - 2023-08-21 16:28:33 --> Router Class Initialized
INFO - 2023-08-21 16:28:33 --> Output Class Initialized
INFO - 2023-08-21 16:28:33 --> Security Class Initialized
DEBUG - 2023-08-21 16:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:28:33 --> Input Class Initialized
INFO - 2023-08-21 16:28:33 --> Language Class Initialized
INFO - 2023-08-21 16:28:33 --> Loader Class Initialized
INFO - 2023-08-21 16:28:33 --> Helper loaded: url_helper
INFO - 2023-08-21 16:28:33 --> Helper loaded: file_helper
INFO - 2023-08-21 16:28:33 --> Helper loaded: html_helper
INFO - 2023-08-21 16:28:33 --> Helper loaded: text_helper
INFO - 2023-08-21 16:28:33 --> Helper loaded: form_helper
INFO - 2023-08-21 16:28:33 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:28:33 --> Helper loaded: security_helper
INFO - 2023-08-21 16:28:33 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:28:33 --> Database Driver Class Initialized
INFO - 2023-08-21 16:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:28:33 --> Parser Class Initialized
INFO - 2023-08-21 16:28:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:28:33 --> Pagination Class Initialized
INFO - 2023-08-21 16:28:33 --> Form Validation Class Initialized
INFO - 2023-08-21 16:28:33 --> Controller Class Initialized
DEBUG - 2023-08-21 16:28:33 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:28:33 --> Model Class Initialized
INFO - 2023-08-21 16:28:33 --> Model Class Initialized
INFO - 2023-08-21 16:28:33 --> Model Class Initialized
INFO - 2023-08-21 16:28:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product.php
DEBUG - 2023-08-21 16:28:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:28:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 16:28:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 16:28:33 --> Model Class Initialized
INFO - 2023-08-21 16:28:33 --> Model Class Initialized
INFO - 2023-08-21 16:28:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 16:28:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 16:28:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 16:28:33 --> Final output sent to browser
DEBUG - 2023-08-21 16:28:33 --> Total execution time: 0.1500
ERROR - 2023-08-21 16:28:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:28:34 --> Config Class Initialized
INFO - 2023-08-21 16:28:34 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:28:34 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:28:34 --> Utf8 Class Initialized
INFO - 2023-08-21 16:28:34 --> URI Class Initialized
INFO - 2023-08-21 16:28:34 --> Router Class Initialized
INFO - 2023-08-21 16:28:34 --> Output Class Initialized
INFO - 2023-08-21 16:28:34 --> Security Class Initialized
DEBUG - 2023-08-21 16:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:28:34 --> Input Class Initialized
INFO - 2023-08-21 16:28:34 --> Language Class Initialized
INFO - 2023-08-21 16:28:34 --> Loader Class Initialized
INFO - 2023-08-21 16:28:34 --> Helper loaded: url_helper
INFO - 2023-08-21 16:28:34 --> Helper loaded: file_helper
INFO - 2023-08-21 16:28:34 --> Helper loaded: html_helper
INFO - 2023-08-21 16:28:34 --> Helper loaded: text_helper
INFO - 2023-08-21 16:28:34 --> Helper loaded: form_helper
INFO - 2023-08-21 16:28:34 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:28:34 --> Helper loaded: security_helper
INFO - 2023-08-21 16:28:34 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:28:34 --> Database Driver Class Initialized
INFO - 2023-08-21 16:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:28:34 --> Parser Class Initialized
INFO - 2023-08-21 16:28:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:28:34 --> Pagination Class Initialized
INFO - 2023-08-21 16:28:34 --> Form Validation Class Initialized
INFO - 2023-08-21 16:28:34 --> Controller Class Initialized
DEBUG - 2023-08-21 16:28:34 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:28:34 --> Model Class Initialized
INFO - 2023-08-21 16:28:34 --> Model Class Initialized
INFO - 2023-08-21 16:28:34 --> Final output sent to browser
DEBUG - 2023-08-21 16:28:34 --> Total execution time: 0.0468
ERROR - 2023-08-21 16:28:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:28:46 --> Config Class Initialized
INFO - 2023-08-21 16:28:46 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:28:46 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:28:46 --> Utf8 Class Initialized
INFO - 2023-08-21 16:28:46 --> URI Class Initialized
INFO - 2023-08-21 16:28:46 --> Router Class Initialized
INFO - 2023-08-21 16:28:46 --> Output Class Initialized
INFO - 2023-08-21 16:28:46 --> Security Class Initialized
DEBUG - 2023-08-21 16:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:28:46 --> Input Class Initialized
INFO - 2023-08-21 16:28:46 --> Language Class Initialized
INFO - 2023-08-21 16:28:46 --> Loader Class Initialized
INFO - 2023-08-21 16:28:46 --> Helper loaded: url_helper
INFO - 2023-08-21 16:28:46 --> Helper loaded: file_helper
INFO - 2023-08-21 16:28:46 --> Helper loaded: html_helper
INFO - 2023-08-21 16:28:46 --> Helper loaded: text_helper
INFO - 2023-08-21 16:28:46 --> Helper loaded: form_helper
INFO - 2023-08-21 16:28:46 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:28:46 --> Helper loaded: security_helper
INFO - 2023-08-21 16:28:46 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:28:46 --> Database Driver Class Initialized
INFO - 2023-08-21 16:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:28:46 --> Parser Class Initialized
INFO - 2023-08-21 16:28:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:28:46 --> Pagination Class Initialized
INFO - 2023-08-21 16:28:46 --> Form Validation Class Initialized
INFO - 2023-08-21 16:28:46 --> Controller Class Initialized
DEBUG - 2023-08-21 16:28:46 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:28:46 --> Model Class Initialized
INFO - 2023-08-21 16:28:46 --> Model Class Initialized
INFO - 2023-08-21 16:28:46 --> Final output sent to browser
DEBUG - 2023-08-21 16:28:46 --> Total execution time: 0.1260
ERROR - 2023-08-21 16:29:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:29:09 --> Config Class Initialized
INFO - 2023-08-21 16:29:09 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:29:09 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:29:09 --> Utf8 Class Initialized
INFO - 2023-08-21 16:29:09 --> URI Class Initialized
INFO - 2023-08-21 16:29:09 --> Router Class Initialized
INFO - 2023-08-21 16:29:09 --> Output Class Initialized
INFO - 2023-08-21 16:29:09 --> Security Class Initialized
DEBUG - 2023-08-21 16:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:29:09 --> Input Class Initialized
INFO - 2023-08-21 16:29:09 --> Language Class Initialized
INFO - 2023-08-21 16:29:09 --> Loader Class Initialized
INFO - 2023-08-21 16:29:09 --> Helper loaded: url_helper
INFO - 2023-08-21 16:29:09 --> Helper loaded: file_helper
INFO - 2023-08-21 16:29:09 --> Helper loaded: html_helper
INFO - 2023-08-21 16:29:09 --> Helper loaded: text_helper
INFO - 2023-08-21 16:29:09 --> Helper loaded: form_helper
INFO - 2023-08-21 16:29:09 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:29:09 --> Helper loaded: security_helper
INFO - 2023-08-21 16:29:09 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:29:09 --> Database Driver Class Initialized
INFO - 2023-08-21 16:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:29:09 --> Parser Class Initialized
INFO - 2023-08-21 16:29:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:29:09 --> Pagination Class Initialized
INFO - 2023-08-21 16:29:09 --> Form Validation Class Initialized
INFO - 2023-08-21 16:29:09 --> Controller Class Initialized
DEBUG - 2023-08-21 16:29:09 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:29:09 --> Model Class Initialized
INFO - 2023-08-21 16:29:09 --> Model Class Initialized
ERROR - 2023-08-21 16:29:09 --> Query error: Unknown column 'product_id' in 'where clause' - Invalid query: SELECT *
FROM `web_setting`
WHERE `product_id` = '55358743'
ERROR - 2023-08-21 16:29:09 --> Severity: error --> Exception: Call to a member function row() on bool /home/powera7m/app.maurnaturo.com/application/helpers/lang_helper.php 16
ERROR - 2023-08-21 16:29:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:29:16 --> Config Class Initialized
INFO - 2023-08-21 16:29:16 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:29:16 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:29:16 --> Utf8 Class Initialized
INFO - 2023-08-21 16:29:16 --> URI Class Initialized
DEBUG - 2023-08-21 16:29:16 --> No URI present. Default controller set.
INFO - 2023-08-21 16:29:16 --> Router Class Initialized
INFO - 2023-08-21 16:29:16 --> Output Class Initialized
INFO - 2023-08-21 16:29:16 --> Security Class Initialized
DEBUG - 2023-08-21 16:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:29:16 --> Input Class Initialized
INFO - 2023-08-21 16:29:16 --> Language Class Initialized
INFO - 2023-08-21 16:29:16 --> Loader Class Initialized
INFO - 2023-08-21 16:29:16 --> Helper loaded: url_helper
INFO - 2023-08-21 16:29:16 --> Helper loaded: file_helper
INFO - 2023-08-21 16:29:16 --> Helper loaded: html_helper
INFO - 2023-08-21 16:29:16 --> Helper loaded: text_helper
INFO - 2023-08-21 16:29:16 --> Helper loaded: form_helper
INFO - 2023-08-21 16:29:16 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:29:16 --> Helper loaded: security_helper
INFO - 2023-08-21 16:29:16 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:29:16 --> Database Driver Class Initialized
INFO - 2023-08-21 16:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:29:16 --> Parser Class Initialized
INFO - 2023-08-21 16:29:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:29:16 --> Pagination Class Initialized
INFO - 2023-08-21 16:29:16 --> Form Validation Class Initialized
INFO - 2023-08-21 16:29:16 --> Controller Class Initialized
INFO - 2023-08-21 16:29:16 --> Model Class Initialized
DEBUG - 2023-08-21 16:29:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:29:16 --> Model Class Initialized
DEBUG - 2023-08-21 16:29:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:29:16 --> Model Class Initialized
INFO - 2023-08-21 16:29:16 --> Model Class Initialized
INFO - 2023-08-21 16:29:16 --> Model Class Initialized
INFO - 2023-08-21 16:29:16 --> Model Class Initialized
DEBUG - 2023-08-21 16:29:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 16:29:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:29:16 --> Model Class Initialized
INFO - 2023-08-21 16:29:16 --> Model Class Initialized
INFO - 2023-08-21 16:29:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-21 16:29:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:29:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 16:29:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 16:29:16 --> Model Class Initialized
INFO - 2023-08-21 16:29:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 16:29:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 16:29:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 16:29:16 --> Final output sent to browser
DEBUG - 2023-08-21 16:29:16 --> Total execution time: 0.2241
ERROR - 2023-08-21 16:29:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:29:22 --> Config Class Initialized
INFO - 2023-08-21 16:29:22 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:29:22 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:29:22 --> Utf8 Class Initialized
INFO - 2023-08-21 16:29:22 --> URI Class Initialized
INFO - 2023-08-21 16:29:22 --> Router Class Initialized
INFO - 2023-08-21 16:29:22 --> Output Class Initialized
INFO - 2023-08-21 16:29:22 --> Security Class Initialized
DEBUG - 2023-08-21 16:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:29:22 --> Input Class Initialized
INFO - 2023-08-21 16:29:22 --> Language Class Initialized
INFO - 2023-08-21 16:29:22 --> Loader Class Initialized
INFO - 2023-08-21 16:29:22 --> Helper loaded: url_helper
INFO - 2023-08-21 16:29:22 --> Helper loaded: file_helper
INFO - 2023-08-21 16:29:22 --> Helper loaded: html_helper
INFO - 2023-08-21 16:29:22 --> Helper loaded: text_helper
INFO - 2023-08-21 16:29:22 --> Helper loaded: form_helper
INFO - 2023-08-21 16:29:22 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:29:22 --> Helper loaded: security_helper
INFO - 2023-08-21 16:29:22 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:29:22 --> Database Driver Class Initialized
INFO - 2023-08-21 16:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:29:22 --> Parser Class Initialized
INFO - 2023-08-21 16:29:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:29:22 --> Pagination Class Initialized
INFO - 2023-08-21 16:29:22 --> Form Validation Class Initialized
INFO - 2023-08-21 16:29:22 --> Controller Class Initialized
DEBUG - 2023-08-21 16:29:22 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:29:22 --> Model Class Initialized
INFO - 2023-08-21 16:29:22 --> Model Class Initialized
INFO - 2023-08-21 16:29:22 --> Model Class Initialized
INFO - 2023-08-21 16:29:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product.php
DEBUG - 2023-08-21 16:29:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:29:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 16:29:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 16:29:22 --> Model Class Initialized
INFO - 2023-08-21 16:29:22 --> Model Class Initialized
INFO - 2023-08-21 16:29:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 16:29:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 16:29:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 16:29:22 --> Final output sent to browser
DEBUG - 2023-08-21 16:29:22 --> Total execution time: 0.1235
ERROR - 2023-08-21 16:29:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:29:23 --> Config Class Initialized
INFO - 2023-08-21 16:29:23 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:29:23 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:29:23 --> Utf8 Class Initialized
INFO - 2023-08-21 16:29:23 --> URI Class Initialized
INFO - 2023-08-21 16:29:23 --> Router Class Initialized
INFO - 2023-08-21 16:29:23 --> Output Class Initialized
INFO - 2023-08-21 16:29:23 --> Security Class Initialized
DEBUG - 2023-08-21 16:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:29:23 --> Input Class Initialized
INFO - 2023-08-21 16:29:23 --> Language Class Initialized
INFO - 2023-08-21 16:29:23 --> Loader Class Initialized
INFO - 2023-08-21 16:29:23 --> Helper loaded: url_helper
INFO - 2023-08-21 16:29:23 --> Helper loaded: file_helper
INFO - 2023-08-21 16:29:23 --> Helper loaded: html_helper
INFO - 2023-08-21 16:29:23 --> Helper loaded: text_helper
INFO - 2023-08-21 16:29:23 --> Helper loaded: form_helper
INFO - 2023-08-21 16:29:23 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:29:23 --> Helper loaded: security_helper
INFO - 2023-08-21 16:29:23 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:29:23 --> Database Driver Class Initialized
INFO - 2023-08-21 16:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:29:23 --> Parser Class Initialized
INFO - 2023-08-21 16:29:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:29:23 --> Pagination Class Initialized
INFO - 2023-08-21 16:29:23 --> Form Validation Class Initialized
INFO - 2023-08-21 16:29:23 --> Controller Class Initialized
DEBUG - 2023-08-21 16:29:23 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:29:23 --> Model Class Initialized
INFO - 2023-08-21 16:29:23 --> Model Class Initialized
INFO - 2023-08-21 16:29:23 --> Final output sent to browser
DEBUG - 2023-08-21 16:29:23 --> Total execution time: 0.0432
ERROR - 2023-08-21 16:29:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:29:28 --> Config Class Initialized
INFO - 2023-08-21 16:29:28 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:29:28 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:29:28 --> Utf8 Class Initialized
INFO - 2023-08-21 16:29:28 --> URI Class Initialized
INFO - 2023-08-21 16:29:28 --> Router Class Initialized
INFO - 2023-08-21 16:29:28 --> Output Class Initialized
INFO - 2023-08-21 16:29:28 --> Security Class Initialized
DEBUG - 2023-08-21 16:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:29:28 --> Input Class Initialized
INFO - 2023-08-21 16:29:28 --> Language Class Initialized
INFO - 2023-08-21 16:29:28 --> Loader Class Initialized
INFO - 2023-08-21 16:29:28 --> Helper loaded: url_helper
INFO - 2023-08-21 16:29:28 --> Helper loaded: file_helper
INFO - 2023-08-21 16:29:28 --> Helper loaded: html_helper
INFO - 2023-08-21 16:29:28 --> Helper loaded: text_helper
INFO - 2023-08-21 16:29:28 --> Helper loaded: form_helper
INFO - 2023-08-21 16:29:28 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:29:28 --> Helper loaded: security_helper
INFO - 2023-08-21 16:29:28 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:29:28 --> Database Driver Class Initialized
INFO - 2023-08-21 16:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:29:28 --> Parser Class Initialized
INFO - 2023-08-21 16:29:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:29:28 --> Pagination Class Initialized
INFO - 2023-08-21 16:29:28 --> Form Validation Class Initialized
INFO - 2023-08-21 16:29:28 --> Controller Class Initialized
DEBUG - 2023-08-21 16:29:28 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:29:28 --> Model Class Initialized
INFO - 2023-08-21 16:29:28 --> Model Class Initialized
INFO - 2023-08-21 16:29:28 --> Final output sent to browser
DEBUG - 2023-08-21 16:29:28 --> Total execution time: 0.1103
ERROR - 2023-08-21 16:29:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:29:48 --> Config Class Initialized
INFO - 2023-08-21 16:29:48 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:29:48 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:29:48 --> Utf8 Class Initialized
INFO - 2023-08-21 16:29:48 --> URI Class Initialized
INFO - 2023-08-21 16:29:48 --> Router Class Initialized
INFO - 2023-08-21 16:29:48 --> Output Class Initialized
INFO - 2023-08-21 16:29:48 --> Security Class Initialized
DEBUG - 2023-08-21 16:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:29:48 --> Input Class Initialized
INFO - 2023-08-21 16:29:48 --> Language Class Initialized
INFO - 2023-08-21 16:29:48 --> Loader Class Initialized
INFO - 2023-08-21 16:29:48 --> Helper loaded: url_helper
INFO - 2023-08-21 16:29:48 --> Helper loaded: file_helper
INFO - 2023-08-21 16:29:48 --> Helper loaded: html_helper
INFO - 2023-08-21 16:29:48 --> Helper loaded: text_helper
INFO - 2023-08-21 16:29:48 --> Helper loaded: form_helper
INFO - 2023-08-21 16:29:48 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:29:48 --> Helper loaded: security_helper
INFO - 2023-08-21 16:29:48 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:29:48 --> Database Driver Class Initialized
INFO - 2023-08-21 16:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:29:49 --> Parser Class Initialized
INFO - 2023-08-21 16:29:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:29:49 --> Pagination Class Initialized
INFO - 2023-08-21 16:29:49 --> Form Validation Class Initialized
INFO - 2023-08-21 16:29:49 --> Controller Class Initialized
DEBUG - 2023-08-21 16:29:49 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:29:49 --> Model Class Initialized
INFO - 2023-08-21 16:29:49 --> Model Class Initialized
INFO - 2023-08-21 16:29:49 --> Model Class Initialized
INFO - 2023-08-21 16:29:49 --> Model Class Initialized
INFO - 2023-08-21 16:29:49 --> Model Class Initialized
INFO - 2023-08-21 16:29:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/edit_product_form.php
DEBUG - 2023-08-21 16:29:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:29:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 16:29:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 16:29:49 --> Model Class Initialized
INFO - 2023-08-21 16:29:49 --> Model Class Initialized
INFO - 2023-08-21 16:29:49 --> Model Class Initialized
INFO - 2023-08-21 16:29:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 16:29:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 16:29:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 16:29:49 --> Final output sent to browser
DEBUG - 2023-08-21 16:29:49 --> Total execution time: 0.1911
ERROR - 2023-08-21 16:30:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:30:06 --> Config Class Initialized
INFO - 2023-08-21 16:30:06 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:30:06 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:30:06 --> Utf8 Class Initialized
INFO - 2023-08-21 16:30:06 --> URI Class Initialized
INFO - 2023-08-21 16:30:06 --> Router Class Initialized
INFO - 2023-08-21 16:30:06 --> Output Class Initialized
INFO - 2023-08-21 16:30:06 --> Security Class Initialized
DEBUG - 2023-08-21 16:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:30:06 --> Input Class Initialized
INFO - 2023-08-21 16:30:06 --> Language Class Initialized
INFO - 2023-08-21 16:30:06 --> Loader Class Initialized
INFO - 2023-08-21 16:30:06 --> Helper loaded: url_helper
INFO - 2023-08-21 16:30:06 --> Helper loaded: file_helper
INFO - 2023-08-21 16:30:06 --> Helper loaded: html_helper
INFO - 2023-08-21 16:30:06 --> Helper loaded: text_helper
INFO - 2023-08-21 16:30:06 --> Helper loaded: form_helper
INFO - 2023-08-21 16:30:06 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:30:06 --> Helper loaded: security_helper
INFO - 2023-08-21 16:30:06 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:30:06 --> Database Driver Class Initialized
INFO - 2023-08-21 16:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:30:06 --> Parser Class Initialized
INFO - 2023-08-21 16:30:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:30:06 --> Pagination Class Initialized
INFO - 2023-08-21 16:30:06 --> Form Validation Class Initialized
INFO - 2023-08-21 16:30:06 --> Controller Class Initialized
DEBUG - 2023-08-21 16:30:06 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:30:06 --> Model Class Initialized
INFO - 2023-08-21 16:30:06 --> Model Class Initialized
ERROR - 2023-08-21 16:30:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:30:06 --> Config Class Initialized
INFO - 2023-08-21 16:30:06 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:30:06 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:30:06 --> Utf8 Class Initialized
INFO - 2023-08-21 16:30:06 --> URI Class Initialized
INFO - 2023-08-21 16:30:06 --> Router Class Initialized
INFO - 2023-08-21 16:30:06 --> Output Class Initialized
INFO - 2023-08-21 16:30:06 --> Security Class Initialized
DEBUG - 2023-08-21 16:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:30:06 --> Input Class Initialized
INFO - 2023-08-21 16:30:06 --> Language Class Initialized
INFO - 2023-08-21 16:30:06 --> Loader Class Initialized
INFO - 2023-08-21 16:30:06 --> Helper loaded: url_helper
INFO - 2023-08-21 16:30:06 --> Helper loaded: file_helper
INFO - 2023-08-21 16:30:06 --> Helper loaded: html_helper
INFO - 2023-08-21 16:30:06 --> Helper loaded: text_helper
INFO - 2023-08-21 16:30:06 --> Helper loaded: form_helper
INFO - 2023-08-21 16:30:06 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:30:06 --> Helper loaded: security_helper
INFO - 2023-08-21 16:30:06 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:30:06 --> Database Driver Class Initialized
INFO - 2023-08-21 16:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:30:06 --> Parser Class Initialized
INFO - 2023-08-21 16:30:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:30:06 --> Pagination Class Initialized
INFO - 2023-08-21 16:30:06 --> Form Validation Class Initialized
INFO - 2023-08-21 16:30:06 --> Controller Class Initialized
DEBUG - 2023-08-21 16:30:06 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:30:06 --> Model Class Initialized
INFO - 2023-08-21 16:30:06 --> Model Class Initialized
INFO - 2023-08-21 16:30:06 --> Model Class Initialized
INFO - 2023-08-21 16:30:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product.php
DEBUG - 2023-08-21 16:30:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:30:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 16:30:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 16:30:06 --> Model Class Initialized
INFO - 2023-08-21 16:30:06 --> Model Class Initialized
INFO - 2023-08-21 16:30:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 16:30:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 16:30:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 16:30:06 --> Final output sent to browser
DEBUG - 2023-08-21 16:30:06 --> Total execution time: 0.1666
ERROR - 2023-08-21 16:30:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:30:07 --> Config Class Initialized
INFO - 2023-08-21 16:30:07 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:30:07 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:30:07 --> Utf8 Class Initialized
INFO - 2023-08-21 16:30:07 --> URI Class Initialized
INFO - 2023-08-21 16:30:07 --> Router Class Initialized
INFO - 2023-08-21 16:30:07 --> Output Class Initialized
INFO - 2023-08-21 16:30:07 --> Security Class Initialized
DEBUG - 2023-08-21 16:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:30:07 --> Input Class Initialized
INFO - 2023-08-21 16:30:07 --> Language Class Initialized
INFO - 2023-08-21 16:30:07 --> Loader Class Initialized
INFO - 2023-08-21 16:30:07 --> Helper loaded: url_helper
INFO - 2023-08-21 16:30:07 --> Helper loaded: file_helper
INFO - 2023-08-21 16:30:07 --> Helper loaded: html_helper
INFO - 2023-08-21 16:30:07 --> Helper loaded: text_helper
INFO - 2023-08-21 16:30:07 --> Helper loaded: form_helper
INFO - 2023-08-21 16:30:07 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:30:07 --> Helper loaded: security_helper
INFO - 2023-08-21 16:30:07 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:30:07 --> Database Driver Class Initialized
INFO - 2023-08-21 16:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:30:07 --> Parser Class Initialized
INFO - 2023-08-21 16:30:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:30:07 --> Pagination Class Initialized
INFO - 2023-08-21 16:30:07 --> Form Validation Class Initialized
INFO - 2023-08-21 16:30:07 --> Controller Class Initialized
DEBUG - 2023-08-21 16:30:07 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:30:07 --> Model Class Initialized
INFO - 2023-08-21 16:30:07 --> Model Class Initialized
INFO - 2023-08-21 16:30:07 --> Final output sent to browser
DEBUG - 2023-08-21 16:30:07 --> Total execution time: 0.0518
ERROR - 2023-08-21 16:30:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:30:16 --> Config Class Initialized
INFO - 2023-08-21 16:30:16 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:30:16 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:30:16 --> Utf8 Class Initialized
INFO - 2023-08-21 16:30:16 --> URI Class Initialized
INFO - 2023-08-21 16:30:16 --> Router Class Initialized
INFO - 2023-08-21 16:30:16 --> Output Class Initialized
INFO - 2023-08-21 16:30:16 --> Security Class Initialized
DEBUG - 2023-08-21 16:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:30:16 --> Input Class Initialized
INFO - 2023-08-21 16:30:16 --> Language Class Initialized
INFO - 2023-08-21 16:30:16 --> Loader Class Initialized
INFO - 2023-08-21 16:30:16 --> Helper loaded: url_helper
INFO - 2023-08-21 16:30:16 --> Helper loaded: file_helper
INFO - 2023-08-21 16:30:16 --> Helper loaded: html_helper
INFO - 2023-08-21 16:30:16 --> Helper loaded: text_helper
INFO - 2023-08-21 16:30:16 --> Helper loaded: form_helper
INFO - 2023-08-21 16:30:16 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:30:16 --> Helper loaded: security_helper
INFO - 2023-08-21 16:30:16 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:30:16 --> Database Driver Class Initialized
INFO - 2023-08-21 16:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:30:16 --> Parser Class Initialized
INFO - 2023-08-21 16:30:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:30:16 --> Pagination Class Initialized
INFO - 2023-08-21 16:30:16 --> Form Validation Class Initialized
INFO - 2023-08-21 16:30:16 --> Controller Class Initialized
DEBUG - 2023-08-21 16:30:16 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:30:16 --> Model Class Initialized
INFO - 2023-08-21 16:30:16 --> Model Class Initialized
INFO - 2023-08-21 16:30:16 --> Final output sent to browser
DEBUG - 2023-08-21 16:30:16 --> Total execution time: 0.1144
ERROR - 2023-08-21 16:30:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:30:52 --> Config Class Initialized
INFO - 2023-08-21 16:30:52 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:30:52 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:30:52 --> Utf8 Class Initialized
INFO - 2023-08-21 16:30:52 --> URI Class Initialized
INFO - 2023-08-21 16:30:52 --> Router Class Initialized
INFO - 2023-08-21 16:30:52 --> Output Class Initialized
INFO - 2023-08-21 16:30:52 --> Security Class Initialized
DEBUG - 2023-08-21 16:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:30:52 --> Input Class Initialized
INFO - 2023-08-21 16:30:52 --> Language Class Initialized
INFO - 2023-08-21 16:30:52 --> Loader Class Initialized
INFO - 2023-08-21 16:30:52 --> Helper loaded: url_helper
INFO - 2023-08-21 16:30:52 --> Helper loaded: file_helper
INFO - 2023-08-21 16:30:52 --> Helper loaded: html_helper
INFO - 2023-08-21 16:30:52 --> Helper loaded: text_helper
INFO - 2023-08-21 16:30:52 --> Helper loaded: form_helper
INFO - 2023-08-21 16:30:52 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:30:52 --> Helper loaded: security_helper
INFO - 2023-08-21 16:30:52 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:30:52 --> Database Driver Class Initialized
INFO - 2023-08-21 16:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:30:52 --> Parser Class Initialized
INFO - 2023-08-21 16:30:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:30:52 --> Pagination Class Initialized
INFO - 2023-08-21 16:30:52 --> Form Validation Class Initialized
INFO - 2023-08-21 16:30:52 --> Controller Class Initialized
INFO - 2023-08-21 16:30:52 --> Model Class Initialized
INFO - 2023-08-21 16:30:52 --> Model Class Initialized
ERROR - 2023-08-21 16:30:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/views/purchase/add_purchase_form.php 157
INFO - 2023-08-21 16:30:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/add_purchase_form.php
DEBUG - 2023-08-21 16:30:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:30:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 16:30:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 16:30:52 --> Model Class Initialized
INFO - 2023-08-21 16:30:52 --> Model Class Initialized
INFO - 2023-08-21 16:30:52 --> Model Class Initialized
INFO - 2023-08-21 16:30:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 16:30:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 16:30:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 16:30:52 --> Final output sent to browser
DEBUG - 2023-08-21 16:30:52 --> Total execution time: 0.1866
ERROR - 2023-08-21 16:31:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:31:30 --> Config Class Initialized
INFO - 2023-08-21 16:31:30 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:31:30 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:31:30 --> Utf8 Class Initialized
INFO - 2023-08-21 16:31:30 --> URI Class Initialized
INFO - 2023-08-21 16:31:30 --> Router Class Initialized
INFO - 2023-08-21 16:31:30 --> Output Class Initialized
INFO - 2023-08-21 16:31:30 --> Security Class Initialized
DEBUG - 2023-08-21 16:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:31:30 --> Input Class Initialized
INFO - 2023-08-21 16:31:30 --> Language Class Initialized
INFO - 2023-08-21 16:31:30 --> Loader Class Initialized
INFO - 2023-08-21 16:31:30 --> Helper loaded: url_helper
INFO - 2023-08-21 16:31:30 --> Helper loaded: file_helper
INFO - 2023-08-21 16:31:30 --> Helper loaded: html_helper
INFO - 2023-08-21 16:31:30 --> Helper loaded: text_helper
INFO - 2023-08-21 16:31:30 --> Helper loaded: form_helper
INFO - 2023-08-21 16:31:30 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:31:30 --> Helper loaded: security_helper
INFO - 2023-08-21 16:31:30 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:31:30 --> Database Driver Class Initialized
INFO - 2023-08-21 16:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:31:30 --> Parser Class Initialized
INFO - 2023-08-21 16:31:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:31:30 --> Pagination Class Initialized
INFO - 2023-08-21 16:31:30 --> Form Validation Class Initialized
INFO - 2023-08-21 16:31:30 --> Controller Class Initialized
INFO - 2023-08-21 16:31:30 --> Model Class Initialized
INFO - 2023-08-21 16:31:30 --> Final output sent to browser
DEBUG - 2023-08-21 16:31:30 --> Total execution time: 0.0191
ERROR - 2023-08-21 16:31:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:31:31 --> Config Class Initialized
INFO - 2023-08-21 16:31:31 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:31:31 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:31:31 --> Utf8 Class Initialized
INFO - 2023-08-21 16:31:31 --> URI Class Initialized
INFO - 2023-08-21 16:31:31 --> Router Class Initialized
INFO - 2023-08-21 16:31:31 --> Output Class Initialized
INFO - 2023-08-21 16:31:31 --> Security Class Initialized
DEBUG - 2023-08-21 16:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:31:31 --> Input Class Initialized
INFO - 2023-08-21 16:31:31 --> Language Class Initialized
INFO - 2023-08-21 16:31:31 --> Loader Class Initialized
INFO - 2023-08-21 16:31:31 --> Helper loaded: url_helper
INFO - 2023-08-21 16:31:31 --> Helper loaded: file_helper
INFO - 2023-08-21 16:31:31 --> Helper loaded: html_helper
INFO - 2023-08-21 16:31:31 --> Helper loaded: text_helper
INFO - 2023-08-21 16:31:31 --> Helper loaded: form_helper
INFO - 2023-08-21 16:31:31 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:31:31 --> Helper loaded: security_helper
INFO - 2023-08-21 16:31:31 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:31:31 --> Database Driver Class Initialized
INFO - 2023-08-21 16:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:31:31 --> Parser Class Initialized
INFO - 2023-08-21 16:31:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:31:31 --> Pagination Class Initialized
INFO - 2023-08-21 16:31:31 --> Form Validation Class Initialized
INFO - 2023-08-21 16:31:31 --> Controller Class Initialized
INFO - 2023-08-21 16:31:31 --> Model Class Initialized
INFO - 2023-08-21 16:31:31 --> Final output sent to browser
DEBUG - 2023-08-21 16:31:31 --> Total execution time: 0.0156
ERROR - 2023-08-21 16:31:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:31:31 --> Config Class Initialized
INFO - 2023-08-21 16:31:31 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:31:31 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:31:31 --> Utf8 Class Initialized
INFO - 2023-08-21 16:31:31 --> URI Class Initialized
INFO - 2023-08-21 16:31:31 --> Router Class Initialized
INFO - 2023-08-21 16:31:31 --> Output Class Initialized
INFO - 2023-08-21 16:31:31 --> Security Class Initialized
DEBUG - 2023-08-21 16:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:31:31 --> Input Class Initialized
INFO - 2023-08-21 16:31:31 --> Language Class Initialized
INFO - 2023-08-21 16:31:31 --> Loader Class Initialized
INFO - 2023-08-21 16:31:31 --> Helper loaded: url_helper
INFO - 2023-08-21 16:31:31 --> Helper loaded: file_helper
INFO - 2023-08-21 16:31:31 --> Helper loaded: html_helper
INFO - 2023-08-21 16:31:31 --> Helper loaded: text_helper
INFO - 2023-08-21 16:31:31 --> Helper loaded: form_helper
INFO - 2023-08-21 16:31:31 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:31:31 --> Helper loaded: security_helper
INFO - 2023-08-21 16:31:31 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:31:31 --> Database Driver Class Initialized
INFO - 2023-08-21 16:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:31:31 --> Parser Class Initialized
INFO - 2023-08-21 16:31:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:31:31 --> Pagination Class Initialized
INFO - 2023-08-21 16:31:31 --> Form Validation Class Initialized
INFO - 2023-08-21 16:31:31 --> Controller Class Initialized
INFO - 2023-08-21 16:31:31 --> Model Class Initialized
INFO - 2023-08-21 16:31:31 --> Final output sent to browser
DEBUG - 2023-08-21 16:31:31 --> Total execution time: 0.0149
ERROR - 2023-08-21 16:31:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:31:32 --> Config Class Initialized
INFO - 2023-08-21 16:31:32 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:31:32 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:31:32 --> Utf8 Class Initialized
INFO - 2023-08-21 16:31:32 --> URI Class Initialized
INFO - 2023-08-21 16:31:32 --> Router Class Initialized
INFO - 2023-08-21 16:31:32 --> Output Class Initialized
INFO - 2023-08-21 16:31:32 --> Security Class Initialized
DEBUG - 2023-08-21 16:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:31:32 --> Input Class Initialized
INFO - 2023-08-21 16:31:32 --> Language Class Initialized
INFO - 2023-08-21 16:31:32 --> Loader Class Initialized
INFO - 2023-08-21 16:31:32 --> Helper loaded: url_helper
INFO - 2023-08-21 16:31:32 --> Helper loaded: file_helper
INFO - 2023-08-21 16:31:32 --> Helper loaded: html_helper
INFO - 2023-08-21 16:31:32 --> Helper loaded: text_helper
INFO - 2023-08-21 16:31:32 --> Helper loaded: form_helper
INFO - 2023-08-21 16:31:32 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:31:32 --> Helper loaded: security_helper
INFO - 2023-08-21 16:31:32 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:31:32 --> Database Driver Class Initialized
INFO - 2023-08-21 16:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:31:32 --> Parser Class Initialized
INFO - 2023-08-21 16:31:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:31:32 --> Pagination Class Initialized
INFO - 2023-08-21 16:31:32 --> Form Validation Class Initialized
INFO - 2023-08-21 16:31:32 --> Controller Class Initialized
INFO - 2023-08-21 16:31:32 --> Model Class Initialized
INFO - 2023-08-21 16:31:32 --> Final output sent to browser
DEBUG - 2023-08-21 16:31:32 --> Total execution time: 0.0154
ERROR - 2023-08-21 16:31:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:31:35 --> Config Class Initialized
INFO - 2023-08-21 16:31:35 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:31:35 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:31:35 --> Utf8 Class Initialized
INFO - 2023-08-21 16:31:35 --> URI Class Initialized
INFO - 2023-08-21 16:31:35 --> Router Class Initialized
INFO - 2023-08-21 16:31:35 --> Output Class Initialized
INFO - 2023-08-21 16:31:35 --> Security Class Initialized
DEBUG - 2023-08-21 16:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:31:35 --> Input Class Initialized
INFO - 2023-08-21 16:31:35 --> Language Class Initialized
INFO - 2023-08-21 16:31:35 --> Loader Class Initialized
INFO - 2023-08-21 16:31:35 --> Helper loaded: url_helper
INFO - 2023-08-21 16:31:35 --> Helper loaded: file_helper
INFO - 2023-08-21 16:31:35 --> Helper loaded: html_helper
INFO - 2023-08-21 16:31:35 --> Helper loaded: text_helper
INFO - 2023-08-21 16:31:35 --> Helper loaded: form_helper
INFO - 2023-08-21 16:31:35 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:31:35 --> Helper loaded: security_helper
INFO - 2023-08-21 16:31:35 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:31:35 --> Database Driver Class Initialized
INFO - 2023-08-21 16:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:31:35 --> Parser Class Initialized
INFO - 2023-08-21 16:31:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:31:35 --> Pagination Class Initialized
INFO - 2023-08-21 16:31:35 --> Form Validation Class Initialized
INFO - 2023-08-21 16:31:35 --> Controller Class Initialized
INFO - 2023-08-21 16:31:35 --> Model Class Initialized
INFO - 2023-08-21 16:31:35 --> Final output sent to browser
DEBUG - 2023-08-21 16:31:35 --> Total execution time: 0.0149
ERROR - 2023-08-21 16:31:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:31:38 --> Config Class Initialized
INFO - 2023-08-21 16:31:38 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:31:38 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:31:38 --> Utf8 Class Initialized
INFO - 2023-08-21 16:31:38 --> URI Class Initialized
INFO - 2023-08-21 16:31:38 --> Router Class Initialized
INFO - 2023-08-21 16:31:38 --> Output Class Initialized
INFO - 2023-08-21 16:31:38 --> Security Class Initialized
DEBUG - 2023-08-21 16:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:31:38 --> Input Class Initialized
INFO - 2023-08-21 16:31:38 --> Language Class Initialized
INFO - 2023-08-21 16:31:38 --> Loader Class Initialized
INFO - 2023-08-21 16:31:38 --> Helper loaded: url_helper
INFO - 2023-08-21 16:31:38 --> Helper loaded: file_helper
INFO - 2023-08-21 16:31:38 --> Helper loaded: html_helper
INFO - 2023-08-21 16:31:38 --> Helper loaded: text_helper
INFO - 2023-08-21 16:31:38 --> Helper loaded: form_helper
INFO - 2023-08-21 16:31:38 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:31:38 --> Helper loaded: security_helper
INFO - 2023-08-21 16:31:38 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:31:38 --> Database Driver Class Initialized
INFO - 2023-08-21 16:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:31:38 --> Parser Class Initialized
INFO - 2023-08-21 16:31:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:31:38 --> Pagination Class Initialized
INFO - 2023-08-21 16:31:38 --> Form Validation Class Initialized
INFO - 2023-08-21 16:31:38 --> Controller Class Initialized
INFO - 2023-08-21 16:31:38 --> Model Class Initialized
INFO - 2023-08-21 16:31:38 --> Final output sent to browser
DEBUG - 2023-08-21 16:31:38 --> Total execution time: 0.0149
ERROR - 2023-08-21 16:31:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:31:39 --> Config Class Initialized
INFO - 2023-08-21 16:31:39 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:31:39 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:31:39 --> Utf8 Class Initialized
INFO - 2023-08-21 16:31:39 --> URI Class Initialized
INFO - 2023-08-21 16:31:39 --> Router Class Initialized
INFO - 2023-08-21 16:31:39 --> Output Class Initialized
INFO - 2023-08-21 16:31:39 --> Security Class Initialized
DEBUG - 2023-08-21 16:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:31:39 --> Input Class Initialized
INFO - 2023-08-21 16:31:39 --> Language Class Initialized
INFO - 2023-08-21 16:31:39 --> Loader Class Initialized
INFO - 2023-08-21 16:31:39 --> Helper loaded: url_helper
INFO - 2023-08-21 16:31:39 --> Helper loaded: file_helper
INFO - 2023-08-21 16:31:39 --> Helper loaded: html_helper
INFO - 2023-08-21 16:31:39 --> Helper loaded: text_helper
INFO - 2023-08-21 16:31:39 --> Helper loaded: form_helper
INFO - 2023-08-21 16:31:39 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:31:39 --> Helper loaded: security_helper
INFO - 2023-08-21 16:31:39 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:31:39 --> Database Driver Class Initialized
INFO - 2023-08-21 16:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:31:39 --> Parser Class Initialized
INFO - 2023-08-21 16:31:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:31:39 --> Pagination Class Initialized
INFO - 2023-08-21 16:31:39 --> Form Validation Class Initialized
INFO - 2023-08-21 16:31:39 --> Controller Class Initialized
INFO - 2023-08-21 16:31:39 --> Model Class Initialized
INFO - 2023-08-21 16:31:39 --> Final output sent to browser
DEBUG - 2023-08-21 16:31:39 --> Total execution time: 0.0148
ERROR - 2023-08-21 16:31:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:31:45 --> Config Class Initialized
INFO - 2023-08-21 16:31:45 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:31:45 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:31:45 --> Utf8 Class Initialized
INFO - 2023-08-21 16:31:45 --> URI Class Initialized
INFO - 2023-08-21 16:31:45 --> Router Class Initialized
INFO - 2023-08-21 16:31:45 --> Output Class Initialized
INFO - 2023-08-21 16:31:45 --> Security Class Initialized
DEBUG - 2023-08-21 16:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:31:45 --> Input Class Initialized
INFO - 2023-08-21 16:31:45 --> Language Class Initialized
INFO - 2023-08-21 16:31:45 --> Loader Class Initialized
INFO - 2023-08-21 16:31:45 --> Helper loaded: url_helper
INFO - 2023-08-21 16:31:45 --> Helper loaded: file_helper
INFO - 2023-08-21 16:31:45 --> Helper loaded: html_helper
INFO - 2023-08-21 16:31:45 --> Helper loaded: text_helper
INFO - 2023-08-21 16:31:45 --> Helper loaded: form_helper
INFO - 2023-08-21 16:31:45 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:31:45 --> Helper loaded: security_helper
INFO - 2023-08-21 16:31:45 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:31:45 --> Database Driver Class Initialized
INFO - 2023-08-21 16:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:31:45 --> Parser Class Initialized
INFO - 2023-08-21 16:31:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:31:45 --> Pagination Class Initialized
INFO - 2023-08-21 16:31:45 --> Form Validation Class Initialized
INFO - 2023-08-21 16:31:45 --> Controller Class Initialized
INFO - 2023-08-21 16:31:45 --> Model Class Initialized
INFO - 2023-08-21 16:31:45 --> Final output sent to browser
DEBUG - 2023-08-21 16:31:45 --> Total execution time: 0.0188
ERROR - 2023-08-21 16:31:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:31:46 --> Config Class Initialized
INFO - 2023-08-21 16:31:46 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:31:46 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:31:46 --> Utf8 Class Initialized
INFO - 2023-08-21 16:31:46 --> URI Class Initialized
INFO - 2023-08-21 16:31:46 --> Router Class Initialized
INFO - 2023-08-21 16:31:46 --> Output Class Initialized
INFO - 2023-08-21 16:31:46 --> Security Class Initialized
DEBUG - 2023-08-21 16:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:31:46 --> Input Class Initialized
INFO - 2023-08-21 16:31:46 --> Language Class Initialized
INFO - 2023-08-21 16:31:46 --> Loader Class Initialized
INFO - 2023-08-21 16:31:46 --> Helper loaded: url_helper
INFO - 2023-08-21 16:31:46 --> Helper loaded: file_helper
INFO - 2023-08-21 16:31:46 --> Helper loaded: html_helper
INFO - 2023-08-21 16:31:46 --> Helper loaded: text_helper
INFO - 2023-08-21 16:31:46 --> Helper loaded: form_helper
INFO - 2023-08-21 16:31:46 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:31:46 --> Helper loaded: security_helper
INFO - 2023-08-21 16:31:46 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:31:46 --> Database Driver Class Initialized
INFO - 2023-08-21 16:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:31:46 --> Parser Class Initialized
INFO - 2023-08-21 16:31:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:31:46 --> Pagination Class Initialized
INFO - 2023-08-21 16:31:46 --> Form Validation Class Initialized
INFO - 2023-08-21 16:31:46 --> Controller Class Initialized
INFO - 2023-08-21 16:31:46 --> Model Class Initialized
INFO - 2023-08-21 16:31:46 --> Final output sent to browser
DEBUG - 2023-08-21 16:31:46 --> Total execution time: 0.0182
ERROR - 2023-08-21 16:31:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:31:49 --> Config Class Initialized
INFO - 2023-08-21 16:31:49 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:31:49 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:31:49 --> Utf8 Class Initialized
INFO - 2023-08-21 16:31:49 --> URI Class Initialized
INFO - 2023-08-21 16:31:49 --> Router Class Initialized
INFO - 2023-08-21 16:31:49 --> Output Class Initialized
INFO - 2023-08-21 16:31:49 --> Security Class Initialized
DEBUG - 2023-08-21 16:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:31:49 --> Input Class Initialized
INFO - 2023-08-21 16:31:49 --> Language Class Initialized
INFO - 2023-08-21 16:31:49 --> Loader Class Initialized
INFO - 2023-08-21 16:31:49 --> Helper loaded: url_helper
INFO - 2023-08-21 16:31:49 --> Helper loaded: file_helper
INFO - 2023-08-21 16:31:49 --> Helper loaded: html_helper
INFO - 2023-08-21 16:31:49 --> Helper loaded: text_helper
INFO - 2023-08-21 16:31:49 --> Helper loaded: form_helper
INFO - 2023-08-21 16:31:49 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:31:49 --> Helper loaded: security_helper
INFO - 2023-08-21 16:31:49 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:31:49 --> Database Driver Class Initialized
INFO - 2023-08-21 16:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:31:49 --> Parser Class Initialized
INFO - 2023-08-21 16:31:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:31:49 --> Pagination Class Initialized
INFO - 2023-08-21 16:31:49 --> Form Validation Class Initialized
INFO - 2023-08-21 16:31:49 --> Controller Class Initialized
INFO - 2023-08-21 16:31:49 --> Model Class Initialized
INFO - 2023-08-21 16:31:49 --> Final output sent to browser
DEBUG - 2023-08-21 16:31:49 --> Total execution time: 0.0225
ERROR - 2023-08-21 16:31:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:31:49 --> Config Class Initialized
INFO - 2023-08-21 16:31:49 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:31:49 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:31:49 --> Utf8 Class Initialized
INFO - 2023-08-21 16:31:49 --> URI Class Initialized
INFO - 2023-08-21 16:31:49 --> Router Class Initialized
INFO - 2023-08-21 16:31:49 --> Output Class Initialized
INFO - 2023-08-21 16:31:49 --> Security Class Initialized
DEBUG - 2023-08-21 16:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:31:49 --> Input Class Initialized
INFO - 2023-08-21 16:31:49 --> Language Class Initialized
INFO - 2023-08-21 16:31:49 --> Loader Class Initialized
INFO - 2023-08-21 16:31:49 --> Helper loaded: url_helper
INFO - 2023-08-21 16:31:49 --> Helper loaded: file_helper
INFO - 2023-08-21 16:31:49 --> Helper loaded: html_helper
INFO - 2023-08-21 16:31:49 --> Helper loaded: text_helper
INFO - 2023-08-21 16:31:49 --> Helper loaded: form_helper
INFO - 2023-08-21 16:31:49 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:31:49 --> Helper loaded: security_helper
INFO - 2023-08-21 16:31:49 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:31:49 --> Database Driver Class Initialized
INFO - 2023-08-21 16:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:31:49 --> Parser Class Initialized
INFO - 2023-08-21 16:31:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:31:49 --> Pagination Class Initialized
INFO - 2023-08-21 16:31:49 --> Form Validation Class Initialized
INFO - 2023-08-21 16:31:49 --> Controller Class Initialized
INFO - 2023-08-21 16:31:49 --> Model Class Initialized
INFO - 2023-08-21 16:31:49 --> Final output sent to browser
DEBUG - 2023-08-21 16:31:49 --> Total execution time: 0.0180
ERROR - 2023-08-21 16:31:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:31:49 --> Config Class Initialized
INFO - 2023-08-21 16:31:49 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:31:49 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:31:49 --> Utf8 Class Initialized
INFO - 2023-08-21 16:31:49 --> URI Class Initialized
INFO - 2023-08-21 16:31:49 --> Router Class Initialized
INFO - 2023-08-21 16:31:49 --> Output Class Initialized
INFO - 2023-08-21 16:31:49 --> Security Class Initialized
DEBUG - 2023-08-21 16:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:31:49 --> Input Class Initialized
INFO - 2023-08-21 16:31:49 --> Language Class Initialized
INFO - 2023-08-21 16:31:49 --> Loader Class Initialized
INFO - 2023-08-21 16:31:49 --> Helper loaded: url_helper
INFO - 2023-08-21 16:31:49 --> Helper loaded: file_helper
INFO - 2023-08-21 16:31:49 --> Helper loaded: html_helper
INFO - 2023-08-21 16:31:49 --> Helper loaded: text_helper
INFO - 2023-08-21 16:31:49 --> Helper loaded: form_helper
INFO - 2023-08-21 16:31:49 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:31:49 --> Helper loaded: security_helper
INFO - 2023-08-21 16:31:49 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:31:49 --> Database Driver Class Initialized
INFO - 2023-08-21 16:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:31:49 --> Parser Class Initialized
INFO - 2023-08-21 16:31:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:31:49 --> Pagination Class Initialized
INFO - 2023-08-21 16:31:49 --> Form Validation Class Initialized
INFO - 2023-08-21 16:31:49 --> Controller Class Initialized
INFO - 2023-08-21 16:31:49 --> Model Class Initialized
INFO - 2023-08-21 16:31:49 --> Final output sent to browser
DEBUG - 2023-08-21 16:31:49 --> Total execution time: 0.0147
ERROR - 2023-08-21 16:31:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:31:50 --> Config Class Initialized
INFO - 2023-08-21 16:31:50 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:31:50 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:31:50 --> Utf8 Class Initialized
INFO - 2023-08-21 16:31:50 --> URI Class Initialized
INFO - 2023-08-21 16:31:50 --> Router Class Initialized
INFO - 2023-08-21 16:31:50 --> Output Class Initialized
INFO - 2023-08-21 16:31:50 --> Security Class Initialized
DEBUG - 2023-08-21 16:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:31:50 --> Input Class Initialized
INFO - 2023-08-21 16:31:50 --> Language Class Initialized
INFO - 2023-08-21 16:31:50 --> Loader Class Initialized
INFO - 2023-08-21 16:31:50 --> Helper loaded: url_helper
INFO - 2023-08-21 16:31:50 --> Helper loaded: file_helper
INFO - 2023-08-21 16:31:50 --> Helper loaded: html_helper
INFO - 2023-08-21 16:31:50 --> Helper loaded: text_helper
INFO - 2023-08-21 16:31:50 --> Helper loaded: form_helper
INFO - 2023-08-21 16:31:50 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:31:50 --> Helper loaded: security_helper
INFO - 2023-08-21 16:31:50 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:31:50 --> Database Driver Class Initialized
INFO - 2023-08-21 16:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:31:50 --> Parser Class Initialized
INFO - 2023-08-21 16:31:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:31:50 --> Pagination Class Initialized
INFO - 2023-08-21 16:31:50 --> Form Validation Class Initialized
INFO - 2023-08-21 16:31:50 --> Controller Class Initialized
INFO - 2023-08-21 16:31:50 --> Model Class Initialized
INFO - 2023-08-21 16:31:50 --> Final output sent to browser
DEBUG - 2023-08-21 16:31:50 --> Total execution time: 0.0139
ERROR - 2023-08-21 16:31:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:31:51 --> Config Class Initialized
INFO - 2023-08-21 16:31:51 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:31:51 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:31:51 --> Utf8 Class Initialized
INFO - 2023-08-21 16:31:51 --> URI Class Initialized
INFO - 2023-08-21 16:31:51 --> Router Class Initialized
INFO - 2023-08-21 16:31:51 --> Output Class Initialized
INFO - 2023-08-21 16:31:51 --> Security Class Initialized
DEBUG - 2023-08-21 16:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:31:51 --> Input Class Initialized
INFO - 2023-08-21 16:31:51 --> Language Class Initialized
INFO - 2023-08-21 16:31:51 --> Loader Class Initialized
INFO - 2023-08-21 16:31:51 --> Helper loaded: url_helper
INFO - 2023-08-21 16:31:51 --> Helper loaded: file_helper
INFO - 2023-08-21 16:31:51 --> Helper loaded: html_helper
INFO - 2023-08-21 16:31:51 --> Helper loaded: text_helper
INFO - 2023-08-21 16:31:51 --> Helper loaded: form_helper
INFO - 2023-08-21 16:31:51 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:31:51 --> Helper loaded: security_helper
INFO - 2023-08-21 16:31:51 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:31:51 --> Database Driver Class Initialized
INFO - 2023-08-21 16:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:31:51 --> Parser Class Initialized
INFO - 2023-08-21 16:31:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:31:51 --> Pagination Class Initialized
INFO - 2023-08-21 16:31:51 --> Form Validation Class Initialized
INFO - 2023-08-21 16:31:51 --> Controller Class Initialized
INFO - 2023-08-21 16:31:51 --> Model Class Initialized
INFO - 2023-08-21 16:31:51 --> Final output sent to browser
DEBUG - 2023-08-21 16:31:51 --> Total execution time: 0.0156
ERROR - 2023-08-21 16:32:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:32:11 --> Config Class Initialized
INFO - 2023-08-21 16:32:11 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:32:11 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:32:11 --> Utf8 Class Initialized
INFO - 2023-08-21 16:32:11 --> URI Class Initialized
INFO - 2023-08-21 16:32:11 --> Router Class Initialized
INFO - 2023-08-21 16:32:11 --> Output Class Initialized
INFO - 2023-08-21 16:32:11 --> Security Class Initialized
DEBUG - 2023-08-21 16:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:32:11 --> Input Class Initialized
INFO - 2023-08-21 16:32:11 --> Language Class Initialized
INFO - 2023-08-21 16:32:11 --> Loader Class Initialized
INFO - 2023-08-21 16:32:11 --> Helper loaded: url_helper
INFO - 2023-08-21 16:32:11 --> Helper loaded: file_helper
INFO - 2023-08-21 16:32:11 --> Helper loaded: html_helper
INFO - 2023-08-21 16:32:11 --> Helper loaded: text_helper
INFO - 2023-08-21 16:32:11 --> Helper loaded: form_helper
INFO - 2023-08-21 16:32:11 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:32:11 --> Helper loaded: security_helper
INFO - 2023-08-21 16:32:11 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:32:11 --> Database Driver Class Initialized
INFO - 2023-08-21 16:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:32:11 --> Parser Class Initialized
INFO - 2023-08-21 16:32:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:32:11 --> Pagination Class Initialized
INFO - 2023-08-21 16:32:11 --> Form Validation Class Initialized
INFO - 2023-08-21 16:32:11 --> Controller Class Initialized
DEBUG - 2023-08-21 16:32:11 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:32:11 --> Model Class Initialized
INFO - 2023-08-21 16:32:11 --> Model Class Initialized
INFO - 2023-08-21 16:32:11 --> Model Class Initialized
INFO - 2023-08-21 16:32:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product.php
DEBUG - 2023-08-21 16:32:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:32:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 16:32:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 16:32:11 --> Model Class Initialized
INFO - 2023-08-21 16:32:11 --> Model Class Initialized
INFO - 2023-08-21 16:32:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 16:32:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 16:32:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 16:32:11 --> Final output sent to browser
DEBUG - 2023-08-21 16:32:11 --> Total execution time: 0.1420
ERROR - 2023-08-21 16:32:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:32:12 --> Config Class Initialized
INFO - 2023-08-21 16:32:12 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:32:12 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:32:12 --> Utf8 Class Initialized
INFO - 2023-08-21 16:32:12 --> URI Class Initialized
INFO - 2023-08-21 16:32:12 --> Router Class Initialized
INFO - 2023-08-21 16:32:12 --> Output Class Initialized
INFO - 2023-08-21 16:32:12 --> Security Class Initialized
DEBUG - 2023-08-21 16:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:32:12 --> Input Class Initialized
INFO - 2023-08-21 16:32:12 --> Language Class Initialized
INFO - 2023-08-21 16:32:12 --> Loader Class Initialized
INFO - 2023-08-21 16:32:12 --> Helper loaded: url_helper
INFO - 2023-08-21 16:32:12 --> Helper loaded: file_helper
INFO - 2023-08-21 16:32:12 --> Helper loaded: html_helper
INFO - 2023-08-21 16:32:12 --> Helper loaded: text_helper
INFO - 2023-08-21 16:32:12 --> Helper loaded: form_helper
INFO - 2023-08-21 16:32:12 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:32:12 --> Helper loaded: security_helper
INFO - 2023-08-21 16:32:12 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:32:12 --> Database Driver Class Initialized
INFO - 2023-08-21 16:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:32:12 --> Parser Class Initialized
INFO - 2023-08-21 16:32:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:32:12 --> Pagination Class Initialized
INFO - 2023-08-21 16:32:12 --> Form Validation Class Initialized
INFO - 2023-08-21 16:32:12 --> Controller Class Initialized
DEBUG - 2023-08-21 16:32:12 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:32:12 --> Model Class Initialized
INFO - 2023-08-21 16:32:12 --> Model Class Initialized
INFO - 2023-08-21 16:32:12 --> Final output sent to browser
DEBUG - 2023-08-21 16:32:12 --> Total execution time: 0.0564
ERROR - 2023-08-21 16:32:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:32:16 --> Config Class Initialized
INFO - 2023-08-21 16:32:16 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:32:16 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:32:16 --> Utf8 Class Initialized
INFO - 2023-08-21 16:32:16 --> URI Class Initialized
INFO - 2023-08-21 16:32:16 --> Router Class Initialized
INFO - 2023-08-21 16:32:16 --> Output Class Initialized
INFO - 2023-08-21 16:32:16 --> Security Class Initialized
DEBUG - 2023-08-21 16:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:32:16 --> Input Class Initialized
INFO - 2023-08-21 16:32:16 --> Language Class Initialized
INFO - 2023-08-21 16:32:16 --> Loader Class Initialized
INFO - 2023-08-21 16:32:16 --> Helper loaded: url_helper
INFO - 2023-08-21 16:32:16 --> Helper loaded: file_helper
INFO - 2023-08-21 16:32:16 --> Helper loaded: html_helper
INFO - 2023-08-21 16:32:16 --> Helper loaded: text_helper
INFO - 2023-08-21 16:32:16 --> Helper loaded: form_helper
INFO - 2023-08-21 16:32:16 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:32:16 --> Helper loaded: security_helper
INFO - 2023-08-21 16:32:16 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:32:16 --> Database Driver Class Initialized
INFO - 2023-08-21 16:32:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:32:16 --> Parser Class Initialized
INFO - 2023-08-21 16:32:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:32:16 --> Pagination Class Initialized
INFO - 2023-08-21 16:32:16 --> Form Validation Class Initialized
INFO - 2023-08-21 16:32:16 --> Controller Class Initialized
DEBUG - 2023-08-21 16:32:16 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:32:16 --> Model Class Initialized
INFO - 2023-08-21 16:32:16 --> Model Class Initialized
INFO - 2023-08-21 16:32:16 --> Final output sent to browser
DEBUG - 2023-08-21 16:32:16 --> Total execution time: 0.1438
ERROR - 2023-08-21 16:32:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:32:40 --> Config Class Initialized
INFO - 2023-08-21 16:32:40 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:32:40 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:32:40 --> Utf8 Class Initialized
INFO - 2023-08-21 16:32:40 --> URI Class Initialized
INFO - 2023-08-21 16:32:40 --> Router Class Initialized
INFO - 2023-08-21 16:32:40 --> Output Class Initialized
INFO - 2023-08-21 16:32:40 --> Security Class Initialized
DEBUG - 2023-08-21 16:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:32:40 --> Input Class Initialized
INFO - 2023-08-21 16:32:40 --> Language Class Initialized
INFO - 2023-08-21 16:32:40 --> Loader Class Initialized
INFO - 2023-08-21 16:32:40 --> Helper loaded: url_helper
INFO - 2023-08-21 16:32:40 --> Helper loaded: file_helper
INFO - 2023-08-21 16:32:40 --> Helper loaded: html_helper
INFO - 2023-08-21 16:32:40 --> Helper loaded: text_helper
INFO - 2023-08-21 16:32:40 --> Helper loaded: form_helper
INFO - 2023-08-21 16:32:40 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:32:40 --> Helper loaded: security_helper
INFO - 2023-08-21 16:32:40 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:32:40 --> Database Driver Class Initialized
INFO - 2023-08-21 16:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:32:40 --> Parser Class Initialized
INFO - 2023-08-21 16:32:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:32:40 --> Pagination Class Initialized
INFO - 2023-08-21 16:32:40 --> Form Validation Class Initialized
INFO - 2023-08-21 16:32:40 --> Controller Class Initialized
DEBUG - 2023-08-21 16:32:40 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:32:40 --> Model Class Initialized
INFO - 2023-08-21 16:32:40 --> Model Class Initialized
INFO - 2023-08-21 16:32:40 --> Model Class Initialized
INFO - 2023-08-21 16:32:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product_details.php
DEBUG - 2023-08-21 16:32:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:32:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 16:32:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 16:32:40 --> Model Class Initialized
INFO - 2023-08-21 16:32:40 --> Model Class Initialized
INFO - 2023-08-21 16:32:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 16:32:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 16:32:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 16:32:40 --> Final output sent to browser
DEBUG - 2023-08-21 16:32:40 --> Total execution time: 0.1644
ERROR - 2023-08-21 16:33:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:33:01 --> Config Class Initialized
INFO - 2023-08-21 16:33:01 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:33:01 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:33:01 --> Utf8 Class Initialized
INFO - 2023-08-21 16:33:01 --> URI Class Initialized
INFO - 2023-08-21 16:33:01 --> Router Class Initialized
INFO - 2023-08-21 16:33:01 --> Output Class Initialized
INFO - 2023-08-21 16:33:01 --> Security Class Initialized
DEBUG - 2023-08-21 16:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:33:01 --> Input Class Initialized
INFO - 2023-08-21 16:33:01 --> Language Class Initialized
INFO - 2023-08-21 16:33:01 --> Loader Class Initialized
INFO - 2023-08-21 16:33:01 --> Helper loaded: url_helper
INFO - 2023-08-21 16:33:01 --> Helper loaded: file_helper
INFO - 2023-08-21 16:33:01 --> Helper loaded: html_helper
INFO - 2023-08-21 16:33:01 --> Helper loaded: text_helper
INFO - 2023-08-21 16:33:01 --> Helper loaded: form_helper
INFO - 2023-08-21 16:33:01 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:33:01 --> Helper loaded: security_helper
INFO - 2023-08-21 16:33:01 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:33:01 --> Database Driver Class Initialized
INFO - 2023-08-21 16:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:33:01 --> Parser Class Initialized
INFO - 2023-08-21 16:33:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:33:01 --> Pagination Class Initialized
INFO - 2023-08-21 16:33:01 --> Form Validation Class Initialized
INFO - 2023-08-21 16:33:01 --> Controller Class Initialized
INFO - 2023-08-21 16:33:01 --> Model Class Initialized
INFO - 2023-08-21 16:33:01 --> Model Class Initialized
ERROR - 2023-08-21 16:33:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/views/purchase/add_purchase_form.php 157
INFO - 2023-08-21 16:33:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/add_purchase_form.php
DEBUG - 2023-08-21 16:33:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:33:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 16:33:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 16:33:01 --> Model Class Initialized
INFO - 2023-08-21 16:33:01 --> Model Class Initialized
INFO - 2023-08-21 16:33:01 --> Model Class Initialized
INFO - 2023-08-21 16:33:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 16:33:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 16:33:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 16:33:01 --> Final output sent to browser
DEBUG - 2023-08-21 16:33:01 --> Total execution time: 0.2268
ERROR - 2023-08-21 16:33:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:33:10 --> Config Class Initialized
INFO - 2023-08-21 16:33:10 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:33:10 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:33:10 --> Utf8 Class Initialized
INFO - 2023-08-21 16:33:10 --> URI Class Initialized
INFO - 2023-08-21 16:33:10 --> Router Class Initialized
INFO - 2023-08-21 16:33:10 --> Output Class Initialized
INFO - 2023-08-21 16:33:10 --> Security Class Initialized
DEBUG - 2023-08-21 16:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:33:10 --> Input Class Initialized
INFO - 2023-08-21 16:33:10 --> Language Class Initialized
INFO - 2023-08-21 16:33:10 --> Loader Class Initialized
INFO - 2023-08-21 16:33:10 --> Helper loaded: url_helper
INFO - 2023-08-21 16:33:10 --> Helper loaded: file_helper
INFO - 2023-08-21 16:33:10 --> Helper loaded: html_helper
INFO - 2023-08-21 16:33:10 --> Helper loaded: text_helper
INFO - 2023-08-21 16:33:10 --> Helper loaded: form_helper
INFO - 2023-08-21 16:33:10 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:33:10 --> Helper loaded: security_helper
INFO - 2023-08-21 16:33:10 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:33:10 --> Database Driver Class Initialized
INFO - 2023-08-21 16:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:33:10 --> Parser Class Initialized
INFO - 2023-08-21 16:33:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:33:10 --> Pagination Class Initialized
INFO - 2023-08-21 16:33:10 --> Form Validation Class Initialized
INFO - 2023-08-21 16:33:10 --> Controller Class Initialized
INFO - 2023-08-21 16:33:10 --> Model Class Initialized
INFO - 2023-08-21 16:33:10 --> Final output sent to browser
DEBUG - 2023-08-21 16:33:10 --> Total execution time: 0.0153
ERROR - 2023-08-21 16:33:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:33:11 --> Config Class Initialized
INFO - 2023-08-21 16:33:11 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:33:11 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:33:11 --> Utf8 Class Initialized
INFO - 2023-08-21 16:33:11 --> URI Class Initialized
INFO - 2023-08-21 16:33:11 --> Router Class Initialized
INFO - 2023-08-21 16:33:11 --> Output Class Initialized
INFO - 2023-08-21 16:33:11 --> Security Class Initialized
DEBUG - 2023-08-21 16:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:33:11 --> Input Class Initialized
INFO - 2023-08-21 16:33:11 --> Language Class Initialized
INFO - 2023-08-21 16:33:11 --> Loader Class Initialized
INFO - 2023-08-21 16:33:11 --> Helper loaded: url_helper
INFO - 2023-08-21 16:33:11 --> Helper loaded: file_helper
INFO - 2023-08-21 16:33:11 --> Helper loaded: html_helper
INFO - 2023-08-21 16:33:11 --> Helper loaded: text_helper
INFO - 2023-08-21 16:33:11 --> Helper loaded: form_helper
INFO - 2023-08-21 16:33:11 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:33:11 --> Helper loaded: security_helper
INFO - 2023-08-21 16:33:11 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:33:11 --> Database Driver Class Initialized
INFO - 2023-08-21 16:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:33:11 --> Parser Class Initialized
INFO - 2023-08-21 16:33:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:33:11 --> Pagination Class Initialized
INFO - 2023-08-21 16:33:11 --> Form Validation Class Initialized
INFO - 2023-08-21 16:33:11 --> Controller Class Initialized
INFO - 2023-08-21 16:33:11 --> Model Class Initialized
INFO - 2023-08-21 16:33:11 --> Final output sent to browser
DEBUG - 2023-08-21 16:33:11 --> Total execution time: 0.0154
ERROR - 2023-08-21 16:33:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:33:12 --> Config Class Initialized
INFO - 2023-08-21 16:33:12 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:33:12 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:33:12 --> Utf8 Class Initialized
INFO - 2023-08-21 16:33:12 --> URI Class Initialized
INFO - 2023-08-21 16:33:12 --> Router Class Initialized
INFO - 2023-08-21 16:33:12 --> Output Class Initialized
INFO - 2023-08-21 16:33:12 --> Security Class Initialized
DEBUG - 2023-08-21 16:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:33:12 --> Input Class Initialized
INFO - 2023-08-21 16:33:12 --> Language Class Initialized
INFO - 2023-08-21 16:33:12 --> Loader Class Initialized
INFO - 2023-08-21 16:33:12 --> Helper loaded: url_helper
INFO - 2023-08-21 16:33:12 --> Helper loaded: file_helper
INFO - 2023-08-21 16:33:12 --> Helper loaded: html_helper
INFO - 2023-08-21 16:33:12 --> Helper loaded: text_helper
INFO - 2023-08-21 16:33:12 --> Helper loaded: form_helper
INFO - 2023-08-21 16:33:12 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:33:12 --> Helper loaded: security_helper
INFO - 2023-08-21 16:33:12 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:33:12 --> Database Driver Class Initialized
INFO - 2023-08-21 16:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:33:12 --> Parser Class Initialized
INFO - 2023-08-21 16:33:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:33:12 --> Pagination Class Initialized
INFO - 2023-08-21 16:33:12 --> Form Validation Class Initialized
INFO - 2023-08-21 16:33:12 --> Controller Class Initialized
INFO - 2023-08-21 16:33:12 --> Model Class Initialized
INFO - 2023-08-21 16:33:12 --> Final output sent to browser
DEBUG - 2023-08-21 16:33:12 --> Total execution time: 0.0156
ERROR - 2023-08-21 16:33:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:33:14 --> Config Class Initialized
INFO - 2023-08-21 16:33:14 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:33:14 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:33:14 --> Utf8 Class Initialized
INFO - 2023-08-21 16:33:14 --> URI Class Initialized
INFO - 2023-08-21 16:33:14 --> Router Class Initialized
INFO - 2023-08-21 16:33:14 --> Output Class Initialized
INFO - 2023-08-21 16:33:14 --> Security Class Initialized
DEBUG - 2023-08-21 16:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:33:14 --> Input Class Initialized
INFO - 2023-08-21 16:33:14 --> Language Class Initialized
INFO - 2023-08-21 16:33:14 --> Loader Class Initialized
INFO - 2023-08-21 16:33:14 --> Helper loaded: url_helper
INFO - 2023-08-21 16:33:14 --> Helper loaded: file_helper
INFO - 2023-08-21 16:33:14 --> Helper loaded: html_helper
INFO - 2023-08-21 16:33:14 --> Helper loaded: text_helper
INFO - 2023-08-21 16:33:14 --> Helper loaded: form_helper
INFO - 2023-08-21 16:33:14 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:33:14 --> Helper loaded: security_helper
INFO - 2023-08-21 16:33:14 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:33:14 --> Database Driver Class Initialized
INFO - 2023-08-21 16:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:33:14 --> Parser Class Initialized
INFO - 2023-08-21 16:33:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:33:14 --> Pagination Class Initialized
INFO - 2023-08-21 16:33:14 --> Form Validation Class Initialized
INFO - 2023-08-21 16:33:14 --> Controller Class Initialized
INFO - 2023-08-21 16:33:14 --> Model Class Initialized
INFO - 2023-08-21 16:33:14 --> Final output sent to browser
DEBUG - 2023-08-21 16:33:14 --> Total execution time: 0.0184
ERROR - 2023-08-21 16:33:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:33:15 --> Config Class Initialized
INFO - 2023-08-21 16:33:15 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:33:15 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:33:15 --> Utf8 Class Initialized
INFO - 2023-08-21 16:33:15 --> URI Class Initialized
INFO - 2023-08-21 16:33:15 --> Router Class Initialized
INFO - 2023-08-21 16:33:15 --> Output Class Initialized
INFO - 2023-08-21 16:33:15 --> Security Class Initialized
DEBUG - 2023-08-21 16:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:33:15 --> Input Class Initialized
INFO - 2023-08-21 16:33:15 --> Language Class Initialized
INFO - 2023-08-21 16:33:15 --> Loader Class Initialized
INFO - 2023-08-21 16:33:15 --> Helper loaded: url_helper
INFO - 2023-08-21 16:33:15 --> Helper loaded: file_helper
INFO - 2023-08-21 16:33:15 --> Helper loaded: html_helper
INFO - 2023-08-21 16:33:15 --> Helper loaded: text_helper
INFO - 2023-08-21 16:33:15 --> Helper loaded: form_helper
INFO - 2023-08-21 16:33:15 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:33:15 --> Helper loaded: security_helper
INFO - 2023-08-21 16:33:15 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:33:15 --> Database Driver Class Initialized
INFO - 2023-08-21 16:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:33:15 --> Parser Class Initialized
INFO - 2023-08-21 16:33:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:33:15 --> Pagination Class Initialized
INFO - 2023-08-21 16:33:15 --> Form Validation Class Initialized
INFO - 2023-08-21 16:33:15 --> Controller Class Initialized
INFO - 2023-08-21 16:33:15 --> Model Class Initialized
INFO - 2023-08-21 16:33:15 --> Final output sent to browser
DEBUG - 2023-08-21 16:33:15 --> Total execution time: 0.0148
ERROR - 2023-08-21 16:33:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:33:17 --> Config Class Initialized
INFO - 2023-08-21 16:33:17 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:33:17 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:33:17 --> Utf8 Class Initialized
INFO - 2023-08-21 16:33:17 --> URI Class Initialized
INFO - 2023-08-21 16:33:17 --> Router Class Initialized
INFO - 2023-08-21 16:33:17 --> Output Class Initialized
INFO - 2023-08-21 16:33:17 --> Security Class Initialized
DEBUG - 2023-08-21 16:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:33:17 --> Input Class Initialized
INFO - 2023-08-21 16:33:17 --> Language Class Initialized
INFO - 2023-08-21 16:33:17 --> Loader Class Initialized
INFO - 2023-08-21 16:33:17 --> Helper loaded: url_helper
INFO - 2023-08-21 16:33:17 --> Helper loaded: file_helper
INFO - 2023-08-21 16:33:17 --> Helper loaded: html_helper
INFO - 2023-08-21 16:33:17 --> Helper loaded: text_helper
INFO - 2023-08-21 16:33:17 --> Helper loaded: form_helper
INFO - 2023-08-21 16:33:17 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:33:17 --> Helper loaded: security_helper
INFO - 2023-08-21 16:33:17 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:33:17 --> Database Driver Class Initialized
INFO - 2023-08-21 16:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:33:17 --> Parser Class Initialized
INFO - 2023-08-21 16:33:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:33:17 --> Pagination Class Initialized
INFO - 2023-08-21 16:33:17 --> Form Validation Class Initialized
INFO - 2023-08-21 16:33:17 --> Controller Class Initialized
INFO - 2023-08-21 16:33:17 --> Model Class Initialized
INFO - 2023-08-21 16:33:17 --> Final output sent to browser
DEBUG - 2023-08-21 16:33:17 --> Total execution time: 0.0157
ERROR - 2023-08-21 16:33:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:33:37 --> Config Class Initialized
INFO - 2023-08-21 16:33:37 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:33:37 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:33:37 --> Utf8 Class Initialized
INFO - 2023-08-21 16:33:37 --> URI Class Initialized
INFO - 2023-08-21 16:33:37 --> Router Class Initialized
INFO - 2023-08-21 16:33:37 --> Output Class Initialized
INFO - 2023-08-21 16:33:37 --> Security Class Initialized
DEBUG - 2023-08-21 16:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:33:37 --> Input Class Initialized
INFO - 2023-08-21 16:33:37 --> Language Class Initialized
INFO - 2023-08-21 16:33:37 --> Loader Class Initialized
INFO - 2023-08-21 16:33:37 --> Helper loaded: url_helper
INFO - 2023-08-21 16:33:37 --> Helper loaded: file_helper
INFO - 2023-08-21 16:33:37 --> Helper loaded: html_helper
INFO - 2023-08-21 16:33:37 --> Helper loaded: text_helper
INFO - 2023-08-21 16:33:37 --> Helper loaded: form_helper
INFO - 2023-08-21 16:33:37 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:33:37 --> Helper loaded: security_helper
INFO - 2023-08-21 16:33:37 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:33:37 --> Database Driver Class Initialized
INFO - 2023-08-21 16:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:33:37 --> Parser Class Initialized
INFO - 2023-08-21 16:33:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:33:37 --> Pagination Class Initialized
INFO - 2023-08-21 16:33:37 --> Form Validation Class Initialized
INFO - 2023-08-21 16:33:37 --> Controller Class Initialized
INFO - 2023-08-21 16:33:37 --> Model Class Initialized
INFO - 2023-08-21 16:33:37 --> Model Class Initialized
ERROR - 2023-08-21 16:33:37 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/views/purchase/add_purchase_form.php 157
INFO - 2023-08-21 16:33:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/add_purchase_form.php
DEBUG - 2023-08-21 16:33:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:33:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 16:33:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 16:33:37 --> Model Class Initialized
INFO - 2023-08-21 16:33:37 --> Model Class Initialized
INFO - 2023-08-21 16:33:37 --> Model Class Initialized
INFO - 2023-08-21 16:33:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 16:33:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 16:33:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 16:33:37 --> Final output sent to browser
DEBUG - 2023-08-21 16:33:37 --> Total execution time: 0.1927
ERROR - 2023-08-21 16:34:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:34:15 --> Config Class Initialized
INFO - 2023-08-21 16:34:15 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:34:15 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:34:15 --> Utf8 Class Initialized
INFO - 2023-08-21 16:34:15 --> URI Class Initialized
INFO - 2023-08-21 16:34:15 --> Router Class Initialized
INFO - 2023-08-21 16:34:15 --> Output Class Initialized
INFO - 2023-08-21 16:34:15 --> Security Class Initialized
DEBUG - 2023-08-21 16:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:34:15 --> Input Class Initialized
INFO - 2023-08-21 16:34:15 --> Language Class Initialized
INFO - 2023-08-21 16:34:15 --> Loader Class Initialized
INFO - 2023-08-21 16:34:15 --> Helper loaded: url_helper
INFO - 2023-08-21 16:34:15 --> Helper loaded: file_helper
INFO - 2023-08-21 16:34:15 --> Helper loaded: html_helper
INFO - 2023-08-21 16:34:15 --> Helper loaded: text_helper
INFO - 2023-08-21 16:34:15 --> Helper loaded: form_helper
INFO - 2023-08-21 16:34:15 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:34:15 --> Helper loaded: security_helper
INFO - 2023-08-21 16:34:15 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:34:15 --> Database Driver Class Initialized
INFO - 2023-08-21 16:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:34:15 --> Parser Class Initialized
INFO - 2023-08-21 16:34:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:34:15 --> Pagination Class Initialized
INFO - 2023-08-21 16:34:15 --> Form Validation Class Initialized
INFO - 2023-08-21 16:34:15 --> Controller Class Initialized
INFO - 2023-08-21 16:34:15 --> Model Class Initialized
INFO - 2023-08-21 16:34:15 --> Final output sent to browser
DEBUG - 2023-08-21 16:34:15 --> Total execution time: 0.0187
ERROR - 2023-08-21 16:34:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:34:18 --> Config Class Initialized
INFO - 2023-08-21 16:34:18 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:34:18 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:34:18 --> Utf8 Class Initialized
INFO - 2023-08-21 16:34:18 --> URI Class Initialized
INFO - 2023-08-21 16:34:18 --> Router Class Initialized
INFO - 2023-08-21 16:34:18 --> Output Class Initialized
INFO - 2023-08-21 16:34:18 --> Security Class Initialized
DEBUG - 2023-08-21 16:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:34:18 --> Input Class Initialized
INFO - 2023-08-21 16:34:18 --> Language Class Initialized
INFO - 2023-08-21 16:34:18 --> Loader Class Initialized
INFO - 2023-08-21 16:34:18 --> Helper loaded: url_helper
INFO - 2023-08-21 16:34:18 --> Helper loaded: file_helper
INFO - 2023-08-21 16:34:18 --> Helper loaded: html_helper
INFO - 2023-08-21 16:34:18 --> Helper loaded: text_helper
INFO - 2023-08-21 16:34:18 --> Helper loaded: form_helper
INFO - 2023-08-21 16:34:18 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:34:18 --> Helper loaded: security_helper
INFO - 2023-08-21 16:34:18 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:34:18 --> Database Driver Class Initialized
INFO - 2023-08-21 16:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:34:18 --> Parser Class Initialized
INFO - 2023-08-21 16:34:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:34:18 --> Pagination Class Initialized
INFO - 2023-08-21 16:34:18 --> Form Validation Class Initialized
INFO - 2023-08-21 16:34:18 --> Controller Class Initialized
INFO - 2023-08-21 16:34:18 --> Model Class Initialized
INFO - 2023-08-21 16:34:18 --> Final output sent to browser
DEBUG - 2023-08-21 16:34:18 --> Total execution time: 0.0192
ERROR - 2023-08-21 16:34:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:34:20 --> Config Class Initialized
INFO - 2023-08-21 16:34:20 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:34:20 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:34:20 --> Utf8 Class Initialized
INFO - 2023-08-21 16:34:20 --> URI Class Initialized
INFO - 2023-08-21 16:34:20 --> Router Class Initialized
INFO - 2023-08-21 16:34:20 --> Output Class Initialized
INFO - 2023-08-21 16:34:20 --> Security Class Initialized
DEBUG - 2023-08-21 16:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:34:20 --> Input Class Initialized
INFO - 2023-08-21 16:34:20 --> Language Class Initialized
INFO - 2023-08-21 16:34:20 --> Loader Class Initialized
INFO - 2023-08-21 16:34:20 --> Helper loaded: url_helper
INFO - 2023-08-21 16:34:20 --> Helper loaded: file_helper
INFO - 2023-08-21 16:34:20 --> Helper loaded: html_helper
INFO - 2023-08-21 16:34:20 --> Helper loaded: text_helper
INFO - 2023-08-21 16:34:20 --> Helper loaded: form_helper
INFO - 2023-08-21 16:34:20 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:34:20 --> Helper loaded: security_helper
INFO - 2023-08-21 16:34:20 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:34:20 --> Database Driver Class Initialized
INFO - 2023-08-21 16:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:34:20 --> Parser Class Initialized
INFO - 2023-08-21 16:34:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:34:20 --> Pagination Class Initialized
INFO - 2023-08-21 16:34:20 --> Form Validation Class Initialized
INFO - 2023-08-21 16:34:20 --> Controller Class Initialized
INFO - 2023-08-21 16:34:20 --> Model Class Initialized
INFO - 2023-08-21 16:34:20 --> Final output sent to browser
DEBUG - 2023-08-21 16:34:20 --> Total execution time: 0.0158
ERROR - 2023-08-21 16:34:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:34:22 --> Config Class Initialized
INFO - 2023-08-21 16:34:22 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:34:22 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:34:22 --> Utf8 Class Initialized
INFO - 2023-08-21 16:34:22 --> URI Class Initialized
INFO - 2023-08-21 16:34:22 --> Router Class Initialized
INFO - 2023-08-21 16:34:22 --> Output Class Initialized
INFO - 2023-08-21 16:34:22 --> Security Class Initialized
DEBUG - 2023-08-21 16:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:34:22 --> Input Class Initialized
INFO - 2023-08-21 16:34:22 --> Language Class Initialized
INFO - 2023-08-21 16:34:22 --> Loader Class Initialized
INFO - 2023-08-21 16:34:22 --> Helper loaded: url_helper
INFO - 2023-08-21 16:34:22 --> Helper loaded: file_helper
INFO - 2023-08-21 16:34:22 --> Helper loaded: html_helper
INFO - 2023-08-21 16:34:22 --> Helper loaded: text_helper
INFO - 2023-08-21 16:34:22 --> Helper loaded: form_helper
INFO - 2023-08-21 16:34:22 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:34:22 --> Helper loaded: security_helper
INFO - 2023-08-21 16:34:22 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:34:22 --> Database Driver Class Initialized
INFO - 2023-08-21 16:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:34:22 --> Parser Class Initialized
INFO - 2023-08-21 16:34:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:34:22 --> Pagination Class Initialized
INFO - 2023-08-21 16:34:22 --> Form Validation Class Initialized
INFO - 2023-08-21 16:34:22 --> Controller Class Initialized
INFO - 2023-08-21 16:34:22 --> Model Class Initialized
INFO - 2023-08-21 16:34:22 --> Final output sent to browser
DEBUG - 2023-08-21 16:34:22 --> Total execution time: 0.0172
ERROR - 2023-08-21 16:34:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:34:24 --> Config Class Initialized
INFO - 2023-08-21 16:34:24 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:34:24 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:34:24 --> Utf8 Class Initialized
INFO - 2023-08-21 16:34:24 --> URI Class Initialized
INFO - 2023-08-21 16:34:24 --> Router Class Initialized
INFO - 2023-08-21 16:34:24 --> Output Class Initialized
INFO - 2023-08-21 16:34:24 --> Security Class Initialized
DEBUG - 2023-08-21 16:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:34:24 --> Input Class Initialized
INFO - 2023-08-21 16:34:24 --> Language Class Initialized
INFO - 2023-08-21 16:34:24 --> Loader Class Initialized
INFO - 2023-08-21 16:34:24 --> Helper loaded: url_helper
INFO - 2023-08-21 16:34:24 --> Helper loaded: file_helper
INFO - 2023-08-21 16:34:24 --> Helper loaded: html_helper
INFO - 2023-08-21 16:34:24 --> Helper loaded: text_helper
INFO - 2023-08-21 16:34:24 --> Helper loaded: form_helper
INFO - 2023-08-21 16:34:24 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:34:24 --> Helper loaded: security_helper
INFO - 2023-08-21 16:34:24 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:34:24 --> Database Driver Class Initialized
INFO - 2023-08-21 16:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:34:24 --> Parser Class Initialized
INFO - 2023-08-21 16:34:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:34:24 --> Pagination Class Initialized
INFO - 2023-08-21 16:34:24 --> Form Validation Class Initialized
INFO - 2023-08-21 16:34:24 --> Controller Class Initialized
INFO - 2023-08-21 16:34:24 --> Model Class Initialized
DEBUG - 2023-08-21 16:34:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 16:34:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:34:24 --> Model Class Initialized
DEBUG - 2023-08-21 16:34:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:34:24 --> Model Class Initialized
INFO - 2023-08-21 16:34:24 --> Final output sent to browser
DEBUG - 2023-08-21 16:34:24 --> Total execution time: 0.0193
ERROR - 2023-08-21 16:34:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:34:33 --> Config Class Initialized
INFO - 2023-08-21 16:34:33 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:34:33 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:34:33 --> Utf8 Class Initialized
INFO - 2023-08-21 16:34:33 --> URI Class Initialized
INFO - 2023-08-21 16:34:33 --> Router Class Initialized
INFO - 2023-08-21 16:34:33 --> Output Class Initialized
INFO - 2023-08-21 16:34:33 --> Security Class Initialized
DEBUG - 2023-08-21 16:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:34:33 --> Input Class Initialized
INFO - 2023-08-21 16:34:33 --> Language Class Initialized
INFO - 2023-08-21 16:34:33 --> Loader Class Initialized
INFO - 2023-08-21 16:34:33 --> Helper loaded: url_helper
INFO - 2023-08-21 16:34:33 --> Helper loaded: file_helper
INFO - 2023-08-21 16:34:33 --> Helper loaded: html_helper
INFO - 2023-08-21 16:34:33 --> Helper loaded: text_helper
INFO - 2023-08-21 16:34:33 --> Helper loaded: form_helper
INFO - 2023-08-21 16:34:33 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:34:33 --> Helper loaded: security_helper
INFO - 2023-08-21 16:34:33 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:34:33 --> Database Driver Class Initialized
INFO - 2023-08-21 16:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:34:33 --> Parser Class Initialized
INFO - 2023-08-21 16:34:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:34:33 --> Pagination Class Initialized
INFO - 2023-08-21 16:34:33 --> Form Validation Class Initialized
INFO - 2023-08-21 16:34:33 --> Controller Class Initialized
INFO - 2023-08-21 16:34:33 --> Model Class Initialized
INFO - 2023-08-21 16:34:33 --> Final output sent to browser
DEBUG - 2023-08-21 16:34:33 --> Total execution time: 0.0167
ERROR - 2023-08-21 16:34:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:34:35 --> Config Class Initialized
INFO - 2023-08-21 16:34:35 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:34:35 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:34:35 --> Utf8 Class Initialized
INFO - 2023-08-21 16:34:35 --> URI Class Initialized
INFO - 2023-08-21 16:34:35 --> Router Class Initialized
INFO - 2023-08-21 16:34:35 --> Output Class Initialized
INFO - 2023-08-21 16:34:35 --> Security Class Initialized
DEBUG - 2023-08-21 16:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:34:35 --> Input Class Initialized
INFO - 2023-08-21 16:34:35 --> Language Class Initialized
INFO - 2023-08-21 16:34:35 --> Loader Class Initialized
INFO - 2023-08-21 16:34:35 --> Helper loaded: url_helper
INFO - 2023-08-21 16:34:35 --> Helper loaded: file_helper
INFO - 2023-08-21 16:34:35 --> Helper loaded: html_helper
INFO - 2023-08-21 16:34:35 --> Helper loaded: text_helper
INFO - 2023-08-21 16:34:35 --> Helper loaded: form_helper
INFO - 2023-08-21 16:34:35 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:34:35 --> Helper loaded: security_helper
INFO - 2023-08-21 16:34:35 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:34:35 --> Database Driver Class Initialized
INFO - 2023-08-21 16:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:34:35 --> Parser Class Initialized
INFO - 2023-08-21 16:34:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:34:35 --> Pagination Class Initialized
INFO - 2023-08-21 16:34:35 --> Form Validation Class Initialized
INFO - 2023-08-21 16:34:35 --> Controller Class Initialized
INFO - 2023-08-21 16:34:35 --> Model Class Initialized
INFO - 2023-08-21 16:34:35 --> Final output sent to browser
DEBUG - 2023-08-21 16:34:35 --> Total execution time: 0.0158
ERROR - 2023-08-21 16:35:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:35:54 --> Config Class Initialized
INFO - 2023-08-21 16:35:54 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:35:54 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:35:54 --> Utf8 Class Initialized
INFO - 2023-08-21 16:35:54 --> URI Class Initialized
INFO - 2023-08-21 16:35:54 --> Router Class Initialized
INFO - 2023-08-21 16:35:54 --> Output Class Initialized
INFO - 2023-08-21 16:35:54 --> Security Class Initialized
DEBUG - 2023-08-21 16:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:35:54 --> Input Class Initialized
INFO - 2023-08-21 16:35:54 --> Language Class Initialized
INFO - 2023-08-21 16:35:54 --> Loader Class Initialized
INFO - 2023-08-21 16:35:54 --> Helper loaded: url_helper
INFO - 2023-08-21 16:35:54 --> Helper loaded: file_helper
INFO - 2023-08-21 16:35:54 --> Helper loaded: html_helper
INFO - 2023-08-21 16:35:54 --> Helper loaded: text_helper
INFO - 2023-08-21 16:35:54 --> Helper loaded: form_helper
INFO - 2023-08-21 16:35:54 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:35:54 --> Helper loaded: security_helper
INFO - 2023-08-21 16:35:54 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:35:54 --> Database Driver Class Initialized
INFO - 2023-08-21 16:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:35:54 --> Parser Class Initialized
INFO - 2023-08-21 16:35:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:35:54 --> Pagination Class Initialized
INFO - 2023-08-21 16:35:54 --> Form Validation Class Initialized
INFO - 2023-08-21 16:35:54 --> Controller Class Initialized
INFO - 2023-08-21 16:35:54 --> Model Class Initialized
ERROR - 2023-08-21 16:35:54 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('20230821163554', 'Purchase', '2023-08-21', NULL, 'Purchase No.20230821163554', 0, '50335.04', 1, '1', '2023-08-21', 1)
ERROR - 2023-08-21 16:35:54 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('20230821163554', 'Purchase', '2023-08-21', NULL, 'Purchase No.20230821163554', '50335.04', 0, 1, '1', '2023-08-21', 1)
ERROR - 2023-08-21 16:35:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:35:55 --> Config Class Initialized
INFO - 2023-08-21 16:35:55 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:35:55 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:35:55 --> Utf8 Class Initialized
INFO - 2023-08-21 16:35:55 --> URI Class Initialized
INFO - 2023-08-21 16:35:55 --> Router Class Initialized
INFO - 2023-08-21 16:35:55 --> Output Class Initialized
INFO - 2023-08-21 16:35:55 --> Security Class Initialized
DEBUG - 2023-08-21 16:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:35:55 --> Input Class Initialized
INFO - 2023-08-21 16:35:55 --> Language Class Initialized
INFO - 2023-08-21 16:35:55 --> Loader Class Initialized
INFO - 2023-08-21 16:35:55 --> Helper loaded: url_helper
INFO - 2023-08-21 16:35:55 --> Helper loaded: file_helper
INFO - 2023-08-21 16:35:55 --> Helper loaded: html_helper
INFO - 2023-08-21 16:35:55 --> Helper loaded: text_helper
INFO - 2023-08-21 16:35:55 --> Helper loaded: form_helper
INFO - 2023-08-21 16:35:55 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:35:55 --> Helper loaded: security_helper
INFO - 2023-08-21 16:35:55 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:35:55 --> Database Driver Class Initialized
INFO - 2023-08-21 16:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:35:55 --> Parser Class Initialized
INFO - 2023-08-21 16:35:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:35:55 --> Pagination Class Initialized
INFO - 2023-08-21 16:35:55 --> Form Validation Class Initialized
INFO - 2023-08-21 16:35:55 --> Controller Class Initialized
INFO - 2023-08-21 16:35:55 --> Model Class Initialized
INFO - 2023-08-21 16:35:55 --> Model Class Initialized
INFO - 2023-08-21 16:35:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase_html.php
DEBUG - 2023-08-21 16:35:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:35:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 16:35:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 16:35:55 --> Model Class Initialized
INFO - 2023-08-21 16:35:55 --> Model Class Initialized
INFO - 2023-08-21 16:35:55 --> Model Class Initialized
INFO - 2023-08-21 16:35:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 16:35:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 16:35:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 16:35:55 --> Final output sent to browser
DEBUG - 2023-08-21 16:35:55 --> Total execution time: 0.1440
ERROR - 2023-08-21 16:36:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:36:30 --> Config Class Initialized
INFO - 2023-08-21 16:36:30 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:36:30 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:36:30 --> Utf8 Class Initialized
INFO - 2023-08-21 16:36:30 --> URI Class Initialized
INFO - 2023-08-21 16:36:30 --> Router Class Initialized
INFO - 2023-08-21 16:36:30 --> Output Class Initialized
INFO - 2023-08-21 16:36:30 --> Security Class Initialized
DEBUG - 2023-08-21 16:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:36:30 --> Input Class Initialized
INFO - 2023-08-21 16:36:30 --> Language Class Initialized
INFO - 2023-08-21 16:36:30 --> Loader Class Initialized
INFO - 2023-08-21 16:36:30 --> Helper loaded: url_helper
INFO - 2023-08-21 16:36:30 --> Helper loaded: file_helper
INFO - 2023-08-21 16:36:30 --> Helper loaded: html_helper
INFO - 2023-08-21 16:36:30 --> Helper loaded: text_helper
INFO - 2023-08-21 16:36:30 --> Helper loaded: form_helper
INFO - 2023-08-21 16:36:30 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:36:30 --> Helper loaded: security_helper
INFO - 2023-08-21 16:36:30 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:36:30 --> Database Driver Class Initialized
INFO - 2023-08-21 16:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:36:30 --> Parser Class Initialized
INFO - 2023-08-21 16:36:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:36:30 --> Pagination Class Initialized
INFO - 2023-08-21 16:36:30 --> Form Validation Class Initialized
INFO - 2023-08-21 16:36:30 --> Controller Class Initialized
INFO - 2023-08-21 16:36:30 --> Model Class Initialized
DEBUG - 2023-08-21 16:36:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 16:36:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:36:30 --> Model Class Initialized
DEBUG - 2023-08-21 16:36:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:36:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/add_stockrequest_form.php
DEBUG - 2023-08-21 16:36:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:36:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 16:36:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 16:36:30 --> Model Class Initialized
INFO - 2023-08-21 16:36:30 --> Model Class Initialized
INFO - 2023-08-21 16:36:30 --> Model Class Initialized
INFO - 2023-08-21 16:36:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 16:36:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 16:36:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 16:36:30 --> Final output sent to browser
DEBUG - 2023-08-21 16:36:30 --> Total execution time: 0.1491
ERROR - 2023-08-21 16:36:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:36:35 --> Config Class Initialized
INFO - 2023-08-21 16:36:35 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:36:35 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:36:35 --> Utf8 Class Initialized
INFO - 2023-08-21 16:36:35 --> URI Class Initialized
INFO - 2023-08-21 16:36:35 --> Router Class Initialized
INFO - 2023-08-21 16:36:35 --> Output Class Initialized
INFO - 2023-08-21 16:36:35 --> Security Class Initialized
DEBUG - 2023-08-21 16:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:36:35 --> Input Class Initialized
INFO - 2023-08-21 16:36:35 --> Language Class Initialized
INFO - 2023-08-21 16:36:35 --> Loader Class Initialized
INFO - 2023-08-21 16:36:35 --> Helper loaded: url_helper
INFO - 2023-08-21 16:36:35 --> Helper loaded: file_helper
INFO - 2023-08-21 16:36:35 --> Helper loaded: html_helper
INFO - 2023-08-21 16:36:35 --> Helper loaded: text_helper
INFO - 2023-08-21 16:36:35 --> Helper loaded: form_helper
INFO - 2023-08-21 16:36:35 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:36:35 --> Helper loaded: security_helper
INFO - 2023-08-21 16:36:35 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:36:35 --> Database Driver Class Initialized
INFO - 2023-08-21 16:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:36:35 --> Parser Class Initialized
INFO - 2023-08-21 16:36:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:36:35 --> Pagination Class Initialized
INFO - 2023-08-21 16:36:35 --> Form Validation Class Initialized
INFO - 2023-08-21 16:36:35 --> Controller Class Initialized
INFO - 2023-08-21 16:36:35 --> Model Class Initialized
INFO - 2023-08-21 16:36:35 --> Final output sent to browser
DEBUG - 2023-08-21 16:36:35 --> Total execution time: 0.0140
ERROR - 2023-08-21 16:36:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:36:39 --> Config Class Initialized
INFO - 2023-08-21 16:36:39 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:36:39 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:36:39 --> Utf8 Class Initialized
INFO - 2023-08-21 16:36:39 --> URI Class Initialized
INFO - 2023-08-21 16:36:39 --> Router Class Initialized
INFO - 2023-08-21 16:36:39 --> Output Class Initialized
INFO - 2023-08-21 16:36:39 --> Security Class Initialized
DEBUG - 2023-08-21 16:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:36:39 --> Input Class Initialized
INFO - 2023-08-21 16:36:39 --> Language Class Initialized
INFO - 2023-08-21 16:36:39 --> Loader Class Initialized
INFO - 2023-08-21 16:36:39 --> Helper loaded: url_helper
INFO - 2023-08-21 16:36:39 --> Helper loaded: file_helper
INFO - 2023-08-21 16:36:39 --> Helper loaded: html_helper
INFO - 2023-08-21 16:36:39 --> Helper loaded: text_helper
INFO - 2023-08-21 16:36:39 --> Helper loaded: form_helper
INFO - 2023-08-21 16:36:39 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:36:39 --> Helper loaded: security_helper
INFO - 2023-08-21 16:36:39 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:36:39 --> Database Driver Class Initialized
INFO - 2023-08-21 16:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:36:39 --> Parser Class Initialized
INFO - 2023-08-21 16:36:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:36:39 --> Pagination Class Initialized
INFO - 2023-08-21 16:36:39 --> Form Validation Class Initialized
INFO - 2023-08-21 16:36:39 --> Controller Class Initialized
INFO - 2023-08-21 16:36:39 --> Model Class Initialized
DEBUG - 2023-08-21 16:36:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 16:36:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:36:39 --> Model Class Initialized
DEBUG - 2023-08-21 16:36:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:36:39 --> Model Class Initialized
INFO - 2023-08-21 16:36:39 --> Final output sent to browser
DEBUG - 2023-08-21 16:36:39 --> Total execution time: 0.0184
ERROR - 2023-08-21 16:36:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:36:40 --> Config Class Initialized
INFO - 2023-08-21 16:36:40 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:36:40 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:36:40 --> Utf8 Class Initialized
INFO - 2023-08-21 16:36:40 --> URI Class Initialized
INFO - 2023-08-21 16:36:40 --> Router Class Initialized
INFO - 2023-08-21 16:36:40 --> Output Class Initialized
INFO - 2023-08-21 16:36:40 --> Security Class Initialized
DEBUG - 2023-08-21 16:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:36:40 --> Input Class Initialized
INFO - 2023-08-21 16:36:40 --> Language Class Initialized
INFO - 2023-08-21 16:36:40 --> Loader Class Initialized
INFO - 2023-08-21 16:36:40 --> Helper loaded: url_helper
INFO - 2023-08-21 16:36:40 --> Helper loaded: file_helper
INFO - 2023-08-21 16:36:40 --> Helper loaded: html_helper
INFO - 2023-08-21 16:36:40 --> Helper loaded: text_helper
INFO - 2023-08-21 16:36:40 --> Helper loaded: form_helper
INFO - 2023-08-21 16:36:40 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:36:40 --> Helper loaded: security_helper
INFO - 2023-08-21 16:36:40 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:36:40 --> Database Driver Class Initialized
INFO - 2023-08-21 16:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:36:40 --> Parser Class Initialized
INFO - 2023-08-21 16:36:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:36:40 --> Pagination Class Initialized
INFO - 2023-08-21 16:36:40 --> Form Validation Class Initialized
INFO - 2023-08-21 16:36:40 --> Controller Class Initialized
INFO - 2023-08-21 16:36:40 --> Model Class Initialized
DEBUG - 2023-08-21 16:36:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 16:36:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:36:40 --> Model Class Initialized
DEBUG - 2023-08-21 16:36:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:36:40 --> Model Class Initialized
INFO - 2023-08-21 16:36:40 --> Final output sent to browser
DEBUG - 2023-08-21 16:36:40 --> Total execution time: 0.0183
ERROR - 2023-08-21 16:36:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:36:40 --> Config Class Initialized
INFO - 2023-08-21 16:36:40 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:36:40 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:36:40 --> Utf8 Class Initialized
INFO - 2023-08-21 16:36:40 --> URI Class Initialized
INFO - 2023-08-21 16:36:40 --> Router Class Initialized
INFO - 2023-08-21 16:36:40 --> Output Class Initialized
INFO - 2023-08-21 16:36:40 --> Security Class Initialized
DEBUG - 2023-08-21 16:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:36:40 --> Input Class Initialized
INFO - 2023-08-21 16:36:40 --> Language Class Initialized
INFO - 2023-08-21 16:36:40 --> Loader Class Initialized
INFO - 2023-08-21 16:36:40 --> Helper loaded: url_helper
INFO - 2023-08-21 16:36:40 --> Helper loaded: file_helper
INFO - 2023-08-21 16:36:40 --> Helper loaded: html_helper
INFO - 2023-08-21 16:36:40 --> Helper loaded: text_helper
INFO - 2023-08-21 16:36:40 --> Helper loaded: form_helper
INFO - 2023-08-21 16:36:40 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:36:40 --> Helper loaded: security_helper
INFO - 2023-08-21 16:36:40 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:36:40 --> Database Driver Class Initialized
INFO - 2023-08-21 16:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:36:40 --> Parser Class Initialized
INFO - 2023-08-21 16:36:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:36:40 --> Pagination Class Initialized
INFO - 2023-08-21 16:36:40 --> Form Validation Class Initialized
INFO - 2023-08-21 16:36:40 --> Controller Class Initialized
INFO - 2023-08-21 16:36:40 --> Model Class Initialized
DEBUG - 2023-08-21 16:36:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 16:36:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:36:40 --> Model Class Initialized
DEBUG - 2023-08-21 16:36:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:36:40 --> Model Class Initialized
INFO - 2023-08-21 16:36:40 --> Final output sent to browser
DEBUG - 2023-08-21 16:36:40 --> Total execution time: 0.0218
ERROR - 2023-08-21 16:36:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:36:41 --> Config Class Initialized
INFO - 2023-08-21 16:36:41 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:36:41 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:36:41 --> Utf8 Class Initialized
INFO - 2023-08-21 16:36:41 --> URI Class Initialized
INFO - 2023-08-21 16:36:41 --> Router Class Initialized
INFO - 2023-08-21 16:36:41 --> Output Class Initialized
INFO - 2023-08-21 16:36:41 --> Security Class Initialized
DEBUG - 2023-08-21 16:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:36:41 --> Input Class Initialized
INFO - 2023-08-21 16:36:41 --> Language Class Initialized
INFO - 2023-08-21 16:36:41 --> Loader Class Initialized
INFO - 2023-08-21 16:36:41 --> Helper loaded: url_helper
INFO - 2023-08-21 16:36:41 --> Helper loaded: file_helper
INFO - 2023-08-21 16:36:41 --> Helper loaded: html_helper
INFO - 2023-08-21 16:36:41 --> Helper loaded: text_helper
INFO - 2023-08-21 16:36:41 --> Helper loaded: form_helper
INFO - 2023-08-21 16:36:41 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:36:41 --> Helper loaded: security_helper
INFO - 2023-08-21 16:36:41 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:36:41 --> Database Driver Class Initialized
INFO - 2023-08-21 16:36:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:36:41 --> Parser Class Initialized
INFO - 2023-08-21 16:36:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:36:41 --> Pagination Class Initialized
INFO - 2023-08-21 16:36:41 --> Form Validation Class Initialized
INFO - 2023-08-21 16:36:41 --> Controller Class Initialized
INFO - 2023-08-21 16:36:41 --> Model Class Initialized
DEBUG - 2023-08-21 16:36:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 16:36:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:36:41 --> Model Class Initialized
DEBUG - 2023-08-21 16:36:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:36:41 --> Model Class Initialized
INFO - 2023-08-21 16:36:41 --> Final output sent to browser
DEBUG - 2023-08-21 16:36:41 --> Total execution time: 0.0219
ERROR - 2023-08-21 16:36:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:36:43 --> Config Class Initialized
INFO - 2023-08-21 16:36:43 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:36:43 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:36:43 --> Utf8 Class Initialized
INFO - 2023-08-21 16:36:43 --> URI Class Initialized
INFO - 2023-08-21 16:36:43 --> Router Class Initialized
INFO - 2023-08-21 16:36:43 --> Output Class Initialized
INFO - 2023-08-21 16:36:43 --> Security Class Initialized
DEBUG - 2023-08-21 16:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:36:43 --> Input Class Initialized
INFO - 2023-08-21 16:36:43 --> Language Class Initialized
INFO - 2023-08-21 16:36:43 --> Loader Class Initialized
INFO - 2023-08-21 16:36:43 --> Helper loaded: url_helper
INFO - 2023-08-21 16:36:43 --> Helper loaded: file_helper
INFO - 2023-08-21 16:36:43 --> Helper loaded: html_helper
INFO - 2023-08-21 16:36:43 --> Helper loaded: text_helper
INFO - 2023-08-21 16:36:43 --> Helper loaded: form_helper
INFO - 2023-08-21 16:36:43 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:36:43 --> Helper loaded: security_helper
INFO - 2023-08-21 16:36:43 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:36:43 --> Database Driver Class Initialized
INFO - 2023-08-21 16:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:36:43 --> Parser Class Initialized
INFO - 2023-08-21 16:36:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:36:43 --> Pagination Class Initialized
INFO - 2023-08-21 16:36:43 --> Form Validation Class Initialized
INFO - 2023-08-21 16:36:43 --> Controller Class Initialized
INFO - 2023-08-21 16:36:43 --> Model Class Initialized
DEBUG - 2023-08-21 16:36:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 16:36:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:36:43 --> Model Class Initialized
DEBUG - 2023-08-21 16:36:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:36:43 --> Model Class Initialized
INFO - 2023-08-21 16:36:43 --> Final output sent to browser
DEBUG - 2023-08-21 16:36:43 --> Total execution time: 0.0181
ERROR - 2023-08-21 16:36:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:36:43 --> Config Class Initialized
INFO - 2023-08-21 16:36:43 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:36:43 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:36:43 --> Utf8 Class Initialized
INFO - 2023-08-21 16:36:43 --> URI Class Initialized
INFO - 2023-08-21 16:36:43 --> Router Class Initialized
INFO - 2023-08-21 16:36:43 --> Output Class Initialized
INFO - 2023-08-21 16:36:43 --> Security Class Initialized
DEBUG - 2023-08-21 16:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:36:43 --> Input Class Initialized
INFO - 2023-08-21 16:36:43 --> Language Class Initialized
INFO - 2023-08-21 16:36:43 --> Loader Class Initialized
INFO - 2023-08-21 16:36:43 --> Helper loaded: url_helper
INFO - 2023-08-21 16:36:43 --> Helper loaded: file_helper
INFO - 2023-08-21 16:36:43 --> Helper loaded: html_helper
INFO - 2023-08-21 16:36:43 --> Helper loaded: text_helper
INFO - 2023-08-21 16:36:43 --> Helper loaded: form_helper
INFO - 2023-08-21 16:36:43 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:36:43 --> Helper loaded: security_helper
INFO - 2023-08-21 16:36:43 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:36:43 --> Database Driver Class Initialized
INFO - 2023-08-21 16:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:36:43 --> Parser Class Initialized
INFO - 2023-08-21 16:36:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:36:43 --> Pagination Class Initialized
INFO - 2023-08-21 16:36:43 --> Form Validation Class Initialized
INFO - 2023-08-21 16:36:43 --> Controller Class Initialized
INFO - 2023-08-21 16:36:43 --> Model Class Initialized
DEBUG - 2023-08-21 16:36:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 16:36:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:36:43 --> Model Class Initialized
DEBUG - 2023-08-21 16:36:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:36:43 --> Model Class Initialized
INFO - 2023-08-21 16:36:43 --> Final output sent to browser
DEBUG - 2023-08-21 16:36:43 --> Total execution time: 0.0179
ERROR - 2023-08-21 16:36:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:36:45 --> Config Class Initialized
INFO - 2023-08-21 16:36:45 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:36:45 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:36:45 --> Utf8 Class Initialized
INFO - 2023-08-21 16:36:45 --> URI Class Initialized
INFO - 2023-08-21 16:36:45 --> Router Class Initialized
INFO - 2023-08-21 16:36:45 --> Output Class Initialized
INFO - 2023-08-21 16:36:45 --> Security Class Initialized
DEBUG - 2023-08-21 16:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:36:45 --> Input Class Initialized
INFO - 2023-08-21 16:36:45 --> Language Class Initialized
INFO - 2023-08-21 16:36:45 --> Loader Class Initialized
INFO - 2023-08-21 16:36:45 --> Helper loaded: url_helper
INFO - 2023-08-21 16:36:45 --> Helper loaded: file_helper
INFO - 2023-08-21 16:36:45 --> Helper loaded: html_helper
INFO - 2023-08-21 16:36:45 --> Helper loaded: text_helper
INFO - 2023-08-21 16:36:45 --> Helper loaded: form_helper
INFO - 2023-08-21 16:36:45 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:36:45 --> Helper loaded: security_helper
INFO - 2023-08-21 16:36:45 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:36:45 --> Database Driver Class Initialized
INFO - 2023-08-21 16:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:36:45 --> Parser Class Initialized
INFO - 2023-08-21 16:36:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:36:45 --> Pagination Class Initialized
INFO - 2023-08-21 16:36:45 --> Form Validation Class Initialized
INFO - 2023-08-21 16:36:45 --> Controller Class Initialized
INFO - 2023-08-21 16:36:45 --> Model Class Initialized
DEBUG - 2023-08-21 16:36:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 16:36:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:36:45 --> Model Class Initialized
DEBUG - 2023-08-21 16:36:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:36:45 --> Model Class Initialized
INFO - 2023-08-21 16:36:45 --> Model Class Initialized
INFO - 2023-08-21 16:36:45 --> Final output sent to browser
DEBUG - 2023-08-21 16:36:45 --> Total execution time: 0.0216
ERROR - 2023-08-21 16:36:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:36:48 --> Config Class Initialized
INFO - 2023-08-21 16:36:48 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:36:48 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:36:48 --> Utf8 Class Initialized
INFO - 2023-08-21 16:36:48 --> URI Class Initialized
INFO - 2023-08-21 16:36:48 --> Router Class Initialized
INFO - 2023-08-21 16:36:48 --> Output Class Initialized
INFO - 2023-08-21 16:36:48 --> Security Class Initialized
DEBUG - 2023-08-21 16:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:36:48 --> Input Class Initialized
INFO - 2023-08-21 16:36:48 --> Language Class Initialized
INFO - 2023-08-21 16:36:48 --> Loader Class Initialized
INFO - 2023-08-21 16:36:48 --> Helper loaded: url_helper
INFO - 2023-08-21 16:36:48 --> Helper loaded: file_helper
INFO - 2023-08-21 16:36:48 --> Helper loaded: html_helper
INFO - 2023-08-21 16:36:48 --> Helper loaded: text_helper
INFO - 2023-08-21 16:36:48 --> Helper loaded: form_helper
INFO - 2023-08-21 16:36:48 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:36:48 --> Helper loaded: security_helper
INFO - 2023-08-21 16:36:48 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:36:48 --> Database Driver Class Initialized
INFO - 2023-08-21 16:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:36:48 --> Parser Class Initialized
INFO - 2023-08-21 16:36:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:36:48 --> Pagination Class Initialized
INFO - 2023-08-21 16:36:48 --> Form Validation Class Initialized
INFO - 2023-08-21 16:36:48 --> Controller Class Initialized
INFO - 2023-08-21 16:36:48 --> Model Class Initialized
DEBUG - 2023-08-21 16:36:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 16:36:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:36:48 --> Model Class Initialized
DEBUG - 2023-08-21 16:36:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:36:48 --> Model Class Initialized
INFO - 2023-08-21 16:36:48 --> Final output sent to browser
DEBUG - 2023-08-21 16:36:48 --> Total execution time: 0.0189
ERROR - 2023-08-21 16:36:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:36:54 --> Config Class Initialized
INFO - 2023-08-21 16:36:54 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:36:54 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:36:54 --> Utf8 Class Initialized
INFO - 2023-08-21 16:36:54 --> URI Class Initialized
DEBUG - 2023-08-21 16:36:54 --> No URI present. Default controller set.
INFO - 2023-08-21 16:36:54 --> Router Class Initialized
INFO - 2023-08-21 16:36:54 --> Output Class Initialized
INFO - 2023-08-21 16:36:54 --> Security Class Initialized
DEBUG - 2023-08-21 16:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:36:54 --> Input Class Initialized
INFO - 2023-08-21 16:36:54 --> Language Class Initialized
INFO - 2023-08-21 16:36:54 --> Loader Class Initialized
INFO - 2023-08-21 16:36:54 --> Helper loaded: url_helper
INFO - 2023-08-21 16:36:54 --> Helper loaded: file_helper
INFO - 2023-08-21 16:36:54 --> Helper loaded: html_helper
INFO - 2023-08-21 16:36:54 --> Helper loaded: text_helper
INFO - 2023-08-21 16:36:54 --> Helper loaded: form_helper
INFO - 2023-08-21 16:36:54 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:36:54 --> Helper loaded: security_helper
INFO - 2023-08-21 16:36:54 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:36:54 --> Database Driver Class Initialized
INFO - 2023-08-21 16:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:36:54 --> Parser Class Initialized
INFO - 2023-08-21 16:36:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:36:54 --> Pagination Class Initialized
INFO - 2023-08-21 16:36:54 --> Form Validation Class Initialized
INFO - 2023-08-21 16:36:54 --> Controller Class Initialized
INFO - 2023-08-21 16:36:54 --> Model Class Initialized
DEBUG - 2023-08-21 16:36:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:36:54 --> Model Class Initialized
DEBUG - 2023-08-21 16:36:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:36:54 --> Model Class Initialized
INFO - 2023-08-21 16:36:54 --> Model Class Initialized
INFO - 2023-08-21 16:36:54 --> Model Class Initialized
INFO - 2023-08-21 16:36:54 --> Model Class Initialized
DEBUG - 2023-08-21 16:36:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 16:36:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:36:54 --> Model Class Initialized
INFO - 2023-08-21 16:36:54 --> Model Class Initialized
INFO - 2023-08-21 16:36:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-21 16:36:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:36:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 16:36:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 16:36:54 --> Model Class Initialized
INFO - 2023-08-21 16:36:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 16:36:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 16:36:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 16:36:54 --> Final output sent to browser
DEBUG - 2023-08-21 16:36:54 --> Total execution time: 0.1946
ERROR - 2023-08-21 16:37:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-21 16:37:23 --> Config Class Initialized
INFO - 2023-08-21 16:37:23 --> Hooks Class Initialized
DEBUG - 2023-08-21 16:37:23 --> UTF-8 Support Enabled
INFO - 2023-08-21 16:37:23 --> Utf8 Class Initialized
INFO - 2023-08-21 16:37:23 --> URI Class Initialized
DEBUG - 2023-08-21 16:37:23 --> No URI present. Default controller set.
INFO - 2023-08-21 16:37:23 --> Router Class Initialized
INFO - 2023-08-21 16:37:23 --> Output Class Initialized
INFO - 2023-08-21 16:37:23 --> Security Class Initialized
DEBUG - 2023-08-21 16:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 16:37:23 --> Input Class Initialized
INFO - 2023-08-21 16:37:23 --> Language Class Initialized
INFO - 2023-08-21 16:37:23 --> Loader Class Initialized
INFO - 2023-08-21 16:37:23 --> Helper loaded: url_helper
INFO - 2023-08-21 16:37:23 --> Helper loaded: file_helper
INFO - 2023-08-21 16:37:23 --> Helper loaded: html_helper
INFO - 2023-08-21 16:37:23 --> Helper loaded: text_helper
INFO - 2023-08-21 16:37:23 --> Helper loaded: form_helper
INFO - 2023-08-21 16:37:23 --> Helper loaded: lang_helper
INFO - 2023-08-21 16:37:23 --> Helper loaded: security_helper
INFO - 2023-08-21 16:37:23 --> Helper loaded: cookie_helper
INFO - 2023-08-21 16:37:23 --> Database Driver Class Initialized
INFO - 2023-08-21 16:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 16:37:23 --> Parser Class Initialized
INFO - 2023-08-21 16:37:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-21 16:37:23 --> Pagination Class Initialized
INFO - 2023-08-21 16:37:23 --> Form Validation Class Initialized
INFO - 2023-08-21 16:37:23 --> Controller Class Initialized
INFO - 2023-08-21 16:37:23 --> Model Class Initialized
DEBUG - 2023-08-21 16:37:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:37:23 --> Model Class Initialized
DEBUG - 2023-08-21 16:37:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:37:23 --> Model Class Initialized
INFO - 2023-08-21 16:37:23 --> Model Class Initialized
INFO - 2023-08-21 16:37:23 --> Model Class Initialized
INFO - 2023-08-21 16:37:23 --> Model Class Initialized
DEBUG - 2023-08-21 16:37:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-21 16:37:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:37:23 --> Model Class Initialized
INFO - 2023-08-21 16:37:23 --> Model Class Initialized
INFO - 2023-08-21 16:37:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-21 16:37:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-21 16:37:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-21 16:37:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-21 16:37:23 --> Model Class Initialized
INFO - 2023-08-21 16:37:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-21 16:37:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-21 16:37:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-21 16:37:23 --> Final output sent to browser
DEBUG - 2023-08-21 16:37:23 --> Total execution time: 0.1871
