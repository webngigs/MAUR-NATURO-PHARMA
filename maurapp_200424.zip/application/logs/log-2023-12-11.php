<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-11 03:45:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 03:45:58 --> Config Class Initialized
INFO - 2023-12-11 03:45:58 --> Hooks Class Initialized
DEBUG - 2023-12-11 03:45:58 --> UTF-8 Support Enabled
INFO - 2023-12-11 03:45:58 --> Utf8 Class Initialized
INFO - 2023-12-11 03:45:58 --> URI Class Initialized
INFO - 2023-12-11 03:45:58 --> Router Class Initialized
INFO - 2023-12-11 03:45:58 --> Output Class Initialized
INFO - 2023-12-11 03:45:58 --> Security Class Initialized
DEBUG - 2023-12-11 03:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 03:45:58 --> Input Class Initialized
INFO - 2023-12-11 03:45:58 --> Language Class Initialized
ERROR - 2023-12-11 03:45:58 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-12-11 05:06:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:06:08 --> Config Class Initialized
INFO - 2023-12-11 05:06:08 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:06:08 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:06:08 --> Utf8 Class Initialized
INFO - 2023-12-11 05:06:08 --> URI Class Initialized
INFO - 2023-12-11 05:06:08 --> Router Class Initialized
INFO - 2023-12-11 05:06:08 --> Output Class Initialized
INFO - 2023-12-11 05:06:08 --> Security Class Initialized
DEBUG - 2023-12-11 05:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:06:08 --> Input Class Initialized
INFO - 2023-12-11 05:06:08 --> Language Class Initialized
INFO - 2023-12-11 05:06:08 --> Loader Class Initialized
INFO - 2023-12-11 05:06:08 --> Helper loaded: url_helper
INFO - 2023-12-11 05:06:08 --> Helper loaded: file_helper
INFO - 2023-12-11 05:06:08 --> Helper loaded: html_helper
INFO - 2023-12-11 05:06:08 --> Helper loaded: text_helper
INFO - 2023-12-11 05:06:08 --> Helper loaded: form_helper
INFO - 2023-12-11 05:06:08 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:06:08 --> Helper loaded: security_helper
INFO - 2023-12-11 05:06:08 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:06:08 --> Database Driver Class Initialized
INFO - 2023-12-11 05:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:06:08 --> Parser Class Initialized
INFO - 2023-12-11 05:06:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:06:08 --> Pagination Class Initialized
INFO - 2023-12-11 05:06:08 --> Form Validation Class Initialized
INFO - 2023-12-11 05:06:08 --> Controller Class Initialized
ERROR - 2023-12-11 05:06:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:06:09 --> Config Class Initialized
INFO - 2023-12-11 05:06:09 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:06:09 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:06:09 --> Utf8 Class Initialized
INFO - 2023-12-11 05:06:09 --> URI Class Initialized
INFO - 2023-12-11 05:06:09 --> Router Class Initialized
INFO - 2023-12-11 05:06:09 --> Output Class Initialized
INFO - 2023-12-11 05:06:09 --> Security Class Initialized
DEBUG - 2023-12-11 05:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:06:09 --> Input Class Initialized
INFO - 2023-12-11 05:06:09 --> Language Class Initialized
INFO - 2023-12-11 05:06:09 --> Loader Class Initialized
INFO - 2023-12-11 05:06:09 --> Helper loaded: url_helper
INFO - 2023-12-11 05:06:09 --> Helper loaded: file_helper
INFO - 2023-12-11 05:06:09 --> Helper loaded: html_helper
INFO - 2023-12-11 05:06:09 --> Helper loaded: text_helper
INFO - 2023-12-11 05:06:09 --> Helper loaded: form_helper
INFO - 2023-12-11 05:06:09 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:06:09 --> Helper loaded: security_helper
INFO - 2023-12-11 05:06:09 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:06:09 --> Database Driver Class Initialized
INFO - 2023-12-11 05:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:06:09 --> Parser Class Initialized
INFO - 2023-12-11 05:06:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:06:09 --> Pagination Class Initialized
INFO - 2023-12-11 05:06:09 --> Form Validation Class Initialized
INFO - 2023-12-11 05:06:09 --> Controller Class Initialized
INFO - 2023-12-11 05:06:09 --> Model Class Initialized
DEBUG - 2023-12-11 05:06:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:06:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-11 05:06:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:06:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-11 05:06:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-11 05:06:09 --> Model Class Initialized
INFO - 2023-12-11 05:06:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-11 05:06:09 --> Final output sent to browser
DEBUG - 2023-12-11 05:06:09 --> Total execution time: 0.0334
ERROR - 2023-12-11 05:10:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:10:32 --> Config Class Initialized
INFO - 2023-12-11 05:10:32 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:10:32 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:10:32 --> Utf8 Class Initialized
INFO - 2023-12-11 05:10:32 --> URI Class Initialized
DEBUG - 2023-12-11 05:10:32 --> No URI present. Default controller set.
INFO - 2023-12-11 05:10:32 --> Router Class Initialized
INFO - 2023-12-11 05:10:32 --> Output Class Initialized
INFO - 2023-12-11 05:10:32 --> Security Class Initialized
DEBUG - 2023-12-11 05:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:10:32 --> Input Class Initialized
INFO - 2023-12-11 05:10:32 --> Language Class Initialized
INFO - 2023-12-11 05:10:32 --> Loader Class Initialized
INFO - 2023-12-11 05:10:32 --> Helper loaded: url_helper
INFO - 2023-12-11 05:10:32 --> Helper loaded: file_helper
INFO - 2023-12-11 05:10:32 --> Helper loaded: html_helper
INFO - 2023-12-11 05:10:32 --> Helper loaded: text_helper
INFO - 2023-12-11 05:10:32 --> Helper loaded: form_helper
INFO - 2023-12-11 05:10:32 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:10:32 --> Helper loaded: security_helper
INFO - 2023-12-11 05:10:32 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:10:32 --> Database Driver Class Initialized
INFO - 2023-12-11 05:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:10:32 --> Parser Class Initialized
INFO - 2023-12-11 05:10:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:10:32 --> Pagination Class Initialized
INFO - 2023-12-11 05:10:32 --> Form Validation Class Initialized
INFO - 2023-12-11 05:10:32 --> Controller Class Initialized
INFO - 2023-12-11 05:10:32 --> Model Class Initialized
DEBUG - 2023-12-11 05:10:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-11 05:10:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:10:33 --> Config Class Initialized
INFO - 2023-12-11 05:10:33 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:10:33 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:10:33 --> Utf8 Class Initialized
INFO - 2023-12-11 05:10:33 --> URI Class Initialized
INFO - 2023-12-11 05:10:33 --> Router Class Initialized
INFO - 2023-12-11 05:10:33 --> Output Class Initialized
INFO - 2023-12-11 05:10:33 --> Security Class Initialized
DEBUG - 2023-12-11 05:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:10:33 --> Input Class Initialized
INFO - 2023-12-11 05:10:33 --> Language Class Initialized
INFO - 2023-12-11 05:10:33 --> Loader Class Initialized
INFO - 2023-12-11 05:10:33 --> Helper loaded: url_helper
INFO - 2023-12-11 05:10:33 --> Helper loaded: file_helper
INFO - 2023-12-11 05:10:33 --> Helper loaded: html_helper
INFO - 2023-12-11 05:10:33 --> Helper loaded: text_helper
INFO - 2023-12-11 05:10:33 --> Helper loaded: form_helper
INFO - 2023-12-11 05:10:33 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:10:33 --> Helper loaded: security_helper
INFO - 2023-12-11 05:10:33 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:10:33 --> Database Driver Class Initialized
INFO - 2023-12-11 05:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:10:33 --> Parser Class Initialized
INFO - 2023-12-11 05:10:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:10:33 --> Pagination Class Initialized
INFO - 2023-12-11 05:10:33 --> Form Validation Class Initialized
INFO - 2023-12-11 05:10:33 --> Controller Class Initialized
INFO - 2023-12-11 05:10:33 --> Model Class Initialized
DEBUG - 2023-12-11 05:10:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:10:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-11 05:10:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:10:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-11 05:10:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-11 05:10:33 --> Model Class Initialized
INFO - 2023-12-11 05:10:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-11 05:10:33 --> Final output sent to browser
DEBUG - 2023-12-11 05:10:33 --> Total execution time: 0.0462
ERROR - 2023-12-11 05:10:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:10:37 --> Config Class Initialized
INFO - 2023-12-11 05:10:37 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:10:37 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:10:37 --> Utf8 Class Initialized
INFO - 2023-12-11 05:10:37 --> URI Class Initialized
INFO - 2023-12-11 05:10:37 --> Router Class Initialized
INFO - 2023-12-11 05:10:37 --> Output Class Initialized
INFO - 2023-12-11 05:10:37 --> Security Class Initialized
DEBUG - 2023-12-11 05:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:10:37 --> Input Class Initialized
INFO - 2023-12-11 05:10:37 --> Language Class Initialized
INFO - 2023-12-11 05:10:37 --> Loader Class Initialized
INFO - 2023-12-11 05:10:37 --> Helper loaded: url_helper
INFO - 2023-12-11 05:10:37 --> Helper loaded: file_helper
INFO - 2023-12-11 05:10:37 --> Helper loaded: html_helper
INFO - 2023-12-11 05:10:37 --> Helper loaded: text_helper
INFO - 2023-12-11 05:10:37 --> Helper loaded: form_helper
INFO - 2023-12-11 05:10:37 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:10:37 --> Helper loaded: security_helper
INFO - 2023-12-11 05:10:37 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:10:37 --> Database Driver Class Initialized
INFO - 2023-12-11 05:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:10:37 --> Parser Class Initialized
INFO - 2023-12-11 05:10:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:10:37 --> Pagination Class Initialized
INFO - 2023-12-11 05:10:37 --> Form Validation Class Initialized
INFO - 2023-12-11 05:10:37 --> Controller Class Initialized
INFO - 2023-12-11 05:10:37 --> Model Class Initialized
DEBUG - 2023-12-11 05:10:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:10:37 --> Model Class Initialized
INFO - 2023-12-11 05:10:37 --> Final output sent to browser
DEBUG - 2023-12-11 05:10:37 --> Total execution time: 0.0188
ERROR - 2023-12-11 05:10:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:10:37 --> Config Class Initialized
INFO - 2023-12-11 05:10:37 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:10:37 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:10:37 --> Utf8 Class Initialized
INFO - 2023-12-11 05:10:37 --> URI Class Initialized
DEBUG - 2023-12-11 05:10:37 --> No URI present. Default controller set.
INFO - 2023-12-11 05:10:37 --> Router Class Initialized
INFO - 2023-12-11 05:10:37 --> Output Class Initialized
INFO - 2023-12-11 05:10:37 --> Security Class Initialized
DEBUG - 2023-12-11 05:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:10:37 --> Input Class Initialized
INFO - 2023-12-11 05:10:37 --> Language Class Initialized
INFO - 2023-12-11 05:10:37 --> Loader Class Initialized
INFO - 2023-12-11 05:10:37 --> Helper loaded: url_helper
INFO - 2023-12-11 05:10:37 --> Helper loaded: file_helper
INFO - 2023-12-11 05:10:37 --> Helper loaded: html_helper
INFO - 2023-12-11 05:10:37 --> Helper loaded: text_helper
INFO - 2023-12-11 05:10:37 --> Helper loaded: form_helper
INFO - 2023-12-11 05:10:37 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:10:37 --> Helper loaded: security_helper
INFO - 2023-12-11 05:10:37 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:10:37 --> Database Driver Class Initialized
INFO - 2023-12-11 05:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:10:37 --> Parser Class Initialized
INFO - 2023-12-11 05:10:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:10:37 --> Pagination Class Initialized
INFO - 2023-12-11 05:10:37 --> Form Validation Class Initialized
INFO - 2023-12-11 05:10:37 --> Controller Class Initialized
INFO - 2023-12-11 05:10:37 --> Model Class Initialized
DEBUG - 2023-12-11 05:10:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:10:37 --> Model Class Initialized
DEBUG - 2023-12-11 05:10:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:10:37 --> Model Class Initialized
INFO - 2023-12-11 05:10:37 --> Model Class Initialized
INFO - 2023-12-11 05:10:37 --> Model Class Initialized
INFO - 2023-12-11 05:10:37 --> Model Class Initialized
DEBUG - 2023-12-11 05:10:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-11 05:10:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:10:37 --> Model Class Initialized
INFO - 2023-12-11 05:10:37 --> Model Class Initialized
INFO - 2023-12-11 05:10:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-11 05:10:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:10:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-11 05:10:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-11 05:10:37 --> Model Class Initialized
INFO - 2023-12-11 05:10:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-11 05:10:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-11 05:10:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-11 05:10:38 --> Final output sent to browser
DEBUG - 2023-12-11 05:10:38 --> Total execution time: 0.4183
ERROR - 2023-12-11 05:10:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:10:38 --> Config Class Initialized
INFO - 2023-12-11 05:10:38 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:10:38 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:10:38 --> Utf8 Class Initialized
INFO - 2023-12-11 05:10:38 --> URI Class Initialized
INFO - 2023-12-11 05:10:38 --> Router Class Initialized
INFO - 2023-12-11 05:10:38 --> Output Class Initialized
INFO - 2023-12-11 05:10:38 --> Security Class Initialized
DEBUG - 2023-12-11 05:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:10:38 --> Input Class Initialized
INFO - 2023-12-11 05:10:38 --> Language Class Initialized
INFO - 2023-12-11 05:10:38 --> Loader Class Initialized
INFO - 2023-12-11 05:10:38 --> Helper loaded: url_helper
INFO - 2023-12-11 05:10:38 --> Helper loaded: file_helper
INFO - 2023-12-11 05:10:38 --> Helper loaded: html_helper
INFO - 2023-12-11 05:10:38 --> Helper loaded: text_helper
INFO - 2023-12-11 05:10:38 --> Helper loaded: form_helper
INFO - 2023-12-11 05:10:38 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:10:38 --> Helper loaded: security_helper
INFO - 2023-12-11 05:10:38 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:10:38 --> Database Driver Class Initialized
INFO - 2023-12-11 05:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:10:38 --> Parser Class Initialized
INFO - 2023-12-11 05:10:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:10:38 --> Pagination Class Initialized
INFO - 2023-12-11 05:10:38 --> Form Validation Class Initialized
INFO - 2023-12-11 05:10:38 --> Controller Class Initialized
DEBUG - 2023-12-11 05:10:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-11 05:10:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:10:38 --> Model Class Initialized
INFO - 2023-12-11 05:10:38 --> Final output sent to browser
DEBUG - 2023-12-11 05:10:38 --> Total execution time: 0.0131
ERROR - 2023-12-11 05:10:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:10:53 --> Config Class Initialized
INFO - 2023-12-11 05:10:53 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:10:53 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:10:53 --> Utf8 Class Initialized
INFO - 2023-12-11 05:10:53 --> URI Class Initialized
INFO - 2023-12-11 05:10:53 --> Router Class Initialized
INFO - 2023-12-11 05:10:53 --> Output Class Initialized
INFO - 2023-12-11 05:10:53 --> Security Class Initialized
DEBUG - 2023-12-11 05:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:10:53 --> Input Class Initialized
INFO - 2023-12-11 05:10:53 --> Language Class Initialized
INFO - 2023-12-11 05:10:53 --> Loader Class Initialized
INFO - 2023-12-11 05:10:53 --> Helper loaded: url_helper
INFO - 2023-12-11 05:10:53 --> Helper loaded: file_helper
INFO - 2023-12-11 05:10:53 --> Helper loaded: html_helper
INFO - 2023-12-11 05:10:53 --> Helper loaded: text_helper
INFO - 2023-12-11 05:10:53 --> Helper loaded: form_helper
INFO - 2023-12-11 05:10:53 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:10:53 --> Helper loaded: security_helper
INFO - 2023-12-11 05:10:53 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:10:53 --> Database Driver Class Initialized
INFO - 2023-12-11 05:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:10:53 --> Parser Class Initialized
INFO - 2023-12-11 05:10:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:10:53 --> Pagination Class Initialized
INFO - 2023-12-11 05:10:53 --> Form Validation Class Initialized
INFO - 2023-12-11 05:10:53 --> Controller Class Initialized
DEBUG - 2023-12-11 05:10:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-11 05:10:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:10:53 --> Model Class Initialized
INFO - 2023-12-11 05:10:53 --> Model Class Initialized
DEBUG - 2023-12-11 05:10:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-11 05:10:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:10:53 --> Model Class Initialized
DEBUG - 2023-12-11 05:10:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:10:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gst/list.php
DEBUG - 2023-12-11 05:10:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:10:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-11 05:10:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-11 05:10:53 --> Model Class Initialized
INFO - 2023-12-11 05:10:53 --> Model Class Initialized
INFO - 2023-12-11 05:10:53 --> Model Class Initialized
INFO - 2023-12-11 05:10:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-11 05:10:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-11 05:10:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-11 05:10:53 --> Final output sent to browser
DEBUG - 2023-12-11 05:10:53 --> Total execution time: 0.2220
ERROR - 2023-12-11 05:10:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:10:55 --> Config Class Initialized
INFO - 2023-12-11 05:10:55 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:10:55 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:10:55 --> Utf8 Class Initialized
INFO - 2023-12-11 05:10:55 --> URI Class Initialized
DEBUG - 2023-12-11 05:10:55 --> No URI present. Default controller set.
INFO - 2023-12-11 05:10:55 --> Router Class Initialized
INFO - 2023-12-11 05:10:55 --> Output Class Initialized
INFO - 2023-12-11 05:10:55 --> Security Class Initialized
DEBUG - 2023-12-11 05:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:10:55 --> Input Class Initialized
INFO - 2023-12-11 05:10:55 --> Language Class Initialized
INFO - 2023-12-11 05:10:55 --> Loader Class Initialized
INFO - 2023-12-11 05:10:55 --> Helper loaded: url_helper
INFO - 2023-12-11 05:10:55 --> Helper loaded: file_helper
INFO - 2023-12-11 05:10:55 --> Helper loaded: html_helper
INFO - 2023-12-11 05:10:55 --> Helper loaded: text_helper
INFO - 2023-12-11 05:10:55 --> Helper loaded: form_helper
INFO - 2023-12-11 05:10:55 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:10:55 --> Helper loaded: security_helper
INFO - 2023-12-11 05:10:55 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:10:55 --> Database Driver Class Initialized
INFO - 2023-12-11 05:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:10:55 --> Parser Class Initialized
INFO - 2023-12-11 05:10:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:10:55 --> Pagination Class Initialized
INFO - 2023-12-11 05:10:55 --> Form Validation Class Initialized
INFO - 2023-12-11 05:10:55 --> Controller Class Initialized
INFO - 2023-12-11 05:10:55 --> Model Class Initialized
DEBUG - 2023-12-11 05:10:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:10:55 --> Model Class Initialized
DEBUG - 2023-12-11 05:10:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:10:55 --> Model Class Initialized
INFO - 2023-12-11 05:10:55 --> Model Class Initialized
INFO - 2023-12-11 05:10:55 --> Model Class Initialized
INFO - 2023-12-11 05:10:55 --> Model Class Initialized
DEBUG - 2023-12-11 05:10:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-11 05:10:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:10:55 --> Model Class Initialized
INFO - 2023-12-11 05:10:55 --> Model Class Initialized
INFO - 2023-12-11 05:10:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-11 05:10:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:10:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-11 05:10:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-11 05:10:55 --> Model Class Initialized
INFO - 2023-12-11 05:10:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-11 05:10:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-11 05:10:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-11 05:10:56 --> Final output sent to browser
DEBUG - 2023-12-11 05:10:56 --> Total execution time: 0.4100
ERROR - 2023-12-11 05:11:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:11:08 --> Config Class Initialized
INFO - 2023-12-11 05:11:08 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:11:08 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:11:08 --> Utf8 Class Initialized
INFO - 2023-12-11 05:11:08 --> URI Class Initialized
DEBUG - 2023-12-11 05:11:08 --> No URI present. Default controller set.
INFO - 2023-12-11 05:11:08 --> Router Class Initialized
INFO - 2023-12-11 05:11:08 --> Output Class Initialized
INFO - 2023-12-11 05:11:08 --> Security Class Initialized
DEBUG - 2023-12-11 05:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:11:08 --> Input Class Initialized
INFO - 2023-12-11 05:11:08 --> Language Class Initialized
INFO - 2023-12-11 05:11:08 --> Loader Class Initialized
INFO - 2023-12-11 05:11:08 --> Helper loaded: url_helper
INFO - 2023-12-11 05:11:08 --> Helper loaded: file_helper
INFO - 2023-12-11 05:11:08 --> Helper loaded: html_helper
INFO - 2023-12-11 05:11:08 --> Helper loaded: text_helper
INFO - 2023-12-11 05:11:08 --> Helper loaded: form_helper
INFO - 2023-12-11 05:11:08 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:11:08 --> Helper loaded: security_helper
INFO - 2023-12-11 05:11:08 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:11:08 --> Database Driver Class Initialized
INFO - 2023-12-11 05:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:11:08 --> Parser Class Initialized
INFO - 2023-12-11 05:11:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:11:08 --> Pagination Class Initialized
INFO - 2023-12-11 05:11:08 --> Form Validation Class Initialized
INFO - 2023-12-11 05:11:08 --> Controller Class Initialized
INFO - 2023-12-11 05:11:08 --> Model Class Initialized
DEBUG - 2023-12-11 05:11:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:11:08 --> Model Class Initialized
DEBUG - 2023-12-11 05:11:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:11:08 --> Model Class Initialized
INFO - 2023-12-11 05:11:08 --> Model Class Initialized
INFO - 2023-12-11 05:11:08 --> Model Class Initialized
INFO - 2023-12-11 05:11:08 --> Model Class Initialized
DEBUG - 2023-12-11 05:11:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-11 05:11:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:11:08 --> Model Class Initialized
INFO - 2023-12-11 05:11:08 --> Model Class Initialized
INFO - 2023-12-11 05:11:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-11 05:11:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:11:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-11 05:11:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-11 05:11:08 --> Model Class Initialized
INFO - 2023-12-11 05:11:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-11 05:11:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-11 05:11:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-11 05:11:08 --> Final output sent to browser
DEBUG - 2023-12-11 05:11:08 --> Total execution time: 0.3941
ERROR - 2023-12-11 05:16:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:16:33 --> Config Class Initialized
INFO - 2023-12-11 05:16:33 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:16:33 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:16:33 --> Utf8 Class Initialized
INFO - 2023-12-11 05:16:33 --> URI Class Initialized
INFO - 2023-12-11 05:16:33 --> Router Class Initialized
INFO - 2023-12-11 05:16:33 --> Output Class Initialized
INFO - 2023-12-11 05:16:33 --> Security Class Initialized
DEBUG - 2023-12-11 05:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:16:33 --> Input Class Initialized
INFO - 2023-12-11 05:16:33 --> Language Class Initialized
INFO - 2023-12-11 05:16:33 --> Loader Class Initialized
INFO - 2023-12-11 05:16:33 --> Helper loaded: url_helper
INFO - 2023-12-11 05:16:33 --> Helper loaded: file_helper
INFO - 2023-12-11 05:16:33 --> Helper loaded: html_helper
INFO - 2023-12-11 05:16:33 --> Helper loaded: text_helper
INFO - 2023-12-11 05:16:33 --> Helper loaded: form_helper
INFO - 2023-12-11 05:16:33 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:16:33 --> Helper loaded: security_helper
INFO - 2023-12-11 05:16:33 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:16:33 --> Database Driver Class Initialized
INFO - 2023-12-11 05:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:16:33 --> Parser Class Initialized
INFO - 2023-12-11 05:16:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:16:33 --> Pagination Class Initialized
INFO - 2023-12-11 05:16:33 --> Form Validation Class Initialized
INFO - 2023-12-11 05:16:33 --> Controller Class Initialized
INFO - 2023-12-11 05:16:33 --> Model Class Initialized
DEBUG - 2023-12-11 05:16:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:16:33 --> Model Class Initialized
INFO - 2023-12-11 05:16:33 --> Final output sent to browser
DEBUG - 2023-12-11 05:16:33 --> Total execution time: 0.0195
ERROR - 2023-12-11 05:16:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:16:33 --> Config Class Initialized
INFO - 2023-12-11 05:16:33 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:16:33 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:16:33 --> Utf8 Class Initialized
INFO - 2023-12-11 05:16:33 --> URI Class Initialized
DEBUG - 2023-12-11 05:16:33 --> No URI present. Default controller set.
INFO - 2023-12-11 05:16:33 --> Router Class Initialized
INFO - 2023-12-11 05:16:33 --> Output Class Initialized
INFO - 2023-12-11 05:16:33 --> Security Class Initialized
DEBUG - 2023-12-11 05:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:16:33 --> Input Class Initialized
INFO - 2023-12-11 05:16:33 --> Language Class Initialized
INFO - 2023-12-11 05:16:33 --> Loader Class Initialized
INFO - 2023-12-11 05:16:33 --> Helper loaded: url_helper
INFO - 2023-12-11 05:16:33 --> Helper loaded: file_helper
INFO - 2023-12-11 05:16:33 --> Helper loaded: html_helper
INFO - 2023-12-11 05:16:33 --> Helper loaded: text_helper
INFO - 2023-12-11 05:16:33 --> Helper loaded: form_helper
INFO - 2023-12-11 05:16:33 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:16:33 --> Helper loaded: security_helper
INFO - 2023-12-11 05:16:33 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:16:33 --> Database Driver Class Initialized
INFO - 2023-12-11 05:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:16:33 --> Parser Class Initialized
INFO - 2023-12-11 05:16:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:16:33 --> Pagination Class Initialized
INFO - 2023-12-11 05:16:33 --> Form Validation Class Initialized
INFO - 2023-12-11 05:16:33 --> Controller Class Initialized
INFO - 2023-12-11 05:16:33 --> Model Class Initialized
DEBUG - 2023-12-11 05:16:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:16:33 --> Model Class Initialized
DEBUG - 2023-12-11 05:16:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:16:33 --> Model Class Initialized
INFO - 2023-12-11 05:16:33 --> Model Class Initialized
INFO - 2023-12-11 05:16:33 --> Model Class Initialized
INFO - 2023-12-11 05:16:33 --> Model Class Initialized
DEBUG - 2023-12-11 05:16:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-11 05:16:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:16:33 --> Model Class Initialized
INFO - 2023-12-11 05:16:33 --> Model Class Initialized
INFO - 2023-12-11 05:16:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-11 05:16:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:16:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-11 05:16:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-11 05:16:33 --> Model Class Initialized
INFO - 2023-12-11 05:16:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-11 05:16:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-11 05:16:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-11 05:16:33 --> Final output sent to browser
DEBUG - 2023-12-11 05:16:33 --> Total execution time: 0.2164
ERROR - 2023-12-11 05:16:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:16:48 --> Config Class Initialized
INFO - 2023-12-11 05:16:48 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:16:48 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:16:48 --> Utf8 Class Initialized
INFO - 2023-12-11 05:16:48 --> URI Class Initialized
INFO - 2023-12-11 05:16:48 --> Router Class Initialized
INFO - 2023-12-11 05:16:48 --> Output Class Initialized
INFO - 2023-12-11 05:16:48 --> Security Class Initialized
DEBUG - 2023-12-11 05:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:16:48 --> Input Class Initialized
INFO - 2023-12-11 05:16:48 --> Language Class Initialized
INFO - 2023-12-11 05:16:48 --> Loader Class Initialized
INFO - 2023-12-11 05:16:48 --> Helper loaded: url_helper
INFO - 2023-12-11 05:16:48 --> Helper loaded: file_helper
INFO - 2023-12-11 05:16:48 --> Helper loaded: html_helper
INFO - 2023-12-11 05:16:48 --> Helper loaded: text_helper
INFO - 2023-12-11 05:16:48 --> Helper loaded: form_helper
INFO - 2023-12-11 05:16:48 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:16:48 --> Helper loaded: security_helper
INFO - 2023-12-11 05:16:48 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:16:48 --> Database Driver Class Initialized
INFO - 2023-12-11 05:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:16:48 --> Parser Class Initialized
INFO - 2023-12-11 05:16:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:16:48 --> Pagination Class Initialized
INFO - 2023-12-11 05:16:48 --> Form Validation Class Initialized
INFO - 2023-12-11 05:16:48 --> Controller Class Initialized
INFO - 2023-12-11 05:16:48 --> Model Class Initialized
DEBUG - 2023-12-11 05:16:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-11 05:16:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:16:48 --> Model Class Initialized
DEBUG - 2023-12-11 05:16:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:16:48 --> Model Class Initialized
INFO - 2023-12-11 05:16:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-11 05:16:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:16:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-11 05:16:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-11 05:16:48 --> Model Class Initialized
INFO - 2023-12-11 05:16:48 --> Model Class Initialized
INFO - 2023-12-11 05:16:48 --> Model Class Initialized
INFO - 2023-12-11 05:16:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-11 05:16:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-11 05:16:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-11 05:16:48 --> Final output sent to browser
DEBUG - 2023-12-11 05:16:48 --> Total execution time: 0.1477
ERROR - 2023-12-11 05:16:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:16:49 --> Config Class Initialized
INFO - 2023-12-11 05:16:49 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:16:49 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:16:49 --> Utf8 Class Initialized
INFO - 2023-12-11 05:16:49 --> URI Class Initialized
INFO - 2023-12-11 05:16:49 --> Router Class Initialized
INFO - 2023-12-11 05:16:49 --> Output Class Initialized
INFO - 2023-12-11 05:16:49 --> Security Class Initialized
DEBUG - 2023-12-11 05:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:16:49 --> Input Class Initialized
INFO - 2023-12-11 05:16:49 --> Language Class Initialized
INFO - 2023-12-11 05:16:49 --> Loader Class Initialized
INFO - 2023-12-11 05:16:49 --> Helper loaded: url_helper
INFO - 2023-12-11 05:16:49 --> Helper loaded: file_helper
INFO - 2023-12-11 05:16:49 --> Helper loaded: html_helper
INFO - 2023-12-11 05:16:49 --> Helper loaded: text_helper
INFO - 2023-12-11 05:16:49 --> Helper loaded: form_helper
INFO - 2023-12-11 05:16:49 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:16:49 --> Helper loaded: security_helper
INFO - 2023-12-11 05:16:49 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:16:49 --> Database Driver Class Initialized
INFO - 2023-12-11 05:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:16:49 --> Parser Class Initialized
INFO - 2023-12-11 05:16:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:16:49 --> Pagination Class Initialized
INFO - 2023-12-11 05:16:49 --> Form Validation Class Initialized
INFO - 2023-12-11 05:16:49 --> Controller Class Initialized
INFO - 2023-12-11 05:16:49 --> Model Class Initialized
DEBUG - 2023-12-11 05:16:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-11 05:16:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:16:49 --> Model Class Initialized
DEBUG - 2023-12-11 05:16:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:16:49 --> Model Class Initialized
INFO - 2023-12-11 05:16:49 --> Final output sent to browser
DEBUG - 2023-12-11 05:16:49 --> Total execution time: 0.0401
ERROR - 2023-12-11 05:16:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:16:54 --> Config Class Initialized
INFO - 2023-12-11 05:16:54 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:16:54 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:16:54 --> Utf8 Class Initialized
INFO - 2023-12-11 05:16:54 --> URI Class Initialized
INFO - 2023-12-11 05:16:54 --> Router Class Initialized
INFO - 2023-12-11 05:16:54 --> Output Class Initialized
INFO - 2023-12-11 05:16:54 --> Security Class Initialized
DEBUG - 2023-12-11 05:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:16:54 --> Input Class Initialized
INFO - 2023-12-11 05:16:54 --> Language Class Initialized
INFO - 2023-12-11 05:16:54 --> Loader Class Initialized
INFO - 2023-12-11 05:16:54 --> Helper loaded: url_helper
INFO - 2023-12-11 05:16:54 --> Helper loaded: file_helper
INFO - 2023-12-11 05:16:54 --> Helper loaded: html_helper
INFO - 2023-12-11 05:16:54 --> Helper loaded: text_helper
INFO - 2023-12-11 05:16:54 --> Helper loaded: form_helper
INFO - 2023-12-11 05:16:54 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:16:54 --> Helper loaded: security_helper
INFO - 2023-12-11 05:16:54 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:16:54 --> Database Driver Class Initialized
INFO - 2023-12-11 05:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:16:54 --> Parser Class Initialized
INFO - 2023-12-11 05:16:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:16:54 --> Pagination Class Initialized
INFO - 2023-12-11 05:16:54 --> Form Validation Class Initialized
INFO - 2023-12-11 05:16:54 --> Controller Class Initialized
INFO - 2023-12-11 05:16:54 --> Model Class Initialized
DEBUG - 2023-12-11 05:16:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-11 05:16:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:16:54 --> Model Class Initialized
DEBUG - 2023-12-11 05:16:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:16:54 --> Model Class Initialized
INFO - 2023-12-11 05:16:54 --> Final output sent to browser
DEBUG - 2023-12-11 05:16:54 --> Total execution time: 0.0680
ERROR - 2023-12-11 05:17:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:17:08 --> Config Class Initialized
INFO - 2023-12-11 05:17:08 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:17:08 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:17:08 --> Utf8 Class Initialized
INFO - 2023-12-11 05:17:08 --> URI Class Initialized
DEBUG - 2023-12-11 05:17:08 --> No URI present. Default controller set.
INFO - 2023-12-11 05:17:08 --> Router Class Initialized
INFO - 2023-12-11 05:17:08 --> Output Class Initialized
INFO - 2023-12-11 05:17:08 --> Security Class Initialized
DEBUG - 2023-12-11 05:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:17:08 --> Input Class Initialized
INFO - 2023-12-11 05:17:08 --> Language Class Initialized
INFO - 2023-12-11 05:17:08 --> Loader Class Initialized
INFO - 2023-12-11 05:17:08 --> Helper loaded: url_helper
INFO - 2023-12-11 05:17:08 --> Helper loaded: file_helper
INFO - 2023-12-11 05:17:08 --> Helper loaded: html_helper
INFO - 2023-12-11 05:17:08 --> Helper loaded: text_helper
INFO - 2023-12-11 05:17:08 --> Helper loaded: form_helper
INFO - 2023-12-11 05:17:08 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:17:08 --> Helper loaded: security_helper
INFO - 2023-12-11 05:17:08 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:17:08 --> Database Driver Class Initialized
INFO - 2023-12-11 05:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:17:08 --> Parser Class Initialized
INFO - 2023-12-11 05:17:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:17:08 --> Pagination Class Initialized
INFO - 2023-12-11 05:17:08 --> Form Validation Class Initialized
INFO - 2023-12-11 05:17:08 --> Controller Class Initialized
INFO - 2023-12-11 05:17:08 --> Model Class Initialized
DEBUG - 2023-12-11 05:17:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:17:08 --> Model Class Initialized
DEBUG - 2023-12-11 05:17:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:17:08 --> Model Class Initialized
INFO - 2023-12-11 05:17:08 --> Model Class Initialized
INFO - 2023-12-11 05:17:08 --> Model Class Initialized
INFO - 2023-12-11 05:17:08 --> Model Class Initialized
DEBUG - 2023-12-11 05:17:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-11 05:17:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:17:08 --> Model Class Initialized
INFO - 2023-12-11 05:17:08 --> Model Class Initialized
INFO - 2023-12-11 05:17:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-11 05:17:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:17:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-11 05:17:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-11 05:17:09 --> Model Class Initialized
INFO - 2023-12-11 05:17:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-11 05:17:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-11 05:17:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-11 05:17:09 --> Final output sent to browser
DEBUG - 2023-12-11 05:17:09 --> Total execution time: 0.2208
ERROR - 2023-12-11 05:17:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:17:20 --> Config Class Initialized
INFO - 2023-12-11 05:17:20 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:17:20 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:17:20 --> Utf8 Class Initialized
INFO - 2023-12-11 05:17:20 --> URI Class Initialized
INFO - 2023-12-11 05:17:20 --> Router Class Initialized
INFO - 2023-12-11 05:17:20 --> Output Class Initialized
INFO - 2023-12-11 05:17:20 --> Security Class Initialized
DEBUG - 2023-12-11 05:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:17:20 --> Input Class Initialized
INFO - 2023-12-11 05:17:20 --> Language Class Initialized
INFO - 2023-12-11 05:17:20 --> Loader Class Initialized
INFO - 2023-12-11 05:17:20 --> Helper loaded: url_helper
INFO - 2023-12-11 05:17:20 --> Helper loaded: file_helper
INFO - 2023-12-11 05:17:20 --> Helper loaded: html_helper
INFO - 2023-12-11 05:17:20 --> Helper loaded: text_helper
INFO - 2023-12-11 05:17:20 --> Helper loaded: form_helper
INFO - 2023-12-11 05:17:20 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:17:20 --> Helper loaded: security_helper
INFO - 2023-12-11 05:17:20 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:17:20 --> Database Driver Class Initialized
INFO - 2023-12-11 05:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:17:20 --> Parser Class Initialized
INFO - 2023-12-11 05:17:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:17:20 --> Pagination Class Initialized
INFO - 2023-12-11 05:17:20 --> Form Validation Class Initialized
INFO - 2023-12-11 05:17:20 --> Controller Class Initialized
INFO - 2023-12-11 05:17:20 --> Model Class Initialized
DEBUG - 2023-12-11 05:17:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-11 05:17:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:17:21 --> Model Class Initialized
DEBUG - 2023-12-11 05:17:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:17:21 --> Model Class Initialized
INFO - 2023-12-11 05:17:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-11 05:17:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:17:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-11 05:17:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-11 05:17:21 --> Model Class Initialized
INFO - 2023-12-11 05:17:21 --> Model Class Initialized
INFO - 2023-12-11 05:17:21 --> Model Class Initialized
INFO - 2023-12-11 05:17:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-11 05:17:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-11 05:17:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-11 05:17:21 --> Final output sent to browser
DEBUG - 2023-12-11 05:17:21 --> Total execution time: 0.1496
ERROR - 2023-12-11 05:17:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:17:21 --> Config Class Initialized
INFO - 2023-12-11 05:17:21 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:17:21 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:17:21 --> Utf8 Class Initialized
INFO - 2023-12-11 05:17:21 --> URI Class Initialized
INFO - 2023-12-11 05:17:21 --> Router Class Initialized
INFO - 2023-12-11 05:17:21 --> Output Class Initialized
INFO - 2023-12-11 05:17:21 --> Security Class Initialized
DEBUG - 2023-12-11 05:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:17:21 --> Input Class Initialized
INFO - 2023-12-11 05:17:21 --> Language Class Initialized
INFO - 2023-12-11 05:17:21 --> Loader Class Initialized
INFO - 2023-12-11 05:17:21 --> Helper loaded: url_helper
INFO - 2023-12-11 05:17:21 --> Helper loaded: file_helper
INFO - 2023-12-11 05:17:21 --> Helper loaded: html_helper
INFO - 2023-12-11 05:17:21 --> Helper loaded: text_helper
INFO - 2023-12-11 05:17:21 --> Helper loaded: form_helper
INFO - 2023-12-11 05:17:21 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:17:21 --> Helper loaded: security_helper
INFO - 2023-12-11 05:17:21 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:17:21 --> Database Driver Class Initialized
INFO - 2023-12-11 05:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:17:21 --> Parser Class Initialized
INFO - 2023-12-11 05:17:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:17:21 --> Pagination Class Initialized
INFO - 2023-12-11 05:17:21 --> Form Validation Class Initialized
INFO - 2023-12-11 05:17:21 --> Controller Class Initialized
INFO - 2023-12-11 05:17:21 --> Model Class Initialized
DEBUG - 2023-12-11 05:17:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-11 05:17:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:17:21 --> Model Class Initialized
DEBUG - 2023-12-11 05:17:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:17:21 --> Model Class Initialized
INFO - 2023-12-11 05:17:21 --> Final output sent to browser
DEBUG - 2023-12-11 05:17:21 --> Total execution time: 0.0377
ERROR - 2023-12-11 05:17:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:17:28 --> Config Class Initialized
INFO - 2023-12-11 05:17:28 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:17:28 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:17:28 --> Utf8 Class Initialized
INFO - 2023-12-11 05:17:28 --> URI Class Initialized
INFO - 2023-12-11 05:17:28 --> Router Class Initialized
INFO - 2023-12-11 05:17:28 --> Output Class Initialized
INFO - 2023-12-11 05:17:28 --> Security Class Initialized
DEBUG - 2023-12-11 05:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:17:28 --> Input Class Initialized
INFO - 2023-12-11 05:17:28 --> Language Class Initialized
INFO - 2023-12-11 05:17:28 --> Loader Class Initialized
INFO - 2023-12-11 05:17:28 --> Helper loaded: url_helper
INFO - 2023-12-11 05:17:28 --> Helper loaded: file_helper
INFO - 2023-12-11 05:17:28 --> Helper loaded: html_helper
INFO - 2023-12-11 05:17:28 --> Helper loaded: text_helper
INFO - 2023-12-11 05:17:28 --> Helper loaded: form_helper
INFO - 2023-12-11 05:17:28 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:17:28 --> Helper loaded: security_helper
INFO - 2023-12-11 05:17:28 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:17:28 --> Database Driver Class Initialized
INFO - 2023-12-11 05:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:17:28 --> Parser Class Initialized
INFO - 2023-12-11 05:17:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:17:28 --> Pagination Class Initialized
INFO - 2023-12-11 05:17:28 --> Form Validation Class Initialized
INFO - 2023-12-11 05:17:28 --> Controller Class Initialized
INFO - 2023-12-11 05:17:28 --> Model Class Initialized
DEBUG - 2023-12-11 05:17:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-11 05:17:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:17:28 --> Model Class Initialized
DEBUG - 2023-12-11 05:17:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:17:28 --> Model Class Initialized
INFO - 2023-12-11 05:17:28 --> Final output sent to browser
DEBUG - 2023-12-11 05:17:28 --> Total execution time: 0.0654
ERROR - 2023-12-11 05:32:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:32:10 --> Config Class Initialized
INFO - 2023-12-11 05:32:10 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:32:10 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:32:10 --> Utf8 Class Initialized
INFO - 2023-12-11 05:32:10 --> URI Class Initialized
INFO - 2023-12-11 05:32:10 --> Router Class Initialized
INFO - 2023-12-11 05:32:10 --> Output Class Initialized
INFO - 2023-12-11 05:32:10 --> Security Class Initialized
DEBUG - 2023-12-11 05:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:32:10 --> Input Class Initialized
INFO - 2023-12-11 05:32:10 --> Language Class Initialized
INFO - 2023-12-11 05:32:10 --> Loader Class Initialized
INFO - 2023-12-11 05:32:10 --> Helper loaded: url_helper
INFO - 2023-12-11 05:32:10 --> Helper loaded: file_helper
INFO - 2023-12-11 05:32:10 --> Helper loaded: html_helper
INFO - 2023-12-11 05:32:10 --> Helper loaded: text_helper
INFO - 2023-12-11 05:32:10 --> Helper loaded: form_helper
INFO - 2023-12-11 05:32:10 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:32:10 --> Helper loaded: security_helper
INFO - 2023-12-11 05:32:10 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:32:10 --> Database Driver Class Initialized
INFO - 2023-12-11 05:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:32:10 --> Parser Class Initialized
INFO - 2023-12-11 05:32:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:32:10 --> Pagination Class Initialized
INFO - 2023-12-11 05:32:10 --> Form Validation Class Initialized
INFO - 2023-12-11 05:32:10 --> Controller Class Initialized
INFO - 2023-12-11 05:32:10 --> Model Class Initialized
DEBUG - 2023-12-11 05:32:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-11 05:32:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:32:10 --> Model Class Initialized
DEBUG - 2023-12-11 05:32:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:32:10 --> Model Class Initialized
INFO - 2023-12-11 05:32:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-11 05:32:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:32:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-11 05:32:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-11 05:32:10 --> Model Class Initialized
INFO - 2023-12-11 05:32:10 --> Model Class Initialized
INFO - 2023-12-11 05:32:10 --> Model Class Initialized
INFO - 2023-12-11 05:32:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-11 05:32:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-11 05:32:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-11 05:32:10 --> Final output sent to browser
DEBUG - 2023-12-11 05:32:10 --> Total execution time: 0.2025
ERROR - 2023-12-11 05:32:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:32:11 --> Config Class Initialized
INFO - 2023-12-11 05:32:11 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:32:11 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:32:11 --> Utf8 Class Initialized
INFO - 2023-12-11 05:32:11 --> URI Class Initialized
INFO - 2023-12-11 05:32:11 --> Router Class Initialized
INFO - 2023-12-11 05:32:11 --> Output Class Initialized
INFO - 2023-12-11 05:32:11 --> Security Class Initialized
DEBUG - 2023-12-11 05:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:32:11 --> Input Class Initialized
INFO - 2023-12-11 05:32:11 --> Language Class Initialized
INFO - 2023-12-11 05:32:11 --> Loader Class Initialized
INFO - 2023-12-11 05:32:11 --> Helper loaded: url_helper
INFO - 2023-12-11 05:32:11 --> Helper loaded: file_helper
INFO - 2023-12-11 05:32:11 --> Helper loaded: html_helper
INFO - 2023-12-11 05:32:11 --> Helper loaded: text_helper
INFO - 2023-12-11 05:32:11 --> Helper loaded: form_helper
INFO - 2023-12-11 05:32:11 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:32:11 --> Helper loaded: security_helper
INFO - 2023-12-11 05:32:11 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:32:11 --> Database Driver Class Initialized
INFO - 2023-12-11 05:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:32:11 --> Parser Class Initialized
INFO - 2023-12-11 05:32:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:32:11 --> Pagination Class Initialized
INFO - 2023-12-11 05:32:11 --> Form Validation Class Initialized
INFO - 2023-12-11 05:32:11 --> Controller Class Initialized
INFO - 2023-12-11 05:32:11 --> Model Class Initialized
DEBUG - 2023-12-11 05:32:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-11 05:32:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:32:11 --> Model Class Initialized
DEBUG - 2023-12-11 05:32:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:32:11 --> Model Class Initialized
INFO - 2023-12-11 05:32:11 --> Final output sent to browser
DEBUG - 2023-12-11 05:32:11 --> Total execution time: 0.0589
ERROR - 2023-12-11 05:37:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:37:58 --> Config Class Initialized
INFO - 2023-12-11 05:37:58 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:37:58 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:37:58 --> Utf8 Class Initialized
INFO - 2023-12-11 05:37:58 --> URI Class Initialized
INFO - 2023-12-11 05:37:58 --> Router Class Initialized
INFO - 2023-12-11 05:37:58 --> Output Class Initialized
INFO - 2023-12-11 05:37:58 --> Security Class Initialized
DEBUG - 2023-12-11 05:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:37:58 --> Input Class Initialized
INFO - 2023-12-11 05:37:58 --> Language Class Initialized
INFO - 2023-12-11 05:37:58 --> Loader Class Initialized
INFO - 2023-12-11 05:37:58 --> Helper loaded: url_helper
INFO - 2023-12-11 05:37:58 --> Helper loaded: file_helper
INFO - 2023-12-11 05:37:58 --> Helper loaded: html_helper
INFO - 2023-12-11 05:37:58 --> Helper loaded: text_helper
INFO - 2023-12-11 05:37:58 --> Helper loaded: form_helper
INFO - 2023-12-11 05:37:58 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:37:58 --> Helper loaded: security_helper
INFO - 2023-12-11 05:37:58 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:37:58 --> Database Driver Class Initialized
INFO - 2023-12-11 05:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:37:58 --> Parser Class Initialized
INFO - 2023-12-11 05:37:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:37:58 --> Pagination Class Initialized
INFO - 2023-12-11 05:37:58 --> Form Validation Class Initialized
INFO - 2023-12-11 05:37:58 --> Controller Class Initialized
INFO - 2023-12-11 05:37:58 --> Model Class Initialized
DEBUG - 2023-12-11 05:37:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-11 05:37:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:37:58 --> Model Class Initialized
DEBUG - 2023-12-11 05:37:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:37:58 --> Model Class Initialized
INFO - 2023-12-11 05:37:59 --> Final output sent to browser
DEBUG - 2023-12-11 05:37:59 --> Total execution time: 1.0442
ERROR - 2023-12-11 05:40:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:40:13 --> Config Class Initialized
INFO - 2023-12-11 05:40:13 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:40:13 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:40:13 --> Utf8 Class Initialized
INFO - 2023-12-11 05:40:13 --> URI Class Initialized
DEBUG - 2023-12-11 05:40:13 --> No URI present. Default controller set.
INFO - 2023-12-11 05:40:13 --> Router Class Initialized
INFO - 2023-12-11 05:40:13 --> Output Class Initialized
INFO - 2023-12-11 05:40:13 --> Security Class Initialized
DEBUG - 2023-12-11 05:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:40:13 --> Input Class Initialized
INFO - 2023-12-11 05:40:13 --> Language Class Initialized
INFO - 2023-12-11 05:40:13 --> Loader Class Initialized
INFO - 2023-12-11 05:40:13 --> Helper loaded: url_helper
INFO - 2023-12-11 05:40:13 --> Helper loaded: file_helper
INFO - 2023-12-11 05:40:13 --> Helper loaded: html_helper
INFO - 2023-12-11 05:40:13 --> Helper loaded: text_helper
INFO - 2023-12-11 05:40:13 --> Helper loaded: form_helper
INFO - 2023-12-11 05:40:13 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:40:13 --> Helper loaded: security_helper
INFO - 2023-12-11 05:40:13 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:40:13 --> Database Driver Class Initialized
INFO - 2023-12-11 05:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:40:13 --> Parser Class Initialized
INFO - 2023-12-11 05:40:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:40:13 --> Pagination Class Initialized
INFO - 2023-12-11 05:40:13 --> Form Validation Class Initialized
INFO - 2023-12-11 05:40:13 --> Controller Class Initialized
INFO - 2023-12-11 05:40:13 --> Model Class Initialized
DEBUG - 2023-12-11 05:40:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:40:13 --> Model Class Initialized
DEBUG - 2023-12-11 05:40:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:40:13 --> Model Class Initialized
INFO - 2023-12-11 05:40:13 --> Model Class Initialized
INFO - 2023-12-11 05:40:13 --> Model Class Initialized
INFO - 2023-12-11 05:40:13 --> Model Class Initialized
DEBUG - 2023-12-11 05:40:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-11 05:40:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:40:13 --> Model Class Initialized
INFO - 2023-12-11 05:40:13 --> Model Class Initialized
INFO - 2023-12-11 05:40:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-11 05:40:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:40:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-11 05:40:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-11 05:40:13 --> Model Class Initialized
INFO - 2023-12-11 05:40:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-11 05:40:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-11 05:40:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-11 05:40:13 --> Final output sent to browser
DEBUG - 2023-12-11 05:40:13 --> Total execution time: 0.3691
ERROR - 2023-12-11 05:42:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:42:50 --> Config Class Initialized
INFO - 2023-12-11 05:42:50 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:42:50 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:42:50 --> Utf8 Class Initialized
INFO - 2023-12-11 05:42:50 --> URI Class Initialized
INFO - 2023-12-11 05:42:50 --> Router Class Initialized
INFO - 2023-12-11 05:42:50 --> Output Class Initialized
INFO - 2023-12-11 05:42:50 --> Security Class Initialized
DEBUG - 2023-12-11 05:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:42:50 --> Input Class Initialized
INFO - 2023-12-11 05:42:50 --> Language Class Initialized
INFO - 2023-12-11 05:42:50 --> Loader Class Initialized
INFO - 2023-12-11 05:42:50 --> Helper loaded: url_helper
INFO - 2023-12-11 05:42:50 --> Helper loaded: file_helper
INFO - 2023-12-11 05:42:50 --> Helper loaded: html_helper
INFO - 2023-12-11 05:42:50 --> Helper loaded: text_helper
INFO - 2023-12-11 05:42:50 --> Helper loaded: form_helper
INFO - 2023-12-11 05:42:50 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:42:50 --> Helper loaded: security_helper
INFO - 2023-12-11 05:42:50 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:42:50 --> Database Driver Class Initialized
INFO - 2023-12-11 05:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:42:50 --> Parser Class Initialized
INFO - 2023-12-11 05:42:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:42:50 --> Pagination Class Initialized
INFO - 2023-12-11 05:42:50 --> Form Validation Class Initialized
INFO - 2023-12-11 05:42:50 --> Controller Class Initialized
INFO - 2023-12-11 05:42:50 --> Model Class Initialized
DEBUG - 2023-12-11 05:42:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-11 05:42:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:42:50 --> Model Class Initialized
DEBUG - 2023-12-11 05:42:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:42:50 --> Model Class Initialized
INFO - 2023-12-11 05:42:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-12-11 05:42:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:42:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-11 05:42:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-11 05:42:50 --> Model Class Initialized
INFO - 2023-12-11 05:42:50 --> Model Class Initialized
INFO - 2023-12-11 05:42:50 --> Model Class Initialized
INFO - 2023-12-11 05:42:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-11 05:42:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-11 05:42:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-11 05:42:50 --> Final output sent to browser
DEBUG - 2023-12-11 05:42:50 --> Total execution time: 0.2417
ERROR - 2023-12-11 05:42:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:42:51 --> Config Class Initialized
INFO - 2023-12-11 05:42:51 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:42:51 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:42:51 --> Utf8 Class Initialized
INFO - 2023-12-11 05:42:51 --> URI Class Initialized
INFO - 2023-12-11 05:42:51 --> Router Class Initialized
INFO - 2023-12-11 05:42:51 --> Output Class Initialized
INFO - 2023-12-11 05:42:51 --> Security Class Initialized
DEBUG - 2023-12-11 05:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:42:51 --> Input Class Initialized
INFO - 2023-12-11 05:42:51 --> Language Class Initialized
INFO - 2023-12-11 05:42:51 --> Loader Class Initialized
INFO - 2023-12-11 05:42:51 --> Helper loaded: url_helper
INFO - 2023-12-11 05:42:51 --> Helper loaded: file_helper
INFO - 2023-12-11 05:42:51 --> Helper loaded: html_helper
INFO - 2023-12-11 05:42:51 --> Helper loaded: text_helper
INFO - 2023-12-11 05:42:51 --> Helper loaded: form_helper
INFO - 2023-12-11 05:42:51 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:42:51 --> Helper loaded: security_helper
INFO - 2023-12-11 05:42:51 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:42:51 --> Database Driver Class Initialized
INFO - 2023-12-11 05:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:42:51 --> Parser Class Initialized
INFO - 2023-12-11 05:42:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:42:51 --> Pagination Class Initialized
INFO - 2023-12-11 05:42:51 --> Form Validation Class Initialized
INFO - 2023-12-11 05:42:51 --> Controller Class Initialized
INFO - 2023-12-11 05:42:51 --> Model Class Initialized
DEBUG - 2023-12-11 05:42:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-11 05:42:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:42:51 --> Model Class Initialized
DEBUG - 2023-12-11 05:42:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:42:51 --> Model Class Initialized
INFO - 2023-12-11 05:42:51 --> Final output sent to browser
DEBUG - 2023-12-11 05:42:51 --> Total execution time: 0.0565
ERROR - 2023-12-11 05:43:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:43:00 --> Config Class Initialized
INFO - 2023-12-11 05:43:00 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:43:00 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:43:00 --> Utf8 Class Initialized
INFO - 2023-12-11 05:43:00 --> URI Class Initialized
INFO - 2023-12-11 05:43:00 --> Router Class Initialized
INFO - 2023-12-11 05:43:00 --> Output Class Initialized
INFO - 2023-12-11 05:43:00 --> Security Class Initialized
DEBUG - 2023-12-11 05:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:43:00 --> Input Class Initialized
INFO - 2023-12-11 05:43:00 --> Language Class Initialized
INFO - 2023-12-11 05:43:00 --> Loader Class Initialized
INFO - 2023-12-11 05:43:00 --> Helper loaded: url_helper
INFO - 2023-12-11 05:43:00 --> Helper loaded: file_helper
INFO - 2023-12-11 05:43:00 --> Helper loaded: html_helper
INFO - 2023-12-11 05:43:00 --> Helper loaded: text_helper
INFO - 2023-12-11 05:43:00 --> Helper loaded: form_helper
INFO - 2023-12-11 05:43:00 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:43:00 --> Helper loaded: security_helper
INFO - 2023-12-11 05:43:00 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:43:00 --> Database Driver Class Initialized
INFO - 2023-12-11 05:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:43:00 --> Parser Class Initialized
INFO - 2023-12-11 05:43:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:43:00 --> Pagination Class Initialized
INFO - 2023-12-11 05:43:00 --> Form Validation Class Initialized
INFO - 2023-12-11 05:43:00 --> Controller Class Initialized
INFO - 2023-12-11 05:43:00 --> Model Class Initialized
DEBUG - 2023-12-11 05:43:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-11 05:43:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:43:00 --> Model Class Initialized
DEBUG - 2023-12-11 05:43:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:43:00 --> Model Class Initialized
INFO - 2023-12-11 05:43:00 --> Final output sent to browser
DEBUG - 2023-12-11 05:43:00 --> Total execution time: 0.1546
ERROR - 2023-12-11 05:43:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:43:11 --> Config Class Initialized
INFO - 2023-12-11 05:43:11 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:43:11 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:43:11 --> Utf8 Class Initialized
INFO - 2023-12-11 05:43:11 --> URI Class Initialized
INFO - 2023-12-11 05:43:11 --> Router Class Initialized
INFO - 2023-12-11 05:43:11 --> Output Class Initialized
INFO - 2023-12-11 05:43:11 --> Security Class Initialized
DEBUG - 2023-12-11 05:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:43:11 --> Input Class Initialized
INFO - 2023-12-11 05:43:11 --> Language Class Initialized
INFO - 2023-12-11 05:43:11 --> Loader Class Initialized
INFO - 2023-12-11 05:43:11 --> Helper loaded: url_helper
INFO - 2023-12-11 05:43:11 --> Helper loaded: file_helper
INFO - 2023-12-11 05:43:11 --> Helper loaded: html_helper
INFO - 2023-12-11 05:43:11 --> Helper loaded: text_helper
INFO - 2023-12-11 05:43:11 --> Helper loaded: form_helper
INFO - 2023-12-11 05:43:11 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:43:11 --> Helper loaded: security_helper
INFO - 2023-12-11 05:43:11 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:43:11 --> Database Driver Class Initialized
INFO - 2023-12-11 05:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:43:11 --> Parser Class Initialized
INFO - 2023-12-11 05:43:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:43:11 --> Pagination Class Initialized
INFO - 2023-12-11 05:43:11 --> Form Validation Class Initialized
INFO - 2023-12-11 05:43:11 --> Controller Class Initialized
INFO - 2023-12-11 05:43:11 --> Model Class Initialized
DEBUG - 2023-12-11 05:43:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-11 05:43:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:43:11 --> Model Class Initialized
DEBUG - 2023-12-11 05:43:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:43:11 --> Model Class Initialized
INFO - 2023-12-11 05:43:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-11 05:43:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:43:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-11 05:43:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-11 05:43:11 --> Model Class Initialized
INFO - 2023-12-11 05:43:11 --> Model Class Initialized
INFO - 2023-12-11 05:43:11 --> Model Class Initialized
INFO - 2023-12-11 05:43:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-11 05:43:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-11 05:43:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-11 05:43:11 --> Final output sent to browser
DEBUG - 2023-12-11 05:43:11 --> Total execution time: 0.2264
ERROR - 2023-12-11 05:43:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:43:12 --> Config Class Initialized
INFO - 2023-12-11 05:43:12 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:43:12 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:43:12 --> Utf8 Class Initialized
INFO - 2023-12-11 05:43:12 --> URI Class Initialized
INFO - 2023-12-11 05:43:12 --> Router Class Initialized
INFO - 2023-12-11 05:43:12 --> Output Class Initialized
INFO - 2023-12-11 05:43:12 --> Security Class Initialized
DEBUG - 2023-12-11 05:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:43:12 --> Input Class Initialized
INFO - 2023-12-11 05:43:12 --> Language Class Initialized
INFO - 2023-12-11 05:43:12 --> Loader Class Initialized
INFO - 2023-12-11 05:43:12 --> Helper loaded: url_helper
INFO - 2023-12-11 05:43:12 --> Helper loaded: file_helper
INFO - 2023-12-11 05:43:12 --> Helper loaded: html_helper
INFO - 2023-12-11 05:43:12 --> Helper loaded: text_helper
INFO - 2023-12-11 05:43:12 --> Helper loaded: form_helper
INFO - 2023-12-11 05:43:12 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:43:12 --> Helper loaded: security_helper
INFO - 2023-12-11 05:43:12 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:43:12 --> Database Driver Class Initialized
INFO - 2023-12-11 05:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:43:12 --> Parser Class Initialized
INFO - 2023-12-11 05:43:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:43:12 --> Pagination Class Initialized
INFO - 2023-12-11 05:43:12 --> Form Validation Class Initialized
INFO - 2023-12-11 05:43:12 --> Controller Class Initialized
INFO - 2023-12-11 05:43:12 --> Model Class Initialized
DEBUG - 2023-12-11 05:43:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-11 05:43:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:43:12 --> Model Class Initialized
DEBUG - 2023-12-11 05:43:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:43:12 --> Model Class Initialized
INFO - 2023-12-11 05:43:12 --> Final output sent to browser
DEBUG - 2023-12-11 05:43:12 --> Total execution time: 0.0622
ERROR - 2023-12-11 05:43:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:43:25 --> Config Class Initialized
INFO - 2023-12-11 05:43:25 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:43:25 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:43:25 --> Utf8 Class Initialized
INFO - 2023-12-11 05:43:25 --> URI Class Initialized
INFO - 2023-12-11 05:43:25 --> Router Class Initialized
INFO - 2023-12-11 05:43:25 --> Output Class Initialized
INFO - 2023-12-11 05:43:25 --> Security Class Initialized
DEBUG - 2023-12-11 05:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:43:25 --> Input Class Initialized
INFO - 2023-12-11 05:43:25 --> Language Class Initialized
INFO - 2023-12-11 05:43:25 --> Loader Class Initialized
INFO - 2023-12-11 05:43:25 --> Helper loaded: url_helper
INFO - 2023-12-11 05:43:25 --> Helper loaded: file_helper
INFO - 2023-12-11 05:43:25 --> Helper loaded: html_helper
INFO - 2023-12-11 05:43:25 --> Helper loaded: text_helper
INFO - 2023-12-11 05:43:25 --> Helper loaded: form_helper
INFO - 2023-12-11 05:43:25 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:43:25 --> Helper loaded: security_helper
INFO - 2023-12-11 05:43:25 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:43:25 --> Database Driver Class Initialized
INFO - 2023-12-11 05:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:43:25 --> Parser Class Initialized
INFO - 2023-12-11 05:43:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:43:25 --> Pagination Class Initialized
INFO - 2023-12-11 05:43:25 --> Form Validation Class Initialized
INFO - 2023-12-11 05:43:25 --> Controller Class Initialized
INFO - 2023-12-11 05:43:25 --> Model Class Initialized
DEBUG - 2023-12-11 05:43:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-11 05:43:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:43:25 --> Model Class Initialized
DEBUG - 2023-12-11 05:43:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:43:25 --> Model Class Initialized
INFO - 2023-12-11 05:43:25 --> Email Class Initialized
INFO - 2023-12-11 05:43:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html_pdf.php
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/frame_reflower.cls.php 210
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/frame_reflower.cls.php 211
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/block_frame_reflower.cls.php 726
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/inline_renderer.cls.php 138
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/inline_renderer.cls.php 138
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-11 05:43:25 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2023-12-11 05:43:26 --> Language file loaded: language/english/email_lang.php
INFO - 2023-12-11 05:43:26 --> Final output sent to browser
DEBUG - 2023-12-11 05:43:26 --> Total execution time: 0.5255
ERROR - 2023-12-11 05:43:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:43:26 --> Config Class Initialized
INFO - 2023-12-11 05:43:26 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:43:26 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:43:26 --> Utf8 Class Initialized
INFO - 2023-12-11 05:43:26 --> URI Class Initialized
INFO - 2023-12-11 05:43:26 --> Router Class Initialized
INFO - 2023-12-11 05:43:26 --> Output Class Initialized
INFO - 2023-12-11 05:43:26 --> Security Class Initialized
DEBUG - 2023-12-11 05:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:43:26 --> Input Class Initialized
INFO - 2023-12-11 05:43:26 --> Language Class Initialized
INFO - 2023-12-11 05:43:26 --> Loader Class Initialized
INFO - 2023-12-11 05:43:26 --> Helper loaded: url_helper
INFO - 2023-12-11 05:43:26 --> Helper loaded: file_helper
INFO - 2023-12-11 05:43:26 --> Helper loaded: html_helper
INFO - 2023-12-11 05:43:26 --> Helper loaded: text_helper
INFO - 2023-12-11 05:43:26 --> Helper loaded: form_helper
INFO - 2023-12-11 05:43:26 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:43:26 --> Helper loaded: security_helper
INFO - 2023-12-11 05:43:26 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:43:26 --> Database Driver Class Initialized
INFO - 2023-12-11 05:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:43:26 --> Parser Class Initialized
INFO - 2023-12-11 05:43:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:43:26 --> Pagination Class Initialized
INFO - 2023-12-11 05:43:26 --> Form Validation Class Initialized
INFO - 2023-12-11 05:43:26 --> Controller Class Initialized
INFO - 2023-12-11 05:43:26 --> Model Class Initialized
DEBUG - 2023-12-11 05:43:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-11 05:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:43:26 --> Model Class Initialized
DEBUG - 2023-12-11 05:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:43:26 --> Model Class Initialized
INFO - 2023-12-11 05:43:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html.php
DEBUG - 2023-12-11 05:43:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:43:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-11 05:43:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-11 05:43:26 --> Model Class Initialized
INFO - 2023-12-11 05:43:26 --> Model Class Initialized
INFO - 2023-12-11 05:43:26 --> Model Class Initialized
INFO - 2023-12-11 05:43:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-11 05:43:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-11 05:43:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-11 05:43:26 --> Final output sent to browser
DEBUG - 2023-12-11 05:43:26 --> Total execution time: 0.2201
ERROR - 2023-12-11 05:43:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:43:42 --> Config Class Initialized
INFO - 2023-12-11 05:43:42 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:43:42 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:43:42 --> Utf8 Class Initialized
INFO - 2023-12-11 05:43:42 --> URI Class Initialized
INFO - 2023-12-11 05:43:42 --> Router Class Initialized
INFO - 2023-12-11 05:43:42 --> Output Class Initialized
INFO - 2023-12-11 05:43:42 --> Security Class Initialized
DEBUG - 2023-12-11 05:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:43:42 --> Input Class Initialized
INFO - 2023-12-11 05:43:42 --> Language Class Initialized
INFO - 2023-12-11 05:43:42 --> Loader Class Initialized
INFO - 2023-12-11 05:43:42 --> Helper loaded: url_helper
INFO - 2023-12-11 05:43:42 --> Helper loaded: file_helper
INFO - 2023-12-11 05:43:42 --> Helper loaded: html_helper
INFO - 2023-12-11 05:43:42 --> Helper loaded: text_helper
INFO - 2023-12-11 05:43:42 --> Helper loaded: form_helper
INFO - 2023-12-11 05:43:42 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:43:42 --> Helper loaded: security_helper
INFO - 2023-12-11 05:43:42 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:43:42 --> Database Driver Class Initialized
INFO - 2023-12-11 05:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:43:42 --> Parser Class Initialized
INFO - 2023-12-11 05:43:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:43:42 --> Pagination Class Initialized
INFO - 2023-12-11 05:43:42 --> Form Validation Class Initialized
INFO - 2023-12-11 05:43:42 --> Controller Class Initialized
INFO - 2023-12-11 05:43:42 --> Model Class Initialized
DEBUG - 2023-12-11 05:43:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-11 05:43:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:43:42 --> Model Class Initialized
DEBUG - 2023-12-11 05:43:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:43:42 --> Model Class Initialized
INFO - 2023-12-11 05:43:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-12-11 05:43:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:43:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-11 05:43:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-11 05:43:42 --> Model Class Initialized
INFO - 2023-12-11 05:43:42 --> Model Class Initialized
INFO - 2023-12-11 05:43:42 --> Model Class Initialized
INFO - 2023-12-11 05:43:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-11 05:43:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-11 05:43:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-11 05:43:42 --> Final output sent to browser
DEBUG - 2023-12-11 05:43:42 --> Total execution time: 0.1965
ERROR - 2023-12-11 05:43:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:43:42 --> Config Class Initialized
INFO - 2023-12-11 05:43:42 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:43:42 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:43:42 --> Utf8 Class Initialized
INFO - 2023-12-11 05:43:42 --> URI Class Initialized
INFO - 2023-12-11 05:43:42 --> Router Class Initialized
INFO - 2023-12-11 05:43:42 --> Output Class Initialized
INFO - 2023-12-11 05:43:42 --> Security Class Initialized
DEBUG - 2023-12-11 05:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:43:42 --> Input Class Initialized
INFO - 2023-12-11 05:43:42 --> Language Class Initialized
INFO - 2023-12-11 05:43:42 --> Loader Class Initialized
INFO - 2023-12-11 05:43:42 --> Helper loaded: url_helper
INFO - 2023-12-11 05:43:42 --> Helper loaded: file_helper
INFO - 2023-12-11 05:43:42 --> Helper loaded: html_helper
INFO - 2023-12-11 05:43:42 --> Helper loaded: text_helper
INFO - 2023-12-11 05:43:42 --> Helper loaded: form_helper
INFO - 2023-12-11 05:43:42 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:43:42 --> Helper loaded: security_helper
INFO - 2023-12-11 05:43:42 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:43:42 --> Database Driver Class Initialized
INFO - 2023-12-11 05:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:43:42 --> Parser Class Initialized
INFO - 2023-12-11 05:43:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:43:42 --> Pagination Class Initialized
INFO - 2023-12-11 05:43:42 --> Form Validation Class Initialized
INFO - 2023-12-11 05:43:42 --> Controller Class Initialized
INFO - 2023-12-11 05:43:42 --> Model Class Initialized
DEBUG - 2023-12-11 05:43:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-11 05:43:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:43:42 --> Model Class Initialized
DEBUG - 2023-12-11 05:43:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:43:42 --> Model Class Initialized
INFO - 2023-12-11 05:43:42 --> Final output sent to browser
DEBUG - 2023-12-11 05:43:42 --> Total execution time: 0.0467
ERROR - 2023-12-11 05:43:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:43:53 --> Config Class Initialized
INFO - 2023-12-11 05:43:53 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:43:53 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:43:53 --> Utf8 Class Initialized
INFO - 2023-12-11 05:43:53 --> URI Class Initialized
DEBUG - 2023-12-11 05:43:53 --> No URI present. Default controller set.
INFO - 2023-12-11 05:43:53 --> Router Class Initialized
INFO - 2023-12-11 05:43:53 --> Output Class Initialized
INFO - 2023-12-11 05:43:53 --> Security Class Initialized
DEBUG - 2023-12-11 05:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:43:53 --> Input Class Initialized
INFO - 2023-12-11 05:43:53 --> Language Class Initialized
INFO - 2023-12-11 05:43:53 --> Loader Class Initialized
INFO - 2023-12-11 05:43:53 --> Helper loaded: url_helper
INFO - 2023-12-11 05:43:53 --> Helper loaded: file_helper
INFO - 2023-12-11 05:43:53 --> Helper loaded: html_helper
INFO - 2023-12-11 05:43:53 --> Helper loaded: text_helper
INFO - 2023-12-11 05:43:53 --> Helper loaded: form_helper
INFO - 2023-12-11 05:43:53 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:43:53 --> Helper loaded: security_helper
INFO - 2023-12-11 05:43:53 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:43:53 --> Database Driver Class Initialized
INFO - 2023-12-11 05:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:43:53 --> Parser Class Initialized
INFO - 2023-12-11 05:43:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:43:53 --> Pagination Class Initialized
INFO - 2023-12-11 05:43:53 --> Form Validation Class Initialized
INFO - 2023-12-11 05:43:53 --> Controller Class Initialized
INFO - 2023-12-11 05:43:53 --> Model Class Initialized
DEBUG - 2023-12-11 05:43:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:43:53 --> Model Class Initialized
DEBUG - 2023-12-11 05:43:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:43:53 --> Model Class Initialized
INFO - 2023-12-11 05:43:53 --> Model Class Initialized
INFO - 2023-12-11 05:43:53 --> Model Class Initialized
INFO - 2023-12-11 05:43:53 --> Model Class Initialized
DEBUG - 2023-12-11 05:43:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-11 05:43:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:43:53 --> Model Class Initialized
INFO - 2023-12-11 05:43:53 --> Model Class Initialized
INFO - 2023-12-11 05:43:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-11 05:43:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:43:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-11 05:43:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-11 05:43:53 --> Model Class Initialized
INFO - 2023-12-11 05:43:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-11 05:43:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-11 05:43:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-11 05:43:53 --> Final output sent to browser
DEBUG - 2023-12-11 05:43:53 --> Total execution time: 0.3621
ERROR - 2023-12-11 05:47:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:47:16 --> Config Class Initialized
INFO - 2023-12-11 05:47:16 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:47:16 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:47:16 --> Utf8 Class Initialized
INFO - 2023-12-11 05:47:16 --> URI Class Initialized
INFO - 2023-12-11 05:47:16 --> Router Class Initialized
INFO - 2023-12-11 05:47:16 --> Output Class Initialized
INFO - 2023-12-11 05:47:16 --> Security Class Initialized
DEBUG - 2023-12-11 05:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:47:16 --> Input Class Initialized
INFO - 2023-12-11 05:47:16 --> Language Class Initialized
INFO - 2023-12-11 05:47:16 --> Loader Class Initialized
INFO - 2023-12-11 05:47:16 --> Helper loaded: url_helper
INFO - 2023-12-11 05:47:16 --> Helper loaded: file_helper
INFO - 2023-12-11 05:47:16 --> Helper loaded: html_helper
INFO - 2023-12-11 05:47:16 --> Helper loaded: text_helper
INFO - 2023-12-11 05:47:16 --> Helper loaded: form_helper
INFO - 2023-12-11 05:47:16 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:47:16 --> Helper loaded: security_helper
INFO - 2023-12-11 05:47:16 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:47:16 --> Database Driver Class Initialized
INFO - 2023-12-11 05:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:47:16 --> Parser Class Initialized
INFO - 2023-12-11 05:47:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:47:16 --> Pagination Class Initialized
INFO - 2023-12-11 05:47:16 --> Form Validation Class Initialized
INFO - 2023-12-11 05:47:16 --> Controller Class Initialized
INFO - 2023-12-11 05:47:16 --> Model Class Initialized
INFO - 2023-12-11 05:47:16 --> Model Class Initialized
INFO - 2023-12-11 05:47:16 --> Model Class Initialized
INFO - 2023-12-11 05:47:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report_batch_wise.php
DEBUG - 2023-12-11 05:47:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:47:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-11 05:47:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-11 05:47:16 --> Model Class Initialized
INFO - 2023-12-11 05:47:16 --> Model Class Initialized
INFO - 2023-12-11 05:47:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-11 05:47:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-11 05:47:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-11 05:47:16 --> Final output sent to browser
DEBUG - 2023-12-11 05:47:16 --> Total execution time: 0.1909
ERROR - 2023-12-11 05:47:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:47:17 --> Config Class Initialized
INFO - 2023-12-11 05:47:17 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:47:17 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:47:17 --> Utf8 Class Initialized
INFO - 2023-12-11 05:47:17 --> URI Class Initialized
INFO - 2023-12-11 05:47:17 --> Router Class Initialized
INFO - 2023-12-11 05:47:17 --> Output Class Initialized
INFO - 2023-12-11 05:47:17 --> Security Class Initialized
DEBUG - 2023-12-11 05:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:47:17 --> Input Class Initialized
INFO - 2023-12-11 05:47:17 --> Language Class Initialized
INFO - 2023-12-11 05:47:17 --> Loader Class Initialized
INFO - 2023-12-11 05:47:17 --> Helper loaded: url_helper
INFO - 2023-12-11 05:47:17 --> Helper loaded: file_helper
INFO - 2023-12-11 05:47:17 --> Helper loaded: html_helper
INFO - 2023-12-11 05:47:17 --> Helper loaded: text_helper
INFO - 2023-12-11 05:47:17 --> Helper loaded: form_helper
INFO - 2023-12-11 05:47:17 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:47:17 --> Helper loaded: security_helper
INFO - 2023-12-11 05:47:17 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:47:17 --> Database Driver Class Initialized
INFO - 2023-12-11 05:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:47:17 --> Parser Class Initialized
INFO - 2023-12-11 05:47:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:47:17 --> Pagination Class Initialized
INFO - 2023-12-11 05:47:17 --> Form Validation Class Initialized
INFO - 2023-12-11 05:47:17 --> Controller Class Initialized
INFO - 2023-12-11 05:47:17 --> Model Class Initialized
INFO - 2023-12-11 05:47:17 --> Model Class Initialized
INFO - 2023-12-11 05:47:17 --> Final output sent to browser
DEBUG - 2023-12-11 05:47:17 --> Total execution time: 0.0268
ERROR - 2023-12-11 05:47:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:47:20 --> Config Class Initialized
INFO - 2023-12-11 05:47:20 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:47:20 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:47:20 --> Utf8 Class Initialized
INFO - 2023-12-11 05:47:20 --> URI Class Initialized
INFO - 2023-12-11 05:47:20 --> Router Class Initialized
INFO - 2023-12-11 05:47:20 --> Output Class Initialized
INFO - 2023-12-11 05:47:20 --> Security Class Initialized
DEBUG - 2023-12-11 05:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:47:20 --> Input Class Initialized
INFO - 2023-12-11 05:47:20 --> Language Class Initialized
INFO - 2023-12-11 05:47:20 --> Loader Class Initialized
INFO - 2023-12-11 05:47:20 --> Helper loaded: url_helper
INFO - 2023-12-11 05:47:20 --> Helper loaded: file_helper
INFO - 2023-12-11 05:47:20 --> Helper loaded: html_helper
INFO - 2023-12-11 05:47:20 --> Helper loaded: text_helper
INFO - 2023-12-11 05:47:20 --> Helper loaded: form_helper
INFO - 2023-12-11 05:47:20 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:47:20 --> Helper loaded: security_helper
INFO - 2023-12-11 05:47:20 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:47:20 --> Database Driver Class Initialized
INFO - 2023-12-11 05:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:47:20 --> Parser Class Initialized
INFO - 2023-12-11 05:47:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:47:20 --> Pagination Class Initialized
INFO - 2023-12-11 05:47:20 --> Form Validation Class Initialized
INFO - 2023-12-11 05:47:20 --> Controller Class Initialized
INFO - 2023-12-11 05:47:20 --> Model Class Initialized
INFO - 2023-12-11 05:47:20 --> Model Class Initialized
INFO - 2023-12-11 05:47:20 --> Final output sent to browser
DEBUG - 2023-12-11 05:47:20 --> Total execution time: 0.0537
ERROR - 2023-12-11 05:53:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:53:02 --> Config Class Initialized
INFO - 2023-12-11 05:53:02 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:53:02 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:53:02 --> Utf8 Class Initialized
INFO - 2023-12-11 05:53:02 --> URI Class Initialized
INFO - 2023-12-11 05:53:02 --> Router Class Initialized
INFO - 2023-12-11 05:53:02 --> Output Class Initialized
INFO - 2023-12-11 05:53:02 --> Security Class Initialized
DEBUG - 2023-12-11 05:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:53:02 --> Input Class Initialized
INFO - 2023-12-11 05:53:02 --> Language Class Initialized
INFO - 2023-12-11 05:53:02 --> Loader Class Initialized
INFO - 2023-12-11 05:53:02 --> Helper loaded: url_helper
INFO - 2023-12-11 05:53:02 --> Helper loaded: file_helper
INFO - 2023-12-11 05:53:02 --> Helper loaded: html_helper
INFO - 2023-12-11 05:53:02 --> Helper loaded: text_helper
INFO - 2023-12-11 05:53:02 --> Helper loaded: form_helper
INFO - 2023-12-11 05:53:02 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:53:02 --> Helper loaded: security_helper
INFO - 2023-12-11 05:53:02 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:53:02 --> Database Driver Class Initialized
INFO - 2023-12-11 05:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:53:02 --> Parser Class Initialized
INFO - 2023-12-11 05:53:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:53:02 --> Pagination Class Initialized
INFO - 2023-12-11 05:53:02 --> Form Validation Class Initialized
INFO - 2023-12-11 05:53:02 --> Controller Class Initialized
INFO - 2023-12-11 05:53:02 --> Model Class Initialized
INFO - 2023-12-11 05:53:02 --> Model Class Initialized
INFO - 2023-12-11 05:53:02 --> Model Class Initialized
INFO - 2023-12-11 05:53:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report_batch_wise.php
DEBUG - 2023-12-11 05:53:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:53:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-11 05:53:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-11 05:53:02 --> Model Class Initialized
INFO - 2023-12-11 05:53:02 --> Model Class Initialized
INFO - 2023-12-11 05:53:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-11 05:53:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-11 05:53:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-11 05:53:03 --> Final output sent to browser
DEBUG - 2023-12-11 05:53:03 --> Total execution time: 0.2422
ERROR - 2023-12-11 05:53:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:53:03 --> Config Class Initialized
INFO - 2023-12-11 05:53:03 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:53:03 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:53:03 --> Utf8 Class Initialized
INFO - 2023-12-11 05:53:03 --> URI Class Initialized
INFO - 2023-12-11 05:53:03 --> Router Class Initialized
INFO - 2023-12-11 05:53:03 --> Output Class Initialized
INFO - 2023-12-11 05:53:03 --> Security Class Initialized
DEBUG - 2023-12-11 05:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:53:03 --> Input Class Initialized
INFO - 2023-12-11 05:53:03 --> Language Class Initialized
INFO - 2023-12-11 05:53:03 --> Loader Class Initialized
INFO - 2023-12-11 05:53:03 --> Helper loaded: url_helper
INFO - 2023-12-11 05:53:03 --> Helper loaded: file_helper
INFO - 2023-12-11 05:53:03 --> Helper loaded: html_helper
INFO - 2023-12-11 05:53:03 --> Helper loaded: text_helper
INFO - 2023-12-11 05:53:03 --> Helper loaded: form_helper
INFO - 2023-12-11 05:53:03 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:53:03 --> Helper loaded: security_helper
INFO - 2023-12-11 05:53:03 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:53:03 --> Database Driver Class Initialized
INFO - 2023-12-11 05:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:53:03 --> Parser Class Initialized
INFO - 2023-12-11 05:53:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:53:03 --> Pagination Class Initialized
INFO - 2023-12-11 05:53:03 --> Form Validation Class Initialized
INFO - 2023-12-11 05:53:03 --> Controller Class Initialized
INFO - 2023-12-11 05:53:03 --> Model Class Initialized
INFO - 2023-12-11 05:53:03 --> Model Class Initialized
INFO - 2023-12-11 05:53:03 --> Final output sent to browser
DEBUG - 2023-12-11 05:53:03 --> Total execution time: 0.0262
ERROR - 2023-12-11 05:53:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:53:07 --> Config Class Initialized
INFO - 2023-12-11 05:53:07 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:53:07 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:53:07 --> Utf8 Class Initialized
INFO - 2023-12-11 05:53:07 --> URI Class Initialized
INFO - 2023-12-11 05:53:07 --> Router Class Initialized
INFO - 2023-12-11 05:53:07 --> Output Class Initialized
INFO - 2023-12-11 05:53:07 --> Security Class Initialized
DEBUG - 2023-12-11 05:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:53:07 --> Input Class Initialized
INFO - 2023-12-11 05:53:07 --> Language Class Initialized
INFO - 2023-12-11 05:53:07 --> Loader Class Initialized
INFO - 2023-12-11 05:53:07 --> Helper loaded: url_helper
INFO - 2023-12-11 05:53:07 --> Helper loaded: file_helper
INFO - 2023-12-11 05:53:07 --> Helper loaded: html_helper
INFO - 2023-12-11 05:53:07 --> Helper loaded: text_helper
INFO - 2023-12-11 05:53:07 --> Helper loaded: form_helper
INFO - 2023-12-11 05:53:07 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:53:07 --> Helper loaded: security_helper
INFO - 2023-12-11 05:53:07 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:53:07 --> Database Driver Class Initialized
INFO - 2023-12-11 05:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:53:07 --> Parser Class Initialized
INFO - 2023-12-11 05:53:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:53:07 --> Pagination Class Initialized
INFO - 2023-12-11 05:53:07 --> Form Validation Class Initialized
INFO - 2023-12-11 05:53:07 --> Controller Class Initialized
DEBUG - 2023-12-11 05:53:07 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:53:07 --> Model Class Initialized
INFO - 2023-12-11 05:53:07 --> Model Class Initialized
INFO - 2023-12-11 05:53:07 --> Model Class Initialized
INFO - 2023-12-11 05:53:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product_details.php
DEBUG - 2023-12-11 05:53:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:53:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-11 05:53:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-11 05:53:07 --> Model Class Initialized
INFO - 2023-12-11 05:53:07 --> Model Class Initialized
INFO - 2023-12-11 05:53:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-11 05:53:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-11 05:53:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-11 05:53:07 --> Final output sent to browser
DEBUG - 2023-12-11 05:53:07 --> Total execution time: 0.2323
ERROR - 2023-12-11 05:54:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:54:36 --> Config Class Initialized
INFO - 2023-12-11 05:54:36 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:54:36 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:54:36 --> Utf8 Class Initialized
INFO - 2023-12-11 05:54:36 --> URI Class Initialized
DEBUG - 2023-12-11 05:54:36 --> No URI present. Default controller set.
INFO - 2023-12-11 05:54:36 --> Router Class Initialized
INFO - 2023-12-11 05:54:36 --> Output Class Initialized
INFO - 2023-12-11 05:54:36 --> Security Class Initialized
DEBUG - 2023-12-11 05:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:54:36 --> Input Class Initialized
INFO - 2023-12-11 05:54:36 --> Language Class Initialized
INFO - 2023-12-11 05:54:36 --> Loader Class Initialized
INFO - 2023-12-11 05:54:36 --> Helper loaded: url_helper
INFO - 2023-12-11 05:54:36 --> Helper loaded: file_helper
INFO - 2023-12-11 05:54:36 --> Helper loaded: html_helper
INFO - 2023-12-11 05:54:36 --> Helper loaded: text_helper
INFO - 2023-12-11 05:54:36 --> Helper loaded: form_helper
INFO - 2023-12-11 05:54:36 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:54:36 --> Helper loaded: security_helper
INFO - 2023-12-11 05:54:36 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:54:36 --> Database Driver Class Initialized
INFO - 2023-12-11 05:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:54:36 --> Parser Class Initialized
INFO - 2023-12-11 05:54:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:54:36 --> Pagination Class Initialized
INFO - 2023-12-11 05:54:36 --> Form Validation Class Initialized
INFO - 2023-12-11 05:54:36 --> Controller Class Initialized
INFO - 2023-12-11 05:54:36 --> Model Class Initialized
DEBUG - 2023-12-11 05:54:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:54:36 --> Model Class Initialized
DEBUG - 2023-12-11 05:54:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:54:36 --> Model Class Initialized
INFO - 2023-12-11 05:54:36 --> Model Class Initialized
INFO - 2023-12-11 05:54:36 --> Model Class Initialized
INFO - 2023-12-11 05:54:36 --> Model Class Initialized
DEBUG - 2023-12-11 05:54:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-11 05:54:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:54:36 --> Model Class Initialized
INFO - 2023-12-11 05:54:36 --> Model Class Initialized
INFO - 2023-12-11 05:54:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-11 05:54:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:54:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-11 05:54:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-11 05:54:36 --> Model Class Initialized
INFO - 2023-12-11 05:54:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-11 05:54:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-11 05:54:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-11 05:54:36 --> Final output sent to browser
DEBUG - 2023-12-11 05:54:36 --> Total execution time: 0.3934
ERROR - 2023-12-11 05:54:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:54:54 --> Config Class Initialized
INFO - 2023-12-11 05:54:54 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:54:54 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:54:54 --> Utf8 Class Initialized
INFO - 2023-12-11 05:54:54 --> URI Class Initialized
DEBUG - 2023-12-11 05:54:54 --> No URI present. Default controller set.
INFO - 2023-12-11 05:54:54 --> Router Class Initialized
INFO - 2023-12-11 05:54:54 --> Output Class Initialized
INFO - 2023-12-11 05:54:54 --> Security Class Initialized
DEBUG - 2023-12-11 05:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:54:54 --> Input Class Initialized
INFO - 2023-12-11 05:54:54 --> Language Class Initialized
INFO - 2023-12-11 05:54:54 --> Loader Class Initialized
INFO - 2023-12-11 05:54:54 --> Helper loaded: url_helper
INFO - 2023-12-11 05:54:54 --> Helper loaded: file_helper
INFO - 2023-12-11 05:54:54 --> Helper loaded: html_helper
INFO - 2023-12-11 05:54:54 --> Helper loaded: text_helper
INFO - 2023-12-11 05:54:54 --> Helper loaded: form_helper
INFO - 2023-12-11 05:54:54 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:54:54 --> Helper loaded: security_helper
INFO - 2023-12-11 05:54:54 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:54:54 --> Database Driver Class Initialized
INFO - 2023-12-11 05:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:54:54 --> Parser Class Initialized
INFO - 2023-12-11 05:54:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:54:54 --> Pagination Class Initialized
INFO - 2023-12-11 05:54:54 --> Form Validation Class Initialized
INFO - 2023-12-11 05:54:54 --> Controller Class Initialized
INFO - 2023-12-11 05:54:54 --> Model Class Initialized
DEBUG - 2023-12-11 05:54:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:54:54 --> Model Class Initialized
DEBUG - 2023-12-11 05:54:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:54:54 --> Model Class Initialized
INFO - 2023-12-11 05:54:54 --> Model Class Initialized
INFO - 2023-12-11 05:54:54 --> Model Class Initialized
INFO - 2023-12-11 05:54:54 --> Model Class Initialized
DEBUG - 2023-12-11 05:54:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-11 05:54:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:54:54 --> Model Class Initialized
INFO - 2023-12-11 05:54:54 --> Model Class Initialized
INFO - 2023-12-11 05:54:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-11 05:54:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:54:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-11 05:54:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-11 05:54:54 --> Model Class Initialized
INFO - 2023-12-11 05:54:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-11 05:54:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-11 05:54:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-11 05:54:54 --> Final output sent to browser
DEBUG - 2023-12-11 05:54:54 --> Total execution time: 0.3769
ERROR - 2023-12-11 05:55:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:55:04 --> Config Class Initialized
INFO - 2023-12-11 05:55:04 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:55:04 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:55:04 --> Utf8 Class Initialized
INFO - 2023-12-11 05:55:04 --> URI Class Initialized
INFO - 2023-12-11 05:55:04 --> Router Class Initialized
INFO - 2023-12-11 05:55:04 --> Output Class Initialized
INFO - 2023-12-11 05:55:04 --> Security Class Initialized
DEBUG - 2023-12-11 05:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:55:04 --> Input Class Initialized
INFO - 2023-12-11 05:55:04 --> Language Class Initialized
INFO - 2023-12-11 05:55:04 --> Loader Class Initialized
INFO - 2023-12-11 05:55:04 --> Helper loaded: url_helper
INFO - 2023-12-11 05:55:04 --> Helper loaded: file_helper
INFO - 2023-12-11 05:55:04 --> Helper loaded: html_helper
INFO - 2023-12-11 05:55:04 --> Helper loaded: text_helper
INFO - 2023-12-11 05:55:04 --> Helper loaded: form_helper
INFO - 2023-12-11 05:55:04 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:55:04 --> Helper loaded: security_helper
INFO - 2023-12-11 05:55:04 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:55:04 --> Database Driver Class Initialized
INFO - 2023-12-11 05:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:55:04 --> Parser Class Initialized
INFO - 2023-12-11 05:55:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:55:04 --> Pagination Class Initialized
INFO - 2023-12-11 05:55:04 --> Form Validation Class Initialized
INFO - 2023-12-11 05:55:04 --> Controller Class Initialized
INFO - 2023-12-11 05:55:04 --> Model Class Initialized
DEBUG - 2023-12-11 05:55:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-11 05:55:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:55:04 --> Model Class Initialized
INFO - 2023-12-11 05:55:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-12-11 05:55:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:55:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-11 05:55:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-11 05:55:04 --> Model Class Initialized
INFO - 2023-12-11 05:55:04 --> Model Class Initialized
INFO - 2023-12-11 05:55:04 --> Model Class Initialized
INFO - 2023-12-11 05:55:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-11 05:55:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-11 05:55:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-11 05:55:04 --> Final output sent to browser
DEBUG - 2023-12-11 05:55:04 --> Total execution time: 0.1278
ERROR - 2023-12-11 05:55:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:55:05 --> Config Class Initialized
INFO - 2023-12-11 05:55:05 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:55:05 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:55:05 --> Utf8 Class Initialized
INFO - 2023-12-11 05:55:05 --> URI Class Initialized
INFO - 2023-12-11 05:55:05 --> Router Class Initialized
INFO - 2023-12-11 05:55:05 --> Output Class Initialized
INFO - 2023-12-11 05:55:05 --> Security Class Initialized
DEBUG - 2023-12-11 05:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:55:05 --> Input Class Initialized
INFO - 2023-12-11 05:55:05 --> Language Class Initialized
INFO - 2023-12-11 05:55:05 --> Loader Class Initialized
INFO - 2023-12-11 05:55:05 --> Helper loaded: url_helper
INFO - 2023-12-11 05:55:05 --> Helper loaded: file_helper
INFO - 2023-12-11 05:55:05 --> Helper loaded: html_helper
INFO - 2023-12-11 05:55:05 --> Helper loaded: text_helper
INFO - 2023-12-11 05:55:05 --> Helper loaded: form_helper
INFO - 2023-12-11 05:55:05 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:55:05 --> Helper loaded: security_helper
INFO - 2023-12-11 05:55:05 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:55:05 --> Database Driver Class Initialized
INFO - 2023-12-11 05:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:55:05 --> Parser Class Initialized
INFO - 2023-12-11 05:55:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:55:05 --> Pagination Class Initialized
INFO - 2023-12-11 05:55:05 --> Form Validation Class Initialized
INFO - 2023-12-11 05:55:05 --> Controller Class Initialized
INFO - 2023-12-11 05:55:05 --> Model Class Initialized
DEBUG - 2023-12-11 05:55:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-11 05:55:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:55:05 --> Model Class Initialized
INFO - 2023-12-11 05:55:05 --> Final output sent to browser
DEBUG - 2023-12-11 05:55:05 --> Total execution time: 0.0464
ERROR - 2023-12-11 05:55:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 05:55:09 --> Config Class Initialized
INFO - 2023-12-11 05:55:09 --> Hooks Class Initialized
DEBUG - 2023-12-11 05:55:09 --> UTF-8 Support Enabled
INFO - 2023-12-11 05:55:09 --> Utf8 Class Initialized
INFO - 2023-12-11 05:55:09 --> URI Class Initialized
INFO - 2023-12-11 05:55:09 --> Router Class Initialized
INFO - 2023-12-11 05:55:09 --> Output Class Initialized
INFO - 2023-12-11 05:55:09 --> Security Class Initialized
DEBUG - 2023-12-11 05:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 05:55:09 --> Input Class Initialized
INFO - 2023-12-11 05:55:09 --> Language Class Initialized
INFO - 2023-12-11 05:55:09 --> Loader Class Initialized
INFO - 2023-12-11 05:55:09 --> Helper loaded: url_helper
INFO - 2023-12-11 05:55:09 --> Helper loaded: file_helper
INFO - 2023-12-11 05:55:09 --> Helper loaded: html_helper
INFO - 2023-12-11 05:55:09 --> Helper loaded: text_helper
INFO - 2023-12-11 05:55:09 --> Helper loaded: form_helper
INFO - 2023-12-11 05:55:09 --> Helper loaded: lang_helper
INFO - 2023-12-11 05:55:09 --> Helper loaded: security_helper
INFO - 2023-12-11 05:55:09 --> Helper loaded: cookie_helper
INFO - 2023-12-11 05:55:09 --> Database Driver Class Initialized
INFO - 2023-12-11 05:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 05:55:09 --> Parser Class Initialized
INFO - 2023-12-11 05:55:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 05:55:09 --> Pagination Class Initialized
INFO - 2023-12-11 05:55:09 --> Form Validation Class Initialized
INFO - 2023-12-11 05:55:09 --> Controller Class Initialized
INFO - 2023-12-11 05:55:09 --> Model Class Initialized
DEBUG - 2023-12-11 05:55:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-11 05:55:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 05:55:09 --> Model Class Initialized
INFO - 2023-12-11 05:55:09 --> Final output sent to browser
DEBUG - 2023-12-11 05:55:09 --> Total execution time: 0.0448
ERROR - 2023-12-11 06:56:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 06:56:25 --> Config Class Initialized
INFO - 2023-12-11 06:56:25 --> Hooks Class Initialized
DEBUG - 2023-12-11 06:56:25 --> UTF-8 Support Enabled
INFO - 2023-12-11 06:56:25 --> Utf8 Class Initialized
INFO - 2023-12-11 06:56:25 --> URI Class Initialized
DEBUG - 2023-12-11 06:56:25 --> No URI present. Default controller set.
INFO - 2023-12-11 06:56:25 --> Router Class Initialized
INFO - 2023-12-11 06:56:25 --> Output Class Initialized
INFO - 2023-12-11 06:56:25 --> Security Class Initialized
DEBUG - 2023-12-11 06:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 06:56:25 --> Input Class Initialized
INFO - 2023-12-11 06:56:25 --> Language Class Initialized
INFO - 2023-12-11 06:56:25 --> Loader Class Initialized
INFO - 2023-12-11 06:56:25 --> Helper loaded: url_helper
INFO - 2023-12-11 06:56:25 --> Helper loaded: file_helper
INFO - 2023-12-11 06:56:25 --> Helper loaded: html_helper
INFO - 2023-12-11 06:56:25 --> Helper loaded: text_helper
INFO - 2023-12-11 06:56:25 --> Helper loaded: form_helper
INFO - 2023-12-11 06:56:25 --> Helper loaded: lang_helper
INFO - 2023-12-11 06:56:25 --> Helper loaded: security_helper
INFO - 2023-12-11 06:56:25 --> Helper loaded: cookie_helper
INFO - 2023-12-11 06:56:25 --> Database Driver Class Initialized
INFO - 2023-12-11 06:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 06:56:25 --> Parser Class Initialized
INFO - 2023-12-11 06:56:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 06:56:25 --> Pagination Class Initialized
INFO - 2023-12-11 06:56:25 --> Form Validation Class Initialized
INFO - 2023-12-11 06:56:25 --> Controller Class Initialized
INFO - 2023-12-11 06:56:25 --> Model Class Initialized
DEBUG - 2023-12-11 06:56:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-11 06:56:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 06:56:25 --> Config Class Initialized
INFO - 2023-12-11 06:56:25 --> Hooks Class Initialized
DEBUG - 2023-12-11 06:56:25 --> UTF-8 Support Enabled
INFO - 2023-12-11 06:56:25 --> Utf8 Class Initialized
INFO - 2023-12-11 06:56:25 --> URI Class Initialized
INFO - 2023-12-11 06:56:25 --> Router Class Initialized
INFO - 2023-12-11 06:56:25 --> Output Class Initialized
INFO - 2023-12-11 06:56:25 --> Security Class Initialized
DEBUG - 2023-12-11 06:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 06:56:25 --> Input Class Initialized
INFO - 2023-12-11 06:56:25 --> Language Class Initialized
INFO - 2023-12-11 06:56:25 --> Loader Class Initialized
INFO - 2023-12-11 06:56:25 --> Helper loaded: url_helper
INFO - 2023-12-11 06:56:25 --> Helper loaded: file_helper
INFO - 2023-12-11 06:56:25 --> Helper loaded: html_helper
INFO - 2023-12-11 06:56:25 --> Helper loaded: text_helper
INFO - 2023-12-11 06:56:25 --> Helper loaded: form_helper
INFO - 2023-12-11 06:56:25 --> Helper loaded: lang_helper
INFO - 2023-12-11 06:56:25 --> Helper loaded: security_helper
INFO - 2023-12-11 06:56:25 --> Helper loaded: cookie_helper
INFO - 2023-12-11 06:56:25 --> Database Driver Class Initialized
INFO - 2023-12-11 06:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 06:56:25 --> Parser Class Initialized
INFO - 2023-12-11 06:56:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 06:56:25 --> Pagination Class Initialized
INFO - 2023-12-11 06:56:25 --> Form Validation Class Initialized
INFO - 2023-12-11 06:56:25 --> Controller Class Initialized
INFO - 2023-12-11 06:56:25 --> Model Class Initialized
DEBUG - 2023-12-11 06:56:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 06:56:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-11 06:56:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-11 06:56:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-11 06:56:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-11 06:56:25 --> Model Class Initialized
INFO - 2023-12-11 06:56:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-11 06:56:25 --> Final output sent to browser
DEBUG - 2023-12-11 06:56:25 --> Total execution time: 0.0310
ERROR - 2023-12-11 06:57:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 06:57:05 --> Config Class Initialized
INFO - 2023-12-11 06:57:05 --> Hooks Class Initialized
DEBUG - 2023-12-11 06:57:05 --> UTF-8 Support Enabled
INFO - 2023-12-11 06:57:05 --> Utf8 Class Initialized
INFO - 2023-12-11 06:57:05 --> URI Class Initialized
INFO - 2023-12-11 06:57:05 --> Router Class Initialized
INFO - 2023-12-11 06:57:05 --> Output Class Initialized
INFO - 2023-12-11 06:57:05 --> Security Class Initialized
DEBUG - 2023-12-11 06:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 06:57:05 --> Input Class Initialized
INFO - 2023-12-11 06:57:05 --> Language Class Initialized
INFO - 2023-12-11 06:57:05 --> Loader Class Initialized
INFO - 2023-12-11 06:57:05 --> Helper loaded: url_helper
INFO - 2023-12-11 06:57:05 --> Helper loaded: file_helper
INFO - 2023-12-11 06:57:05 --> Helper loaded: html_helper
INFO - 2023-12-11 06:57:05 --> Helper loaded: text_helper
INFO - 2023-12-11 06:57:05 --> Helper loaded: form_helper
INFO - 2023-12-11 06:57:05 --> Helper loaded: lang_helper
INFO - 2023-12-11 06:57:05 --> Helper loaded: security_helper
INFO - 2023-12-11 06:57:05 --> Helper loaded: cookie_helper
INFO - 2023-12-11 06:57:05 --> Database Driver Class Initialized
INFO - 2023-12-11 06:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 06:57:05 --> Parser Class Initialized
INFO - 2023-12-11 06:57:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 06:57:05 --> Pagination Class Initialized
INFO - 2023-12-11 06:57:05 --> Form Validation Class Initialized
INFO - 2023-12-11 06:57:05 --> Controller Class Initialized
INFO - 2023-12-11 06:57:05 --> Model Class Initialized
DEBUG - 2023-12-11 06:57:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 06:57:05 --> Model Class Initialized
INFO - 2023-12-11 06:57:05 --> Final output sent to browser
DEBUG - 2023-12-11 06:57:05 --> Total execution time: 0.0216
ERROR - 2023-12-11 06:57:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 06:57:05 --> Config Class Initialized
INFO - 2023-12-11 06:57:05 --> Hooks Class Initialized
DEBUG - 2023-12-11 06:57:05 --> UTF-8 Support Enabled
INFO - 2023-12-11 06:57:05 --> Utf8 Class Initialized
INFO - 2023-12-11 06:57:05 --> URI Class Initialized
DEBUG - 2023-12-11 06:57:05 --> No URI present. Default controller set.
INFO - 2023-12-11 06:57:05 --> Router Class Initialized
INFO - 2023-12-11 06:57:05 --> Output Class Initialized
INFO - 2023-12-11 06:57:05 --> Security Class Initialized
DEBUG - 2023-12-11 06:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 06:57:05 --> Input Class Initialized
INFO - 2023-12-11 06:57:05 --> Language Class Initialized
INFO - 2023-12-11 06:57:05 --> Loader Class Initialized
INFO - 2023-12-11 06:57:05 --> Helper loaded: url_helper
INFO - 2023-12-11 06:57:05 --> Helper loaded: file_helper
INFO - 2023-12-11 06:57:05 --> Helper loaded: html_helper
INFO - 2023-12-11 06:57:05 --> Helper loaded: text_helper
INFO - 2023-12-11 06:57:05 --> Helper loaded: form_helper
INFO - 2023-12-11 06:57:05 --> Helper loaded: lang_helper
INFO - 2023-12-11 06:57:05 --> Helper loaded: security_helper
INFO - 2023-12-11 06:57:05 --> Helper loaded: cookie_helper
INFO - 2023-12-11 06:57:05 --> Database Driver Class Initialized
INFO - 2023-12-11 06:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 06:57:05 --> Parser Class Initialized
INFO - 2023-12-11 06:57:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 06:57:05 --> Pagination Class Initialized
INFO - 2023-12-11 06:57:05 --> Form Validation Class Initialized
INFO - 2023-12-11 06:57:05 --> Controller Class Initialized
INFO - 2023-12-11 06:57:05 --> Model Class Initialized
DEBUG - 2023-12-11 06:57:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 06:57:05 --> Model Class Initialized
DEBUG - 2023-12-11 06:57:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 06:57:05 --> Model Class Initialized
INFO - 2023-12-11 06:57:05 --> Model Class Initialized
INFO - 2023-12-11 06:57:05 --> Model Class Initialized
INFO - 2023-12-11 06:57:05 --> Model Class Initialized
DEBUG - 2023-12-11 06:57:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-11 06:57:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 06:57:05 --> Model Class Initialized
INFO - 2023-12-11 06:57:05 --> Model Class Initialized
INFO - 2023-12-11 06:57:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-11 06:57:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-11 06:57:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-11 06:57:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-11 06:57:06 --> Model Class Initialized
INFO - 2023-12-11 06:57:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-11 06:57:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-11 06:57:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-11 06:57:06 --> Final output sent to browser
DEBUG - 2023-12-11 06:57:06 --> Total execution time: 0.2192
ERROR - 2023-12-11 06:57:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 06:57:28 --> Config Class Initialized
INFO - 2023-12-11 06:57:28 --> Hooks Class Initialized
DEBUG - 2023-12-11 06:57:28 --> UTF-8 Support Enabled
INFO - 2023-12-11 06:57:28 --> Utf8 Class Initialized
INFO - 2023-12-11 06:57:28 --> URI Class Initialized
INFO - 2023-12-11 06:57:28 --> Router Class Initialized
INFO - 2023-12-11 06:57:28 --> Output Class Initialized
INFO - 2023-12-11 06:57:28 --> Security Class Initialized
DEBUG - 2023-12-11 06:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 06:57:28 --> Input Class Initialized
INFO - 2023-12-11 06:57:28 --> Language Class Initialized
INFO - 2023-12-11 06:57:28 --> Loader Class Initialized
INFO - 2023-12-11 06:57:28 --> Helper loaded: url_helper
INFO - 2023-12-11 06:57:28 --> Helper loaded: file_helper
INFO - 2023-12-11 06:57:28 --> Helper loaded: html_helper
INFO - 2023-12-11 06:57:28 --> Helper loaded: text_helper
INFO - 2023-12-11 06:57:28 --> Helper loaded: form_helper
INFO - 2023-12-11 06:57:28 --> Helper loaded: lang_helper
INFO - 2023-12-11 06:57:28 --> Helper loaded: security_helper
INFO - 2023-12-11 06:57:28 --> Helper loaded: cookie_helper
INFO - 2023-12-11 06:57:28 --> Database Driver Class Initialized
INFO - 2023-12-11 06:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 06:57:28 --> Parser Class Initialized
INFO - 2023-12-11 06:57:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 06:57:28 --> Pagination Class Initialized
INFO - 2023-12-11 06:57:28 --> Form Validation Class Initialized
INFO - 2023-12-11 06:57:28 --> Controller Class Initialized
INFO - 2023-12-11 06:57:28 --> Model Class Initialized
DEBUG - 2023-12-11 06:57:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 06:57:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-11 06:57:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-11 06:57:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-11 06:57:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-11 06:57:28 --> Model Class Initialized
INFO - 2023-12-11 06:57:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-11 06:57:28 --> Final output sent to browser
DEBUG - 2023-12-11 06:57:28 --> Total execution time: 0.0321
ERROR - 2023-12-11 06:57:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 06:57:28 --> Config Class Initialized
INFO - 2023-12-11 06:57:28 --> Hooks Class Initialized
DEBUG - 2023-12-11 06:57:28 --> UTF-8 Support Enabled
INFO - 2023-12-11 06:57:28 --> Utf8 Class Initialized
INFO - 2023-12-11 06:57:28 --> URI Class Initialized
INFO - 2023-12-11 06:57:28 --> Router Class Initialized
INFO - 2023-12-11 06:57:28 --> Output Class Initialized
INFO - 2023-12-11 06:57:28 --> Security Class Initialized
DEBUG - 2023-12-11 06:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 06:57:28 --> Input Class Initialized
INFO - 2023-12-11 06:57:28 --> Language Class Initialized
INFO - 2023-12-11 06:57:28 --> Loader Class Initialized
INFO - 2023-12-11 06:57:28 --> Helper loaded: url_helper
INFO - 2023-12-11 06:57:28 --> Helper loaded: file_helper
INFO - 2023-12-11 06:57:28 --> Helper loaded: html_helper
INFO - 2023-12-11 06:57:28 --> Helper loaded: text_helper
INFO - 2023-12-11 06:57:28 --> Helper loaded: form_helper
INFO - 2023-12-11 06:57:28 --> Helper loaded: lang_helper
INFO - 2023-12-11 06:57:28 --> Helper loaded: security_helper
INFO - 2023-12-11 06:57:28 --> Helper loaded: cookie_helper
INFO - 2023-12-11 06:57:28 --> Database Driver Class Initialized
INFO - 2023-12-11 06:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 06:57:28 --> Parser Class Initialized
INFO - 2023-12-11 06:57:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 06:57:28 --> Pagination Class Initialized
INFO - 2023-12-11 06:57:28 --> Form Validation Class Initialized
INFO - 2023-12-11 06:57:28 --> Controller Class Initialized
INFO - 2023-12-11 06:57:28 --> Model Class Initialized
DEBUG - 2023-12-11 06:57:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 06:57:28 --> Model Class Initialized
DEBUG - 2023-12-11 06:57:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 06:57:28 --> Model Class Initialized
INFO - 2023-12-11 06:57:28 --> Model Class Initialized
INFO - 2023-12-11 06:57:28 --> Model Class Initialized
INFO - 2023-12-11 06:57:28 --> Model Class Initialized
DEBUG - 2023-12-11 06:57:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-11 06:57:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 06:57:28 --> Model Class Initialized
INFO - 2023-12-11 06:57:28 --> Model Class Initialized
INFO - 2023-12-11 06:57:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-11 06:57:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-11 06:57:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-11 06:57:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-11 06:57:28 --> Model Class Initialized
INFO - 2023-12-11 06:57:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-11 06:57:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-11 06:57:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-11 06:57:28 --> Final output sent to browser
DEBUG - 2023-12-11 06:57:28 --> Total execution time: 0.2190
ERROR - 2023-12-11 06:57:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 06:57:35 --> Config Class Initialized
INFO - 2023-12-11 06:57:35 --> Hooks Class Initialized
DEBUG - 2023-12-11 06:57:35 --> UTF-8 Support Enabled
INFO - 2023-12-11 06:57:35 --> Utf8 Class Initialized
INFO - 2023-12-11 06:57:35 --> URI Class Initialized
INFO - 2023-12-11 06:57:35 --> Router Class Initialized
INFO - 2023-12-11 06:57:35 --> Output Class Initialized
INFO - 2023-12-11 06:57:35 --> Security Class Initialized
DEBUG - 2023-12-11 06:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 06:57:35 --> Input Class Initialized
INFO - 2023-12-11 06:57:35 --> Language Class Initialized
INFO - 2023-12-11 06:57:35 --> Loader Class Initialized
INFO - 2023-12-11 06:57:35 --> Helper loaded: url_helper
INFO - 2023-12-11 06:57:35 --> Helper loaded: file_helper
INFO - 2023-12-11 06:57:35 --> Helper loaded: html_helper
INFO - 2023-12-11 06:57:35 --> Helper loaded: text_helper
INFO - 2023-12-11 06:57:35 --> Helper loaded: form_helper
INFO - 2023-12-11 06:57:35 --> Helper loaded: lang_helper
INFO - 2023-12-11 06:57:35 --> Helper loaded: security_helper
INFO - 2023-12-11 06:57:35 --> Helper loaded: cookie_helper
INFO - 2023-12-11 06:57:35 --> Database Driver Class Initialized
INFO - 2023-12-11 06:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 06:57:35 --> Parser Class Initialized
INFO - 2023-12-11 06:57:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 06:57:35 --> Pagination Class Initialized
INFO - 2023-12-11 06:57:35 --> Form Validation Class Initialized
INFO - 2023-12-11 06:57:35 --> Controller Class Initialized
INFO - 2023-12-11 06:57:35 --> Model Class Initialized
DEBUG - 2023-12-11 06:57:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-11 06:57:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 06:57:35 --> Model Class Initialized
DEBUG - 2023-12-11 06:57:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 06:57:35 --> Model Class Initialized
INFO - 2023-12-11 06:57:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-11 06:57:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-11 06:57:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-11 06:57:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-11 06:57:35 --> Model Class Initialized
INFO - 2023-12-11 06:57:35 --> Model Class Initialized
INFO - 2023-12-11 06:57:35 --> Model Class Initialized
INFO - 2023-12-11 06:57:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-11 06:57:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-11 06:57:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-11 06:57:36 --> Final output sent to browser
DEBUG - 2023-12-11 06:57:36 --> Total execution time: 0.1465
ERROR - 2023-12-11 06:57:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 06:57:36 --> Config Class Initialized
INFO - 2023-12-11 06:57:36 --> Hooks Class Initialized
DEBUG - 2023-12-11 06:57:36 --> UTF-8 Support Enabled
INFO - 2023-12-11 06:57:36 --> Utf8 Class Initialized
INFO - 2023-12-11 06:57:36 --> URI Class Initialized
INFO - 2023-12-11 06:57:36 --> Router Class Initialized
INFO - 2023-12-11 06:57:36 --> Output Class Initialized
INFO - 2023-12-11 06:57:36 --> Security Class Initialized
DEBUG - 2023-12-11 06:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 06:57:36 --> Input Class Initialized
INFO - 2023-12-11 06:57:36 --> Language Class Initialized
INFO - 2023-12-11 06:57:36 --> Loader Class Initialized
INFO - 2023-12-11 06:57:36 --> Helper loaded: url_helper
INFO - 2023-12-11 06:57:36 --> Helper loaded: file_helper
INFO - 2023-12-11 06:57:36 --> Helper loaded: html_helper
INFO - 2023-12-11 06:57:36 --> Helper loaded: text_helper
INFO - 2023-12-11 06:57:36 --> Helper loaded: form_helper
INFO - 2023-12-11 06:57:36 --> Helper loaded: lang_helper
INFO - 2023-12-11 06:57:36 --> Helper loaded: security_helper
INFO - 2023-12-11 06:57:36 --> Helper loaded: cookie_helper
INFO - 2023-12-11 06:57:36 --> Database Driver Class Initialized
INFO - 2023-12-11 06:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 06:57:36 --> Parser Class Initialized
INFO - 2023-12-11 06:57:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 06:57:36 --> Pagination Class Initialized
INFO - 2023-12-11 06:57:36 --> Form Validation Class Initialized
INFO - 2023-12-11 06:57:36 --> Controller Class Initialized
INFO - 2023-12-11 06:57:36 --> Model Class Initialized
DEBUG - 2023-12-11 06:57:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-11 06:57:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 06:57:36 --> Model Class Initialized
DEBUG - 2023-12-11 06:57:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 06:57:36 --> Model Class Initialized
INFO - 2023-12-11 06:57:36 --> Final output sent to browser
DEBUG - 2023-12-11 06:57:36 --> Total execution time: 0.0369
ERROR - 2023-12-11 06:58:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 06:58:09 --> Config Class Initialized
INFO - 2023-12-11 06:58:09 --> Hooks Class Initialized
DEBUG - 2023-12-11 06:58:09 --> UTF-8 Support Enabled
INFO - 2023-12-11 06:58:09 --> Utf8 Class Initialized
INFO - 2023-12-11 06:58:09 --> URI Class Initialized
INFO - 2023-12-11 06:58:09 --> Router Class Initialized
INFO - 2023-12-11 06:58:09 --> Output Class Initialized
INFO - 2023-12-11 06:58:09 --> Security Class Initialized
DEBUG - 2023-12-11 06:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 06:58:09 --> Input Class Initialized
INFO - 2023-12-11 06:58:09 --> Language Class Initialized
INFO - 2023-12-11 06:58:09 --> Loader Class Initialized
INFO - 2023-12-11 06:58:09 --> Helper loaded: url_helper
INFO - 2023-12-11 06:58:09 --> Helper loaded: file_helper
INFO - 2023-12-11 06:58:09 --> Helper loaded: html_helper
INFO - 2023-12-11 06:58:09 --> Helper loaded: text_helper
INFO - 2023-12-11 06:58:09 --> Helper loaded: form_helper
INFO - 2023-12-11 06:58:09 --> Helper loaded: lang_helper
INFO - 2023-12-11 06:58:09 --> Helper loaded: security_helper
INFO - 2023-12-11 06:58:09 --> Helper loaded: cookie_helper
INFO - 2023-12-11 06:58:09 --> Database Driver Class Initialized
INFO - 2023-12-11 06:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 06:58:09 --> Parser Class Initialized
INFO - 2023-12-11 06:58:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 06:58:09 --> Pagination Class Initialized
INFO - 2023-12-11 06:58:09 --> Form Validation Class Initialized
INFO - 2023-12-11 06:58:09 --> Controller Class Initialized
INFO - 2023-12-11 06:58:09 --> Model Class Initialized
DEBUG - 2023-12-11 06:58:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-11 06:58:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 06:58:09 --> Model Class Initialized
DEBUG - 2023-12-11 06:58:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 06:58:09 --> Model Class Initialized
DEBUG - 2023-12-11 06:58:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 06:58:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-12-11 06:58:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-11 06:58:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-11 06:58:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-11 06:58:09 --> Model Class Initialized
INFO - 2023-12-11 06:58:09 --> Model Class Initialized
INFO - 2023-12-11 06:58:09 --> Model Class Initialized
INFO - 2023-12-11 06:58:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-11 06:58:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-11 06:58:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-11 06:58:09 --> Final output sent to browser
DEBUG - 2023-12-11 06:58:09 --> Total execution time: 0.1445
ERROR - 2023-12-11 10:53:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 10:53:57 --> Config Class Initialized
INFO - 2023-12-11 10:53:57 --> Hooks Class Initialized
DEBUG - 2023-12-11 10:53:57 --> UTF-8 Support Enabled
INFO - 2023-12-11 10:53:57 --> Utf8 Class Initialized
INFO - 2023-12-11 10:53:57 --> URI Class Initialized
DEBUG - 2023-12-11 10:53:57 --> No URI present. Default controller set.
INFO - 2023-12-11 10:53:57 --> Router Class Initialized
INFO - 2023-12-11 10:53:57 --> Output Class Initialized
INFO - 2023-12-11 10:53:57 --> Security Class Initialized
DEBUG - 2023-12-11 10:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 10:53:57 --> Input Class Initialized
INFO - 2023-12-11 10:53:57 --> Language Class Initialized
INFO - 2023-12-11 10:53:57 --> Loader Class Initialized
INFO - 2023-12-11 10:53:57 --> Helper loaded: url_helper
INFO - 2023-12-11 10:53:57 --> Helper loaded: file_helper
INFO - 2023-12-11 10:53:57 --> Helper loaded: html_helper
INFO - 2023-12-11 10:53:57 --> Helper loaded: text_helper
INFO - 2023-12-11 10:53:57 --> Helper loaded: form_helper
INFO - 2023-12-11 10:53:57 --> Helper loaded: lang_helper
INFO - 2023-12-11 10:53:57 --> Helper loaded: security_helper
INFO - 2023-12-11 10:53:57 --> Helper loaded: cookie_helper
INFO - 2023-12-11 10:53:57 --> Database Driver Class Initialized
INFO - 2023-12-11 10:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 10:53:57 --> Parser Class Initialized
INFO - 2023-12-11 10:53:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 10:53:57 --> Pagination Class Initialized
INFO - 2023-12-11 10:53:57 --> Form Validation Class Initialized
INFO - 2023-12-11 10:53:57 --> Controller Class Initialized
INFO - 2023-12-11 10:53:57 --> Model Class Initialized
DEBUG - 2023-12-11 10:53:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-11 10:53:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 10:53:57 --> Config Class Initialized
INFO - 2023-12-11 10:53:57 --> Hooks Class Initialized
DEBUG - 2023-12-11 10:53:57 --> UTF-8 Support Enabled
INFO - 2023-12-11 10:53:57 --> Utf8 Class Initialized
INFO - 2023-12-11 10:53:57 --> URI Class Initialized
INFO - 2023-12-11 10:53:57 --> Router Class Initialized
INFO - 2023-12-11 10:53:57 --> Output Class Initialized
INFO - 2023-12-11 10:53:57 --> Security Class Initialized
DEBUG - 2023-12-11 10:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 10:53:57 --> Input Class Initialized
INFO - 2023-12-11 10:53:57 --> Language Class Initialized
INFO - 2023-12-11 10:53:57 --> Loader Class Initialized
INFO - 2023-12-11 10:53:57 --> Helper loaded: url_helper
INFO - 2023-12-11 10:53:57 --> Helper loaded: file_helper
INFO - 2023-12-11 10:53:57 --> Helper loaded: html_helper
INFO - 2023-12-11 10:53:57 --> Helper loaded: text_helper
INFO - 2023-12-11 10:53:57 --> Helper loaded: form_helper
INFO - 2023-12-11 10:53:57 --> Helper loaded: lang_helper
INFO - 2023-12-11 10:53:57 --> Helper loaded: security_helper
INFO - 2023-12-11 10:53:57 --> Helper loaded: cookie_helper
INFO - 2023-12-11 10:53:57 --> Database Driver Class Initialized
INFO - 2023-12-11 10:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 10:53:57 --> Parser Class Initialized
INFO - 2023-12-11 10:53:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 10:53:57 --> Pagination Class Initialized
INFO - 2023-12-11 10:53:57 --> Form Validation Class Initialized
INFO - 2023-12-11 10:53:57 --> Controller Class Initialized
INFO - 2023-12-11 10:53:57 --> Model Class Initialized
DEBUG - 2023-12-11 10:53:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 10:53:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-11 10:53:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-11 10:53:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-11 10:53:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-11 10:53:57 --> Model Class Initialized
INFO - 2023-12-11 10:53:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-11 10:53:57 --> Final output sent to browser
DEBUG - 2023-12-11 10:53:57 --> Total execution time: 0.0343
ERROR - 2023-12-11 10:54:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 10:54:59 --> Config Class Initialized
INFO - 2023-12-11 10:54:59 --> Hooks Class Initialized
DEBUG - 2023-12-11 10:54:59 --> UTF-8 Support Enabled
INFO - 2023-12-11 10:54:59 --> Utf8 Class Initialized
INFO - 2023-12-11 10:54:59 --> URI Class Initialized
DEBUG - 2023-12-11 10:54:59 --> No URI present. Default controller set.
INFO - 2023-12-11 10:54:59 --> Router Class Initialized
INFO - 2023-12-11 10:54:59 --> Output Class Initialized
INFO - 2023-12-11 10:54:59 --> Security Class Initialized
DEBUG - 2023-12-11 10:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 10:54:59 --> Input Class Initialized
INFO - 2023-12-11 10:54:59 --> Language Class Initialized
INFO - 2023-12-11 10:54:59 --> Loader Class Initialized
INFO - 2023-12-11 10:54:59 --> Helper loaded: url_helper
INFO - 2023-12-11 10:54:59 --> Helper loaded: file_helper
INFO - 2023-12-11 10:54:59 --> Helper loaded: html_helper
INFO - 2023-12-11 10:54:59 --> Helper loaded: text_helper
INFO - 2023-12-11 10:54:59 --> Helper loaded: form_helper
INFO - 2023-12-11 10:54:59 --> Helper loaded: lang_helper
INFO - 2023-12-11 10:54:59 --> Helper loaded: security_helper
INFO - 2023-12-11 10:54:59 --> Helper loaded: cookie_helper
INFO - 2023-12-11 10:54:59 --> Database Driver Class Initialized
INFO - 2023-12-11 10:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 10:54:59 --> Parser Class Initialized
INFO - 2023-12-11 10:54:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 10:54:59 --> Pagination Class Initialized
INFO - 2023-12-11 10:54:59 --> Form Validation Class Initialized
INFO - 2023-12-11 10:54:59 --> Controller Class Initialized
INFO - 2023-12-11 10:54:59 --> Model Class Initialized
DEBUG - 2023-12-11 10:54:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-11 10:55:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 10:55:00 --> Config Class Initialized
INFO - 2023-12-11 10:55:00 --> Hooks Class Initialized
DEBUG - 2023-12-11 10:55:00 --> UTF-8 Support Enabled
INFO - 2023-12-11 10:55:00 --> Utf8 Class Initialized
INFO - 2023-12-11 10:55:00 --> URI Class Initialized
INFO - 2023-12-11 10:55:00 --> Router Class Initialized
INFO - 2023-12-11 10:55:00 --> Output Class Initialized
INFO - 2023-12-11 10:55:00 --> Security Class Initialized
DEBUG - 2023-12-11 10:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 10:55:00 --> Input Class Initialized
INFO - 2023-12-11 10:55:00 --> Language Class Initialized
INFO - 2023-12-11 10:55:00 --> Loader Class Initialized
INFO - 2023-12-11 10:55:00 --> Helper loaded: url_helper
INFO - 2023-12-11 10:55:00 --> Helper loaded: file_helper
INFO - 2023-12-11 10:55:00 --> Helper loaded: html_helper
INFO - 2023-12-11 10:55:00 --> Helper loaded: text_helper
INFO - 2023-12-11 10:55:00 --> Helper loaded: form_helper
INFO - 2023-12-11 10:55:00 --> Helper loaded: lang_helper
INFO - 2023-12-11 10:55:00 --> Helper loaded: security_helper
INFO - 2023-12-11 10:55:00 --> Helper loaded: cookie_helper
INFO - 2023-12-11 10:55:00 --> Database Driver Class Initialized
INFO - 2023-12-11 10:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 10:55:00 --> Parser Class Initialized
INFO - 2023-12-11 10:55:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 10:55:00 --> Pagination Class Initialized
INFO - 2023-12-11 10:55:00 --> Form Validation Class Initialized
INFO - 2023-12-11 10:55:00 --> Controller Class Initialized
INFO - 2023-12-11 10:55:00 --> Model Class Initialized
DEBUG - 2023-12-11 10:55:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-11 10:55:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-11 10:55:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-11 10:55:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-11 10:55:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-11 10:55:00 --> Model Class Initialized
INFO - 2023-12-11 10:55:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-11 10:55:00 --> Final output sent to browser
DEBUG - 2023-12-11 10:55:00 --> Total execution time: 0.0282
ERROR - 2023-12-11 13:32:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 13:32:27 --> Config Class Initialized
INFO - 2023-12-11 13:32:27 --> Hooks Class Initialized
DEBUG - 2023-12-11 13:32:27 --> UTF-8 Support Enabled
INFO - 2023-12-11 13:32:27 --> Utf8 Class Initialized
INFO - 2023-12-11 13:32:27 --> URI Class Initialized
DEBUG - 2023-12-11 13:32:27 --> No URI present. Default controller set.
INFO - 2023-12-11 13:32:27 --> Router Class Initialized
INFO - 2023-12-11 13:32:27 --> Output Class Initialized
INFO - 2023-12-11 13:32:27 --> Security Class Initialized
DEBUG - 2023-12-11 13:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 13:32:27 --> Input Class Initialized
INFO - 2023-12-11 13:32:27 --> Language Class Initialized
INFO - 2023-12-11 13:32:27 --> Loader Class Initialized
INFO - 2023-12-11 13:32:27 --> Helper loaded: url_helper
INFO - 2023-12-11 13:32:27 --> Helper loaded: file_helper
INFO - 2023-12-11 13:32:27 --> Helper loaded: html_helper
INFO - 2023-12-11 13:32:27 --> Helper loaded: text_helper
INFO - 2023-12-11 13:32:27 --> Helper loaded: form_helper
INFO - 2023-12-11 13:32:27 --> Helper loaded: lang_helper
INFO - 2023-12-11 13:32:27 --> Helper loaded: security_helper
INFO - 2023-12-11 13:32:27 --> Helper loaded: cookie_helper
INFO - 2023-12-11 13:32:27 --> Database Driver Class Initialized
INFO - 2023-12-11 13:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-11 13:32:27 --> Parser Class Initialized
INFO - 2023-12-11 13:32:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-11 13:32:27 --> Pagination Class Initialized
INFO - 2023-12-11 13:32:27 --> Form Validation Class Initialized
INFO - 2023-12-11 13:32:27 --> Controller Class Initialized
INFO - 2023-12-11 13:32:27 --> Model Class Initialized
DEBUG - 2023-12-11 13:32:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-11 15:46:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-11 15:46:20 --> Config Class Initialized
INFO - 2023-12-11 15:46:20 --> Hooks Class Initialized
DEBUG - 2023-12-11 15:46:20 --> UTF-8 Support Enabled
INFO - 2023-12-11 15:46:20 --> Utf8 Class Initialized
INFO - 2023-12-11 15:46:20 --> URI Class Initialized
INFO - 2023-12-11 15:46:20 --> Router Class Initialized
INFO - 2023-12-11 15:46:20 --> Output Class Initialized
INFO - 2023-12-11 15:46:20 --> Security Class Initialized
DEBUG - 2023-12-11 15:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-11 15:46:20 --> Input Class Initialized
INFO - 2023-12-11 15:46:20 --> Language Class Initialized
ERROR - 2023-12-11 15:46:20 --> 404 Page Not Found: Well-known/assetlinks.json
