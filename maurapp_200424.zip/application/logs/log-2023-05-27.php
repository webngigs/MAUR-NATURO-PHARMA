<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-27 02:19:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 02:19:21 --> Config Class Initialized
INFO - 2023-05-27 02:19:21 --> Hooks Class Initialized
DEBUG - 2023-05-27 02:19:21 --> UTF-8 Support Enabled
INFO - 2023-05-27 02:19:21 --> Utf8 Class Initialized
INFO - 2023-05-27 02:19:21 --> URI Class Initialized
DEBUG - 2023-05-27 02:19:21 --> No URI present. Default controller set.
INFO - 2023-05-27 02:19:21 --> Router Class Initialized
INFO - 2023-05-27 02:19:21 --> Output Class Initialized
INFO - 2023-05-27 02:19:21 --> Security Class Initialized
DEBUG - 2023-05-27 02:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 02:19:21 --> Input Class Initialized
INFO - 2023-05-27 02:19:21 --> Language Class Initialized
INFO - 2023-05-27 02:19:21 --> Loader Class Initialized
INFO - 2023-05-27 02:19:21 --> Helper loaded: url_helper
INFO - 2023-05-27 02:19:21 --> Helper loaded: file_helper
INFO - 2023-05-27 02:19:21 --> Helper loaded: html_helper
INFO - 2023-05-27 02:19:21 --> Helper loaded: text_helper
INFO - 2023-05-27 02:19:21 --> Helper loaded: form_helper
INFO - 2023-05-27 02:19:21 --> Helper loaded: lang_helper
INFO - 2023-05-27 02:19:21 --> Helper loaded: security_helper
INFO - 2023-05-27 02:19:21 --> Helper loaded: cookie_helper
INFO - 2023-05-27 02:19:21 --> Database Driver Class Initialized
INFO - 2023-05-27 02:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 02:19:21 --> Parser Class Initialized
INFO - 2023-05-27 02:19:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 02:19:21 --> Pagination Class Initialized
INFO - 2023-05-27 02:19:21 --> Form Validation Class Initialized
INFO - 2023-05-27 02:19:21 --> Controller Class Initialized
INFO - 2023-05-27 02:19:21 --> Model Class Initialized
DEBUG - 2023-05-27 02:19:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-27 02:19:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 02:19:22 --> Config Class Initialized
INFO - 2023-05-27 02:19:22 --> Hooks Class Initialized
DEBUG - 2023-05-27 02:19:22 --> UTF-8 Support Enabled
INFO - 2023-05-27 02:19:22 --> Utf8 Class Initialized
INFO - 2023-05-27 02:19:22 --> URI Class Initialized
DEBUG - 2023-05-27 02:19:22 --> No URI present. Default controller set.
INFO - 2023-05-27 02:19:22 --> Router Class Initialized
INFO - 2023-05-27 02:19:22 --> Output Class Initialized
INFO - 2023-05-27 02:19:22 --> Security Class Initialized
DEBUG - 2023-05-27 02:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 02:19:22 --> Input Class Initialized
INFO - 2023-05-27 02:19:22 --> Language Class Initialized
INFO - 2023-05-27 02:19:22 --> Loader Class Initialized
INFO - 2023-05-27 02:19:22 --> Helper loaded: url_helper
INFO - 2023-05-27 02:19:22 --> Helper loaded: file_helper
INFO - 2023-05-27 02:19:22 --> Helper loaded: html_helper
INFO - 2023-05-27 02:19:22 --> Helper loaded: text_helper
INFO - 2023-05-27 02:19:22 --> Helper loaded: form_helper
INFO - 2023-05-27 02:19:22 --> Helper loaded: lang_helper
INFO - 2023-05-27 02:19:22 --> Helper loaded: security_helper
INFO - 2023-05-27 02:19:22 --> Helper loaded: cookie_helper
INFO - 2023-05-27 02:19:22 --> Database Driver Class Initialized
INFO - 2023-05-27 02:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 02:19:22 --> Parser Class Initialized
INFO - 2023-05-27 02:19:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 02:19:22 --> Pagination Class Initialized
INFO - 2023-05-27 02:19:22 --> Form Validation Class Initialized
INFO - 2023-05-27 02:19:22 --> Controller Class Initialized
INFO - 2023-05-27 02:19:22 --> Model Class Initialized
DEBUG - 2023-05-27 02:19:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-27 02:19:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 02:19:22 --> Config Class Initialized
INFO - 2023-05-27 02:19:22 --> Hooks Class Initialized
DEBUG - 2023-05-27 02:19:22 --> UTF-8 Support Enabled
INFO - 2023-05-27 02:19:22 --> Utf8 Class Initialized
INFO - 2023-05-27 02:19:22 --> URI Class Initialized
DEBUG - 2023-05-27 02:19:22 --> No URI present. Default controller set.
INFO - 2023-05-27 02:19:22 --> Router Class Initialized
INFO - 2023-05-27 02:19:22 --> Output Class Initialized
INFO - 2023-05-27 02:19:22 --> Security Class Initialized
DEBUG - 2023-05-27 02:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 02:19:22 --> Input Class Initialized
INFO - 2023-05-27 02:19:22 --> Language Class Initialized
INFO - 2023-05-27 02:19:22 --> Loader Class Initialized
INFO - 2023-05-27 02:19:22 --> Helper loaded: url_helper
INFO - 2023-05-27 02:19:22 --> Helper loaded: file_helper
INFO - 2023-05-27 02:19:22 --> Helper loaded: html_helper
INFO - 2023-05-27 02:19:22 --> Helper loaded: text_helper
INFO - 2023-05-27 02:19:22 --> Helper loaded: form_helper
INFO - 2023-05-27 02:19:22 --> Helper loaded: lang_helper
INFO - 2023-05-27 02:19:22 --> Helper loaded: security_helper
INFO - 2023-05-27 02:19:22 --> Helper loaded: cookie_helper
INFO - 2023-05-27 02:19:22 --> Database Driver Class Initialized
INFO - 2023-05-27 02:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 02:19:22 --> Parser Class Initialized
INFO - 2023-05-27 02:19:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 02:19:22 --> Pagination Class Initialized
INFO - 2023-05-27 02:19:22 --> Form Validation Class Initialized
INFO - 2023-05-27 02:19:22 --> Controller Class Initialized
INFO - 2023-05-27 02:19:22 --> Model Class Initialized
DEBUG - 2023-05-27 02:19:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-27 02:19:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 02:19:23 --> Config Class Initialized
INFO - 2023-05-27 02:19:23 --> Hooks Class Initialized
DEBUG - 2023-05-27 02:19:23 --> UTF-8 Support Enabled
INFO - 2023-05-27 02:19:23 --> Utf8 Class Initialized
INFO - 2023-05-27 02:19:23 --> URI Class Initialized
DEBUG - 2023-05-27 02:19:23 --> No URI present. Default controller set.
INFO - 2023-05-27 02:19:23 --> Router Class Initialized
INFO - 2023-05-27 02:19:23 --> Output Class Initialized
INFO - 2023-05-27 02:19:23 --> Security Class Initialized
DEBUG - 2023-05-27 02:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 02:19:23 --> Input Class Initialized
INFO - 2023-05-27 02:19:23 --> Language Class Initialized
INFO - 2023-05-27 02:19:23 --> Loader Class Initialized
INFO - 2023-05-27 02:19:23 --> Helper loaded: url_helper
INFO - 2023-05-27 02:19:23 --> Helper loaded: file_helper
INFO - 2023-05-27 02:19:23 --> Helper loaded: html_helper
INFO - 2023-05-27 02:19:23 --> Helper loaded: text_helper
INFO - 2023-05-27 02:19:23 --> Helper loaded: form_helper
INFO - 2023-05-27 02:19:23 --> Helper loaded: lang_helper
INFO - 2023-05-27 02:19:23 --> Helper loaded: security_helper
INFO - 2023-05-27 02:19:23 --> Helper loaded: cookie_helper
INFO - 2023-05-27 02:19:23 --> Database Driver Class Initialized
INFO - 2023-05-27 02:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 02:19:23 --> Parser Class Initialized
INFO - 2023-05-27 02:19:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 02:19:23 --> Pagination Class Initialized
INFO - 2023-05-27 02:19:23 --> Form Validation Class Initialized
INFO - 2023-05-27 02:19:23 --> Controller Class Initialized
INFO - 2023-05-27 02:19:23 --> Model Class Initialized
DEBUG - 2023-05-27 02:19:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-27 05:39:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 05:39:17 --> Config Class Initialized
INFO - 2023-05-27 05:39:17 --> Hooks Class Initialized
DEBUG - 2023-05-27 05:39:17 --> UTF-8 Support Enabled
INFO - 2023-05-27 05:39:17 --> Utf8 Class Initialized
INFO - 2023-05-27 05:39:17 --> URI Class Initialized
INFO - 2023-05-27 05:39:17 --> Router Class Initialized
INFO - 2023-05-27 05:39:17 --> Output Class Initialized
INFO - 2023-05-27 05:39:17 --> Security Class Initialized
DEBUG - 2023-05-27 05:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 05:39:17 --> Input Class Initialized
INFO - 2023-05-27 05:39:17 --> Language Class Initialized
INFO - 2023-05-27 05:39:17 --> Loader Class Initialized
INFO - 2023-05-27 05:39:17 --> Helper loaded: url_helper
INFO - 2023-05-27 05:39:17 --> Helper loaded: file_helper
INFO - 2023-05-27 05:39:17 --> Helper loaded: html_helper
INFO - 2023-05-27 05:39:17 --> Helper loaded: text_helper
INFO - 2023-05-27 05:39:17 --> Helper loaded: form_helper
INFO - 2023-05-27 05:39:17 --> Helper loaded: lang_helper
INFO - 2023-05-27 05:39:17 --> Helper loaded: security_helper
INFO - 2023-05-27 05:39:17 --> Helper loaded: cookie_helper
INFO - 2023-05-27 05:39:17 --> Database Driver Class Initialized
INFO - 2023-05-27 05:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 05:39:17 --> Parser Class Initialized
INFO - 2023-05-27 05:39:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 05:39:17 --> Pagination Class Initialized
INFO - 2023-05-27 05:39:17 --> Form Validation Class Initialized
INFO - 2023-05-27 05:39:17 --> Controller Class Initialized
ERROR - 2023-05-27 05:39:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 05:39:17 --> Config Class Initialized
INFO - 2023-05-27 05:39:17 --> Hooks Class Initialized
DEBUG - 2023-05-27 05:39:17 --> UTF-8 Support Enabled
INFO - 2023-05-27 05:39:17 --> Utf8 Class Initialized
INFO - 2023-05-27 05:39:17 --> URI Class Initialized
INFO - 2023-05-27 05:39:17 --> Router Class Initialized
INFO - 2023-05-27 05:39:17 --> Output Class Initialized
INFO - 2023-05-27 05:39:17 --> Security Class Initialized
DEBUG - 2023-05-27 05:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 05:39:17 --> Input Class Initialized
INFO - 2023-05-27 05:39:17 --> Language Class Initialized
INFO - 2023-05-27 05:39:17 --> Loader Class Initialized
INFO - 2023-05-27 05:39:17 --> Helper loaded: url_helper
INFO - 2023-05-27 05:39:17 --> Helper loaded: file_helper
INFO - 2023-05-27 05:39:17 --> Helper loaded: html_helper
INFO - 2023-05-27 05:39:17 --> Helper loaded: text_helper
INFO - 2023-05-27 05:39:17 --> Helper loaded: form_helper
INFO - 2023-05-27 05:39:17 --> Helper loaded: lang_helper
INFO - 2023-05-27 05:39:17 --> Helper loaded: security_helper
INFO - 2023-05-27 05:39:17 --> Helper loaded: cookie_helper
INFO - 2023-05-27 05:39:17 --> Database Driver Class Initialized
INFO - 2023-05-27 05:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 05:39:17 --> Parser Class Initialized
INFO - 2023-05-27 05:39:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 05:39:17 --> Pagination Class Initialized
INFO - 2023-05-27 05:39:17 --> Form Validation Class Initialized
INFO - 2023-05-27 05:39:17 --> Controller Class Initialized
INFO - 2023-05-27 05:39:17 --> Model Class Initialized
DEBUG - 2023-05-27 05:39:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 05:39:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-27 05:39:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-27 05:39:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-27 05:39:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-27 05:39:17 --> Model Class Initialized
INFO - 2023-05-27 05:39:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-27 05:39:17 --> Final output sent to browser
DEBUG - 2023-05-27 05:39:17 --> Total execution time: 0.0370
ERROR - 2023-05-27 05:39:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 05:39:22 --> Config Class Initialized
INFO - 2023-05-27 05:39:22 --> Hooks Class Initialized
DEBUG - 2023-05-27 05:39:22 --> UTF-8 Support Enabled
INFO - 2023-05-27 05:39:22 --> Utf8 Class Initialized
INFO - 2023-05-27 05:39:22 --> URI Class Initialized
INFO - 2023-05-27 05:39:22 --> Router Class Initialized
INFO - 2023-05-27 05:39:22 --> Output Class Initialized
INFO - 2023-05-27 05:39:22 --> Security Class Initialized
DEBUG - 2023-05-27 05:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 05:39:22 --> Input Class Initialized
INFO - 2023-05-27 05:39:22 --> Language Class Initialized
INFO - 2023-05-27 05:39:22 --> Loader Class Initialized
INFO - 2023-05-27 05:39:22 --> Helper loaded: url_helper
INFO - 2023-05-27 05:39:22 --> Helper loaded: file_helper
INFO - 2023-05-27 05:39:22 --> Helper loaded: html_helper
INFO - 2023-05-27 05:39:22 --> Helper loaded: text_helper
INFO - 2023-05-27 05:39:22 --> Helper loaded: form_helper
INFO - 2023-05-27 05:39:22 --> Helper loaded: lang_helper
INFO - 2023-05-27 05:39:22 --> Helper loaded: security_helper
INFO - 2023-05-27 05:39:22 --> Helper loaded: cookie_helper
INFO - 2023-05-27 05:39:22 --> Database Driver Class Initialized
INFO - 2023-05-27 05:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 05:39:22 --> Parser Class Initialized
INFO - 2023-05-27 05:39:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 05:39:22 --> Pagination Class Initialized
INFO - 2023-05-27 05:39:22 --> Form Validation Class Initialized
INFO - 2023-05-27 05:39:22 --> Controller Class Initialized
INFO - 2023-05-27 05:39:22 --> Model Class Initialized
DEBUG - 2023-05-27 05:39:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 05:39:22 --> Model Class Initialized
INFO - 2023-05-27 05:39:22 --> Final output sent to browser
DEBUG - 2023-05-27 05:39:22 --> Total execution time: 0.0204
ERROR - 2023-05-27 05:39:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 05:39:23 --> Config Class Initialized
INFO - 2023-05-27 05:39:23 --> Hooks Class Initialized
DEBUG - 2023-05-27 05:39:23 --> UTF-8 Support Enabled
INFO - 2023-05-27 05:39:23 --> Utf8 Class Initialized
INFO - 2023-05-27 05:39:23 --> URI Class Initialized
DEBUG - 2023-05-27 05:39:23 --> No URI present. Default controller set.
INFO - 2023-05-27 05:39:23 --> Router Class Initialized
INFO - 2023-05-27 05:39:23 --> Output Class Initialized
INFO - 2023-05-27 05:39:23 --> Security Class Initialized
DEBUG - 2023-05-27 05:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 05:39:23 --> Input Class Initialized
INFO - 2023-05-27 05:39:23 --> Language Class Initialized
INFO - 2023-05-27 05:39:23 --> Loader Class Initialized
INFO - 2023-05-27 05:39:23 --> Helper loaded: url_helper
INFO - 2023-05-27 05:39:23 --> Helper loaded: file_helper
INFO - 2023-05-27 05:39:23 --> Helper loaded: html_helper
INFO - 2023-05-27 05:39:23 --> Helper loaded: text_helper
INFO - 2023-05-27 05:39:23 --> Helper loaded: form_helper
INFO - 2023-05-27 05:39:23 --> Helper loaded: lang_helper
INFO - 2023-05-27 05:39:23 --> Helper loaded: security_helper
INFO - 2023-05-27 05:39:23 --> Helper loaded: cookie_helper
INFO - 2023-05-27 05:39:23 --> Database Driver Class Initialized
INFO - 2023-05-27 05:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 05:39:23 --> Parser Class Initialized
INFO - 2023-05-27 05:39:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 05:39:23 --> Pagination Class Initialized
INFO - 2023-05-27 05:39:23 --> Form Validation Class Initialized
INFO - 2023-05-27 05:39:23 --> Controller Class Initialized
INFO - 2023-05-27 05:39:23 --> Model Class Initialized
DEBUG - 2023-05-27 05:39:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 05:39:23 --> Model Class Initialized
DEBUG - 2023-05-27 05:39:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 05:39:23 --> Model Class Initialized
INFO - 2023-05-27 05:39:23 --> Model Class Initialized
INFO - 2023-05-27 05:39:23 --> Model Class Initialized
INFO - 2023-05-27 05:39:23 --> Model Class Initialized
DEBUG - 2023-05-27 05:39:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-27 05:39:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 05:39:23 --> Model Class Initialized
INFO - 2023-05-27 05:39:23 --> Model Class Initialized
INFO - 2023-05-27 05:39:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-27 05:39:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-27 05:39:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-27 05:39:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-27 05:39:23 --> Model Class Initialized
INFO - 2023-05-27 05:39:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-27 05:39:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-27 05:39:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-27 05:39:23 --> Final output sent to browser
DEBUG - 2023-05-27 05:39:23 --> Total execution time: 0.0936
ERROR - 2023-05-27 06:30:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 06:30:47 --> Config Class Initialized
INFO - 2023-05-27 06:30:47 --> Hooks Class Initialized
DEBUG - 2023-05-27 06:30:47 --> UTF-8 Support Enabled
INFO - 2023-05-27 06:30:47 --> Utf8 Class Initialized
INFO - 2023-05-27 06:30:47 --> URI Class Initialized
DEBUG - 2023-05-27 06:30:47 --> No URI present. Default controller set.
INFO - 2023-05-27 06:30:47 --> Router Class Initialized
INFO - 2023-05-27 06:30:47 --> Output Class Initialized
INFO - 2023-05-27 06:30:47 --> Security Class Initialized
DEBUG - 2023-05-27 06:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 06:30:47 --> Input Class Initialized
INFO - 2023-05-27 06:30:47 --> Language Class Initialized
INFO - 2023-05-27 06:30:47 --> Loader Class Initialized
INFO - 2023-05-27 06:30:47 --> Helper loaded: url_helper
INFO - 2023-05-27 06:30:47 --> Helper loaded: file_helper
INFO - 2023-05-27 06:30:47 --> Helper loaded: html_helper
INFO - 2023-05-27 06:30:47 --> Helper loaded: text_helper
INFO - 2023-05-27 06:30:47 --> Helper loaded: form_helper
INFO - 2023-05-27 06:30:47 --> Helper loaded: lang_helper
INFO - 2023-05-27 06:30:47 --> Helper loaded: security_helper
INFO - 2023-05-27 06:30:47 --> Helper loaded: cookie_helper
INFO - 2023-05-27 06:30:47 --> Database Driver Class Initialized
INFO - 2023-05-27 06:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 06:30:47 --> Parser Class Initialized
INFO - 2023-05-27 06:30:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 06:30:47 --> Pagination Class Initialized
INFO - 2023-05-27 06:30:47 --> Form Validation Class Initialized
INFO - 2023-05-27 06:30:47 --> Controller Class Initialized
INFO - 2023-05-27 06:30:47 --> Model Class Initialized
DEBUG - 2023-05-27 06:30:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 06:30:47 --> Model Class Initialized
DEBUG - 2023-05-27 06:30:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 06:30:47 --> Model Class Initialized
INFO - 2023-05-27 06:30:47 --> Model Class Initialized
INFO - 2023-05-27 06:30:47 --> Model Class Initialized
INFO - 2023-05-27 06:30:47 --> Model Class Initialized
DEBUG - 2023-05-27 06:30:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-27 06:30:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 06:30:47 --> Model Class Initialized
INFO - 2023-05-27 06:30:47 --> Model Class Initialized
INFO - 2023-05-27 06:30:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-27 06:30:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-27 06:30:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-27 06:30:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-27 06:30:47 --> Model Class Initialized
INFO - 2023-05-27 06:30:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-27 06:30:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-27 06:30:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-27 06:30:47 --> Final output sent to browser
DEBUG - 2023-05-27 06:30:47 --> Total execution time: 0.0874
ERROR - 2023-05-27 13:50:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 13:50:16 --> Config Class Initialized
INFO - 2023-05-27 13:50:16 --> Hooks Class Initialized
DEBUG - 2023-05-27 13:50:16 --> UTF-8 Support Enabled
INFO - 2023-05-27 13:50:16 --> Utf8 Class Initialized
INFO - 2023-05-27 13:50:16 --> URI Class Initialized
DEBUG - 2023-05-27 13:50:16 --> No URI present. Default controller set.
INFO - 2023-05-27 13:50:16 --> Router Class Initialized
INFO - 2023-05-27 13:50:16 --> Output Class Initialized
INFO - 2023-05-27 13:50:16 --> Security Class Initialized
DEBUG - 2023-05-27 13:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 13:50:16 --> Input Class Initialized
INFO - 2023-05-27 13:50:16 --> Language Class Initialized
INFO - 2023-05-27 13:50:16 --> Loader Class Initialized
INFO - 2023-05-27 13:50:16 --> Helper loaded: url_helper
INFO - 2023-05-27 13:50:16 --> Helper loaded: file_helper
INFO - 2023-05-27 13:50:16 --> Helper loaded: html_helper
INFO - 2023-05-27 13:50:16 --> Helper loaded: text_helper
INFO - 2023-05-27 13:50:16 --> Helper loaded: form_helper
INFO - 2023-05-27 13:50:16 --> Helper loaded: lang_helper
INFO - 2023-05-27 13:50:16 --> Helper loaded: security_helper
INFO - 2023-05-27 13:50:16 --> Helper loaded: cookie_helper
INFO - 2023-05-27 13:50:16 --> Database Driver Class Initialized
INFO - 2023-05-27 13:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 13:50:16 --> Parser Class Initialized
INFO - 2023-05-27 13:50:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 13:50:16 --> Pagination Class Initialized
INFO - 2023-05-27 13:50:16 --> Form Validation Class Initialized
INFO - 2023-05-27 13:50:16 --> Controller Class Initialized
INFO - 2023-05-27 13:50:16 --> Model Class Initialized
DEBUG - 2023-05-27 13:50:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-27 13:50:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 13:50:17 --> Config Class Initialized
INFO - 2023-05-27 13:50:17 --> Hooks Class Initialized
DEBUG - 2023-05-27 13:50:17 --> UTF-8 Support Enabled
INFO - 2023-05-27 13:50:17 --> Utf8 Class Initialized
INFO - 2023-05-27 13:50:17 --> URI Class Initialized
INFO - 2023-05-27 13:50:17 --> Router Class Initialized
INFO - 2023-05-27 13:50:17 --> Output Class Initialized
INFO - 2023-05-27 13:50:17 --> Security Class Initialized
DEBUG - 2023-05-27 13:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 13:50:17 --> Input Class Initialized
INFO - 2023-05-27 13:50:17 --> Language Class Initialized
INFO - 2023-05-27 13:50:17 --> Loader Class Initialized
INFO - 2023-05-27 13:50:17 --> Helper loaded: url_helper
INFO - 2023-05-27 13:50:17 --> Helper loaded: file_helper
INFO - 2023-05-27 13:50:17 --> Helper loaded: html_helper
INFO - 2023-05-27 13:50:17 --> Helper loaded: text_helper
INFO - 2023-05-27 13:50:17 --> Helper loaded: form_helper
INFO - 2023-05-27 13:50:17 --> Helper loaded: lang_helper
INFO - 2023-05-27 13:50:17 --> Helper loaded: security_helper
INFO - 2023-05-27 13:50:17 --> Helper loaded: cookie_helper
INFO - 2023-05-27 13:50:17 --> Database Driver Class Initialized
INFO - 2023-05-27 13:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 13:50:17 --> Parser Class Initialized
INFO - 2023-05-27 13:50:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 13:50:17 --> Pagination Class Initialized
INFO - 2023-05-27 13:50:17 --> Form Validation Class Initialized
INFO - 2023-05-27 13:50:17 --> Controller Class Initialized
INFO - 2023-05-27 13:50:17 --> Model Class Initialized
DEBUG - 2023-05-27 13:50:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 13:50:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-27 13:50:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-27 13:50:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-27 13:50:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-27 13:50:17 --> Model Class Initialized
INFO - 2023-05-27 13:50:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-27 13:50:17 --> Final output sent to browser
DEBUG - 2023-05-27 13:50:17 --> Total execution time: 0.0301
ERROR - 2023-05-27 13:50:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 13:50:40 --> Config Class Initialized
INFO - 2023-05-27 13:50:40 --> Hooks Class Initialized
DEBUG - 2023-05-27 13:50:40 --> UTF-8 Support Enabled
INFO - 2023-05-27 13:50:40 --> Utf8 Class Initialized
INFO - 2023-05-27 13:50:40 --> URI Class Initialized
INFO - 2023-05-27 13:50:40 --> Router Class Initialized
INFO - 2023-05-27 13:50:40 --> Output Class Initialized
INFO - 2023-05-27 13:50:40 --> Security Class Initialized
DEBUG - 2023-05-27 13:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 13:50:40 --> Input Class Initialized
INFO - 2023-05-27 13:50:40 --> Language Class Initialized
INFO - 2023-05-27 13:50:40 --> Loader Class Initialized
INFO - 2023-05-27 13:50:40 --> Helper loaded: url_helper
INFO - 2023-05-27 13:50:40 --> Helper loaded: file_helper
INFO - 2023-05-27 13:50:40 --> Helper loaded: html_helper
INFO - 2023-05-27 13:50:40 --> Helper loaded: text_helper
INFO - 2023-05-27 13:50:40 --> Helper loaded: form_helper
INFO - 2023-05-27 13:50:40 --> Helper loaded: lang_helper
INFO - 2023-05-27 13:50:40 --> Helper loaded: security_helper
INFO - 2023-05-27 13:50:40 --> Helper loaded: cookie_helper
INFO - 2023-05-27 13:50:40 --> Database Driver Class Initialized
INFO - 2023-05-27 13:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 13:50:40 --> Parser Class Initialized
INFO - 2023-05-27 13:50:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 13:50:40 --> Pagination Class Initialized
INFO - 2023-05-27 13:50:40 --> Form Validation Class Initialized
INFO - 2023-05-27 13:50:40 --> Controller Class Initialized
INFO - 2023-05-27 13:50:40 --> Model Class Initialized
DEBUG - 2023-05-27 13:50:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 13:50:40 --> Model Class Initialized
INFO - 2023-05-27 13:50:40 --> Final output sent to browser
DEBUG - 2023-05-27 13:50:40 --> Total execution time: 0.0202
ERROR - 2023-05-27 13:50:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 13:50:40 --> Config Class Initialized
INFO - 2023-05-27 13:50:40 --> Hooks Class Initialized
DEBUG - 2023-05-27 13:50:40 --> UTF-8 Support Enabled
INFO - 2023-05-27 13:50:40 --> Utf8 Class Initialized
INFO - 2023-05-27 13:50:40 --> URI Class Initialized
DEBUG - 2023-05-27 13:50:40 --> No URI present. Default controller set.
INFO - 2023-05-27 13:50:40 --> Router Class Initialized
INFO - 2023-05-27 13:50:40 --> Output Class Initialized
INFO - 2023-05-27 13:50:40 --> Security Class Initialized
DEBUG - 2023-05-27 13:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 13:50:40 --> Input Class Initialized
INFO - 2023-05-27 13:50:40 --> Language Class Initialized
INFO - 2023-05-27 13:50:40 --> Loader Class Initialized
INFO - 2023-05-27 13:50:40 --> Helper loaded: url_helper
INFO - 2023-05-27 13:50:40 --> Helper loaded: file_helper
INFO - 2023-05-27 13:50:40 --> Helper loaded: html_helper
INFO - 2023-05-27 13:50:40 --> Helper loaded: text_helper
INFO - 2023-05-27 13:50:40 --> Helper loaded: form_helper
INFO - 2023-05-27 13:50:40 --> Helper loaded: lang_helper
INFO - 2023-05-27 13:50:40 --> Helper loaded: security_helper
INFO - 2023-05-27 13:50:40 --> Helper loaded: cookie_helper
INFO - 2023-05-27 13:50:40 --> Database Driver Class Initialized
INFO - 2023-05-27 13:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 13:50:40 --> Parser Class Initialized
INFO - 2023-05-27 13:50:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 13:50:40 --> Pagination Class Initialized
INFO - 2023-05-27 13:50:40 --> Form Validation Class Initialized
INFO - 2023-05-27 13:50:40 --> Controller Class Initialized
INFO - 2023-05-27 13:50:40 --> Model Class Initialized
DEBUG - 2023-05-27 13:50:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 13:50:40 --> Model Class Initialized
DEBUG - 2023-05-27 13:50:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 13:50:40 --> Model Class Initialized
INFO - 2023-05-27 13:50:40 --> Model Class Initialized
INFO - 2023-05-27 13:50:40 --> Model Class Initialized
INFO - 2023-05-27 13:50:40 --> Model Class Initialized
DEBUG - 2023-05-27 13:50:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-27 13:50:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 13:50:40 --> Model Class Initialized
INFO - 2023-05-27 13:50:40 --> Model Class Initialized
INFO - 2023-05-27 13:50:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-27 13:50:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-27 13:50:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-27 13:50:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-27 13:50:40 --> Model Class Initialized
INFO - 2023-05-27 13:50:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-27 13:50:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-27 13:50:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-27 13:50:40 --> Final output sent to browser
DEBUG - 2023-05-27 13:50:40 --> Total execution time: 0.0823
ERROR - 2023-05-27 13:51:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 13:51:00 --> Config Class Initialized
INFO - 2023-05-27 13:51:00 --> Hooks Class Initialized
DEBUG - 2023-05-27 13:51:00 --> UTF-8 Support Enabled
INFO - 2023-05-27 13:51:00 --> Utf8 Class Initialized
INFO - 2023-05-27 13:51:00 --> URI Class Initialized
INFO - 2023-05-27 13:51:00 --> Router Class Initialized
INFO - 2023-05-27 13:51:00 --> Output Class Initialized
INFO - 2023-05-27 13:51:00 --> Security Class Initialized
DEBUG - 2023-05-27 13:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 13:51:00 --> Input Class Initialized
INFO - 2023-05-27 13:51:00 --> Language Class Initialized
INFO - 2023-05-27 13:51:00 --> Loader Class Initialized
INFO - 2023-05-27 13:51:00 --> Helper loaded: url_helper
INFO - 2023-05-27 13:51:00 --> Helper loaded: file_helper
INFO - 2023-05-27 13:51:00 --> Helper loaded: html_helper
INFO - 2023-05-27 13:51:00 --> Helper loaded: text_helper
INFO - 2023-05-27 13:51:00 --> Helper loaded: form_helper
INFO - 2023-05-27 13:51:00 --> Helper loaded: lang_helper
INFO - 2023-05-27 13:51:00 --> Helper loaded: security_helper
INFO - 2023-05-27 13:51:00 --> Helper loaded: cookie_helper
INFO - 2023-05-27 13:51:00 --> Database Driver Class Initialized
INFO - 2023-05-27 13:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 13:51:00 --> Parser Class Initialized
INFO - 2023-05-27 13:51:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 13:51:00 --> Pagination Class Initialized
INFO - 2023-05-27 13:51:00 --> Form Validation Class Initialized
INFO - 2023-05-27 13:51:00 --> Controller Class Initialized
INFO - 2023-05-27 13:51:00 --> Model Class Initialized
DEBUG - 2023-05-27 13:51:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-27 13:51:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 13:51:00 --> Model Class Initialized
INFO - 2023-05-27 13:51:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-05-27 13:51:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-27 13:51:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-27 13:51:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-27 13:51:00 --> Model Class Initialized
INFO - 2023-05-27 13:51:00 --> Model Class Initialized
INFO - 2023-05-27 13:51:00 --> Model Class Initialized
INFO - 2023-05-27 13:51:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-27 13:51:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-27 13:51:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-27 13:51:00 --> Final output sent to browser
DEBUG - 2023-05-27 13:51:00 --> Total execution time: 0.0669
ERROR - 2023-05-27 13:51:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 13:51:01 --> Config Class Initialized
INFO - 2023-05-27 13:51:01 --> Hooks Class Initialized
DEBUG - 2023-05-27 13:51:01 --> UTF-8 Support Enabled
INFO - 2023-05-27 13:51:01 --> Utf8 Class Initialized
INFO - 2023-05-27 13:51:01 --> URI Class Initialized
INFO - 2023-05-27 13:51:01 --> Router Class Initialized
INFO - 2023-05-27 13:51:01 --> Output Class Initialized
INFO - 2023-05-27 13:51:01 --> Security Class Initialized
DEBUG - 2023-05-27 13:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 13:51:01 --> Input Class Initialized
INFO - 2023-05-27 13:51:01 --> Language Class Initialized
INFO - 2023-05-27 13:51:01 --> Loader Class Initialized
INFO - 2023-05-27 13:51:01 --> Helper loaded: url_helper
INFO - 2023-05-27 13:51:01 --> Helper loaded: file_helper
INFO - 2023-05-27 13:51:01 --> Helper loaded: html_helper
INFO - 2023-05-27 13:51:01 --> Helper loaded: text_helper
INFO - 2023-05-27 13:51:01 --> Helper loaded: form_helper
INFO - 2023-05-27 13:51:01 --> Helper loaded: lang_helper
INFO - 2023-05-27 13:51:01 --> Helper loaded: security_helper
INFO - 2023-05-27 13:51:01 --> Helper loaded: cookie_helper
INFO - 2023-05-27 13:51:01 --> Database Driver Class Initialized
INFO - 2023-05-27 13:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 13:51:01 --> Parser Class Initialized
INFO - 2023-05-27 13:51:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 13:51:01 --> Pagination Class Initialized
INFO - 2023-05-27 13:51:01 --> Form Validation Class Initialized
INFO - 2023-05-27 13:51:01 --> Controller Class Initialized
INFO - 2023-05-27 13:51:01 --> Model Class Initialized
DEBUG - 2023-05-27 13:51:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-27 13:51:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 13:51:01 --> Model Class Initialized
INFO - 2023-05-27 13:51:01 --> Final output sent to browser
DEBUG - 2023-05-27 13:51:01 --> Total execution time: 0.0266
ERROR - 2023-05-27 13:51:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 13:51:04 --> Config Class Initialized
INFO - 2023-05-27 13:51:04 --> Hooks Class Initialized
DEBUG - 2023-05-27 13:51:04 --> UTF-8 Support Enabled
INFO - 2023-05-27 13:51:04 --> Utf8 Class Initialized
INFO - 2023-05-27 13:51:04 --> URI Class Initialized
DEBUG - 2023-05-27 13:51:04 --> No URI present. Default controller set.
INFO - 2023-05-27 13:51:04 --> Router Class Initialized
INFO - 2023-05-27 13:51:04 --> Output Class Initialized
INFO - 2023-05-27 13:51:04 --> Security Class Initialized
DEBUG - 2023-05-27 13:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 13:51:04 --> Input Class Initialized
INFO - 2023-05-27 13:51:04 --> Language Class Initialized
INFO - 2023-05-27 13:51:04 --> Loader Class Initialized
INFO - 2023-05-27 13:51:04 --> Helper loaded: url_helper
INFO - 2023-05-27 13:51:04 --> Helper loaded: file_helper
INFO - 2023-05-27 13:51:04 --> Helper loaded: html_helper
INFO - 2023-05-27 13:51:04 --> Helper loaded: text_helper
INFO - 2023-05-27 13:51:04 --> Helper loaded: form_helper
INFO - 2023-05-27 13:51:04 --> Helper loaded: lang_helper
INFO - 2023-05-27 13:51:04 --> Helper loaded: security_helper
INFO - 2023-05-27 13:51:04 --> Helper loaded: cookie_helper
INFO - 2023-05-27 13:51:04 --> Database Driver Class Initialized
INFO - 2023-05-27 13:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 13:51:04 --> Parser Class Initialized
INFO - 2023-05-27 13:51:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 13:51:04 --> Pagination Class Initialized
INFO - 2023-05-27 13:51:04 --> Form Validation Class Initialized
INFO - 2023-05-27 13:51:04 --> Controller Class Initialized
INFO - 2023-05-27 13:51:04 --> Model Class Initialized
DEBUG - 2023-05-27 13:51:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 13:51:04 --> Model Class Initialized
DEBUG - 2023-05-27 13:51:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 13:51:04 --> Model Class Initialized
INFO - 2023-05-27 13:51:04 --> Model Class Initialized
INFO - 2023-05-27 13:51:04 --> Model Class Initialized
INFO - 2023-05-27 13:51:04 --> Model Class Initialized
DEBUG - 2023-05-27 13:51:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-27 13:51:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 13:51:04 --> Model Class Initialized
INFO - 2023-05-27 13:51:04 --> Model Class Initialized
INFO - 2023-05-27 13:51:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-27 13:51:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-27 13:51:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-27 13:51:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-27 13:51:04 --> Model Class Initialized
INFO - 2023-05-27 13:51:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-27 13:51:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-27 13:51:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-27 13:51:04 --> Final output sent to browser
DEBUG - 2023-05-27 13:51:04 --> Total execution time: 0.0847
ERROR - 2023-05-27 13:51:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 13:51:16 --> Config Class Initialized
INFO - 2023-05-27 13:51:16 --> Hooks Class Initialized
DEBUG - 2023-05-27 13:51:16 --> UTF-8 Support Enabled
INFO - 2023-05-27 13:51:16 --> Utf8 Class Initialized
INFO - 2023-05-27 13:51:16 --> URI Class Initialized
INFO - 2023-05-27 13:51:16 --> Router Class Initialized
INFO - 2023-05-27 13:51:16 --> Output Class Initialized
INFO - 2023-05-27 13:51:16 --> Security Class Initialized
DEBUG - 2023-05-27 13:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 13:51:16 --> Input Class Initialized
INFO - 2023-05-27 13:51:16 --> Language Class Initialized
INFO - 2023-05-27 13:51:16 --> Loader Class Initialized
INFO - 2023-05-27 13:51:16 --> Helper loaded: url_helper
INFO - 2023-05-27 13:51:16 --> Helper loaded: file_helper
INFO - 2023-05-27 13:51:16 --> Helper loaded: html_helper
INFO - 2023-05-27 13:51:16 --> Helper loaded: text_helper
INFO - 2023-05-27 13:51:16 --> Helper loaded: form_helper
INFO - 2023-05-27 13:51:16 --> Helper loaded: lang_helper
INFO - 2023-05-27 13:51:16 --> Helper loaded: security_helper
INFO - 2023-05-27 13:51:16 --> Helper loaded: cookie_helper
INFO - 2023-05-27 13:51:16 --> Database Driver Class Initialized
INFO - 2023-05-27 13:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 13:51:16 --> Parser Class Initialized
INFO - 2023-05-27 13:51:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 13:51:16 --> Pagination Class Initialized
INFO - 2023-05-27 13:51:16 --> Form Validation Class Initialized
INFO - 2023-05-27 13:51:16 --> Controller Class Initialized
INFO - 2023-05-27 13:51:16 --> Model Class Initialized
DEBUG - 2023-05-27 13:51:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-27 13:51:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 13:51:16 --> Model Class Initialized
INFO - 2023-05-27 13:51:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-05-27 13:51:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-27 13:51:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-27 13:51:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-27 13:51:16 --> Model Class Initialized
INFO - 2023-05-27 13:51:16 --> Model Class Initialized
INFO - 2023-05-27 13:51:16 --> Model Class Initialized
INFO - 2023-05-27 13:51:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-27 13:51:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-27 13:51:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-27 13:51:16 --> Final output sent to browser
DEBUG - 2023-05-27 13:51:16 --> Total execution time: 0.0765
ERROR - 2023-05-27 13:51:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 13:51:17 --> Config Class Initialized
INFO - 2023-05-27 13:51:17 --> Hooks Class Initialized
DEBUG - 2023-05-27 13:51:17 --> UTF-8 Support Enabled
INFO - 2023-05-27 13:51:17 --> Utf8 Class Initialized
INFO - 2023-05-27 13:51:17 --> URI Class Initialized
INFO - 2023-05-27 13:51:17 --> Router Class Initialized
INFO - 2023-05-27 13:51:17 --> Output Class Initialized
INFO - 2023-05-27 13:51:17 --> Security Class Initialized
DEBUG - 2023-05-27 13:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 13:51:17 --> Input Class Initialized
INFO - 2023-05-27 13:51:17 --> Language Class Initialized
INFO - 2023-05-27 13:51:17 --> Loader Class Initialized
INFO - 2023-05-27 13:51:17 --> Helper loaded: url_helper
INFO - 2023-05-27 13:51:17 --> Helper loaded: file_helper
INFO - 2023-05-27 13:51:17 --> Helper loaded: html_helper
INFO - 2023-05-27 13:51:17 --> Helper loaded: text_helper
INFO - 2023-05-27 13:51:17 --> Helper loaded: form_helper
INFO - 2023-05-27 13:51:17 --> Helper loaded: lang_helper
INFO - 2023-05-27 13:51:17 --> Helper loaded: security_helper
INFO - 2023-05-27 13:51:17 --> Helper loaded: cookie_helper
INFO - 2023-05-27 13:51:17 --> Database Driver Class Initialized
INFO - 2023-05-27 13:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 13:51:17 --> Parser Class Initialized
INFO - 2023-05-27 13:51:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 13:51:17 --> Pagination Class Initialized
INFO - 2023-05-27 13:51:17 --> Form Validation Class Initialized
INFO - 2023-05-27 13:51:17 --> Controller Class Initialized
INFO - 2023-05-27 13:51:17 --> Model Class Initialized
DEBUG - 2023-05-27 13:51:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-27 13:51:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 13:51:17 --> Model Class Initialized
INFO - 2023-05-27 13:51:17 --> Final output sent to browser
DEBUG - 2023-05-27 13:51:17 --> Total execution time: 0.0296
ERROR - 2023-05-27 14:19:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 14:19:07 --> Config Class Initialized
INFO - 2023-05-27 14:19:07 --> Hooks Class Initialized
DEBUG - 2023-05-27 14:19:07 --> UTF-8 Support Enabled
INFO - 2023-05-27 14:19:07 --> Utf8 Class Initialized
INFO - 2023-05-27 14:19:07 --> URI Class Initialized
DEBUG - 2023-05-27 14:19:07 --> No URI present. Default controller set.
INFO - 2023-05-27 14:19:07 --> Router Class Initialized
INFO - 2023-05-27 14:19:07 --> Output Class Initialized
INFO - 2023-05-27 14:19:07 --> Security Class Initialized
DEBUG - 2023-05-27 14:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 14:19:07 --> Input Class Initialized
INFO - 2023-05-27 14:19:07 --> Language Class Initialized
INFO - 2023-05-27 14:19:07 --> Loader Class Initialized
INFO - 2023-05-27 14:19:07 --> Helper loaded: url_helper
INFO - 2023-05-27 14:19:07 --> Helper loaded: file_helper
INFO - 2023-05-27 14:19:07 --> Helper loaded: html_helper
INFO - 2023-05-27 14:19:07 --> Helper loaded: text_helper
INFO - 2023-05-27 14:19:07 --> Helper loaded: form_helper
INFO - 2023-05-27 14:19:07 --> Helper loaded: lang_helper
INFO - 2023-05-27 14:19:07 --> Helper loaded: security_helper
INFO - 2023-05-27 14:19:07 --> Helper loaded: cookie_helper
INFO - 2023-05-27 14:19:07 --> Database Driver Class Initialized
INFO - 2023-05-27 14:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 14:19:07 --> Parser Class Initialized
INFO - 2023-05-27 14:19:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 14:19:07 --> Pagination Class Initialized
INFO - 2023-05-27 14:19:07 --> Form Validation Class Initialized
INFO - 2023-05-27 14:19:07 --> Controller Class Initialized
INFO - 2023-05-27 14:19:07 --> Model Class Initialized
DEBUG - 2023-05-27 14:19:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-27 14:19:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 14:19:08 --> Config Class Initialized
INFO - 2023-05-27 14:19:08 --> Hooks Class Initialized
DEBUG - 2023-05-27 14:19:08 --> UTF-8 Support Enabled
INFO - 2023-05-27 14:19:08 --> Utf8 Class Initialized
INFO - 2023-05-27 14:19:08 --> URI Class Initialized
DEBUG - 2023-05-27 14:19:08 --> No URI present. Default controller set.
INFO - 2023-05-27 14:19:08 --> Router Class Initialized
INFO - 2023-05-27 14:19:08 --> Output Class Initialized
INFO - 2023-05-27 14:19:08 --> Security Class Initialized
DEBUG - 2023-05-27 14:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 14:19:08 --> Input Class Initialized
INFO - 2023-05-27 14:19:08 --> Language Class Initialized
INFO - 2023-05-27 14:19:08 --> Loader Class Initialized
INFO - 2023-05-27 14:19:08 --> Helper loaded: url_helper
INFO - 2023-05-27 14:19:08 --> Helper loaded: file_helper
INFO - 2023-05-27 14:19:08 --> Helper loaded: html_helper
INFO - 2023-05-27 14:19:08 --> Helper loaded: text_helper
INFO - 2023-05-27 14:19:08 --> Helper loaded: form_helper
INFO - 2023-05-27 14:19:08 --> Helper loaded: lang_helper
INFO - 2023-05-27 14:19:08 --> Helper loaded: security_helper
INFO - 2023-05-27 14:19:08 --> Helper loaded: cookie_helper
INFO - 2023-05-27 14:19:08 --> Database Driver Class Initialized
INFO - 2023-05-27 14:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 14:19:08 --> Parser Class Initialized
INFO - 2023-05-27 14:19:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 14:19:08 --> Pagination Class Initialized
INFO - 2023-05-27 14:19:08 --> Form Validation Class Initialized
INFO - 2023-05-27 14:19:08 --> Controller Class Initialized
INFO - 2023-05-27 14:19:08 --> Model Class Initialized
DEBUG - 2023-05-27 14:19:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-27 14:19:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 14:19:09 --> Config Class Initialized
INFO - 2023-05-27 14:19:09 --> Hooks Class Initialized
DEBUG - 2023-05-27 14:19:09 --> UTF-8 Support Enabled
INFO - 2023-05-27 14:19:09 --> Utf8 Class Initialized
INFO - 2023-05-27 14:19:09 --> URI Class Initialized
DEBUG - 2023-05-27 14:19:09 --> No URI present. Default controller set.
INFO - 2023-05-27 14:19:09 --> Router Class Initialized
INFO - 2023-05-27 14:19:09 --> Output Class Initialized
INFO - 2023-05-27 14:19:09 --> Security Class Initialized
DEBUG - 2023-05-27 14:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 14:19:09 --> Input Class Initialized
INFO - 2023-05-27 14:19:09 --> Language Class Initialized
INFO - 2023-05-27 14:19:09 --> Loader Class Initialized
INFO - 2023-05-27 14:19:09 --> Helper loaded: url_helper
INFO - 2023-05-27 14:19:09 --> Helper loaded: file_helper
INFO - 2023-05-27 14:19:09 --> Helper loaded: html_helper
INFO - 2023-05-27 14:19:09 --> Helper loaded: text_helper
INFO - 2023-05-27 14:19:09 --> Helper loaded: form_helper
INFO - 2023-05-27 14:19:09 --> Helper loaded: lang_helper
INFO - 2023-05-27 14:19:09 --> Helper loaded: security_helper
INFO - 2023-05-27 14:19:09 --> Helper loaded: cookie_helper
INFO - 2023-05-27 14:19:09 --> Database Driver Class Initialized
INFO - 2023-05-27 14:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 14:19:09 --> Parser Class Initialized
INFO - 2023-05-27 14:19:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 14:19:09 --> Pagination Class Initialized
INFO - 2023-05-27 14:19:09 --> Form Validation Class Initialized
INFO - 2023-05-27 14:19:09 --> Controller Class Initialized
INFO - 2023-05-27 14:19:09 --> Model Class Initialized
DEBUG - 2023-05-27 14:19:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-27 14:19:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 14:19:14 --> Config Class Initialized
INFO - 2023-05-27 14:19:14 --> Hooks Class Initialized
DEBUG - 2023-05-27 14:19:14 --> UTF-8 Support Enabled
INFO - 2023-05-27 14:19:14 --> Utf8 Class Initialized
INFO - 2023-05-27 14:19:14 --> URI Class Initialized
DEBUG - 2023-05-27 14:19:14 --> No URI present. Default controller set.
INFO - 2023-05-27 14:19:14 --> Router Class Initialized
INFO - 2023-05-27 14:19:14 --> Output Class Initialized
INFO - 2023-05-27 14:19:14 --> Security Class Initialized
DEBUG - 2023-05-27 14:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 14:19:14 --> Input Class Initialized
INFO - 2023-05-27 14:19:14 --> Language Class Initialized
INFO - 2023-05-27 14:19:14 --> Loader Class Initialized
INFO - 2023-05-27 14:19:14 --> Helper loaded: url_helper
INFO - 2023-05-27 14:19:14 --> Helper loaded: file_helper
INFO - 2023-05-27 14:19:14 --> Helper loaded: html_helper
INFO - 2023-05-27 14:19:14 --> Helper loaded: text_helper
INFO - 2023-05-27 14:19:14 --> Helper loaded: form_helper
INFO - 2023-05-27 14:19:14 --> Helper loaded: lang_helper
INFO - 2023-05-27 14:19:14 --> Helper loaded: security_helper
INFO - 2023-05-27 14:19:14 --> Helper loaded: cookie_helper
INFO - 2023-05-27 14:19:14 --> Database Driver Class Initialized
INFO - 2023-05-27 14:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 14:19:14 --> Parser Class Initialized
INFO - 2023-05-27 14:19:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 14:19:14 --> Pagination Class Initialized
INFO - 2023-05-27 14:19:14 --> Form Validation Class Initialized
INFO - 2023-05-27 14:19:14 --> Controller Class Initialized
INFO - 2023-05-27 14:19:14 --> Model Class Initialized
DEBUG - 2023-05-27 14:19:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-27 14:19:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 14:19:14 --> Config Class Initialized
INFO - 2023-05-27 14:19:14 --> Hooks Class Initialized
DEBUG - 2023-05-27 14:19:14 --> UTF-8 Support Enabled
INFO - 2023-05-27 14:19:14 --> Utf8 Class Initialized
INFO - 2023-05-27 14:19:14 --> URI Class Initialized
DEBUG - 2023-05-27 14:19:14 --> No URI present. Default controller set.
INFO - 2023-05-27 14:19:14 --> Router Class Initialized
INFO - 2023-05-27 14:19:14 --> Output Class Initialized
INFO - 2023-05-27 14:19:14 --> Security Class Initialized
DEBUG - 2023-05-27 14:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 14:19:14 --> Input Class Initialized
INFO - 2023-05-27 14:19:14 --> Language Class Initialized
INFO - 2023-05-27 14:19:14 --> Loader Class Initialized
INFO - 2023-05-27 14:19:14 --> Helper loaded: url_helper
INFO - 2023-05-27 14:19:14 --> Helper loaded: file_helper
INFO - 2023-05-27 14:19:14 --> Helper loaded: html_helper
INFO - 2023-05-27 14:19:14 --> Helper loaded: text_helper
INFO - 2023-05-27 14:19:14 --> Helper loaded: form_helper
INFO - 2023-05-27 14:19:14 --> Helper loaded: lang_helper
INFO - 2023-05-27 14:19:14 --> Helper loaded: security_helper
INFO - 2023-05-27 14:19:14 --> Helper loaded: cookie_helper
INFO - 2023-05-27 14:19:14 --> Database Driver Class Initialized
INFO - 2023-05-27 14:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 14:19:14 --> Parser Class Initialized
INFO - 2023-05-27 14:19:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 14:19:14 --> Pagination Class Initialized
INFO - 2023-05-27 14:19:14 --> Form Validation Class Initialized
INFO - 2023-05-27 14:19:14 --> Controller Class Initialized
INFO - 2023-05-27 14:19:14 --> Model Class Initialized
DEBUG - 2023-05-27 14:19:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-27 14:19:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 14:19:14 --> Config Class Initialized
INFO - 2023-05-27 14:19:14 --> Hooks Class Initialized
DEBUG - 2023-05-27 14:19:14 --> UTF-8 Support Enabled
INFO - 2023-05-27 14:19:14 --> Utf8 Class Initialized
INFO - 2023-05-27 14:19:14 --> URI Class Initialized
DEBUG - 2023-05-27 14:19:14 --> No URI present. Default controller set.
INFO - 2023-05-27 14:19:14 --> Router Class Initialized
INFO - 2023-05-27 14:19:14 --> Output Class Initialized
INFO - 2023-05-27 14:19:14 --> Security Class Initialized
DEBUG - 2023-05-27 14:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 14:19:14 --> Input Class Initialized
INFO - 2023-05-27 14:19:14 --> Language Class Initialized
INFO - 2023-05-27 14:19:14 --> Loader Class Initialized
INFO - 2023-05-27 14:19:14 --> Helper loaded: url_helper
INFO - 2023-05-27 14:19:14 --> Helper loaded: file_helper
INFO - 2023-05-27 14:19:14 --> Helper loaded: html_helper
INFO - 2023-05-27 14:19:14 --> Helper loaded: text_helper
INFO - 2023-05-27 14:19:14 --> Helper loaded: form_helper
INFO - 2023-05-27 14:19:14 --> Helper loaded: lang_helper
INFO - 2023-05-27 14:19:14 --> Helper loaded: security_helper
INFO - 2023-05-27 14:19:14 --> Helper loaded: cookie_helper
INFO - 2023-05-27 14:19:14 --> Database Driver Class Initialized
INFO - 2023-05-27 14:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 14:19:14 --> Parser Class Initialized
INFO - 2023-05-27 14:19:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 14:19:14 --> Pagination Class Initialized
INFO - 2023-05-27 14:19:14 --> Form Validation Class Initialized
INFO - 2023-05-27 14:19:14 --> Controller Class Initialized
INFO - 2023-05-27 14:19:14 --> Model Class Initialized
DEBUG - 2023-05-27 14:19:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-27 14:19:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 14:19:15 --> Config Class Initialized
INFO - 2023-05-27 14:19:15 --> Hooks Class Initialized
DEBUG - 2023-05-27 14:19:15 --> UTF-8 Support Enabled
INFO - 2023-05-27 14:19:15 --> Utf8 Class Initialized
INFO - 2023-05-27 14:19:15 --> URI Class Initialized
DEBUG - 2023-05-27 14:19:15 --> No URI present. Default controller set.
INFO - 2023-05-27 14:19:15 --> Router Class Initialized
INFO - 2023-05-27 14:19:15 --> Output Class Initialized
INFO - 2023-05-27 14:19:15 --> Security Class Initialized
DEBUG - 2023-05-27 14:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 14:19:15 --> Input Class Initialized
INFO - 2023-05-27 14:19:15 --> Language Class Initialized
INFO - 2023-05-27 14:19:15 --> Loader Class Initialized
INFO - 2023-05-27 14:19:15 --> Helper loaded: url_helper
INFO - 2023-05-27 14:19:15 --> Helper loaded: file_helper
INFO - 2023-05-27 14:19:15 --> Helper loaded: html_helper
INFO - 2023-05-27 14:19:15 --> Helper loaded: text_helper
INFO - 2023-05-27 14:19:15 --> Helper loaded: form_helper
INFO - 2023-05-27 14:19:15 --> Helper loaded: lang_helper
INFO - 2023-05-27 14:19:15 --> Helper loaded: security_helper
INFO - 2023-05-27 14:19:15 --> Helper loaded: cookie_helper
INFO - 2023-05-27 14:19:15 --> Database Driver Class Initialized
INFO - 2023-05-27 14:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 14:19:15 --> Parser Class Initialized
INFO - 2023-05-27 14:19:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 14:19:15 --> Pagination Class Initialized
INFO - 2023-05-27 14:19:15 --> Form Validation Class Initialized
INFO - 2023-05-27 14:19:15 --> Controller Class Initialized
INFO - 2023-05-27 14:19:15 --> Model Class Initialized
DEBUG - 2023-05-27 14:19:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-27 14:19:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 14:19:15 --> Config Class Initialized
INFO - 2023-05-27 14:19:15 --> Hooks Class Initialized
DEBUG - 2023-05-27 14:19:15 --> UTF-8 Support Enabled
INFO - 2023-05-27 14:19:15 --> Utf8 Class Initialized
INFO - 2023-05-27 14:19:15 --> URI Class Initialized
DEBUG - 2023-05-27 14:19:15 --> No URI present. Default controller set.
INFO - 2023-05-27 14:19:15 --> Router Class Initialized
INFO - 2023-05-27 14:19:15 --> Output Class Initialized
INFO - 2023-05-27 14:19:15 --> Security Class Initialized
DEBUG - 2023-05-27 14:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 14:19:15 --> Input Class Initialized
INFO - 2023-05-27 14:19:15 --> Language Class Initialized
INFO - 2023-05-27 14:19:15 --> Loader Class Initialized
INFO - 2023-05-27 14:19:15 --> Helper loaded: url_helper
INFO - 2023-05-27 14:19:15 --> Helper loaded: file_helper
INFO - 2023-05-27 14:19:15 --> Helper loaded: html_helper
INFO - 2023-05-27 14:19:15 --> Helper loaded: text_helper
INFO - 2023-05-27 14:19:15 --> Helper loaded: form_helper
INFO - 2023-05-27 14:19:15 --> Helper loaded: lang_helper
INFO - 2023-05-27 14:19:15 --> Helper loaded: security_helper
INFO - 2023-05-27 14:19:15 --> Helper loaded: cookie_helper
INFO - 2023-05-27 14:19:15 --> Database Driver Class Initialized
INFO - 2023-05-27 14:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 14:19:15 --> Parser Class Initialized
INFO - 2023-05-27 14:19:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 14:19:15 --> Pagination Class Initialized
INFO - 2023-05-27 14:19:15 --> Form Validation Class Initialized
INFO - 2023-05-27 14:19:15 --> Controller Class Initialized
INFO - 2023-05-27 14:19:15 --> Model Class Initialized
DEBUG - 2023-05-27 14:19:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-27 14:19:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 14:19:15 --> Config Class Initialized
INFO - 2023-05-27 14:19:15 --> Hooks Class Initialized
DEBUG - 2023-05-27 14:19:15 --> UTF-8 Support Enabled
INFO - 2023-05-27 14:19:15 --> Utf8 Class Initialized
INFO - 2023-05-27 14:19:15 --> URI Class Initialized
DEBUG - 2023-05-27 14:19:15 --> No URI present. Default controller set.
INFO - 2023-05-27 14:19:15 --> Router Class Initialized
INFO - 2023-05-27 14:19:15 --> Output Class Initialized
INFO - 2023-05-27 14:19:15 --> Security Class Initialized
DEBUG - 2023-05-27 14:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 14:19:15 --> Input Class Initialized
INFO - 2023-05-27 14:19:15 --> Language Class Initialized
INFO - 2023-05-27 14:19:15 --> Loader Class Initialized
INFO - 2023-05-27 14:19:15 --> Helper loaded: url_helper
INFO - 2023-05-27 14:19:15 --> Helper loaded: file_helper
INFO - 2023-05-27 14:19:15 --> Helper loaded: html_helper
INFO - 2023-05-27 14:19:15 --> Helper loaded: text_helper
INFO - 2023-05-27 14:19:15 --> Helper loaded: form_helper
INFO - 2023-05-27 14:19:15 --> Helper loaded: lang_helper
INFO - 2023-05-27 14:19:15 --> Helper loaded: security_helper
INFO - 2023-05-27 14:19:15 --> Helper loaded: cookie_helper
INFO - 2023-05-27 14:19:15 --> Database Driver Class Initialized
INFO - 2023-05-27 14:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 14:19:15 --> Parser Class Initialized
INFO - 2023-05-27 14:19:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 14:19:15 --> Pagination Class Initialized
INFO - 2023-05-27 14:19:15 --> Form Validation Class Initialized
INFO - 2023-05-27 14:19:15 --> Controller Class Initialized
INFO - 2023-05-27 14:19:15 --> Model Class Initialized
DEBUG - 2023-05-27 14:19:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-27 14:19:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 14:19:15 --> Config Class Initialized
INFO - 2023-05-27 14:19:15 --> Hooks Class Initialized
DEBUG - 2023-05-27 14:19:15 --> UTF-8 Support Enabled
INFO - 2023-05-27 14:19:15 --> Utf8 Class Initialized
INFO - 2023-05-27 14:19:15 --> URI Class Initialized
DEBUG - 2023-05-27 14:19:15 --> No URI present. Default controller set.
INFO - 2023-05-27 14:19:15 --> Router Class Initialized
INFO - 2023-05-27 14:19:15 --> Output Class Initialized
INFO - 2023-05-27 14:19:15 --> Security Class Initialized
DEBUG - 2023-05-27 14:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 14:19:15 --> Input Class Initialized
INFO - 2023-05-27 14:19:15 --> Language Class Initialized
INFO - 2023-05-27 14:19:15 --> Loader Class Initialized
INFO - 2023-05-27 14:19:15 --> Helper loaded: url_helper
INFO - 2023-05-27 14:19:15 --> Helper loaded: file_helper
INFO - 2023-05-27 14:19:15 --> Helper loaded: html_helper
INFO - 2023-05-27 14:19:15 --> Helper loaded: text_helper
INFO - 2023-05-27 14:19:15 --> Helper loaded: form_helper
INFO - 2023-05-27 14:19:15 --> Helper loaded: lang_helper
INFO - 2023-05-27 14:19:15 --> Helper loaded: security_helper
INFO - 2023-05-27 14:19:15 --> Helper loaded: cookie_helper
INFO - 2023-05-27 14:19:15 --> Database Driver Class Initialized
INFO - 2023-05-27 14:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 14:19:15 --> Parser Class Initialized
INFO - 2023-05-27 14:19:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 14:19:15 --> Pagination Class Initialized
INFO - 2023-05-27 14:19:15 --> Form Validation Class Initialized
INFO - 2023-05-27 14:19:15 --> Controller Class Initialized
INFO - 2023-05-27 14:19:15 --> Model Class Initialized
DEBUG - 2023-05-27 14:19:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-27 14:19:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 14:19:15 --> Config Class Initialized
INFO - 2023-05-27 14:19:15 --> Hooks Class Initialized
DEBUG - 2023-05-27 14:19:15 --> UTF-8 Support Enabled
INFO - 2023-05-27 14:19:15 --> Utf8 Class Initialized
INFO - 2023-05-27 14:19:15 --> URI Class Initialized
DEBUG - 2023-05-27 14:19:15 --> No URI present. Default controller set.
INFO - 2023-05-27 14:19:15 --> Router Class Initialized
INFO - 2023-05-27 14:19:15 --> Output Class Initialized
INFO - 2023-05-27 14:19:15 --> Security Class Initialized
DEBUG - 2023-05-27 14:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 14:19:15 --> Input Class Initialized
INFO - 2023-05-27 14:19:15 --> Language Class Initialized
INFO - 2023-05-27 14:19:15 --> Loader Class Initialized
INFO - 2023-05-27 14:19:15 --> Helper loaded: url_helper
INFO - 2023-05-27 14:19:15 --> Helper loaded: file_helper
INFO - 2023-05-27 14:19:15 --> Helper loaded: html_helper
INFO - 2023-05-27 14:19:15 --> Helper loaded: text_helper
INFO - 2023-05-27 14:19:15 --> Helper loaded: form_helper
INFO - 2023-05-27 14:19:15 --> Helper loaded: lang_helper
INFO - 2023-05-27 14:19:15 --> Helper loaded: security_helper
INFO - 2023-05-27 14:19:15 --> Helper loaded: cookie_helper
INFO - 2023-05-27 14:19:15 --> Database Driver Class Initialized
INFO - 2023-05-27 14:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 14:19:15 --> Parser Class Initialized
INFO - 2023-05-27 14:19:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 14:19:15 --> Pagination Class Initialized
INFO - 2023-05-27 14:19:15 --> Form Validation Class Initialized
INFO - 2023-05-27 14:19:15 --> Controller Class Initialized
INFO - 2023-05-27 14:19:15 --> Model Class Initialized
DEBUG - 2023-05-27 14:19:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-27 14:19:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 14:19:15 --> Config Class Initialized
INFO - 2023-05-27 14:19:15 --> Hooks Class Initialized
DEBUG - 2023-05-27 14:19:15 --> UTF-8 Support Enabled
INFO - 2023-05-27 14:19:15 --> Utf8 Class Initialized
INFO - 2023-05-27 14:19:15 --> URI Class Initialized
DEBUG - 2023-05-27 14:19:15 --> No URI present. Default controller set.
INFO - 2023-05-27 14:19:15 --> Router Class Initialized
INFO - 2023-05-27 14:19:15 --> Output Class Initialized
INFO - 2023-05-27 14:19:15 --> Security Class Initialized
DEBUG - 2023-05-27 14:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 14:19:15 --> Input Class Initialized
INFO - 2023-05-27 14:19:15 --> Language Class Initialized
INFO - 2023-05-27 14:19:15 --> Loader Class Initialized
INFO - 2023-05-27 14:19:15 --> Helper loaded: url_helper
INFO - 2023-05-27 14:19:15 --> Helper loaded: file_helper
INFO - 2023-05-27 14:19:15 --> Helper loaded: html_helper
INFO - 2023-05-27 14:19:15 --> Helper loaded: text_helper
INFO - 2023-05-27 14:19:15 --> Helper loaded: form_helper
INFO - 2023-05-27 14:19:15 --> Helper loaded: lang_helper
INFO - 2023-05-27 14:19:15 --> Helper loaded: security_helper
INFO - 2023-05-27 14:19:15 --> Helper loaded: cookie_helper
INFO - 2023-05-27 14:19:15 --> Database Driver Class Initialized
INFO - 2023-05-27 14:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 14:19:15 --> Parser Class Initialized
INFO - 2023-05-27 14:19:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 14:19:15 --> Pagination Class Initialized
INFO - 2023-05-27 14:19:15 --> Form Validation Class Initialized
INFO - 2023-05-27 14:19:15 --> Controller Class Initialized
INFO - 2023-05-27 14:19:15 --> Model Class Initialized
DEBUG - 2023-05-27 14:19:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-27 14:19:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 14:19:16 --> Config Class Initialized
INFO - 2023-05-27 14:19:16 --> Hooks Class Initialized
DEBUG - 2023-05-27 14:19:16 --> UTF-8 Support Enabled
INFO - 2023-05-27 14:19:16 --> Utf8 Class Initialized
INFO - 2023-05-27 14:19:16 --> URI Class Initialized
DEBUG - 2023-05-27 14:19:16 --> No URI present. Default controller set.
INFO - 2023-05-27 14:19:16 --> Router Class Initialized
INFO - 2023-05-27 14:19:16 --> Output Class Initialized
INFO - 2023-05-27 14:19:16 --> Security Class Initialized
DEBUG - 2023-05-27 14:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 14:19:16 --> Input Class Initialized
INFO - 2023-05-27 14:19:16 --> Language Class Initialized
INFO - 2023-05-27 14:19:16 --> Loader Class Initialized
INFO - 2023-05-27 14:19:16 --> Helper loaded: url_helper
INFO - 2023-05-27 14:19:16 --> Helper loaded: file_helper
INFO - 2023-05-27 14:19:16 --> Helper loaded: html_helper
INFO - 2023-05-27 14:19:16 --> Helper loaded: text_helper
INFO - 2023-05-27 14:19:16 --> Helper loaded: form_helper
INFO - 2023-05-27 14:19:16 --> Helper loaded: lang_helper
INFO - 2023-05-27 14:19:16 --> Helper loaded: security_helper
INFO - 2023-05-27 14:19:16 --> Helper loaded: cookie_helper
INFO - 2023-05-27 14:19:16 --> Database Driver Class Initialized
INFO - 2023-05-27 14:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 14:19:16 --> Parser Class Initialized
INFO - 2023-05-27 14:19:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 14:19:16 --> Pagination Class Initialized
INFO - 2023-05-27 14:19:16 --> Form Validation Class Initialized
INFO - 2023-05-27 14:19:16 --> Controller Class Initialized
INFO - 2023-05-27 14:19:16 --> Model Class Initialized
DEBUG - 2023-05-27 14:19:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-27 14:19:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 14:19:16 --> Config Class Initialized
INFO - 2023-05-27 14:19:16 --> Hooks Class Initialized
DEBUG - 2023-05-27 14:19:16 --> UTF-8 Support Enabled
INFO - 2023-05-27 14:19:16 --> Utf8 Class Initialized
INFO - 2023-05-27 14:19:16 --> URI Class Initialized
DEBUG - 2023-05-27 14:19:16 --> No URI present. Default controller set.
INFO - 2023-05-27 14:19:16 --> Router Class Initialized
INFO - 2023-05-27 14:19:16 --> Output Class Initialized
INFO - 2023-05-27 14:19:16 --> Security Class Initialized
DEBUG - 2023-05-27 14:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 14:19:16 --> Input Class Initialized
INFO - 2023-05-27 14:19:16 --> Language Class Initialized
INFO - 2023-05-27 14:19:16 --> Loader Class Initialized
INFO - 2023-05-27 14:19:16 --> Helper loaded: url_helper
INFO - 2023-05-27 14:19:16 --> Helper loaded: file_helper
INFO - 2023-05-27 14:19:16 --> Helper loaded: html_helper
INFO - 2023-05-27 14:19:16 --> Helper loaded: text_helper
INFO - 2023-05-27 14:19:16 --> Helper loaded: form_helper
INFO - 2023-05-27 14:19:16 --> Helper loaded: lang_helper
INFO - 2023-05-27 14:19:16 --> Helper loaded: security_helper
INFO - 2023-05-27 14:19:16 --> Helper loaded: cookie_helper
INFO - 2023-05-27 14:19:16 --> Database Driver Class Initialized
INFO - 2023-05-27 14:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 14:19:16 --> Parser Class Initialized
INFO - 2023-05-27 14:19:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 14:19:16 --> Pagination Class Initialized
INFO - 2023-05-27 14:19:16 --> Form Validation Class Initialized
INFO - 2023-05-27 14:19:16 --> Controller Class Initialized
INFO - 2023-05-27 14:19:16 --> Model Class Initialized
DEBUG - 2023-05-27 14:19:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-27 14:19:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 14:19:16 --> Config Class Initialized
INFO - 2023-05-27 14:19:16 --> Hooks Class Initialized
DEBUG - 2023-05-27 14:19:16 --> UTF-8 Support Enabled
INFO - 2023-05-27 14:19:16 --> Utf8 Class Initialized
INFO - 2023-05-27 14:19:16 --> URI Class Initialized
DEBUG - 2023-05-27 14:19:16 --> No URI present. Default controller set.
INFO - 2023-05-27 14:19:16 --> Router Class Initialized
INFO - 2023-05-27 14:19:16 --> Output Class Initialized
INFO - 2023-05-27 14:19:16 --> Security Class Initialized
DEBUG - 2023-05-27 14:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 14:19:16 --> Input Class Initialized
INFO - 2023-05-27 14:19:16 --> Language Class Initialized
INFO - 2023-05-27 14:19:16 --> Loader Class Initialized
INFO - 2023-05-27 14:19:16 --> Helper loaded: url_helper
INFO - 2023-05-27 14:19:16 --> Helper loaded: file_helper
INFO - 2023-05-27 14:19:16 --> Helper loaded: html_helper
INFO - 2023-05-27 14:19:16 --> Helper loaded: text_helper
INFO - 2023-05-27 14:19:16 --> Helper loaded: form_helper
INFO - 2023-05-27 14:19:16 --> Helper loaded: lang_helper
INFO - 2023-05-27 14:19:16 --> Helper loaded: security_helper
INFO - 2023-05-27 14:19:16 --> Helper loaded: cookie_helper
INFO - 2023-05-27 14:19:16 --> Database Driver Class Initialized
INFO - 2023-05-27 14:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 14:19:16 --> Parser Class Initialized
INFO - 2023-05-27 14:19:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 14:19:16 --> Pagination Class Initialized
INFO - 2023-05-27 14:19:16 --> Form Validation Class Initialized
INFO - 2023-05-27 14:19:16 --> Controller Class Initialized
INFO - 2023-05-27 14:19:16 --> Model Class Initialized
DEBUG - 2023-05-27 14:19:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-27 14:19:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 14:19:16 --> Config Class Initialized
INFO - 2023-05-27 14:19:16 --> Hooks Class Initialized
DEBUG - 2023-05-27 14:19:16 --> UTF-8 Support Enabled
INFO - 2023-05-27 14:19:16 --> Utf8 Class Initialized
INFO - 2023-05-27 14:19:16 --> URI Class Initialized
DEBUG - 2023-05-27 14:19:16 --> No URI present. Default controller set.
INFO - 2023-05-27 14:19:16 --> Router Class Initialized
INFO - 2023-05-27 14:19:16 --> Output Class Initialized
INFO - 2023-05-27 14:19:16 --> Security Class Initialized
DEBUG - 2023-05-27 14:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 14:19:16 --> Input Class Initialized
INFO - 2023-05-27 14:19:16 --> Language Class Initialized
INFO - 2023-05-27 14:19:16 --> Loader Class Initialized
INFO - 2023-05-27 14:19:16 --> Helper loaded: url_helper
INFO - 2023-05-27 14:19:16 --> Helper loaded: file_helper
INFO - 2023-05-27 14:19:16 --> Helper loaded: html_helper
INFO - 2023-05-27 14:19:16 --> Helper loaded: text_helper
INFO - 2023-05-27 14:19:16 --> Helper loaded: form_helper
INFO - 2023-05-27 14:19:16 --> Helper loaded: lang_helper
INFO - 2023-05-27 14:19:16 --> Helper loaded: security_helper
INFO - 2023-05-27 14:19:16 --> Helper loaded: cookie_helper
INFO - 2023-05-27 14:19:16 --> Database Driver Class Initialized
INFO - 2023-05-27 14:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 14:19:16 --> Parser Class Initialized
INFO - 2023-05-27 14:19:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 14:19:16 --> Pagination Class Initialized
INFO - 2023-05-27 14:19:16 --> Form Validation Class Initialized
INFO - 2023-05-27 14:19:16 --> Controller Class Initialized
INFO - 2023-05-27 14:19:16 --> Model Class Initialized
DEBUG - 2023-05-27 14:19:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-27 14:19:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 14:19:16 --> Config Class Initialized
INFO - 2023-05-27 14:19:16 --> Hooks Class Initialized
DEBUG - 2023-05-27 14:19:16 --> UTF-8 Support Enabled
INFO - 2023-05-27 14:19:16 --> Utf8 Class Initialized
INFO - 2023-05-27 14:19:16 --> URI Class Initialized
DEBUG - 2023-05-27 14:19:16 --> No URI present. Default controller set.
INFO - 2023-05-27 14:19:16 --> Router Class Initialized
INFO - 2023-05-27 14:19:16 --> Output Class Initialized
INFO - 2023-05-27 14:19:16 --> Security Class Initialized
DEBUG - 2023-05-27 14:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 14:19:16 --> Input Class Initialized
INFO - 2023-05-27 14:19:16 --> Language Class Initialized
INFO - 2023-05-27 14:19:16 --> Loader Class Initialized
INFO - 2023-05-27 14:19:16 --> Helper loaded: url_helper
INFO - 2023-05-27 14:19:16 --> Helper loaded: file_helper
INFO - 2023-05-27 14:19:16 --> Helper loaded: html_helper
INFO - 2023-05-27 14:19:16 --> Helper loaded: text_helper
INFO - 2023-05-27 14:19:16 --> Helper loaded: form_helper
INFO - 2023-05-27 14:19:16 --> Helper loaded: lang_helper
INFO - 2023-05-27 14:19:16 --> Helper loaded: security_helper
INFO - 2023-05-27 14:19:16 --> Helper loaded: cookie_helper
INFO - 2023-05-27 14:19:16 --> Database Driver Class Initialized
INFO - 2023-05-27 14:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 14:19:16 --> Parser Class Initialized
INFO - 2023-05-27 14:19:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 14:19:16 --> Pagination Class Initialized
INFO - 2023-05-27 14:19:16 --> Form Validation Class Initialized
INFO - 2023-05-27 14:19:16 --> Controller Class Initialized
INFO - 2023-05-27 14:19:16 --> Model Class Initialized
DEBUG - 2023-05-27 14:19:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-27 14:19:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 14:19:18 --> Config Class Initialized
INFO - 2023-05-27 14:19:18 --> Hooks Class Initialized
DEBUG - 2023-05-27 14:19:18 --> UTF-8 Support Enabled
INFO - 2023-05-27 14:19:18 --> Utf8 Class Initialized
INFO - 2023-05-27 14:19:18 --> URI Class Initialized
DEBUG - 2023-05-27 14:19:18 --> No URI present. Default controller set.
INFO - 2023-05-27 14:19:18 --> Router Class Initialized
INFO - 2023-05-27 14:19:18 --> Output Class Initialized
INFO - 2023-05-27 14:19:18 --> Security Class Initialized
DEBUG - 2023-05-27 14:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 14:19:18 --> Input Class Initialized
INFO - 2023-05-27 14:19:18 --> Language Class Initialized
INFO - 2023-05-27 14:19:18 --> Loader Class Initialized
INFO - 2023-05-27 14:19:18 --> Helper loaded: url_helper
INFO - 2023-05-27 14:19:18 --> Helper loaded: file_helper
INFO - 2023-05-27 14:19:18 --> Helper loaded: html_helper
INFO - 2023-05-27 14:19:18 --> Helper loaded: text_helper
INFO - 2023-05-27 14:19:18 --> Helper loaded: form_helper
INFO - 2023-05-27 14:19:18 --> Helper loaded: lang_helper
INFO - 2023-05-27 14:19:18 --> Helper loaded: security_helper
INFO - 2023-05-27 14:19:18 --> Helper loaded: cookie_helper
INFO - 2023-05-27 14:19:18 --> Database Driver Class Initialized
INFO - 2023-05-27 14:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 14:19:18 --> Parser Class Initialized
INFO - 2023-05-27 14:19:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 14:19:18 --> Pagination Class Initialized
INFO - 2023-05-27 14:19:18 --> Form Validation Class Initialized
INFO - 2023-05-27 14:19:18 --> Controller Class Initialized
INFO - 2023-05-27 14:19:18 --> Model Class Initialized
DEBUG - 2023-05-27 14:19:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-27 14:19:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 14:19:18 --> Config Class Initialized
INFO - 2023-05-27 14:19:18 --> Hooks Class Initialized
DEBUG - 2023-05-27 14:19:18 --> UTF-8 Support Enabled
INFO - 2023-05-27 14:19:18 --> Utf8 Class Initialized
INFO - 2023-05-27 14:19:18 --> URI Class Initialized
DEBUG - 2023-05-27 14:19:18 --> No URI present. Default controller set.
INFO - 2023-05-27 14:19:18 --> Router Class Initialized
INFO - 2023-05-27 14:19:18 --> Output Class Initialized
INFO - 2023-05-27 14:19:18 --> Security Class Initialized
DEBUG - 2023-05-27 14:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 14:19:18 --> Input Class Initialized
INFO - 2023-05-27 14:19:18 --> Language Class Initialized
INFO - 2023-05-27 14:19:18 --> Loader Class Initialized
INFO - 2023-05-27 14:19:18 --> Helper loaded: url_helper
INFO - 2023-05-27 14:19:18 --> Helper loaded: file_helper
INFO - 2023-05-27 14:19:18 --> Helper loaded: html_helper
INFO - 2023-05-27 14:19:18 --> Helper loaded: text_helper
INFO - 2023-05-27 14:19:18 --> Helper loaded: form_helper
INFO - 2023-05-27 14:19:18 --> Helper loaded: lang_helper
INFO - 2023-05-27 14:19:18 --> Helper loaded: security_helper
INFO - 2023-05-27 14:19:18 --> Helper loaded: cookie_helper
INFO - 2023-05-27 14:19:18 --> Database Driver Class Initialized
INFO - 2023-05-27 14:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 14:19:18 --> Parser Class Initialized
INFO - 2023-05-27 14:19:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 14:19:18 --> Pagination Class Initialized
INFO - 2023-05-27 14:19:18 --> Form Validation Class Initialized
INFO - 2023-05-27 14:19:18 --> Controller Class Initialized
INFO - 2023-05-27 14:19:18 --> Model Class Initialized
DEBUG - 2023-05-27 14:19:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-27 14:19:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 14:19:19 --> Config Class Initialized
INFO - 2023-05-27 14:19:19 --> Hooks Class Initialized
DEBUG - 2023-05-27 14:19:19 --> UTF-8 Support Enabled
INFO - 2023-05-27 14:19:19 --> Utf8 Class Initialized
INFO - 2023-05-27 14:19:19 --> URI Class Initialized
DEBUG - 2023-05-27 14:19:19 --> No URI present. Default controller set.
INFO - 2023-05-27 14:19:19 --> Router Class Initialized
INFO - 2023-05-27 14:19:19 --> Output Class Initialized
INFO - 2023-05-27 14:19:19 --> Security Class Initialized
DEBUG - 2023-05-27 14:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 14:19:19 --> Input Class Initialized
INFO - 2023-05-27 14:19:19 --> Language Class Initialized
INFO - 2023-05-27 14:19:19 --> Loader Class Initialized
INFO - 2023-05-27 14:19:19 --> Helper loaded: url_helper
INFO - 2023-05-27 14:19:19 --> Helper loaded: file_helper
INFO - 2023-05-27 14:19:19 --> Helper loaded: html_helper
INFO - 2023-05-27 14:19:19 --> Helper loaded: text_helper
INFO - 2023-05-27 14:19:19 --> Helper loaded: form_helper
INFO - 2023-05-27 14:19:19 --> Helper loaded: lang_helper
INFO - 2023-05-27 14:19:19 --> Helper loaded: security_helper
INFO - 2023-05-27 14:19:19 --> Helper loaded: cookie_helper
INFO - 2023-05-27 14:19:19 --> Database Driver Class Initialized
INFO - 2023-05-27 14:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 14:19:19 --> Parser Class Initialized
INFO - 2023-05-27 14:19:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 14:19:19 --> Pagination Class Initialized
INFO - 2023-05-27 14:19:19 --> Form Validation Class Initialized
INFO - 2023-05-27 14:19:19 --> Controller Class Initialized
INFO - 2023-05-27 14:19:19 --> Model Class Initialized
DEBUG - 2023-05-27 14:19:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-27 14:19:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 14:19:19 --> Config Class Initialized
INFO - 2023-05-27 14:19:19 --> Hooks Class Initialized
DEBUG - 2023-05-27 14:19:19 --> UTF-8 Support Enabled
INFO - 2023-05-27 14:19:19 --> Utf8 Class Initialized
INFO - 2023-05-27 14:19:19 --> URI Class Initialized
DEBUG - 2023-05-27 14:19:19 --> No URI present. Default controller set.
INFO - 2023-05-27 14:19:19 --> Router Class Initialized
INFO - 2023-05-27 14:19:19 --> Output Class Initialized
INFO - 2023-05-27 14:19:19 --> Security Class Initialized
DEBUG - 2023-05-27 14:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 14:19:19 --> Input Class Initialized
INFO - 2023-05-27 14:19:19 --> Language Class Initialized
INFO - 2023-05-27 14:19:19 --> Loader Class Initialized
INFO - 2023-05-27 14:19:19 --> Helper loaded: url_helper
INFO - 2023-05-27 14:19:19 --> Helper loaded: file_helper
INFO - 2023-05-27 14:19:19 --> Helper loaded: html_helper
INFO - 2023-05-27 14:19:19 --> Helper loaded: text_helper
INFO - 2023-05-27 14:19:19 --> Helper loaded: form_helper
INFO - 2023-05-27 14:19:19 --> Helper loaded: lang_helper
INFO - 2023-05-27 14:19:19 --> Helper loaded: security_helper
INFO - 2023-05-27 14:19:19 --> Helper loaded: cookie_helper
INFO - 2023-05-27 14:19:19 --> Database Driver Class Initialized
INFO - 2023-05-27 14:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 14:19:19 --> Parser Class Initialized
INFO - 2023-05-27 14:19:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 14:19:19 --> Pagination Class Initialized
INFO - 2023-05-27 14:19:19 --> Form Validation Class Initialized
INFO - 2023-05-27 14:19:19 --> Controller Class Initialized
INFO - 2023-05-27 14:19:19 --> Model Class Initialized
DEBUG - 2023-05-27 14:19:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-27 14:19:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 14:19:19 --> Config Class Initialized
INFO - 2023-05-27 14:19:19 --> Hooks Class Initialized
DEBUG - 2023-05-27 14:19:19 --> UTF-8 Support Enabled
INFO - 2023-05-27 14:19:19 --> Utf8 Class Initialized
INFO - 2023-05-27 14:19:19 --> URI Class Initialized
DEBUG - 2023-05-27 14:19:19 --> No URI present. Default controller set.
INFO - 2023-05-27 14:19:19 --> Router Class Initialized
INFO - 2023-05-27 14:19:19 --> Output Class Initialized
INFO - 2023-05-27 14:19:19 --> Security Class Initialized
DEBUG - 2023-05-27 14:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 14:19:19 --> Input Class Initialized
INFO - 2023-05-27 14:19:19 --> Language Class Initialized
INFO - 2023-05-27 14:19:19 --> Loader Class Initialized
INFO - 2023-05-27 14:19:19 --> Helper loaded: url_helper
INFO - 2023-05-27 14:19:19 --> Helper loaded: file_helper
INFO - 2023-05-27 14:19:19 --> Helper loaded: html_helper
INFO - 2023-05-27 14:19:19 --> Helper loaded: text_helper
INFO - 2023-05-27 14:19:19 --> Helper loaded: form_helper
INFO - 2023-05-27 14:19:19 --> Helper loaded: lang_helper
INFO - 2023-05-27 14:19:19 --> Helper loaded: security_helper
INFO - 2023-05-27 14:19:19 --> Helper loaded: cookie_helper
INFO - 2023-05-27 14:19:19 --> Database Driver Class Initialized
INFO - 2023-05-27 14:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 14:19:19 --> Parser Class Initialized
INFO - 2023-05-27 14:19:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 14:19:19 --> Pagination Class Initialized
INFO - 2023-05-27 14:19:19 --> Form Validation Class Initialized
INFO - 2023-05-27 14:19:19 --> Controller Class Initialized
INFO - 2023-05-27 14:19:19 --> Model Class Initialized
DEBUG - 2023-05-27 14:19:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-27 14:19:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 14:19:20 --> Config Class Initialized
INFO - 2023-05-27 14:19:20 --> Hooks Class Initialized
DEBUG - 2023-05-27 14:19:20 --> UTF-8 Support Enabled
INFO - 2023-05-27 14:19:20 --> Utf8 Class Initialized
INFO - 2023-05-27 14:19:20 --> URI Class Initialized
DEBUG - 2023-05-27 14:19:20 --> No URI present. Default controller set.
INFO - 2023-05-27 14:19:20 --> Router Class Initialized
INFO - 2023-05-27 14:19:20 --> Output Class Initialized
INFO - 2023-05-27 14:19:20 --> Security Class Initialized
DEBUG - 2023-05-27 14:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 14:19:20 --> Input Class Initialized
INFO - 2023-05-27 14:19:20 --> Language Class Initialized
INFO - 2023-05-27 14:19:20 --> Loader Class Initialized
INFO - 2023-05-27 14:19:20 --> Helper loaded: url_helper
INFO - 2023-05-27 14:19:20 --> Helper loaded: file_helper
INFO - 2023-05-27 14:19:20 --> Helper loaded: html_helper
INFO - 2023-05-27 14:19:20 --> Helper loaded: text_helper
INFO - 2023-05-27 14:19:20 --> Helper loaded: form_helper
INFO - 2023-05-27 14:19:20 --> Helper loaded: lang_helper
INFO - 2023-05-27 14:19:20 --> Helper loaded: security_helper
INFO - 2023-05-27 14:19:20 --> Helper loaded: cookie_helper
INFO - 2023-05-27 14:19:20 --> Database Driver Class Initialized
INFO - 2023-05-27 14:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 14:19:20 --> Parser Class Initialized
INFO - 2023-05-27 14:19:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 14:19:20 --> Pagination Class Initialized
INFO - 2023-05-27 14:19:20 --> Form Validation Class Initialized
INFO - 2023-05-27 14:19:20 --> Controller Class Initialized
INFO - 2023-05-27 14:19:20 --> Model Class Initialized
DEBUG - 2023-05-27 14:19:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-27 14:19:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 14:19:21 --> Config Class Initialized
INFO - 2023-05-27 14:19:21 --> Hooks Class Initialized
DEBUG - 2023-05-27 14:19:21 --> UTF-8 Support Enabled
INFO - 2023-05-27 14:19:21 --> Utf8 Class Initialized
INFO - 2023-05-27 14:19:21 --> URI Class Initialized
DEBUG - 2023-05-27 14:19:21 --> No URI present. Default controller set.
INFO - 2023-05-27 14:19:21 --> Router Class Initialized
INFO - 2023-05-27 14:19:21 --> Output Class Initialized
INFO - 2023-05-27 14:19:21 --> Security Class Initialized
DEBUG - 2023-05-27 14:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 14:19:21 --> Input Class Initialized
INFO - 2023-05-27 14:19:21 --> Language Class Initialized
INFO - 2023-05-27 14:19:21 --> Loader Class Initialized
INFO - 2023-05-27 14:19:21 --> Helper loaded: url_helper
INFO - 2023-05-27 14:19:21 --> Helper loaded: file_helper
INFO - 2023-05-27 14:19:21 --> Helper loaded: html_helper
INFO - 2023-05-27 14:19:21 --> Helper loaded: text_helper
INFO - 2023-05-27 14:19:21 --> Helper loaded: form_helper
INFO - 2023-05-27 14:19:21 --> Helper loaded: lang_helper
INFO - 2023-05-27 14:19:21 --> Helper loaded: security_helper
INFO - 2023-05-27 14:19:21 --> Helper loaded: cookie_helper
INFO - 2023-05-27 14:19:21 --> Database Driver Class Initialized
INFO - 2023-05-27 14:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 14:19:21 --> Parser Class Initialized
INFO - 2023-05-27 14:19:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 14:19:21 --> Pagination Class Initialized
INFO - 2023-05-27 14:19:21 --> Form Validation Class Initialized
INFO - 2023-05-27 14:19:21 --> Controller Class Initialized
INFO - 2023-05-27 14:19:21 --> Model Class Initialized
DEBUG - 2023-05-27 14:19:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-27 14:19:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 14:19:28 --> Config Class Initialized
INFO - 2023-05-27 14:19:28 --> Hooks Class Initialized
DEBUG - 2023-05-27 14:19:28 --> UTF-8 Support Enabled
INFO - 2023-05-27 14:19:28 --> Utf8 Class Initialized
INFO - 2023-05-27 14:19:28 --> URI Class Initialized
DEBUG - 2023-05-27 14:19:28 --> No URI present. Default controller set.
INFO - 2023-05-27 14:19:28 --> Router Class Initialized
INFO - 2023-05-27 14:19:28 --> Output Class Initialized
INFO - 2023-05-27 14:19:28 --> Security Class Initialized
DEBUG - 2023-05-27 14:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 14:19:28 --> Input Class Initialized
INFO - 2023-05-27 14:19:28 --> Language Class Initialized
INFO - 2023-05-27 14:19:28 --> Loader Class Initialized
INFO - 2023-05-27 14:19:28 --> Helper loaded: url_helper
INFO - 2023-05-27 14:19:28 --> Helper loaded: file_helper
INFO - 2023-05-27 14:19:28 --> Helper loaded: html_helper
INFO - 2023-05-27 14:19:28 --> Helper loaded: text_helper
INFO - 2023-05-27 14:19:28 --> Helper loaded: form_helper
INFO - 2023-05-27 14:19:28 --> Helper loaded: lang_helper
INFO - 2023-05-27 14:19:28 --> Helper loaded: security_helper
INFO - 2023-05-27 14:19:28 --> Helper loaded: cookie_helper
INFO - 2023-05-27 14:19:28 --> Database Driver Class Initialized
INFO - 2023-05-27 14:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 14:19:28 --> Parser Class Initialized
INFO - 2023-05-27 14:19:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 14:19:28 --> Pagination Class Initialized
INFO - 2023-05-27 14:19:28 --> Form Validation Class Initialized
INFO - 2023-05-27 14:19:28 --> Controller Class Initialized
INFO - 2023-05-27 14:19:28 --> Model Class Initialized
DEBUG - 2023-05-27 14:19:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-27 14:36:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 14:36:36 --> Config Class Initialized
INFO - 2023-05-27 14:36:36 --> Hooks Class Initialized
DEBUG - 2023-05-27 14:36:36 --> UTF-8 Support Enabled
INFO - 2023-05-27 14:36:36 --> Utf8 Class Initialized
INFO - 2023-05-27 14:36:36 --> URI Class Initialized
INFO - 2023-05-27 14:36:36 --> Router Class Initialized
INFO - 2023-05-27 14:36:36 --> Output Class Initialized
INFO - 2023-05-27 14:36:36 --> Security Class Initialized
DEBUG - 2023-05-27 14:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 14:36:36 --> Input Class Initialized
INFO - 2023-05-27 14:36:36 --> Language Class Initialized
INFO - 2023-05-27 14:36:36 --> Loader Class Initialized
INFO - 2023-05-27 14:36:36 --> Helper loaded: url_helper
INFO - 2023-05-27 14:36:36 --> Helper loaded: file_helper
INFO - 2023-05-27 14:36:36 --> Helper loaded: html_helper
INFO - 2023-05-27 14:36:36 --> Helper loaded: text_helper
INFO - 2023-05-27 14:36:36 --> Helper loaded: form_helper
INFO - 2023-05-27 14:36:36 --> Helper loaded: lang_helper
INFO - 2023-05-27 14:36:36 --> Helper loaded: security_helper
INFO - 2023-05-27 14:36:36 --> Helper loaded: cookie_helper
INFO - 2023-05-27 14:36:36 --> Database Driver Class Initialized
INFO - 2023-05-27 14:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 14:36:36 --> Parser Class Initialized
INFO - 2023-05-27 14:36:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 14:36:36 --> Pagination Class Initialized
INFO - 2023-05-27 14:36:36 --> Form Validation Class Initialized
INFO - 2023-05-27 14:36:36 --> Controller Class Initialized
INFO - 2023-05-27 14:36:36 --> Model Class Initialized
DEBUG - 2023-05-27 14:36:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 14:36:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-27 14:36:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-27 14:36:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-27 14:36:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-27 14:36:36 --> Model Class Initialized
INFO - 2023-05-27 14:36:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-27 14:36:36 --> Final output sent to browser
DEBUG - 2023-05-27 14:36:36 --> Total execution time: 0.0323
ERROR - 2023-05-27 14:43:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 14:43:34 --> Config Class Initialized
INFO - 2023-05-27 14:43:34 --> Hooks Class Initialized
DEBUG - 2023-05-27 14:43:34 --> UTF-8 Support Enabled
INFO - 2023-05-27 14:43:34 --> Utf8 Class Initialized
INFO - 2023-05-27 14:43:34 --> URI Class Initialized
DEBUG - 2023-05-27 14:43:34 --> No URI present. Default controller set.
INFO - 2023-05-27 14:43:34 --> Router Class Initialized
INFO - 2023-05-27 14:43:34 --> Output Class Initialized
INFO - 2023-05-27 14:43:34 --> Security Class Initialized
DEBUG - 2023-05-27 14:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 14:43:34 --> Input Class Initialized
INFO - 2023-05-27 14:43:34 --> Language Class Initialized
INFO - 2023-05-27 14:43:34 --> Loader Class Initialized
INFO - 2023-05-27 14:43:34 --> Helper loaded: url_helper
INFO - 2023-05-27 14:43:34 --> Helper loaded: file_helper
INFO - 2023-05-27 14:43:34 --> Helper loaded: html_helper
INFO - 2023-05-27 14:43:34 --> Helper loaded: text_helper
INFO - 2023-05-27 14:43:34 --> Helper loaded: form_helper
INFO - 2023-05-27 14:43:34 --> Helper loaded: lang_helper
INFO - 2023-05-27 14:43:34 --> Helper loaded: security_helper
INFO - 2023-05-27 14:43:34 --> Helper loaded: cookie_helper
INFO - 2023-05-27 14:43:34 --> Database Driver Class Initialized
INFO - 2023-05-27 14:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 14:43:34 --> Parser Class Initialized
INFO - 2023-05-27 14:43:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 14:43:34 --> Pagination Class Initialized
INFO - 2023-05-27 14:43:34 --> Form Validation Class Initialized
INFO - 2023-05-27 14:43:34 --> Controller Class Initialized
INFO - 2023-05-27 14:43:34 --> Model Class Initialized
DEBUG - 2023-05-27 14:43:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-27 16:52:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 16:52:40 --> Config Class Initialized
INFO - 2023-05-27 16:52:40 --> Hooks Class Initialized
DEBUG - 2023-05-27 16:52:40 --> UTF-8 Support Enabled
INFO - 2023-05-27 16:52:40 --> Utf8 Class Initialized
INFO - 2023-05-27 16:52:40 --> URI Class Initialized
DEBUG - 2023-05-27 16:52:40 --> No URI present. Default controller set.
INFO - 2023-05-27 16:52:40 --> Router Class Initialized
INFO - 2023-05-27 16:52:40 --> Output Class Initialized
INFO - 2023-05-27 16:52:40 --> Security Class Initialized
DEBUG - 2023-05-27 16:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 16:52:40 --> Input Class Initialized
INFO - 2023-05-27 16:52:40 --> Language Class Initialized
INFO - 2023-05-27 16:52:40 --> Loader Class Initialized
INFO - 2023-05-27 16:52:40 --> Helper loaded: url_helper
INFO - 2023-05-27 16:52:40 --> Helper loaded: file_helper
INFO - 2023-05-27 16:52:40 --> Helper loaded: html_helper
INFO - 2023-05-27 16:52:40 --> Helper loaded: text_helper
INFO - 2023-05-27 16:52:40 --> Helper loaded: form_helper
INFO - 2023-05-27 16:52:40 --> Helper loaded: lang_helper
INFO - 2023-05-27 16:52:40 --> Helper loaded: security_helper
INFO - 2023-05-27 16:52:40 --> Helper loaded: cookie_helper
INFO - 2023-05-27 16:52:40 --> Database Driver Class Initialized
INFO - 2023-05-27 16:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 16:52:40 --> Parser Class Initialized
INFO - 2023-05-27 16:52:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 16:52:40 --> Pagination Class Initialized
INFO - 2023-05-27 16:52:40 --> Form Validation Class Initialized
INFO - 2023-05-27 16:52:40 --> Controller Class Initialized
INFO - 2023-05-27 16:52:40 --> Model Class Initialized
DEBUG - 2023-05-27 16:52:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-27 16:52:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 16:52:40 --> Config Class Initialized
INFO - 2023-05-27 16:52:40 --> Hooks Class Initialized
DEBUG - 2023-05-27 16:52:40 --> UTF-8 Support Enabled
INFO - 2023-05-27 16:52:40 --> Utf8 Class Initialized
INFO - 2023-05-27 16:52:40 --> URI Class Initialized
INFO - 2023-05-27 16:52:40 --> Router Class Initialized
INFO - 2023-05-27 16:52:40 --> Output Class Initialized
INFO - 2023-05-27 16:52:40 --> Security Class Initialized
DEBUG - 2023-05-27 16:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 16:52:40 --> Input Class Initialized
INFO - 2023-05-27 16:52:40 --> Language Class Initialized
INFO - 2023-05-27 16:52:40 --> Loader Class Initialized
INFO - 2023-05-27 16:52:40 --> Helper loaded: url_helper
INFO - 2023-05-27 16:52:40 --> Helper loaded: file_helper
INFO - 2023-05-27 16:52:40 --> Helper loaded: html_helper
INFO - 2023-05-27 16:52:40 --> Helper loaded: text_helper
INFO - 2023-05-27 16:52:40 --> Helper loaded: form_helper
INFO - 2023-05-27 16:52:40 --> Helper loaded: lang_helper
INFO - 2023-05-27 16:52:40 --> Helper loaded: security_helper
INFO - 2023-05-27 16:52:40 --> Helper loaded: cookie_helper
INFO - 2023-05-27 16:52:40 --> Database Driver Class Initialized
INFO - 2023-05-27 16:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 16:52:40 --> Parser Class Initialized
INFO - 2023-05-27 16:52:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 16:52:40 --> Pagination Class Initialized
INFO - 2023-05-27 16:52:40 --> Form Validation Class Initialized
INFO - 2023-05-27 16:52:40 --> Controller Class Initialized
INFO - 2023-05-27 16:52:40 --> Model Class Initialized
DEBUG - 2023-05-27 16:52:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 16:52:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-27 16:52:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-27 16:52:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-27 16:52:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-27 16:52:40 --> Model Class Initialized
INFO - 2023-05-27 16:52:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-27 16:52:40 --> Final output sent to browser
DEBUG - 2023-05-27 16:52:40 --> Total execution time: 0.0296
ERROR - 2023-05-27 16:52:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 16:52:43 --> Config Class Initialized
INFO - 2023-05-27 16:52:43 --> Hooks Class Initialized
DEBUG - 2023-05-27 16:52:43 --> UTF-8 Support Enabled
INFO - 2023-05-27 16:52:43 --> Utf8 Class Initialized
INFO - 2023-05-27 16:52:43 --> URI Class Initialized
INFO - 2023-05-27 16:52:43 --> Router Class Initialized
INFO - 2023-05-27 16:52:43 --> Output Class Initialized
INFO - 2023-05-27 16:52:43 --> Security Class Initialized
DEBUG - 2023-05-27 16:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 16:52:43 --> Input Class Initialized
INFO - 2023-05-27 16:52:43 --> Language Class Initialized
INFO - 2023-05-27 16:52:43 --> Loader Class Initialized
INFO - 2023-05-27 16:52:43 --> Helper loaded: url_helper
INFO - 2023-05-27 16:52:43 --> Helper loaded: file_helper
INFO - 2023-05-27 16:52:43 --> Helper loaded: html_helper
INFO - 2023-05-27 16:52:43 --> Helper loaded: text_helper
INFO - 2023-05-27 16:52:43 --> Helper loaded: form_helper
INFO - 2023-05-27 16:52:43 --> Helper loaded: lang_helper
INFO - 2023-05-27 16:52:43 --> Helper loaded: security_helper
INFO - 2023-05-27 16:52:43 --> Helper loaded: cookie_helper
INFO - 2023-05-27 16:52:43 --> Database Driver Class Initialized
INFO - 2023-05-27 16:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 16:52:43 --> Parser Class Initialized
INFO - 2023-05-27 16:52:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 16:52:43 --> Pagination Class Initialized
INFO - 2023-05-27 16:52:43 --> Form Validation Class Initialized
INFO - 2023-05-27 16:52:43 --> Controller Class Initialized
INFO - 2023-05-27 16:52:43 --> Model Class Initialized
DEBUG - 2023-05-27 16:52:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 16:52:43 --> Model Class Initialized
INFO - 2023-05-27 16:52:43 --> Final output sent to browser
DEBUG - 2023-05-27 16:52:43 --> Total execution time: 0.0192
ERROR - 2023-05-27 16:52:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 16:52:43 --> Config Class Initialized
INFO - 2023-05-27 16:52:43 --> Hooks Class Initialized
DEBUG - 2023-05-27 16:52:43 --> UTF-8 Support Enabled
INFO - 2023-05-27 16:52:43 --> Utf8 Class Initialized
INFO - 2023-05-27 16:52:43 --> URI Class Initialized
DEBUG - 2023-05-27 16:52:43 --> No URI present. Default controller set.
INFO - 2023-05-27 16:52:43 --> Router Class Initialized
INFO - 2023-05-27 16:52:43 --> Output Class Initialized
INFO - 2023-05-27 16:52:43 --> Security Class Initialized
DEBUG - 2023-05-27 16:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 16:52:43 --> Input Class Initialized
INFO - 2023-05-27 16:52:43 --> Language Class Initialized
INFO - 2023-05-27 16:52:43 --> Loader Class Initialized
INFO - 2023-05-27 16:52:43 --> Helper loaded: url_helper
INFO - 2023-05-27 16:52:43 --> Helper loaded: file_helper
INFO - 2023-05-27 16:52:43 --> Helper loaded: html_helper
INFO - 2023-05-27 16:52:43 --> Helper loaded: text_helper
INFO - 2023-05-27 16:52:43 --> Helper loaded: form_helper
INFO - 2023-05-27 16:52:43 --> Helper loaded: lang_helper
INFO - 2023-05-27 16:52:43 --> Helper loaded: security_helper
INFO - 2023-05-27 16:52:43 --> Helper loaded: cookie_helper
INFO - 2023-05-27 16:52:43 --> Database Driver Class Initialized
INFO - 2023-05-27 16:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 16:52:43 --> Parser Class Initialized
INFO - 2023-05-27 16:52:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 16:52:43 --> Pagination Class Initialized
INFO - 2023-05-27 16:52:43 --> Form Validation Class Initialized
INFO - 2023-05-27 16:52:43 --> Controller Class Initialized
INFO - 2023-05-27 16:52:43 --> Model Class Initialized
DEBUG - 2023-05-27 16:52:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 16:52:43 --> Model Class Initialized
DEBUG - 2023-05-27 16:52:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 16:52:43 --> Model Class Initialized
INFO - 2023-05-27 16:52:43 --> Model Class Initialized
INFO - 2023-05-27 16:52:43 --> Model Class Initialized
INFO - 2023-05-27 16:52:43 --> Model Class Initialized
DEBUG - 2023-05-27 16:52:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-27 16:52:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 16:52:43 --> Model Class Initialized
INFO - 2023-05-27 16:52:43 --> Model Class Initialized
INFO - 2023-05-27 16:52:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-27 16:52:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-27 16:52:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-27 16:52:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-27 16:52:43 --> Model Class Initialized
INFO - 2023-05-27 16:52:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-27 16:52:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-27 16:52:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-27 16:52:43 --> Final output sent to browser
DEBUG - 2023-05-27 16:52:43 --> Total execution time: 0.1612
ERROR - 2023-05-27 16:52:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 16:52:44 --> Config Class Initialized
INFO - 2023-05-27 16:52:44 --> Hooks Class Initialized
DEBUG - 2023-05-27 16:52:44 --> UTF-8 Support Enabled
INFO - 2023-05-27 16:52:44 --> Utf8 Class Initialized
INFO - 2023-05-27 16:52:44 --> URI Class Initialized
INFO - 2023-05-27 16:52:44 --> Router Class Initialized
INFO - 2023-05-27 16:52:44 --> Output Class Initialized
INFO - 2023-05-27 16:52:44 --> Security Class Initialized
DEBUG - 2023-05-27 16:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 16:52:44 --> Input Class Initialized
INFO - 2023-05-27 16:52:44 --> Language Class Initialized
INFO - 2023-05-27 16:52:44 --> Loader Class Initialized
INFO - 2023-05-27 16:52:44 --> Helper loaded: url_helper
INFO - 2023-05-27 16:52:44 --> Helper loaded: file_helper
INFO - 2023-05-27 16:52:44 --> Helper loaded: html_helper
INFO - 2023-05-27 16:52:44 --> Helper loaded: text_helper
INFO - 2023-05-27 16:52:44 --> Helper loaded: form_helper
INFO - 2023-05-27 16:52:44 --> Helper loaded: lang_helper
INFO - 2023-05-27 16:52:44 --> Helper loaded: security_helper
INFO - 2023-05-27 16:52:44 --> Helper loaded: cookie_helper
INFO - 2023-05-27 16:52:44 --> Database Driver Class Initialized
INFO - 2023-05-27 16:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 16:52:44 --> Parser Class Initialized
INFO - 2023-05-27 16:52:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 16:52:44 --> Pagination Class Initialized
INFO - 2023-05-27 16:52:44 --> Form Validation Class Initialized
INFO - 2023-05-27 16:52:44 --> Controller Class Initialized
DEBUG - 2023-05-27 16:52:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-27 16:52:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 16:52:44 --> Model Class Initialized
INFO - 2023-05-27 16:52:44 --> Final output sent to browser
DEBUG - 2023-05-27 16:52:44 --> Total execution time: 0.0128
ERROR - 2023-05-27 16:52:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 16:52:56 --> Config Class Initialized
INFO - 2023-05-27 16:52:56 --> Hooks Class Initialized
DEBUG - 2023-05-27 16:52:56 --> UTF-8 Support Enabled
INFO - 2023-05-27 16:52:56 --> Utf8 Class Initialized
INFO - 2023-05-27 16:52:56 --> URI Class Initialized
INFO - 2023-05-27 16:52:56 --> Router Class Initialized
INFO - 2023-05-27 16:52:56 --> Output Class Initialized
INFO - 2023-05-27 16:52:56 --> Security Class Initialized
DEBUG - 2023-05-27 16:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 16:52:56 --> Input Class Initialized
INFO - 2023-05-27 16:52:56 --> Language Class Initialized
INFO - 2023-05-27 16:52:56 --> Loader Class Initialized
INFO - 2023-05-27 16:52:56 --> Helper loaded: url_helper
INFO - 2023-05-27 16:52:56 --> Helper loaded: file_helper
INFO - 2023-05-27 16:52:56 --> Helper loaded: html_helper
INFO - 2023-05-27 16:52:56 --> Helper loaded: text_helper
INFO - 2023-05-27 16:52:56 --> Helper loaded: form_helper
INFO - 2023-05-27 16:52:56 --> Helper loaded: lang_helper
INFO - 2023-05-27 16:52:56 --> Helper loaded: security_helper
INFO - 2023-05-27 16:52:56 --> Helper loaded: cookie_helper
INFO - 2023-05-27 16:52:56 --> Database Driver Class Initialized
INFO - 2023-05-27 16:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 16:52:56 --> Parser Class Initialized
INFO - 2023-05-27 16:52:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 16:52:56 --> Pagination Class Initialized
INFO - 2023-05-27 16:52:56 --> Form Validation Class Initialized
INFO - 2023-05-27 16:52:56 --> Controller Class Initialized
INFO - 2023-05-27 16:52:56 --> Model Class Initialized
INFO - 2023-05-27 16:52:56 --> Model Class Initialized
INFO - 2023-05-27 16:52:56 --> Model Class Initialized
INFO - 2023-05-27 16:52:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report_batch_wise.php
DEBUG - 2023-05-27 16:52:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-27 16:52:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-27 16:52:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-27 16:52:56 --> Model Class Initialized
INFO - 2023-05-27 16:52:56 --> Model Class Initialized
INFO - 2023-05-27 16:52:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-27 16:52:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-27 16:52:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-27 16:52:56 --> Final output sent to browser
DEBUG - 2023-05-27 16:52:56 --> Total execution time: 0.1326
ERROR - 2023-05-27 16:52:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 16:52:57 --> Config Class Initialized
INFO - 2023-05-27 16:52:57 --> Hooks Class Initialized
DEBUG - 2023-05-27 16:52:57 --> UTF-8 Support Enabled
INFO - 2023-05-27 16:52:57 --> Utf8 Class Initialized
INFO - 2023-05-27 16:52:57 --> URI Class Initialized
INFO - 2023-05-27 16:52:57 --> Router Class Initialized
INFO - 2023-05-27 16:52:57 --> Output Class Initialized
INFO - 2023-05-27 16:52:57 --> Security Class Initialized
DEBUG - 2023-05-27 16:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 16:52:57 --> Input Class Initialized
INFO - 2023-05-27 16:52:57 --> Language Class Initialized
INFO - 2023-05-27 16:52:57 --> Loader Class Initialized
INFO - 2023-05-27 16:52:57 --> Helper loaded: url_helper
INFO - 2023-05-27 16:52:57 --> Helper loaded: file_helper
INFO - 2023-05-27 16:52:57 --> Helper loaded: html_helper
INFO - 2023-05-27 16:52:57 --> Helper loaded: text_helper
INFO - 2023-05-27 16:52:57 --> Helper loaded: form_helper
INFO - 2023-05-27 16:52:57 --> Helper loaded: lang_helper
INFO - 2023-05-27 16:52:57 --> Helper loaded: security_helper
INFO - 2023-05-27 16:52:57 --> Helper loaded: cookie_helper
INFO - 2023-05-27 16:52:57 --> Database Driver Class Initialized
INFO - 2023-05-27 16:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 16:52:57 --> Parser Class Initialized
INFO - 2023-05-27 16:52:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 16:52:57 --> Pagination Class Initialized
INFO - 2023-05-27 16:52:57 --> Form Validation Class Initialized
INFO - 2023-05-27 16:52:57 --> Controller Class Initialized
INFO - 2023-05-27 16:52:57 --> Model Class Initialized
INFO - 2023-05-27 16:52:57 --> Model Class Initialized
INFO - 2023-05-27 16:52:57 --> Final output sent to browser
DEBUG - 2023-05-27 16:52:57 --> Total execution time: 0.0249
ERROR - 2023-05-27 16:53:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 16:53:00 --> Config Class Initialized
INFO - 2023-05-27 16:53:00 --> Hooks Class Initialized
DEBUG - 2023-05-27 16:53:00 --> UTF-8 Support Enabled
INFO - 2023-05-27 16:53:00 --> Utf8 Class Initialized
INFO - 2023-05-27 16:53:00 --> URI Class Initialized
INFO - 2023-05-27 16:53:00 --> Router Class Initialized
INFO - 2023-05-27 16:53:00 --> Output Class Initialized
INFO - 2023-05-27 16:53:00 --> Security Class Initialized
DEBUG - 2023-05-27 16:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 16:53:00 --> Input Class Initialized
INFO - 2023-05-27 16:53:00 --> Language Class Initialized
INFO - 2023-05-27 16:53:00 --> Loader Class Initialized
INFO - 2023-05-27 16:53:00 --> Helper loaded: url_helper
INFO - 2023-05-27 16:53:00 --> Helper loaded: file_helper
INFO - 2023-05-27 16:53:00 --> Helper loaded: html_helper
INFO - 2023-05-27 16:53:00 --> Helper loaded: text_helper
INFO - 2023-05-27 16:53:00 --> Helper loaded: form_helper
INFO - 2023-05-27 16:53:00 --> Helper loaded: lang_helper
INFO - 2023-05-27 16:53:00 --> Helper loaded: security_helper
INFO - 2023-05-27 16:53:00 --> Helper loaded: cookie_helper
INFO - 2023-05-27 16:53:00 --> Database Driver Class Initialized
INFO - 2023-05-27 16:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 16:53:00 --> Parser Class Initialized
INFO - 2023-05-27 16:53:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 16:53:00 --> Pagination Class Initialized
INFO - 2023-05-27 16:53:00 --> Form Validation Class Initialized
INFO - 2023-05-27 16:53:00 --> Controller Class Initialized
INFO - 2023-05-27 16:53:00 --> Model Class Initialized
INFO - 2023-05-27 16:53:00 --> Model Class Initialized
INFO - 2023-05-27 16:53:00 --> Final output sent to browser
DEBUG - 2023-05-27 16:53:00 --> Total execution time: 0.0345
ERROR - 2023-05-27 16:53:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 16:53:51 --> Config Class Initialized
INFO - 2023-05-27 16:53:51 --> Hooks Class Initialized
DEBUG - 2023-05-27 16:53:51 --> UTF-8 Support Enabled
INFO - 2023-05-27 16:53:51 --> Utf8 Class Initialized
INFO - 2023-05-27 16:53:51 --> URI Class Initialized
DEBUG - 2023-05-27 16:53:51 --> No URI present. Default controller set.
INFO - 2023-05-27 16:53:51 --> Router Class Initialized
INFO - 2023-05-27 16:53:51 --> Output Class Initialized
INFO - 2023-05-27 16:53:51 --> Security Class Initialized
DEBUG - 2023-05-27 16:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 16:53:51 --> Input Class Initialized
INFO - 2023-05-27 16:53:51 --> Language Class Initialized
INFO - 2023-05-27 16:53:51 --> Loader Class Initialized
INFO - 2023-05-27 16:53:51 --> Helper loaded: url_helper
INFO - 2023-05-27 16:53:51 --> Helper loaded: file_helper
INFO - 2023-05-27 16:53:51 --> Helper loaded: html_helper
INFO - 2023-05-27 16:53:51 --> Helper loaded: text_helper
INFO - 2023-05-27 16:53:51 --> Helper loaded: form_helper
INFO - 2023-05-27 16:53:51 --> Helper loaded: lang_helper
INFO - 2023-05-27 16:53:51 --> Helper loaded: security_helper
INFO - 2023-05-27 16:53:51 --> Helper loaded: cookie_helper
INFO - 2023-05-27 16:53:51 --> Database Driver Class Initialized
INFO - 2023-05-27 16:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 16:53:51 --> Parser Class Initialized
INFO - 2023-05-27 16:53:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 16:53:51 --> Pagination Class Initialized
INFO - 2023-05-27 16:53:51 --> Form Validation Class Initialized
INFO - 2023-05-27 16:53:51 --> Controller Class Initialized
INFO - 2023-05-27 16:53:51 --> Model Class Initialized
DEBUG - 2023-05-27 16:53:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-27 16:53:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 16:53:52 --> Config Class Initialized
INFO - 2023-05-27 16:53:52 --> Hooks Class Initialized
DEBUG - 2023-05-27 16:53:52 --> UTF-8 Support Enabled
INFO - 2023-05-27 16:53:52 --> Utf8 Class Initialized
INFO - 2023-05-27 16:53:52 --> URI Class Initialized
INFO - 2023-05-27 16:53:52 --> Router Class Initialized
INFO - 2023-05-27 16:53:52 --> Output Class Initialized
INFO - 2023-05-27 16:53:52 --> Security Class Initialized
DEBUG - 2023-05-27 16:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 16:53:52 --> Input Class Initialized
INFO - 2023-05-27 16:53:52 --> Language Class Initialized
INFO - 2023-05-27 16:53:52 --> Loader Class Initialized
INFO - 2023-05-27 16:53:52 --> Helper loaded: url_helper
INFO - 2023-05-27 16:53:52 --> Helper loaded: file_helper
INFO - 2023-05-27 16:53:52 --> Helper loaded: html_helper
INFO - 2023-05-27 16:53:52 --> Helper loaded: text_helper
INFO - 2023-05-27 16:53:52 --> Helper loaded: form_helper
INFO - 2023-05-27 16:53:52 --> Helper loaded: lang_helper
INFO - 2023-05-27 16:53:52 --> Helper loaded: security_helper
INFO - 2023-05-27 16:53:52 --> Helper loaded: cookie_helper
INFO - 2023-05-27 16:53:52 --> Database Driver Class Initialized
INFO - 2023-05-27 16:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 16:53:52 --> Parser Class Initialized
INFO - 2023-05-27 16:53:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 16:53:52 --> Pagination Class Initialized
INFO - 2023-05-27 16:53:52 --> Form Validation Class Initialized
INFO - 2023-05-27 16:53:52 --> Controller Class Initialized
INFO - 2023-05-27 16:53:52 --> Model Class Initialized
DEBUG - 2023-05-27 16:53:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 16:53:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-27 16:53:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-27 16:53:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-27 16:53:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-27 16:53:52 --> Model Class Initialized
INFO - 2023-05-27 16:53:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-27 16:53:52 --> Final output sent to browser
DEBUG - 2023-05-27 16:53:52 --> Total execution time: 0.0325
ERROR - 2023-05-27 16:53:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 16:53:56 --> Config Class Initialized
INFO - 2023-05-27 16:53:56 --> Hooks Class Initialized
DEBUG - 2023-05-27 16:53:56 --> UTF-8 Support Enabled
INFO - 2023-05-27 16:53:56 --> Utf8 Class Initialized
INFO - 2023-05-27 16:53:56 --> URI Class Initialized
INFO - 2023-05-27 16:53:56 --> Router Class Initialized
INFO - 2023-05-27 16:53:56 --> Output Class Initialized
INFO - 2023-05-27 16:53:56 --> Security Class Initialized
DEBUG - 2023-05-27 16:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 16:53:56 --> Input Class Initialized
INFO - 2023-05-27 16:53:56 --> Language Class Initialized
INFO - 2023-05-27 16:53:56 --> Loader Class Initialized
INFO - 2023-05-27 16:53:56 --> Helper loaded: url_helper
INFO - 2023-05-27 16:53:56 --> Helper loaded: file_helper
INFO - 2023-05-27 16:53:56 --> Helper loaded: html_helper
INFO - 2023-05-27 16:53:56 --> Helper loaded: text_helper
INFO - 2023-05-27 16:53:56 --> Helper loaded: form_helper
INFO - 2023-05-27 16:53:56 --> Helper loaded: lang_helper
INFO - 2023-05-27 16:53:56 --> Helper loaded: security_helper
INFO - 2023-05-27 16:53:56 --> Helper loaded: cookie_helper
INFO - 2023-05-27 16:53:56 --> Database Driver Class Initialized
INFO - 2023-05-27 16:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 16:53:56 --> Parser Class Initialized
INFO - 2023-05-27 16:53:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 16:53:56 --> Pagination Class Initialized
INFO - 2023-05-27 16:53:56 --> Form Validation Class Initialized
INFO - 2023-05-27 16:53:56 --> Controller Class Initialized
INFO - 2023-05-27 16:53:56 --> Model Class Initialized
DEBUG - 2023-05-27 16:53:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 16:53:56 --> Model Class Initialized
INFO - 2023-05-27 16:53:56 --> Final output sent to browser
DEBUG - 2023-05-27 16:53:56 --> Total execution time: 0.0167
ERROR - 2023-05-27 16:53:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 16:53:56 --> Config Class Initialized
INFO - 2023-05-27 16:53:56 --> Hooks Class Initialized
DEBUG - 2023-05-27 16:53:56 --> UTF-8 Support Enabled
INFO - 2023-05-27 16:53:56 --> Utf8 Class Initialized
INFO - 2023-05-27 16:53:56 --> URI Class Initialized
DEBUG - 2023-05-27 16:53:56 --> No URI present. Default controller set.
INFO - 2023-05-27 16:53:56 --> Router Class Initialized
INFO - 2023-05-27 16:53:56 --> Output Class Initialized
INFO - 2023-05-27 16:53:56 --> Security Class Initialized
DEBUG - 2023-05-27 16:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 16:53:56 --> Input Class Initialized
INFO - 2023-05-27 16:53:56 --> Language Class Initialized
INFO - 2023-05-27 16:53:56 --> Loader Class Initialized
INFO - 2023-05-27 16:53:56 --> Helper loaded: url_helper
INFO - 2023-05-27 16:53:56 --> Helper loaded: file_helper
INFO - 2023-05-27 16:53:56 --> Helper loaded: html_helper
INFO - 2023-05-27 16:53:56 --> Helper loaded: text_helper
INFO - 2023-05-27 16:53:56 --> Helper loaded: form_helper
INFO - 2023-05-27 16:53:56 --> Helper loaded: lang_helper
INFO - 2023-05-27 16:53:56 --> Helper loaded: security_helper
INFO - 2023-05-27 16:53:56 --> Helper loaded: cookie_helper
INFO - 2023-05-27 16:53:56 --> Database Driver Class Initialized
INFO - 2023-05-27 16:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 16:53:56 --> Parser Class Initialized
INFO - 2023-05-27 16:53:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 16:53:56 --> Pagination Class Initialized
INFO - 2023-05-27 16:53:56 --> Form Validation Class Initialized
INFO - 2023-05-27 16:53:56 --> Controller Class Initialized
INFO - 2023-05-27 16:53:56 --> Model Class Initialized
DEBUG - 2023-05-27 16:53:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 16:53:56 --> Model Class Initialized
DEBUG - 2023-05-27 16:53:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 16:53:56 --> Model Class Initialized
INFO - 2023-05-27 16:53:56 --> Model Class Initialized
INFO - 2023-05-27 16:53:56 --> Model Class Initialized
INFO - 2023-05-27 16:53:56 --> Model Class Initialized
DEBUG - 2023-05-27 16:53:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-27 16:53:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 16:53:56 --> Model Class Initialized
INFO - 2023-05-27 16:53:56 --> Model Class Initialized
INFO - 2023-05-27 16:53:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-27 16:53:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-27 16:53:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-27 16:53:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-27 16:53:57 --> Model Class Initialized
INFO - 2023-05-27 16:53:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-27 16:53:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-27 16:53:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-27 16:53:57 --> Final output sent to browser
DEBUG - 2023-05-27 16:53:57 --> Total execution time: 0.0781
ERROR - 2023-05-27 16:54:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 16:54:12 --> Config Class Initialized
INFO - 2023-05-27 16:54:12 --> Hooks Class Initialized
DEBUG - 2023-05-27 16:54:12 --> UTF-8 Support Enabled
INFO - 2023-05-27 16:54:12 --> Utf8 Class Initialized
INFO - 2023-05-27 16:54:12 --> URI Class Initialized
INFO - 2023-05-27 16:54:12 --> Router Class Initialized
INFO - 2023-05-27 16:54:12 --> Output Class Initialized
INFO - 2023-05-27 16:54:12 --> Security Class Initialized
DEBUG - 2023-05-27 16:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 16:54:12 --> Input Class Initialized
INFO - 2023-05-27 16:54:12 --> Language Class Initialized
INFO - 2023-05-27 16:54:12 --> Loader Class Initialized
INFO - 2023-05-27 16:54:12 --> Helper loaded: url_helper
INFO - 2023-05-27 16:54:12 --> Helper loaded: file_helper
INFO - 2023-05-27 16:54:12 --> Helper loaded: html_helper
INFO - 2023-05-27 16:54:12 --> Helper loaded: text_helper
INFO - 2023-05-27 16:54:12 --> Helper loaded: form_helper
INFO - 2023-05-27 16:54:12 --> Helper loaded: lang_helper
INFO - 2023-05-27 16:54:12 --> Helper loaded: security_helper
INFO - 2023-05-27 16:54:12 --> Helper loaded: cookie_helper
INFO - 2023-05-27 16:54:12 --> Database Driver Class Initialized
INFO - 2023-05-27 16:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 16:54:12 --> Parser Class Initialized
INFO - 2023-05-27 16:54:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 16:54:12 --> Pagination Class Initialized
INFO - 2023-05-27 16:54:12 --> Form Validation Class Initialized
INFO - 2023-05-27 16:54:12 --> Controller Class Initialized
INFO - 2023-05-27 16:54:12 --> Model Class Initialized
DEBUG - 2023-05-27 16:54:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-27 16:54:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 16:54:12 --> Model Class Initialized
INFO - 2023-05-27 16:54:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-05-27 16:54:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-27 16:54:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-27 16:54:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-27 16:54:12 --> Model Class Initialized
INFO - 2023-05-27 16:54:12 --> Model Class Initialized
INFO - 2023-05-27 16:54:12 --> Model Class Initialized
INFO - 2023-05-27 16:54:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-27 16:54:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-27 16:54:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-27 16:54:12 --> Final output sent to browser
DEBUG - 2023-05-27 16:54:12 --> Total execution time: 0.0684
ERROR - 2023-05-27 16:54:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 16:54:13 --> Config Class Initialized
INFO - 2023-05-27 16:54:13 --> Hooks Class Initialized
DEBUG - 2023-05-27 16:54:13 --> UTF-8 Support Enabled
INFO - 2023-05-27 16:54:13 --> Utf8 Class Initialized
INFO - 2023-05-27 16:54:13 --> URI Class Initialized
INFO - 2023-05-27 16:54:13 --> Router Class Initialized
INFO - 2023-05-27 16:54:13 --> Output Class Initialized
INFO - 2023-05-27 16:54:13 --> Security Class Initialized
DEBUG - 2023-05-27 16:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 16:54:13 --> Input Class Initialized
INFO - 2023-05-27 16:54:13 --> Language Class Initialized
INFO - 2023-05-27 16:54:13 --> Loader Class Initialized
INFO - 2023-05-27 16:54:13 --> Helper loaded: url_helper
INFO - 2023-05-27 16:54:13 --> Helper loaded: file_helper
INFO - 2023-05-27 16:54:13 --> Helper loaded: html_helper
INFO - 2023-05-27 16:54:13 --> Helper loaded: text_helper
INFO - 2023-05-27 16:54:13 --> Helper loaded: form_helper
INFO - 2023-05-27 16:54:13 --> Helper loaded: lang_helper
INFO - 2023-05-27 16:54:13 --> Helper loaded: security_helper
INFO - 2023-05-27 16:54:13 --> Helper loaded: cookie_helper
INFO - 2023-05-27 16:54:13 --> Database Driver Class Initialized
INFO - 2023-05-27 16:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 16:54:13 --> Parser Class Initialized
INFO - 2023-05-27 16:54:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 16:54:13 --> Pagination Class Initialized
INFO - 2023-05-27 16:54:13 --> Form Validation Class Initialized
INFO - 2023-05-27 16:54:13 --> Controller Class Initialized
INFO - 2023-05-27 16:54:13 --> Model Class Initialized
DEBUG - 2023-05-27 16:54:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-27 16:54:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 16:54:13 --> Model Class Initialized
INFO - 2023-05-27 16:54:13 --> Final output sent to browser
DEBUG - 2023-05-27 16:54:13 --> Total execution time: 0.0236
ERROR - 2023-05-27 16:54:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 16:54:16 --> Config Class Initialized
INFO - 2023-05-27 16:54:16 --> Hooks Class Initialized
DEBUG - 2023-05-27 16:54:16 --> UTF-8 Support Enabled
INFO - 2023-05-27 16:54:16 --> Utf8 Class Initialized
INFO - 2023-05-27 16:54:16 --> URI Class Initialized
INFO - 2023-05-27 16:54:16 --> Router Class Initialized
INFO - 2023-05-27 16:54:16 --> Output Class Initialized
INFO - 2023-05-27 16:54:16 --> Security Class Initialized
DEBUG - 2023-05-27 16:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 16:54:16 --> Input Class Initialized
INFO - 2023-05-27 16:54:16 --> Language Class Initialized
INFO - 2023-05-27 16:54:16 --> Loader Class Initialized
INFO - 2023-05-27 16:54:16 --> Helper loaded: url_helper
INFO - 2023-05-27 16:54:16 --> Helper loaded: file_helper
INFO - 2023-05-27 16:54:16 --> Helper loaded: html_helper
INFO - 2023-05-27 16:54:16 --> Helper loaded: text_helper
INFO - 2023-05-27 16:54:16 --> Helper loaded: form_helper
INFO - 2023-05-27 16:54:16 --> Helper loaded: lang_helper
INFO - 2023-05-27 16:54:16 --> Helper loaded: security_helper
INFO - 2023-05-27 16:54:16 --> Helper loaded: cookie_helper
INFO - 2023-05-27 16:54:16 --> Database Driver Class Initialized
INFO - 2023-05-27 16:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 16:54:16 --> Parser Class Initialized
INFO - 2023-05-27 16:54:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 16:54:16 --> Pagination Class Initialized
INFO - 2023-05-27 16:54:16 --> Form Validation Class Initialized
INFO - 2023-05-27 16:54:16 --> Controller Class Initialized
INFO - 2023-05-27 16:54:16 --> Model Class Initialized
DEBUG - 2023-05-27 16:54:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-27 16:54:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 16:54:16 --> Model Class Initialized
INFO - 2023-05-27 16:54:16 --> Final output sent to browser
DEBUG - 2023-05-27 16:54:16 --> Total execution time: 0.0220
ERROR - 2023-05-27 16:56:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 16:56:52 --> Config Class Initialized
INFO - 2023-05-27 16:56:52 --> Hooks Class Initialized
DEBUG - 2023-05-27 16:56:52 --> UTF-8 Support Enabled
INFO - 2023-05-27 16:56:52 --> Utf8 Class Initialized
INFO - 2023-05-27 16:56:52 --> URI Class Initialized
DEBUG - 2023-05-27 16:56:52 --> No URI present. Default controller set.
INFO - 2023-05-27 16:56:52 --> Router Class Initialized
INFO - 2023-05-27 16:56:52 --> Output Class Initialized
INFO - 2023-05-27 16:56:52 --> Security Class Initialized
DEBUG - 2023-05-27 16:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 16:56:52 --> Input Class Initialized
INFO - 2023-05-27 16:56:52 --> Language Class Initialized
INFO - 2023-05-27 16:56:52 --> Loader Class Initialized
INFO - 2023-05-27 16:56:52 --> Helper loaded: url_helper
INFO - 2023-05-27 16:56:52 --> Helper loaded: file_helper
INFO - 2023-05-27 16:56:52 --> Helper loaded: html_helper
INFO - 2023-05-27 16:56:52 --> Helper loaded: text_helper
INFO - 2023-05-27 16:56:52 --> Helper loaded: form_helper
INFO - 2023-05-27 16:56:52 --> Helper loaded: lang_helper
INFO - 2023-05-27 16:56:52 --> Helper loaded: security_helper
INFO - 2023-05-27 16:56:52 --> Helper loaded: cookie_helper
INFO - 2023-05-27 16:56:52 --> Database Driver Class Initialized
INFO - 2023-05-27 16:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 16:56:52 --> Parser Class Initialized
INFO - 2023-05-27 16:56:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 16:56:52 --> Pagination Class Initialized
INFO - 2023-05-27 16:56:52 --> Form Validation Class Initialized
INFO - 2023-05-27 16:56:52 --> Controller Class Initialized
INFO - 2023-05-27 16:56:52 --> Model Class Initialized
DEBUG - 2023-05-27 16:56:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 16:56:52 --> Model Class Initialized
DEBUG - 2023-05-27 16:56:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 16:56:52 --> Model Class Initialized
INFO - 2023-05-27 16:56:52 --> Model Class Initialized
INFO - 2023-05-27 16:56:52 --> Model Class Initialized
INFO - 2023-05-27 16:56:52 --> Model Class Initialized
DEBUG - 2023-05-27 16:56:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-27 16:56:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 16:56:52 --> Model Class Initialized
INFO - 2023-05-27 16:56:52 --> Model Class Initialized
INFO - 2023-05-27 16:56:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-27 16:56:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-27 16:56:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-27 16:56:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-27 16:56:52 --> Model Class Initialized
INFO - 2023-05-27 16:56:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-27 16:56:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-27 16:56:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-27 16:56:53 --> Final output sent to browser
DEBUG - 2023-05-27 16:56:53 --> Total execution time: 0.0793
ERROR - 2023-05-27 16:57:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 16:57:02 --> Config Class Initialized
INFO - 2023-05-27 16:57:02 --> Hooks Class Initialized
DEBUG - 2023-05-27 16:57:02 --> UTF-8 Support Enabled
INFO - 2023-05-27 16:57:02 --> Utf8 Class Initialized
INFO - 2023-05-27 16:57:02 --> URI Class Initialized
INFO - 2023-05-27 16:57:02 --> Router Class Initialized
INFO - 2023-05-27 16:57:02 --> Output Class Initialized
INFO - 2023-05-27 16:57:02 --> Security Class Initialized
DEBUG - 2023-05-27 16:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 16:57:02 --> Input Class Initialized
INFO - 2023-05-27 16:57:02 --> Language Class Initialized
INFO - 2023-05-27 16:57:02 --> Loader Class Initialized
INFO - 2023-05-27 16:57:02 --> Helper loaded: url_helper
INFO - 2023-05-27 16:57:02 --> Helper loaded: file_helper
INFO - 2023-05-27 16:57:02 --> Helper loaded: html_helper
INFO - 2023-05-27 16:57:02 --> Helper loaded: text_helper
INFO - 2023-05-27 16:57:02 --> Helper loaded: form_helper
INFO - 2023-05-27 16:57:02 --> Helper loaded: lang_helper
INFO - 2023-05-27 16:57:02 --> Helper loaded: security_helper
INFO - 2023-05-27 16:57:02 --> Helper loaded: cookie_helper
INFO - 2023-05-27 16:57:02 --> Database Driver Class Initialized
INFO - 2023-05-27 16:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 16:57:02 --> Parser Class Initialized
INFO - 2023-05-27 16:57:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 16:57:02 --> Pagination Class Initialized
INFO - 2023-05-27 16:57:02 --> Form Validation Class Initialized
INFO - 2023-05-27 16:57:02 --> Controller Class Initialized
INFO - 2023-05-27 16:57:02 --> Model Class Initialized
DEBUG - 2023-05-27 16:57:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-27 16:57:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 16:57:02 --> Model Class Initialized
DEBUG - 2023-05-27 16:57:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 16:57:02 --> Model Class Initialized
INFO - 2023-05-27 16:57:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-27 16:57:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-27 16:57:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-27 16:57:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-27 16:57:02 --> Model Class Initialized
INFO - 2023-05-27 16:57:02 --> Model Class Initialized
INFO - 2023-05-27 16:57:02 --> Model Class Initialized
INFO - 2023-05-27 16:57:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-27 16:57:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-27 16:57:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-27 16:57:02 --> Final output sent to browser
DEBUG - 2023-05-27 16:57:02 --> Total execution time: 0.0660
ERROR - 2023-05-27 16:57:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 16:57:03 --> Config Class Initialized
INFO - 2023-05-27 16:57:03 --> Hooks Class Initialized
DEBUG - 2023-05-27 16:57:03 --> UTF-8 Support Enabled
INFO - 2023-05-27 16:57:03 --> Utf8 Class Initialized
INFO - 2023-05-27 16:57:03 --> URI Class Initialized
INFO - 2023-05-27 16:57:03 --> Router Class Initialized
INFO - 2023-05-27 16:57:03 --> Output Class Initialized
INFO - 2023-05-27 16:57:03 --> Security Class Initialized
DEBUG - 2023-05-27 16:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 16:57:03 --> Input Class Initialized
INFO - 2023-05-27 16:57:03 --> Language Class Initialized
INFO - 2023-05-27 16:57:03 --> Loader Class Initialized
INFO - 2023-05-27 16:57:03 --> Helper loaded: url_helper
INFO - 2023-05-27 16:57:03 --> Helper loaded: file_helper
INFO - 2023-05-27 16:57:03 --> Helper loaded: html_helper
INFO - 2023-05-27 16:57:03 --> Helper loaded: text_helper
INFO - 2023-05-27 16:57:03 --> Helper loaded: form_helper
INFO - 2023-05-27 16:57:03 --> Helper loaded: lang_helper
INFO - 2023-05-27 16:57:03 --> Helper loaded: security_helper
INFO - 2023-05-27 16:57:03 --> Helper loaded: cookie_helper
INFO - 2023-05-27 16:57:03 --> Database Driver Class Initialized
INFO - 2023-05-27 16:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 16:57:03 --> Parser Class Initialized
INFO - 2023-05-27 16:57:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 16:57:03 --> Pagination Class Initialized
INFO - 2023-05-27 16:57:03 --> Form Validation Class Initialized
INFO - 2023-05-27 16:57:03 --> Controller Class Initialized
INFO - 2023-05-27 16:57:03 --> Model Class Initialized
DEBUG - 2023-05-27 16:57:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-27 16:57:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 16:57:03 --> Model Class Initialized
DEBUG - 2023-05-27 16:57:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 16:57:03 --> Model Class Initialized
INFO - 2023-05-27 16:57:03 --> Final output sent to browser
DEBUG - 2023-05-27 16:57:03 --> Total execution time: 0.0366
ERROR - 2023-05-27 16:57:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-27 16:57:06 --> Config Class Initialized
INFO - 2023-05-27 16:57:06 --> Hooks Class Initialized
DEBUG - 2023-05-27 16:57:06 --> UTF-8 Support Enabled
INFO - 2023-05-27 16:57:06 --> Utf8 Class Initialized
INFO - 2023-05-27 16:57:06 --> URI Class Initialized
INFO - 2023-05-27 16:57:06 --> Router Class Initialized
INFO - 2023-05-27 16:57:06 --> Output Class Initialized
INFO - 2023-05-27 16:57:06 --> Security Class Initialized
DEBUG - 2023-05-27 16:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 16:57:06 --> Input Class Initialized
INFO - 2023-05-27 16:57:06 --> Language Class Initialized
INFO - 2023-05-27 16:57:06 --> Loader Class Initialized
INFO - 2023-05-27 16:57:06 --> Helper loaded: url_helper
INFO - 2023-05-27 16:57:06 --> Helper loaded: file_helper
INFO - 2023-05-27 16:57:06 --> Helper loaded: html_helper
INFO - 2023-05-27 16:57:06 --> Helper loaded: text_helper
INFO - 2023-05-27 16:57:06 --> Helper loaded: form_helper
INFO - 2023-05-27 16:57:06 --> Helper loaded: lang_helper
INFO - 2023-05-27 16:57:06 --> Helper loaded: security_helper
INFO - 2023-05-27 16:57:06 --> Helper loaded: cookie_helper
INFO - 2023-05-27 16:57:06 --> Database Driver Class Initialized
INFO - 2023-05-27 16:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-27 16:57:06 --> Parser Class Initialized
INFO - 2023-05-27 16:57:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-27 16:57:06 --> Pagination Class Initialized
INFO - 2023-05-27 16:57:06 --> Form Validation Class Initialized
INFO - 2023-05-27 16:57:06 --> Controller Class Initialized
INFO - 2023-05-27 16:57:06 --> Model Class Initialized
DEBUG - 2023-05-27 16:57:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-27 16:57:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 16:57:06 --> Model Class Initialized
DEBUG - 2023-05-27 16:57:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-27 16:57:06 --> Model Class Initialized
INFO - 2023-05-27 16:57:07 --> Final output sent to browser
DEBUG - 2023-05-27 16:57:07 --> Total execution time: 0.0684
