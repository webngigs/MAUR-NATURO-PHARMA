<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-28 04:32:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 04:32:34 --> Config Class Initialized
INFO - 2023-10-28 04:32:34 --> Hooks Class Initialized
DEBUG - 2023-10-28 04:32:34 --> UTF-8 Support Enabled
INFO - 2023-10-28 04:32:34 --> Utf8 Class Initialized
INFO - 2023-10-28 04:32:34 --> URI Class Initialized
INFO - 2023-10-28 04:32:34 --> Router Class Initialized
INFO - 2023-10-28 04:32:34 --> Output Class Initialized
INFO - 2023-10-28 04:32:34 --> Security Class Initialized
DEBUG - 2023-10-28 04:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 04:32:34 --> Input Class Initialized
INFO - 2023-10-28 04:32:34 --> Language Class Initialized
ERROR - 2023-10-28 04:32:34 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-10-28 10:52:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 10:52:48 --> Config Class Initialized
INFO - 2023-10-28 10:52:48 --> Hooks Class Initialized
DEBUG - 2023-10-28 10:52:48 --> UTF-8 Support Enabled
INFO - 2023-10-28 10:52:48 --> Utf8 Class Initialized
INFO - 2023-10-28 10:52:48 --> URI Class Initialized
DEBUG - 2023-10-28 10:52:48 --> No URI present. Default controller set.
INFO - 2023-10-28 10:52:48 --> Router Class Initialized
INFO - 2023-10-28 10:52:48 --> Output Class Initialized
INFO - 2023-10-28 10:52:48 --> Security Class Initialized
DEBUG - 2023-10-28 10:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 10:52:48 --> Input Class Initialized
INFO - 2023-10-28 10:52:48 --> Language Class Initialized
INFO - 2023-10-28 10:52:48 --> Loader Class Initialized
INFO - 2023-10-28 10:52:48 --> Helper loaded: url_helper
INFO - 2023-10-28 10:52:48 --> Helper loaded: file_helper
INFO - 2023-10-28 10:52:48 --> Helper loaded: html_helper
INFO - 2023-10-28 10:52:48 --> Helper loaded: text_helper
INFO - 2023-10-28 10:52:48 --> Helper loaded: form_helper
INFO - 2023-10-28 10:52:48 --> Helper loaded: lang_helper
INFO - 2023-10-28 10:52:48 --> Helper loaded: security_helper
INFO - 2023-10-28 10:52:48 --> Helper loaded: cookie_helper
INFO - 2023-10-28 10:52:48 --> Database Driver Class Initialized
INFO - 2023-10-28 10:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 10:52:48 --> Parser Class Initialized
INFO - 2023-10-28 10:52:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 10:52:48 --> Pagination Class Initialized
INFO - 2023-10-28 10:52:48 --> Form Validation Class Initialized
INFO - 2023-10-28 10:52:48 --> Controller Class Initialized
INFO - 2023-10-28 10:52:48 --> Model Class Initialized
DEBUG - 2023-10-28 10:52:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-28 10:52:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 10:52:48 --> Config Class Initialized
INFO - 2023-10-28 10:52:48 --> Hooks Class Initialized
DEBUG - 2023-10-28 10:52:48 --> UTF-8 Support Enabled
INFO - 2023-10-28 10:52:48 --> Utf8 Class Initialized
INFO - 2023-10-28 10:52:48 --> URI Class Initialized
INFO - 2023-10-28 10:52:48 --> Router Class Initialized
INFO - 2023-10-28 10:52:48 --> Output Class Initialized
INFO - 2023-10-28 10:52:48 --> Security Class Initialized
DEBUG - 2023-10-28 10:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 10:52:48 --> Input Class Initialized
INFO - 2023-10-28 10:52:48 --> Language Class Initialized
INFO - 2023-10-28 10:52:48 --> Loader Class Initialized
INFO - 2023-10-28 10:52:48 --> Helper loaded: url_helper
INFO - 2023-10-28 10:52:48 --> Helper loaded: file_helper
INFO - 2023-10-28 10:52:48 --> Helper loaded: html_helper
INFO - 2023-10-28 10:52:48 --> Helper loaded: text_helper
INFO - 2023-10-28 10:52:48 --> Helper loaded: form_helper
INFO - 2023-10-28 10:52:48 --> Helper loaded: lang_helper
INFO - 2023-10-28 10:52:48 --> Helper loaded: security_helper
INFO - 2023-10-28 10:52:48 --> Helper loaded: cookie_helper
INFO - 2023-10-28 10:52:48 --> Database Driver Class Initialized
INFO - 2023-10-28 10:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 10:52:48 --> Parser Class Initialized
INFO - 2023-10-28 10:52:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 10:52:48 --> Pagination Class Initialized
INFO - 2023-10-28 10:52:48 --> Form Validation Class Initialized
INFO - 2023-10-28 10:52:48 --> Controller Class Initialized
INFO - 2023-10-28 10:52:48 --> Model Class Initialized
DEBUG - 2023-10-28 10:52:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:52:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-28 10:52:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:52:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 10:52:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 10:52:48 --> Model Class Initialized
INFO - 2023-10-28 10:52:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 10:52:48 --> Final output sent to browser
DEBUG - 2023-10-28 10:52:48 --> Total execution time: 0.0329
ERROR - 2023-10-28 10:53:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 10:53:10 --> Config Class Initialized
INFO - 2023-10-28 10:53:10 --> Hooks Class Initialized
DEBUG - 2023-10-28 10:53:10 --> UTF-8 Support Enabled
INFO - 2023-10-28 10:53:10 --> Utf8 Class Initialized
INFO - 2023-10-28 10:53:10 --> URI Class Initialized
INFO - 2023-10-28 10:53:10 --> Router Class Initialized
INFO - 2023-10-28 10:53:10 --> Output Class Initialized
INFO - 2023-10-28 10:53:10 --> Security Class Initialized
DEBUG - 2023-10-28 10:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 10:53:10 --> Input Class Initialized
INFO - 2023-10-28 10:53:10 --> Language Class Initialized
INFO - 2023-10-28 10:53:10 --> Loader Class Initialized
INFO - 2023-10-28 10:53:10 --> Helper loaded: url_helper
INFO - 2023-10-28 10:53:10 --> Helper loaded: file_helper
INFO - 2023-10-28 10:53:10 --> Helper loaded: html_helper
INFO - 2023-10-28 10:53:10 --> Helper loaded: text_helper
INFO - 2023-10-28 10:53:10 --> Helper loaded: form_helper
INFO - 2023-10-28 10:53:10 --> Helper loaded: lang_helper
INFO - 2023-10-28 10:53:10 --> Helper loaded: security_helper
INFO - 2023-10-28 10:53:10 --> Helper loaded: cookie_helper
INFO - 2023-10-28 10:53:10 --> Database Driver Class Initialized
INFO - 2023-10-28 10:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 10:53:10 --> Parser Class Initialized
INFO - 2023-10-28 10:53:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 10:53:10 --> Pagination Class Initialized
INFO - 2023-10-28 10:53:10 --> Form Validation Class Initialized
INFO - 2023-10-28 10:53:10 --> Controller Class Initialized
INFO - 2023-10-28 10:53:10 --> Model Class Initialized
DEBUG - 2023-10-28 10:53:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:53:10 --> Model Class Initialized
INFO - 2023-10-28 10:53:10 --> Final output sent to browser
DEBUG - 2023-10-28 10:53:10 --> Total execution time: 0.0205
ERROR - 2023-10-28 10:53:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 10:53:11 --> Config Class Initialized
INFO - 2023-10-28 10:53:11 --> Hooks Class Initialized
DEBUG - 2023-10-28 10:53:11 --> UTF-8 Support Enabled
INFO - 2023-10-28 10:53:11 --> Utf8 Class Initialized
INFO - 2023-10-28 10:53:11 --> URI Class Initialized
INFO - 2023-10-28 10:53:11 --> Router Class Initialized
INFO - 2023-10-28 10:53:11 --> Output Class Initialized
INFO - 2023-10-28 10:53:11 --> Security Class Initialized
DEBUG - 2023-10-28 10:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 10:53:11 --> Input Class Initialized
INFO - 2023-10-28 10:53:11 --> Language Class Initialized
INFO - 2023-10-28 10:53:11 --> Loader Class Initialized
INFO - 2023-10-28 10:53:11 --> Helper loaded: url_helper
INFO - 2023-10-28 10:53:11 --> Helper loaded: file_helper
INFO - 2023-10-28 10:53:11 --> Helper loaded: html_helper
INFO - 2023-10-28 10:53:11 --> Helper loaded: text_helper
INFO - 2023-10-28 10:53:11 --> Helper loaded: form_helper
INFO - 2023-10-28 10:53:11 --> Helper loaded: lang_helper
INFO - 2023-10-28 10:53:11 --> Helper loaded: security_helper
INFO - 2023-10-28 10:53:11 --> Helper loaded: cookie_helper
INFO - 2023-10-28 10:53:11 --> Database Driver Class Initialized
INFO - 2023-10-28 10:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 10:53:11 --> Parser Class Initialized
INFO - 2023-10-28 10:53:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 10:53:11 --> Pagination Class Initialized
INFO - 2023-10-28 10:53:11 --> Form Validation Class Initialized
INFO - 2023-10-28 10:53:11 --> Controller Class Initialized
INFO - 2023-10-28 10:53:11 --> Model Class Initialized
DEBUG - 2023-10-28 10:53:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:53:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-28 10:53:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:53:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 10:53:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 10:53:11 --> Model Class Initialized
INFO - 2023-10-28 10:53:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 10:53:11 --> Final output sent to browser
DEBUG - 2023-10-28 10:53:11 --> Total execution time: 0.0288
ERROR - 2023-10-28 10:53:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 10:53:52 --> Config Class Initialized
INFO - 2023-10-28 10:53:52 --> Hooks Class Initialized
DEBUG - 2023-10-28 10:53:52 --> UTF-8 Support Enabled
INFO - 2023-10-28 10:53:52 --> Utf8 Class Initialized
INFO - 2023-10-28 10:53:52 --> URI Class Initialized
DEBUG - 2023-10-28 10:53:52 --> No URI present. Default controller set.
INFO - 2023-10-28 10:53:52 --> Router Class Initialized
INFO - 2023-10-28 10:53:52 --> Output Class Initialized
INFO - 2023-10-28 10:53:52 --> Security Class Initialized
DEBUG - 2023-10-28 10:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 10:53:52 --> Input Class Initialized
INFO - 2023-10-28 10:53:52 --> Language Class Initialized
INFO - 2023-10-28 10:53:52 --> Loader Class Initialized
INFO - 2023-10-28 10:53:52 --> Helper loaded: url_helper
INFO - 2023-10-28 10:53:52 --> Helper loaded: file_helper
INFO - 2023-10-28 10:53:52 --> Helper loaded: html_helper
INFO - 2023-10-28 10:53:52 --> Helper loaded: text_helper
INFO - 2023-10-28 10:53:52 --> Helper loaded: form_helper
INFO - 2023-10-28 10:53:52 --> Helper loaded: lang_helper
INFO - 2023-10-28 10:53:52 --> Helper loaded: security_helper
INFO - 2023-10-28 10:53:52 --> Helper loaded: cookie_helper
INFO - 2023-10-28 10:53:52 --> Database Driver Class Initialized
INFO - 2023-10-28 10:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 10:53:52 --> Parser Class Initialized
INFO - 2023-10-28 10:53:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 10:53:52 --> Pagination Class Initialized
INFO - 2023-10-28 10:53:52 --> Form Validation Class Initialized
INFO - 2023-10-28 10:53:52 --> Controller Class Initialized
INFO - 2023-10-28 10:53:52 --> Model Class Initialized
DEBUG - 2023-10-28 10:53:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-28 10:53:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 10:53:52 --> Config Class Initialized
INFO - 2023-10-28 10:53:52 --> Hooks Class Initialized
DEBUG - 2023-10-28 10:53:52 --> UTF-8 Support Enabled
INFO - 2023-10-28 10:53:52 --> Utf8 Class Initialized
INFO - 2023-10-28 10:53:52 --> URI Class Initialized
INFO - 2023-10-28 10:53:52 --> Router Class Initialized
INFO - 2023-10-28 10:53:52 --> Output Class Initialized
INFO - 2023-10-28 10:53:52 --> Security Class Initialized
DEBUG - 2023-10-28 10:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 10:53:52 --> Input Class Initialized
INFO - 2023-10-28 10:53:52 --> Language Class Initialized
INFO - 2023-10-28 10:53:52 --> Loader Class Initialized
INFO - 2023-10-28 10:53:52 --> Helper loaded: url_helper
INFO - 2023-10-28 10:53:52 --> Helper loaded: file_helper
INFO - 2023-10-28 10:53:52 --> Helper loaded: html_helper
INFO - 2023-10-28 10:53:52 --> Helper loaded: text_helper
INFO - 2023-10-28 10:53:52 --> Helper loaded: form_helper
INFO - 2023-10-28 10:53:52 --> Helper loaded: lang_helper
INFO - 2023-10-28 10:53:52 --> Helper loaded: security_helper
INFO - 2023-10-28 10:53:52 --> Helper loaded: cookie_helper
INFO - 2023-10-28 10:53:52 --> Database Driver Class Initialized
INFO - 2023-10-28 10:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 10:53:52 --> Parser Class Initialized
INFO - 2023-10-28 10:53:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 10:53:52 --> Pagination Class Initialized
INFO - 2023-10-28 10:53:52 --> Form Validation Class Initialized
INFO - 2023-10-28 10:53:52 --> Controller Class Initialized
INFO - 2023-10-28 10:53:52 --> Model Class Initialized
DEBUG - 2023-10-28 10:53:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:53:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-28 10:53:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:53:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 10:53:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 10:53:52 --> Model Class Initialized
INFO - 2023-10-28 10:53:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 10:53:52 --> Final output sent to browser
DEBUG - 2023-10-28 10:53:52 --> Total execution time: 0.0314
ERROR - 2023-10-28 10:53:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 10:53:56 --> Config Class Initialized
INFO - 2023-10-28 10:53:56 --> Hooks Class Initialized
DEBUG - 2023-10-28 10:53:56 --> UTF-8 Support Enabled
INFO - 2023-10-28 10:53:56 --> Utf8 Class Initialized
INFO - 2023-10-28 10:53:56 --> URI Class Initialized
INFO - 2023-10-28 10:53:56 --> Router Class Initialized
INFO - 2023-10-28 10:53:56 --> Output Class Initialized
INFO - 2023-10-28 10:53:56 --> Security Class Initialized
DEBUG - 2023-10-28 10:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 10:53:56 --> Input Class Initialized
INFO - 2023-10-28 10:53:56 --> Language Class Initialized
INFO - 2023-10-28 10:53:56 --> Loader Class Initialized
INFO - 2023-10-28 10:53:56 --> Helper loaded: url_helper
INFO - 2023-10-28 10:53:56 --> Helper loaded: file_helper
INFO - 2023-10-28 10:53:56 --> Helper loaded: html_helper
INFO - 2023-10-28 10:53:56 --> Helper loaded: text_helper
INFO - 2023-10-28 10:53:56 --> Helper loaded: form_helper
INFO - 2023-10-28 10:53:56 --> Helper loaded: lang_helper
INFO - 2023-10-28 10:53:56 --> Helper loaded: security_helper
INFO - 2023-10-28 10:53:56 --> Helper loaded: cookie_helper
INFO - 2023-10-28 10:53:56 --> Database Driver Class Initialized
INFO - 2023-10-28 10:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 10:53:56 --> Parser Class Initialized
INFO - 2023-10-28 10:53:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 10:53:56 --> Pagination Class Initialized
INFO - 2023-10-28 10:53:56 --> Form Validation Class Initialized
INFO - 2023-10-28 10:53:56 --> Controller Class Initialized
INFO - 2023-10-28 10:53:56 --> Model Class Initialized
DEBUG - 2023-10-28 10:53:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:53:56 --> Model Class Initialized
INFO - 2023-10-28 10:53:56 --> Final output sent to browser
DEBUG - 2023-10-28 10:53:56 --> Total execution time: 0.0204
ERROR - 2023-10-28 10:53:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 10:53:56 --> Config Class Initialized
INFO - 2023-10-28 10:53:56 --> Hooks Class Initialized
DEBUG - 2023-10-28 10:53:56 --> UTF-8 Support Enabled
INFO - 2023-10-28 10:53:56 --> Utf8 Class Initialized
INFO - 2023-10-28 10:53:56 --> URI Class Initialized
DEBUG - 2023-10-28 10:53:56 --> No URI present. Default controller set.
INFO - 2023-10-28 10:53:56 --> Router Class Initialized
INFO - 2023-10-28 10:53:56 --> Output Class Initialized
INFO - 2023-10-28 10:53:56 --> Security Class Initialized
DEBUG - 2023-10-28 10:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 10:53:56 --> Input Class Initialized
INFO - 2023-10-28 10:53:56 --> Language Class Initialized
INFO - 2023-10-28 10:53:56 --> Loader Class Initialized
INFO - 2023-10-28 10:53:56 --> Helper loaded: url_helper
INFO - 2023-10-28 10:53:56 --> Helper loaded: file_helper
INFO - 2023-10-28 10:53:56 --> Helper loaded: html_helper
INFO - 2023-10-28 10:53:56 --> Helper loaded: text_helper
INFO - 2023-10-28 10:53:56 --> Helper loaded: form_helper
INFO - 2023-10-28 10:53:56 --> Helper loaded: lang_helper
INFO - 2023-10-28 10:53:56 --> Helper loaded: security_helper
INFO - 2023-10-28 10:53:56 --> Helper loaded: cookie_helper
INFO - 2023-10-28 10:53:56 --> Database Driver Class Initialized
INFO - 2023-10-28 10:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 10:53:56 --> Parser Class Initialized
INFO - 2023-10-28 10:53:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 10:53:56 --> Pagination Class Initialized
INFO - 2023-10-28 10:53:56 --> Form Validation Class Initialized
INFO - 2023-10-28 10:53:56 --> Controller Class Initialized
INFO - 2023-10-28 10:53:56 --> Model Class Initialized
DEBUG - 2023-10-28 10:53:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:53:56 --> Model Class Initialized
DEBUG - 2023-10-28 10:53:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:53:56 --> Model Class Initialized
INFO - 2023-10-28 10:53:56 --> Model Class Initialized
INFO - 2023-10-28 10:53:56 --> Model Class Initialized
INFO - 2023-10-28 10:53:56 --> Model Class Initialized
DEBUG - 2023-10-28 10:53:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 10:53:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:53:56 --> Model Class Initialized
INFO - 2023-10-28 10:53:56 --> Model Class Initialized
INFO - 2023-10-28 10:53:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-28 10:53:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:53:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 10:53:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 10:53:57 --> Model Class Initialized
INFO - 2023-10-28 10:53:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 10:53:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 10:53:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 10:53:57 --> Final output sent to browser
DEBUG - 2023-10-28 10:53:57 --> Total execution time: 0.2161
ERROR - 2023-10-28 10:54:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 10:54:03 --> Config Class Initialized
INFO - 2023-10-28 10:54:03 --> Hooks Class Initialized
DEBUG - 2023-10-28 10:54:03 --> UTF-8 Support Enabled
INFO - 2023-10-28 10:54:03 --> Utf8 Class Initialized
INFO - 2023-10-28 10:54:03 --> URI Class Initialized
DEBUG - 2023-10-28 10:54:03 --> No URI present. Default controller set.
INFO - 2023-10-28 10:54:03 --> Router Class Initialized
INFO - 2023-10-28 10:54:03 --> Output Class Initialized
INFO - 2023-10-28 10:54:03 --> Security Class Initialized
DEBUG - 2023-10-28 10:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 10:54:03 --> Input Class Initialized
INFO - 2023-10-28 10:54:03 --> Language Class Initialized
INFO - 2023-10-28 10:54:03 --> Loader Class Initialized
INFO - 2023-10-28 10:54:03 --> Helper loaded: url_helper
INFO - 2023-10-28 10:54:03 --> Helper loaded: file_helper
INFO - 2023-10-28 10:54:03 --> Helper loaded: html_helper
INFO - 2023-10-28 10:54:03 --> Helper loaded: text_helper
INFO - 2023-10-28 10:54:03 --> Helper loaded: form_helper
INFO - 2023-10-28 10:54:03 --> Helper loaded: lang_helper
INFO - 2023-10-28 10:54:03 --> Helper loaded: security_helper
INFO - 2023-10-28 10:54:03 --> Helper loaded: cookie_helper
INFO - 2023-10-28 10:54:03 --> Database Driver Class Initialized
INFO - 2023-10-28 10:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 10:54:03 --> Parser Class Initialized
INFO - 2023-10-28 10:54:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 10:54:03 --> Pagination Class Initialized
INFO - 2023-10-28 10:54:03 --> Form Validation Class Initialized
INFO - 2023-10-28 10:54:03 --> Controller Class Initialized
INFO - 2023-10-28 10:54:03 --> Model Class Initialized
DEBUG - 2023-10-28 10:54:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:54:03 --> Model Class Initialized
DEBUG - 2023-10-28 10:54:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:54:03 --> Model Class Initialized
INFO - 2023-10-28 10:54:03 --> Model Class Initialized
INFO - 2023-10-28 10:54:03 --> Model Class Initialized
INFO - 2023-10-28 10:54:03 --> Model Class Initialized
DEBUG - 2023-10-28 10:54:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 10:54:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:54:03 --> Model Class Initialized
INFO - 2023-10-28 10:54:03 --> Model Class Initialized
INFO - 2023-10-28 10:54:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-28 10:54:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:54:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 10:54:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 10:54:03 --> Model Class Initialized
INFO - 2023-10-28 10:54:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 10:54:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 10:54:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 10:54:03 --> Final output sent to browser
DEBUG - 2023-10-28 10:54:03 --> Total execution time: 0.2006
ERROR - 2023-10-28 10:54:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 10:54:06 --> Config Class Initialized
INFO - 2023-10-28 10:54:06 --> Hooks Class Initialized
DEBUG - 2023-10-28 10:54:06 --> UTF-8 Support Enabled
INFO - 2023-10-28 10:54:06 --> Utf8 Class Initialized
INFO - 2023-10-28 10:54:06 --> URI Class Initialized
INFO - 2023-10-28 10:54:06 --> Router Class Initialized
INFO - 2023-10-28 10:54:06 --> Output Class Initialized
INFO - 2023-10-28 10:54:06 --> Security Class Initialized
DEBUG - 2023-10-28 10:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 10:54:06 --> Input Class Initialized
INFO - 2023-10-28 10:54:06 --> Language Class Initialized
INFO - 2023-10-28 10:54:06 --> Loader Class Initialized
INFO - 2023-10-28 10:54:06 --> Helper loaded: url_helper
INFO - 2023-10-28 10:54:06 --> Helper loaded: file_helper
INFO - 2023-10-28 10:54:06 --> Helper loaded: html_helper
INFO - 2023-10-28 10:54:06 --> Helper loaded: text_helper
INFO - 2023-10-28 10:54:06 --> Helper loaded: form_helper
INFO - 2023-10-28 10:54:06 --> Helper loaded: lang_helper
INFO - 2023-10-28 10:54:06 --> Helper loaded: security_helper
INFO - 2023-10-28 10:54:06 --> Helper loaded: cookie_helper
INFO - 2023-10-28 10:54:06 --> Database Driver Class Initialized
INFO - 2023-10-28 10:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 10:54:06 --> Parser Class Initialized
INFO - 2023-10-28 10:54:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 10:54:06 --> Pagination Class Initialized
INFO - 2023-10-28 10:54:06 --> Form Validation Class Initialized
INFO - 2023-10-28 10:54:06 --> Controller Class Initialized
DEBUG - 2023-10-28 10:54:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 10:54:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:54:06 --> Model Class Initialized
INFO - 2023-10-28 10:54:06 --> Model Class Initialized
DEBUG - 2023-10-28 10:54:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 10:54:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:54:06 --> Model Class Initialized
DEBUG - 2023-10-28 10:54:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:54:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gst/list.php
DEBUG - 2023-10-28 10:54:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:54:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 10:54:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 10:54:06 --> Model Class Initialized
INFO - 2023-10-28 10:54:06 --> Model Class Initialized
INFO - 2023-10-28 10:54:06 --> Model Class Initialized
INFO - 2023-10-28 10:54:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 10:54:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 10:54:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 10:54:06 --> Final output sent to browser
DEBUG - 2023-10-28 10:54:06 --> Total execution time: 0.1212
ERROR - 2023-10-28 10:54:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 10:54:08 --> Config Class Initialized
INFO - 2023-10-28 10:54:08 --> Hooks Class Initialized
DEBUG - 2023-10-28 10:54:08 --> UTF-8 Support Enabled
INFO - 2023-10-28 10:54:08 --> Utf8 Class Initialized
INFO - 2023-10-28 10:54:08 --> URI Class Initialized
DEBUG - 2023-10-28 10:54:08 --> No URI present. Default controller set.
INFO - 2023-10-28 10:54:08 --> Router Class Initialized
INFO - 2023-10-28 10:54:08 --> Output Class Initialized
INFO - 2023-10-28 10:54:08 --> Security Class Initialized
DEBUG - 2023-10-28 10:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 10:54:08 --> Input Class Initialized
INFO - 2023-10-28 10:54:08 --> Language Class Initialized
INFO - 2023-10-28 10:54:08 --> Loader Class Initialized
INFO - 2023-10-28 10:54:08 --> Helper loaded: url_helper
INFO - 2023-10-28 10:54:08 --> Helper loaded: file_helper
INFO - 2023-10-28 10:54:08 --> Helper loaded: html_helper
INFO - 2023-10-28 10:54:08 --> Helper loaded: text_helper
INFO - 2023-10-28 10:54:08 --> Helper loaded: form_helper
INFO - 2023-10-28 10:54:08 --> Helper loaded: lang_helper
INFO - 2023-10-28 10:54:08 --> Helper loaded: security_helper
INFO - 2023-10-28 10:54:08 --> Helper loaded: cookie_helper
INFO - 2023-10-28 10:54:08 --> Database Driver Class Initialized
INFO - 2023-10-28 10:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 10:54:08 --> Parser Class Initialized
INFO - 2023-10-28 10:54:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 10:54:08 --> Pagination Class Initialized
INFO - 2023-10-28 10:54:08 --> Form Validation Class Initialized
INFO - 2023-10-28 10:54:08 --> Controller Class Initialized
INFO - 2023-10-28 10:54:08 --> Model Class Initialized
DEBUG - 2023-10-28 10:54:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:54:08 --> Model Class Initialized
DEBUG - 2023-10-28 10:54:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:54:08 --> Model Class Initialized
INFO - 2023-10-28 10:54:08 --> Model Class Initialized
INFO - 2023-10-28 10:54:08 --> Model Class Initialized
INFO - 2023-10-28 10:54:08 --> Model Class Initialized
DEBUG - 2023-10-28 10:54:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 10:54:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:54:08 --> Model Class Initialized
INFO - 2023-10-28 10:54:08 --> Model Class Initialized
INFO - 2023-10-28 10:54:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-28 10:54:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:54:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 10:54:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 10:54:08 --> Model Class Initialized
INFO - 2023-10-28 10:54:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 10:54:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 10:54:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 10:54:09 --> Final output sent to browser
DEBUG - 2023-10-28 10:54:09 --> Total execution time: 0.1946
ERROR - 2023-10-28 10:54:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 10:54:19 --> Config Class Initialized
INFO - 2023-10-28 10:54:19 --> Hooks Class Initialized
DEBUG - 2023-10-28 10:54:19 --> UTF-8 Support Enabled
INFO - 2023-10-28 10:54:19 --> Utf8 Class Initialized
INFO - 2023-10-28 10:54:19 --> URI Class Initialized
INFO - 2023-10-28 10:54:19 --> Router Class Initialized
INFO - 2023-10-28 10:54:19 --> Output Class Initialized
INFO - 2023-10-28 10:54:19 --> Security Class Initialized
DEBUG - 2023-10-28 10:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 10:54:19 --> Input Class Initialized
INFO - 2023-10-28 10:54:19 --> Language Class Initialized
INFO - 2023-10-28 10:54:19 --> Loader Class Initialized
INFO - 2023-10-28 10:54:19 --> Helper loaded: url_helper
INFO - 2023-10-28 10:54:19 --> Helper loaded: file_helper
INFO - 2023-10-28 10:54:19 --> Helper loaded: html_helper
INFO - 2023-10-28 10:54:19 --> Helper loaded: text_helper
INFO - 2023-10-28 10:54:19 --> Helper loaded: form_helper
INFO - 2023-10-28 10:54:19 --> Helper loaded: lang_helper
INFO - 2023-10-28 10:54:19 --> Helper loaded: security_helper
INFO - 2023-10-28 10:54:19 --> Helper loaded: cookie_helper
INFO - 2023-10-28 10:54:19 --> Database Driver Class Initialized
INFO - 2023-10-28 10:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 10:54:19 --> Parser Class Initialized
INFO - 2023-10-28 10:54:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 10:54:19 --> Pagination Class Initialized
INFO - 2023-10-28 10:54:19 --> Form Validation Class Initialized
INFO - 2023-10-28 10:54:19 --> Controller Class Initialized
INFO - 2023-10-28 10:54:19 --> Model Class Initialized
DEBUG - 2023-10-28 10:54:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 10:54:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:54:19 --> Model Class Initialized
DEBUG - 2023-10-28 10:54:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:54:19 --> Model Class Initialized
INFO - 2023-10-28 10:54:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-28 10:54:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:54:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 10:54:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 10:54:19 --> Model Class Initialized
INFO - 2023-10-28 10:54:19 --> Model Class Initialized
INFO - 2023-10-28 10:54:19 --> Model Class Initialized
INFO - 2023-10-28 10:54:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 10:54:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 10:54:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 10:54:19 --> Final output sent to browser
DEBUG - 2023-10-28 10:54:19 --> Total execution time: 0.1239
ERROR - 2023-10-28 10:54:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 10:54:20 --> Config Class Initialized
INFO - 2023-10-28 10:54:20 --> Hooks Class Initialized
DEBUG - 2023-10-28 10:54:20 --> UTF-8 Support Enabled
INFO - 2023-10-28 10:54:20 --> Utf8 Class Initialized
INFO - 2023-10-28 10:54:20 --> URI Class Initialized
INFO - 2023-10-28 10:54:20 --> Router Class Initialized
INFO - 2023-10-28 10:54:20 --> Output Class Initialized
INFO - 2023-10-28 10:54:20 --> Security Class Initialized
DEBUG - 2023-10-28 10:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 10:54:20 --> Input Class Initialized
INFO - 2023-10-28 10:54:20 --> Language Class Initialized
INFO - 2023-10-28 10:54:20 --> Loader Class Initialized
INFO - 2023-10-28 10:54:20 --> Helper loaded: url_helper
INFO - 2023-10-28 10:54:20 --> Helper loaded: file_helper
INFO - 2023-10-28 10:54:20 --> Helper loaded: html_helper
INFO - 2023-10-28 10:54:20 --> Helper loaded: text_helper
INFO - 2023-10-28 10:54:20 --> Helper loaded: form_helper
INFO - 2023-10-28 10:54:20 --> Helper loaded: lang_helper
INFO - 2023-10-28 10:54:20 --> Helper loaded: security_helper
INFO - 2023-10-28 10:54:20 --> Helper loaded: cookie_helper
INFO - 2023-10-28 10:54:20 --> Database Driver Class Initialized
INFO - 2023-10-28 10:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 10:54:20 --> Parser Class Initialized
INFO - 2023-10-28 10:54:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 10:54:20 --> Pagination Class Initialized
INFO - 2023-10-28 10:54:20 --> Form Validation Class Initialized
INFO - 2023-10-28 10:54:20 --> Controller Class Initialized
INFO - 2023-10-28 10:54:20 --> Model Class Initialized
DEBUG - 2023-10-28 10:54:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 10:54:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:54:20 --> Model Class Initialized
DEBUG - 2023-10-28 10:54:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:54:20 --> Model Class Initialized
INFO - 2023-10-28 10:54:20 --> Final output sent to browser
DEBUG - 2023-10-28 10:54:20 --> Total execution time: 0.0365
ERROR - 2023-10-28 10:54:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 10:54:28 --> Config Class Initialized
INFO - 2023-10-28 10:54:28 --> Hooks Class Initialized
DEBUG - 2023-10-28 10:54:28 --> UTF-8 Support Enabled
INFO - 2023-10-28 10:54:28 --> Utf8 Class Initialized
INFO - 2023-10-28 10:54:28 --> URI Class Initialized
INFO - 2023-10-28 10:54:28 --> Router Class Initialized
INFO - 2023-10-28 10:54:28 --> Output Class Initialized
INFO - 2023-10-28 10:54:28 --> Security Class Initialized
DEBUG - 2023-10-28 10:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 10:54:28 --> Input Class Initialized
INFO - 2023-10-28 10:54:28 --> Language Class Initialized
INFO - 2023-10-28 10:54:28 --> Loader Class Initialized
INFO - 2023-10-28 10:54:28 --> Helper loaded: url_helper
INFO - 2023-10-28 10:54:28 --> Helper loaded: file_helper
INFO - 2023-10-28 10:54:28 --> Helper loaded: html_helper
INFO - 2023-10-28 10:54:28 --> Helper loaded: text_helper
INFO - 2023-10-28 10:54:28 --> Helper loaded: form_helper
INFO - 2023-10-28 10:54:28 --> Helper loaded: lang_helper
INFO - 2023-10-28 10:54:28 --> Helper loaded: security_helper
INFO - 2023-10-28 10:54:28 --> Helper loaded: cookie_helper
INFO - 2023-10-28 10:54:28 --> Database Driver Class Initialized
INFO - 2023-10-28 10:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 10:54:28 --> Parser Class Initialized
INFO - 2023-10-28 10:54:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 10:54:28 --> Pagination Class Initialized
INFO - 2023-10-28 10:54:28 --> Form Validation Class Initialized
INFO - 2023-10-28 10:54:28 --> Controller Class Initialized
INFO - 2023-10-28 10:54:28 --> Model Class Initialized
DEBUG - 2023-10-28 10:54:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 10:54:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:54:28 --> Model Class Initialized
DEBUG - 2023-10-28 10:54:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:54:28 --> Model Class Initialized
INFO - 2023-10-28 10:54:28 --> Final output sent to browser
DEBUG - 2023-10-28 10:54:28 --> Total execution time: 0.0560
ERROR - 2023-10-28 10:54:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 10:54:55 --> Config Class Initialized
INFO - 2023-10-28 10:54:55 --> Hooks Class Initialized
DEBUG - 2023-10-28 10:54:55 --> UTF-8 Support Enabled
INFO - 2023-10-28 10:54:55 --> Utf8 Class Initialized
INFO - 2023-10-28 10:54:55 --> URI Class Initialized
DEBUG - 2023-10-28 10:54:55 --> No URI present. Default controller set.
INFO - 2023-10-28 10:54:55 --> Router Class Initialized
INFO - 2023-10-28 10:54:55 --> Output Class Initialized
INFO - 2023-10-28 10:54:55 --> Security Class Initialized
DEBUG - 2023-10-28 10:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 10:54:55 --> Input Class Initialized
INFO - 2023-10-28 10:54:55 --> Language Class Initialized
INFO - 2023-10-28 10:54:55 --> Loader Class Initialized
INFO - 2023-10-28 10:54:55 --> Helper loaded: url_helper
INFO - 2023-10-28 10:54:55 --> Helper loaded: file_helper
INFO - 2023-10-28 10:54:55 --> Helper loaded: html_helper
INFO - 2023-10-28 10:54:55 --> Helper loaded: text_helper
INFO - 2023-10-28 10:54:55 --> Helper loaded: form_helper
INFO - 2023-10-28 10:54:55 --> Helper loaded: lang_helper
INFO - 2023-10-28 10:54:55 --> Helper loaded: security_helper
INFO - 2023-10-28 10:54:55 --> Helper loaded: cookie_helper
INFO - 2023-10-28 10:54:55 --> Database Driver Class Initialized
INFO - 2023-10-28 10:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 10:54:55 --> Parser Class Initialized
INFO - 2023-10-28 10:54:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 10:54:55 --> Pagination Class Initialized
INFO - 2023-10-28 10:54:55 --> Form Validation Class Initialized
INFO - 2023-10-28 10:54:55 --> Controller Class Initialized
INFO - 2023-10-28 10:54:55 --> Model Class Initialized
DEBUG - 2023-10-28 10:54:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-28 10:54:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 10:54:55 --> Config Class Initialized
INFO - 2023-10-28 10:54:55 --> Hooks Class Initialized
DEBUG - 2023-10-28 10:54:55 --> UTF-8 Support Enabled
INFO - 2023-10-28 10:54:55 --> Utf8 Class Initialized
INFO - 2023-10-28 10:54:55 --> URI Class Initialized
INFO - 2023-10-28 10:54:55 --> Router Class Initialized
INFO - 2023-10-28 10:54:55 --> Output Class Initialized
INFO - 2023-10-28 10:54:55 --> Security Class Initialized
DEBUG - 2023-10-28 10:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 10:54:55 --> Input Class Initialized
INFO - 2023-10-28 10:54:55 --> Language Class Initialized
INFO - 2023-10-28 10:54:55 --> Loader Class Initialized
INFO - 2023-10-28 10:54:55 --> Helper loaded: url_helper
INFO - 2023-10-28 10:54:55 --> Helper loaded: file_helper
INFO - 2023-10-28 10:54:55 --> Helper loaded: html_helper
INFO - 2023-10-28 10:54:55 --> Helper loaded: text_helper
INFO - 2023-10-28 10:54:55 --> Helper loaded: form_helper
INFO - 2023-10-28 10:54:55 --> Helper loaded: lang_helper
INFO - 2023-10-28 10:54:55 --> Helper loaded: security_helper
INFO - 2023-10-28 10:54:55 --> Helper loaded: cookie_helper
INFO - 2023-10-28 10:54:55 --> Database Driver Class Initialized
INFO - 2023-10-28 10:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 10:54:55 --> Parser Class Initialized
INFO - 2023-10-28 10:54:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 10:54:55 --> Pagination Class Initialized
INFO - 2023-10-28 10:54:55 --> Form Validation Class Initialized
INFO - 2023-10-28 10:54:55 --> Controller Class Initialized
INFO - 2023-10-28 10:54:55 --> Model Class Initialized
DEBUG - 2023-10-28 10:54:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:54:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-28 10:54:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:54:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 10:54:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 10:54:55 --> Model Class Initialized
INFO - 2023-10-28 10:54:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 10:54:55 --> Final output sent to browser
DEBUG - 2023-10-28 10:54:55 --> Total execution time: 0.0303
ERROR - 2023-10-28 10:54:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 10:54:58 --> Config Class Initialized
INFO - 2023-10-28 10:54:58 --> Hooks Class Initialized
DEBUG - 2023-10-28 10:54:58 --> UTF-8 Support Enabled
INFO - 2023-10-28 10:54:58 --> Utf8 Class Initialized
INFO - 2023-10-28 10:54:58 --> URI Class Initialized
INFO - 2023-10-28 10:54:58 --> Router Class Initialized
INFO - 2023-10-28 10:54:58 --> Output Class Initialized
INFO - 2023-10-28 10:54:58 --> Security Class Initialized
DEBUG - 2023-10-28 10:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 10:54:58 --> Input Class Initialized
INFO - 2023-10-28 10:54:58 --> Language Class Initialized
INFO - 2023-10-28 10:54:58 --> Loader Class Initialized
INFO - 2023-10-28 10:54:58 --> Helper loaded: url_helper
INFO - 2023-10-28 10:54:58 --> Helper loaded: file_helper
INFO - 2023-10-28 10:54:58 --> Helper loaded: html_helper
INFO - 2023-10-28 10:54:58 --> Helper loaded: text_helper
INFO - 2023-10-28 10:54:58 --> Helper loaded: form_helper
INFO - 2023-10-28 10:54:58 --> Helper loaded: lang_helper
INFO - 2023-10-28 10:54:58 --> Helper loaded: security_helper
INFO - 2023-10-28 10:54:58 --> Helper loaded: cookie_helper
INFO - 2023-10-28 10:54:58 --> Database Driver Class Initialized
INFO - 2023-10-28 10:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 10:54:58 --> Parser Class Initialized
INFO - 2023-10-28 10:54:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 10:54:58 --> Pagination Class Initialized
INFO - 2023-10-28 10:54:58 --> Form Validation Class Initialized
INFO - 2023-10-28 10:54:58 --> Controller Class Initialized
INFO - 2023-10-28 10:54:58 --> Model Class Initialized
DEBUG - 2023-10-28 10:54:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:54:58 --> Model Class Initialized
INFO - 2023-10-28 10:54:58 --> Final output sent to browser
DEBUG - 2023-10-28 10:54:58 --> Total execution time: 0.0199
ERROR - 2023-10-28 10:54:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 10:54:59 --> Config Class Initialized
INFO - 2023-10-28 10:54:59 --> Hooks Class Initialized
DEBUG - 2023-10-28 10:54:59 --> UTF-8 Support Enabled
INFO - 2023-10-28 10:54:59 --> Utf8 Class Initialized
INFO - 2023-10-28 10:54:59 --> URI Class Initialized
DEBUG - 2023-10-28 10:54:59 --> No URI present. Default controller set.
INFO - 2023-10-28 10:54:59 --> Router Class Initialized
INFO - 2023-10-28 10:54:59 --> Output Class Initialized
INFO - 2023-10-28 10:54:59 --> Security Class Initialized
DEBUG - 2023-10-28 10:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 10:54:59 --> Input Class Initialized
INFO - 2023-10-28 10:54:59 --> Language Class Initialized
INFO - 2023-10-28 10:54:59 --> Loader Class Initialized
INFO - 2023-10-28 10:54:59 --> Helper loaded: url_helper
INFO - 2023-10-28 10:54:59 --> Helper loaded: file_helper
INFO - 2023-10-28 10:54:59 --> Helper loaded: html_helper
INFO - 2023-10-28 10:54:59 --> Helper loaded: text_helper
INFO - 2023-10-28 10:54:59 --> Helper loaded: form_helper
INFO - 2023-10-28 10:54:59 --> Helper loaded: lang_helper
INFO - 2023-10-28 10:54:59 --> Helper loaded: security_helper
INFO - 2023-10-28 10:54:59 --> Helper loaded: cookie_helper
INFO - 2023-10-28 10:54:59 --> Database Driver Class Initialized
INFO - 2023-10-28 10:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 10:54:59 --> Parser Class Initialized
INFO - 2023-10-28 10:54:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 10:54:59 --> Pagination Class Initialized
INFO - 2023-10-28 10:54:59 --> Form Validation Class Initialized
INFO - 2023-10-28 10:54:59 --> Controller Class Initialized
INFO - 2023-10-28 10:54:59 --> Model Class Initialized
DEBUG - 2023-10-28 10:54:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:54:59 --> Model Class Initialized
DEBUG - 2023-10-28 10:54:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:54:59 --> Model Class Initialized
INFO - 2023-10-28 10:54:59 --> Model Class Initialized
INFO - 2023-10-28 10:54:59 --> Model Class Initialized
INFO - 2023-10-28 10:54:59 --> Model Class Initialized
DEBUG - 2023-10-28 10:54:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 10:54:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:54:59 --> Model Class Initialized
INFO - 2023-10-28 10:54:59 --> Model Class Initialized
INFO - 2023-10-28 10:54:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-28 10:54:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:54:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 10:54:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 10:54:59 --> Model Class Initialized
INFO - 2023-10-28 10:54:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 10:54:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 10:54:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 10:54:59 --> Final output sent to browser
DEBUG - 2023-10-28 10:54:59 --> Total execution time: 0.3579
ERROR - 2023-10-28 10:55:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 10:55:00 --> Config Class Initialized
INFO - 2023-10-28 10:55:00 --> Hooks Class Initialized
DEBUG - 2023-10-28 10:55:00 --> UTF-8 Support Enabled
INFO - 2023-10-28 10:55:00 --> Utf8 Class Initialized
INFO - 2023-10-28 10:55:00 --> URI Class Initialized
INFO - 2023-10-28 10:55:00 --> Router Class Initialized
INFO - 2023-10-28 10:55:00 --> Output Class Initialized
INFO - 2023-10-28 10:55:00 --> Security Class Initialized
DEBUG - 2023-10-28 10:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 10:55:00 --> Input Class Initialized
INFO - 2023-10-28 10:55:00 --> Language Class Initialized
INFO - 2023-10-28 10:55:00 --> Loader Class Initialized
INFO - 2023-10-28 10:55:00 --> Helper loaded: url_helper
INFO - 2023-10-28 10:55:00 --> Helper loaded: file_helper
INFO - 2023-10-28 10:55:00 --> Helper loaded: html_helper
INFO - 2023-10-28 10:55:00 --> Helper loaded: text_helper
INFO - 2023-10-28 10:55:00 --> Helper loaded: form_helper
INFO - 2023-10-28 10:55:00 --> Helper loaded: lang_helper
INFO - 2023-10-28 10:55:00 --> Helper loaded: security_helper
INFO - 2023-10-28 10:55:00 --> Helper loaded: cookie_helper
INFO - 2023-10-28 10:55:00 --> Database Driver Class Initialized
INFO - 2023-10-28 10:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 10:55:00 --> Parser Class Initialized
INFO - 2023-10-28 10:55:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 10:55:00 --> Pagination Class Initialized
INFO - 2023-10-28 10:55:00 --> Form Validation Class Initialized
INFO - 2023-10-28 10:55:00 --> Controller Class Initialized
DEBUG - 2023-10-28 10:55:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 10:55:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:55:00 --> Model Class Initialized
INFO - 2023-10-28 10:55:00 --> Final output sent to browser
DEBUG - 2023-10-28 10:55:00 --> Total execution time: 0.0130
ERROR - 2023-10-28 10:55:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 10:55:06 --> Config Class Initialized
INFO - 2023-10-28 10:55:06 --> Hooks Class Initialized
DEBUG - 2023-10-28 10:55:06 --> UTF-8 Support Enabled
INFO - 2023-10-28 10:55:06 --> Utf8 Class Initialized
INFO - 2023-10-28 10:55:06 --> URI Class Initialized
INFO - 2023-10-28 10:55:06 --> Router Class Initialized
INFO - 2023-10-28 10:55:06 --> Output Class Initialized
INFO - 2023-10-28 10:55:06 --> Security Class Initialized
DEBUG - 2023-10-28 10:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 10:55:06 --> Input Class Initialized
INFO - 2023-10-28 10:55:06 --> Language Class Initialized
INFO - 2023-10-28 10:55:06 --> Loader Class Initialized
INFO - 2023-10-28 10:55:06 --> Helper loaded: url_helper
INFO - 2023-10-28 10:55:06 --> Helper loaded: file_helper
INFO - 2023-10-28 10:55:06 --> Helper loaded: html_helper
INFO - 2023-10-28 10:55:06 --> Helper loaded: text_helper
INFO - 2023-10-28 10:55:06 --> Helper loaded: form_helper
INFO - 2023-10-28 10:55:06 --> Helper loaded: lang_helper
INFO - 2023-10-28 10:55:06 --> Helper loaded: security_helper
INFO - 2023-10-28 10:55:06 --> Helper loaded: cookie_helper
INFO - 2023-10-28 10:55:06 --> Database Driver Class Initialized
INFO - 2023-10-28 10:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 10:55:06 --> Parser Class Initialized
INFO - 2023-10-28 10:55:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 10:55:06 --> Pagination Class Initialized
INFO - 2023-10-28 10:55:06 --> Form Validation Class Initialized
INFO - 2023-10-28 10:55:06 --> Controller Class Initialized
INFO - 2023-10-28 10:55:06 --> Model Class Initialized
DEBUG - 2023-10-28 10:55:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 10:55:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:55:06 --> Model Class Initialized
DEBUG - 2023-10-28 10:55:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:55:06 --> Model Class Initialized
INFO - 2023-10-28 10:55:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-28 10:55:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:55:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 10:55:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 10:55:06 --> Model Class Initialized
INFO - 2023-10-28 10:55:06 --> Model Class Initialized
INFO - 2023-10-28 10:55:06 --> Model Class Initialized
INFO - 2023-10-28 10:55:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 10:55:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 10:55:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 10:55:06 --> Final output sent to browser
DEBUG - 2023-10-28 10:55:06 --> Total execution time: 0.1910
ERROR - 2023-10-28 10:55:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 10:55:06 --> Config Class Initialized
INFO - 2023-10-28 10:55:06 --> Hooks Class Initialized
DEBUG - 2023-10-28 10:55:06 --> UTF-8 Support Enabled
INFO - 2023-10-28 10:55:06 --> Utf8 Class Initialized
INFO - 2023-10-28 10:55:06 --> URI Class Initialized
INFO - 2023-10-28 10:55:06 --> Router Class Initialized
INFO - 2023-10-28 10:55:06 --> Output Class Initialized
INFO - 2023-10-28 10:55:06 --> Security Class Initialized
DEBUG - 2023-10-28 10:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 10:55:06 --> Input Class Initialized
INFO - 2023-10-28 10:55:06 --> Language Class Initialized
INFO - 2023-10-28 10:55:06 --> Loader Class Initialized
INFO - 2023-10-28 10:55:06 --> Helper loaded: url_helper
INFO - 2023-10-28 10:55:06 --> Helper loaded: file_helper
INFO - 2023-10-28 10:55:06 --> Helper loaded: html_helper
INFO - 2023-10-28 10:55:06 --> Helper loaded: text_helper
INFO - 2023-10-28 10:55:06 --> Helper loaded: form_helper
INFO - 2023-10-28 10:55:06 --> Helper loaded: lang_helper
INFO - 2023-10-28 10:55:06 --> Helper loaded: security_helper
INFO - 2023-10-28 10:55:06 --> Helper loaded: cookie_helper
INFO - 2023-10-28 10:55:07 --> Database Driver Class Initialized
INFO - 2023-10-28 10:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 10:55:07 --> Parser Class Initialized
INFO - 2023-10-28 10:55:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 10:55:07 --> Pagination Class Initialized
INFO - 2023-10-28 10:55:07 --> Form Validation Class Initialized
INFO - 2023-10-28 10:55:07 --> Controller Class Initialized
INFO - 2023-10-28 10:55:07 --> Model Class Initialized
DEBUG - 2023-10-28 10:55:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 10:55:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:55:07 --> Model Class Initialized
DEBUG - 2023-10-28 10:55:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:55:07 --> Model Class Initialized
INFO - 2023-10-28 10:55:07 --> Final output sent to browser
DEBUG - 2023-10-28 10:55:07 --> Total execution time: 0.0538
ERROR - 2023-10-28 10:55:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 10:55:11 --> Config Class Initialized
INFO - 2023-10-28 10:55:11 --> Hooks Class Initialized
DEBUG - 2023-10-28 10:55:11 --> UTF-8 Support Enabled
INFO - 2023-10-28 10:55:11 --> Utf8 Class Initialized
INFO - 2023-10-28 10:55:11 --> URI Class Initialized
INFO - 2023-10-28 10:55:11 --> Router Class Initialized
INFO - 2023-10-28 10:55:11 --> Output Class Initialized
INFO - 2023-10-28 10:55:11 --> Security Class Initialized
DEBUG - 2023-10-28 10:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 10:55:11 --> Input Class Initialized
INFO - 2023-10-28 10:55:11 --> Language Class Initialized
INFO - 2023-10-28 10:55:11 --> Loader Class Initialized
INFO - 2023-10-28 10:55:11 --> Helper loaded: url_helper
INFO - 2023-10-28 10:55:11 --> Helper loaded: file_helper
INFO - 2023-10-28 10:55:11 --> Helper loaded: html_helper
INFO - 2023-10-28 10:55:11 --> Helper loaded: text_helper
INFO - 2023-10-28 10:55:11 --> Helper loaded: form_helper
INFO - 2023-10-28 10:55:11 --> Helper loaded: lang_helper
INFO - 2023-10-28 10:55:11 --> Helper loaded: security_helper
INFO - 2023-10-28 10:55:11 --> Helper loaded: cookie_helper
INFO - 2023-10-28 10:55:11 --> Database Driver Class Initialized
INFO - 2023-10-28 10:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 10:55:11 --> Parser Class Initialized
INFO - 2023-10-28 10:55:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 10:55:11 --> Pagination Class Initialized
INFO - 2023-10-28 10:55:11 --> Form Validation Class Initialized
INFO - 2023-10-28 10:55:11 --> Controller Class Initialized
INFO - 2023-10-28 10:55:11 --> Model Class Initialized
DEBUG - 2023-10-28 10:55:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 10:55:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:55:11 --> Model Class Initialized
DEBUG - 2023-10-28 10:55:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:55:11 --> Model Class Initialized
INFO - 2023-10-28 10:55:12 --> Final output sent to browser
DEBUG - 2023-10-28 10:55:12 --> Total execution time: 0.9186
ERROR - 2023-10-28 10:55:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 10:55:35 --> Config Class Initialized
INFO - 2023-10-28 10:55:35 --> Hooks Class Initialized
DEBUG - 2023-10-28 10:55:35 --> UTF-8 Support Enabled
INFO - 2023-10-28 10:55:35 --> Utf8 Class Initialized
INFO - 2023-10-28 10:55:35 --> URI Class Initialized
INFO - 2023-10-28 10:55:35 --> Router Class Initialized
INFO - 2023-10-28 10:55:35 --> Output Class Initialized
INFO - 2023-10-28 10:55:35 --> Security Class Initialized
DEBUG - 2023-10-28 10:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 10:55:35 --> Input Class Initialized
INFO - 2023-10-28 10:55:35 --> Language Class Initialized
INFO - 2023-10-28 10:55:35 --> Loader Class Initialized
INFO - 2023-10-28 10:55:35 --> Helper loaded: url_helper
INFO - 2023-10-28 10:55:35 --> Helper loaded: file_helper
INFO - 2023-10-28 10:55:35 --> Helper loaded: html_helper
INFO - 2023-10-28 10:55:35 --> Helper loaded: text_helper
INFO - 2023-10-28 10:55:35 --> Helper loaded: form_helper
INFO - 2023-10-28 10:55:35 --> Helper loaded: lang_helper
INFO - 2023-10-28 10:55:35 --> Helper loaded: security_helper
INFO - 2023-10-28 10:55:35 --> Helper loaded: cookie_helper
INFO - 2023-10-28 10:55:35 --> Database Driver Class Initialized
INFO - 2023-10-28 10:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 10:55:35 --> Parser Class Initialized
INFO - 2023-10-28 10:55:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 10:55:35 --> Pagination Class Initialized
INFO - 2023-10-28 10:55:35 --> Form Validation Class Initialized
INFO - 2023-10-28 10:55:35 --> Controller Class Initialized
INFO - 2023-10-28 10:55:35 --> Model Class Initialized
DEBUG - 2023-10-28 10:55:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 10:55:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:55:35 --> Model Class Initialized
DEBUG - 2023-10-28 10:55:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:55:35 --> Model Class Initialized
ERROR - 2023-10-28 10:55:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 10:55:36 --> Config Class Initialized
INFO - 2023-10-28 10:55:36 --> Hooks Class Initialized
DEBUG - 2023-10-28 10:55:36 --> UTF-8 Support Enabled
INFO - 2023-10-28 10:55:36 --> Utf8 Class Initialized
INFO - 2023-10-28 10:55:36 --> URI Class Initialized
INFO - 2023-10-28 10:55:36 --> Router Class Initialized
INFO - 2023-10-28 10:55:36 --> Output Class Initialized
INFO - 2023-10-28 10:55:36 --> Security Class Initialized
DEBUG - 2023-10-28 10:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 10:55:36 --> Input Class Initialized
INFO - 2023-10-28 10:55:36 --> Language Class Initialized
INFO - 2023-10-28 10:55:36 --> Loader Class Initialized
INFO - 2023-10-28 10:55:36 --> Helper loaded: url_helper
INFO - 2023-10-28 10:55:36 --> Helper loaded: file_helper
INFO - 2023-10-28 10:55:36 --> Helper loaded: html_helper
INFO - 2023-10-28 10:55:36 --> Helper loaded: text_helper
INFO - 2023-10-28 10:55:36 --> Helper loaded: form_helper
INFO - 2023-10-28 10:55:36 --> Helper loaded: lang_helper
INFO - 2023-10-28 10:55:36 --> Helper loaded: security_helper
INFO - 2023-10-28 10:55:36 --> Helper loaded: cookie_helper
INFO - 2023-10-28 10:55:36 --> Database Driver Class Initialized
INFO - 2023-10-28 10:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 10:55:36 --> Parser Class Initialized
INFO - 2023-10-28 10:55:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 10:55:36 --> Pagination Class Initialized
INFO - 2023-10-28 10:55:36 --> Form Validation Class Initialized
INFO - 2023-10-28 10:55:36 --> Controller Class Initialized
INFO - 2023-10-28 10:55:36 --> Model Class Initialized
DEBUG - 2023-10-28 10:55:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 10:55:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:55:36 --> Model Class Initialized
DEBUG - 2023-10-28 10:55:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:55:36 --> Model Class Initialized
INFO - 2023-10-28 10:55:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-28 10:55:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:55:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 10:55:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 10:55:36 --> Model Class Initialized
INFO - 2023-10-28 10:55:36 --> Model Class Initialized
INFO - 2023-10-28 10:55:36 --> Model Class Initialized
INFO - 2023-10-28 10:55:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 10:55:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 10:55:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 10:55:36 --> Final output sent to browser
DEBUG - 2023-10-28 10:55:36 --> Total execution time: 0.2073
ERROR - 2023-10-28 10:55:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 10:55:37 --> Config Class Initialized
INFO - 2023-10-28 10:55:37 --> Hooks Class Initialized
DEBUG - 2023-10-28 10:55:37 --> UTF-8 Support Enabled
INFO - 2023-10-28 10:55:37 --> Utf8 Class Initialized
INFO - 2023-10-28 10:55:37 --> URI Class Initialized
INFO - 2023-10-28 10:55:37 --> Router Class Initialized
INFO - 2023-10-28 10:55:37 --> Output Class Initialized
INFO - 2023-10-28 10:55:37 --> Security Class Initialized
DEBUG - 2023-10-28 10:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 10:55:37 --> Input Class Initialized
INFO - 2023-10-28 10:55:37 --> Language Class Initialized
INFO - 2023-10-28 10:55:37 --> Loader Class Initialized
INFO - 2023-10-28 10:55:37 --> Helper loaded: url_helper
INFO - 2023-10-28 10:55:37 --> Helper loaded: file_helper
INFO - 2023-10-28 10:55:37 --> Helper loaded: html_helper
INFO - 2023-10-28 10:55:37 --> Helper loaded: text_helper
INFO - 2023-10-28 10:55:37 --> Helper loaded: form_helper
INFO - 2023-10-28 10:55:37 --> Helper loaded: lang_helper
INFO - 2023-10-28 10:55:37 --> Helper loaded: security_helper
INFO - 2023-10-28 10:55:37 --> Helper loaded: cookie_helper
INFO - 2023-10-28 10:55:37 --> Database Driver Class Initialized
INFO - 2023-10-28 10:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 10:55:37 --> Parser Class Initialized
INFO - 2023-10-28 10:55:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 10:55:37 --> Pagination Class Initialized
INFO - 2023-10-28 10:55:37 --> Form Validation Class Initialized
INFO - 2023-10-28 10:55:37 --> Controller Class Initialized
INFO - 2023-10-28 10:55:37 --> Model Class Initialized
DEBUG - 2023-10-28 10:55:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 10:55:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:55:37 --> Model Class Initialized
DEBUG - 2023-10-28 10:55:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:55:37 --> Model Class Initialized
INFO - 2023-10-28 10:55:37 --> Final output sent to browser
DEBUG - 2023-10-28 10:55:37 --> Total execution time: 0.0595
ERROR - 2023-10-28 10:55:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 10:55:43 --> Config Class Initialized
INFO - 2023-10-28 10:55:43 --> Hooks Class Initialized
DEBUG - 2023-10-28 10:55:43 --> UTF-8 Support Enabled
INFO - 2023-10-28 10:55:43 --> Utf8 Class Initialized
INFO - 2023-10-28 10:55:43 --> URI Class Initialized
INFO - 2023-10-28 10:55:43 --> Router Class Initialized
INFO - 2023-10-28 10:55:43 --> Output Class Initialized
INFO - 2023-10-28 10:55:43 --> Security Class Initialized
DEBUG - 2023-10-28 10:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 10:55:43 --> Input Class Initialized
INFO - 2023-10-28 10:55:43 --> Language Class Initialized
INFO - 2023-10-28 10:55:43 --> Loader Class Initialized
INFO - 2023-10-28 10:55:43 --> Helper loaded: url_helper
INFO - 2023-10-28 10:55:43 --> Helper loaded: file_helper
INFO - 2023-10-28 10:55:43 --> Helper loaded: html_helper
INFO - 2023-10-28 10:55:43 --> Helper loaded: text_helper
INFO - 2023-10-28 10:55:43 --> Helper loaded: form_helper
INFO - 2023-10-28 10:55:43 --> Helper loaded: lang_helper
INFO - 2023-10-28 10:55:43 --> Helper loaded: security_helper
INFO - 2023-10-28 10:55:43 --> Helper loaded: cookie_helper
INFO - 2023-10-28 10:55:43 --> Database Driver Class Initialized
INFO - 2023-10-28 10:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 10:55:43 --> Parser Class Initialized
INFO - 2023-10-28 10:55:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 10:55:43 --> Pagination Class Initialized
INFO - 2023-10-28 10:55:43 --> Form Validation Class Initialized
INFO - 2023-10-28 10:55:43 --> Controller Class Initialized
INFO - 2023-10-28 10:55:43 --> Model Class Initialized
DEBUG - 2023-10-28 10:55:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 10:55:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:55:43 --> Model Class Initialized
DEBUG - 2023-10-28 10:55:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:55:43 --> Model Class Initialized
INFO - 2023-10-28 10:55:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-28 10:55:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:55:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 10:55:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 10:55:43 --> Model Class Initialized
INFO - 2023-10-28 10:55:43 --> Model Class Initialized
INFO - 2023-10-28 10:55:43 --> Model Class Initialized
INFO - 2023-10-28 10:55:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 10:55:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 10:55:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 10:55:44 --> Final output sent to browser
DEBUG - 2023-10-28 10:55:44 --> Total execution time: 0.1342
ERROR - 2023-10-28 10:55:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 10:55:44 --> Config Class Initialized
INFO - 2023-10-28 10:55:44 --> Hooks Class Initialized
DEBUG - 2023-10-28 10:55:44 --> UTF-8 Support Enabled
INFO - 2023-10-28 10:55:44 --> Utf8 Class Initialized
INFO - 2023-10-28 10:55:44 --> URI Class Initialized
INFO - 2023-10-28 10:55:44 --> Router Class Initialized
INFO - 2023-10-28 10:55:44 --> Output Class Initialized
INFO - 2023-10-28 10:55:44 --> Security Class Initialized
DEBUG - 2023-10-28 10:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 10:55:44 --> Input Class Initialized
INFO - 2023-10-28 10:55:44 --> Language Class Initialized
INFO - 2023-10-28 10:55:44 --> Loader Class Initialized
INFO - 2023-10-28 10:55:44 --> Helper loaded: url_helper
INFO - 2023-10-28 10:55:44 --> Helper loaded: file_helper
INFO - 2023-10-28 10:55:44 --> Helper loaded: html_helper
INFO - 2023-10-28 10:55:44 --> Helper loaded: text_helper
INFO - 2023-10-28 10:55:44 --> Helper loaded: form_helper
INFO - 2023-10-28 10:55:44 --> Helper loaded: lang_helper
INFO - 2023-10-28 10:55:44 --> Helper loaded: security_helper
INFO - 2023-10-28 10:55:44 --> Helper loaded: cookie_helper
INFO - 2023-10-28 10:55:44 --> Database Driver Class Initialized
INFO - 2023-10-28 10:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 10:55:44 --> Parser Class Initialized
INFO - 2023-10-28 10:55:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 10:55:44 --> Pagination Class Initialized
INFO - 2023-10-28 10:55:44 --> Form Validation Class Initialized
INFO - 2023-10-28 10:55:44 --> Controller Class Initialized
INFO - 2023-10-28 10:55:44 --> Model Class Initialized
DEBUG - 2023-10-28 10:55:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 10:55:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:55:44 --> Model Class Initialized
DEBUG - 2023-10-28 10:55:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:55:44 --> Model Class Initialized
INFO - 2023-10-28 10:55:44 --> Final output sent to browser
DEBUG - 2023-10-28 10:55:44 --> Total execution time: 0.0386
ERROR - 2023-10-28 10:55:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 10:55:47 --> Config Class Initialized
INFO - 2023-10-28 10:55:47 --> Hooks Class Initialized
DEBUG - 2023-10-28 10:55:47 --> UTF-8 Support Enabled
INFO - 2023-10-28 10:55:47 --> Utf8 Class Initialized
INFO - 2023-10-28 10:55:47 --> URI Class Initialized
INFO - 2023-10-28 10:55:47 --> Router Class Initialized
INFO - 2023-10-28 10:55:47 --> Output Class Initialized
INFO - 2023-10-28 10:55:47 --> Security Class Initialized
DEBUG - 2023-10-28 10:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 10:55:47 --> Input Class Initialized
INFO - 2023-10-28 10:55:47 --> Language Class Initialized
INFO - 2023-10-28 10:55:47 --> Loader Class Initialized
INFO - 2023-10-28 10:55:47 --> Helper loaded: url_helper
INFO - 2023-10-28 10:55:47 --> Helper loaded: file_helper
INFO - 2023-10-28 10:55:47 --> Helper loaded: html_helper
INFO - 2023-10-28 10:55:47 --> Helper loaded: text_helper
INFO - 2023-10-28 10:55:47 --> Helper loaded: form_helper
INFO - 2023-10-28 10:55:47 --> Helper loaded: lang_helper
INFO - 2023-10-28 10:55:47 --> Helper loaded: security_helper
INFO - 2023-10-28 10:55:47 --> Helper loaded: cookie_helper
INFO - 2023-10-28 10:55:47 --> Database Driver Class Initialized
INFO - 2023-10-28 10:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 10:55:47 --> Parser Class Initialized
INFO - 2023-10-28 10:55:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 10:55:47 --> Pagination Class Initialized
INFO - 2023-10-28 10:55:47 --> Form Validation Class Initialized
INFO - 2023-10-28 10:55:47 --> Controller Class Initialized
INFO - 2023-10-28 10:55:47 --> Model Class Initialized
DEBUG - 2023-10-28 10:55:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 10:55:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:55:47 --> Model Class Initialized
DEBUG - 2023-10-28 10:55:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:55:47 --> Model Class Initialized
INFO - 2023-10-28 10:55:47 --> Final output sent to browser
DEBUG - 2023-10-28 10:55:47 --> Total execution time: 0.0649
ERROR - 2023-10-28 10:55:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 10:55:57 --> Config Class Initialized
INFO - 2023-10-28 10:55:57 --> Hooks Class Initialized
DEBUG - 2023-10-28 10:55:57 --> UTF-8 Support Enabled
INFO - 2023-10-28 10:55:57 --> Utf8 Class Initialized
INFO - 2023-10-28 10:55:57 --> URI Class Initialized
INFO - 2023-10-28 10:55:57 --> Router Class Initialized
INFO - 2023-10-28 10:55:57 --> Output Class Initialized
INFO - 2023-10-28 10:55:57 --> Security Class Initialized
DEBUG - 2023-10-28 10:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 10:55:57 --> Input Class Initialized
INFO - 2023-10-28 10:55:57 --> Language Class Initialized
INFO - 2023-10-28 10:55:57 --> Loader Class Initialized
INFO - 2023-10-28 10:55:57 --> Helper loaded: url_helper
INFO - 2023-10-28 10:55:57 --> Helper loaded: file_helper
INFO - 2023-10-28 10:55:57 --> Helper loaded: html_helper
INFO - 2023-10-28 10:55:57 --> Helper loaded: text_helper
INFO - 2023-10-28 10:55:57 --> Helper loaded: form_helper
INFO - 2023-10-28 10:55:57 --> Helper loaded: lang_helper
INFO - 2023-10-28 10:55:57 --> Helper loaded: security_helper
INFO - 2023-10-28 10:55:57 --> Helper loaded: cookie_helper
INFO - 2023-10-28 10:55:57 --> Database Driver Class Initialized
INFO - 2023-10-28 10:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 10:55:57 --> Parser Class Initialized
INFO - 2023-10-28 10:55:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 10:55:57 --> Pagination Class Initialized
INFO - 2023-10-28 10:55:57 --> Form Validation Class Initialized
INFO - 2023-10-28 10:55:57 --> Controller Class Initialized
INFO - 2023-10-28 10:55:57 --> Model Class Initialized
DEBUG - 2023-10-28 10:55:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 10:55:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:55:57 --> Model Class Initialized
DEBUG - 2023-10-28 10:55:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:55:57 --> Model Class Initialized
INFO - 2023-10-28 10:55:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-10-28 10:55:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:55:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 10:55:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 10:55:57 --> Model Class Initialized
INFO - 2023-10-28 10:55:57 --> Model Class Initialized
INFO - 2023-10-28 10:55:57 --> Model Class Initialized
INFO - 2023-10-28 10:55:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 10:55:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 10:55:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 10:55:58 --> Final output sent to browser
DEBUG - 2023-10-28 10:55:58 --> Total execution time: 0.1356
ERROR - 2023-10-28 10:55:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 10:55:58 --> Config Class Initialized
INFO - 2023-10-28 10:55:58 --> Hooks Class Initialized
DEBUG - 2023-10-28 10:55:58 --> UTF-8 Support Enabled
INFO - 2023-10-28 10:55:58 --> Utf8 Class Initialized
INFO - 2023-10-28 10:55:58 --> URI Class Initialized
INFO - 2023-10-28 10:55:58 --> Router Class Initialized
INFO - 2023-10-28 10:55:58 --> Output Class Initialized
INFO - 2023-10-28 10:55:58 --> Security Class Initialized
DEBUG - 2023-10-28 10:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 10:55:58 --> Input Class Initialized
INFO - 2023-10-28 10:55:58 --> Language Class Initialized
INFO - 2023-10-28 10:55:58 --> Loader Class Initialized
INFO - 2023-10-28 10:55:58 --> Helper loaded: url_helper
INFO - 2023-10-28 10:55:58 --> Helper loaded: file_helper
INFO - 2023-10-28 10:55:58 --> Helper loaded: html_helper
INFO - 2023-10-28 10:55:58 --> Helper loaded: text_helper
INFO - 2023-10-28 10:55:58 --> Helper loaded: form_helper
INFO - 2023-10-28 10:55:58 --> Helper loaded: lang_helper
INFO - 2023-10-28 10:55:58 --> Helper loaded: security_helper
INFO - 2023-10-28 10:55:58 --> Helper loaded: cookie_helper
INFO - 2023-10-28 10:55:58 --> Database Driver Class Initialized
INFO - 2023-10-28 10:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 10:55:58 --> Parser Class Initialized
INFO - 2023-10-28 10:55:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 10:55:58 --> Pagination Class Initialized
INFO - 2023-10-28 10:55:58 --> Form Validation Class Initialized
INFO - 2023-10-28 10:55:58 --> Controller Class Initialized
INFO - 2023-10-28 10:55:58 --> Model Class Initialized
DEBUG - 2023-10-28 10:55:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 10:55:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:55:58 --> Model Class Initialized
DEBUG - 2023-10-28 10:55:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:55:58 --> Model Class Initialized
INFO - 2023-10-28 10:55:58 --> Final output sent to browser
DEBUG - 2023-10-28 10:55:58 --> Total execution time: 0.0278
ERROR - 2023-10-28 10:56:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 10:56:05 --> Config Class Initialized
INFO - 2023-10-28 10:56:05 --> Hooks Class Initialized
DEBUG - 2023-10-28 10:56:05 --> UTF-8 Support Enabled
INFO - 2023-10-28 10:56:05 --> Utf8 Class Initialized
INFO - 2023-10-28 10:56:05 --> URI Class Initialized
INFO - 2023-10-28 10:56:05 --> Router Class Initialized
INFO - 2023-10-28 10:56:05 --> Output Class Initialized
INFO - 2023-10-28 10:56:05 --> Security Class Initialized
DEBUG - 2023-10-28 10:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 10:56:05 --> Input Class Initialized
INFO - 2023-10-28 10:56:05 --> Language Class Initialized
INFO - 2023-10-28 10:56:05 --> Loader Class Initialized
INFO - 2023-10-28 10:56:05 --> Helper loaded: url_helper
INFO - 2023-10-28 10:56:05 --> Helper loaded: file_helper
INFO - 2023-10-28 10:56:05 --> Helper loaded: html_helper
INFO - 2023-10-28 10:56:05 --> Helper loaded: text_helper
INFO - 2023-10-28 10:56:05 --> Helper loaded: form_helper
INFO - 2023-10-28 10:56:05 --> Helper loaded: lang_helper
INFO - 2023-10-28 10:56:05 --> Helper loaded: security_helper
INFO - 2023-10-28 10:56:05 --> Helper loaded: cookie_helper
INFO - 2023-10-28 10:56:05 --> Database Driver Class Initialized
INFO - 2023-10-28 10:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 10:56:05 --> Parser Class Initialized
INFO - 2023-10-28 10:56:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 10:56:05 --> Pagination Class Initialized
INFO - 2023-10-28 10:56:05 --> Form Validation Class Initialized
INFO - 2023-10-28 10:56:05 --> Controller Class Initialized
INFO - 2023-10-28 10:56:05 --> Model Class Initialized
DEBUG - 2023-10-28 10:56:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 10:56:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:56:05 --> Model Class Initialized
DEBUG - 2023-10-28 10:56:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:56:05 --> Model Class Initialized
ERROR - 2023-10-28 10:56:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 10:56:05 --> Config Class Initialized
INFO - 2023-10-28 10:56:05 --> Hooks Class Initialized
DEBUG - 2023-10-28 10:56:05 --> UTF-8 Support Enabled
INFO - 2023-10-28 10:56:05 --> Utf8 Class Initialized
INFO - 2023-10-28 10:56:05 --> URI Class Initialized
INFO - 2023-10-28 10:56:05 --> Router Class Initialized
INFO - 2023-10-28 10:56:05 --> Output Class Initialized
INFO - 2023-10-28 10:56:05 --> Security Class Initialized
DEBUG - 2023-10-28 10:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 10:56:05 --> Input Class Initialized
INFO - 2023-10-28 10:56:05 --> Language Class Initialized
INFO - 2023-10-28 10:56:05 --> Loader Class Initialized
INFO - 2023-10-28 10:56:05 --> Helper loaded: url_helper
INFO - 2023-10-28 10:56:05 --> Helper loaded: file_helper
INFO - 2023-10-28 10:56:05 --> Helper loaded: html_helper
INFO - 2023-10-28 10:56:05 --> Helper loaded: text_helper
INFO - 2023-10-28 10:56:05 --> Helper loaded: form_helper
INFO - 2023-10-28 10:56:05 --> Helper loaded: lang_helper
INFO - 2023-10-28 10:56:05 --> Helper loaded: security_helper
INFO - 2023-10-28 10:56:05 --> Helper loaded: cookie_helper
INFO - 2023-10-28 10:56:05 --> Database Driver Class Initialized
INFO - 2023-10-28 10:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 10:56:05 --> Parser Class Initialized
INFO - 2023-10-28 10:56:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 10:56:05 --> Pagination Class Initialized
INFO - 2023-10-28 10:56:05 --> Form Validation Class Initialized
INFO - 2023-10-28 10:56:05 --> Controller Class Initialized
INFO - 2023-10-28 10:56:05 --> Model Class Initialized
DEBUG - 2023-10-28 10:56:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 10:56:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:56:05 --> Model Class Initialized
DEBUG - 2023-10-28 10:56:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:56:05 --> Model Class Initialized
INFO - 2023-10-28 10:56:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-10-28 10:56:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:56:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 10:56:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 10:56:05 --> Model Class Initialized
INFO - 2023-10-28 10:56:05 --> Model Class Initialized
INFO - 2023-10-28 10:56:05 --> Model Class Initialized
INFO - 2023-10-28 10:56:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 10:56:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 10:56:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 10:56:05 --> Final output sent to browser
DEBUG - 2023-10-28 10:56:05 --> Total execution time: 0.1361
ERROR - 2023-10-28 10:56:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 10:56:06 --> Config Class Initialized
INFO - 2023-10-28 10:56:06 --> Hooks Class Initialized
DEBUG - 2023-10-28 10:56:06 --> UTF-8 Support Enabled
INFO - 2023-10-28 10:56:06 --> Utf8 Class Initialized
INFO - 2023-10-28 10:56:06 --> URI Class Initialized
INFO - 2023-10-28 10:56:06 --> Router Class Initialized
INFO - 2023-10-28 10:56:06 --> Output Class Initialized
INFO - 2023-10-28 10:56:06 --> Security Class Initialized
DEBUG - 2023-10-28 10:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 10:56:06 --> Input Class Initialized
INFO - 2023-10-28 10:56:06 --> Language Class Initialized
INFO - 2023-10-28 10:56:06 --> Loader Class Initialized
INFO - 2023-10-28 10:56:06 --> Helper loaded: url_helper
INFO - 2023-10-28 10:56:06 --> Helper loaded: file_helper
INFO - 2023-10-28 10:56:06 --> Helper loaded: html_helper
INFO - 2023-10-28 10:56:06 --> Helper loaded: text_helper
INFO - 2023-10-28 10:56:06 --> Helper loaded: form_helper
INFO - 2023-10-28 10:56:06 --> Helper loaded: lang_helper
INFO - 2023-10-28 10:56:06 --> Helper loaded: security_helper
INFO - 2023-10-28 10:56:06 --> Helper loaded: cookie_helper
INFO - 2023-10-28 10:56:06 --> Database Driver Class Initialized
INFO - 2023-10-28 10:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 10:56:06 --> Parser Class Initialized
INFO - 2023-10-28 10:56:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 10:56:06 --> Pagination Class Initialized
INFO - 2023-10-28 10:56:06 --> Form Validation Class Initialized
INFO - 2023-10-28 10:56:06 --> Controller Class Initialized
INFO - 2023-10-28 10:56:06 --> Model Class Initialized
DEBUG - 2023-10-28 10:56:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 10:56:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:56:06 --> Model Class Initialized
DEBUG - 2023-10-28 10:56:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:56:06 --> Model Class Initialized
INFO - 2023-10-28 10:56:06 --> Final output sent to browser
DEBUG - 2023-10-28 10:56:06 --> Total execution time: 0.0238
ERROR - 2023-10-28 10:56:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 10:56:11 --> Config Class Initialized
INFO - 2023-10-28 10:56:11 --> Hooks Class Initialized
DEBUG - 2023-10-28 10:56:11 --> UTF-8 Support Enabled
INFO - 2023-10-28 10:56:11 --> Utf8 Class Initialized
INFO - 2023-10-28 10:56:11 --> URI Class Initialized
DEBUG - 2023-10-28 10:56:11 --> No URI present. Default controller set.
INFO - 2023-10-28 10:56:11 --> Router Class Initialized
INFO - 2023-10-28 10:56:11 --> Output Class Initialized
INFO - 2023-10-28 10:56:11 --> Security Class Initialized
DEBUG - 2023-10-28 10:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 10:56:11 --> Input Class Initialized
INFO - 2023-10-28 10:56:11 --> Language Class Initialized
INFO - 2023-10-28 10:56:11 --> Loader Class Initialized
INFO - 2023-10-28 10:56:11 --> Helper loaded: url_helper
INFO - 2023-10-28 10:56:11 --> Helper loaded: file_helper
INFO - 2023-10-28 10:56:11 --> Helper loaded: html_helper
INFO - 2023-10-28 10:56:11 --> Helper loaded: text_helper
INFO - 2023-10-28 10:56:11 --> Helper loaded: form_helper
INFO - 2023-10-28 10:56:11 --> Helper loaded: lang_helper
INFO - 2023-10-28 10:56:11 --> Helper loaded: security_helper
INFO - 2023-10-28 10:56:11 --> Helper loaded: cookie_helper
INFO - 2023-10-28 10:56:11 --> Database Driver Class Initialized
INFO - 2023-10-28 10:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 10:56:11 --> Parser Class Initialized
INFO - 2023-10-28 10:56:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 10:56:11 --> Pagination Class Initialized
INFO - 2023-10-28 10:56:11 --> Form Validation Class Initialized
INFO - 2023-10-28 10:56:11 --> Controller Class Initialized
INFO - 2023-10-28 10:56:11 --> Model Class Initialized
DEBUG - 2023-10-28 10:56:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:56:11 --> Model Class Initialized
DEBUG - 2023-10-28 10:56:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:56:11 --> Model Class Initialized
INFO - 2023-10-28 10:56:11 --> Model Class Initialized
INFO - 2023-10-28 10:56:11 --> Model Class Initialized
INFO - 2023-10-28 10:56:11 --> Model Class Initialized
DEBUG - 2023-10-28 10:56:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 10:56:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:56:11 --> Model Class Initialized
INFO - 2023-10-28 10:56:11 --> Model Class Initialized
INFO - 2023-10-28 10:56:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-28 10:56:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:56:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 10:56:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 10:56:11 --> Model Class Initialized
INFO - 2023-10-28 10:56:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 10:56:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 10:56:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 10:56:11 --> Final output sent to browser
DEBUG - 2023-10-28 10:56:11 --> Total execution time: 0.2039
ERROR - 2023-10-28 10:56:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 10:56:21 --> Config Class Initialized
INFO - 2023-10-28 10:56:21 --> Hooks Class Initialized
DEBUG - 2023-10-28 10:56:21 --> UTF-8 Support Enabled
INFO - 2023-10-28 10:56:21 --> Utf8 Class Initialized
INFO - 2023-10-28 10:56:21 --> URI Class Initialized
INFO - 2023-10-28 10:56:21 --> Router Class Initialized
INFO - 2023-10-28 10:56:21 --> Output Class Initialized
INFO - 2023-10-28 10:56:21 --> Security Class Initialized
DEBUG - 2023-10-28 10:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 10:56:21 --> Input Class Initialized
INFO - 2023-10-28 10:56:21 --> Language Class Initialized
INFO - 2023-10-28 10:56:21 --> Loader Class Initialized
INFO - 2023-10-28 10:56:21 --> Helper loaded: url_helper
INFO - 2023-10-28 10:56:21 --> Helper loaded: file_helper
INFO - 2023-10-28 10:56:21 --> Helper loaded: html_helper
INFO - 2023-10-28 10:56:21 --> Helper loaded: text_helper
INFO - 2023-10-28 10:56:21 --> Helper loaded: form_helper
INFO - 2023-10-28 10:56:21 --> Helper loaded: lang_helper
INFO - 2023-10-28 10:56:21 --> Helper loaded: security_helper
INFO - 2023-10-28 10:56:21 --> Helper loaded: cookie_helper
INFO - 2023-10-28 10:56:21 --> Database Driver Class Initialized
INFO - 2023-10-28 10:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 10:56:21 --> Parser Class Initialized
INFO - 2023-10-28 10:56:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 10:56:21 --> Pagination Class Initialized
INFO - 2023-10-28 10:56:21 --> Form Validation Class Initialized
INFO - 2023-10-28 10:56:21 --> Controller Class Initialized
INFO - 2023-10-28 10:56:21 --> Model Class Initialized
DEBUG - 2023-10-28 10:56:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 10:56:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:56:21 --> Model Class Initialized
DEBUG - 2023-10-28 10:56:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:56:21 --> Model Class Initialized
INFO - 2023-10-28 10:56:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-10-28 10:56:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:56:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 10:56:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 10:56:21 --> Model Class Initialized
INFO - 2023-10-28 10:56:21 --> Model Class Initialized
INFO - 2023-10-28 10:56:21 --> Model Class Initialized
INFO - 2023-10-28 10:56:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 10:56:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 10:56:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 10:56:21 --> Final output sent to browser
DEBUG - 2023-10-28 10:56:21 --> Total execution time: 0.1892
ERROR - 2023-10-28 10:56:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 10:56:21 --> Config Class Initialized
INFO - 2023-10-28 10:56:21 --> Hooks Class Initialized
DEBUG - 2023-10-28 10:56:21 --> UTF-8 Support Enabled
INFO - 2023-10-28 10:56:21 --> Utf8 Class Initialized
INFO - 2023-10-28 10:56:21 --> URI Class Initialized
INFO - 2023-10-28 10:56:21 --> Router Class Initialized
INFO - 2023-10-28 10:56:21 --> Output Class Initialized
INFO - 2023-10-28 10:56:21 --> Security Class Initialized
DEBUG - 2023-10-28 10:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 10:56:21 --> Input Class Initialized
INFO - 2023-10-28 10:56:21 --> Language Class Initialized
INFO - 2023-10-28 10:56:21 --> Loader Class Initialized
INFO - 2023-10-28 10:56:21 --> Helper loaded: url_helper
INFO - 2023-10-28 10:56:21 --> Helper loaded: file_helper
INFO - 2023-10-28 10:56:21 --> Helper loaded: html_helper
INFO - 2023-10-28 10:56:21 --> Helper loaded: text_helper
INFO - 2023-10-28 10:56:21 --> Helper loaded: form_helper
INFO - 2023-10-28 10:56:21 --> Helper loaded: lang_helper
INFO - 2023-10-28 10:56:21 --> Helper loaded: security_helper
INFO - 2023-10-28 10:56:21 --> Helper loaded: cookie_helper
INFO - 2023-10-28 10:56:21 --> Database Driver Class Initialized
INFO - 2023-10-28 10:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 10:56:21 --> Parser Class Initialized
INFO - 2023-10-28 10:56:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 10:56:21 --> Pagination Class Initialized
INFO - 2023-10-28 10:56:21 --> Form Validation Class Initialized
INFO - 2023-10-28 10:56:21 --> Controller Class Initialized
INFO - 2023-10-28 10:56:21 --> Model Class Initialized
DEBUG - 2023-10-28 10:56:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 10:56:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:56:21 --> Model Class Initialized
DEBUG - 2023-10-28 10:56:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:56:21 --> Model Class Initialized
INFO - 2023-10-28 10:56:21 --> Final output sent to browser
DEBUG - 2023-10-28 10:56:21 --> Total execution time: 0.0454
ERROR - 2023-10-28 10:56:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 10:56:28 --> Config Class Initialized
INFO - 2023-10-28 10:56:28 --> Hooks Class Initialized
DEBUG - 2023-10-28 10:56:28 --> UTF-8 Support Enabled
INFO - 2023-10-28 10:56:28 --> Utf8 Class Initialized
INFO - 2023-10-28 10:56:28 --> URI Class Initialized
DEBUG - 2023-10-28 10:56:28 --> No URI present. Default controller set.
INFO - 2023-10-28 10:56:28 --> Router Class Initialized
INFO - 2023-10-28 10:56:28 --> Output Class Initialized
INFO - 2023-10-28 10:56:28 --> Security Class Initialized
DEBUG - 2023-10-28 10:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 10:56:28 --> Input Class Initialized
INFO - 2023-10-28 10:56:28 --> Language Class Initialized
INFO - 2023-10-28 10:56:28 --> Loader Class Initialized
INFO - 2023-10-28 10:56:28 --> Helper loaded: url_helper
INFO - 2023-10-28 10:56:28 --> Helper loaded: file_helper
INFO - 2023-10-28 10:56:28 --> Helper loaded: html_helper
INFO - 2023-10-28 10:56:28 --> Helper loaded: text_helper
INFO - 2023-10-28 10:56:28 --> Helper loaded: form_helper
INFO - 2023-10-28 10:56:28 --> Helper loaded: lang_helper
INFO - 2023-10-28 10:56:28 --> Helper loaded: security_helper
INFO - 2023-10-28 10:56:28 --> Helper loaded: cookie_helper
INFO - 2023-10-28 10:56:28 --> Database Driver Class Initialized
INFO - 2023-10-28 10:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 10:56:28 --> Parser Class Initialized
INFO - 2023-10-28 10:56:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 10:56:28 --> Pagination Class Initialized
INFO - 2023-10-28 10:56:28 --> Form Validation Class Initialized
INFO - 2023-10-28 10:56:28 --> Controller Class Initialized
INFO - 2023-10-28 10:56:28 --> Model Class Initialized
DEBUG - 2023-10-28 10:56:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:56:28 --> Model Class Initialized
DEBUG - 2023-10-28 10:56:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:56:28 --> Model Class Initialized
INFO - 2023-10-28 10:56:28 --> Model Class Initialized
INFO - 2023-10-28 10:56:28 --> Model Class Initialized
INFO - 2023-10-28 10:56:28 --> Model Class Initialized
DEBUG - 2023-10-28 10:56:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 10:56:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:56:28 --> Model Class Initialized
INFO - 2023-10-28 10:56:28 --> Model Class Initialized
INFO - 2023-10-28 10:56:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-28 10:56:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:56:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 10:56:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 10:56:28 --> Model Class Initialized
INFO - 2023-10-28 10:56:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 10:56:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 10:56:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 10:56:28 --> Final output sent to browser
DEBUG - 2023-10-28 10:56:28 --> Total execution time: 0.3561
ERROR - 2023-10-28 10:56:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 10:56:43 --> Config Class Initialized
INFO - 2023-10-28 10:56:43 --> Hooks Class Initialized
DEBUG - 2023-10-28 10:56:43 --> UTF-8 Support Enabled
INFO - 2023-10-28 10:56:43 --> Utf8 Class Initialized
INFO - 2023-10-28 10:56:43 --> URI Class Initialized
DEBUG - 2023-10-28 10:56:43 --> No URI present. Default controller set.
INFO - 2023-10-28 10:56:43 --> Router Class Initialized
INFO - 2023-10-28 10:56:43 --> Output Class Initialized
INFO - 2023-10-28 10:56:43 --> Security Class Initialized
DEBUG - 2023-10-28 10:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 10:56:43 --> Input Class Initialized
INFO - 2023-10-28 10:56:43 --> Language Class Initialized
INFO - 2023-10-28 10:56:43 --> Loader Class Initialized
INFO - 2023-10-28 10:56:43 --> Helper loaded: url_helper
INFO - 2023-10-28 10:56:43 --> Helper loaded: file_helper
INFO - 2023-10-28 10:56:43 --> Helper loaded: html_helper
INFO - 2023-10-28 10:56:43 --> Helper loaded: text_helper
INFO - 2023-10-28 10:56:43 --> Helper loaded: form_helper
INFO - 2023-10-28 10:56:43 --> Helper loaded: lang_helper
INFO - 2023-10-28 10:56:43 --> Helper loaded: security_helper
INFO - 2023-10-28 10:56:43 --> Helper loaded: cookie_helper
INFO - 2023-10-28 10:56:43 --> Database Driver Class Initialized
INFO - 2023-10-28 10:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 10:56:43 --> Parser Class Initialized
INFO - 2023-10-28 10:56:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 10:56:43 --> Pagination Class Initialized
INFO - 2023-10-28 10:56:43 --> Form Validation Class Initialized
INFO - 2023-10-28 10:56:43 --> Controller Class Initialized
INFO - 2023-10-28 10:56:43 --> Model Class Initialized
DEBUG - 2023-10-28 10:56:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:56:43 --> Model Class Initialized
DEBUG - 2023-10-28 10:56:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:56:43 --> Model Class Initialized
INFO - 2023-10-28 10:56:43 --> Model Class Initialized
INFO - 2023-10-28 10:56:43 --> Model Class Initialized
INFO - 2023-10-28 10:56:43 --> Model Class Initialized
DEBUG - 2023-10-28 10:56:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 10:56:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:56:43 --> Model Class Initialized
INFO - 2023-10-28 10:56:43 --> Model Class Initialized
INFO - 2023-10-28 10:56:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-28 10:56:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:56:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 10:56:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 10:56:43 --> Model Class Initialized
INFO - 2023-10-28 10:56:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 10:56:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 10:56:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 10:56:43 --> Final output sent to browser
DEBUG - 2023-10-28 10:56:43 --> Total execution time: 0.1964
ERROR - 2023-10-28 10:56:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 10:56:56 --> Config Class Initialized
INFO - 2023-10-28 10:56:56 --> Hooks Class Initialized
DEBUG - 2023-10-28 10:56:56 --> UTF-8 Support Enabled
INFO - 2023-10-28 10:56:56 --> Utf8 Class Initialized
INFO - 2023-10-28 10:56:56 --> URI Class Initialized
INFO - 2023-10-28 10:56:56 --> Router Class Initialized
INFO - 2023-10-28 10:56:56 --> Output Class Initialized
INFO - 2023-10-28 10:56:56 --> Security Class Initialized
DEBUG - 2023-10-28 10:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 10:56:56 --> Input Class Initialized
INFO - 2023-10-28 10:56:56 --> Language Class Initialized
INFO - 2023-10-28 10:56:56 --> Loader Class Initialized
INFO - 2023-10-28 10:56:56 --> Helper loaded: url_helper
INFO - 2023-10-28 10:56:56 --> Helper loaded: file_helper
INFO - 2023-10-28 10:56:56 --> Helper loaded: html_helper
INFO - 2023-10-28 10:56:56 --> Helper loaded: text_helper
INFO - 2023-10-28 10:56:56 --> Helper loaded: form_helper
INFO - 2023-10-28 10:56:56 --> Helper loaded: lang_helper
INFO - 2023-10-28 10:56:56 --> Helper loaded: security_helper
INFO - 2023-10-28 10:56:56 --> Helper loaded: cookie_helper
INFO - 2023-10-28 10:56:56 --> Database Driver Class Initialized
INFO - 2023-10-28 10:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 10:56:56 --> Parser Class Initialized
INFO - 2023-10-28 10:56:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 10:56:56 --> Pagination Class Initialized
INFO - 2023-10-28 10:56:56 --> Form Validation Class Initialized
INFO - 2023-10-28 10:56:56 --> Controller Class Initialized
DEBUG - 2023-10-28 10:56:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 10:56:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:56:56 --> Model Class Initialized
DEBUG - 2023-10-28 10:56:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:56:56 --> Model Class Initialized
DEBUG - 2023-10-28 10:56:56 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:56:56 --> Model Class Initialized
INFO - 2023-10-28 10:56:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-10-28 10:56:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:56:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 10:56:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 10:56:56 --> Model Class Initialized
INFO - 2023-10-28 10:56:56 --> Model Class Initialized
INFO - 2023-10-28 10:56:56 --> Model Class Initialized
INFO - 2023-10-28 10:56:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 10:56:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 10:56:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 10:56:56 --> Final output sent to browser
DEBUG - 2023-10-28 10:56:56 --> Total execution time: 0.1314
ERROR - 2023-10-28 10:56:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 10:56:57 --> Config Class Initialized
INFO - 2023-10-28 10:56:57 --> Hooks Class Initialized
DEBUG - 2023-10-28 10:56:57 --> UTF-8 Support Enabled
INFO - 2023-10-28 10:56:57 --> Utf8 Class Initialized
INFO - 2023-10-28 10:56:57 --> URI Class Initialized
INFO - 2023-10-28 10:56:57 --> Router Class Initialized
INFO - 2023-10-28 10:56:57 --> Output Class Initialized
INFO - 2023-10-28 10:56:57 --> Security Class Initialized
DEBUG - 2023-10-28 10:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 10:56:57 --> Input Class Initialized
INFO - 2023-10-28 10:56:57 --> Language Class Initialized
INFO - 2023-10-28 10:56:57 --> Loader Class Initialized
INFO - 2023-10-28 10:56:57 --> Helper loaded: url_helper
INFO - 2023-10-28 10:56:57 --> Helper loaded: file_helper
INFO - 2023-10-28 10:56:57 --> Helper loaded: html_helper
INFO - 2023-10-28 10:56:57 --> Helper loaded: text_helper
INFO - 2023-10-28 10:56:57 --> Helper loaded: form_helper
INFO - 2023-10-28 10:56:57 --> Helper loaded: lang_helper
INFO - 2023-10-28 10:56:57 --> Helper loaded: security_helper
INFO - 2023-10-28 10:56:57 --> Helper loaded: cookie_helper
INFO - 2023-10-28 10:56:57 --> Database Driver Class Initialized
INFO - 2023-10-28 10:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 10:56:57 --> Parser Class Initialized
INFO - 2023-10-28 10:56:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 10:56:57 --> Pagination Class Initialized
INFO - 2023-10-28 10:56:57 --> Form Validation Class Initialized
INFO - 2023-10-28 10:56:57 --> Controller Class Initialized
DEBUG - 2023-10-28 10:56:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 10:56:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:56:57 --> Model Class Initialized
DEBUG - 2023-10-28 10:56:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:56:57 --> Model Class Initialized
INFO - 2023-10-28 10:56:57 --> Final output sent to browser
DEBUG - 2023-10-28 10:56:57 --> Total execution time: 0.0216
ERROR - 2023-10-28 10:57:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 10:57:02 --> Config Class Initialized
INFO - 2023-10-28 10:57:02 --> Hooks Class Initialized
DEBUG - 2023-10-28 10:57:02 --> UTF-8 Support Enabled
INFO - 2023-10-28 10:57:02 --> Utf8 Class Initialized
INFO - 2023-10-28 10:57:02 --> URI Class Initialized
DEBUG - 2023-10-28 10:57:02 --> No URI present. Default controller set.
INFO - 2023-10-28 10:57:02 --> Router Class Initialized
INFO - 2023-10-28 10:57:02 --> Output Class Initialized
INFO - 2023-10-28 10:57:02 --> Security Class Initialized
DEBUG - 2023-10-28 10:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 10:57:02 --> Input Class Initialized
INFO - 2023-10-28 10:57:02 --> Language Class Initialized
INFO - 2023-10-28 10:57:02 --> Loader Class Initialized
INFO - 2023-10-28 10:57:02 --> Helper loaded: url_helper
INFO - 2023-10-28 10:57:02 --> Helper loaded: file_helper
INFO - 2023-10-28 10:57:02 --> Helper loaded: html_helper
INFO - 2023-10-28 10:57:02 --> Helper loaded: text_helper
INFO - 2023-10-28 10:57:02 --> Helper loaded: form_helper
INFO - 2023-10-28 10:57:02 --> Helper loaded: lang_helper
INFO - 2023-10-28 10:57:02 --> Helper loaded: security_helper
INFO - 2023-10-28 10:57:02 --> Helper loaded: cookie_helper
INFO - 2023-10-28 10:57:02 --> Database Driver Class Initialized
INFO - 2023-10-28 10:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 10:57:02 --> Parser Class Initialized
INFO - 2023-10-28 10:57:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 10:57:02 --> Pagination Class Initialized
INFO - 2023-10-28 10:57:02 --> Form Validation Class Initialized
INFO - 2023-10-28 10:57:02 --> Controller Class Initialized
INFO - 2023-10-28 10:57:02 --> Model Class Initialized
DEBUG - 2023-10-28 10:57:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:57:02 --> Model Class Initialized
DEBUG - 2023-10-28 10:57:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:57:02 --> Model Class Initialized
INFO - 2023-10-28 10:57:02 --> Model Class Initialized
INFO - 2023-10-28 10:57:02 --> Model Class Initialized
INFO - 2023-10-28 10:57:02 --> Model Class Initialized
DEBUG - 2023-10-28 10:57:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 10:57:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:57:02 --> Model Class Initialized
INFO - 2023-10-28 10:57:02 --> Model Class Initialized
INFO - 2023-10-28 10:57:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-28 10:57:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 10:57:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 10:57:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 10:57:02 --> Model Class Initialized
INFO - 2023-10-28 10:57:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 10:57:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 10:57:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 10:57:02 --> Final output sent to browser
DEBUG - 2023-10-28 10:57:02 --> Total execution time: 0.2033
ERROR - 2023-10-28 11:03:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 11:03:17 --> Config Class Initialized
INFO - 2023-10-28 11:03:17 --> Hooks Class Initialized
DEBUG - 2023-10-28 11:03:17 --> UTF-8 Support Enabled
INFO - 2023-10-28 11:03:17 --> Utf8 Class Initialized
INFO - 2023-10-28 11:03:17 --> URI Class Initialized
DEBUG - 2023-10-28 11:03:17 --> No URI present. Default controller set.
INFO - 2023-10-28 11:03:17 --> Router Class Initialized
INFO - 2023-10-28 11:03:17 --> Output Class Initialized
INFO - 2023-10-28 11:03:17 --> Security Class Initialized
DEBUG - 2023-10-28 11:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 11:03:17 --> Input Class Initialized
INFO - 2023-10-28 11:03:17 --> Language Class Initialized
INFO - 2023-10-28 11:03:17 --> Loader Class Initialized
INFO - 2023-10-28 11:03:17 --> Helper loaded: url_helper
INFO - 2023-10-28 11:03:17 --> Helper loaded: file_helper
INFO - 2023-10-28 11:03:17 --> Helper loaded: html_helper
INFO - 2023-10-28 11:03:17 --> Helper loaded: text_helper
INFO - 2023-10-28 11:03:17 --> Helper loaded: form_helper
INFO - 2023-10-28 11:03:17 --> Helper loaded: lang_helper
INFO - 2023-10-28 11:03:17 --> Helper loaded: security_helper
INFO - 2023-10-28 11:03:17 --> Helper loaded: cookie_helper
INFO - 2023-10-28 11:03:17 --> Database Driver Class Initialized
INFO - 2023-10-28 11:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 11:03:17 --> Parser Class Initialized
INFO - 2023-10-28 11:03:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 11:03:17 --> Pagination Class Initialized
INFO - 2023-10-28 11:03:17 --> Form Validation Class Initialized
INFO - 2023-10-28 11:03:17 --> Controller Class Initialized
INFO - 2023-10-28 11:03:17 --> Model Class Initialized
DEBUG - 2023-10-28 11:03:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 11:03:17 --> Model Class Initialized
DEBUG - 2023-10-28 11:03:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 11:03:17 --> Model Class Initialized
INFO - 2023-10-28 11:03:17 --> Model Class Initialized
INFO - 2023-10-28 11:03:17 --> Model Class Initialized
INFO - 2023-10-28 11:03:17 --> Model Class Initialized
DEBUG - 2023-10-28 11:03:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 11:03:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 11:03:17 --> Model Class Initialized
INFO - 2023-10-28 11:03:17 --> Model Class Initialized
INFO - 2023-10-28 11:03:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-28 11:03:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 11:03:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 11:03:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 11:03:18 --> Model Class Initialized
INFO - 2023-10-28 11:03:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 11:03:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 11:03:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 11:03:18 --> Final output sent to browser
DEBUG - 2023-10-28 11:03:18 --> Total execution time: 0.3578
ERROR - 2023-10-28 11:03:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 11:03:36 --> Config Class Initialized
INFO - 2023-10-28 11:03:36 --> Hooks Class Initialized
DEBUG - 2023-10-28 11:03:36 --> UTF-8 Support Enabled
INFO - 2023-10-28 11:03:36 --> Utf8 Class Initialized
INFO - 2023-10-28 11:03:36 --> URI Class Initialized
INFO - 2023-10-28 11:03:36 --> Router Class Initialized
INFO - 2023-10-28 11:03:36 --> Output Class Initialized
INFO - 2023-10-28 11:03:36 --> Security Class Initialized
DEBUG - 2023-10-28 11:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 11:03:36 --> Input Class Initialized
INFO - 2023-10-28 11:03:36 --> Language Class Initialized
INFO - 2023-10-28 11:03:36 --> Loader Class Initialized
INFO - 2023-10-28 11:03:36 --> Helper loaded: url_helper
INFO - 2023-10-28 11:03:36 --> Helper loaded: file_helper
INFO - 2023-10-28 11:03:36 --> Helper loaded: html_helper
INFO - 2023-10-28 11:03:36 --> Helper loaded: text_helper
INFO - 2023-10-28 11:03:36 --> Helper loaded: form_helper
INFO - 2023-10-28 11:03:36 --> Helper loaded: lang_helper
INFO - 2023-10-28 11:03:36 --> Helper loaded: security_helper
INFO - 2023-10-28 11:03:36 --> Helper loaded: cookie_helper
INFO - 2023-10-28 11:03:36 --> Database Driver Class Initialized
INFO - 2023-10-28 11:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 11:03:36 --> Parser Class Initialized
INFO - 2023-10-28 11:03:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 11:03:36 --> Pagination Class Initialized
INFO - 2023-10-28 11:03:36 --> Form Validation Class Initialized
INFO - 2023-10-28 11:03:36 --> Controller Class Initialized
DEBUG - 2023-10-28 11:03:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 11:03:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 11:03:36 --> Model Class Initialized
DEBUG - 2023-10-28 11:03:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 11:03:36 --> Model Class Initialized
DEBUG - 2023-10-28 11:03:36 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-10-28 11:03:36 --> Model Class Initialized
INFO - 2023-10-28 11:03:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-10-28 11:03:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 11:03:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 11:03:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 11:03:36 --> Model Class Initialized
INFO - 2023-10-28 11:03:36 --> Model Class Initialized
INFO - 2023-10-28 11:03:36 --> Model Class Initialized
INFO - 2023-10-28 11:03:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 11:03:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 11:03:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 11:03:36 --> Final output sent to browser
DEBUG - 2023-10-28 11:03:36 --> Total execution time: 0.1880
ERROR - 2023-10-28 11:03:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 11:03:37 --> Config Class Initialized
INFO - 2023-10-28 11:03:37 --> Hooks Class Initialized
DEBUG - 2023-10-28 11:03:37 --> UTF-8 Support Enabled
INFO - 2023-10-28 11:03:37 --> Utf8 Class Initialized
INFO - 2023-10-28 11:03:37 --> URI Class Initialized
INFO - 2023-10-28 11:03:37 --> Router Class Initialized
INFO - 2023-10-28 11:03:37 --> Output Class Initialized
INFO - 2023-10-28 11:03:37 --> Security Class Initialized
DEBUG - 2023-10-28 11:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 11:03:37 --> Input Class Initialized
INFO - 2023-10-28 11:03:37 --> Language Class Initialized
INFO - 2023-10-28 11:03:37 --> Loader Class Initialized
INFO - 2023-10-28 11:03:37 --> Helper loaded: url_helper
INFO - 2023-10-28 11:03:37 --> Helper loaded: file_helper
INFO - 2023-10-28 11:03:37 --> Helper loaded: html_helper
INFO - 2023-10-28 11:03:37 --> Helper loaded: text_helper
INFO - 2023-10-28 11:03:37 --> Helper loaded: form_helper
INFO - 2023-10-28 11:03:37 --> Helper loaded: lang_helper
INFO - 2023-10-28 11:03:37 --> Helper loaded: security_helper
INFO - 2023-10-28 11:03:37 --> Helper loaded: cookie_helper
INFO - 2023-10-28 11:03:37 --> Database Driver Class Initialized
INFO - 2023-10-28 11:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 11:03:37 --> Parser Class Initialized
INFO - 2023-10-28 11:03:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 11:03:37 --> Pagination Class Initialized
INFO - 2023-10-28 11:03:37 --> Form Validation Class Initialized
INFO - 2023-10-28 11:03:37 --> Controller Class Initialized
DEBUG - 2023-10-28 11:03:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 11:03:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 11:03:37 --> Model Class Initialized
DEBUG - 2023-10-28 11:03:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 11:03:37 --> Model Class Initialized
INFO - 2023-10-28 11:03:37 --> Final output sent to browser
DEBUG - 2023-10-28 11:03:37 --> Total execution time: 0.0328
ERROR - 2023-10-28 11:03:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 11:03:40 --> Config Class Initialized
INFO - 2023-10-28 11:03:40 --> Hooks Class Initialized
DEBUG - 2023-10-28 11:03:40 --> UTF-8 Support Enabled
INFO - 2023-10-28 11:03:40 --> Utf8 Class Initialized
INFO - 2023-10-28 11:03:40 --> URI Class Initialized
INFO - 2023-10-28 11:03:40 --> Router Class Initialized
INFO - 2023-10-28 11:03:40 --> Output Class Initialized
INFO - 2023-10-28 11:03:40 --> Security Class Initialized
DEBUG - 2023-10-28 11:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 11:03:40 --> Input Class Initialized
INFO - 2023-10-28 11:03:40 --> Language Class Initialized
INFO - 2023-10-28 11:03:40 --> Loader Class Initialized
INFO - 2023-10-28 11:03:40 --> Helper loaded: url_helper
INFO - 2023-10-28 11:03:40 --> Helper loaded: file_helper
INFO - 2023-10-28 11:03:40 --> Helper loaded: html_helper
INFO - 2023-10-28 11:03:40 --> Helper loaded: text_helper
INFO - 2023-10-28 11:03:40 --> Helper loaded: form_helper
INFO - 2023-10-28 11:03:40 --> Helper loaded: lang_helper
INFO - 2023-10-28 11:03:40 --> Helper loaded: security_helper
INFO - 2023-10-28 11:03:40 --> Helper loaded: cookie_helper
INFO - 2023-10-28 11:03:40 --> Database Driver Class Initialized
INFO - 2023-10-28 11:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 11:03:40 --> Parser Class Initialized
INFO - 2023-10-28 11:03:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 11:03:40 --> Pagination Class Initialized
INFO - 2023-10-28 11:03:40 --> Form Validation Class Initialized
INFO - 2023-10-28 11:03:40 --> Controller Class Initialized
DEBUG - 2023-10-28 11:03:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 11:03:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 11:03:40 --> Model Class Initialized
DEBUG - 2023-10-28 11:03:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 11:03:40 --> Model Class Initialized
INFO - 2023-10-28 11:03:41 --> Final output sent to browser
DEBUG - 2023-10-28 11:03:41 --> Total execution time: 0.1971
ERROR - 2023-10-28 11:03:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 11:03:46 --> Config Class Initialized
INFO - 2023-10-28 11:03:46 --> Hooks Class Initialized
DEBUG - 2023-10-28 11:03:46 --> UTF-8 Support Enabled
INFO - 2023-10-28 11:03:46 --> Utf8 Class Initialized
INFO - 2023-10-28 11:03:46 --> URI Class Initialized
DEBUG - 2023-10-28 11:03:46 --> No URI present. Default controller set.
INFO - 2023-10-28 11:03:46 --> Router Class Initialized
INFO - 2023-10-28 11:03:46 --> Output Class Initialized
INFO - 2023-10-28 11:03:46 --> Security Class Initialized
DEBUG - 2023-10-28 11:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 11:03:46 --> Input Class Initialized
INFO - 2023-10-28 11:03:46 --> Language Class Initialized
INFO - 2023-10-28 11:03:46 --> Loader Class Initialized
INFO - 2023-10-28 11:03:46 --> Helper loaded: url_helper
INFO - 2023-10-28 11:03:46 --> Helper loaded: file_helper
INFO - 2023-10-28 11:03:46 --> Helper loaded: html_helper
INFO - 2023-10-28 11:03:46 --> Helper loaded: text_helper
INFO - 2023-10-28 11:03:46 --> Helper loaded: form_helper
INFO - 2023-10-28 11:03:46 --> Helper loaded: lang_helper
INFO - 2023-10-28 11:03:46 --> Helper loaded: security_helper
INFO - 2023-10-28 11:03:46 --> Helper loaded: cookie_helper
INFO - 2023-10-28 11:03:46 --> Database Driver Class Initialized
INFO - 2023-10-28 11:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 11:03:46 --> Parser Class Initialized
INFO - 2023-10-28 11:03:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 11:03:46 --> Pagination Class Initialized
INFO - 2023-10-28 11:03:46 --> Form Validation Class Initialized
INFO - 2023-10-28 11:03:46 --> Controller Class Initialized
INFO - 2023-10-28 11:03:46 --> Model Class Initialized
DEBUG - 2023-10-28 11:03:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 11:03:46 --> Model Class Initialized
DEBUG - 2023-10-28 11:03:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 11:03:46 --> Model Class Initialized
INFO - 2023-10-28 11:03:46 --> Model Class Initialized
INFO - 2023-10-28 11:03:46 --> Model Class Initialized
INFO - 2023-10-28 11:03:46 --> Model Class Initialized
DEBUG - 2023-10-28 11:03:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 11:03:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 11:03:46 --> Model Class Initialized
INFO - 2023-10-28 11:03:46 --> Model Class Initialized
INFO - 2023-10-28 11:03:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-28 11:03:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 11:03:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 11:03:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 11:03:46 --> Model Class Initialized
INFO - 2023-10-28 11:03:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 11:03:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 11:03:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 11:03:46 --> Final output sent to browser
DEBUG - 2023-10-28 11:03:46 --> Total execution time: 0.3517
ERROR - 2023-10-28 11:03:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 11:03:49 --> Config Class Initialized
INFO - 2023-10-28 11:03:49 --> Hooks Class Initialized
DEBUG - 2023-10-28 11:03:49 --> UTF-8 Support Enabled
INFO - 2023-10-28 11:03:49 --> Utf8 Class Initialized
INFO - 2023-10-28 11:03:49 --> URI Class Initialized
INFO - 2023-10-28 11:03:49 --> Router Class Initialized
INFO - 2023-10-28 11:03:49 --> Output Class Initialized
INFO - 2023-10-28 11:03:49 --> Security Class Initialized
DEBUG - 2023-10-28 11:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 11:03:49 --> Input Class Initialized
INFO - 2023-10-28 11:03:49 --> Language Class Initialized
INFO - 2023-10-28 11:03:49 --> Loader Class Initialized
INFO - 2023-10-28 11:03:49 --> Helper loaded: url_helper
INFO - 2023-10-28 11:03:49 --> Helper loaded: file_helper
INFO - 2023-10-28 11:03:49 --> Helper loaded: html_helper
INFO - 2023-10-28 11:03:49 --> Helper loaded: text_helper
INFO - 2023-10-28 11:03:49 --> Helper loaded: form_helper
INFO - 2023-10-28 11:03:49 --> Helper loaded: lang_helper
INFO - 2023-10-28 11:03:49 --> Helper loaded: security_helper
INFO - 2023-10-28 11:03:49 --> Helper loaded: cookie_helper
INFO - 2023-10-28 11:03:49 --> Database Driver Class Initialized
INFO - 2023-10-28 11:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 11:03:49 --> Parser Class Initialized
INFO - 2023-10-28 11:03:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 11:03:49 --> Pagination Class Initialized
INFO - 2023-10-28 11:03:49 --> Form Validation Class Initialized
INFO - 2023-10-28 11:03:49 --> Controller Class Initialized
DEBUG - 2023-10-28 11:03:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 11:03:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 11:03:49 --> Model Class Initialized
INFO - 2023-10-28 11:03:49 --> Model Class Initialized
DEBUG - 2023-10-28 11:03:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 11:03:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 11:03:49 --> Model Class Initialized
DEBUG - 2023-10-28 11:03:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 11:03:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gst/list.php
DEBUG - 2023-10-28 11:03:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 11:03:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 11:03:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 11:03:49 --> Model Class Initialized
INFO - 2023-10-28 11:03:49 --> Model Class Initialized
INFO - 2023-10-28 11:03:49 --> Model Class Initialized
INFO - 2023-10-28 11:03:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 11:03:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 11:03:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 11:03:49 --> Final output sent to browser
DEBUG - 2023-10-28 11:03:49 --> Total execution time: 0.1663
ERROR - 2023-10-28 11:03:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 11:03:59 --> Config Class Initialized
INFO - 2023-10-28 11:03:59 --> Hooks Class Initialized
DEBUG - 2023-10-28 11:03:59 --> UTF-8 Support Enabled
INFO - 2023-10-28 11:03:59 --> Utf8 Class Initialized
INFO - 2023-10-28 11:03:59 --> URI Class Initialized
DEBUG - 2023-10-28 11:03:59 --> No URI present. Default controller set.
INFO - 2023-10-28 11:03:59 --> Router Class Initialized
INFO - 2023-10-28 11:03:59 --> Output Class Initialized
INFO - 2023-10-28 11:03:59 --> Security Class Initialized
DEBUG - 2023-10-28 11:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 11:03:59 --> Input Class Initialized
INFO - 2023-10-28 11:03:59 --> Language Class Initialized
INFO - 2023-10-28 11:03:59 --> Loader Class Initialized
INFO - 2023-10-28 11:03:59 --> Helper loaded: url_helper
INFO - 2023-10-28 11:03:59 --> Helper loaded: file_helper
INFO - 2023-10-28 11:03:59 --> Helper loaded: html_helper
INFO - 2023-10-28 11:03:59 --> Helper loaded: text_helper
INFO - 2023-10-28 11:03:59 --> Helper loaded: form_helper
INFO - 2023-10-28 11:03:59 --> Helper loaded: lang_helper
INFO - 2023-10-28 11:03:59 --> Helper loaded: security_helper
INFO - 2023-10-28 11:03:59 --> Helper loaded: cookie_helper
INFO - 2023-10-28 11:03:59 --> Database Driver Class Initialized
INFO - 2023-10-28 11:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 11:03:59 --> Parser Class Initialized
INFO - 2023-10-28 11:03:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 11:03:59 --> Pagination Class Initialized
INFO - 2023-10-28 11:03:59 --> Form Validation Class Initialized
INFO - 2023-10-28 11:03:59 --> Controller Class Initialized
INFO - 2023-10-28 11:03:59 --> Model Class Initialized
DEBUG - 2023-10-28 11:03:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 11:03:59 --> Model Class Initialized
DEBUG - 2023-10-28 11:03:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 11:03:59 --> Model Class Initialized
INFO - 2023-10-28 11:03:59 --> Model Class Initialized
INFO - 2023-10-28 11:03:59 --> Model Class Initialized
INFO - 2023-10-28 11:03:59 --> Model Class Initialized
DEBUG - 2023-10-28 11:03:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 11:03:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 11:03:59 --> Model Class Initialized
INFO - 2023-10-28 11:03:59 --> Model Class Initialized
INFO - 2023-10-28 11:03:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-28 11:03:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 11:03:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 11:03:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 11:03:59 --> Model Class Initialized
INFO - 2023-10-28 11:03:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 11:03:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 11:03:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 11:03:59 --> Final output sent to browser
DEBUG - 2023-10-28 11:03:59 --> Total execution time: 0.2008
ERROR - 2023-10-28 11:04:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 11:04:06 --> Config Class Initialized
INFO - 2023-10-28 11:04:06 --> Hooks Class Initialized
DEBUG - 2023-10-28 11:04:06 --> UTF-8 Support Enabled
INFO - 2023-10-28 11:04:06 --> Utf8 Class Initialized
INFO - 2023-10-28 11:04:06 --> URI Class Initialized
INFO - 2023-10-28 11:04:06 --> Router Class Initialized
INFO - 2023-10-28 11:04:06 --> Output Class Initialized
INFO - 2023-10-28 11:04:06 --> Security Class Initialized
DEBUG - 2023-10-28 11:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 11:04:06 --> Input Class Initialized
INFO - 2023-10-28 11:04:06 --> Language Class Initialized
INFO - 2023-10-28 11:04:06 --> Loader Class Initialized
INFO - 2023-10-28 11:04:06 --> Helper loaded: url_helper
INFO - 2023-10-28 11:04:06 --> Helper loaded: file_helper
INFO - 2023-10-28 11:04:06 --> Helper loaded: html_helper
INFO - 2023-10-28 11:04:06 --> Helper loaded: text_helper
INFO - 2023-10-28 11:04:06 --> Helper loaded: form_helper
INFO - 2023-10-28 11:04:06 --> Helper loaded: lang_helper
INFO - 2023-10-28 11:04:06 --> Helper loaded: security_helper
INFO - 2023-10-28 11:04:06 --> Helper loaded: cookie_helper
INFO - 2023-10-28 11:04:06 --> Database Driver Class Initialized
INFO - 2023-10-28 11:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 11:04:06 --> Parser Class Initialized
INFO - 2023-10-28 11:04:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 11:04:06 --> Pagination Class Initialized
INFO - 2023-10-28 11:04:06 --> Form Validation Class Initialized
INFO - 2023-10-28 11:04:06 --> Controller Class Initialized
INFO - 2023-10-28 11:04:06 --> Model Class Initialized
DEBUG - 2023-10-28 11:04:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 11:04:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 11:04:06 --> Model Class Initialized
DEBUG - 2023-10-28 11:04:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 11:04:06 --> Model Class Initialized
INFO - 2023-10-28 11:04:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-28 11:04:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 11:04:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 11:04:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 11:04:06 --> Model Class Initialized
INFO - 2023-10-28 11:04:06 --> Model Class Initialized
INFO - 2023-10-28 11:04:06 --> Model Class Initialized
INFO - 2023-10-28 11:04:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 11:04:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 11:04:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 11:04:06 --> Final output sent to browser
DEBUG - 2023-10-28 11:04:06 --> Total execution time: 0.1333
ERROR - 2023-10-28 11:04:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 11:04:07 --> Config Class Initialized
INFO - 2023-10-28 11:04:07 --> Hooks Class Initialized
DEBUG - 2023-10-28 11:04:07 --> UTF-8 Support Enabled
INFO - 2023-10-28 11:04:07 --> Utf8 Class Initialized
INFO - 2023-10-28 11:04:07 --> URI Class Initialized
INFO - 2023-10-28 11:04:07 --> Router Class Initialized
INFO - 2023-10-28 11:04:07 --> Output Class Initialized
INFO - 2023-10-28 11:04:07 --> Security Class Initialized
DEBUG - 2023-10-28 11:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 11:04:07 --> Input Class Initialized
INFO - 2023-10-28 11:04:07 --> Language Class Initialized
INFO - 2023-10-28 11:04:07 --> Loader Class Initialized
INFO - 2023-10-28 11:04:07 --> Helper loaded: url_helper
INFO - 2023-10-28 11:04:07 --> Helper loaded: file_helper
INFO - 2023-10-28 11:04:07 --> Helper loaded: html_helper
INFO - 2023-10-28 11:04:07 --> Helper loaded: text_helper
INFO - 2023-10-28 11:04:07 --> Helper loaded: form_helper
INFO - 2023-10-28 11:04:07 --> Helper loaded: lang_helper
INFO - 2023-10-28 11:04:07 --> Helper loaded: security_helper
INFO - 2023-10-28 11:04:07 --> Helper loaded: cookie_helper
INFO - 2023-10-28 11:04:07 --> Database Driver Class Initialized
INFO - 2023-10-28 11:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 11:04:07 --> Parser Class Initialized
INFO - 2023-10-28 11:04:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 11:04:07 --> Pagination Class Initialized
INFO - 2023-10-28 11:04:07 --> Form Validation Class Initialized
INFO - 2023-10-28 11:04:07 --> Controller Class Initialized
INFO - 2023-10-28 11:04:07 --> Model Class Initialized
DEBUG - 2023-10-28 11:04:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 11:04:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 11:04:07 --> Model Class Initialized
DEBUG - 2023-10-28 11:04:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 11:04:07 --> Model Class Initialized
INFO - 2023-10-28 11:04:07 --> Final output sent to browser
DEBUG - 2023-10-28 11:04:07 --> Total execution time: 0.0378
ERROR - 2023-10-28 11:04:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 11:04:13 --> Config Class Initialized
INFO - 2023-10-28 11:04:13 --> Hooks Class Initialized
DEBUG - 2023-10-28 11:04:13 --> UTF-8 Support Enabled
INFO - 2023-10-28 11:04:13 --> Utf8 Class Initialized
INFO - 2023-10-28 11:04:13 --> URI Class Initialized
INFO - 2023-10-28 11:04:13 --> Router Class Initialized
INFO - 2023-10-28 11:04:13 --> Output Class Initialized
INFO - 2023-10-28 11:04:13 --> Security Class Initialized
DEBUG - 2023-10-28 11:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 11:04:13 --> Input Class Initialized
INFO - 2023-10-28 11:04:13 --> Language Class Initialized
INFO - 2023-10-28 11:04:13 --> Loader Class Initialized
INFO - 2023-10-28 11:04:13 --> Helper loaded: url_helper
INFO - 2023-10-28 11:04:13 --> Helper loaded: file_helper
INFO - 2023-10-28 11:04:13 --> Helper loaded: html_helper
INFO - 2023-10-28 11:04:13 --> Helper loaded: text_helper
INFO - 2023-10-28 11:04:13 --> Helper loaded: form_helper
INFO - 2023-10-28 11:04:13 --> Helper loaded: lang_helper
INFO - 2023-10-28 11:04:13 --> Helper loaded: security_helper
INFO - 2023-10-28 11:04:13 --> Helper loaded: cookie_helper
INFO - 2023-10-28 11:04:13 --> Database Driver Class Initialized
INFO - 2023-10-28 11:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 11:04:13 --> Parser Class Initialized
INFO - 2023-10-28 11:04:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 11:04:13 --> Pagination Class Initialized
INFO - 2023-10-28 11:04:13 --> Form Validation Class Initialized
INFO - 2023-10-28 11:04:13 --> Controller Class Initialized
INFO - 2023-10-28 11:04:13 --> Model Class Initialized
DEBUG - 2023-10-28 11:04:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 11:04:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 11:04:13 --> Model Class Initialized
DEBUG - 2023-10-28 11:04:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 11:04:13 --> Model Class Initialized
INFO - 2023-10-28 11:04:13 --> Final output sent to browser
DEBUG - 2023-10-28 11:04:13 --> Total execution time: 0.0568
ERROR - 2023-10-28 11:04:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 11:04:29 --> Config Class Initialized
INFO - 2023-10-28 11:04:29 --> Hooks Class Initialized
DEBUG - 2023-10-28 11:04:29 --> UTF-8 Support Enabled
INFO - 2023-10-28 11:04:29 --> Utf8 Class Initialized
INFO - 2023-10-28 11:04:29 --> URI Class Initialized
DEBUG - 2023-10-28 11:04:29 --> No URI present. Default controller set.
INFO - 2023-10-28 11:04:29 --> Router Class Initialized
INFO - 2023-10-28 11:04:29 --> Output Class Initialized
INFO - 2023-10-28 11:04:29 --> Security Class Initialized
DEBUG - 2023-10-28 11:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 11:04:29 --> Input Class Initialized
INFO - 2023-10-28 11:04:29 --> Language Class Initialized
INFO - 2023-10-28 11:04:29 --> Loader Class Initialized
INFO - 2023-10-28 11:04:29 --> Helper loaded: url_helper
INFO - 2023-10-28 11:04:29 --> Helper loaded: file_helper
INFO - 2023-10-28 11:04:29 --> Helper loaded: html_helper
INFO - 2023-10-28 11:04:29 --> Helper loaded: text_helper
INFO - 2023-10-28 11:04:29 --> Helper loaded: form_helper
INFO - 2023-10-28 11:04:29 --> Helper loaded: lang_helper
INFO - 2023-10-28 11:04:29 --> Helper loaded: security_helper
INFO - 2023-10-28 11:04:29 --> Helper loaded: cookie_helper
INFO - 2023-10-28 11:04:29 --> Database Driver Class Initialized
INFO - 2023-10-28 11:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 11:04:29 --> Parser Class Initialized
INFO - 2023-10-28 11:04:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 11:04:29 --> Pagination Class Initialized
INFO - 2023-10-28 11:04:29 --> Form Validation Class Initialized
INFO - 2023-10-28 11:04:29 --> Controller Class Initialized
INFO - 2023-10-28 11:04:29 --> Model Class Initialized
DEBUG - 2023-10-28 11:04:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 11:04:29 --> Model Class Initialized
DEBUG - 2023-10-28 11:04:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 11:04:29 --> Model Class Initialized
INFO - 2023-10-28 11:04:29 --> Model Class Initialized
INFO - 2023-10-28 11:04:29 --> Model Class Initialized
INFO - 2023-10-28 11:04:29 --> Model Class Initialized
DEBUG - 2023-10-28 11:04:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 11:04:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 11:04:29 --> Model Class Initialized
INFO - 2023-10-28 11:04:29 --> Model Class Initialized
INFO - 2023-10-28 11:04:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-28 11:04:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 11:04:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 11:04:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 11:04:30 --> Model Class Initialized
INFO - 2023-10-28 11:04:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 11:04:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 11:04:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 11:04:30 --> Final output sent to browser
DEBUG - 2023-10-28 11:04:30 --> Total execution time: 0.1943
ERROR - 2023-10-28 11:04:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 11:04:37 --> Config Class Initialized
INFO - 2023-10-28 11:04:37 --> Hooks Class Initialized
DEBUG - 2023-10-28 11:04:37 --> UTF-8 Support Enabled
INFO - 2023-10-28 11:04:37 --> Utf8 Class Initialized
INFO - 2023-10-28 11:04:37 --> URI Class Initialized
DEBUG - 2023-10-28 11:04:37 --> No URI present. Default controller set.
INFO - 2023-10-28 11:04:37 --> Router Class Initialized
INFO - 2023-10-28 11:04:37 --> Output Class Initialized
INFO - 2023-10-28 11:04:37 --> Security Class Initialized
DEBUG - 2023-10-28 11:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 11:04:37 --> Input Class Initialized
INFO - 2023-10-28 11:04:37 --> Language Class Initialized
INFO - 2023-10-28 11:04:37 --> Loader Class Initialized
INFO - 2023-10-28 11:04:37 --> Helper loaded: url_helper
INFO - 2023-10-28 11:04:37 --> Helper loaded: file_helper
INFO - 2023-10-28 11:04:37 --> Helper loaded: html_helper
INFO - 2023-10-28 11:04:37 --> Helper loaded: text_helper
INFO - 2023-10-28 11:04:37 --> Helper loaded: form_helper
INFO - 2023-10-28 11:04:37 --> Helper loaded: lang_helper
INFO - 2023-10-28 11:04:37 --> Helper loaded: security_helper
INFO - 2023-10-28 11:04:37 --> Helper loaded: cookie_helper
INFO - 2023-10-28 11:04:37 --> Database Driver Class Initialized
INFO - 2023-10-28 11:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 11:04:37 --> Parser Class Initialized
INFO - 2023-10-28 11:04:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 11:04:37 --> Pagination Class Initialized
INFO - 2023-10-28 11:04:37 --> Form Validation Class Initialized
INFO - 2023-10-28 11:04:37 --> Controller Class Initialized
INFO - 2023-10-28 11:04:37 --> Model Class Initialized
DEBUG - 2023-10-28 11:04:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 11:04:37 --> Model Class Initialized
DEBUG - 2023-10-28 11:04:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 11:04:37 --> Model Class Initialized
INFO - 2023-10-28 11:04:37 --> Model Class Initialized
INFO - 2023-10-28 11:04:37 --> Model Class Initialized
INFO - 2023-10-28 11:04:37 --> Model Class Initialized
DEBUG - 2023-10-28 11:04:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 11:04:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 11:04:37 --> Model Class Initialized
INFO - 2023-10-28 11:04:37 --> Model Class Initialized
INFO - 2023-10-28 11:04:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-28 11:04:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 11:04:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 11:04:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 11:04:37 --> Model Class Initialized
INFO - 2023-10-28 11:04:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 11:04:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 11:04:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 11:04:38 --> Final output sent to browser
DEBUG - 2023-10-28 11:04:38 --> Total execution time: 0.3501
ERROR - 2023-10-28 12:32:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:32:35 --> Config Class Initialized
INFO - 2023-10-28 12:32:35 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:32:35 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:32:35 --> Utf8 Class Initialized
INFO - 2023-10-28 12:32:35 --> URI Class Initialized
DEBUG - 2023-10-28 12:32:35 --> No URI present. Default controller set.
INFO - 2023-10-28 12:32:35 --> Router Class Initialized
INFO - 2023-10-28 12:32:35 --> Output Class Initialized
INFO - 2023-10-28 12:32:35 --> Security Class Initialized
DEBUG - 2023-10-28 12:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:32:35 --> Input Class Initialized
INFO - 2023-10-28 12:32:35 --> Language Class Initialized
INFO - 2023-10-28 12:32:35 --> Loader Class Initialized
INFO - 2023-10-28 12:32:35 --> Helper loaded: url_helper
INFO - 2023-10-28 12:32:35 --> Helper loaded: file_helper
INFO - 2023-10-28 12:32:35 --> Helper loaded: html_helper
INFO - 2023-10-28 12:32:35 --> Helper loaded: text_helper
INFO - 2023-10-28 12:32:35 --> Helper loaded: form_helper
INFO - 2023-10-28 12:32:35 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:32:35 --> Helper loaded: security_helper
INFO - 2023-10-28 12:32:35 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:32:35 --> Database Driver Class Initialized
INFO - 2023-10-28 12:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:32:35 --> Parser Class Initialized
INFO - 2023-10-28 12:32:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:32:35 --> Pagination Class Initialized
INFO - 2023-10-28 12:32:35 --> Form Validation Class Initialized
INFO - 2023-10-28 12:32:35 --> Controller Class Initialized
INFO - 2023-10-28 12:32:35 --> Model Class Initialized
DEBUG - 2023-10-28 12:32:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:32:35 --> Model Class Initialized
DEBUG - 2023-10-28 12:32:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:32:35 --> Model Class Initialized
INFO - 2023-10-28 12:32:35 --> Model Class Initialized
INFO - 2023-10-28 12:32:35 --> Model Class Initialized
INFO - 2023-10-28 12:32:35 --> Model Class Initialized
DEBUG - 2023-10-28 12:32:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:32:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:32:35 --> Model Class Initialized
INFO - 2023-10-28 12:32:35 --> Model Class Initialized
INFO - 2023-10-28 12:32:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-28 12:32:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:32:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 12:32:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 12:32:35 --> Model Class Initialized
INFO - 2023-10-28 12:32:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 12:32:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 12:32:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 12:32:35 --> Final output sent to browser
DEBUG - 2023-10-28 12:32:35 --> Total execution time: 0.2056
ERROR - 2023-10-28 12:32:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:32:42 --> Config Class Initialized
INFO - 2023-10-28 12:32:42 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:32:42 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:32:42 --> Utf8 Class Initialized
INFO - 2023-10-28 12:32:42 --> URI Class Initialized
INFO - 2023-10-28 12:32:42 --> Router Class Initialized
INFO - 2023-10-28 12:32:42 --> Output Class Initialized
INFO - 2023-10-28 12:32:42 --> Security Class Initialized
DEBUG - 2023-10-28 12:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:32:42 --> Input Class Initialized
INFO - 2023-10-28 12:32:42 --> Language Class Initialized
INFO - 2023-10-28 12:32:42 --> Loader Class Initialized
INFO - 2023-10-28 12:32:42 --> Helper loaded: url_helper
INFO - 2023-10-28 12:32:42 --> Helper loaded: file_helper
INFO - 2023-10-28 12:32:42 --> Helper loaded: html_helper
INFO - 2023-10-28 12:32:42 --> Helper loaded: text_helper
INFO - 2023-10-28 12:32:42 --> Helper loaded: form_helper
INFO - 2023-10-28 12:32:42 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:32:42 --> Helper loaded: security_helper
INFO - 2023-10-28 12:32:42 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:32:42 --> Database Driver Class Initialized
INFO - 2023-10-28 12:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:32:42 --> Parser Class Initialized
INFO - 2023-10-28 12:32:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:32:42 --> Pagination Class Initialized
INFO - 2023-10-28 12:32:42 --> Form Validation Class Initialized
INFO - 2023-10-28 12:32:42 --> Controller Class Initialized
INFO - 2023-10-28 12:32:42 --> Model Class Initialized
DEBUG - 2023-10-28 12:32:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:32:42 --> Final output sent to browser
DEBUG - 2023-10-28 12:32:42 --> Total execution time: 0.0134
ERROR - 2023-10-28 12:32:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:32:42 --> Config Class Initialized
INFO - 2023-10-28 12:32:42 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:32:42 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:32:42 --> Utf8 Class Initialized
INFO - 2023-10-28 12:32:42 --> URI Class Initialized
INFO - 2023-10-28 12:32:42 --> Router Class Initialized
INFO - 2023-10-28 12:32:42 --> Output Class Initialized
INFO - 2023-10-28 12:32:42 --> Security Class Initialized
DEBUG - 2023-10-28 12:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:32:42 --> Input Class Initialized
INFO - 2023-10-28 12:32:42 --> Language Class Initialized
INFO - 2023-10-28 12:32:42 --> Loader Class Initialized
INFO - 2023-10-28 12:32:42 --> Helper loaded: url_helper
INFO - 2023-10-28 12:32:42 --> Helper loaded: file_helper
INFO - 2023-10-28 12:32:42 --> Helper loaded: html_helper
INFO - 2023-10-28 12:32:42 --> Helper loaded: text_helper
INFO - 2023-10-28 12:32:42 --> Helper loaded: form_helper
INFO - 2023-10-28 12:32:42 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:32:42 --> Helper loaded: security_helper
INFO - 2023-10-28 12:32:42 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:32:42 --> Database Driver Class Initialized
INFO - 2023-10-28 12:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:32:42 --> Parser Class Initialized
INFO - 2023-10-28 12:32:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:32:42 --> Pagination Class Initialized
INFO - 2023-10-28 12:32:42 --> Form Validation Class Initialized
INFO - 2023-10-28 12:32:42 --> Controller Class Initialized
INFO - 2023-10-28 12:32:42 --> Model Class Initialized
DEBUG - 2023-10-28 12:32:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:32:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-28 12:32:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:32:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 12:32:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 12:32:42 --> Model Class Initialized
INFO - 2023-10-28 12:32:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 12:32:42 --> Final output sent to browser
DEBUG - 2023-10-28 12:32:42 --> Total execution time: 0.0292
ERROR - 2023-10-28 12:33:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:33:18 --> Config Class Initialized
INFO - 2023-10-28 12:33:18 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:33:18 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:33:18 --> Utf8 Class Initialized
INFO - 2023-10-28 12:33:18 --> URI Class Initialized
DEBUG - 2023-10-28 12:33:18 --> No URI present. Default controller set.
INFO - 2023-10-28 12:33:18 --> Router Class Initialized
INFO - 2023-10-28 12:33:18 --> Output Class Initialized
INFO - 2023-10-28 12:33:18 --> Security Class Initialized
DEBUG - 2023-10-28 12:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:33:18 --> Input Class Initialized
INFO - 2023-10-28 12:33:18 --> Language Class Initialized
INFO - 2023-10-28 12:33:18 --> Loader Class Initialized
INFO - 2023-10-28 12:33:18 --> Helper loaded: url_helper
INFO - 2023-10-28 12:33:18 --> Helper loaded: file_helper
INFO - 2023-10-28 12:33:18 --> Helper loaded: html_helper
INFO - 2023-10-28 12:33:18 --> Helper loaded: text_helper
INFO - 2023-10-28 12:33:18 --> Helper loaded: form_helper
INFO - 2023-10-28 12:33:18 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:33:18 --> Helper loaded: security_helper
INFO - 2023-10-28 12:33:18 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:33:18 --> Database Driver Class Initialized
INFO - 2023-10-28 12:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:33:18 --> Parser Class Initialized
INFO - 2023-10-28 12:33:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:33:18 --> Pagination Class Initialized
INFO - 2023-10-28 12:33:18 --> Form Validation Class Initialized
INFO - 2023-10-28 12:33:18 --> Controller Class Initialized
INFO - 2023-10-28 12:33:18 --> Model Class Initialized
DEBUG - 2023-10-28 12:33:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:33:18 --> Model Class Initialized
DEBUG - 2023-10-28 12:33:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:33:18 --> Model Class Initialized
INFO - 2023-10-28 12:33:18 --> Model Class Initialized
INFO - 2023-10-28 12:33:18 --> Model Class Initialized
INFO - 2023-10-28 12:33:18 --> Model Class Initialized
DEBUG - 2023-10-28 12:33:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:33:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:33:18 --> Model Class Initialized
INFO - 2023-10-28 12:33:18 --> Model Class Initialized
INFO - 2023-10-28 12:33:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-28 12:33:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:33:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 12:33:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 12:33:18 --> Model Class Initialized
INFO - 2023-10-28 12:33:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 12:33:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 12:33:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 12:33:18 --> Final output sent to browser
DEBUG - 2023-10-28 12:33:18 --> Total execution time: 0.3825
ERROR - 2023-10-28 12:33:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:33:24 --> Config Class Initialized
INFO - 2023-10-28 12:33:24 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:33:24 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:33:24 --> Utf8 Class Initialized
INFO - 2023-10-28 12:33:24 --> URI Class Initialized
INFO - 2023-10-28 12:33:24 --> Router Class Initialized
INFO - 2023-10-28 12:33:24 --> Output Class Initialized
INFO - 2023-10-28 12:33:24 --> Security Class Initialized
DEBUG - 2023-10-28 12:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:33:24 --> Input Class Initialized
INFO - 2023-10-28 12:33:24 --> Language Class Initialized
INFO - 2023-10-28 12:33:24 --> Loader Class Initialized
INFO - 2023-10-28 12:33:24 --> Helper loaded: url_helper
INFO - 2023-10-28 12:33:24 --> Helper loaded: file_helper
INFO - 2023-10-28 12:33:24 --> Helper loaded: html_helper
INFO - 2023-10-28 12:33:24 --> Helper loaded: text_helper
INFO - 2023-10-28 12:33:24 --> Helper loaded: form_helper
INFO - 2023-10-28 12:33:24 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:33:24 --> Helper loaded: security_helper
INFO - 2023-10-28 12:33:24 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:33:24 --> Database Driver Class Initialized
INFO - 2023-10-28 12:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:33:24 --> Parser Class Initialized
INFO - 2023-10-28 12:33:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:33:24 --> Pagination Class Initialized
INFO - 2023-10-28 12:33:24 --> Form Validation Class Initialized
INFO - 2023-10-28 12:33:24 --> Controller Class Initialized
INFO - 2023-10-28 12:33:24 --> Model Class Initialized
DEBUG - 2023-10-28 12:33:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:33:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:33:24 --> Model Class Initialized
DEBUG - 2023-10-28 12:33:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:33:24 --> Model Class Initialized
INFO - 2023-10-28 12:33:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-28 12:33:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:33:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 12:33:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 12:33:24 --> Model Class Initialized
INFO - 2023-10-28 12:33:24 --> Model Class Initialized
INFO - 2023-10-28 12:33:24 --> Model Class Initialized
INFO - 2023-10-28 12:33:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 12:33:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 12:33:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 12:33:24 --> Final output sent to browser
DEBUG - 2023-10-28 12:33:24 --> Total execution time: 0.2049
ERROR - 2023-10-28 12:33:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:33:25 --> Config Class Initialized
INFO - 2023-10-28 12:33:25 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:33:25 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:33:25 --> Utf8 Class Initialized
INFO - 2023-10-28 12:33:25 --> URI Class Initialized
INFO - 2023-10-28 12:33:25 --> Router Class Initialized
INFO - 2023-10-28 12:33:25 --> Output Class Initialized
INFO - 2023-10-28 12:33:25 --> Security Class Initialized
DEBUG - 2023-10-28 12:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:33:25 --> Input Class Initialized
INFO - 2023-10-28 12:33:25 --> Language Class Initialized
INFO - 2023-10-28 12:33:25 --> Loader Class Initialized
INFO - 2023-10-28 12:33:25 --> Helper loaded: url_helper
INFO - 2023-10-28 12:33:25 --> Helper loaded: file_helper
INFO - 2023-10-28 12:33:25 --> Helper loaded: html_helper
INFO - 2023-10-28 12:33:25 --> Helper loaded: text_helper
INFO - 2023-10-28 12:33:25 --> Helper loaded: form_helper
INFO - 2023-10-28 12:33:25 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:33:25 --> Helper loaded: security_helper
INFO - 2023-10-28 12:33:25 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:33:25 --> Database Driver Class Initialized
INFO - 2023-10-28 12:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:33:25 --> Parser Class Initialized
INFO - 2023-10-28 12:33:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:33:25 --> Pagination Class Initialized
INFO - 2023-10-28 12:33:25 --> Form Validation Class Initialized
INFO - 2023-10-28 12:33:25 --> Controller Class Initialized
INFO - 2023-10-28 12:33:25 --> Model Class Initialized
DEBUG - 2023-10-28 12:33:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:33:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:33:25 --> Model Class Initialized
DEBUG - 2023-10-28 12:33:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:33:25 --> Model Class Initialized
INFO - 2023-10-28 12:33:25 --> Final output sent to browser
DEBUG - 2023-10-28 12:33:25 --> Total execution time: 0.0860
ERROR - 2023-10-28 12:33:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:33:28 --> Config Class Initialized
INFO - 2023-10-28 12:33:28 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:33:28 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:33:28 --> Utf8 Class Initialized
INFO - 2023-10-28 12:33:28 --> URI Class Initialized
INFO - 2023-10-28 12:33:28 --> Router Class Initialized
INFO - 2023-10-28 12:33:28 --> Output Class Initialized
INFO - 2023-10-28 12:33:28 --> Security Class Initialized
DEBUG - 2023-10-28 12:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:33:28 --> Input Class Initialized
INFO - 2023-10-28 12:33:28 --> Language Class Initialized
INFO - 2023-10-28 12:33:28 --> Loader Class Initialized
INFO - 2023-10-28 12:33:28 --> Helper loaded: url_helper
INFO - 2023-10-28 12:33:28 --> Helper loaded: file_helper
INFO - 2023-10-28 12:33:28 --> Helper loaded: html_helper
INFO - 2023-10-28 12:33:28 --> Helper loaded: text_helper
INFO - 2023-10-28 12:33:28 --> Helper loaded: form_helper
INFO - 2023-10-28 12:33:28 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:33:28 --> Helper loaded: security_helper
INFO - 2023-10-28 12:33:28 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:33:28 --> Database Driver Class Initialized
INFO - 2023-10-28 12:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:33:28 --> Parser Class Initialized
INFO - 2023-10-28 12:33:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:33:28 --> Pagination Class Initialized
INFO - 2023-10-28 12:33:28 --> Form Validation Class Initialized
INFO - 2023-10-28 12:33:28 --> Controller Class Initialized
INFO - 2023-10-28 12:33:28 --> Model Class Initialized
DEBUG - 2023-10-28 12:33:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:33:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:33:28 --> Model Class Initialized
DEBUG - 2023-10-28 12:33:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:33:28 --> Model Class Initialized
INFO - 2023-10-28 12:33:29 --> Final output sent to browser
DEBUG - 2023-10-28 12:33:29 --> Total execution time: 0.9247
ERROR - 2023-10-28 12:33:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:33:39 --> Config Class Initialized
INFO - 2023-10-28 12:33:39 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:33:39 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:33:39 --> Utf8 Class Initialized
INFO - 2023-10-28 12:33:39 --> URI Class Initialized
INFO - 2023-10-28 12:33:39 --> Router Class Initialized
INFO - 2023-10-28 12:33:39 --> Output Class Initialized
INFO - 2023-10-28 12:33:39 --> Security Class Initialized
DEBUG - 2023-10-28 12:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:33:39 --> Input Class Initialized
INFO - 2023-10-28 12:33:39 --> Language Class Initialized
INFO - 2023-10-28 12:33:39 --> Loader Class Initialized
INFO - 2023-10-28 12:33:39 --> Helper loaded: url_helper
INFO - 2023-10-28 12:33:39 --> Helper loaded: file_helper
INFO - 2023-10-28 12:33:39 --> Helper loaded: html_helper
INFO - 2023-10-28 12:33:39 --> Helper loaded: text_helper
INFO - 2023-10-28 12:33:39 --> Helper loaded: form_helper
INFO - 2023-10-28 12:33:39 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:33:39 --> Helper loaded: security_helper
INFO - 2023-10-28 12:33:39 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:33:39 --> Database Driver Class Initialized
INFO - 2023-10-28 12:33:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:33:39 --> Parser Class Initialized
INFO - 2023-10-28 12:33:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:33:39 --> Pagination Class Initialized
INFO - 2023-10-28 12:33:39 --> Form Validation Class Initialized
INFO - 2023-10-28 12:33:39 --> Controller Class Initialized
INFO - 2023-10-28 12:33:39 --> Model Class Initialized
DEBUG - 2023-10-28 12:33:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:33:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:33:39 --> Model Class Initialized
DEBUG - 2023-10-28 12:33:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:33:39 --> Model Class Initialized
ERROR - 2023-10-28 12:33:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:33:40 --> Config Class Initialized
INFO - 2023-10-28 12:33:40 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:33:40 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:33:40 --> Utf8 Class Initialized
INFO - 2023-10-28 12:33:40 --> URI Class Initialized
INFO - 2023-10-28 12:33:40 --> Router Class Initialized
INFO - 2023-10-28 12:33:40 --> Output Class Initialized
INFO - 2023-10-28 12:33:40 --> Security Class Initialized
DEBUG - 2023-10-28 12:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:33:40 --> Input Class Initialized
INFO - 2023-10-28 12:33:40 --> Language Class Initialized
INFO - 2023-10-28 12:33:40 --> Loader Class Initialized
INFO - 2023-10-28 12:33:40 --> Helper loaded: url_helper
INFO - 2023-10-28 12:33:40 --> Helper loaded: file_helper
INFO - 2023-10-28 12:33:40 --> Helper loaded: html_helper
INFO - 2023-10-28 12:33:40 --> Helper loaded: text_helper
INFO - 2023-10-28 12:33:40 --> Helper loaded: form_helper
INFO - 2023-10-28 12:33:40 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:33:40 --> Helper loaded: security_helper
INFO - 2023-10-28 12:33:40 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:33:40 --> Database Driver Class Initialized
INFO - 2023-10-28 12:33:40 --> Final output sent to browser
DEBUG - 2023-10-28 12:33:40 --> Total execution time: 0.7610
INFO - 2023-10-28 12:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:33:40 --> Parser Class Initialized
INFO - 2023-10-28 12:33:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:33:40 --> Pagination Class Initialized
INFO - 2023-10-28 12:33:40 --> Form Validation Class Initialized
INFO - 2023-10-28 12:33:40 --> Controller Class Initialized
INFO - 2023-10-28 12:33:40 --> Model Class Initialized
DEBUG - 2023-10-28 12:33:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:33:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:33:40 --> Model Class Initialized
DEBUG - 2023-10-28 12:33:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:33:40 --> Model Class Initialized
INFO - 2023-10-28 12:33:40 --> Final output sent to browser
DEBUG - 2023-10-28 12:33:40 --> Total execution time: 0.2051
ERROR - 2023-10-28 12:33:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:33:40 --> Config Class Initialized
INFO - 2023-10-28 12:33:40 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:33:40 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:33:40 --> Utf8 Class Initialized
INFO - 2023-10-28 12:33:40 --> URI Class Initialized
INFO - 2023-10-28 12:33:40 --> Router Class Initialized
INFO - 2023-10-28 12:33:40 --> Output Class Initialized
INFO - 2023-10-28 12:33:40 --> Security Class Initialized
DEBUG - 2023-10-28 12:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:33:40 --> Input Class Initialized
INFO - 2023-10-28 12:33:40 --> Language Class Initialized
INFO - 2023-10-28 12:33:40 --> Loader Class Initialized
INFO - 2023-10-28 12:33:40 --> Helper loaded: url_helper
INFO - 2023-10-28 12:33:40 --> Helper loaded: file_helper
INFO - 2023-10-28 12:33:40 --> Helper loaded: html_helper
INFO - 2023-10-28 12:33:40 --> Helper loaded: text_helper
INFO - 2023-10-28 12:33:40 --> Helper loaded: form_helper
INFO - 2023-10-28 12:33:40 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:33:40 --> Helper loaded: security_helper
INFO - 2023-10-28 12:33:40 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:33:40 --> Database Driver Class Initialized
INFO - 2023-10-28 12:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:33:40 --> Parser Class Initialized
INFO - 2023-10-28 12:33:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:33:40 --> Pagination Class Initialized
INFO - 2023-10-28 12:33:40 --> Form Validation Class Initialized
INFO - 2023-10-28 12:33:40 --> Controller Class Initialized
INFO - 2023-10-28 12:33:40 --> Model Class Initialized
DEBUG - 2023-10-28 12:33:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:33:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:33:40 --> Model Class Initialized
DEBUG - 2023-10-28 12:33:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:33:40 --> Model Class Initialized
INFO - 2023-10-28 12:33:40 --> Final output sent to browser
DEBUG - 2023-10-28 12:33:40 --> Total execution time: 0.0491
ERROR - 2023-10-28 12:33:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:33:41 --> Config Class Initialized
INFO - 2023-10-28 12:33:41 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:33:41 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:33:41 --> Utf8 Class Initialized
INFO - 2023-10-28 12:33:41 --> URI Class Initialized
INFO - 2023-10-28 12:33:41 --> Router Class Initialized
INFO - 2023-10-28 12:33:41 --> Output Class Initialized
INFO - 2023-10-28 12:33:41 --> Security Class Initialized
DEBUG - 2023-10-28 12:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:33:41 --> Input Class Initialized
INFO - 2023-10-28 12:33:41 --> Language Class Initialized
INFO - 2023-10-28 12:33:41 --> Loader Class Initialized
INFO - 2023-10-28 12:33:41 --> Helper loaded: url_helper
INFO - 2023-10-28 12:33:41 --> Helper loaded: file_helper
INFO - 2023-10-28 12:33:41 --> Helper loaded: html_helper
INFO - 2023-10-28 12:33:41 --> Helper loaded: text_helper
INFO - 2023-10-28 12:33:41 --> Helper loaded: form_helper
INFO - 2023-10-28 12:33:41 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:33:41 --> Helper loaded: security_helper
INFO - 2023-10-28 12:33:41 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:33:41 --> Database Driver Class Initialized
INFO - 2023-10-28 12:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:33:41 --> Parser Class Initialized
INFO - 2023-10-28 12:33:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:33:41 --> Pagination Class Initialized
INFO - 2023-10-28 12:33:41 --> Form Validation Class Initialized
INFO - 2023-10-28 12:33:41 --> Controller Class Initialized
INFO - 2023-10-28 12:33:41 --> Model Class Initialized
DEBUG - 2023-10-28 12:33:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:33:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:33:41 --> Model Class Initialized
DEBUG - 2023-10-28 12:33:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:33:41 --> Model Class Initialized
INFO - 2023-10-28 12:33:41 --> Final output sent to browser
DEBUG - 2023-10-28 12:33:41 --> Total execution time: 0.0449
ERROR - 2023-10-28 12:33:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:33:42 --> Config Class Initialized
INFO - 2023-10-28 12:33:42 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:33:42 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:33:42 --> Utf8 Class Initialized
INFO - 2023-10-28 12:33:42 --> URI Class Initialized
INFO - 2023-10-28 12:33:42 --> Router Class Initialized
INFO - 2023-10-28 12:33:42 --> Output Class Initialized
INFO - 2023-10-28 12:33:42 --> Security Class Initialized
DEBUG - 2023-10-28 12:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:33:42 --> Input Class Initialized
INFO - 2023-10-28 12:33:42 --> Language Class Initialized
INFO - 2023-10-28 12:33:42 --> Loader Class Initialized
INFO - 2023-10-28 12:33:42 --> Helper loaded: url_helper
INFO - 2023-10-28 12:33:42 --> Helper loaded: file_helper
INFO - 2023-10-28 12:33:42 --> Helper loaded: html_helper
INFO - 2023-10-28 12:33:42 --> Helper loaded: text_helper
INFO - 2023-10-28 12:33:42 --> Helper loaded: form_helper
INFO - 2023-10-28 12:33:42 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:33:42 --> Helper loaded: security_helper
INFO - 2023-10-28 12:33:42 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:33:42 --> Database Driver Class Initialized
INFO - 2023-10-28 12:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:33:42 --> Parser Class Initialized
INFO - 2023-10-28 12:33:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:33:42 --> Pagination Class Initialized
INFO - 2023-10-28 12:33:42 --> Form Validation Class Initialized
INFO - 2023-10-28 12:33:42 --> Controller Class Initialized
INFO - 2023-10-28 12:33:42 --> Model Class Initialized
DEBUG - 2023-10-28 12:33:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:33:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:33:42 --> Model Class Initialized
DEBUG - 2023-10-28 12:33:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:33:42 --> Model Class Initialized
INFO - 2023-10-28 12:33:42 --> Final output sent to browser
DEBUG - 2023-10-28 12:33:42 --> Total execution time: 0.0258
ERROR - 2023-10-28 12:33:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:33:45 --> Config Class Initialized
INFO - 2023-10-28 12:33:45 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:33:45 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:33:45 --> Utf8 Class Initialized
INFO - 2023-10-28 12:33:45 --> URI Class Initialized
INFO - 2023-10-28 12:33:45 --> Router Class Initialized
INFO - 2023-10-28 12:33:45 --> Output Class Initialized
INFO - 2023-10-28 12:33:45 --> Security Class Initialized
DEBUG - 2023-10-28 12:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:33:45 --> Input Class Initialized
INFO - 2023-10-28 12:33:45 --> Language Class Initialized
INFO - 2023-10-28 12:33:45 --> Loader Class Initialized
INFO - 2023-10-28 12:33:45 --> Helper loaded: url_helper
INFO - 2023-10-28 12:33:45 --> Helper loaded: file_helper
INFO - 2023-10-28 12:33:45 --> Helper loaded: html_helper
INFO - 2023-10-28 12:33:45 --> Helper loaded: text_helper
INFO - 2023-10-28 12:33:45 --> Helper loaded: form_helper
INFO - 2023-10-28 12:33:45 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:33:45 --> Helper loaded: security_helper
INFO - 2023-10-28 12:33:45 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:33:45 --> Database Driver Class Initialized
INFO - 2023-10-28 12:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:33:45 --> Parser Class Initialized
INFO - 2023-10-28 12:33:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:33:45 --> Pagination Class Initialized
INFO - 2023-10-28 12:33:45 --> Form Validation Class Initialized
INFO - 2023-10-28 12:33:45 --> Controller Class Initialized
INFO - 2023-10-28 12:33:45 --> Model Class Initialized
DEBUG - 2023-10-28 12:33:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:33:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:33:45 --> Model Class Initialized
DEBUG - 2023-10-28 12:33:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:33:45 --> Model Class Initialized
DEBUG - 2023-10-28 12:33:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:33:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-10-28 12:33:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:33:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 12:33:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 12:33:45 --> Model Class Initialized
INFO - 2023-10-28 12:33:45 --> Model Class Initialized
INFO - 2023-10-28 12:33:45 --> Model Class Initialized
INFO - 2023-10-28 12:33:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 12:33:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 12:33:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 12:33:45 --> Final output sent to browser
DEBUG - 2023-10-28 12:33:45 --> Total execution time: 0.2083
ERROR - 2023-10-28 12:33:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:33:55 --> Config Class Initialized
INFO - 2023-10-28 12:33:55 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:33:55 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:33:55 --> Utf8 Class Initialized
INFO - 2023-10-28 12:33:55 --> URI Class Initialized
INFO - 2023-10-28 12:33:55 --> Router Class Initialized
INFO - 2023-10-28 12:33:55 --> Output Class Initialized
INFO - 2023-10-28 12:33:55 --> Security Class Initialized
DEBUG - 2023-10-28 12:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:33:55 --> Input Class Initialized
INFO - 2023-10-28 12:33:55 --> Language Class Initialized
INFO - 2023-10-28 12:33:55 --> Loader Class Initialized
INFO - 2023-10-28 12:33:55 --> Helper loaded: url_helper
INFO - 2023-10-28 12:33:55 --> Helper loaded: file_helper
INFO - 2023-10-28 12:33:55 --> Helper loaded: html_helper
INFO - 2023-10-28 12:33:55 --> Helper loaded: text_helper
INFO - 2023-10-28 12:33:55 --> Helper loaded: form_helper
INFO - 2023-10-28 12:33:55 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:33:55 --> Helper loaded: security_helper
INFO - 2023-10-28 12:33:55 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:33:55 --> Database Driver Class Initialized
INFO - 2023-10-28 12:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:33:55 --> Parser Class Initialized
INFO - 2023-10-28 12:33:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:33:55 --> Pagination Class Initialized
INFO - 2023-10-28 12:33:55 --> Form Validation Class Initialized
INFO - 2023-10-28 12:33:55 --> Controller Class Initialized
INFO - 2023-10-28 12:33:55 --> Model Class Initialized
DEBUG - 2023-10-28 12:33:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:33:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:33:55 --> Model Class Initialized
DEBUG - 2023-10-28 12:33:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:33:55 --> Model Class Initialized
INFO - 2023-10-28 12:33:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-10-28 12:33:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:33:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 12:33:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 12:33:55 --> Model Class Initialized
INFO - 2023-10-28 12:33:55 --> Model Class Initialized
INFO - 2023-10-28 12:33:55 --> Model Class Initialized
INFO - 2023-10-28 12:33:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 12:33:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 12:33:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 12:33:55 --> Final output sent to browser
DEBUG - 2023-10-28 12:33:55 --> Total execution time: 0.1868
ERROR - 2023-10-28 12:33:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:33:55 --> Config Class Initialized
INFO - 2023-10-28 12:33:55 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:33:55 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:33:55 --> Utf8 Class Initialized
INFO - 2023-10-28 12:33:55 --> URI Class Initialized
INFO - 2023-10-28 12:33:55 --> Router Class Initialized
INFO - 2023-10-28 12:33:55 --> Output Class Initialized
INFO - 2023-10-28 12:33:55 --> Security Class Initialized
DEBUG - 2023-10-28 12:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:33:55 --> Input Class Initialized
INFO - 2023-10-28 12:33:55 --> Language Class Initialized
INFO - 2023-10-28 12:33:55 --> Loader Class Initialized
INFO - 2023-10-28 12:33:55 --> Helper loaded: url_helper
INFO - 2023-10-28 12:33:55 --> Helper loaded: file_helper
INFO - 2023-10-28 12:33:55 --> Helper loaded: html_helper
INFO - 2023-10-28 12:33:55 --> Helper loaded: text_helper
INFO - 2023-10-28 12:33:55 --> Helper loaded: form_helper
INFO - 2023-10-28 12:33:55 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:33:55 --> Helper loaded: security_helper
INFO - 2023-10-28 12:33:55 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:33:55 --> Database Driver Class Initialized
INFO - 2023-10-28 12:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:33:55 --> Parser Class Initialized
INFO - 2023-10-28 12:33:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:33:55 --> Pagination Class Initialized
INFO - 2023-10-28 12:33:55 --> Form Validation Class Initialized
INFO - 2023-10-28 12:33:55 --> Controller Class Initialized
INFO - 2023-10-28 12:33:55 --> Model Class Initialized
DEBUG - 2023-10-28 12:33:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:33:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:33:55 --> Model Class Initialized
DEBUG - 2023-10-28 12:33:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:33:55 --> Model Class Initialized
INFO - 2023-10-28 12:33:56 --> Final output sent to browser
DEBUG - 2023-10-28 12:33:56 --> Total execution time: 0.0471
ERROR - 2023-10-28 12:34:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:34:03 --> Config Class Initialized
INFO - 2023-10-28 12:34:03 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:34:03 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:34:03 --> Utf8 Class Initialized
INFO - 2023-10-28 12:34:03 --> URI Class Initialized
INFO - 2023-10-28 12:34:03 --> Router Class Initialized
INFO - 2023-10-28 12:34:03 --> Output Class Initialized
INFO - 2023-10-28 12:34:03 --> Security Class Initialized
DEBUG - 2023-10-28 12:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:34:03 --> Input Class Initialized
INFO - 2023-10-28 12:34:03 --> Language Class Initialized
INFO - 2023-10-28 12:34:03 --> Loader Class Initialized
INFO - 2023-10-28 12:34:03 --> Helper loaded: url_helper
INFO - 2023-10-28 12:34:03 --> Helper loaded: file_helper
INFO - 2023-10-28 12:34:03 --> Helper loaded: html_helper
INFO - 2023-10-28 12:34:03 --> Helper loaded: text_helper
INFO - 2023-10-28 12:34:03 --> Helper loaded: form_helper
INFO - 2023-10-28 12:34:03 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:34:03 --> Helper loaded: security_helper
INFO - 2023-10-28 12:34:03 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:34:03 --> Database Driver Class Initialized
INFO - 2023-10-28 12:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:34:03 --> Parser Class Initialized
INFO - 2023-10-28 12:34:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:34:03 --> Pagination Class Initialized
INFO - 2023-10-28 12:34:03 --> Form Validation Class Initialized
INFO - 2023-10-28 12:34:03 --> Controller Class Initialized
INFO - 2023-10-28 12:34:03 --> Model Class Initialized
DEBUG - 2023-10-28 12:34:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:34:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:34:03 --> Model Class Initialized
DEBUG - 2023-10-28 12:34:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:34:03 --> Model Class Initialized
INFO - 2023-10-28 12:34:04 --> Final output sent to browser
DEBUG - 2023-10-28 12:34:04 --> Total execution time: 0.1581
ERROR - 2023-10-28 12:34:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:34:13 --> Config Class Initialized
INFO - 2023-10-28 12:34:13 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:34:13 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:34:13 --> Utf8 Class Initialized
INFO - 2023-10-28 12:34:13 --> URI Class Initialized
INFO - 2023-10-28 12:34:13 --> Router Class Initialized
INFO - 2023-10-28 12:34:13 --> Output Class Initialized
INFO - 2023-10-28 12:34:13 --> Security Class Initialized
DEBUG - 2023-10-28 12:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:34:13 --> Input Class Initialized
INFO - 2023-10-28 12:34:13 --> Language Class Initialized
INFO - 2023-10-28 12:34:13 --> Loader Class Initialized
INFO - 2023-10-28 12:34:13 --> Helper loaded: url_helper
INFO - 2023-10-28 12:34:13 --> Helper loaded: file_helper
INFO - 2023-10-28 12:34:13 --> Helper loaded: html_helper
INFO - 2023-10-28 12:34:13 --> Helper loaded: text_helper
INFO - 2023-10-28 12:34:13 --> Helper loaded: form_helper
INFO - 2023-10-28 12:34:13 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:34:13 --> Helper loaded: security_helper
INFO - 2023-10-28 12:34:13 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:34:13 --> Database Driver Class Initialized
INFO - 2023-10-28 12:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:34:13 --> Parser Class Initialized
INFO - 2023-10-28 12:34:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:34:13 --> Pagination Class Initialized
INFO - 2023-10-28 12:34:13 --> Form Validation Class Initialized
INFO - 2023-10-28 12:34:13 --> Controller Class Initialized
INFO - 2023-10-28 12:34:13 --> Model Class Initialized
DEBUG - 2023-10-28 12:34:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:34:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:34:13 --> Model Class Initialized
DEBUG - 2023-10-28 12:34:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:34:13 --> Model Class Initialized
INFO - 2023-10-28 12:34:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html.php
DEBUG - 2023-10-28 12:34:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:34:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 12:34:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 12:34:13 --> Model Class Initialized
INFO - 2023-10-28 12:34:13 --> Model Class Initialized
INFO - 2023-10-28 12:34:13 --> Model Class Initialized
INFO - 2023-10-28 12:34:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 12:34:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 12:34:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 12:34:13 --> Final output sent to browser
DEBUG - 2023-10-28 12:34:13 --> Total execution time: 0.1963
ERROR - 2023-10-28 12:35:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:35:07 --> Config Class Initialized
INFO - 2023-10-28 12:35:07 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:35:07 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:35:07 --> Utf8 Class Initialized
INFO - 2023-10-28 12:35:07 --> URI Class Initialized
INFO - 2023-10-28 12:35:07 --> Router Class Initialized
INFO - 2023-10-28 12:35:07 --> Output Class Initialized
INFO - 2023-10-28 12:35:07 --> Security Class Initialized
DEBUG - 2023-10-28 12:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:35:07 --> Input Class Initialized
INFO - 2023-10-28 12:35:07 --> Language Class Initialized
INFO - 2023-10-28 12:35:07 --> Loader Class Initialized
INFO - 2023-10-28 12:35:07 --> Helper loaded: url_helper
INFO - 2023-10-28 12:35:07 --> Helper loaded: file_helper
INFO - 2023-10-28 12:35:07 --> Helper loaded: html_helper
INFO - 2023-10-28 12:35:07 --> Helper loaded: text_helper
INFO - 2023-10-28 12:35:07 --> Helper loaded: form_helper
INFO - 2023-10-28 12:35:07 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:35:07 --> Helper loaded: security_helper
INFO - 2023-10-28 12:35:07 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:35:07 --> Database Driver Class Initialized
INFO - 2023-10-28 12:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:35:07 --> Parser Class Initialized
INFO - 2023-10-28 12:35:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:35:07 --> Pagination Class Initialized
INFO - 2023-10-28 12:35:07 --> Form Validation Class Initialized
INFO - 2023-10-28 12:35:07 --> Controller Class Initialized
DEBUG - 2023-10-28 12:35:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:35:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:35:07 --> Model Class Initialized
INFO - 2023-10-28 12:35:07 --> Model Class Initialized
DEBUG - 2023-10-28 12:35:07 --> Lmr class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:35:07 --> Model Class Initialized
INFO - 2023-10-28 12:35:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/mr/mr.php
DEBUG - 2023-10-28 12:35:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:35:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 12:35:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 12:35:07 --> Model Class Initialized
INFO - 2023-10-28 12:35:07 --> Model Class Initialized
INFO - 2023-10-28 12:35:07 --> Model Class Initialized
INFO - 2023-10-28 12:35:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 12:35:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 12:35:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 12:35:07 --> Final output sent to browser
DEBUG - 2023-10-28 12:35:07 --> Total execution time: 0.1958
ERROR - 2023-10-28 12:35:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:35:08 --> Config Class Initialized
INFO - 2023-10-28 12:35:08 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:35:08 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:35:08 --> Utf8 Class Initialized
INFO - 2023-10-28 12:35:08 --> URI Class Initialized
INFO - 2023-10-28 12:35:08 --> Router Class Initialized
INFO - 2023-10-28 12:35:08 --> Output Class Initialized
INFO - 2023-10-28 12:35:08 --> Security Class Initialized
DEBUG - 2023-10-28 12:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:35:08 --> Input Class Initialized
INFO - 2023-10-28 12:35:08 --> Language Class Initialized
INFO - 2023-10-28 12:35:08 --> Loader Class Initialized
INFO - 2023-10-28 12:35:08 --> Helper loaded: url_helper
INFO - 2023-10-28 12:35:08 --> Helper loaded: file_helper
INFO - 2023-10-28 12:35:08 --> Helper loaded: html_helper
INFO - 2023-10-28 12:35:08 --> Helper loaded: text_helper
INFO - 2023-10-28 12:35:08 --> Helper loaded: form_helper
INFO - 2023-10-28 12:35:08 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:35:08 --> Helper loaded: security_helper
INFO - 2023-10-28 12:35:08 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:35:08 --> Database Driver Class Initialized
INFO - 2023-10-28 12:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:35:08 --> Parser Class Initialized
INFO - 2023-10-28 12:35:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:35:08 --> Pagination Class Initialized
INFO - 2023-10-28 12:35:08 --> Form Validation Class Initialized
INFO - 2023-10-28 12:35:08 --> Controller Class Initialized
DEBUG - 2023-10-28 12:35:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:35:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:35:08 --> Model Class Initialized
INFO - 2023-10-28 12:35:08 --> Model Class Initialized
INFO - 2023-10-28 12:35:08 --> Final output sent to browser
DEBUG - 2023-10-28 12:35:08 --> Total execution time: 0.0267
ERROR - 2023-10-28 12:35:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:35:19 --> Config Class Initialized
INFO - 2023-10-28 12:35:19 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:35:19 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:35:19 --> Utf8 Class Initialized
INFO - 2023-10-28 12:35:19 --> URI Class Initialized
INFO - 2023-10-28 12:35:19 --> Router Class Initialized
INFO - 2023-10-28 12:35:19 --> Output Class Initialized
INFO - 2023-10-28 12:35:19 --> Security Class Initialized
DEBUG - 2023-10-28 12:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:35:19 --> Input Class Initialized
INFO - 2023-10-28 12:35:19 --> Language Class Initialized
INFO - 2023-10-28 12:35:19 --> Loader Class Initialized
INFO - 2023-10-28 12:35:19 --> Helper loaded: url_helper
INFO - 2023-10-28 12:35:19 --> Helper loaded: file_helper
INFO - 2023-10-28 12:35:19 --> Helper loaded: html_helper
INFO - 2023-10-28 12:35:19 --> Helper loaded: text_helper
INFO - 2023-10-28 12:35:19 --> Helper loaded: form_helper
INFO - 2023-10-28 12:35:19 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:35:19 --> Helper loaded: security_helper
INFO - 2023-10-28 12:35:19 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:35:19 --> Database Driver Class Initialized
INFO - 2023-10-28 12:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:35:19 --> Parser Class Initialized
INFO - 2023-10-28 12:35:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:35:19 --> Pagination Class Initialized
INFO - 2023-10-28 12:35:19 --> Form Validation Class Initialized
INFO - 2023-10-28 12:35:19 --> Controller Class Initialized
INFO - 2023-10-28 12:35:19 --> Model Class Initialized
DEBUG - 2023-10-28 12:35:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:35:19 --> Model Class Initialized
INFO - 2023-10-28 12:35:19 --> Final output sent to browser
DEBUG - 2023-10-28 12:35:19 --> Total execution time: 0.0172
ERROR - 2023-10-28 12:35:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:35:19 --> Config Class Initialized
INFO - 2023-10-28 12:35:19 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:35:19 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:35:19 --> Utf8 Class Initialized
INFO - 2023-10-28 12:35:19 --> URI Class Initialized
DEBUG - 2023-10-28 12:35:19 --> No URI present. Default controller set.
INFO - 2023-10-28 12:35:19 --> Router Class Initialized
INFO - 2023-10-28 12:35:19 --> Output Class Initialized
INFO - 2023-10-28 12:35:19 --> Security Class Initialized
DEBUG - 2023-10-28 12:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:35:19 --> Input Class Initialized
INFO - 2023-10-28 12:35:19 --> Language Class Initialized
INFO - 2023-10-28 12:35:19 --> Loader Class Initialized
INFO - 2023-10-28 12:35:19 --> Helper loaded: url_helper
INFO - 2023-10-28 12:35:19 --> Helper loaded: file_helper
INFO - 2023-10-28 12:35:19 --> Helper loaded: html_helper
INFO - 2023-10-28 12:35:19 --> Helper loaded: text_helper
INFO - 2023-10-28 12:35:19 --> Helper loaded: form_helper
INFO - 2023-10-28 12:35:19 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:35:19 --> Helper loaded: security_helper
INFO - 2023-10-28 12:35:19 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:35:19 --> Database Driver Class Initialized
INFO - 2023-10-28 12:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:35:19 --> Parser Class Initialized
INFO - 2023-10-28 12:35:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:35:19 --> Pagination Class Initialized
INFO - 2023-10-28 12:35:19 --> Form Validation Class Initialized
INFO - 2023-10-28 12:35:19 --> Controller Class Initialized
INFO - 2023-10-28 12:35:19 --> Model Class Initialized
DEBUG - 2023-10-28 12:35:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:35:19 --> Model Class Initialized
DEBUG - 2023-10-28 12:35:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:35:19 --> Model Class Initialized
INFO - 2023-10-28 12:35:19 --> Model Class Initialized
INFO - 2023-10-28 12:35:19 --> Model Class Initialized
INFO - 2023-10-28 12:35:19 --> Model Class Initialized
DEBUG - 2023-10-28 12:35:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:35:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:35:19 --> Model Class Initialized
INFO - 2023-10-28 12:35:19 --> Model Class Initialized
INFO - 2023-10-28 12:35:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-28 12:35:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:35:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 12:35:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 12:35:20 --> Model Class Initialized
INFO - 2023-10-28 12:35:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 12:35:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 12:35:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 12:35:20 --> Final output sent to browser
DEBUG - 2023-10-28 12:35:20 --> Total execution time: 0.1908
ERROR - 2023-10-28 12:35:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:35:39 --> Config Class Initialized
INFO - 2023-10-28 12:35:39 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:35:39 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:35:39 --> Utf8 Class Initialized
INFO - 2023-10-28 12:35:39 --> URI Class Initialized
INFO - 2023-10-28 12:35:39 --> Router Class Initialized
INFO - 2023-10-28 12:35:39 --> Output Class Initialized
INFO - 2023-10-28 12:35:39 --> Security Class Initialized
DEBUG - 2023-10-28 12:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:35:39 --> Input Class Initialized
INFO - 2023-10-28 12:35:39 --> Language Class Initialized
INFO - 2023-10-28 12:35:39 --> Loader Class Initialized
INFO - 2023-10-28 12:35:39 --> Helper loaded: url_helper
INFO - 2023-10-28 12:35:39 --> Helper loaded: file_helper
INFO - 2023-10-28 12:35:39 --> Helper loaded: html_helper
INFO - 2023-10-28 12:35:39 --> Helper loaded: text_helper
INFO - 2023-10-28 12:35:39 --> Helper loaded: form_helper
INFO - 2023-10-28 12:35:39 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:35:39 --> Helper loaded: security_helper
INFO - 2023-10-28 12:35:39 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:35:39 --> Database Driver Class Initialized
INFO - 2023-10-28 12:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:35:39 --> Parser Class Initialized
INFO - 2023-10-28 12:35:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:35:39 --> Pagination Class Initialized
INFO - 2023-10-28 12:35:39 --> Form Validation Class Initialized
INFO - 2023-10-28 12:35:39 --> Controller Class Initialized
INFO - 2023-10-28 12:35:39 --> Model Class Initialized
DEBUG - 2023-10-28 12:35:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:35:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:35:39 --> Model Class Initialized
DEBUG - 2023-10-28 12:35:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:35:39 --> Model Class Initialized
INFO - 2023-10-28 12:35:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-28 12:35:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:35:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 12:35:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 12:35:39 --> Model Class Initialized
INFO - 2023-10-28 12:35:39 --> Model Class Initialized
INFO - 2023-10-28 12:35:39 --> Model Class Initialized
INFO - 2023-10-28 12:35:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 12:35:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 12:35:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 12:35:40 --> Final output sent to browser
DEBUG - 2023-10-28 12:35:40 --> Total execution time: 0.1311
ERROR - 2023-10-28 12:35:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:35:40 --> Config Class Initialized
INFO - 2023-10-28 12:35:40 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:35:40 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:35:40 --> Utf8 Class Initialized
INFO - 2023-10-28 12:35:40 --> URI Class Initialized
INFO - 2023-10-28 12:35:40 --> Router Class Initialized
INFO - 2023-10-28 12:35:40 --> Output Class Initialized
INFO - 2023-10-28 12:35:40 --> Security Class Initialized
DEBUG - 2023-10-28 12:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:35:40 --> Input Class Initialized
INFO - 2023-10-28 12:35:40 --> Language Class Initialized
INFO - 2023-10-28 12:35:40 --> Loader Class Initialized
INFO - 2023-10-28 12:35:40 --> Helper loaded: url_helper
INFO - 2023-10-28 12:35:40 --> Helper loaded: file_helper
INFO - 2023-10-28 12:35:40 --> Helper loaded: html_helper
INFO - 2023-10-28 12:35:40 --> Helper loaded: text_helper
INFO - 2023-10-28 12:35:40 --> Helper loaded: form_helper
INFO - 2023-10-28 12:35:40 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:35:40 --> Helper loaded: security_helper
INFO - 2023-10-28 12:35:40 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:35:40 --> Database Driver Class Initialized
INFO - 2023-10-28 12:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:35:40 --> Parser Class Initialized
INFO - 2023-10-28 12:35:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:35:40 --> Pagination Class Initialized
INFO - 2023-10-28 12:35:40 --> Form Validation Class Initialized
INFO - 2023-10-28 12:35:40 --> Controller Class Initialized
INFO - 2023-10-28 12:35:40 --> Model Class Initialized
DEBUG - 2023-10-28 12:35:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:35:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:35:40 --> Model Class Initialized
DEBUG - 2023-10-28 12:35:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:35:40 --> Model Class Initialized
INFO - 2023-10-28 12:35:40 --> Final output sent to browser
DEBUG - 2023-10-28 12:35:40 --> Total execution time: 0.0345
ERROR - 2023-10-28 12:36:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:36:06 --> Config Class Initialized
INFO - 2023-10-28 12:36:06 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:36:06 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:36:06 --> Utf8 Class Initialized
INFO - 2023-10-28 12:36:06 --> URI Class Initialized
INFO - 2023-10-28 12:36:06 --> Router Class Initialized
INFO - 2023-10-28 12:36:06 --> Output Class Initialized
INFO - 2023-10-28 12:36:06 --> Security Class Initialized
DEBUG - 2023-10-28 12:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:36:06 --> Input Class Initialized
INFO - 2023-10-28 12:36:06 --> Language Class Initialized
INFO - 2023-10-28 12:36:06 --> Loader Class Initialized
INFO - 2023-10-28 12:36:06 --> Helper loaded: url_helper
INFO - 2023-10-28 12:36:06 --> Helper loaded: file_helper
INFO - 2023-10-28 12:36:06 --> Helper loaded: html_helper
INFO - 2023-10-28 12:36:06 --> Helper loaded: text_helper
INFO - 2023-10-28 12:36:06 --> Helper loaded: form_helper
INFO - 2023-10-28 12:36:06 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:36:06 --> Helper loaded: security_helper
INFO - 2023-10-28 12:36:06 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:36:06 --> Database Driver Class Initialized
INFO - 2023-10-28 12:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:36:06 --> Parser Class Initialized
INFO - 2023-10-28 12:36:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:36:06 --> Pagination Class Initialized
INFO - 2023-10-28 12:36:06 --> Form Validation Class Initialized
INFO - 2023-10-28 12:36:06 --> Controller Class Initialized
INFO - 2023-10-28 12:36:06 --> Model Class Initialized
DEBUG - 2023-10-28 12:36:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:36:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:36:06 --> Model Class Initialized
INFO - 2023-10-28 12:36:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-10-28 12:36:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:36:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 12:36:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 12:36:06 --> Model Class Initialized
INFO - 2023-10-28 12:36:06 --> Model Class Initialized
INFO - 2023-10-28 12:36:06 --> Model Class Initialized
INFO - 2023-10-28 12:36:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 12:36:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 12:36:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 12:36:07 --> Final output sent to browser
DEBUG - 2023-10-28 12:36:07 --> Total execution time: 0.1245
ERROR - 2023-10-28 12:36:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:36:07 --> Config Class Initialized
INFO - 2023-10-28 12:36:07 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:36:07 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:36:07 --> Utf8 Class Initialized
INFO - 2023-10-28 12:36:07 --> URI Class Initialized
INFO - 2023-10-28 12:36:07 --> Router Class Initialized
INFO - 2023-10-28 12:36:07 --> Output Class Initialized
INFO - 2023-10-28 12:36:07 --> Security Class Initialized
DEBUG - 2023-10-28 12:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:36:07 --> Input Class Initialized
INFO - 2023-10-28 12:36:07 --> Language Class Initialized
INFO - 2023-10-28 12:36:07 --> Loader Class Initialized
INFO - 2023-10-28 12:36:07 --> Helper loaded: url_helper
INFO - 2023-10-28 12:36:07 --> Helper loaded: file_helper
INFO - 2023-10-28 12:36:07 --> Helper loaded: html_helper
INFO - 2023-10-28 12:36:07 --> Helper loaded: text_helper
INFO - 2023-10-28 12:36:07 --> Helper loaded: form_helper
INFO - 2023-10-28 12:36:07 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:36:07 --> Helper loaded: security_helper
INFO - 2023-10-28 12:36:07 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:36:07 --> Database Driver Class Initialized
INFO - 2023-10-28 12:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:36:07 --> Parser Class Initialized
INFO - 2023-10-28 12:36:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:36:07 --> Pagination Class Initialized
INFO - 2023-10-28 12:36:07 --> Form Validation Class Initialized
INFO - 2023-10-28 12:36:07 --> Controller Class Initialized
INFO - 2023-10-28 12:36:07 --> Model Class Initialized
DEBUG - 2023-10-28 12:36:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:36:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:36:07 --> Model Class Initialized
INFO - 2023-10-28 12:36:07 --> Final output sent to browser
DEBUG - 2023-10-28 12:36:07 --> Total execution time: 0.0413
ERROR - 2023-10-28 12:36:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:36:46 --> Config Class Initialized
INFO - 2023-10-28 12:36:46 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:36:46 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:36:46 --> Utf8 Class Initialized
INFO - 2023-10-28 12:36:46 --> URI Class Initialized
INFO - 2023-10-28 12:36:46 --> Router Class Initialized
INFO - 2023-10-28 12:36:46 --> Output Class Initialized
INFO - 2023-10-28 12:36:46 --> Security Class Initialized
DEBUG - 2023-10-28 12:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:36:46 --> Input Class Initialized
INFO - 2023-10-28 12:36:46 --> Language Class Initialized
INFO - 2023-10-28 12:36:46 --> Loader Class Initialized
INFO - 2023-10-28 12:36:46 --> Helper loaded: url_helper
INFO - 2023-10-28 12:36:46 --> Helper loaded: file_helper
INFO - 2023-10-28 12:36:46 --> Helper loaded: html_helper
INFO - 2023-10-28 12:36:46 --> Helper loaded: text_helper
INFO - 2023-10-28 12:36:46 --> Helper loaded: form_helper
INFO - 2023-10-28 12:36:46 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:36:46 --> Helper loaded: security_helper
INFO - 2023-10-28 12:36:46 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:36:46 --> Database Driver Class Initialized
INFO - 2023-10-28 12:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:36:46 --> Parser Class Initialized
INFO - 2023-10-28 12:36:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:36:46 --> Pagination Class Initialized
INFO - 2023-10-28 12:36:46 --> Form Validation Class Initialized
INFO - 2023-10-28 12:36:46 --> Controller Class Initialized
INFO - 2023-10-28 12:36:46 --> Model Class Initialized
DEBUG - 2023-10-28 12:36:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:36:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:36:46 --> Model Class Initialized
DEBUG - 2023-10-28 12:36:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:36:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/add_stockrequest_form.php
DEBUG - 2023-10-28 12:36:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:36:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 12:36:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 12:36:46 --> Model Class Initialized
INFO - 2023-10-28 12:36:46 --> Model Class Initialized
INFO - 2023-10-28 12:36:46 --> Model Class Initialized
INFO - 2023-10-28 12:36:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 12:36:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 12:36:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 12:36:46 --> Final output sent to browser
DEBUG - 2023-10-28 12:36:46 --> Total execution time: 0.2050
ERROR - 2023-10-28 12:36:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:36:51 --> Config Class Initialized
INFO - 2023-10-28 12:36:51 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:36:51 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:36:51 --> Utf8 Class Initialized
INFO - 2023-10-28 12:36:51 --> URI Class Initialized
INFO - 2023-10-28 12:36:51 --> Router Class Initialized
INFO - 2023-10-28 12:36:51 --> Output Class Initialized
INFO - 2023-10-28 12:36:51 --> Security Class Initialized
DEBUG - 2023-10-28 12:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:36:51 --> Input Class Initialized
INFO - 2023-10-28 12:36:51 --> Language Class Initialized
INFO - 2023-10-28 12:36:51 --> Loader Class Initialized
INFO - 2023-10-28 12:36:51 --> Helper loaded: url_helper
INFO - 2023-10-28 12:36:51 --> Helper loaded: file_helper
INFO - 2023-10-28 12:36:51 --> Helper loaded: html_helper
INFO - 2023-10-28 12:36:51 --> Helper loaded: text_helper
INFO - 2023-10-28 12:36:51 --> Helper loaded: form_helper
INFO - 2023-10-28 12:36:51 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:36:51 --> Helper loaded: security_helper
INFO - 2023-10-28 12:36:51 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:36:51 --> Database Driver Class Initialized
INFO - 2023-10-28 12:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:36:51 --> Parser Class Initialized
INFO - 2023-10-28 12:36:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:36:51 --> Pagination Class Initialized
INFO - 2023-10-28 12:36:51 --> Form Validation Class Initialized
INFO - 2023-10-28 12:36:51 --> Controller Class Initialized
INFO - 2023-10-28 12:36:51 --> Model Class Initialized
INFO - 2023-10-28 12:36:51 --> Final output sent to browser
DEBUG - 2023-10-28 12:36:51 --> Total execution time: 0.0161
ERROR - 2023-10-28 12:37:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:37:18 --> Config Class Initialized
INFO - 2023-10-28 12:37:18 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:37:18 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:37:18 --> Utf8 Class Initialized
INFO - 2023-10-28 12:37:18 --> URI Class Initialized
INFO - 2023-10-28 12:37:18 --> Router Class Initialized
INFO - 2023-10-28 12:37:18 --> Output Class Initialized
INFO - 2023-10-28 12:37:18 --> Security Class Initialized
DEBUG - 2023-10-28 12:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:37:18 --> Input Class Initialized
INFO - 2023-10-28 12:37:18 --> Language Class Initialized
INFO - 2023-10-28 12:37:18 --> Loader Class Initialized
INFO - 2023-10-28 12:37:18 --> Helper loaded: url_helper
INFO - 2023-10-28 12:37:18 --> Helper loaded: file_helper
INFO - 2023-10-28 12:37:18 --> Helper loaded: html_helper
INFO - 2023-10-28 12:37:18 --> Helper loaded: text_helper
INFO - 2023-10-28 12:37:18 --> Helper loaded: form_helper
INFO - 2023-10-28 12:37:18 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:37:18 --> Helper loaded: security_helper
INFO - 2023-10-28 12:37:18 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:37:18 --> Database Driver Class Initialized
INFO - 2023-10-28 12:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:37:18 --> Parser Class Initialized
INFO - 2023-10-28 12:37:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:37:18 --> Pagination Class Initialized
INFO - 2023-10-28 12:37:18 --> Form Validation Class Initialized
INFO - 2023-10-28 12:37:18 --> Controller Class Initialized
INFO - 2023-10-28 12:37:18 --> Model Class Initialized
DEBUG - 2023-10-28 12:37:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:37:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:37:18 --> Model Class Initialized
DEBUG - 2023-10-28 12:37:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:37:18 --> Model Class Initialized
INFO - 2023-10-28 12:37:18 --> Final output sent to browser
DEBUG - 2023-10-28 12:37:18 --> Total execution time: 0.0212
ERROR - 2023-10-28 12:37:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:37:18 --> Config Class Initialized
INFO - 2023-10-28 12:37:18 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:37:18 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:37:18 --> Utf8 Class Initialized
INFO - 2023-10-28 12:37:18 --> URI Class Initialized
INFO - 2023-10-28 12:37:18 --> Router Class Initialized
INFO - 2023-10-28 12:37:18 --> Output Class Initialized
INFO - 2023-10-28 12:37:18 --> Security Class Initialized
DEBUG - 2023-10-28 12:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:37:18 --> Input Class Initialized
INFO - 2023-10-28 12:37:18 --> Language Class Initialized
INFO - 2023-10-28 12:37:18 --> Loader Class Initialized
INFO - 2023-10-28 12:37:18 --> Helper loaded: url_helper
INFO - 2023-10-28 12:37:18 --> Helper loaded: file_helper
INFO - 2023-10-28 12:37:18 --> Helper loaded: html_helper
INFO - 2023-10-28 12:37:18 --> Helper loaded: text_helper
INFO - 2023-10-28 12:37:18 --> Helper loaded: form_helper
INFO - 2023-10-28 12:37:18 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:37:18 --> Helper loaded: security_helper
INFO - 2023-10-28 12:37:18 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:37:18 --> Database Driver Class Initialized
INFO - 2023-10-28 12:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:37:18 --> Parser Class Initialized
INFO - 2023-10-28 12:37:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:37:18 --> Pagination Class Initialized
INFO - 2023-10-28 12:37:18 --> Form Validation Class Initialized
INFO - 2023-10-28 12:37:18 --> Controller Class Initialized
INFO - 2023-10-28 12:37:18 --> Model Class Initialized
DEBUG - 2023-10-28 12:37:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:37:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:37:18 --> Model Class Initialized
DEBUG - 2023-10-28 12:37:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:37:18 --> Model Class Initialized
INFO - 2023-10-28 12:37:18 --> Final output sent to browser
DEBUG - 2023-10-28 12:37:18 --> Total execution time: 0.0186
ERROR - 2023-10-28 12:37:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:37:19 --> Config Class Initialized
INFO - 2023-10-28 12:37:19 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:37:19 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:37:19 --> Utf8 Class Initialized
INFO - 2023-10-28 12:37:19 --> URI Class Initialized
INFO - 2023-10-28 12:37:19 --> Router Class Initialized
INFO - 2023-10-28 12:37:19 --> Output Class Initialized
INFO - 2023-10-28 12:37:19 --> Security Class Initialized
DEBUG - 2023-10-28 12:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:37:19 --> Input Class Initialized
INFO - 2023-10-28 12:37:19 --> Language Class Initialized
INFO - 2023-10-28 12:37:19 --> Loader Class Initialized
INFO - 2023-10-28 12:37:19 --> Helper loaded: url_helper
INFO - 2023-10-28 12:37:19 --> Helper loaded: file_helper
INFO - 2023-10-28 12:37:19 --> Helper loaded: html_helper
INFO - 2023-10-28 12:37:19 --> Helper loaded: text_helper
INFO - 2023-10-28 12:37:19 --> Helper loaded: form_helper
INFO - 2023-10-28 12:37:19 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:37:19 --> Helper loaded: security_helper
INFO - 2023-10-28 12:37:19 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:37:19 --> Database Driver Class Initialized
INFO - 2023-10-28 12:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:37:19 --> Parser Class Initialized
INFO - 2023-10-28 12:37:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:37:19 --> Pagination Class Initialized
INFO - 2023-10-28 12:37:19 --> Form Validation Class Initialized
INFO - 2023-10-28 12:37:19 --> Controller Class Initialized
INFO - 2023-10-28 12:37:19 --> Model Class Initialized
DEBUG - 2023-10-28 12:37:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:37:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:37:19 --> Model Class Initialized
DEBUG - 2023-10-28 12:37:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:37:19 --> Model Class Initialized
INFO - 2023-10-28 12:37:19 --> Final output sent to browser
DEBUG - 2023-10-28 12:37:19 --> Total execution time: 0.0210
ERROR - 2023-10-28 12:37:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:37:20 --> Config Class Initialized
INFO - 2023-10-28 12:37:20 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:37:20 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:37:20 --> Utf8 Class Initialized
INFO - 2023-10-28 12:37:20 --> URI Class Initialized
INFO - 2023-10-28 12:37:20 --> Router Class Initialized
INFO - 2023-10-28 12:37:20 --> Output Class Initialized
INFO - 2023-10-28 12:37:20 --> Security Class Initialized
DEBUG - 2023-10-28 12:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:37:20 --> Input Class Initialized
INFO - 2023-10-28 12:37:20 --> Language Class Initialized
INFO - 2023-10-28 12:37:20 --> Loader Class Initialized
INFO - 2023-10-28 12:37:20 --> Helper loaded: url_helper
INFO - 2023-10-28 12:37:20 --> Helper loaded: file_helper
INFO - 2023-10-28 12:37:20 --> Helper loaded: html_helper
INFO - 2023-10-28 12:37:20 --> Helper loaded: text_helper
INFO - 2023-10-28 12:37:20 --> Helper loaded: form_helper
INFO - 2023-10-28 12:37:20 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:37:20 --> Helper loaded: security_helper
INFO - 2023-10-28 12:37:20 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:37:20 --> Database Driver Class Initialized
INFO - 2023-10-28 12:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:37:20 --> Parser Class Initialized
INFO - 2023-10-28 12:37:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:37:20 --> Pagination Class Initialized
INFO - 2023-10-28 12:37:20 --> Form Validation Class Initialized
INFO - 2023-10-28 12:37:20 --> Controller Class Initialized
INFO - 2023-10-28 12:37:20 --> Model Class Initialized
DEBUG - 2023-10-28 12:37:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:37:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:37:20 --> Model Class Initialized
DEBUG - 2023-10-28 12:37:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:37:20 --> Model Class Initialized
INFO - 2023-10-28 12:37:20 --> Final output sent to browser
DEBUG - 2023-10-28 12:37:20 --> Total execution time: 0.0189
ERROR - 2023-10-28 12:37:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:37:22 --> Config Class Initialized
INFO - 2023-10-28 12:37:22 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:37:22 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:37:22 --> Utf8 Class Initialized
INFO - 2023-10-28 12:37:22 --> URI Class Initialized
INFO - 2023-10-28 12:37:22 --> Router Class Initialized
INFO - 2023-10-28 12:37:22 --> Output Class Initialized
INFO - 2023-10-28 12:37:22 --> Security Class Initialized
DEBUG - 2023-10-28 12:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:37:22 --> Input Class Initialized
INFO - 2023-10-28 12:37:22 --> Language Class Initialized
INFO - 2023-10-28 12:37:22 --> Loader Class Initialized
INFO - 2023-10-28 12:37:22 --> Helper loaded: url_helper
INFO - 2023-10-28 12:37:22 --> Helper loaded: file_helper
INFO - 2023-10-28 12:37:22 --> Helper loaded: html_helper
INFO - 2023-10-28 12:37:22 --> Helper loaded: text_helper
INFO - 2023-10-28 12:37:22 --> Helper loaded: form_helper
INFO - 2023-10-28 12:37:22 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:37:22 --> Helper loaded: security_helper
INFO - 2023-10-28 12:37:22 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:37:22 --> Database Driver Class Initialized
INFO - 2023-10-28 12:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:37:22 --> Parser Class Initialized
INFO - 2023-10-28 12:37:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:37:22 --> Pagination Class Initialized
INFO - 2023-10-28 12:37:22 --> Form Validation Class Initialized
INFO - 2023-10-28 12:37:22 --> Controller Class Initialized
INFO - 2023-10-28 12:37:22 --> Model Class Initialized
DEBUG - 2023-10-28 12:37:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:37:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:37:22 --> Model Class Initialized
DEBUG - 2023-10-28 12:37:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:37:22 --> Model Class Initialized
INFO - 2023-10-28 12:37:22 --> Final output sent to browser
DEBUG - 2023-10-28 12:37:22 --> Total execution time: 0.0178
ERROR - 2023-10-28 12:37:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:37:24 --> Config Class Initialized
INFO - 2023-10-28 12:37:24 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:37:24 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:37:24 --> Utf8 Class Initialized
INFO - 2023-10-28 12:37:24 --> URI Class Initialized
INFO - 2023-10-28 12:37:24 --> Router Class Initialized
INFO - 2023-10-28 12:37:24 --> Output Class Initialized
INFO - 2023-10-28 12:37:24 --> Security Class Initialized
DEBUG - 2023-10-28 12:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:37:24 --> Input Class Initialized
INFO - 2023-10-28 12:37:24 --> Language Class Initialized
INFO - 2023-10-28 12:37:24 --> Loader Class Initialized
INFO - 2023-10-28 12:37:24 --> Helper loaded: url_helper
INFO - 2023-10-28 12:37:24 --> Helper loaded: file_helper
INFO - 2023-10-28 12:37:24 --> Helper loaded: html_helper
INFO - 2023-10-28 12:37:24 --> Helper loaded: text_helper
INFO - 2023-10-28 12:37:24 --> Helper loaded: form_helper
INFO - 2023-10-28 12:37:24 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:37:24 --> Helper loaded: security_helper
INFO - 2023-10-28 12:37:24 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:37:24 --> Database Driver Class Initialized
INFO - 2023-10-28 12:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:37:24 --> Parser Class Initialized
INFO - 2023-10-28 12:37:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:37:24 --> Pagination Class Initialized
INFO - 2023-10-28 12:37:24 --> Form Validation Class Initialized
INFO - 2023-10-28 12:37:24 --> Controller Class Initialized
INFO - 2023-10-28 12:37:24 --> Model Class Initialized
DEBUG - 2023-10-28 12:37:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:37:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:37:24 --> Model Class Initialized
DEBUG - 2023-10-28 12:37:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:37:24 --> Model Class Initialized
INFO - 2023-10-28 12:37:24 --> Model Class Initialized
INFO - 2023-10-28 12:37:24 --> Final output sent to browser
DEBUG - 2023-10-28 12:37:24 --> Total execution time: 0.0217
ERROR - 2023-10-28 12:37:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:37:27 --> Config Class Initialized
INFO - 2023-10-28 12:37:27 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:37:27 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:37:27 --> Utf8 Class Initialized
INFO - 2023-10-28 12:37:27 --> URI Class Initialized
INFO - 2023-10-28 12:37:27 --> Router Class Initialized
INFO - 2023-10-28 12:37:27 --> Output Class Initialized
INFO - 2023-10-28 12:37:27 --> Security Class Initialized
DEBUG - 2023-10-28 12:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:37:27 --> Input Class Initialized
INFO - 2023-10-28 12:37:27 --> Language Class Initialized
INFO - 2023-10-28 12:37:27 --> Loader Class Initialized
INFO - 2023-10-28 12:37:27 --> Helper loaded: url_helper
INFO - 2023-10-28 12:37:27 --> Helper loaded: file_helper
INFO - 2023-10-28 12:37:27 --> Helper loaded: html_helper
INFO - 2023-10-28 12:37:27 --> Helper loaded: text_helper
INFO - 2023-10-28 12:37:27 --> Helper loaded: form_helper
INFO - 2023-10-28 12:37:27 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:37:27 --> Helper loaded: security_helper
INFO - 2023-10-28 12:37:27 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:37:27 --> Database Driver Class Initialized
INFO - 2023-10-28 12:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:37:27 --> Parser Class Initialized
INFO - 2023-10-28 12:37:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:37:27 --> Pagination Class Initialized
INFO - 2023-10-28 12:37:27 --> Form Validation Class Initialized
INFO - 2023-10-28 12:37:27 --> Controller Class Initialized
INFO - 2023-10-28 12:37:27 --> Model Class Initialized
DEBUG - 2023-10-28 12:37:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:37:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:37:27 --> Model Class Initialized
DEBUG - 2023-10-28 12:37:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:37:27 --> Model Class Initialized
INFO - 2023-10-28 12:37:27 --> Final output sent to browser
DEBUG - 2023-10-28 12:37:27 --> Total execution time: 0.0187
ERROR - 2023-10-28 12:37:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:37:44 --> Config Class Initialized
INFO - 2023-10-28 12:37:44 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:37:44 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:37:44 --> Utf8 Class Initialized
INFO - 2023-10-28 12:37:44 --> URI Class Initialized
INFO - 2023-10-28 12:37:44 --> Router Class Initialized
INFO - 2023-10-28 12:37:44 --> Output Class Initialized
INFO - 2023-10-28 12:37:44 --> Security Class Initialized
DEBUG - 2023-10-28 12:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:37:44 --> Input Class Initialized
INFO - 2023-10-28 12:37:44 --> Language Class Initialized
INFO - 2023-10-28 12:37:44 --> Loader Class Initialized
INFO - 2023-10-28 12:37:44 --> Helper loaded: url_helper
INFO - 2023-10-28 12:37:44 --> Helper loaded: file_helper
INFO - 2023-10-28 12:37:44 --> Helper loaded: html_helper
INFO - 2023-10-28 12:37:44 --> Helper loaded: text_helper
INFO - 2023-10-28 12:37:44 --> Helper loaded: form_helper
INFO - 2023-10-28 12:37:44 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:37:44 --> Helper loaded: security_helper
INFO - 2023-10-28 12:37:44 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:37:44 --> Database Driver Class Initialized
INFO - 2023-10-28 12:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:37:44 --> Parser Class Initialized
INFO - 2023-10-28 12:37:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:37:44 --> Pagination Class Initialized
INFO - 2023-10-28 12:37:44 --> Form Validation Class Initialized
INFO - 2023-10-28 12:37:44 --> Controller Class Initialized
INFO - 2023-10-28 12:37:44 --> Model Class Initialized
DEBUG - 2023-10-28 12:37:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:37:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:37:44 --> Model Class Initialized
DEBUG - 2023-10-28 12:37:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:37:44 --> Model Class Initialized
INFO - 2023-10-28 12:37:44 --> Final output sent to browser
DEBUG - 2023-10-28 12:37:44 --> Total execution time: 0.0207
ERROR - 2023-10-28 12:37:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:37:45 --> Config Class Initialized
INFO - 2023-10-28 12:37:45 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:37:45 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:37:45 --> Utf8 Class Initialized
INFO - 2023-10-28 12:37:45 --> URI Class Initialized
INFO - 2023-10-28 12:37:45 --> Router Class Initialized
INFO - 2023-10-28 12:37:45 --> Output Class Initialized
INFO - 2023-10-28 12:37:45 --> Security Class Initialized
DEBUG - 2023-10-28 12:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:37:45 --> Input Class Initialized
INFO - 2023-10-28 12:37:45 --> Language Class Initialized
INFO - 2023-10-28 12:37:45 --> Loader Class Initialized
INFO - 2023-10-28 12:37:45 --> Helper loaded: url_helper
INFO - 2023-10-28 12:37:45 --> Helper loaded: file_helper
INFO - 2023-10-28 12:37:45 --> Helper loaded: html_helper
INFO - 2023-10-28 12:37:45 --> Helper loaded: text_helper
INFO - 2023-10-28 12:37:45 --> Helper loaded: form_helper
INFO - 2023-10-28 12:37:45 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:37:45 --> Helper loaded: security_helper
INFO - 2023-10-28 12:37:45 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:37:45 --> Database Driver Class Initialized
INFO - 2023-10-28 12:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:37:45 --> Parser Class Initialized
INFO - 2023-10-28 12:37:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:37:45 --> Pagination Class Initialized
INFO - 2023-10-28 12:37:45 --> Form Validation Class Initialized
INFO - 2023-10-28 12:37:45 --> Controller Class Initialized
INFO - 2023-10-28 12:37:45 --> Model Class Initialized
DEBUG - 2023-10-28 12:37:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:37:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:37:45 --> Model Class Initialized
DEBUG - 2023-10-28 12:37:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:37:45 --> Model Class Initialized
INFO - 2023-10-28 12:37:45 --> Final output sent to browser
DEBUG - 2023-10-28 12:37:45 --> Total execution time: 0.0192
ERROR - 2023-10-28 12:37:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:37:46 --> Config Class Initialized
INFO - 2023-10-28 12:37:46 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:37:46 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:37:46 --> Utf8 Class Initialized
INFO - 2023-10-28 12:37:46 --> URI Class Initialized
INFO - 2023-10-28 12:37:46 --> Router Class Initialized
INFO - 2023-10-28 12:37:46 --> Output Class Initialized
INFO - 2023-10-28 12:37:46 --> Security Class Initialized
DEBUG - 2023-10-28 12:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:37:46 --> Input Class Initialized
INFO - 2023-10-28 12:37:46 --> Language Class Initialized
INFO - 2023-10-28 12:37:46 --> Loader Class Initialized
INFO - 2023-10-28 12:37:46 --> Helper loaded: url_helper
INFO - 2023-10-28 12:37:46 --> Helper loaded: file_helper
INFO - 2023-10-28 12:37:46 --> Helper loaded: html_helper
INFO - 2023-10-28 12:37:46 --> Helper loaded: text_helper
INFO - 2023-10-28 12:37:46 --> Helper loaded: form_helper
INFO - 2023-10-28 12:37:46 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:37:46 --> Helper loaded: security_helper
INFO - 2023-10-28 12:37:46 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:37:46 --> Database Driver Class Initialized
INFO - 2023-10-28 12:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:37:46 --> Parser Class Initialized
INFO - 2023-10-28 12:37:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:37:46 --> Pagination Class Initialized
INFO - 2023-10-28 12:37:46 --> Form Validation Class Initialized
INFO - 2023-10-28 12:37:46 --> Controller Class Initialized
INFO - 2023-10-28 12:37:46 --> Model Class Initialized
DEBUG - 2023-10-28 12:37:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:37:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:37:46 --> Model Class Initialized
DEBUG - 2023-10-28 12:37:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:37:46 --> Model Class Initialized
INFO - 2023-10-28 12:37:46 --> Final output sent to browser
DEBUG - 2023-10-28 12:37:46 --> Total execution time: 0.0191
ERROR - 2023-10-28 12:37:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:37:46 --> Config Class Initialized
INFO - 2023-10-28 12:37:46 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:37:46 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:37:46 --> Utf8 Class Initialized
INFO - 2023-10-28 12:37:46 --> URI Class Initialized
INFO - 2023-10-28 12:37:46 --> Router Class Initialized
INFO - 2023-10-28 12:37:46 --> Output Class Initialized
INFO - 2023-10-28 12:37:46 --> Security Class Initialized
DEBUG - 2023-10-28 12:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:37:46 --> Input Class Initialized
INFO - 2023-10-28 12:37:46 --> Language Class Initialized
INFO - 2023-10-28 12:37:46 --> Loader Class Initialized
INFO - 2023-10-28 12:37:46 --> Helper loaded: url_helper
INFO - 2023-10-28 12:37:46 --> Helper loaded: file_helper
INFO - 2023-10-28 12:37:46 --> Helper loaded: html_helper
INFO - 2023-10-28 12:37:46 --> Helper loaded: text_helper
INFO - 2023-10-28 12:37:46 --> Helper loaded: form_helper
INFO - 2023-10-28 12:37:46 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:37:46 --> Helper loaded: security_helper
INFO - 2023-10-28 12:37:46 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:37:46 --> Database Driver Class Initialized
INFO - 2023-10-28 12:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:37:46 --> Parser Class Initialized
INFO - 2023-10-28 12:37:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:37:46 --> Pagination Class Initialized
INFO - 2023-10-28 12:37:46 --> Form Validation Class Initialized
INFO - 2023-10-28 12:37:46 --> Controller Class Initialized
INFO - 2023-10-28 12:37:46 --> Model Class Initialized
DEBUG - 2023-10-28 12:37:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:37:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:37:46 --> Model Class Initialized
DEBUG - 2023-10-28 12:37:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:37:46 --> Model Class Initialized
INFO - 2023-10-28 12:37:46 --> Final output sent to browser
DEBUG - 2023-10-28 12:37:46 --> Total execution time: 0.0185
ERROR - 2023-10-28 12:37:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:37:48 --> Config Class Initialized
INFO - 2023-10-28 12:37:48 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:37:48 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:37:48 --> Utf8 Class Initialized
INFO - 2023-10-28 12:37:48 --> URI Class Initialized
INFO - 2023-10-28 12:37:48 --> Router Class Initialized
INFO - 2023-10-28 12:37:48 --> Output Class Initialized
INFO - 2023-10-28 12:37:48 --> Security Class Initialized
DEBUG - 2023-10-28 12:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:37:48 --> Input Class Initialized
INFO - 2023-10-28 12:37:48 --> Language Class Initialized
INFO - 2023-10-28 12:37:48 --> Loader Class Initialized
INFO - 2023-10-28 12:37:48 --> Helper loaded: url_helper
INFO - 2023-10-28 12:37:48 --> Helper loaded: file_helper
INFO - 2023-10-28 12:37:48 --> Helper loaded: html_helper
INFO - 2023-10-28 12:37:48 --> Helper loaded: text_helper
INFO - 2023-10-28 12:37:48 --> Helper loaded: form_helper
INFO - 2023-10-28 12:37:48 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:37:48 --> Helper loaded: security_helper
INFO - 2023-10-28 12:37:48 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:37:48 --> Database Driver Class Initialized
INFO - 2023-10-28 12:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:37:48 --> Parser Class Initialized
INFO - 2023-10-28 12:37:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:37:48 --> Pagination Class Initialized
INFO - 2023-10-28 12:37:48 --> Form Validation Class Initialized
INFO - 2023-10-28 12:37:48 --> Controller Class Initialized
INFO - 2023-10-28 12:37:48 --> Model Class Initialized
DEBUG - 2023-10-28 12:37:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:37:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:37:48 --> Model Class Initialized
DEBUG - 2023-10-28 12:37:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:37:48 --> Model Class Initialized
INFO - 2023-10-28 12:37:48 --> Final output sent to browser
DEBUG - 2023-10-28 12:37:48 --> Total execution time: 0.0180
ERROR - 2023-10-28 12:37:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:37:48 --> Config Class Initialized
INFO - 2023-10-28 12:37:48 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:37:48 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:37:48 --> Utf8 Class Initialized
INFO - 2023-10-28 12:37:48 --> URI Class Initialized
INFO - 2023-10-28 12:37:48 --> Router Class Initialized
INFO - 2023-10-28 12:37:48 --> Output Class Initialized
INFO - 2023-10-28 12:37:48 --> Security Class Initialized
DEBUG - 2023-10-28 12:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:37:48 --> Input Class Initialized
INFO - 2023-10-28 12:37:48 --> Language Class Initialized
INFO - 2023-10-28 12:37:48 --> Loader Class Initialized
INFO - 2023-10-28 12:37:48 --> Helper loaded: url_helper
INFO - 2023-10-28 12:37:48 --> Helper loaded: file_helper
INFO - 2023-10-28 12:37:48 --> Helper loaded: html_helper
INFO - 2023-10-28 12:37:48 --> Helper loaded: text_helper
INFO - 2023-10-28 12:37:48 --> Helper loaded: form_helper
INFO - 2023-10-28 12:37:48 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:37:48 --> Helper loaded: security_helper
INFO - 2023-10-28 12:37:48 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:37:48 --> Database Driver Class Initialized
INFO - 2023-10-28 12:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:37:48 --> Parser Class Initialized
INFO - 2023-10-28 12:37:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:37:48 --> Pagination Class Initialized
INFO - 2023-10-28 12:37:48 --> Form Validation Class Initialized
INFO - 2023-10-28 12:37:48 --> Controller Class Initialized
INFO - 2023-10-28 12:37:48 --> Model Class Initialized
DEBUG - 2023-10-28 12:37:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:37:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:37:48 --> Model Class Initialized
DEBUG - 2023-10-28 12:37:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:37:48 --> Model Class Initialized
INFO - 2023-10-28 12:37:48 --> Final output sent to browser
DEBUG - 2023-10-28 12:37:48 --> Total execution time: 0.0177
ERROR - 2023-10-28 12:37:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:37:50 --> Config Class Initialized
INFO - 2023-10-28 12:37:50 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:37:50 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:37:50 --> Utf8 Class Initialized
INFO - 2023-10-28 12:37:50 --> URI Class Initialized
INFO - 2023-10-28 12:37:50 --> Router Class Initialized
INFO - 2023-10-28 12:37:50 --> Output Class Initialized
INFO - 2023-10-28 12:37:50 --> Security Class Initialized
DEBUG - 2023-10-28 12:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:37:50 --> Input Class Initialized
INFO - 2023-10-28 12:37:50 --> Language Class Initialized
INFO - 2023-10-28 12:37:50 --> Loader Class Initialized
INFO - 2023-10-28 12:37:50 --> Helper loaded: url_helper
INFO - 2023-10-28 12:37:50 --> Helper loaded: file_helper
INFO - 2023-10-28 12:37:50 --> Helper loaded: html_helper
INFO - 2023-10-28 12:37:50 --> Helper loaded: text_helper
INFO - 2023-10-28 12:37:50 --> Helper loaded: form_helper
INFO - 2023-10-28 12:37:50 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:37:50 --> Helper loaded: security_helper
INFO - 2023-10-28 12:37:50 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:37:50 --> Database Driver Class Initialized
INFO - 2023-10-28 12:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:37:50 --> Parser Class Initialized
INFO - 2023-10-28 12:37:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:37:50 --> Pagination Class Initialized
INFO - 2023-10-28 12:37:50 --> Form Validation Class Initialized
INFO - 2023-10-28 12:37:50 --> Controller Class Initialized
INFO - 2023-10-28 12:37:50 --> Model Class Initialized
DEBUG - 2023-10-28 12:37:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:37:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:37:50 --> Model Class Initialized
DEBUG - 2023-10-28 12:37:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:37:50 --> Model Class Initialized
INFO - 2023-10-28 12:37:50 --> Final output sent to browser
DEBUG - 2023-10-28 12:37:50 --> Total execution time: 0.0178
ERROR - 2023-10-28 12:37:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:37:55 --> Config Class Initialized
INFO - 2023-10-28 12:37:55 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:37:55 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:37:55 --> Utf8 Class Initialized
INFO - 2023-10-28 12:37:55 --> URI Class Initialized
INFO - 2023-10-28 12:37:55 --> Router Class Initialized
INFO - 2023-10-28 12:37:55 --> Output Class Initialized
INFO - 2023-10-28 12:37:55 --> Security Class Initialized
DEBUG - 2023-10-28 12:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:37:55 --> Input Class Initialized
INFO - 2023-10-28 12:37:55 --> Language Class Initialized
INFO - 2023-10-28 12:37:55 --> Loader Class Initialized
INFO - 2023-10-28 12:37:55 --> Helper loaded: url_helper
INFO - 2023-10-28 12:37:55 --> Helper loaded: file_helper
INFO - 2023-10-28 12:37:55 --> Helper loaded: html_helper
INFO - 2023-10-28 12:37:55 --> Helper loaded: text_helper
INFO - 2023-10-28 12:37:55 --> Helper loaded: form_helper
INFO - 2023-10-28 12:37:55 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:37:55 --> Helper loaded: security_helper
INFO - 2023-10-28 12:37:55 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:37:55 --> Database Driver Class Initialized
INFO - 2023-10-28 12:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:37:55 --> Parser Class Initialized
INFO - 2023-10-28 12:37:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:37:55 --> Pagination Class Initialized
INFO - 2023-10-28 12:37:55 --> Form Validation Class Initialized
INFO - 2023-10-28 12:37:55 --> Controller Class Initialized
INFO - 2023-10-28 12:37:55 --> Model Class Initialized
DEBUG - 2023-10-28 12:37:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:37:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:37:55 --> Model Class Initialized
DEBUG - 2023-10-28 12:37:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:37:55 --> Model Class Initialized
INFO - 2023-10-28 12:37:55 --> Model Class Initialized
INFO - 2023-10-28 12:37:55 --> Final output sent to browser
DEBUG - 2023-10-28 12:37:55 --> Total execution time: 0.0212
ERROR - 2023-10-28 12:37:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:37:58 --> Config Class Initialized
INFO - 2023-10-28 12:37:58 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:37:58 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:37:58 --> Utf8 Class Initialized
INFO - 2023-10-28 12:37:58 --> URI Class Initialized
INFO - 2023-10-28 12:37:58 --> Router Class Initialized
INFO - 2023-10-28 12:37:58 --> Output Class Initialized
INFO - 2023-10-28 12:37:58 --> Security Class Initialized
DEBUG - 2023-10-28 12:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:37:58 --> Input Class Initialized
INFO - 2023-10-28 12:37:58 --> Language Class Initialized
INFO - 2023-10-28 12:37:58 --> Loader Class Initialized
INFO - 2023-10-28 12:37:58 --> Helper loaded: url_helper
INFO - 2023-10-28 12:37:58 --> Helper loaded: file_helper
INFO - 2023-10-28 12:37:58 --> Helper loaded: html_helper
INFO - 2023-10-28 12:37:58 --> Helper loaded: text_helper
INFO - 2023-10-28 12:37:58 --> Helper loaded: form_helper
INFO - 2023-10-28 12:37:58 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:37:58 --> Helper loaded: security_helper
INFO - 2023-10-28 12:37:58 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:37:58 --> Database Driver Class Initialized
INFO - 2023-10-28 12:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:37:58 --> Parser Class Initialized
INFO - 2023-10-28 12:37:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:37:58 --> Pagination Class Initialized
INFO - 2023-10-28 12:37:58 --> Form Validation Class Initialized
INFO - 2023-10-28 12:37:58 --> Controller Class Initialized
INFO - 2023-10-28 12:37:58 --> Model Class Initialized
DEBUG - 2023-10-28 12:37:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:37:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:37:58 --> Model Class Initialized
DEBUG - 2023-10-28 12:37:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:37:58 --> Model Class Initialized
INFO - 2023-10-28 12:37:58 --> Final output sent to browser
DEBUG - 2023-10-28 12:37:58 --> Total execution time: 0.0189
ERROR - 2023-10-28 12:38:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:38:13 --> Config Class Initialized
INFO - 2023-10-28 12:38:13 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:38:13 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:38:13 --> Utf8 Class Initialized
INFO - 2023-10-28 12:38:13 --> URI Class Initialized
INFO - 2023-10-28 12:38:13 --> Router Class Initialized
INFO - 2023-10-28 12:38:13 --> Output Class Initialized
INFO - 2023-10-28 12:38:13 --> Security Class Initialized
DEBUG - 2023-10-28 12:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:38:13 --> Input Class Initialized
INFO - 2023-10-28 12:38:13 --> Language Class Initialized
INFO - 2023-10-28 12:38:13 --> Loader Class Initialized
INFO - 2023-10-28 12:38:13 --> Helper loaded: url_helper
INFO - 2023-10-28 12:38:13 --> Helper loaded: file_helper
INFO - 2023-10-28 12:38:13 --> Helper loaded: html_helper
INFO - 2023-10-28 12:38:13 --> Helper loaded: text_helper
INFO - 2023-10-28 12:38:13 --> Helper loaded: form_helper
INFO - 2023-10-28 12:38:13 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:38:13 --> Helper loaded: security_helper
INFO - 2023-10-28 12:38:13 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:38:13 --> Database Driver Class Initialized
INFO - 2023-10-28 12:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:38:13 --> Parser Class Initialized
INFO - 2023-10-28 12:38:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:38:13 --> Pagination Class Initialized
INFO - 2023-10-28 12:38:13 --> Form Validation Class Initialized
INFO - 2023-10-28 12:38:13 --> Controller Class Initialized
INFO - 2023-10-28 12:38:13 --> Model Class Initialized
DEBUG - 2023-10-28 12:38:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:38:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:38:13 --> Model Class Initialized
DEBUG - 2023-10-28 12:38:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:38:13 --> Model Class Initialized
INFO - 2023-10-28 12:38:13 --> Final output sent to browser
DEBUG - 2023-10-28 12:38:13 --> Total execution time: 0.0214
ERROR - 2023-10-28 12:38:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:38:14 --> Config Class Initialized
INFO - 2023-10-28 12:38:14 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:38:14 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:38:14 --> Utf8 Class Initialized
INFO - 2023-10-28 12:38:14 --> URI Class Initialized
INFO - 2023-10-28 12:38:14 --> Router Class Initialized
INFO - 2023-10-28 12:38:14 --> Output Class Initialized
INFO - 2023-10-28 12:38:14 --> Security Class Initialized
DEBUG - 2023-10-28 12:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:38:14 --> Input Class Initialized
INFO - 2023-10-28 12:38:14 --> Language Class Initialized
INFO - 2023-10-28 12:38:14 --> Loader Class Initialized
INFO - 2023-10-28 12:38:14 --> Helper loaded: url_helper
INFO - 2023-10-28 12:38:14 --> Helper loaded: file_helper
INFO - 2023-10-28 12:38:14 --> Helper loaded: html_helper
INFO - 2023-10-28 12:38:14 --> Helper loaded: text_helper
INFO - 2023-10-28 12:38:14 --> Helper loaded: form_helper
INFO - 2023-10-28 12:38:14 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:38:14 --> Helper loaded: security_helper
INFO - 2023-10-28 12:38:14 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:38:14 --> Database Driver Class Initialized
INFO - 2023-10-28 12:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:38:14 --> Parser Class Initialized
INFO - 2023-10-28 12:38:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:38:14 --> Pagination Class Initialized
INFO - 2023-10-28 12:38:14 --> Form Validation Class Initialized
INFO - 2023-10-28 12:38:14 --> Controller Class Initialized
INFO - 2023-10-28 12:38:14 --> Model Class Initialized
DEBUG - 2023-10-28 12:38:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:38:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:38:14 --> Model Class Initialized
DEBUG - 2023-10-28 12:38:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:38:14 --> Model Class Initialized
INFO - 2023-10-28 12:38:14 --> Final output sent to browser
DEBUG - 2023-10-28 12:38:14 --> Total execution time: 0.0174
ERROR - 2023-10-28 12:38:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:38:14 --> Config Class Initialized
INFO - 2023-10-28 12:38:14 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:38:14 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:38:14 --> Utf8 Class Initialized
INFO - 2023-10-28 12:38:14 --> URI Class Initialized
INFO - 2023-10-28 12:38:14 --> Router Class Initialized
INFO - 2023-10-28 12:38:14 --> Output Class Initialized
INFO - 2023-10-28 12:38:14 --> Security Class Initialized
DEBUG - 2023-10-28 12:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:38:14 --> Input Class Initialized
INFO - 2023-10-28 12:38:14 --> Language Class Initialized
INFO - 2023-10-28 12:38:14 --> Loader Class Initialized
INFO - 2023-10-28 12:38:14 --> Helper loaded: url_helper
INFO - 2023-10-28 12:38:14 --> Helper loaded: file_helper
INFO - 2023-10-28 12:38:14 --> Helper loaded: html_helper
INFO - 2023-10-28 12:38:14 --> Helper loaded: text_helper
INFO - 2023-10-28 12:38:14 --> Helper loaded: form_helper
INFO - 2023-10-28 12:38:14 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:38:14 --> Helper loaded: security_helper
INFO - 2023-10-28 12:38:14 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:38:14 --> Database Driver Class Initialized
INFO - 2023-10-28 12:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:38:14 --> Parser Class Initialized
INFO - 2023-10-28 12:38:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:38:14 --> Pagination Class Initialized
INFO - 2023-10-28 12:38:14 --> Form Validation Class Initialized
INFO - 2023-10-28 12:38:14 --> Controller Class Initialized
INFO - 2023-10-28 12:38:14 --> Model Class Initialized
DEBUG - 2023-10-28 12:38:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:38:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:38:14 --> Model Class Initialized
DEBUG - 2023-10-28 12:38:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:38:14 --> Model Class Initialized
INFO - 2023-10-28 12:38:14 --> Final output sent to browser
DEBUG - 2023-10-28 12:38:14 --> Total execution time: 0.0185
ERROR - 2023-10-28 12:38:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:38:15 --> Config Class Initialized
INFO - 2023-10-28 12:38:15 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:38:15 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:38:15 --> Utf8 Class Initialized
INFO - 2023-10-28 12:38:15 --> URI Class Initialized
INFO - 2023-10-28 12:38:15 --> Router Class Initialized
INFO - 2023-10-28 12:38:15 --> Output Class Initialized
INFO - 2023-10-28 12:38:15 --> Security Class Initialized
DEBUG - 2023-10-28 12:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:38:15 --> Input Class Initialized
INFO - 2023-10-28 12:38:15 --> Language Class Initialized
INFO - 2023-10-28 12:38:15 --> Loader Class Initialized
INFO - 2023-10-28 12:38:15 --> Helper loaded: url_helper
INFO - 2023-10-28 12:38:15 --> Helper loaded: file_helper
INFO - 2023-10-28 12:38:15 --> Helper loaded: html_helper
INFO - 2023-10-28 12:38:15 --> Helper loaded: text_helper
INFO - 2023-10-28 12:38:15 --> Helper loaded: form_helper
INFO - 2023-10-28 12:38:15 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:38:15 --> Helper loaded: security_helper
INFO - 2023-10-28 12:38:15 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:38:15 --> Database Driver Class Initialized
INFO - 2023-10-28 12:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:38:15 --> Parser Class Initialized
INFO - 2023-10-28 12:38:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:38:15 --> Pagination Class Initialized
INFO - 2023-10-28 12:38:15 --> Form Validation Class Initialized
INFO - 2023-10-28 12:38:15 --> Controller Class Initialized
INFO - 2023-10-28 12:38:15 --> Model Class Initialized
DEBUG - 2023-10-28 12:38:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:38:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:38:15 --> Model Class Initialized
DEBUG - 2023-10-28 12:38:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:38:15 --> Model Class Initialized
INFO - 2023-10-28 12:38:15 --> Final output sent to browser
DEBUG - 2023-10-28 12:38:15 --> Total execution time: 0.0200
ERROR - 2023-10-28 12:38:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:38:26 --> Config Class Initialized
INFO - 2023-10-28 12:38:26 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:38:26 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:38:26 --> Utf8 Class Initialized
INFO - 2023-10-28 12:38:26 --> URI Class Initialized
INFO - 2023-10-28 12:38:26 --> Router Class Initialized
INFO - 2023-10-28 12:38:26 --> Output Class Initialized
INFO - 2023-10-28 12:38:26 --> Security Class Initialized
DEBUG - 2023-10-28 12:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:38:26 --> Input Class Initialized
INFO - 2023-10-28 12:38:26 --> Language Class Initialized
INFO - 2023-10-28 12:38:26 --> Loader Class Initialized
INFO - 2023-10-28 12:38:26 --> Helper loaded: url_helper
INFO - 2023-10-28 12:38:26 --> Helper loaded: file_helper
INFO - 2023-10-28 12:38:26 --> Helper loaded: html_helper
INFO - 2023-10-28 12:38:26 --> Helper loaded: text_helper
INFO - 2023-10-28 12:38:26 --> Helper loaded: form_helper
INFO - 2023-10-28 12:38:26 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:38:26 --> Helper loaded: security_helper
INFO - 2023-10-28 12:38:26 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:38:26 --> Database Driver Class Initialized
INFO - 2023-10-28 12:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:38:26 --> Parser Class Initialized
INFO - 2023-10-28 12:38:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:38:26 --> Pagination Class Initialized
INFO - 2023-10-28 12:38:26 --> Form Validation Class Initialized
INFO - 2023-10-28 12:38:26 --> Controller Class Initialized
INFO - 2023-10-28 12:38:26 --> Model Class Initialized
DEBUG - 2023-10-28 12:38:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:38:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:38:26 --> Model Class Initialized
DEBUG - 2023-10-28 12:38:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:38:26 --> Model Class Initialized
INFO - 2023-10-28 12:38:26 --> Model Class Initialized
INFO - 2023-10-28 12:38:26 --> Final output sent to browser
DEBUG - 2023-10-28 12:38:26 --> Total execution time: 0.0201
ERROR - 2023-10-28 12:38:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:38:28 --> Config Class Initialized
INFO - 2023-10-28 12:38:28 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:38:28 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:38:28 --> Utf8 Class Initialized
INFO - 2023-10-28 12:38:28 --> URI Class Initialized
INFO - 2023-10-28 12:38:28 --> Router Class Initialized
INFO - 2023-10-28 12:38:28 --> Output Class Initialized
INFO - 2023-10-28 12:38:28 --> Security Class Initialized
DEBUG - 2023-10-28 12:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:38:28 --> Input Class Initialized
INFO - 2023-10-28 12:38:28 --> Language Class Initialized
INFO - 2023-10-28 12:38:28 --> Loader Class Initialized
INFO - 2023-10-28 12:38:28 --> Helper loaded: url_helper
INFO - 2023-10-28 12:38:28 --> Helper loaded: file_helper
INFO - 2023-10-28 12:38:28 --> Helper loaded: html_helper
INFO - 2023-10-28 12:38:28 --> Helper loaded: text_helper
INFO - 2023-10-28 12:38:28 --> Helper loaded: form_helper
INFO - 2023-10-28 12:38:28 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:38:28 --> Helper loaded: security_helper
INFO - 2023-10-28 12:38:28 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:38:28 --> Database Driver Class Initialized
INFO - 2023-10-28 12:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:38:28 --> Parser Class Initialized
INFO - 2023-10-28 12:38:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:38:28 --> Pagination Class Initialized
INFO - 2023-10-28 12:38:28 --> Form Validation Class Initialized
INFO - 2023-10-28 12:38:28 --> Controller Class Initialized
INFO - 2023-10-28 12:38:28 --> Model Class Initialized
DEBUG - 2023-10-28 12:38:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:38:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:38:28 --> Model Class Initialized
DEBUG - 2023-10-28 12:38:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:38:28 --> Model Class Initialized
INFO - 2023-10-28 12:38:28 --> Final output sent to browser
DEBUG - 2023-10-28 12:38:28 --> Total execution time: 0.0229
ERROR - 2023-10-28 12:38:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:38:42 --> Config Class Initialized
INFO - 2023-10-28 12:38:42 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:38:42 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:38:42 --> Utf8 Class Initialized
INFO - 2023-10-28 12:38:42 --> URI Class Initialized
INFO - 2023-10-28 12:38:42 --> Router Class Initialized
INFO - 2023-10-28 12:38:42 --> Output Class Initialized
INFO - 2023-10-28 12:38:42 --> Security Class Initialized
DEBUG - 2023-10-28 12:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:38:42 --> Input Class Initialized
INFO - 2023-10-28 12:38:42 --> Language Class Initialized
INFO - 2023-10-28 12:38:42 --> Loader Class Initialized
INFO - 2023-10-28 12:38:42 --> Helper loaded: url_helper
INFO - 2023-10-28 12:38:42 --> Helper loaded: file_helper
INFO - 2023-10-28 12:38:42 --> Helper loaded: html_helper
INFO - 2023-10-28 12:38:42 --> Helper loaded: text_helper
INFO - 2023-10-28 12:38:42 --> Helper loaded: form_helper
INFO - 2023-10-28 12:38:42 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:38:42 --> Helper loaded: security_helper
INFO - 2023-10-28 12:38:42 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:38:42 --> Database Driver Class Initialized
INFO - 2023-10-28 12:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:38:42 --> Parser Class Initialized
INFO - 2023-10-28 12:38:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:38:42 --> Pagination Class Initialized
INFO - 2023-10-28 12:38:42 --> Form Validation Class Initialized
INFO - 2023-10-28 12:38:42 --> Controller Class Initialized
INFO - 2023-10-28 12:38:42 --> Model Class Initialized
DEBUG - 2023-10-28 12:38:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:38:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:38:42 --> Model Class Initialized
DEBUG - 2023-10-28 12:38:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:38:42 --> Model Class Initialized
INFO - 2023-10-28 12:38:42 --> Final output sent to browser
DEBUG - 2023-10-28 12:38:42 --> Total execution time: 0.0202
ERROR - 2023-10-28 12:38:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:38:42 --> Config Class Initialized
INFO - 2023-10-28 12:38:42 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:38:42 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:38:42 --> Utf8 Class Initialized
INFO - 2023-10-28 12:38:42 --> URI Class Initialized
INFO - 2023-10-28 12:38:42 --> Router Class Initialized
INFO - 2023-10-28 12:38:42 --> Output Class Initialized
INFO - 2023-10-28 12:38:42 --> Security Class Initialized
DEBUG - 2023-10-28 12:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:38:42 --> Input Class Initialized
INFO - 2023-10-28 12:38:42 --> Language Class Initialized
INFO - 2023-10-28 12:38:42 --> Loader Class Initialized
INFO - 2023-10-28 12:38:42 --> Helper loaded: url_helper
INFO - 2023-10-28 12:38:42 --> Helper loaded: file_helper
INFO - 2023-10-28 12:38:42 --> Helper loaded: html_helper
INFO - 2023-10-28 12:38:42 --> Helper loaded: text_helper
INFO - 2023-10-28 12:38:42 --> Helper loaded: form_helper
INFO - 2023-10-28 12:38:42 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:38:42 --> Helper loaded: security_helper
INFO - 2023-10-28 12:38:42 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:38:42 --> Database Driver Class Initialized
INFO - 2023-10-28 12:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:38:42 --> Parser Class Initialized
INFO - 2023-10-28 12:38:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:38:42 --> Pagination Class Initialized
INFO - 2023-10-28 12:38:42 --> Form Validation Class Initialized
INFO - 2023-10-28 12:38:42 --> Controller Class Initialized
INFO - 2023-10-28 12:38:42 --> Model Class Initialized
DEBUG - 2023-10-28 12:38:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:38:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:38:42 --> Model Class Initialized
DEBUG - 2023-10-28 12:38:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:38:42 --> Model Class Initialized
INFO - 2023-10-28 12:38:42 --> Final output sent to browser
DEBUG - 2023-10-28 12:38:42 --> Total execution time: 0.0193
ERROR - 2023-10-28 12:38:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:38:43 --> Config Class Initialized
INFO - 2023-10-28 12:38:43 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:38:43 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:38:43 --> Utf8 Class Initialized
INFO - 2023-10-28 12:38:43 --> URI Class Initialized
INFO - 2023-10-28 12:38:43 --> Router Class Initialized
INFO - 2023-10-28 12:38:43 --> Output Class Initialized
INFO - 2023-10-28 12:38:43 --> Security Class Initialized
DEBUG - 2023-10-28 12:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:38:43 --> Input Class Initialized
INFO - 2023-10-28 12:38:43 --> Language Class Initialized
INFO - 2023-10-28 12:38:43 --> Loader Class Initialized
INFO - 2023-10-28 12:38:43 --> Helper loaded: url_helper
INFO - 2023-10-28 12:38:43 --> Helper loaded: file_helper
INFO - 2023-10-28 12:38:43 --> Helper loaded: html_helper
INFO - 2023-10-28 12:38:43 --> Helper loaded: text_helper
INFO - 2023-10-28 12:38:43 --> Helper loaded: form_helper
INFO - 2023-10-28 12:38:43 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:38:43 --> Helper loaded: security_helper
INFO - 2023-10-28 12:38:43 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:38:43 --> Database Driver Class Initialized
INFO - 2023-10-28 12:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:38:43 --> Parser Class Initialized
INFO - 2023-10-28 12:38:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:38:43 --> Pagination Class Initialized
INFO - 2023-10-28 12:38:43 --> Form Validation Class Initialized
INFO - 2023-10-28 12:38:43 --> Controller Class Initialized
INFO - 2023-10-28 12:38:43 --> Model Class Initialized
DEBUG - 2023-10-28 12:38:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:38:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:38:43 --> Model Class Initialized
DEBUG - 2023-10-28 12:38:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:38:43 --> Model Class Initialized
INFO - 2023-10-28 12:38:43 --> Final output sent to browser
DEBUG - 2023-10-28 12:38:43 --> Total execution time: 0.0188
ERROR - 2023-10-28 12:38:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:38:43 --> Config Class Initialized
INFO - 2023-10-28 12:38:43 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:38:43 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:38:43 --> Utf8 Class Initialized
INFO - 2023-10-28 12:38:43 --> URI Class Initialized
INFO - 2023-10-28 12:38:43 --> Router Class Initialized
INFO - 2023-10-28 12:38:43 --> Output Class Initialized
INFO - 2023-10-28 12:38:43 --> Security Class Initialized
DEBUG - 2023-10-28 12:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:38:43 --> Input Class Initialized
INFO - 2023-10-28 12:38:43 --> Language Class Initialized
INFO - 2023-10-28 12:38:43 --> Loader Class Initialized
INFO - 2023-10-28 12:38:43 --> Helper loaded: url_helper
INFO - 2023-10-28 12:38:43 --> Helper loaded: file_helper
INFO - 2023-10-28 12:38:43 --> Helper loaded: html_helper
INFO - 2023-10-28 12:38:43 --> Helper loaded: text_helper
INFO - 2023-10-28 12:38:43 --> Helper loaded: form_helper
INFO - 2023-10-28 12:38:43 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:38:43 --> Helper loaded: security_helper
INFO - 2023-10-28 12:38:43 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:38:43 --> Database Driver Class Initialized
INFO - 2023-10-28 12:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:38:43 --> Parser Class Initialized
INFO - 2023-10-28 12:38:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:38:43 --> Pagination Class Initialized
INFO - 2023-10-28 12:38:43 --> Form Validation Class Initialized
INFO - 2023-10-28 12:38:43 --> Controller Class Initialized
INFO - 2023-10-28 12:38:43 --> Model Class Initialized
DEBUG - 2023-10-28 12:38:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:38:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:38:43 --> Model Class Initialized
DEBUG - 2023-10-28 12:38:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:38:43 --> Model Class Initialized
INFO - 2023-10-28 12:38:43 --> Final output sent to browser
DEBUG - 2023-10-28 12:38:43 --> Total execution time: 0.0244
ERROR - 2023-10-28 12:38:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:38:44 --> Config Class Initialized
INFO - 2023-10-28 12:38:44 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:38:44 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:38:44 --> Utf8 Class Initialized
INFO - 2023-10-28 12:38:44 --> URI Class Initialized
INFO - 2023-10-28 12:38:44 --> Router Class Initialized
INFO - 2023-10-28 12:38:44 --> Output Class Initialized
INFO - 2023-10-28 12:38:44 --> Security Class Initialized
DEBUG - 2023-10-28 12:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:38:44 --> Input Class Initialized
INFO - 2023-10-28 12:38:44 --> Language Class Initialized
INFO - 2023-10-28 12:38:44 --> Loader Class Initialized
INFO - 2023-10-28 12:38:44 --> Helper loaded: url_helper
INFO - 2023-10-28 12:38:44 --> Helper loaded: file_helper
INFO - 2023-10-28 12:38:44 --> Helper loaded: html_helper
INFO - 2023-10-28 12:38:44 --> Helper loaded: text_helper
INFO - 2023-10-28 12:38:44 --> Helper loaded: form_helper
INFO - 2023-10-28 12:38:44 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:38:44 --> Helper loaded: security_helper
INFO - 2023-10-28 12:38:44 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:38:44 --> Database Driver Class Initialized
INFO - 2023-10-28 12:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:38:44 --> Parser Class Initialized
INFO - 2023-10-28 12:38:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:38:44 --> Pagination Class Initialized
INFO - 2023-10-28 12:38:44 --> Form Validation Class Initialized
INFO - 2023-10-28 12:38:44 --> Controller Class Initialized
INFO - 2023-10-28 12:38:44 --> Model Class Initialized
DEBUG - 2023-10-28 12:38:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:38:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:38:44 --> Model Class Initialized
DEBUG - 2023-10-28 12:38:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:38:44 --> Model Class Initialized
INFO - 2023-10-28 12:38:44 --> Final output sent to browser
DEBUG - 2023-10-28 12:38:44 --> Total execution time: 0.0171
ERROR - 2023-10-28 12:38:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:38:45 --> Config Class Initialized
INFO - 2023-10-28 12:38:45 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:38:45 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:38:45 --> Utf8 Class Initialized
INFO - 2023-10-28 12:38:45 --> URI Class Initialized
INFO - 2023-10-28 12:38:45 --> Router Class Initialized
INFO - 2023-10-28 12:38:45 --> Output Class Initialized
INFO - 2023-10-28 12:38:45 --> Security Class Initialized
DEBUG - 2023-10-28 12:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:38:45 --> Input Class Initialized
INFO - 2023-10-28 12:38:45 --> Language Class Initialized
INFO - 2023-10-28 12:38:45 --> Loader Class Initialized
INFO - 2023-10-28 12:38:45 --> Helper loaded: url_helper
INFO - 2023-10-28 12:38:45 --> Helper loaded: file_helper
INFO - 2023-10-28 12:38:45 --> Helper loaded: html_helper
INFO - 2023-10-28 12:38:45 --> Helper loaded: text_helper
INFO - 2023-10-28 12:38:45 --> Helper loaded: form_helper
INFO - 2023-10-28 12:38:45 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:38:45 --> Helper loaded: security_helper
INFO - 2023-10-28 12:38:45 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:38:45 --> Database Driver Class Initialized
INFO - 2023-10-28 12:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:38:45 --> Parser Class Initialized
INFO - 2023-10-28 12:38:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:38:45 --> Pagination Class Initialized
INFO - 2023-10-28 12:38:45 --> Form Validation Class Initialized
INFO - 2023-10-28 12:38:45 --> Controller Class Initialized
INFO - 2023-10-28 12:38:45 --> Model Class Initialized
DEBUG - 2023-10-28 12:38:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:38:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:38:45 --> Model Class Initialized
DEBUG - 2023-10-28 12:38:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:38:45 --> Model Class Initialized
INFO - 2023-10-28 12:38:45 --> Final output sent to browser
DEBUG - 2023-10-28 12:38:45 --> Total execution time: 0.0182
ERROR - 2023-10-28 12:38:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:38:45 --> Config Class Initialized
INFO - 2023-10-28 12:38:45 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:38:45 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:38:45 --> Utf8 Class Initialized
INFO - 2023-10-28 12:38:45 --> URI Class Initialized
INFO - 2023-10-28 12:38:45 --> Router Class Initialized
INFO - 2023-10-28 12:38:45 --> Output Class Initialized
INFO - 2023-10-28 12:38:45 --> Security Class Initialized
DEBUG - 2023-10-28 12:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:38:45 --> Input Class Initialized
INFO - 2023-10-28 12:38:45 --> Language Class Initialized
INFO - 2023-10-28 12:38:45 --> Loader Class Initialized
INFO - 2023-10-28 12:38:45 --> Helper loaded: url_helper
INFO - 2023-10-28 12:38:45 --> Helper loaded: file_helper
INFO - 2023-10-28 12:38:45 --> Helper loaded: html_helper
INFO - 2023-10-28 12:38:45 --> Helper loaded: text_helper
INFO - 2023-10-28 12:38:45 --> Helper loaded: form_helper
INFO - 2023-10-28 12:38:45 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:38:45 --> Helper loaded: security_helper
INFO - 2023-10-28 12:38:45 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:38:45 --> Database Driver Class Initialized
INFO - 2023-10-28 12:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:38:45 --> Parser Class Initialized
INFO - 2023-10-28 12:38:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:38:45 --> Pagination Class Initialized
INFO - 2023-10-28 12:38:45 --> Form Validation Class Initialized
INFO - 2023-10-28 12:38:45 --> Controller Class Initialized
INFO - 2023-10-28 12:38:45 --> Model Class Initialized
DEBUG - 2023-10-28 12:38:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:38:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:38:45 --> Model Class Initialized
DEBUG - 2023-10-28 12:38:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:38:45 --> Model Class Initialized
INFO - 2023-10-28 12:38:45 --> Final output sent to browser
DEBUG - 2023-10-28 12:38:45 --> Total execution time: 0.0181
ERROR - 2023-10-28 12:38:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:38:48 --> Config Class Initialized
INFO - 2023-10-28 12:38:48 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:38:48 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:38:48 --> Utf8 Class Initialized
INFO - 2023-10-28 12:38:48 --> URI Class Initialized
INFO - 2023-10-28 12:38:48 --> Router Class Initialized
INFO - 2023-10-28 12:38:48 --> Output Class Initialized
INFO - 2023-10-28 12:38:48 --> Security Class Initialized
DEBUG - 2023-10-28 12:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:38:48 --> Input Class Initialized
INFO - 2023-10-28 12:38:48 --> Language Class Initialized
INFO - 2023-10-28 12:38:48 --> Loader Class Initialized
INFO - 2023-10-28 12:38:48 --> Helper loaded: url_helper
INFO - 2023-10-28 12:38:48 --> Helper loaded: file_helper
INFO - 2023-10-28 12:38:48 --> Helper loaded: html_helper
INFO - 2023-10-28 12:38:48 --> Helper loaded: text_helper
INFO - 2023-10-28 12:38:48 --> Helper loaded: form_helper
INFO - 2023-10-28 12:38:48 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:38:48 --> Helper loaded: security_helper
INFO - 2023-10-28 12:38:48 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:38:48 --> Database Driver Class Initialized
INFO - 2023-10-28 12:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:38:48 --> Parser Class Initialized
INFO - 2023-10-28 12:38:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:38:48 --> Pagination Class Initialized
INFO - 2023-10-28 12:38:48 --> Form Validation Class Initialized
INFO - 2023-10-28 12:38:48 --> Controller Class Initialized
INFO - 2023-10-28 12:38:48 --> Model Class Initialized
DEBUG - 2023-10-28 12:38:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:38:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:38:48 --> Model Class Initialized
DEBUG - 2023-10-28 12:38:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:38:48 --> Model Class Initialized
INFO - 2023-10-28 12:38:48 --> Model Class Initialized
INFO - 2023-10-28 12:38:48 --> Final output sent to browser
DEBUG - 2023-10-28 12:38:48 --> Total execution time: 0.0246
ERROR - 2023-10-28 12:38:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:38:50 --> Config Class Initialized
INFO - 2023-10-28 12:38:50 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:38:50 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:38:50 --> Utf8 Class Initialized
INFO - 2023-10-28 12:38:50 --> URI Class Initialized
INFO - 2023-10-28 12:38:50 --> Router Class Initialized
INFO - 2023-10-28 12:38:50 --> Output Class Initialized
INFO - 2023-10-28 12:38:50 --> Security Class Initialized
DEBUG - 2023-10-28 12:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:38:50 --> Input Class Initialized
INFO - 2023-10-28 12:38:50 --> Language Class Initialized
INFO - 2023-10-28 12:38:50 --> Loader Class Initialized
INFO - 2023-10-28 12:38:50 --> Helper loaded: url_helper
INFO - 2023-10-28 12:38:50 --> Helper loaded: file_helper
INFO - 2023-10-28 12:38:50 --> Helper loaded: html_helper
INFO - 2023-10-28 12:38:50 --> Helper loaded: text_helper
INFO - 2023-10-28 12:38:50 --> Helper loaded: form_helper
INFO - 2023-10-28 12:38:50 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:38:50 --> Helper loaded: security_helper
INFO - 2023-10-28 12:38:50 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:38:50 --> Database Driver Class Initialized
INFO - 2023-10-28 12:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:38:50 --> Parser Class Initialized
INFO - 2023-10-28 12:38:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:38:50 --> Pagination Class Initialized
INFO - 2023-10-28 12:38:50 --> Form Validation Class Initialized
INFO - 2023-10-28 12:38:50 --> Controller Class Initialized
INFO - 2023-10-28 12:38:50 --> Model Class Initialized
DEBUG - 2023-10-28 12:38:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:38:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:38:50 --> Model Class Initialized
DEBUG - 2023-10-28 12:38:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:38:50 --> Model Class Initialized
INFO - 2023-10-28 12:38:50 --> Final output sent to browser
DEBUG - 2023-10-28 12:38:50 --> Total execution time: 0.0187
ERROR - 2023-10-28 12:39:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:39:13 --> Config Class Initialized
INFO - 2023-10-28 12:39:13 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:39:13 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:39:13 --> Utf8 Class Initialized
INFO - 2023-10-28 12:39:13 --> URI Class Initialized
INFO - 2023-10-28 12:39:13 --> Router Class Initialized
INFO - 2023-10-28 12:39:13 --> Output Class Initialized
INFO - 2023-10-28 12:39:13 --> Security Class Initialized
DEBUG - 2023-10-28 12:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:39:13 --> Input Class Initialized
INFO - 2023-10-28 12:39:13 --> Language Class Initialized
INFO - 2023-10-28 12:39:13 --> Loader Class Initialized
INFO - 2023-10-28 12:39:13 --> Helper loaded: url_helper
INFO - 2023-10-28 12:39:13 --> Helper loaded: file_helper
INFO - 2023-10-28 12:39:13 --> Helper loaded: html_helper
INFO - 2023-10-28 12:39:13 --> Helper loaded: text_helper
INFO - 2023-10-28 12:39:13 --> Helper loaded: form_helper
INFO - 2023-10-28 12:39:13 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:39:13 --> Helper loaded: security_helper
INFO - 2023-10-28 12:39:13 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:39:13 --> Database Driver Class Initialized
INFO - 2023-10-28 12:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:39:13 --> Parser Class Initialized
INFO - 2023-10-28 12:39:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:39:13 --> Pagination Class Initialized
INFO - 2023-10-28 12:39:13 --> Form Validation Class Initialized
INFO - 2023-10-28 12:39:13 --> Controller Class Initialized
INFO - 2023-10-28 12:39:13 --> Model Class Initialized
DEBUG - 2023-10-28 12:39:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:39:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:39:13 --> Model Class Initialized
DEBUG - 2023-10-28 12:39:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:39:13 --> Model Class Initialized
INFO - 2023-10-28 12:39:13 --> Final output sent to browser
DEBUG - 2023-10-28 12:39:13 --> Total execution time: 0.0230
ERROR - 2023-10-28 12:39:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:39:13 --> Config Class Initialized
INFO - 2023-10-28 12:39:13 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:39:13 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:39:13 --> Utf8 Class Initialized
INFO - 2023-10-28 12:39:13 --> URI Class Initialized
INFO - 2023-10-28 12:39:13 --> Router Class Initialized
INFO - 2023-10-28 12:39:13 --> Output Class Initialized
INFO - 2023-10-28 12:39:13 --> Security Class Initialized
DEBUG - 2023-10-28 12:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:39:13 --> Input Class Initialized
INFO - 2023-10-28 12:39:13 --> Language Class Initialized
INFO - 2023-10-28 12:39:13 --> Loader Class Initialized
INFO - 2023-10-28 12:39:13 --> Helper loaded: url_helper
INFO - 2023-10-28 12:39:13 --> Helper loaded: file_helper
INFO - 2023-10-28 12:39:13 --> Helper loaded: html_helper
INFO - 2023-10-28 12:39:13 --> Helper loaded: text_helper
INFO - 2023-10-28 12:39:13 --> Helper loaded: form_helper
INFO - 2023-10-28 12:39:13 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:39:13 --> Helper loaded: security_helper
INFO - 2023-10-28 12:39:13 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:39:13 --> Database Driver Class Initialized
INFO - 2023-10-28 12:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:39:13 --> Parser Class Initialized
INFO - 2023-10-28 12:39:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:39:13 --> Pagination Class Initialized
INFO - 2023-10-28 12:39:13 --> Form Validation Class Initialized
INFO - 2023-10-28 12:39:13 --> Controller Class Initialized
INFO - 2023-10-28 12:39:13 --> Model Class Initialized
DEBUG - 2023-10-28 12:39:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:39:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:39:13 --> Model Class Initialized
DEBUG - 2023-10-28 12:39:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:39:13 --> Model Class Initialized
INFO - 2023-10-28 12:39:13 --> Final output sent to browser
DEBUG - 2023-10-28 12:39:13 --> Total execution time: 0.0184
ERROR - 2023-10-28 12:39:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:39:14 --> Config Class Initialized
INFO - 2023-10-28 12:39:14 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:39:14 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:39:14 --> Utf8 Class Initialized
INFO - 2023-10-28 12:39:14 --> URI Class Initialized
INFO - 2023-10-28 12:39:14 --> Router Class Initialized
INFO - 2023-10-28 12:39:14 --> Output Class Initialized
INFO - 2023-10-28 12:39:14 --> Security Class Initialized
DEBUG - 2023-10-28 12:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:39:14 --> Input Class Initialized
INFO - 2023-10-28 12:39:14 --> Language Class Initialized
INFO - 2023-10-28 12:39:14 --> Loader Class Initialized
INFO - 2023-10-28 12:39:14 --> Helper loaded: url_helper
INFO - 2023-10-28 12:39:14 --> Helper loaded: file_helper
INFO - 2023-10-28 12:39:14 --> Helper loaded: html_helper
INFO - 2023-10-28 12:39:14 --> Helper loaded: text_helper
INFO - 2023-10-28 12:39:14 --> Helper loaded: form_helper
INFO - 2023-10-28 12:39:14 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:39:14 --> Helper loaded: security_helper
INFO - 2023-10-28 12:39:14 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:39:14 --> Database Driver Class Initialized
INFO - 2023-10-28 12:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:39:14 --> Parser Class Initialized
INFO - 2023-10-28 12:39:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:39:14 --> Pagination Class Initialized
INFO - 2023-10-28 12:39:14 --> Form Validation Class Initialized
INFO - 2023-10-28 12:39:14 --> Controller Class Initialized
INFO - 2023-10-28 12:39:14 --> Model Class Initialized
DEBUG - 2023-10-28 12:39:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:39:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:39:14 --> Model Class Initialized
DEBUG - 2023-10-28 12:39:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:39:14 --> Model Class Initialized
INFO - 2023-10-28 12:39:14 --> Final output sent to browser
DEBUG - 2023-10-28 12:39:14 --> Total execution time: 0.0177
ERROR - 2023-10-28 12:39:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:39:14 --> Config Class Initialized
INFO - 2023-10-28 12:39:14 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:39:14 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:39:14 --> Utf8 Class Initialized
INFO - 2023-10-28 12:39:14 --> URI Class Initialized
INFO - 2023-10-28 12:39:14 --> Router Class Initialized
INFO - 2023-10-28 12:39:14 --> Output Class Initialized
INFO - 2023-10-28 12:39:14 --> Security Class Initialized
DEBUG - 2023-10-28 12:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:39:14 --> Input Class Initialized
INFO - 2023-10-28 12:39:14 --> Language Class Initialized
INFO - 2023-10-28 12:39:14 --> Loader Class Initialized
INFO - 2023-10-28 12:39:14 --> Helper loaded: url_helper
INFO - 2023-10-28 12:39:14 --> Helper loaded: file_helper
INFO - 2023-10-28 12:39:14 --> Helper loaded: html_helper
INFO - 2023-10-28 12:39:14 --> Helper loaded: text_helper
INFO - 2023-10-28 12:39:14 --> Helper loaded: form_helper
INFO - 2023-10-28 12:39:14 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:39:14 --> Helper loaded: security_helper
INFO - 2023-10-28 12:39:14 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:39:14 --> Database Driver Class Initialized
INFO - 2023-10-28 12:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:39:14 --> Parser Class Initialized
INFO - 2023-10-28 12:39:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:39:14 --> Pagination Class Initialized
INFO - 2023-10-28 12:39:14 --> Form Validation Class Initialized
INFO - 2023-10-28 12:39:14 --> Controller Class Initialized
INFO - 2023-10-28 12:39:14 --> Model Class Initialized
DEBUG - 2023-10-28 12:39:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:39:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:39:14 --> Model Class Initialized
DEBUG - 2023-10-28 12:39:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:39:14 --> Model Class Initialized
INFO - 2023-10-28 12:39:14 --> Final output sent to browser
DEBUG - 2023-10-28 12:39:14 --> Total execution time: 0.0238
ERROR - 2023-10-28 12:39:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:39:15 --> Config Class Initialized
INFO - 2023-10-28 12:39:15 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:39:15 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:39:15 --> Utf8 Class Initialized
INFO - 2023-10-28 12:39:15 --> URI Class Initialized
INFO - 2023-10-28 12:39:15 --> Router Class Initialized
INFO - 2023-10-28 12:39:15 --> Output Class Initialized
INFO - 2023-10-28 12:39:15 --> Security Class Initialized
DEBUG - 2023-10-28 12:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:39:15 --> Input Class Initialized
INFO - 2023-10-28 12:39:15 --> Language Class Initialized
INFO - 2023-10-28 12:39:15 --> Loader Class Initialized
INFO - 2023-10-28 12:39:15 --> Helper loaded: url_helper
INFO - 2023-10-28 12:39:15 --> Helper loaded: file_helper
INFO - 2023-10-28 12:39:15 --> Helper loaded: html_helper
INFO - 2023-10-28 12:39:15 --> Helper loaded: text_helper
INFO - 2023-10-28 12:39:15 --> Helper loaded: form_helper
INFO - 2023-10-28 12:39:15 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:39:15 --> Helper loaded: security_helper
INFO - 2023-10-28 12:39:15 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:39:15 --> Database Driver Class Initialized
INFO - 2023-10-28 12:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:39:15 --> Parser Class Initialized
INFO - 2023-10-28 12:39:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:39:15 --> Pagination Class Initialized
INFO - 2023-10-28 12:39:15 --> Form Validation Class Initialized
INFO - 2023-10-28 12:39:15 --> Controller Class Initialized
INFO - 2023-10-28 12:39:15 --> Model Class Initialized
DEBUG - 2023-10-28 12:39:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:39:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:39:15 --> Model Class Initialized
DEBUG - 2023-10-28 12:39:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:39:15 --> Model Class Initialized
INFO - 2023-10-28 12:39:15 --> Final output sent to browser
DEBUG - 2023-10-28 12:39:15 --> Total execution time: 0.0175
ERROR - 2023-10-28 12:39:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:39:17 --> Config Class Initialized
INFO - 2023-10-28 12:39:17 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:39:17 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:39:17 --> Utf8 Class Initialized
INFO - 2023-10-28 12:39:17 --> URI Class Initialized
INFO - 2023-10-28 12:39:17 --> Router Class Initialized
INFO - 2023-10-28 12:39:17 --> Output Class Initialized
INFO - 2023-10-28 12:39:17 --> Security Class Initialized
DEBUG - 2023-10-28 12:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:39:17 --> Input Class Initialized
INFO - 2023-10-28 12:39:17 --> Language Class Initialized
INFO - 2023-10-28 12:39:17 --> Loader Class Initialized
INFO - 2023-10-28 12:39:17 --> Helper loaded: url_helper
INFO - 2023-10-28 12:39:17 --> Helper loaded: file_helper
INFO - 2023-10-28 12:39:17 --> Helper loaded: html_helper
INFO - 2023-10-28 12:39:17 --> Helper loaded: text_helper
INFO - 2023-10-28 12:39:17 --> Helper loaded: form_helper
INFO - 2023-10-28 12:39:17 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:39:17 --> Helper loaded: security_helper
INFO - 2023-10-28 12:39:17 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:39:17 --> Database Driver Class Initialized
INFO - 2023-10-28 12:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:39:17 --> Parser Class Initialized
INFO - 2023-10-28 12:39:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:39:17 --> Pagination Class Initialized
INFO - 2023-10-28 12:39:17 --> Form Validation Class Initialized
INFO - 2023-10-28 12:39:17 --> Controller Class Initialized
INFO - 2023-10-28 12:39:17 --> Model Class Initialized
DEBUG - 2023-10-28 12:39:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:39:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:39:17 --> Model Class Initialized
DEBUG - 2023-10-28 12:39:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:39:17 --> Model Class Initialized
INFO - 2023-10-28 12:39:17 --> Model Class Initialized
INFO - 2023-10-28 12:39:17 --> Final output sent to browser
DEBUG - 2023-10-28 12:39:17 --> Total execution time: 0.0214
ERROR - 2023-10-28 12:39:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:39:19 --> Config Class Initialized
INFO - 2023-10-28 12:39:19 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:39:19 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:39:19 --> Utf8 Class Initialized
INFO - 2023-10-28 12:39:19 --> URI Class Initialized
INFO - 2023-10-28 12:39:19 --> Router Class Initialized
INFO - 2023-10-28 12:39:19 --> Output Class Initialized
INFO - 2023-10-28 12:39:19 --> Security Class Initialized
DEBUG - 2023-10-28 12:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:39:19 --> Input Class Initialized
INFO - 2023-10-28 12:39:19 --> Language Class Initialized
INFO - 2023-10-28 12:39:19 --> Loader Class Initialized
INFO - 2023-10-28 12:39:19 --> Helper loaded: url_helper
INFO - 2023-10-28 12:39:19 --> Helper loaded: file_helper
INFO - 2023-10-28 12:39:19 --> Helper loaded: html_helper
INFO - 2023-10-28 12:39:19 --> Helper loaded: text_helper
INFO - 2023-10-28 12:39:19 --> Helper loaded: form_helper
INFO - 2023-10-28 12:39:19 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:39:19 --> Helper loaded: security_helper
INFO - 2023-10-28 12:39:19 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:39:19 --> Database Driver Class Initialized
INFO - 2023-10-28 12:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:39:19 --> Parser Class Initialized
INFO - 2023-10-28 12:39:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:39:19 --> Pagination Class Initialized
INFO - 2023-10-28 12:39:19 --> Form Validation Class Initialized
INFO - 2023-10-28 12:39:19 --> Controller Class Initialized
INFO - 2023-10-28 12:39:19 --> Model Class Initialized
DEBUG - 2023-10-28 12:39:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:39:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:39:19 --> Model Class Initialized
DEBUG - 2023-10-28 12:39:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:39:19 --> Model Class Initialized
INFO - 2023-10-28 12:39:19 --> Final output sent to browser
DEBUG - 2023-10-28 12:39:19 --> Total execution time: 0.0232
ERROR - 2023-10-28 12:40:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:40:02 --> Config Class Initialized
INFO - 2023-10-28 12:40:02 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:40:02 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:40:02 --> Utf8 Class Initialized
INFO - 2023-10-28 12:40:02 --> URI Class Initialized
INFO - 2023-10-28 12:40:02 --> Router Class Initialized
INFO - 2023-10-28 12:40:02 --> Output Class Initialized
INFO - 2023-10-28 12:40:02 --> Security Class Initialized
DEBUG - 2023-10-28 12:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:40:02 --> Input Class Initialized
INFO - 2023-10-28 12:40:02 --> Language Class Initialized
INFO - 2023-10-28 12:40:02 --> Loader Class Initialized
INFO - 2023-10-28 12:40:02 --> Helper loaded: url_helper
INFO - 2023-10-28 12:40:02 --> Helper loaded: file_helper
INFO - 2023-10-28 12:40:02 --> Helper loaded: html_helper
INFO - 2023-10-28 12:40:02 --> Helper loaded: text_helper
INFO - 2023-10-28 12:40:02 --> Helper loaded: form_helper
INFO - 2023-10-28 12:40:02 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:40:02 --> Helper loaded: security_helper
INFO - 2023-10-28 12:40:02 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:40:02 --> Database Driver Class Initialized
INFO - 2023-10-28 12:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:40:02 --> Parser Class Initialized
INFO - 2023-10-28 12:40:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:40:02 --> Pagination Class Initialized
INFO - 2023-10-28 12:40:02 --> Form Validation Class Initialized
INFO - 2023-10-28 12:40:02 --> Controller Class Initialized
INFO - 2023-10-28 12:40:02 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:40:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:02 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:02 --> Model Class Initialized
INFO - 2023-10-28 12:40:02 --> Final output sent to browser
DEBUG - 2023-10-28 12:40:02 --> Total execution time: 0.0217
ERROR - 2023-10-28 12:40:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:40:02 --> Config Class Initialized
INFO - 2023-10-28 12:40:02 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:40:02 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:40:02 --> Utf8 Class Initialized
INFO - 2023-10-28 12:40:02 --> URI Class Initialized
INFO - 2023-10-28 12:40:02 --> Router Class Initialized
INFO - 2023-10-28 12:40:02 --> Output Class Initialized
INFO - 2023-10-28 12:40:02 --> Security Class Initialized
DEBUG - 2023-10-28 12:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:40:02 --> Input Class Initialized
INFO - 2023-10-28 12:40:02 --> Language Class Initialized
INFO - 2023-10-28 12:40:02 --> Loader Class Initialized
INFO - 2023-10-28 12:40:02 --> Helper loaded: url_helper
INFO - 2023-10-28 12:40:02 --> Helper loaded: file_helper
INFO - 2023-10-28 12:40:02 --> Helper loaded: html_helper
INFO - 2023-10-28 12:40:02 --> Helper loaded: text_helper
INFO - 2023-10-28 12:40:02 --> Helper loaded: form_helper
INFO - 2023-10-28 12:40:02 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:40:02 --> Helper loaded: security_helper
INFO - 2023-10-28 12:40:02 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:40:02 --> Database Driver Class Initialized
INFO - 2023-10-28 12:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:40:02 --> Parser Class Initialized
INFO - 2023-10-28 12:40:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:40:02 --> Pagination Class Initialized
INFO - 2023-10-28 12:40:02 --> Form Validation Class Initialized
INFO - 2023-10-28 12:40:02 --> Controller Class Initialized
INFO - 2023-10-28 12:40:02 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:40:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:02 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:02 --> Model Class Initialized
INFO - 2023-10-28 12:40:02 --> Final output sent to browser
DEBUG - 2023-10-28 12:40:02 --> Total execution time: 0.0183
ERROR - 2023-10-28 12:40:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:40:03 --> Config Class Initialized
INFO - 2023-10-28 12:40:03 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:40:03 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:40:03 --> Utf8 Class Initialized
INFO - 2023-10-28 12:40:03 --> URI Class Initialized
INFO - 2023-10-28 12:40:03 --> Router Class Initialized
INFO - 2023-10-28 12:40:03 --> Output Class Initialized
INFO - 2023-10-28 12:40:03 --> Security Class Initialized
DEBUG - 2023-10-28 12:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:40:03 --> Input Class Initialized
INFO - 2023-10-28 12:40:03 --> Language Class Initialized
INFO - 2023-10-28 12:40:03 --> Loader Class Initialized
INFO - 2023-10-28 12:40:03 --> Helper loaded: url_helper
INFO - 2023-10-28 12:40:03 --> Helper loaded: file_helper
INFO - 2023-10-28 12:40:03 --> Helper loaded: html_helper
INFO - 2023-10-28 12:40:03 --> Helper loaded: text_helper
INFO - 2023-10-28 12:40:03 --> Helper loaded: form_helper
INFO - 2023-10-28 12:40:03 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:40:03 --> Helper loaded: security_helper
INFO - 2023-10-28 12:40:03 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:40:03 --> Database Driver Class Initialized
INFO - 2023-10-28 12:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:40:03 --> Parser Class Initialized
INFO - 2023-10-28 12:40:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:40:03 --> Pagination Class Initialized
INFO - 2023-10-28 12:40:03 --> Form Validation Class Initialized
INFO - 2023-10-28 12:40:03 --> Controller Class Initialized
INFO - 2023-10-28 12:40:03 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:40:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:03 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:03 --> Model Class Initialized
INFO - 2023-10-28 12:40:03 --> Final output sent to browser
DEBUG - 2023-10-28 12:40:03 --> Total execution time: 0.0186
ERROR - 2023-10-28 12:40:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:40:03 --> Config Class Initialized
INFO - 2023-10-28 12:40:03 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:40:03 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:40:03 --> Utf8 Class Initialized
INFO - 2023-10-28 12:40:03 --> URI Class Initialized
INFO - 2023-10-28 12:40:03 --> Router Class Initialized
INFO - 2023-10-28 12:40:03 --> Output Class Initialized
INFO - 2023-10-28 12:40:03 --> Security Class Initialized
DEBUG - 2023-10-28 12:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:40:03 --> Input Class Initialized
INFO - 2023-10-28 12:40:03 --> Language Class Initialized
INFO - 2023-10-28 12:40:03 --> Loader Class Initialized
INFO - 2023-10-28 12:40:03 --> Helper loaded: url_helper
INFO - 2023-10-28 12:40:03 --> Helper loaded: file_helper
INFO - 2023-10-28 12:40:03 --> Helper loaded: html_helper
INFO - 2023-10-28 12:40:03 --> Helper loaded: text_helper
INFO - 2023-10-28 12:40:03 --> Helper loaded: form_helper
INFO - 2023-10-28 12:40:03 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:40:03 --> Helper loaded: security_helper
INFO - 2023-10-28 12:40:03 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:40:03 --> Database Driver Class Initialized
INFO - 2023-10-28 12:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:40:03 --> Parser Class Initialized
INFO - 2023-10-28 12:40:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:40:03 --> Pagination Class Initialized
INFO - 2023-10-28 12:40:03 --> Form Validation Class Initialized
INFO - 2023-10-28 12:40:03 --> Controller Class Initialized
INFO - 2023-10-28 12:40:03 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:40:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:03 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:03 --> Model Class Initialized
INFO - 2023-10-28 12:40:03 --> Final output sent to browser
DEBUG - 2023-10-28 12:40:03 --> Total execution time: 0.0184
ERROR - 2023-10-28 12:40:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:40:04 --> Config Class Initialized
INFO - 2023-10-28 12:40:04 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:40:04 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:40:04 --> Utf8 Class Initialized
INFO - 2023-10-28 12:40:04 --> URI Class Initialized
INFO - 2023-10-28 12:40:04 --> Router Class Initialized
INFO - 2023-10-28 12:40:04 --> Output Class Initialized
INFO - 2023-10-28 12:40:04 --> Security Class Initialized
DEBUG - 2023-10-28 12:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:40:04 --> Input Class Initialized
INFO - 2023-10-28 12:40:04 --> Language Class Initialized
INFO - 2023-10-28 12:40:04 --> Loader Class Initialized
INFO - 2023-10-28 12:40:04 --> Helper loaded: url_helper
INFO - 2023-10-28 12:40:04 --> Helper loaded: file_helper
INFO - 2023-10-28 12:40:04 --> Helper loaded: html_helper
INFO - 2023-10-28 12:40:04 --> Helper loaded: text_helper
INFO - 2023-10-28 12:40:04 --> Helper loaded: form_helper
INFO - 2023-10-28 12:40:04 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:40:04 --> Helper loaded: security_helper
INFO - 2023-10-28 12:40:04 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:40:04 --> Database Driver Class Initialized
INFO - 2023-10-28 12:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:40:04 --> Parser Class Initialized
INFO - 2023-10-28 12:40:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:40:04 --> Pagination Class Initialized
INFO - 2023-10-28 12:40:04 --> Form Validation Class Initialized
INFO - 2023-10-28 12:40:04 --> Controller Class Initialized
INFO - 2023-10-28 12:40:04 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:40:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:04 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:04 --> Model Class Initialized
INFO - 2023-10-28 12:40:04 --> Final output sent to browser
DEBUG - 2023-10-28 12:40:04 --> Total execution time: 0.0169
ERROR - 2023-10-28 12:40:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:40:04 --> Config Class Initialized
INFO - 2023-10-28 12:40:04 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:40:04 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:40:04 --> Utf8 Class Initialized
INFO - 2023-10-28 12:40:04 --> URI Class Initialized
INFO - 2023-10-28 12:40:04 --> Router Class Initialized
INFO - 2023-10-28 12:40:04 --> Output Class Initialized
INFO - 2023-10-28 12:40:04 --> Security Class Initialized
DEBUG - 2023-10-28 12:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:40:04 --> Input Class Initialized
INFO - 2023-10-28 12:40:04 --> Language Class Initialized
INFO - 2023-10-28 12:40:04 --> Loader Class Initialized
INFO - 2023-10-28 12:40:04 --> Helper loaded: url_helper
INFO - 2023-10-28 12:40:04 --> Helper loaded: file_helper
INFO - 2023-10-28 12:40:04 --> Helper loaded: html_helper
INFO - 2023-10-28 12:40:04 --> Helper loaded: text_helper
INFO - 2023-10-28 12:40:04 --> Helper loaded: form_helper
INFO - 2023-10-28 12:40:04 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:40:04 --> Helper loaded: security_helper
INFO - 2023-10-28 12:40:04 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:40:04 --> Database Driver Class Initialized
INFO - 2023-10-28 12:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:40:04 --> Parser Class Initialized
INFO - 2023-10-28 12:40:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:40:04 --> Pagination Class Initialized
INFO - 2023-10-28 12:40:04 --> Form Validation Class Initialized
INFO - 2023-10-28 12:40:04 --> Controller Class Initialized
INFO - 2023-10-28 12:40:04 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:40:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:04 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:04 --> Model Class Initialized
INFO - 2023-10-28 12:40:04 --> Final output sent to browser
DEBUG - 2023-10-28 12:40:04 --> Total execution time: 0.0181
ERROR - 2023-10-28 12:40:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:40:07 --> Config Class Initialized
INFO - 2023-10-28 12:40:07 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:40:07 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:40:07 --> Utf8 Class Initialized
INFO - 2023-10-28 12:40:07 --> URI Class Initialized
INFO - 2023-10-28 12:40:07 --> Router Class Initialized
INFO - 2023-10-28 12:40:07 --> Output Class Initialized
INFO - 2023-10-28 12:40:07 --> Security Class Initialized
DEBUG - 2023-10-28 12:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:40:07 --> Input Class Initialized
INFO - 2023-10-28 12:40:07 --> Language Class Initialized
INFO - 2023-10-28 12:40:07 --> Loader Class Initialized
INFO - 2023-10-28 12:40:07 --> Helper loaded: url_helper
INFO - 2023-10-28 12:40:07 --> Helper loaded: file_helper
INFO - 2023-10-28 12:40:07 --> Helper loaded: html_helper
INFO - 2023-10-28 12:40:07 --> Helper loaded: text_helper
INFO - 2023-10-28 12:40:07 --> Helper loaded: form_helper
INFO - 2023-10-28 12:40:07 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:40:07 --> Helper loaded: security_helper
INFO - 2023-10-28 12:40:07 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:40:07 --> Database Driver Class Initialized
INFO - 2023-10-28 12:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:40:07 --> Parser Class Initialized
INFO - 2023-10-28 12:40:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:40:07 --> Pagination Class Initialized
INFO - 2023-10-28 12:40:07 --> Form Validation Class Initialized
INFO - 2023-10-28 12:40:07 --> Controller Class Initialized
INFO - 2023-10-28 12:40:07 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:40:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:07 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:07 --> Model Class Initialized
INFO - 2023-10-28 12:40:07 --> Model Class Initialized
INFO - 2023-10-28 12:40:07 --> Final output sent to browser
DEBUG - 2023-10-28 12:40:07 --> Total execution time: 0.0214
ERROR - 2023-10-28 12:40:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:40:09 --> Config Class Initialized
INFO - 2023-10-28 12:40:09 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:40:09 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:40:09 --> Utf8 Class Initialized
INFO - 2023-10-28 12:40:09 --> URI Class Initialized
INFO - 2023-10-28 12:40:09 --> Router Class Initialized
INFO - 2023-10-28 12:40:09 --> Output Class Initialized
INFO - 2023-10-28 12:40:09 --> Security Class Initialized
DEBUG - 2023-10-28 12:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:40:09 --> Input Class Initialized
INFO - 2023-10-28 12:40:09 --> Language Class Initialized
INFO - 2023-10-28 12:40:09 --> Loader Class Initialized
INFO - 2023-10-28 12:40:09 --> Helper loaded: url_helper
INFO - 2023-10-28 12:40:09 --> Helper loaded: file_helper
INFO - 2023-10-28 12:40:09 --> Helper loaded: html_helper
INFO - 2023-10-28 12:40:09 --> Helper loaded: text_helper
INFO - 2023-10-28 12:40:09 --> Helper loaded: form_helper
INFO - 2023-10-28 12:40:09 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:40:09 --> Helper loaded: security_helper
INFO - 2023-10-28 12:40:09 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:40:09 --> Database Driver Class Initialized
INFO - 2023-10-28 12:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:40:09 --> Parser Class Initialized
INFO - 2023-10-28 12:40:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:40:09 --> Pagination Class Initialized
INFO - 2023-10-28 12:40:09 --> Form Validation Class Initialized
INFO - 2023-10-28 12:40:09 --> Controller Class Initialized
INFO - 2023-10-28 12:40:09 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:40:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:09 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:09 --> Model Class Initialized
INFO - 2023-10-28 12:40:09 --> Final output sent to browser
DEBUG - 2023-10-28 12:40:09 --> Total execution time: 0.0188
ERROR - 2023-10-28 12:40:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:40:22 --> Config Class Initialized
INFO - 2023-10-28 12:40:22 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:40:22 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:40:22 --> Utf8 Class Initialized
INFO - 2023-10-28 12:40:22 --> URI Class Initialized
INFO - 2023-10-28 12:40:22 --> Router Class Initialized
INFO - 2023-10-28 12:40:22 --> Output Class Initialized
INFO - 2023-10-28 12:40:22 --> Security Class Initialized
DEBUG - 2023-10-28 12:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:40:22 --> Input Class Initialized
INFO - 2023-10-28 12:40:22 --> Language Class Initialized
INFO - 2023-10-28 12:40:22 --> Loader Class Initialized
INFO - 2023-10-28 12:40:22 --> Helper loaded: url_helper
INFO - 2023-10-28 12:40:22 --> Helper loaded: file_helper
INFO - 2023-10-28 12:40:22 --> Helper loaded: html_helper
INFO - 2023-10-28 12:40:22 --> Helper loaded: text_helper
INFO - 2023-10-28 12:40:22 --> Helper loaded: form_helper
INFO - 2023-10-28 12:40:22 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:40:22 --> Helper loaded: security_helper
INFO - 2023-10-28 12:40:22 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:40:22 --> Database Driver Class Initialized
INFO - 2023-10-28 12:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:40:22 --> Parser Class Initialized
INFO - 2023-10-28 12:40:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:40:22 --> Pagination Class Initialized
INFO - 2023-10-28 12:40:22 --> Form Validation Class Initialized
INFO - 2023-10-28 12:40:22 --> Controller Class Initialized
INFO - 2023-10-28 12:40:22 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:40:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:22 --> Model Class Initialized
INFO - 2023-10-28 12:40:22 --> Email Class Initialized
INFO - 2023-10-28 12:40:22 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-10-28 12:40:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:40:23 --> Config Class Initialized
INFO - 2023-10-28 12:40:23 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:40:23 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:40:23 --> Utf8 Class Initialized
INFO - 2023-10-28 12:40:23 --> URI Class Initialized
INFO - 2023-10-28 12:40:23 --> Router Class Initialized
INFO - 2023-10-28 12:40:23 --> Output Class Initialized
INFO - 2023-10-28 12:40:23 --> Security Class Initialized
DEBUG - 2023-10-28 12:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:40:23 --> Input Class Initialized
INFO - 2023-10-28 12:40:23 --> Language Class Initialized
INFO - 2023-10-28 12:40:23 --> Loader Class Initialized
INFO - 2023-10-28 12:40:23 --> Helper loaded: url_helper
INFO - 2023-10-28 12:40:23 --> Helper loaded: file_helper
INFO - 2023-10-28 12:40:23 --> Helper loaded: html_helper
INFO - 2023-10-28 12:40:23 --> Helper loaded: text_helper
INFO - 2023-10-28 12:40:23 --> Helper loaded: form_helper
INFO - 2023-10-28 12:40:23 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:40:23 --> Helper loaded: security_helper
INFO - 2023-10-28 12:40:23 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:40:23 --> Database Driver Class Initialized
INFO - 2023-10-28 12:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:40:23 --> Parser Class Initialized
INFO - 2023-10-28 12:40:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:40:23 --> Pagination Class Initialized
INFO - 2023-10-28 12:40:23 --> Form Validation Class Initialized
INFO - 2023-10-28 12:40:23 --> Controller Class Initialized
INFO - 2023-10-28 12:40:23 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:40:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:23 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-10-28 12:40:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 12:40:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 12:40:23 --> Model Class Initialized
INFO - 2023-10-28 12:40:23 --> Model Class Initialized
INFO - 2023-10-28 12:40:23 --> Model Class Initialized
INFO - 2023-10-28 12:40:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 12:40:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 12:40:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 12:40:23 --> Final output sent to browser
DEBUG - 2023-10-28 12:40:23 --> Total execution time: 0.2082
ERROR - 2023-10-28 12:40:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:40:30 --> Config Class Initialized
INFO - 2023-10-28 12:40:30 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:40:30 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:40:30 --> Utf8 Class Initialized
INFO - 2023-10-28 12:40:30 --> URI Class Initialized
INFO - 2023-10-28 12:40:30 --> Router Class Initialized
INFO - 2023-10-28 12:40:30 --> Output Class Initialized
INFO - 2023-10-28 12:40:30 --> Security Class Initialized
DEBUG - 2023-10-28 12:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:40:30 --> Input Class Initialized
INFO - 2023-10-28 12:40:30 --> Language Class Initialized
INFO - 2023-10-28 12:40:30 --> Loader Class Initialized
INFO - 2023-10-28 12:40:30 --> Helper loaded: url_helper
INFO - 2023-10-28 12:40:30 --> Helper loaded: file_helper
INFO - 2023-10-28 12:40:30 --> Helper loaded: html_helper
INFO - 2023-10-28 12:40:30 --> Helper loaded: text_helper
INFO - 2023-10-28 12:40:30 --> Helper loaded: form_helper
INFO - 2023-10-28 12:40:30 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:40:30 --> Helper loaded: security_helper
INFO - 2023-10-28 12:40:30 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:40:30 --> Database Driver Class Initialized
INFO - 2023-10-28 12:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:40:30 --> Parser Class Initialized
INFO - 2023-10-28 12:40:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:40:30 --> Pagination Class Initialized
INFO - 2023-10-28 12:40:30 --> Form Validation Class Initialized
INFO - 2023-10-28 12:40:30 --> Controller Class Initialized
INFO - 2023-10-28 12:40:30 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:40:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:30 --> Model Class Initialized
INFO - 2023-10-28 12:40:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-10-28 12:40:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 12:40:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 12:40:30 --> Model Class Initialized
INFO - 2023-10-28 12:40:30 --> Model Class Initialized
INFO - 2023-10-28 12:40:30 --> Model Class Initialized
INFO - 2023-10-28 12:40:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 12:40:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 12:40:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 12:40:31 --> Final output sent to browser
DEBUG - 2023-10-28 12:40:31 --> Total execution time: 0.1346
ERROR - 2023-10-28 12:40:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:40:31 --> Config Class Initialized
INFO - 2023-10-28 12:40:31 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:40:31 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:40:31 --> Utf8 Class Initialized
INFO - 2023-10-28 12:40:31 --> URI Class Initialized
INFO - 2023-10-28 12:40:31 --> Router Class Initialized
INFO - 2023-10-28 12:40:31 --> Output Class Initialized
INFO - 2023-10-28 12:40:31 --> Security Class Initialized
DEBUG - 2023-10-28 12:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:40:31 --> Input Class Initialized
INFO - 2023-10-28 12:40:31 --> Language Class Initialized
INFO - 2023-10-28 12:40:31 --> Loader Class Initialized
INFO - 2023-10-28 12:40:31 --> Helper loaded: url_helper
INFO - 2023-10-28 12:40:31 --> Helper loaded: file_helper
INFO - 2023-10-28 12:40:31 --> Helper loaded: html_helper
INFO - 2023-10-28 12:40:31 --> Helper loaded: text_helper
INFO - 2023-10-28 12:40:31 --> Helper loaded: form_helper
INFO - 2023-10-28 12:40:31 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:40:31 --> Helper loaded: security_helper
INFO - 2023-10-28 12:40:31 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:40:31 --> Database Driver Class Initialized
INFO - 2023-10-28 12:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:40:31 --> Parser Class Initialized
INFO - 2023-10-28 12:40:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:40:31 --> Pagination Class Initialized
INFO - 2023-10-28 12:40:31 --> Form Validation Class Initialized
INFO - 2023-10-28 12:40:31 --> Controller Class Initialized
INFO - 2023-10-28 12:40:31 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:40:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:31 --> Model Class Initialized
INFO - 2023-10-28 12:40:31 --> Final output sent to browser
DEBUG - 2023-10-28 12:40:31 --> Total execution time: 0.0297
ERROR - 2023-10-28 12:40:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:40:33 --> Config Class Initialized
INFO - 2023-10-28 12:40:33 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:40:33 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:40:33 --> Utf8 Class Initialized
INFO - 2023-10-28 12:40:33 --> URI Class Initialized
INFO - 2023-10-28 12:40:33 --> Router Class Initialized
INFO - 2023-10-28 12:40:33 --> Output Class Initialized
INFO - 2023-10-28 12:40:33 --> Security Class Initialized
DEBUG - 2023-10-28 12:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:40:33 --> Input Class Initialized
INFO - 2023-10-28 12:40:33 --> Language Class Initialized
INFO - 2023-10-28 12:40:33 --> Loader Class Initialized
INFO - 2023-10-28 12:40:33 --> Helper loaded: url_helper
INFO - 2023-10-28 12:40:33 --> Helper loaded: file_helper
INFO - 2023-10-28 12:40:33 --> Helper loaded: html_helper
INFO - 2023-10-28 12:40:33 --> Helper loaded: text_helper
INFO - 2023-10-28 12:40:33 --> Helper loaded: form_helper
INFO - 2023-10-28 12:40:33 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:40:33 --> Helper loaded: security_helper
INFO - 2023-10-28 12:40:33 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:40:33 --> Database Driver Class Initialized
INFO - 2023-10-28 12:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:40:33 --> Parser Class Initialized
INFO - 2023-10-28 12:40:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:40:33 --> Pagination Class Initialized
INFO - 2023-10-28 12:40:33 --> Form Validation Class Initialized
INFO - 2023-10-28 12:40:33 --> Controller Class Initialized
INFO - 2023-10-28 12:40:33 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:40:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:33 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-10-28 12:40:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 12:40:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 12:40:33 --> Model Class Initialized
INFO - 2023-10-28 12:40:33 --> Model Class Initialized
INFO - 2023-10-28 12:40:33 --> Model Class Initialized
INFO - 2023-10-28 12:40:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 12:40:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 12:40:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 12:40:33 --> Final output sent to browser
DEBUG - 2023-10-28 12:40:33 --> Total execution time: 0.1339
ERROR - 2023-10-28 12:40:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:40:36 --> Config Class Initialized
INFO - 2023-10-28 12:40:36 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:40:36 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:40:36 --> Utf8 Class Initialized
INFO - 2023-10-28 12:40:36 --> URI Class Initialized
INFO - 2023-10-28 12:40:36 --> Router Class Initialized
INFO - 2023-10-28 12:40:36 --> Output Class Initialized
INFO - 2023-10-28 12:40:36 --> Security Class Initialized
DEBUG - 2023-10-28 12:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:40:36 --> Input Class Initialized
INFO - 2023-10-28 12:40:36 --> Language Class Initialized
INFO - 2023-10-28 12:40:36 --> Loader Class Initialized
INFO - 2023-10-28 12:40:36 --> Helper loaded: url_helper
INFO - 2023-10-28 12:40:36 --> Helper loaded: file_helper
INFO - 2023-10-28 12:40:36 --> Helper loaded: html_helper
INFO - 2023-10-28 12:40:36 --> Helper loaded: text_helper
INFO - 2023-10-28 12:40:36 --> Helper loaded: form_helper
INFO - 2023-10-28 12:40:36 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:40:36 --> Helper loaded: security_helper
INFO - 2023-10-28 12:40:36 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:40:36 --> Database Driver Class Initialized
INFO - 2023-10-28 12:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:40:36 --> Parser Class Initialized
INFO - 2023-10-28 12:40:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:40:36 --> Pagination Class Initialized
INFO - 2023-10-28 12:40:36 --> Form Validation Class Initialized
INFO - 2023-10-28 12:40:36 --> Controller Class Initialized
INFO - 2023-10-28 12:40:36 --> Final output sent to browser
DEBUG - 2023-10-28 12:40:36 --> Total execution time: 0.0173
ERROR - 2023-10-28 12:40:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:40:38 --> Config Class Initialized
INFO - 2023-10-28 12:40:38 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:40:38 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:40:38 --> Utf8 Class Initialized
INFO - 2023-10-28 12:40:38 --> URI Class Initialized
INFO - 2023-10-28 12:40:38 --> Router Class Initialized
INFO - 2023-10-28 12:40:38 --> Output Class Initialized
INFO - 2023-10-28 12:40:38 --> Security Class Initialized
DEBUG - 2023-10-28 12:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:40:38 --> Input Class Initialized
INFO - 2023-10-28 12:40:38 --> Language Class Initialized
INFO - 2023-10-28 12:40:38 --> Loader Class Initialized
INFO - 2023-10-28 12:40:38 --> Helper loaded: url_helper
INFO - 2023-10-28 12:40:38 --> Helper loaded: file_helper
INFO - 2023-10-28 12:40:38 --> Helper loaded: html_helper
INFO - 2023-10-28 12:40:38 --> Helper loaded: text_helper
INFO - 2023-10-28 12:40:38 --> Helper loaded: form_helper
INFO - 2023-10-28 12:40:38 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:40:38 --> Helper loaded: security_helper
INFO - 2023-10-28 12:40:38 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:40:38 --> Database Driver Class Initialized
INFO - 2023-10-28 12:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:40:38 --> Parser Class Initialized
INFO - 2023-10-28 12:40:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:40:38 --> Pagination Class Initialized
INFO - 2023-10-28 12:40:38 --> Form Validation Class Initialized
INFO - 2023-10-28 12:40:38 --> Controller Class Initialized
INFO - 2023-10-28 12:40:38 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:40:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:38 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-10-28 12:40:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 12:40:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 12:40:38 --> Model Class Initialized
INFO - 2023-10-28 12:40:38 --> Model Class Initialized
INFO - 2023-10-28 12:40:38 --> Model Class Initialized
INFO - 2023-10-28 12:40:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 12:40:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 12:40:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 12:40:38 --> Final output sent to browser
DEBUG - 2023-10-28 12:40:38 --> Total execution time: 0.1353
ERROR - 2023-10-28 12:40:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:40:42 --> Config Class Initialized
INFO - 2023-10-28 12:40:42 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:40:42 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:40:42 --> Utf8 Class Initialized
INFO - 2023-10-28 12:40:42 --> URI Class Initialized
INFO - 2023-10-28 12:40:42 --> Router Class Initialized
INFO - 2023-10-28 12:40:42 --> Output Class Initialized
INFO - 2023-10-28 12:40:42 --> Security Class Initialized
DEBUG - 2023-10-28 12:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:40:42 --> Input Class Initialized
INFO - 2023-10-28 12:40:42 --> Language Class Initialized
INFO - 2023-10-28 12:40:42 --> Loader Class Initialized
INFO - 2023-10-28 12:40:42 --> Helper loaded: url_helper
INFO - 2023-10-28 12:40:42 --> Helper loaded: file_helper
INFO - 2023-10-28 12:40:42 --> Helper loaded: html_helper
INFO - 2023-10-28 12:40:42 --> Helper loaded: text_helper
INFO - 2023-10-28 12:40:42 --> Helper loaded: form_helper
INFO - 2023-10-28 12:40:42 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:40:42 --> Helper loaded: security_helper
INFO - 2023-10-28 12:40:42 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:40:42 --> Database Driver Class Initialized
INFO - 2023-10-28 12:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:40:42 --> Parser Class Initialized
INFO - 2023-10-28 12:40:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:40:42 --> Pagination Class Initialized
INFO - 2023-10-28 12:40:42 --> Form Validation Class Initialized
INFO - 2023-10-28 12:40:42 --> Controller Class Initialized
INFO - 2023-10-28 12:40:42 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:40:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:42 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:42 --> Model Class Initialized
INFO - 2023-10-28 12:40:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-28 12:40:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 12:40:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 12:40:42 --> Model Class Initialized
INFO - 2023-10-28 12:40:42 --> Model Class Initialized
INFO - 2023-10-28 12:40:42 --> Model Class Initialized
INFO - 2023-10-28 12:40:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 12:40:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 12:40:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 12:40:42 --> Final output sent to browser
DEBUG - 2023-10-28 12:40:42 --> Total execution time: 0.1426
ERROR - 2023-10-28 12:40:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:40:42 --> Config Class Initialized
INFO - 2023-10-28 12:40:42 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:40:42 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:40:42 --> Utf8 Class Initialized
INFO - 2023-10-28 12:40:42 --> URI Class Initialized
INFO - 2023-10-28 12:40:42 --> Router Class Initialized
INFO - 2023-10-28 12:40:42 --> Output Class Initialized
INFO - 2023-10-28 12:40:42 --> Security Class Initialized
DEBUG - 2023-10-28 12:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:40:42 --> Input Class Initialized
INFO - 2023-10-28 12:40:42 --> Language Class Initialized
INFO - 2023-10-28 12:40:42 --> Loader Class Initialized
INFO - 2023-10-28 12:40:42 --> Helper loaded: url_helper
INFO - 2023-10-28 12:40:42 --> Helper loaded: file_helper
INFO - 2023-10-28 12:40:42 --> Helper loaded: html_helper
INFO - 2023-10-28 12:40:42 --> Helper loaded: text_helper
INFO - 2023-10-28 12:40:42 --> Helper loaded: form_helper
INFO - 2023-10-28 12:40:42 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:40:42 --> Helper loaded: security_helper
INFO - 2023-10-28 12:40:42 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:40:42 --> Database Driver Class Initialized
INFO - 2023-10-28 12:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:40:42 --> Parser Class Initialized
INFO - 2023-10-28 12:40:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:40:42 --> Pagination Class Initialized
INFO - 2023-10-28 12:40:42 --> Form Validation Class Initialized
INFO - 2023-10-28 12:40:42 --> Controller Class Initialized
INFO - 2023-10-28 12:40:42 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:40:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:42 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:42 --> Model Class Initialized
INFO - 2023-10-28 12:40:42 --> Final output sent to browser
DEBUG - 2023-10-28 12:40:42 --> Total execution time: 0.0317
ERROR - 2023-10-28 12:40:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:40:45 --> Config Class Initialized
INFO - 2023-10-28 12:40:45 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:40:45 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:40:45 --> Utf8 Class Initialized
INFO - 2023-10-28 12:40:45 --> URI Class Initialized
INFO - 2023-10-28 12:40:45 --> Router Class Initialized
INFO - 2023-10-28 12:40:45 --> Output Class Initialized
INFO - 2023-10-28 12:40:45 --> Security Class Initialized
DEBUG - 2023-10-28 12:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:40:45 --> Input Class Initialized
INFO - 2023-10-28 12:40:45 --> Language Class Initialized
INFO - 2023-10-28 12:40:45 --> Loader Class Initialized
INFO - 2023-10-28 12:40:45 --> Helper loaded: url_helper
INFO - 2023-10-28 12:40:45 --> Helper loaded: file_helper
INFO - 2023-10-28 12:40:45 --> Helper loaded: html_helper
INFO - 2023-10-28 12:40:45 --> Helper loaded: text_helper
INFO - 2023-10-28 12:40:45 --> Helper loaded: form_helper
INFO - 2023-10-28 12:40:45 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:40:45 --> Helper loaded: security_helper
INFO - 2023-10-28 12:40:45 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:40:45 --> Database Driver Class Initialized
INFO - 2023-10-28 12:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:40:45 --> Parser Class Initialized
INFO - 2023-10-28 12:40:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:40:45 --> Pagination Class Initialized
INFO - 2023-10-28 12:40:45 --> Form Validation Class Initialized
INFO - 2023-10-28 12:40:45 --> Controller Class Initialized
INFO - 2023-10-28 12:40:45 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:40:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:45 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:45 --> Model Class Initialized
INFO - 2023-10-28 12:40:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-10-28 12:40:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 12:40:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 12:40:45 --> Model Class Initialized
INFO - 2023-10-28 12:40:45 --> Model Class Initialized
INFO - 2023-10-28 12:40:45 --> Model Class Initialized
INFO - 2023-10-28 12:40:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 12:40:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 12:40:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 12:40:45 --> Final output sent to browser
DEBUG - 2023-10-28 12:40:45 --> Total execution time: 0.1464
ERROR - 2023-10-28 12:40:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:40:48 --> Config Class Initialized
INFO - 2023-10-28 12:40:48 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:40:48 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:40:48 --> Utf8 Class Initialized
INFO - 2023-10-28 12:40:48 --> URI Class Initialized
INFO - 2023-10-28 12:40:48 --> Router Class Initialized
INFO - 2023-10-28 12:40:48 --> Output Class Initialized
INFO - 2023-10-28 12:40:48 --> Security Class Initialized
DEBUG - 2023-10-28 12:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:40:48 --> Input Class Initialized
INFO - 2023-10-28 12:40:48 --> Language Class Initialized
INFO - 2023-10-28 12:40:48 --> Loader Class Initialized
INFO - 2023-10-28 12:40:48 --> Helper loaded: url_helper
INFO - 2023-10-28 12:40:48 --> Helper loaded: file_helper
INFO - 2023-10-28 12:40:48 --> Helper loaded: html_helper
INFO - 2023-10-28 12:40:48 --> Helper loaded: text_helper
INFO - 2023-10-28 12:40:48 --> Helper loaded: form_helper
INFO - 2023-10-28 12:40:48 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:40:48 --> Helper loaded: security_helper
INFO - 2023-10-28 12:40:48 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:40:48 --> Database Driver Class Initialized
INFO - 2023-10-28 12:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:40:48 --> Parser Class Initialized
INFO - 2023-10-28 12:40:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:40:48 --> Pagination Class Initialized
INFO - 2023-10-28 12:40:48 --> Form Validation Class Initialized
INFO - 2023-10-28 12:40:48 --> Controller Class Initialized
INFO - 2023-10-28 12:40:48 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:48 --> Final output sent to browser
DEBUG - 2023-10-28 12:40:48 --> Total execution time: 0.0156
ERROR - 2023-10-28 12:40:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:40:49 --> Config Class Initialized
INFO - 2023-10-28 12:40:49 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:40:49 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:40:49 --> Utf8 Class Initialized
INFO - 2023-10-28 12:40:49 --> URI Class Initialized
INFO - 2023-10-28 12:40:49 --> Router Class Initialized
INFO - 2023-10-28 12:40:49 --> Output Class Initialized
INFO - 2023-10-28 12:40:49 --> Security Class Initialized
DEBUG - 2023-10-28 12:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:40:49 --> Input Class Initialized
INFO - 2023-10-28 12:40:49 --> Language Class Initialized
INFO - 2023-10-28 12:40:49 --> Loader Class Initialized
INFO - 2023-10-28 12:40:49 --> Helper loaded: url_helper
INFO - 2023-10-28 12:40:49 --> Helper loaded: file_helper
INFO - 2023-10-28 12:40:49 --> Helper loaded: html_helper
INFO - 2023-10-28 12:40:49 --> Helper loaded: text_helper
INFO - 2023-10-28 12:40:49 --> Helper loaded: form_helper
INFO - 2023-10-28 12:40:49 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:40:49 --> Helper loaded: security_helper
INFO - 2023-10-28 12:40:49 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:40:49 --> Database Driver Class Initialized
INFO - 2023-10-28 12:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:40:49 --> Parser Class Initialized
INFO - 2023-10-28 12:40:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:40:49 --> Pagination Class Initialized
INFO - 2023-10-28 12:40:49 --> Form Validation Class Initialized
INFO - 2023-10-28 12:40:49 --> Controller Class Initialized
INFO - 2023-10-28 12:40:49 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:49 --> Final output sent to browser
DEBUG - 2023-10-28 12:40:49 --> Total execution time: 0.0170
ERROR - 2023-10-28 12:40:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:40:49 --> Config Class Initialized
INFO - 2023-10-28 12:40:49 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:40:49 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:40:49 --> Utf8 Class Initialized
INFO - 2023-10-28 12:40:49 --> URI Class Initialized
INFO - 2023-10-28 12:40:49 --> Router Class Initialized
INFO - 2023-10-28 12:40:49 --> Output Class Initialized
INFO - 2023-10-28 12:40:49 --> Security Class Initialized
DEBUG - 2023-10-28 12:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:40:49 --> Input Class Initialized
INFO - 2023-10-28 12:40:49 --> Language Class Initialized
INFO - 2023-10-28 12:40:49 --> Loader Class Initialized
INFO - 2023-10-28 12:40:49 --> Helper loaded: url_helper
INFO - 2023-10-28 12:40:49 --> Helper loaded: file_helper
INFO - 2023-10-28 12:40:49 --> Helper loaded: html_helper
INFO - 2023-10-28 12:40:49 --> Helper loaded: text_helper
INFO - 2023-10-28 12:40:49 --> Helper loaded: form_helper
INFO - 2023-10-28 12:40:49 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:40:49 --> Helper loaded: security_helper
INFO - 2023-10-28 12:40:49 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:40:49 --> Database Driver Class Initialized
INFO - 2023-10-28 12:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:40:49 --> Parser Class Initialized
INFO - 2023-10-28 12:40:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:40:49 --> Pagination Class Initialized
INFO - 2023-10-28 12:40:49 --> Form Validation Class Initialized
INFO - 2023-10-28 12:40:49 --> Controller Class Initialized
INFO - 2023-10-28 12:40:49 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:49 --> Final output sent to browser
DEBUG - 2023-10-28 12:40:49 --> Total execution time: 0.0155
ERROR - 2023-10-28 12:40:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:40:50 --> Config Class Initialized
INFO - 2023-10-28 12:40:50 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:40:50 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:40:50 --> Utf8 Class Initialized
INFO - 2023-10-28 12:40:50 --> URI Class Initialized
INFO - 2023-10-28 12:40:50 --> Router Class Initialized
INFO - 2023-10-28 12:40:50 --> Output Class Initialized
INFO - 2023-10-28 12:40:50 --> Security Class Initialized
DEBUG - 2023-10-28 12:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:40:50 --> Input Class Initialized
INFO - 2023-10-28 12:40:50 --> Language Class Initialized
INFO - 2023-10-28 12:40:50 --> Loader Class Initialized
INFO - 2023-10-28 12:40:50 --> Helper loaded: url_helper
INFO - 2023-10-28 12:40:50 --> Helper loaded: file_helper
INFO - 2023-10-28 12:40:50 --> Helper loaded: html_helper
INFO - 2023-10-28 12:40:50 --> Helper loaded: text_helper
INFO - 2023-10-28 12:40:50 --> Helper loaded: form_helper
INFO - 2023-10-28 12:40:50 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:40:50 --> Helper loaded: security_helper
INFO - 2023-10-28 12:40:50 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:40:50 --> Database Driver Class Initialized
INFO - 2023-10-28 12:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:40:50 --> Parser Class Initialized
INFO - 2023-10-28 12:40:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:40:50 --> Pagination Class Initialized
INFO - 2023-10-28 12:40:50 --> Form Validation Class Initialized
INFO - 2023-10-28 12:40:50 --> Controller Class Initialized
INFO - 2023-10-28 12:40:50 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:50 --> Final output sent to browser
DEBUG - 2023-10-28 12:40:50 --> Total execution time: 0.0151
ERROR - 2023-10-28 12:40:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:40:51 --> Config Class Initialized
INFO - 2023-10-28 12:40:51 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:40:51 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:40:51 --> Utf8 Class Initialized
INFO - 2023-10-28 12:40:51 --> URI Class Initialized
INFO - 2023-10-28 12:40:51 --> Router Class Initialized
INFO - 2023-10-28 12:40:51 --> Output Class Initialized
INFO - 2023-10-28 12:40:51 --> Security Class Initialized
DEBUG - 2023-10-28 12:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:40:51 --> Input Class Initialized
INFO - 2023-10-28 12:40:51 --> Language Class Initialized
INFO - 2023-10-28 12:40:51 --> Loader Class Initialized
INFO - 2023-10-28 12:40:51 --> Helper loaded: url_helper
INFO - 2023-10-28 12:40:51 --> Helper loaded: file_helper
INFO - 2023-10-28 12:40:51 --> Helper loaded: html_helper
INFO - 2023-10-28 12:40:51 --> Helper loaded: text_helper
INFO - 2023-10-28 12:40:51 --> Helper loaded: form_helper
INFO - 2023-10-28 12:40:51 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:40:51 --> Helper loaded: security_helper
INFO - 2023-10-28 12:40:51 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:40:51 --> Database Driver Class Initialized
INFO - 2023-10-28 12:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:40:51 --> Parser Class Initialized
INFO - 2023-10-28 12:40:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:40:51 --> Pagination Class Initialized
INFO - 2023-10-28 12:40:51 --> Form Validation Class Initialized
INFO - 2023-10-28 12:40:51 --> Controller Class Initialized
INFO - 2023-10-28 12:40:51 --> Final output sent to browser
DEBUG - 2023-10-28 12:40:51 --> Total execution time: 0.0132
ERROR - 2023-10-28 12:40:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:40:55 --> Config Class Initialized
INFO - 2023-10-28 12:40:55 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:40:55 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:40:55 --> Utf8 Class Initialized
INFO - 2023-10-28 12:40:55 --> URI Class Initialized
INFO - 2023-10-28 12:40:55 --> Router Class Initialized
INFO - 2023-10-28 12:40:55 --> Output Class Initialized
INFO - 2023-10-28 12:40:55 --> Security Class Initialized
DEBUG - 2023-10-28 12:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:40:55 --> Input Class Initialized
INFO - 2023-10-28 12:40:55 --> Language Class Initialized
INFO - 2023-10-28 12:40:55 --> Loader Class Initialized
INFO - 2023-10-28 12:40:55 --> Helper loaded: url_helper
INFO - 2023-10-28 12:40:55 --> Helper loaded: file_helper
INFO - 2023-10-28 12:40:55 --> Helper loaded: html_helper
INFO - 2023-10-28 12:40:55 --> Helper loaded: text_helper
INFO - 2023-10-28 12:40:55 --> Helper loaded: form_helper
INFO - 2023-10-28 12:40:55 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:40:55 --> Helper loaded: security_helper
INFO - 2023-10-28 12:40:55 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:40:55 --> Database Driver Class Initialized
INFO - 2023-10-28 12:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:40:55 --> Parser Class Initialized
INFO - 2023-10-28 12:40:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:40:55 --> Pagination Class Initialized
INFO - 2023-10-28 12:40:55 --> Form Validation Class Initialized
INFO - 2023-10-28 12:40:55 --> Controller Class Initialized
INFO - 2023-10-28 12:40:55 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:40:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:55 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:55 --> Model Class Initialized
INFO - 2023-10-28 12:40:55 --> Final output sent to browser
DEBUG - 2023-10-28 12:40:55 --> Total execution time: 0.0554
ERROR - 2023-10-28 12:40:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:40:55 --> Config Class Initialized
INFO - 2023-10-28 12:40:55 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:40:55 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:40:55 --> Utf8 Class Initialized
INFO - 2023-10-28 12:40:55 --> URI Class Initialized
INFO - 2023-10-28 12:40:55 --> Router Class Initialized
INFO - 2023-10-28 12:40:55 --> Output Class Initialized
INFO - 2023-10-28 12:40:55 --> Security Class Initialized
DEBUG - 2023-10-28 12:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:40:55 --> Input Class Initialized
INFO - 2023-10-28 12:40:55 --> Language Class Initialized
INFO - 2023-10-28 12:40:55 --> Loader Class Initialized
INFO - 2023-10-28 12:40:55 --> Helper loaded: url_helper
INFO - 2023-10-28 12:40:55 --> Helper loaded: file_helper
INFO - 2023-10-28 12:40:55 --> Helper loaded: html_helper
INFO - 2023-10-28 12:40:55 --> Helper loaded: text_helper
INFO - 2023-10-28 12:40:55 --> Helper loaded: form_helper
INFO - 2023-10-28 12:40:55 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:40:55 --> Helper loaded: security_helper
INFO - 2023-10-28 12:40:55 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:40:55 --> Database Driver Class Initialized
INFO - 2023-10-28 12:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:40:55 --> Parser Class Initialized
INFO - 2023-10-28 12:40:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:40:55 --> Pagination Class Initialized
INFO - 2023-10-28 12:40:55 --> Form Validation Class Initialized
INFO - 2023-10-28 12:40:55 --> Controller Class Initialized
INFO - 2023-10-28 12:40:55 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:40:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:55 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:55 --> Model Class Initialized
INFO - 2023-10-28 12:40:55 --> Final output sent to browser
DEBUG - 2023-10-28 12:40:55 --> Total execution time: 0.0522
ERROR - 2023-10-28 12:40:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:40:56 --> Config Class Initialized
INFO - 2023-10-28 12:40:56 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:40:56 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:40:56 --> Utf8 Class Initialized
INFO - 2023-10-28 12:40:56 --> URI Class Initialized
INFO - 2023-10-28 12:40:56 --> Router Class Initialized
INFO - 2023-10-28 12:40:56 --> Output Class Initialized
INFO - 2023-10-28 12:40:56 --> Security Class Initialized
DEBUG - 2023-10-28 12:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:40:56 --> Input Class Initialized
INFO - 2023-10-28 12:40:56 --> Language Class Initialized
INFO - 2023-10-28 12:40:56 --> Loader Class Initialized
INFO - 2023-10-28 12:40:56 --> Helper loaded: url_helper
INFO - 2023-10-28 12:40:56 --> Helper loaded: file_helper
INFO - 2023-10-28 12:40:56 --> Helper loaded: html_helper
INFO - 2023-10-28 12:40:56 --> Helper loaded: text_helper
INFO - 2023-10-28 12:40:56 --> Helper loaded: form_helper
INFO - 2023-10-28 12:40:56 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:40:56 --> Helper loaded: security_helper
INFO - 2023-10-28 12:40:56 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:40:56 --> Database Driver Class Initialized
INFO - 2023-10-28 12:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:40:56 --> Parser Class Initialized
INFO - 2023-10-28 12:40:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:40:56 --> Pagination Class Initialized
INFO - 2023-10-28 12:40:56 --> Form Validation Class Initialized
INFO - 2023-10-28 12:40:56 --> Controller Class Initialized
INFO - 2023-10-28 12:40:56 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:40:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:56 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:56 --> Model Class Initialized
INFO - 2023-10-28 12:40:56 --> Final output sent to browser
DEBUG - 2023-10-28 12:40:56 --> Total execution time: 0.0629
ERROR - 2023-10-28 12:40:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:40:56 --> Config Class Initialized
INFO - 2023-10-28 12:40:56 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:40:56 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:40:56 --> Utf8 Class Initialized
INFO - 2023-10-28 12:40:56 --> URI Class Initialized
INFO - 2023-10-28 12:40:56 --> Router Class Initialized
INFO - 2023-10-28 12:40:56 --> Output Class Initialized
INFO - 2023-10-28 12:40:56 --> Security Class Initialized
DEBUG - 2023-10-28 12:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:40:56 --> Input Class Initialized
INFO - 2023-10-28 12:40:56 --> Language Class Initialized
INFO - 2023-10-28 12:40:56 --> Loader Class Initialized
INFO - 2023-10-28 12:40:56 --> Helper loaded: url_helper
INFO - 2023-10-28 12:40:56 --> Helper loaded: file_helper
INFO - 2023-10-28 12:40:56 --> Helper loaded: html_helper
INFO - 2023-10-28 12:40:56 --> Helper loaded: text_helper
INFO - 2023-10-28 12:40:56 --> Helper loaded: form_helper
INFO - 2023-10-28 12:40:56 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:40:56 --> Helper loaded: security_helper
INFO - 2023-10-28 12:40:56 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:40:56 --> Database Driver Class Initialized
INFO - 2023-10-28 12:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:40:56 --> Parser Class Initialized
INFO - 2023-10-28 12:40:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:40:56 --> Pagination Class Initialized
INFO - 2023-10-28 12:40:56 --> Form Validation Class Initialized
INFO - 2023-10-28 12:40:56 --> Controller Class Initialized
INFO - 2023-10-28 12:40:56 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:40:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:56 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:56 --> Model Class Initialized
INFO - 2023-10-28 12:40:56 --> Final output sent to browser
DEBUG - 2023-10-28 12:40:56 --> Total execution time: 0.0524
ERROR - 2023-10-28 12:40:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:40:57 --> Config Class Initialized
INFO - 2023-10-28 12:40:57 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:40:57 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:40:57 --> Utf8 Class Initialized
INFO - 2023-10-28 12:40:57 --> URI Class Initialized
INFO - 2023-10-28 12:40:57 --> Router Class Initialized
INFO - 2023-10-28 12:40:57 --> Output Class Initialized
INFO - 2023-10-28 12:40:57 --> Security Class Initialized
DEBUG - 2023-10-28 12:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:40:57 --> Input Class Initialized
INFO - 2023-10-28 12:40:57 --> Language Class Initialized
INFO - 2023-10-28 12:40:57 --> Loader Class Initialized
INFO - 2023-10-28 12:40:57 --> Helper loaded: url_helper
INFO - 2023-10-28 12:40:57 --> Helper loaded: file_helper
INFO - 2023-10-28 12:40:57 --> Helper loaded: html_helper
INFO - 2023-10-28 12:40:57 --> Helper loaded: text_helper
INFO - 2023-10-28 12:40:57 --> Helper loaded: form_helper
INFO - 2023-10-28 12:40:57 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:40:57 --> Helper loaded: security_helper
INFO - 2023-10-28 12:40:57 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:40:57 --> Database Driver Class Initialized
INFO - 2023-10-28 12:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:40:57 --> Parser Class Initialized
INFO - 2023-10-28 12:40:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:40:57 --> Pagination Class Initialized
INFO - 2023-10-28 12:40:57 --> Form Validation Class Initialized
INFO - 2023-10-28 12:40:57 --> Controller Class Initialized
INFO - 2023-10-28 12:40:57 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:40:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:57 --> Model Class Initialized
DEBUG - 2023-10-28 12:40:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:40:57 --> Model Class Initialized
INFO - 2023-10-28 12:40:57 --> Final output sent to browser
DEBUG - 2023-10-28 12:40:57 --> Total execution time: 0.0238
ERROR - 2023-10-28 12:41:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:41:00 --> Config Class Initialized
INFO - 2023-10-28 12:41:00 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:41:00 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:41:00 --> Utf8 Class Initialized
INFO - 2023-10-28 12:41:00 --> URI Class Initialized
INFO - 2023-10-28 12:41:00 --> Router Class Initialized
INFO - 2023-10-28 12:41:00 --> Output Class Initialized
INFO - 2023-10-28 12:41:00 --> Security Class Initialized
DEBUG - 2023-10-28 12:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:41:00 --> Input Class Initialized
INFO - 2023-10-28 12:41:00 --> Language Class Initialized
INFO - 2023-10-28 12:41:00 --> Loader Class Initialized
INFO - 2023-10-28 12:41:00 --> Helper loaded: url_helper
INFO - 2023-10-28 12:41:00 --> Helper loaded: file_helper
INFO - 2023-10-28 12:41:00 --> Helper loaded: html_helper
INFO - 2023-10-28 12:41:00 --> Helper loaded: text_helper
INFO - 2023-10-28 12:41:00 --> Helper loaded: form_helper
INFO - 2023-10-28 12:41:00 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:41:00 --> Helper loaded: security_helper
INFO - 2023-10-28 12:41:00 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:41:00 --> Database Driver Class Initialized
INFO - 2023-10-28 12:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:41:00 --> Parser Class Initialized
INFO - 2023-10-28 12:41:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:41:00 --> Pagination Class Initialized
INFO - 2023-10-28 12:41:00 --> Form Validation Class Initialized
INFO - 2023-10-28 12:41:00 --> Controller Class Initialized
INFO - 2023-10-28 12:41:00 --> Model Class Initialized
DEBUG - 2023-10-28 12:41:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:41:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:41:00 --> Model Class Initialized
INFO - 2023-10-28 12:41:00 --> Model Class Initialized
INFO - 2023-10-28 12:41:00 --> Final output sent to browser
DEBUG - 2023-10-28 12:41:00 --> Total execution time: 0.0187
ERROR - 2023-10-28 12:41:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:41:00 --> Config Class Initialized
INFO - 2023-10-28 12:41:00 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:41:00 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:41:00 --> Utf8 Class Initialized
INFO - 2023-10-28 12:41:00 --> URI Class Initialized
INFO - 2023-10-28 12:41:00 --> Router Class Initialized
INFO - 2023-10-28 12:41:00 --> Output Class Initialized
INFO - 2023-10-28 12:41:00 --> Security Class Initialized
DEBUG - 2023-10-28 12:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:41:00 --> Input Class Initialized
INFO - 2023-10-28 12:41:00 --> Language Class Initialized
INFO - 2023-10-28 12:41:00 --> Loader Class Initialized
INFO - 2023-10-28 12:41:00 --> Helper loaded: url_helper
INFO - 2023-10-28 12:41:00 --> Helper loaded: file_helper
INFO - 2023-10-28 12:41:00 --> Helper loaded: html_helper
INFO - 2023-10-28 12:41:00 --> Helper loaded: text_helper
INFO - 2023-10-28 12:41:00 --> Helper loaded: form_helper
INFO - 2023-10-28 12:41:00 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:41:00 --> Helper loaded: security_helper
INFO - 2023-10-28 12:41:00 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:41:00 --> Database Driver Class Initialized
INFO - 2023-10-28 12:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:41:00 --> Parser Class Initialized
INFO - 2023-10-28 12:41:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:41:00 --> Pagination Class Initialized
INFO - 2023-10-28 12:41:00 --> Form Validation Class Initialized
INFO - 2023-10-28 12:41:00 --> Controller Class Initialized
INFO - 2023-10-28 12:41:00 --> Model Class Initialized
DEBUG - 2023-10-28 12:41:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:41:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:41:00 --> Model Class Initialized
DEBUG - 2023-10-28 12:41:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:41:00 --> Model Class Initialized
INFO - 2023-10-28 12:41:00 --> Final output sent to browser
DEBUG - 2023-10-28 12:41:00 --> Total execution time: 0.0182
ERROR - 2023-10-28 12:41:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:41:26 --> Config Class Initialized
INFO - 2023-10-28 12:41:26 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:41:26 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:41:26 --> Utf8 Class Initialized
INFO - 2023-10-28 12:41:26 --> URI Class Initialized
INFO - 2023-10-28 12:41:26 --> Router Class Initialized
INFO - 2023-10-28 12:41:26 --> Output Class Initialized
INFO - 2023-10-28 12:41:26 --> Security Class Initialized
DEBUG - 2023-10-28 12:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:41:26 --> Input Class Initialized
INFO - 2023-10-28 12:41:26 --> Language Class Initialized
INFO - 2023-10-28 12:41:26 --> Loader Class Initialized
INFO - 2023-10-28 12:41:26 --> Helper loaded: url_helper
INFO - 2023-10-28 12:41:26 --> Helper loaded: file_helper
INFO - 2023-10-28 12:41:26 --> Helper loaded: html_helper
INFO - 2023-10-28 12:41:26 --> Helper loaded: text_helper
INFO - 2023-10-28 12:41:26 --> Helper loaded: form_helper
INFO - 2023-10-28 12:41:26 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:41:26 --> Helper loaded: security_helper
INFO - 2023-10-28 12:41:26 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:41:26 --> Database Driver Class Initialized
INFO - 2023-10-28 12:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:41:26 --> Parser Class Initialized
INFO - 2023-10-28 12:41:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:41:26 --> Pagination Class Initialized
INFO - 2023-10-28 12:41:26 --> Form Validation Class Initialized
INFO - 2023-10-28 12:41:26 --> Controller Class Initialized
DEBUG - 2023-10-28 12:41:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:41:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:41:26 --> Model Class Initialized
DEBUG - 2023-10-28 12:41:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:41:26 --> Model Class Initialized
DEBUG - 2023-10-28 12:41:26 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:41:26 --> Model Class Initialized
INFO - 2023-10-28 12:41:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-10-28 12:41:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:41:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 12:41:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 12:41:26 --> Model Class Initialized
INFO - 2023-10-28 12:41:26 --> Model Class Initialized
INFO - 2023-10-28 12:41:26 --> Model Class Initialized
INFO - 2023-10-28 12:41:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 12:41:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 12:41:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 12:41:26 --> Final output sent to browser
DEBUG - 2023-10-28 12:41:26 --> Total execution time: 0.1905
ERROR - 2023-10-28 12:41:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:41:27 --> Config Class Initialized
INFO - 2023-10-28 12:41:27 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:41:27 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:41:27 --> Utf8 Class Initialized
INFO - 2023-10-28 12:41:27 --> URI Class Initialized
INFO - 2023-10-28 12:41:27 --> Router Class Initialized
INFO - 2023-10-28 12:41:27 --> Output Class Initialized
INFO - 2023-10-28 12:41:27 --> Security Class Initialized
DEBUG - 2023-10-28 12:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:41:27 --> Input Class Initialized
INFO - 2023-10-28 12:41:27 --> Language Class Initialized
INFO - 2023-10-28 12:41:27 --> Loader Class Initialized
INFO - 2023-10-28 12:41:27 --> Helper loaded: url_helper
INFO - 2023-10-28 12:41:27 --> Helper loaded: file_helper
INFO - 2023-10-28 12:41:27 --> Helper loaded: html_helper
INFO - 2023-10-28 12:41:27 --> Helper loaded: text_helper
INFO - 2023-10-28 12:41:27 --> Helper loaded: form_helper
INFO - 2023-10-28 12:41:27 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:41:27 --> Helper loaded: security_helper
INFO - 2023-10-28 12:41:27 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:41:27 --> Database Driver Class Initialized
INFO - 2023-10-28 12:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:41:27 --> Parser Class Initialized
INFO - 2023-10-28 12:41:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:41:27 --> Pagination Class Initialized
INFO - 2023-10-28 12:41:27 --> Form Validation Class Initialized
INFO - 2023-10-28 12:41:27 --> Controller Class Initialized
DEBUG - 2023-10-28 12:41:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:41:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:41:27 --> Model Class Initialized
DEBUG - 2023-10-28 12:41:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:41:27 --> Model Class Initialized
INFO - 2023-10-28 12:41:27 --> Final output sent to browser
DEBUG - 2023-10-28 12:41:27 --> Total execution time: 0.0302
ERROR - 2023-10-28 12:41:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:41:32 --> Config Class Initialized
INFO - 2023-10-28 12:41:32 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:41:32 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:41:32 --> Utf8 Class Initialized
INFO - 2023-10-28 12:41:32 --> URI Class Initialized
INFO - 2023-10-28 12:41:32 --> Router Class Initialized
INFO - 2023-10-28 12:41:32 --> Output Class Initialized
INFO - 2023-10-28 12:41:32 --> Security Class Initialized
DEBUG - 2023-10-28 12:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:41:32 --> Input Class Initialized
INFO - 2023-10-28 12:41:32 --> Language Class Initialized
INFO - 2023-10-28 12:41:32 --> Loader Class Initialized
INFO - 2023-10-28 12:41:32 --> Helper loaded: url_helper
INFO - 2023-10-28 12:41:32 --> Helper loaded: file_helper
INFO - 2023-10-28 12:41:32 --> Helper loaded: html_helper
INFO - 2023-10-28 12:41:32 --> Helper loaded: text_helper
INFO - 2023-10-28 12:41:32 --> Helper loaded: form_helper
INFO - 2023-10-28 12:41:32 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:41:32 --> Helper loaded: security_helper
INFO - 2023-10-28 12:41:32 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:41:32 --> Database Driver Class Initialized
INFO - 2023-10-28 12:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:41:32 --> Parser Class Initialized
INFO - 2023-10-28 12:41:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:41:32 --> Pagination Class Initialized
INFO - 2023-10-28 12:41:32 --> Form Validation Class Initialized
INFO - 2023-10-28 12:41:32 --> Controller Class Initialized
DEBUG - 2023-10-28 12:41:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:41:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:41:32 --> Model Class Initialized
DEBUG - 2023-10-28 12:41:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:41:32 --> Model Class Initialized
INFO - 2023-10-28 12:41:32 --> Final output sent to browser
DEBUG - 2023-10-28 12:41:32 --> Total execution time: 0.0329
ERROR - 2023-10-28 12:41:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:41:33 --> Config Class Initialized
INFO - 2023-10-28 12:41:33 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:41:33 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:41:33 --> Utf8 Class Initialized
INFO - 2023-10-28 12:41:33 --> URI Class Initialized
INFO - 2023-10-28 12:41:33 --> Router Class Initialized
INFO - 2023-10-28 12:41:33 --> Output Class Initialized
INFO - 2023-10-28 12:41:33 --> Security Class Initialized
DEBUG - 2023-10-28 12:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:41:33 --> Input Class Initialized
INFO - 2023-10-28 12:41:33 --> Language Class Initialized
INFO - 2023-10-28 12:41:33 --> Loader Class Initialized
INFO - 2023-10-28 12:41:33 --> Helper loaded: url_helper
INFO - 2023-10-28 12:41:33 --> Helper loaded: file_helper
INFO - 2023-10-28 12:41:33 --> Helper loaded: html_helper
INFO - 2023-10-28 12:41:33 --> Helper loaded: text_helper
INFO - 2023-10-28 12:41:33 --> Helper loaded: form_helper
INFO - 2023-10-28 12:41:33 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:41:33 --> Helper loaded: security_helper
INFO - 2023-10-28 12:41:33 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:41:33 --> Database Driver Class Initialized
INFO - 2023-10-28 12:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:41:33 --> Parser Class Initialized
INFO - 2023-10-28 12:41:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:41:33 --> Pagination Class Initialized
INFO - 2023-10-28 12:41:33 --> Form Validation Class Initialized
INFO - 2023-10-28 12:41:33 --> Controller Class Initialized
DEBUG - 2023-10-28 12:41:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:41:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:41:33 --> Model Class Initialized
DEBUG - 2023-10-28 12:41:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:41:33 --> Model Class Initialized
INFO - 2023-10-28 12:41:33 --> Final output sent to browser
DEBUG - 2023-10-28 12:41:33 --> Total execution time: 0.0329
ERROR - 2023-10-28 12:41:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:41:34 --> Config Class Initialized
INFO - 2023-10-28 12:41:34 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:41:34 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:41:34 --> Utf8 Class Initialized
INFO - 2023-10-28 12:41:34 --> URI Class Initialized
INFO - 2023-10-28 12:41:34 --> Router Class Initialized
INFO - 2023-10-28 12:41:34 --> Output Class Initialized
INFO - 2023-10-28 12:41:34 --> Security Class Initialized
DEBUG - 2023-10-28 12:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:41:34 --> Input Class Initialized
INFO - 2023-10-28 12:41:34 --> Language Class Initialized
INFO - 2023-10-28 12:41:34 --> Loader Class Initialized
INFO - 2023-10-28 12:41:34 --> Helper loaded: url_helper
INFO - 2023-10-28 12:41:34 --> Helper loaded: file_helper
INFO - 2023-10-28 12:41:34 --> Helper loaded: html_helper
INFO - 2023-10-28 12:41:34 --> Helper loaded: text_helper
INFO - 2023-10-28 12:41:34 --> Helper loaded: form_helper
INFO - 2023-10-28 12:41:34 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:41:34 --> Helper loaded: security_helper
INFO - 2023-10-28 12:41:34 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:41:34 --> Database Driver Class Initialized
INFO - 2023-10-28 12:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:41:34 --> Parser Class Initialized
INFO - 2023-10-28 12:41:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:41:34 --> Pagination Class Initialized
INFO - 2023-10-28 12:41:34 --> Form Validation Class Initialized
INFO - 2023-10-28 12:41:34 --> Controller Class Initialized
DEBUG - 2023-10-28 12:41:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:41:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:41:34 --> Model Class Initialized
DEBUG - 2023-10-28 12:41:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:41:34 --> Model Class Initialized
INFO - 2023-10-28 12:41:34 --> Final output sent to browser
DEBUG - 2023-10-28 12:41:34 --> Total execution time: 0.0258
ERROR - 2023-10-28 12:41:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:41:35 --> Config Class Initialized
INFO - 2023-10-28 12:41:35 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:41:35 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:41:35 --> Utf8 Class Initialized
INFO - 2023-10-28 12:41:35 --> URI Class Initialized
INFO - 2023-10-28 12:41:35 --> Router Class Initialized
INFO - 2023-10-28 12:41:35 --> Output Class Initialized
INFO - 2023-10-28 12:41:35 --> Security Class Initialized
DEBUG - 2023-10-28 12:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:41:35 --> Input Class Initialized
INFO - 2023-10-28 12:41:35 --> Language Class Initialized
INFO - 2023-10-28 12:41:35 --> Loader Class Initialized
INFO - 2023-10-28 12:41:35 --> Helper loaded: url_helper
INFO - 2023-10-28 12:41:35 --> Helper loaded: file_helper
INFO - 2023-10-28 12:41:35 --> Helper loaded: html_helper
INFO - 2023-10-28 12:41:35 --> Helper loaded: text_helper
INFO - 2023-10-28 12:41:35 --> Helper loaded: form_helper
INFO - 2023-10-28 12:41:35 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:41:35 --> Helper loaded: security_helper
INFO - 2023-10-28 12:41:35 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:41:35 --> Database Driver Class Initialized
INFO - 2023-10-28 12:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:41:35 --> Parser Class Initialized
INFO - 2023-10-28 12:41:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:41:35 --> Pagination Class Initialized
INFO - 2023-10-28 12:41:35 --> Form Validation Class Initialized
INFO - 2023-10-28 12:41:35 --> Controller Class Initialized
DEBUG - 2023-10-28 12:41:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:41:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:41:35 --> Model Class Initialized
DEBUG - 2023-10-28 12:41:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:41:35 --> Model Class Initialized
INFO - 2023-10-28 12:41:35 --> Final output sent to browser
DEBUG - 2023-10-28 12:41:35 --> Total execution time: 0.0217
ERROR - 2023-10-28 12:41:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:41:38 --> Config Class Initialized
INFO - 2023-10-28 12:41:38 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:41:38 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:41:38 --> Utf8 Class Initialized
INFO - 2023-10-28 12:41:38 --> URI Class Initialized
INFO - 2023-10-28 12:41:38 --> Router Class Initialized
INFO - 2023-10-28 12:41:38 --> Output Class Initialized
INFO - 2023-10-28 12:41:38 --> Security Class Initialized
DEBUG - 2023-10-28 12:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:41:38 --> Input Class Initialized
INFO - 2023-10-28 12:41:38 --> Language Class Initialized
INFO - 2023-10-28 12:41:38 --> Loader Class Initialized
INFO - 2023-10-28 12:41:38 --> Helper loaded: url_helper
INFO - 2023-10-28 12:41:38 --> Helper loaded: file_helper
INFO - 2023-10-28 12:41:38 --> Helper loaded: html_helper
INFO - 2023-10-28 12:41:38 --> Helper loaded: text_helper
INFO - 2023-10-28 12:41:38 --> Helper loaded: form_helper
INFO - 2023-10-28 12:41:38 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:41:38 --> Helper loaded: security_helper
INFO - 2023-10-28 12:41:38 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:41:38 --> Database Driver Class Initialized
INFO - 2023-10-28 12:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:41:38 --> Parser Class Initialized
INFO - 2023-10-28 12:41:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:41:38 --> Pagination Class Initialized
INFO - 2023-10-28 12:41:38 --> Form Validation Class Initialized
INFO - 2023-10-28 12:41:38 --> Controller Class Initialized
DEBUG - 2023-10-28 12:41:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:41:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:41:38 --> Model Class Initialized
DEBUG - 2023-10-28 12:41:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:41:38 --> Model Class Initialized
INFO - 2023-10-28 12:41:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/edit_customer_form.php
DEBUG - 2023-10-28 12:41:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:41:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 12:41:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 12:41:38 --> Model Class Initialized
INFO - 2023-10-28 12:41:38 --> Model Class Initialized
INFO - 2023-10-28 12:41:38 --> Model Class Initialized
INFO - 2023-10-28 12:41:38 --> Model Class Initialized
INFO - 2023-10-28 12:41:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 12:41:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 12:41:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 12:41:39 --> Final output sent to browser
DEBUG - 2023-10-28 12:41:39 --> Total execution time: 0.2085
ERROR - 2023-10-28 12:42:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:42:00 --> Config Class Initialized
INFO - 2023-10-28 12:42:00 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:42:00 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:42:00 --> Utf8 Class Initialized
INFO - 2023-10-28 12:42:00 --> URI Class Initialized
INFO - 2023-10-28 12:42:00 --> Router Class Initialized
INFO - 2023-10-28 12:42:00 --> Output Class Initialized
INFO - 2023-10-28 12:42:00 --> Security Class Initialized
DEBUG - 2023-10-28 12:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:42:00 --> Input Class Initialized
INFO - 2023-10-28 12:42:00 --> Language Class Initialized
INFO - 2023-10-28 12:42:00 --> Loader Class Initialized
INFO - 2023-10-28 12:42:00 --> Helper loaded: url_helper
INFO - 2023-10-28 12:42:00 --> Helper loaded: file_helper
INFO - 2023-10-28 12:42:00 --> Helper loaded: html_helper
INFO - 2023-10-28 12:42:00 --> Helper loaded: text_helper
INFO - 2023-10-28 12:42:00 --> Helper loaded: form_helper
INFO - 2023-10-28 12:42:00 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:42:00 --> Helper loaded: security_helper
INFO - 2023-10-28 12:42:00 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:42:00 --> Database Driver Class Initialized
INFO - 2023-10-28 12:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:42:00 --> Parser Class Initialized
INFO - 2023-10-28 12:42:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:42:00 --> Pagination Class Initialized
INFO - 2023-10-28 12:42:00 --> Form Validation Class Initialized
INFO - 2023-10-28 12:42:00 --> Controller Class Initialized
DEBUG - 2023-10-28 12:42:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:42:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:00 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:00 --> Model Class Initialized
ERROR - 2023-10-28 12:42:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:42:00 --> Config Class Initialized
INFO - 2023-10-28 12:42:00 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:42:00 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:42:00 --> Utf8 Class Initialized
INFO - 2023-10-28 12:42:00 --> URI Class Initialized
INFO - 2023-10-28 12:42:00 --> Router Class Initialized
INFO - 2023-10-28 12:42:00 --> Output Class Initialized
INFO - 2023-10-28 12:42:00 --> Security Class Initialized
DEBUG - 2023-10-28 12:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:42:00 --> Input Class Initialized
INFO - 2023-10-28 12:42:00 --> Language Class Initialized
INFO - 2023-10-28 12:42:00 --> Loader Class Initialized
INFO - 2023-10-28 12:42:00 --> Helper loaded: url_helper
INFO - 2023-10-28 12:42:00 --> Helper loaded: file_helper
INFO - 2023-10-28 12:42:00 --> Helper loaded: html_helper
INFO - 2023-10-28 12:42:00 --> Helper loaded: text_helper
INFO - 2023-10-28 12:42:00 --> Helper loaded: form_helper
INFO - 2023-10-28 12:42:00 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:42:00 --> Helper loaded: security_helper
INFO - 2023-10-28 12:42:00 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:42:00 --> Database Driver Class Initialized
INFO - 2023-10-28 12:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:42:00 --> Parser Class Initialized
INFO - 2023-10-28 12:42:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:42:00 --> Pagination Class Initialized
INFO - 2023-10-28 12:42:00 --> Form Validation Class Initialized
INFO - 2023-10-28 12:42:00 --> Controller Class Initialized
DEBUG - 2023-10-28 12:42:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:42:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:00 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:00 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:00 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:00 --> Model Class Initialized
INFO - 2023-10-28 12:42:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-10-28 12:42:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 12:42:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 12:42:00 --> Model Class Initialized
INFO - 2023-10-28 12:42:00 --> Model Class Initialized
INFO - 2023-10-28 12:42:00 --> Model Class Initialized
INFO - 2023-10-28 12:42:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 12:42:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 12:42:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 12:42:00 --> Final output sent to browser
DEBUG - 2023-10-28 12:42:00 --> Total execution time: 0.1875
ERROR - 2023-10-28 12:42:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:42:01 --> Config Class Initialized
INFO - 2023-10-28 12:42:01 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:42:01 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:42:01 --> Utf8 Class Initialized
INFO - 2023-10-28 12:42:01 --> URI Class Initialized
INFO - 2023-10-28 12:42:01 --> Router Class Initialized
INFO - 2023-10-28 12:42:01 --> Output Class Initialized
INFO - 2023-10-28 12:42:01 --> Security Class Initialized
DEBUG - 2023-10-28 12:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:42:01 --> Input Class Initialized
INFO - 2023-10-28 12:42:01 --> Language Class Initialized
INFO - 2023-10-28 12:42:01 --> Loader Class Initialized
INFO - 2023-10-28 12:42:01 --> Helper loaded: url_helper
INFO - 2023-10-28 12:42:01 --> Helper loaded: file_helper
INFO - 2023-10-28 12:42:01 --> Helper loaded: html_helper
INFO - 2023-10-28 12:42:01 --> Helper loaded: text_helper
INFO - 2023-10-28 12:42:01 --> Helper loaded: form_helper
INFO - 2023-10-28 12:42:01 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:42:01 --> Helper loaded: security_helper
INFO - 2023-10-28 12:42:01 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:42:01 --> Database Driver Class Initialized
INFO - 2023-10-28 12:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:42:01 --> Parser Class Initialized
INFO - 2023-10-28 12:42:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:42:01 --> Pagination Class Initialized
INFO - 2023-10-28 12:42:01 --> Form Validation Class Initialized
INFO - 2023-10-28 12:42:01 --> Controller Class Initialized
DEBUG - 2023-10-28 12:42:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:42:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:01 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:01 --> Model Class Initialized
INFO - 2023-10-28 12:42:01 --> Final output sent to browser
DEBUG - 2023-10-28 12:42:01 --> Total execution time: 0.0340
ERROR - 2023-10-28 12:42:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:42:10 --> Config Class Initialized
INFO - 2023-10-28 12:42:10 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:42:10 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:42:10 --> Utf8 Class Initialized
INFO - 2023-10-28 12:42:10 --> URI Class Initialized
INFO - 2023-10-28 12:42:10 --> Router Class Initialized
INFO - 2023-10-28 12:42:10 --> Output Class Initialized
INFO - 2023-10-28 12:42:10 --> Security Class Initialized
DEBUG - 2023-10-28 12:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:42:10 --> Input Class Initialized
INFO - 2023-10-28 12:42:10 --> Language Class Initialized
INFO - 2023-10-28 12:42:10 --> Loader Class Initialized
INFO - 2023-10-28 12:42:10 --> Helper loaded: url_helper
INFO - 2023-10-28 12:42:10 --> Helper loaded: file_helper
INFO - 2023-10-28 12:42:10 --> Helper loaded: html_helper
INFO - 2023-10-28 12:42:10 --> Helper loaded: text_helper
INFO - 2023-10-28 12:42:10 --> Helper loaded: form_helper
INFO - 2023-10-28 12:42:10 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:42:10 --> Helper loaded: security_helper
INFO - 2023-10-28 12:42:10 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:42:10 --> Database Driver Class Initialized
INFO - 2023-10-28 12:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:42:10 --> Parser Class Initialized
INFO - 2023-10-28 12:42:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:42:10 --> Pagination Class Initialized
INFO - 2023-10-28 12:42:10 --> Form Validation Class Initialized
INFO - 2023-10-28 12:42:10 --> Controller Class Initialized
INFO - 2023-10-28 12:42:10 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:10 --> Final output sent to browser
DEBUG - 2023-10-28 12:42:10 --> Total execution time: 0.0163
ERROR - 2023-10-28 12:42:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:42:11 --> Config Class Initialized
INFO - 2023-10-28 12:42:11 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:42:11 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:42:11 --> Utf8 Class Initialized
INFO - 2023-10-28 12:42:11 --> URI Class Initialized
INFO - 2023-10-28 12:42:11 --> Router Class Initialized
INFO - 2023-10-28 12:42:11 --> Output Class Initialized
INFO - 2023-10-28 12:42:11 --> Security Class Initialized
DEBUG - 2023-10-28 12:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:42:11 --> Input Class Initialized
INFO - 2023-10-28 12:42:11 --> Language Class Initialized
INFO - 2023-10-28 12:42:11 --> Loader Class Initialized
INFO - 2023-10-28 12:42:11 --> Helper loaded: url_helper
INFO - 2023-10-28 12:42:11 --> Helper loaded: file_helper
INFO - 2023-10-28 12:42:11 --> Helper loaded: html_helper
INFO - 2023-10-28 12:42:11 --> Helper loaded: text_helper
INFO - 2023-10-28 12:42:11 --> Helper loaded: form_helper
INFO - 2023-10-28 12:42:11 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:42:11 --> Helper loaded: security_helper
INFO - 2023-10-28 12:42:11 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:42:11 --> Database Driver Class Initialized
INFO - 2023-10-28 12:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:42:11 --> Parser Class Initialized
INFO - 2023-10-28 12:42:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:42:11 --> Pagination Class Initialized
INFO - 2023-10-28 12:42:11 --> Form Validation Class Initialized
INFO - 2023-10-28 12:42:11 --> Controller Class Initialized
INFO - 2023-10-28 12:42:11 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:11 --> Final output sent to browser
DEBUG - 2023-10-28 12:42:11 --> Total execution time: 0.0189
ERROR - 2023-10-28 12:42:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:42:13 --> Config Class Initialized
INFO - 2023-10-28 12:42:13 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:42:13 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:42:13 --> Utf8 Class Initialized
INFO - 2023-10-28 12:42:13 --> URI Class Initialized
INFO - 2023-10-28 12:42:13 --> Router Class Initialized
INFO - 2023-10-28 12:42:13 --> Output Class Initialized
INFO - 2023-10-28 12:42:13 --> Security Class Initialized
DEBUG - 2023-10-28 12:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:42:13 --> Input Class Initialized
INFO - 2023-10-28 12:42:13 --> Language Class Initialized
INFO - 2023-10-28 12:42:13 --> Loader Class Initialized
INFO - 2023-10-28 12:42:13 --> Helper loaded: url_helper
INFO - 2023-10-28 12:42:13 --> Helper loaded: file_helper
INFO - 2023-10-28 12:42:13 --> Helper loaded: html_helper
INFO - 2023-10-28 12:42:13 --> Helper loaded: text_helper
INFO - 2023-10-28 12:42:13 --> Helper loaded: form_helper
INFO - 2023-10-28 12:42:13 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:42:13 --> Helper loaded: security_helper
INFO - 2023-10-28 12:42:13 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:42:13 --> Database Driver Class Initialized
INFO - 2023-10-28 12:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:42:13 --> Parser Class Initialized
INFO - 2023-10-28 12:42:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:42:13 --> Pagination Class Initialized
INFO - 2023-10-28 12:42:13 --> Form Validation Class Initialized
INFO - 2023-10-28 12:42:13 --> Controller Class Initialized
INFO - 2023-10-28 12:42:13 --> Final output sent to browser
DEBUG - 2023-10-28 12:42:13 --> Total execution time: 0.0139
ERROR - 2023-10-28 12:42:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:42:18 --> Config Class Initialized
INFO - 2023-10-28 12:42:18 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:42:18 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:42:18 --> Utf8 Class Initialized
INFO - 2023-10-28 12:42:18 --> URI Class Initialized
INFO - 2023-10-28 12:42:18 --> Router Class Initialized
INFO - 2023-10-28 12:42:18 --> Output Class Initialized
INFO - 2023-10-28 12:42:18 --> Security Class Initialized
DEBUG - 2023-10-28 12:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:42:18 --> Input Class Initialized
INFO - 2023-10-28 12:42:18 --> Language Class Initialized
INFO - 2023-10-28 12:42:18 --> Loader Class Initialized
INFO - 2023-10-28 12:42:18 --> Helper loaded: url_helper
INFO - 2023-10-28 12:42:18 --> Helper loaded: file_helper
INFO - 2023-10-28 12:42:18 --> Helper loaded: html_helper
INFO - 2023-10-28 12:42:18 --> Helper loaded: text_helper
INFO - 2023-10-28 12:42:18 --> Helper loaded: form_helper
INFO - 2023-10-28 12:42:18 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:42:18 --> Helper loaded: security_helper
INFO - 2023-10-28 12:42:18 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:42:18 --> Database Driver Class Initialized
INFO - 2023-10-28 12:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:42:18 --> Parser Class Initialized
INFO - 2023-10-28 12:42:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:42:18 --> Pagination Class Initialized
INFO - 2023-10-28 12:42:18 --> Form Validation Class Initialized
INFO - 2023-10-28 12:42:18 --> Controller Class Initialized
INFO - 2023-10-28 12:42:18 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:42:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:18 --> Model Class Initialized
INFO - 2023-10-28 12:42:18 --> Final output sent to browser
DEBUG - 2023-10-28 12:42:18 --> Total execution time: 0.0167
ERROR - 2023-10-28 12:42:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:42:27 --> Config Class Initialized
INFO - 2023-10-28 12:42:27 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:42:27 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:42:27 --> Utf8 Class Initialized
INFO - 2023-10-28 12:42:27 --> URI Class Initialized
INFO - 2023-10-28 12:42:27 --> Router Class Initialized
INFO - 2023-10-28 12:42:27 --> Output Class Initialized
INFO - 2023-10-28 12:42:27 --> Security Class Initialized
DEBUG - 2023-10-28 12:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:42:27 --> Input Class Initialized
INFO - 2023-10-28 12:42:27 --> Language Class Initialized
INFO - 2023-10-28 12:42:27 --> Loader Class Initialized
INFO - 2023-10-28 12:42:27 --> Helper loaded: url_helper
INFO - 2023-10-28 12:42:27 --> Helper loaded: file_helper
INFO - 2023-10-28 12:42:27 --> Helper loaded: html_helper
INFO - 2023-10-28 12:42:27 --> Helper loaded: text_helper
INFO - 2023-10-28 12:42:27 --> Helper loaded: form_helper
INFO - 2023-10-28 12:42:27 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:42:27 --> Helper loaded: security_helper
INFO - 2023-10-28 12:42:27 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:42:27 --> Database Driver Class Initialized
INFO - 2023-10-28 12:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:42:27 --> Parser Class Initialized
INFO - 2023-10-28 12:42:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:42:27 --> Pagination Class Initialized
INFO - 2023-10-28 12:42:27 --> Form Validation Class Initialized
INFO - 2023-10-28 12:42:27 --> Controller Class Initialized
INFO - 2023-10-28 12:42:27 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:42:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:27 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:27 --> Model Class Initialized
INFO - 2023-10-28 12:42:27 --> Final output sent to browser
DEBUG - 2023-10-28 12:42:27 --> Total execution time: 0.0522
ERROR - 2023-10-28 12:42:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:42:28 --> Config Class Initialized
INFO - 2023-10-28 12:42:28 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:42:28 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:42:28 --> Utf8 Class Initialized
INFO - 2023-10-28 12:42:28 --> URI Class Initialized
INFO - 2023-10-28 12:42:28 --> Router Class Initialized
INFO - 2023-10-28 12:42:28 --> Output Class Initialized
INFO - 2023-10-28 12:42:28 --> Security Class Initialized
DEBUG - 2023-10-28 12:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:42:28 --> Input Class Initialized
INFO - 2023-10-28 12:42:28 --> Language Class Initialized
INFO - 2023-10-28 12:42:28 --> Loader Class Initialized
INFO - 2023-10-28 12:42:28 --> Helper loaded: url_helper
INFO - 2023-10-28 12:42:28 --> Helper loaded: file_helper
INFO - 2023-10-28 12:42:28 --> Helper loaded: html_helper
INFO - 2023-10-28 12:42:28 --> Helper loaded: text_helper
INFO - 2023-10-28 12:42:28 --> Helper loaded: form_helper
INFO - 2023-10-28 12:42:28 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:42:28 --> Helper loaded: security_helper
INFO - 2023-10-28 12:42:28 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:42:28 --> Database Driver Class Initialized
INFO - 2023-10-28 12:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:42:28 --> Parser Class Initialized
INFO - 2023-10-28 12:42:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:42:28 --> Pagination Class Initialized
INFO - 2023-10-28 12:42:28 --> Form Validation Class Initialized
INFO - 2023-10-28 12:42:28 --> Controller Class Initialized
INFO - 2023-10-28 12:42:28 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:42:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:28 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:28 --> Model Class Initialized
INFO - 2023-10-28 12:42:28 --> Final output sent to browser
DEBUG - 2023-10-28 12:42:28 --> Total execution time: 0.0516
ERROR - 2023-10-28 12:42:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:42:28 --> Config Class Initialized
INFO - 2023-10-28 12:42:28 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:42:28 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:42:28 --> Utf8 Class Initialized
INFO - 2023-10-28 12:42:28 --> URI Class Initialized
INFO - 2023-10-28 12:42:28 --> Router Class Initialized
INFO - 2023-10-28 12:42:28 --> Output Class Initialized
INFO - 2023-10-28 12:42:28 --> Security Class Initialized
DEBUG - 2023-10-28 12:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:42:28 --> Input Class Initialized
INFO - 2023-10-28 12:42:28 --> Language Class Initialized
INFO - 2023-10-28 12:42:28 --> Loader Class Initialized
INFO - 2023-10-28 12:42:28 --> Helper loaded: url_helper
INFO - 2023-10-28 12:42:28 --> Helper loaded: file_helper
INFO - 2023-10-28 12:42:28 --> Helper loaded: html_helper
INFO - 2023-10-28 12:42:28 --> Helper loaded: text_helper
INFO - 2023-10-28 12:42:28 --> Helper loaded: form_helper
INFO - 2023-10-28 12:42:28 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:42:28 --> Helper loaded: security_helper
INFO - 2023-10-28 12:42:28 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:42:28 --> Database Driver Class Initialized
INFO - 2023-10-28 12:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:42:28 --> Parser Class Initialized
INFO - 2023-10-28 12:42:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:42:28 --> Pagination Class Initialized
INFO - 2023-10-28 12:42:28 --> Form Validation Class Initialized
INFO - 2023-10-28 12:42:28 --> Controller Class Initialized
INFO - 2023-10-28 12:42:28 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:42:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:28 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:28 --> Model Class Initialized
INFO - 2023-10-28 12:42:28 --> Final output sent to browser
DEBUG - 2023-10-28 12:42:28 --> Total execution time: 0.0171
ERROR - 2023-10-28 12:42:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:42:29 --> Config Class Initialized
INFO - 2023-10-28 12:42:29 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:42:29 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:42:29 --> Utf8 Class Initialized
INFO - 2023-10-28 12:42:29 --> URI Class Initialized
INFO - 2023-10-28 12:42:29 --> Router Class Initialized
INFO - 2023-10-28 12:42:29 --> Output Class Initialized
INFO - 2023-10-28 12:42:29 --> Security Class Initialized
DEBUG - 2023-10-28 12:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:42:29 --> Input Class Initialized
INFO - 2023-10-28 12:42:29 --> Language Class Initialized
INFO - 2023-10-28 12:42:29 --> Loader Class Initialized
INFO - 2023-10-28 12:42:29 --> Helper loaded: url_helper
INFO - 2023-10-28 12:42:29 --> Helper loaded: file_helper
INFO - 2023-10-28 12:42:29 --> Helper loaded: html_helper
INFO - 2023-10-28 12:42:29 --> Helper loaded: text_helper
INFO - 2023-10-28 12:42:29 --> Helper loaded: form_helper
INFO - 2023-10-28 12:42:29 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:42:29 --> Helper loaded: security_helper
INFO - 2023-10-28 12:42:29 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:42:29 --> Database Driver Class Initialized
INFO - 2023-10-28 12:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:42:29 --> Parser Class Initialized
INFO - 2023-10-28 12:42:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:42:29 --> Pagination Class Initialized
INFO - 2023-10-28 12:42:29 --> Form Validation Class Initialized
INFO - 2023-10-28 12:42:29 --> Controller Class Initialized
INFO - 2023-10-28 12:42:29 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:42:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:29 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:29 --> Model Class Initialized
INFO - 2023-10-28 12:42:29 --> Final output sent to browser
DEBUG - 2023-10-28 12:42:29 --> Total execution time: 0.0171
ERROR - 2023-10-28 12:42:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:42:29 --> Config Class Initialized
INFO - 2023-10-28 12:42:29 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:42:29 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:42:29 --> Utf8 Class Initialized
INFO - 2023-10-28 12:42:29 --> URI Class Initialized
INFO - 2023-10-28 12:42:29 --> Router Class Initialized
INFO - 2023-10-28 12:42:29 --> Output Class Initialized
INFO - 2023-10-28 12:42:29 --> Security Class Initialized
DEBUG - 2023-10-28 12:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:42:29 --> Input Class Initialized
INFO - 2023-10-28 12:42:29 --> Language Class Initialized
INFO - 2023-10-28 12:42:29 --> Loader Class Initialized
INFO - 2023-10-28 12:42:29 --> Helper loaded: url_helper
INFO - 2023-10-28 12:42:29 --> Helper loaded: file_helper
INFO - 2023-10-28 12:42:29 --> Helper loaded: html_helper
INFO - 2023-10-28 12:42:29 --> Helper loaded: text_helper
INFO - 2023-10-28 12:42:29 --> Helper loaded: form_helper
INFO - 2023-10-28 12:42:29 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:42:29 --> Helper loaded: security_helper
INFO - 2023-10-28 12:42:29 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:42:29 --> Database Driver Class Initialized
INFO - 2023-10-28 12:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:42:29 --> Parser Class Initialized
INFO - 2023-10-28 12:42:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:42:29 --> Pagination Class Initialized
INFO - 2023-10-28 12:42:29 --> Form Validation Class Initialized
INFO - 2023-10-28 12:42:29 --> Controller Class Initialized
INFO - 2023-10-28 12:42:29 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:42:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:29 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:29 --> Model Class Initialized
INFO - 2023-10-28 12:42:29 --> Final output sent to browser
DEBUG - 2023-10-28 12:42:29 --> Total execution time: 0.0174
ERROR - 2023-10-28 12:42:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:42:32 --> Config Class Initialized
INFO - 2023-10-28 12:42:32 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:42:32 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:42:32 --> Utf8 Class Initialized
INFO - 2023-10-28 12:42:32 --> URI Class Initialized
INFO - 2023-10-28 12:42:32 --> Router Class Initialized
INFO - 2023-10-28 12:42:32 --> Output Class Initialized
INFO - 2023-10-28 12:42:32 --> Security Class Initialized
DEBUG - 2023-10-28 12:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:42:32 --> Input Class Initialized
INFO - 2023-10-28 12:42:32 --> Language Class Initialized
INFO - 2023-10-28 12:42:32 --> Loader Class Initialized
INFO - 2023-10-28 12:42:32 --> Helper loaded: url_helper
INFO - 2023-10-28 12:42:32 --> Helper loaded: file_helper
INFO - 2023-10-28 12:42:32 --> Helper loaded: html_helper
INFO - 2023-10-28 12:42:32 --> Helper loaded: text_helper
INFO - 2023-10-28 12:42:32 --> Helper loaded: form_helper
INFO - 2023-10-28 12:42:32 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:42:32 --> Helper loaded: security_helper
INFO - 2023-10-28 12:42:32 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:42:32 --> Database Driver Class Initialized
INFO - 2023-10-28 12:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:42:32 --> Parser Class Initialized
INFO - 2023-10-28 12:42:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:42:32 --> Pagination Class Initialized
INFO - 2023-10-28 12:42:32 --> Form Validation Class Initialized
INFO - 2023-10-28 12:42:32 --> Controller Class Initialized
INFO - 2023-10-28 12:42:32 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:42:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:32 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:32 --> Model Class Initialized
INFO - 2023-10-28 12:42:32 --> Final output sent to browser
DEBUG - 2023-10-28 12:42:32 --> Total execution time: 0.0181
ERROR - 2023-10-28 12:42:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:42:34 --> Config Class Initialized
INFO - 2023-10-28 12:42:34 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:42:34 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:42:34 --> Utf8 Class Initialized
INFO - 2023-10-28 12:42:34 --> URI Class Initialized
INFO - 2023-10-28 12:42:34 --> Router Class Initialized
INFO - 2023-10-28 12:42:34 --> Output Class Initialized
INFO - 2023-10-28 12:42:34 --> Security Class Initialized
DEBUG - 2023-10-28 12:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:42:34 --> Input Class Initialized
INFO - 2023-10-28 12:42:34 --> Language Class Initialized
INFO - 2023-10-28 12:42:34 --> Loader Class Initialized
INFO - 2023-10-28 12:42:34 --> Helper loaded: url_helper
INFO - 2023-10-28 12:42:34 --> Helper loaded: file_helper
INFO - 2023-10-28 12:42:34 --> Helper loaded: html_helper
INFO - 2023-10-28 12:42:34 --> Helper loaded: text_helper
INFO - 2023-10-28 12:42:34 --> Helper loaded: form_helper
INFO - 2023-10-28 12:42:34 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:42:34 --> Helper loaded: security_helper
INFO - 2023-10-28 12:42:34 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:42:34 --> Database Driver Class Initialized
INFO - 2023-10-28 12:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:42:34 --> Parser Class Initialized
INFO - 2023-10-28 12:42:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:42:34 --> Pagination Class Initialized
INFO - 2023-10-28 12:42:34 --> Form Validation Class Initialized
INFO - 2023-10-28 12:42:34 --> Controller Class Initialized
INFO - 2023-10-28 12:42:34 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:42:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:34 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:34 --> Model Class Initialized
INFO - 2023-10-28 12:42:34 --> Final output sent to browser
DEBUG - 2023-10-28 12:42:34 --> Total execution time: 0.0633
ERROR - 2023-10-28 12:42:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:42:35 --> Config Class Initialized
INFO - 2023-10-28 12:42:35 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:42:35 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:42:35 --> Utf8 Class Initialized
INFO - 2023-10-28 12:42:35 --> URI Class Initialized
INFO - 2023-10-28 12:42:35 --> Router Class Initialized
INFO - 2023-10-28 12:42:35 --> Output Class Initialized
INFO - 2023-10-28 12:42:35 --> Security Class Initialized
DEBUG - 2023-10-28 12:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:42:35 --> Input Class Initialized
INFO - 2023-10-28 12:42:35 --> Language Class Initialized
INFO - 2023-10-28 12:42:35 --> Loader Class Initialized
INFO - 2023-10-28 12:42:35 --> Helper loaded: url_helper
INFO - 2023-10-28 12:42:35 --> Helper loaded: file_helper
INFO - 2023-10-28 12:42:35 --> Helper loaded: html_helper
INFO - 2023-10-28 12:42:35 --> Helper loaded: text_helper
INFO - 2023-10-28 12:42:35 --> Helper loaded: form_helper
INFO - 2023-10-28 12:42:35 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:42:35 --> Helper loaded: security_helper
INFO - 2023-10-28 12:42:35 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:42:35 --> Database Driver Class Initialized
INFO - 2023-10-28 12:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:42:35 --> Parser Class Initialized
INFO - 2023-10-28 12:42:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:42:35 --> Pagination Class Initialized
INFO - 2023-10-28 12:42:35 --> Form Validation Class Initialized
INFO - 2023-10-28 12:42:35 --> Controller Class Initialized
INFO - 2023-10-28 12:42:35 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:42:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:35 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:35 --> Model Class Initialized
INFO - 2023-10-28 12:42:35 --> Final output sent to browser
DEBUG - 2023-10-28 12:42:35 --> Total execution time: 0.0545
ERROR - 2023-10-28 12:42:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:42:36 --> Config Class Initialized
INFO - 2023-10-28 12:42:36 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:42:36 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:42:36 --> Utf8 Class Initialized
INFO - 2023-10-28 12:42:36 --> URI Class Initialized
INFO - 2023-10-28 12:42:36 --> Router Class Initialized
INFO - 2023-10-28 12:42:36 --> Output Class Initialized
INFO - 2023-10-28 12:42:36 --> Security Class Initialized
DEBUG - 2023-10-28 12:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:42:36 --> Input Class Initialized
INFO - 2023-10-28 12:42:36 --> Language Class Initialized
INFO - 2023-10-28 12:42:36 --> Loader Class Initialized
INFO - 2023-10-28 12:42:36 --> Helper loaded: url_helper
INFO - 2023-10-28 12:42:36 --> Helper loaded: file_helper
INFO - 2023-10-28 12:42:36 --> Helper loaded: html_helper
INFO - 2023-10-28 12:42:36 --> Helper loaded: text_helper
INFO - 2023-10-28 12:42:36 --> Helper loaded: form_helper
INFO - 2023-10-28 12:42:36 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:42:36 --> Helper loaded: security_helper
INFO - 2023-10-28 12:42:36 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:42:36 --> Database Driver Class Initialized
INFO - 2023-10-28 12:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:42:36 --> Parser Class Initialized
INFO - 2023-10-28 12:42:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:42:36 --> Pagination Class Initialized
INFO - 2023-10-28 12:42:36 --> Form Validation Class Initialized
INFO - 2023-10-28 12:42:36 --> Controller Class Initialized
INFO - 2023-10-28 12:42:36 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:42:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:36 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:36 --> Model Class Initialized
INFO - 2023-10-28 12:42:36 --> Final output sent to browser
DEBUG - 2023-10-28 12:42:36 --> Total execution time: 0.0190
ERROR - 2023-10-28 12:42:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:42:36 --> Config Class Initialized
INFO - 2023-10-28 12:42:36 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:42:36 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:42:36 --> Utf8 Class Initialized
INFO - 2023-10-28 12:42:36 --> URI Class Initialized
INFO - 2023-10-28 12:42:36 --> Router Class Initialized
INFO - 2023-10-28 12:42:36 --> Output Class Initialized
INFO - 2023-10-28 12:42:36 --> Security Class Initialized
DEBUG - 2023-10-28 12:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:42:36 --> Input Class Initialized
INFO - 2023-10-28 12:42:36 --> Language Class Initialized
INFO - 2023-10-28 12:42:36 --> Loader Class Initialized
INFO - 2023-10-28 12:42:36 --> Helper loaded: url_helper
INFO - 2023-10-28 12:42:36 --> Helper loaded: file_helper
INFO - 2023-10-28 12:42:36 --> Helper loaded: html_helper
INFO - 2023-10-28 12:42:36 --> Helper loaded: text_helper
INFO - 2023-10-28 12:42:36 --> Helper loaded: form_helper
INFO - 2023-10-28 12:42:36 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:42:36 --> Helper loaded: security_helper
INFO - 2023-10-28 12:42:36 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:42:36 --> Database Driver Class Initialized
INFO - 2023-10-28 12:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:42:36 --> Parser Class Initialized
INFO - 2023-10-28 12:42:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:42:36 --> Pagination Class Initialized
INFO - 2023-10-28 12:42:36 --> Form Validation Class Initialized
INFO - 2023-10-28 12:42:36 --> Controller Class Initialized
INFO - 2023-10-28 12:42:37 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:42:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:37 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:37 --> Model Class Initialized
INFO - 2023-10-28 12:42:37 --> Final output sent to browser
DEBUG - 2023-10-28 12:42:37 --> Total execution time: 0.0189
ERROR - 2023-10-28 12:42:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:42:37 --> Config Class Initialized
INFO - 2023-10-28 12:42:37 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:42:37 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:42:37 --> Utf8 Class Initialized
INFO - 2023-10-28 12:42:37 --> URI Class Initialized
INFO - 2023-10-28 12:42:37 --> Router Class Initialized
INFO - 2023-10-28 12:42:37 --> Output Class Initialized
INFO - 2023-10-28 12:42:37 --> Security Class Initialized
DEBUG - 2023-10-28 12:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:42:37 --> Input Class Initialized
INFO - 2023-10-28 12:42:37 --> Language Class Initialized
INFO - 2023-10-28 12:42:37 --> Loader Class Initialized
INFO - 2023-10-28 12:42:37 --> Helper loaded: url_helper
INFO - 2023-10-28 12:42:37 --> Helper loaded: file_helper
INFO - 2023-10-28 12:42:37 --> Helper loaded: html_helper
INFO - 2023-10-28 12:42:37 --> Helper loaded: text_helper
INFO - 2023-10-28 12:42:37 --> Helper loaded: form_helper
INFO - 2023-10-28 12:42:37 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:42:37 --> Helper loaded: security_helper
INFO - 2023-10-28 12:42:37 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:42:37 --> Database Driver Class Initialized
INFO - 2023-10-28 12:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:42:37 --> Parser Class Initialized
INFO - 2023-10-28 12:42:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:42:37 --> Pagination Class Initialized
INFO - 2023-10-28 12:42:37 --> Form Validation Class Initialized
INFO - 2023-10-28 12:42:37 --> Controller Class Initialized
INFO - 2023-10-28 12:42:37 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:42:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:37 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:37 --> Model Class Initialized
INFO - 2023-10-28 12:42:37 --> Final output sent to browser
DEBUG - 2023-10-28 12:42:37 --> Total execution time: 0.0226
ERROR - 2023-10-28 12:42:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:42:38 --> Config Class Initialized
INFO - 2023-10-28 12:42:38 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:42:38 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:42:38 --> Utf8 Class Initialized
INFO - 2023-10-28 12:42:38 --> URI Class Initialized
INFO - 2023-10-28 12:42:38 --> Router Class Initialized
INFO - 2023-10-28 12:42:38 --> Output Class Initialized
INFO - 2023-10-28 12:42:38 --> Security Class Initialized
DEBUG - 2023-10-28 12:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:42:38 --> Input Class Initialized
INFO - 2023-10-28 12:42:38 --> Language Class Initialized
INFO - 2023-10-28 12:42:38 --> Loader Class Initialized
INFO - 2023-10-28 12:42:38 --> Helper loaded: url_helper
INFO - 2023-10-28 12:42:38 --> Helper loaded: file_helper
INFO - 2023-10-28 12:42:38 --> Helper loaded: html_helper
INFO - 2023-10-28 12:42:38 --> Helper loaded: text_helper
INFO - 2023-10-28 12:42:38 --> Helper loaded: form_helper
INFO - 2023-10-28 12:42:38 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:42:38 --> Helper loaded: security_helper
INFO - 2023-10-28 12:42:38 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:42:38 --> Database Driver Class Initialized
INFO - 2023-10-28 12:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:42:38 --> Parser Class Initialized
INFO - 2023-10-28 12:42:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:42:38 --> Pagination Class Initialized
INFO - 2023-10-28 12:42:38 --> Form Validation Class Initialized
INFO - 2023-10-28 12:42:38 --> Controller Class Initialized
INFO - 2023-10-28 12:42:38 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:42:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:38 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:38 --> Model Class Initialized
INFO - 2023-10-28 12:42:38 --> Final output sent to browser
DEBUG - 2023-10-28 12:42:38 --> Total execution time: 0.0180
ERROR - 2023-10-28 12:42:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:42:40 --> Config Class Initialized
INFO - 2023-10-28 12:42:40 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:42:40 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:42:40 --> Utf8 Class Initialized
INFO - 2023-10-28 12:42:40 --> URI Class Initialized
INFO - 2023-10-28 12:42:40 --> Router Class Initialized
INFO - 2023-10-28 12:42:40 --> Output Class Initialized
INFO - 2023-10-28 12:42:40 --> Security Class Initialized
DEBUG - 2023-10-28 12:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:42:40 --> Input Class Initialized
INFO - 2023-10-28 12:42:40 --> Language Class Initialized
INFO - 2023-10-28 12:42:40 --> Loader Class Initialized
INFO - 2023-10-28 12:42:40 --> Helper loaded: url_helper
INFO - 2023-10-28 12:42:40 --> Helper loaded: file_helper
INFO - 2023-10-28 12:42:40 --> Helper loaded: html_helper
INFO - 2023-10-28 12:42:40 --> Helper loaded: text_helper
INFO - 2023-10-28 12:42:40 --> Helper loaded: form_helper
INFO - 2023-10-28 12:42:40 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:42:40 --> Helper loaded: security_helper
INFO - 2023-10-28 12:42:40 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:42:40 --> Database Driver Class Initialized
INFO - 2023-10-28 12:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:42:40 --> Parser Class Initialized
INFO - 2023-10-28 12:42:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:42:40 --> Pagination Class Initialized
INFO - 2023-10-28 12:42:40 --> Form Validation Class Initialized
INFO - 2023-10-28 12:42:40 --> Controller Class Initialized
INFO - 2023-10-28 12:42:40 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:42:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:40 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:40 --> Model Class Initialized
INFO - 2023-10-28 12:42:40 --> Final output sent to browser
DEBUG - 2023-10-28 12:42:40 --> Total execution time: 0.0223
ERROR - 2023-10-28 12:42:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:42:40 --> Config Class Initialized
INFO - 2023-10-28 12:42:40 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:42:40 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:42:40 --> Utf8 Class Initialized
INFO - 2023-10-28 12:42:40 --> URI Class Initialized
INFO - 2023-10-28 12:42:40 --> Router Class Initialized
INFO - 2023-10-28 12:42:40 --> Output Class Initialized
INFO - 2023-10-28 12:42:40 --> Security Class Initialized
DEBUG - 2023-10-28 12:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:42:40 --> Input Class Initialized
INFO - 2023-10-28 12:42:40 --> Language Class Initialized
INFO - 2023-10-28 12:42:40 --> Loader Class Initialized
INFO - 2023-10-28 12:42:40 --> Helper loaded: url_helper
INFO - 2023-10-28 12:42:40 --> Helper loaded: file_helper
INFO - 2023-10-28 12:42:40 --> Helper loaded: html_helper
INFO - 2023-10-28 12:42:40 --> Helper loaded: text_helper
INFO - 2023-10-28 12:42:40 --> Helper loaded: form_helper
INFO - 2023-10-28 12:42:40 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:42:40 --> Helper loaded: security_helper
INFO - 2023-10-28 12:42:40 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:42:41 --> Database Driver Class Initialized
INFO - 2023-10-28 12:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:42:41 --> Parser Class Initialized
INFO - 2023-10-28 12:42:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:42:41 --> Pagination Class Initialized
INFO - 2023-10-28 12:42:41 --> Form Validation Class Initialized
INFO - 2023-10-28 12:42:41 --> Controller Class Initialized
INFO - 2023-10-28 12:42:41 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:42:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:41 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:41 --> Model Class Initialized
INFO - 2023-10-28 12:42:41 --> Final output sent to browser
DEBUG - 2023-10-28 12:42:41 --> Total execution time: 0.0553
ERROR - 2023-10-28 12:42:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:42:42 --> Config Class Initialized
INFO - 2023-10-28 12:42:42 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:42:42 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:42:42 --> Utf8 Class Initialized
INFO - 2023-10-28 12:42:42 --> URI Class Initialized
INFO - 2023-10-28 12:42:42 --> Router Class Initialized
INFO - 2023-10-28 12:42:42 --> Output Class Initialized
INFO - 2023-10-28 12:42:42 --> Security Class Initialized
DEBUG - 2023-10-28 12:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:42:42 --> Input Class Initialized
INFO - 2023-10-28 12:42:42 --> Language Class Initialized
INFO - 2023-10-28 12:42:42 --> Loader Class Initialized
INFO - 2023-10-28 12:42:42 --> Helper loaded: url_helper
INFO - 2023-10-28 12:42:42 --> Helper loaded: file_helper
INFO - 2023-10-28 12:42:42 --> Helper loaded: html_helper
INFO - 2023-10-28 12:42:42 --> Helper loaded: text_helper
INFO - 2023-10-28 12:42:42 --> Helper loaded: form_helper
INFO - 2023-10-28 12:42:42 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:42:42 --> Helper loaded: security_helper
INFO - 2023-10-28 12:42:42 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:42:42 --> Database Driver Class Initialized
INFO - 2023-10-28 12:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:42:42 --> Parser Class Initialized
INFO - 2023-10-28 12:42:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:42:42 --> Pagination Class Initialized
INFO - 2023-10-28 12:42:42 --> Form Validation Class Initialized
INFO - 2023-10-28 12:42:42 --> Controller Class Initialized
INFO - 2023-10-28 12:42:42 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:42:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:42 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:42 --> Model Class Initialized
INFO - 2023-10-28 12:42:42 --> Final output sent to browser
DEBUG - 2023-10-28 12:42:42 --> Total execution time: 0.0198
ERROR - 2023-10-28 12:42:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:42:44 --> Config Class Initialized
INFO - 2023-10-28 12:42:44 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:42:44 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:42:44 --> Utf8 Class Initialized
INFO - 2023-10-28 12:42:44 --> URI Class Initialized
INFO - 2023-10-28 12:42:44 --> Router Class Initialized
INFO - 2023-10-28 12:42:44 --> Output Class Initialized
INFO - 2023-10-28 12:42:44 --> Security Class Initialized
DEBUG - 2023-10-28 12:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:42:44 --> Input Class Initialized
INFO - 2023-10-28 12:42:44 --> Language Class Initialized
INFO - 2023-10-28 12:42:44 --> Loader Class Initialized
INFO - 2023-10-28 12:42:44 --> Helper loaded: url_helper
INFO - 2023-10-28 12:42:44 --> Helper loaded: file_helper
INFO - 2023-10-28 12:42:44 --> Helper loaded: html_helper
INFO - 2023-10-28 12:42:44 --> Helper loaded: text_helper
INFO - 2023-10-28 12:42:44 --> Helper loaded: form_helper
INFO - 2023-10-28 12:42:44 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:42:44 --> Helper loaded: security_helper
INFO - 2023-10-28 12:42:44 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:42:44 --> Database Driver Class Initialized
INFO - 2023-10-28 12:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:42:44 --> Parser Class Initialized
INFO - 2023-10-28 12:42:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:42:44 --> Pagination Class Initialized
INFO - 2023-10-28 12:42:44 --> Form Validation Class Initialized
INFO - 2023-10-28 12:42:44 --> Controller Class Initialized
INFO - 2023-10-28 12:42:44 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:42:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:44 --> Model Class Initialized
INFO - 2023-10-28 12:42:44 --> Model Class Initialized
INFO - 2023-10-28 12:42:44 --> Final output sent to browser
DEBUG - 2023-10-28 12:42:44 --> Total execution time: 0.0189
ERROR - 2023-10-28 12:42:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:42:47 --> Config Class Initialized
INFO - 2023-10-28 12:42:47 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:42:47 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:42:47 --> Utf8 Class Initialized
INFO - 2023-10-28 12:42:47 --> URI Class Initialized
INFO - 2023-10-28 12:42:47 --> Router Class Initialized
INFO - 2023-10-28 12:42:47 --> Output Class Initialized
INFO - 2023-10-28 12:42:47 --> Security Class Initialized
DEBUG - 2023-10-28 12:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:42:47 --> Input Class Initialized
INFO - 2023-10-28 12:42:47 --> Language Class Initialized
INFO - 2023-10-28 12:42:47 --> Loader Class Initialized
INFO - 2023-10-28 12:42:47 --> Helper loaded: url_helper
INFO - 2023-10-28 12:42:47 --> Helper loaded: file_helper
INFO - 2023-10-28 12:42:47 --> Helper loaded: html_helper
INFO - 2023-10-28 12:42:47 --> Helper loaded: text_helper
INFO - 2023-10-28 12:42:47 --> Helper loaded: form_helper
INFO - 2023-10-28 12:42:47 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:42:47 --> Helper loaded: security_helper
INFO - 2023-10-28 12:42:47 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:42:47 --> Database Driver Class Initialized
INFO - 2023-10-28 12:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:42:47 --> Parser Class Initialized
INFO - 2023-10-28 12:42:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:42:47 --> Pagination Class Initialized
INFO - 2023-10-28 12:42:47 --> Form Validation Class Initialized
INFO - 2023-10-28 12:42:47 --> Controller Class Initialized
INFO - 2023-10-28 12:42:47 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:42:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:47 --> Model Class Initialized
INFO - 2023-10-28 12:42:47 --> Final output sent to browser
DEBUG - 2023-10-28 12:42:47 --> Total execution time: 0.0165
ERROR - 2023-10-28 12:42:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:42:55 --> Config Class Initialized
INFO - 2023-10-28 12:42:55 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:42:55 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:42:55 --> Utf8 Class Initialized
INFO - 2023-10-28 12:42:55 --> URI Class Initialized
INFO - 2023-10-28 12:42:55 --> Router Class Initialized
INFO - 2023-10-28 12:42:55 --> Output Class Initialized
INFO - 2023-10-28 12:42:55 --> Security Class Initialized
DEBUG - 2023-10-28 12:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:42:55 --> Input Class Initialized
INFO - 2023-10-28 12:42:55 --> Language Class Initialized
INFO - 2023-10-28 12:42:55 --> Loader Class Initialized
INFO - 2023-10-28 12:42:55 --> Helper loaded: url_helper
INFO - 2023-10-28 12:42:55 --> Helper loaded: file_helper
INFO - 2023-10-28 12:42:55 --> Helper loaded: html_helper
INFO - 2023-10-28 12:42:55 --> Helper loaded: text_helper
INFO - 2023-10-28 12:42:55 --> Helper loaded: form_helper
INFO - 2023-10-28 12:42:55 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:42:55 --> Helper loaded: security_helper
INFO - 2023-10-28 12:42:55 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:42:55 --> Database Driver Class Initialized
INFO - 2023-10-28 12:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:42:55 --> Parser Class Initialized
INFO - 2023-10-28 12:42:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:42:55 --> Pagination Class Initialized
INFO - 2023-10-28 12:42:55 --> Form Validation Class Initialized
INFO - 2023-10-28 12:42:55 --> Controller Class Initialized
INFO - 2023-10-28 12:42:55 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:42:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:55 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:55 --> Model Class Initialized
INFO - 2023-10-28 12:42:55 --> Final output sent to browser
DEBUG - 2023-10-28 12:42:55 --> Total execution time: 0.0521
ERROR - 2023-10-28 12:42:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:42:56 --> Config Class Initialized
INFO - 2023-10-28 12:42:56 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:42:56 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:42:56 --> Utf8 Class Initialized
INFO - 2023-10-28 12:42:56 --> URI Class Initialized
INFO - 2023-10-28 12:42:56 --> Router Class Initialized
INFO - 2023-10-28 12:42:56 --> Output Class Initialized
INFO - 2023-10-28 12:42:56 --> Security Class Initialized
DEBUG - 2023-10-28 12:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:42:56 --> Input Class Initialized
INFO - 2023-10-28 12:42:56 --> Language Class Initialized
INFO - 2023-10-28 12:42:56 --> Loader Class Initialized
INFO - 2023-10-28 12:42:56 --> Helper loaded: url_helper
INFO - 2023-10-28 12:42:56 --> Helper loaded: file_helper
INFO - 2023-10-28 12:42:56 --> Helper loaded: html_helper
INFO - 2023-10-28 12:42:56 --> Helper loaded: text_helper
INFO - 2023-10-28 12:42:56 --> Helper loaded: form_helper
INFO - 2023-10-28 12:42:56 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:42:56 --> Helper loaded: security_helper
INFO - 2023-10-28 12:42:56 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:42:56 --> Database Driver Class Initialized
INFO - 2023-10-28 12:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:42:56 --> Parser Class Initialized
INFO - 2023-10-28 12:42:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:42:56 --> Pagination Class Initialized
INFO - 2023-10-28 12:42:56 --> Form Validation Class Initialized
INFO - 2023-10-28 12:42:56 --> Controller Class Initialized
INFO - 2023-10-28 12:42:56 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:42:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:56 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:56 --> Model Class Initialized
INFO - 2023-10-28 12:42:56 --> Final output sent to browser
DEBUG - 2023-10-28 12:42:56 --> Total execution time: 0.0549
ERROR - 2023-10-28 12:42:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:42:56 --> Config Class Initialized
INFO - 2023-10-28 12:42:56 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:42:56 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:42:56 --> Utf8 Class Initialized
INFO - 2023-10-28 12:42:56 --> URI Class Initialized
INFO - 2023-10-28 12:42:56 --> Router Class Initialized
INFO - 2023-10-28 12:42:56 --> Output Class Initialized
INFO - 2023-10-28 12:42:56 --> Security Class Initialized
DEBUG - 2023-10-28 12:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:42:56 --> Input Class Initialized
INFO - 2023-10-28 12:42:56 --> Language Class Initialized
INFO - 2023-10-28 12:42:56 --> Loader Class Initialized
INFO - 2023-10-28 12:42:56 --> Helper loaded: url_helper
INFO - 2023-10-28 12:42:56 --> Helper loaded: file_helper
INFO - 2023-10-28 12:42:56 --> Helper loaded: html_helper
INFO - 2023-10-28 12:42:56 --> Helper loaded: text_helper
INFO - 2023-10-28 12:42:56 --> Helper loaded: form_helper
INFO - 2023-10-28 12:42:56 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:42:56 --> Helper loaded: security_helper
INFO - 2023-10-28 12:42:56 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:42:56 --> Database Driver Class Initialized
INFO - 2023-10-28 12:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:42:56 --> Parser Class Initialized
INFO - 2023-10-28 12:42:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:42:56 --> Pagination Class Initialized
INFO - 2023-10-28 12:42:56 --> Form Validation Class Initialized
INFO - 2023-10-28 12:42:56 --> Controller Class Initialized
INFO - 2023-10-28 12:42:56 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:42:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:56 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:56 --> Model Class Initialized
INFO - 2023-10-28 12:42:57 --> Final output sent to browser
DEBUG - 2023-10-28 12:42:57 --> Total execution time: 0.0597
ERROR - 2023-10-28 12:42:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:42:57 --> Config Class Initialized
INFO - 2023-10-28 12:42:57 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:42:57 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:42:57 --> Utf8 Class Initialized
INFO - 2023-10-28 12:42:57 --> URI Class Initialized
INFO - 2023-10-28 12:42:57 --> Router Class Initialized
INFO - 2023-10-28 12:42:57 --> Output Class Initialized
INFO - 2023-10-28 12:42:57 --> Security Class Initialized
DEBUG - 2023-10-28 12:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:42:57 --> Input Class Initialized
INFO - 2023-10-28 12:42:57 --> Language Class Initialized
INFO - 2023-10-28 12:42:57 --> Loader Class Initialized
INFO - 2023-10-28 12:42:57 --> Helper loaded: url_helper
INFO - 2023-10-28 12:42:57 --> Helper loaded: file_helper
INFO - 2023-10-28 12:42:57 --> Helper loaded: html_helper
INFO - 2023-10-28 12:42:57 --> Helper loaded: text_helper
INFO - 2023-10-28 12:42:57 --> Helper loaded: form_helper
INFO - 2023-10-28 12:42:57 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:42:57 --> Helper loaded: security_helper
INFO - 2023-10-28 12:42:57 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:42:57 --> Database Driver Class Initialized
INFO - 2023-10-28 12:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:42:57 --> Parser Class Initialized
INFO - 2023-10-28 12:42:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:42:57 --> Pagination Class Initialized
INFO - 2023-10-28 12:42:57 --> Form Validation Class Initialized
INFO - 2023-10-28 12:42:57 --> Controller Class Initialized
INFO - 2023-10-28 12:42:57 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:42:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:57 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:57 --> Model Class Initialized
INFO - 2023-10-28 12:42:57 --> Final output sent to browser
DEBUG - 2023-10-28 12:42:57 --> Total execution time: 0.0541
ERROR - 2023-10-28 12:42:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:42:58 --> Config Class Initialized
INFO - 2023-10-28 12:42:58 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:42:58 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:42:58 --> Utf8 Class Initialized
INFO - 2023-10-28 12:42:58 --> URI Class Initialized
INFO - 2023-10-28 12:42:58 --> Router Class Initialized
INFO - 2023-10-28 12:42:58 --> Output Class Initialized
INFO - 2023-10-28 12:42:58 --> Security Class Initialized
DEBUG - 2023-10-28 12:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:42:58 --> Input Class Initialized
INFO - 2023-10-28 12:42:58 --> Language Class Initialized
INFO - 2023-10-28 12:42:58 --> Loader Class Initialized
INFO - 2023-10-28 12:42:58 --> Helper loaded: url_helper
INFO - 2023-10-28 12:42:58 --> Helper loaded: file_helper
INFO - 2023-10-28 12:42:58 --> Helper loaded: html_helper
INFO - 2023-10-28 12:42:58 --> Helper loaded: text_helper
INFO - 2023-10-28 12:42:58 --> Helper loaded: form_helper
INFO - 2023-10-28 12:42:58 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:42:58 --> Helper loaded: security_helper
INFO - 2023-10-28 12:42:58 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:42:58 --> Database Driver Class Initialized
INFO - 2023-10-28 12:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:42:58 --> Parser Class Initialized
INFO - 2023-10-28 12:42:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:42:58 --> Pagination Class Initialized
INFO - 2023-10-28 12:42:58 --> Form Validation Class Initialized
INFO - 2023-10-28 12:42:58 --> Controller Class Initialized
INFO - 2023-10-28 12:42:58 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:42:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:58 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:58 --> Model Class Initialized
INFO - 2023-10-28 12:42:58 --> Final output sent to browser
DEBUG - 2023-10-28 12:42:58 --> Total execution time: 0.0273
ERROR - 2023-10-28 12:42:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:42:58 --> Config Class Initialized
INFO - 2023-10-28 12:42:58 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:42:58 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:42:58 --> Utf8 Class Initialized
INFO - 2023-10-28 12:42:58 --> URI Class Initialized
INFO - 2023-10-28 12:42:58 --> Router Class Initialized
INFO - 2023-10-28 12:42:58 --> Output Class Initialized
INFO - 2023-10-28 12:42:58 --> Security Class Initialized
DEBUG - 2023-10-28 12:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:42:58 --> Input Class Initialized
INFO - 2023-10-28 12:42:58 --> Language Class Initialized
INFO - 2023-10-28 12:42:58 --> Loader Class Initialized
INFO - 2023-10-28 12:42:58 --> Helper loaded: url_helper
INFO - 2023-10-28 12:42:58 --> Helper loaded: file_helper
INFO - 2023-10-28 12:42:58 --> Helper loaded: html_helper
INFO - 2023-10-28 12:42:58 --> Helper loaded: text_helper
INFO - 2023-10-28 12:42:58 --> Helper loaded: form_helper
INFO - 2023-10-28 12:42:58 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:42:58 --> Helper loaded: security_helper
INFO - 2023-10-28 12:42:58 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:42:58 --> Database Driver Class Initialized
INFO - 2023-10-28 12:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:42:58 --> Parser Class Initialized
INFO - 2023-10-28 12:42:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:42:58 --> Pagination Class Initialized
INFO - 2023-10-28 12:42:58 --> Form Validation Class Initialized
INFO - 2023-10-28 12:42:58 --> Controller Class Initialized
INFO - 2023-10-28 12:42:58 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:42:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:58 --> Model Class Initialized
DEBUG - 2023-10-28 12:42:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:42:58 --> Model Class Initialized
INFO - 2023-10-28 12:42:58 --> Final output sent to browser
DEBUG - 2023-10-28 12:42:58 --> Total execution time: 0.0200
ERROR - 2023-10-28 12:43:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:43:01 --> Config Class Initialized
INFO - 2023-10-28 12:43:01 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:43:01 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:43:01 --> Utf8 Class Initialized
INFO - 2023-10-28 12:43:01 --> URI Class Initialized
INFO - 2023-10-28 12:43:01 --> Router Class Initialized
INFO - 2023-10-28 12:43:01 --> Output Class Initialized
INFO - 2023-10-28 12:43:01 --> Security Class Initialized
DEBUG - 2023-10-28 12:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:43:01 --> Input Class Initialized
INFO - 2023-10-28 12:43:01 --> Language Class Initialized
INFO - 2023-10-28 12:43:01 --> Loader Class Initialized
INFO - 2023-10-28 12:43:01 --> Helper loaded: url_helper
INFO - 2023-10-28 12:43:01 --> Helper loaded: file_helper
INFO - 2023-10-28 12:43:01 --> Helper loaded: html_helper
INFO - 2023-10-28 12:43:01 --> Helper loaded: text_helper
INFO - 2023-10-28 12:43:01 --> Helper loaded: form_helper
INFO - 2023-10-28 12:43:01 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:43:01 --> Helper loaded: security_helper
INFO - 2023-10-28 12:43:01 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:43:01 --> Database Driver Class Initialized
INFO - 2023-10-28 12:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:43:01 --> Parser Class Initialized
INFO - 2023-10-28 12:43:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:43:01 --> Pagination Class Initialized
INFO - 2023-10-28 12:43:01 --> Form Validation Class Initialized
INFO - 2023-10-28 12:43:01 --> Controller Class Initialized
INFO - 2023-10-28 12:43:01 --> Model Class Initialized
DEBUG - 2023-10-28 12:43:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:43:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:43:01 --> Model Class Initialized
INFO - 2023-10-28 12:43:01 --> Model Class Initialized
INFO - 2023-10-28 12:43:01 --> Final output sent to browser
DEBUG - 2023-10-28 12:43:01 --> Total execution time: 0.0263
ERROR - 2023-10-28 12:43:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:43:01 --> Config Class Initialized
INFO - 2023-10-28 12:43:01 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:43:01 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:43:01 --> Utf8 Class Initialized
INFO - 2023-10-28 12:43:01 --> URI Class Initialized
INFO - 2023-10-28 12:43:01 --> Router Class Initialized
INFO - 2023-10-28 12:43:01 --> Output Class Initialized
INFO - 2023-10-28 12:43:01 --> Security Class Initialized
DEBUG - 2023-10-28 12:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:43:01 --> Input Class Initialized
INFO - 2023-10-28 12:43:01 --> Language Class Initialized
INFO - 2023-10-28 12:43:01 --> Loader Class Initialized
INFO - 2023-10-28 12:43:01 --> Helper loaded: url_helper
INFO - 2023-10-28 12:43:01 --> Helper loaded: file_helper
INFO - 2023-10-28 12:43:01 --> Helper loaded: html_helper
INFO - 2023-10-28 12:43:01 --> Helper loaded: text_helper
INFO - 2023-10-28 12:43:01 --> Helper loaded: form_helper
INFO - 2023-10-28 12:43:01 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:43:01 --> Helper loaded: security_helper
INFO - 2023-10-28 12:43:01 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:43:01 --> Database Driver Class Initialized
INFO - 2023-10-28 12:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:43:01 --> Parser Class Initialized
INFO - 2023-10-28 12:43:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:43:01 --> Pagination Class Initialized
INFO - 2023-10-28 12:43:01 --> Form Validation Class Initialized
INFO - 2023-10-28 12:43:01 --> Controller Class Initialized
INFO - 2023-10-28 12:43:01 --> Model Class Initialized
DEBUG - 2023-10-28 12:43:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:43:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:43:01 --> Model Class Initialized
DEBUG - 2023-10-28 12:43:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:43:01 --> Model Class Initialized
INFO - 2023-10-28 12:43:01 --> Final output sent to browser
DEBUG - 2023-10-28 12:43:01 --> Total execution time: 0.0202
ERROR - 2023-10-28 12:43:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:43:03 --> Config Class Initialized
INFO - 2023-10-28 12:43:03 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:43:03 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:43:03 --> Utf8 Class Initialized
INFO - 2023-10-28 12:43:03 --> URI Class Initialized
INFO - 2023-10-28 12:43:03 --> Router Class Initialized
INFO - 2023-10-28 12:43:03 --> Output Class Initialized
INFO - 2023-10-28 12:43:03 --> Security Class Initialized
DEBUG - 2023-10-28 12:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:43:03 --> Input Class Initialized
INFO - 2023-10-28 12:43:03 --> Language Class Initialized
INFO - 2023-10-28 12:43:03 --> Loader Class Initialized
INFO - 2023-10-28 12:43:03 --> Helper loaded: url_helper
INFO - 2023-10-28 12:43:03 --> Helper loaded: file_helper
INFO - 2023-10-28 12:43:03 --> Helper loaded: html_helper
INFO - 2023-10-28 12:43:03 --> Helper loaded: text_helper
INFO - 2023-10-28 12:43:03 --> Helper loaded: form_helper
INFO - 2023-10-28 12:43:03 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:43:03 --> Helper loaded: security_helper
INFO - 2023-10-28 12:43:03 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:43:03 --> Database Driver Class Initialized
INFO - 2023-10-28 12:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:43:03 --> Parser Class Initialized
INFO - 2023-10-28 12:43:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:43:03 --> Pagination Class Initialized
INFO - 2023-10-28 12:43:03 --> Form Validation Class Initialized
INFO - 2023-10-28 12:43:03 --> Controller Class Initialized
INFO - 2023-10-28 12:43:03 --> Model Class Initialized
DEBUG - 2023-10-28 12:43:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:43:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:43:03 --> Model Class Initialized
INFO - 2023-10-28 12:43:03 --> Final output sent to browser
DEBUG - 2023-10-28 12:43:03 --> Total execution time: 0.0198
ERROR - 2023-10-28 12:43:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:43:12 --> Config Class Initialized
INFO - 2023-10-28 12:43:12 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:43:12 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:43:12 --> Utf8 Class Initialized
INFO - 2023-10-28 12:43:12 --> URI Class Initialized
INFO - 2023-10-28 12:43:12 --> Router Class Initialized
INFO - 2023-10-28 12:43:12 --> Output Class Initialized
INFO - 2023-10-28 12:43:12 --> Security Class Initialized
DEBUG - 2023-10-28 12:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:43:12 --> Input Class Initialized
INFO - 2023-10-28 12:43:12 --> Language Class Initialized
INFO - 2023-10-28 12:43:12 --> Loader Class Initialized
INFO - 2023-10-28 12:43:12 --> Helper loaded: url_helper
INFO - 2023-10-28 12:43:12 --> Helper loaded: file_helper
INFO - 2023-10-28 12:43:12 --> Helper loaded: html_helper
INFO - 2023-10-28 12:43:12 --> Helper loaded: text_helper
INFO - 2023-10-28 12:43:12 --> Helper loaded: form_helper
INFO - 2023-10-28 12:43:12 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:43:12 --> Helper loaded: security_helper
INFO - 2023-10-28 12:43:12 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:43:12 --> Database Driver Class Initialized
INFO - 2023-10-28 12:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:43:12 --> Parser Class Initialized
INFO - 2023-10-28 12:43:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:43:12 --> Pagination Class Initialized
INFO - 2023-10-28 12:43:12 --> Form Validation Class Initialized
INFO - 2023-10-28 12:43:12 --> Controller Class Initialized
INFO - 2023-10-28 12:43:12 --> Model Class Initialized
DEBUG - 2023-10-28 12:43:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:43:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:43:12 --> Model Class Initialized
DEBUG - 2023-10-28 12:43:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:43:12 --> Model Class Initialized
INFO - 2023-10-28 12:43:12 --> Final output sent to browser
DEBUG - 2023-10-28 12:43:12 --> Total execution time: 0.0581
ERROR - 2023-10-28 12:43:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:43:13 --> Config Class Initialized
INFO - 2023-10-28 12:43:13 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:43:13 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:43:13 --> Utf8 Class Initialized
INFO - 2023-10-28 12:43:13 --> URI Class Initialized
INFO - 2023-10-28 12:43:13 --> Router Class Initialized
INFO - 2023-10-28 12:43:13 --> Output Class Initialized
INFO - 2023-10-28 12:43:13 --> Security Class Initialized
DEBUG - 2023-10-28 12:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:43:13 --> Input Class Initialized
INFO - 2023-10-28 12:43:13 --> Language Class Initialized
INFO - 2023-10-28 12:43:13 --> Loader Class Initialized
INFO - 2023-10-28 12:43:13 --> Helper loaded: url_helper
INFO - 2023-10-28 12:43:13 --> Helper loaded: file_helper
INFO - 2023-10-28 12:43:13 --> Helper loaded: html_helper
INFO - 2023-10-28 12:43:13 --> Helper loaded: text_helper
INFO - 2023-10-28 12:43:13 --> Helper loaded: form_helper
INFO - 2023-10-28 12:43:13 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:43:13 --> Helper loaded: security_helper
INFO - 2023-10-28 12:43:13 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:43:13 --> Database Driver Class Initialized
INFO - 2023-10-28 12:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:43:13 --> Parser Class Initialized
INFO - 2023-10-28 12:43:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:43:13 --> Pagination Class Initialized
INFO - 2023-10-28 12:43:13 --> Form Validation Class Initialized
INFO - 2023-10-28 12:43:13 --> Controller Class Initialized
INFO - 2023-10-28 12:43:13 --> Model Class Initialized
DEBUG - 2023-10-28 12:43:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:43:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:43:13 --> Model Class Initialized
DEBUG - 2023-10-28 12:43:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:43:13 --> Model Class Initialized
INFO - 2023-10-28 12:43:13 --> Final output sent to browser
DEBUG - 2023-10-28 12:43:13 --> Total execution time: 0.0524
ERROR - 2023-10-28 12:43:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:43:13 --> Config Class Initialized
INFO - 2023-10-28 12:43:13 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:43:13 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:43:13 --> Utf8 Class Initialized
INFO - 2023-10-28 12:43:13 --> URI Class Initialized
INFO - 2023-10-28 12:43:13 --> Router Class Initialized
INFO - 2023-10-28 12:43:13 --> Output Class Initialized
INFO - 2023-10-28 12:43:13 --> Security Class Initialized
DEBUG - 2023-10-28 12:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:43:13 --> Input Class Initialized
INFO - 2023-10-28 12:43:13 --> Language Class Initialized
INFO - 2023-10-28 12:43:13 --> Loader Class Initialized
INFO - 2023-10-28 12:43:13 --> Helper loaded: url_helper
INFO - 2023-10-28 12:43:13 --> Helper loaded: file_helper
INFO - 2023-10-28 12:43:13 --> Helper loaded: html_helper
INFO - 2023-10-28 12:43:13 --> Helper loaded: text_helper
INFO - 2023-10-28 12:43:13 --> Helper loaded: form_helper
INFO - 2023-10-28 12:43:13 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:43:13 --> Helper loaded: security_helper
INFO - 2023-10-28 12:43:13 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:43:13 --> Database Driver Class Initialized
INFO - 2023-10-28 12:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:43:13 --> Parser Class Initialized
INFO - 2023-10-28 12:43:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:43:13 --> Pagination Class Initialized
INFO - 2023-10-28 12:43:13 --> Form Validation Class Initialized
INFO - 2023-10-28 12:43:13 --> Controller Class Initialized
INFO - 2023-10-28 12:43:13 --> Model Class Initialized
DEBUG - 2023-10-28 12:43:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:43:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:43:13 --> Model Class Initialized
DEBUG - 2023-10-28 12:43:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:43:13 --> Model Class Initialized
INFO - 2023-10-28 12:43:13 --> Final output sent to browser
DEBUG - 2023-10-28 12:43:13 --> Total execution time: 0.0507
ERROR - 2023-10-28 12:43:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:43:14 --> Config Class Initialized
INFO - 2023-10-28 12:43:14 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:43:14 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:43:14 --> Utf8 Class Initialized
INFO - 2023-10-28 12:43:14 --> URI Class Initialized
INFO - 2023-10-28 12:43:14 --> Router Class Initialized
INFO - 2023-10-28 12:43:14 --> Output Class Initialized
INFO - 2023-10-28 12:43:14 --> Security Class Initialized
DEBUG - 2023-10-28 12:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:43:14 --> Input Class Initialized
INFO - 2023-10-28 12:43:14 --> Language Class Initialized
INFO - 2023-10-28 12:43:14 --> Loader Class Initialized
INFO - 2023-10-28 12:43:14 --> Helper loaded: url_helper
INFO - 2023-10-28 12:43:14 --> Helper loaded: file_helper
INFO - 2023-10-28 12:43:14 --> Helper loaded: html_helper
INFO - 2023-10-28 12:43:14 --> Helper loaded: text_helper
INFO - 2023-10-28 12:43:14 --> Helper loaded: form_helper
INFO - 2023-10-28 12:43:14 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:43:14 --> Helper loaded: security_helper
INFO - 2023-10-28 12:43:14 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:43:14 --> Database Driver Class Initialized
INFO - 2023-10-28 12:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:43:14 --> Parser Class Initialized
INFO - 2023-10-28 12:43:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:43:14 --> Pagination Class Initialized
INFO - 2023-10-28 12:43:14 --> Form Validation Class Initialized
INFO - 2023-10-28 12:43:14 --> Controller Class Initialized
INFO - 2023-10-28 12:43:14 --> Model Class Initialized
DEBUG - 2023-10-28 12:43:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:43:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:43:14 --> Model Class Initialized
DEBUG - 2023-10-28 12:43:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:43:14 --> Model Class Initialized
INFO - 2023-10-28 12:43:14 --> Final output sent to browser
DEBUG - 2023-10-28 12:43:14 --> Total execution time: 0.0507
ERROR - 2023-10-28 12:43:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:43:18 --> Config Class Initialized
INFO - 2023-10-28 12:43:18 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:43:18 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:43:18 --> Utf8 Class Initialized
INFO - 2023-10-28 12:43:18 --> URI Class Initialized
INFO - 2023-10-28 12:43:18 --> Router Class Initialized
INFO - 2023-10-28 12:43:18 --> Output Class Initialized
INFO - 2023-10-28 12:43:18 --> Security Class Initialized
DEBUG - 2023-10-28 12:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:43:18 --> Input Class Initialized
INFO - 2023-10-28 12:43:18 --> Language Class Initialized
INFO - 2023-10-28 12:43:18 --> Loader Class Initialized
INFO - 2023-10-28 12:43:18 --> Helper loaded: url_helper
INFO - 2023-10-28 12:43:18 --> Helper loaded: file_helper
INFO - 2023-10-28 12:43:18 --> Helper loaded: html_helper
INFO - 2023-10-28 12:43:18 --> Helper loaded: text_helper
INFO - 2023-10-28 12:43:18 --> Helper loaded: form_helper
INFO - 2023-10-28 12:43:18 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:43:18 --> Helper loaded: security_helper
INFO - 2023-10-28 12:43:18 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:43:18 --> Database Driver Class Initialized
INFO - 2023-10-28 12:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:43:18 --> Parser Class Initialized
INFO - 2023-10-28 12:43:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:43:18 --> Pagination Class Initialized
INFO - 2023-10-28 12:43:18 --> Form Validation Class Initialized
INFO - 2023-10-28 12:43:18 --> Controller Class Initialized
INFO - 2023-10-28 12:43:18 --> Model Class Initialized
DEBUG - 2023-10-28 12:43:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:43:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:43:18 --> Model Class Initialized
DEBUG - 2023-10-28 12:43:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:43:18 --> Model Class Initialized
INFO - 2023-10-28 12:43:18 --> Final output sent to browser
DEBUG - 2023-10-28 12:43:18 --> Total execution time: 0.0181
ERROR - 2023-10-28 12:43:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:43:20 --> Config Class Initialized
INFO - 2023-10-28 12:43:20 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:43:20 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:43:20 --> Utf8 Class Initialized
INFO - 2023-10-28 12:43:20 --> URI Class Initialized
INFO - 2023-10-28 12:43:20 --> Router Class Initialized
INFO - 2023-10-28 12:43:20 --> Output Class Initialized
INFO - 2023-10-28 12:43:20 --> Security Class Initialized
DEBUG - 2023-10-28 12:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:43:20 --> Input Class Initialized
INFO - 2023-10-28 12:43:20 --> Language Class Initialized
INFO - 2023-10-28 12:43:20 --> Loader Class Initialized
INFO - 2023-10-28 12:43:20 --> Helper loaded: url_helper
INFO - 2023-10-28 12:43:20 --> Helper loaded: file_helper
INFO - 2023-10-28 12:43:20 --> Helper loaded: html_helper
INFO - 2023-10-28 12:43:20 --> Helper loaded: text_helper
INFO - 2023-10-28 12:43:20 --> Helper loaded: form_helper
INFO - 2023-10-28 12:43:20 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:43:20 --> Helper loaded: security_helper
INFO - 2023-10-28 12:43:20 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:43:20 --> Database Driver Class Initialized
INFO - 2023-10-28 12:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:43:20 --> Parser Class Initialized
INFO - 2023-10-28 12:43:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:43:20 --> Pagination Class Initialized
INFO - 2023-10-28 12:43:20 --> Form Validation Class Initialized
INFO - 2023-10-28 12:43:20 --> Controller Class Initialized
INFO - 2023-10-28 12:43:20 --> Model Class Initialized
DEBUG - 2023-10-28 12:43:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:43:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:43:20 --> Model Class Initialized
INFO - 2023-10-28 12:43:20 --> Model Class Initialized
INFO - 2023-10-28 12:43:20 --> Final output sent to browser
DEBUG - 2023-10-28 12:43:20 --> Total execution time: 0.0240
ERROR - 2023-10-28 12:43:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:43:22 --> Config Class Initialized
INFO - 2023-10-28 12:43:22 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:43:22 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:43:22 --> Utf8 Class Initialized
INFO - 2023-10-28 12:43:22 --> URI Class Initialized
INFO - 2023-10-28 12:43:22 --> Router Class Initialized
INFO - 2023-10-28 12:43:22 --> Output Class Initialized
INFO - 2023-10-28 12:43:22 --> Security Class Initialized
DEBUG - 2023-10-28 12:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:43:22 --> Input Class Initialized
INFO - 2023-10-28 12:43:22 --> Language Class Initialized
INFO - 2023-10-28 12:43:22 --> Loader Class Initialized
INFO - 2023-10-28 12:43:22 --> Helper loaded: url_helper
INFO - 2023-10-28 12:43:22 --> Helper loaded: file_helper
INFO - 2023-10-28 12:43:22 --> Helper loaded: html_helper
INFO - 2023-10-28 12:43:22 --> Helper loaded: text_helper
INFO - 2023-10-28 12:43:22 --> Helper loaded: form_helper
INFO - 2023-10-28 12:43:22 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:43:22 --> Helper loaded: security_helper
INFO - 2023-10-28 12:43:22 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:43:22 --> Database Driver Class Initialized
INFO - 2023-10-28 12:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:43:22 --> Parser Class Initialized
INFO - 2023-10-28 12:43:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:43:22 --> Pagination Class Initialized
INFO - 2023-10-28 12:43:22 --> Form Validation Class Initialized
INFO - 2023-10-28 12:43:22 --> Controller Class Initialized
INFO - 2023-10-28 12:43:22 --> Model Class Initialized
DEBUG - 2023-10-28 12:43:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:43:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:43:22 --> Model Class Initialized
INFO - 2023-10-28 12:43:22 --> Final output sent to browser
DEBUG - 2023-10-28 12:43:22 --> Total execution time: 0.0156
ERROR - 2023-10-28 12:43:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:43:52 --> Config Class Initialized
INFO - 2023-10-28 12:43:52 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:43:52 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:43:52 --> Utf8 Class Initialized
INFO - 2023-10-28 12:43:52 --> URI Class Initialized
INFO - 2023-10-28 12:43:52 --> Router Class Initialized
INFO - 2023-10-28 12:43:52 --> Output Class Initialized
INFO - 2023-10-28 12:43:52 --> Security Class Initialized
DEBUG - 2023-10-28 12:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:43:52 --> Input Class Initialized
INFO - 2023-10-28 12:43:52 --> Language Class Initialized
INFO - 2023-10-28 12:43:52 --> Loader Class Initialized
INFO - 2023-10-28 12:43:52 --> Helper loaded: url_helper
INFO - 2023-10-28 12:43:52 --> Helper loaded: file_helper
INFO - 2023-10-28 12:43:52 --> Helper loaded: html_helper
INFO - 2023-10-28 12:43:52 --> Helper loaded: text_helper
INFO - 2023-10-28 12:43:52 --> Helper loaded: form_helper
INFO - 2023-10-28 12:43:52 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:43:52 --> Helper loaded: security_helper
INFO - 2023-10-28 12:43:52 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:43:52 --> Database Driver Class Initialized
INFO - 2023-10-28 12:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:43:52 --> Parser Class Initialized
INFO - 2023-10-28 12:43:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:43:52 --> Pagination Class Initialized
INFO - 2023-10-28 12:43:52 --> Form Validation Class Initialized
INFO - 2023-10-28 12:43:52 --> Controller Class Initialized
INFO - 2023-10-28 12:43:52 --> Model Class Initialized
DEBUG - 2023-10-28 12:43:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:43:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:43:52 --> Model Class Initialized
DEBUG - 2023-10-28 12:43:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:43:52 --> Model Class Initialized
INFO - 2023-10-28 12:43:52 --> Final output sent to browser
DEBUG - 2023-10-28 12:43:52 --> Total execution time: 0.0556
ERROR - 2023-10-28 12:43:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:43:52 --> Config Class Initialized
INFO - 2023-10-28 12:43:52 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:43:52 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:43:52 --> Utf8 Class Initialized
INFO - 2023-10-28 12:43:52 --> URI Class Initialized
INFO - 2023-10-28 12:43:52 --> Router Class Initialized
INFO - 2023-10-28 12:43:52 --> Output Class Initialized
INFO - 2023-10-28 12:43:52 --> Security Class Initialized
DEBUG - 2023-10-28 12:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:43:52 --> Input Class Initialized
INFO - 2023-10-28 12:43:52 --> Language Class Initialized
INFO - 2023-10-28 12:43:52 --> Loader Class Initialized
INFO - 2023-10-28 12:43:52 --> Helper loaded: url_helper
INFO - 2023-10-28 12:43:52 --> Helper loaded: file_helper
INFO - 2023-10-28 12:43:52 --> Helper loaded: html_helper
INFO - 2023-10-28 12:43:52 --> Helper loaded: text_helper
INFO - 2023-10-28 12:43:52 --> Helper loaded: form_helper
INFO - 2023-10-28 12:43:52 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:43:52 --> Helper loaded: security_helper
INFO - 2023-10-28 12:43:52 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:43:52 --> Database Driver Class Initialized
INFO - 2023-10-28 12:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:43:52 --> Parser Class Initialized
INFO - 2023-10-28 12:43:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:43:52 --> Pagination Class Initialized
INFO - 2023-10-28 12:43:52 --> Form Validation Class Initialized
INFO - 2023-10-28 12:43:52 --> Controller Class Initialized
INFO - 2023-10-28 12:43:52 --> Model Class Initialized
DEBUG - 2023-10-28 12:43:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:43:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:43:52 --> Model Class Initialized
DEBUG - 2023-10-28 12:43:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:43:52 --> Model Class Initialized
INFO - 2023-10-28 12:43:53 --> Final output sent to browser
DEBUG - 2023-10-28 12:43:53 --> Total execution time: 0.0524
ERROR - 2023-10-28 12:43:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:43:53 --> Config Class Initialized
INFO - 2023-10-28 12:43:53 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:43:53 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:43:53 --> Utf8 Class Initialized
INFO - 2023-10-28 12:43:53 --> URI Class Initialized
INFO - 2023-10-28 12:43:53 --> Router Class Initialized
INFO - 2023-10-28 12:43:53 --> Output Class Initialized
INFO - 2023-10-28 12:43:53 --> Security Class Initialized
DEBUG - 2023-10-28 12:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:43:53 --> Input Class Initialized
INFO - 2023-10-28 12:43:53 --> Language Class Initialized
INFO - 2023-10-28 12:43:53 --> Loader Class Initialized
INFO - 2023-10-28 12:43:53 --> Helper loaded: url_helper
INFO - 2023-10-28 12:43:53 --> Helper loaded: file_helper
INFO - 2023-10-28 12:43:53 --> Helper loaded: html_helper
INFO - 2023-10-28 12:43:53 --> Helper loaded: text_helper
INFO - 2023-10-28 12:43:53 --> Helper loaded: form_helper
INFO - 2023-10-28 12:43:53 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:43:53 --> Helper loaded: security_helper
INFO - 2023-10-28 12:43:53 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:43:53 --> Database Driver Class Initialized
INFO - 2023-10-28 12:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:43:53 --> Parser Class Initialized
INFO - 2023-10-28 12:43:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:43:53 --> Pagination Class Initialized
INFO - 2023-10-28 12:43:53 --> Form Validation Class Initialized
INFO - 2023-10-28 12:43:53 --> Controller Class Initialized
INFO - 2023-10-28 12:43:53 --> Model Class Initialized
DEBUG - 2023-10-28 12:43:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:43:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:43:53 --> Model Class Initialized
DEBUG - 2023-10-28 12:43:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:43:53 --> Model Class Initialized
INFO - 2023-10-28 12:43:53 --> Final output sent to browser
DEBUG - 2023-10-28 12:43:53 --> Total execution time: 0.0525
ERROR - 2023-10-28 12:43:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:43:53 --> Config Class Initialized
INFO - 2023-10-28 12:43:53 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:43:53 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:43:53 --> Utf8 Class Initialized
INFO - 2023-10-28 12:43:53 --> URI Class Initialized
INFO - 2023-10-28 12:43:53 --> Router Class Initialized
INFO - 2023-10-28 12:43:53 --> Output Class Initialized
INFO - 2023-10-28 12:43:53 --> Security Class Initialized
DEBUG - 2023-10-28 12:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:43:53 --> Input Class Initialized
INFO - 2023-10-28 12:43:53 --> Language Class Initialized
INFO - 2023-10-28 12:43:53 --> Loader Class Initialized
INFO - 2023-10-28 12:43:53 --> Helper loaded: url_helper
INFO - 2023-10-28 12:43:53 --> Helper loaded: file_helper
INFO - 2023-10-28 12:43:53 --> Helper loaded: html_helper
INFO - 2023-10-28 12:43:53 --> Helper loaded: text_helper
INFO - 2023-10-28 12:43:53 --> Helper loaded: form_helper
INFO - 2023-10-28 12:43:53 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:43:53 --> Helper loaded: security_helper
INFO - 2023-10-28 12:43:53 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:43:53 --> Database Driver Class Initialized
INFO - 2023-10-28 12:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:43:53 --> Parser Class Initialized
INFO - 2023-10-28 12:43:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:43:53 --> Pagination Class Initialized
INFO - 2023-10-28 12:43:53 --> Form Validation Class Initialized
INFO - 2023-10-28 12:43:53 --> Controller Class Initialized
INFO - 2023-10-28 12:43:53 --> Model Class Initialized
DEBUG - 2023-10-28 12:43:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:43:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:43:53 --> Model Class Initialized
DEBUG - 2023-10-28 12:43:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:43:53 --> Model Class Initialized
INFO - 2023-10-28 12:43:53 --> Final output sent to browser
DEBUG - 2023-10-28 12:43:53 --> Total execution time: 0.0518
ERROR - 2023-10-28 12:43:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:43:55 --> Config Class Initialized
INFO - 2023-10-28 12:43:55 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:43:55 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:43:55 --> Utf8 Class Initialized
INFO - 2023-10-28 12:43:55 --> URI Class Initialized
INFO - 2023-10-28 12:43:55 --> Router Class Initialized
INFO - 2023-10-28 12:43:55 --> Output Class Initialized
INFO - 2023-10-28 12:43:55 --> Security Class Initialized
DEBUG - 2023-10-28 12:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:43:55 --> Input Class Initialized
INFO - 2023-10-28 12:43:55 --> Language Class Initialized
INFO - 2023-10-28 12:43:55 --> Loader Class Initialized
INFO - 2023-10-28 12:43:55 --> Helper loaded: url_helper
INFO - 2023-10-28 12:43:55 --> Helper loaded: file_helper
INFO - 2023-10-28 12:43:55 --> Helper loaded: html_helper
INFO - 2023-10-28 12:43:55 --> Helper loaded: text_helper
INFO - 2023-10-28 12:43:55 --> Helper loaded: form_helper
INFO - 2023-10-28 12:43:55 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:43:55 --> Helper loaded: security_helper
INFO - 2023-10-28 12:43:55 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:43:55 --> Database Driver Class Initialized
INFO - 2023-10-28 12:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:43:55 --> Parser Class Initialized
INFO - 2023-10-28 12:43:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:43:55 --> Pagination Class Initialized
INFO - 2023-10-28 12:43:55 --> Form Validation Class Initialized
INFO - 2023-10-28 12:43:55 --> Controller Class Initialized
INFO - 2023-10-28 12:43:55 --> Model Class Initialized
DEBUG - 2023-10-28 12:43:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:43:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:43:55 --> Model Class Initialized
INFO - 2023-10-28 12:43:55 --> Model Class Initialized
INFO - 2023-10-28 12:43:55 --> Final output sent to browser
DEBUG - 2023-10-28 12:43:55 --> Total execution time: 0.0196
ERROR - 2023-10-28 12:43:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:43:58 --> Config Class Initialized
INFO - 2023-10-28 12:43:58 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:43:58 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:43:58 --> Utf8 Class Initialized
INFO - 2023-10-28 12:43:58 --> URI Class Initialized
INFO - 2023-10-28 12:43:58 --> Router Class Initialized
INFO - 2023-10-28 12:43:58 --> Output Class Initialized
INFO - 2023-10-28 12:43:58 --> Security Class Initialized
DEBUG - 2023-10-28 12:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:43:58 --> Input Class Initialized
INFO - 2023-10-28 12:43:58 --> Language Class Initialized
INFO - 2023-10-28 12:43:58 --> Loader Class Initialized
INFO - 2023-10-28 12:43:58 --> Helper loaded: url_helper
INFO - 2023-10-28 12:43:58 --> Helper loaded: file_helper
INFO - 2023-10-28 12:43:58 --> Helper loaded: html_helper
INFO - 2023-10-28 12:43:58 --> Helper loaded: text_helper
INFO - 2023-10-28 12:43:58 --> Helper loaded: form_helper
INFO - 2023-10-28 12:43:58 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:43:58 --> Helper loaded: security_helper
INFO - 2023-10-28 12:43:58 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:43:58 --> Database Driver Class Initialized
INFO - 2023-10-28 12:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:43:58 --> Parser Class Initialized
INFO - 2023-10-28 12:43:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:43:58 --> Pagination Class Initialized
INFO - 2023-10-28 12:43:58 --> Form Validation Class Initialized
INFO - 2023-10-28 12:43:58 --> Controller Class Initialized
INFO - 2023-10-28 12:43:58 --> Model Class Initialized
DEBUG - 2023-10-28 12:43:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:43:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:43:58 --> Model Class Initialized
INFO - 2023-10-28 12:43:58 --> Final output sent to browser
DEBUG - 2023-10-28 12:43:58 --> Total execution time: 0.0164
ERROR - 2023-10-28 12:44:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:44:07 --> Config Class Initialized
INFO - 2023-10-28 12:44:07 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:44:07 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:44:07 --> Utf8 Class Initialized
INFO - 2023-10-28 12:44:07 --> URI Class Initialized
INFO - 2023-10-28 12:44:07 --> Router Class Initialized
INFO - 2023-10-28 12:44:07 --> Output Class Initialized
INFO - 2023-10-28 12:44:07 --> Security Class Initialized
DEBUG - 2023-10-28 12:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:44:07 --> Input Class Initialized
INFO - 2023-10-28 12:44:07 --> Language Class Initialized
INFO - 2023-10-28 12:44:07 --> Loader Class Initialized
INFO - 2023-10-28 12:44:07 --> Helper loaded: url_helper
INFO - 2023-10-28 12:44:07 --> Helper loaded: file_helper
INFO - 2023-10-28 12:44:07 --> Helper loaded: html_helper
INFO - 2023-10-28 12:44:07 --> Helper loaded: text_helper
INFO - 2023-10-28 12:44:07 --> Helper loaded: form_helper
INFO - 2023-10-28 12:44:07 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:44:07 --> Helper loaded: security_helper
INFO - 2023-10-28 12:44:07 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:44:07 --> Database Driver Class Initialized
INFO - 2023-10-28 12:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:44:07 --> Parser Class Initialized
INFO - 2023-10-28 12:44:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:44:07 --> Pagination Class Initialized
INFO - 2023-10-28 12:44:07 --> Form Validation Class Initialized
INFO - 2023-10-28 12:44:07 --> Controller Class Initialized
INFO - 2023-10-28 12:44:07 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:44:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:07 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:07 --> Model Class Initialized
INFO - 2023-10-28 12:44:07 --> Final output sent to browser
DEBUG - 2023-10-28 12:44:07 --> Total execution time: 0.0525
ERROR - 2023-10-28 12:44:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:44:07 --> Config Class Initialized
INFO - 2023-10-28 12:44:07 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:44:07 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:44:07 --> Utf8 Class Initialized
INFO - 2023-10-28 12:44:07 --> URI Class Initialized
INFO - 2023-10-28 12:44:07 --> Router Class Initialized
INFO - 2023-10-28 12:44:07 --> Output Class Initialized
INFO - 2023-10-28 12:44:07 --> Security Class Initialized
DEBUG - 2023-10-28 12:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:44:07 --> Input Class Initialized
INFO - 2023-10-28 12:44:07 --> Language Class Initialized
INFO - 2023-10-28 12:44:07 --> Loader Class Initialized
INFO - 2023-10-28 12:44:07 --> Helper loaded: url_helper
INFO - 2023-10-28 12:44:07 --> Helper loaded: file_helper
INFO - 2023-10-28 12:44:07 --> Helper loaded: html_helper
INFO - 2023-10-28 12:44:07 --> Helper loaded: text_helper
INFO - 2023-10-28 12:44:07 --> Helper loaded: form_helper
INFO - 2023-10-28 12:44:07 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:44:07 --> Helper loaded: security_helper
INFO - 2023-10-28 12:44:07 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:44:07 --> Database Driver Class Initialized
INFO - 2023-10-28 12:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:44:07 --> Parser Class Initialized
INFO - 2023-10-28 12:44:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:44:07 --> Pagination Class Initialized
INFO - 2023-10-28 12:44:07 --> Form Validation Class Initialized
INFO - 2023-10-28 12:44:07 --> Controller Class Initialized
INFO - 2023-10-28 12:44:07 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:44:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:07 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:07 --> Model Class Initialized
INFO - 2023-10-28 12:44:07 --> Final output sent to browser
DEBUG - 2023-10-28 12:44:07 --> Total execution time: 0.0509
ERROR - 2023-10-28 12:44:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:44:08 --> Config Class Initialized
INFO - 2023-10-28 12:44:08 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:44:08 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:44:08 --> Utf8 Class Initialized
INFO - 2023-10-28 12:44:08 --> URI Class Initialized
INFO - 2023-10-28 12:44:08 --> Router Class Initialized
INFO - 2023-10-28 12:44:08 --> Output Class Initialized
INFO - 2023-10-28 12:44:08 --> Security Class Initialized
DEBUG - 2023-10-28 12:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:44:08 --> Input Class Initialized
INFO - 2023-10-28 12:44:08 --> Language Class Initialized
INFO - 2023-10-28 12:44:08 --> Loader Class Initialized
INFO - 2023-10-28 12:44:08 --> Helper loaded: url_helper
INFO - 2023-10-28 12:44:08 --> Helper loaded: file_helper
INFO - 2023-10-28 12:44:08 --> Helper loaded: html_helper
INFO - 2023-10-28 12:44:08 --> Helper loaded: text_helper
INFO - 2023-10-28 12:44:08 --> Helper loaded: form_helper
INFO - 2023-10-28 12:44:08 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:44:08 --> Helper loaded: security_helper
INFO - 2023-10-28 12:44:08 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:44:08 --> Database Driver Class Initialized
INFO - 2023-10-28 12:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:44:08 --> Parser Class Initialized
INFO - 2023-10-28 12:44:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:44:08 --> Pagination Class Initialized
INFO - 2023-10-28 12:44:08 --> Form Validation Class Initialized
INFO - 2023-10-28 12:44:08 --> Controller Class Initialized
INFO - 2023-10-28 12:44:08 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:44:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:08 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:08 --> Model Class Initialized
INFO - 2023-10-28 12:44:08 --> Final output sent to browser
DEBUG - 2023-10-28 12:44:08 --> Total execution time: 0.0526
ERROR - 2023-10-28 12:44:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:44:08 --> Config Class Initialized
INFO - 2023-10-28 12:44:08 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:44:08 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:44:08 --> Utf8 Class Initialized
INFO - 2023-10-28 12:44:08 --> URI Class Initialized
INFO - 2023-10-28 12:44:08 --> Router Class Initialized
INFO - 2023-10-28 12:44:08 --> Output Class Initialized
INFO - 2023-10-28 12:44:08 --> Security Class Initialized
DEBUG - 2023-10-28 12:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:44:08 --> Input Class Initialized
INFO - 2023-10-28 12:44:08 --> Language Class Initialized
INFO - 2023-10-28 12:44:08 --> Loader Class Initialized
INFO - 2023-10-28 12:44:08 --> Helper loaded: url_helper
INFO - 2023-10-28 12:44:08 --> Helper loaded: file_helper
INFO - 2023-10-28 12:44:08 --> Helper loaded: html_helper
INFO - 2023-10-28 12:44:08 --> Helper loaded: text_helper
INFO - 2023-10-28 12:44:08 --> Helper loaded: form_helper
INFO - 2023-10-28 12:44:08 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:44:08 --> Helper loaded: security_helper
INFO - 2023-10-28 12:44:08 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:44:08 --> Database Driver Class Initialized
INFO - 2023-10-28 12:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:44:08 --> Parser Class Initialized
INFO - 2023-10-28 12:44:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:44:08 --> Pagination Class Initialized
INFO - 2023-10-28 12:44:08 --> Form Validation Class Initialized
INFO - 2023-10-28 12:44:08 --> Controller Class Initialized
INFO - 2023-10-28 12:44:08 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:44:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:08 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:08 --> Model Class Initialized
INFO - 2023-10-28 12:44:08 --> Final output sent to browser
DEBUG - 2023-10-28 12:44:08 --> Total execution time: 0.0524
ERROR - 2023-10-28 12:44:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:44:09 --> Config Class Initialized
INFO - 2023-10-28 12:44:09 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:44:09 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:44:09 --> Utf8 Class Initialized
INFO - 2023-10-28 12:44:09 --> URI Class Initialized
INFO - 2023-10-28 12:44:09 --> Router Class Initialized
INFO - 2023-10-28 12:44:09 --> Output Class Initialized
INFO - 2023-10-28 12:44:09 --> Security Class Initialized
DEBUG - 2023-10-28 12:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:44:09 --> Input Class Initialized
INFO - 2023-10-28 12:44:09 --> Language Class Initialized
INFO - 2023-10-28 12:44:09 --> Loader Class Initialized
INFO - 2023-10-28 12:44:09 --> Helper loaded: url_helper
INFO - 2023-10-28 12:44:09 --> Helper loaded: file_helper
INFO - 2023-10-28 12:44:09 --> Helper loaded: html_helper
INFO - 2023-10-28 12:44:09 --> Helper loaded: text_helper
INFO - 2023-10-28 12:44:09 --> Helper loaded: form_helper
INFO - 2023-10-28 12:44:09 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:44:09 --> Helper loaded: security_helper
INFO - 2023-10-28 12:44:09 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:44:09 --> Database Driver Class Initialized
INFO - 2023-10-28 12:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:44:09 --> Parser Class Initialized
INFO - 2023-10-28 12:44:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:44:09 --> Pagination Class Initialized
INFO - 2023-10-28 12:44:09 --> Form Validation Class Initialized
INFO - 2023-10-28 12:44:09 --> Controller Class Initialized
INFO - 2023-10-28 12:44:09 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:44:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:09 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:09 --> Model Class Initialized
INFO - 2023-10-28 12:44:09 --> Final output sent to browser
DEBUG - 2023-10-28 12:44:09 --> Total execution time: 0.0194
ERROR - 2023-10-28 12:44:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:44:11 --> Config Class Initialized
INFO - 2023-10-28 12:44:11 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:44:11 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:44:11 --> Utf8 Class Initialized
INFO - 2023-10-28 12:44:11 --> URI Class Initialized
INFO - 2023-10-28 12:44:11 --> Router Class Initialized
INFO - 2023-10-28 12:44:11 --> Output Class Initialized
INFO - 2023-10-28 12:44:11 --> Security Class Initialized
DEBUG - 2023-10-28 12:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:44:11 --> Input Class Initialized
INFO - 2023-10-28 12:44:11 --> Language Class Initialized
INFO - 2023-10-28 12:44:11 --> Loader Class Initialized
INFO - 2023-10-28 12:44:11 --> Helper loaded: url_helper
INFO - 2023-10-28 12:44:11 --> Helper loaded: file_helper
INFO - 2023-10-28 12:44:11 --> Helper loaded: html_helper
INFO - 2023-10-28 12:44:11 --> Helper loaded: text_helper
INFO - 2023-10-28 12:44:11 --> Helper loaded: form_helper
INFO - 2023-10-28 12:44:11 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:44:11 --> Helper loaded: security_helper
INFO - 2023-10-28 12:44:11 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:44:11 --> Database Driver Class Initialized
INFO - 2023-10-28 12:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:44:11 --> Parser Class Initialized
INFO - 2023-10-28 12:44:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:44:11 --> Pagination Class Initialized
INFO - 2023-10-28 12:44:11 --> Form Validation Class Initialized
INFO - 2023-10-28 12:44:11 --> Controller Class Initialized
INFO - 2023-10-28 12:44:11 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:44:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:11 --> Model Class Initialized
INFO - 2023-10-28 12:44:11 --> Model Class Initialized
INFO - 2023-10-28 12:44:11 --> Final output sent to browser
DEBUG - 2023-10-28 12:44:11 --> Total execution time: 0.0183
ERROR - 2023-10-28 12:44:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:44:13 --> Config Class Initialized
INFO - 2023-10-28 12:44:13 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:44:13 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:44:13 --> Utf8 Class Initialized
INFO - 2023-10-28 12:44:13 --> URI Class Initialized
INFO - 2023-10-28 12:44:13 --> Router Class Initialized
INFO - 2023-10-28 12:44:13 --> Output Class Initialized
INFO - 2023-10-28 12:44:13 --> Security Class Initialized
DEBUG - 2023-10-28 12:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:44:13 --> Input Class Initialized
INFO - 2023-10-28 12:44:13 --> Language Class Initialized
INFO - 2023-10-28 12:44:13 --> Loader Class Initialized
INFO - 2023-10-28 12:44:13 --> Helper loaded: url_helper
INFO - 2023-10-28 12:44:13 --> Helper loaded: file_helper
INFO - 2023-10-28 12:44:13 --> Helper loaded: html_helper
INFO - 2023-10-28 12:44:13 --> Helper loaded: text_helper
INFO - 2023-10-28 12:44:13 --> Helper loaded: form_helper
INFO - 2023-10-28 12:44:13 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:44:13 --> Helper loaded: security_helper
INFO - 2023-10-28 12:44:13 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:44:13 --> Database Driver Class Initialized
INFO - 2023-10-28 12:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:44:13 --> Parser Class Initialized
INFO - 2023-10-28 12:44:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:44:13 --> Pagination Class Initialized
INFO - 2023-10-28 12:44:13 --> Form Validation Class Initialized
INFO - 2023-10-28 12:44:13 --> Controller Class Initialized
INFO - 2023-10-28 12:44:13 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:44:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:13 --> Model Class Initialized
INFO - 2023-10-28 12:44:13 --> Final output sent to browser
DEBUG - 2023-10-28 12:44:13 --> Total execution time: 0.0176
ERROR - 2023-10-28 12:44:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:44:25 --> Config Class Initialized
INFO - 2023-10-28 12:44:25 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:44:25 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:44:25 --> Utf8 Class Initialized
INFO - 2023-10-28 12:44:25 --> URI Class Initialized
INFO - 2023-10-28 12:44:25 --> Router Class Initialized
INFO - 2023-10-28 12:44:25 --> Output Class Initialized
INFO - 2023-10-28 12:44:25 --> Security Class Initialized
DEBUG - 2023-10-28 12:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:44:25 --> Input Class Initialized
INFO - 2023-10-28 12:44:25 --> Language Class Initialized
INFO - 2023-10-28 12:44:25 --> Loader Class Initialized
INFO - 2023-10-28 12:44:25 --> Helper loaded: url_helper
INFO - 2023-10-28 12:44:25 --> Helper loaded: file_helper
INFO - 2023-10-28 12:44:25 --> Helper loaded: html_helper
INFO - 2023-10-28 12:44:25 --> Helper loaded: text_helper
INFO - 2023-10-28 12:44:25 --> Helper loaded: form_helper
INFO - 2023-10-28 12:44:25 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:44:25 --> Helper loaded: security_helper
INFO - 2023-10-28 12:44:25 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:44:25 --> Database Driver Class Initialized
INFO - 2023-10-28 12:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:44:25 --> Parser Class Initialized
INFO - 2023-10-28 12:44:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:44:25 --> Pagination Class Initialized
INFO - 2023-10-28 12:44:25 --> Form Validation Class Initialized
INFO - 2023-10-28 12:44:25 --> Controller Class Initialized
INFO - 2023-10-28 12:44:25 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:44:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:25 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:25 --> Model Class Initialized
INFO - 2023-10-28 12:44:25 --> Final output sent to browser
DEBUG - 2023-10-28 12:44:25 --> Total execution time: 0.0554
ERROR - 2023-10-28 12:44:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:44:26 --> Config Class Initialized
INFO - 2023-10-28 12:44:26 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:44:26 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:44:26 --> Utf8 Class Initialized
INFO - 2023-10-28 12:44:26 --> URI Class Initialized
INFO - 2023-10-28 12:44:26 --> Router Class Initialized
INFO - 2023-10-28 12:44:26 --> Output Class Initialized
INFO - 2023-10-28 12:44:26 --> Security Class Initialized
DEBUG - 2023-10-28 12:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:44:26 --> Input Class Initialized
INFO - 2023-10-28 12:44:26 --> Language Class Initialized
INFO - 2023-10-28 12:44:26 --> Loader Class Initialized
INFO - 2023-10-28 12:44:26 --> Helper loaded: url_helper
INFO - 2023-10-28 12:44:26 --> Helper loaded: file_helper
INFO - 2023-10-28 12:44:26 --> Helper loaded: html_helper
INFO - 2023-10-28 12:44:26 --> Helper loaded: text_helper
INFO - 2023-10-28 12:44:26 --> Helper loaded: form_helper
INFO - 2023-10-28 12:44:26 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:44:26 --> Helper loaded: security_helper
INFO - 2023-10-28 12:44:26 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:44:26 --> Database Driver Class Initialized
INFO - 2023-10-28 12:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:44:26 --> Parser Class Initialized
INFO - 2023-10-28 12:44:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:44:26 --> Pagination Class Initialized
INFO - 2023-10-28 12:44:26 --> Form Validation Class Initialized
INFO - 2023-10-28 12:44:26 --> Controller Class Initialized
INFO - 2023-10-28 12:44:26 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:44:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:26 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:26 --> Model Class Initialized
INFO - 2023-10-28 12:44:26 --> Final output sent to browser
DEBUG - 2023-10-28 12:44:26 --> Total execution time: 0.0527
ERROR - 2023-10-28 12:44:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:44:26 --> Config Class Initialized
INFO - 2023-10-28 12:44:26 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:44:26 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:44:26 --> Utf8 Class Initialized
INFO - 2023-10-28 12:44:26 --> URI Class Initialized
INFO - 2023-10-28 12:44:26 --> Router Class Initialized
INFO - 2023-10-28 12:44:26 --> Output Class Initialized
INFO - 2023-10-28 12:44:26 --> Security Class Initialized
DEBUG - 2023-10-28 12:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:44:26 --> Input Class Initialized
INFO - 2023-10-28 12:44:26 --> Language Class Initialized
INFO - 2023-10-28 12:44:26 --> Loader Class Initialized
INFO - 2023-10-28 12:44:26 --> Helper loaded: url_helper
INFO - 2023-10-28 12:44:26 --> Helper loaded: file_helper
INFO - 2023-10-28 12:44:26 --> Helper loaded: html_helper
INFO - 2023-10-28 12:44:26 --> Helper loaded: text_helper
INFO - 2023-10-28 12:44:26 --> Helper loaded: form_helper
INFO - 2023-10-28 12:44:26 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:44:26 --> Helper loaded: security_helper
INFO - 2023-10-28 12:44:26 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:44:26 --> Database Driver Class Initialized
INFO - 2023-10-28 12:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:44:26 --> Parser Class Initialized
INFO - 2023-10-28 12:44:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:44:26 --> Pagination Class Initialized
INFO - 2023-10-28 12:44:26 --> Form Validation Class Initialized
INFO - 2023-10-28 12:44:26 --> Controller Class Initialized
INFO - 2023-10-28 12:44:26 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:44:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:26 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:26 --> Model Class Initialized
INFO - 2023-10-28 12:44:26 --> Final output sent to browser
DEBUG - 2023-10-28 12:44:26 --> Total execution time: 0.0517
ERROR - 2023-10-28 12:44:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:44:26 --> Config Class Initialized
INFO - 2023-10-28 12:44:26 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:44:26 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:44:26 --> Utf8 Class Initialized
INFO - 2023-10-28 12:44:26 --> URI Class Initialized
INFO - 2023-10-28 12:44:26 --> Router Class Initialized
INFO - 2023-10-28 12:44:26 --> Output Class Initialized
INFO - 2023-10-28 12:44:26 --> Security Class Initialized
DEBUG - 2023-10-28 12:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:44:26 --> Input Class Initialized
INFO - 2023-10-28 12:44:26 --> Language Class Initialized
INFO - 2023-10-28 12:44:26 --> Loader Class Initialized
INFO - 2023-10-28 12:44:26 --> Helper loaded: url_helper
INFO - 2023-10-28 12:44:26 --> Helper loaded: file_helper
INFO - 2023-10-28 12:44:26 --> Helper loaded: html_helper
INFO - 2023-10-28 12:44:26 --> Helper loaded: text_helper
INFO - 2023-10-28 12:44:26 --> Helper loaded: form_helper
INFO - 2023-10-28 12:44:26 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:44:26 --> Helper loaded: security_helper
INFO - 2023-10-28 12:44:26 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:44:26 --> Database Driver Class Initialized
INFO - 2023-10-28 12:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:44:26 --> Parser Class Initialized
INFO - 2023-10-28 12:44:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:44:26 --> Pagination Class Initialized
INFO - 2023-10-28 12:44:26 --> Form Validation Class Initialized
INFO - 2023-10-28 12:44:26 --> Controller Class Initialized
INFO - 2023-10-28 12:44:26 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:44:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:26 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:26 --> Model Class Initialized
INFO - 2023-10-28 12:44:26 --> Final output sent to browser
DEBUG - 2023-10-28 12:44:26 --> Total execution time: 0.0526
ERROR - 2023-10-28 12:44:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:44:29 --> Config Class Initialized
INFO - 2023-10-28 12:44:29 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:44:29 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:44:29 --> Utf8 Class Initialized
INFO - 2023-10-28 12:44:29 --> URI Class Initialized
INFO - 2023-10-28 12:44:29 --> Router Class Initialized
INFO - 2023-10-28 12:44:29 --> Output Class Initialized
INFO - 2023-10-28 12:44:29 --> Security Class Initialized
DEBUG - 2023-10-28 12:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:44:29 --> Input Class Initialized
INFO - 2023-10-28 12:44:29 --> Language Class Initialized
INFO - 2023-10-28 12:44:29 --> Loader Class Initialized
INFO - 2023-10-28 12:44:29 --> Helper loaded: url_helper
INFO - 2023-10-28 12:44:29 --> Helper loaded: file_helper
INFO - 2023-10-28 12:44:29 --> Helper loaded: html_helper
INFO - 2023-10-28 12:44:29 --> Helper loaded: text_helper
INFO - 2023-10-28 12:44:29 --> Helper loaded: form_helper
INFO - 2023-10-28 12:44:29 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:44:29 --> Helper loaded: security_helper
INFO - 2023-10-28 12:44:29 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:44:29 --> Database Driver Class Initialized
INFO - 2023-10-28 12:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:44:29 --> Parser Class Initialized
INFO - 2023-10-28 12:44:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:44:29 --> Pagination Class Initialized
INFO - 2023-10-28 12:44:29 --> Form Validation Class Initialized
INFO - 2023-10-28 12:44:29 --> Controller Class Initialized
INFO - 2023-10-28 12:44:29 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:44:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:29 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:29 --> Model Class Initialized
INFO - 2023-10-28 12:44:29 --> Final output sent to browser
DEBUG - 2023-10-28 12:44:29 --> Total execution time: 0.0188
ERROR - 2023-10-28 12:44:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:44:31 --> Config Class Initialized
INFO - 2023-10-28 12:44:31 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:44:31 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:44:31 --> Utf8 Class Initialized
INFO - 2023-10-28 12:44:31 --> URI Class Initialized
INFO - 2023-10-28 12:44:31 --> Router Class Initialized
INFO - 2023-10-28 12:44:31 --> Output Class Initialized
INFO - 2023-10-28 12:44:31 --> Security Class Initialized
DEBUG - 2023-10-28 12:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:44:31 --> Input Class Initialized
INFO - 2023-10-28 12:44:31 --> Language Class Initialized
INFO - 2023-10-28 12:44:31 --> Loader Class Initialized
INFO - 2023-10-28 12:44:31 --> Helper loaded: url_helper
INFO - 2023-10-28 12:44:31 --> Helper loaded: file_helper
INFO - 2023-10-28 12:44:31 --> Helper loaded: html_helper
INFO - 2023-10-28 12:44:31 --> Helper loaded: text_helper
INFO - 2023-10-28 12:44:31 --> Helper loaded: form_helper
INFO - 2023-10-28 12:44:31 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:44:31 --> Helper loaded: security_helper
INFO - 2023-10-28 12:44:31 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:44:31 --> Database Driver Class Initialized
INFO - 2023-10-28 12:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:44:31 --> Parser Class Initialized
INFO - 2023-10-28 12:44:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:44:31 --> Pagination Class Initialized
INFO - 2023-10-28 12:44:31 --> Form Validation Class Initialized
INFO - 2023-10-28 12:44:31 --> Controller Class Initialized
INFO - 2023-10-28 12:44:31 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:44:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:31 --> Model Class Initialized
INFO - 2023-10-28 12:44:31 --> Model Class Initialized
INFO - 2023-10-28 12:44:31 --> Final output sent to browser
DEBUG - 2023-10-28 12:44:31 --> Total execution time: 0.0199
ERROR - 2023-10-28 12:44:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:44:34 --> Config Class Initialized
INFO - 2023-10-28 12:44:34 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:44:34 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:44:34 --> Utf8 Class Initialized
INFO - 2023-10-28 12:44:34 --> URI Class Initialized
INFO - 2023-10-28 12:44:34 --> Router Class Initialized
INFO - 2023-10-28 12:44:34 --> Output Class Initialized
INFO - 2023-10-28 12:44:34 --> Security Class Initialized
DEBUG - 2023-10-28 12:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:44:34 --> Input Class Initialized
INFO - 2023-10-28 12:44:34 --> Language Class Initialized
INFO - 2023-10-28 12:44:34 --> Loader Class Initialized
INFO - 2023-10-28 12:44:34 --> Helper loaded: url_helper
INFO - 2023-10-28 12:44:34 --> Helper loaded: file_helper
INFO - 2023-10-28 12:44:34 --> Helper loaded: html_helper
INFO - 2023-10-28 12:44:34 --> Helper loaded: text_helper
INFO - 2023-10-28 12:44:34 --> Helper loaded: form_helper
INFO - 2023-10-28 12:44:34 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:44:34 --> Helper loaded: security_helper
INFO - 2023-10-28 12:44:34 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:44:34 --> Database Driver Class Initialized
INFO - 2023-10-28 12:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:44:34 --> Parser Class Initialized
INFO - 2023-10-28 12:44:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:44:34 --> Pagination Class Initialized
INFO - 2023-10-28 12:44:34 --> Form Validation Class Initialized
INFO - 2023-10-28 12:44:34 --> Controller Class Initialized
INFO - 2023-10-28 12:44:34 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:44:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:34 --> Model Class Initialized
INFO - 2023-10-28 12:44:34 --> Final output sent to browser
DEBUG - 2023-10-28 12:44:34 --> Total execution time: 0.0165
ERROR - 2023-10-28 12:44:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:44:46 --> Config Class Initialized
INFO - 2023-10-28 12:44:46 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:44:46 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:44:46 --> Utf8 Class Initialized
INFO - 2023-10-28 12:44:46 --> URI Class Initialized
INFO - 2023-10-28 12:44:46 --> Router Class Initialized
INFO - 2023-10-28 12:44:46 --> Output Class Initialized
INFO - 2023-10-28 12:44:46 --> Security Class Initialized
DEBUG - 2023-10-28 12:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:44:46 --> Input Class Initialized
INFO - 2023-10-28 12:44:46 --> Language Class Initialized
INFO - 2023-10-28 12:44:46 --> Loader Class Initialized
INFO - 2023-10-28 12:44:46 --> Helper loaded: url_helper
INFO - 2023-10-28 12:44:46 --> Helper loaded: file_helper
INFO - 2023-10-28 12:44:46 --> Helper loaded: html_helper
INFO - 2023-10-28 12:44:46 --> Helper loaded: text_helper
INFO - 2023-10-28 12:44:46 --> Helper loaded: form_helper
INFO - 2023-10-28 12:44:46 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:44:46 --> Helper loaded: security_helper
INFO - 2023-10-28 12:44:46 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:44:46 --> Database Driver Class Initialized
INFO - 2023-10-28 12:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:44:46 --> Parser Class Initialized
INFO - 2023-10-28 12:44:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:44:46 --> Pagination Class Initialized
INFO - 2023-10-28 12:44:46 --> Form Validation Class Initialized
INFO - 2023-10-28 12:44:46 --> Controller Class Initialized
INFO - 2023-10-28 12:44:46 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:44:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:46 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:46 --> Model Class Initialized
INFO - 2023-10-28 12:44:46 --> Final output sent to browser
DEBUG - 2023-10-28 12:44:46 --> Total execution time: 0.0554
ERROR - 2023-10-28 12:44:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:44:46 --> Config Class Initialized
INFO - 2023-10-28 12:44:46 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:44:46 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:44:46 --> Utf8 Class Initialized
INFO - 2023-10-28 12:44:46 --> URI Class Initialized
INFO - 2023-10-28 12:44:46 --> Router Class Initialized
INFO - 2023-10-28 12:44:46 --> Output Class Initialized
INFO - 2023-10-28 12:44:46 --> Security Class Initialized
DEBUG - 2023-10-28 12:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:44:46 --> Input Class Initialized
INFO - 2023-10-28 12:44:46 --> Language Class Initialized
INFO - 2023-10-28 12:44:46 --> Loader Class Initialized
INFO - 2023-10-28 12:44:46 --> Helper loaded: url_helper
INFO - 2023-10-28 12:44:46 --> Helper loaded: file_helper
INFO - 2023-10-28 12:44:46 --> Helper loaded: html_helper
INFO - 2023-10-28 12:44:46 --> Helper loaded: text_helper
INFO - 2023-10-28 12:44:46 --> Helper loaded: form_helper
INFO - 2023-10-28 12:44:46 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:44:46 --> Helper loaded: security_helper
INFO - 2023-10-28 12:44:46 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:44:46 --> Database Driver Class Initialized
INFO - 2023-10-28 12:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:44:46 --> Parser Class Initialized
INFO - 2023-10-28 12:44:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:44:46 --> Pagination Class Initialized
INFO - 2023-10-28 12:44:46 --> Form Validation Class Initialized
INFO - 2023-10-28 12:44:46 --> Controller Class Initialized
INFO - 2023-10-28 12:44:46 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:44:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:46 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:46 --> Model Class Initialized
INFO - 2023-10-28 12:44:46 --> Final output sent to browser
DEBUG - 2023-10-28 12:44:46 --> Total execution time: 0.0512
ERROR - 2023-10-28 12:44:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:44:47 --> Config Class Initialized
INFO - 2023-10-28 12:44:47 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:44:47 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:44:47 --> Utf8 Class Initialized
INFO - 2023-10-28 12:44:47 --> URI Class Initialized
INFO - 2023-10-28 12:44:47 --> Router Class Initialized
INFO - 2023-10-28 12:44:47 --> Output Class Initialized
INFO - 2023-10-28 12:44:47 --> Security Class Initialized
DEBUG - 2023-10-28 12:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:44:47 --> Input Class Initialized
INFO - 2023-10-28 12:44:47 --> Language Class Initialized
INFO - 2023-10-28 12:44:47 --> Loader Class Initialized
INFO - 2023-10-28 12:44:47 --> Helper loaded: url_helper
INFO - 2023-10-28 12:44:47 --> Helper loaded: file_helper
INFO - 2023-10-28 12:44:47 --> Helper loaded: html_helper
INFO - 2023-10-28 12:44:47 --> Helper loaded: text_helper
INFO - 2023-10-28 12:44:47 --> Helper loaded: form_helper
INFO - 2023-10-28 12:44:47 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:44:47 --> Helper loaded: security_helper
INFO - 2023-10-28 12:44:47 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:44:47 --> Database Driver Class Initialized
INFO - 2023-10-28 12:44:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:44:47 --> Parser Class Initialized
INFO - 2023-10-28 12:44:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:44:47 --> Pagination Class Initialized
INFO - 2023-10-28 12:44:47 --> Form Validation Class Initialized
INFO - 2023-10-28 12:44:47 --> Controller Class Initialized
INFO - 2023-10-28 12:44:47 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:44:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:47 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:47 --> Model Class Initialized
INFO - 2023-10-28 12:44:47 --> Final output sent to browser
DEBUG - 2023-10-28 12:44:47 --> Total execution time: 0.0187
ERROR - 2023-10-28 12:44:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:44:47 --> Config Class Initialized
INFO - 2023-10-28 12:44:47 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:44:47 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:44:47 --> Utf8 Class Initialized
INFO - 2023-10-28 12:44:47 --> URI Class Initialized
INFO - 2023-10-28 12:44:47 --> Router Class Initialized
INFO - 2023-10-28 12:44:47 --> Output Class Initialized
INFO - 2023-10-28 12:44:47 --> Security Class Initialized
DEBUG - 2023-10-28 12:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:44:47 --> Input Class Initialized
INFO - 2023-10-28 12:44:47 --> Language Class Initialized
INFO - 2023-10-28 12:44:47 --> Loader Class Initialized
INFO - 2023-10-28 12:44:47 --> Helper loaded: url_helper
INFO - 2023-10-28 12:44:47 --> Helper loaded: file_helper
INFO - 2023-10-28 12:44:47 --> Helper loaded: html_helper
INFO - 2023-10-28 12:44:47 --> Helper loaded: text_helper
INFO - 2023-10-28 12:44:47 --> Helper loaded: form_helper
INFO - 2023-10-28 12:44:47 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:44:47 --> Helper loaded: security_helper
INFO - 2023-10-28 12:44:47 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:44:47 --> Database Driver Class Initialized
INFO - 2023-10-28 12:44:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:44:47 --> Parser Class Initialized
INFO - 2023-10-28 12:44:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:44:47 --> Pagination Class Initialized
INFO - 2023-10-28 12:44:47 --> Form Validation Class Initialized
INFO - 2023-10-28 12:44:47 --> Controller Class Initialized
INFO - 2023-10-28 12:44:47 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:44:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:47 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:47 --> Model Class Initialized
INFO - 2023-10-28 12:44:47 --> Final output sent to browser
DEBUG - 2023-10-28 12:44:47 --> Total execution time: 0.0182
ERROR - 2023-10-28 12:44:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:44:48 --> Config Class Initialized
INFO - 2023-10-28 12:44:48 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:44:48 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:44:48 --> Utf8 Class Initialized
INFO - 2023-10-28 12:44:48 --> URI Class Initialized
INFO - 2023-10-28 12:44:48 --> Router Class Initialized
INFO - 2023-10-28 12:44:48 --> Output Class Initialized
INFO - 2023-10-28 12:44:48 --> Security Class Initialized
DEBUG - 2023-10-28 12:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:44:48 --> Input Class Initialized
INFO - 2023-10-28 12:44:48 --> Language Class Initialized
INFO - 2023-10-28 12:44:48 --> Loader Class Initialized
INFO - 2023-10-28 12:44:48 --> Helper loaded: url_helper
INFO - 2023-10-28 12:44:48 --> Helper loaded: file_helper
INFO - 2023-10-28 12:44:48 --> Helper loaded: html_helper
INFO - 2023-10-28 12:44:48 --> Helper loaded: text_helper
INFO - 2023-10-28 12:44:48 --> Helper loaded: form_helper
INFO - 2023-10-28 12:44:48 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:44:48 --> Helper loaded: security_helper
INFO - 2023-10-28 12:44:48 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:44:48 --> Database Driver Class Initialized
INFO - 2023-10-28 12:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:44:48 --> Parser Class Initialized
INFO - 2023-10-28 12:44:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:44:48 --> Pagination Class Initialized
INFO - 2023-10-28 12:44:48 --> Form Validation Class Initialized
INFO - 2023-10-28 12:44:48 --> Controller Class Initialized
INFO - 2023-10-28 12:44:48 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:44:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:48 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:48 --> Model Class Initialized
INFO - 2023-10-28 12:44:48 --> Final output sent to browser
DEBUG - 2023-10-28 12:44:48 --> Total execution time: 0.0233
ERROR - 2023-10-28 12:44:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:44:50 --> Config Class Initialized
INFO - 2023-10-28 12:44:50 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:44:50 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:44:50 --> Utf8 Class Initialized
INFO - 2023-10-28 12:44:50 --> URI Class Initialized
INFO - 2023-10-28 12:44:50 --> Router Class Initialized
INFO - 2023-10-28 12:44:50 --> Output Class Initialized
INFO - 2023-10-28 12:44:50 --> Security Class Initialized
DEBUG - 2023-10-28 12:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:44:50 --> Input Class Initialized
INFO - 2023-10-28 12:44:50 --> Language Class Initialized
INFO - 2023-10-28 12:44:50 --> Loader Class Initialized
INFO - 2023-10-28 12:44:50 --> Helper loaded: url_helper
INFO - 2023-10-28 12:44:50 --> Helper loaded: file_helper
INFO - 2023-10-28 12:44:50 --> Helper loaded: html_helper
INFO - 2023-10-28 12:44:50 --> Helper loaded: text_helper
INFO - 2023-10-28 12:44:50 --> Helper loaded: form_helper
INFO - 2023-10-28 12:44:50 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:44:50 --> Helper loaded: security_helper
INFO - 2023-10-28 12:44:50 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:44:50 --> Database Driver Class Initialized
INFO - 2023-10-28 12:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:44:50 --> Parser Class Initialized
INFO - 2023-10-28 12:44:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:44:50 --> Pagination Class Initialized
INFO - 2023-10-28 12:44:50 --> Form Validation Class Initialized
INFO - 2023-10-28 12:44:50 --> Controller Class Initialized
INFO - 2023-10-28 12:44:50 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:44:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:50 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:50 --> Model Class Initialized
INFO - 2023-10-28 12:44:50 --> Final output sent to browser
DEBUG - 2023-10-28 12:44:50 --> Total execution time: 0.0224
ERROR - 2023-10-28 12:44:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:44:51 --> Config Class Initialized
INFO - 2023-10-28 12:44:51 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:44:51 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:44:51 --> Utf8 Class Initialized
INFO - 2023-10-28 12:44:51 --> URI Class Initialized
INFO - 2023-10-28 12:44:51 --> Router Class Initialized
INFO - 2023-10-28 12:44:51 --> Output Class Initialized
INFO - 2023-10-28 12:44:51 --> Security Class Initialized
DEBUG - 2023-10-28 12:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:44:51 --> Input Class Initialized
INFO - 2023-10-28 12:44:51 --> Language Class Initialized
INFO - 2023-10-28 12:44:51 --> Loader Class Initialized
INFO - 2023-10-28 12:44:51 --> Helper loaded: url_helper
INFO - 2023-10-28 12:44:51 --> Helper loaded: file_helper
INFO - 2023-10-28 12:44:51 --> Helper loaded: html_helper
INFO - 2023-10-28 12:44:51 --> Helper loaded: text_helper
INFO - 2023-10-28 12:44:51 --> Helper loaded: form_helper
INFO - 2023-10-28 12:44:51 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:44:51 --> Helper loaded: security_helper
INFO - 2023-10-28 12:44:51 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:44:51 --> Database Driver Class Initialized
INFO - 2023-10-28 12:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:44:51 --> Parser Class Initialized
INFO - 2023-10-28 12:44:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:44:51 --> Pagination Class Initialized
INFO - 2023-10-28 12:44:51 --> Form Validation Class Initialized
INFO - 2023-10-28 12:44:51 --> Controller Class Initialized
INFO - 2023-10-28 12:44:51 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:44:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:51 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:51 --> Model Class Initialized
INFO - 2023-10-28 12:44:51 --> Final output sent to browser
DEBUG - 2023-10-28 12:44:51 --> Total execution time: 0.0226
ERROR - 2023-10-28 12:44:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:44:52 --> Config Class Initialized
INFO - 2023-10-28 12:44:52 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:44:52 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:44:52 --> Utf8 Class Initialized
INFO - 2023-10-28 12:44:52 --> URI Class Initialized
INFO - 2023-10-28 12:44:52 --> Router Class Initialized
INFO - 2023-10-28 12:44:52 --> Output Class Initialized
INFO - 2023-10-28 12:44:52 --> Security Class Initialized
DEBUG - 2023-10-28 12:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:44:52 --> Input Class Initialized
INFO - 2023-10-28 12:44:52 --> Language Class Initialized
INFO - 2023-10-28 12:44:52 --> Loader Class Initialized
INFO - 2023-10-28 12:44:52 --> Helper loaded: url_helper
INFO - 2023-10-28 12:44:52 --> Helper loaded: file_helper
INFO - 2023-10-28 12:44:52 --> Helper loaded: html_helper
INFO - 2023-10-28 12:44:52 --> Helper loaded: text_helper
INFO - 2023-10-28 12:44:52 --> Helper loaded: form_helper
INFO - 2023-10-28 12:44:52 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:44:52 --> Helper loaded: security_helper
INFO - 2023-10-28 12:44:52 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:44:52 --> Database Driver Class Initialized
INFO - 2023-10-28 12:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:44:52 --> Parser Class Initialized
INFO - 2023-10-28 12:44:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:44:52 --> Pagination Class Initialized
INFO - 2023-10-28 12:44:52 --> Form Validation Class Initialized
INFO - 2023-10-28 12:44:52 --> Controller Class Initialized
INFO - 2023-10-28 12:44:52 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:44:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:52 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:52 --> Model Class Initialized
INFO - 2023-10-28 12:44:52 --> Final output sent to browser
DEBUG - 2023-10-28 12:44:52 --> Total execution time: 0.0606
ERROR - 2023-10-28 12:44:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:44:53 --> Config Class Initialized
INFO - 2023-10-28 12:44:53 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:44:53 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:44:53 --> Utf8 Class Initialized
INFO - 2023-10-28 12:44:53 --> URI Class Initialized
INFO - 2023-10-28 12:44:53 --> Router Class Initialized
INFO - 2023-10-28 12:44:53 --> Output Class Initialized
INFO - 2023-10-28 12:44:53 --> Security Class Initialized
DEBUG - 2023-10-28 12:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:44:53 --> Input Class Initialized
INFO - 2023-10-28 12:44:53 --> Language Class Initialized
INFO - 2023-10-28 12:44:53 --> Loader Class Initialized
INFO - 2023-10-28 12:44:53 --> Helper loaded: url_helper
INFO - 2023-10-28 12:44:53 --> Helper loaded: file_helper
INFO - 2023-10-28 12:44:53 --> Helper loaded: html_helper
INFO - 2023-10-28 12:44:53 --> Helper loaded: text_helper
INFO - 2023-10-28 12:44:53 --> Helper loaded: form_helper
INFO - 2023-10-28 12:44:53 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:44:53 --> Helper loaded: security_helper
INFO - 2023-10-28 12:44:53 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:44:53 --> Database Driver Class Initialized
INFO - 2023-10-28 12:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:44:53 --> Parser Class Initialized
INFO - 2023-10-28 12:44:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:44:53 --> Pagination Class Initialized
INFO - 2023-10-28 12:44:53 --> Form Validation Class Initialized
INFO - 2023-10-28 12:44:53 --> Controller Class Initialized
INFO - 2023-10-28 12:44:53 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:44:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:53 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:53 --> Model Class Initialized
INFO - 2023-10-28 12:44:53 --> Final output sent to browser
DEBUG - 2023-10-28 12:44:53 --> Total execution time: 0.0263
ERROR - 2023-10-28 12:44:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:44:55 --> Config Class Initialized
INFO - 2023-10-28 12:44:55 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:44:55 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:44:55 --> Utf8 Class Initialized
INFO - 2023-10-28 12:44:55 --> URI Class Initialized
INFO - 2023-10-28 12:44:55 --> Router Class Initialized
INFO - 2023-10-28 12:44:55 --> Output Class Initialized
INFO - 2023-10-28 12:44:55 --> Security Class Initialized
DEBUG - 2023-10-28 12:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:44:55 --> Input Class Initialized
INFO - 2023-10-28 12:44:55 --> Language Class Initialized
INFO - 2023-10-28 12:44:55 --> Loader Class Initialized
INFO - 2023-10-28 12:44:55 --> Helper loaded: url_helper
INFO - 2023-10-28 12:44:55 --> Helper loaded: file_helper
INFO - 2023-10-28 12:44:55 --> Helper loaded: html_helper
INFO - 2023-10-28 12:44:55 --> Helper loaded: text_helper
INFO - 2023-10-28 12:44:55 --> Helper loaded: form_helper
INFO - 2023-10-28 12:44:55 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:44:55 --> Helper loaded: security_helper
INFO - 2023-10-28 12:44:55 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:44:55 --> Database Driver Class Initialized
INFO - 2023-10-28 12:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:44:55 --> Parser Class Initialized
INFO - 2023-10-28 12:44:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:44:55 --> Pagination Class Initialized
INFO - 2023-10-28 12:44:55 --> Form Validation Class Initialized
INFO - 2023-10-28 12:44:55 --> Controller Class Initialized
INFO - 2023-10-28 12:44:55 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:44:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:55 --> Model Class Initialized
INFO - 2023-10-28 12:44:55 --> Model Class Initialized
INFO - 2023-10-28 12:44:55 --> Final output sent to browser
DEBUG - 2023-10-28 12:44:55 --> Total execution time: 0.0239
ERROR - 2023-10-28 12:44:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:44:57 --> Config Class Initialized
INFO - 2023-10-28 12:44:57 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:44:57 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:44:57 --> Utf8 Class Initialized
INFO - 2023-10-28 12:44:57 --> URI Class Initialized
INFO - 2023-10-28 12:44:57 --> Router Class Initialized
INFO - 2023-10-28 12:44:57 --> Output Class Initialized
INFO - 2023-10-28 12:44:57 --> Security Class Initialized
DEBUG - 2023-10-28 12:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:44:57 --> Input Class Initialized
INFO - 2023-10-28 12:44:57 --> Language Class Initialized
INFO - 2023-10-28 12:44:57 --> Loader Class Initialized
INFO - 2023-10-28 12:44:57 --> Helper loaded: url_helper
INFO - 2023-10-28 12:44:57 --> Helper loaded: file_helper
INFO - 2023-10-28 12:44:57 --> Helper loaded: html_helper
INFO - 2023-10-28 12:44:57 --> Helper loaded: text_helper
INFO - 2023-10-28 12:44:57 --> Helper loaded: form_helper
INFO - 2023-10-28 12:44:57 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:44:57 --> Helper loaded: security_helper
INFO - 2023-10-28 12:44:57 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:44:57 --> Database Driver Class Initialized
INFO - 2023-10-28 12:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:44:57 --> Parser Class Initialized
INFO - 2023-10-28 12:44:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:44:57 --> Pagination Class Initialized
INFO - 2023-10-28 12:44:57 --> Form Validation Class Initialized
INFO - 2023-10-28 12:44:57 --> Controller Class Initialized
INFO - 2023-10-28 12:44:57 --> Model Class Initialized
DEBUG - 2023-10-28 12:44:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:44:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:44:57 --> Model Class Initialized
INFO - 2023-10-28 12:44:57 --> Final output sent to browser
DEBUG - 2023-10-28 12:44:57 --> Total execution time: 0.0164
ERROR - 2023-10-28 12:45:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:45:12 --> Config Class Initialized
INFO - 2023-10-28 12:45:12 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:45:12 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:45:12 --> Utf8 Class Initialized
INFO - 2023-10-28 12:45:12 --> URI Class Initialized
INFO - 2023-10-28 12:45:12 --> Router Class Initialized
INFO - 2023-10-28 12:45:12 --> Output Class Initialized
INFO - 2023-10-28 12:45:12 --> Security Class Initialized
DEBUG - 2023-10-28 12:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:45:12 --> Input Class Initialized
INFO - 2023-10-28 12:45:12 --> Language Class Initialized
INFO - 2023-10-28 12:45:12 --> Loader Class Initialized
INFO - 2023-10-28 12:45:12 --> Helper loaded: url_helper
INFO - 2023-10-28 12:45:12 --> Helper loaded: file_helper
INFO - 2023-10-28 12:45:12 --> Helper loaded: html_helper
INFO - 2023-10-28 12:45:12 --> Helper loaded: text_helper
INFO - 2023-10-28 12:45:12 --> Helper loaded: form_helper
INFO - 2023-10-28 12:45:12 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:45:12 --> Helper loaded: security_helper
INFO - 2023-10-28 12:45:12 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:45:12 --> Database Driver Class Initialized
INFO - 2023-10-28 12:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:45:12 --> Parser Class Initialized
INFO - 2023-10-28 12:45:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:45:12 --> Pagination Class Initialized
INFO - 2023-10-28 12:45:12 --> Form Validation Class Initialized
INFO - 2023-10-28 12:45:12 --> Controller Class Initialized
INFO - 2023-10-28 12:45:12 --> Model Class Initialized
DEBUG - 2023-10-28 12:45:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:45:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:45:12 --> Model Class Initialized
DEBUG - 2023-10-28 12:45:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:45:12 --> Model Class Initialized
INFO - 2023-10-28 12:45:12 --> Final output sent to browser
DEBUG - 2023-10-28 12:45:12 --> Total execution time: 0.0648
ERROR - 2023-10-28 12:45:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:45:12 --> Config Class Initialized
INFO - 2023-10-28 12:45:12 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:45:12 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:45:12 --> Utf8 Class Initialized
INFO - 2023-10-28 12:45:12 --> URI Class Initialized
INFO - 2023-10-28 12:45:12 --> Router Class Initialized
INFO - 2023-10-28 12:45:12 --> Output Class Initialized
INFO - 2023-10-28 12:45:12 --> Security Class Initialized
DEBUG - 2023-10-28 12:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:45:12 --> Input Class Initialized
INFO - 2023-10-28 12:45:12 --> Language Class Initialized
INFO - 2023-10-28 12:45:12 --> Loader Class Initialized
INFO - 2023-10-28 12:45:12 --> Helper loaded: url_helper
INFO - 2023-10-28 12:45:12 --> Helper loaded: file_helper
INFO - 2023-10-28 12:45:12 --> Helper loaded: html_helper
INFO - 2023-10-28 12:45:12 --> Helper loaded: text_helper
INFO - 2023-10-28 12:45:12 --> Helper loaded: form_helper
INFO - 2023-10-28 12:45:12 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:45:12 --> Helper loaded: security_helper
INFO - 2023-10-28 12:45:12 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:45:12 --> Database Driver Class Initialized
INFO - 2023-10-28 12:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:45:12 --> Parser Class Initialized
INFO - 2023-10-28 12:45:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:45:12 --> Pagination Class Initialized
INFO - 2023-10-28 12:45:12 --> Form Validation Class Initialized
INFO - 2023-10-28 12:45:12 --> Controller Class Initialized
INFO - 2023-10-28 12:45:12 --> Model Class Initialized
DEBUG - 2023-10-28 12:45:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:45:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:45:12 --> Model Class Initialized
DEBUG - 2023-10-28 12:45:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:45:12 --> Model Class Initialized
INFO - 2023-10-28 12:45:12 --> Final output sent to browser
DEBUG - 2023-10-28 12:45:12 --> Total execution time: 0.0546
ERROR - 2023-10-28 12:45:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:45:13 --> Config Class Initialized
INFO - 2023-10-28 12:45:13 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:45:13 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:45:13 --> Utf8 Class Initialized
INFO - 2023-10-28 12:45:13 --> URI Class Initialized
INFO - 2023-10-28 12:45:13 --> Router Class Initialized
INFO - 2023-10-28 12:45:13 --> Output Class Initialized
INFO - 2023-10-28 12:45:13 --> Security Class Initialized
DEBUG - 2023-10-28 12:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:45:13 --> Input Class Initialized
INFO - 2023-10-28 12:45:13 --> Language Class Initialized
INFO - 2023-10-28 12:45:13 --> Loader Class Initialized
INFO - 2023-10-28 12:45:13 --> Helper loaded: url_helper
INFO - 2023-10-28 12:45:13 --> Helper loaded: file_helper
INFO - 2023-10-28 12:45:13 --> Helper loaded: html_helper
INFO - 2023-10-28 12:45:13 --> Helper loaded: text_helper
INFO - 2023-10-28 12:45:13 --> Helper loaded: form_helper
INFO - 2023-10-28 12:45:13 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:45:13 --> Helper loaded: security_helper
INFO - 2023-10-28 12:45:13 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:45:13 --> Database Driver Class Initialized
INFO - 2023-10-28 12:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:45:13 --> Parser Class Initialized
INFO - 2023-10-28 12:45:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:45:13 --> Pagination Class Initialized
INFO - 2023-10-28 12:45:13 --> Form Validation Class Initialized
INFO - 2023-10-28 12:45:13 --> Controller Class Initialized
INFO - 2023-10-28 12:45:13 --> Model Class Initialized
DEBUG - 2023-10-28 12:45:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:45:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:45:13 --> Model Class Initialized
DEBUG - 2023-10-28 12:45:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:45:13 --> Model Class Initialized
INFO - 2023-10-28 12:45:13 --> Final output sent to browser
DEBUG - 2023-10-28 12:45:13 --> Total execution time: 0.0540
ERROR - 2023-10-28 12:45:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:45:13 --> Config Class Initialized
INFO - 2023-10-28 12:45:13 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:45:13 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:45:13 --> Utf8 Class Initialized
INFO - 2023-10-28 12:45:13 --> URI Class Initialized
INFO - 2023-10-28 12:45:13 --> Router Class Initialized
INFO - 2023-10-28 12:45:13 --> Output Class Initialized
INFO - 2023-10-28 12:45:13 --> Security Class Initialized
DEBUG - 2023-10-28 12:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:45:13 --> Input Class Initialized
INFO - 2023-10-28 12:45:13 --> Language Class Initialized
INFO - 2023-10-28 12:45:13 --> Loader Class Initialized
INFO - 2023-10-28 12:45:13 --> Helper loaded: url_helper
INFO - 2023-10-28 12:45:13 --> Helper loaded: file_helper
INFO - 2023-10-28 12:45:13 --> Helper loaded: html_helper
INFO - 2023-10-28 12:45:13 --> Helper loaded: text_helper
INFO - 2023-10-28 12:45:13 --> Helper loaded: form_helper
INFO - 2023-10-28 12:45:13 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:45:13 --> Helper loaded: security_helper
INFO - 2023-10-28 12:45:13 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:45:13 --> Database Driver Class Initialized
INFO - 2023-10-28 12:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:45:13 --> Parser Class Initialized
INFO - 2023-10-28 12:45:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:45:13 --> Pagination Class Initialized
INFO - 2023-10-28 12:45:13 --> Form Validation Class Initialized
INFO - 2023-10-28 12:45:13 --> Controller Class Initialized
INFO - 2023-10-28 12:45:13 --> Model Class Initialized
DEBUG - 2023-10-28 12:45:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:45:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:45:13 --> Model Class Initialized
DEBUG - 2023-10-28 12:45:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:45:13 --> Model Class Initialized
INFO - 2023-10-28 12:45:13 --> Final output sent to browser
DEBUG - 2023-10-28 12:45:13 --> Total execution time: 0.0521
ERROR - 2023-10-28 12:45:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:45:14 --> Config Class Initialized
INFO - 2023-10-28 12:45:14 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:45:14 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:45:14 --> Utf8 Class Initialized
INFO - 2023-10-28 12:45:14 --> URI Class Initialized
INFO - 2023-10-28 12:45:14 --> Router Class Initialized
INFO - 2023-10-28 12:45:14 --> Output Class Initialized
INFO - 2023-10-28 12:45:14 --> Security Class Initialized
DEBUG - 2023-10-28 12:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:45:14 --> Input Class Initialized
INFO - 2023-10-28 12:45:14 --> Language Class Initialized
INFO - 2023-10-28 12:45:14 --> Loader Class Initialized
INFO - 2023-10-28 12:45:14 --> Helper loaded: url_helper
INFO - 2023-10-28 12:45:14 --> Helper loaded: file_helper
INFO - 2023-10-28 12:45:14 --> Helper loaded: html_helper
INFO - 2023-10-28 12:45:14 --> Helper loaded: text_helper
INFO - 2023-10-28 12:45:14 --> Helper loaded: form_helper
INFO - 2023-10-28 12:45:14 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:45:14 --> Helper loaded: security_helper
INFO - 2023-10-28 12:45:14 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:45:14 --> Database Driver Class Initialized
INFO - 2023-10-28 12:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:45:14 --> Parser Class Initialized
INFO - 2023-10-28 12:45:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:45:14 --> Pagination Class Initialized
INFO - 2023-10-28 12:45:14 --> Form Validation Class Initialized
INFO - 2023-10-28 12:45:14 --> Controller Class Initialized
INFO - 2023-10-28 12:45:14 --> Model Class Initialized
DEBUG - 2023-10-28 12:45:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:45:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:45:14 --> Model Class Initialized
DEBUG - 2023-10-28 12:45:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:45:14 --> Model Class Initialized
INFO - 2023-10-28 12:45:14 --> Final output sent to browser
DEBUG - 2023-10-28 12:45:14 --> Total execution time: 0.0209
ERROR - 2023-10-28 12:45:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:45:16 --> Config Class Initialized
INFO - 2023-10-28 12:45:16 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:45:16 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:45:16 --> Utf8 Class Initialized
INFO - 2023-10-28 12:45:16 --> URI Class Initialized
INFO - 2023-10-28 12:45:16 --> Router Class Initialized
INFO - 2023-10-28 12:45:16 --> Output Class Initialized
INFO - 2023-10-28 12:45:16 --> Security Class Initialized
DEBUG - 2023-10-28 12:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:45:16 --> Input Class Initialized
INFO - 2023-10-28 12:45:16 --> Language Class Initialized
INFO - 2023-10-28 12:45:16 --> Loader Class Initialized
INFO - 2023-10-28 12:45:16 --> Helper loaded: url_helper
INFO - 2023-10-28 12:45:16 --> Helper loaded: file_helper
INFO - 2023-10-28 12:45:16 --> Helper loaded: html_helper
INFO - 2023-10-28 12:45:16 --> Helper loaded: text_helper
INFO - 2023-10-28 12:45:16 --> Helper loaded: form_helper
INFO - 2023-10-28 12:45:16 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:45:16 --> Helper loaded: security_helper
INFO - 2023-10-28 12:45:16 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:45:16 --> Database Driver Class Initialized
INFO - 2023-10-28 12:45:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:45:16 --> Parser Class Initialized
INFO - 2023-10-28 12:45:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:45:16 --> Pagination Class Initialized
INFO - 2023-10-28 12:45:16 --> Form Validation Class Initialized
INFO - 2023-10-28 12:45:16 --> Controller Class Initialized
INFO - 2023-10-28 12:45:16 --> Model Class Initialized
DEBUG - 2023-10-28 12:45:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:45:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:45:16 --> Model Class Initialized
INFO - 2023-10-28 12:45:16 --> Model Class Initialized
INFO - 2023-10-28 12:45:16 --> Final output sent to browser
DEBUG - 2023-10-28 12:45:16 --> Total execution time: 0.0197
ERROR - 2023-10-28 12:45:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:45:18 --> Config Class Initialized
INFO - 2023-10-28 12:45:18 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:45:18 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:45:18 --> Utf8 Class Initialized
INFO - 2023-10-28 12:45:18 --> URI Class Initialized
INFO - 2023-10-28 12:45:18 --> Router Class Initialized
INFO - 2023-10-28 12:45:18 --> Output Class Initialized
INFO - 2023-10-28 12:45:18 --> Security Class Initialized
DEBUG - 2023-10-28 12:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:45:18 --> Input Class Initialized
INFO - 2023-10-28 12:45:18 --> Language Class Initialized
INFO - 2023-10-28 12:45:18 --> Loader Class Initialized
INFO - 2023-10-28 12:45:18 --> Helper loaded: url_helper
INFO - 2023-10-28 12:45:18 --> Helper loaded: file_helper
INFO - 2023-10-28 12:45:18 --> Helper loaded: html_helper
INFO - 2023-10-28 12:45:18 --> Helper loaded: text_helper
INFO - 2023-10-28 12:45:18 --> Helper loaded: form_helper
INFO - 2023-10-28 12:45:18 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:45:18 --> Helper loaded: security_helper
INFO - 2023-10-28 12:45:18 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:45:18 --> Database Driver Class Initialized
INFO - 2023-10-28 12:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:45:18 --> Parser Class Initialized
INFO - 2023-10-28 12:45:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:45:18 --> Pagination Class Initialized
INFO - 2023-10-28 12:45:18 --> Form Validation Class Initialized
INFO - 2023-10-28 12:45:18 --> Controller Class Initialized
INFO - 2023-10-28 12:45:18 --> Model Class Initialized
DEBUG - 2023-10-28 12:45:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:45:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:45:18 --> Model Class Initialized
INFO - 2023-10-28 12:45:18 --> Final output sent to browser
DEBUG - 2023-10-28 12:45:18 --> Total execution time: 0.0164
ERROR - 2023-10-28 12:45:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:45:29 --> Config Class Initialized
INFO - 2023-10-28 12:45:29 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:45:29 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:45:29 --> Utf8 Class Initialized
INFO - 2023-10-28 12:45:29 --> URI Class Initialized
INFO - 2023-10-28 12:45:29 --> Router Class Initialized
INFO - 2023-10-28 12:45:29 --> Output Class Initialized
INFO - 2023-10-28 12:45:29 --> Security Class Initialized
DEBUG - 2023-10-28 12:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:45:29 --> Input Class Initialized
INFO - 2023-10-28 12:45:29 --> Language Class Initialized
INFO - 2023-10-28 12:45:29 --> Loader Class Initialized
INFO - 2023-10-28 12:45:29 --> Helper loaded: url_helper
INFO - 2023-10-28 12:45:29 --> Helper loaded: file_helper
INFO - 2023-10-28 12:45:29 --> Helper loaded: html_helper
INFO - 2023-10-28 12:45:29 --> Helper loaded: text_helper
INFO - 2023-10-28 12:45:29 --> Helper loaded: form_helper
INFO - 2023-10-28 12:45:29 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:45:29 --> Helper loaded: security_helper
INFO - 2023-10-28 12:45:29 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:45:29 --> Database Driver Class Initialized
INFO - 2023-10-28 12:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:45:29 --> Parser Class Initialized
INFO - 2023-10-28 12:45:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:45:29 --> Pagination Class Initialized
INFO - 2023-10-28 12:45:29 --> Form Validation Class Initialized
INFO - 2023-10-28 12:45:29 --> Controller Class Initialized
INFO - 2023-10-28 12:45:29 --> Model Class Initialized
DEBUG - 2023-10-28 12:45:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:45:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:45:29 --> Model Class Initialized
DEBUG - 2023-10-28 12:45:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:45:29 --> Model Class Initialized
INFO - 2023-10-28 12:45:29 --> Final output sent to browser
DEBUG - 2023-10-28 12:45:29 --> Total execution time: 0.0523
ERROR - 2023-10-28 12:45:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:45:29 --> Config Class Initialized
INFO - 2023-10-28 12:45:29 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:45:29 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:45:29 --> Utf8 Class Initialized
INFO - 2023-10-28 12:45:29 --> URI Class Initialized
INFO - 2023-10-28 12:45:29 --> Router Class Initialized
INFO - 2023-10-28 12:45:29 --> Output Class Initialized
INFO - 2023-10-28 12:45:29 --> Security Class Initialized
DEBUG - 2023-10-28 12:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:45:29 --> Input Class Initialized
INFO - 2023-10-28 12:45:29 --> Language Class Initialized
INFO - 2023-10-28 12:45:29 --> Loader Class Initialized
INFO - 2023-10-28 12:45:29 --> Helper loaded: url_helper
INFO - 2023-10-28 12:45:29 --> Helper loaded: file_helper
INFO - 2023-10-28 12:45:29 --> Helper loaded: html_helper
INFO - 2023-10-28 12:45:29 --> Helper loaded: text_helper
INFO - 2023-10-28 12:45:29 --> Helper loaded: form_helper
INFO - 2023-10-28 12:45:29 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:45:29 --> Helper loaded: security_helper
INFO - 2023-10-28 12:45:29 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:45:29 --> Database Driver Class Initialized
INFO - 2023-10-28 12:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:45:29 --> Parser Class Initialized
INFO - 2023-10-28 12:45:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:45:29 --> Pagination Class Initialized
INFO - 2023-10-28 12:45:29 --> Form Validation Class Initialized
INFO - 2023-10-28 12:45:29 --> Controller Class Initialized
INFO - 2023-10-28 12:45:29 --> Model Class Initialized
DEBUG - 2023-10-28 12:45:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:45:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:45:29 --> Model Class Initialized
DEBUG - 2023-10-28 12:45:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:45:29 --> Model Class Initialized
INFO - 2023-10-28 12:45:29 --> Final output sent to browser
DEBUG - 2023-10-28 12:45:29 --> Total execution time: 0.0507
ERROR - 2023-10-28 12:45:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:45:30 --> Config Class Initialized
INFO - 2023-10-28 12:45:30 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:45:30 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:45:30 --> Utf8 Class Initialized
INFO - 2023-10-28 12:45:30 --> URI Class Initialized
INFO - 2023-10-28 12:45:30 --> Router Class Initialized
INFO - 2023-10-28 12:45:30 --> Output Class Initialized
INFO - 2023-10-28 12:45:30 --> Security Class Initialized
DEBUG - 2023-10-28 12:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:45:30 --> Input Class Initialized
INFO - 2023-10-28 12:45:30 --> Language Class Initialized
INFO - 2023-10-28 12:45:30 --> Loader Class Initialized
INFO - 2023-10-28 12:45:30 --> Helper loaded: url_helper
INFO - 2023-10-28 12:45:30 --> Helper loaded: file_helper
INFO - 2023-10-28 12:45:30 --> Helper loaded: html_helper
INFO - 2023-10-28 12:45:30 --> Helper loaded: text_helper
INFO - 2023-10-28 12:45:30 --> Helper loaded: form_helper
INFO - 2023-10-28 12:45:30 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:45:30 --> Helper loaded: security_helper
INFO - 2023-10-28 12:45:30 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:45:30 --> Database Driver Class Initialized
INFO - 2023-10-28 12:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:45:30 --> Parser Class Initialized
INFO - 2023-10-28 12:45:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:45:30 --> Pagination Class Initialized
INFO - 2023-10-28 12:45:30 --> Form Validation Class Initialized
INFO - 2023-10-28 12:45:30 --> Controller Class Initialized
INFO - 2023-10-28 12:45:30 --> Model Class Initialized
DEBUG - 2023-10-28 12:45:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:45:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:45:30 --> Model Class Initialized
DEBUG - 2023-10-28 12:45:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:45:30 --> Model Class Initialized
INFO - 2023-10-28 12:45:30 --> Final output sent to browser
DEBUG - 2023-10-28 12:45:30 --> Total execution time: 0.0514
ERROR - 2023-10-28 12:45:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:45:32 --> Config Class Initialized
INFO - 2023-10-28 12:45:32 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:45:32 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:45:32 --> Utf8 Class Initialized
INFO - 2023-10-28 12:45:32 --> URI Class Initialized
INFO - 2023-10-28 12:45:32 --> Router Class Initialized
INFO - 2023-10-28 12:45:32 --> Output Class Initialized
INFO - 2023-10-28 12:45:32 --> Security Class Initialized
DEBUG - 2023-10-28 12:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:45:32 --> Input Class Initialized
INFO - 2023-10-28 12:45:32 --> Language Class Initialized
INFO - 2023-10-28 12:45:32 --> Loader Class Initialized
INFO - 2023-10-28 12:45:32 --> Helper loaded: url_helper
INFO - 2023-10-28 12:45:32 --> Helper loaded: file_helper
INFO - 2023-10-28 12:45:32 --> Helper loaded: html_helper
INFO - 2023-10-28 12:45:32 --> Helper loaded: text_helper
INFO - 2023-10-28 12:45:32 --> Helper loaded: form_helper
INFO - 2023-10-28 12:45:32 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:45:32 --> Helper loaded: security_helper
INFO - 2023-10-28 12:45:32 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:45:32 --> Database Driver Class Initialized
INFO - 2023-10-28 12:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:45:32 --> Parser Class Initialized
INFO - 2023-10-28 12:45:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:45:32 --> Pagination Class Initialized
INFO - 2023-10-28 12:45:32 --> Form Validation Class Initialized
INFO - 2023-10-28 12:45:32 --> Controller Class Initialized
INFO - 2023-10-28 12:45:32 --> Model Class Initialized
DEBUG - 2023-10-28 12:45:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:45:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:45:32 --> Model Class Initialized
INFO - 2023-10-28 12:45:32 --> Model Class Initialized
INFO - 2023-10-28 12:45:32 --> Final output sent to browser
DEBUG - 2023-10-28 12:45:32 --> Total execution time: 0.0185
ERROR - 2023-10-28 12:45:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:45:34 --> Config Class Initialized
INFO - 2023-10-28 12:45:34 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:45:34 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:45:34 --> Utf8 Class Initialized
INFO - 2023-10-28 12:45:34 --> URI Class Initialized
INFO - 2023-10-28 12:45:34 --> Router Class Initialized
INFO - 2023-10-28 12:45:34 --> Output Class Initialized
INFO - 2023-10-28 12:45:34 --> Security Class Initialized
DEBUG - 2023-10-28 12:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:45:34 --> Input Class Initialized
INFO - 2023-10-28 12:45:34 --> Language Class Initialized
INFO - 2023-10-28 12:45:34 --> Loader Class Initialized
INFO - 2023-10-28 12:45:34 --> Helper loaded: url_helper
INFO - 2023-10-28 12:45:34 --> Helper loaded: file_helper
INFO - 2023-10-28 12:45:34 --> Helper loaded: html_helper
INFO - 2023-10-28 12:45:34 --> Helper loaded: text_helper
INFO - 2023-10-28 12:45:34 --> Helper loaded: form_helper
INFO - 2023-10-28 12:45:34 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:45:34 --> Helper loaded: security_helper
INFO - 2023-10-28 12:45:34 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:45:34 --> Database Driver Class Initialized
INFO - 2023-10-28 12:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:45:34 --> Parser Class Initialized
INFO - 2023-10-28 12:45:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:45:34 --> Pagination Class Initialized
INFO - 2023-10-28 12:45:34 --> Form Validation Class Initialized
INFO - 2023-10-28 12:45:34 --> Controller Class Initialized
INFO - 2023-10-28 12:45:34 --> Model Class Initialized
DEBUG - 2023-10-28 12:45:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:45:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:45:34 --> Model Class Initialized
INFO - 2023-10-28 12:45:34 --> Final output sent to browser
DEBUG - 2023-10-28 12:45:34 --> Total execution time: 0.0185
ERROR - 2023-10-28 12:45:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:45:44 --> Config Class Initialized
INFO - 2023-10-28 12:45:44 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:45:44 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:45:44 --> Utf8 Class Initialized
INFO - 2023-10-28 12:45:44 --> URI Class Initialized
INFO - 2023-10-28 12:45:44 --> Router Class Initialized
INFO - 2023-10-28 12:45:44 --> Output Class Initialized
INFO - 2023-10-28 12:45:44 --> Security Class Initialized
DEBUG - 2023-10-28 12:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:45:44 --> Input Class Initialized
INFO - 2023-10-28 12:45:44 --> Language Class Initialized
INFO - 2023-10-28 12:45:44 --> Loader Class Initialized
INFO - 2023-10-28 12:45:44 --> Helper loaded: url_helper
INFO - 2023-10-28 12:45:44 --> Helper loaded: file_helper
INFO - 2023-10-28 12:45:44 --> Helper loaded: html_helper
INFO - 2023-10-28 12:45:44 --> Helper loaded: text_helper
INFO - 2023-10-28 12:45:44 --> Helper loaded: form_helper
INFO - 2023-10-28 12:45:44 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:45:44 --> Helper loaded: security_helper
INFO - 2023-10-28 12:45:44 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:45:44 --> Database Driver Class Initialized
INFO - 2023-10-28 12:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:45:44 --> Parser Class Initialized
INFO - 2023-10-28 12:45:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:45:44 --> Pagination Class Initialized
INFO - 2023-10-28 12:45:44 --> Form Validation Class Initialized
INFO - 2023-10-28 12:45:44 --> Controller Class Initialized
INFO - 2023-10-28 12:45:44 --> Model Class Initialized
DEBUG - 2023-10-28 12:45:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:45:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:45:44 --> Model Class Initialized
DEBUG - 2023-10-28 12:45:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:45:44 --> Model Class Initialized
INFO - 2023-10-28 12:45:44 --> Email Class Initialized
DEBUG - 2023-10-28 12:45:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:45:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2023-10-28 12:45:44 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2023-10-28 12:45:44 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2023-10-28 12:45:44 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2023-10-28 12:45:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-10-28 12:45:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-10-28 12:45:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-10-28 12:45:44 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-10-28 12:45:44 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-10-28 12:45:44 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-10-28 12:45:44 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-10-28 12:45:44 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2023-10-28 12:45:45 --> Language file loaded: language/english/email_lang.php
INFO - 2023-10-28 12:45:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2023-10-28 12:45:45 --> Final output sent to browser
DEBUG - 2023-10-28 12:45:45 --> Total execution time: 0.5452
ERROR - 2023-10-28 12:45:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:45:47 --> Config Class Initialized
INFO - 2023-10-28 12:45:47 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:45:47 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:45:47 --> Utf8 Class Initialized
INFO - 2023-10-28 12:45:47 --> URI Class Initialized
INFO - 2023-10-28 12:45:47 --> Router Class Initialized
INFO - 2023-10-28 12:45:47 --> Output Class Initialized
INFO - 2023-10-28 12:45:47 --> Security Class Initialized
DEBUG - 2023-10-28 12:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:45:47 --> Input Class Initialized
INFO - 2023-10-28 12:45:47 --> Language Class Initialized
INFO - 2023-10-28 12:45:47 --> Loader Class Initialized
INFO - 2023-10-28 12:45:47 --> Helper loaded: url_helper
INFO - 2023-10-28 12:45:47 --> Helper loaded: file_helper
INFO - 2023-10-28 12:45:47 --> Helper loaded: html_helper
INFO - 2023-10-28 12:45:47 --> Helper loaded: text_helper
INFO - 2023-10-28 12:45:47 --> Helper loaded: form_helper
INFO - 2023-10-28 12:45:47 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:45:47 --> Helper loaded: security_helper
INFO - 2023-10-28 12:45:47 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:45:47 --> Database Driver Class Initialized
INFO - 2023-10-28 12:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:45:47 --> Parser Class Initialized
INFO - 2023-10-28 12:45:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:45:47 --> Pagination Class Initialized
INFO - 2023-10-28 12:45:47 --> Form Validation Class Initialized
INFO - 2023-10-28 12:45:47 --> Controller Class Initialized
INFO - 2023-10-28 12:45:47 --> Model Class Initialized
DEBUG - 2023-10-28 12:45:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:45:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:45:47 --> Model Class Initialized
DEBUG - 2023-10-28 12:45:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:45:47 --> Model Class Initialized
INFO - 2023-10-28 12:45:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-10-28 12:45:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:45:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 12:45:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 12:45:47 --> Model Class Initialized
INFO - 2023-10-28 12:45:47 --> Model Class Initialized
INFO - 2023-10-28 12:45:47 --> Model Class Initialized
INFO - 2023-10-28 12:45:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 12:45:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 12:45:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 12:45:47 --> Final output sent to browser
DEBUG - 2023-10-28 12:45:47 --> Total execution time: 0.1506
ERROR - 2023-10-28 12:45:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:45:54 --> Config Class Initialized
INFO - 2023-10-28 12:45:54 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:45:54 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:45:54 --> Utf8 Class Initialized
INFO - 2023-10-28 12:45:54 --> URI Class Initialized
INFO - 2023-10-28 12:45:54 --> Router Class Initialized
INFO - 2023-10-28 12:45:54 --> Output Class Initialized
INFO - 2023-10-28 12:45:54 --> Security Class Initialized
DEBUG - 2023-10-28 12:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:45:54 --> Input Class Initialized
INFO - 2023-10-28 12:45:54 --> Language Class Initialized
INFO - 2023-10-28 12:45:54 --> Loader Class Initialized
INFO - 2023-10-28 12:45:54 --> Helper loaded: url_helper
INFO - 2023-10-28 12:45:54 --> Helper loaded: file_helper
INFO - 2023-10-28 12:45:54 --> Helper loaded: html_helper
INFO - 2023-10-28 12:45:54 --> Helper loaded: text_helper
INFO - 2023-10-28 12:45:54 --> Helper loaded: form_helper
INFO - 2023-10-28 12:45:54 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:45:54 --> Helper loaded: security_helper
INFO - 2023-10-28 12:45:54 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:45:54 --> Database Driver Class Initialized
INFO - 2023-10-28 12:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:45:54 --> Parser Class Initialized
INFO - 2023-10-28 12:45:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:45:54 --> Pagination Class Initialized
INFO - 2023-10-28 12:45:54 --> Form Validation Class Initialized
INFO - 2023-10-28 12:45:54 --> Controller Class Initialized
INFO - 2023-10-28 12:45:54 --> Model Class Initialized
DEBUG - 2023-10-28 12:45:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:45:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:45:54 --> Model Class Initialized
DEBUG - 2023-10-28 12:45:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:45:54 --> Model Class Initialized
INFO - 2023-10-28 12:45:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-28 12:45:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:45:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 12:45:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 12:45:54 --> Model Class Initialized
INFO - 2023-10-28 12:45:54 --> Model Class Initialized
INFO - 2023-10-28 12:45:54 --> Model Class Initialized
INFO - 2023-10-28 12:45:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 12:45:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 12:45:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 12:45:54 --> Final output sent to browser
DEBUG - 2023-10-28 12:45:54 --> Total execution time: 0.1341
ERROR - 2023-10-28 12:45:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:45:55 --> Config Class Initialized
INFO - 2023-10-28 12:45:55 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:45:55 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:45:55 --> Utf8 Class Initialized
INFO - 2023-10-28 12:45:55 --> URI Class Initialized
INFO - 2023-10-28 12:45:55 --> Router Class Initialized
INFO - 2023-10-28 12:45:55 --> Output Class Initialized
INFO - 2023-10-28 12:45:55 --> Security Class Initialized
DEBUG - 2023-10-28 12:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:45:55 --> Input Class Initialized
INFO - 2023-10-28 12:45:55 --> Language Class Initialized
INFO - 2023-10-28 12:45:55 --> Loader Class Initialized
INFO - 2023-10-28 12:45:55 --> Helper loaded: url_helper
INFO - 2023-10-28 12:45:55 --> Helper loaded: file_helper
INFO - 2023-10-28 12:45:55 --> Helper loaded: html_helper
INFO - 2023-10-28 12:45:55 --> Helper loaded: text_helper
INFO - 2023-10-28 12:45:55 --> Helper loaded: form_helper
INFO - 2023-10-28 12:45:55 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:45:55 --> Helper loaded: security_helper
INFO - 2023-10-28 12:45:55 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:45:55 --> Database Driver Class Initialized
INFO - 2023-10-28 12:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:45:55 --> Parser Class Initialized
INFO - 2023-10-28 12:45:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:45:55 --> Pagination Class Initialized
INFO - 2023-10-28 12:45:55 --> Form Validation Class Initialized
INFO - 2023-10-28 12:45:55 --> Controller Class Initialized
INFO - 2023-10-28 12:45:55 --> Model Class Initialized
DEBUG - 2023-10-28 12:45:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:45:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:45:55 --> Model Class Initialized
DEBUG - 2023-10-28 12:45:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:45:55 --> Model Class Initialized
INFO - 2023-10-28 12:45:55 --> Final output sent to browser
DEBUG - 2023-10-28 12:45:55 --> Total execution time: 0.0383
ERROR - 2023-10-28 12:45:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:45:57 --> Config Class Initialized
INFO - 2023-10-28 12:45:57 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:45:57 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:45:57 --> Utf8 Class Initialized
INFO - 2023-10-28 12:45:57 --> URI Class Initialized
INFO - 2023-10-28 12:45:57 --> Router Class Initialized
INFO - 2023-10-28 12:45:57 --> Output Class Initialized
INFO - 2023-10-28 12:45:57 --> Security Class Initialized
DEBUG - 2023-10-28 12:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:45:57 --> Input Class Initialized
INFO - 2023-10-28 12:45:57 --> Language Class Initialized
INFO - 2023-10-28 12:45:57 --> Loader Class Initialized
INFO - 2023-10-28 12:45:57 --> Helper loaded: url_helper
INFO - 2023-10-28 12:45:57 --> Helper loaded: file_helper
INFO - 2023-10-28 12:45:57 --> Helper loaded: html_helper
INFO - 2023-10-28 12:45:57 --> Helper loaded: text_helper
INFO - 2023-10-28 12:45:57 --> Helper loaded: form_helper
INFO - 2023-10-28 12:45:57 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:45:57 --> Helper loaded: security_helper
INFO - 2023-10-28 12:45:57 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:45:57 --> Database Driver Class Initialized
INFO - 2023-10-28 12:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:45:57 --> Parser Class Initialized
INFO - 2023-10-28 12:45:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:45:57 --> Pagination Class Initialized
INFO - 2023-10-28 12:45:57 --> Form Validation Class Initialized
INFO - 2023-10-28 12:45:57 --> Controller Class Initialized
INFO - 2023-10-28 12:45:57 --> Model Class Initialized
DEBUG - 2023-10-28 12:45:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:45:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:45:57 --> Model Class Initialized
DEBUG - 2023-10-28 12:45:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:45:57 --> Model Class Initialized
DEBUG - 2023-10-28 12:45:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:45:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2023-10-28 12:45:58 --> Final output sent to browser
DEBUG - 2023-10-28 12:45:58 --> Total execution time: 0.2352
ERROR - 2023-10-28 12:45:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:45:58 --> Config Class Initialized
INFO - 2023-10-28 12:45:58 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:45:58 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:45:58 --> Utf8 Class Initialized
INFO - 2023-10-28 12:45:58 --> URI Class Initialized
INFO - 2023-10-28 12:45:58 --> Router Class Initialized
INFO - 2023-10-28 12:45:58 --> Output Class Initialized
INFO - 2023-10-28 12:45:58 --> Security Class Initialized
DEBUG - 2023-10-28 12:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:45:58 --> Input Class Initialized
INFO - 2023-10-28 12:45:58 --> Language Class Initialized
INFO - 2023-10-28 12:45:58 --> Loader Class Initialized
INFO - 2023-10-28 12:45:58 --> Helper loaded: url_helper
INFO - 2023-10-28 12:45:58 --> Helper loaded: file_helper
INFO - 2023-10-28 12:45:58 --> Helper loaded: html_helper
INFO - 2023-10-28 12:45:58 --> Helper loaded: text_helper
INFO - 2023-10-28 12:45:58 --> Helper loaded: form_helper
INFO - 2023-10-28 12:45:58 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:45:58 --> Helper loaded: security_helper
INFO - 2023-10-28 12:45:58 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:45:58 --> Database Driver Class Initialized
INFO - 2023-10-28 12:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:45:58 --> Parser Class Initialized
INFO - 2023-10-28 12:45:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:45:58 --> Pagination Class Initialized
INFO - 2023-10-28 12:45:58 --> Form Validation Class Initialized
INFO - 2023-10-28 12:45:58 --> Controller Class Initialized
INFO - 2023-10-28 12:45:58 --> Model Class Initialized
DEBUG - 2023-10-28 12:45:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:45:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:45:58 --> Model Class Initialized
DEBUG - 2023-10-28 12:45:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:45:58 --> Model Class Initialized
DEBUG - 2023-10-28 12:45:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:45:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:45:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2023-10-28 12:45:58 --> Final output sent to browser
DEBUG - 2023-10-28 12:45:58 --> Total execution time: 0.2295
ERROR - 2023-10-28 12:47:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:47:29 --> Config Class Initialized
INFO - 2023-10-28 12:47:29 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:47:29 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:47:29 --> Utf8 Class Initialized
INFO - 2023-10-28 12:47:29 --> URI Class Initialized
INFO - 2023-10-28 12:47:29 --> Router Class Initialized
INFO - 2023-10-28 12:47:29 --> Output Class Initialized
INFO - 2023-10-28 12:47:29 --> Security Class Initialized
DEBUG - 2023-10-28 12:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:47:29 --> Input Class Initialized
INFO - 2023-10-28 12:47:29 --> Language Class Initialized
INFO - 2023-10-28 12:47:29 --> Loader Class Initialized
INFO - 2023-10-28 12:47:29 --> Helper loaded: url_helper
INFO - 2023-10-28 12:47:29 --> Helper loaded: file_helper
INFO - 2023-10-28 12:47:29 --> Helper loaded: html_helper
INFO - 2023-10-28 12:47:29 --> Helper loaded: text_helper
INFO - 2023-10-28 12:47:29 --> Helper loaded: form_helper
INFO - 2023-10-28 12:47:29 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:47:29 --> Helper loaded: security_helper
INFO - 2023-10-28 12:47:29 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:47:29 --> Database Driver Class Initialized
INFO - 2023-10-28 12:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:47:29 --> Parser Class Initialized
INFO - 2023-10-28 12:47:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:47:29 --> Pagination Class Initialized
INFO - 2023-10-28 12:47:29 --> Form Validation Class Initialized
INFO - 2023-10-28 12:47:29 --> Controller Class Initialized
INFO - 2023-10-28 12:47:29 --> Model Class Initialized
DEBUG - 2023-10-28 12:47:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:47:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:47:29 --> Model Class Initialized
DEBUG - 2023-10-28 12:47:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:47:29 --> Model Class Initialized
INFO - 2023-10-28 12:47:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-28 12:47:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:47:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 12:47:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 12:47:29 --> Model Class Initialized
INFO - 2023-10-28 12:47:29 --> Model Class Initialized
INFO - 2023-10-28 12:47:29 --> Model Class Initialized
INFO - 2023-10-28 12:47:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 12:47:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 12:47:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 12:47:30 --> Final output sent to browser
DEBUG - 2023-10-28 12:47:30 --> Total execution time: 0.1931
ERROR - 2023-10-28 12:47:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:47:30 --> Config Class Initialized
INFO - 2023-10-28 12:47:30 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:47:30 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:47:30 --> Utf8 Class Initialized
INFO - 2023-10-28 12:47:30 --> URI Class Initialized
INFO - 2023-10-28 12:47:30 --> Router Class Initialized
INFO - 2023-10-28 12:47:30 --> Output Class Initialized
INFO - 2023-10-28 12:47:30 --> Security Class Initialized
DEBUG - 2023-10-28 12:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:47:30 --> Input Class Initialized
INFO - 2023-10-28 12:47:30 --> Language Class Initialized
INFO - 2023-10-28 12:47:30 --> Loader Class Initialized
INFO - 2023-10-28 12:47:30 --> Helper loaded: url_helper
INFO - 2023-10-28 12:47:30 --> Helper loaded: file_helper
INFO - 2023-10-28 12:47:30 --> Helper loaded: html_helper
INFO - 2023-10-28 12:47:30 --> Helper loaded: text_helper
INFO - 2023-10-28 12:47:30 --> Helper loaded: form_helper
INFO - 2023-10-28 12:47:30 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:47:30 --> Helper loaded: security_helper
INFO - 2023-10-28 12:47:30 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:47:30 --> Database Driver Class Initialized
INFO - 2023-10-28 12:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:47:30 --> Parser Class Initialized
INFO - 2023-10-28 12:47:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:47:30 --> Pagination Class Initialized
INFO - 2023-10-28 12:47:30 --> Form Validation Class Initialized
INFO - 2023-10-28 12:47:30 --> Controller Class Initialized
INFO - 2023-10-28 12:47:30 --> Model Class Initialized
DEBUG - 2023-10-28 12:47:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:47:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:47:30 --> Model Class Initialized
DEBUG - 2023-10-28 12:47:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:47:30 --> Model Class Initialized
INFO - 2023-10-28 12:47:30 --> Final output sent to browser
DEBUG - 2023-10-28 12:47:30 --> Total execution time: 0.0543
ERROR - 2023-10-28 12:47:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:47:33 --> Config Class Initialized
INFO - 2023-10-28 12:47:33 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:47:33 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:47:33 --> Utf8 Class Initialized
INFO - 2023-10-28 12:47:33 --> URI Class Initialized
INFO - 2023-10-28 12:47:33 --> Router Class Initialized
INFO - 2023-10-28 12:47:33 --> Output Class Initialized
INFO - 2023-10-28 12:47:33 --> Security Class Initialized
DEBUG - 2023-10-28 12:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:47:33 --> Input Class Initialized
INFO - 2023-10-28 12:47:33 --> Language Class Initialized
INFO - 2023-10-28 12:47:33 --> Loader Class Initialized
INFO - 2023-10-28 12:47:33 --> Helper loaded: url_helper
INFO - 2023-10-28 12:47:33 --> Helper loaded: file_helper
INFO - 2023-10-28 12:47:33 --> Helper loaded: html_helper
INFO - 2023-10-28 12:47:33 --> Helper loaded: text_helper
INFO - 2023-10-28 12:47:33 --> Helper loaded: form_helper
INFO - 2023-10-28 12:47:33 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:47:33 --> Helper loaded: security_helper
INFO - 2023-10-28 12:47:33 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:47:33 --> Database Driver Class Initialized
INFO - 2023-10-28 12:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:47:33 --> Parser Class Initialized
INFO - 2023-10-28 12:47:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:47:33 --> Pagination Class Initialized
INFO - 2023-10-28 12:47:33 --> Form Validation Class Initialized
INFO - 2023-10-28 12:47:33 --> Controller Class Initialized
INFO - 2023-10-28 12:47:33 --> Model Class Initialized
DEBUG - 2023-10-28 12:47:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:47:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:47:33 --> Model Class Initialized
DEBUG - 2023-10-28 12:47:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:47:33 --> Model Class Initialized
DEBUG - 2023-10-28 12:47:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:47:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2023-10-28 12:47:33 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2023-10-28 12:47:33 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2023-10-28 12:47:33 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-28 12:47:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2023-10-28 12:47:34 --> Final output sent to browser
DEBUG - 2023-10-28 12:47:34 --> Total execution time: 0.2318
ERROR - 2023-10-28 12:47:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 12:47:44 --> Config Class Initialized
INFO - 2023-10-28 12:47:44 --> Hooks Class Initialized
DEBUG - 2023-10-28 12:47:44 --> UTF-8 Support Enabled
INFO - 2023-10-28 12:47:44 --> Utf8 Class Initialized
INFO - 2023-10-28 12:47:44 --> URI Class Initialized
INFO - 2023-10-28 12:47:44 --> Router Class Initialized
INFO - 2023-10-28 12:47:44 --> Output Class Initialized
INFO - 2023-10-28 12:47:44 --> Security Class Initialized
DEBUG - 2023-10-28 12:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 12:47:44 --> Input Class Initialized
INFO - 2023-10-28 12:47:44 --> Language Class Initialized
INFO - 2023-10-28 12:47:44 --> Loader Class Initialized
INFO - 2023-10-28 12:47:44 --> Helper loaded: url_helper
INFO - 2023-10-28 12:47:44 --> Helper loaded: file_helper
INFO - 2023-10-28 12:47:44 --> Helper loaded: html_helper
INFO - 2023-10-28 12:47:44 --> Helper loaded: text_helper
INFO - 2023-10-28 12:47:44 --> Helper loaded: form_helper
INFO - 2023-10-28 12:47:44 --> Helper loaded: lang_helper
INFO - 2023-10-28 12:47:44 --> Helper loaded: security_helper
INFO - 2023-10-28 12:47:44 --> Helper loaded: cookie_helper
INFO - 2023-10-28 12:47:44 --> Database Driver Class Initialized
INFO - 2023-10-28 12:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 12:47:44 --> Parser Class Initialized
INFO - 2023-10-28 12:47:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 12:47:44 --> Pagination Class Initialized
INFO - 2023-10-28 12:47:44 --> Form Validation Class Initialized
INFO - 2023-10-28 12:47:44 --> Controller Class Initialized
INFO - 2023-10-28 12:47:44 --> Model Class Initialized
DEBUG - 2023-10-28 12:47:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 12:47:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:47:44 --> Model Class Initialized
DEBUG - 2023-10-28 12:47:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:47:44 --> Model Class Initialized
DEBUG - 2023-10-28 12:47:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:47:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-10-28 12:47:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 12:47:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 12:47:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 12:47:44 --> Model Class Initialized
INFO - 2023-10-28 12:47:44 --> Model Class Initialized
INFO - 2023-10-28 12:47:44 --> Model Class Initialized
INFO - 2023-10-28 12:47:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 12:47:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 12:47:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 12:47:44 --> Final output sent to browser
DEBUG - 2023-10-28 12:47:44 --> Total execution time: 0.2071
ERROR - 2023-10-28 13:19:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 13:19:40 --> Config Class Initialized
INFO - 2023-10-28 13:19:40 --> Hooks Class Initialized
DEBUG - 2023-10-28 13:19:40 --> UTF-8 Support Enabled
INFO - 2023-10-28 13:19:40 --> Utf8 Class Initialized
INFO - 2023-10-28 13:19:40 --> URI Class Initialized
DEBUG - 2023-10-28 13:19:40 --> No URI present. Default controller set.
INFO - 2023-10-28 13:19:40 --> Router Class Initialized
INFO - 2023-10-28 13:19:40 --> Output Class Initialized
INFO - 2023-10-28 13:19:40 --> Security Class Initialized
DEBUG - 2023-10-28 13:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 13:19:40 --> Input Class Initialized
INFO - 2023-10-28 13:19:40 --> Language Class Initialized
INFO - 2023-10-28 13:19:40 --> Loader Class Initialized
INFO - 2023-10-28 13:19:40 --> Helper loaded: url_helper
INFO - 2023-10-28 13:19:40 --> Helper loaded: file_helper
INFO - 2023-10-28 13:19:40 --> Helper loaded: html_helper
INFO - 2023-10-28 13:19:40 --> Helper loaded: text_helper
INFO - 2023-10-28 13:19:40 --> Helper loaded: form_helper
INFO - 2023-10-28 13:19:40 --> Helper loaded: lang_helper
INFO - 2023-10-28 13:19:40 --> Helper loaded: security_helper
INFO - 2023-10-28 13:19:40 --> Helper loaded: cookie_helper
INFO - 2023-10-28 13:19:40 --> Database Driver Class Initialized
INFO - 2023-10-28 13:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 13:19:40 --> Parser Class Initialized
INFO - 2023-10-28 13:19:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 13:19:40 --> Pagination Class Initialized
INFO - 2023-10-28 13:19:40 --> Form Validation Class Initialized
INFO - 2023-10-28 13:19:40 --> Controller Class Initialized
INFO - 2023-10-28 13:19:40 --> Model Class Initialized
DEBUG - 2023-10-28 13:19:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-28 13:19:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 13:19:40 --> Config Class Initialized
INFO - 2023-10-28 13:19:40 --> Hooks Class Initialized
DEBUG - 2023-10-28 13:19:40 --> UTF-8 Support Enabled
INFO - 2023-10-28 13:19:40 --> Utf8 Class Initialized
INFO - 2023-10-28 13:19:40 --> URI Class Initialized
INFO - 2023-10-28 13:19:40 --> Router Class Initialized
INFO - 2023-10-28 13:19:40 --> Output Class Initialized
INFO - 2023-10-28 13:19:40 --> Security Class Initialized
DEBUG - 2023-10-28 13:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 13:19:40 --> Input Class Initialized
INFO - 2023-10-28 13:19:40 --> Language Class Initialized
INFO - 2023-10-28 13:19:40 --> Loader Class Initialized
INFO - 2023-10-28 13:19:40 --> Helper loaded: url_helper
INFO - 2023-10-28 13:19:40 --> Helper loaded: file_helper
INFO - 2023-10-28 13:19:40 --> Helper loaded: html_helper
INFO - 2023-10-28 13:19:40 --> Helper loaded: text_helper
INFO - 2023-10-28 13:19:40 --> Helper loaded: form_helper
INFO - 2023-10-28 13:19:40 --> Helper loaded: lang_helper
INFO - 2023-10-28 13:19:40 --> Helper loaded: security_helper
INFO - 2023-10-28 13:19:40 --> Helper loaded: cookie_helper
INFO - 2023-10-28 13:19:40 --> Database Driver Class Initialized
INFO - 2023-10-28 13:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 13:19:40 --> Parser Class Initialized
INFO - 2023-10-28 13:19:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 13:19:40 --> Pagination Class Initialized
INFO - 2023-10-28 13:19:40 --> Form Validation Class Initialized
INFO - 2023-10-28 13:19:40 --> Controller Class Initialized
INFO - 2023-10-28 13:19:40 --> Model Class Initialized
DEBUG - 2023-10-28 13:19:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 13:19:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-28 13:19:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 13:19:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 13:19:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 13:19:40 --> Model Class Initialized
INFO - 2023-10-28 13:19:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 13:19:40 --> Final output sent to browser
DEBUG - 2023-10-28 13:19:40 --> Total execution time: 0.0349
ERROR - 2023-10-28 13:19:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 13:19:55 --> Config Class Initialized
INFO - 2023-10-28 13:19:55 --> Hooks Class Initialized
DEBUG - 2023-10-28 13:19:55 --> UTF-8 Support Enabled
INFO - 2023-10-28 13:19:55 --> Utf8 Class Initialized
INFO - 2023-10-28 13:19:55 --> URI Class Initialized
INFO - 2023-10-28 13:19:55 --> Router Class Initialized
INFO - 2023-10-28 13:19:55 --> Output Class Initialized
INFO - 2023-10-28 13:19:55 --> Security Class Initialized
DEBUG - 2023-10-28 13:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 13:19:55 --> Input Class Initialized
INFO - 2023-10-28 13:19:55 --> Language Class Initialized
INFO - 2023-10-28 13:19:55 --> Loader Class Initialized
INFO - 2023-10-28 13:19:55 --> Helper loaded: url_helper
INFO - 2023-10-28 13:19:55 --> Helper loaded: file_helper
INFO - 2023-10-28 13:19:55 --> Helper loaded: html_helper
INFO - 2023-10-28 13:19:55 --> Helper loaded: text_helper
INFO - 2023-10-28 13:19:55 --> Helper loaded: form_helper
INFO - 2023-10-28 13:19:55 --> Helper loaded: lang_helper
INFO - 2023-10-28 13:19:55 --> Helper loaded: security_helper
INFO - 2023-10-28 13:19:55 --> Helper loaded: cookie_helper
INFO - 2023-10-28 13:19:55 --> Database Driver Class Initialized
INFO - 2023-10-28 13:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 13:19:55 --> Parser Class Initialized
INFO - 2023-10-28 13:19:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 13:19:55 --> Pagination Class Initialized
INFO - 2023-10-28 13:19:55 --> Form Validation Class Initialized
INFO - 2023-10-28 13:19:55 --> Controller Class Initialized
INFO - 2023-10-28 13:19:55 --> Model Class Initialized
DEBUG - 2023-10-28 13:19:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 13:19:55 --> Model Class Initialized
INFO - 2023-10-28 13:19:55 --> Final output sent to browser
DEBUG - 2023-10-28 13:19:55 --> Total execution time: 0.0194
ERROR - 2023-10-28 13:19:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 13:19:55 --> Config Class Initialized
INFO - 2023-10-28 13:19:55 --> Hooks Class Initialized
DEBUG - 2023-10-28 13:19:55 --> UTF-8 Support Enabled
INFO - 2023-10-28 13:19:55 --> Utf8 Class Initialized
INFO - 2023-10-28 13:19:55 --> URI Class Initialized
DEBUG - 2023-10-28 13:19:55 --> No URI present. Default controller set.
INFO - 2023-10-28 13:19:55 --> Router Class Initialized
INFO - 2023-10-28 13:19:55 --> Output Class Initialized
INFO - 2023-10-28 13:19:55 --> Security Class Initialized
DEBUG - 2023-10-28 13:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 13:19:55 --> Input Class Initialized
INFO - 2023-10-28 13:19:55 --> Language Class Initialized
INFO - 2023-10-28 13:19:55 --> Loader Class Initialized
INFO - 2023-10-28 13:19:55 --> Helper loaded: url_helper
INFO - 2023-10-28 13:19:55 --> Helper loaded: file_helper
INFO - 2023-10-28 13:19:55 --> Helper loaded: html_helper
INFO - 2023-10-28 13:19:55 --> Helper loaded: text_helper
INFO - 2023-10-28 13:19:55 --> Helper loaded: form_helper
INFO - 2023-10-28 13:19:55 --> Helper loaded: lang_helper
INFO - 2023-10-28 13:19:55 --> Helper loaded: security_helper
INFO - 2023-10-28 13:19:55 --> Helper loaded: cookie_helper
INFO - 2023-10-28 13:19:55 --> Database Driver Class Initialized
INFO - 2023-10-28 13:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 13:19:55 --> Parser Class Initialized
INFO - 2023-10-28 13:19:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 13:19:55 --> Pagination Class Initialized
INFO - 2023-10-28 13:19:55 --> Form Validation Class Initialized
INFO - 2023-10-28 13:19:55 --> Controller Class Initialized
INFO - 2023-10-28 13:19:55 --> Model Class Initialized
DEBUG - 2023-10-28 13:19:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 13:19:55 --> Model Class Initialized
DEBUG - 2023-10-28 13:19:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 13:19:55 --> Model Class Initialized
INFO - 2023-10-28 13:19:55 --> Model Class Initialized
INFO - 2023-10-28 13:19:55 --> Model Class Initialized
INFO - 2023-10-28 13:19:55 --> Model Class Initialized
DEBUG - 2023-10-28 13:19:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 13:19:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 13:19:55 --> Model Class Initialized
INFO - 2023-10-28 13:19:55 --> Model Class Initialized
INFO - 2023-10-28 13:19:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-28 13:19:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 13:19:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 13:19:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 13:19:55 --> Model Class Initialized
INFO - 2023-10-28 13:19:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 13:19:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 13:19:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 13:19:55 --> Final output sent to browser
DEBUG - 2023-10-28 13:19:55 --> Total execution time: 0.1986
ERROR - 2023-10-28 13:36:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 13:36:46 --> Config Class Initialized
INFO - 2023-10-28 13:36:46 --> Hooks Class Initialized
DEBUG - 2023-10-28 13:36:46 --> UTF-8 Support Enabled
INFO - 2023-10-28 13:36:46 --> Utf8 Class Initialized
INFO - 2023-10-28 13:36:46 --> URI Class Initialized
DEBUG - 2023-10-28 13:36:46 --> No URI present. Default controller set.
INFO - 2023-10-28 13:36:46 --> Router Class Initialized
INFO - 2023-10-28 13:36:46 --> Output Class Initialized
INFO - 2023-10-28 13:36:46 --> Security Class Initialized
DEBUG - 2023-10-28 13:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 13:36:46 --> Input Class Initialized
INFO - 2023-10-28 13:36:46 --> Language Class Initialized
INFO - 2023-10-28 13:36:46 --> Loader Class Initialized
INFO - 2023-10-28 13:36:46 --> Helper loaded: url_helper
INFO - 2023-10-28 13:36:46 --> Helper loaded: file_helper
INFO - 2023-10-28 13:36:46 --> Helper loaded: html_helper
INFO - 2023-10-28 13:36:46 --> Helper loaded: text_helper
INFO - 2023-10-28 13:36:46 --> Helper loaded: form_helper
INFO - 2023-10-28 13:36:46 --> Helper loaded: lang_helper
INFO - 2023-10-28 13:36:46 --> Helper loaded: security_helper
INFO - 2023-10-28 13:36:46 --> Helper loaded: cookie_helper
INFO - 2023-10-28 13:36:46 --> Database Driver Class Initialized
INFO - 2023-10-28 13:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 13:36:46 --> Parser Class Initialized
INFO - 2023-10-28 13:36:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 13:36:46 --> Pagination Class Initialized
INFO - 2023-10-28 13:36:46 --> Form Validation Class Initialized
INFO - 2023-10-28 13:36:46 --> Controller Class Initialized
INFO - 2023-10-28 13:36:46 --> Model Class Initialized
DEBUG - 2023-10-28 13:36:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-28 13:36:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 13:36:52 --> Config Class Initialized
INFO - 2023-10-28 13:36:52 --> Hooks Class Initialized
DEBUG - 2023-10-28 13:36:52 --> UTF-8 Support Enabled
INFO - 2023-10-28 13:36:52 --> Utf8 Class Initialized
INFO - 2023-10-28 13:36:52 --> URI Class Initialized
DEBUG - 2023-10-28 13:36:52 --> No URI present. Default controller set.
INFO - 2023-10-28 13:36:52 --> Router Class Initialized
INFO - 2023-10-28 13:36:52 --> Output Class Initialized
INFO - 2023-10-28 13:36:52 --> Security Class Initialized
DEBUG - 2023-10-28 13:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 13:36:52 --> Input Class Initialized
INFO - 2023-10-28 13:36:52 --> Language Class Initialized
INFO - 2023-10-28 13:36:52 --> Loader Class Initialized
INFO - 2023-10-28 13:36:52 --> Helper loaded: url_helper
INFO - 2023-10-28 13:36:52 --> Helper loaded: file_helper
INFO - 2023-10-28 13:36:52 --> Helper loaded: html_helper
INFO - 2023-10-28 13:36:52 --> Helper loaded: text_helper
INFO - 2023-10-28 13:36:52 --> Helper loaded: form_helper
INFO - 2023-10-28 13:36:52 --> Helper loaded: lang_helper
INFO - 2023-10-28 13:36:52 --> Helper loaded: security_helper
INFO - 2023-10-28 13:36:52 --> Helper loaded: cookie_helper
INFO - 2023-10-28 13:36:52 --> Database Driver Class Initialized
INFO - 2023-10-28 13:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 13:36:52 --> Parser Class Initialized
INFO - 2023-10-28 13:36:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 13:36:52 --> Pagination Class Initialized
INFO - 2023-10-28 13:36:52 --> Form Validation Class Initialized
INFO - 2023-10-28 13:36:52 --> Controller Class Initialized
INFO - 2023-10-28 13:36:52 --> Model Class Initialized
DEBUG - 2023-10-28 13:36:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-28 13:36:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 13:36:53 --> Config Class Initialized
INFO - 2023-10-28 13:36:53 --> Hooks Class Initialized
DEBUG - 2023-10-28 13:36:53 --> UTF-8 Support Enabled
INFO - 2023-10-28 13:36:53 --> Utf8 Class Initialized
INFO - 2023-10-28 13:36:53 --> URI Class Initialized
DEBUG - 2023-10-28 13:36:53 --> No URI present. Default controller set.
INFO - 2023-10-28 13:36:53 --> Router Class Initialized
INFO - 2023-10-28 13:36:53 --> Output Class Initialized
INFO - 2023-10-28 13:36:53 --> Security Class Initialized
DEBUG - 2023-10-28 13:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 13:36:53 --> Input Class Initialized
INFO - 2023-10-28 13:36:53 --> Language Class Initialized
INFO - 2023-10-28 13:36:53 --> Loader Class Initialized
INFO - 2023-10-28 13:36:53 --> Helper loaded: url_helper
INFO - 2023-10-28 13:36:53 --> Helper loaded: file_helper
INFO - 2023-10-28 13:36:53 --> Helper loaded: html_helper
INFO - 2023-10-28 13:36:53 --> Helper loaded: text_helper
INFO - 2023-10-28 13:36:53 --> Helper loaded: form_helper
INFO - 2023-10-28 13:36:53 --> Helper loaded: lang_helper
INFO - 2023-10-28 13:36:53 --> Helper loaded: security_helper
INFO - 2023-10-28 13:36:53 --> Helper loaded: cookie_helper
INFO - 2023-10-28 13:36:53 --> Database Driver Class Initialized
INFO - 2023-10-28 13:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 13:36:53 --> Parser Class Initialized
INFO - 2023-10-28 13:36:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 13:36:53 --> Pagination Class Initialized
INFO - 2023-10-28 13:36:53 --> Form Validation Class Initialized
INFO - 2023-10-28 13:36:53 --> Controller Class Initialized
INFO - 2023-10-28 13:36:53 --> Model Class Initialized
DEBUG - 2023-10-28 13:36:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-28 13:36:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 13:36:53 --> Config Class Initialized
INFO - 2023-10-28 13:36:53 --> Hooks Class Initialized
DEBUG - 2023-10-28 13:36:53 --> UTF-8 Support Enabled
INFO - 2023-10-28 13:36:53 --> Utf8 Class Initialized
INFO - 2023-10-28 13:36:53 --> URI Class Initialized
DEBUG - 2023-10-28 13:36:53 --> No URI present. Default controller set.
INFO - 2023-10-28 13:36:53 --> Router Class Initialized
INFO - 2023-10-28 13:36:53 --> Output Class Initialized
INFO - 2023-10-28 13:36:53 --> Security Class Initialized
DEBUG - 2023-10-28 13:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 13:36:53 --> Input Class Initialized
INFO - 2023-10-28 13:36:53 --> Language Class Initialized
INFO - 2023-10-28 13:36:53 --> Loader Class Initialized
INFO - 2023-10-28 13:36:53 --> Helper loaded: url_helper
INFO - 2023-10-28 13:36:53 --> Helper loaded: file_helper
INFO - 2023-10-28 13:36:53 --> Helper loaded: html_helper
INFO - 2023-10-28 13:36:53 --> Helper loaded: text_helper
INFO - 2023-10-28 13:36:53 --> Helper loaded: form_helper
INFO - 2023-10-28 13:36:53 --> Helper loaded: lang_helper
INFO - 2023-10-28 13:36:53 --> Helper loaded: security_helper
INFO - 2023-10-28 13:36:53 --> Helper loaded: cookie_helper
INFO - 2023-10-28 13:36:53 --> Database Driver Class Initialized
INFO - 2023-10-28 13:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 13:36:53 --> Parser Class Initialized
INFO - 2023-10-28 13:36:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 13:36:53 --> Pagination Class Initialized
INFO - 2023-10-28 13:36:53 --> Form Validation Class Initialized
INFO - 2023-10-28 13:36:53 --> Controller Class Initialized
INFO - 2023-10-28 13:36:53 --> Model Class Initialized
DEBUG - 2023-10-28 13:36:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-28 13:40:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 13:40:02 --> Config Class Initialized
INFO - 2023-10-28 13:40:02 --> Hooks Class Initialized
DEBUG - 2023-10-28 13:40:02 --> UTF-8 Support Enabled
INFO - 2023-10-28 13:40:02 --> Utf8 Class Initialized
INFO - 2023-10-28 13:40:02 --> URI Class Initialized
DEBUG - 2023-10-28 13:40:02 --> No URI present. Default controller set.
INFO - 2023-10-28 13:40:02 --> Router Class Initialized
INFO - 2023-10-28 13:40:02 --> Output Class Initialized
INFO - 2023-10-28 13:40:02 --> Security Class Initialized
DEBUG - 2023-10-28 13:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 13:40:02 --> Input Class Initialized
INFO - 2023-10-28 13:40:02 --> Language Class Initialized
INFO - 2023-10-28 13:40:02 --> Loader Class Initialized
INFO - 2023-10-28 13:40:02 --> Helper loaded: url_helper
INFO - 2023-10-28 13:40:02 --> Helper loaded: file_helper
INFO - 2023-10-28 13:40:02 --> Helper loaded: html_helper
INFO - 2023-10-28 13:40:02 --> Helper loaded: text_helper
INFO - 2023-10-28 13:40:02 --> Helper loaded: form_helper
INFO - 2023-10-28 13:40:02 --> Helper loaded: lang_helper
INFO - 2023-10-28 13:40:02 --> Helper loaded: security_helper
INFO - 2023-10-28 13:40:02 --> Helper loaded: cookie_helper
INFO - 2023-10-28 13:40:02 --> Database Driver Class Initialized
INFO - 2023-10-28 13:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 13:40:02 --> Parser Class Initialized
INFO - 2023-10-28 13:40:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 13:40:02 --> Pagination Class Initialized
INFO - 2023-10-28 13:40:02 --> Form Validation Class Initialized
INFO - 2023-10-28 13:40:02 --> Controller Class Initialized
INFO - 2023-10-28 13:40:02 --> Model Class Initialized
DEBUG - 2023-10-28 13:40:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-28 13:40:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 13:40:03 --> Config Class Initialized
INFO - 2023-10-28 13:40:03 --> Hooks Class Initialized
DEBUG - 2023-10-28 13:40:03 --> UTF-8 Support Enabled
INFO - 2023-10-28 13:40:03 --> Utf8 Class Initialized
INFO - 2023-10-28 13:40:03 --> URI Class Initialized
INFO - 2023-10-28 13:40:03 --> Router Class Initialized
INFO - 2023-10-28 13:40:03 --> Output Class Initialized
INFO - 2023-10-28 13:40:03 --> Security Class Initialized
DEBUG - 2023-10-28 13:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 13:40:03 --> Input Class Initialized
INFO - 2023-10-28 13:40:03 --> Language Class Initialized
INFO - 2023-10-28 13:40:03 --> Loader Class Initialized
INFO - 2023-10-28 13:40:03 --> Helper loaded: url_helper
INFO - 2023-10-28 13:40:03 --> Helper loaded: file_helper
INFO - 2023-10-28 13:40:03 --> Helper loaded: html_helper
INFO - 2023-10-28 13:40:03 --> Helper loaded: text_helper
INFO - 2023-10-28 13:40:03 --> Helper loaded: form_helper
INFO - 2023-10-28 13:40:03 --> Helper loaded: lang_helper
INFO - 2023-10-28 13:40:03 --> Helper loaded: security_helper
INFO - 2023-10-28 13:40:03 --> Helper loaded: cookie_helper
INFO - 2023-10-28 13:40:03 --> Database Driver Class Initialized
INFO - 2023-10-28 13:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 13:40:03 --> Parser Class Initialized
INFO - 2023-10-28 13:40:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 13:40:03 --> Pagination Class Initialized
INFO - 2023-10-28 13:40:03 --> Form Validation Class Initialized
INFO - 2023-10-28 13:40:03 --> Controller Class Initialized
INFO - 2023-10-28 13:40:03 --> Model Class Initialized
DEBUG - 2023-10-28 13:40:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 13:40:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-28 13:40:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 13:40:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 13:40:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 13:40:03 --> Model Class Initialized
INFO - 2023-10-28 13:40:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 13:40:03 --> Final output sent to browser
DEBUG - 2023-10-28 13:40:03 --> Total execution time: 0.0322
ERROR - 2023-10-28 13:41:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 13:41:31 --> Config Class Initialized
INFO - 2023-10-28 13:41:31 --> Hooks Class Initialized
DEBUG - 2023-10-28 13:41:31 --> UTF-8 Support Enabled
INFO - 2023-10-28 13:41:31 --> Utf8 Class Initialized
INFO - 2023-10-28 13:41:31 --> URI Class Initialized
INFO - 2023-10-28 13:41:31 --> Router Class Initialized
INFO - 2023-10-28 13:41:31 --> Output Class Initialized
INFO - 2023-10-28 13:41:31 --> Security Class Initialized
DEBUG - 2023-10-28 13:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 13:41:31 --> Input Class Initialized
INFO - 2023-10-28 13:41:31 --> Language Class Initialized
INFO - 2023-10-28 13:41:31 --> Loader Class Initialized
INFO - 2023-10-28 13:41:31 --> Helper loaded: url_helper
INFO - 2023-10-28 13:41:31 --> Helper loaded: file_helper
INFO - 2023-10-28 13:41:31 --> Helper loaded: html_helper
INFO - 2023-10-28 13:41:31 --> Helper loaded: text_helper
INFO - 2023-10-28 13:41:31 --> Helper loaded: form_helper
INFO - 2023-10-28 13:41:31 --> Helper loaded: lang_helper
INFO - 2023-10-28 13:41:31 --> Helper loaded: security_helper
INFO - 2023-10-28 13:41:31 --> Helper loaded: cookie_helper
INFO - 2023-10-28 13:41:31 --> Database Driver Class Initialized
INFO - 2023-10-28 13:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 13:41:31 --> Parser Class Initialized
INFO - 2023-10-28 13:41:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 13:41:31 --> Pagination Class Initialized
INFO - 2023-10-28 13:41:31 --> Form Validation Class Initialized
INFO - 2023-10-28 13:41:31 --> Controller Class Initialized
INFO - 2023-10-28 13:41:31 --> Model Class Initialized
DEBUG - 2023-10-28 13:41:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 13:41:31 --> Model Class Initialized
INFO - 2023-10-28 13:41:31 --> Final output sent to browser
DEBUG - 2023-10-28 13:41:31 --> Total execution time: 0.0205
ERROR - 2023-10-28 13:41:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 13:41:32 --> Config Class Initialized
INFO - 2023-10-28 13:41:32 --> Hooks Class Initialized
DEBUG - 2023-10-28 13:41:32 --> UTF-8 Support Enabled
INFO - 2023-10-28 13:41:32 --> Utf8 Class Initialized
INFO - 2023-10-28 13:41:32 --> URI Class Initialized
DEBUG - 2023-10-28 13:41:32 --> No URI present. Default controller set.
INFO - 2023-10-28 13:41:32 --> Router Class Initialized
INFO - 2023-10-28 13:41:32 --> Output Class Initialized
INFO - 2023-10-28 13:41:32 --> Security Class Initialized
DEBUG - 2023-10-28 13:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 13:41:32 --> Input Class Initialized
INFO - 2023-10-28 13:41:32 --> Language Class Initialized
INFO - 2023-10-28 13:41:32 --> Loader Class Initialized
INFO - 2023-10-28 13:41:32 --> Helper loaded: url_helper
INFO - 2023-10-28 13:41:32 --> Helper loaded: file_helper
INFO - 2023-10-28 13:41:32 --> Helper loaded: html_helper
INFO - 2023-10-28 13:41:32 --> Helper loaded: text_helper
INFO - 2023-10-28 13:41:32 --> Helper loaded: form_helper
INFO - 2023-10-28 13:41:32 --> Helper loaded: lang_helper
INFO - 2023-10-28 13:41:32 --> Helper loaded: security_helper
INFO - 2023-10-28 13:41:32 --> Helper loaded: cookie_helper
INFO - 2023-10-28 13:41:32 --> Database Driver Class Initialized
INFO - 2023-10-28 13:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 13:41:32 --> Parser Class Initialized
INFO - 2023-10-28 13:41:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 13:41:32 --> Pagination Class Initialized
INFO - 2023-10-28 13:41:32 --> Form Validation Class Initialized
INFO - 2023-10-28 13:41:32 --> Controller Class Initialized
INFO - 2023-10-28 13:41:32 --> Model Class Initialized
DEBUG - 2023-10-28 13:41:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 13:41:32 --> Model Class Initialized
DEBUG - 2023-10-28 13:41:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 13:41:32 --> Model Class Initialized
INFO - 2023-10-28 13:41:32 --> Model Class Initialized
INFO - 2023-10-28 13:41:32 --> Model Class Initialized
INFO - 2023-10-28 13:41:32 --> Model Class Initialized
DEBUG - 2023-10-28 13:41:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 13:41:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 13:41:32 --> Model Class Initialized
INFO - 2023-10-28 13:41:32 --> Model Class Initialized
INFO - 2023-10-28 13:41:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-28 13:41:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 13:41:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 13:41:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 13:41:32 --> Model Class Initialized
INFO - 2023-10-28 13:41:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 13:41:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 13:41:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 13:41:33 --> Final output sent to browser
DEBUG - 2023-10-28 13:41:33 --> Total execution time: 0.1899
ERROR - 2023-10-28 13:41:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 13:41:52 --> Config Class Initialized
INFO - 2023-10-28 13:41:52 --> Hooks Class Initialized
DEBUG - 2023-10-28 13:41:52 --> UTF-8 Support Enabled
INFO - 2023-10-28 13:41:52 --> Utf8 Class Initialized
INFO - 2023-10-28 13:41:52 --> URI Class Initialized
INFO - 2023-10-28 13:41:52 --> Router Class Initialized
INFO - 2023-10-28 13:41:52 --> Output Class Initialized
INFO - 2023-10-28 13:41:52 --> Security Class Initialized
DEBUG - 2023-10-28 13:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 13:41:52 --> Input Class Initialized
INFO - 2023-10-28 13:41:52 --> Language Class Initialized
INFO - 2023-10-28 13:41:52 --> Loader Class Initialized
INFO - 2023-10-28 13:41:52 --> Helper loaded: url_helper
INFO - 2023-10-28 13:41:52 --> Helper loaded: file_helper
INFO - 2023-10-28 13:41:52 --> Helper loaded: html_helper
INFO - 2023-10-28 13:41:52 --> Helper loaded: text_helper
INFO - 2023-10-28 13:41:52 --> Helper loaded: form_helper
INFO - 2023-10-28 13:41:52 --> Helper loaded: lang_helper
INFO - 2023-10-28 13:41:52 --> Helper loaded: security_helper
INFO - 2023-10-28 13:41:52 --> Helper loaded: cookie_helper
INFO - 2023-10-28 13:41:52 --> Database Driver Class Initialized
INFO - 2023-10-28 13:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 13:41:52 --> Parser Class Initialized
INFO - 2023-10-28 13:41:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 13:41:52 --> Pagination Class Initialized
INFO - 2023-10-28 13:41:52 --> Form Validation Class Initialized
INFO - 2023-10-28 13:41:52 --> Controller Class Initialized
INFO - 2023-10-28 13:41:52 --> Model Class Initialized
DEBUG - 2023-10-28 13:41:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 13:41:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 13:41:52 --> Model Class Initialized
DEBUG - 2023-10-28 13:41:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 13:41:52 --> Model Class Initialized
INFO - 2023-10-28 13:41:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-28 13:41:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 13:41:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 13:41:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 13:41:52 --> Model Class Initialized
INFO - 2023-10-28 13:41:52 --> Model Class Initialized
INFO - 2023-10-28 13:41:52 --> Model Class Initialized
INFO - 2023-10-28 13:41:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 13:41:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 13:41:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 13:41:52 --> Final output sent to browser
DEBUG - 2023-10-28 13:41:52 --> Total execution time: 0.1288
ERROR - 2023-10-28 13:41:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 13:41:54 --> Config Class Initialized
INFO - 2023-10-28 13:41:54 --> Hooks Class Initialized
DEBUG - 2023-10-28 13:41:54 --> UTF-8 Support Enabled
INFO - 2023-10-28 13:41:54 --> Utf8 Class Initialized
INFO - 2023-10-28 13:41:54 --> URI Class Initialized
INFO - 2023-10-28 13:41:54 --> Router Class Initialized
INFO - 2023-10-28 13:41:54 --> Output Class Initialized
INFO - 2023-10-28 13:41:54 --> Security Class Initialized
DEBUG - 2023-10-28 13:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 13:41:54 --> Input Class Initialized
INFO - 2023-10-28 13:41:54 --> Language Class Initialized
INFO - 2023-10-28 13:41:54 --> Loader Class Initialized
INFO - 2023-10-28 13:41:54 --> Helper loaded: url_helper
INFO - 2023-10-28 13:41:54 --> Helper loaded: file_helper
INFO - 2023-10-28 13:41:54 --> Helper loaded: html_helper
INFO - 2023-10-28 13:41:54 --> Helper loaded: text_helper
INFO - 2023-10-28 13:41:54 --> Helper loaded: form_helper
INFO - 2023-10-28 13:41:54 --> Helper loaded: lang_helper
INFO - 2023-10-28 13:41:54 --> Helper loaded: security_helper
INFO - 2023-10-28 13:41:54 --> Helper loaded: cookie_helper
INFO - 2023-10-28 13:41:54 --> Database Driver Class Initialized
INFO - 2023-10-28 13:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 13:41:54 --> Parser Class Initialized
INFO - 2023-10-28 13:41:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 13:41:54 --> Pagination Class Initialized
INFO - 2023-10-28 13:41:54 --> Form Validation Class Initialized
INFO - 2023-10-28 13:41:54 --> Controller Class Initialized
INFO - 2023-10-28 13:41:54 --> Model Class Initialized
DEBUG - 2023-10-28 13:41:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 13:41:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 13:41:54 --> Model Class Initialized
DEBUG - 2023-10-28 13:41:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 13:41:54 --> Model Class Initialized
INFO - 2023-10-28 13:41:54 --> Final output sent to browser
DEBUG - 2023-10-28 13:41:54 --> Total execution time: 0.0246
ERROR - 2023-10-28 13:42:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 13:42:53 --> Config Class Initialized
INFO - 2023-10-28 13:42:53 --> Hooks Class Initialized
DEBUG - 2023-10-28 13:42:53 --> UTF-8 Support Enabled
INFO - 2023-10-28 13:42:53 --> Utf8 Class Initialized
INFO - 2023-10-28 13:42:53 --> URI Class Initialized
INFO - 2023-10-28 13:42:53 --> Router Class Initialized
INFO - 2023-10-28 13:42:53 --> Output Class Initialized
INFO - 2023-10-28 13:42:53 --> Security Class Initialized
DEBUG - 2023-10-28 13:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 13:42:53 --> Input Class Initialized
INFO - 2023-10-28 13:42:53 --> Language Class Initialized
INFO - 2023-10-28 13:42:53 --> Loader Class Initialized
INFO - 2023-10-28 13:42:53 --> Helper loaded: url_helper
INFO - 2023-10-28 13:42:53 --> Helper loaded: file_helper
INFO - 2023-10-28 13:42:53 --> Helper loaded: html_helper
INFO - 2023-10-28 13:42:53 --> Helper loaded: text_helper
INFO - 2023-10-28 13:42:53 --> Helper loaded: form_helper
INFO - 2023-10-28 13:42:53 --> Helper loaded: lang_helper
INFO - 2023-10-28 13:42:53 --> Helper loaded: security_helper
INFO - 2023-10-28 13:42:53 --> Helper loaded: cookie_helper
INFO - 2023-10-28 13:42:53 --> Database Driver Class Initialized
INFO - 2023-10-28 13:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 13:42:53 --> Parser Class Initialized
INFO - 2023-10-28 13:42:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 13:42:53 --> Pagination Class Initialized
INFO - 2023-10-28 13:42:53 --> Form Validation Class Initialized
INFO - 2023-10-28 13:42:53 --> Controller Class Initialized
INFO - 2023-10-28 13:42:53 --> Model Class Initialized
DEBUG - 2023-10-28 13:42:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 13:42:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 13:42:53 --> Model Class Initialized
DEBUG - 2023-10-28 13:42:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 13:42:53 --> Model Class Initialized
DEBUG - 2023-10-28 13:42:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 13:42:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-10-28 13:42:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 13:42:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 13:42:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 13:42:53 --> Model Class Initialized
INFO - 2023-10-28 13:42:53 --> Model Class Initialized
INFO - 2023-10-28 13:42:53 --> Model Class Initialized
INFO - 2023-10-28 13:42:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 13:42:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 13:42:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 13:42:54 --> Final output sent to browser
DEBUG - 2023-10-28 13:42:54 --> Total execution time: 0.1316
ERROR - 2023-10-28 13:42:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 13:42:55 --> Config Class Initialized
INFO - 2023-10-28 13:42:55 --> Hooks Class Initialized
DEBUG - 2023-10-28 13:42:55 --> UTF-8 Support Enabled
INFO - 2023-10-28 13:42:55 --> Utf8 Class Initialized
INFO - 2023-10-28 13:42:55 --> URI Class Initialized
INFO - 2023-10-28 13:42:55 --> Router Class Initialized
INFO - 2023-10-28 13:42:55 --> Output Class Initialized
INFO - 2023-10-28 13:42:55 --> Security Class Initialized
DEBUG - 2023-10-28 13:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 13:42:55 --> Input Class Initialized
INFO - 2023-10-28 13:42:55 --> Language Class Initialized
INFO - 2023-10-28 13:42:55 --> Loader Class Initialized
INFO - 2023-10-28 13:42:55 --> Helper loaded: url_helper
INFO - 2023-10-28 13:42:55 --> Helper loaded: file_helper
INFO - 2023-10-28 13:42:55 --> Helper loaded: html_helper
INFO - 2023-10-28 13:42:55 --> Helper loaded: text_helper
INFO - 2023-10-28 13:42:55 --> Helper loaded: form_helper
INFO - 2023-10-28 13:42:55 --> Helper loaded: lang_helper
INFO - 2023-10-28 13:42:55 --> Helper loaded: security_helper
INFO - 2023-10-28 13:42:55 --> Helper loaded: cookie_helper
INFO - 2023-10-28 13:42:55 --> Database Driver Class Initialized
INFO - 2023-10-28 13:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 13:42:55 --> Parser Class Initialized
INFO - 2023-10-28 13:42:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 13:42:55 --> Pagination Class Initialized
INFO - 2023-10-28 13:42:55 --> Form Validation Class Initialized
INFO - 2023-10-28 13:42:55 --> Controller Class Initialized
INFO - 2023-10-28 13:42:55 --> Model Class Initialized
DEBUG - 2023-10-28 13:42:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 13:42:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 13:42:55 --> Model Class Initialized
DEBUG - 2023-10-28 13:42:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 13:42:55 --> Model Class Initialized
DEBUG - 2023-10-28 13:42:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 13:42:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-10-28 13:42:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 13:42:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 13:42:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 13:42:55 --> Model Class Initialized
INFO - 2023-10-28 13:42:55 --> Model Class Initialized
INFO - 2023-10-28 13:42:55 --> Model Class Initialized
INFO - 2023-10-28 13:42:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 13:42:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 13:42:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 13:42:55 --> Final output sent to browser
DEBUG - 2023-10-28 13:42:55 --> Total execution time: 0.1364
ERROR - 2023-10-28 13:49:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 13:49:30 --> Config Class Initialized
INFO - 2023-10-28 13:49:30 --> Hooks Class Initialized
DEBUG - 2023-10-28 13:49:30 --> UTF-8 Support Enabled
INFO - 2023-10-28 13:49:30 --> Utf8 Class Initialized
INFO - 2023-10-28 13:49:30 --> URI Class Initialized
DEBUG - 2023-10-28 13:49:30 --> No URI present. Default controller set.
INFO - 2023-10-28 13:49:30 --> Router Class Initialized
INFO - 2023-10-28 13:49:30 --> Output Class Initialized
INFO - 2023-10-28 13:49:30 --> Security Class Initialized
DEBUG - 2023-10-28 13:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 13:49:30 --> Input Class Initialized
INFO - 2023-10-28 13:49:30 --> Language Class Initialized
INFO - 2023-10-28 13:49:30 --> Loader Class Initialized
INFO - 2023-10-28 13:49:30 --> Helper loaded: url_helper
INFO - 2023-10-28 13:49:30 --> Helper loaded: file_helper
INFO - 2023-10-28 13:49:30 --> Helper loaded: html_helper
INFO - 2023-10-28 13:49:30 --> Helper loaded: text_helper
INFO - 2023-10-28 13:49:30 --> Helper loaded: form_helper
INFO - 2023-10-28 13:49:30 --> Helper loaded: lang_helper
INFO - 2023-10-28 13:49:30 --> Helper loaded: security_helper
INFO - 2023-10-28 13:49:30 --> Helper loaded: cookie_helper
INFO - 2023-10-28 13:49:30 --> Database Driver Class Initialized
INFO - 2023-10-28 13:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 13:49:30 --> Parser Class Initialized
INFO - 2023-10-28 13:49:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 13:49:30 --> Pagination Class Initialized
INFO - 2023-10-28 13:49:30 --> Form Validation Class Initialized
INFO - 2023-10-28 13:49:30 --> Controller Class Initialized
INFO - 2023-10-28 13:49:30 --> Model Class Initialized
DEBUG - 2023-10-28 13:49:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 13:49:30 --> Model Class Initialized
DEBUG - 2023-10-28 13:49:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 13:49:30 --> Model Class Initialized
INFO - 2023-10-28 13:49:30 --> Model Class Initialized
INFO - 2023-10-28 13:49:30 --> Model Class Initialized
INFO - 2023-10-28 13:49:30 --> Model Class Initialized
DEBUG - 2023-10-28 13:49:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 13:49:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 13:49:30 --> Model Class Initialized
INFO - 2023-10-28 13:49:30 --> Model Class Initialized
INFO - 2023-10-28 13:49:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-28 13:49:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 13:49:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 13:49:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 13:49:30 --> Model Class Initialized
INFO - 2023-10-28 13:49:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 13:49:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 13:49:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 13:49:30 --> Final output sent to browser
DEBUG - 2023-10-28 13:49:30 --> Total execution time: 0.1920
ERROR - 2023-10-28 13:49:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 13:49:38 --> Config Class Initialized
INFO - 2023-10-28 13:49:38 --> Hooks Class Initialized
DEBUG - 2023-10-28 13:49:38 --> UTF-8 Support Enabled
INFO - 2023-10-28 13:49:38 --> Utf8 Class Initialized
INFO - 2023-10-28 13:49:38 --> URI Class Initialized
INFO - 2023-10-28 13:49:38 --> Router Class Initialized
INFO - 2023-10-28 13:49:38 --> Output Class Initialized
INFO - 2023-10-28 13:49:38 --> Security Class Initialized
DEBUG - 2023-10-28 13:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 13:49:38 --> Input Class Initialized
INFO - 2023-10-28 13:49:38 --> Language Class Initialized
INFO - 2023-10-28 13:49:38 --> Loader Class Initialized
INFO - 2023-10-28 13:49:38 --> Helper loaded: url_helper
INFO - 2023-10-28 13:49:38 --> Helper loaded: file_helper
INFO - 2023-10-28 13:49:38 --> Helper loaded: html_helper
INFO - 2023-10-28 13:49:38 --> Helper loaded: text_helper
INFO - 2023-10-28 13:49:38 --> Helper loaded: form_helper
INFO - 2023-10-28 13:49:38 --> Helper loaded: lang_helper
INFO - 2023-10-28 13:49:38 --> Helper loaded: security_helper
INFO - 2023-10-28 13:49:38 --> Helper loaded: cookie_helper
INFO - 2023-10-28 13:49:38 --> Database Driver Class Initialized
INFO - 2023-10-28 13:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 13:49:38 --> Parser Class Initialized
INFO - 2023-10-28 13:49:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 13:49:38 --> Pagination Class Initialized
INFO - 2023-10-28 13:49:38 --> Form Validation Class Initialized
INFO - 2023-10-28 13:49:38 --> Controller Class Initialized
INFO - 2023-10-28 13:49:38 --> Model Class Initialized
DEBUG - 2023-10-28 13:49:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 13:49:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 13:49:38 --> Model Class Initialized
DEBUG - 2023-10-28 13:49:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 13:49:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-10-28 13:49:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 13:49:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 13:49:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 13:49:38 --> Model Class Initialized
INFO - 2023-10-28 13:49:38 --> Model Class Initialized
INFO - 2023-10-28 13:49:38 --> Model Class Initialized
INFO - 2023-10-28 13:49:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 13:49:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 13:49:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 13:49:38 --> Final output sent to browser
DEBUG - 2023-10-28 13:49:38 --> Total execution time: 0.1195
ERROR - 2023-10-28 13:49:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 13:49:43 --> Config Class Initialized
INFO - 2023-10-28 13:49:43 --> Hooks Class Initialized
DEBUG - 2023-10-28 13:49:43 --> UTF-8 Support Enabled
INFO - 2023-10-28 13:49:43 --> Utf8 Class Initialized
INFO - 2023-10-28 13:49:43 --> URI Class Initialized
INFO - 2023-10-28 13:49:43 --> Router Class Initialized
INFO - 2023-10-28 13:49:43 --> Output Class Initialized
INFO - 2023-10-28 13:49:43 --> Security Class Initialized
DEBUG - 2023-10-28 13:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 13:49:43 --> Input Class Initialized
INFO - 2023-10-28 13:49:43 --> Language Class Initialized
INFO - 2023-10-28 13:49:43 --> Loader Class Initialized
INFO - 2023-10-28 13:49:43 --> Helper loaded: url_helper
INFO - 2023-10-28 13:49:43 --> Helper loaded: file_helper
INFO - 2023-10-28 13:49:43 --> Helper loaded: html_helper
INFO - 2023-10-28 13:49:43 --> Helper loaded: text_helper
INFO - 2023-10-28 13:49:43 --> Helper loaded: form_helper
INFO - 2023-10-28 13:49:43 --> Helper loaded: lang_helper
INFO - 2023-10-28 13:49:43 --> Helper loaded: security_helper
INFO - 2023-10-28 13:49:43 --> Helper loaded: cookie_helper
INFO - 2023-10-28 13:49:43 --> Database Driver Class Initialized
INFO - 2023-10-28 13:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 13:49:43 --> Parser Class Initialized
INFO - 2023-10-28 13:49:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 13:49:43 --> Pagination Class Initialized
INFO - 2023-10-28 13:49:43 --> Form Validation Class Initialized
INFO - 2023-10-28 13:49:43 --> Controller Class Initialized
INFO - 2023-10-28 13:49:43 --> Model Class Initialized
DEBUG - 2023-10-28 13:49:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 13:49:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 13:49:43 --> Model Class Initialized
DEBUG - 2023-10-28 13:49:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 13:49:43 --> Model Class Initialized
INFO - 2023-10-28 13:49:43 --> Final output sent to browser
DEBUG - 2023-10-28 13:49:43 --> Total execution time: 0.0183
ERROR - 2023-10-28 13:49:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 13:49:44 --> Config Class Initialized
INFO - 2023-10-28 13:49:44 --> Hooks Class Initialized
DEBUG - 2023-10-28 13:49:44 --> UTF-8 Support Enabled
INFO - 2023-10-28 13:49:44 --> Utf8 Class Initialized
INFO - 2023-10-28 13:49:44 --> URI Class Initialized
INFO - 2023-10-28 13:49:44 --> Router Class Initialized
INFO - 2023-10-28 13:49:44 --> Output Class Initialized
INFO - 2023-10-28 13:49:44 --> Security Class Initialized
DEBUG - 2023-10-28 13:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 13:49:44 --> Input Class Initialized
INFO - 2023-10-28 13:49:44 --> Language Class Initialized
INFO - 2023-10-28 13:49:44 --> Loader Class Initialized
INFO - 2023-10-28 13:49:44 --> Helper loaded: url_helper
INFO - 2023-10-28 13:49:44 --> Helper loaded: file_helper
INFO - 2023-10-28 13:49:44 --> Helper loaded: html_helper
INFO - 2023-10-28 13:49:44 --> Helper loaded: text_helper
INFO - 2023-10-28 13:49:44 --> Helper loaded: form_helper
INFO - 2023-10-28 13:49:44 --> Helper loaded: lang_helper
INFO - 2023-10-28 13:49:44 --> Helper loaded: security_helper
INFO - 2023-10-28 13:49:44 --> Helper loaded: cookie_helper
INFO - 2023-10-28 13:49:44 --> Database Driver Class Initialized
INFO - 2023-10-28 13:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 13:49:44 --> Parser Class Initialized
INFO - 2023-10-28 13:49:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 13:49:44 --> Pagination Class Initialized
INFO - 2023-10-28 13:49:44 --> Form Validation Class Initialized
INFO - 2023-10-28 13:49:44 --> Controller Class Initialized
INFO - 2023-10-28 13:49:44 --> Model Class Initialized
DEBUG - 2023-10-28 13:49:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 13:49:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 13:49:44 --> Model Class Initialized
DEBUG - 2023-10-28 13:49:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 13:49:44 --> Model Class Initialized
INFO - 2023-10-28 13:49:44 --> Final output sent to browser
DEBUG - 2023-10-28 13:49:44 --> Total execution time: 0.0204
ERROR - 2023-10-28 13:49:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 13:49:44 --> Config Class Initialized
INFO - 2023-10-28 13:49:44 --> Hooks Class Initialized
DEBUG - 2023-10-28 13:49:44 --> UTF-8 Support Enabled
INFO - 2023-10-28 13:49:44 --> Utf8 Class Initialized
INFO - 2023-10-28 13:49:44 --> URI Class Initialized
INFO - 2023-10-28 13:49:44 --> Router Class Initialized
INFO - 2023-10-28 13:49:44 --> Output Class Initialized
INFO - 2023-10-28 13:49:44 --> Security Class Initialized
DEBUG - 2023-10-28 13:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 13:49:44 --> Input Class Initialized
INFO - 2023-10-28 13:49:44 --> Language Class Initialized
INFO - 2023-10-28 13:49:44 --> Loader Class Initialized
INFO - 2023-10-28 13:49:44 --> Helper loaded: url_helper
INFO - 2023-10-28 13:49:44 --> Helper loaded: file_helper
INFO - 2023-10-28 13:49:44 --> Helper loaded: html_helper
INFO - 2023-10-28 13:49:44 --> Helper loaded: text_helper
INFO - 2023-10-28 13:49:44 --> Helper loaded: form_helper
INFO - 2023-10-28 13:49:44 --> Helper loaded: lang_helper
INFO - 2023-10-28 13:49:44 --> Helper loaded: security_helper
INFO - 2023-10-28 13:49:44 --> Helper loaded: cookie_helper
INFO - 2023-10-28 13:49:44 --> Database Driver Class Initialized
INFO - 2023-10-28 13:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 13:49:44 --> Parser Class Initialized
INFO - 2023-10-28 13:49:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 13:49:44 --> Pagination Class Initialized
INFO - 2023-10-28 13:49:44 --> Form Validation Class Initialized
INFO - 2023-10-28 13:49:44 --> Controller Class Initialized
INFO - 2023-10-28 13:49:44 --> Model Class Initialized
DEBUG - 2023-10-28 13:49:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 13:49:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 13:49:44 --> Model Class Initialized
DEBUG - 2023-10-28 13:49:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 13:49:44 --> Model Class Initialized
INFO - 2023-10-28 13:49:44 --> Final output sent to browser
DEBUG - 2023-10-28 13:49:44 --> Total execution time: 0.0182
ERROR - 2023-10-28 14:44:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 14:44:07 --> Config Class Initialized
INFO - 2023-10-28 14:44:07 --> Hooks Class Initialized
DEBUG - 2023-10-28 14:44:07 --> UTF-8 Support Enabled
INFO - 2023-10-28 14:44:07 --> Utf8 Class Initialized
INFO - 2023-10-28 14:44:07 --> URI Class Initialized
DEBUG - 2023-10-28 14:44:07 --> No URI present. Default controller set.
INFO - 2023-10-28 14:44:07 --> Router Class Initialized
INFO - 2023-10-28 14:44:07 --> Output Class Initialized
INFO - 2023-10-28 14:44:07 --> Security Class Initialized
DEBUG - 2023-10-28 14:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 14:44:07 --> Input Class Initialized
INFO - 2023-10-28 14:44:07 --> Language Class Initialized
INFO - 2023-10-28 14:44:07 --> Loader Class Initialized
INFO - 2023-10-28 14:44:07 --> Helper loaded: url_helper
INFO - 2023-10-28 14:44:07 --> Helper loaded: file_helper
INFO - 2023-10-28 14:44:07 --> Helper loaded: html_helper
INFO - 2023-10-28 14:44:07 --> Helper loaded: text_helper
INFO - 2023-10-28 14:44:07 --> Helper loaded: form_helper
INFO - 2023-10-28 14:44:07 --> Helper loaded: lang_helper
INFO - 2023-10-28 14:44:07 --> Helper loaded: security_helper
INFO - 2023-10-28 14:44:07 --> Helper loaded: cookie_helper
INFO - 2023-10-28 14:44:07 --> Database Driver Class Initialized
INFO - 2023-10-28 14:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 14:44:07 --> Parser Class Initialized
INFO - 2023-10-28 14:44:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 14:44:07 --> Pagination Class Initialized
INFO - 2023-10-28 14:44:07 --> Form Validation Class Initialized
INFO - 2023-10-28 14:44:07 --> Controller Class Initialized
INFO - 2023-10-28 14:44:07 --> Model Class Initialized
DEBUG - 2023-10-28 14:44:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-28 14:44:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 14:44:07 --> Config Class Initialized
INFO - 2023-10-28 14:44:07 --> Hooks Class Initialized
DEBUG - 2023-10-28 14:44:07 --> UTF-8 Support Enabled
INFO - 2023-10-28 14:44:07 --> Utf8 Class Initialized
INFO - 2023-10-28 14:44:07 --> URI Class Initialized
INFO - 2023-10-28 14:44:07 --> Router Class Initialized
INFO - 2023-10-28 14:44:07 --> Output Class Initialized
INFO - 2023-10-28 14:44:07 --> Security Class Initialized
DEBUG - 2023-10-28 14:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 14:44:07 --> Input Class Initialized
INFO - 2023-10-28 14:44:07 --> Language Class Initialized
INFO - 2023-10-28 14:44:07 --> Loader Class Initialized
INFO - 2023-10-28 14:44:07 --> Helper loaded: url_helper
INFO - 2023-10-28 14:44:07 --> Helper loaded: file_helper
INFO - 2023-10-28 14:44:07 --> Helper loaded: html_helper
INFO - 2023-10-28 14:44:07 --> Helper loaded: text_helper
INFO - 2023-10-28 14:44:07 --> Helper loaded: form_helper
INFO - 2023-10-28 14:44:07 --> Helper loaded: lang_helper
INFO - 2023-10-28 14:44:07 --> Helper loaded: security_helper
INFO - 2023-10-28 14:44:07 --> Helper loaded: cookie_helper
INFO - 2023-10-28 14:44:07 --> Database Driver Class Initialized
INFO - 2023-10-28 14:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 14:44:07 --> Parser Class Initialized
INFO - 2023-10-28 14:44:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 14:44:07 --> Pagination Class Initialized
INFO - 2023-10-28 14:44:07 --> Form Validation Class Initialized
INFO - 2023-10-28 14:44:07 --> Controller Class Initialized
INFO - 2023-10-28 14:44:07 --> Model Class Initialized
DEBUG - 2023-10-28 14:44:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 14:44:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-28 14:44:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 14:44:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 14:44:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 14:44:07 --> Model Class Initialized
INFO - 2023-10-28 14:44:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 14:44:07 --> Final output sent to browser
DEBUG - 2023-10-28 14:44:07 --> Total execution time: 0.0301
ERROR - 2023-10-28 14:44:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 14:44:25 --> Config Class Initialized
INFO - 2023-10-28 14:44:25 --> Hooks Class Initialized
DEBUG - 2023-10-28 14:44:25 --> UTF-8 Support Enabled
INFO - 2023-10-28 14:44:25 --> Utf8 Class Initialized
INFO - 2023-10-28 14:44:25 --> URI Class Initialized
INFO - 2023-10-28 14:44:25 --> Router Class Initialized
INFO - 2023-10-28 14:44:25 --> Output Class Initialized
INFO - 2023-10-28 14:44:25 --> Security Class Initialized
DEBUG - 2023-10-28 14:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 14:44:25 --> Input Class Initialized
INFO - 2023-10-28 14:44:25 --> Language Class Initialized
INFO - 2023-10-28 14:44:25 --> Loader Class Initialized
INFO - 2023-10-28 14:44:25 --> Helper loaded: url_helper
INFO - 2023-10-28 14:44:25 --> Helper loaded: file_helper
INFO - 2023-10-28 14:44:25 --> Helper loaded: html_helper
INFO - 2023-10-28 14:44:25 --> Helper loaded: text_helper
INFO - 2023-10-28 14:44:25 --> Helper loaded: form_helper
INFO - 2023-10-28 14:44:25 --> Helper loaded: lang_helper
INFO - 2023-10-28 14:44:25 --> Helper loaded: security_helper
INFO - 2023-10-28 14:44:25 --> Helper loaded: cookie_helper
INFO - 2023-10-28 14:44:25 --> Database Driver Class Initialized
INFO - 2023-10-28 14:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 14:44:25 --> Parser Class Initialized
INFO - 2023-10-28 14:44:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 14:44:25 --> Pagination Class Initialized
INFO - 2023-10-28 14:44:25 --> Form Validation Class Initialized
INFO - 2023-10-28 14:44:25 --> Controller Class Initialized
INFO - 2023-10-28 14:44:25 --> Model Class Initialized
DEBUG - 2023-10-28 14:44:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 14:44:25 --> Model Class Initialized
INFO - 2023-10-28 14:44:25 --> Final output sent to browser
DEBUG - 2023-10-28 14:44:25 --> Total execution time: 0.0203
ERROR - 2023-10-28 14:44:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 14:44:25 --> Config Class Initialized
INFO - 2023-10-28 14:44:25 --> Hooks Class Initialized
DEBUG - 2023-10-28 14:44:25 --> UTF-8 Support Enabled
INFO - 2023-10-28 14:44:25 --> Utf8 Class Initialized
INFO - 2023-10-28 14:44:25 --> URI Class Initialized
DEBUG - 2023-10-28 14:44:25 --> No URI present. Default controller set.
INFO - 2023-10-28 14:44:25 --> Router Class Initialized
INFO - 2023-10-28 14:44:25 --> Output Class Initialized
INFO - 2023-10-28 14:44:25 --> Security Class Initialized
DEBUG - 2023-10-28 14:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 14:44:25 --> Input Class Initialized
INFO - 2023-10-28 14:44:25 --> Language Class Initialized
INFO - 2023-10-28 14:44:25 --> Loader Class Initialized
INFO - 2023-10-28 14:44:25 --> Helper loaded: url_helper
INFO - 2023-10-28 14:44:25 --> Helper loaded: file_helper
INFO - 2023-10-28 14:44:25 --> Helper loaded: html_helper
INFO - 2023-10-28 14:44:25 --> Helper loaded: text_helper
INFO - 2023-10-28 14:44:25 --> Helper loaded: form_helper
INFO - 2023-10-28 14:44:25 --> Helper loaded: lang_helper
INFO - 2023-10-28 14:44:25 --> Helper loaded: security_helper
INFO - 2023-10-28 14:44:25 --> Helper loaded: cookie_helper
INFO - 2023-10-28 14:44:25 --> Database Driver Class Initialized
INFO - 2023-10-28 14:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 14:44:25 --> Parser Class Initialized
INFO - 2023-10-28 14:44:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 14:44:25 --> Pagination Class Initialized
INFO - 2023-10-28 14:44:25 --> Form Validation Class Initialized
INFO - 2023-10-28 14:44:25 --> Controller Class Initialized
INFO - 2023-10-28 14:44:25 --> Model Class Initialized
DEBUG - 2023-10-28 14:44:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 14:44:25 --> Model Class Initialized
DEBUG - 2023-10-28 14:44:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 14:44:25 --> Model Class Initialized
INFO - 2023-10-28 14:44:25 --> Model Class Initialized
INFO - 2023-10-28 14:44:25 --> Model Class Initialized
INFO - 2023-10-28 14:44:25 --> Model Class Initialized
DEBUG - 2023-10-28 14:44:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 14:44:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 14:44:25 --> Model Class Initialized
INFO - 2023-10-28 14:44:25 --> Model Class Initialized
INFO - 2023-10-28 14:44:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-28 14:44:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 14:44:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 14:44:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 14:44:25 --> Model Class Initialized
INFO - 2023-10-28 14:44:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 14:44:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 14:44:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 14:44:26 --> Final output sent to browser
DEBUG - 2023-10-28 14:44:26 --> Total execution time: 0.2219
ERROR - 2023-10-28 14:44:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 14:44:33 --> Config Class Initialized
INFO - 2023-10-28 14:44:33 --> Hooks Class Initialized
DEBUG - 2023-10-28 14:44:33 --> UTF-8 Support Enabled
INFO - 2023-10-28 14:44:33 --> Utf8 Class Initialized
INFO - 2023-10-28 14:44:33 --> URI Class Initialized
INFO - 2023-10-28 14:44:33 --> Router Class Initialized
INFO - 2023-10-28 14:44:33 --> Output Class Initialized
INFO - 2023-10-28 14:44:33 --> Security Class Initialized
DEBUG - 2023-10-28 14:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 14:44:33 --> Input Class Initialized
INFO - 2023-10-28 14:44:33 --> Language Class Initialized
INFO - 2023-10-28 14:44:33 --> Loader Class Initialized
INFO - 2023-10-28 14:44:33 --> Helper loaded: url_helper
INFO - 2023-10-28 14:44:33 --> Helper loaded: file_helper
INFO - 2023-10-28 14:44:33 --> Helper loaded: html_helper
INFO - 2023-10-28 14:44:33 --> Helper loaded: text_helper
INFO - 2023-10-28 14:44:33 --> Helper loaded: form_helper
INFO - 2023-10-28 14:44:33 --> Helper loaded: lang_helper
INFO - 2023-10-28 14:44:33 --> Helper loaded: security_helper
INFO - 2023-10-28 14:44:33 --> Helper loaded: cookie_helper
INFO - 2023-10-28 14:44:33 --> Database Driver Class Initialized
INFO - 2023-10-28 14:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 14:44:33 --> Parser Class Initialized
INFO - 2023-10-28 14:44:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 14:44:33 --> Pagination Class Initialized
INFO - 2023-10-28 14:44:33 --> Form Validation Class Initialized
INFO - 2023-10-28 14:44:33 --> Controller Class Initialized
INFO - 2023-10-28 14:44:33 --> Model Class Initialized
INFO - 2023-10-28 14:44:33 --> Model Class Initialized
INFO - 2023-10-28 14:44:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2023-10-28 14:44:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 14:44:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 14:44:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 14:44:33 --> Model Class Initialized
INFO - 2023-10-28 14:44:33 --> Model Class Initialized
INFO - 2023-10-28 14:44:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 14:44:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 14:44:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 14:44:33 --> Final output sent to browser
DEBUG - 2023-10-28 14:44:33 --> Total execution time: 0.1766
ERROR - 2023-10-28 14:44:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 14:44:35 --> Config Class Initialized
INFO - 2023-10-28 14:44:35 --> Hooks Class Initialized
DEBUG - 2023-10-28 14:44:35 --> UTF-8 Support Enabled
INFO - 2023-10-28 14:44:35 --> Utf8 Class Initialized
INFO - 2023-10-28 14:44:35 --> URI Class Initialized
INFO - 2023-10-28 14:44:35 --> Router Class Initialized
INFO - 2023-10-28 14:44:35 --> Output Class Initialized
INFO - 2023-10-28 14:44:35 --> Security Class Initialized
DEBUG - 2023-10-28 14:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 14:44:35 --> Input Class Initialized
INFO - 2023-10-28 14:44:35 --> Language Class Initialized
INFO - 2023-10-28 14:44:35 --> Loader Class Initialized
INFO - 2023-10-28 14:44:35 --> Helper loaded: url_helper
INFO - 2023-10-28 14:44:35 --> Helper loaded: file_helper
INFO - 2023-10-28 14:44:35 --> Helper loaded: html_helper
INFO - 2023-10-28 14:44:35 --> Helper loaded: text_helper
INFO - 2023-10-28 14:44:35 --> Helper loaded: form_helper
INFO - 2023-10-28 14:44:35 --> Helper loaded: lang_helper
INFO - 2023-10-28 14:44:35 --> Helper loaded: security_helper
INFO - 2023-10-28 14:44:35 --> Helper loaded: cookie_helper
INFO - 2023-10-28 14:44:35 --> Database Driver Class Initialized
INFO - 2023-10-28 14:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 14:44:35 --> Parser Class Initialized
INFO - 2023-10-28 14:44:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 14:44:35 --> Pagination Class Initialized
INFO - 2023-10-28 14:44:35 --> Form Validation Class Initialized
INFO - 2023-10-28 14:44:35 --> Controller Class Initialized
INFO - 2023-10-28 14:44:35 --> Model Class Initialized
INFO - 2023-10-28 14:44:35 --> Model Class Initialized
INFO - 2023-10-28 14:44:35 --> Final output sent to browser
DEBUG - 2023-10-28 14:44:35 --> Total execution time: 0.1720
ERROR - 2023-10-28 14:46:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 14:46:06 --> Config Class Initialized
INFO - 2023-10-28 14:46:06 --> Hooks Class Initialized
DEBUG - 2023-10-28 14:46:06 --> UTF-8 Support Enabled
INFO - 2023-10-28 14:46:06 --> Utf8 Class Initialized
INFO - 2023-10-28 14:46:06 --> URI Class Initialized
DEBUG - 2023-10-28 14:46:06 --> No URI present. Default controller set.
INFO - 2023-10-28 14:46:06 --> Router Class Initialized
INFO - 2023-10-28 14:46:06 --> Output Class Initialized
INFO - 2023-10-28 14:46:06 --> Security Class Initialized
DEBUG - 2023-10-28 14:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 14:46:06 --> Input Class Initialized
INFO - 2023-10-28 14:46:06 --> Language Class Initialized
INFO - 2023-10-28 14:46:06 --> Loader Class Initialized
INFO - 2023-10-28 14:46:06 --> Helper loaded: url_helper
INFO - 2023-10-28 14:46:06 --> Helper loaded: file_helper
INFO - 2023-10-28 14:46:06 --> Helper loaded: html_helper
INFO - 2023-10-28 14:46:06 --> Helper loaded: text_helper
INFO - 2023-10-28 14:46:06 --> Helper loaded: form_helper
INFO - 2023-10-28 14:46:06 --> Helper loaded: lang_helper
INFO - 2023-10-28 14:46:06 --> Helper loaded: security_helper
INFO - 2023-10-28 14:46:06 --> Helper loaded: cookie_helper
INFO - 2023-10-28 14:46:06 --> Database Driver Class Initialized
INFO - 2023-10-28 14:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 14:46:06 --> Parser Class Initialized
INFO - 2023-10-28 14:46:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 14:46:06 --> Pagination Class Initialized
INFO - 2023-10-28 14:46:06 --> Form Validation Class Initialized
INFO - 2023-10-28 14:46:06 --> Controller Class Initialized
INFO - 2023-10-28 14:46:06 --> Model Class Initialized
DEBUG - 2023-10-28 14:46:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 14:46:06 --> Model Class Initialized
DEBUG - 2023-10-28 14:46:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 14:46:06 --> Model Class Initialized
INFO - 2023-10-28 14:46:06 --> Model Class Initialized
INFO - 2023-10-28 14:46:06 --> Model Class Initialized
INFO - 2023-10-28 14:46:06 --> Model Class Initialized
DEBUG - 2023-10-28 14:46:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 14:46:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 14:46:06 --> Model Class Initialized
INFO - 2023-10-28 14:46:06 --> Model Class Initialized
INFO - 2023-10-28 14:46:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-28 14:46:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 14:46:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 14:46:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 14:46:06 --> Model Class Initialized
INFO - 2023-10-28 14:46:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 14:46:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 14:46:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 14:46:06 --> Final output sent to browser
DEBUG - 2023-10-28 14:46:06 --> Total execution time: 0.2027
ERROR - 2023-10-28 14:46:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 14:46:29 --> Config Class Initialized
INFO - 2023-10-28 14:46:29 --> Hooks Class Initialized
DEBUG - 2023-10-28 14:46:29 --> UTF-8 Support Enabled
INFO - 2023-10-28 14:46:29 --> Utf8 Class Initialized
INFO - 2023-10-28 14:46:29 --> URI Class Initialized
INFO - 2023-10-28 14:46:29 --> Router Class Initialized
INFO - 2023-10-28 14:46:29 --> Output Class Initialized
INFO - 2023-10-28 14:46:29 --> Security Class Initialized
DEBUG - 2023-10-28 14:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 14:46:29 --> Input Class Initialized
INFO - 2023-10-28 14:46:29 --> Language Class Initialized
INFO - 2023-10-28 14:46:29 --> Loader Class Initialized
INFO - 2023-10-28 14:46:29 --> Helper loaded: url_helper
INFO - 2023-10-28 14:46:29 --> Helper loaded: file_helper
INFO - 2023-10-28 14:46:29 --> Helper loaded: html_helper
INFO - 2023-10-28 14:46:29 --> Helper loaded: text_helper
INFO - 2023-10-28 14:46:29 --> Helper loaded: form_helper
INFO - 2023-10-28 14:46:29 --> Helper loaded: lang_helper
INFO - 2023-10-28 14:46:29 --> Helper loaded: security_helper
INFO - 2023-10-28 14:46:29 --> Helper loaded: cookie_helper
INFO - 2023-10-28 14:46:29 --> Database Driver Class Initialized
INFO - 2023-10-28 14:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 14:46:29 --> Parser Class Initialized
INFO - 2023-10-28 14:46:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 14:46:29 --> Pagination Class Initialized
INFO - 2023-10-28 14:46:29 --> Form Validation Class Initialized
INFO - 2023-10-28 14:46:29 --> Controller Class Initialized
INFO - 2023-10-28 14:46:29 --> Model Class Initialized
DEBUG - 2023-10-28 14:46:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 14:46:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-28 14:46:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 14:46:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 14:46:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 14:46:29 --> Model Class Initialized
INFO - 2023-10-28 14:46:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 14:46:29 --> Final output sent to browser
DEBUG - 2023-10-28 14:46:29 --> Total execution time: 0.0314
ERROR - 2023-10-28 14:46:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 14:46:29 --> Config Class Initialized
INFO - 2023-10-28 14:46:29 --> Hooks Class Initialized
DEBUG - 2023-10-28 14:46:29 --> UTF-8 Support Enabled
INFO - 2023-10-28 14:46:29 --> Utf8 Class Initialized
INFO - 2023-10-28 14:46:29 --> URI Class Initialized
INFO - 2023-10-28 14:46:29 --> Router Class Initialized
INFO - 2023-10-28 14:46:29 --> Output Class Initialized
INFO - 2023-10-28 14:46:29 --> Security Class Initialized
DEBUG - 2023-10-28 14:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 14:46:29 --> Input Class Initialized
INFO - 2023-10-28 14:46:29 --> Language Class Initialized
INFO - 2023-10-28 14:46:29 --> Loader Class Initialized
INFO - 2023-10-28 14:46:29 --> Helper loaded: url_helper
INFO - 2023-10-28 14:46:29 --> Helper loaded: file_helper
INFO - 2023-10-28 14:46:29 --> Helper loaded: html_helper
INFO - 2023-10-28 14:46:29 --> Helper loaded: text_helper
INFO - 2023-10-28 14:46:29 --> Helper loaded: form_helper
INFO - 2023-10-28 14:46:29 --> Helper loaded: lang_helper
INFO - 2023-10-28 14:46:29 --> Helper loaded: security_helper
INFO - 2023-10-28 14:46:29 --> Helper loaded: cookie_helper
INFO - 2023-10-28 14:46:29 --> Database Driver Class Initialized
INFO - 2023-10-28 14:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 14:46:29 --> Parser Class Initialized
INFO - 2023-10-28 14:46:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-28 14:46:29 --> Pagination Class Initialized
INFO - 2023-10-28 14:46:29 --> Form Validation Class Initialized
INFO - 2023-10-28 14:46:29 --> Controller Class Initialized
INFO - 2023-10-28 14:46:29 --> Model Class Initialized
DEBUG - 2023-10-28 14:46:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 14:46:29 --> Model Class Initialized
DEBUG - 2023-10-28 14:46:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 14:46:29 --> Model Class Initialized
INFO - 2023-10-28 14:46:29 --> Model Class Initialized
INFO - 2023-10-28 14:46:29 --> Model Class Initialized
INFO - 2023-10-28 14:46:29 --> Model Class Initialized
DEBUG - 2023-10-28 14:46:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 14:46:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-28 14:46:29 --> Model Class Initialized
INFO - 2023-10-28 14:46:29 --> Model Class Initialized
INFO - 2023-10-28 14:46:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-28 14:46:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-28 14:46:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-28 14:46:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-28 14:46:29 --> Model Class Initialized
INFO - 2023-10-28 14:46:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-28 14:46:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-28 14:46:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-28 14:46:30 --> Final output sent to browser
DEBUG - 2023-10-28 14:46:30 --> Total execution time: 0.1965
ERROR - 2023-10-28 21:02:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-28 21:02:39 --> Config Class Initialized
INFO - 2023-10-28 21:02:39 --> Hooks Class Initialized
DEBUG - 2023-10-28 21:02:39 --> UTF-8 Support Enabled
INFO - 2023-10-28 21:02:39 --> Utf8 Class Initialized
INFO - 2023-10-28 21:02:39 --> URI Class Initialized
INFO - 2023-10-28 21:02:39 --> Router Class Initialized
INFO - 2023-10-28 21:02:39 --> Output Class Initialized
INFO - 2023-10-28 21:02:39 --> Security Class Initialized
DEBUG - 2023-10-28 21:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 21:02:39 --> Input Class Initialized
INFO - 2023-10-28 21:02:39 --> Language Class Initialized
ERROR - 2023-10-28 21:02:39 --> 404 Page Not Found: Well-known/assetlinks.json
