<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-01-14 00:25:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 00:25:51 --> Config Class Initialized
INFO - 2024-01-14 00:25:51 --> Hooks Class Initialized
DEBUG - 2024-01-14 00:25:51 --> UTF-8 Support Enabled
INFO - 2024-01-14 00:25:51 --> Utf8 Class Initialized
INFO - 2024-01-14 00:25:51 --> URI Class Initialized
INFO - 2024-01-14 00:25:51 --> Router Class Initialized
INFO - 2024-01-14 00:25:51 --> Output Class Initialized
INFO - 2024-01-14 00:25:51 --> Security Class Initialized
DEBUG - 2024-01-14 00:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 00:25:51 --> Input Class Initialized
INFO - 2024-01-14 00:25:51 --> Language Class Initialized
ERROR - 2024-01-14 00:25:51 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-01-14 02:57:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 02:57:40 --> Config Class Initialized
INFO - 2024-01-14 02:57:40 --> Hooks Class Initialized
DEBUG - 2024-01-14 02:57:40 --> UTF-8 Support Enabled
INFO - 2024-01-14 02:57:40 --> Utf8 Class Initialized
INFO - 2024-01-14 02:57:40 --> URI Class Initialized
INFO - 2024-01-14 02:57:40 --> Router Class Initialized
INFO - 2024-01-14 02:57:40 --> Output Class Initialized
INFO - 2024-01-14 02:57:40 --> Security Class Initialized
DEBUG - 2024-01-14 02:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 02:57:40 --> Input Class Initialized
INFO - 2024-01-14 02:57:40 --> Language Class Initialized
ERROR - 2024-01-14 02:57:40 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2024-01-14 02:57:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 02:57:41 --> Config Class Initialized
INFO - 2024-01-14 02:57:41 --> Hooks Class Initialized
DEBUG - 2024-01-14 02:57:41 --> UTF-8 Support Enabled
INFO - 2024-01-14 02:57:41 --> Utf8 Class Initialized
INFO - 2024-01-14 02:57:41 --> URI Class Initialized
DEBUG - 2024-01-14 02:57:41 --> No URI present. Default controller set.
INFO - 2024-01-14 02:57:41 --> Router Class Initialized
INFO - 2024-01-14 02:57:41 --> Output Class Initialized
INFO - 2024-01-14 02:57:41 --> Security Class Initialized
DEBUG - 2024-01-14 02:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 02:57:41 --> Input Class Initialized
INFO - 2024-01-14 02:57:41 --> Language Class Initialized
INFO - 2024-01-14 02:57:41 --> Loader Class Initialized
INFO - 2024-01-14 02:57:41 --> Helper loaded: url_helper
INFO - 2024-01-14 02:57:41 --> Helper loaded: file_helper
INFO - 2024-01-14 02:57:41 --> Helper loaded: html_helper
INFO - 2024-01-14 02:57:41 --> Helper loaded: text_helper
INFO - 2024-01-14 02:57:41 --> Helper loaded: form_helper
INFO - 2024-01-14 02:57:41 --> Helper loaded: lang_helper
INFO - 2024-01-14 02:57:41 --> Helper loaded: security_helper
INFO - 2024-01-14 02:57:41 --> Helper loaded: cookie_helper
INFO - 2024-01-14 02:57:41 --> Database Driver Class Initialized
INFO - 2024-01-14 02:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 02:57:41 --> Parser Class Initialized
INFO - 2024-01-14 02:57:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 02:57:41 --> Pagination Class Initialized
INFO - 2024-01-14 02:57:41 --> Form Validation Class Initialized
INFO - 2024-01-14 02:57:41 --> Controller Class Initialized
INFO - 2024-01-14 02:57:41 --> Model Class Initialized
DEBUG - 2024-01-14 02:57:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-14 02:57:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 02:57:42 --> Config Class Initialized
INFO - 2024-01-14 02:57:42 --> Hooks Class Initialized
DEBUG - 2024-01-14 02:57:42 --> UTF-8 Support Enabled
INFO - 2024-01-14 02:57:42 --> Utf8 Class Initialized
INFO - 2024-01-14 02:57:42 --> URI Class Initialized
INFO - 2024-01-14 02:57:42 --> Router Class Initialized
INFO - 2024-01-14 02:57:42 --> Output Class Initialized
INFO - 2024-01-14 02:57:42 --> Security Class Initialized
DEBUG - 2024-01-14 02:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 02:57:42 --> Input Class Initialized
INFO - 2024-01-14 02:57:42 --> Language Class Initialized
ERROR - 2024-01-14 02:57:42 --> 404 Page Not Found: Wp-cronphp/index
ERROR - 2024-01-14 13:31:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 13:31:35 --> Config Class Initialized
INFO - 2024-01-14 13:31:35 --> Hooks Class Initialized
DEBUG - 2024-01-14 13:31:35 --> UTF-8 Support Enabled
INFO - 2024-01-14 13:31:35 --> Utf8 Class Initialized
INFO - 2024-01-14 13:31:35 --> URI Class Initialized
DEBUG - 2024-01-14 13:31:35 --> No URI present. Default controller set.
INFO - 2024-01-14 13:31:35 --> Router Class Initialized
INFO - 2024-01-14 13:31:35 --> Output Class Initialized
INFO - 2024-01-14 13:31:35 --> Security Class Initialized
DEBUG - 2024-01-14 13:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 13:31:35 --> Input Class Initialized
INFO - 2024-01-14 13:31:35 --> Language Class Initialized
INFO - 2024-01-14 13:31:35 --> Loader Class Initialized
INFO - 2024-01-14 13:31:35 --> Helper loaded: url_helper
INFO - 2024-01-14 13:31:35 --> Helper loaded: file_helper
INFO - 2024-01-14 13:31:35 --> Helper loaded: html_helper
INFO - 2024-01-14 13:31:35 --> Helper loaded: text_helper
INFO - 2024-01-14 13:31:35 --> Helper loaded: form_helper
INFO - 2024-01-14 13:31:35 --> Helper loaded: lang_helper
INFO - 2024-01-14 13:31:35 --> Helper loaded: security_helper
INFO - 2024-01-14 13:31:35 --> Helper loaded: cookie_helper
INFO - 2024-01-14 13:31:35 --> Database Driver Class Initialized
INFO - 2024-01-14 13:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 13:31:35 --> Parser Class Initialized
INFO - 2024-01-14 13:31:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 13:31:35 --> Pagination Class Initialized
INFO - 2024-01-14 13:31:35 --> Form Validation Class Initialized
INFO - 2024-01-14 13:31:35 --> Controller Class Initialized
INFO - 2024-01-14 13:31:35 --> Model Class Initialized
DEBUG - 2024-01-14 13:31:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-14 13:31:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 13:31:35 --> Config Class Initialized
INFO - 2024-01-14 13:31:35 --> Hooks Class Initialized
DEBUG - 2024-01-14 13:31:35 --> UTF-8 Support Enabled
INFO - 2024-01-14 13:31:35 --> Utf8 Class Initialized
INFO - 2024-01-14 13:31:35 --> URI Class Initialized
INFO - 2024-01-14 13:31:35 --> Router Class Initialized
INFO - 2024-01-14 13:31:35 --> Output Class Initialized
INFO - 2024-01-14 13:31:35 --> Security Class Initialized
DEBUG - 2024-01-14 13:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 13:31:35 --> Input Class Initialized
INFO - 2024-01-14 13:31:35 --> Language Class Initialized
INFO - 2024-01-14 13:31:35 --> Loader Class Initialized
INFO - 2024-01-14 13:31:35 --> Helper loaded: url_helper
INFO - 2024-01-14 13:31:35 --> Helper loaded: file_helper
INFO - 2024-01-14 13:31:35 --> Helper loaded: html_helper
INFO - 2024-01-14 13:31:35 --> Helper loaded: text_helper
INFO - 2024-01-14 13:31:35 --> Helper loaded: form_helper
INFO - 2024-01-14 13:31:35 --> Helper loaded: lang_helper
INFO - 2024-01-14 13:31:35 --> Helper loaded: security_helper
INFO - 2024-01-14 13:31:35 --> Helper loaded: cookie_helper
INFO - 2024-01-14 13:31:35 --> Database Driver Class Initialized
INFO - 2024-01-14 13:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 13:31:35 --> Parser Class Initialized
INFO - 2024-01-14 13:31:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 13:31:35 --> Pagination Class Initialized
INFO - 2024-01-14 13:31:35 --> Form Validation Class Initialized
INFO - 2024-01-14 13:31:35 --> Controller Class Initialized
INFO - 2024-01-14 13:31:35 --> Model Class Initialized
DEBUG - 2024-01-14 13:31:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:31:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-14 13:31:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:31:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-14 13:31:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-14 13:31:35 --> Model Class Initialized
INFO - 2024-01-14 13:31:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-14 13:31:35 --> Final output sent to browser
DEBUG - 2024-01-14 13:31:35 --> Total execution time: 0.0345
ERROR - 2024-01-14 13:31:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 13:31:57 --> Config Class Initialized
INFO - 2024-01-14 13:31:57 --> Hooks Class Initialized
DEBUG - 2024-01-14 13:31:57 --> UTF-8 Support Enabled
INFO - 2024-01-14 13:31:57 --> Utf8 Class Initialized
INFO - 2024-01-14 13:31:57 --> URI Class Initialized
INFO - 2024-01-14 13:31:57 --> Router Class Initialized
INFO - 2024-01-14 13:31:57 --> Output Class Initialized
INFO - 2024-01-14 13:31:57 --> Security Class Initialized
DEBUG - 2024-01-14 13:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 13:31:57 --> Input Class Initialized
INFO - 2024-01-14 13:31:57 --> Language Class Initialized
INFO - 2024-01-14 13:31:57 --> Loader Class Initialized
INFO - 2024-01-14 13:31:57 --> Helper loaded: url_helper
INFO - 2024-01-14 13:31:57 --> Helper loaded: file_helper
INFO - 2024-01-14 13:31:57 --> Helper loaded: html_helper
INFO - 2024-01-14 13:31:57 --> Helper loaded: text_helper
INFO - 2024-01-14 13:31:57 --> Helper loaded: form_helper
INFO - 2024-01-14 13:31:57 --> Helper loaded: lang_helper
INFO - 2024-01-14 13:31:57 --> Helper loaded: security_helper
INFO - 2024-01-14 13:31:57 --> Helper loaded: cookie_helper
INFO - 2024-01-14 13:31:57 --> Database Driver Class Initialized
INFO - 2024-01-14 13:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 13:31:57 --> Parser Class Initialized
INFO - 2024-01-14 13:31:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 13:31:57 --> Pagination Class Initialized
INFO - 2024-01-14 13:31:57 --> Form Validation Class Initialized
INFO - 2024-01-14 13:31:57 --> Controller Class Initialized
INFO - 2024-01-14 13:31:57 --> Model Class Initialized
DEBUG - 2024-01-14 13:31:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:31:57 --> Model Class Initialized
INFO - 2024-01-14 13:31:57 --> Final output sent to browser
DEBUG - 2024-01-14 13:31:57 --> Total execution time: 0.0224
ERROR - 2024-01-14 13:31:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 13:31:57 --> Config Class Initialized
INFO - 2024-01-14 13:31:57 --> Hooks Class Initialized
DEBUG - 2024-01-14 13:31:57 --> UTF-8 Support Enabled
INFO - 2024-01-14 13:31:57 --> Utf8 Class Initialized
INFO - 2024-01-14 13:31:57 --> URI Class Initialized
DEBUG - 2024-01-14 13:31:57 --> No URI present. Default controller set.
INFO - 2024-01-14 13:31:57 --> Router Class Initialized
INFO - 2024-01-14 13:31:57 --> Output Class Initialized
INFO - 2024-01-14 13:31:57 --> Security Class Initialized
DEBUG - 2024-01-14 13:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 13:31:57 --> Input Class Initialized
INFO - 2024-01-14 13:31:57 --> Language Class Initialized
INFO - 2024-01-14 13:31:57 --> Loader Class Initialized
INFO - 2024-01-14 13:31:57 --> Helper loaded: url_helper
INFO - 2024-01-14 13:31:57 --> Helper loaded: file_helper
INFO - 2024-01-14 13:31:57 --> Helper loaded: html_helper
INFO - 2024-01-14 13:31:57 --> Helper loaded: text_helper
INFO - 2024-01-14 13:31:57 --> Helper loaded: form_helper
INFO - 2024-01-14 13:31:57 --> Helper loaded: lang_helper
INFO - 2024-01-14 13:31:57 --> Helper loaded: security_helper
INFO - 2024-01-14 13:31:57 --> Helper loaded: cookie_helper
INFO - 2024-01-14 13:31:57 --> Database Driver Class Initialized
INFO - 2024-01-14 13:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 13:31:57 --> Parser Class Initialized
INFO - 2024-01-14 13:31:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 13:31:57 --> Pagination Class Initialized
INFO - 2024-01-14 13:31:57 --> Form Validation Class Initialized
INFO - 2024-01-14 13:31:57 --> Controller Class Initialized
INFO - 2024-01-14 13:31:57 --> Model Class Initialized
DEBUG - 2024-01-14 13:31:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:31:57 --> Model Class Initialized
DEBUG - 2024-01-14 13:31:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:31:57 --> Model Class Initialized
INFO - 2024-01-14 13:31:57 --> Model Class Initialized
INFO - 2024-01-14 13:31:57 --> Model Class Initialized
INFO - 2024-01-14 13:31:57 --> Model Class Initialized
DEBUG - 2024-01-14 13:31:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 13:31:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:31:57 --> Model Class Initialized
INFO - 2024-01-14 13:31:57 --> Model Class Initialized
INFO - 2024-01-14 13:31:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-14 13:31:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:31:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-14 13:31:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-14 13:31:57 --> Model Class Initialized
INFO - 2024-01-14 13:31:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-14 13:31:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-14 13:31:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-14 13:31:57 --> Final output sent to browser
DEBUG - 2024-01-14 13:31:57 --> Total execution time: 0.2263
ERROR - 2024-01-14 13:32:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 13:32:44 --> Config Class Initialized
INFO - 2024-01-14 13:32:44 --> Hooks Class Initialized
DEBUG - 2024-01-14 13:32:44 --> UTF-8 Support Enabled
INFO - 2024-01-14 13:32:44 --> Utf8 Class Initialized
INFO - 2024-01-14 13:32:44 --> URI Class Initialized
INFO - 2024-01-14 13:32:44 --> Router Class Initialized
INFO - 2024-01-14 13:32:44 --> Output Class Initialized
INFO - 2024-01-14 13:32:44 --> Security Class Initialized
DEBUG - 2024-01-14 13:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 13:32:44 --> Input Class Initialized
INFO - 2024-01-14 13:32:44 --> Language Class Initialized
INFO - 2024-01-14 13:32:44 --> Loader Class Initialized
INFO - 2024-01-14 13:32:44 --> Helper loaded: url_helper
INFO - 2024-01-14 13:32:44 --> Helper loaded: file_helper
INFO - 2024-01-14 13:32:44 --> Helper loaded: html_helper
INFO - 2024-01-14 13:32:44 --> Helper loaded: text_helper
INFO - 2024-01-14 13:32:44 --> Helper loaded: form_helper
INFO - 2024-01-14 13:32:44 --> Helper loaded: lang_helper
INFO - 2024-01-14 13:32:44 --> Helper loaded: security_helper
INFO - 2024-01-14 13:32:44 --> Helper loaded: cookie_helper
INFO - 2024-01-14 13:32:44 --> Database Driver Class Initialized
INFO - 2024-01-14 13:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 13:32:44 --> Parser Class Initialized
INFO - 2024-01-14 13:32:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 13:32:44 --> Pagination Class Initialized
INFO - 2024-01-14 13:32:44 --> Form Validation Class Initialized
INFO - 2024-01-14 13:32:44 --> Controller Class Initialized
INFO - 2024-01-14 13:32:44 --> Model Class Initialized
DEBUG - 2024-01-14 13:32:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:32:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-14 13:32:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:32:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-14 13:32:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-14 13:32:44 --> Model Class Initialized
INFO - 2024-01-14 13:32:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-14 13:32:44 --> Final output sent to browser
DEBUG - 2024-01-14 13:32:44 --> Total execution time: 0.0337
ERROR - 2024-01-14 13:32:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 13:32:44 --> Config Class Initialized
INFO - 2024-01-14 13:32:44 --> Hooks Class Initialized
DEBUG - 2024-01-14 13:32:44 --> UTF-8 Support Enabled
INFO - 2024-01-14 13:32:44 --> Utf8 Class Initialized
INFO - 2024-01-14 13:32:44 --> URI Class Initialized
INFO - 2024-01-14 13:32:44 --> Router Class Initialized
INFO - 2024-01-14 13:32:44 --> Output Class Initialized
INFO - 2024-01-14 13:32:44 --> Security Class Initialized
DEBUG - 2024-01-14 13:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 13:32:44 --> Input Class Initialized
INFO - 2024-01-14 13:32:44 --> Language Class Initialized
INFO - 2024-01-14 13:32:44 --> Loader Class Initialized
INFO - 2024-01-14 13:32:44 --> Helper loaded: url_helper
INFO - 2024-01-14 13:32:44 --> Helper loaded: file_helper
INFO - 2024-01-14 13:32:44 --> Helper loaded: html_helper
INFO - 2024-01-14 13:32:44 --> Helper loaded: text_helper
INFO - 2024-01-14 13:32:44 --> Helper loaded: form_helper
INFO - 2024-01-14 13:32:44 --> Helper loaded: lang_helper
INFO - 2024-01-14 13:32:44 --> Helper loaded: security_helper
INFO - 2024-01-14 13:32:44 --> Helper loaded: cookie_helper
INFO - 2024-01-14 13:32:44 --> Database Driver Class Initialized
INFO - 2024-01-14 13:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 13:32:44 --> Parser Class Initialized
INFO - 2024-01-14 13:32:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 13:32:44 --> Pagination Class Initialized
INFO - 2024-01-14 13:32:44 --> Form Validation Class Initialized
INFO - 2024-01-14 13:32:44 --> Controller Class Initialized
INFO - 2024-01-14 13:32:44 --> Model Class Initialized
DEBUG - 2024-01-14 13:32:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:32:44 --> Model Class Initialized
DEBUG - 2024-01-14 13:32:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:32:44 --> Model Class Initialized
INFO - 2024-01-14 13:32:44 --> Model Class Initialized
INFO - 2024-01-14 13:32:44 --> Model Class Initialized
INFO - 2024-01-14 13:32:44 --> Model Class Initialized
DEBUG - 2024-01-14 13:32:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 13:32:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:32:44 --> Model Class Initialized
INFO - 2024-01-14 13:32:44 --> Model Class Initialized
INFO - 2024-01-14 13:32:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-14 13:32:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:32:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-14 13:32:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-14 13:32:44 --> Model Class Initialized
INFO - 2024-01-14 13:32:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-14 13:32:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-14 13:32:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-14 13:32:44 --> Final output sent to browser
DEBUG - 2024-01-14 13:32:44 --> Total execution time: 0.2338
ERROR - 2024-01-14 13:33:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 13:33:01 --> Config Class Initialized
INFO - 2024-01-14 13:33:01 --> Hooks Class Initialized
DEBUG - 2024-01-14 13:33:01 --> UTF-8 Support Enabled
INFO - 2024-01-14 13:33:01 --> Utf8 Class Initialized
INFO - 2024-01-14 13:33:01 --> URI Class Initialized
INFO - 2024-01-14 13:33:01 --> Router Class Initialized
INFO - 2024-01-14 13:33:01 --> Output Class Initialized
INFO - 2024-01-14 13:33:01 --> Security Class Initialized
DEBUG - 2024-01-14 13:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 13:33:01 --> Input Class Initialized
INFO - 2024-01-14 13:33:01 --> Language Class Initialized
INFO - 2024-01-14 13:33:01 --> Loader Class Initialized
INFO - 2024-01-14 13:33:01 --> Helper loaded: url_helper
INFO - 2024-01-14 13:33:01 --> Helper loaded: file_helper
INFO - 2024-01-14 13:33:01 --> Helper loaded: html_helper
INFO - 2024-01-14 13:33:01 --> Helper loaded: text_helper
INFO - 2024-01-14 13:33:01 --> Helper loaded: form_helper
INFO - 2024-01-14 13:33:01 --> Helper loaded: lang_helper
INFO - 2024-01-14 13:33:01 --> Helper loaded: security_helper
INFO - 2024-01-14 13:33:01 --> Helper loaded: cookie_helper
INFO - 2024-01-14 13:33:01 --> Database Driver Class Initialized
INFO - 2024-01-14 13:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 13:33:01 --> Parser Class Initialized
INFO - 2024-01-14 13:33:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 13:33:01 --> Pagination Class Initialized
INFO - 2024-01-14 13:33:01 --> Form Validation Class Initialized
INFO - 2024-01-14 13:33:01 --> Controller Class Initialized
DEBUG - 2024-01-14 13:33:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 13:33:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:33:01 --> Model Class Initialized
DEBUG - 2024-01-14 13:33:01 --> Lgift class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:33:01 --> Model Class Initialized
DEBUG - 2024-01-14 13:33:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 13:33:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:33:01 --> Model Class Initialized
DEBUG - 2024-01-14 13:33:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:33:01 --> Model Class Initialized
INFO - 2024-01-14 13:33:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/gift.php
DEBUG - 2024-01-14 13:33:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:33:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-14 13:33:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-14 13:33:01 --> Model Class Initialized
INFO - 2024-01-14 13:33:01 --> Model Class Initialized
INFO - 2024-01-14 13:33:01 --> Model Class Initialized
INFO - 2024-01-14 13:33:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-14 13:33:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-14 13:33:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-14 13:33:01 --> Final output sent to browser
DEBUG - 2024-01-14 13:33:01 --> Total execution time: 0.1521
ERROR - 2024-01-14 13:33:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 13:33:02 --> Config Class Initialized
INFO - 2024-01-14 13:33:02 --> Hooks Class Initialized
DEBUG - 2024-01-14 13:33:02 --> UTF-8 Support Enabled
INFO - 2024-01-14 13:33:02 --> Utf8 Class Initialized
INFO - 2024-01-14 13:33:02 --> URI Class Initialized
INFO - 2024-01-14 13:33:02 --> Router Class Initialized
INFO - 2024-01-14 13:33:02 --> Output Class Initialized
INFO - 2024-01-14 13:33:02 --> Security Class Initialized
DEBUG - 2024-01-14 13:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 13:33:02 --> Input Class Initialized
INFO - 2024-01-14 13:33:02 --> Language Class Initialized
INFO - 2024-01-14 13:33:02 --> Loader Class Initialized
INFO - 2024-01-14 13:33:02 --> Helper loaded: url_helper
INFO - 2024-01-14 13:33:02 --> Helper loaded: file_helper
INFO - 2024-01-14 13:33:02 --> Helper loaded: html_helper
INFO - 2024-01-14 13:33:02 --> Helper loaded: text_helper
INFO - 2024-01-14 13:33:02 --> Helper loaded: form_helper
INFO - 2024-01-14 13:33:02 --> Helper loaded: lang_helper
INFO - 2024-01-14 13:33:02 --> Helper loaded: security_helper
INFO - 2024-01-14 13:33:02 --> Helper loaded: cookie_helper
INFO - 2024-01-14 13:33:02 --> Database Driver Class Initialized
INFO - 2024-01-14 13:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 13:33:02 --> Parser Class Initialized
INFO - 2024-01-14 13:33:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 13:33:02 --> Pagination Class Initialized
INFO - 2024-01-14 13:33:02 --> Form Validation Class Initialized
INFO - 2024-01-14 13:33:02 --> Controller Class Initialized
DEBUG - 2024-01-14 13:33:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 13:33:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:33:02 --> Model Class Initialized
INFO - 2024-01-14 13:33:02 --> Final output sent to browser
DEBUG - 2024-01-14 13:33:02 --> Total execution time: 0.0212
ERROR - 2024-01-14 13:34:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 13:34:18 --> Config Class Initialized
INFO - 2024-01-14 13:34:18 --> Hooks Class Initialized
DEBUG - 2024-01-14 13:34:18 --> UTF-8 Support Enabled
INFO - 2024-01-14 13:34:18 --> Utf8 Class Initialized
INFO - 2024-01-14 13:34:18 --> URI Class Initialized
INFO - 2024-01-14 13:34:18 --> Router Class Initialized
INFO - 2024-01-14 13:34:18 --> Output Class Initialized
INFO - 2024-01-14 13:34:18 --> Security Class Initialized
DEBUG - 2024-01-14 13:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 13:34:18 --> Input Class Initialized
INFO - 2024-01-14 13:34:18 --> Language Class Initialized
INFO - 2024-01-14 13:34:18 --> Loader Class Initialized
INFO - 2024-01-14 13:34:18 --> Helper loaded: url_helper
INFO - 2024-01-14 13:34:18 --> Helper loaded: file_helper
INFO - 2024-01-14 13:34:18 --> Helper loaded: html_helper
INFO - 2024-01-14 13:34:18 --> Helper loaded: text_helper
INFO - 2024-01-14 13:34:18 --> Helper loaded: form_helper
INFO - 2024-01-14 13:34:18 --> Helper loaded: lang_helper
INFO - 2024-01-14 13:34:18 --> Helper loaded: security_helper
INFO - 2024-01-14 13:34:18 --> Helper loaded: cookie_helper
INFO - 2024-01-14 13:34:18 --> Database Driver Class Initialized
INFO - 2024-01-14 13:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 13:34:18 --> Parser Class Initialized
INFO - 2024-01-14 13:34:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 13:34:18 --> Pagination Class Initialized
INFO - 2024-01-14 13:34:18 --> Form Validation Class Initialized
INFO - 2024-01-14 13:34:18 --> Controller Class Initialized
INFO - 2024-01-14 13:34:18 --> Model Class Initialized
DEBUG - 2024-01-14 13:34:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:34:18 --> Model Class Initialized
DEBUG - 2024-01-14 13:34:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:34:18 --> Model Class Initialized
INFO - 2024-01-14 13:34:18 --> Model Class Initialized
INFO - 2024-01-14 13:34:18 --> Model Class Initialized
INFO - 2024-01-14 13:34:18 --> Model Class Initialized
DEBUG - 2024-01-14 13:34:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 13:34:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:34:18 --> Model Class Initialized
INFO - 2024-01-14 13:34:18 --> Model Class Initialized
INFO - 2024-01-14 13:34:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-14 13:34:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:34:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-14 13:34:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-14 13:34:18 --> Model Class Initialized
INFO - 2024-01-14 13:34:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-14 13:34:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-14 13:34:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-14 13:34:18 --> Final output sent to browser
DEBUG - 2024-01-14 13:34:18 --> Total execution time: 0.2252
ERROR - 2024-01-14 13:34:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 13:34:27 --> Config Class Initialized
INFO - 2024-01-14 13:34:27 --> Hooks Class Initialized
DEBUG - 2024-01-14 13:34:27 --> UTF-8 Support Enabled
INFO - 2024-01-14 13:34:27 --> Utf8 Class Initialized
INFO - 2024-01-14 13:34:27 --> URI Class Initialized
DEBUG - 2024-01-14 13:34:27 --> No URI present. Default controller set.
INFO - 2024-01-14 13:34:27 --> Router Class Initialized
INFO - 2024-01-14 13:34:27 --> Output Class Initialized
INFO - 2024-01-14 13:34:27 --> Security Class Initialized
DEBUG - 2024-01-14 13:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 13:34:27 --> Input Class Initialized
INFO - 2024-01-14 13:34:27 --> Language Class Initialized
INFO - 2024-01-14 13:34:27 --> Loader Class Initialized
INFO - 2024-01-14 13:34:27 --> Helper loaded: url_helper
INFO - 2024-01-14 13:34:27 --> Helper loaded: file_helper
INFO - 2024-01-14 13:34:27 --> Helper loaded: html_helper
INFO - 2024-01-14 13:34:27 --> Helper loaded: text_helper
INFO - 2024-01-14 13:34:27 --> Helper loaded: form_helper
INFO - 2024-01-14 13:34:27 --> Helper loaded: lang_helper
INFO - 2024-01-14 13:34:27 --> Helper loaded: security_helper
INFO - 2024-01-14 13:34:27 --> Helper loaded: cookie_helper
INFO - 2024-01-14 13:34:27 --> Database Driver Class Initialized
INFO - 2024-01-14 13:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 13:34:27 --> Parser Class Initialized
INFO - 2024-01-14 13:34:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 13:34:27 --> Pagination Class Initialized
INFO - 2024-01-14 13:34:27 --> Form Validation Class Initialized
INFO - 2024-01-14 13:34:27 --> Controller Class Initialized
INFO - 2024-01-14 13:34:27 --> Model Class Initialized
DEBUG - 2024-01-14 13:34:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:34:27 --> Model Class Initialized
DEBUG - 2024-01-14 13:34:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:34:27 --> Model Class Initialized
INFO - 2024-01-14 13:34:27 --> Model Class Initialized
INFO - 2024-01-14 13:34:27 --> Model Class Initialized
INFO - 2024-01-14 13:34:27 --> Model Class Initialized
DEBUG - 2024-01-14 13:34:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 13:34:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:34:27 --> Model Class Initialized
INFO - 2024-01-14 13:34:27 --> Model Class Initialized
INFO - 2024-01-14 13:34:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-14 13:34:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:34:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-14 13:34:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-14 13:34:27 --> Model Class Initialized
INFO - 2024-01-14 13:34:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-14 13:34:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-14 13:34:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-14 13:34:27 --> Final output sent to browser
DEBUG - 2024-01-14 13:34:27 --> Total execution time: 0.2170
ERROR - 2024-01-14 13:34:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 13:34:56 --> Config Class Initialized
INFO - 2024-01-14 13:34:56 --> Hooks Class Initialized
DEBUG - 2024-01-14 13:34:56 --> UTF-8 Support Enabled
INFO - 2024-01-14 13:34:56 --> Utf8 Class Initialized
INFO - 2024-01-14 13:34:56 --> URI Class Initialized
DEBUG - 2024-01-14 13:34:56 --> No URI present. Default controller set.
INFO - 2024-01-14 13:34:56 --> Router Class Initialized
INFO - 2024-01-14 13:34:56 --> Output Class Initialized
INFO - 2024-01-14 13:34:56 --> Security Class Initialized
DEBUG - 2024-01-14 13:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 13:34:56 --> Input Class Initialized
INFO - 2024-01-14 13:34:56 --> Language Class Initialized
INFO - 2024-01-14 13:34:56 --> Loader Class Initialized
INFO - 2024-01-14 13:34:56 --> Helper loaded: url_helper
INFO - 2024-01-14 13:34:56 --> Helper loaded: file_helper
INFO - 2024-01-14 13:34:56 --> Helper loaded: html_helper
INFO - 2024-01-14 13:34:56 --> Helper loaded: text_helper
INFO - 2024-01-14 13:34:56 --> Helper loaded: form_helper
INFO - 2024-01-14 13:34:56 --> Helper loaded: lang_helper
INFO - 2024-01-14 13:34:56 --> Helper loaded: security_helper
INFO - 2024-01-14 13:34:56 --> Helper loaded: cookie_helper
INFO - 2024-01-14 13:34:56 --> Database Driver Class Initialized
INFO - 2024-01-14 13:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 13:34:56 --> Parser Class Initialized
INFO - 2024-01-14 13:34:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 13:34:56 --> Pagination Class Initialized
INFO - 2024-01-14 13:34:56 --> Form Validation Class Initialized
INFO - 2024-01-14 13:34:56 --> Controller Class Initialized
INFO - 2024-01-14 13:34:56 --> Model Class Initialized
DEBUG - 2024-01-14 13:34:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:34:56 --> Model Class Initialized
DEBUG - 2024-01-14 13:34:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:34:56 --> Model Class Initialized
INFO - 2024-01-14 13:34:56 --> Model Class Initialized
INFO - 2024-01-14 13:34:56 --> Model Class Initialized
INFO - 2024-01-14 13:34:56 --> Model Class Initialized
DEBUG - 2024-01-14 13:34:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 13:34:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:34:56 --> Model Class Initialized
INFO - 2024-01-14 13:34:56 --> Model Class Initialized
INFO - 2024-01-14 13:34:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-14 13:34:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:34:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-14 13:34:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-14 13:34:56 --> Model Class Initialized
INFO - 2024-01-14 13:34:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-14 13:34:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-14 13:34:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-14 13:34:56 --> Final output sent to browser
DEBUG - 2024-01-14 13:34:56 --> Total execution time: 0.2249
ERROR - 2024-01-14 13:35:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 13:35:20 --> Config Class Initialized
INFO - 2024-01-14 13:35:20 --> Hooks Class Initialized
DEBUG - 2024-01-14 13:35:20 --> UTF-8 Support Enabled
INFO - 2024-01-14 13:35:20 --> Utf8 Class Initialized
INFO - 2024-01-14 13:35:20 --> URI Class Initialized
INFO - 2024-01-14 13:35:20 --> Router Class Initialized
INFO - 2024-01-14 13:35:20 --> Output Class Initialized
INFO - 2024-01-14 13:35:20 --> Security Class Initialized
DEBUG - 2024-01-14 13:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 13:35:20 --> Input Class Initialized
INFO - 2024-01-14 13:35:20 --> Language Class Initialized
INFO - 2024-01-14 13:35:20 --> Loader Class Initialized
INFO - 2024-01-14 13:35:20 --> Helper loaded: url_helper
INFO - 2024-01-14 13:35:20 --> Helper loaded: file_helper
INFO - 2024-01-14 13:35:20 --> Helper loaded: html_helper
INFO - 2024-01-14 13:35:20 --> Helper loaded: text_helper
INFO - 2024-01-14 13:35:20 --> Helper loaded: form_helper
INFO - 2024-01-14 13:35:20 --> Helper loaded: lang_helper
INFO - 2024-01-14 13:35:20 --> Helper loaded: security_helper
INFO - 2024-01-14 13:35:20 --> Helper loaded: cookie_helper
INFO - 2024-01-14 13:35:20 --> Database Driver Class Initialized
INFO - 2024-01-14 13:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 13:35:20 --> Parser Class Initialized
INFO - 2024-01-14 13:35:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 13:35:20 --> Pagination Class Initialized
INFO - 2024-01-14 13:35:20 --> Form Validation Class Initialized
INFO - 2024-01-14 13:35:20 --> Controller Class Initialized
INFO - 2024-01-14 13:35:20 --> Model Class Initialized
DEBUG - 2024-01-14 13:35:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 13:35:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:35:20 --> Model Class Initialized
INFO - 2024-01-14 13:35:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest.php
DEBUG - 2024-01-14 13:35:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:35:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-14 13:35:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-14 13:35:20 --> Model Class Initialized
INFO - 2024-01-14 13:35:20 --> Model Class Initialized
INFO - 2024-01-14 13:35:20 --> Model Class Initialized
INFO - 2024-01-14 13:35:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-14 13:35:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-14 13:35:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-14 13:35:20 --> Final output sent to browser
DEBUG - 2024-01-14 13:35:20 --> Total execution time: 0.1445
ERROR - 2024-01-14 13:35:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 13:35:21 --> Config Class Initialized
INFO - 2024-01-14 13:35:21 --> Hooks Class Initialized
DEBUG - 2024-01-14 13:35:21 --> UTF-8 Support Enabled
INFO - 2024-01-14 13:35:21 --> Utf8 Class Initialized
INFO - 2024-01-14 13:35:21 --> URI Class Initialized
INFO - 2024-01-14 13:35:21 --> Router Class Initialized
INFO - 2024-01-14 13:35:21 --> Output Class Initialized
INFO - 2024-01-14 13:35:21 --> Security Class Initialized
DEBUG - 2024-01-14 13:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 13:35:21 --> Input Class Initialized
INFO - 2024-01-14 13:35:21 --> Language Class Initialized
INFO - 2024-01-14 13:35:21 --> Loader Class Initialized
INFO - 2024-01-14 13:35:21 --> Helper loaded: url_helper
INFO - 2024-01-14 13:35:21 --> Helper loaded: file_helper
INFO - 2024-01-14 13:35:21 --> Helper loaded: html_helper
INFO - 2024-01-14 13:35:21 --> Helper loaded: text_helper
INFO - 2024-01-14 13:35:21 --> Helper loaded: form_helper
INFO - 2024-01-14 13:35:21 --> Helper loaded: lang_helper
INFO - 2024-01-14 13:35:21 --> Helper loaded: security_helper
INFO - 2024-01-14 13:35:21 --> Helper loaded: cookie_helper
INFO - 2024-01-14 13:35:21 --> Database Driver Class Initialized
INFO - 2024-01-14 13:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 13:35:21 --> Parser Class Initialized
INFO - 2024-01-14 13:35:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 13:35:21 --> Pagination Class Initialized
INFO - 2024-01-14 13:35:21 --> Form Validation Class Initialized
INFO - 2024-01-14 13:35:21 --> Controller Class Initialized
INFO - 2024-01-14 13:35:21 --> Model Class Initialized
DEBUG - 2024-01-14 13:35:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 13:35:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:35:21 --> Model Class Initialized
INFO - 2024-01-14 13:35:21 --> Final output sent to browser
DEBUG - 2024-01-14 13:35:21 --> Total execution time: 0.0167
ERROR - 2024-01-14 13:35:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 13:35:39 --> Config Class Initialized
INFO - 2024-01-14 13:35:39 --> Hooks Class Initialized
DEBUG - 2024-01-14 13:35:39 --> UTF-8 Support Enabled
INFO - 2024-01-14 13:35:39 --> Utf8 Class Initialized
INFO - 2024-01-14 13:35:39 --> URI Class Initialized
DEBUG - 2024-01-14 13:35:39 --> No URI present. Default controller set.
INFO - 2024-01-14 13:35:39 --> Router Class Initialized
INFO - 2024-01-14 13:35:39 --> Output Class Initialized
INFO - 2024-01-14 13:35:39 --> Security Class Initialized
DEBUG - 2024-01-14 13:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 13:35:39 --> Input Class Initialized
INFO - 2024-01-14 13:35:39 --> Language Class Initialized
INFO - 2024-01-14 13:35:39 --> Loader Class Initialized
INFO - 2024-01-14 13:35:39 --> Helper loaded: url_helper
INFO - 2024-01-14 13:35:39 --> Helper loaded: file_helper
INFO - 2024-01-14 13:35:39 --> Helper loaded: html_helper
INFO - 2024-01-14 13:35:39 --> Helper loaded: text_helper
INFO - 2024-01-14 13:35:39 --> Helper loaded: form_helper
INFO - 2024-01-14 13:35:39 --> Helper loaded: lang_helper
INFO - 2024-01-14 13:35:39 --> Helper loaded: security_helper
INFO - 2024-01-14 13:35:39 --> Helper loaded: cookie_helper
INFO - 2024-01-14 13:35:39 --> Database Driver Class Initialized
INFO - 2024-01-14 13:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 13:35:39 --> Parser Class Initialized
INFO - 2024-01-14 13:35:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 13:35:39 --> Pagination Class Initialized
INFO - 2024-01-14 13:35:39 --> Form Validation Class Initialized
INFO - 2024-01-14 13:35:39 --> Controller Class Initialized
INFO - 2024-01-14 13:35:39 --> Model Class Initialized
DEBUG - 2024-01-14 13:35:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:35:39 --> Model Class Initialized
DEBUG - 2024-01-14 13:35:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:35:39 --> Model Class Initialized
INFO - 2024-01-14 13:35:39 --> Model Class Initialized
INFO - 2024-01-14 13:35:39 --> Model Class Initialized
INFO - 2024-01-14 13:35:39 --> Model Class Initialized
DEBUG - 2024-01-14 13:35:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 13:35:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:35:39 --> Model Class Initialized
INFO - 2024-01-14 13:35:39 --> Model Class Initialized
INFO - 2024-01-14 13:35:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-14 13:35:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:35:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-14 13:35:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-14 13:35:39 --> Model Class Initialized
INFO - 2024-01-14 13:35:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-14 13:35:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-14 13:35:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-14 13:35:39 --> Final output sent to browser
DEBUG - 2024-01-14 13:35:39 --> Total execution time: 0.2463
ERROR - 2024-01-14 13:35:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 13:35:59 --> Config Class Initialized
INFO - 2024-01-14 13:35:59 --> Hooks Class Initialized
DEBUG - 2024-01-14 13:35:59 --> UTF-8 Support Enabled
INFO - 2024-01-14 13:35:59 --> Utf8 Class Initialized
INFO - 2024-01-14 13:35:59 --> URI Class Initialized
DEBUG - 2024-01-14 13:35:59 --> No URI present. Default controller set.
INFO - 2024-01-14 13:35:59 --> Router Class Initialized
INFO - 2024-01-14 13:35:59 --> Output Class Initialized
INFO - 2024-01-14 13:35:59 --> Security Class Initialized
DEBUG - 2024-01-14 13:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 13:35:59 --> Input Class Initialized
INFO - 2024-01-14 13:35:59 --> Language Class Initialized
INFO - 2024-01-14 13:35:59 --> Loader Class Initialized
INFO - 2024-01-14 13:35:59 --> Helper loaded: url_helper
INFO - 2024-01-14 13:35:59 --> Helper loaded: file_helper
INFO - 2024-01-14 13:35:59 --> Helper loaded: html_helper
INFO - 2024-01-14 13:35:59 --> Helper loaded: text_helper
INFO - 2024-01-14 13:35:59 --> Helper loaded: form_helper
INFO - 2024-01-14 13:35:59 --> Helper loaded: lang_helper
INFO - 2024-01-14 13:35:59 --> Helper loaded: security_helper
INFO - 2024-01-14 13:35:59 --> Helper loaded: cookie_helper
INFO - 2024-01-14 13:35:59 --> Database Driver Class Initialized
INFO - 2024-01-14 13:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 13:35:59 --> Parser Class Initialized
INFO - 2024-01-14 13:35:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 13:35:59 --> Pagination Class Initialized
INFO - 2024-01-14 13:35:59 --> Form Validation Class Initialized
INFO - 2024-01-14 13:35:59 --> Controller Class Initialized
INFO - 2024-01-14 13:35:59 --> Model Class Initialized
DEBUG - 2024-01-14 13:35:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:35:59 --> Model Class Initialized
DEBUG - 2024-01-14 13:35:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:35:59 --> Model Class Initialized
INFO - 2024-01-14 13:35:59 --> Model Class Initialized
INFO - 2024-01-14 13:35:59 --> Model Class Initialized
INFO - 2024-01-14 13:35:59 --> Model Class Initialized
DEBUG - 2024-01-14 13:35:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 13:35:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:35:59 --> Model Class Initialized
INFO - 2024-01-14 13:35:59 --> Model Class Initialized
INFO - 2024-01-14 13:35:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-14 13:35:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:35:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-14 13:35:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-14 13:35:59 --> Model Class Initialized
INFO - 2024-01-14 13:36:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-14 13:36:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-14 13:36:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-14 13:36:00 --> Final output sent to browser
DEBUG - 2024-01-14 13:36:00 --> Total execution time: 0.2242
ERROR - 2024-01-14 13:36:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 13:36:37 --> Config Class Initialized
INFO - 2024-01-14 13:36:37 --> Hooks Class Initialized
DEBUG - 2024-01-14 13:36:37 --> UTF-8 Support Enabled
INFO - 2024-01-14 13:36:37 --> Utf8 Class Initialized
INFO - 2024-01-14 13:36:37 --> URI Class Initialized
INFO - 2024-01-14 13:36:37 --> Router Class Initialized
INFO - 2024-01-14 13:36:37 --> Output Class Initialized
INFO - 2024-01-14 13:36:37 --> Security Class Initialized
DEBUG - 2024-01-14 13:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 13:36:37 --> Input Class Initialized
INFO - 2024-01-14 13:36:37 --> Language Class Initialized
INFO - 2024-01-14 13:36:37 --> Loader Class Initialized
INFO - 2024-01-14 13:36:37 --> Helper loaded: url_helper
INFO - 2024-01-14 13:36:37 --> Helper loaded: file_helper
INFO - 2024-01-14 13:36:37 --> Helper loaded: html_helper
INFO - 2024-01-14 13:36:37 --> Helper loaded: text_helper
INFO - 2024-01-14 13:36:37 --> Helper loaded: form_helper
INFO - 2024-01-14 13:36:37 --> Helper loaded: lang_helper
INFO - 2024-01-14 13:36:37 --> Helper loaded: security_helper
INFO - 2024-01-14 13:36:37 --> Helper loaded: cookie_helper
INFO - 2024-01-14 13:36:37 --> Database Driver Class Initialized
INFO - 2024-01-14 13:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 13:36:37 --> Parser Class Initialized
INFO - 2024-01-14 13:36:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 13:36:37 --> Pagination Class Initialized
INFO - 2024-01-14 13:36:37 --> Form Validation Class Initialized
INFO - 2024-01-14 13:36:37 --> Controller Class Initialized
DEBUG - 2024-01-14 13:36:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 13:36:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:36:37 --> Model Class Initialized
DEBUG - 2024-01-14 13:36:37 --> Lgift class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:36:37 --> Model Class Initialized
DEBUG - 2024-01-14 13:36:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 13:36:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:36:37 --> Model Class Initialized
DEBUG - 2024-01-14 13:36:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:36:37 --> Model Class Initialized
INFO - 2024-01-14 13:36:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/gift.php
DEBUG - 2024-01-14 13:36:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:36:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-14 13:36:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-14 13:36:37 --> Model Class Initialized
INFO - 2024-01-14 13:36:37 --> Model Class Initialized
INFO - 2024-01-14 13:36:37 --> Model Class Initialized
INFO - 2024-01-14 13:36:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-14 13:36:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-14 13:36:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-14 13:36:37 --> Final output sent to browser
DEBUG - 2024-01-14 13:36:37 --> Total execution time: 0.1396
ERROR - 2024-01-14 13:36:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 13:36:38 --> Config Class Initialized
INFO - 2024-01-14 13:36:38 --> Hooks Class Initialized
DEBUG - 2024-01-14 13:36:38 --> UTF-8 Support Enabled
INFO - 2024-01-14 13:36:38 --> Utf8 Class Initialized
INFO - 2024-01-14 13:36:38 --> URI Class Initialized
INFO - 2024-01-14 13:36:38 --> Router Class Initialized
INFO - 2024-01-14 13:36:38 --> Output Class Initialized
INFO - 2024-01-14 13:36:38 --> Security Class Initialized
DEBUG - 2024-01-14 13:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 13:36:38 --> Input Class Initialized
INFO - 2024-01-14 13:36:38 --> Language Class Initialized
INFO - 2024-01-14 13:36:38 --> Loader Class Initialized
INFO - 2024-01-14 13:36:38 --> Helper loaded: url_helper
INFO - 2024-01-14 13:36:38 --> Helper loaded: file_helper
INFO - 2024-01-14 13:36:38 --> Helper loaded: html_helper
INFO - 2024-01-14 13:36:38 --> Helper loaded: text_helper
INFO - 2024-01-14 13:36:38 --> Helper loaded: form_helper
INFO - 2024-01-14 13:36:38 --> Helper loaded: lang_helper
INFO - 2024-01-14 13:36:38 --> Helper loaded: security_helper
INFO - 2024-01-14 13:36:38 --> Helper loaded: cookie_helper
INFO - 2024-01-14 13:36:38 --> Database Driver Class Initialized
INFO - 2024-01-14 13:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 13:36:38 --> Parser Class Initialized
INFO - 2024-01-14 13:36:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 13:36:38 --> Pagination Class Initialized
INFO - 2024-01-14 13:36:38 --> Form Validation Class Initialized
INFO - 2024-01-14 13:36:38 --> Controller Class Initialized
DEBUG - 2024-01-14 13:36:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 13:36:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:36:38 --> Model Class Initialized
INFO - 2024-01-14 13:36:38 --> Final output sent to browser
DEBUG - 2024-01-14 13:36:38 --> Total execution time: 0.0205
ERROR - 2024-01-14 13:37:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 13:37:44 --> Config Class Initialized
INFO - 2024-01-14 13:37:44 --> Hooks Class Initialized
DEBUG - 2024-01-14 13:37:44 --> UTF-8 Support Enabled
INFO - 2024-01-14 13:37:44 --> Utf8 Class Initialized
INFO - 2024-01-14 13:37:44 --> URI Class Initialized
DEBUG - 2024-01-14 13:37:44 --> No URI present. Default controller set.
INFO - 2024-01-14 13:37:44 --> Router Class Initialized
INFO - 2024-01-14 13:37:44 --> Output Class Initialized
INFO - 2024-01-14 13:37:44 --> Security Class Initialized
DEBUG - 2024-01-14 13:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 13:37:44 --> Input Class Initialized
INFO - 2024-01-14 13:37:44 --> Language Class Initialized
INFO - 2024-01-14 13:37:44 --> Loader Class Initialized
INFO - 2024-01-14 13:37:44 --> Helper loaded: url_helper
INFO - 2024-01-14 13:37:44 --> Helper loaded: file_helper
INFO - 2024-01-14 13:37:44 --> Helper loaded: html_helper
INFO - 2024-01-14 13:37:44 --> Helper loaded: text_helper
INFO - 2024-01-14 13:37:44 --> Helper loaded: form_helper
INFO - 2024-01-14 13:37:44 --> Helper loaded: lang_helper
INFO - 2024-01-14 13:37:44 --> Helper loaded: security_helper
INFO - 2024-01-14 13:37:44 --> Helper loaded: cookie_helper
INFO - 2024-01-14 13:37:44 --> Database Driver Class Initialized
INFO - 2024-01-14 13:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 13:37:44 --> Parser Class Initialized
INFO - 2024-01-14 13:37:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 13:37:44 --> Pagination Class Initialized
INFO - 2024-01-14 13:37:44 --> Form Validation Class Initialized
INFO - 2024-01-14 13:37:44 --> Controller Class Initialized
INFO - 2024-01-14 13:37:44 --> Model Class Initialized
DEBUG - 2024-01-14 13:37:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:37:44 --> Model Class Initialized
DEBUG - 2024-01-14 13:37:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:37:44 --> Model Class Initialized
INFO - 2024-01-14 13:37:44 --> Model Class Initialized
INFO - 2024-01-14 13:37:44 --> Model Class Initialized
INFO - 2024-01-14 13:37:44 --> Model Class Initialized
DEBUG - 2024-01-14 13:37:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 13:37:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:37:44 --> Model Class Initialized
INFO - 2024-01-14 13:37:44 --> Model Class Initialized
INFO - 2024-01-14 13:37:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-14 13:37:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:37:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-14 13:37:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-14 13:37:44 --> Model Class Initialized
INFO - 2024-01-14 13:37:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-14 13:37:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-14 13:37:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-14 13:37:44 --> Final output sent to browser
DEBUG - 2024-01-14 13:37:44 --> Total execution time: 0.2316
ERROR - 2024-01-14 13:38:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 13:38:16 --> Config Class Initialized
INFO - 2024-01-14 13:38:16 --> Hooks Class Initialized
DEBUG - 2024-01-14 13:38:16 --> UTF-8 Support Enabled
INFO - 2024-01-14 13:38:16 --> Utf8 Class Initialized
INFO - 2024-01-14 13:38:16 --> URI Class Initialized
INFO - 2024-01-14 13:38:16 --> Router Class Initialized
INFO - 2024-01-14 13:38:16 --> Output Class Initialized
INFO - 2024-01-14 13:38:16 --> Security Class Initialized
DEBUG - 2024-01-14 13:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 13:38:16 --> Input Class Initialized
INFO - 2024-01-14 13:38:16 --> Language Class Initialized
INFO - 2024-01-14 13:38:16 --> Loader Class Initialized
INFO - 2024-01-14 13:38:16 --> Helper loaded: url_helper
INFO - 2024-01-14 13:38:16 --> Helper loaded: file_helper
INFO - 2024-01-14 13:38:16 --> Helper loaded: html_helper
INFO - 2024-01-14 13:38:16 --> Helper loaded: text_helper
INFO - 2024-01-14 13:38:16 --> Helper loaded: form_helper
INFO - 2024-01-14 13:38:16 --> Helper loaded: lang_helper
INFO - 2024-01-14 13:38:16 --> Helper loaded: security_helper
INFO - 2024-01-14 13:38:16 --> Helper loaded: cookie_helper
INFO - 2024-01-14 13:38:16 --> Database Driver Class Initialized
INFO - 2024-01-14 13:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 13:38:16 --> Parser Class Initialized
INFO - 2024-01-14 13:38:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 13:38:16 --> Pagination Class Initialized
INFO - 2024-01-14 13:38:16 --> Form Validation Class Initialized
INFO - 2024-01-14 13:38:16 --> Controller Class Initialized
INFO - 2024-01-14 13:38:16 --> Model Class Initialized
DEBUG - 2024-01-14 13:38:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 13:38:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:38:16 --> Model Class Initialized
DEBUG - 2024-01-14 13:38:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:38:16 --> Model Class Initialized
INFO - 2024-01-14 13:38:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2024-01-14 13:38:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:38:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-14 13:38:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-14 13:38:16 --> Model Class Initialized
INFO - 2024-01-14 13:38:16 --> Model Class Initialized
INFO - 2024-01-14 13:38:16 --> Model Class Initialized
INFO - 2024-01-14 13:38:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-14 13:38:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-14 13:38:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-14 13:38:16 --> Final output sent to browser
DEBUG - 2024-01-14 13:38:16 --> Total execution time: 0.1532
ERROR - 2024-01-14 13:38:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 13:38:16 --> Config Class Initialized
INFO - 2024-01-14 13:38:16 --> Hooks Class Initialized
DEBUG - 2024-01-14 13:38:16 --> UTF-8 Support Enabled
INFO - 2024-01-14 13:38:16 --> Utf8 Class Initialized
INFO - 2024-01-14 13:38:16 --> URI Class Initialized
INFO - 2024-01-14 13:38:16 --> Router Class Initialized
INFO - 2024-01-14 13:38:16 --> Output Class Initialized
INFO - 2024-01-14 13:38:16 --> Security Class Initialized
DEBUG - 2024-01-14 13:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 13:38:16 --> Input Class Initialized
INFO - 2024-01-14 13:38:16 --> Language Class Initialized
INFO - 2024-01-14 13:38:16 --> Loader Class Initialized
INFO - 2024-01-14 13:38:16 --> Helper loaded: url_helper
INFO - 2024-01-14 13:38:16 --> Helper loaded: file_helper
INFO - 2024-01-14 13:38:16 --> Helper loaded: html_helper
INFO - 2024-01-14 13:38:16 --> Helper loaded: text_helper
INFO - 2024-01-14 13:38:16 --> Helper loaded: form_helper
INFO - 2024-01-14 13:38:16 --> Helper loaded: lang_helper
INFO - 2024-01-14 13:38:16 --> Helper loaded: security_helper
INFO - 2024-01-14 13:38:16 --> Helper loaded: cookie_helper
INFO - 2024-01-14 13:38:16 --> Database Driver Class Initialized
INFO - 2024-01-14 13:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 13:38:16 --> Parser Class Initialized
INFO - 2024-01-14 13:38:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 13:38:16 --> Pagination Class Initialized
INFO - 2024-01-14 13:38:16 --> Form Validation Class Initialized
INFO - 2024-01-14 13:38:16 --> Controller Class Initialized
INFO - 2024-01-14 13:38:16 --> Model Class Initialized
DEBUG - 2024-01-14 13:38:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 13:38:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:38:16 --> Model Class Initialized
DEBUG - 2024-01-14 13:38:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:38:16 --> Model Class Initialized
INFO - 2024-01-14 13:38:17 --> Final output sent to browser
DEBUG - 2024-01-14 13:38:17 --> Total execution time: 0.0450
ERROR - 2024-01-14 13:39:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 13:39:28 --> Config Class Initialized
INFO - 2024-01-14 13:39:28 --> Hooks Class Initialized
DEBUG - 2024-01-14 13:39:28 --> UTF-8 Support Enabled
INFO - 2024-01-14 13:39:28 --> Utf8 Class Initialized
INFO - 2024-01-14 13:39:28 --> URI Class Initialized
INFO - 2024-01-14 13:39:28 --> Router Class Initialized
INFO - 2024-01-14 13:39:28 --> Output Class Initialized
INFO - 2024-01-14 13:39:28 --> Security Class Initialized
DEBUG - 2024-01-14 13:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 13:39:28 --> Input Class Initialized
INFO - 2024-01-14 13:39:28 --> Language Class Initialized
INFO - 2024-01-14 13:39:28 --> Loader Class Initialized
INFO - 2024-01-14 13:39:28 --> Helper loaded: url_helper
INFO - 2024-01-14 13:39:28 --> Helper loaded: file_helper
INFO - 2024-01-14 13:39:28 --> Helper loaded: html_helper
INFO - 2024-01-14 13:39:28 --> Helper loaded: text_helper
INFO - 2024-01-14 13:39:28 --> Helper loaded: form_helper
INFO - 2024-01-14 13:39:28 --> Helper loaded: lang_helper
INFO - 2024-01-14 13:39:28 --> Helper loaded: security_helper
INFO - 2024-01-14 13:39:28 --> Helper loaded: cookie_helper
INFO - 2024-01-14 13:39:28 --> Database Driver Class Initialized
INFO - 2024-01-14 13:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 13:39:28 --> Parser Class Initialized
INFO - 2024-01-14 13:39:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 13:39:28 --> Pagination Class Initialized
INFO - 2024-01-14 13:39:28 --> Form Validation Class Initialized
INFO - 2024-01-14 13:39:28 --> Controller Class Initialized
INFO - 2024-01-14 13:39:28 --> Model Class Initialized
DEBUG - 2024-01-14 13:39:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 13:39:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:39:28 --> Model Class Initialized
DEBUG - 2024-01-14 13:39:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:39:28 --> Model Class Initialized
INFO - 2024-01-14 13:39:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html.php
DEBUG - 2024-01-14 13:39:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:39:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-14 13:39:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-14 13:39:28 --> Model Class Initialized
INFO - 2024-01-14 13:39:28 --> Model Class Initialized
INFO - 2024-01-14 13:39:28 --> Model Class Initialized
INFO - 2024-01-14 13:39:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-14 13:39:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-14 13:39:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-14 13:39:28 --> Final output sent to browser
DEBUG - 2024-01-14 13:39:28 --> Total execution time: 0.1551
ERROR - 2024-01-14 13:39:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 13:39:42 --> Config Class Initialized
INFO - 2024-01-14 13:39:42 --> Hooks Class Initialized
DEBUG - 2024-01-14 13:39:42 --> UTF-8 Support Enabled
INFO - 2024-01-14 13:39:42 --> Utf8 Class Initialized
INFO - 2024-01-14 13:39:42 --> URI Class Initialized
INFO - 2024-01-14 13:39:42 --> Router Class Initialized
INFO - 2024-01-14 13:39:42 --> Output Class Initialized
INFO - 2024-01-14 13:39:42 --> Security Class Initialized
DEBUG - 2024-01-14 13:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 13:39:42 --> Input Class Initialized
INFO - 2024-01-14 13:39:42 --> Language Class Initialized
INFO - 2024-01-14 13:39:42 --> Loader Class Initialized
INFO - 2024-01-14 13:39:42 --> Helper loaded: url_helper
INFO - 2024-01-14 13:39:42 --> Helper loaded: file_helper
INFO - 2024-01-14 13:39:42 --> Helper loaded: html_helper
INFO - 2024-01-14 13:39:42 --> Helper loaded: text_helper
INFO - 2024-01-14 13:39:42 --> Helper loaded: form_helper
INFO - 2024-01-14 13:39:42 --> Helper loaded: lang_helper
INFO - 2024-01-14 13:39:42 --> Helper loaded: security_helper
INFO - 2024-01-14 13:39:42 --> Helper loaded: cookie_helper
INFO - 2024-01-14 13:39:42 --> Database Driver Class Initialized
INFO - 2024-01-14 13:39:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 13:39:42 --> Parser Class Initialized
INFO - 2024-01-14 13:39:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 13:39:42 --> Pagination Class Initialized
INFO - 2024-01-14 13:39:42 --> Form Validation Class Initialized
INFO - 2024-01-14 13:39:42 --> Controller Class Initialized
INFO - 2024-01-14 13:39:42 --> Model Class Initialized
DEBUG - 2024-01-14 13:39:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 13:39:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:39:42 --> Model Class Initialized
DEBUG - 2024-01-14 13:39:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:39:42 --> Model Class Initialized
INFO - 2024-01-14 13:39:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2024-01-14 13:39:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:39:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-14 13:39:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-14 13:39:42 --> Model Class Initialized
INFO - 2024-01-14 13:39:42 --> Model Class Initialized
INFO - 2024-01-14 13:39:42 --> Model Class Initialized
INFO - 2024-01-14 13:39:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-14 13:39:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-14 13:39:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-14 13:39:42 --> Final output sent to browser
DEBUG - 2024-01-14 13:39:42 --> Total execution time: 0.1467
ERROR - 2024-01-14 13:39:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 13:39:43 --> Config Class Initialized
INFO - 2024-01-14 13:39:43 --> Hooks Class Initialized
DEBUG - 2024-01-14 13:39:43 --> UTF-8 Support Enabled
INFO - 2024-01-14 13:39:43 --> Utf8 Class Initialized
INFO - 2024-01-14 13:39:43 --> URI Class Initialized
INFO - 2024-01-14 13:39:43 --> Router Class Initialized
INFO - 2024-01-14 13:39:43 --> Output Class Initialized
INFO - 2024-01-14 13:39:43 --> Security Class Initialized
DEBUG - 2024-01-14 13:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 13:39:43 --> Input Class Initialized
INFO - 2024-01-14 13:39:43 --> Language Class Initialized
INFO - 2024-01-14 13:39:43 --> Loader Class Initialized
INFO - 2024-01-14 13:39:43 --> Helper loaded: url_helper
INFO - 2024-01-14 13:39:43 --> Helper loaded: file_helper
INFO - 2024-01-14 13:39:43 --> Helper loaded: html_helper
INFO - 2024-01-14 13:39:43 --> Helper loaded: text_helper
INFO - 2024-01-14 13:39:43 --> Helper loaded: form_helper
INFO - 2024-01-14 13:39:43 --> Helper loaded: lang_helper
INFO - 2024-01-14 13:39:43 --> Helper loaded: security_helper
INFO - 2024-01-14 13:39:43 --> Helper loaded: cookie_helper
INFO - 2024-01-14 13:39:43 --> Database Driver Class Initialized
INFO - 2024-01-14 13:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 13:39:43 --> Parser Class Initialized
INFO - 2024-01-14 13:39:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 13:39:43 --> Pagination Class Initialized
INFO - 2024-01-14 13:39:43 --> Form Validation Class Initialized
INFO - 2024-01-14 13:39:43 --> Controller Class Initialized
INFO - 2024-01-14 13:39:43 --> Model Class Initialized
DEBUG - 2024-01-14 13:39:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 13:39:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:39:43 --> Model Class Initialized
DEBUG - 2024-01-14 13:39:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:39:43 --> Model Class Initialized
INFO - 2024-01-14 13:39:43 --> Final output sent to browser
DEBUG - 2024-01-14 13:39:43 --> Total execution time: 0.0479
ERROR - 2024-01-14 13:39:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 13:39:43 --> Config Class Initialized
INFO - 2024-01-14 13:39:43 --> Hooks Class Initialized
DEBUG - 2024-01-14 13:39:43 --> UTF-8 Support Enabled
INFO - 2024-01-14 13:39:43 --> Utf8 Class Initialized
INFO - 2024-01-14 13:39:43 --> URI Class Initialized
DEBUG - 2024-01-14 13:39:43 --> No URI present. Default controller set.
INFO - 2024-01-14 13:39:43 --> Router Class Initialized
INFO - 2024-01-14 13:39:43 --> Output Class Initialized
INFO - 2024-01-14 13:39:43 --> Security Class Initialized
DEBUG - 2024-01-14 13:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 13:39:43 --> Input Class Initialized
INFO - 2024-01-14 13:39:43 --> Language Class Initialized
INFO - 2024-01-14 13:39:43 --> Loader Class Initialized
INFO - 2024-01-14 13:39:43 --> Helper loaded: url_helper
INFO - 2024-01-14 13:39:43 --> Helper loaded: file_helper
INFO - 2024-01-14 13:39:43 --> Helper loaded: html_helper
INFO - 2024-01-14 13:39:43 --> Helper loaded: text_helper
INFO - 2024-01-14 13:39:43 --> Helper loaded: form_helper
INFO - 2024-01-14 13:39:43 --> Helper loaded: lang_helper
INFO - 2024-01-14 13:39:43 --> Helper loaded: security_helper
INFO - 2024-01-14 13:39:43 --> Helper loaded: cookie_helper
INFO - 2024-01-14 13:39:43 --> Database Driver Class Initialized
INFO - 2024-01-14 13:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 13:39:43 --> Parser Class Initialized
INFO - 2024-01-14 13:39:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 13:39:43 --> Pagination Class Initialized
INFO - 2024-01-14 13:39:43 --> Form Validation Class Initialized
INFO - 2024-01-14 13:39:43 --> Controller Class Initialized
INFO - 2024-01-14 13:39:43 --> Model Class Initialized
DEBUG - 2024-01-14 13:39:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:39:43 --> Model Class Initialized
DEBUG - 2024-01-14 13:39:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:39:43 --> Model Class Initialized
INFO - 2024-01-14 13:39:43 --> Model Class Initialized
INFO - 2024-01-14 13:39:43 --> Model Class Initialized
INFO - 2024-01-14 13:39:43 --> Model Class Initialized
DEBUG - 2024-01-14 13:39:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 13:39:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:39:43 --> Model Class Initialized
INFO - 2024-01-14 13:39:43 --> Model Class Initialized
INFO - 2024-01-14 13:39:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-14 13:39:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:39:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-14 13:39:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-14 13:39:44 --> Model Class Initialized
INFO - 2024-01-14 13:39:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-14 13:39:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-14 13:39:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-14 13:39:44 --> Final output sent to browser
DEBUG - 2024-01-14 13:39:44 --> Total execution time: 0.2158
ERROR - 2024-01-14 13:40:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 13:40:33 --> Config Class Initialized
INFO - 2024-01-14 13:40:33 --> Hooks Class Initialized
DEBUG - 2024-01-14 13:40:33 --> UTF-8 Support Enabled
INFO - 2024-01-14 13:40:33 --> Utf8 Class Initialized
INFO - 2024-01-14 13:40:33 --> URI Class Initialized
INFO - 2024-01-14 13:40:33 --> Router Class Initialized
INFO - 2024-01-14 13:40:33 --> Output Class Initialized
INFO - 2024-01-14 13:40:33 --> Security Class Initialized
DEBUG - 2024-01-14 13:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 13:40:33 --> Input Class Initialized
INFO - 2024-01-14 13:40:33 --> Language Class Initialized
INFO - 2024-01-14 13:40:33 --> Loader Class Initialized
INFO - 2024-01-14 13:40:33 --> Helper loaded: url_helper
INFO - 2024-01-14 13:40:33 --> Helper loaded: file_helper
INFO - 2024-01-14 13:40:33 --> Helper loaded: html_helper
INFO - 2024-01-14 13:40:33 --> Helper loaded: text_helper
INFO - 2024-01-14 13:40:33 --> Helper loaded: form_helper
INFO - 2024-01-14 13:40:33 --> Helper loaded: lang_helper
INFO - 2024-01-14 13:40:33 --> Helper loaded: security_helper
INFO - 2024-01-14 13:40:33 --> Helper loaded: cookie_helper
INFO - 2024-01-14 13:40:33 --> Database Driver Class Initialized
INFO - 2024-01-14 13:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 13:40:33 --> Parser Class Initialized
INFO - 2024-01-14 13:40:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 13:40:33 --> Pagination Class Initialized
INFO - 2024-01-14 13:40:33 --> Form Validation Class Initialized
INFO - 2024-01-14 13:40:33 --> Controller Class Initialized
ERROR - 2024-01-14 13:40:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 13:40:33 --> Config Class Initialized
INFO - 2024-01-14 13:40:33 --> Hooks Class Initialized
DEBUG - 2024-01-14 13:40:33 --> UTF-8 Support Enabled
INFO - 2024-01-14 13:40:33 --> Utf8 Class Initialized
INFO - 2024-01-14 13:40:33 --> URI Class Initialized
INFO - 2024-01-14 13:40:33 --> Router Class Initialized
INFO - 2024-01-14 13:40:33 --> Output Class Initialized
INFO - 2024-01-14 13:40:33 --> Security Class Initialized
DEBUG - 2024-01-14 13:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 13:40:33 --> Input Class Initialized
INFO - 2024-01-14 13:40:33 --> Language Class Initialized
INFO - 2024-01-14 13:40:33 --> Loader Class Initialized
INFO - 2024-01-14 13:40:33 --> Helper loaded: url_helper
INFO - 2024-01-14 13:40:33 --> Helper loaded: file_helper
INFO - 2024-01-14 13:40:33 --> Helper loaded: html_helper
INFO - 2024-01-14 13:40:33 --> Helper loaded: text_helper
INFO - 2024-01-14 13:40:33 --> Helper loaded: form_helper
INFO - 2024-01-14 13:40:33 --> Helper loaded: lang_helper
INFO - 2024-01-14 13:40:33 --> Helper loaded: security_helper
INFO - 2024-01-14 13:40:33 --> Helper loaded: cookie_helper
INFO - 2024-01-14 13:40:33 --> Database Driver Class Initialized
INFO - 2024-01-14 13:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 13:40:33 --> Parser Class Initialized
INFO - 2024-01-14 13:40:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 13:40:33 --> Pagination Class Initialized
INFO - 2024-01-14 13:40:33 --> Form Validation Class Initialized
INFO - 2024-01-14 13:40:33 --> Controller Class Initialized
INFO - 2024-01-14 13:40:33 --> Model Class Initialized
DEBUG - 2024-01-14 13:40:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:40:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-14 13:40:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-14 13:40:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-14 13:40:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-14 13:40:33 --> Model Class Initialized
INFO - 2024-01-14 13:40:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-14 13:40:33 --> Final output sent to browser
DEBUG - 2024-01-14 13:40:33 --> Total execution time: 0.0319
ERROR - 2024-01-14 15:02:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 15:02:13 --> Config Class Initialized
INFO - 2024-01-14 15:02:13 --> Hooks Class Initialized
DEBUG - 2024-01-14 15:02:13 --> UTF-8 Support Enabled
INFO - 2024-01-14 15:02:13 --> Utf8 Class Initialized
INFO - 2024-01-14 15:02:13 --> URI Class Initialized
INFO - 2024-01-14 15:02:13 --> Router Class Initialized
INFO - 2024-01-14 15:02:13 --> Output Class Initialized
INFO - 2024-01-14 15:02:13 --> Security Class Initialized
DEBUG - 2024-01-14 15:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 15:02:13 --> Input Class Initialized
INFO - 2024-01-14 15:02:13 --> Language Class Initialized
INFO - 2024-01-14 15:02:13 --> Loader Class Initialized
INFO - 2024-01-14 15:02:13 --> Helper loaded: url_helper
INFO - 2024-01-14 15:02:13 --> Helper loaded: file_helper
INFO - 2024-01-14 15:02:13 --> Helper loaded: html_helper
INFO - 2024-01-14 15:02:13 --> Helper loaded: text_helper
INFO - 2024-01-14 15:02:13 --> Helper loaded: form_helper
INFO - 2024-01-14 15:02:13 --> Helper loaded: lang_helper
INFO - 2024-01-14 15:02:13 --> Helper loaded: security_helper
INFO - 2024-01-14 15:02:13 --> Helper loaded: cookie_helper
INFO - 2024-01-14 15:02:13 --> Database Driver Class Initialized
INFO - 2024-01-14 15:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 15:02:13 --> Parser Class Initialized
INFO - 2024-01-14 15:02:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 15:02:13 --> Pagination Class Initialized
INFO - 2024-01-14 15:02:13 --> Form Validation Class Initialized
INFO - 2024-01-14 15:02:13 --> Controller Class Initialized
ERROR - 2024-01-14 15:02:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 15:02:15 --> Config Class Initialized
INFO - 2024-01-14 15:02:15 --> Hooks Class Initialized
DEBUG - 2024-01-14 15:02:15 --> UTF-8 Support Enabled
INFO - 2024-01-14 15:02:15 --> Utf8 Class Initialized
INFO - 2024-01-14 15:02:15 --> URI Class Initialized
INFO - 2024-01-14 15:02:15 --> Router Class Initialized
INFO - 2024-01-14 15:02:15 --> Output Class Initialized
INFO - 2024-01-14 15:02:15 --> Security Class Initialized
DEBUG - 2024-01-14 15:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 15:02:15 --> Input Class Initialized
INFO - 2024-01-14 15:02:15 --> Language Class Initialized
INFO - 2024-01-14 15:02:15 --> Loader Class Initialized
INFO - 2024-01-14 15:02:15 --> Helper loaded: url_helper
INFO - 2024-01-14 15:02:15 --> Helper loaded: file_helper
INFO - 2024-01-14 15:02:15 --> Helper loaded: html_helper
INFO - 2024-01-14 15:02:15 --> Helper loaded: text_helper
INFO - 2024-01-14 15:02:15 --> Helper loaded: form_helper
INFO - 2024-01-14 15:02:15 --> Helper loaded: lang_helper
INFO - 2024-01-14 15:02:15 --> Helper loaded: security_helper
INFO - 2024-01-14 15:02:15 --> Helper loaded: cookie_helper
INFO - 2024-01-14 15:02:15 --> Database Driver Class Initialized
INFO - 2024-01-14 15:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 15:02:15 --> Parser Class Initialized
INFO - 2024-01-14 15:02:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 15:02:15 --> Pagination Class Initialized
INFO - 2024-01-14 15:02:15 --> Form Validation Class Initialized
INFO - 2024-01-14 15:02:15 --> Controller Class Initialized
INFO - 2024-01-14 15:02:15 --> Model Class Initialized
DEBUG - 2024-01-14 15:02:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:02:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-14 15:02:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:02:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-14 15:02:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-14 15:02:15 --> Model Class Initialized
INFO - 2024-01-14 15:02:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-14 15:02:15 --> Final output sent to browser
DEBUG - 2024-01-14 15:02:15 --> Total execution time: 0.0367
ERROR - 2024-01-14 15:12:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 15:12:51 --> Config Class Initialized
INFO - 2024-01-14 15:12:51 --> Hooks Class Initialized
DEBUG - 2024-01-14 15:12:51 --> UTF-8 Support Enabled
INFO - 2024-01-14 15:12:51 --> Utf8 Class Initialized
INFO - 2024-01-14 15:12:51 --> URI Class Initialized
DEBUG - 2024-01-14 15:12:51 --> No URI present. Default controller set.
INFO - 2024-01-14 15:12:51 --> Router Class Initialized
INFO - 2024-01-14 15:12:51 --> Output Class Initialized
INFO - 2024-01-14 15:12:51 --> Security Class Initialized
DEBUG - 2024-01-14 15:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 15:12:51 --> Input Class Initialized
INFO - 2024-01-14 15:12:51 --> Language Class Initialized
INFO - 2024-01-14 15:12:51 --> Loader Class Initialized
INFO - 2024-01-14 15:12:51 --> Helper loaded: url_helper
INFO - 2024-01-14 15:12:51 --> Helper loaded: file_helper
INFO - 2024-01-14 15:12:51 --> Helper loaded: html_helper
INFO - 2024-01-14 15:12:51 --> Helper loaded: text_helper
INFO - 2024-01-14 15:12:51 --> Helper loaded: form_helper
INFO - 2024-01-14 15:12:51 --> Helper loaded: lang_helper
INFO - 2024-01-14 15:12:51 --> Helper loaded: security_helper
INFO - 2024-01-14 15:12:51 --> Helper loaded: cookie_helper
INFO - 2024-01-14 15:12:51 --> Database Driver Class Initialized
INFO - 2024-01-14 15:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 15:12:51 --> Parser Class Initialized
INFO - 2024-01-14 15:12:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 15:12:51 --> Pagination Class Initialized
INFO - 2024-01-14 15:12:51 --> Form Validation Class Initialized
INFO - 2024-01-14 15:12:51 --> Controller Class Initialized
INFO - 2024-01-14 15:12:51 --> Model Class Initialized
DEBUG - 2024-01-14 15:12:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-14 15:12:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 15:12:52 --> Config Class Initialized
INFO - 2024-01-14 15:12:52 --> Hooks Class Initialized
DEBUG - 2024-01-14 15:12:52 --> UTF-8 Support Enabled
INFO - 2024-01-14 15:12:52 --> Utf8 Class Initialized
INFO - 2024-01-14 15:12:52 --> URI Class Initialized
INFO - 2024-01-14 15:12:52 --> Router Class Initialized
INFO - 2024-01-14 15:12:52 --> Output Class Initialized
INFO - 2024-01-14 15:12:52 --> Security Class Initialized
DEBUG - 2024-01-14 15:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 15:12:52 --> Input Class Initialized
INFO - 2024-01-14 15:12:52 --> Language Class Initialized
INFO - 2024-01-14 15:12:52 --> Loader Class Initialized
INFO - 2024-01-14 15:12:52 --> Helper loaded: url_helper
INFO - 2024-01-14 15:12:52 --> Helper loaded: file_helper
INFO - 2024-01-14 15:12:52 --> Helper loaded: html_helper
INFO - 2024-01-14 15:12:52 --> Helper loaded: text_helper
INFO - 2024-01-14 15:12:52 --> Helper loaded: form_helper
INFO - 2024-01-14 15:12:52 --> Helper loaded: lang_helper
INFO - 2024-01-14 15:12:52 --> Helper loaded: security_helper
INFO - 2024-01-14 15:12:52 --> Helper loaded: cookie_helper
INFO - 2024-01-14 15:12:52 --> Database Driver Class Initialized
INFO - 2024-01-14 15:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 15:12:52 --> Parser Class Initialized
INFO - 2024-01-14 15:12:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 15:12:52 --> Pagination Class Initialized
INFO - 2024-01-14 15:12:52 --> Form Validation Class Initialized
INFO - 2024-01-14 15:12:52 --> Controller Class Initialized
INFO - 2024-01-14 15:12:52 --> Model Class Initialized
DEBUG - 2024-01-14 15:12:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:12:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-14 15:12:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:12:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-14 15:12:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-14 15:12:52 --> Model Class Initialized
INFO - 2024-01-14 15:12:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-14 15:12:52 --> Final output sent to browser
DEBUG - 2024-01-14 15:12:52 --> Total execution time: 0.0422
ERROR - 2024-01-14 15:12:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 15:12:57 --> Config Class Initialized
INFO - 2024-01-14 15:12:57 --> Hooks Class Initialized
DEBUG - 2024-01-14 15:12:57 --> UTF-8 Support Enabled
INFO - 2024-01-14 15:12:57 --> Utf8 Class Initialized
INFO - 2024-01-14 15:12:57 --> URI Class Initialized
INFO - 2024-01-14 15:12:57 --> Router Class Initialized
INFO - 2024-01-14 15:12:57 --> Output Class Initialized
INFO - 2024-01-14 15:12:57 --> Security Class Initialized
DEBUG - 2024-01-14 15:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 15:12:57 --> Input Class Initialized
INFO - 2024-01-14 15:12:57 --> Language Class Initialized
INFO - 2024-01-14 15:12:57 --> Loader Class Initialized
INFO - 2024-01-14 15:12:57 --> Helper loaded: url_helper
INFO - 2024-01-14 15:12:57 --> Helper loaded: file_helper
INFO - 2024-01-14 15:12:57 --> Helper loaded: html_helper
INFO - 2024-01-14 15:12:57 --> Helper loaded: text_helper
INFO - 2024-01-14 15:12:57 --> Helper loaded: form_helper
INFO - 2024-01-14 15:12:57 --> Helper loaded: lang_helper
INFO - 2024-01-14 15:12:57 --> Helper loaded: security_helper
INFO - 2024-01-14 15:12:57 --> Helper loaded: cookie_helper
INFO - 2024-01-14 15:12:57 --> Database Driver Class Initialized
INFO - 2024-01-14 15:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 15:12:57 --> Parser Class Initialized
INFO - 2024-01-14 15:12:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 15:12:57 --> Pagination Class Initialized
INFO - 2024-01-14 15:12:57 --> Form Validation Class Initialized
INFO - 2024-01-14 15:12:57 --> Controller Class Initialized
INFO - 2024-01-14 15:12:57 --> Model Class Initialized
DEBUG - 2024-01-14 15:12:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:12:57 --> Model Class Initialized
INFO - 2024-01-14 15:12:57 --> Final output sent to browser
DEBUG - 2024-01-14 15:12:57 --> Total execution time: 0.0189
ERROR - 2024-01-14 15:12:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 15:12:57 --> Config Class Initialized
INFO - 2024-01-14 15:12:57 --> Hooks Class Initialized
DEBUG - 2024-01-14 15:12:57 --> UTF-8 Support Enabled
INFO - 2024-01-14 15:12:57 --> Utf8 Class Initialized
INFO - 2024-01-14 15:12:57 --> URI Class Initialized
DEBUG - 2024-01-14 15:12:57 --> No URI present. Default controller set.
INFO - 2024-01-14 15:12:57 --> Router Class Initialized
INFO - 2024-01-14 15:12:57 --> Output Class Initialized
INFO - 2024-01-14 15:12:57 --> Security Class Initialized
DEBUG - 2024-01-14 15:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 15:12:57 --> Input Class Initialized
INFO - 2024-01-14 15:12:57 --> Language Class Initialized
INFO - 2024-01-14 15:12:57 --> Loader Class Initialized
INFO - 2024-01-14 15:12:57 --> Helper loaded: url_helper
INFO - 2024-01-14 15:12:57 --> Helper loaded: file_helper
INFO - 2024-01-14 15:12:57 --> Helper loaded: html_helper
INFO - 2024-01-14 15:12:57 --> Helper loaded: text_helper
INFO - 2024-01-14 15:12:57 --> Helper loaded: form_helper
INFO - 2024-01-14 15:12:57 --> Helper loaded: lang_helper
INFO - 2024-01-14 15:12:57 --> Helper loaded: security_helper
INFO - 2024-01-14 15:12:57 --> Helper loaded: cookie_helper
INFO - 2024-01-14 15:12:57 --> Database Driver Class Initialized
INFO - 2024-01-14 15:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 15:12:57 --> Parser Class Initialized
INFO - 2024-01-14 15:12:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 15:12:57 --> Pagination Class Initialized
INFO - 2024-01-14 15:12:57 --> Form Validation Class Initialized
INFO - 2024-01-14 15:12:57 --> Controller Class Initialized
INFO - 2024-01-14 15:12:57 --> Model Class Initialized
DEBUG - 2024-01-14 15:12:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:12:57 --> Model Class Initialized
DEBUG - 2024-01-14 15:12:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:12:57 --> Model Class Initialized
INFO - 2024-01-14 15:12:57 --> Model Class Initialized
INFO - 2024-01-14 15:12:57 --> Model Class Initialized
INFO - 2024-01-14 15:12:57 --> Model Class Initialized
DEBUG - 2024-01-14 15:12:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 15:12:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:12:57 --> Model Class Initialized
INFO - 2024-01-14 15:12:57 --> Model Class Initialized
INFO - 2024-01-14 15:12:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-14 15:12:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:12:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-14 15:12:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-14 15:12:58 --> Model Class Initialized
INFO - 2024-01-14 15:12:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-14 15:12:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-14 15:12:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-14 15:12:58 --> Final output sent to browser
DEBUG - 2024-01-14 15:12:58 --> Total execution time: 0.4263
ERROR - 2024-01-14 15:13:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 15:13:02 --> Config Class Initialized
INFO - 2024-01-14 15:13:02 --> Hooks Class Initialized
DEBUG - 2024-01-14 15:13:02 --> UTF-8 Support Enabled
INFO - 2024-01-14 15:13:02 --> Utf8 Class Initialized
INFO - 2024-01-14 15:13:02 --> URI Class Initialized
INFO - 2024-01-14 15:13:02 --> Router Class Initialized
INFO - 2024-01-14 15:13:02 --> Output Class Initialized
INFO - 2024-01-14 15:13:02 --> Security Class Initialized
DEBUG - 2024-01-14 15:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 15:13:02 --> Input Class Initialized
INFO - 2024-01-14 15:13:02 --> Language Class Initialized
INFO - 2024-01-14 15:13:02 --> Loader Class Initialized
INFO - 2024-01-14 15:13:02 --> Helper loaded: url_helper
INFO - 2024-01-14 15:13:02 --> Helper loaded: file_helper
INFO - 2024-01-14 15:13:02 --> Helper loaded: html_helper
INFO - 2024-01-14 15:13:02 --> Helper loaded: text_helper
INFO - 2024-01-14 15:13:02 --> Helper loaded: form_helper
INFO - 2024-01-14 15:13:02 --> Helper loaded: lang_helper
INFO - 2024-01-14 15:13:02 --> Helper loaded: security_helper
INFO - 2024-01-14 15:13:02 --> Helper loaded: cookie_helper
INFO - 2024-01-14 15:13:02 --> Database Driver Class Initialized
INFO - 2024-01-14 15:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 15:13:02 --> Parser Class Initialized
INFO - 2024-01-14 15:13:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 15:13:02 --> Pagination Class Initialized
INFO - 2024-01-14 15:13:02 --> Form Validation Class Initialized
INFO - 2024-01-14 15:13:02 --> Controller Class Initialized
DEBUG - 2024-01-14 15:13:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 15:13:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:13:02 --> Model Class Initialized
INFO - 2024-01-14 15:13:02 --> Final output sent to browser
DEBUG - 2024-01-14 15:13:02 --> Total execution time: 0.0144
ERROR - 2024-01-14 15:13:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 15:13:16 --> Config Class Initialized
INFO - 2024-01-14 15:13:16 --> Hooks Class Initialized
DEBUG - 2024-01-14 15:13:16 --> UTF-8 Support Enabled
INFO - 2024-01-14 15:13:16 --> Utf8 Class Initialized
INFO - 2024-01-14 15:13:16 --> URI Class Initialized
INFO - 2024-01-14 15:13:16 --> Router Class Initialized
INFO - 2024-01-14 15:13:16 --> Output Class Initialized
INFO - 2024-01-14 15:13:16 --> Security Class Initialized
DEBUG - 2024-01-14 15:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 15:13:16 --> Input Class Initialized
INFO - 2024-01-14 15:13:16 --> Language Class Initialized
INFO - 2024-01-14 15:13:16 --> Loader Class Initialized
INFO - 2024-01-14 15:13:16 --> Helper loaded: url_helper
INFO - 2024-01-14 15:13:16 --> Helper loaded: file_helper
INFO - 2024-01-14 15:13:16 --> Helper loaded: html_helper
INFO - 2024-01-14 15:13:16 --> Helper loaded: text_helper
INFO - 2024-01-14 15:13:16 --> Helper loaded: form_helper
INFO - 2024-01-14 15:13:16 --> Helper loaded: lang_helper
INFO - 2024-01-14 15:13:16 --> Helper loaded: security_helper
INFO - 2024-01-14 15:13:16 --> Helper loaded: cookie_helper
INFO - 2024-01-14 15:13:16 --> Database Driver Class Initialized
INFO - 2024-01-14 15:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 15:13:16 --> Parser Class Initialized
INFO - 2024-01-14 15:13:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 15:13:16 --> Pagination Class Initialized
INFO - 2024-01-14 15:13:16 --> Form Validation Class Initialized
INFO - 2024-01-14 15:13:16 --> Controller Class Initialized
INFO - 2024-01-14 15:13:16 --> Model Class Initialized
DEBUG - 2024-01-14 15:13:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 15:13:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:13:16 --> Model Class Initialized
INFO - 2024-01-14 15:13:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2024-01-14 15:13:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:13:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-14 15:13:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-14 15:13:16 --> Model Class Initialized
INFO - 2024-01-14 15:13:16 --> Model Class Initialized
INFO - 2024-01-14 15:13:16 --> Model Class Initialized
INFO - 2024-01-14 15:13:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-14 15:13:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-14 15:13:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-14 15:13:16 --> Final output sent to browser
DEBUG - 2024-01-14 15:13:16 --> Total execution time: 0.2300
ERROR - 2024-01-14 15:13:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 15:13:17 --> Config Class Initialized
INFO - 2024-01-14 15:13:17 --> Hooks Class Initialized
DEBUG - 2024-01-14 15:13:17 --> UTF-8 Support Enabled
INFO - 2024-01-14 15:13:17 --> Utf8 Class Initialized
INFO - 2024-01-14 15:13:17 --> URI Class Initialized
INFO - 2024-01-14 15:13:17 --> Router Class Initialized
INFO - 2024-01-14 15:13:17 --> Output Class Initialized
INFO - 2024-01-14 15:13:17 --> Security Class Initialized
DEBUG - 2024-01-14 15:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 15:13:17 --> Input Class Initialized
INFO - 2024-01-14 15:13:17 --> Language Class Initialized
INFO - 2024-01-14 15:13:17 --> Loader Class Initialized
INFO - 2024-01-14 15:13:17 --> Helper loaded: url_helper
INFO - 2024-01-14 15:13:17 --> Helper loaded: file_helper
INFO - 2024-01-14 15:13:17 --> Helper loaded: html_helper
INFO - 2024-01-14 15:13:17 --> Helper loaded: text_helper
INFO - 2024-01-14 15:13:17 --> Helper loaded: form_helper
INFO - 2024-01-14 15:13:17 --> Helper loaded: lang_helper
INFO - 2024-01-14 15:13:17 --> Helper loaded: security_helper
INFO - 2024-01-14 15:13:17 --> Helper loaded: cookie_helper
INFO - 2024-01-14 15:13:17 --> Database Driver Class Initialized
INFO - 2024-01-14 15:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 15:13:17 --> Parser Class Initialized
INFO - 2024-01-14 15:13:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 15:13:17 --> Pagination Class Initialized
INFO - 2024-01-14 15:13:17 --> Form Validation Class Initialized
INFO - 2024-01-14 15:13:17 --> Controller Class Initialized
INFO - 2024-01-14 15:13:17 --> Model Class Initialized
DEBUG - 2024-01-14 15:13:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 15:13:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:13:17 --> Model Class Initialized
INFO - 2024-01-14 15:13:17 --> Final output sent to browser
DEBUG - 2024-01-14 15:13:17 --> Total execution time: 0.0230
ERROR - 2024-01-14 15:13:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 15:13:30 --> Config Class Initialized
INFO - 2024-01-14 15:13:30 --> Hooks Class Initialized
DEBUG - 2024-01-14 15:13:30 --> UTF-8 Support Enabled
INFO - 2024-01-14 15:13:30 --> Utf8 Class Initialized
INFO - 2024-01-14 15:13:30 --> URI Class Initialized
INFO - 2024-01-14 15:13:30 --> Router Class Initialized
INFO - 2024-01-14 15:13:30 --> Output Class Initialized
INFO - 2024-01-14 15:13:30 --> Security Class Initialized
DEBUG - 2024-01-14 15:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 15:13:30 --> Input Class Initialized
INFO - 2024-01-14 15:13:30 --> Language Class Initialized
INFO - 2024-01-14 15:13:30 --> Loader Class Initialized
INFO - 2024-01-14 15:13:30 --> Helper loaded: url_helper
INFO - 2024-01-14 15:13:30 --> Helper loaded: file_helper
INFO - 2024-01-14 15:13:30 --> Helper loaded: html_helper
INFO - 2024-01-14 15:13:30 --> Helper loaded: text_helper
INFO - 2024-01-14 15:13:30 --> Helper loaded: form_helper
INFO - 2024-01-14 15:13:30 --> Helper loaded: lang_helper
INFO - 2024-01-14 15:13:30 --> Helper loaded: security_helper
INFO - 2024-01-14 15:13:30 --> Helper loaded: cookie_helper
INFO - 2024-01-14 15:13:30 --> Database Driver Class Initialized
INFO - 2024-01-14 15:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 15:13:30 --> Parser Class Initialized
INFO - 2024-01-14 15:13:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 15:13:30 --> Pagination Class Initialized
INFO - 2024-01-14 15:13:30 --> Form Validation Class Initialized
INFO - 2024-01-14 15:13:30 --> Controller Class Initialized
INFO - 2024-01-14 15:13:30 --> Model Class Initialized
DEBUG - 2024-01-14 15:13:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 15:13:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:13:30 --> Model Class Initialized
ERROR - 2024-01-14 15:13:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 15:13:30 --> Config Class Initialized
INFO - 2024-01-14 15:13:30 --> Hooks Class Initialized
DEBUG - 2024-01-14 15:13:30 --> UTF-8 Support Enabled
INFO - 2024-01-14 15:13:30 --> Utf8 Class Initialized
INFO - 2024-01-14 15:13:30 --> URI Class Initialized
INFO - 2024-01-14 15:13:30 --> Router Class Initialized
INFO - 2024-01-14 15:13:30 --> Output Class Initialized
INFO - 2024-01-14 15:13:30 --> Security Class Initialized
DEBUG - 2024-01-14 15:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 15:13:31 --> Input Class Initialized
INFO - 2024-01-14 15:13:31 --> Language Class Initialized
INFO - 2024-01-14 15:13:31 --> Loader Class Initialized
INFO - 2024-01-14 15:13:31 --> Helper loaded: url_helper
INFO - 2024-01-14 15:13:31 --> Helper loaded: file_helper
INFO - 2024-01-14 15:13:31 --> Helper loaded: html_helper
INFO - 2024-01-14 15:13:31 --> Helper loaded: text_helper
INFO - 2024-01-14 15:13:31 --> Helper loaded: form_helper
INFO - 2024-01-14 15:13:31 --> Helper loaded: lang_helper
INFO - 2024-01-14 15:13:31 --> Helper loaded: security_helper
INFO - 2024-01-14 15:13:31 --> Helper loaded: cookie_helper
INFO - 2024-01-14 15:13:31 --> Database Driver Class Initialized
INFO - 2024-01-14 15:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 15:13:31 --> Parser Class Initialized
INFO - 2024-01-14 15:13:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 15:13:31 --> Pagination Class Initialized
INFO - 2024-01-14 15:13:31 --> Form Validation Class Initialized
INFO - 2024-01-14 15:13:31 --> Controller Class Initialized
INFO - 2024-01-14 15:13:31 --> Model Class Initialized
DEBUG - 2024-01-14 15:13:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 15:13:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:13:31 --> Model Class Initialized
INFO - 2024-01-14 15:13:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2024-01-14 15:13:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:13:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-14 15:13:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-14 15:13:31 --> Model Class Initialized
INFO - 2024-01-14 15:13:31 --> Model Class Initialized
INFO - 2024-01-14 15:13:31 --> Model Class Initialized
INFO - 2024-01-14 15:13:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-14 15:13:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-14 15:13:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-14 15:13:31 --> Final output sent to browser
DEBUG - 2024-01-14 15:13:31 --> Total execution time: 0.2268
ERROR - 2024-01-14 15:13:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 15:13:31 --> Config Class Initialized
INFO - 2024-01-14 15:13:31 --> Hooks Class Initialized
DEBUG - 2024-01-14 15:13:31 --> UTF-8 Support Enabled
INFO - 2024-01-14 15:13:31 --> Utf8 Class Initialized
INFO - 2024-01-14 15:13:31 --> URI Class Initialized
INFO - 2024-01-14 15:13:31 --> Router Class Initialized
INFO - 2024-01-14 15:13:31 --> Output Class Initialized
INFO - 2024-01-14 15:13:31 --> Security Class Initialized
DEBUG - 2024-01-14 15:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 15:13:31 --> Input Class Initialized
INFO - 2024-01-14 15:13:31 --> Language Class Initialized
INFO - 2024-01-14 15:13:31 --> Loader Class Initialized
INFO - 2024-01-14 15:13:31 --> Helper loaded: url_helper
INFO - 2024-01-14 15:13:31 --> Helper loaded: file_helper
INFO - 2024-01-14 15:13:31 --> Helper loaded: html_helper
INFO - 2024-01-14 15:13:31 --> Helper loaded: text_helper
INFO - 2024-01-14 15:13:31 --> Helper loaded: form_helper
INFO - 2024-01-14 15:13:31 --> Helper loaded: lang_helper
INFO - 2024-01-14 15:13:31 --> Helper loaded: security_helper
INFO - 2024-01-14 15:13:31 --> Helper loaded: cookie_helper
INFO - 2024-01-14 15:13:31 --> Database Driver Class Initialized
INFO - 2024-01-14 15:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 15:13:31 --> Parser Class Initialized
INFO - 2024-01-14 15:13:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 15:13:31 --> Pagination Class Initialized
INFO - 2024-01-14 15:13:31 --> Form Validation Class Initialized
INFO - 2024-01-14 15:13:31 --> Controller Class Initialized
INFO - 2024-01-14 15:13:31 --> Model Class Initialized
DEBUG - 2024-01-14 15:13:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 15:13:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:13:31 --> Model Class Initialized
INFO - 2024-01-14 15:13:31 --> Final output sent to browser
DEBUG - 2024-01-14 15:13:31 --> Total execution time: 0.0189
ERROR - 2024-01-14 15:13:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 15:13:34 --> Config Class Initialized
INFO - 2024-01-14 15:13:34 --> Hooks Class Initialized
DEBUG - 2024-01-14 15:13:34 --> UTF-8 Support Enabled
INFO - 2024-01-14 15:13:34 --> Utf8 Class Initialized
INFO - 2024-01-14 15:13:34 --> URI Class Initialized
INFO - 2024-01-14 15:13:34 --> Router Class Initialized
INFO - 2024-01-14 15:13:34 --> Output Class Initialized
INFO - 2024-01-14 15:13:34 --> Security Class Initialized
DEBUG - 2024-01-14 15:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 15:13:34 --> Input Class Initialized
INFO - 2024-01-14 15:13:34 --> Language Class Initialized
INFO - 2024-01-14 15:13:34 --> Loader Class Initialized
INFO - 2024-01-14 15:13:34 --> Helper loaded: url_helper
INFO - 2024-01-14 15:13:34 --> Helper loaded: file_helper
INFO - 2024-01-14 15:13:34 --> Helper loaded: html_helper
INFO - 2024-01-14 15:13:34 --> Helper loaded: text_helper
INFO - 2024-01-14 15:13:34 --> Helper loaded: form_helper
INFO - 2024-01-14 15:13:34 --> Helper loaded: lang_helper
INFO - 2024-01-14 15:13:34 --> Helper loaded: security_helper
INFO - 2024-01-14 15:13:34 --> Helper loaded: cookie_helper
INFO - 2024-01-14 15:13:34 --> Database Driver Class Initialized
INFO - 2024-01-14 15:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 15:13:34 --> Parser Class Initialized
INFO - 2024-01-14 15:13:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 15:13:34 --> Pagination Class Initialized
INFO - 2024-01-14 15:13:34 --> Form Validation Class Initialized
INFO - 2024-01-14 15:13:34 --> Controller Class Initialized
INFO - 2024-01-14 15:13:34 --> Model Class Initialized
DEBUG - 2024-01-14 15:13:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 15:13:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:13:34 --> Model Class Initialized
DEBUG - 2024-01-14 15:13:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:13:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2024-01-14 15:13:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:13:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-14 15:13:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-14 15:13:34 --> Model Class Initialized
INFO - 2024-01-14 15:13:34 --> Model Class Initialized
INFO - 2024-01-14 15:13:34 --> Model Class Initialized
INFO - 2024-01-14 15:13:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-14 15:13:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-14 15:13:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-14 15:13:34 --> Final output sent to browser
DEBUG - 2024-01-14 15:13:34 --> Total execution time: 0.2172
ERROR - 2024-01-14 15:13:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 15:13:54 --> Config Class Initialized
INFO - 2024-01-14 15:13:54 --> Hooks Class Initialized
DEBUG - 2024-01-14 15:13:54 --> UTF-8 Support Enabled
INFO - 2024-01-14 15:13:54 --> Utf8 Class Initialized
INFO - 2024-01-14 15:13:54 --> URI Class Initialized
INFO - 2024-01-14 15:13:54 --> Router Class Initialized
INFO - 2024-01-14 15:13:54 --> Output Class Initialized
INFO - 2024-01-14 15:13:54 --> Security Class Initialized
DEBUG - 2024-01-14 15:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 15:13:54 --> Input Class Initialized
INFO - 2024-01-14 15:13:54 --> Language Class Initialized
INFO - 2024-01-14 15:13:54 --> Loader Class Initialized
INFO - 2024-01-14 15:13:54 --> Helper loaded: url_helper
INFO - 2024-01-14 15:13:54 --> Helper loaded: file_helper
INFO - 2024-01-14 15:13:54 --> Helper loaded: html_helper
INFO - 2024-01-14 15:13:54 --> Helper loaded: text_helper
INFO - 2024-01-14 15:13:54 --> Helper loaded: form_helper
INFO - 2024-01-14 15:13:54 --> Helper loaded: lang_helper
INFO - 2024-01-14 15:13:54 --> Helper loaded: security_helper
INFO - 2024-01-14 15:13:54 --> Helper loaded: cookie_helper
INFO - 2024-01-14 15:13:54 --> Database Driver Class Initialized
INFO - 2024-01-14 15:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 15:13:54 --> Parser Class Initialized
INFO - 2024-01-14 15:13:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 15:13:54 --> Pagination Class Initialized
INFO - 2024-01-14 15:13:54 --> Form Validation Class Initialized
INFO - 2024-01-14 15:13:54 --> Controller Class Initialized
INFO - 2024-01-14 15:13:54 --> Model Class Initialized
DEBUG - 2024-01-14 15:13:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 15:13:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:13:54 --> Model Class Initialized
INFO - 2024-01-14 15:13:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2024-01-14 15:13:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:13:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-14 15:13:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-14 15:13:54 --> Model Class Initialized
INFO - 2024-01-14 15:13:54 --> Model Class Initialized
INFO - 2024-01-14 15:13:54 --> Model Class Initialized
INFO - 2024-01-14 15:13:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-14 15:13:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-14 15:13:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-14 15:13:54 --> Final output sent to browser
DEBUG - 2024-01-14 15:13:54 --> Total execution time: 0.2431
ERROR - 2024-01-14 15:13:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 15:13:55 --> Config Class Initialized
INFO - 2024-01-14 15:13:55 --> Hooks Class Initialized
DEBUG - 2024-01-14 15:13:55 --> UTF-8 Support Enabled
INFO - 2024-01-14 15:13:55 --> Utf8 Class Initialized
INFO - 2024-01-14 15:13:55 --> URI Class Initialized
INFO - 2024-01-14 15:13:55 --> Router Class Initialized
INFO - 2024-01-14 15:13:55 --> Output Class Initialized
INFO - 2024-01-14 15:13:55 --> Security Class Initialized
DEBUG - 2024-01-14 15:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 15:13:55 --> Input Class Initialized
INFO - 2024-01-14 15:13:55 --> Language Class Initialized
INFO - 2024-01-14 15:13:55 --> Loader Class Initialized
INFO - 2024-01-14 15:13:55 --> Helper loaded: url_helper
INFO - 2024-01-14 15:13:55 --> Helper loaded: file_helper
INFO - 2024-01-14 15:13:55 --> Helper loaded: html_helper
INFO - 2024-01-14 15:13:55 --> Helper loaded: text_helper
INFO - 2024-01-14 15:13:55 --> Helper loaded: form_helper
INFO - 2024-01-14 15:13:55 --> Helper loaded: lang_helper
INFO - 2024-01-14 15:13:55 --> Helper loaded: security_helper
INFO - 2024-01-14 15:13:55 --> Helper loaded: cookie_helper
INFO - 2024-01-14 15:13:55 --> Database Driver Class Initialized
INFO - 2024-01-14 15:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 15:13:55 --> Parser Class Initialized
INFO - 2024-01-14 15:13:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 15:13:55 --> Pagination Class Initialized
INFO - 2024-01-14 15:13:55 --> Form Validation Class Initialized
INFO - 2024-01-14 15:13:55 --> Controller Class Initialized
INFO - 2024-01-14 15:13:55 --> Model Class Initialized
DEBUG - 2024-01-14 15:13:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 15:13:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:13:55 --> Model Class Initialized
INFO - 2024-01-14 15:13:55 --> Final output sent to browser
DEBUG - 2024-01-14 15:13:55 --> Total execution time: 0.0190
ERROR - 2024-01-14 15:13:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 15:13:59 --> Config Class Initialized
INFO - 2024-01-14 15:13:59 --> Hooks Class Initialized
DEBUG - 2024-01-14 15:13:59 --> UTF-8 Support Enabled
INFO - 2024-01-14 15:13:59 --> Utf8 Class Initialized
INFO - 2024-01-14 15:13:59 --> URI Class Initialized
INFO - 2024-01-14 15:13:59 --> Router Class Initialized
INFO - 2024-01-14 15:13:59 --> Output Class Initialized
INFO - 2024-01-14 15:13:59 --> Security Class Initialized
DEBUG - 2024-01-14 15:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 15:13:59 --> Input Class Initialized
INFO - 2024-01-14 15:13:59 --> Language Class Initialized
INFO - 2024-01-14 15:13:59 --> Loader Class Initialized
INFO - 2024-01-14 15:13:59 --> Helper loaded: url_helper
INFO - 2024-01-14 15:13:59 --> Helper loaded: file_helper
INFO - 2024-01-14 15:13:59 --> Helper loaded: html_helper
INFO - 2024-01-14 15:13:59 --> Helper loaded: text_helper
INFO - 2024-01-14 15:13:59 --> Helper loaded: form_helper
INFO - 2024-01-14 15:13:59 --> Helper loaded: lang_helper
INFO - 2024-01-14 15:13:59 --> Helper loaded: security_helper
INFO - 2024-01-14 15:13:59 --> Helper loaded: cookie_helper
INFO - 2024-01-14 15:13:59 --> Database Driver Class Initialized
INFO - 2024-01-14 15:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 15:13:59 --> Parser Class Initialized
INFO - 2024-01-14 15:13:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 15:13:59 --> Pagination Class Initialized
INFO - 2024-01-14 15:13:59 --> Form Validation Class Initialized
INFO - 2024-01-14 15:13:59 --> Controller Class Initialized
INFO - 2024-01-14 15:13:59 --> Model Class Initialized
DEBUG - 2024-01-14 15:13:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 15:13:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:13:59 --> Model Class Initialized
ERROR - 2024-01-14 15:13:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 15:13:59 --> Config Class Initialized
INFO - 2024-01-14 15:13:59 --> Hooks Class Initialized
DEBUG - 2024-01-14 15:13:59 --> UTF-8 Support Enabled
INFO - 2024-01-14 15:13:59 --> Utf8 Class Initialized
INFO - 2024-01-14 15:13:59 --> URI Class Initialized
INFO - 2024-01-14 15:13:59 --> Router Class Initialized
INFO - 2024-01-14 15:13:59 --> Output Class Initialized
INFO - 2024-01-14 15:13:59 --> Security Class Initialized
DEBUG - 2024-01-14 15:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 15:13:59 --> Input Class Initialized
INFO - 2024-01-14 15:13:59 --> Language Class Initialized
INFO - 2024-01-14 15:13:59 --> Loader Class Initialized
INFO - 2024-01-14 15:13:59 --> Helper loaded: url_helper
INFO - 2024-01-14 15:13:59 --> Helper loaded: file_helper
INFO - 2024-01-14 15:13:59 --> Helper loaded: html_helper
INFO - 2024-01-14 15:13:59 --> Helper loaded: text_helper
INFO - 2024-01-14 15:13:59 --> Helper loaded: form_helper
INFO - 2024-01-14 15:13:59 --> Helper loaded: lang_helper
INFO - 2024-01-14 15:13:59 --> Helper loaded: security_helper
INFO - 2024-01-14 15:13:59 --> Helper loaded: cookie_helper
INFO - 2024-01-14 15:13:59 --> Database Driver Class Initialized
INFO - 2024-01-14 15:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 15:13:59 --> Parser Class Initialized
INFO - 2024-01-14 15:13:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 15:13:59 --> Pagination Class Initialized
INFO - 2024-01-14 15:13:59 --> Form Validation Class Initialized
INFO - 2024-01-14 15:13:59 --> Controller Class Initialized
INFO - 2024-01-14 15:13:59 --> Model Class Initialized
DEBUG - 2024-01-14 15:13:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 15:13:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:13:59 --> Model Class Initialized
INFO - 2024-01-14 15:13:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2024-01-14 15:13:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:13:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-14 15:13:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-14 15:13:59 --> Model Class Initialized
INFO - 2024-01-14 15:13:59 --> Model Class Initialized
INFO - 2024-01-14 15:13:59 --> Model Class Initialized
INFO - 2024-01-14 15:14:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-14 15:14:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-14 15:14:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-14 15:14:00 --> Final output sent to browser
DEBUG - 2024-01-14 15:14:00 --> Total execution time: 0.2380
ERROR - 2024-01-14 15:14:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 15:14:00 --> Config Class Initialized
INFO - 2024-01-14 15:14:00 --> Hooks Class Initialized
DEBUG - 2024-01-14 15:14:00 --> UTF-8 Support Enabled
INFO - 2024-01-14 15:14:00 --> Utf8 Class Initialized
INFO - 2024-01-14 15:14:00 --> URI Class Initialized
INFO - 2024-01-14 15:14:00 --> Router Class Initialized
INFO - 2024-01-14 15:14:00 --> Output Class Initialized
INFO - 2024-01-14 15:14:00 --> Security Class Initialized
DEBUG - 2024-01-14 15:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 15:14:00 --> Input Class Initialized
INFO - 2024-01-14 15:14:00 --> Language Class Initialized
INFO - 2024-01-14 15:14:00 --> Loader Class Initialized
INFO - 2024-01-14 15:14:00 --> Helper loaded: url_helper
INFO - 2024-01-14 15:14:00 --> Helper loaded: file_helper
INFO - 2024-01-14 15:14:00 --> Helper loaded: html_helper
INFO - 2024-01-14 15:14:00 --> Helper loaded: text_helper
INFO - 2024-01-14 15:14:00 --> Helper loaded: form_helper
INFO - 2024-01-14 15:14:00 --> Helper loaded: lang_helper
INFO - 2024-01-14 15:14:00 --> Helper loaded: security_helper
INFO - 2024-01-14 15:14:00 --> Helper loaded: cookie_helper
INFO - 2024-01-14 15:14:00 --> Database Driver Class Initialized
INFO - 2024-01-14 15:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 15:14:00 --> Parser Class Initialized
INFO - 2024-01-14 15:14:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 15:14:00 --> Pagination Class Initialized
INFO - 2024-01-14 15:14:00 --> Form Validation Class Initialized
INFO - 2024-01-14 15:14:00 --> Controller Class Initialized
INFO - 2024-01-14 15:14:00 --> Model Class Initialized
DEBUG - 2024-01-14 15:14:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 15:14:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:14:00 --> Model Class Initialized
INFO - 2024-01-14 15:14:00 --> Final output sent to browser
DEBUG - 2024-01-14 15:14:00 --> Total execution time: 0.0161
ERROR - 2024-01-14 15:14:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 15:14:03 --> Config Class Initialized
INFO - 2024-01-14 15:14:03 --> Hooks Class Initialized
DEBUG - 2024-01-14 15:14:03 --> UTF-8 Support Enabled
INFO - 2024-01-14 15:14:03 --> Utf8 Class Initialized
INFO - 2024-01-14 15:14:03 --> URI Class Initialized
DEBUG - 2024-01-14 15:14:03 --> No URI present. Default controller set.
INFO - 2024-01-14 15:14:03 --> Router Class Initialized
INFO - 2024-01-14 15:14:03 --> Output Class Initialized
INFO - 2024-01-14 15:14:03 --> Security Class Initialized
DEBUG - 2024-01-14 15:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 15:14:03 --> Input Class Initialized
INFO - 2024-01-14 15:14:03 --> Language Class Initialized
INFO - 2024-01-14 15:14:03 --> Loader Class Initialized
INFO - 2024-01-14 15:14:03 --> Helper loaded: url_helper
INFO - 2024-01-14 15:14:03 --> Helper loaded: file_helper
INFO - 2024-01-14 15:14:03 --> Helper loaded: html_helper
INFO - 2024-01-14 15:14:03 --> Helper loaded: text_helper
INFO - 2024-01-14 15:14:03 --> Helper loaded: form_helper
INFO - 2024-01-14 15:14:03 --> Helper loaded: lang_helper
INFO - 2024-01-14 15:14:03 --> Helper loaded: security_helper
INFO - 2024-01-14 15:14:03 --> Helper loaded: cookie_helper
INFO - 2024-01-14 15:14:03 --> Database Driver Class Initialized
INFO - 2024-01-14 15:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 15:14:03 --> Parser Class Initialized
INFO - 2024-01-14 15:14:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 15:14:03 --> Pagination Class Initialized
INFO - 2024-01-14 15:14:03 --> Form Validation Class Initialized
INFO - 2024-01-14 15:14:03 --> Controller Class Initialized
INFO - 2024-01-14 15:14:03 --> Model Class Initialized
DEBUG - 2024-01-14 15:14:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:14:03 --> Model Class Initialized
DEBUG - 2024-01-14 15:14:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:14:03 --> Model Class Initialized
INFO - 2024-01-14 15:14:03 --> Model Class Initialized
INFO - 2024-01-14 15:14:03 --> Model Class Initialized
INFO - 2024-01-14 15:14:03 --> Model Class Initialized
DEBUG - 2024-01-14 15:14:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 15:14:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:14:03 --> Model Class Initialized
INFO - 2024-01-14 15:14:03 --> Model Class Initialized
INFO - 2024-01-14 15:14:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-14 15:14:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:14:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-14 15:14:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-14 15:14:03 --> Model Class Initialized
INFO - 2024-01-14 15:14:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-14 15:14:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-14 15:14:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-14 15:14:03 --> Final output sent to browser
DEBUG - 2024-01-14 15:14:03 --> Total execution time: 0.4327
ERROR - 2024-01-14 15:14:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 15:14:14 --> Config Class Initialized
INFO - 2024-01-14 15:14:14 --> Hooks Class Initialized
DEBUG - 2024-01-14 15:14:14 --> UTF-8 Support Enabled
INFO - 2024-01-14 15:14:14 --> Utf8 Class Initialized
INFO - 2024-01-14 15:14:14 --> URI Class Initialized
INFO - 2024-01-14 15:14:14 --> Router Class Initialized
INFO - 2024-01-14 15:14:14 --> Output Class Initialized
INFO - 2024-01-14 15:14:14 --> Security Class Initialized
DEBUG - 2024-01-14 15:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 15:14:14 --> Input Class Initialized
INFO - 2024-01-14 15:14:14 --> Language Class Initialized
INFO - 2024-01-14 15:14:14 --> Loader Class Initialized
INFO - 2024-01-14 15:14:14 --> Helper loaded: url_helper
INFO - 2024-01-14 15:14:14 --> Helper loaded: file_helper
INFO - 2024-01-14 15:14:14 --> Helper loaded: html_helper
INFO - 2024-01-14 15:14:14 --> Helper loaded: text_helper
INFO - 2024-01-14 15:14:14 --> Helper loaded: form_helper
INFO - 2024-01-14 15:14:14 --> Helper loaded: lang_helper
INFO - 2024-01-14 15:14:14 --> Helper loaded: security_helper
INFO - 2024-01-14 15:14:14 --> Helper loaded: cookie_helper
INFO - 2024-01-14 15:14:14 --> Database Driver Class Initialized
INFO - 2024-01-14 15:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 15:14:14 --> Parser Class Initialized
INFO - 2024-01-14 15:14:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 15:14:14 --> Pagination Class Initialized
INFO - 2024-01-14 15:14:14 --> Form Validation Class Initialized
INFO - 2024-01-14 15:14:14 --> Controller Class Initialized
DEBUG - 2024-01-14 15:14:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 15:14:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:14:14 --> Model Class Initialized
DEBUG - 2024-01-14 15:14:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:14:14 --> Model Class Initialized
DEBUG - 2024-01-14 15:14:14 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:14:14 --> Model Class Initialized
INFO - 2024-01-14 15:14:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-01-14 15:14:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:14:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-14 15:14:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-14 15:14:14 --> Model Class Initialized
INFO - 2024-01-14 15:14:14 --> Model Class Initialized
INFO - 2024-01-14 15:14:14 --> Model Class Initialized
INFO - 2024-01-14 15:14:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-14 15:14:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-14 15:14:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-14 15:14:14 --> Final output sent to browser
DEBUG - 2024-01-14 15:14:14 --> Total execution time: 0.2354
ERROR - 2024-01-14 15:14:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 15:14:15 --> Config Class Initialized
INFO - 2024-01-14 15:14:15 --> Hooks Class Initialized
DEBUG - 2024-01-14 15:14:15 --> UTF-8 Support Enabled
INFO - 2024-01-14 15:14:15 --> Utf8 Class Initialized
INFO - 2024-01-14 15:14:15 --> URI Class Initialized
INFO - 2024-01-14 15:14:15 --> Router Class Initialized
INFO - 2024-01-14 15:14:15 --> Output Class Initialized
INFO - 2024-01-14 15:14:15 --> Security Class Initialized
DEBUG - 2024-01-14 15:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 15:14:15 --> Input Class Initialized
INFO - 2024-01-14 15:14:15 --> Language Class Initialized
INFO - 2024-01-14 15:14:15 --> Loader Class Initialized
INFO - 2024-01-14 15:14:15 --> Helper loaded: url_helper
INFO - 2024-01-14 15:14:15 --> Helper loaded: file_helper
INFO - 2024-01-14 15:14:15 --> Helper loaded: html_helper
INFO - 2024-01-14 15:14:15 --> Helper loaded: text_helper
INFO - 2024-01-14 15:14:15 --> Helper loaded: form_helper
INFO - 2024-01-14 15:14:15 --> Helper loaded: lang_helper
INFO - 2024-01-14 15:14:15 --> Helper loaded: security_helper
INFO - 2024-01-14 15:14:15 --> Helper loaded: cookie_helper
INFO - 2024-01-14 15:14:15 --> Database Driver Class Initialized
INFO - 2024-01-14 15:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 15:14:15 --> Parser Class Initialized
INFO - 2024-01-14 15:14:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 15:14:15 --> Pagination Class Initialized
INFO - 2024-01-14 15:14:15 --> Form Validation Class Initialized
INFO - 2024-01-14 15:14:15 --> Controller Class Initialized
DEBUG - 2024-01-14 15:14:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 15:14:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:14:15 --> Model Class Initialized
DEBUG - 2024-01-14 15:14:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:14:15 --> Model Class Initialized
INFO - 2024-01-14 15:14:15 --> Final output sent to browser
DEBUG - 2024-01-14 15:14:15 --> Total execution time: 0.0390
ERROR - 2024-01-14 15:14:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 15:14:20 --> Config Class Initialized
INFO - 2024-01-14 15:14:20 --> Hooks Class Initialized
DEBUG - 2024-01-14 15:14:20 --> UTF-8 Support Enabled
INFO - 2024-01-14 15:14:20 --> Utf8 Class Initialized
INFO - 2024-01-14 15:14:20 --> URI Class Initialized
INFO - 2024-01-14 15:14:20 --> Router Class Initialized
INFO - 2024-01-14 15:14:20 --> Output Class Initialized
INFO - 2024-01-14 15:14:20 --> Security Class Initialized
DEBUG - 2024-01-14 15:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 15:14:20 --> Input Class Initialized
INFO - 2024-01-14 15:14:20 --> Language Class Initialized
INFO - 2024-01-14 15:14:20 --> Loader Class Initialized
INFO - 2024-01-14 15:14:20 --> Helper loaded: url_helper
INFO - 2024-01-14 15:14:20 --> Helper loaded: file_helper
INFO - 2024-01-14 15:14:20 --> Helper loaded: html_helper
INFO - 2024-01-14 15:14:20 --> Helper loaded: text_helper
INFO - 2024-01-14 15:14:20 --> Helper loaded: form_helper
INFO - 2024-01-14 15:14:20 --> Helper loaded: lang_helper
INFO - 2024-01-14 15:14:20 --> Helper loaded: security_helper
INFO - 2024-01-14 15:14:20 --> Helper loaded: cookie_helper
INFO - 2024-01-14 15:14:20 --> Database Driver Class Initialized
INFO - 2024-01-14 15:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 15:14:20 --> Parser Class Initialized
INFO - 2024-01-14 15:14:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 15:14:20 --> Pagination Class Initialized
INFO - 2024-01-14 15:14:20 --> Form Validation Class Initialized
INFO - 2024-01-14 15:14:20 --> Controller Class Initialized
DEBUG - 2024-01-14 15:14:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 15:14:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:14:20 --> Model Class Initialized
DEBUG - 2024-01-14 15:14:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:14:20 --> Model Class Initialized
INFO - 2024-01-14 15:14:20 --> Final output sent to browser
DEBUG - 2024-01-14 15:14:20 --> Total execution time: 0.2088
ERROR - 2024-01-14 15:14:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 15:14:26 --> Config Class Initialized
INFO - 2024-01-14 15:14:26 --> Hooks Class Initialized
DEBUG - 2024-01-14 15:14:26 --> UTF-8 Support Enabled
INFO - 2024-01-14 15:14:26 --> Utf8 Class Initialized
INFO - 2024-01-14 15:14:26 --> URI Class Initialized
DEBUG - 2024-01-14 15:14:26 --> No URI present. Default controller set.
INFO - 2024-01-14 15:14:26 --> Router Class Initialized
INFO - 2024-01-14 15:14:26 --> Output Class Initialized
INFO - 2024-01-14 15:14:26 --> Security Class Initialized
DEBUG - 2024-01-14 15:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 15:14:26 --> Input Class Initialized
INFO - 2024-01-14 15:14:26 --> Language Class Initialized
INFO - 2024-01-14 15:14:26 --> Loader Class Initialized
INFO - 2024-01-14 15:14:26 --> Helper loaded: url_helper
INFO - 2024-01-14 15:14:26 --> Helper loaded: file_helper
INFO - 2024-01-14 15:14:26 --> Helper loaded: html_helper
INFO - 2024-01-14 15:14:26 --> Helper loaded: text_helper
INFO - 2024-01-14 15:14:26 --> Helper loaded: form_helper
INFO - 2024-01-14 15:14:26 --> Helper loaded: lang_helper
INFO - 2024-01-14 15:14:26 --> Helper loaded: security_helper
INFO - 2024-01-14 15:14:26 --> Helper loaded: cookie_helper
INFO - 2024-01-14 15:14:26 --> Database Driver Class Initialized
INFO - 2024-01-14 15:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 15:14:26 --> Parser Class Initialized
INFO - 2024-01-14 15:14:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 15:14:26 --> Pagination Class Initialized
INFO - 2024-01-14 15:14:26 --> Form Validation Class Initialized
INFO - 2024-01-14 15:14:26 --> Controller Class Initialized
INFO - 2024-01-14 15:14:26 --> Model Class Initialized
DEBUG - 2024-01-14 15:14:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:14:26 --> Model Class Initialized
DEBUG - 2024-01-14 15:14:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:14:26 --> Model Class Initialized
INFO - 2024-01-14 15:14:26 --> Model Class Initialized
INFO - 2024-01-14 15:14:26 --> Model Class Initialized
INFO - 2024-01-14 15:14:26 --> Model Class Initialized
DEBUG - 2024-01-14 15:14:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 15:14:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:14:26 --> Model Class Initialized
INFO - 2024-01-14 15:14:26 --> Model Class Initialized
INFO - 2024-01-14 15:14:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-14 15:14:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:14:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-14 15:14:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-14 15:14:26 --> Model Class Initialized
INFO - 2024-01-14 15:14:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-14 15:14:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-14 15:14:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-14 15:14:26 --> Final output sent to browser
DEBUG - 2024-01-14 15:14:26 --> Total execution time: 0.4112
ERROR - 2024-01-14 15:14:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 15:14:35 --> Config Class Initialized
INFO - 2024-01-14 15:14:35 --> Hooks Class Initialized
DEBUG - 2024-01-14 15:14:35 --> UTF-8 Support Enabled
INFO - 2024-01-14 15:14:35 --> Utf8 Class Initialized
INFO - 2024-01-14 15:14:35 --> URI Class Initialized
INFO - 2024-01-14 15:14:35 --> Router Class Initialized
INFO - 2024-01-14 15:14:35 --> Output Class Initialized
INFO - 2024-01-14 15:14:35 --> Security Class Initialized
DEBUG - 2024-01-14 15:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 15:14:35 --> Input Class Initialized
INFO - 2024-01-14 15:14:35 --> Language Class Initialized
INFO - 2024-01-14 15:14:35 --> Loader Class Initialized
INFO - 2024-01-14 15:14:35 --> Helper loaded: url_helper
INFO - 2024-01-14 15:14:35 --> Helper loaded: file_helper
INFO - 2024-01-14 15:14:35 --> Helper loaded: html_helper
INFO - 2024-01-14 15:14:35 --> Helper loaded: text_helper
INFO - 2024-01-14 15:14:35 --> Helper loaded: form_helper
INFO - 2024-01-14 15:14:35 --> Helper loaded: lang_helper
INFO - 2024-01-14 15:14:35 --> Helper loaded: security_helper
INFO - 2024-01-14 15:14:35 --> Helper loaded: cookie_helper
INFO - 2024-01-14 15:14:35 --> Database Driver Class Initialized
INFO - 2024-01-14 15:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 15:14:35 --> Parser Class Initialized
INFO - 2024-01-14 15:14:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 15:14:35 --> Pagination Class Initialized
INFO - 2024-01-14 15:14:35 --> Form Validation Class Initialized
INFO - 2024-01-14 15:14:35 --> Controller Class Initialized
INFO - 2024-01-14 15:14:35 --> Model Class Initialized
DEBUG - 2024-01-14 15:14:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 15:14:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:14:35 --> Model Class Initialized
DEBUG - 2024-01-14 15:14:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:14:35 --> Model Class Initialized
INFO - 2024-01-14 15:14:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-14 15:14:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:14:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-14 15:14:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-14 15:14:35 --> Model Class Initialized
INFO - 2024-01-14 15:14:35 --> Model Class Initialized
INFO - 2024-01-14 15:14:35 --> Model Class Initialized
INFO - 2024-01-14 15:14:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-14 15:14:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-14 15:14:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-14 15:14:35 --> Final output sent to browser
DEBUG - 2024-01-14 15:14:35 --> Total execution time: 0.2167
ERROR - 2024-01-14 15:14:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 15:14:36 --> Config Class Initialized
INFO - 2024-01-14 15:14:36 --> Hooks Class Initialized
DEBUG - 2024-01-14 15:14:36 --> UTF-8 Support Enabled
INFO - 2024-01-14 15:14:36 --> Utf8 Class Initialized
INFO - 2024-01-14 15:14:36 --> URI Class Initialized
INFO - 2024-01-14 15:14:36 --> Router Class Initialized
INFO - 2024-01-14 15:14:36 --> Output Class Initialized
INFO - 2024-01-14 15:14:36 --> Security Class Initialized
DEBUG - 2024-01-14 15:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 15:14:36 --> Input Class Initialized
INFO - 2024-01-14 15:14:36 --> Language Class Initialized
INFO - 2024-01-14 15:14:36 --> Loader Class Initialized
INFO - 2024-01-14 15:14:36 --> Helper loaded: url_helper
INFO - 2024-01-14 15:14:36 --> Helper loaded: file_helper
INFO - 2024-01-14 15:14:36 --> Helper loaded: html_helper
INFO - 2024-01-14 15:14:36 --> Helper loaded: text_helper
INFO - 2024-01-14 15:14:36 --> Helper loaded: form_helper
INFO - 2024-01-14 15:14:36 --> Helper loaded: lang_helper
INFO - 2024-01-14 15:14:36 --> Helper loaded: security_helper
INFO - 2024-01-14 15:14:36 --> Helper loaded: cookie_helper
INFO - 2024-01-14 15:14:36 --> Database Driver Class Initialized
INFO - 2024-01-14 15:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 15:14:36 --> Parser Class Initialized
INFO - 2024-01-14 15:14:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 15:14:36 --> Pagination Class Initialized
INFO - 2024-01-14 15:14:36 --> Form Validation Class Initialized
INFO - 2024-01-14 15:14:36 --> Controller Class Initialized
INFO - 2024-01-14 15:14:36 --> Model Class Initialized
DEBUG - 2024-01-14 15:14:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 15:14:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:14:36 --> Model Class Initialized
DEBUG - 2024-01-14 15:14:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:14:36 --> Model Class Initialized
INFO - 2024-01-14 15:14:36 --> Final output sent to browser
DEBUG - 2024-01-14 15:14:36 --> Total execution time: 0.0606
ERROR - 2024-01-14 15:14:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 15:14:40 --> Config Class Initialized
INFO - 2024-01-14 15:14:40 --> Hooks Class Initialized
DEBUG - 2024-01-14 15:14:40 --> UTF-8 Support Enabled
INFO - 2024-01-14 15:14:40 --> Utf8 Class Initialized
INFO - 2024-01-14 15:14:40 --> URI Class Initialized
INFO - 2024-01-14 15:14:40 --> Router Class Initialized
INFO - 2024-01-14 15:14:40 --> Output Class Initialized
INFO - 2024-01-14 15:14:40 --> Security Class Initialized
DEBUG - 2024-01-14 15:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 15:14:40 --> Input Class Initialized
INFO - 2024-01-14 15:14:40 --> Language Class Initialized
INFO - 2024-01-14 15:14:40 --> Loader Class Initialized
INFO - 2024-01-14 15:14:40 --> Helper loaded: url_helper
INFO - 2024-01-14 15:14:40 --> Helper loaded: file_helper
INFO - 2024-01-14 15:14:40 --> Helper loaded: html_helper
INFO - 2024-01-14 15:14:40 --> Helper loaded: text_helper
INFO - 2024-01-14 15:14:40 --> Helper loaded: form_helper
INFO - 2024-01-14 15:14:40 --> Helper loaded: lang_helper
INFO - 2024-01-14 15:14:40 --> Helper loaded: security_helper
INFO - 2024-01-14 15:14:40 --> Helper loaded: cookie_helper
INFO - 2024-01-14 15:14:40 --> Database Driver Class Initialized
INFO - 2024-01-14 15:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 15:14:40 --> Parser Class Initialized
INFO - 2024-01-14 15:14:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 15:14:40 --> Pagination Class Initialized
INFO - 2024-01-14 15:14:40 --> Form Validation Class Initialized
INFO - 2024-01-14 15:14:40 --> Controller Class Initialized
INFO - 2024-01-14 15:14:40 --> Model Class Initialized
DEBUG - 2024-01-14 15:14:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 15:14:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:14:40 --> Model Class Initialized
DEBUG - 2024-01-14 15:14:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:14:40 --> Model Class Initialized
INFO - 2024-01-14 15:14:41 --> Final output sent to browser
DEBUG - 2024-01-14 15:14:41 --> Total execution time: 1.1338
ERROR - 2024-01-14 15:14:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 15:14:45 --> Config Class Initialized
INFO - 2024-01-14 15:14:45 --> Hooks Class Initialized
DEBUG - 2024-01-14 15:14:45 --> UTF-8 Support Enabled
INFO - 2024-01-14 15:14:45 --> Utf8 Class Initialized
INFO - 2024-01-14 15:14:45 --> URI Class Initialized
DEBUG - 2024-01-14 15:14:45 --> No URI present. Default controller set.
INFO - 2024-01-14 15:14:45 --> Router Class Initialized
INFO - 2024-01-14 15:14:45 --> Output Class Initialized
INFO - 2024-01-14 15:14:45 --> Security Class Initialized
DEBUG - 2024-01-14 15:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 15:14:45 --> Input Class Initialized
INFO - 2024-01-14 15:14:45 --> Language Class Initialized
INFO - 2024-01-14 15:14:45 --> Loader Class Initialized
INFO - 2024-01-14 15:14:45 --> Helper loaded: url_helper
INFO - 2024-01-14 15:14:45 --> Helper loaded: file_helper
INFO - 2024-01-14 15:14:45 --> Helper loaded: html_helper
INFO - 2024-01-14 15:14:45 --> Helper loaded: text_helper
INFO - 2024-01-14 15:14:45 --> Helper loaded: form_helper
INFO - 2024-01-14 15:14:45 --> Helper loaded: lang_helper
INFO - 2024-01-14 15:14:45 --> Helper loaded: security_helper
INFO - 2024-01-14 15:14:45 --> Helper loaded: cookie_helper
INFO - 2024-01-14 15:14:45 --> Database Driver Class Initialized
INFO - 2024-01-14 15:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 15:14:45 --> Parser Class Initialized
INFO - 2024-01-14 15:14:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 15:14:45 --> Pagination Class Initialized
INFO - 2024-01-14 15:14:45 --> Form Validation Class Initialized
INFO - 2024-01-14 15:14:45 --> Controller Class Initialized
INFO - 2024-01-14 15:14:45 --> Model Class Initialized
DEBUG - 2024-01-14 15:14:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:14:45 --> Model Class Initialized
DEBUG - 2024-01-14 15:14:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:14:45 --> Model Class Initialized
INFO - 2024-01-14 15:14:45 --> Model Class Initialized
INFO - 2024-01-14 15:14:45 --> Model Class Initialized
INFO - 2024-01-14 15:14:45 --> Model Class Initialized
DEBUG - 2024-01-14 15:14:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-14 15:14:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:14:45 --> Model Class Initialized
INFO - 2024-01-14 15:14:45 --> Model Class Initialized
INFO - 2024-01-14 15:14:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-14 15:14:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:14:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-14 15:14:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-14 15:14:45 --> Model Class Initialized
INFO - 2024-01-14 15:14:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-14 15:14:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-14 15:14:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-14 15:14:45 --> Final output sent to browser
DEBUG - 2024-01-14 15:14:45 --> Total execution time: 0.4072
ERROR - 2024-01-14 15:14:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 15:14:55 --> Config Class Initialized
INFO - 2024-01-14 15:14:55 --> Hooks Class Initialized
DEBUG - 2024-01-14 15:14:55 --> UTF-8 Support Enabled
INFO - 2024-01-14 15:14:55 --> Utf8 Class Initialized
INFO - 2024-01-14 15:14:55 --> URI Class Initialized
INFO - 2024-01-14 15:14:55 --> Router Class Initialized
INFO - 2024-01-14 15:14:55 --> Output Class Initialized
INFO - 2024-01-14 15:14:55 --> Security Class Initialized
DEBUG - 2024-01-14 15:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 15:14:55 --> Input Class Initialized
INFO - 2024-01-14 15:14:55 --> Language Class Initialized
INFO - 2024-01-14 15:14:55 --> Loader Class Initialized
INFO - 2024-01-14 15:14:55 --> Helper loaded: url_helper
INFO - 2024-01-14 15:14:55 --> Helper loaded: file_helper
INFO - 2024-01-14 15:14:55 --> Helper loaded: html_helper
INFO - 2024-01-14 15:14:55 --> Helper loaded: text_helper
INFO - 2024-01-14 15:14:55 --> Helper loaded: form_helper
INFO - 2024-01-14 15:14:55 --> Helper loaded: lang_helper
INFO - 2024-01-14 15:14:55 --> Helper loaded: security_helper
INFO - 2024-01-14 15:14:55 --> Helper loaded: cookie_helper
INFO - 2024-01-14 15:14:55 --> Database Driver Class Initialized
INFO - 2024-01-14 15:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 15:14:55 --> Parser Class Initialized
INFO - 2024-01-14 15:14:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 15:14:55 --> Pagination Class Initialized
INFO - 2024-01-14 15:14:55 --> Form Validation Class Initialized
INFO - 2024-01-14 15:14:55 --> Controller Class Initialized
INFO - 2024-01-14 15:14:55 --> Model Class Initialized
DEBUG - 2024-01-14 15:14:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:14:55 --> Final output sent to browser
DEBUG - 2024-01-14 15:14:55 --> Total execution time: 0.0126
ERROR - 2024-01-14 15:14:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 15:14:55 --> Config Class Initialized
INFO - 2024-01-14 15:14:55 --> Hooks Class Initialized
DEBUG - 2024-01-14 15:14:55 --> UTF-8 Support Enabled
INFO - 2024-01-14 15:14:55 --> Utf8 Class Initialized
INFO - 2024-01-14 15:14:55 --> URI Class Initialized
INFO - 2024-01-14 15:14:55 --> Router Class Initialized
INFO - 2024-01-14 15:14:55 --> Output Class Initialized
INFO - 2024-01-14 15:14:55 --> Security Class Initialized
DEBUG - 2024-01-14 15:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 15:14:55 --> Input Class Initialized
INFO - 2024-01-14 15:14:55 --> Language Class Initialized
INFO - 2024-01-14 15:14:55 --> Loader Class Initialized
INFO - 2024-01-14 15:14:55 --> Helper loaded: url_helper
INFO - 2024-01-14 15:14:55 --> Helper loaded: file_helper
INFO - 2024-01-14 15:14:55 --> Helper loaded: html_helper
INFO - 2024-01-14 15:14:55 --> Helper loaded: text_helper
INFO - 2024-01-14 15:14:55 --> Helper loaded: form_helper
INFO - 2024-01-14 15:14:55 --> Helper loaded: lang_helper
INFO - 2024-01-14 15:14:55 --> Helper loaded: security_helper
INFO - 2024-01-14 15:14:55 --> Helper loaded: cookie_helper
INFO - 2024-01-14 15:14:55 --> Database Driver Class Initialized
INFO - 2024-01-14 15:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 15:14:55 --> Parser Class Initialized
INFO - 2024-01-14 15:14:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 15:14:55 --> Pagination Class Initialized
INFO - 2024-01-14 15:14:55 --> Form Validation Class Initialized
INFO - 2024-01-14 15:14:55 --> Controller Class Initialized
INFO - 2024-01-14 15:14:55 --> Model Class Initialized
DEBUG - 2024-01-14 15:14:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:14:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-14 15:14:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-14 15:14:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-14 15:14:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-14 15:14:55 --> Model Class Initialized
INFO - 2024-01-14 15:14:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-14 15:14:55 --> Final output sent to browser
DEBUG - 2024-01-14 15:14:55 --> Total execution time: 0.0274
ERROR - 2024-01-14 16:54:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 16:54:01 --> Config Class Initialized
INFO - 2024-01-14 16:54:01 --> Hooks Class Initialized
DEBUG - 2024-01-14 16:54:01 --> UTF-8 Support Enabled
INFO - 2024-01-14 16:54:01 --> Utf8 Class Initialized
INFO - 2024-01-14 16:54:01 --> URI Class Initialized
INFO - 2024-01-14 16:54:01 --> Router Class Initialized
INFO - 2024-01-14 16:54:01 --> Output Class Initialized
INFO - 2024-01-14 16:54:01 --> Security Class Initialized
DEBUG - 2024-01-14 16:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 16:54:01 --> Input Class Initialized
INFO - 2024-01-14 16:54:01 --> Language Class Initialized
ERROR - 2024-01-14 16:54:01 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2024-01-14 17:01:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 17:01:33 --> Config Class Initialized
INFO - 2024-01-14 17:01:33 --> Hooks Class Initialized
DEBUG - 2024-01-14 17:01:33 --> UTF-8 Support Enabled
INFO - 2024-01-14 17:01:33 --> Utf8 Class Initialized
INFO - 2024-01-14 17:01:33 --> URI Class Initialized
DEBUG - 2024-01-14 17:01:33 --> No URI present. Default controller set.
INFO - 2024-01-14 17:01:33 --> Router Class Initialized
INFO - 2024-01-14 17:01:33 --> Output Class Initialized
INFO - 2024-01-14 17:01:33 --> Security Class Initialized
DEBUG - 2024-01-14 17:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 17:01:33 --> Input Class Initialized
INFO - 2024-01-14 17:01:33 --> Language Class Initialized
INFO - 2024-01-14 17:01:33 --> Loader Class Initialized
INFO - 2024-01-14 17:01:33 --> Helper loaded: url_helper
INFO - 2024-01-14 17:01:33 --> Helper loaded: file_helper
INFO - 2024-01-14 17:01:33 --> Helper loaded: html_helper
INFO - 2024-01-14 17:01:33 --> Helper loaded: text_helper
INFO - 2024-01-14 17:01:33 --> Helper loaded: form_helper
INFO - 2024-01-14 17:01:33 --> Helper loaded: lang_helper
INFO - 2024-01-14 17:01:33 --> Helper loaded: security_helper
INFO - 2024-01-14 17:01:33 --> Helper loaded: cookie_helper
INFO - 2024-01-14 17:01:33 --> Database Driver Class Initialized
INFO - 2024-01-14 17:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 17:01:33 --> Parser Class Initialized
INFO - 2024-01-14 17:01:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 17:01:33 --> Pagination Class Initialized
INFO - 2024-01-14 17:01:33 --> Form Validation Class Initialized
INFO - 2024-01-14 17:01:33 --> Controller Class Initialized
INFO - 2024-01-14 17:01:33 --> Model Class Initialized
DEBUG - 2024-01-14 17:01:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-14 17:01:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 17:01:34 --> Config Class Initialized
INFO - 2024-01-14 17:01:34 --> Hooks Class Initialized
DEBUG - 2024-01-14 17:01:34 --> UTF-8 Support Enabled
INFO - 2024-01-14 17:01:34 --> Utf8 Class Initialized
INFO - 2024-01-14 17:01:34 --> URI Class Initialized
INFO - 2024-01-14 17:01:34 --> Router Class Initialized
INFO - 2024-01-14 17:01:34 --> Output Class Initialized
INFO - 2024-01-14 17:01:34 --> Security Class Initialized
DEBUG - 2024-01-14 17:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 17:01:34 --> Input Class Initialized
INFO - 2024-01-14 17:01:34 --> Language Class Initialized
INFO - 2024-01-14 17:01:34 --> Loader Class Initialized
INFO - 2024-01-14 17:01:34 --> Helper loaded: url_helper
INFO - 2024-01-14 17:01:34 --> Helper loaded: file_helper
INFO - 2024-01-14 17:01:34 --> Helper loaded: html_helper
INFO - 2024-01-14 17:01:34 --> Helper loaded: text_helper
INFO - 2024-01-14 17:01:34 --> Helper loaded: form_helper
INFO - 2024-01-14 17:01:34 --> Helper loaded: lang_helper
INFO - 2024-01-14 17:01:34 --> Helper loaded: security_helper
INFO - 2024-01-14 17:01:34 --> Helper loaded: cookie_helper
INFO - 2024-01-14 17:01:34 --> Database Driver Class Initialized
INFO - 2024-01-14 17:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-14 17:01:34 --> Parser Class Initialized
INFO - 2024-01-14 17:01:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-14 17:01:34 --> Pagination Class Initialized
INFO - 2024-01-14 17:01:34 --> Form Validation Class Initialized
INFO - 2024-01-14 17:01:34 --> Controller Class Initialized
INFO - 2024-01-14 17:01:34 --> Model Class Initialized
DEBUG - 2024-01-14 17:01:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-14 17:01:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-14 17:01:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-14 17:01:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-14 17:01:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-14 17:01:34 --> Model Class Initialized
INFO - 2024-01-14 17:01:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-14 17:01:34 --> Final output sent to browser
DEBUG - 2024-01-14 17:01:34 --> Total execution time: 0.0347
ERROR - 2024-01-14 23:26:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 23:26:52 --> Config Class Initialized
INFO - 2024-01-14 23:26:52 --> Hooks Class Initialized
DEBUG - 2024-01-14 23:26:52 --> UTF-8 Support Enabled
INFO - 2024-01-14 23:26:52 --> Utf8 Class Initialized
INFO - 2024-01-14 23:26:52 --> URI Class Initialized
INFO - 2024-01-14 23:26:52 --> Router Class Initialized
INFO - 2024-01-14 23:26:52 --> Output Class Initialized
INFO - 2024-01-14 23:26:52 --> Security Class Initialized
DEBUG - 2024-01-14 23:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 23:26:52 --> Input Class Initialized
INFO - 2024-01-14 23:26:52 --> Language Class Initialized
ERROR - 2024-01-14 23:26:52 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-01-14 23:56:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-14 23:56:16 --> Config Class Initialized
INFO - 2024-01-14 23:56:16 --> Hooks Class Initialized
DEBUG - 2024-01-14 23:56:16 --> UTF-8 Support Enabled
INFO - 2024-01-14 23:56:16 --> Utf8 Class Initialized
INFO - 2024-01-14 23:56:16 --> URI Class Initialized
INFO - 2024-01-14 23:56:16 --> Router Class Initialized
INFO - 2024-01-14 23:56:16 --> Output Class Initialized
INFO - 2024-01-14 23:56:16 --> Security Class Initialized
DEBUG - 2024-01-14 23:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-14 23:56:16 --> Input Class Initialized
INFO - 2024-01-14 23:56:16 --> Language Class Initialized
ERROR - 2024-01-14 23:56:16 --> 404 Page Not Found: Well-known/assetlinks.json
