<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-08 00:02:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-08 00:02:18 --> Config Class Initialized
INFO - 2023-12-08 00:02:18 --> Hooks Class Initialized
DEBUG - 2023-12-08 00:02:18 --> UTF-8 Support Enabled
INFO - 2023-12-08 00:02:18 --> Utf8 Class Initialized
INFO - 2023-12-08 00:02:18 --> URI Class Initialized
DEBUG - 2023-12-08 00:02:18 --> No URI present. Default controller set.
INFO - 2023-12-08 00:02:18 --> Router Class Initialized
INFO - 2023-12-08 00:02:18 --> Output Class Initialized
INFO - 2023-12-08 00:02:18 --> Security Class Initialized
DEBUG - 2023-12-08 00:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 00:02:18 --> Input Class Initialized
INFO - 2023-12-08 00:02:18 --> Language Class Initialized
INFO - 2023-12-08 00:02:18 --> Loader Class Initialized
INFO - 2023-12-08 00:02:18 --> Helper loaded: url_helper
INFO - 2023-12-08 00:02:18 --> Helper loaded: file_helper
INFO - 2023-12-08 00:02:18 --> Helper loaded: html_helper
INFO - 2023-12-08 00:02:18 --> Helper loaded: text_helper
INFO - 2023-12-08 00:02:18 --> Helper loaded: form_helper
INFO - 2023-12-08 00:02:18 --> Helper loaded: lang_helper
INFO - 2023-12-08 00:02:18 --> Helper loaded: security_helper
INFO - 2023-12-08 00:02:18 --> Helper loaded: cookie_helper
INFO - 2023-12-08 00:02:18 --> Database Driver Class Initialized
INFO - 2023-12-08 00:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 00:02:18 --> Parser Class Initialized
INFO - 2023-12-08 00:02:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-08 00:02:18 --> Pagination Class Initialized
INFO - 2023-12-08 00:02:18 --> Form Validation Class Initialized
INFO - 2023-12-08 00:02:18 --> Controller Class Initialized
INFO - 2023-12-08 00:02:18 --> Model Class Initialized
DEBUG - 2023-12-08 00:02:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-08 00:02:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-08 00:02:19 --> Config Class Initialized
INFO - 2023-12-08 00:02:19 --> Hooks Class Initialized
DEBUG - 2023-12-08 00:02:19 --> UTF-8 Support Enabled
INFO - 2023-12-08 00:02:19 --> Utf8 Class Initialized
INFO - 2023-12-08 00:02:19 --> URI Class Initialized
DEBUG - 2023-12-08 00:02:19 --> No URI present. Default controller set.
INFO - 2023-12-08 00:02:19 --> Router Class Initialized
INFO - 2023-12-08 00:02:19 --> Output Class Initialized
INFO - 2023-12-08 00:02:19 --> Security Class Initialized
DEBUG - 2023-12-08 00:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 00:02:19 --> Input Class Initialized
INFO - 2023-12-08 00:02:19 --> Language Class Initialized
INFO - 2023-12-08 00:02:19 --> Loader Class Initialized
INFO - 2023-12-08 00:02:19 --> Helper loaded: url_helper
INFO - 2023-12-08 00:02:19 --> Helper loaded: file_helper
INFO - 2023-12-08 00:02:19 --> Helper loaded: html_helper
INFO - 2023-12-08 00:02:19 --> Helper loaded: text_helper
INFO - 2023-12-08 00:02:19 --> Helper loaded: form_helper
INFO - 2023-12-08 00:02:19 --> Helper loaded: lang_helper
INFO - 2023-12-08 00:02:19 --> Helper loaded: security_helper
INFO - 2023-12-08 00:02:19 --> Helper loaded: cookie_helper
INFO - 2023-12-08 00:02:19 --> Database Driver Class Initialized
INFO - 2023-12-08 00:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 00:02:19 --> Parser Class Initialized
INFO - 2023-12-08 00:02:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-08 00:02:19 --> Pagination Class Initialized
INFO - 2023-12-08 00:02:19 --> Form Validation Class Initialized
INFO - 2023-12-08 00:02:19 --> Controller Class Initialized
INFO - 2023-12-08 00:02:19 --> Model Class Initialized
DEBUG - 2023-12-08 00:02:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-08 00:02:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-08 00:02:20 --> Config Class Initialized
INFO - 2023-12-08 00:02:20 --> Hooks Class Initialized
DEBUG - 2023-12-08 00:02:20 --> UTF-8 Support Enabled
INFO - 2023-12-08 00:02:20 --> Utf8 Class Initialized
INFO - 2023-12-08 00:02:20 --> URI Class Initialized
DEBUG - 2023-12-08 00:02:20 --> No URI present. Default controller set.
INFO - 2023-12-08 00:02:20 --> Router Class Initialized
INFO - 2023-12-08 00:02:20 --> Output Class Initialized
INFO - 2023-12-08 00:02:20 --> Security Class Initialized
DEBUG - 2023-12-08 00:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 00:02:20 --> Input Class Initialized
INFO - 2023-12-08 00:02:20 --> Language Class Initialized
INFO - 2023-12-08 00:02:20 --> Loader Class Initialized
INFO - 2023-12-08 00:02:20 --> Helper loaded: url_helper
INFO - 2023-12-08 00:02:20 --> Helper loaded: file_helper
INFO - 2023-12-08 00:02:20 --> Helper loaded: html_helper
INFO - 2023-12-08 00:02:20 --> Helper loaded: text_helper
INFO - 2023-12-08 00:02:20 --> Helper loaded: form_helper
INFO - 2023-12-08 00:02:20 --> Helper loaded: lang_helper
INFO - 2023-12-08 00:02:20 --> Helper loaded: security_helper
INFO - 2023-12-08 00:02:20 --> Helper loaded: cookie_helper
INFO - 2023-12-08 00:02:20 --> Database Driver Class Initialized
INFO - 2023-12-08 00:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 00:02:20 --> Parser Class Initialized
INFO - 2023-12-08 00:02:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-08 00:02:20 --> Pagination Class Initialized
INFO - 2023-12-08 00:02:20 --> Form Validation Class Initialized
INFO - 2023-12-08 00:02:20 --> Controller Class Initialized
INFO - 2023-12-08 00:02:20 --> Model Class Initialized
DEBUG - 2023-12-08 00:02:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-08 00:02:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-08 00:02:20 --> Config Class Initialized
INFO - 2023-12-08 00:02:20 --> Hooks Class Initialized
DEBUG - 2023-12-08 00:02:20 --> UTF-8 Support Enabled
INFO - 2023-12-08 00:02:20 --> Utf8 Class Initialized
INFO - 2023-12-08 00:02:20 --> URI Class Initialized
DEBUG - 2023-12-08 00:02:20 --> No URI present. Default controller set.
INFO - 2023-12-08 00:02:20 --> Router Class Initialized
INFO - 2023-12-08 00:02:20 --> Output Class Initialized
INFO - 2023-12-08 00:02:20 --> Security Class Initialized
DEBUG - 2023-12-08 00:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 00:02:20 --> Input Class Initialized
INFO - 2023-12-08 00:02:20 --> Language Class Initialized
INFO - 2023-12-08 00:02:20 --> Loader Class Initialized
INFO - 2023-12-08 00:02:20 --> Helper loaded: url_helper
INFO - 2023-12-08 00:02:20 --> Helper loaded: file_helper
INFO - 2023-12-08 00:02:20 --> Helper loaded: html_helper
INFO - 2023-12-08 00:02:20 --> Helper loaded: text_helper
INFO - 2023-12-08 00:02:20 --> Helper loaded: form_helper
INFO - 2023-12-08 00:02:20 --> Helper loaded: lang_helper
INFO - 2023-12-08 00:02:20 --> Helper loaded: security_helper
INFO - 2023-12-08 00:02:20 --> Helper loaded: cookie_helper
INFO - 2023-12-08 00:02:20 --> Database Driver Class Initialized
INFO - 2023-12-08 00:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 00:02:20 --> Parser Class Initialized
INFO - 2023-12-08 00:02:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-08 00:02:20 --> Pagination Class Initialized
INFO - 2023-12-08 00:02:20 --> Form Validation Class Initialized
INFO - 2023-12-08 00:02:20 --> Controller Class Initialized
INFO - 2023-12-08 00:02:20 --> Model Class Initialized
DEBUG - 2023-12-08 00:02:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-08 03:08:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-08 03:08:49 --> Config Class Initialized
INFO - 2023-12-08 03:08:49 --> Hooks Class Initialized
DEBUG - 2023-12-08 03:08:49 --> UTF-8 Support Enabled
INFO - 2023-12-08 03:08:49 --> Utf8 Class Initialized
INFO - 2023-12-08 03:08:49 --> URI Class Initialized
DEBUG - 2023-12-08 03:08:49 --> No URI present. Default controller set.
INFO - 2023-12-08 03:08:49 --> Router Class Initialized
INFO - 2023-12-08 03:08:49 --> Output Class Initialized
INFO - 2023-12-08 03:08:49 --> Security Class Initialized
DEBUG - 2023-12-08 03:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 03:08:49 --> Input Class Initialized
INFO - 2023-12-08 03:08:49 --> Language Class Initialized
INFO - 2023-12-08 03:08:49 --> Loader Class Initialized
INFO - 2023-12-08 03:08:49 --> Helper loaded: url_helper
INFO - 2023-12-08 03:08:49 --> Helper loaded: file_helper
INFO - 2023-12-08 03:08:49 --> Helper loaded: html_helper
INFO - 2023-12-08 03:08:49 --> Helper loaded: text_helper
INFO - 2023-12-08 03:08:49 --> Helper loaded: form_helper
INFO - 2023-12-08 03:08:49 --> Helper loaded: lang_helper
INFO - 2023-12-08 03:08:49 --> Helper loaded: security_helper
INFO - 2023-12-08 03:08:49 --> Helper loaded: cookie_helper
INFO - 2023-12-08 03:08:49 --> Database Driver Class Initialized
INFO - 2023-12-08 03:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 03:08:49 --> Parser Class Initialized
INFO - 2023-12-08 03:08:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-08 03:08:49 --> Pagination Class Initialized
INFO - 2023-12-08 03:08:49 --> Form Validation Class Initialized
INFO - 2023-12-08 03:08:49 --> Controller Class Initialized
INFO - 2023-12-08 03:08:49 --> Model Class Initialized
DEBUG - 2023-12-08 03:08:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-08 05:07:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-08 05:07:27 --> Config Class Initialized
INFO - 2023-12-08 05:07:27 --> Hooks Class Initialized
DEBUG - 2023-12-08 05:07:27 --> UTF-8 Support Enabled
INFO - 2023-12-08 05:07:27 --> Utf8 Class Initialized
INFO - 2023-12-08 05:07:27 --> URI Class Initialized
INFO - 2023-12-08 05:07:27 --> Router Class Initialized
INFO - 2023-12-08 05:07:27 --> Output Class Initialized
INFO - 2023-12-08 05:07:27 --> Security Class Initialized
DEBUG - 2023-12-08 05:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 05:07:27 --> Input Class Initialized
INFO - 2023-12-08 05:07:27 --> Language Class Initialized
ERROR - 2023-12-08 05:07:27 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-12-08 08:59:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-08 08:59:07 --> Config Class Initialized
INFO - 2023-12-08 08:59:07 --> Hooks Class Initialized
DEBUG - 2023-12-08 08:59:07 --> UTF-8 Support Enabled
INFO - 2023-12-08 08:59:07 --> Utf8 Class Initialized
INFO - 2023-12-08 08:59:07 --> URI Class Initialized
DEBUG - 2023-12-08 08:59:07 --> No URI present. Default controller set.
INFO - 2023-12-08 08:59:07 --> Router Class Initialized
INFO - 2023-12-08 08:59:07 --> Output Class Initialized
INFO - 2023-12-08 08:59:07 --> Security Class Initialized
DEBUG - 2023-12-08 08:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 08:59:07 --> Input Class Initialized
INFO - 2023-12-08 08:59:07 --> Language Class Initialized
INFO - 2023-12-08 08:59:07 --> Loader Class Initialized
INFO - 2023-12-08 08:59:07 --> Helper loaded: url_helper
INFO - 2023-12-08 08:59:07 --> Helper loaded: file_helper
INFO - 2023-12-08 08:59:07 --> Helper loaded: html_helper
INFO - 2023-12-08 08:59:07 --> Helper loaded: text_helper
INFO - 2023-12-08 08:59:07 --> Helper loaded: form_helper
INFO - 2023-12-08 08:59:07 --> Helper loaded: lang_helper
INFO - 2023-12-08 08:59:07 --> Helper loaded: security_helper
INFO - 2023-12-08 08:59:07 --> Helper loaded: cookie_helper
INFO - 2023-12-08 08:59:07 --> Database Driver Class Initialized
INFO - 2023-12-08 08:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 08:59:07 --> Parser Class Initialized
INFO - 2023-12-08 08:59:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-08 08:59:07 --> Pagination Class Initialized
INFO - 2023-12-08 08:59:07 --> Form Validation Class Initialized
INFO - 2023-12-08 08:59:07 --> Controller Class Initialized
INFO - 2023-12-08 08:59:07 --> Model Class Initialized
DEBUG - 2023-12-08 08:59:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-08 08:59:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-08 08:59:08 --> Config Class Initialized
INFO - 2023-12-08 08:59:08 --> Hooks Class Initialized
DEBUG - 2023-12-08 08:59:08 --> UTF-8 Support Enabled
INFO - 2023-12-08 08:59:08 --> Utf8 Class Initialized
INFO - 2023-12-08 08:59:08 --> URI Class Initialized
INFO - 2023-12-08 08:59:08 --> Router Class Initialized
INFO - 2023-12-08 08:59:08 --> Output Class Initialized
INFO - 2023-12-08 08:59:08 --> Security Class Initialized
DEBUG - 2023-12-08 08:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 08:59:08 --> Input Class Initialized
INFO - 2023-12-08 08:59:08 --> Language Class Initialized
INFO - 2023-12-08 08:59:08 --> Loader Class Initialized
INFO - 2023-12-08 08:59:08 --> Helper loaded: url_helper
INFO - 2023-12-08 08:59:08 --> Helper loaded: file_helper
INFO - 2023-12-08 08:59:08 --> Helper loaded: html_helper
INFO - 2023-12-08 08:59:08 --> Helper loaded: text_helper
INFO - 2023-12-08 08:59:08 --> Helper loaded: form_helper
INFO - 2023-12-08 08:59:08 --> Helper loaded: lang_helper
INFO - 2023-12-08 08:59:08 --> Helper loaded: security_helper
INFO - 2023-12-08 08:59:08 --> Helper loaded: cookie_helper
INFO - 2023-12-08 08:59:08 --> Database Driver Class Initialized
INFO - 2023-12-08 08:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 08:59:08 --> Parser Class Initialized
INFO - 2023-12-08 08:59:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-08 08:59:08 --> Pagination Class Initialized
INFO - 2023-12-08 08:59:08 --> Form Validation Class Initialized
INFO - 2023-12-08 08:59:08 --> Controller Class Initialized
INFO - 2023-12-08 08:59:08 --> Model Class Initialized
DEBUG - 2023-12-08 08:59:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-08 08:59:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-08 08:59:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-08 08:59:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-08 08:59:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-08 08:59:08 --> Model Class Initialized
INFO - 2023-12-08 08:59:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-08 08:59:08 --> Final output sent to browser
DEBUG - 2023-12-08 08:59:08 --> Total execution time: 0.0344
ERROR - 2023-12-08 08:59:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-08 08:59:29 --> Config Class Initialized
INFO - 2023-12-08 08:59:29 --> Hooks Class Initialized
DEBUG - 2023-12-08 08:59:29 --> UTF-8 Support Enabled
INFO - 2023-12-08 08:59:29 --> Utf8 Class Initialized
INFO - 2023-12-08 08:59:29 --> URI Class Initialized
INFO - 2023-12-08 08:59:29 --> Router Class Initialized
INFO - 2023-12-08 08:59:29 --> Output Class Initialized
INFO - 2023-12-08 08:59:29 --> Security Class Initialized
DEBUG - 2023-12-08 08:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 08:59:29 --> Input Class Initialized
INFO - 2023-12-08 08:59:29 --> Language Class Initialized
INFO - 2023-12-08 08:59:29 --> Loader Class Initialized
INFO - 2023-12-08 08:59:29 --> Helper loaded: url_helper
INFO - 2023-12-08 08:59:29 --> Helper loaded: file_helper
INFO - 2023-12-08 08:59:29 --> Helper loaded: html_helper
INFO - 2023-12-08 08:59:29 --> Helper loaded: text_helper
INFO - 2023-12-08 08:59:29 --> Helper loaded: form_helper
INFO - 2023-12-08 08:59:29 --> Helper loaded: lang_helper
INFO - 2023-12-08 08:59:29 --> Helper loaded: security_helper
INFO - 2023-12-08 08:59:29 --> Helper loaded: cookie_helper
INFO - 2023-12-08 08:59:29 --> Database Driver Class Initialized
INFO - 2023-12-08 08:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 08:59:30 --> Parser Class Initialized
INFO - 2023-12-08 08:59:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-08 08:59:30 --> Pagination Class Initialized
INFO - 2023-12-08 08:59:30 --> Form Validation Class Initialized
INFO - 2023-12-08 08:59:30 --> Controller Class Initialized
INFO - 2023-12-08 08:59:30 --> Model Class Initialized
DEBUG - 2023-12-08 08:59:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-08 08:59:30 --> Model Class Initialized
INFO - 2023-12-08 08:59:30 --> Final output sent to browser
DEBUG - 2023-12-08 08:59:30 --> Total execution time: 0.0197
ERROR - 2023-12-08 08:59:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-08 08:59:30 --> Config Class Initialized
INFO - 2023-12-08 08:59:30 --> Hooks Class Initialized
DEBUG - 2023-12-08 08:59:30 --> UTF-8 Support Enabled
INFO - 2023-12-08 08:59:30 --> Utf8 Class Initialized
INFO - 2023-12-08 08:59:30 --> URI Class Initialized
DEBUG - 2023-12-08 08:59:30 --> No URI present. Default controller set.
INFO - 2023-12-08 08:59:30 --> Router Class Initialized
INFO - 2023-12-08 08:59:30 --> Output Class Initialized
INFO - 2023-12-08 08:59:30 --> Security Class Initialized
DEBUG - 2023-12-08 08:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 08:59:30 --> Input Class Initialized
INFO - 2023-12-08 08:59:30 --> Language Class Initialized
INFO - 2023-12-08 08:59:30 --> Loader Class Initialized
INFO - 2023-12-08 08:59:30 --> Helper loaded: url_helper
INFO - 2023-12-08 08:59:30 --> Helper loaded: file_helper
INFO - 2023-12-08 08:59:30 --> Helper loaded: html_helper
INFO - 2023-12-08 08:59:30 --> Helper loaded: text_helper
INFO - 2023-12-08 08:59:30 --> Helper loaded: form_helper
INFO - 2023-12-08 08:59:30 --> Helper loaded: lang_helper
INFO - 2023-12-08 08:59:30 --> Helper loaded: security_helper
INFO - 2023-12-08 08:59:30 --> Helper loaded: cookie_helper
INFO - 2023-12-08 08:59:30 --> Database Driver Class Initialized
INFO - 2023-12-08 08:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 08:59:30 --> Parser Class Initialized
INFO - 2023-12-08 08:59:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-08 08:59:30 --> Pagination Class Initialized
INFO - 2023-12-08 08:59:30 --> Form Validation Class Initialized
INFO - 2023-12-08 08:59:30 --> Controller Class Initialized
INFO - 2023-12-08 08:59:30 --> Model Class Initialized
DEBUG - 2023-12-08 08:59:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-08 08:59:30 --> Model Class Initialized
DEBUG - 2023-12-08 08:59:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-08 08:59:30 --> Model Class Initialized
INFO - 2023-12-08 08:59:30 --> Model Class Initialized
INFO - 2023-12-08 08:59:30 --> Model Class Initialized
INFO - 2023-12-08 08:59:30 --> Model Class Initialized
DEBUG - 2023-12-08 08:59:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-08 08:59:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-08 08:59:30 --> Model Class Initialized
INFO - 2023-12-08 08:59:30 --> Model Class Initialized
INFO - 2023-12-08 08:59:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-08 08:59:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-08 08:59:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-08 08:59:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-08 08:59:30 --> Model Class Initialized
INFO - 2023-12-08 08:59:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-08 08:59:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-08 08:59:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-08 08:59:30 --> Final output sent to browser
DEBUG - 2023-12-08 08:59:30 --> Total execution time: 0.3838
ERROR - 2023-12-08 08:59:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-08 08:59:31 --> Config Class Initialized
INFO - 2023-12-08 08:59:31 --> Hooks Class Initialized
DEBUG - 2023-12-08 08:59:31 --> UTF-8 Support Enabled
INFO - 2023-12-08 08:59:31 --> Utf8 Class Initialized
INFO - 2023-12-08 08:59:31 --> URI Class Initialized
INFO - 2023-12-08 08:59:31 --> Router Class Initialized
INFO - 2023-12-08 08:59:31 --> Output Class Initialized
INFO - 2023-12-08 08:59:31 --> Security Class Initialized
DEBUG - 2023-12-08 08:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 08:59:31 --> Input Class Initialized
INFO - 2023-12-08 08:59:31 --> Language Class Initialized
INFO - 2023-12-08 08:59:31 --> Loader Class Initialized
INFO - 2023-12-08 08:59:31 --> Helper loaded: url_helper
INFO - 2023-12-08 08:59:31 --> Helper loaded: file_helper
INFO - 2023-12-08 08:59:31 --> Helper loaded: html_helper
INFO - 2023-12-08 08:59:31 --> Helper loaded: text_helper
INFO - 2023-12-08 08:59:31 --> Helper loaded: form_helper
INFO - 2023-12-08 08:59:31 --> Helper loaded: lang_helper
INFO - 2023-12-08 08:59:31 --> Helper loaded: security_helper
INFO - 2023-12-08 08:59:31 --> Helper loaded: cookie_helper
INFO - 2023-12-08 08:59:31 --> Database Driver Class Initialized
INFO - 2023-12-08 08:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 08:59:31 --> Parser Class Initialized
INFO - 2023-12-08 08:59:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-08 08:59:31 --> Pagination Class Initialized
INFO - 2023-12-08 08:59:31 --> Form Validation Class Initialized
INFO - 2023-12-08 08:59:31 --> Controller Class Initialized
DEBUG - 2023-12-08 08:59:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-08 08:59:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-08 08:59:31 --> Model Class Initialized
INFO - 2023-12-08 08:59:31 --> Final output sent to browser
DEBUG - 2023-12-08 08:59:31 --> Total execution time: 0.0136
ERROR - 2023-12-08 17:14:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-08 17:14:45 --> Config Class Initialized
INFO - 2023-12-08 17:14:45 --> Hooks Class Initialized
DEBUG - 2023-12-08 17:14:45 --> UTF-8 Support Enabled
INFO - 2023-12-08 17:14:45 --> Utf8 Class Initialized
INFO - 2023-12-08 17:14:45 --> URI Class Initialized
INFO - 2023-12-08 17:14:45 --> Router Class Initialized
INFO - 2023-12-08 17:14:45 --> Output Class Initialized
INFO - 2023-12-08 17:14:45 --> Security Class Initialized
DEBUG - 2023-12-08 17:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 17:14:45 --> Input Class Initialized
INFO - 2023-12-08 17:14:45 --> Language Class Initialized
ERROR - 2023-12-08 17:14:45 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-12-08 20:50:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-08 20:50:15 --> Config Class Initialized
INFO - 2023-12-08 20:50:15 --> Hooks Class Initialized
DEBUG - 2023-12-08 20:50:15 --> UTF-8 Support Enabled
INFO - 2023-12-08 20:50:15 --> Utf8 Class Initialized
INFO - 2023-12-08 20:50:15 --> URI Class Initialized
DEBUG - 2023-12-08 20:50:15 --> No URI present. Default controller set.
INFO - 2023-12-08 20:50:15 --> Router Class Initialized
INFO - 2023-12-08 20:50:15 --> Output Class Initialized
INFO - 2023-12-08 20:50:15 --> Security Class Initialized
DEBUG - 2023-12-08 20:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 20:50:15 --> Input Class Initialized
INFO - 2023-12-08 20:50:15 --> Language Class Initialized
INFO - 2023-12-08 20:50:15 --> Loader Class Initialized
INFO - 2023-12-08 20:50:15 --> Helper loaded: url_helper
INFO - 2023-12-08 20:50:15 --> Helper loaded: file_helper
INFO - 2023-12-08 20:50:15 --> Helper loaded: html_helper
INFO - 2023-12-08 20:50:15 --> Helper loaded: text_helper
INFO - 2023-12-08 20:50:15 --> Helper loaded: form_helper
INFO - 2023-12-08 20:50:15 --> Helper loaded: lang_helper
INFO - 2023-12-08 20:50:15 --> Helper loaded: security_helper
INFO - 2023-12-08 20:50:15 --> Helper loaded: cookie_helper
INFO - 2023-12-08 20:50:15 --> Database Driver Class Initialized
INFO - 2023-12-08 20:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 20:50:15 --> Parser Class Initialized
INFO - 2023-12-08 20:50:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-08 20:50:15 --> Pagination Class Initialized
INFO - 2023-12-08 20:50:15 --> Form Validation Class Initialized
INFO - 2023-12-08 20:50:15 --> Controller Class Initialized
INFO - 2023-12-08 20:50:15 --> Model Class Initialized
DEBUG - 2023-12-08 20:50:15 --> Session class already loaded. Second attempt ignored.
