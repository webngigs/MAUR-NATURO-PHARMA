<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-12 01:12:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-12 01:12:59 --> Config Class Initialized
INFO - 2023-10-12 01:12:59 --> Hooks Class Initialized
DEBUG - 2023-10-12 01:12:59 --> UTF-8 Support Enabled
INFO - 2023-10-12 01:12:59 --> Utf8 Class Initialized
INFO - 2023-10-12 01:12:59 --> URI Class Initialized
DEBUG - 2023-10-12 01:12:59 --> No URI present. Default controller set.
INFO - 2023-10-12 01:12:59 --> Router Class Initialized
INFO - 2023-10-12 01:12:59 --> Output Class Initialized
INFO - 2023-10-12 01:12:59 --> Security Class Initialized
DEBUG - 2023-10-12 01:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 01:12:59 --> Input Class Initialized
INFO - 2023-10-12 01:12:59 --> Language Class Initialized
INFO - 2023-10-12 01:12:59 --> Loader Class Initialized
INFO - 2023-10-12 01:12:59 --> Helper loaded: url_helper
INFO - 2023-10-12 01:12:59 --> Helper loaded: file_helper
INFO - 2023-10-12 01:12:59 --> Helper loaded: html_helper
INFO - 2023-10-12 01:12:59 --> Helper loaded: text_helper
INFO - 2023-10-12 01:12:59 --> Helper loaded: form_helper
INFO - 2023-10-12 01:12:59 --> Helper loaded: lang_helper
INFO - 2023-10-12 01:12:59 --> Helper loaded: security_helper
INFO - 2023-10-12 01:12:59 --> Helper loaded: cookie_helper
INFO - 2023-10-12 01:12:59 --> Database Driver Class Initialized
INFO - 2023-10-12 01:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 01:12:59 --> Parser Class Initialized
INFO - 2023-10-12 01:12:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-12 01:12:59 --> Pagination Class Initialized
INFO - 2023-10-12 01:12:59 --> Form Validation Class Initialized
INFO - 2023-10-12 01:12:59 --> Controller Class Initialized
INFO - 2023-10-12 01:12:59 --> Model Class Initialized
DEBUG - 2023-10-12 01:12:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-12 01:13:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-12 01:13:00 --> Config Class Initialized
INFO - 2023-10-12 01:13:00 --> Hooks Class Initialized
DEBUG - 2023-10-12 01:13:00 --> UTF-8 Support Enabled
INFO - 2023-10-12 01:13:00 --> Utf8 Class Initialized
INFO - 2023-10-12 01:13:00 --> URI Class Initialized
INFO - 2023-10-12 01:13:00 --> Router Class Initialized
INFO - 2023-10-12 01:13:00 --> Output Class Initialized
INFO - 2023-10-12 01:13:00 --> Security Class Initialized
DEBUG - 2023-10-12 01:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 01:13:00 --> Input Class Initialized
INFO - 2023-10-12 01:13:00 --> Language Class Initialized
INFO - 2023-10-12 01:13:00 --> Loader Class Initialized
INFO - 2023-10-12 01:13:00 --> Helper loaded: url_helper
INFO - 2023-10-12 01:13:00 --> Helper loaded: file_helper
INFO - 2023-10-12 01:13:00 --> Helper loaded: html_helper
INFO - 2023-10-12 01:13:00 --> Helper loaded: text_helper
INFO - 2023-10-12 01:13:00 --> Helper loaded: form_helper
INFO - 2023-10-12 01:13:00 --> Helper loaded: lang_helper
INFO - 2023-10-12 01:13:00 --> Helper loaded: security_helper
INFO - 2023-10-12 01:13:00 --> Helper loaded: cookie_helper
INFO - 2023-10-12 01:13:00 --> Database Driver Class Initialized
INFO - 2023-10-12 01:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 01:13:00 --> Parser Class Initialized
INFO - 2023-10-12 01:13:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-12 01:13:00 --> Pagination Class Initialized
INFO - 2023-10-12 01:13:00 --> Form Validation Class Initialized
INFO - 2023-10-12 01:13:00 --> Controller Class Initialized
INFO - 2023-10-12 01:13:00 --> Model Class Initialized
DEBUG - 2023-10-12 01:13:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-12 01:13:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-12 01:13:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-12 01:13:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-12 01:13:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-12 01:13:00 --> Model Class Initialized
INFO - 2023-10-12 01:13:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-12 01:13:00 --> Final output sent to browser
DEBUG - 2023-10-12 01:13:00 --> Total execution time: 0.0350
ERROR - 2023-10-12 01:13:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-12 01:13:18 --> Config Class Initialized
INFO - 2023-10-12 01:13:18 --> Hooks Class Initialized
DEBUG - 2023-10-12 01:13:18 --> UTF-8 Support Enabled
INFO - 2023-10-12 01:13:18 --> Utf8 Class Initialized
INFO - 2023-10-12 01:13:18 --> URI Class Initialized
INFO - 2023-10-12 01:13:18 --> Router Class Initialized
INFO - 2023-10-12 01:13:18 --> Output Class Initialized
INFO - 2023-10-12 01:13:18 --> Security Class Initialized
DEBUG - 2023-10-12 01:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 01:13:18 --> Input Class Initialized
INFO - 2023-10-12 01:13:18 --> Language Class Initialized
INFO - 2023-10-12 01:13:18 --> Loader Class Initialized
INFO - 2023-10-12 01:13:18 --> Helper loaded: url_helper
INFO - 2023-10-12 01:13:18 --> Helper loaded: file_helper
INFO - 2023-10-12 01:13:18 --> Helper loaded: html_helper
INFO - 2023-10-12 01:13:18 --> Helper loaded: text_helper
INFO - 2023-10-12 01:13:18 --> Helper loaded: form_helper
INFO - 2023-10-12 01:13:18 --> Helper loaded: lang_helper
INFO - 2023-10-12 01:13:18 --> Helper loaded: security_helper
INFO - 2023-10-12 01:13:18 --> Helper loaded: cookie_helper
INFO - 2023-10-12 01:13:18 --> Database Driver Class Initialized
INFO - 2023-10-12 01:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 01:13:18 --> Parser Class Initialized
INFO - 2023-10-12 01:13:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-12 01:13:18 --> Pagination Class Initialized
INFO - 2023-10-12 01:13:18 --> Form Validation Class Initialized
INFO - 2023-10-12 01:13:18 --> Controller Class Initialized
INFO - 2023-10-12 01:13:18 --> Model Class Initialized
DEBUG - 2023-10-12 01:13:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-12 01:13:18 --> Model Class Initialized
INFO - 2023-10-12 01:13:18 --> Final output sent to browser
DEBUG - 2023-10-12 01:13:18 --> Total execution time: 0.0218
ERROR - 2023-10-12 01:13:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-12 01:13:18 --> Config Class Initialized
INFO - 2023-10-12 01:13:18 --> Hooks Class Initialized
DEBUG - 2023-10-12 01:13:18 --> UTF-8 Support Enabled
INFO - 2023-10-12 01:13:18 --> Utf8 Class Initialized
INFO - 2023-10-12 01:13:18 --> URI Class Initialized
DEBUG - 2023-10-12 01:13:18 --> No URI present. Default controller set.
INFO - 2023-10-12 01:13:18 --> Router Class Initialized
INFO - 2023-10-12 01:13:18 --> Output Class Initialized
INFO - 2023-10-12 01:13:18 --> Security Class Initialized
DEBUG - 2023-10-12 01:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 01:13:18 --> Input Class Initialized
INFO - 2023-10-12 01:13:18 --> Language Class Initialized
INFO - 2023-10-12 01:13:18 --> Loader Class Initialized
INFO - 2023-10-12 01:13:18 --> Helper loaded: url_helper
INFO - 2023-10-12 01:13:18 --> Helper loaded: file_helper
INFO - 2023-10-12 01:13:18 --> Helper loaded: html_helper
INFO - 2023-10-12 01:13:18 --> Helper loaded: text_helper
INFO - 2023-10-12 01:13:18 --> Helper loaded: form_helper
INFO - 2023-10-12 01:13:18 --> Helper loaded: lang_helper
INFO - 2023-10-12 01:13:18 --> Helper loaded: security_helper
INFO - 2023-10-12 01:13:18 --> Helper loaded: cookie_helper
INFO - 2023-10-12 01:13:18 --> Database Driver Class Initialized
INFO - 2023-10-12 01:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 01:13:18 --> Parser Class Initialized
INFO - 2023-10-12 01:13:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-12 01:13:18 --> Pagination Class Initialized
INFO - 2023-10-12 01:13:18 --> Form Validation Class Initialized
INFO - 2023-10-12 01:13:18 --> Controller Class Initialized
INFO - 2023-10-12 01:13:18 --> Model Class Initialized
DEBUG - 2023-10-12 01:13:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-12 01:13:18 --> Model Class Initialized
DEBUG - 2023-10-12 01:13:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-12 01:13:18 --> Model Class Initialized
INFO - 2023-10-12 01:13:18 --> Model Class Initialized
INFO - 2023-10-12 01:13:18 --> Model Class Initialized
INFO - 2023-10-12 01:13:18 --> Model Class Initialized
DEBUG - 2023-10-12 01:13:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-12 01:13:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-12 01:13:18 --> Model Class Initialized
INFO - 2023-10-12 01:13:18 --> Model Class Initialized
INFO - 2023-10-12 01:13:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-12 01:13:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-12 01:13:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-12 01:13:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-12 01:13:18 --> Model Class Initialized
INFO - 2023-10-12 01:13:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-12 01:13:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-12 01:13:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-12 01:13:18 --> Final output sent to browser
DEBUG - 2023-10-12 01:13:18 --> Total execution time: 0.2101
ERROR - 2023-10-12 01:13:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-12 01:13:45 --> Config Class Initialized
INFO - 2023-10-12 01:13:45 --> Hooks Class Initialized
DEBUG - 2023-10-12 01:13:45 --> UTF-8 Support Enabled
INFO - 2023-10-12 01:13:45 --> Utf8 Class Initialized
INFO - 2023-10-12 01:13:45 --> URI Class Initialized
INFO - 2023-10-12 01:13:45 --> Router Class Initialized
INFO - 2023-10-12 01:13:45 --> Output Class Initialized
INFO - 2023-10-12 01:13:45 --> Security Class Initialized
DEBUG - 2023-10-12 01:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 01:13:45 --> Input Class Initialized
INFO - 2023-10-12 01:13:45 --> Language Class Initialized
INFO - 2023-10-12 01:13:45 --> Loader Class Initialized
INFO - 2023-10-12 01:13:45 --> Helper loaded: url_helper
INFO - 2023-10-12 01:13:45 --> Helper loaded: file_helper
INFO - 2023-10-12 01:13:45 --> Helper loaded: html_helper
INFO - 2023-10-12 01:13:45 --> Helper loaded: text_helper
INFO - 2023-10-12 01:13:45 --> Helper loaded: form_helper
INFO - 2023-10-12 01:13:45 --> Helper loaded: lang_helper
INFO - 2023-10-12 01:13:45 --> Helper loaded: security_helper
INFO - 2023-10-12 01:13:45 --> Helper loaded: cookie_helper
INFO - 2023-10-12 01:13:45 --> Database Driver Class Initialized
INFO - 2023-10-12 01:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 01:13:45 --> Parser Class Initialized
INFO - 2023-10-12 01:13:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-12 01:13:45 --> Pagination Class Initialized
INFO - 2023-10-12 01:13:45 --> Form Validation Class Initialized
INFO - 2023-10-12 01:13:45 --> Controller Class Initialized
INFO - 2023-10-12 01:13:45 --> Model Class Initialized
DEBUG - 2023-10-12 01:13:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-12 01:13:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-12 01:13:45 --> Model Class Initialized
DEBUG - 2023-10-12 01:13:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-12 01:13:45 --> Model Class Initialized
INFO - 2023-10-12 01:13:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-12 01:13:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-12 01:13:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-12 01:13:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-12 01:13:45 --> Model Class Initialized
INFO - 2023-10-12 01:13:45 --> Model Class Initialized
INFO - 2023-10-12 01:13:45 --> Model Class Initialized
INFO - 2023-10-12 01:13:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-12 01:13:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-12 01:13:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-12 01:13:45 --> Final output sent to browser
DEBUG - 2023-10-12 01:13:45 --> Total execution time: 0.1557
ERROR - 2023-10-12 01:13:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-12 01:13:46 --> Config Class Initialized
INFO - 2023-10-12 01:13:46 --> Hooks Class Initialized
DEBUG - 2023-10-12 01:13:46 --> UTF-8 Support Enabled
INFO - 2023-10-12 01:13:46 --> Utf8 Class Initialized
INFO - 2023-10-12 01:13:46 --> URI Class Initialized
INFO - 2023-10-12 01:13:46 --> Router Class Initialized
INFO - 2023-10-12 01:13:46 --> Output Class Initialized
INFO - 2023-10-12 01:13:46 --> Security Class Initialized
DEBUG - 2023-10-12 01:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 01:13:46 --> Input Class Initialized
INFO - 2023-10-12 01:13:46 --> Language Class Initialized
INFO - 2023-10-12 01:13:46 --> Loader Class Initialized
INFO - 2023-10-12 01:13:46 --> Helper loaded: url_helper
INFO - 2023-10-12 01:13:46 --> Helper loaded: file_helper
INFO - 2023-10-12 01:13:46 --> Helper loaded: html_helper
INFO - 2023-10-12 01:13:46 --> Helper loaded: text_helper
INFO - 2023-10-12 01:13:46 --> Helper loaded: form_helper
INFO - 2023-10-12 01:13:46 --> Helper loaded: lang_helper
INFO - 2023-10-12 01:13:46 --> Helper loaded: security_helper
INFO - 2023-10-12 01:13:46 --> Helper loaded: cookie_helper
INFO - 2023-10-12 01:13:46 --> Database Driver Class Initialized
INFO - 2023-10-12 01:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 01:13:46 --> Parser Class Initialized
INFO - 2023-10-12 01:13:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-12 01:13:46 --> Pagination Class Initialized
INFO - 2023-10-12 01:13:46 --> Form Validation Class Initialized
INFO - 2023-10-12 01:13:46 --> Controller Class Initialized
INFO - 2023-10-12 01:13:46 --> Model Class Initialized
DEBUG - 2023-10-12 01:13:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-12 01:13:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-12 01:13:46 --> Model Class Initialized
DEBUG - 2023-10-12 01:13:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-12 01:13:46 --> Model Class Initialized
INFO - 2023-10-12 01:13:46 --> Final output sent to browser
DEBUG - 2023-10-12 01:13:46 --> Total execution time: 0.2072
ERROR - 2023-10-12 01:13:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-12 01:13:55 --> Config Class Initialized
INFO - 2023-10-12 01:13:55 --> Hooks Class Initialized
DEBUG - 2023-10-12 01:13:55 --> UTF-8 Support Enabled
INFO - 2023-10-12 01:13:55 --> Utf8 Class Initialized
INFO - 2023-10-12 01:13:55 --> URI Class Initialized
INFO - 2023-10-12 01:13:55 --> Router Class Initialized
INFO - 2023-10-12 01:13:55 --> Output Class Initialized
INFO - 2023-10-12 01:13:55 --> Security Class Initialized
DEBUG - 2023-10-12 01:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 01:13:55 --> Input Class Initialized
INFO - 2023-10-12 01:13:55 --> Language Class Initialized
INFO - 2023-10-12 01:13:55 --> Loader Class Initialized
INFO - 2023-10-12 01:13:55 --> Helper loaded: url_helper
INFO - 2023-10-12 01:13:55 --> Helper loaded: file_helper
INFO - 2023-10-12 01:13:55 --> Helper loaded: html_helper
INFO - 2023-10-12 01:13:55 --> Helper loaded: text_helper
INFO - 2023-10-12 01:13:55 --> Helper loaded: form_helper
INFO - 2023-10-12 01:13:55 --> Helper loaded: lang_helper
INFO - 2023-10-12 01:13:55 --> Helper loaded: security_helper
INFO - 2023-10-12 01:13:55 --> Helper loaded: cookie_helper
INFO - 2023-10-12 01:13:55 --> Database Driver Class Initialized
INFO - 2023-10-12 01:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 01:13:55 --> Parser Class Initialized
INFO - 2023-10-12 01:13:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-12 01:13:55 --> Pagination Class Initialized
INFO - 2023-10-12 01:13:55 --> Form Validation Class Initialized
INFO - 2023-10-12 01:13:55 --> Controller Class Initialized
INFO - 2023-10-12 01:13:55 --> Model Class Initialized
DEBUG - 2023-10-12 01:13:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-12 01:13:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-12 01:13:55 --> Model Class Initialized
DEBUG - 2023-10-12 01:13:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-12 01:13:55 --> Model Class Initialized
INFO - 2023-10-12 01:13:55 --> Final output sent to browser
DEBUG - 2023-10-12 01:13:55 --> Total execution time: 0.0305
ERROR - 2023-10-12 01:14:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-12 01:14:14 --> Config Class Initialized
INFO - 2023-10-12 01:14:14 --> Hooks Class Initialized
DEBUG - 2023-10-12 01:14:14 --> UTF-8 Support Enabled
INFO - 2023-10-12 01:14:14 --> Utf8 Class Initialized
INFO - 2023-10-12 01:14:14 --> URI Class Initialized
INFO - 2023-10-12 01:14:14 --> Router Class Initialized
INFO - 2023-10-12 01:14:14 --> Output Class Initialized
INFO - 2023-10-12 01:14:14 --> Security Class Initialized
DEBUG - 2023-10-12 01:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 01:14:14 --> Input Class Initialized
INFO - 2023-10-12 01:14:14 --> Language Class Initialized
INFO - 2023-10-12 01:14:14 --> Loader Class Initialized
INFO - 2023-10-12 01:14:14 --> Helper loaded: url_helper
INFO - 2023-10-12 01:14:14 --> Helper loaded: file_helper
INFO - 2023-10-12 01:14:14 --> Helper loaded: html_helper
INFO - 2023-10-12 01:14:14 --> Helper loaded: text_helper
INFO - 2023-10-12 01:14:14 --> Helper loaded: form_helper
INFO - 2023-10-12 01:14:14 --> Helper loaded: lang_helper
INFO - 2023-10-12 01:14:14 --> Helper loaded: security_helper
INFO - 2023-10-12 01:14:14 --> Helper loaded: cookie_helper
INFO - 2023-10-12 01:14:14 --> Database Driver Class Initialized
INFO - 2023-10-12 01:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 01:14:14 --> Parser Class Initialized
INFO - 2023-10-12 01:14:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-12 01:14:14 --> Pagination Class Initialized
INFO - 2023-10-12 01:14:14 --> Form Validation Class Initialized
INFO - 2023-10-12 01:14:14 --> Controller Class Initialized
INFO - 2023-10-12 01:14:14 --> Model Class Initialized
DEBUG - 2023-10-12 01:14:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-12 01:14:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-12 01:14:14 --> Model Class Initialized
DEBUG - 2023-10-12 01:14:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-12 01:14:14 --> Model Class Initialized
DEBUG - 2023-10-12 01:14:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-12 01:14:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-10-12 01:14:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-12 01:14:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-12 01:14:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-12 01:14:14 --> Model Class Initialized
INFO - 2023-10-12 01:14:14 --> Model Class Initialized
INFO - 2023-10-12 01:14:14 --> Model Class Initialized
INFO - 2023-10-12 01:14:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-12 01:14:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-12 01:14:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-12 01:14:14 --> Final output sent to browser
DEBUG - 2023-10-12 01:14:14 --> Total execution time: 0.1527
ERROR - 2023-10-12 04:02:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-12 04:02:32 --> Config Class Initialized
INFO - 2023-10-12 04:02:32 --> Hooks Class Initialized
DEBUG - 2023-10-12 04:02:32 --> UTF-8 Support Enabled
INFO - 2023-10-12 04:02:32 --> Utf8 Class Initialized
INFO - 2023-10-12 04:02:32 --> URI Class Initialized
DEBUG - 2023-10-12 04:02:32 --> No URI present. Default controller set.
INFO - 2023-10-12 04:02:32 --> Router Class Initialized
INFO - 2023-10-12 04:02:32 --> Output Class Initialized
INFO - 2023-10-12 04:02:32 --> Security Class Initialized
DEBUG - 2023-10-12 04:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 04:02:32 --> Input Class Initialized
INFO - 2023-10-12 04:02:32 --> Language Class Initialized
INFO - 2023-10-12 04:02:32 --> Loader Class Initialized
INFO - 2023-10-12 04:02:32 --> Helper loaded: url_helper
INFO - 2023-10-12 04:02:32 --> Helper loaded: file_helper
INFO - 2023-10-12 04:02:32 --> Helper loaded: html_helper
INFO - 2023-10-12 04:02:32 --> Helper loaded: text_helper
INFO - 2023-10-12 04:02:32 --> Helper loaded: form_helper
INFO - 2023-10-12 04:02:32 --> Helper loaded: lang_helper
INFO - 2023-10-12 04:02:32 --> Helper loaded: security_helper
INFO - 2023-10-12 04:02:32 --> Helper loaded: cookie_helper
INFO - 2023-10-12 04:02:32 --> Database Driver Class Initialized
INFO - 2023-10-12 04:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 04:02:32 --> Parser Class Initialized
INFO - 2023-10-12 04:02:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-12 04:02:32 --> Pagination Class Initialized
INFO - 2023-10-12 04:02:32 --> Form Validation Class Initialized
INFO - 2023-10-12 04:02:32 --> Controller Class Initialized
INFO - 2023-10-12 04:02:32 --> Model Class Initialized
DEBUG - 2023-10-12 04:02:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-12 05:12:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-12 05:12:03 --> Config Class Initialized
INFO - 2023-10-12 05:12:03 --> Hooks Class Initialized
DEBUG - 2023-10-12 05:12:03 --> UTF-8 Support Enabled
INFO - 2023-10-12 05:12:03 --> Utf8 Class Initialized
INFO - 2023-10-12 05:12:03 --> URI Class Initialized
DEBUG - 2023-10-12 05:12:03 --> No URI present. Default controller set.
INFO - 2023-10-12 05:12:03 --> Router Class Initialized
INFO - 2023-10-12 05:12:03 --> Output Class Initialized
INFO - 2023-10-12 05:12:03 --> Security Class Initialized
DEBUG - 2023-10-12 05:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 05:12:03 --> Input Class Initialized
INFO - 2023-10-12 05:12:03 --> Language Class Initialized
INFO - 2023-10-12 05:12:03 --> Loader Class Initialized
INFO - 2023-10-12 05:12:03 --> Helper loaded: url_helper
INFO - 2023-10-12 05:12:03 --> Helper loaded: file_helper
INFO - 2023-10-12 05:12:03 --> Helper loaded: html_helper
INFO - 2023-10-12 05:12:03 --> Helper loaded: text_helper
INFO - 2023-10-12 05:12:03 --> Helper loaded: form_helper
INFO - 2023-10-12 05:12:03 --> Helper loaded: lang_helper
INFO - 2023-10-12 05:12:03 --> Helper loaded: security_helper
INFO - 2023-10-12 05:12:03 --> Helper loaded: cookie_helper
INFO - 2023-10-12 05:12:03 --> Database Driver Class Initialized
INFO - 2023-10-12 05:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 05:12:03 --> Parser Class Initialized
INFO - 2023-10-12 05:12:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-12 05:12:03 --> Pagination Class Initialized
INFO - 2023-10-12 05:12:03 --> Form Validation Class Initialized
INFO - 2023-10-12 05:12:03 --> Controller Class Initialized
INFO - 2023-10-12 05:12:03 --> Model Class Initialized
DEBUG - 2023-10-12 05:12:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-12 05:12:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-12 05:12:03 --> Config Class Initialized
INFO - 2023-10-12 05:12:03 --> Hooks Class Initialized
DEBUG - 2023-10-12 05:12:03 --> UTF-8 Support Enabled
INFO - 2023-10-12 05:12:03 --> Utf8 Class Initialized
INFO - 2023-10-12 05:12:03 --> URI Class Initialized
INFO - 2023-10-12 05:12:03 --> Router Class Initialized
INFO - 2023-10-12 05:12:03 --> Output Class Initialized
INFO - 2023-10-12 05:12:03 --> Security Class Initialized
DEBUG - 2023-10-12 05:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 05:12:03 --> Input Class Initialized
INFO - 2023-10-12 05:12:03 --> Language Class Initialized
INFO - 2023-10-12 05:12:03 --> Loader Class Initialized
INFO - 2023-10-12 05:12:03 --> Helper loaded: url_helper
INFO - 2023-10-12 05:12:03 --> Helper loaded: file_helper
INFO - 2023-10-12 05:12:03 --> Helper loaded: html_helper
INFO - 2023-10-12 05:12:03 --> Helper loaded: text_helper
INFO - 2023-10-12 05:12:03 --> Helper loaded: form_helper
INFO - 2023-10-12 05:12:03 --> Helper loaded: lang_helper
INFO - 2023-10-12 05:12:03 --> Helper loaded: security_helper
INFO - 2023-10-12 05:12:03 --> Helper loaded: cookie_helper
INFO - 2023-10-12 05:12:03 --> Database Driver Class Initialized
INFO - 2023-10-12 05:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 05:12:03 --> Parser Class Initialized
INFO - 2023-10-12 05:12:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-12 05:12:03 --> Pagination Class Initialized
INFO - 2023-10-12 05:12:03 --> Form Validation Class Initialized
INFO - 2023-10-12 05:12:03 --> Controller Class Initialized
INFO - 2023-10-12 05:12:03 --> Model Class Initialized
DEBUG - 2023-10-12 05:12:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-12 05:12:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-12 05:12:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-12 05:12:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-12 05:12:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-12 05:12:03 --> Model Class Initialized
INFO - 2023-10-12 05:12:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-12 05:12:03 --> Final output sent to browser
DEBUG - 2023-10-12 05:12:03 --> Total execution time: 0.0338
ERROR - 2023-10-12 09:46:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-12 09:46:04 --> Config Class Initialized
INFO - 2023-10-12 09:46:04 --> Hooks Class Initialized
DEBUG - 2023-10-12 09:46:04 --> UTF-8 Support Enabled
INFO - 2023-10-12 09:46:04 --> Utf8 Class Initialized
INFO - 2023-10-12 09:46:04 --> URI Class Initialized
DEBUG - 2023-10-12 09:46:04 --> No URI present. Default controller set.
INFO - 2023-10-12 09:46:04 --> Router Class Initialized
INFO - 2023-10-12 09:46:04 --> Output Class Initialized
INFO - 2023-10-12 09:46:04 --> Security Class Initialized
DEBUG - 2023-10-12 09:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 09:46:04 --> Input Class Initialized
INFO - 2023-10-12 09:46:04 --> Language Class Initialized
INFO - 2023-10-12 09:46:04 --> Loader Class Initialized
INFO - 2023-10-12 09:46:04 --> Helper loaded: url_helper
INFO - 2023-10-12 09:46:04 --> Helper loaded: file_helper
INFO - 2023-10-12 09:46:04 --> Helper loaded: html_helper
INFO - 2023-10-12 09:46:04 --> Helper loaded: text_helper
INFO - 2023-10-12 09:46:04 --> Helper loaded: form_helper
INFO - 2023-10-12 09:46:04 --> Helper loaded: lang_helper
INFO - 2023-10-12 09:46:04 --> Helper loaded: security_helper
INFO - 2023-10-12 09:46:04 --> Helper loaded: cookie_helper
INFO - 2023-10-12 09:46:04 --> Database Driver Class Initialized
INFO - 2023-10-12 09:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 09:46:04 --> Parser Class Initialized
INFO - 2023-10-12 09:46:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-12 09:46:04 --> Pagination Class Initialized
INFO - 2023-10-12 09:46:04 --> Form Validation Class Initialized
INFO - 2023-10-12 09:46:04 --> Controller Class Initialized
INFO - 2023-10-12 09:46:04 --> Model Class Initialized
DEBUG - 2023-10-12 09:46:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-12 09:46:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-12 09:46:04 --> Config Class Initialized
INFO - 2023-10-12 09:46:04 --> Hooks Class Initialized
DEBUG - 2023-10-12 09:46:04 --> UTF-8 Support Enabled
INFO - 2023-10-12 09:46:04 --> Utf8 Class Initialized
INFO - 2023-10-12 09:46:04 --> URI Class Initialized
INFO - 2023-10-12 09:46:04 --> Router Class Initialized
INFO - 2023-10-12 09:46:04 --> Output Class Initialized
INFO - 2023-10-12 09:46:04 --> Security Class Initialized
DEBUG - 2023-10-12 09:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 09:46:04 --> Input Class Initialized
INFO - 2023-10-12 09:46:04 --> Language Class Initialized
INFO - 2023-10-12 09:46:05 --> Loader Class Initialized
INFO - 2023-10-12 09:46:05 --> Helper loaded: url_helper
INFO - 2023-10-12 09:46:05 --> Helper loaded: file_helper
INFO - 2023-10-12 09:46:05 --> Helper loaded: html_helper
INFO - 2023-10-12 09:46:05 --> Helper loaded: text_helper
INFO - 2023-10-12 09:46:05 --> Helper loaded: form_helper
INFO - 2023-10-12 09:46:05 --> Helper loaded: lang_helper
INFO - 2023-10-12 09:46:05 --> Helper loaded: security_helper
INFO - 2023-10-12 09:46:05 --> Helper loaded: cookie_helper
INFO - 2023-10-12 09:46:05 --> Database Driver Class Initialized
INFO - 2023-10-12 09:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 09:46:05 --> Parser Class Initialized
INFO - 2023-10-12 09:46:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-12 09:46:05 --> Pagination Class Initialized
INFO - 2023-10-12 09:46:05 --> Form Validation Class Initialized
INFO - 2023-10-12 09:46:05 --> Controller Class Initialized
INFO - 2023-10-12 09:46:05 --> Model Class Initialized
DEBUG - 2023-10-12 09:46:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-12 09:46:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-12 09:46:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-12 09:46:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-12 09:46:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-12 09:46:05 --> Model Class Initialized
INFO - 2023-10-12 09:46:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-12 09:46:05 --> Final output sent to browser
DEBUG - 2023-10-12 09:46:05 --> Total execution time: 0.0318
ERROR - 2023-10-12 09:46:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-12 09:46:07 --> Config Class Initialized
INFO - 2023-10-12 09:46:07 --> Hooks Class Initialized
DEBUG - 2023-10-12 09:46:07 --> UTF-8 Support Enabled
INFO - 2023-10-12 09:46:07 --> Utf8 Class Initialized
INFO - 2023-10-12 09:46:07 --> URI Class Initialized
INFO - 2023-10-12 09:46:07 --> Router Class Initialized
INFO - 2023-10-12 09:46:07 --> Output Class Initialized
INFO - 2023-10-12 09:46:07 --> Security Class Initialized
DEBUG - 2023-10-12 09:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 09:46:07 --> Input Class Initialized
INFO - 2023-10-12 09:46:07 --> Language Class Initialized
INFO - 2023-10-12 09:46:07 --> Loader Class Initialized
INFO - 2023-10-12 09:46:07 --> Helper loaded: url_helper
INFO - 2023-10-12 09:46:07 --> Helper loaded: file_helper
INFO - 2023-10-12 09:46:07 --> Helper loaded: html_helper
INFO - 2023-10-12 09:46:07 --> Helper loaded: text_helper
INFO - 2023-10-12 09:46:07 --> Helper loaded: form_helper
INFO - 2023-10-12 09:46:07 --> Helper loaded: lang_helper
INFO - 2023-10-12 09:46:07 --> Helper loaded: security_helper
INFO - 2023-10-12 09:46:07 --> Helper loaded: cookie_helper
INFO - 2023-10-12 09:46:07 --> Database Driver Class Initialized
INFO - 2023-10-12 09:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 09:46:07 --> Parser Class Initialized
INFO - 2023-10-12 09:46:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-12 09:46:07 --> Pagination Class Initialized
INFO - 2023-10-12 09:46:07 --> Form Validation Class Initialized
INFO - 2023-10-12 09:46:07 --> Controller Class Initialized
INFO - 2023-10-12 09:46:07 --> Model Class Initialized
DEBUG - 2023-10-12 09:46:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-12 09:46:07 --> Model Class Initialized
INFO - 2023-10-12 09:46:07 --> Final output sent to browser
DEBUG - 2023-10-12 09:46:07 --> Total execution time: 0.0193
ERROR - 2023-10-12 09:46:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-12 09:46:08 --> Config Class Initialized
INFO - 2023-10-12 09:46:08 --> Hooks Class Initialized
DEBUG - 2023-10-12 09:46:08 --> UTF-8 Support Enabled
INFO - 2023-10-12 09:46:08 --> Utf8 Class Initialized
INFO - 2023-10-12 09:46:08 --> URI Class Initialized
DEBUG - 2023-10-12 09:46:08 --> No URI present. Default controller set.
INFO - 2023-10-12 09:46:08 --> Router Class Initialized
INFO - 2023-10-12 09:46:08 --> Output Class Initialized
INFO - 2023-10-12 09:46:08 --> Security Class Initialized
DEBUG - 2023-10-12 09:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 09:46:08 --> Input Class Initialized
INFO - 2023-10-12 09:46:08 --> Language Class Initialized
INFO - 2023-10-12 09:46:08 --> Loader Class Initialized
INFO - 2023-10-12 09:46:08 --> Helper loaded: url_helper
INFO - 2023-10-12 09:46:08 --> Helper loaded: file_helper
INFO - 2023-10-12 09:46:08 --> Helper loaded: html_helper
INFO - 2023-10-12 09:46:08 --> Helper loaded: text_helper
INFO - 2023-10-12 09:46:08 --> Helper loaded: form_helper
INFO - 2023-10-12 09:46:08 --> Helper loaded: lang_helper
INFO - 2023-10-12 09:46:08 --> Helper loaded: security_helper
INFO - 2023-10-12 09:46:08 --> Helper loaded: cookie_helper
INFO - 2023-10-12 09:46:08 --> Database Driver Class Initialized
INFO - 2023-10-12 09:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 09:46:08 --> Parser Class Initialized
INFO - 2023-10-12 09:46:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-12 09:46:08 --> Pagination Class Initialized
INFO - 2023-10-12 09:46:08 --> Form Validation Class Initialized
INFO - 2023-10-12 09:46:08 --> Controller Class Initialized
INFO - 2023-10-12 09:46:08 --> Model Class Initialized
DEBUG - 2023-10-12 09:46:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-12 09:46:08 --> Model Class Initialized
DEBUG - 2023-10-12 09:46:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-12 09:46:08 --> Model Class Initialized
INFO - 2023-10-12 09:46:08 --> Model Class Initialized
INFO - 2023-10-12 09:46:08 --> Model Class Initialized
INFO - 2023-10-12 09:46:08 --> Model Class Initialized
DEBUG - 2023-10-12 09:46:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-12 09:46:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-12 09:46:08 --> Model Class Initialized
INFO - 2023-10-12 09:46:08 --> Model Class Initialized
INFO - 2023-10-12 09:46:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-12 09:46:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-12 09:46:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-12 09:46:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-12 09:46:08 --> Model Class Initialized
INFO - 2023-10-12 09:46:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-12 09:46:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-12 09:46:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-12 09:46:08 --> Final output sent to browser
DEBUG - 2023-10-12 09:46:08 --> Total execution time: 0.3930
ERROR - 2023-10-12 09:46:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-12 09:46:09 --> Config Class Initialized
INFO - 2023-10-12 09:46:09 --> Hooks Class Initialized
DEBUG - 2023-10-12 09:46:09 --> UTF-8 Support Enabled
INFO - 2023-10-12 09:46:09 --> Utf8 Class Initialized
INFO - 2023-10-12 09:46:09 --> URI Class Initialized
INFO - 2023-10-12 09:46:09 --> Router Class Initialized
INFO - 2023-10-12 09:46:09 --> Output Class Initialized
INFO - 2023-10-12 09:46:09 --> Security Class Initialized
DEBUG - 2023-10-12 09:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 09:46:09 --> Input Class Initialized
INFO - 2023-10-12 09:46:09 --> Language Class Initialized
INFO - 2023-10-12 09:46:09 --> Loader Class Initialized
INFO - 2023-10-12 09:46:09 --> Helper loaded: url_helper
INFO - 2023-10-12 09:46:09 --> Helper loaded: file_helper
INFO - 2023-10-12 09:46:09 --> Helper loaded: html_helper
INFO - 2023-10-12 09:46:09 --> Helper loaded: text_helper
INFO - 2023-10-12 09:46:09 --> Helper loaded: form_helper
INFO - 2023-10-12 09:46:09 --> Helper loaded: lang_helper
INFO - 2023-10-12 09:46:09 --> Helper loaded: security_helper
INFO - 2023-10-12 09:46:09 --> Helper loaded: cookie_helper
INFO - 2023-10-12 09:46:09 --> Database Driver Class Initialized
INFO - 2023-10-12 09:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 09:46:09 --> Parser Class Initialized
INFO - 2023-10-12 09:46:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-12 09:46:09 --> Pagination Class Initialized
INFO - 2023-10-12 09:46:09 --> Form Validation Class Initialized
INFO - 2023-10-12 09:46:09 --> Controller Class Initialized
DEBUG - 2023-10-12 09:46:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-12 09:46:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-12 09:46:09 --> Model Class Initialized
INFO - 2023-10-12 09:46:09 --> Final output sent to browser
DEBUG - 2023-10-12 09:46:09 --> Total execution time: 0.0161
ERROR - 2023-10-12 09:49:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-12 09:49:04 --> Config Class Initialized
INFO - 2023-10-12 09:49:04 --> Hooks Class Initialized
DEBUG - 2023-10-12 09:49:04 --> UTF-8 Support Enabled
INFO - 2023-10-12 09:49:04 --> Utf8 Class Initialized
INFO - 2023-10-12 09:49:04 --> URI Class Initialized
INFO - 2023-10-12 09:49:04 --> Router Class Initialized
INFO - 2023-10-12 09:49:04 --> Output Class Initialized
INFO - 2023-10-12 09:49:04 --> Security Class Initialized
DEBUG - 2023-10-12 09:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 09:49:04 --> Input Class Initialized
INFO - 2023-10-12 09:49:04 --> Language Class Initialized
INFO - 2023-10-12 09:49:04 --> Loader Class Initialized
INFO - 2023-10-12 09:49:04 --> Helper loaded: url_helper
INFO - 2023-10-12 09:49:04 --> Helper loaded: file_helper
INFO - 2023-10-12 09:49:04 --> Helper loaded: html_helper
INFO - 2023-10-12 09:49:04 --> Helper loaded: text_helper
INFO - 2023-10-12 09:49:04 --> Helper loaded: form_helper
INFO - 2023-10-12 09:49:04 --> Helper loaded: lang_helper
INFO - 2023-10-12 09:49:04 --> Helper loaded: security_helper
INFO - 2023-10-12 09:49:04 --> Helper loaded: cookie_helper
INFO - 2023-10-12 09:49:04 --> Database Driver Class Initialized
INFO - 2023-10-12 09:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 09:49:04 --> Parser Class Initialized
INFO - 2023-10-12 09:49:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-12 09:49:04 --> Pagination Class Initialized
INFO - 2023-10-12 09:49:04 --> Form Validation Class Initialized
INFO - 2023-10-12 09:49:04 --> Controller Class Initialized
INFO - 2023-10-12 09:49:04 --> Model Class Initialized
DEBUG - 2023-10-12 09:49:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-12 09:49:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-12 09:49:04 --> Model Class Initialized
DEBUG - 2023-10-12 09:49:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-12 09:49:04 --> Model Class Initialized
INFO - 2023-10-12 09:49:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-12 09:49:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-12 09:49:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-12 09:49:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-12 09:49:04 --> Model Class Initialized
INFO - 2023-10-12 09:49:04 --> Model Class Initialized
INFO - 2023-10-12 09:49:04 --> Model Class Initialized
INFO - 2023-10-12 09:49:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-12 09:49:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-12 09:49:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-12 09:49:04 --> Final output sent to browser
DEBUG - 2023-10-12 09:49:04 --> Total execution time: 0.1999
ERROR - 2023-10-12 09:49:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-12 09:49:05 --> Config Class Initialized
INFO - 2023-10-12 09:49:05 --> Hooks Class Initialized
DEBUG - 2023-10-12 09:49:05 --> UTF-8 Support Enabled
INFO - 2023-10-12 09:49:05 --> Utf8 Class Initialized
INFO - 2023-10-12 09:49:05 --> URI Class Initialized
INFO - 2023-10-12 09:49:05 --> Router Class Initialized
INFO - 2023-10-12 09:49:05 --> Output Class Initialized
INFO - 2023-10-12 09:49:05 --> Security Class Initialized
DEBUG - 2023-10-12 09:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 09:49:05 --> Input Class Initialized
INFO - 2023-10-12 09:49:05 --> Language Class Initialized
INFO - 2023-10-12 09:49:05 --> Loader Class Initialized
INFO - 2023-10-12 09:49:05 --> Helper loaded: url_helper
INFO - 2023-10-12 09:49:05 --> Helper loaded: file_helper
INFO - 2023-10-12 09:49:05 --> Helper loaded: html_helper
INFO - 2023-10-12 09:49:05 --> Helper loaded: text_helper
INFO - 2023-10-12 09:49:05 --> Helper loaded: form_helper
INFO - 2023-10-12 09:49:05 --> Helper loaded: lang_helper
INFO - 2023-10-12 09:49:05 --> Helper loaded: security_helper
INFO - 2023-10-12 09:49:05 --> Helper loaded: cookie_helper
INFO - 2023-10-12 09:49:05 --> Database Driver Class Initialized
INFO - 2023-10-12 09:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 09:49:05 --> Parser Class Initialized
INFO - 2023-10-12 09:49:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-12 09:49:05 --> Pagination Class Initialized
INFO - 2023-10-12 09:49:05 --> Form Validation Class Initialized
INFO - 2023-10-12 09:49:05 --> Controller Class Initialized
INFO - 2023-10-12 09:49:05 --> Model Class Initialized
DEBUG - 2023-10-12 09:49:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-12 09:49:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-12 09:49:05 --> Model Class Initialized
DEBUG - 2023-10-12 09:49:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-12 09:49:05 --> Model Class Initialized
INFO - 2023-10-12 09:49:05 --> Final output sent to browser
DEBUG - 2023-10-12 09:49:05 --> Total execution time: 0.0638
ERROR - 2023-10-12 09:49:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-12 09:49:11 --> Config Class Initialized
INFO - 2023-10-12 09:49:11 --> Hooks Class Initialized
DEBUG - 2023-10-12 09:49:11 --> UTF-8 Support Enabled
INFO - 2023-10-12 09:49:11 --> Utf8 Class Initialized
INFO - 2023-10-12 09:49:11 --> URI Class Initialized
DEBUG - 2023-10-12 09:49:11 --> No URI present. Default controller set.
INFO - 2023-10-12 09:49:11 --> Router Class Initialized
INFO - 2023-10-12 09:49:11 --> Output Class Initialized
INFO - 2023-10-12 09:49:11 --> Security Class Initialized
DEBUG - 2023-10-12 09:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 09:49:11 --> Input Class Initialized
INFO - 2023-10-12 09:49:11 --> Language Class Initialized
INFO - 2023-10-12 09:49:11 --> Loader Class Initialized
INFO - 2023-10-12 09:49:11 --> Helper loaded: url_helper
INFO - 2023-10-12 09:49:11 --> Helper loaded: file_helper
INFO - 2023-10-12 09:49:11 --> Helper loaded: html_helper
INFO - 2023-10-12 09:49:11 --> Helper loaded: text_helper
INFO - 2023-10-12 09:49:11 --> Helper loaded: form_helper
INFO - 2023-10-12 09:49:11 --> Helper loaded: lang_helper
INFO - 2023-10-12 09:49:11 --> Helper loaded: security_helper
INFO - 2023-10-12 09:49:11 --> Helper loaded: cookie_helper
INFO - 2023-10-12 09:49:11 --> Database Driver Class Initialized
INFO - 2023-10-12 09:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 09:49:11 --> Parser Class Initialized
INFO - 2023-10-12 09:49:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-12 09:49:11 --> Pagination Class Initialized
INFO - 2023-10-12 09:49:11 --> Form Validation Class Initialized
INFO - 2023-10-12 09:49:11 --> Controller Class Initialized
INFO - 2023-10-12 09:49:11 --> Model Class Initialized
DEBUG - 2023-10-12 09:49:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-12 09:49:11 --> Model Class Initialized
DEBUG - 2023-10-12 09:49:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-12 09:49:11 --> Model Class Initialized
INFO - 2023-10-12 09:49:11 --> Model Class Initialized
INFO - 2023-10-12 09:49:11 --> Model Class Initialized
INFO - 2023-10-12 09:49:11 --> Model Class Initialized
DEBUG - 2023-10-12 09:49:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-12 09:49:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-12 09:49:11 --> Model Class Initialized
INFO - 2023-10-12 09:49:11 --> Model Class Initialized
INFO - 2023-10-12 09:49:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-12 09:49:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-12 09:49:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-12 09:49:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-12 09:49:11 --> Model Class Initialized
INFO - 2023-10-12 09:49:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-12 09:49:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-12 09:49:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-12 09:49:11 --> Final output sent to browser
DEBUG - 2023-10-12 09:49:11 --> Total execution time: 0.3527
ERROR - 2023-10-12 09:50:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-12 09:50:55 --> Config Class Initialized
INFO - 2023-10-12 09:50:55 --> Hooks Class Initialized
DEBUG - 2023-10-12 09:50:55 --> UTF-8 Support Enabled
INFO - 2023-10-12 09:50:55 --> Utf8 Class Initialized
INFO - 2023-10-12 09:50:55 --> URI Class Initialized
INFO - 2023-10-12 09:50:55 --> Router Class Initialized
INFO - 2023-10-12 09:50:55 --> Output Class Initialized
INFO - 2023-10-12 09:50:55 --> Security Class Initialized
DEBUG - 2023-10-12 09:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 09:50:55 --> Input Class Initialized
INFO - 2023-10-12 09:50:55 --> Language Class Initialized
INFO - 2023-10-12 09:50:55 --> Loader Class Initialized
INFO - 2023-10-12 09:50:55 --> Helper loaded: url_helper
INFO - 2023-10-12 09:50:55 --> Helper loaded: file_helper
INFO - 2023-10-12 09:50:55 --> Helper loaded: html_helper
INFO - 2023-10-12 09:50:55 --> Helper loaded: text_helper
INFO - 2023-10-12 09:50:55 --> Helper loaded: form_helper
INFO - 2023-10-12 09:50:55 --> Helper loaded: lang_helper
INFO - 2023-10-12 09:50:55 --> Helper loaded: security_helper
INFO - 2023-10-12 09:50:55 --> Helper loaded: cookie_helper
INFO - 2023-10-12 09:50:55 --> Database Driver Class Initialized
INFO - 2023-10-12 09:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 09:50:55 --> Parser Class Initialized
INFO - 2023-10-12 09:50:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-12 09:50:55 --> Pagination Class Initialized
INFO - 2023-10-12 09:50:55 --> Form Validation Class Initialized
INFO - 2023-10-12 09:50:55 --> Controller Class Initialized
DEBUG - 2023-10-12 09:50:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-12 09:50:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-12 09:50:55 --> Model Class Initialized
DEBUG - 2023-10-12 09:50:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-12 09:50:55 --> Model Class Initialized
DEBUG - 2023-10-12 09:50:55 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-10-12 09:50:55 --> Model Class Initialized
INFO - 2023-10-12 09:50:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-10-12 09:50:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-12 09:50:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-12 09:50:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-12 09:50:55 --> Model Class Initialized
INFO - 2023-10-12 09:50:55 --> Model Class Initialized
INFO - 2023-10-12 09:50:55 --> Model Class Initialized
INFO - 2023-10-12 09:50:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-12 09:50:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-12 09:50:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-12 09:50:55 --> Final output sent to browser
DEBUG - 2023-10-12 09:50:55 --> Total execution time: 0.2549
ERROR - 2023-10-12 09:50:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-12 09:50:56 --> Config Class Initialized
INFO - 2023-10-12 09:50:56 --> Hooks Class Initialized
DEBUG - 2023-10-12 09:50:56 --> UTF-8 Support Enabled
INFO - 2023-10-12 09:50:56 --> Utf8 Class Initialized
INFO - 2023-10-12 09:50:56 --> URI Class Initialized
INFO - 2023-10-12 09:50:56 --> Router Class Initialized
INFO - 2023-10-12 09:50:56 --> Output Class Initialized
INFO - 2023-10-12 09:50:56 --> Security Class Initialized
DEBUG - 2023-10-12 09:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 09:50:56 --> Input Class Initialized
INFO - 2023-10-12 09:50:56 --> Language Class Initialized
INFO - 2023-10-12 09:50:56 --> Loader Class Initialized
INFO - 2023-10-12 09:50:56 --> Helper loaded: url_helper
INFO - 2023-10-12 09:50:56 --> Helper loaded: file_helper
INFO - 2023-10-12 09:50:56 --> Helper loaded: html_helper
INFO - 2023-10-12 09:50:56 --> Helper loaded: text_helper
INFO - 2023-10-12 09:50:56 --> Helper loaded: form_helper
INFO - 2023-10-12 09:50:56 --> Helper loaded: lang_helper
INFO - 2023-10-12 09:50:56 --> Helper loaded: security_helper
INFO - 2023-10-12 09:50:56 --> Helper loaded: cookie_helper
INFO - 2023-10-12 09:50:56 --> Database Driver Class Initialized
INFO - 2023-10-12 09:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 09:50:56 --> Parser Class Initialized
INFO - 2023-10-12 09:50:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-12 09:50:56 --> Pagination Class Initialized
INFO - 2023-10-12 09:50:56 --> Form Validation Class Initialized
INFO - 2023-10-12 09:50:56 --> Controller Class Initialized
DEBUG - 2023-10-12 09:50:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-12 09:50:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-12 09:50:56 --> Model Class Initialized
DEBUG - 2023-10-12 09:50:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-12 09:50:56 --> Model Class Initialized
INFO - 2023-10-12 09:50:56 --> Final output sent to browser
DEBUG - 2023-10-12 09:50:56 --> Total execution time: 0.0319
ERROR - 2023-10-12 09:51:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-12 09:51:00 --> Config Class Initialized
INFO - 2023-10-12 09:51:00 --> Hooks Class Initialized
DEBUG - 2023-10-12 09:51:00 --> UTF-8 Support Enabled
INFO - 2023-10-12 09:51:00 --> Utf8 Class Initialized
INFO - 2023-10-12 09:51:00 --> URI Class Initialized
INFO - 2023-10-12 09:51:00 --> Router Class Initialized
INFO - 2023-10-12 09:51:00 --> Output Class Initialized
INFO - 2023-10-12 09:51:00 --> Security Class Initialized
DEBUG - 2023-10-12 09:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 09:51:00 --> Input Class Initialized
INFO - 2023-10-12 09:51:00 --> Language Class Initialized
INFO - 2023-10-12 09:51:00 --> Loader Class Initialized
INFO - 2023-10-12 09:51:00 --> Helper loaded: url_helper
INFO - 2023-10-12 09:51:00 --> Helper loaded: file_helper
INFO - 2023-10-12 09:51:00 --> Helper loaded: html_helper
INFO - 2023-10-12 09:51:00 --> Helper loaded: text_helper
INFO - 2023-10-12 09:51:00 --> Helper loaded: form_helper
INFO - 2023-10-12 09:51:00 --> Helper loaded: lang_helper
INFO - 2023-10-12 09:51:00 --> Helper loaded: security_helper
INFO - 2023-10-12 09:51:00 --> Helper loaded: cookie_helper
INFO - 2023-10-12 09:51:00 --> Database Driver Class Initialized
INFO - 2023-10-12 09:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 09:51:00 --> Parser Class Initialized
INFO - 2023-10-12 09:51:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-12 09:51:00 --> Pagination Class Initialized
INFO - 2023-10-12 09:51:00 --> Form Validation Class Initialized
INFO - 2023-10-12 09:51:00 --> Controller Class Initialized
DEBUG - 2023-10-12 09:51:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-12 09:51:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-12 09:51:00 --> Model Class Initialized
DEBUG - 2023-10-12 09:51:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-12 09:51:00 --> Model Class Initialized
INFO - 2023-10-12 09:51:00 --> Final output sent to browser
DEBUG - 2023-10-12 09:51:00 --> Total execution time: 0.1609
ERROR - 2023-10-12 09:51:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-12 09:51:35 --> Config Class Initialized
INFO - 2023-10-12 09:51:35 --> Hooks Class Initialized
DEBUG - 2023-10-12 09:51:35 --> UTF-8 Support Enabled
INFO - 2023-10-12 09:51:35 --> Utf8 Class Initialized
INFO - 2023-10-12 09:51:35 --> URI Class Initialized
DEBUG - 2023-10-12 09:51:35 --> No URI present. Default controller set.
INFO - 2023-10-12 09:51:35 --> Router Class Initialized
INFO - 2023-10-12 09:51:35 --> Output Class Initialized
INFO - 2023-10-12 09:51:35 --> Security Class Initialized
DEBUG - 2023-10-12 09:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 09:51:35 --> Input Class Initialized
INFO - 2023-10-12 09:51:35 --> Language Class Initialized
INFO - 2023-10-12 09:51:35 --> Loader Class Initialized
INFO - 2023-10-12 09:51:35 --> Helper loaded: url_helper
INFO - 2023-10-12 09:51:35 --> Helper loaded: file_helper
INFO - 2023-10-12 09:51:35 --> Helper loaded: html_helper
INFO - 2023-10-12 09:51:35 --> Helper loaded: text_helper
INFO - 2023-10-12 09:51:35 --> Helper loaded: form_helper
INFO - 2023-10-12 09:51:35 --> Helper loaded: lang_helper
INFO - 2023-10-12 09:51:35 --> Helper loaded: security_helper
INFO - 2023-10-12 09:51:35 --> Helper loaded: cookie_helper
INFO - 2023-10-12 09:51:35 --> Database Driver Class Initialized
INFO - 2023-10-12 09:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 09:51:35 --> Parser Class Initialized
INFO - 2023-10-12 09:51:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-12 09:51:35 --> Pagination Class Initialized
INFO - 2023-10-12 09:51:35 --> Form Validation Class Initialized
INFO - 2023-10-12 09:51:35 --> Controller Class Initialized
INFO - 2023-10-12 09:51:35 --> Model Class Initialized
DEBUG - 2023-10-12 09:51:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-12 09:51:35 --> Model Class Initialized
DEBUG - 2023-10-12 09:51:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-12 09:51:35 --> Model Class Initialized
INFO - 2023-10-12 09:51:35 --> Model Class Initialized
INFO - 2023-10-12 09:51:35 --> Model Class Initialized
INFO - 2023-10-12 09:51:35 --> Model Class Initialized
DEBUG - 2023-10-12 09:51:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-12 09:51:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-12 09:51:35 --> Model Class Initialized
INFO - 2023-10-12 09:51:35 --> Model Class Initialized
INFO - 2023-10-12 09:51:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-12 09:51:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-12 09:51:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-12 09:51:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-12 09:51:35 --> Model Class Initialized
INFO - 2023-10-12 09:51:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-12 09:51:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-12 09:51:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-12 09:51:35 --> Final output sent to browser
DEBUG - 2023-10-12 09:51:35 --> Total execution time: 0.3723
ERROR - 2023-10-12 10:01:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-12 10:01:44 --> Config Class Initialized
INFO - 2023-10-12 10:01:44 --> Hooks Class Initialized
DEBUG - 2023-10-12 10:01:44 --> UTF-8 Support Enabled
INFO - 2023-10-12 10:01:44 --> Utf8 Class Initialized
INFO - 2023-10-12 10:01:44 --> URI Class Initialized
DEBUG - 2023-10-12 10:01:44 --> No URI present. Default controller set.
INFO - 2023-10-12 10:01:44 --> Router Class Initialized
INFO - 2023-10-12 10:01:44 --> Output Class Initialized
INFO - 2023-10-12 10:01:44 --> Security Class Initialized
DEBUG - 2023-10-12 10:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 10:01:44 --> Input Class Initialized
INFO - 2023-10-12 10:01:44 --> Language Class Initialized
INFO - 2023-10-12 10:01:44 --> Loader Class Initialized
INFO - 2023-10-12 10:01:44 --> Helper loaded: url_helper
INFO - 2023-10-12 10:01:44 --> Helper loaded: file_helper
INFO - 2023-10-12 10:01:44 --> Helper loaded: html_helper
INFO - 2023-10-12 10:01:44 --> Helper loaded: text_helper
INFO - 2023-10-12 10:01:44 --> Helper loaded: form_helper
INFO - 2023-10-12 10:01:44 --> Helper loaded: lang_helper
INFO - 2023-10-12 10:01:44 --> Helper loaded: security_helper
INFO - 2023-10-12 10:01:44 --> Helper loaded: cookie_helper
INFO - 2023-10-12 10:01:44 --> Database Driver Class Initialized
INFO - 2023-10-12 10:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 10:01:44 --> Parser Class Initialized
INFO - 2023-10-12 10:01:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-12 10:01:44 --> Pagination Class Initialized
INFO - 2023-10-12 10:01:44 --> Form Validation Class Initialized
INFO - 2023-10-12 10:01:44 --> Controller Class Initialized
INFO - 2023-10-12 10:01:44 --> Model Class Initialized
DEBUG - 2023-10-12 10:01:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-12 10:01:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-12 10:01:45 --> Config Class Initialized
INFO - 2023-10-12 10:01:45 --> Hooks Class Initialized
DEBUG - 2023-10-12 10:01:45 --> UTF-8 Support Enabled
INFO - 2023-10-12 10:01:45 --> Utf8 Class Initialized
INFO - 2023-10-12 10:01:45 --> URI Class Initialized
DEBUG - 2023-10-12 10:01:45 --> No URI present. Default controller set.
INFO - 2023-10-12 10:01:45 --> Router Class Initialized
INFO - 2023-10-12 10:01:45 --> Output Class Initialized
INFO - 2023-10-12 10:01:45 --> Security Class Initialized
DEBUG - 2023-10-12 10:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 10:01:45 --> Input Class Initialized
INFO - 2023-10-12 10:01:45 --> Language Class Initialized
INFO - 2023-10-12 10:01:45 --> Loader Class Initialized
INFO - 2023-10-12 10:01:45 --> Helper loaded: url_helper
INFO - 2023-10-12 10:01:45 --> Helper loaded: file_helper
INFO - 2023-10-12 10:01:45 --> Helper loaded: html_helper
INFO - 2023-10-12 10:01:45 --> Helper loaded: text_helper
INFO - 2023-10-12 10:01:45 --> Helper loaded: form_helper
INFO - 2023-10-12 10:01:45 --> Helper loaded: lang_helper
INFO - 2023-10-12 10:01:45 --> Helper loaded: security_helper
INFO - 2023-10-12 10:01:45 --> Helper loaded: cookie_helper
INFO - 2023-10-12 10:01:45 --> Database Driver Class Initialized
INFO - 2023-10-12 10:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 10:01:45 --> Parser Class Initialized
INFO - 2023-10-12 10:01:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-12 10:01:45 --> Pagination Class Initialized
INFO - 2023-10-12 10:01:45 --> Form Validation Class Initialized
INFO - 2023-10-12 10:01:45 --> Controller Class Initialized
INFO - 2023-10-12 10:01:45 --> Model Class Initialized
DEBUG - 2023-10-12 10:01:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-12 10:01:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-12 10:01:45 --> Config Class Initialized
INFO - 2023-10-12 10:01:45 --> Hooks Class Initialized
DEBUG - 2023-10-12 10:01:45 --> UTF-8 Support Enabled
INFO - 2023-10-12 10:01:45 --> Utf8 Class Initialized
INFO - 2023-10-12 10:01:45 --> URI Class Initialized
INFO - 2023-10-12 10:01:45 --> Router Class Initialized
INFO - 2023-10-12 10:01:45 --> Output Class Initialized
INFO - 2023-10-12 10:01:45 --> Security Class Initialized
DEBUG - 2023-10-12 10:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 10:01:45 --> Input Class Initialized
INFO - 2023-10-12 10:01:45 --> Language Class Initialized
INFO - 2023-10-12 10:01:45 --> Loader Class Initialized
INFO - 2023-10-12 10:01:45 --> Helper loaded: url_helper
INFO - 2023-10-12 10:01:45 --> Helper loaded: file_helper
INFO - 2023-10-12 10:01:45 --> Helper loaded: html_helper
INFO - 2023-10-12 10:01:45 --> Helper loaded: text_helper
INFO - 2023-10-12 10:01:45 --> Helper loaded: form_helper
INFO - 2023-10-12 10:01:45 --> Helper loaded: lang_helper
INFO - 2023-10-12 10:01:45 --> Helper loaded: security_helper
INFO - 2023-10-12 10:01:45 --> Helper loaded: cookie_helper
INFO - 2023-10-12 10:01:45 --> Database Driver Class Initialized
INFO - 2023-10-12 10:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 10:01:45 --> Parser Class Initialized
INFO - 2023-10-12 10:01:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-12 10:01:45 --> Pagination Class Initialized
INFO - 2023-10-12 10:01:45 --> Form Validation Class Initialized
INFO - 2023-10-12 10:01:45 --> Controller Class Initialized
INFO - 2023-10-12 10:01:45 --> Model Class Initialized
DEBUG - 2023-10-12 10:01:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-12 10:01:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-12 10:01:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-12 10:01:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-12 10:01:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-12 10:01:45 --> Model Class Initialized
INFO - 2023-10-12 10:01:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-12 10:01:45 --> Final output sent to browser
DEBUG - 2023-10-12 10:01:45 --> Total execution time: 0.2674
ERROR - 2023-10-12 10:28:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-12 10:28:10 --> Config Class Initialized
INFO - 2023-10-12 10:28:10 --> Hooks Class Initialized
DEBUG - 2023-10-12 10:28:10 --> UTF-8 Support Enabled
INFO - 2023-10-12 10:28:10 --> Utf8 Class Initialized
INFO - 2023-10-12 10:28:10 --> URI Class Initialized
DEBUG - 2023-10-12 10:28:10 --> No URI present. Default controller set.
INFO - 2023-10-12 10:28:10 --> Router Class Initialized
INFO - 2023-10-12 10:28:10 --> Output Class Initialized
INFO - 2023-10-12 10:28:10 --> Security Class Initialized
DEBUG - 2023-10-12 10:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 10:28:10 --> Input Class Initialized
INFO - 2023-10-12 10:28:10 --> Language Class Initialized
INFO - 2023-10-12 10:28:10 --> Loader Class Initialized
INFO - 2023-10-12 10:28:10 --> Helper loaded: url_helper
INFO - 2023-10-12 10:28:10 --> Helper loaded: file_helper
INFO - 2023-10-12 10:28:10 --> Helper loaded: html_helper
INFO - 2023-10-12 10:28:10 --> Helper loaded: text_helper
INFO - 2023-10-12 10:28:10 --> Helper loaded: form_helper
INFO - 2023-10-12 10:28:10 --> Helper loaded: lang_helper
INFO - 2023-10-12 10:28:10 --> Helper loaded: security_helper
INFO - 2023-10-12 10:28:10 --> Helper loaded: cookie_helper
INFO - 2023-10-12 10:28:10 --> Database Driver Class Initialized
INFO - 2023-10-12 10:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 10:28:10 --> Parser Class Initialized
INFO - 2023-10-12 10:28:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-12 10:28:10 --> Pagination Class Initialized
INFO - 2023-10-12 10:28:10 --> Form Validation Class Initialized
INFO - 2023-10-12 10:28:10 --> Controller Class Initialized
INFO - 2023-10-12 10:28:10 --> Model Class Initialized
DEBUG - 2023-10-12 10:28:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-12 12:08:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-12 12:08:41 --> Config Class Initialized
INFO - 2023-10-12 12:08:41 --> Hooks Class Initialized
DEBUG - 2023-10-12 12:08:41 --> UTF-8 Support Enabled
INFO - 2023-10-12 12:08:41 --> Utf8 Class Initialized
INFO - 2023-10-12 12:08:41 --> URI Class Initialized
INFO - 2023-10-12 12:08:41 --> Router Class Initialized
INFO - 2023-10-12 12:08:41 --> Output Class Initialized
INFO - 2023-10-12 12:08:41 --> Security Class Initialized
DEBUG - 2023-10-12 12:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 12:08:41 --> Input Class Initialized
INFO - 2023-10-12 12:08:41 --> Language Class Initialized
INFO - 2023-10-12 12:08:41 --> Loader Class Initialized
INFO - 2023-10-12 12:08:41 --> Helper loaded: url_helper
INFO - 2023-10-12 12:08:41 --> Helper loaded: file_helper
INFO - 2023-10-12 12:08:41 --> Helper loaded: html_helper
INFO - 2023-10-12 12:08:41 --> Helper loaded: text_helper
INFO - 2023-10-12 12:08:41 --> Helper loaded: form_helper
INFO - 2023-10-12 12:08:41 --> Helper loaded: lang_helper
INFO - 2023-10-12 12:08:41 --> Helper loaded: security_helper
INFO - 2023-10-12 12:08:41 --> Helper loaded: cookie_helper
INFO - 2023-10-12 12:08:41 --> Database Driver Class Initialized
INFO - 2023-10-12 12:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 12:08:41 --> Parser Class Initialized
INFO - 2023-10-12 12:08:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-12 12:08:41 --> Pagination Class Initialized
INFO - 2023-10-12 12:08:41 --> Form Validation Class Initialized
INFO - 2023-10-12 12:08:41 --> Controller Class Initialized
INFO - 2023-10-12 12:08:41 --> Model Class Initialized
DEBUG - 2023-10-12 12:08:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-12 12:08:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-12 12:08:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-12 12:08:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-12 12:08:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-12 12:08:41 --> Model Class Initialized
INFO - 2023-10-12 12:08:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-12 12:08:41 --> Final output sent to browser
DEBUG - 2023-10-12 12:08:41 --> Total execution time: 0.0440
