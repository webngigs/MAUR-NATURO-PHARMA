<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-04-04 05:34:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-04 05:34:38 --> Config Class Initialized
INFO - 2024-04-04 05:34:38 --> Hooks Class Initialized
DEBUG - 2024-04-04 05:34:38 --> UTF-8 Support Enabled
INFO - 2024-04-04 05:34:38 --> Utf8 Class Initialized
INFO - 2024-04-04 05:34:38 --> URI Class Initialized
DEBUG - 2024-04-04 05:34:38 --> No URI present. Default controller set.
INFO - 2024-04-04 05:34:38 --> Router Class Initialized
INFO - 2024-04-04 05:34:38 --> Output Class Initialized
INFO - 2024-04-04 05:34:38 --> Security Class Initialized
DEBUG - 2024-04-04 05:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-04 05:34:38 --> Input Class Initialized
INFO - 2024-04-04 05:34:38 --> Language Class Initialized
INFO - 2024-04-04 05:34:38 --> Loader Class Initialized
INFO - 2024-04-04 05:34:38 --> Helper loaded: url_helper
INFO - 2024-04-04 05:34:38 --> Helper loaded: file_helper
INFO - 2024-04-04 05:34:38 --> Helper loaded: html_helper
INFO - 2024-04-04 05:34:38 --> Helper loaded: text_helper
INFO - 2024-04-04 05:34:38 --> Helper loaded: form_helper
INFO - 2024-04-04 05:34:38 --> Helper loaded: lang_helper
INFO - 2024-04-04 05:34:38 --> Helper loaded: security_helper
INFO - 2024-04-04 05:34:38 --> Helper loaded: cookie_helper
INFO - 2024-04-04 05:34:38 --> Database Driver Class Initialized
INFO - 2024-04-04 05:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-04 05:34:38 --> Parser Class Initialized
INFO - 2024-04-04 05:34:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-04 05:34:38 --> Pagination Class Initialized
INFO - 2024-04-04 05:34:38 --> Form Validation Class Initialized
INFO - 2024-04-04 05:34:38 --> Controller Class Initialized
INFO - 2024-04-04 05:34:38 --> Model Class Initialized
DEBUG - 2024-04-04 05:34:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-04-04 05:34:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-04 05:34:38 --> Config Class Initialized
INFO - 2024-04-04 05:34:38 --> Hooks Class Initialized
DEBUG - 2024-04-04 05:34:38 --> UTF-8 Support Enabled
INFO - 2024-04-04 05:34:38 --> Utf8 Class Initialized
INFO - 2024-04-04 05:34:38 --> URI Class Initialized
INFO - 2024-04-04 05:34:38 --> Router Class Initialized
INFO - 2024-04-04 05:34:38 --> Output Class Initialized
INFO - 2024-04-04 05:34:38 --> Security Class Initialized
DEBUG - 2024-04-04 05:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-04 05:34:38 --> Input Class Initialized
INFO - 2024-04-04 05:34:38 --> Language Class Initialized
INFO - 2024-04-04 05:34:38 --> Loader Class Initialized
INFO - 2024-04-04 05:34:38 --> Helper loaded: url_helper
INFO - 2024-04-04 05:34:38 --> Helper loaded: file_helper
INFO - 2024-04-04 05:34:38 --> Helper loaded: html_helper
INFO - 2024-04-04 05:34:38 --> Helper loaded: text_helper
INFO - 2024-04-04 05:34:38 --> Helper loaded: form_helper
INFO - 2024-04-04 05:34:38 --> Helper loaded: lang_helper
INFO - 2024-04-04 05:34:38 --> Helper loaded: security_helper
INFO - 2024-04-04 05:34:38 --> Helper loaded: cookie_helper
INFO - 2024-04-04 05:34:38 --> Database Driver Class Initialized
INFO - 2024-04-04 05:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-04 05:34:38 --> Parser Class Initialized
INFO - 2024-04-04 05:34:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-04 05:34:38 --> Pagination Class Initialized
INFO - 2024-04-04 05:34:38 --> Form Validation Class Initialized
INFO - 2024-04-04 05:34:38 --> Controller Class Initialized
INFO - 2024-04-04 05:34:38 --> Model Class Initialized
DEBUG - 2024-04-04 05:34:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-04 05:34:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-04-04 05:34:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-04 05:34:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-04 05:34:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-04 05:34:38 --> Model Class Initialized
INFO - 2024-04-04 05:34:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-04 05:34:38 --> Final output sent to browser
DEBUG - 2024-04-04 05:34:38 --> Total execution time: 0.0402
ERROR - 2024-04-04 05:34:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-04 05:34:43 --> Config Class Initialized
INFO - 2024-04-04 05:34:43 --> Hooks Class Initialized
DEBUG - 2024-04-04 05:34:43 --> UTF-8 Support Enabled
INFO - 2024-04-04 05:34:43 --> Utf8 Class Initialized
INFO - 2024-04-04 05:34:43 --> URI Class Initialized
INFO - 2024-04-04 05:34:43 --> Router Class Initialized
INFO - 2024-04-04 05:34:43 --> Output Class Initialized
INFO - 2024-04-04 05:34:43 --> Security Class Initialized
DEBUG - 2024-04-04 05:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-04 05:34:43 --> Input Class Initialized
INFO - 2024-04-04 05:34:43 --> Language Class Initialized
INFO - 2024-04-04 05:34:43 --> Loader Class Initialized
INFO - 2024-04-04 05:34:43 --> Helper loaded: url_helper
INFO - 2024-04-04 05:34:43 --> Helper loaded: file_helper
INFO - 2024-04-04 05:34:43 --> Helper loaded: html_helper
INFO - 2024-04-04 05:34:43 --> Helper loaded: text_helper
INFO - 2024-04-04 05:34:43 --> Helper loaded: form_helper
INFO - 2024-04-04 05:34:43 --> Helper loaded: lang_helper
INFO - 2024-04-04 05:34:43 --> Helper loaded: security_helper
INFO - 2024-04-04 05:34:43 --> Helper loaded: cookie_helper
INFO - 2024-04-04 05:34:43 --> Database Driver Class Initialized
INFO - 2024-04-04 05:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-04 05:34:43 --> Parser Class Initialized
INFO - 2024-04-04 05:34:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-04 05:34:43 --> Pagination Class Initialized
INFO - 2024-04-04 05:34:43 --> Form Validation Class Initialized
INFO - 2024-04-04 05:34:43 --> Controller Class Initialized
INFO - 2024-04-04 05:34:43 --> Model Class Initialized
DEBUG - 2024-04-04 05:34:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-04 05:34:43 --> Model Class Initialized
INFO - 2024-04-04 05:34:43 --> Final output sent to browser
DEBUG - 2024-04-04 05:34:43 --> Total execution time: 0.0190
ERROR - 2024-04-04 05:34:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-04 05:34:43 --> Config Class Initialized
INFO - 2024-04-04 05:34:43 --> Hooks Class Initialized
DEBUG - 2024-04-04 05:34:43 --> UTF-8 Support Enabled
INFO - 2024-04-04 05:34:43 --> Utf8 Class Initialized
INFO - 2024-04-04 05:34:43 --> URI Class Initialized
DEBUG - 2024-04-04 05:34:43 --> No URI present. Default controller set.
INFO - 2024-04-04 05:34:43 --> Router Class Initialized
INFO - 2024-04-04 05:34:43 --> Output Class Initialized
INFO - 2024-04-04 05:34:43 --> Security Class Initialized
DEBUG - 2024-04-04 05:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-04 05:34:43 --> Input Class Initialized
INFO - 2024-04-04 05:34:43 --> Language Class Initialized
INFO - 2024-04-04 05:34:43 --> Loader Class Initialized
INFO - 2024-04-04 05:34:43 --> Helper loaded: url_helper
INFO - 2024-04-04 05:34:43 --> Helper loaded: file_helper
INFO - 2024-04-04 05:34:43 --> Helper loaded: html_helper
INFO - 2024-04-04 05:34:43 --> Helper loaded: text_helper
INFO - 2024-04-04 05:34:43 --> Helper loaded: form_helper
INFO - 2024-04-04 05:34:43 --> Helper loaded: lang_helper
INFO - 2024-04-04 05:34:43 --> Helper loaded: security_helper
INFO - 2024-04-04 05:34:43 --> Helper loaded: cookie_helper
INFO - 2024-04-04 05:34:43 --> Database Driver Class Initialized
INFO - 2024-04-04 05:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-04 05:34:43 --> Parser Class Initialized
INFO - 2024-04-04 05:34:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-04 05:34:43 --> Pagination Class Initialized
INFO - 2024-04-04 05:34:43 --> Form Validation Class Initialized
INFO - 2024-04-04 05:34:43 --> Controller Class Initialized
INFO - 2024-04-04 05:34:43 --> Model Class Initialized
DEBUG - 2024-04-04 05:34:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-04 05:34:43 --> Model Class Initialized
DEBUG - 2024-04-04 05:34:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-04 05:34:43 --> Model Class Initialized
INFO - 2024-04-04 05:34:43 --> Model Class Initialized
INFO - 2024-04-04 05:34:43 --> Model Class Initialized
INFO - 2024-04-04 05:34:43 --> Model Class Initialized
DEBUG - 2024-04-04 05:34:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-04 05:34:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-04 05:34:43 --> Model Class Initialized
INFO - 2024-04-04 05:34:43 --> Model Class Initialized
INFO - 2024-04-04 05:34:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-04 05:34:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-04 05:34:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-04 05:34:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-04 05:34:43 --> Model Class Initialized
INFO - 2024-04-04 05:34:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-04 05:34:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-04 05:34:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-04 05:34:43 --> Final output sent to browser
DEBUG - 2024-04-04 05:34:43 --> Total execution time: 0.4662
ERROR - 2024-04-04 05:34:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-04 05:34:44 --> Config Class Initialized
INFO - 2024-04-04 05:34:44 --> Hooks Class Initialized
DEBUG - 2024-04-04 05:34:44 --> UTF-8 Support Enabled
INFO - 2024-04-04 05:34:44 --> Utf8 Class Initialized
INFO - 2024-04-04 05:34:44 --> URI Class Initialized
INFO - 2024-04-04 05:34:44 --> Router Class Initialized
INFO - 2024-04-04 05:34:44 --> Output Class Initialized
INFO - 2024-04-04 05:34:44 --> Security Class Initialized
DEBUG - 2024-04-04 05:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-04 05:34:44 --> Input Class Initialized
INFO - 2024-04-04 05:34:44 --> Language Class Initialized
INFO - 2024-04-04 05:34:44 --> Loader Class Initialized
INFO - 2024-04-04 05:34:44 --> Helper loaded: url_helper
INFO - 2024-04-04 05:34:44 --> Helper loaded: file_helper
INFO - 2024-04-04 05:34:44 --> Helper loaded: html_helper
INFO - 2024-04-04 05:34:44 --> Helper loaded: text_helper
INFO - 2024-04-04 05:34:44 --> Helper loaded: form_helper
INFO - 2024-04-04 05:34:44 --> Helper loaded: lang_helper
INFO - 2024-04-04 05:34:44 --> Helper loaded: security_helper
INFO - 2024-04-04 05:34:44 --> Helper loaded: cookie_helper
INFO - 2024-04-04 05:34:44 --> Database Driver Class Initialized
INFO - 2024-04-04 05:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-04 05:34:44 --> Parser Class Initialized
INFO - 2024-04-04 05:34:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-04 05:34:44 --> Pagination Class Initialized
INFO - 2024-04-04 05:34:44 --> Form Validation Class Initialized
INFO - 2024-04-04 05:34:44 --> Controller Class Initialized
DEBUG - 2024-04-04 05:34:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-04 05:34:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-04 05:34:44 --> Model Class Initialized
INFO - 2024-04-04 05:34:44 --> Final output sent to browser
DEBUG - 2024-04-04 05:34:44 --> Total execution time: 0.0131
ERROR - 2024-04-04 05:49:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-04 05:49:52 --> Config Class Initialized
INFO - 2024-04-04 05:49:52 --> Hooks Class Initialized
DEBUG - 2024-04-04 05:49:52 --> UTF-8 Support Enabled
INFO - 2024-04-04 05:49:52 --> Utf8 Class Initialized
INFO - 2024-04-04 05:49:52 --> URI Class Initialized
DEBUG - 2024-04-04 05:49:52 --> No URI present. Default controller set.
INFO - 2024-04-04 05:49:52 --> Router Class Initialized
INFO - 2024-04-04 05:49:52 --> Output Class Initialized
INFO - 2024-04-04 05:49:52 --> Security Class Initialized
DEBUG - 2024-04-04 05:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-04 05:49:52 --> Input Class Initialized
INFO - 2024-04-04 05:49:52 --> Language Class Initialized
INFO - 2024-04-04 05:49:52 --> Loader Class Initialized
INFO - 2024-04-04 05:49:52 --> Helper loaded: url_helper
INFO - 2024-04-04 05:49:52 --> Helper loaded: file_helper
INFO - 2024-04-04 05:49:52 --> Helper loaded: html_helper
INFO - 2024-04-04 05:49:52 --> Helper loaded: text_helper
INFO - 2024-04-04 05:49:52 --> Helper loaded: form_helper
INFO - 2024-04-04 05:49:52 --> Helper loaded: lang_helper
INFO - 2024-04-04 05:49:52 --> Helper loaded: security_helper
INFO - 2024-04-04 05:49:52 --> Helper loaded: cookie_helper
INFO - 2024-04-04 05:49:52 --> Database Driver Class Initialized
INFO - 2024-04-04 05:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-04 05:49:52 --> Parser Class Initialized
INFO - 2024-04-04 05:49:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-04 05:49:52 --> Pagination Class Initialized
INFO - 2024-04-04 05:49:52 --> Form Validation Class Initialized
INFO - 2024-04-04 05:49:52 --> Controller Class Initialized
INFO - 2024-04-04 05:49:52 --> Model Class Initialized
DEBUG - 2024-04-04 05:49:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-04 05:49:52 --> Model Class Initialized
DEBUG - 2024-04-04 05:49:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-04 05:49:52 --> Model Class Initialized
INFO - 2024-04-04 05:49:52 --> Model Class Initialized
INFO - 2024-04-04 05:49:52 --> Model Class Initialized
INFO - 2024-04-04 05:49:52 --> Model Class Initialized
DEBUG - 2024-04-04 05:49:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-04 05:49:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-04 05:49:52 --> Model Class Initialized
INFO - 2024-04-04 05:49:52 --> Model Class Initialized
INFO - 2024-04-04 05:49:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-04 05:49:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-04 05:49:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-04 05:49:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-04 05:49:52 --> Model Class Initialized
INFO - 2024-04-04 05:49:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-04 05:49:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-04 05:49:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-04 05:49:52 --> Final output sent to browser
DEBUG - 2024-04-04 05:49:52 --> Total execution time: 0.4916
ERROR - 2024-04-04 05:50:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-04 05:50:05 --> Config Class Initialized
INFO - 2024-04-04 05:50:05 --> Hooks Class Initialized
DEBUG - 2024-04-04 05:50:05 --> UTF-8 Support Enabled
INFO - 2024-04-04 05:50:05 --> Utf8 Class Initialized
INFO - 2024-04-04 05:50:05 --> URI Class Initialized
INFO - 2024-04-04 05:50:05 --> Router Class Initialized
INFO - 2024-04-04 05:50:05 --> Output Class Initialized
INFO - 2024-04-04 05:50:05 --> Security Class Initialized
DEBUG - 2024-04-04 05:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-04 05:50:05 --> Input Class Initialized
INFO - 2024-04-04 05:50:05 --> Language Class Initialized
INFO - 2024-04-04 05:50:06 --> Loader Class Initialized
INFO - 2024-04-04 05:50:06 --> Helper loaded: url_helper
INFO - 2024-04-04 05:50:06 --> Helper loaded: file_helper
INFO - 2024-04-04 05:50:06 --> Helper loaded: html_helper
INFO - 2024-04-04 05:50:06 --> Helper loaded: text_helper
INFO - 2024-04-04 05:50:06 --> Helper loaded: form_helper
INFO - 2024-04-04 05:50:06 --> Helper loaded: lang_helper
INFO - 2024-04-04 05:50:06 --> Helper loaded: security_helper
INFO - 2024-04-04 05:50:06 --> Helper loaded: cookie_helper
INFO - 2024-04-04 05:50:06 --> Database Driver Class Initialized
INFO - 2024-04-04 05:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-04 05:50:06 --> Parser Class Initialized
INFO - 2024-04-04 05:50:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-04 05:50:06 --> Pagination Class Initialized
INFO - 2024-04-04 05:50:06 --> Form Validation Class Initialized
INFO - 2024-04-04 05:50:06 --> Controller Class Initialized
INFO - 2024-04-04 05:50:06 --> Model Class Initialized
DEBUG - 2024-04-04 05:50:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-04 05:50:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-04 05:50:06 --> Model Class Initialized
DEBUG - 2024-04-04 05:50:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-04 05:50:06 --> Model Class Initialized
INFO - 2024-04-04 05:50:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-04-04 05:50:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-04 05:50:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-04 05:50:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-04 05:50:06 --> Model Class Initialized
INFO - 2024-04-04 05:50:06 --> Model Class Initialized
INFO - 2024-04-04 05:50:06 --> Model Class Initialized
INFO - 2024-04-04 05:50:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-04 05:50:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-04 05:50:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-04 05:50:06 --> Final output sent to browser
DEBUG - 2024-04-04 05:50:06 --> Total execution time: 0.2623
ERROR - 2024-04-04 05:50:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-04 05:50:07 --> Config Class Initialized
INFO - 2024-04-04 05:50:07 --> Hooks Class Initialized
DEBUG - 2024-04-04 05:50:07 --> UTF-8 Support Enabled
INFO - 2024-04-04 05:50:07 --> Utf8 Class Initialized
INFO - 2024-04-04 05:50:07 --> URI Class Initialized
INFO - 2024-04-04 05:50:07 --> Router Class Initialized
INFO - 2024-04-04 05:50:07 --> Output Class Initialized
INFO - 2024-04-04 05:50:07 --> Security Class Initialized
DEBUG - 2024-04-04 05:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-04 05:50:07 --> Input Class Initialized
INFO - 2024-04-04 05:50:07 --> Language Class Initialized
INFO - 2024-04-04 05:50:07 --> Loader Class Initialized
INFO - 2024-04-04 05:50:07 --> Helper loaded: url_helper
INFO - 2024-04-04 05:50:07 --> Helper loaded: file_helper
INFO - 2024-04-04 05:50:07 --> Helper loaded: html_helper
INFO - 2024-04-04 05:50:07 --> Helper loaded: text_helper
INFO - 2024-04-04 05:50:07 --> Helper loaded: form_helper
INFO - 2024-04-04 05:50:07 --> Helper loaded: lang_helper
INFO - 2024-04-04 05:50:07 --> Helper loaded: security_helper
INFO - 2024-04-04 05:50:07 --> Helper loaded: cookie_helper
INFO - 2024-04-04 05:50:07 --> Database Driver Class Initialized
INFO - 2024-04-04 05:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-04 05:50:07 --> Parser Class Initialized
INFO - 2024-04-04 05:50:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-04 05:50:07 --> Pagination Class Initialized
INFO - 2024-04-04 05:50:07 --> Form Validation Class Initialized
INFO - 2024-04-04 05:50:07 --> Controller Class Initialized
INFO - 2024-04-04 05:50:07 --> Model Class Initialized
DEBUG - 2024-04-04 05:50:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-04 05:50:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-04 05:50:07 --> Model Class Initialized
DEBUG - 2024-04-04 05:50:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-04 05:50:07 --> Model Class Initialized
INFO - 2024-04-04 05:50:07 --> Final output sent to browser
DEBUG - 2024-04-04 05:50:07 --> Total execution time: 0.0669
ERROR - 2024-04-04 05:50:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-04 05:50:29 --> Config Class Initialized
INFO - 2024-04-04 05:50:29 --> Hooks Class Initialized
DEBUG - 2024-04-04 05:50:29 --> UTF-8 Support Enabled
INFO - 2024-04-04 05:50:29 --> Utf8 Class Initialized
INFO - 2024-04-04 05:50:29 --> URI Class Initialized
DEBUG - 2024-04-04 05:50:29 --> No URI present. Default controller set.
INFO - 2024-04-04 05:50:29 --> Router Class Initialized
INFO - 2024-04-04 05:50:29 --> Output Class Initialized
INFO - 2024-04-04 05:50:29 --> Security Class Initialized
DEBUG - 2024-04-04 05:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-04 05:50:29 --> Input Class Initialized
INFO - 2024-04-04 05:50:29 --> Language Class Initialized
INFO - 2024-04-04 05:50:29 --> Loader Class Initialized
INFO - 2024-04-04 05:50:29 --> Helper loaded: url_helper
INFO - 2024-04-04 05:50:29 --> Helper loaded: file_helper
INFO - 2024-04-04 05:50:29 --> Helper loaded: html_helper
INFO - 2024-04-04 05:50:29 --> Helper loaded: text_helper
INFO - 2024-04-04 05:50:29 --> Helper loaded: form_helper
INFO - 2024-04-04 05:50:29 --> Helper loaded: lang_helper
INFO - 2024-04-04 05:50:29 --> Helper loaded: security_helper
INFO - 2024-04-04 05:50:29 --> Helper loaded: cookie_helper
INFO - 2024-04-04 05:50:29 --> Database Driver Class Initialized
INFO - 2024-04-04 05:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-04 05:50:29 --> Parser Class Initialized
INFO - 2024-04-04 05:50:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-04 05:50:29 --> Pagination Class Initialized
INFO - 2024-04-04 05:50:29 --> Form Validation Class Initialized
INFO - 2024-04-04 05:50:29 --> Controller Class Initialized
INFO - 2024-04-04 05:50:29 --> Model Class Initialized
DEBUG - 2024-04-04 05:50:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-04 05:50:29 --> Model Class Initialized
DEBUG - 2024-04-04 05:50:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-04 05:50:29 --> Model Class Initialized
INFO - 2024-04-04 05:50:29 --> Model Class Initialized
INFO - 2024-04-04 05:50:29 --> Model Class Initialized
INFO - 2024-04-04 05:50:29 --> Model Class Initialized
DEBUG - 2024-04-04 05:50:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-04 05:50:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-04 05:50:29 --> Model Class Initialized
INFO - 2024-04-04 05:50:29 --> Model Class Initialized
INFO - 2024-04-04 05:50:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-04 05:50:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-04 05:50:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-04 05:50:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-04 05:50:29 --> Model Class Initialized
INFO - 2024-04-04 05:50:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-04 05:50:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-04 05:50:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-04 05:50:30 --> Final output sent to browser
DEBUG - 2024-04-04 05:50:30 --> Total execution time: 0.5166
ERROR - 2024-04-04 11:44:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-04 11:44:45 --> Config Class Initialized
INFO - 2024-04-04 11:44:45 --> Hooks Class Initialized
DEBUG - 2024-04-04 11:44:45 --> UTF-8 Support Enabled
INFO - 2024-04-04 11:44:45 --> Utf8 Class Initialized
INFO - 2024-04-04 11:44:45 --> URI Class Initialized
DEBUG - 2024-04-04 11:44:45 --> No URI present. Default controller set.
INFO - 2024-04-04 11:44:45 --> Router Class Initialized
INFO - 2024-04-04 11:44:45 --> Output Class Initialized
INFO - 2024-04-04 11:44:45 --> Security Class Initialized
DEBUG - 2024-04-04 11:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-04 11:44:45 --> Input Class Initialized
INFO - 2024-04-04 11:44:45 --> Language Class Initialized
INFO - 2024-04-04 11:44:45 --> Loader Class Initialized
INFO - 2024-04-04 11:44:45 --> Helper loaded: url_helper
INFO - 2024-04-04 11:44:45 --> Helper loaded: file_helper
INFO - 2024-04-04 11:44:45 --> Helper loaded: html_helper
INFO - 2024-04-04 11:44:45 --> Helper loaded: text_helper
INFO - 2024-04-04 11:44:45 --> Helper loaded: form_helper
INFO - 2024-04-04 11:44:45 --> Helper loaded: lang_helper
INFO - 2024-04-04 11:44:45 --> Helper loaded: security_helper
INFO - 2024-04-04 11:44:45 --> Helper loaded: cookie_helper
INFO - 2024-04-04 11:44:45 --> Database Driver Class Initialized
INFO - 2024-04-04 11:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-04 11:44:45 --> Parser Class Initialized
INFO - 2024-04-04 11:44:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-04 11:44:45 --> Pagination Class Initialized
INFO - 2024-04-04 11:44:45 --> Form Validation Class Initialized
INFO - 2024-04-04 11:44:45 --> Controller Class Initialized
INFO - 2024-04-04 11:44:45 --> Model Class Initialized
DEBUG - 2024-04-04 11:44:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-04-04 11:44:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-04 11:44:45 --> Config Class Initialized
INFO - 2024-04-04 11:44:45 --> Hooks Class Initialized
DEBUG - 2024-04-04 11:44:45 --> UTF-8 Support Enabled
INFO - 2024-04-04 11:44:45 --> Utf8 Class Initialized
INFO - 2024-04-04 11:44:45 --> URI Class Initialized
INFO - 2024-04-04 11:44:45 --> Router Class Initialized
INFO - 2024-04-04 11:44:45 --> Output Class Initialized
INFO - 2024-04-04 11:44:45 --> Security Class Initialized
DEBUG - 2024-04-04 11:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-04 11:44:45 --> Input Class Initialized
INFO - 2024-04-04 11:44:45 --> Language Class Initialized
INFO - 2024-04-04 11:44:45 --> Loader Class Initialized
INFO - 2024-04-04 11:44:45 --> Helper loaded: url_helper
INFO - 2024-04-04 11:44:45 --> Helper loaded: file_helper
INFO - 2024-04-04 11:44:45 --> Helper loaded: html_helper
INFO - 2024-04-04 11:44:45 --> Helper loaded: text_helper
INFO - 2024-04-04 11:44:45 --> Helper loaded: form_helper
INFO - 2024-04-04 11:44:45 --> Helper loaded: lang_helper
INFO - 2024-04-04 11:44:45 --> Helper loaded: security_helper
INFO - 2024-04-04 11:44:45 --> Helper loaded: cookie_helper
INFO - 2024-04-04 11:44:45 --> Database Driver Class Initialized
INFO - 2024-04-04 11:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-04 11:44:45 --> Parser Class Initialized
INFO - 2024-04-04 11:44:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-04 11:44:45 --> Pagination Class Initialized
INFO - 2024-04-04 11:44:45 --> Form Validation Class Initialized
INFO - 2024-04-04 11:44:45 --> Controller Class Initialized
INFO - 2024-04-04 11:44:45 --> Model Class Initialized
DEBUG - 2024-04-04 11:44:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-04 11:44:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-04-04 11:44:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-04 11:44:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-04 11:44:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-04 11:44:45 --> Model Class Initialized
INFO - 2024-04-04 11:44:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-04 11:44:45 --> Final output sent to browser
DEBUG - 2024-04-04 11:44:45 --> Total execution time: 0.0335
ERROR - 2024-04-04 11:44:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-04 11:44:55 --> Config Class Initialized
INFO - 2024-04-04 11:44:55 --> Hooks Class Initialized
DEBUG - 2024-04-04 11:44:55 --> UTF-8 Support Enabled
INFO - 2024-04-04 11:44:55 --> Utf8 Class Initialized
INFO - 2024-04-04 11:44:55 --> URI Class Initialized
INFO - 2024-04-04 11:44:55 --> Router Class Initialized
INFO - 2024-04-04 11:44:55 --> Output Class Initialized
INFO - 2024-04-04 11:44:55 --> Security Class Initialized
DEBUG - 2024-04-04 11:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-04 11:44:55 --> Input Class Initialized
INFO - 2024-04-04 11:44:55 --> Language Class Initialized
INFO - 2024-04-04 11:44:55 --> Loader Class Initialized
INFO - 2024-04-04 11:44:55 --> Helper loaded: url_helper
INFO - 2024-04-04 11:44:55 --> Helper loaded: file_helper
INFO - 2024-04-04 11:44:55 --> Helper loaded: html_helper
INFO - 2024-04-04 11:44:55 --> Helper loaded: text_helper
INFO - 2024-04-04 11:44:55 --> Helper loaded: form_helper
INFO - 2024-04-04 11:44:55 --> Helper loaded: lang_helper
INFO - 2024-04-04 11:44:55 --> Helper loaded: security_helper
INFO - 2024-04-04 11:44:55 --> Helper loaded: cookie_helper
INFO - 2024-04-04 11:44:55 --> Database Driver Class Initialized
INFO - 2024-04-04 11:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-04 11:44:55 --> Parser Class Initialized
INFO - 2024-04-04 11:44:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-04 11:44:55 --> Pagination Class Initialized
INFO - 2024-04-04 11:44:55 --> Form Validation Class Initialized
INFO - 2024-04-04 11:44:55 --> Controller Class Initialized
INFO - 2024-04-04 11:44:55 --> Model Class Initialized
DEBUG - 2024-04-04 11:44:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-04 11:44:55 --> Model Class Initialized
INFO - 2024-04-04 11:44:55 --> Final output sent to browser
DEBUG - 2024-04-04 11:44:55 --> Total execution time: 0.0190
ERROR - 2024-04-04 11:44:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-04 11:44:55 --> Config Class Initialized
INFO - 2024-04-04 11:44:55 --> Hooks Class Initialized
DEBUG - 2024-04-04 11:44:55 --> UTF-8 Support Enabled
INFO - 2024-04-04 11:44:55 --> Utf8 Class Initialized
INFO - 2024-04-04 11:44:55 --> URI Class Initialized
DEBUG - 2024-04-04 11:44:55 --> No URI present. Default controller set.
INFO - 2024-04-04 11:44:55 --> Router Class Initialized
INFO - 2024-04-04 11:44:55 --> Output Class Initialized
INFO - 2024-04-04 11:44:55 --> Security Class Initialized
DEBUG - 2024-04-04 11:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-04 11:44:55 --> Input Class Initialized
INFO - 2024-04-04 11:44:55 --> Language Class Initialized
INFO - 2024-04-04 11:44:55 --> Loader Class Initialized
INFO - 2024-04-04 11:44:55 --> Helper loaded: url_helper
INFO - 2024-04-04 11:44:55 --> Helper loaded: file_helper
INFO - 2024-04-04 11:44:55 --> Helper loaded: html_helper
INFO - 2024-04-04 11:44:55 --> Helper loaded: text_helper
INFO - 2024-04-04 11:44:55 --> Helper loaded: form_helper
INFO - 2024-04-04 11:44:55 --> Helper loaded: lang_helper
INFO - 2024-04-04 11:44:55 --> Helper loaded: security_helper
INFO - 2024-04-04 11:44:55 --> Helper loaded: cookie_helper
INFO - 2024-04-04 11:44:55 --> Database Driver Class Initialized
INFO - 2024-04-04 11:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-04 11:44:55 --> Parser Class Initialized
INFO - 2024-04-04 11:44:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-04 11:44:55 --> Pagination Class Initialized
INFO - 2024-04-04 11:44:55 --> Form Validation Class Initialized
INFO - 2024-04-04 11:44:55 --> Controller Class Initialized
INFO - 2024-04-04 11:44:55 --> Model Class Initialized
DEBUG - 2024-04-04 11:44:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-04 11:44:55 --> Model Class Initialized
DEBUG - 2024-04-04 11:44:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-04 11:44:55 --> Model Class Initialized
INFO - 2024-04-04 11:44:55 --> Model Class Initialized
INFO - 2024-04-04 11:44:55 --> Model Class Initialized
INFO - 2024-04-04 11:44:55 --> Model Class Initialized
DEBUG - 2024-04-04 11:44:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-04 11:44:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-04 11:44:55 --> Model Class Initialized
INFO - 2024-04-04 11:44:55 --> Model Class Initialized
INFO - 2024-04-04 11:44:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-04 11:44:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-04 11:44:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-04 11:44:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-04 11:44:55 --> Model Class Initialized
INFO - 2024-04-04 11:44:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-04 11:44:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-04 11:44:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-04 11:44:55 --> Final output sent to browser
DEBUG - 2024-04-04 11:44:55 --> Total execution time: 0.2554
ERROR - 2024-04-04 14:00:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-04 14:00:42 --> Config Class Initialized
INFO - 2024-04-04 14:00:42 --> Hooks Class Initialized
DEBUG - 2024-04-04 14:00:42 --> UTF-8 Support Enabled
INFO - 2024-04-04 14:00:42 --> Utf8 Class Initialized
INFO - 2024-04-04 14:00:42 --> URI Class Initialized
INFO - 2024-04-04 14:00:42 --> Router Class Initialized
INFO - 2024-04-04 14:00:42 --> Output Class Initialized
INFO - 2024-04-04 14:00:42 --> Security Class Initialized
DEBUG - 2024-04-04 14:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-04 14:00:42 --> Input Class Initialized
INFO - 2024-04-04 14:00:42 --> Language Class Initialized
ERROR - 2024-04-04 14:00:42 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-04-04 18:39:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-04 18:39:26 --> Config Class Initialized
INFO - 2024-04-04 18:39:26 --> Hooks Class Initialized
DEBUG - 2024-04-04 18:39:26 --> UTF-8 Support Enabled
INFO - 2024-04-04 18:39:26 --> Utf8 Class Initialized
INFO - 2024-04-04 18:39:26 --> URI Class Initialized
INFO - 2024-04-04 18:39:26 --> Router Class Initialized
INFO - 2024-04-04 18:39:26 --> Output Class Initialized
INFO - 2024-04-04 18:39:26 --> Security Class Initialized
DEBUG - 2024-04-04 18:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-04 18:39:26 --> Input Class Initialized
INFO - 2024-04-04 18:39:26 --> Language Class Initialized
ERROR - 2024-04-04 18:39:26 --> 404 Page Not Found: Well-known/assetlinks.json
