<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-04-20 01:14:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 01:14:04 --> Config Class Initialized
INFO - 2023-04-20 01:14:04 --> Hooks Class Initialized
DEBUG - 2023-04-20 01:14:04 --> UTF-8 Support Enabled
INFO - 2023-04-20 01:14:04 --> Utf8 Class Initialized
INFO - 2023-04-20 01:14:04 --> URI Class Initialized
DEBUG - 2023-04-20 01:14:04 --> No URI present. Default controller set.
INFO - 2023-04-20 01:14:04 --> Router Class Initialized
INFO - 2023-04-20 01:14:04 --> Output Class Initialized
INFO - 2023-04-20 01:14:04 --> Security Class Initialized
DEBUG - 2023-04-20 01:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 01:14:04 --> Input Class Initialized
INFO - 2023-04-20 01:14:04 --> Language Class Initialized
INFO - 2023-04-20 01:14:04 --> Loader Class Initialized
INFO - 2023-04-20 01:14:04 --> Helper loaded: url_helper
INFO - 2023-04-20 01:14:04 --> Helper loaded: file_helper
INFO - 2023-04-20 01:14:04 --> Helper loaded: html_helper
INFO - 2023-04-20 01:14:04 --> Helper loaded: text_helper
INFO - 2023-04-20 01:14:04 --> Helper loaded: form_helper
INFO - 2023-04-20 01:14:04 --> Helper loaded: lang_helper
INFO - 2023-04-20 01:14:04 --> Helper loaded: security_helper
INFO - 2023-04-20 01:14:04 --> Helper loaded: cookie_helper
INFO - 2023-04-20 01:14:04 --> Database Driver Class Initialized
INFO - 2023-04-20 01:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 01:14:04 --> Parser Class Initialized
INFO - 2023-04-20 01:14:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 01:14:04 --> Pagination Class Initialized
INFO - 2023-04-20 01:14:04 --> Form Validation Class Initialized
INFO - 2023-04-20 01:14:04 --> Controller Class Initialized
INFO - 2023-04-20 01:14:04 --> Model Class Initialized
DEBUG - 2023-04-20 01:14:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-20 01:14:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 01:14:04 --> Config Class Initialized
INFO - 2023-04-20 01:14:04 --> Hooks Class Initialized
DEBUG - 2023-04-20 01:14:04 --> UTF-8 Support Enabled
INFO - 2023-04-20 01:14:04 --> Utf8 Class Initialized
INFO - 2023-04-20 01:14:04 --> URI Class Initialized
INFO - 2023-04-20 01:14:04 --> Router Class Initialized
INFO - 2023-04-20 01:14:04 --> Output Class Initialized
INFO - 2023-04-20 01:14:04 --> Security Class Initialized
DEBUG - 2023-04-20 01:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 01:14:04 --> Input Class Initialized
INFO - 2023-04-20 01:14:04 --> Language Class Initialized
INFO - 2023-04-20 01:14:04 --> Loader Class Initialized
INFO - 2023-04-20 01:14:04 --> Helper loaded: url_helper
INFO - 2023-04-20 01:14:04 --> Helper loaded: file_helper
INFO - 2023-04-20 01:14:04 --> Helper loaded: html_helper
INFO - 2023-04-20 01:14:04 --> Helper loaded: text_helper
INFO - 2023-04-20 01:14:04 --> Helper loaded: form_helper
INFO - 2023-04-20 01:14:04 --> Helper loaded: lang_helper
INFO - 2023-04-20 01:14:04 --> Helper loaded: security_helper
INFO - 2023-04-20 01:14:04 --> Helper loaded: cookie_helper
INFO - 2023-04-20 01:14:04 --> Database Driver Class Initialized
INFO - 2023-04-20 01:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 01:14:04 --> Parser Class Initialized
INFO - 2023-04-20 01:14:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 01:14:04 --> Pagination Class Initialized
INFO - 2023-04-20 01:14:04 --> Form Validation Class Initialized
INFO - 2023-04-20 01:14:04 --> Controller Class Initialized
INFO - 2023-04-20 01:14:04 --> Model Class Initialized
DEBUG - 2023-04-20 01:14:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 01:14:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-20 01:14:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 01:14:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 01:14:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 01:14:04 --> Model Class Initialized
INFO - 2023-04-20 01:14:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 01:14:04 --> Final output sent to browser
DEBUG - 2023-04-20 01:14:04 --> Total execution time: 0.0337
ERROR - 2023-04-20 01:14:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 01:14:21 --> Config Class Initialized
INFO - 2023-04-20 01:14:21 --> Hooks Class Initialized
DEBUG - 2023-04-20 01:14:21 --> UTF-8 Support Enabled
INFO - 2023-04-20 01:14:21 --> Utf8 Class Initialized
INFO - 2023-04-20 01:14:21 --> URI Class Initialized
INFO - 2023-04-20 01:14:21 --> Router Class Initialized
INFO - 2023-04-20 01:14:21 --> Output Class Initialized
INFO - 2023-04-20 01:14:21 --> Security Class Initialized
DEBUG - 2023-04-20 01:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 01:14:21 --> Input Class Initialized
INFO - 2023-04-20 01:14:21 --> Language Class Initialized
INFO - 2023-04-20 01:14:21 --> Loader Class Initialized
INFO - 2023-04-20 01:14:21 --> Helper loaded: url_helper
INFO - 2023-04-20 01:14:21 --> Helper loaded: file_helper
INFO - 2023-04-20 01:14:21 --> Helper loaded: html_helper
INFO - 2023-04-20 01:14:21 --> Helper loaded: text_helper
INFO - 2023-04-20 01:14:21 --> Helper loaded: form_helper
INFO - 2023-04-20 01:14:21 --> Helper loaded: lang_helper
INFO - 2023-04-20 01:14:21 --> Helper loaded: security_helper
INFO - 2023-04-20 01:14:21 --> Helper loaded: cookie_helper
INFO - 2023-04-20 01:14:21 --> Database Driver Class Initialized
INFO - 2023-04-20 01:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 01:14:21 --> Parser Class Initialized
INFO - 2023-04-20 01:14:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 01:14:21 --> Pagination Class Initialized
INFO - 2023-04-20 01:14:21 --> Form Validation Class Initialized
INFO - 2023-04-20 01:14:21 --> Controller Class Initialized
INFO - 2023-04-20 01:14:21 --> Model Class Initialized
DEBUG - 2023-04-20 01:14:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 01:14:21 --> Model Class Initialized
INFO - 2023-04-20 01:14:21 --> Final output sent to browser
DEBUG - 2023-04-20 01:14:21 --> Total execution time: 0.0200
ERROR - 2023-04-20 01:14:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 01:14:22 --> Config Class Initialized
INFO - 2023-04-20 01:14:22 --> Hooks Class Initialized
DEBUG - 2023-04-20 01:14:22 --> UTF-8 Support Enabled
INFO - 2023-04-20 01:14:22 --> Utf8 Class Initialized
INFO - 2023-04-20 01:14:22 --> URI Class Initialized
DEBUG - 2023-04-20 01:14:22 --> No URI present. Default controller set.
INFO - 2023-04-20 01:14:22 --> Router Class Initialized
INFO - 2023-04-20 01:14:22 --> Output Class Initialized
INFO - 2023-04-20 01:14:22 --> Security Class Initialized
DEBUG - 2023-04-20 01:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 01:14:22 --> Input Class Initialized
INFO - 2023-04-20 01:14:22 --> Language Class Initialized
INFO - 2023-04-20 01:14:22 --> Loader Class Initialized
INFO - 2023-04-20 01:14:22 --> Helper loaded: url_helper
INFO - 2023-04-20 01:14:22 --> Helper loaded: file_helper
INFO - 2023-04-20 01:14:22 --> Helper loaded: html_helper
INFO - 2023-04-20 01:14:22 --> Helper loaded: text_helper
INFO - 2023-04-20 01:14:22 --> Helper loaded: form_helper
INFO - 2023-04-20 01:14:22 --> Helper loaded: lang_helper
INFO - 2023-04-20 01:14:22 --> Helper loaded: security_helper
INFO - 2023-04-20 01:14:22 --> Helper loaded: cookie_helper
INFO - 2023-04-20 01:14:22 --> Database Driver Class Initialized
INFO - 2023-04-20 01:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 01:14:22 --> Parser Class Initialized
INFO - 2023-04-20 01:14:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 01:14:22 --> Pagination Class Initialized
INFO - 2023-04-20 01:14:22 --> Form Validation Class Initialized
INFO - 2023-04-20 01:14:22 --> Controller Class Initialized
INFO - 2023-04-20 01:14:22 --> Model Class Initialized
DEBUG - 2023-04-20 01:14:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 01:14:22 --> Model Class Initialized
DEBUG - 2023-04-20 01:14:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 01:14:22 --> Model Class Initialized
INFO - 2023-04-20 01:14:22 --> Model Class Initialized
INFO - 2023-04-20 01:14:22 --> Model Class Initialized
INFO - 2023-04-20 01:14:22 --> Model Class Initialized
DEBUG - 2023-04-20 01:14:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 01:14:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 01:14:22 --> Model Class Initialized
INFO - 2023-04-20 01:14:22 --> Model Class Initialized
INFO - 2023-04-20 01:14:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-20 01:14:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 01:14:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 01:14:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 01:14:22 --> Model Class Initialized
INFO - 2023-04-20 01:14:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 01:14:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 01:14:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 01:14:22 --> Final output sent to browser
DEBUG - 2023-04-20 01:14:22 --> Total execution time: 0.2418
ERROR - 2023-04-20 01:14:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 01:14:23 --> Config Class Initialized
INFO - 2023-04-20 01:14:23 --> Hooks Class Initialized
DEBUG - 2023-04-20 01:14:23 --> UTF-8 Support Enabled
INFO - 2023-04-20 01:14:23 --> Utf8 Class Initialized
INFO - 2023-04-20 01:14:23 --> URI Class Initialized
INFO - 2023-04-20 01:14:23 --> Router Class Initialized
INFO - 2023-04-20 01:14:23 --> Output Class Initialized
INFO - 2023-04-20 01:14:23 --> Security Class Initialized
DEBUG - 2023-04-20 01:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 01:14:23 --> Input Class Initialized
INFO - 2023-04-20 01:14:23 --> Language Class Initialized
INFO - 2023-04-20 01:14:23 --> Loader Class Initialized
INFO - 2023-04-20 01:14:23 --> Helper loaded: url_helper
INFO - 2023-04-20 01:14:23 --> Helper loaded: file_helper
INFO - 2023-04-20 01:14:23 --> Helper loaded: html_helper
INFO - 2023-04-20 01:14:23 --> Helper loaded: text_helper
INFO - 2023-04-20 01:14:23 --> Helper loaded: form_helper
INFO - 2023-04-20 01:14:23 --> Helper loaded: lang_helper
INFO - 2023-04-20 01:14:23 --> Helper loaded: security_helper
INFO - 2023-04-20 01:14:23 --> Helper loaded: cookie_helper
INFO - 2023-04-20 01:14:23 --> Database Driver Class Initialized
INFO - 2023-04-20 01:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 01:14:23 --> Parser Class Initialized
INFO - 2023-04-20 01:14:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 01:14:23 --> Pagination Class Initialized
INFO - 2023-04-20 01:14:23 --> Form Validation Class Initialized
INFO - 2023-04-20 01:14:23 --> Controller Class Initialized
DEBUG - 2023-04-20 01:14:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 01:14:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 01:14:23 --> Model Class Initialized
INFO - 2023-04-20 01:14:23 --> Final output sent to browser
DEBUG - 2023-04-20 01:14:23 --> Total execution time: 0.0133
ERROR - 2023-04-20 01:14:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 01:14:42 --> Config Class Initialized
INFO - 2023-04-20 01:14:42 --> Hooks Class Initialized
DEBUG - 2023-04-20 01:14:42 --> UTF-8 Support Enabled
INFO - 2023-04-20 01:14:42 --> Utf8 Class Initialized
INFO - 2023-04-20 01:14:42 --> URI Class Initialized
INFO - 2023-04-20 01:14:42 --> Router Class Initialized
INFO - 2023-04-20 01:14:42 --> Output Class Initialized
INFO - 2023-04-20 01:14:42 --> Security Class Initialized
DEBUG - 2023-04-20 01:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 01:14:42 --> Input Class Initialized
INFO - 2023-04-20 01:14:42 --> Language Class Initialized
INFO - 2023-04-20 01:14:42 --> Loader Class Initialized
INFO - 2023-04-20 01:14:42 --> Helper loaded: url_helper
INFO - 2023-04-20 01:14:42 --> Helper loaded: file_helper
INFO - 2023-04-20 01:14:42 --> Helper loaded: html_helper
INFO - 2023-04-20 01:14:42 --> Helper loaded: text_helper
INFO - 2023-04-20 01:14:42 --> Helper loaded: form_helper
INFO - 2023-04-20 01:14:42 --> Helper loaded: lang_helper
INFO - 2023-04-20 01:14:42 --> Helper loaded: security_helper
INFO - 2023-04-20 01:14:42 --> Helper loaded: cookie_helper
INFO - 2023-04-20 01:14:42 --> Database Driver Class Initialized
INFO - 2023-04-20 01:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 01:14:42 --> Parser Class Initialized
INFO - 2023-04-20 01:14:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 01:14:42 --> Pagination Class Initialized
INFO - 2023-04-20 01:14:42 --> Form Validation Class Initialized
INFO - 2023-04-20 01:14:42 --> Controller Class Initialized
INFO - 2023-04-20 01:14:42 --> Model Class Initialized
DEBUG - 2023-04-20 01:14:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 01:14:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 01:14:42 --> Model Class Initialized
DEBUG - 2023-04-20 01:14:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 01:14:42 --> Model Class Initialized
INFO - 2023-04-20 01:14:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-04-20 01:14:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 01:14:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 01:14:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 01:14:42 --> Model Class Initialized
INFO - 2023-04-20 01:14:42 --> Model Class Initialized
INFO - 2023-04-20 01:14:42 --> Model Class Initialized
INFO - 2023-04-20 01:14:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 01:14:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 01:14:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 01:14:42 --> Final output sent to browser
DEBUG - 2023-04-20 01:14:42 --> Total execution time: 0.1368
ERROR - 2023-04-20 01:14:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 01:14:42 --> Config Class Initialized
INFO - 2023-04-20 01:14:42 --> Hooks Class Initialized
DEBUG - 2023-04-20 01:14:42 --> UTF-8 Support Enabled
INFO - 2023-04-20 01:14:42 --> Utf8 Class Initialized
INFO - 2023-04-20 01:14:42 --> URI Class Initialized
INFO - 2023-04-20 01:14:42 --> Router Class Initialized
INFO - 2023-04-20 01:14:42 --> Output Class Initialized
INFO - 2023-04-20 01:14:42 --> Security Class Initialized
DEBUG - 2023-04-20 01:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 01:14:42 --> Input Class Initialized
INFO - 2023-04-20 01:14:42 --> Language Class Initialized
INFO - 2023-04-20 01:14:42 --> Loader Class Initialized
INFO - 2023-04-20 01:14:42 --> Helper loaded: url_helper
INFO - 2023-04-20 01:14:42 --> Helper loaded: file_helper
INFO - 2023-04-20 01:14:42 --> Helper loaded: html_helper
INFO - 2023-04-20 01:14:42 --> Helper loaded: text_helper
INFO - 2023-04-20 01:14:42 --> Helper loaded: form_helper
INFO - 2023-04-20 01:14:42 --> Helper loaded: lang_helper
INFO - 2023-04-20 01:14:42 --> Helper loaded: security_helper
INFO - 2023-04-20 01:14:42 --> Helper loaded: cookie_helper
INFO - 2023-04-20 01:14:42 --> Database Driver Class Initialized
INFO - 2023-04-20 01:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 01:14:42 --> Parser Class Initialized
INFO - 2023-04-20 01:14:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 01:14:42 --> Pagination Class Initialized
INFO - 2023-04-20 01:14:42 --> Form Validation Class Initialized
INFO - 2023-04-20 01:14:42 --> Controller Class Initialized
INFO - 2023-04-20 01:14:42 --> Model Class Initialized
DEBUG - 2023-04-20 01:14:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 01:14:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 01:14:42 --> Model Class Initialized
DEBUG - 2023-04-20 01:14:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 01:14:42 --> Model Class Initialized
INFO - 2023-04-20 01:14:42 --> Final output sent to browser
DEBUG - 2023-04-20 01:14:42 --> Total execution time: 0.0542
ERROR - 2023-04-20 01:14:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 01:14:50 --> Config Class Initialized
INFO - 2023-04-20 01:14:50 --> Hooks Class Initialized
DEBUG - 2023-04-20 01:14:50 --> UTF-8 Support Enabled
INFO - 2023-04-20 01:14:50 --> Utf8 Class Initialized
INFO - 2023-04-20 01:14:50 --> URI Class Initialized
INFO - 2023-04-20 01:14:50 --> Router Class Initialized
INFO - 2023-04-20 01:14:50 --> Output Class Initialized
INFO - 2023-04-20 01:14:50 --> Security Class Initialized
DEBUG - 2023-04-20 01:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 01:14:50 --> Input Class Initialized
INFO - 2023-04-20 01:14:50 --> Language Class Initialized
INFO - 2023-04-20 01:14:50 --> Loader Class Initialized
INFO - 2023-04-20 01:14:50 --> Helper loaded: url_helper
INFO - 2023-04-20 01:14:50 --> Helper loaded: file_helper
INFO - 2023-04-20 01:14:50 --> Helper loaded: html_helper
INFO - 2023-04-20 01:14:50 --> Helper loaded: text_helper
INFO - 2023-04-20 01:14:50 --> Helper loaded: form_helper
INFO - 2023-04-20 01:14:50 --> Helper loaded: lang_helper
INFO - 2023-04-20 01:14:50 --> Helper loaded: security_helper
INFO - 2023-04-20 01:14:50 --> Helper loaded: cookie_helper
INFO - 2023-04-20 01:14:50 --> Database Driver Class Initialized
INFO - 2023-04-20 01:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 01:14:50 --> Parser Class Initialized
INFO - 2023-04-20 01:14:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 01:14:50 --> Pagination Class Initialized
INFO - 2023-04-20 01:14:50 --> Form Validation Class Initialized
INFO - 2023-04-20 01:14:50 --> Controller Class Initialized
INFO - 2023-04-20 01:14:50 --> Model Class Initialized
DEBUG - 2023-04-20 01:14:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 01:14:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 01:14:50 --> Model Class Initialized
DEBUG - 2023-04-20 01:14:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 01:14:50 --> Model Class Initialized
INFO - 2023-04-20 01:14:50 --> Final output sent to browser
DEBUG - 2023-04-20 01:14:50 --> Total execution time: 0.0637
ERROR - 2023-04-20 01:15:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 01:15:39 --> Config Class Initialized
INFO - 2023-04-20 01:15:39 --> Hooks Class Initialized
DEBUG - 2023-04-20 01:15:39 --> UTF-8 Support Enabled
INFO - 2023-04-20 01:15:39 --> Utf8 Class Initialized
INFO - 2023-04-20 01:15:39 --> URI Class Initialized
INFO - 2023-04-20 01:15:39 --> Router Class Initialized
INFO - 2023-04-20 01:15:39 --> Output Class Initialized
INFO - 2023-04-20 01:15:39 --> Security Class Initialized
DEBUG - 2023-04-20 01:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 01:15:39 --> Input Class Initialized
INFO - 2023-04-20 01:15:39 --> Language Class Initialized
INFO - 2023-04-20 01:15:39 --> Loader Class Initialized
INFO - 2023-04-20 01:15:39 --> Helper loaded: url_helper
INFO - 2023-04-20 01:15:39 --> Helper loaded: file_helper
INFO - 2023-04-20 01:15:39 --> Helper loaded: html_helper
INFO - 2023-04-20 01:15:39 --> Helper loaded: text_helper
INFO - 2023-04-20 01:15:39 --> Helper loaded: form_helper
INFO - 2023-04-20 01:15:39 --> Helper loaded: lang_helper
INFO - 2023-04-20 01:15:39 --> Helper loaded: security_helper
INFO - 2023-04-20 01:15:39 --> Helper loaded: cookie_helper
INFO - 2023-04-20 01:15:39 --> Database Driver Class Initialized
INFO - 2023-04-20 01:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 01:15:39 --> Parser Class Initialized
INFO - 2023-04-20 01:15:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 01:15:39 --> Pagination Class Initialized
INFO - 2023-04-20 01:15:39 --> Form Validation Class Initialized
INFO - 2023-04-20 01:15:39 --> Controller Class Initialized
INFO - 2023-04-20 01:15:39 --> Model Class Initialized
DEBUG - 2023-04-20 01:15:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 01:15:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 01:15:39 --> Model Class Initialized
DEBUG - 2023-04-20 01:15:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 01:15:39 --> Model Class Initialized
INFO - 2023-04-20 01:15:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-04-20 01:15:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 01:15:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 01:15:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 01:15:39 --> Model Class Initialized
INFO - 2023-04-20 01:15:39 --> Model Class Initialized
INFO - 2023-04-20 01:15:39 --> Model Class Initialized
INFO - 2023-04-20 01:15:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 01:15:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 01:15:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 01:15:39 --> Final output sent to browser
DEBUG - 2023-04-20 01:15:39 --> Total execution time: 0.1377
ERROR - 2023-04-20 01:15:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 01:15:40 --> Config Class Initialized
INFO - 2023-04-20 01:15:40 --> Hooks Class Initialized
DEBUG - 2023-04-20 01:15:40 --> UTF-8 Support Enabled
INFO - 2023-04-20 01:15:40 --> Utf8 Class Initialized
INFO - 2023-04-20 01:15:40 --> URI Class Initialized
INFO - 2023-04-20 01:15:40 --> Router Class Initialized
INFO - 2023-04-20 01:15:40 --> Output Class Initialized
INFO - 2023-04-20 01:15:40 --> Security Class Initialized
DEBUG - 2023-04-20 01:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 01:15:40 --> Input Class Initialized
INFO - 2023-04-20 01:15:40 --> Language Class Initialized
INFO - 2023-04-20 01:15:40 --> Loader Class Initialized
INFO - 2023-04-20 01:15:40 --> Helper loaded: url_helper
INFO - 2023-04-20 01:15:40 --> Helper loaded: file_helper
INFO - 2023-04-20 01:15:40 --> Helper loaded: html_helper
INFO - 2023-04-20 01:15:40 --> Helper loaded: text_helper
INFO - 2023-04-20 01:15:40 --> Helper loaded: form_helper
INFO - 2023-04-20 01:15:40 --> Helper loaded: lang_helper
INFO - 2023-04-20 01:15:40 --> Helper loaded: security_helper
INFO - 2023-04-20 01:15:40 --> Helper loaded: cookie_helper
INFO - 2023-04-20 01:15:40 --> Database Driver Class Initialized
INFO - 2023-04-20 01:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 01:15:40 --> Parser Class Initialized
INFO - 2023-04-20 01:15:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 01:15:40 --> Pagination Class Initialized
INFO - 2023-04-20 01:15:40 --> Form Validation Class Initialized
INFO - 2023-04-20 01:15:40 --> Controller Class Initialized
INFO - 2023-04-20 01:15:40 --> Model Class Initialized
DEBUG - 2023-04-20 01:15:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 01:15:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 01:15:40 --> Model Class Initialized
DEBUG - 2023-04-20 01:15:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 01:15:40 --> Model Class Initialized
INFO - 2023-04-20 01:15:40 --> Final output sent to browser
DEBUG - 2023-04-20 01:15:40 --> Total execution time: 0.0252
ERROR - 2023-04-20 01:15:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 01:15:42 --> Config Class Initialized
INFO - 2023-04-20 01:15:42 --> Hooks Class Initialized
DEBUG - 2023-04-20 01:15:42 --> UTF-8 Support Enabled
INFO - 2023-04-20 01:15:42 --> Utf8 Class Initialized
INFO - 2023-04-20 01:15:42 --> URI Class Initialized
INFO - 2023-04-20 01:15:42 --> Router Class Initialized
INFO - 2023-04-20 01:15:42 --> Output Class Initialized
INFO - 2023-04-20 01:15:42 --> Security Class Initialized
DEBUG - 2023-04-20 01:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 01:15:42 --> Input Class Initialized
INFO - 2023-04-20 01:15:42 --> Language Class Initialized
INFO - 2023-04-20 01:15:42 --> Loader Class Initialized
INFO - 2023-04-20 01:15:42 --> Helper loaded: url_helper
INFO - 2023-04-20 01:15:42 --> Helper loaded: file_helper
INFO - 2023-04-20 01:15:42 --> Helper loaded: html_helper
INFO - 2023-04-20 01:15:42 --> Helper loaded: text_helper
INFO - 2023-04-20 01:15:42 --> Helper loaded: form_helper
INFO - 2023-04-20 01:15:42 --> Helper loaded: lang_helper
INFO - 2023-04-20 01:15:42 --> Helper loaded: security_helper
INFO - 2023-04-20 01:15:42 --> Helper loaded: cookie_helper
INFO - 2023-04-20 01:15:42 --> Database Driver Class Initialized
INFO - 2023-04-20 01:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 01:15:42 --> Parser Class Initialized
INFO - 2023-04-20 01:15:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 01:15:42 --> Pagination Class Initialized
INFO - 2023-04-20 01:15:42 --> Form Validation Class Initialized
INFO - 2023-04-20 01:15:42 --> Controller Class Initialized
INFO - 2023-04-20 01:15:42 --> Model Class Initialized
DEBUG - 2023-04-20 01:15:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 01:15:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 01:15:42 --> Model Class Initialized
DEBUG - 2023-04-20 01:15:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 01:15:42 --> Model Class Initialized
INFO - 2023-04-20 01:15:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html.php
DEBUG - 2023-04-20 01:15:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 01:15:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 01:15:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 01:15:42 --> Model Class Initialized
INFO - 2023-04-20 01:15:42 --> Model Class Initialized
INFO - 2023-04-20 01:15:42 --> Model Class Initialized
INFO - 2023-04-20 01:15:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 01:15:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 01:15:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 01:15:42 --> Final output sent to browser
DEBUG - 2023-04-20 01:15:42 --> Total execution time: 0.1475
ERROR - 2023-04-20 01:15:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 01:15:57 --> Config Class Initialized
INFO - 2023-04-20 01:15:57 --> Hooks Class Initialized
DEBUG - 2023-04-20 01:15:57 --> UTF-8 Support Enabled
INFO - 2023-04-20 01:15:57 --> Utf8 Class Initialized
INFO - 2023-04-20 01:15:57 --> URI Class Initialized
INFO - 2023-04-20 01:15:57 --> Router Class Initialized
INFO - 2023-04-20 01:15:57 --> Output Class Initialized
INFO - 2023-04-20 01:15:57 --> Security Class Initialized
DEBUG - 2023-04-20 01:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 01:15:57 --> Input Class Initialized
INFO - 2023-04-20 01:15:57 --> Language Class Initialized
INFO - 2023-04-20 01:15:57 --> Loader Class Initialized
INFO - 2023-04-20 01:15:57 --> Helper loaded: url_helper
INFO - 2023-04-20 01:15:57 --> Helper loaded: file_helper
INFO - 2023-04-20 01:15:57 --> Helper loaded: html_helper
INFO - 2023-04-20 01:15:57 --> Helper loaded: text_helper
INFO - 2023-04-20 01:15:57 --> Helper loaded: form_helper
INFO - 2023-04-20 01:15:57 --> Helper loaded: lang_helper
INFO - 2023-04-20 01:15:57 --> Helper loaded: security_helper
INFO - 2023-04-20 01:15:57 --> Helper loaded: cookie_helper
INFO - 2023-04-20 01:15:57 --> Database Driver Class Initialized
INFO - 2023-04-20 01:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 01:15:57 --> Parser Class Initialized
INFO - 2023-04-20 01:15:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 01:15:57 --> Pagination Class Initialized
INFO - 2023-04-20 01:15:57 --> Form Validation Class Initialized
INFO - 2023-04-20 01:15:57 --> Controller Class Initialized
INFO - 2023-04-20 01:15:57 --> Model Class Initialized
DEBUG - 2023-04-20 01:15:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 01:15:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 01:15:57 --> Model Class Initialized
DEBUG - 2023-04-20 01:15:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 01:15:57 --> Model Class Initialized
INFO - 2023-04-20 01:15:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-04-20 01:15:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 01:15:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 01:15:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 01:15:57 --> Model Class Initialized
INFO - 2023-04-20 01:15:57 --> Model Class Initialized
INFO - 2023-04-20 01:15:57 --> Model Class Initialized
INFO - 2023-04-20 01:15:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 01:15:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 01:15:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 01:15:57 --> Final output sent to browser
DEBUG - 2023-04-20 01:15:57 --> Total execution time: 0.1359
ERROR - 2023-04-20 01:15:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 01:15:58 --> Config Class Initialized
INFO - 2023-04-20 01:15:58 --> Hooks Class Initialized
DEBUG - 2023-04-20 01:15:58 --> UTF-8 Support Enabled
INFO - 2023-04-20 01:15:58 --> Utf8 Class Initialized
INFO - 2023-04-20 01:15:58 --> URI Class Initialized
INFO - 2023-04-20 01:15:58 --> Router Class Initialized
INFO - 2023-04-20 01:15:58 --> Output Class Initialized
INFO - 2023-04-20 01:15:58 --> Security Class Initialized
DEBUG - 2023-04-20 01:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 01:15:58 --> Input Class Initialized
INFO - 2023-04-20 01:15:58 --> Language Class Initialized
INFO - 2023-04-20 01:15:58 --> Loader Class Initialized
INFO - 2023-04-20 01:15:58 --> Helper loaded: url_helper
INFO - 2023-04-20 01:15:58 --> Helper loaded: file_helper
INFO - 2023-04-20 01:15:58 --> Helper loaded: html_helper
INFO - 2023-04-20 01:15:58 --> Helper loaded: text_helper
INFO - 2023-04-20 01:15:58 --> Helper loaded: form_helper
INFO - 2023-04-20 01:15:58 --> Helper loaded: lang_helper
INFO - 2023-04-20 01:15:58 --> Helper loaded: security_helper
INFO - 2023-04-20 01:15:58 --> Helper loaded: cookie_helper
INFO - 2023-04-20 01:15:58 --> Database Driver Class Initialized
INFO - 2023-04-20 01:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 01:15:58 --> Parser Class Initialized
INFO - 2023-04-20 01:15:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 01:15:58 --> Pagination Class Initialized
INFO - 2023-04-20 01:15:58 --> Form Validation Class Initialized
INFO - 2023-04-20 01:15:58 --> Controller Class Initialized
INFO - 2023-04-20 01:15:58 --> Model Class Initialized
DEBUG - 2023-04-20 01:15:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 01:15:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 01:15:58 --> Model Class Initialized
DEBUG - 2023-04-20 01:15:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 01:15:58 --> Model Class Initialized
INFO - 2023-04-20 01:15:58 --> Final output sent to browser
DEBUG - 2023-04-20 01:15:58 --> Total execution time: 0.0253
ERROR - 2023-04-20 01:16:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 01:16:17 --> Config Class Initialized
INFO - 2023-04-20 01:16:17 --> Hooks Class Initialized
DEBUG - 2023-04-20 01:16:17 --> UTF-8 Support Enabled
INFO - 2023-04-20 01:16:17 --> Utf8 Class Initialized
INFO - 2023-04-20 01:16:17 --> URI Class Initialized
INFO - 2023-04-20 01:16:17 --> Router Class Initialized
INFO - 2023-04-20 01:16:17 --> Output Class Initialized
INFO - 2023-04-20 01:16:17 --> Security Class Initialized
DEBUG - 2023-04-20 01:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 01:16:17 --> Input Class Initialized
INFO - 2023-04-20 01:16:17 --> Language Class Initialized
INFO - 2023-04-20 01:16:17 --> Loader Class Initialized
INFO - 2023-04-20 01:16:17 --> Helper loaded: url_helper
INFO - 2023-04-20 01:16:17 --> Helper loaded: file_helper
INFO - 2023-04-20 01:16:17 --> Helper loaded: html_helper
INFO - 2023-04-20 01:16:17 --> Helper loaded: text_helper
INFO - 2023-04-20 01:16:17 --> Helper loaded: form_helper
INFO - 2023-04-20 01:16:17 --> Helper loaded: lang_helper
INFO - 2023-04-20 01:16:17 --> Helper loaded: security_helper
INFO - 2023-04-20 01:16:17 --> Helper loaded: cookie_helper
INFO - 2023-04-20 01:16:17 --> Database Driver Class Initialized
INFO - 2023-04-20 01:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 01:16:17 --> Parser Class Initialized
INFO - 2023-04-20 01:16:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 01:16:17 --> Pagination Class Initialized
INFO - 2023-04-20 01:16:17 --> Form Validation Class Initialized
INFO - 2023-04-20 01:16:17 --> Controller Class Initialized
INFO - 2023-04-20 01:16:17 --> Model Class Initialized
DEBUG - 2023-04-20 01:16:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 01:16:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 01:16:17 --> Model Class Initialized
DEBUG - 2023-04-20 01:16:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 01:16:17 --> Model Class Initialized
INFO - 2023-04-20 01:16:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-04-20 01:16:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 01:16:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 01:16:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 01:16:17 --> Model Class Initialized
INFO - 2023-04-20 01:16:17 --> Model Class Initialized
INFO - 2023-04-20 01:16:17 --> Model Class Initialized
INFO - 2023-04-20 01:16:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 01:16:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 01:16:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 01:16:17 --> Final output sent to browser
DEBUG - 2023-04-20 01:16:17 --> Total execution time: 0.1369
ERROR - 2023-04-20 01:16:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 01:16:17 --> Config Class Initialized
INFO - 2023-04-20 01:16:17 --> Hooks Class Initialized
DEBUG - 2023-04-20 01:16:17 --> UTF-8 Support Enabled
INFO - 2023-04-20 01:16:17 --> Utf8 Class Initialized
INFO - 2023-04-20 01:16:17 --> URI Class Initialized
INFO - 2023-04-20 01:16:17 --> Router Class Initialized
INFO - 2023-04-20 01:16:17 --> Output Class Initialized
INFO - 2023-04-20 01:16:17 --> Security Class Initialized
DEBUG - 2023-04-20 01:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 01:16:17 --> Input Class Initialized
INFO - 2023-04-20 01:16:17 --> Language Class Initialized
INFO - 2023-04-20 01:16:17 --> Loader Class Initialized
INFO - 2023-04-20 01:16:17 --> Helper loaded: url_helper
INFO - 2023-04-20 01:16:17 --> Helper loaded: file_helper
INFO - 2023-04-20 01:16:17 --> Helper loaded: html_helper
INFO - 2023-04-20 01:16:17 --> Helper loaded: text_helper
INFO - 2023-04-20 01:16:17 --> Helper loaded: form_helper
INFO - 2023-04-20 01:16:17 --> Helper loaded: lang_helper
INFO - 2023-04-20 01:16:17 --> Helper loaded: security_helper
INFO - 2023-04-20 01:16:17 --> Helper loaded: cookie_helper
INFO - 2023-04-20 01:16:17 --> Database Driver Class Initialized
INFO - 2023-04-20 01:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 01:16:17 --> Parser Class Initialized
INFO - 2023-04-20 01:16:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 01:16:17 --> Pagination Class Initialized
INFO - 2023-04-20 01:16:17 --> Form Validation Class Initialized
INFO - 2023-04-20 01:16:17 --> Controller Class Initialized
INFO - 2023-04-20 01:16:17 --> Model Class Initialized
DEBUG - 2023-04-20 01:16:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 01:16:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 01:16:17 --> Model Class Initialized
DEBUG - 2023-04-20 01:16:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 01:16:17 --> Model Class Initialized
INFO - 2023-04-20 01:16:17 --> Final output sent to browser
DEBUG - 2023-04-20 01:16:17 --> Total execution time: 0.0540
ERROR - 2023-04-20 01:16:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 01:16:25 --> Config Class Initialized
INFO - 2023-04-20 01:16:25 --> Hooks Class Initialized
DEBUG - 2023-04-20 01:16:25 --> UTF-8 Support Enabled
INFO - 2023-04-20 01:16:25 --> Utf8 Class Initialized
INFO - 2023-04-20 01:16:25 --> URI Class Initialized
INFO - 2023-04-20 01:16:25 --> Router Class Initialized
INFO - 2023-04-20 01:16:25 --> Output Class Initialized
INFO - 2023-04-20 01:16:25 --> Security Class Initialized
DEBUG - 2023-04-20 01:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 01:16:25 --> Input Class Initialized
INFO - 2023-04-20 01:16:25 --> Language Class Initialized
INFO - 2023-04-20 01:16:25 --> Loader Class Initialized
INFO - 2023-04-20 01:16:25 --> Helper loaded: url_helper
INFO - 2023-04-20 01:16:25 --> Helper loaded: file_helper
INFO - 2023-04-20 01:16:25 --> Helper loaded: html_helper
INFO - 2023-04-20 01:16:25 --> Helper loaded: text_helper
INFO - 2023-04-20 01:16:25 --> Helper loaded: form_helper
INFO - 2023-04-20 01:16:25 --> Helper loaded: lang_helper
INFO - 2023-04-20 01:16:25 --> Helper loaded: security_helper
INFO - 2023-04-20 01:16:25 --> Helper loaded: cookie_helper
INFO - 2023-04-20 01:16:25 --> Database Driver Class Initialized
INFO - 2023-04-20 01:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 01:16:25 --> Parser Class Initialized
INFO - 2023-04-20 01:16:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 01:16:25 --> Pagination Class Initialized
INFO - 2023-04-20 01:16:25 --> Form Validation Class Initialized
INFO - 2023-04-20 01:16:25 --> Controller Class Initialized
INFO - 2023-04-20 01:16:25 --> Model Class Initialized
DEBUG - 2023-04-20 01:16:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 01:16:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 01:16:25 --> Model Class Initialized
DEBUG - 2023-04-20 01:16:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 01:16:25 --> Model Class Initialized
INFO - 2023-04-20 01:16:25 --> Final output sent to browser
DEBUG - 2023-04-20 01:16:25 --> Total execution time: 0.0616
ERROR - 2023-04-20 06:15:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 06:15:12 --> Config Class Initialized
INFO - 2023-04-20 06:15:12 --> Hooks Class Initialized
DEBUG - 2023-04-20 06:15:12 --> UTF-8 Support Enabled
INFO - 2023-04-20 06:15:12 --> Utf8 Class Initialized
INFO - 2023-04-20 06:15:12 --> URI Class Initialized
DEBUG - 2023-04-20 06:15:12 --> No URI present. Default controller set.
INFO - 2023-04-20 06:15:12 --> Router Class Initialized
INFO - 2023-04-20 06:15:12 --> Output Class Initialized
INFO - 2023-04-20 06:15:12 --> Security Class Initialized
DEBUG - 2023-04-20 06:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 06:15:12 --> Input Class Initialized
INFO - 2023-04-20 06:15:12 --> Language Class Initialized
INFO - 2023-04-20 06:15:12 --> Loader Class Initialized
INFO - 2023-04-20 06:15:12 --> Helper loaded: url_helper
INFO - 2023-04-20 06:15:12 --> Helper loaded: file_helper
INFO - 2023-04-20 06:15:12 --> Helper loaded: html_helper
INFO - 2023-04-20 06:15:12 --> Helper loaded: text_helper
INFO - 2023-04-20 06:15:12 --> Helper loaded: form_helper
INFO - 2023-04-20 06:15:12 --> Helper loaded: lang_helper
INFO - 2023-04-20 06:15:12 --> Helper loaded: security_helper
INFO - 2023-04-20 06:15:12 --> Helper loaded: cookie_helper
INFO - 2023-04-20 06:15:12 --> Database Driver Class Initialized
INFO - 2023-04-20 06:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 06:15:12 --> Parser Class Initialized
INFO - 2023-04-20 06:15:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 06:15:12 --> Pagination Class Initialized
INFO - 2023-04-20 06:15:12 --> Form Validation Class Initialized
INFO - 2023-04-20 06:15:12 --> Controller Class Initialized
INFO - 2023-04-20 06:15:12 --> Model Class Initialized
DEBUG - 2023-04-20 06:15:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-20 06:15:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 06:15:13 --> Config Class Initialized
INFO - 2023-04-20 06:15:13 --> Hooks Class Initialized
DEBUG - 2023-04-20 06:15:13 --> UTF-8 Support Enabled
INFO - 2023-04-20 06:15:13 --> Utf8 Class Initialized
INFO - 2023-04-20 06:15:13 --> URI Class Initialized
INFO - 2023-04-20 06:15:13 --> Router Class Initialized
INFO - 2023-04-20 06:15:13 --> Output Class Initialized
INFO - 2023-04-20 06:15:13 --> Security Class Initialized
DEBUG - 2023-04-20 06:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 06:15:13 --> Input Class Initialized
INFO - 2023-04-20 06:15:13 --> Language Class Initialized
INFO - 2023-04-20 06:15:13 --> Loader Class Initialized
INFO - 2023-04-20 06:15:13 --> Helper loaded: url_helper
INFO - 2023-04-20 06:15:13 --> Helper loaded: file_helper
INFO - 2023-04-20 06:15:13 --> Helper loaded: html_helper
INFO - 2023-04-20 06:15:13 --> Helper loaded: text_helper
INFO - 2023-04-20 06:15:13 --> Helper loaded: form_helper
INFO - 2023-04-20 06:15:13 --> Helper loaded: lang_helper
INFO - 2023-04-20 06:15:13 --> Helper loaded: security_helper
INFO - 2023-04-20 06:15:13 --> Helper loaded: cookie_helper
INFO - 2023-04-20 06:15:13 --> Database Driver Class Initialized
INFO - 2023-04-20 06:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 06:15:13 --> Parser Class Initialized
INFO - 2023-04-20 06:15:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 06:15:13 --> Pagination Class Initialized
INFO - 2023-04-20 06:15:13 --> Form Validation Class Initialized
INFO - 2023-04-20 06:15:13 --> Controller Class Initialized
INFO - 2023-04-20 06:15:13 --> Model Class Initialized
DEBUG - 2023-04-20 06:15:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 06:15:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-20 06:15:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 06:15:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 06:15:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 06:15:13 --> Model Class Initialized
INFO - 2023-04-20 06:15:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 06:15:13 --> Final output sent to browser
DEBUG - 2023-04-20 06:15:13 --> Total execution time: 0.0346
ERROR - 2023-04-20 06:15:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 06:15:37 --> Config Class Initialized
INFO - 2023-04-20 06:15:37 --> Hooks Class Initialized
DEBUG - 2023-04-20 06:15:37 --> UTF-8 Support Enabled
INFO - 2023-04-20 06:15:37 --> Utf8 Class Initialized
INFO - 2023-04-20 06:15:37 --> URI Class Initialized
INFO - 2023-04-20 06:15:37 --> Router Class Initialized
INFO - 2023-04-20 06:15:37 --> Output Class Initialized
INFO - 2023-04-20 06:15:37 --> Security Class Initialized
DEBUG - 2023-04-20 06:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 06:15:37 --> Input Class Initialized
INFO - 2023-04-20 06:15:37 --> Language Class Initialized
INFO - 2023-04-20 06:15:37 --> Loader Class Initialized
INFO - 2023-04-20 06:15:37 --> Helper loaded: url_helper
INFO - 2023-04-20 06:15:37 --> Helper loaded: file_helper
INFO - 2023-04-20 06:15:37 --> Helper loaded: html_helper
INFO - 2023-04-20 06:15:37 --> Helper loaded: text_helper
INFO - 2023-04-20 06:15:37 --> Helper loaded: form_helper
INFO - 2023-04-20 06:15:37 --> Helper loaded: lang_helper
INFO - 2023-04-20 06:15:37 --> Helper loaded: security_helper
INFO - 2023-04-20 06:15:37 --> Helper loaded: cookie_helper
INFO - 2023-04-20 06:15:37 --> Database Driver Class Initialized
INFO - 2023-04-20 06:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 06:15:37 --> Parser Class Initialized
INFO - 2023-04-20 06:15:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 06:15:37 --> Pagination Class Initialized
INFO - 2023-04-20 06:15:37 --> Form Validation Class Initialized
INFO - 2023-04-20 06:15:37 --> Controller Class Initialized
INFO - 2023-04-20 06:15:37 --> Model Class Initialized
DEBUG - 2023-04-20 06:15:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 06:15:37 --> Model Class Initialized
INFO - 2023-04-20 06:15:37 --> Final output sent to browser
DEBUG - 2023-04-20 06:15:37 --> Total execution time: 0.0202
ERROR - 2023-04-20 06:15:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 06:15:37 --> Config Class Initialized
INFO - 2023-04-20 06:15:37 --> Hooks Class Initialized
DEBUG - 2023-04-20 06:15:37 --> UTF-8 Support Enabled
INFO - 2023-04-20 06:15:37 --> Utf8 Class Initialized
INFO - 2023-04-20 06:15:37 --> URI Class Initialized
INFO - 2023-04-20 06:15:37 --> Router Class Initialized
INFO - 2023-04-20 06:15:37 --> Output Class Initialized
INFO - 2023-04-20 06:15:37 --> Security Class Initialized
DEBUG - 2023-04-20 06:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 06:15:37 --> Input Class Initialized
INFO - 2023-04-20 06:15:37 --> Language Class Initialized
INFO - 2023-04-20 06:15:37 --> Loader Class Initialized
INFO - 2023-04-20 06:15:37 --> Helper loaded: url_helper
INFO - 2023-04-20 06:15:37 --> Helper loaded: file_helper
INFO - 2023-04-20 06:15:37 --> Helper loaded: html_helper
INFO - 2023-04-20 06:15:37 --> Helper loaded: text_helper
INFO - 2023-04-20 06:15:37 --> Helper loaded: form_helper
INFO - 2023-04-20 06:15:37 --> Helper loaded: lang_helper
INFO - 2023-04-20 06:15:37 --> Helper loaded: security_helper
INFO - 2023-04-20 06:15:37 --> Helper loaded: cookie_helper
INFO - 2023-04-20 06:15:37 --> Database Driver Class Initialized
INFO - 2023-04-20 06:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 06:15:37 --> Parser Class Initialized
INFO - 2023-04-20 06:15:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 06:15:37 --> Pagination Class Initialized
INFO - 2023-04-20 06:15:37 --> Form Validation Class Initialized
INFO - 2023-04-20 06:15:37 --> Controller Class Initialized
INFO - 2023-04-20 06:15:37 --> Model Class Initialized
DEBUG - 2023-04-20 06:15:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 06:15:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-20 06:15:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 06:15:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 06:15:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 06:15:37 --> Model Class Initialized
INFO - 2023-04-20 06:15:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 06:15:37 --> Final output sent to browser
DEBUG - 2023-04-20 06:15:37 --> Total execution time: 0.0283
ERROR - 2023-04-20 06:16:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 06:16:18 --> Config Class Initialized
INFO - 2023-04-20 06:16:18 --> Hooks Class Initialized
DEBUG - 2023-04-20 06:16:18 --> UTF-8 Support Enabled
INFO - 2023-04-20 06:16:18 --> Utf8 Class Initialized
INFO - 2023-04-20 06:16:18 --> URI Class Initialized
DEBUG - 2023-04-20 06:16:18 --> No URI present. Default controller set.
INFO - 2023-04-20 06:16:18 --> Router Class Initialized
INFO - 2023-04-20 06:16:18 --> Output Class Initialized
INFO - 2023-04-20 06:16:18 --> Security Class Initialized
DEBUG - 2023-04-20 06:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 06:16:18 --> Input Class Initialized
INFO - 2023-04-20 06:16:18 --> Language Class Initialized
INFO - 2023-04-20 06:16:18 --> Loader Class Initialized
INFO - 2023-04-20 06:16:18 --> Helper loaded: url_helper
INFO - 2023-04-20 06:16:18 --> Helper loaded: file_helper
INFO - 2023-04-20 06:16:18 --> Helper loaded: html_helper
INFO - 2023-04-20 06:16:18 --> Helper loaded: text_helper
INFO - 2023-04-20 06:16:18 --> Helper loaded: form_helper
INFO - 2023-04-20 06:16:18 --> Helper loaded: lang_helper
INFO - 2023-04-20 06:16:18 --> Helper loaded: security_helper
INFO - 2023-04-20 06:16:18 --> Helper loaded: cookie_helper
INFO - 2023-04-20 06:16:18 --> Database Driver Class Initialized
INFO - 2023-04-20 06:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 06:16:18 --> Parser Class Initialized
INFO - 2023-04-20 06:16:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 06:16:18 --> Pagination Class Initialized
INFO - 2023-04-20 06:16:18 --> Form Validation Class Initialized
INFO - 2023-04-20 06:16:18 --> Controller Class Initialized
INFO - 2023-04-20 06:16:18 --> Model Class Initialized
DEBUG - 2023-04-20 06:16:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-20 06:16:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 06:16:19 --> Config Class Initialized
INFO - 2023-04-20 06:16:19 --> Hooks Class Initialized
DEBUG - 2023-04-20 06:16:19 --> UTF-8 Support Enabled
INFO - 2023-04-20 06:16:19 --> Utf8 Class Initialized
INFO - 2023-04-20 06:16:19 --> URI Class Initialized
INFO - 2023-04-20 06:16:19 --> Router Class Initialized
INFO - 2023-04-20 06:16:19 --> Output Class Initialized
INFO - 2023-04-20 06:16:19 --> Security Class Initialized
DEBUG - 2023-04-20 06:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 06:16:19 --> Input Class Initialized
INFO - 2023-04-20 06:16:19 --> Language Class Initialized
INFO - 2023-04-20 06:16:19 --> Loader Class Initialized
INFO - 2023-04-20 06:16:19 --> Helper loaded: url_helper
INFO - 2023-04-20 06:16:19 --> Helper loaded: file_helper
INFO - 2023-04-20 06:16:19 --> Helper loaded: html_helper
INFO - 2023-04-20 06:16:19 --> Helper loaded: text_helper
INFO - 2023-04-20 06:16:19 --> Helper loaded: form_helper
INFO - 2023-04-20 06:16:19 --> Helper loaded: lang_helper
INFO - 2023-04-20 06:16:19 --> Helper loaded: security_helper
INFO - 2023-04-20 06:16:19 --> Helper loaded: cookie_helper
INFO - 2023-04-20 06:16:19 --> Database Driver Class Initialized
INFO - 2023-04-20 06:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 06:16:19 --> Parser Class Initialized
INFO - 2023-04-20 06:16:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 06:16:19 --> Pagination Class Initialized
INFO - 2023-04-20 06:16:19 --> Form Validation Class Initialized
INFO - 2023-04-20 06:16:19 --> Controller Class Initialized
INFO - 2023-04-20 06:16:19 --> Model Class Initialized
DEBUG - 2023-04-20 06:16:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 06:16:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-20 06:16:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 06:16:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 06:16:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 06:16:19 --> Model Class Initialized
INFO - 2023-04-20 06:16:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 06:16:19 --> Final output sent to browser
DEBUG - 2023-04-20 06:16:19 --> Total execution time: 0.0281
ERROR - 2023-04-20 06:17:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 06:17:00 --> Config Class Initialized
INFO - 2023-04-20 06:17:00 --> Hooks Class Initialized
DEBUG - 2023-04-20 06:17:00 --> UTF-8 Support Enabled
INFO - 2023-04-20 06:17:00 --> Utf8 Class Initialized
INFO - 2023-04-20 06:17:00 --> URI Class Initialized
INFO - 2023-04-20 06:17:00 --> Router Class Initialized
INFO - 2023-04-20 06:17:00 --> Output Class Initialized
INFO - 2023-04-20 06:17:00 --> Security Class Initialized
DEBUG - 2023-04-20 06:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 06:17:00 --> Input Class Initialized
INFO - 2023-04-20 06:17:00 --> Language Class Initialized
INFO - 2023-04-20 06:17:00 --> Loader Class Initialized
INFO - 2023-04-20 06:17:00 --> Helper loaded: url_helper
INFO - 2023-04-20 06:17:00 --> Helper loaded: file_helper
INFO - 2023-04-20 06:17:00 --> Helper loaded: html_helper
INFO - 2023-04-20 06:17:00 --> Helper loaded: text_helper
INFO - 2023-04-20 06:17:00 --> Helper loaded: form_helper
INFO - 2023-04-20 06:17:00 --> Helper loaded: lang_helper
INFO - 2023-04-20 06:17:00 --> Helper loaded: security_helper
INFO - 2023-04-20 06:17:00 --> Helper loaded: cookie_helper
INFO - 2023-04-20 06:17:00 --> Database Driver Class Initialized
INFO - 2023-04-20 06:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 06:17:00 --> Parser Class Initialized
INFO - 2023-04-20 06:17:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 06:17:00 --> Pagination Class Initialized
INFO - 2023-04-20 06:17:00 --> Form Validation Class Initialized
INFO - 2023-04-20 06:17:00 --> Controller Class Initialized
INFO - 2023-04-20 06:17:00 --> Model Class Initialized
DEBUG - 2023-04-20 06:17:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 06:17:00 --> Model Class Initialized
INFO - 2023-04-20 06:17:00 --> Final output sent to browser
DEBUG - 2023-04-20 06:17:00 --> Total execution time: 0.0202
ERROR - 2023-04-20 06:17:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 06:17:01 --> Config Class Initialized
INFO - 2023-04-20 06:17:01 --> Hooks Class Initialized
DEBUG - 2023-04-20 06:17:01 --> UTF-8 Support Enabled
INFO - 2023-04-20 06:17:01 --> Utf8 Class Initialized
INFO - 2023-04-20 06:17:01 --> URI Class Initialized
DEBUG - 2023-04-20 06:17:01 --> No URI present. Default controller set.
INFO - 2023-04-20 06:17:01 --> Router Class Initialized
INFO - 2023-04-20 06:17:01 --> Output Class Initialized
INFO - 2023-04-20 06:17:01 --> Security Class Initialized
DEBUG - 2023-04-20 06:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 06:17:01 --> Input Class Initialized
INFO - 2023-04-20 06:17:01 --> Language Class Initialized
INFO - 2023-04-20 06:17:01 --> Loader Class Initialized
INFO - 2023-04-20 06:17:01 --> Helper loaded: url_helper
INFO - 2023-04-20 06:17:01 --> Helper loaded: file_helper
INFO - 2023-04-20 06:17:01 --> Helper loaded: html_helper
INFO - 2023-04-20 06:17:01 --> Helper loaded: text_helper
INFO - 2023-04-20 06:17:01 --> Helper loaded: form_helper
INFO - 2023-04-20 06:17:01 --> Helper loaded: lang_helper
INFO - 2023-04-20 06:17:01 --> Helper loaded: security_helper
INFO - 2023-04-20 06:17:01 --> Helper loaded: cookie_helper
INFO - 2023-04-20 06:17:01 --> Database Driver Class Initialized
INFO - 2023-04-20 06:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 06:17:01 --> Parser Class Initialized
INFO - 2023-04-20 06:17:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 06:17:01 --> Pagination Class Initialized
INFO - 2023-04-20 06:17:01 --> Form Validation Class Initialized
INFO - 2023-04-20 06:17:01 --> Controller Class Initialized
INFO - 2023-04-20 06:17:01 --> Model Class Initialized
DEBUG - 2023-04-20 06:17:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 06:17:01 --> Model Class Initialized
DEBUG - 2023-04-20 06:17:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 06:17:01 --> Model Class Initialized
INFO - 2023-04-20 06:17:01 --> Model Class Initialized
INFO - 2023-04-20 06:17:01 --> Model Class Initialized
INFO - 2023-04-20 06:17:01 --> Model Class Initialized
DEBUG - 2023-04-20 06:17:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 06:17:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 06:17:01 --> Model Class Initialized
INFO - 2023-04-20 06:17:01 --> Model Class Initialized
INFO - 2023-04-20 06:17:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-20 06:17:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 06:17:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 06:17:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 06:17:01 --> Model Class Initialized
INFO - 2023-04-20 06:17:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 06:17:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 06:17:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 06:17:01 --> Final output sent to browser
DEBUG - 2023-04-20 06:17:01 --> Total execution time: 0.0768
ERROR - 2023-04-20 06:18:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 06:18:18 --> Config Class Initialized
INFO - 2023-04-20 06:18:18 --> Hooks Class Initialized
DEBUG - 2023-04-20 06:18:18 --> UTF-8 Support Enabled
INFO - 2023-04-20 06:18:18 --> Utf8 Class Initialized
INFO - 2023-04-20 06:18:18 --> URI Class Initialized
INFO - 2023-04-20 06:18:18 --> Router Class Initialized
INFO - 2023-04-20 06:18:18 --> Output Class Initialized
INFO - 2023-04-20 06:18:18 --> Security Class Initialized
DEBUG - 2023-04-20 06:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 06:18:18 --> Input Class Initialized
INFO - 2023-04-20 06:18:18 --> Language Class Initialized
INFO - 2023-04-20 06:18:18 --> Loader Class Initialized
INFO - 2023-04-20 06:18:18 --> Helper loaded: url_helper
INFO - 2023-04-20 06:18:18 --> Helper loaded: file_helper
INFO - 2023-04-20 06:18:18 --> Helper loaded: html_helper
INFO - 2023-04-20 06:18:18 --> Helper loaded: text_helper
INFO - 2023-04-20 06:18:18 --> Helper loaded: form_helper
INFO - 2023-04-20 06:18:18 --> Helper loaded: lang_helper
INFO - 2023-04-20 06:18:18 --> Helper loaded: security_helper
INFO - 2023-04-20 06:18:18 --> Helper loaded: cookie_helper
INFO - 2023-04-20 06:18:18 --> Database Driver Class Initialized
INFO - 2023-04-20 06:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 06:18:18 --> Parser Class Initialized
INFO - 2023-04-20 06:18:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 06:18:18 --> Pagination Class Initialized
INFO - 2023-04-20 06:18:18 --> Form Validation Class Initialized
INFO - 2023-04-20 06:18:18 --> Controller Class Initialized
INFO - 2023-04-20 06:18:18 --> Model Class Initialized
DEBUG - 2023-04-20 06:18:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 06:18:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-20 06:18:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 06:18:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 06:18:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 06:18:18 --> Model Class Initialized
INFO - 2023-04-20 06:18:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 06:18:18 --> Final output sent to browser
DEBUG - 2023-04-20 06:18:18 --> Total execution time: 0.0313
ERROR - 2023-04-20 06:18:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 06:18:18 --> Config Class Initialized
INFO - 2023-04-20 06:18:18 --> Hooks Class Initialized
DEBUG - 2023-04-20 06:18:18 --> UTF-8 Support Enabled
INFO - 2023-04-20 06:18:18 --> Utf8 Class Initialized
INFO - 2023-04-20 06:18:18 --> URI Class Initialized
INFO - 2023-04-20 06:18:18 --> Router Class Initialized
INFO - 2023-04-20 06:18:18 --> Output Class Initialized
INFO - 2023-04-20 06:18:18 --> Security Class Initialized
DEBUG - 2023-04-20 06:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 06:18:18 --> Input Class Initialized
INFO - 2023-04-20 06:18:18 --> Language Class Initialized
INFO - 2023-04-20 06:18:18 --> Loader Class Initialized
INFO - 2023-04-20 06:18:18 --> Helper loaded: url_helper
INFO - 2023-04-20 06:18:18 --> Helper loaded: file_helper
INFO - 2023-04-20 06:18:18 --> Helper loaded: html_helper
INFO - 2023-04-20 06:18:18 --> Helper loaded: text_helper
INFO - 2023-04-20 06:18:18 --> Helper loaded: form_helper
INFO - 2023-04-20 06:18:18 --> Helper loaded: lang_helper
INFO - 2023-04-20 06:18:18 --> Helper loaded: security_helper
INFO - 2023-04-20 06:18:18 --> Helper loaded: cookie_helper
INFO - 2023-04-20 06:18:18 --> Database Driver Class Initialized
INFO - 2023-04-20 06:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 06:18:18 --> Parser Class Initialized
INFO - 2023-04-20 06:18:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 06:18:18 --> Pagination Class Initialized
INFO - 2023-04-20 06:18:18 --> Form Validation Class Initialized
INFO - 2023-04-20 06:18:18 --> Controller Class Initialized
INFO - 2023-04-20 06:18:18 --> Model Class Initialized
DEBUG - 2023-04-20 06:18:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 06:18:18 --> Model Class Initialized
DEBUG - 2023-04-20 06:18:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 06:18:18 --> Model Class Initialized
INFO - 2023-04-20 06:18:18 --> Model Class Initialized
INFO - 2023-04-20 06:18:18 --> Model Class Initialized
INFO - 2023-04-20 06:18:18 --> Model Class Initialized
DEBUG - 2023-04-20 06:18:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 06:18:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 06:18:18 --> Model Class Initialized
INFO - 2023-04-20 06:18:18 --> Model Class Initialized
INFO - 2023-04-20 06:18:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-20 06:18:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 06:18:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 06:18:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 06:18:18 --> Model Class Initialized
INFO - 2023-04-20 06:18:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 06:18:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 06:18:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 06:18:18 --> Final output sent to browser
DEBUG - 2023-04-20 06:18:18 --> Total execution time: 0.0702
ERROR - 2023-04-20 07:54:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 07:54:15 --> Config Class Initialized
INFO - 2023-04-20 07:54:15 --> Hooks Class Initialized
DEBUG - 2023-04-20 07:54:15 --> UTF-8 Support Enabled
INFO - 2023-04-20 07:54:15 --> Utf8 Class Initialized
INFO - 2023-04-20 07:54:15 --> URI Class Initialized
INFO - 2023-04-20 07:54:15 --> Router Class Initialized
INFO - 2023-04-20 07:54:15 --> Output Class Initialized
INFO - 2023-04-20 07:54:15 --> Security Class Initialized
DEBUG - 2023-04-20 07:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 07:54:15 --> Input Class Initialized
INFO - 2023-04-20 07:54:15 --> Language Class Initialized
INFO - 2023-04-20 07:54:15 --> Loader Class Initialized
INFO - 2023-04-20 07:54:15 --> Helper loaded: url_helper
INFO - 2023-04-20 07:54:15 --> Helper loaded: file_helper
INFO - 2023-04-20 07:54:15 --> Helper loaded: html_helper
INFO - 2023-04-20 07:54:15 --> Helper loaded: text_helper
INFO - 2023-04-20 07:54:15 --> Helper loaded: form_helper
INFO - 2023-04-20 07:54:15 --> Helper loaded: lang_helper
INFO - 2023-04-20 07:54:15 --> Helper loaded: security_helper
INFO - 2023-04-20 07:54:15 --> Helper loaded: cookie_helper
INFO - 2023-04-20 07:54:15 --> Database Driver Class Initialized
INFO - 2023-04-20 07:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 07:54:15 --> Parser Class Initialized
INFO - 2023-04-20 07:54:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 07:54:15 --> Pagination Class Initialized
INFO - 2023-04-20 07:54:15 --> Form Validation Class Initialized
INFO - 2023-04-20 07:54:15 --> Controller Class Initialized
ERROR - 2023-04-20 07:54:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 07:54:17 --> Config Class Initialized
INFO - 2023-04-20 07:54:17 --> Hooks Class Initialized
DEBUG - 2023-04-20 07:54:17 --> UTF-8 Support Enabled
INFO - 2023-04-20 07:54:17 --> Utf8 Class Initialized
INFO - 2023-04-20 07:54:17 --> URI Class Initialized
INFO - 2023-04-20 07:54:17 --> Router Class Initialized
INFO - 2023-04-20 07:54:17 --> Output Class Initialized
INFO - 2023-04-20 07:54:17 --> Security Class Initialized
DEBUG - 2023-04-20 07:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 07:54:17 --> Input Class Initialized
INFO - 2023-04-20 07:54:17 --> Language Class Initialized
INFO - 2023-04-20 07:54:17 --> Loader Class Initialized
INFO - 2023-04-20 07:54:17 --> Helper loaded: url_helper
INFO - 2023-04-20 07:54:17 --> Helper loaded: file_helper
INFO - 2023-04-20 07:54:17 --> Helper loaded: html_helper
INFO - 2023-04-20 07:54:17 --> Helper loaded: text_helper
INFO - 2023-04-20 07:54:17 --> Helper loaded: form_helper
INFO - 2023-04-20 07:54:17 --> Helper loaded: lang_helper
INFO - 2023-04-20 07:54:17 --> Helper loaded: security_helper
INFO - 2023-04-20 07:54:17 --> Helper loaded: cookie_helper
INFO - 2023-04-20 07:54:17 --> Database Driver Class Initialized
INFO - 2023-04-20 07:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 07:54:17 --> Parser Class Initialized
INFO - 2023-04-20 07:54:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 07:54:17 --> Pagination Class Initialized
INFO - 2023-04-20 07:54:17 --> Form Validation Class Initialized
INFO - 2023-04-20 07:54:17 --> Controller Class Initialized
INFO - 2023-04-20 07:54:17 --> Model Class Initialized
DEBUG - 2023-04-20 07:54:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 07:54:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-20 07:54:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 07:54:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 07:54:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 07:54:17 --> Model Class Initialized
INFO - 2023-04-20 07:54:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 07:54:17 --> Final output sent to browser
DEBUG - 2023-04-20 07:54:17 --> Total execution time: 0.0343
ERROR - 2023-04-20 07:54:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 07:54:30 --> Config Class Initialized
INFO - 2023-04-20 07:54:30 --> Hooks Class Initialized
DEBUG - 2023-04-20 07:54:30 --> UTF-8 Support Enabled
INFO - 2023-04-20 07:54:30 --> Utf8 Class Initialized
INFO - 2023-04-20 07:54:30 --> URI Class Initialized
DEBUG - 2023-04-20 07:54:30 --> No URI present. Default controller set.
INFO - 2023-04-20 07:54:30 --> Router Class Initialized
INFO - 2023-04-20 07:54:30 --> Output Class Initialized
INFO - 2023-04-20 07:54:30 --> Security Class Initialized
DEBUG - 2023-04-20 07:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 07:54:30 --> Input Class Initialized
INFO - 2023-04-20 07:54:30 --> Language Class Initialized
INFO - 2023-04-20 07:54:30 --> Loader Class Initialized
INFO - 2023-04-20 07:54:31 --> Helper loaded: url_helper
INFO - 2023-04-20 07:54:31 --> Helper loaded: file_helper
INFO - 2023-04-20 07:54:31 --> Helper loaded: html_helper
INFO - 2023-04-20 07:54:31 --> Helper loaded: text_helper
INFO - 2023-04-20 07:54:31 --> Helper loaded: form_helper
INFO - 2023-04-20 07:54:31 --> Helper loaded: lang_helper
INFO - 2023-04-20 07:54:31 --> Helper loaded: security_helper
INFO - 2023-04-20 07:54:31 --> Helper loaded: cookie_helper
INFO - 2023-04-20 07:54:31 --> Database Driver Class Initialized
INFO - 2023-04-20 07:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 07:54:31 --> Parser Class Initialized
INFO - 2023-04-20 07:54:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 07:54:31 --> Pagination Class Initialized
INFO - 2023-04-20 07:54:31 --> Form Validation Class Initialized
INFO - 2023-04-20 07:54:31 --> Controller Class Initialized
INFO - 2023-04-20 07:54:31 --> Model Class Initialized
DEBUG - 2023-04-20 07:54:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-20 07:54:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 07:54:31 --> Config Class Initialized
INFO - 2023-04-20 07:54:31 --> Hooks Class Initialized
DEBUG - 2023-04-20 07:54:31 --> UTF-8 Support Enabled
INFO - 2023-04-20 07:54:31 --> Utf8 Class Initialized
INFO - 2023-04-20 07:54:31 --> URI Class Initialized
INFO - 2023-04-20 07:54:31 --> Router Class Initialized
INFO - 2023-04-20 07:54:31 --> Output Class Initialized
INFO - 2023-04-20 07:54:31 --> Security Class Initialized
DEBUG - 2023-04-20 07:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 07:54:31 --> Input Class Initialized
INFO - 2023-04-20 07:54:31 --> Language Class Initialized
INFO - 2023-04-20 07:54:31 --> Loader Class Initialized
INFO - 2023-04-20 07:54:31 --> Helper loaded: url_helper
INFO - 2023-04-20 07:54:31 --> Helper loaded: file_helper
INFO - 2023-04-20 07:54:31 --> Helper loaded: html_helper
INFO - 2023-04-20 07:54:31 --> Helper loaded: text_helper
INFO - 2023-04-20 07:54:31 --> Helper loaded: form_helper
INFO - 2023-04-20 07:54:31 --> Helper loaded: lang_helper
INFO - 2023-04-20 07:54:31 --> Helper loaded: security_helper
INFO - 2023-04-20 07:54:31 --> Helper loaded: cookie_helper
INFO - 2023-04-20 07:54:31 --> Database Driver Class Initialized
INFO - 2023-04-20 07:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 07:54:31 --> Parser Class Initialized
INFO - 2023-04-20 07:54:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 07:54:31 --> Pagination Class Initialized
INFO - 2023-04-20 07:54:31 --> Form Validation Class Initialized
INFO - 2023-04-20 07:54:31 --> Controller Class Initialized
INFO - 2023-04-20 07:54:31 --> Model Class Initialized
DEBUG - 2023-04-20 07:54:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 07:54:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-20 07:54:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 07:54:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 07:54:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 07:54:31 --> Model Class Initialized
INFO - 2023-04-20 07:54:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 07:54:31 --> Final output sent to browser
DEBUG - 2023-04-20 07:54:31 --> Total execution time: 0.0308
ERROR - 2023-04-20 07:54:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 07:54:49 --> Config Class Initialized
INFO - 2023-04-20 07:54:49 --> Hooks Class Initialized
DEBUG - 2023-04-20 07:54:49 --> UTF-8 Support Enabled
INFO - 2023-04-20 07:54:49 --> Utf8 Class Initialized
INFO - 2023-04-20 07:54:49 --> URI Class Initialized
INFO - 2023-04-20 07:54:49 --> Router Class Initialized
INFO - 2023-04-20 07:54:49 --> Output Class Initialized
INFO - 2023-04-20 07:54:49 --> Security Class Initialized
DEBUG - 2023-04-20 07:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 07:54:49 --> Input Class Initialized
INFO - 2023-04-20 07:54:49 --> Language Class Initialized
INFO - 2023-04-20 07:54:49 --> Loader Class Initialized
INFO - 2023-04-20 07:54:49 --> Helper loaded: url_helper
INFO - 2023-04-20 07:54:49 --> Helper loaded: file_helper
INFO - 2023-04-20 07:54:49 --> Helper loaded: html_helper
INFO - 2023-04-20 07:54:49 --> Helper loaded: text_helper
INFO - 2023-04-20 07:54:49 --> Helper loaded: form_helper
INFO - 2023-04-20 07:54:49 --> Helper loaded: lang_helper
INFO - 2023-04-20 07:54:49 --> Helper loaded: security_helper
INFO - 2023-04-20 07:54:49 --> Helper loaded: cookie_helper
INFO - 2023-04-20 07:54:49 --> Database Driver Class Initialized
INFO - 2023-04-20 07:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 07:54:49 --> Parser Class Initialized
INFO - 2023-04-20 07:54:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 07:54:49 --> Pagination Class Initialized
INFO - 2023-04-20 07:54:49 --> Form Validation Class Initialized
INFO - 2023-04-20 07:54:49 --> Controller Class Initialized
INFO - 2023-04-20 07:54:49 --> Model Class Initialized
DEBUG - 2023-04-20 07:54:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 07:54:49 --> Model Class Initialized
INFO - 2023-04-20 07:54:49 --> Final output sent to browser
DEBUG - 2023-04-20 07:54:49 --> Total execution time: 0.0225
ERROR - 2023-04-20 07:54:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 07:54:49 --> Config Class Initialized
INFO - 2023-04-20 07:54:49 --> Hooks Class Initialized
DEBUG - 2023-04-20 07:54:49 --> UTF-8 Support Enabled
INFO - 2023-04-20 07:54:49 --> Utf8 Class Initialized
INFO - 2023-04-20 07:54:49 --> URI Class Initialized
INFO - 2023-04-20 07:54:49 --> Router Class Initialized
INFO - 2023-04-20 07:54:49 --> Output Class Initialized
INFO - 2023-04-20 07:54:49 --> Security Class Initialized
DEBUG - 2023-04-20 07:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 07:54:49 --> Input Class Initialized
INFO - 2023-04-20 07:54:49 --> Language Class Initialized
INFO - 2023-04-20 07:54:49 --> Loader Class Initialized
INFO - 2023-04-20 07:54:49 --> Helper loaded: url_helper
INFO - 2023-04-20 07:54:49 --> Helper loaded: file_helper
INFO - 2023-04-20 07:54:49 --> Helper loaded: html_helper
INFO - 2023-04-20 07:54:49 --> Helper loaded: text_helper
INFO - 2023-04-20 07:54:49 --> Helper loaded: form_helper
INFO - 2023-04-20 07:54:49 --> Helper loaded: lang_helper
INFO - 2023-04-20 07:54:49 --> Helper loaded: security_helper
INFO - 2023-04-20 07:54:49 --> Helper loaded: cookie_helper
INFO - 2023-04-20 07:54:49 --> Database Driver Class Initialized
INFO - 2023-04-20 07:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 07:54:49 --> Parser Class Initialized
INFO - 2023-04-20 07:54:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 07:54:49 --> Pagination Class Initialized
INFO - 2023-04-20 07:54:49 --> Form Validation Class Initialized
INFO - 2023-04-20 07:54:49 --> Controller Class Initialized
INFO - 2023-04-20 07:54:49 --> Model Class Initialized
DEBUG - 2023-04-20 07:54:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 07:54:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-20 07:54:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 07:54:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 07:54:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 07:54:49 --> Model Class Initialized
INFO - 2023-04-20 07:54:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 07:54:49 --> Final output sent to browser
DEBUG - 2023-04-20 07:54:49 --> Total execution time: 0.0344
ERROR - 2023-04-20 07:55:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 07:55:04 --> Config Class Initialized
INFO - 2023-04-20 07:55:04 --> Hooks Class Initialized
DEBUG - 2023-04-20 07:55:04 --> UTF-8 Support Enabled
INFO - 2023-04-20 07:55:04 --> Utf8 Class Initialized
INFO - 2023-04-20 07:55:04 --> URI Class Initialized
INFO - 2023-04-20 07:55:04 --> Router Class Initialized
INFO - 2023-04-20 07:55:04 --> Output Class Initialized
INFO - 2023-04-20 07:55:04 --> Security Class Initialized
DEBUG - 2023-04-20 07:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 07:55:04 --> Input Class Initialized
INFO - 2023-04-20 07:55:04 --> Language Class Initialized
INFO - 2023-04-20 07:55:04 --> Loader Class Initialized
INFO - 2023-04-20 07:55:04 --> Helper loaded: url_helper
INFO - 2023-04-20 07:55:04 --> Helper loaded: file_helper
INFO - 2023-04-20 07:55:04 --> Helper loaded: html_helper
INFO - 2023-04-20 07:55:04 --> Helper loaded: text_helper
INFO - 2023-04-20 07:55:04 --> Helper loaded: form_helper
INFO - 2023-04-20 07:55:04 --> Helper loaded: lang_helper
INFO - 2023-04-20 07:55:04 --> Helper loaded: security_helper
INFO - 2023-04-20 07:55:04 --> Helper loaded: cookie_helper
INFO - 2023-04-20 07:55:04 --> Database Driver Class Initialized
INFO - 2023-04-20 07:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 07:55:04 --> Parser Class Initialized
INFO - 2023-04-20 07:55:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 07:55:04 --> Pagination Class Initialized
INFO - 2023-04-20 07:55:04 --> Form Validation Class Initialized
INFO - 2023-04-20 07:55:04 --> Controller Class Initialized
INFO - 2023-04-20 07:55:04 --> Model Class Initialized
DEBUG - 2023-04-20 07:55:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 07:55:04 --> Model Class Initialized
INFO - 2023-04-20 07:55:04 --> Final output sent to browser
DEBUG - 2023-04-20 07:55:04 --> Total execution time: 0.0191
ERROR - 2023-04-20 07:55:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 07:55:04 --> Config Class Initialized
INFO - 2023-04-20 07:55:04 --> Hooks Class Initialized
DEBUG - 2023-04-20 07:55:04 --> UTF-8 Support Enabled
INFO - 2023-04-20 07:55:04 --> Utf8 Class Initialized
INFO - 2023-04-20 07:55:04 --> URI Class Initialized
DEBUG - 2023-04-20 07:55:04 --> No URI present. Default controller set.
INFO - 2023-04-20 07:55:04 --> Router Class Initialized
INFO - 2023-04-20 07:55:04 --> Output Class Initialized
INFO - 2023-04-20 07:55:04 --> Security Class Initialized
DEBUG - 2023-04-20 07:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 07:55:04 --> Input Class Initialized
INFO - 2023-04-20 07:55:04 --> Language Class Initialized
INFO - 2023-04-20 07:55:04 --> Loader Class Initialized
INFO - 2023-04-20 07:55:04 --> Helper loaded: url_helper
INFO - 2023-04-20 07:55:04 --> Helper loaded: file_helper
INFO - 2023-04-20 07:55:04 --> Helper loaded: html_helper
INFO - 2023-04-20 07:55:04 --> Helper loaded: text_helper
INFO - 2023-04-20 07:55:04 --> Helper loaded: form_helper
INFO - 2023-04-20 07:55:04 --> Helper loaded: lang_helper
INFO - 2023-04-20 07:55:04 --> Helper loaded: security_helper
INFO - 2023-04-20 07:55:04 --> Helper loaded: cookie_helper
INFO - 2023-04-20 07:55:04 --> Database Driver Class Initialized
INFO - 2023-04-20 07:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 07:55:04 --> Parser Class Initialized
INFO - 2023-04-20 07:55:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 07:55:04 --> Pagination Class Initialized
INFO - 2023-04-20 07:55:04 --> Form Validation Class Initialized
INFO - 2023-04-20 07:55:04 --> Controller Class Initialized
INFO - 2023-04-20 07:55:04 --> Model Class Initialized
DEBUG - 2023-04-20 07:55:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 07:55:04 --> Model Class Initialized
DEBUG - 2023-04-20 07:55:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 07:55:04 --> Model Class Initialized
INFO - 2023-04-20 07:55:04 --> Model Class Initialized
INFO - 2023-04-20 07:55:04 --> Model Class Initialized
INFO - 2023-04-20 07:55:04 --> Model Class Initialized
DEBUG - 2023-04-20 07:55:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 07:55:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 07:55:04 --> Model Class Initialized
INFO - 2023-04-20 07:55:04 --> Model Class Initialized
INFO - 2023-04-20 07:55:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-20 07:55:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 07:55:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 07:55:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 07:55:04 --> Model Class Initialized
INFO - 2023-04-20 07:55:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 07:55:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 07:55:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 07:55:04 --> Final output sent to browser
DEBUG - 2023-04-20 07:55:04 --> Total execution time: 0.1867
ERROR - 2023-04-20 07:55:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 07:55:05 --> Config Class Initialized
INFO - 2023-04-20 07:55:05 --> Hooks Class Initialized
DEBUG - 2023-04-20 07:55:05 --> UTF-8 Support Enabled
INFO - 2023-04-20 07:55:05 --> Utf8 Class Initialized
INFO - 2023-04-20 07:55:05 --> URI Class Initialized
INFO - 2023-04-20 07:55:05 --> Router Class Initialized
INFO - 2023-04-20 07:55:05 --> Output Class Initialized
INFO - 2023-04-20 07:55:05 --> Security Class Initialized
DEBUG - 2023-04-20 07:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 07:55:05 --> Input Class Initialized
INFO - 2023-04-20 07:55:05 --> Language Class Initialized
INFO - 2023-04-20 07:55:05 --> Loader Class Initialized
INFO - 2023-04-20 07:55:05 --> Helper loaded: url_helper
INFO - 2023-04-20 07:55:05 --> Helper loaded: file_helper
INFO - 2023-04-20 07:55:05 --> Helper loaded: html_helper
INFO - 2023-04-20 07:55:05 --> Helper loaded: text_helper
INFO - 2023-04-20 07:55:05 --> Helper loaded: form_helper
INFO - 2023-04-20 07:55:05 --> Helper loaded: lang_helper
INFO - 2023-04-20 07:55:05 --> Helper loaded: security_helper
INFO - 2023-04-20 07:55:05 --> Helper loaded: cookie_helper
INFO - 2023-04-20 07:55:05 --> Database Driver Class Initialized
INFO - 2023-04-20 07:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 07:55:05 --> Parser Class Initialized
INFO - 2023-04-20 07:55:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 07:55:05 --> Pagination Class Initialized
INFO - 2023-04-20 07:55:05 --> Form Validation Class Initialized
INFO - 2023-04-20 07:55:05 --> Controller Class Initialized
DEBUG - 2023-04-20 07:55:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 07:55:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 07:55:05 --> Model Class Initialized
INFO - 2023-04-20 07:55:05 --> Final output sent to browser
DEBUG - 2023-04-20 07:55:05 --> Total execution time: 0.0138
ERROR - 2023-04-20 07:55:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 07:55:20 --> Config Class Initialized
INFO - 2023-04-20 07:55:20 --> Hooks Class Initialized
DEBUG - 2023-04-20 07:55:20 --> UTF-8 Support Enabled
INFO - 2023-04-20 07:55:20 --> Utf8 Class Initialized
INFO - 2023-04-20 07:55:20 --> URI Class Initialized
INFO - 2023-04-20 07:55:20 --> Router Class Initialized
INFO - 2023-04-20 07:55:20 --> Output Class Initialized
INFO - 2023-04-20 07:55:20 --> Security Class Initialized
DEBUG - 2023-04-20 07:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 07:55:20 --> Input Class Initialized
INFO - 2023-04-20 07:55:20 --> Language Class Initialized
INFO - 2023-04-20 07:55:20 --> Loader Class Initialized
INFO - 2023-04-20 07:55:20 --> Helper loaded: url_helper
INFO - 2023-04-20 07:55:20 --> Helper loaded: file_helper
INFO - 2023-04-20 07:55:20 --> Helper loaded: html_helper
INFO - 2023-04-20 07:55:20 --> Helper loaded: text_helper
INFO - 2023-04-20 07:55:20 --> Helper loaded: form_helper
INFO - 2023-04-20 07:55:20 --> Helper loaded: lang_helper
INFO - 2023-04-20 07:55:20 --> Helper loaded: security_helper
INFO - 2023-04-20 07:55:20 --> Helper loaded: cookie_helper
INFO - 2023-04-20 07:55:20 --> Database Driver Class Initialized
INFO - 2023-04-20 07:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 07:55:20 --> Parser Class Initialized
INFO - 2023-04-20 07:55:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 07:55:20 --> Pagination Class Initialized
INFO - 2023-04-20 07:55:20 --> Form Validation Class Initialized
INFO - 2023-04-20 07:55:20 --> Controller Class Initialized
INFO - 2023-04-20 07:55:20 --> Model Class Initialized
DEBUG - 2023-04-20 07:55:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 07:55:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 07:55:20 --> Model Class Initialized
DEBUG - 2023-04-20 07:55:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 07:55:20 --> Model Class Initialized
INFO - 2023-04-20 07:55:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-04-20 07:55:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 07:55:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 07:55:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 07:55:20 --> Model Class Initialized
INFO - 2023-04-20 07:55:20 --> Model Class Initialized
INFO - 2023-04-20 07:55:20 --> Model Class Initialized
INFO - 2023-04-20 07:55:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 07:55:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 07:55:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 07:55:20 --> Final output sent to browser
DEBUG - 2023-04-20 07:55:20 --> Total execution time: 0.1468
ERROR - 2023-04-20 07:55:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 07:55:21 --> Config Class Initialized
INFO - 2023-04-20 07:55:21 --> Hooks Class Initialized
DEBUG - 2023-04-20 07:55:21 --> UTF-8 Support Enabled
INFO - 2023-04-20 07:55:21 --> Utf8 Class Initialized
INFO - 2023-04-20 07:55:21 --> URI Class Initialized
INFO - 2023-04-20 07:55:21 --> Router Class Initialized
INFO - 2023-04-20 07:55:21 --> Output Class Initialized
INFO - 2023-04-20 07:55:21 --> Security Class Initialized
DEBUG - 2023-04-20 07:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 07:55:21 --> Input Class Initialized
INFO - 2023-04-20 07:55:21 --> Language Class Initialized
INFO - 2023-04-20 07:55:21 --> Loader Class Initialized
INFO - 2023-04-20 07:55:21 --> Helper loaded: url_helper
INFO - 2023-04-20 07:55:21 --> Helper loaded: file_helper
INFO - 2023-04-20 07:55:21 --> Helper loaded: html_helper
INFO - 2023-04-20 07:55:21 --> Helper loaded: text_helper
INFO - 2023-04-20 07:55:21 --> Helper loaded: form_helper
INFO - 2023-04-20 07:55:21 --> Helper loaded: lang_helper
INFO - 2023-04-20 07:55:21 --> Helper loaded: security_helper
INFO - 2023-04-20 07:55:21 --> Helper loaded: cookie_helper
INFO - 2023-04-20 07:55:21 --> Database Driver Class Initialized
INFO - 2023-04-20 07:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 07:55:21 --> Parser Class Initialized
INFO - 2023-04-20 07:55:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 07:55:21 --> Pagination Class Initialized
INFO - 2023-04-20 07:55:21 --> Form Validation Class Initialized
INFO - 2023-04-20 07:55:21 --> Controller Class Initialized
INFO - 2023-04-20 07:55:21 --> Model Class Initialized
DEBUG - 2023-04-20 07:55:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 07:55:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 07:55:21 --> Model Class Initialized
DEBUG - 2023-04-20 07:55:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 07:55:21 --> Model Class Initialized
INFO - 2023-04-20 07:55:21 --> Final output sent to browser
DEBUG - 2023-04-20 07:55:21 --> Total execution time: 0.0665
ERROR - 2023-04-20 07:55:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 07:55:26 --> Config Class Initialized
INFO - 2023-04-20 07:55:26 --> Hooks Class Initialized
DEBUG - 2023-04-20 07:55:26 --> UTF-8 Support Enabled
INFO - 2023-04-20 07:55:26 --> Utf8 Class Initialized
INFO - 2023-04-20 07:55:26 --> URI Class Initialized
INFO - 2023-04-20 07:55:26 --> Router Class Initialized
INFO - 2023-04-20 07:55:26 --> Output Class Initialized
INFO - 2023-04-20 07:55:26 --> Security Class Initialized
DEBUG - 2023-04-20 07:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 07:55:26 --> Input Class Initialized
INFO - 2023-04-20 07:55:26 --> Language Class Initialized
INFO - 2023-04-20 07:55:26 --> Loader Class Initialized
INFO - 2023-04-20 07:55:26 --> Helper loaded: url_helper
INFO - 2023-04-20 07:55:26 --> Helper loaded: file_helper
INFO - 2023-04-20 07:55:26 --> Helper loaded: html_helper
INFO - 2023-04-20 07:55:26 --> Helper loaded: text_helper
INFO - 2023-04-20 07:55:26 --> Helper loaded: form_helper
INFO - 2023-04-20 07:55:26 --> Helper loaded: lang_helper
INFO - 2023-04-20 07:55:26 --> Helper loaded: security_helper
INFO - 2023-04-20 07:55:26 --> Helper loaded: cookie_helper
INFO - 2023-04-20 07:55:26 --> Database Driver Class Initialized
INFO - 2023-04-20 07:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 07:55:26 --> Parser Class Initialized
INFO - 2023-04-20 07:55:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 07:55:26 --> Pagination Class Initialized
INFO - 2023-04-20 07:55:26 --> Form Validation Class Initialized
INFO - 2023-04-20 07:55:26 --> Controller Class Initialized
INFO - 2023-04-20 07:55:26 --> Model Class Initialized
DEBUG - 2023-04-20 07:55:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 07:55:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 07:55:26 --> Model Class Initialized
DEBUG - 2023-04-20 07:55:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 07:55:26 --> Model Class Initialized
INFO - 2023-04-20 07:55:26 --> Final output sent to browser
DEBUG - 2023-04-20 07:55:26 --> Total execution time: 0.0723
ERROR - 2023-04-20 09:35:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:35:31 --> Config Class Initialized
INFO - 2023-04-20 09:35:31 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:35:31 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:35:31 --> Utf8 Class Initialized
INFO - 2023-04-20 09:35:31 --> URI Class Initialized
DEBUG - 2023-04-20 09:35:31 --> No URI present. Default controller set.
INFO - 2023-04-20 09:35:31 --> Router Class Initialized
INFO - 2023-04-20 09:35:31 --> Output Class Initialized
INFO - 2023-04-20 09:35:31 --> Security Class Initialized
DEBUG - 2023-04-20 09:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:35:31 --> Input Class Initialized
INFO - 2023-04-20 09:35:31 --> Language Class Initialized
INFO - 2023-04-20 09:35:31 --> Loader Class Initialized
INFO - 2023-04-20 09:35:31 --> Helper loaded: url_helper
INFO - 2023-04-20 09:35:31 --> Helper loaded: file_helper
INFO - 2023-04-20 09:35:31 --> Helper loaded: html_helper
INFO - 2023-04-20 09:35:31 --> Helper loaded: text_helper
INFO - 2023-04-20 09:35:31 --> Helper loaded: form_helper
INFO - 2023-04-20 09:35:31 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:35:31 --> Helper loaded: security_helper
INFO - 2023-04-20 09:35:31 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:35:31 --> Database Driver Class Initialized
INFO - 2023-04-20 09:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:35:31 --> Parser Class Initialized
INFO - 2023-04-20 09:35:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:35:31 --> Pagination Class Initialized
INFO - 2023-04-20 09:35:31 --> Form Validation Class Initialized
INFO - 2023-04-20 09:35:31 --> Controller Class Initialized
INFO - 2023-04-20 09:35:31 --> Model Class Initialized
DEBUG - 2023-04-20 09:35:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:35:31 --> Model Class Initialized
DEBUG - 2023-04-20 09:35:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:35:31 --> Model Class Initialized
INFO - 2023-04-20 09:35:31 --> Model Class Initialized
INFO - 2023-04-20 09:35:31 --> Model Class Initialized
INFO - 2023-04-20 09:35:31 --> Model Class Initialized
DEBUG - 2023-04-20 09:35:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:35:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:35:31 --> Model Class Initialized
INFO - 2023-04-20 09:35:31 --> Model Class Initialized
INFO - 2023-04-20 09:35:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-20 09:35:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:35:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 09:35:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 09:35:31 --> Model Class Initialized
INFO - 2023-04-20 09:35:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 09:35:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 09:35:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 09:35:31 --> Final output sent to browser
DEBUG - 2023-04-20 09:35:31 --> Total execution time: 0.2177
ERROR - 2023-04-20 09:37:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:37:11 --> Config Class Initialized
INFO - 2023-04-20 09:37:11 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:37:11 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:37:11 --> Utf8 Class Initialized
INFO - 2023-04-20 09:37:11 --> URI Class Initialized
INFO - 2023-04-20 09:37:11 --> Router Class Initialized
INFO - 2023-04-20 09:37:11 --> Output Class Initialized
INFO - 2023-04-20 09:37:11 --> Security Class Initialized
DEBUG - 2023-04-20 09:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:37:11 --> Input Class Initialized
INFO - 2023-04-20 09:37:11 --> Language Class Initialized
INFO - 2023-04-20 09:37:11 --> Loader Class Initialized
INFO - 2023-04-20 09:37:11 --> Helper loaded: url_helper
INFO - 2023-04-20 09:37:11 --> Helper loaded: file_helper
INFO - 2023-04-20 09:37:11 --> Helper loaded: html_helper
INFO - 2023-04-20 09:37:11 --> Helper loaded: text_helper
INFO - 2023-04-20 09:37:11 --> Helper loaded: form_helper
INFO - 2023-04-20 09:37:11 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:37:11 --> Helper loaded: security_helper
INFO - 2023-04-20 09:37:11 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:37:11 --> Database Driver Class Initialized
INFO - 2023-04-20 09:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:37:11 --> Parser Class Initialized
INFO - 2023-04-20 09:37:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:37:11 --> Pagination Class Initialized
INFO - 2023-04-20 09:37:11 --> Form Validation Class Initialized
INFO - 2023-04-20 09:37:11 --> Controller Class Initialized
INFO - 2023-04-20 09:37:11 --> Model Class Initialized
DEBUG - 2023-04-20 09:37:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:37:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:37:11 --> Model Class Initialized
DEBUG - 2023-04-20 09:37:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:37:11 --> Model Class Initialized
INFO - 2023-04-20 09:37:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-04-20 09:37:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:37:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 09:37:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 09:37:11 --> Model Class Initialized
INFO - 2023-04-20 09:37:11 --> Model Class Initialized
INFO - 2023-04-20 09:37:11 --> Model Class Initialized
INFO - 2023-04-20 09:37:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 09:37:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 09:37:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 09:37:11 --> Final output sent to browser
DEBUG - 2023-04-20 09:37:11 --> Total execution time: 0.1568
ERROR - 2023-04-20 09:37:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:37:12 --> Config Class Initialized
INFO - 2023-04-20 09:37:12 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:37:12 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:37:12 --> Utf8 Class Initialized
INFO - 2023-04-20 09:37:12 --> URI Class Initialized
INFO - 2023-04-20 09:37:12 --> Router Class Initialized
INFO - 2023-04-20 09:37:12 --> Output Class Initialized
INFO - 2023-04-20 09:37:12 --> Security Class Initialized
DEBUG - 2023-04-20 09:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:37:12 --> Input Class Initialized
INFO - 2023-04-20 09:37:12 --> Language Class Initialized
INFO - 2023-04-20 09:37:12 --> Loader Class Initialized
INFO - 2023-04-20 09:37:12 --> Helper loaded: url_helper
INFO - 2023-04-20 09:37:12 --> Helper loaded: file_helper
INFO - 2023-04-20 09:37:12 --> Helper loaded: html_helper
INFO - 2023-04-20 09:37:12 --> Helper loaded: text_helper
INFO - 2023-04-20 09:37:12 --> Helper loaded: form_helper
INFO - 2023-04-20 09:37:12 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:37:12 --> Helper loaded: security_helper
INFO - 2023-04-20 09:37:12 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:37:12 --> Database Driver Class Initialized
INFO - 2023-04-20 09:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:37:12 --> Parser Class Initialized
INFO - 2023-04-20 09:37:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:37:12 --> Pagination Class Initialized
INFO - 2023-04-20 09:37:12 --> Form Validation Class Initialized
INFO - 2023-04-20 09:37:12 --> Controller Class Initialized
INFO - 2023-04-20 09:37:12 --> Model Class Initialized
DEBUG - 2023-04-20 09:37:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:37:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:37:12 --> Model Class Initialized
DEBUG - 2023-04-20 09:37:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:37:12 --> Model Class Initialized
INFO - 2023-04-20 09:37:12 --> Final output sent to browser
DEBUG - 2023-04-20 09:37:12 --> Total execution time: 0.0562
ERROR - 2023-04-20 09:37:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:37:16 --> Config Class Initialized
INFO - 2023-04-20 09:37:16 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:37:16 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:37:16 --> Utf8 Class Initialized
INFO - 2023-04-20 09:37:16 --> URI Class Initialized
INFO - 2023-04-20 09:37:16 --> Router Class Initialized
INFO - 2023-04-20 09:37:16 --> Output Class Initialized
INFO - 2023-04-20 09:37:16 --> Security Class Initialized
DEBUG - 2023-04-20 09:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:37:16 --> Input Class Initialized
INFO - 2023-04-20 09:37:16 --> Language Class Initialized
INFO - 2023-04-20 09:37:16 --> Loader Class Initialized
INFO - 2023-04-20 09:37:16 --> Helper loaded: url_helper
INFO - 2023-04-20 09:37:16 --> Helper loaded: file_helper
INFO - 2023-04-20 09:37:16 --> Helper loaded: html_helper
INFO - 2023-04-20 09:37:16 --> Helper loaded: text_helper
INFO - 2023-04-20 09:37:16 --> Helper loaded: form_helper
INFO - 2023-04-20 09:37:16 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:37:16 --> Helper loaded: security_helper
INFO - 2023-04-20 09:37:16 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:37:16 --> Database Driver Class Initialized
INFO - 2023-04-20 09:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:37:16 --> Parser Class Initialized
INFO - 2023-04-20 09:37:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:37:16 --> Pagination Class Initialized
INFO - 2023-04-20 09:37:16 --> Form Validation Class Initialized
INFO - 2023-04-20 09:37:16 --> Controller Class Initialized
INFO - 2023-04-20 09:37:16 --> Model Class Initialized
DEBUG - 2023-04-20 09:37:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:37:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:37:16 --> Model Class Initialized
DEBUG - 2023-04-20 09:37:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:37:16 --> Model Class Initialized
INFO - 2023-04-20 09:37:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-04-20 09:37:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:37:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 09:37:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 09:37:16 --> Model Class Initialized
INFO - 2023-04-20 09:37:16 --> Model Class Initialized
INFO - 2023-04-20 09:37:16 --> Model Class Initialized
INFO - 2023-04-20 09:37:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 09:37:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 09:37:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 09:37:16 --> Final output sent to browser
DEBUG - 2023-04-20 09:37:16 --> Total execution time: 0.1565
ERROR - 2023-04-20 09:37:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:37:17 --> Config Class Initialized
INFO - 2023-04-20 09:37:17 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:37:17 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:37:17 --> Utf8 Class Initialized
INFO - 2023-04-20 09:37:17 --> URI Class Initialized
INFO - 2023-04-20 09:37:17 --> Router Class Initialized
INFO - 2023-04-20 09:37:17 --> Output Class Initialized
INFO - 2023-04-20 09:37:17 --> Security Class Initialized
DEBUG - 2023-04-20 09:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:37:17 --> Input Class Initialized
INFO - 2023-04-20 09:37:17 --> Language Class Initialized
INFO - 2023-04-20 09:37:17 --> Loader Class Initialized
INFO - 2023-04-20 09:37:17 --> Helper loaded: url_helper
INFO - 2023-04-20 09:37:17 --> Helper loaded: file_helper
INFO - 2023-04-20 09:37:17 --> Helper loaded: html_helper
INFO - 2023-04-20 09:37:17 --> Helper loaded: text_helper
INFO - 2023-04-20 09:37:17 --> Helper loaded: form_helper
INFO - 2023-04-20 09:37:17 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:37:17 --> Helper loaded: security_helper
INFO - 2023-04-20 09:37:17 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:37:17 --> Database Driver Class Initialized
INFO - 2023-04-20 09:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:37:17 --> Parser Class Initialized
INFO - 2023-04-20 09:37:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:37:17 --> Pagination Class Initialized
INFO - 2023-04-20 09:37:17 --> Form Validation Class Initialized
INFO - 2023-04-20 09:37:17 --> Controller Class Initialized
INFO - 2023-04-20 09:37:17 --> Model Class Initialized
DEBUG - 2023-04-20 09:37:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:37:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:37:17 --> Model Class Initialized
DEBUG - 2023-04-20 09:37:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:37:17 --> Model Class Initialized
INFO - 2023-04-20 09:37:17 --> Final output sent to browser
DEBUG - 2023-04-20 09:37:17 --> Total execution time: 0.0610
ERROR - 2023-04-20 09:37:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:37:23 --> Config Class Initialized
INFO - 2023-04-20 09:37:23 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:37:23 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:37:23 --> Utf8 Class Initialized
INFO - 2023-04-20 09:37:23 --> URI Class Initialized
INFO - 2023-04-20 09:37:23 --> Router Class Initialized
INFO - 2023-04-20 09:37:23 --> Output Class Initialized
INFO - 2023-04-20 09:37:23 --> Security Class Initialized
DEBUG - 2023-04-20 09:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:37:23 --> Input Class Initialized
INFO - 2023-04-20 09:37:23 --> Language Class Initialized
INFO - 2023-04-20 09:37:23 --> Loader Class Initialized
INFO - 2023-04-20 09:37:23 --> Helper loaded: url_helper
INFO - 2023-04-20 09:37:23 --> Helper loaded: file_helper
INFO - 2023-04-20 09:37:23 --> Helper loaded: html_helper
INFO - 2023-04-20 09:37:23 --> Helper loaded: text_helper
INFO - 2023-04-20 09:37:23 --> Helper loaded: form_helper
INFO - 2023-04-20 09:37:23 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:37:23 --> Helper loaded: security_helper
INFO - 2023-04-20 09:37:23 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:37:23 --> Database Driver Class Initialized
INFO - 2023-04-20 09:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:37:23 --> Parser Class Initialized
INFO - 2023-04-20 09:37:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:37:23 --> Pagination Class Initialized
INFO - 2023-04-20 09:37:23 --> Form Validation Class Initialized
INFO - 2023-04-20 09:37:23 --> Controller Class Initialized
INFO - 2023-04-20 09:37:23 --> Model Class Initialized
DEBUG - 2023-04-20 09:37:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:37:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:37:23 --> Model Class Initialized
DEBUG - 2023-04-20 09:37:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:37:23 --> Model Class Initialized
INFO - 2023-04-20 09:37:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-04-20 09:37:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:37:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 09:37:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 09:37:23 --> Model Class Initialized
INFO - 2023-04-20 09:37:23 --> Model Class Initialized
INFO - 2023-04-20 09:37:23 --> Model Class Initialized
INFO - 2023-04-20 09:37:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 09:37:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 09:37:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 09:37:24 --> Final output sent to browser
DEBUG - 2023-04-20 09:37:24 --> Total execution time: 0.1473
ERROR - 2023-04-20 09:37:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:37:24 --> Config Class Initialized
INFO - 2023-04-20 09:37:24 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:37:24 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:37:24 --> Utf8 Class Initialized
INFO - 2023-04-20 09:37:24 --> URI Class Initialized
INFO - 2023-04-20 09:37:24 --> Router Class Initialized
INFO - 2023-04-20 09:37:24 --> Output Class Initialized
INFO - 2023-04-20 09:37:24 --> Security Class Initialized
DEBUG - 2023-04-20 09:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:37:24 --> Input Class Initialized
INFO - 2023-04-20 09:37:24 --> Language Class Initialized
INFO - 2023-04-20 09:37:24 --> Loader Class Initialized
INFO - 2023-04-20 09:37:24 --> Helper loaded: url_helper
INFO - 2023-04-20 09:37:24 --> Helper loaded: file_helper
INFO - 2023-04-20 09:37:24 --> Helper loaded: html_helper
INFO - 2023-04-20 09:37:24 --> Helper loaded: text_helper
INFO - 2023-04-20 09:37:24 --> Helper loaded: form_helper
INFO - 2023-04-20 09:37:24 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:37:24 --> Helper loaded: security_helper
INFO - 2023-04-20 09:37:24 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:37:24 --> Database Driver Class Initialized
INFO - 2023-04-20 09:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:37:24 --> Parser Class Initialized
INFO - 2023-04-20 09:37:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:37:24 --> Pagination Class Initialized
INFO - 2023-04-20 09:37:24 --> Form Validation Class Initialized
INFO - 2023-04-20 09:37:24 --> Controller Class Initialized
INFO - 2023-04-20 09:37:24 --> Model Class Initialized
DEBUG - 2023-04-20 09:37:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:37:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:37:24 --> Model Class Initialized
DEBUG - 2023-04-20 09:37:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:37:24 --> Model Class Initialized
INFO - 2023-04-20 09:37:24 --> Final output sent to browser
DEBUG - 2023-04-20 09:37:24 --> Total execution time: 0.0591
ERROR - 2023-04-20 09:37:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:37:29 --> Config Class Initialized
INFO - 2023-04-20 09:37:29 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:37:29 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:37:29 --> Utf8 Class Initialized
INFO - 2023-04-20 09:37:29 --> URI Class Initialized
INFO - 2023-04-20 09:37:29 --> Router Class Initialized
INFO - 2023-04-20 09:37:29 --> Output Class Initialized
INFO - 2023-04-20 09:37:29 --> Security Class Initialized
DEBUG - 2023-04-20 09:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:37:29 --> Input Class Initialized
INFO - 2023-04-20 09:37:29 --> Language Class Initialized
INFO - 2023-04-20 09:37:29 --> Loader Class Initialized
INFO - 2023-04-20 09:37:29 --> Helper loaded: url_helper
INFO - 2023-04-20 09:37:29 --> Helper loaded: file_helper
INFO - 2023-04-20 09:37:29 --> Helper loaded: html_helper
INFO - 2023-04-20 09:37:29 --> Helper loaded: text_helper
INFO - 2023-04-20 09:37:29 --> Helper loaded: form_helper
INFO - 2023-04-20 09:37:29 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:37:29 --> Helper loaded: security_helper
INFO - 2023-04-20 09:37:29 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:37:29 --> Database Driver Class Initialized
INFO - 2023-04-20 09:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:37:29 --> Parser Class Initialized
INFO - 2023-04-20 09:37:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:37:29 --> Pagination Class Initialized
INFO - 2023-04-20 09:37:29 --> Form Validation Class Initialized
INFO - 2023-04-20 09:37:29 --> Controller Class Initialized
INFO - 2023-04-20 09:37:29 --> Model Class Initialized
DEBUG - 2023-04-20 09:37:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:37:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:37:29 --> Model Class Initialized
DEBUG - 2023-04-20 09:37:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:37:29 --> Model Class Initialized
INFO - 2023-04-20 09:37:29 --> Final output sent to browser
DEBUG - 2023-04-20 09:37:29 --> Total execution time: 0.0689
ERROR - 2023-04-20 09:37:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:37:45 --> Config Class Initialized
INFO - 2023-04-20 09:37:45 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:37:45 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:37:45 --> Utf8 Class Initialized
INFO - 2023-04-20 09:37:45 --> URI Class Initialized
INFO - 2023-04-20 09:37:45 --> Router Class Initialized
INFO - 2023-04-20 09:37:45 --> Output Class Initialized
INFO - 2023-04-20 09:37:45 --> Security Class Initialized
DEBUG - 2023-04-20 09:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:37:45 --> Input Class Initialized
INFO - 2023-04-20 09:37:45 --> Language Class Initialized
INFO - 2023-04-20 09:37:45 --> Loader Class Initialized
INFO - 2023-04-20 09:37:45 --> Helper loaded: url_helper
INFO - 2023-04-20 09:37:45 --> Helper loaded: file_helper
INFO - 2023-04-20 09:37:45 --> Helper loaded: html_helper
INFO - 2023-04-20 09:37:45 --> Helper loaded: text_helper
INFO - 2023-04-20 09:37:45 --> Helper loaded: form_helper
INFO - 2023-04-20 09:37:45 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:37:45 --> Helper loaded: security_helper
INFO - 2023-04-20 09:37:45 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:37:45 --> Database Driver Class Initialized
INFO - 2023-04-20 09:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:37:45 --> Parser Class Initialized
INFO - 2023-04-20 09:37:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:37:45 --> Pagination Class Initialized
INFO - 2023-04-20 09:37:45 --> Form Validation Class Initialized
INFO - 2023-04-20 09:37:45 --> Controller Class Initialized
INFO - 2023-04-20 09:37:45 --> Model Class Initialized
DEBUG - 2023-04-20 09:37:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:37:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:37:45 --> Model Class Initialized
DEBUG - 2023-04-20 09:37:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:37:45 --> Model Class Initialized
INFO - 2023-04-20 09:37:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-04-20 09:37:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:37:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 09:37:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 09:37:45 --> Model Class Initialized
INFO - 2023-04-20 09:37:45 --> Model Class Initialized
INFO - 2023-04-20 09:37:45 --> Model Class Initialized
INFO - 2023-04-20 09:37:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 09:37:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 09:37:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 09:37:45 --> Final output sent to browser
DEBUG - 2023-04-20 09:37:45 --> Total execution time: 0.1606
ERROR - 2023-04-20 09:37:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:37:46 --> Config Class Initialized
INFO - 2023-04-20 09:37:46 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:37:46 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:37:46 --> Utf8 Class Initialized
INFO - 2023-04-20 09:37:46 --> URI Class Initialized
INFO - 2023-04-20 09:37:46 --> Router Class Initialized
INFO - 2023-04-20 09:37:46 --> Output Class Initialized
INFO - 2023-04-20 09:37:46 --> Security Class Initialized
DEBUG - 2023-04-20 09:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:37:46 --> Input Class Initialized
INFO - 2023-04-20 09:37:46 --> Language Class Initialized
INFO - 2023-04-20 09:37:46 --> Loader Class Initialized
INFO - 2023-04-20 09:37:46 --> Helper loaded: url_helper
INFO - 2023-04-20 09:37:46 --> Helper loaded: file_helper
INFO - 2023-04-20 09:37:46 --> Helper loaded: html_helper
INFO - 2023-04-20 09:37:46 --> Helper loaded: text_helper
INFO - 2023-04-20 09:37:46 --> Helper loaded: form_helper
INFO - 2023-04-20 09:37:46 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:37:46 --> Helper loaded: security_helper
INFO - 2023-04-20 09:37:46 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:37:46 --> Database Driver Class Initialized
INFO - 2023-04-20 09:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:37:46 --> Parser Class Initialized
INFO - 2023-04-20 09:37:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:37:46 --> Pagination Class Initialized
INFO - 2023-04-20 09:37:46 --> Form Validation Class Initialized
INFO - 2023-04-20 09:37:46 --> Controller Class Initialized
INFO - 2023-04-20 09:37:46 --> Model Class Initialized
DEBUG - 2023-04-20 09:37:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:37:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:37:46 --> Model Class Initialized
DEBUG - 2023-04-20 09:37:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:37:46 --> Model Class Initialized
INFO - 2023-04-20 09:37:46 --> Final output sent to browser
DEBUG - 2023-04-20 09:37:46 --> Total execution time: 0.0619
ERROR - 2023-04-20 09:37:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:37:52 --> Config Class Initialized
INFO - 2023-04-20 09:37:52 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:37:52 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:37:52 --> Utf8 Class Initialized
INFO - 2023-04-20 09:37:52 --> URI Class Initialized
INFO - 2023-04-20 09:37:52 --> Router Class Initialized
INFO - 2023-04-20 09:37:52 --> Output Class Initialized
INFO - 2023-04-20 09:37:52 --> Security Class Initialized
DEBUG - 2023-04-20 09:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:37:52 --> Input Class Initialized
INFO - 2023-04-20 09:37:52 --> Language Class Initialized
INFO - 2023-04-20 09:37:52 --> Loader Class Initialized
INFO - 2023-04-20 09:37:52 --> Helper loaded: url_helper
INFO - 2023-04-20 09:37:52 --> Helper loaded: file_helper
INFO - 2023-04-20 09:37:52 --> Helper loaded: html_helper
INFO - 2023-04-20 09:37:52 --> Helper loaded: text_helper
INFO - 2023-04-20 09:37:52 --> Helper loaded: form_helper
INFO - 2023-04-20 09:37:52 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:37:52 --> Helper loaded: security_helper
INFO - 2023-04-20 09:37:52 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:37:52 --> Database Driver Class Initialized
INFO - 2023-04-20 09:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:37:52 --> Parser Class Initialized
INFO - 2023-04-20 09:37:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:37:52 --> Pagination Class Initialized
INFO - 2023-04-20 09:37:52 --> Form Validation Class Initialized
INFO - 2023-04-20 09:37:52 --> Controller Class Initialized
INFO - 2023-04-20 09:37:52 --> Model Class Initialized
DEBUG - 2023-04-20 09:37:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:37:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:37:52 --> Model Class Initialized
DEBUG - 2023-04-20 09:37:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:37:52 --> Model Class Initialized
INFO - 2023-04-20 09:37:52 --> Final output sent to browser
DEBUG - 2023-04-20 09:37:52 --> Total execution time: 0.0709
ERROR - 2023-04-20 09:38:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:38:03 --> Config Class Initialized
INFO - 2023-04-20 09:38:03 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:38:03 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:38:03 --> Utf8 Class Initialized
INFO - 2023-04-20 09:38:03 --> URI Class Initialized
INFO - 2023-04-20 09:38:03 --> Router Class Initialized
INFO - 2023-04-20 09:38:03 --> Output Class Initialized
INFO - 2023-04-20 09:38:03 --> Security Class Initialized
DEBUG - 2023-04-20 09:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:38:03 --> Input Class Initialized
INFO - 2023-04-20 09:38:03 --> Language Class Initialized
INFO - 2023-04-20 09:38:03 --> Loader Class Initialized
INFO - 2023-04-20 09:38:03 --> Helper loaded: url_helper
INFO - 2023-04-20 09:38:03 --> Helper loaded: file_helper
INFO - 2023-04-20 09:38:03 --> Helper loaded: html_helper
INFO - 2023-04-20 09:38:03 --> Helper loaded: text_helper
INFO - 2023-04-20 09:38:03 --> Helper loaded: form_helper
INFO - 2023-04-20 09:38:03 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:38:03 --> Helper loaded: security_helper
INFO - 2023-04-20 09:38:03 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:38:03 --> Database Driver Class Initialized
INFO - 2023-04-20 09:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:38:03 --> Parser Class Initialized
INFO - 2023-04-20 09:38:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:38:03 --> Pagination Class Initialized
INFO - 2023-04-20 09:38:03 --> Form Validation Class Initialized
INFO - 2023-04-20 09:38:03 --> Controller Class Initialized
INFO - 2023-04-20 09:38:03 --> Model Class Initialized
DEBUG - 2023-04-20 09:38:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:38:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:38:03 --> Model Class Initialized
INFO - 2023-04-20 09:38:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest.php
DEBUG - 2023-04-20 09:38:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:38:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 09:38:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 09:38:03 --> Model Class Initialized
INFO - 2023-04-20 09:38:03 --> Model Class Initialized
INFO - 2023-04-20 09:38:03 --> Model Class Initialized
INFO - 2023-04-20 09:38:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 09:38:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 09:38:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 09:38:03 --> Final output sent to browser
DEBUG - 2023-04-20 09:38:03 --> Total execution time: 0.1465
ERROR - 2023-04-20 09:38:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:38:04 --> Config Class Initialized
INFO - 2023-04-20 09:38:04 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:38:04 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:38:04 --> Utf8 Class Initialized
INFO - 2023-04-20 09:38:04 --> URI Class Initialized
INFO - 2023-04-20 09:38:04 --> Router Class Initialized
INFO - 2023-04-20 09:38:04 --> Output Class Initialized
INFO - 2023-04-20 09:38:04 --> Security Class Initialized
DEBUG - 2023-04-20 09:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:38:04 --> Input Class Initialized
INFO - 2023-04-20 09:38:04 --> Language Class Initialized
INFO - 2023-04-20 09:38:04 --> Loader Class Initialized
INFO - 2023-04-20 09:38:04 --> Helper loaded: url_helper
INFO - 2023-04-20 09:38:04 --> Helper loaded: file_helper
INFO - 2023-04-20 09:38:04 --> Helper loaded: html_helper
INFO - 2023-04-20 09:38:04 --> Helper loaded: text_helper
INFO - 2023-04-20 09:38:04 --> Helper loaded: form_helper
INFO - 2023-04-20 09:38:04 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:38:04 --> Helper loaded: security_helper
INFO - 2023-04-20 09:38:04 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:38:04 --> Database Driver Class Initialized
INFO - 2023-04-20 09:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:38:04 --> Parser Class Initialized
INFO - 2023-04-20 09:38:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:38:04 --> Pagination Class Initialized
INFO - 2023-04-20 09:38:04 --> Form Validation Class Initialized
INFO - 2023-04-20 09:38:04 --> Controller Class Initialized
INFO - 2023-04-20 09:38:04 --> Model Class Initialized
DEBUG - 2023-04-20 09:38:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:38:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:38:04 --> Model Class Initialized
INFO - 2023-04-20 09:38:04 --> Final output sent to browser
DEBUG - 2023-04-20 09:38:04 --> Total execution time: 0.0160
ERROR - 2023-04-20 09:38:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:38:07 --> Config Class Initialized
INFO - 2023-04-20 09:38:07 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:38:07 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:38:07 --> Utf8 Class Initialized
INFO - 2023-04-20 09:38:07 --> URI Class Initialized
INFO - 2023-04-20 09:38:07 --> Router Class Initialized
INFO - 2023-04-20 09:38:07 --> Output Class Initialized
INFO - 2023-04-20 09:38:07 --> Security Class Initialized
DEBUG - 2023-04-20 09:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:38:07 --> Input Class Initialized
INFO - 2023-04-20 09:38:07 --> Language Class Initialized
INFO - 2023-04-20 09:38:07 --> Loader Class Initialized
INFO - 2023-04-20 09:38:07 --> Helper loaded: url_helper
INFO - 2023-04-20 09:38:07 --> Helper loaded: file_helper
INFO - 2023-04-20 09:38:07 --> Helper loaded: html_helper
INFO - 2023-04-20 09:38:07 --> Helper loaded: text_helper
INFO - 2023-04-20 09:38:07 --> Helper loaded: form_helper
INFO - 2023-04-20 09:38:07 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:38:07 --> Helper loaded: security_helper
INFO - 2023-04-20 09:38:07 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:38:07 --> Database Driver Class Initialized
INFO - 2023-04-20 09:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:38:07 --> Parser Class Initialized
INFO - 2023-04-20 09:38:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:38:07 --> Pagination Class Initialized
INFO - 2023-04-20 09:38:07 --> Form Validation Class Initialized
INFO - 2023-04-20 09:38:07 --> Controller Class Initialized
INFO - 2023-04-20 09:38:07 --> Model Class Initialized
DEBUG - 2023-04-20 09:38:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:38:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:38:07 --> Model Class Initialized
INFO - 2023-04-20 09:38:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-04-20 09:38:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:38:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 09:38:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 09:38:07 --> Model Class Initialized
INFO - 2023-04-20 09:38:07 --> Model Class Initialized
INFO - 2023-04-20 09:38:07 --> Model Class Initialized
INFO - 2023-04-20 09:38:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 09:38:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 09:38:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 09:38:08 --> Final output sent to browser
DEBUG - 2023-04-20 09:38:08 --> Total execution time: 0.1461
ERROR - 2023-04-20 09:38:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:38:08 --> Config Class Initialized
INFO - 2023-04-20 09:38:08 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:38:08 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:38:08 --> Utf8 Class Initialized
INFO - 2023-04-20 09:38:08 --> URI Class Initialized
INFO - 2023-04-20 09:38:08 --> Router Class Initialized
INFO - 2023-04-20 09:38:08 --> Output Class Initialized
INFO - 2023-04-20 09:38:08 --> Security Class Initialized
DEBUG - 2023-04-20 09:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:38:08 --> Input Class Initialized
INFO - 2023-04-20 09:38:08 --> Language Class Initialized
INFO - 2023-04-20 09:38:08 --> Loader Class Initialized
INFO - 2023-04-20 09:38:08 --> Helper loaded: url_helper
INFO - 2023-04-20 09:38:08 --> Helper loaded: file_helper
INFO - 2023-04-20 09:38:08 --> Helper loaded: html_helper
INFO - 2023-04-20 09:38:08 --> Helper loaded: text_helper
INFO - 2023-04-20 09:38:08 --> Helper loaded: form_helper
INFO - 2023-04-20 09:38:08 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:38:08 --> Helper loaded: security_helper
INFO - 2023-04-20 09:38:08 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:38:08 --> Database Driver Class Initialized
INFO - 2023-04-20 09:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:38:08 --> Parser Class Initialized
INFO - 2023-04-20 09:38:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:38:08 --> Pagination Class Initialized
INFO - 2023-04-20 09:38:08 --> Form Validation Class Initialized
INFO - 2023-04-20 09:38:08 --> Controller Class Initialized
INFO - 2023-04-20 09:38:08 --> Model Class Initialized
DEBUG - 2023-04-20 09:38:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:38:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:38:08 --> Model Class Initialized
INFO - 2023-04-20 09:38:08 --> Final output sent to browser
DEBUG - 2023-04-20 09:38:08 --> Total execution time: 0.0305
ERROR - 2023-04-20 09:38:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:38:14 --> Config Class Initialized
INFO - 2023-04-20 09:38:14 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:38:14 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:38:14 --> Utf8 Class Initialized
INFO - 2023-04-20 09:38:14 --> URI Class Initialized
INFO - 2023-04-20 09:38:14 --> Router Class Initialized
INFO - 2023-04-20 09:38:14 --> Output Class Initialized
INFO - 2023-04-20 09:38:14 --> Security Class Initialized
DEBUG - 2023-04-20 09:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:38:14 --> Input Class Initialized
INFO - 2023-04-20 09:38:14 --> Language Class Initialized
INFO - 2023-04-20 09:38:14 --> Loader Class Initialized
INFO - 2023-04-20 09:38:14 --> Helper loaded: url_helper
INFO - 2023-04-20 09:38:14 --> Helper loaded: file_helper
INFO - 2023-04-20 09:38:14 --> Helper loaded: html_helper
INFO - 2023-04-20 09:38:14 --> Helper loaded: text_helper
INFO - 2023-04-20 09:38:14 --> Helper loaded: form_helper
INFO - 2023-04-20 09:38:14 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:38:14 --> Helper loaded: security_helper
INFO - 2023-04-20 09:38:14 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:38:14 --> Database Driver Class Initialized
INFO - 2023-04-20 09:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:38:14 --> Parser Class Initialized
INFO - 2023-04-20 09:38:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:38:14 --> Pagination Class Initialized
INFO - 2023-04-20 09:38:14 --> Form Validation Class Initialized
INFO - 2023-04-20 09:38:14 --> Controller Class Initialized
INFO - 2023-04-20 09:38:14 --> Model Class Initialized
DEBUG - 2023-04-20 09:38:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:38:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:38:14 --> Model Class Initialized
INFO - 2023-04-20 09:38:14 --> Final output sent to browser
DEBUG - 2023-04-20 09:38:14 --> Total execution time: 0.0352
ERROR - 2023-04-20 09:38:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:38:25 --> Config Class Initialized
INFO - 2023-04-20 09:38:25 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:38:25 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:38:25 --> Utf8 Class Initialized
INFO - 2023-04-20 09:38:25 --> URI Class Initialized
INFO - 2023-04-20 09:38:25 --> Router Class Initialized
INFO - 2023-04-20 09:38:25 --> Output Class Initialized
INFO - 2023-04-20 09:38:25 --> Security Class Initialized
DEBUG - 2023-04-20 09:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:38:25 --> Input Class Initialized
INFO - 2023-04-20 09:38:25 --> Language Class Initialized
INFO - 2023-04-20 09:38:25 --> Loader Class Initialized
INFO - 2023-04-20 09:38:25 --> Helper loaded: url_helper
INFO - 2023-04-20 09:38:25 --> Helper loaded: file_helper
INFO - 2023-04-20 09:38:25 --> Helper loaded: html_helper
INFO - 2023-04-20 09:38:25 --> Helper loaded: text_helper
INFO - 2023-04-20 09:38:25 --> Helper loaded: form_helper
INFO - 2023-04-20 09:38:25 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:38:25 --> Helper loaded: security_helper
INFO - 2023-04-20 09:38:25 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:38:25 --> Database Driver Class Initialized
INFO - 2023-04-20 09:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:38:25 --> Parser Class Initialized
INFO - 2023-04-20 09:38:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:38:25 --> Pagination Class Initialized
INFO - 2023-04-20 09:38:25 --> Form Validation Class Initialized
INFO - 2023-04-20 09:38:25 --> Controller Class Initialized
INFO - 2023-04-20 09:38:25 --> Model Class Initialized
DEBUG - 2023-04-20 09:38:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:38:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:38:25 --> Model Class Initialized
INFO - 2023-04-20 09:38:25 --> Final output sent to browser
DEBUG - 2023-04-20 09:38:25 --> Total execution time: 0.0364
ERROR - 2023-04-20 09:38:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:38:58 --> Config Class Initialized
INFO - 2023-04-20 09:38:58 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:38:58 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:38:58 --> Utf8 Class Initialized
INFO - 2023-04-20 09:38:58 --> URI Class Initialized
INFO - 2023-04-20 09:38:58 --> Router Class Initialized
INFO - 2023-04-20 09:38:58 --> Output Class Initialized
INFO - 2023-04-20 09:38:58 --> Security Class Initialized
DEBUG - 2023-04-20 09:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:38:58 --> Input Class Initialized
INFO - 2023-04-20 09:38:58 --> Language Class Initialized
INFO - 2023-04-20 09:38:58 --> Loader Class Initialized
INFO - 2023-04-20 09:38:58 --> Helper loaded: url_helper
INFO - 2023-04-20 09:38:58 --> Helper loaded: file_helper
INFO - 2023-04-20 09:38:58 --> Helper loaded: html_helper
INFO - 2023-04-20 09:38:58 --> Helper loaded: text_helper
INFO - 2023-04-20 09:38:58 --> Helper loaded: form_helper
INFO - 2023-04-20 09:38:58 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:38:58 --> Helper loaded: security_helper
INFO - 2023-04-20 09:38:58 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:38:58 --> Database Driver Class Initialized
INFO - 2023-04-20 09:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:38:58 --> Parser Class Initialized
INFO - 2023-04-20 09:38:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:38:58 --> Pagination Class Initialized
INFO - 2023-04-20 09:38:58 --> Form Validation Class Initialized
INFO - 2023-04-20 09:38:58 --> Controller Class Initialized
INFO - 2023-04-20 09:38:58 --> Model Class Initialized
DEBUG - 2023-04-20 09:38:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:38:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:38:58 --> Model Class Initialized
DEBUG - 2023-04-20 09:38:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:38:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-04-20 09:38:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:38:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 09:38:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 09:38:58 --> Model Class Initialized
INFO - 2023-04-20 09:38:58 --> Model Class Initialized
INFO - 2023-04-20 09:38:58 --> Model Class Initialized
INFO - 2023-04-20 09:38:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 09:38:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 09:38:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 09:38:58 --> Final output sent to browser
DEBUG - 2023-04-20 09:38:58 --> Total execution time: 0.1666
ERROR - 2023-04-20 09:39:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:39:22 --> Config Class Initialized
INFO - 2023-04-20 09:39:22 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:39:22 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:39:22 --> Utf8 Class Initialized
INFO - 2023-04-20 09:39:22 --> URI Class Initialized
INFO - 2023-04-20 09:39:22 --> Router Class Initialized
INFO - 2023-04-20 09:39:22 --> Output Class Initialized
INFO - 2023-04-20 09:39:22 --> Security Class Initialized
DEBUG - 2023-04-20 09:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:39:22 --> Input Class Initialized
INFO - 2023-04-20 09:39:22 --> Language Class Initialized
INFO - 2023-04-20 09:39:22 --> Loader Class Initialized
INFO - 2023-04-20 09:39:22 --> Helper loaded: url_helper
INFO - 2023-04-20 09:39:22 --> Helper loaded: file_helper
INFO - 2023-04-20 09:39:22 --> Helper loaded: html_helper
INFO - 2023-04-20 09:39:22 --> Helper loaded: text_helper
INFO - 2023-04-20 09:39:22 --> Helper loaded: form_helper
INFO - 2023-04-20 09:39:22 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:39:22 --> Helper loaded: security_helper
INFO - 2023-04-20 09:39:22 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:39:22 --> Database Driver Class Initialized
INFO - 2023-04-20 09:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:39:22 --> Parser Class Initialized
INFO - 2023-04-20 09:39:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:39:22 --> Pagination Class Initialized
INFO - 2023-04-20 09:39:22 --> Form Validation Class Initialized
INFO - 2023-04-20 09:39:22 --> Controller Class Initialized
INFO - 2023-04-20 09:39:22 --> Model Class Initialized
DEBUG - 2023-04-20 09:39:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:39:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:39:22 --> Model Class Initialized
INFO - 2023-04-20 09:39:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-04-20 09:39:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:39:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 09:39:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 09:39:22 --> Model Class Initialized
INFO - 2023-04-20 09:39:22 --> Model Class Initialized
INFO - 2023-04-20 09:39:22 --> Model Class Initialized
INFO - 2023-04-20 09:39:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 09:39:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 09:39:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 09:39:22 --> Final output sent to browser
DEBUG - 2023-04-20 09:39:22 --> Total execution time: 0.1510
ERROR - 2023-04-20 09:39:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:39:23 --> Config Class Initialized
INFO - 2023-04-20 09:39:23 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:39:23 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:39:23 --> Utf8 Class Initialized
INFO - 2023-04-20 09:39:23 --> URI Class Initialized
INFO - 2023-04-20 09:39:23 --> Router Class Initialized
INFO - 2023-04-20 09:39:23 --> Output Class Initialized
INFO - 2023-04-20 09:39:23 --> Security Class Initialized
DEBUG - 2023-04-20 09:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:39:23 --> Input Class Initialized
INFO - 2023-04-20 09:39:23 --> Language Class Initialized
INFO - 2023-04-20 09:39:23 --> Loader Class Initialized
INFO - 2023-04-20 09:39:23 --> Helper loaded: url_helper
INFO - 2023-04-20 09:39:23 --> Helper loaded: file_helper
INFO - 2023-04-20 09:39:23 --> Helper loaded: html_helper
INFO - 2023-04-20 09:39:23 --> Helper loaded: text_helper
INFO - 2023-04-20 09:39:23 --> Helper loaded: form_helper
INFO - 2023-04-20 09:39:23 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:39:23 --> Helper loaded: security_helper
INFO - 2023-04-20 09:39:23 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:39:23 --> Database Driver Class Initialized
INFO - 2023-04-20 09:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:39:23 --> Parser Class Initialized
INFO - 2023-04-20 09:39:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:39:23 --> Pagination Class Initialized
INFO - 2023-04-20 09:39:23 --> Form Validation Class Initialized
INFO - 2023-04-20 09:39:23 --> Controller Class Initialized
INFO - 2023-04-20 09:39:23 --> Model Class Initialized
DEBUG - 2023-04-20 09:39:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:39:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:39:23 --> Model Class Initialized
INFO - 2023-04-20 09:39:23 --> Final output sent to browser
DEBUG - 2023-04-20 09:39:23 --> Total execution time: 0.0348
ERROR - 2023-04-20 09:39:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:39:28 --> Config Class Initialized
INFO - 2023-04-20 09:39:28 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:39:28 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:39:28 --> Utf8 Class Initialized
INFO - 2023-04-20 09:39:28 --> URI Class Initialized
INFO - 2023-04-20 09:39:28 --> Router Class Initialized
INFO - 2023-04-20 09:39:28 --> Output Class Initialized
INFO - 2023-04-20 09:39:28 --> Security Class Initialized
DEBUG - 2023-04-20 09:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:39:28 --> Input Class Initialized
INFO - 2023-04-20 09:39:28 --> Language Class Initialized
INFO - 2023-04-20 09:39:28 --> Loader Class Initialized
INFO - 2023-04-20 09:39:28 --> Helper loaded: url_helper
INFO - 2023-04-20 09:39:28 --> Helper loaded: file_helper
INFO - 2023-04-20 09:39:28 --> Helper loaded: html_helper
INFO - 2023-04-20 09:39:28 --> Helper loaded: text_helper
INFO - 2023-04-20 09:39:28 --> Helper loaded: form_helper
INFO - 2023-04-20 09:39:28 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:39:28 --> Helper loaded: security_helper
INFO - 2023-04-20 09:39:28 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:39:28 --> Database Driver Class Initialized
INFO - 2023-04-20 09:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:39:28 --> Parser Class Initialized
INFO - 2023-04-20 09:39:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:39:28 --> Pagination Class Initialized
INFO - 2023-04-20 09:39:28 --> Form Validation Class Initialized
INFO - 2023-04-20 09:39:28 --> Controller Class Initialized
INFO - 2023-04-20 09:39:28 --> Model Class Initialized
DEBUG - 2023-04-20 09:39:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:39:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:39:28 --> Model Class Initialized
INFO - 2023-04-20 09:39:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-04-20 09:39:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:39:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 09:39:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 09:39:28 --> Model Class Initialized
INFO - 2023-04-20 09:39:28 --> Model Class Initialized
INFO - 2023-04-20 09:39:28 --> Model Class Initialized
INFO - 2023-04-20 09:39:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 09:39:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 09:39:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 09:39:28 --> Final output sent to browser
DEBUG - 2023-04-20 09:39:28 --> Total execution time: 0.1319
ERROR - 2023-04-20 09:39:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:39:29 --> Config Class Initialized
INFO - 2023-04-20 09:39:29 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:39:29 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:39:29 --> Utf8 Class Initialized
INFO - 2023-04-20 09:39:29 --> URI Class Initialized
INFO - 2023-04-20 09:39:29 --> Router Class Initialized
INFO - 2023-04-20 09:39:29 --> Output Class Initialized
INFO - 2023-04-20 09:39:29 --> Security Class Initialized
DEBUG - 2023-04-20 09:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:39:29 --> Input Class Initialized
INFO - 2023-04-20 09:39:29 --> Language Class Initialized
INFO - 2023-04-20 09:39:29 --> Loader Class Initialized
INFO - 2023-04-20 09:39:29 --> Helper loaded: url_helper
INFO - 2023-04-20 09:39:29 --> Helper loaded: file_helper
INFO - 2023-04-20 09:39:29 --> Helper loaded: html_helper
INFO - 2023-04-20 09:39:29 --> Helper loaded: text_helper
INFO - 2023-04-20 09:39:29 --> Helper loaded: form_helper
INFO - 2023-04-20 09:39:29 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:39:29 --> Helper loaded: security_helper
INFO - 2023-04-20 09:39:29 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:39:29 --> Database Driver Class Initialized
INFO - 2023-04-20 09:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:39:29 --> Parser Class Initialized
INFO - 2023-04-20 09:39:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:39:29 --> Pagination Class Initialized
INFO - 2023-04-20 09:39:29 --> Form Validation Class Initialized
INFO - 2023-04-20 09:39:29 --> Controller Class Initialized
INFO - 2023-04-20 09:39:29 --> Model Class Initialized
DEBUG - 2023-04-20 09:39:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:39:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:39:29 --> Model Class Initialized
INFO - 2023-04-20 09:39:29 --> Final output sent to browser
DEBUG - 2023-04-20 09:39:29 --> Total execution time: 0.0285
ERROR - 2023-04-20 09:39:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:39:44 --> Config Class Initialized
INFO - 2023-04-20 09:39:44 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:39:44 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:39:44 --> Utf8 Class Initialized
INFO - 2023-04-20 09:39:44 --> URI Class Initialized
INFO - 2023-04-20 09:39:44 --> Router Class Initialized
INFO - 2023-04-20 09:39:44 --> Output Class Initialized
INFO - 2023-04-20 09:39:44 --> Security Class Initialized
DEBUG - 2023-04-20 09:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:39:44 --> Input Class Initialized
INFO - 2023-04-20 09:39:44 --> Language Class Initialized
INFO - 2023-04-20 09:39:44 --> Loader Class Initialized
INFO - 2023-04-20 09:39:44 --> Helper loaded: url_helper
INFO - 2023-04-20 09:39:44 --> Helper loaded: file_helper
INFO - 2023-04-20 09:39:44 --> Helper loaded: html_helper
INFO - 2023-04-20 09:39:44 --> Helper loaded: text_helper
INFO - 2023-04-20 09:39:44 --> Helper loaded: form_helper
INFO - 2023-04-20 09:39:44 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:39:44 --> Helper loaded: security_helper
INFO - 2023-04-20 09:39:44 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:39:44 --> Database Driver Class Initialized
INFO - 2023-04-20 09:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:39:44 --> Parser Class Initialized
INFO - 2023-04-20 09:39:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:39:44 --> Pagination Class Initialized
INFO - 2023-04-20 09:39:44 --> Form Validation Class Initialized
INFO - 2023-04-20 09:39:44 --> Controller Class Initialized
INFO - 2023-04-20 09:39:44 --> Model Class Initialized
DEBUG - 2023-04-20 09:39:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:39:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:39:44 --> Model Class Initialized
DEBUG - 2023-04-20 09:39:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:39:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-04-20 09:39:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:39:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 09:39:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 09:39:44 --> Model Class Initialized
INFO - 2023-04-20 09:39:44 --> Model Class Initialized
INFO - 2023-04-20 09:39:44 --> Model Class Initialized
INFO - 2023-04-20 09:39:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 09:39:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 09:39:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 09:39:44 --> Final output sent to browser
DEBUG - 2023-04-20 09:39:44 --> Total execution time: 0.2274
ERROR - 2023-04-20 09:40:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:40:14 --> Config Class Initialized
INFO - 2023-04-20 09:40:14 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:40:14 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:40:14 --> Utf8 Class Initialized
INFO - 2023-04-20 09:40:14 --> URI Class Initialized
INFO - 2023-04-20 09:40:14 --> Router Class Initialized
INFO - 2023-04-20 09:40:14 --> Output Class Initialized
INFO - 2023-04-20 09:40:14 --> Security Class Initialized
DEBUG - 2023-04-20 09:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:40:14 --> Input Class Initialized
INFO - 2023-04-20 09:40:14 --> Language Class Initialized
INFO - 2023-04-20 09:40:14 --> Loader Class Initialized
INFO - 2023-04-20 09:40:14 --> Helper loaded: url_helper
INFO - 2023-04-20 09:40:14 --> Helper loaded: file_helper
INFO - 2023-04-20 09:40:14 --> Helper loaded: html_helper
INFO - 2023-04-20 09:40:14 --> Helper loaded: text_helper
INFO - 2023-04-20 09:40:14 --> Helper loaded: form_helper
INFO - 2023-04-20 09:40:14 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:40:14 --> Helper loaded: security_helper
INFO - 2023-04-20 09:40:14 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:40:14 --> Database Driver Class Initialized
INFO - 2023-04-20 09:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:40:14 --> Parser Class Initialized
INFO - 2023-04-20 09:40:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:40:14 --> Pagination Class Initialized
INFO - 2023-04-20 09:40:14 --> Form Validation Class Initialized
INFO - 2023-04-20 09:40:14 --> Controller Class Initialized
INFO - 2023-04-20 09:40:14 --> Model Class Initialized
DEBUG - 2023-04-20 09:40:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:40:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:40:14 --> Model Class Initialized
INFO - 2023-04-20 09:40:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest.php
DEBUG - 2023-04-20 09:40:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:40:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 09:40:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 09:40:14 --> Model Class Initialized
INFO - 2023-04-20 09:40:14 --> Model Class Initialized
INFO - 2023-04-20 09:40:14 --> Model Class Initialized
INFO - 2023-04-20 09:40:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 09:40:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 09:40:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 09:40:14 --> Final output sent to browser
DEBUG - 2023-04-20 09:40:14 --> Total execution time: 0.1451
ERROR - 2023-04-20 09:40:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:40:15 --> Config Class Initialized
INFO - 2023-04-20 09:40:15 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:40:15 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:40:15 --> Utf8 Class Initialized
INFO - 2023-04-20 09:40:15 --> URI Class Initialized
INFO - 2023-04-20 09:40:15 --> Router Class Initialized
INFO - 2023-04-20 09:40:15 --> Output Class Initialized
INFO - 2023-04-20 09:40:15 --> Security Class Initialized
DEBUG - 2023-04-20 09:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:40:15 --> Input Class Initialized
INFO - 2023-04-20 09:40:15 --> Language Class Initialized
INFO - 2023-04-20 09:40:15 --> Loader Class Initialized
INFO - 2023-04-20 09:40:15 --> Helper loaded: url_helper
INFO - 2023-04-20 09:40:15 --> Helper loaded: file_helper
INFO - 2023-04-20 09:40:15 --> Helper loaded: html_helper
INFO - 2023-04-20 09:40:15 --> Helper loaded: text_helper
INFO - 2023-04-20 09:40:15 --> Helper loaded: form_helper
INFO - 2023-04-20 09:40:15 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:40:15 --> Helper loaded: security_helper
INFO - 2023-04-20 09:40:15 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:40:15 --> Database Driver Class Initialized
INFO - 2023-04-20 09:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:40:15 --> Parser Class Initialized
INFO - 2023-04-20 09:40:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:40:15 --> Pagination Class Initialized
INFO - 2023-04-20 09:40:15 --> Form Validation Class Initialized
INFO - 2023-04-20 09:40:15 --> Controller Class Initialized
INFO - 2023-04-20 09:40:15 --> Model Class Initialized
DEBUG - 2023-04-20 09:40:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:40:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:40:15 --> Model Class Initialized
INFO - 2023-04-20 09:40:15 --> Final output sent to browser
DEBUG - 2023-04-20 09:40:15 --> Total execution time: 0.0204
ERROR - 2023-04-20 09:40:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:40:20 --> Config Class Initialized
INFO - 2023-04-20 09:40:20 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:40:20 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:40:20 --> Utf8 Class Initialized
INFO - 2023-04-20 09:40:20 --> URI Class Initialized
INFO - 2023-04-20 09:40:20 --> Router Class Initialized
INFO - 2023-04-20 09:40:20 --> Output Class Initialized
INFO - 2023-04-20 09:40:20 --> Security Class Initialized
DEBUG - 2023-04-20 09:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:40:20 --> Input Class Initialized
INFO - 2023-04-20 09:40:20 --> Language Class Initialized
INFO - 2023-04-20 09:40:20 --> Loader Class Initialized
INFO - 2023-04-20 09:40:20 --> Helper loaded: url_helper
INFO - 2023-04-20 09:40:20 --> Helper loaded: file_helper
INFO - 2023-04-20 09:40:20 --> Helper loaded: html_helper
INFO - 2023-04-20 09:40:20 --> Helper loaded: text_helper
INFO - 2023-04-20 09:40:20 --> Helper loaded: form_helper
INFO - 2023-04-20 09:40:20 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:40:20 --> Helper loaded: security_helper
INFO - 2023-04-20 09:40:20 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:40:20 --> Database Driver Class Initialized
INFO - 2023-04-20 09:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:40:20 --> Parser Class Initialized
INFO - 2023-04-20 09:40:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:40:20 --> Pagination Class Initialized
INFO - 2023-04-20 09:40:20 --> Form Validation Class Initialized
INFO - 2023-04-20 09:40:20 --> Controller Class Initialized
INFO - 2023-04-20 09:40:20 --> Model Class Initialized
DEBUG - 2023-04-20 09:40:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:40:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:40:20 --> Model Class Initialized
INFO - 2023-04-20 09:40:20 --> Final output sent to browser
DEBUG - 2023-04-20 09:40:20 --> Total execution time: 0.0151
ERROR - 2023-04-20 09:40:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:40:24 --> Config Class Initialized
INFO - 2023-04-20 09:40:24 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:40:24 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:40:24 --> Utf8 Class Initialized
INFO - 2023-04-20 09:40:24 --> URI Class Initialized
INFO - 2023-04-20 09:40:24 --> Router Class Initialized
INFO - 2023-04-20 09:40:24 --> Output Class Initialized
INFO - 2023-04-20 09:40:24 --> Security Class Initialized
DEBUG - 2023-04-20 09:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:40:24 --> Input Class Initialized
INFO - 2023-04-20 09:40:24 --> Language Class Initialized
INFO - 2023-04-20 09:40:24 --> Loader Class Initialized
INFO - 2023-04-20 09:40:24 --> Helper loaded: url_helper
INFO - 2023-04-20 09:40:24 --> Helper loaded: file_helper
INFO - 2023-04-20 09:40:24 --> Helper loaded: html_helper
INFO - 2023-04-20 09:40:24 --> Helper loaded: text_helper
INFO - 2023-04-20 09:40:24 --> Helper loaded: form_helper
INFO - 2023-04-20 09:40:24 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:40:24 --> Helper loaded: security_helper
INFO - 2023-04-20 09:40:24 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:40:24 --> Database Driver Class Initialized
INFO - 2023-04-20 09:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:40:24 --> Parser Class Initialized
INFO - 2023-04-20 09:40:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:40:24 --> Pagination Class Initialized
INFO - 2023-04-20 09:40:24 --> Form Validation Class Initialized
INFO - 2023-04-20 09:40:24 --> Controller Class Initialized
INFO - 2023-04-20 09:40:24 --> Model Class Initialized
DEBUG - 2023-04-20 09:40:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:40:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:40:24 --> Model Class Initialized
INFO - 2023-04-20 09:40:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-04-20 09:40:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:40:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 09:40:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 09:40:24 --> Model Class Initialized
INFO - 2023-04-20 09:40:24 --> Model Class Initialized
INFO - 2023-04-20 09:40:24 --> Model Class Initialized
INFO - 2023-04-20 09:40:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 09:40:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 09:40:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 09:40:24 --> Final output sent to browser
DEBUG - 2023-04-20 09:40:24 --> Total execution time: 0.1446
ERROR - 2023-04-20 09:40:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:40:25 --> Config Class Initialized
INFO - 2023-04-20 09:40:25 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:40:25 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:40:25 --> Utf8 Class Initialized
INFO - 2023-04-20 09:40:25 --> URI Class Initialized
INFO - 2023-04-20 09:40:25 --> Router Class Initialized
INFO - 2023-04-20 09:40:25 --> Output Class Initialized
INFO - 2023-04-20 09:40:25 --> Security Class Initialized
DEBUG - 2023-04-20 09:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:40:25 --> Input Class Initialized
INFO - 2023-04-20 09:40:25 --> Language Class Initialized
INFO - 2023-04-20 09:40:25 --> Loader Class Initialized
INFO - 2023-04-20 09:40:25 --> Helper loaded: url_helper
INFO - 2023-04-20 09:40:25 --> Helper loaded: file_helper
INFO - 2023-04-20 09:40:25 --> Helper loaded: html_helper
INFO - 2023-04-20 09:40:25 --> Helper loaded: text_helper
INFO - 2023-04-20 09:40:25 --> Helper loaded: form_helper
INFO - 2023-04-20 09:40:25 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:40:25 --> Helper loaded: security_helper
INFO - 2023-04-20 09:40:25 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:40:25 --> Database Driver Class Initialized
INFO - 2023-04-20 09:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:40:25 --> Parser Class Initialized
INFO - 2023-04-20 09:40:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:40:25 --> Pagination Class Initialized
INFO - 2023-04-20 09:40:25 --> Form Validation Class Initialized
INFO - 2023-04-20 09:40:25 --> Controller Class Initialized
INFO - 2023-04-20 09:40:25 --> Model Class Initialized
DEBUG - 2023-04-20 09:40:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:40:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:40:25 --> Model Class Initialized
INFO - 2023-04-20 09:40:25 --> Final output sent to browser
DEBUG - 2023-04-20 09:40:25 --> Total execution time: 0.0301
ERROR - 2023-04-20 09:40:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:40:29 --> Config Class Initialized
INFO - 2023-04-20 09:40:29 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:40:29 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:40:29 --> Utf8 Class Initialized
INFO - 2023-04-20 09:40:29 --> URI Class Initialized
INFO - 2023-04-20 09:40:29 --> Router Class Initialized
INFO - 2023-04-20 09:40:29 --> Output Class Initialized
INFO - 2023-04-20 09:40:29 --> Security Class Initialized
DEBUG - 2023-04-20 09:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:40:29 --> Input Class Initialized
INFO - 2023-04-20 09:40:29 --> Language Class Initialized
INFO - 2023-04-20 09:40:29 --> Loader Class Initialized
INFO - 2023-04-20 09:40:29 --> Helper loaded: url_helper
INFO - 2023-04-20 09:40:29 --> Helper loaded: file_helper
INFO - 2023-04-20 09:40:29 --> Helper loaded: html_helper
INFO - 2023-04-20 09:40:29 --> Helper loaded: text_helper
INFO - 2023-04-20 09:40:29 --> Helper loaded: form_helper
INFO - 2023-04-20 09:40:29 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:40:29 --> Helper loaded: security_helper
INFO - 2023-04-20 09:40:29 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:40:29 --> Database Driver Class Initialized
INFO - 2023-04-20 09:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:40:29 --> Parser Class Initialized
INFO - 2023-04-20 09:40:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:40:29 --> Pagination Class Initialized
INFO - 2023-04-20 09:40:29 --> Form Validation Class Initialized
INFO - 2023-04-20 09:40:29 --> Controller Class Initialized
INFO - 2023-04-20 09:40:29 --> Model Class Initialized
DEBUG - 2023-04-20 09:40:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:40:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:40:29 --> Model Class Initialized
INFO - 2023-04-20 09:40:29 --> Final output sent to browser
DEBUG - 2023-04-20 09:40:29 --> Total execution time: 0.0335
ERROR - 2023-04-20 09:40:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:40:51 --> Config Class Initialized
INFO - 2023-04-20 09:40:51 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:40:51 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:40:51 --> Utf8 Class Initialized
INFO - 2023-04-20 09:40:51 --> URI Class Initialized
INFO - 2023-04-20 09:40:51 --> Router Class Initialized
INFO - 2023-04-20 09:40:51 --> Output Class Initialized
INFO - 2023-04-20 09:40:51 --> Security Class Initialized
DEBUG - 2023-04-20 09:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:40:51 --> Input Class Initialized
INFO - 2023-04-20 09:40:51 --> Language Class Initialized
INFO - 2023-04-20 09:40:51 --> Loader Class Initialized
INFO - 2023-04-20 09:40:51 --> Helper loaded: url_helper
INFO - 2023-04-20 09:40:51 --> Helper loaded: file_helper
INFO - 2023-04-20 09:40:51 --> Helper loaded: html_helper
INFO - 2023-04-20 09:40:51 --> Helper loaded: text_helper
INFO - 2023-04-20 09:40:51 --> Helper loaded: form_helper
INFO - 2023-04-20 09:40:51 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:40:51 --> Helper loaded: security_helper
INFO - 2023-04-20 09:40:51 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:40:51 --> Database Driver Class Initialized
INFO - 2023-04-20 09:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:40:51 --> Parser Class Initialized
INFO - 2023-04-20 09:40:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:40:51 --> Pagination Class Initialized
INFO - 2023-04-20 09:40:51 --> Form Validation Class Initialized
INFO - 2023-04-20 09:40:51 --> Controller Class Initialized
INFO - 2023-04-20 09:40:51 --> Model Class Initialized
DEBUG - 2023-04-20 09:40:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:40:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:40:51 --> Model Class Initialized
DEBUG - 2023-04-20 09:40:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:40:51 --> Model Class Initialized
INFO - 2023-04-20 09:40:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-04-20 09:40:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:40:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 09:40:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 09:40:51 --> Model Class Initialized
INFO - 2023-04-20 09:40:51 --> Model Class Initialized
INFO - 2023-04-20 09:40:51 --> Model Class Initialized
INFO - 2023-04-20 09:40:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 09:40:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 09:40:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 09:40:51 --> Final output sent to browser
DEBUG - 2023-04-20 09:40:51 --> Total execution time: 0.1627
ERROR - 2023-04-20 09:40:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:40:52 --> Config Class Initialized
INFO - 2023-04-20 09:40:52 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:40:52 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:40:52 --> Utf8 Class Initialized
INFO - 2023-04-20 09:40:52 --> URI Class Initialized
INFO - 2023-04-20 09:40:52 --> Router Class Initialized
INFO - 2023-04-20 09:40:52 --> Output Class Initialized
INFO - 2023-04-20 09:40:52 --> Security Class Initialized
DEBUG - 2023-04-20 09:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:40:52 --> Input Class Initialized
INFO - 2023-04-20 09:40:52 --> Language Class Initialized
INFO - 2023-04-20 09:40:52 --> Loader Class Initialized
INFO - 2023-04-20 09:40:52 --> Helper loaded: url_helper
INFO - 2023-04-20 09:40:52 --> Helper loaded: file_helper
INFO - 2023-04-20 09:40:52 --> Helper loaded: html_helper
INFO - 2023-04-20 09:40:52 --> Helper loaded: text_helper
INFO - 2023-04-20 09:40:52 --> Helper loaded: form_helper
INFO - 2023-04-20 09:40:52 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:40:52 --> Helper loaded: security_helper
INFO - 2023-04-20 09:40:52 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:40:52 --> Database Driver Class Initialized
INFO - 2023-04-20 09:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:40:52 --> Parser Class Initialized
INFO - 2023-04-20 09:40:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:40:52 --> Pagination Class Initialized
INFO - 2023-04-20 09:40:52 --> Form Validation Class Initialized
INFO - 2023-04-20 09:40:52 --> Controller Class Initialized
INFO - 2023-04-20 09:40:52 --> Model Class Initialized
DEBUG - 2023-04-20 09:40:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:40:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:40:52 --> Model Class Initialized
DEBUG - 2023-04-20 09:40:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:40:52 --> Model Class Initialized
INFO - 2023-04-20 09:40:52 --> Final output sent to browser
DEBUG - 2023-04-20 09:40:52 --> Total execution time: 0.0625
ERROR - 2023-04-20 09:40:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:40:56 --> Config Class Initialized
INFO - 2023-04-20 09:40:56 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:40:56 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:40:56 --> Utf8 Class Initialized
INFO - 2023-04-20 09:40:56 --> URI Class Initialized
INFO - 2023-04-20 09:40:56 --> Router Class Initialized
INFO - 2023-04-20 09:40:56 --> Output Class Initialized
INFO - 2023-04-20 09:40:56 --> Security Class Initialized
DEBUG - 2023-04-20 09:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:40:56 --> Input Class Initialized
INFO - 2023-04-20 09:40:56 --> Language Class Initialized
INFO - 2023-04-20 09:40:56 --> Loader Class Initialized
INFO - 2023-04-20 09:40:56 --> Helper loaded: url_helper
INFO - 2023-04-20 09:40:56 --> Helper loaded: file_helper
INFO - 2023-04-20 09:40:56 --> Helper loaded: html_helper
INFO - 2023-04-20 09:40:56 --> Helper loaded: text_helper
INFO - 2023-04-20 09:40:56 --> Helper loaded: form_helper
INFO - 2023-04-20 09:40:56 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:40:56 --> Helper loaded: security_helper
INFO - 2023-04-20 09:40:56 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:40:56 --> Database Driver Class Initialized
INFO - 2023-04-20 09:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:40:56 --> Parser Class Initialized
INFO - 2023-04-20 09:40:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:40:56 --> Pagination Class Initialized
INFO - 2023-04-20 09:40:56 --> Form Validation Class Initialized
INFO - 2023-04-20 09:40:56 --> Controller Class Initialized
INFO - 2023-04-20 09:40:56 --> Model Class Initialized
DEBUG - 2023-04-20 09:40:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:40:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:40:56 --> Model Class Initialized
DEBUG - 2023-04-20 09:40:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:40:56 --> Model Class Initialized
INFO - 2023-04-20 09:40:56 --> Final output sent to browser
DEBUG - 2023-04-20 09:40:56 --> Total execution time: 0.0720
ERROR - 2023-04-20 09:41:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:41:28 --> Config Class Initialized
INFO - 2023-04-20 09:41:28 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:41:28 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:41:28 --> Utf8 Class Initialized
INFO - 2023-04-20 09:41:28 --> URI Class Initialized
INFO - 2023-04-20 09:41:28 --> Router Class Initialized
INFO - 2023-04-20 09:41:28 --> Output Class Initialized
INFO - 2023-04-20 09:41:28 --> Security Class Initialized
DEBUG - 2023-04-20 09:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:41:28 --> Input Class Initialized
INFO - 2023-04-20 09:41:28 --> Language Class Initialized
INFO - 2023-04-20 09:41:28 --> Loader Class Initialized
INFO - 2023-04-20 09:41:28 --> Helper loaded: url_helper
INFO - 2023-04-20 09:41:28 --> Helper loaded: file_helper
INFO - 2023-04-20 09:41:28 --> Helper loaded: html_helper
INFO - 2023-04-20 09:41:28 --> Helper loaded: text_helper
INFO - 2023-04-20 09:41:28 --> Helper loaded: form_helper
INFO - 2023-04-20 09:41:28 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:41:28 --> Helper loaded: security_helper
INFO - 2023-04-20 09:41:28 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:41:28 --> Database Driver Class Initialized
INFO - 2023-04-20 09:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:41:28 --> Parser Class Initialized
INFO - 2023-04-20 09:41:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:41:28 --> Pagination Class Initialized
INFO - 2023-04-20 09:41:28 --> Form Validation Class Initialized
INFO - 2023-04-20 09:41:28 --> Controller Class Initialized
INFO - 2023-04-20 09:41:28 --> Model Class Initialized
DEBUG - 2023-04-20 09:41:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:41:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:41:28 --> Model Class Initialized
DEBUG - 2023-04-20 09:41:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:41:28 --> Model Class Initialized
DEBUG - 2023-04-20 09:41:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:41:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-04-20 09:41:28 --> Occational class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:41:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:41:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
DEBUG - 2023-04-20 09:41:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:41:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 09:41:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 09:41:28 --> Model Class Initialized
INFO - 2023-04-20 09:41:28 --> Model Class Initialized
INFO - 2023-04-20 09:41:28 --> Model Class Initialized
INFO - 2023-04-20 09:41:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 09:41:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 09:41:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 09:41:28 --> Final output sent to browser
DEBUG - 2023-04-20 09:41:28 --> Total execution time: 0.1909
ERROR - 2023-04-20 09:43:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:43:21 --> Config Class Initialized
INFO - 2023-04-20 09:43:21 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:43:21 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:43:21 --> Utf8 Class Initialized
INFO - 2023-04-20 09:43:21 --> URI Class Initialized
INFO - 2023-04-20 09:43:21 --> Router Class Initialized
INFO - 2023-04-20 09:43:21 --> Output Class Initialized
INFO - 2023-04-20 09:43:21 --> Security Class Initialized
DEBUG - 2023-04-20 09:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:43:21 --> Input Class Initialized
INFO - 2023-04-20 09:43:21 --> Language Class Initialized
INFO - 2023-04-20 09:43:21 --> Loader Class Initialized
INFO - 2023-04-20 09:43:21 --> Helper loaded: url_helper
INFO - 2023-04-20 09:43:21 --> Helper loaded: file_helper
INFO - 2023-04-20 09:43:21 --> Helper loaded: html_helper
INFO - 2023-04-20 09:43:21 --> Helper loaded: text_helper
INFO - 2023-04-20 09:43:21 --> Helper loaded: form_helper
INFO - 2023-04-20 09:43:21 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:43:21 --> Helper loaded: security_helper
INFO - 2023-04-20 09:43:21 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:43:21 --> Database Driver Class Initialized
INFO - 2023-04-20 09:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:43:21 --> Parser Class Initialized
INFO - 2023-04-20 09:43:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:43:21 --> Pagination Class Initialized
INFO - 2023-04-20 09:43:21 --> Form Validation Class Initialized
INFO - 2023-04-20 09:43:21 --> Controller Class Initialized
INFO - 2023-04-20 09:43:21 --> Model Class Initialized
DEBUG - 2023-04-20 09:43:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:43:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:43:21 --> Model Class Initialized
INFO - 2023-04-20 09:43:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-04-20 09:43:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:43:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 09:43:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 09:43:21 --> Model Class Initialized
INFO - 2023-04-20 09:43:21 --> Model Class Initialized
INFO - 2023-04-20 09:43:21 --> Model Class Initialized
INFO - 2023-04-20 09:43:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 09:43:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 09:43:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 09:43:21 --> Final output sent to browser
DEBUG - 2023-04-20 09:43:21 --> Total execution time: 0.1685
ERROR - 2023-04-20 09:43:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:43:22 --> Config Class Initialized
INFO - 2023-04-20 09:43:22 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:43:22 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:43:22 --> Utf8 Class Initialized
INFO - 2023-04-20 09:43:22 --> URI Class Initialized
INFO - 2023-04-20 09:43:22 --> Router Class Initialized
INFO - 2023-04-20 09:43:22 --> Output Class Initialized
INFO - 2023-04-20 09:43:22 --> Security Class Initialized
DEBUG - 2023-04-20 09:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:43:22 --> Input Class Initialized
INFO - 2023-04-20 09:43:22 --> Language Class Initialized
INFO - 2023-04-20 09:43:22 --> Loader Class Initialized
INFO - 2023-04-20 09:43:22 --> Helper loaded: url_helper
INFO - 2023-04-20 09:43:22 --> Helper loaded: file_helper
INFO - 2023-04-20 09:43:22 --> Helper loaded: html_helper
INFO - 2023-04-20 09:43:22 --> Helper loaded: text_helper
INFO - 2023-04-20 09:43:22 --> Helper loaded: form_helper
INFO - 2023-04-20 09:43:22 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:43:22 --> Helper loaded: security_helper
INFO - 2023-04-20 09:43:22 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:43:22 --> Database Driver Class Initialized
INFO - 2023-04-20 09:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:43:22 --> Parser Class Initialized
INFO - 2023-04-20 09:43:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:43:22 --> Pagination Class Initialized
INFO - 2023-04-20 09:43:22 --> Form Validation Class Initialized
INFO - 2023-04-20 09:43:22 --> Controller Class Initialized
INFO - 2023-04-20 09:43:22 --> Model Class Initialized
DEBUG - 2023-04-20 09:43:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:43:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:43:22 --> Model Class Initialized
INFO - 2023-04-20 09:43:22 --> Final output sent to browser
DEBUG - 2023-04-20 09:43:22 --> Total execution time: 0.0294
ERROR - 2023-04-20 09:43:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:43:51 --> Config Class Initialized
INFO - 2023-04-20 09:43:51 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:43:51 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:43:51 --> Utf8 Class Initialized
INFO - 2023-04-20 09:43:51 --> URI Class Initialized
INFO - 2023-04-20 09:43:51 --> Router Class Initialized
INFO - 2023-04-20 09:43:51 --> Output Class Initialized
INFO - 2023-04-20 09:43:51 --> Security Class Initialized
DEBUG - 2023-04-20 09:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:43:51 --> Input Class Initialized
INFO - 2023-04-20 09:43:51 --> Language Class Initialized
INFO - 2023-04-20 09:43:51 --> Loader Class Initialized
INFO - 2023-04-20 09:43:51 --> Helper loaded: url_helper
INFO - 2023-04-20 09:43:51 --> Helper loaded: file_helper
INFO - 2023-04-20 09:43:51 --> Helper loaded: html_helper
INFO - 2023-04-20 09:43:51 --> Helper loaded: text_helper
INFO - 2023-04-20 09:43:51 --> Helper loaded: form_helper
INFO - 2023-04-20 09:43:51 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:43:51 --> Helper loaded: security_helper
INFO - 2023-04-20 09:43:51 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:43:51 --> Database Driver Class Initialized
INFO - 2023-04-20 09:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:43:51 --> Parser Class Initialized
INFO - 2023-04-20 09:43:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:43:51 --> Pagination Class Initialized
INFO - 2023-04-20 09:43:51 --> Form Validation Class Initialized
INFO - 2023-04-20 09:43:51 --> Controller Class Initialized
INFO - 2023-04-20 09:43:51 --> Model Class Initialized
DEBUG - 2023-04-20 09:43:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:43:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:43:51 --> Model Class Initialized
INFO - 2023-04-20 09:43:51 --> Final output sent to browser
DEBUG - 2023-04-20 09:43:51 --> Total execution time: 0.0397
ERROR - 2023-04-20 09:43:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:43:55 --> Config Class Initialized
INFO - 2023-04-20 09:43:55 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:43:55 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:43:55 --> Utf8 Class Initialized
INFO - 2023-04-20 09:43:55 --> URI Class Initialized
INFO - 2023-04-20 09:43:55 --> Router Class Initialized
INFO - 2023-04-20 09:43:55 --> Output Class Initialized
INFO - 2023-04-20 09:43:55 --> Security Class Initialized
DEBUG - 2023-04-20 09:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:43:55 --> Input Class Initialized
INFO - 2023-04-20 09:43:55 --> Language Class Initialized
INFO - 2023-04-20 09:43:55 --> Loader Class Initialized
INFO - 2023-04-20 09:43:55 --> Helper loaded: url_helper
INFO - 2023-04-20 09:43:55 --> Helper loaded: file_helper
INFO - 2023-04-20 09:43:55 --> Helper loaded: html_helper
INFO - 2023-04-20 09:43:55 --> Helper loaded: text_helper
INFO - 2023-04-20 09:43:55 --> Helper loaded: form_helper
INFO - 2023-04-20 09:43:55 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:43:55 --> Helper loaded: security_helper
INFO - 2023-04-20 09:43:55 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:43:55 --> Database Driver Class Initialized
INFO - 2023-04-20 09:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:43:55 --> Parser Class Initialized
INFO - 2023-04-20 09:43:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:43:55 --> Pagination Class Initialized
INFO - 2023-04-20 09:43:55 --> Form Validation Class Initialized
INFO - 2023-04-20 09:43:55 --> Controller Class Initialized
INFO - 2023-04-20 09:43:55 --> Model Class Initialized
DEBUG - 2023-04-20 09:43:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:43:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:43:55 --> Model Class Initialized
INFO - 2023-04-20 09:43:55 --> Final output sent to browser
DEBUG - 2023-04-20 09:43:55 --> Total execution time: 0.0344
ERROR - 2023-04-20 09:44:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:44:17 --> Config Class Initialized
INFO - 2023-04-20 09:44:17 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:44:17 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:44:17 --> Utf8 Class Initialized
INFO - 2023-04-20 09:44:17 --> URI Class Initialized
INFO - 2023-04-20 09:44:17 --> Router Class Initialized
INFO - 2023-04-20 09:44:17 --> Output Class Initialized
INFO - 2023-04-20 09:44:17 --> Security Class Initialized
DEBUG - 2023-04-20 09:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:44:17 --> Input Class Initialized
INFO - 2023-04-20 09:44:17 --> Language Class Initialized
INFO - 2023-04-20 09:44:17 --> Loader Class Initialized
INFO - 2023-04-20 09:44:17 --> Helper loaded: url_helper
INFO - 2023-04-20 09:44:17 --> Helper loaded: file_helper
INFO - 2023-04-20 09:44:17 --> Helper loaded: html_helper
INFO - 2023-04-20 09:44:17 --> Helper loaded: text_helper
INFO - 2023-04-20 09:44:17 --> Helper loaded: form_helper
INFO - 2023-04-20 09:44:17 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:44:17 --> Helper loaded: security_helper
INFO - 2023-04-20 09:44:17 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:44:17 --> Database Driver Class Initialized
INFO - 2023-04-20 09:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:44:17 --> Parser Class Initialized
INFO - 2023-04-20 09:44:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:44:17 --> Pagination Class Initialized
INFO - 2023-04-20 09:44:17 --> Form Validation Class Initialized
INFO - 2023-04-20 09:44:17 --> Controller Class Initialized
INFO - 2023-04-20 09:44:17 --> Model Class Initialized
DEBUG - 2023-04-20 09:44:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:44:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:44:17 --> Model Class Initialized
DEBUG - 2023-04-20 09:44:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:44:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-04-20 09:44:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:44:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 09:44:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 09:44:17 --> Model Class Initialized
INFO - 2023-04-20 09:44:17 --> Model Class Initialized
INFO - 2023-04-20 09:44:17 --> Model Class Initialized
INFO - 2023-04-20 09:44:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 09:44:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 09:44:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 09:44:17 --> Final output sent to browser
DEBUG - 2023-04-20 09:44:17 --> Total execution time: 0.1429
ERROR - 2023-04-20 09:44:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:44:38 --> Config Class Initialized
INFO - 2023-04-20 09:44:38 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:44:38 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:44:38 --> Utf8 Class Initialized
INFO - 2023-04-20 09:44:38 --> URI Class Initialized
INFO - 2023-04-20 09:44:38 --> Router Class Initialized
INFO - 2023-04-20 09:44:38 --> Output Class Initialized
INFO - 2023-04-20 09:44:38 --> Security Class Initialized
DEBUG - 2023-04-20 09:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:44:38 --> Input Class Initialized
INFO - 2023-04-20 09:44:38 --> Language Class Initialized
INFO - 2023-04-20 09:44:38 --> Loader Class Initialized
INFO - 2023-04-20 09:44:38 --> Helper loaded: url_helper
INFO - 2023-04-20 09:44:38 --> Helper loaded: file_helper
INFO - 2023-04-20 09:44:38 --> Helper loaded: html_helper
INFO - 2023-04-20 09:44:38 --> Helper loaded: text_helper
INFO - 2023-04-20 09:44:38 --> Helper loaded: form_helper
INFO - 2023-04-20 09:44:38 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:44:38 --> Helper loaded: security_helper
INFO - 2023-04-20 09:44:38 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:44:38 --> Database Driver Class Initialized
INFO - 2023-04-20 09:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:44:38 --> Parser Class Initialized
INFO - 2023-04-20 09:44:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:44:38 --> Pagination Class Initialized
INFO - 2023-04-20 09:44:38 --> Form Validation Class Initialized
INFO - 2023-04-20 09:44:38 --> Controller Class Initialized
INFO - 2023-04-20 09:44:38 --> Model Class Initialized
DEBUG - 2023-04-20 09:44:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:44:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:44:38 --> Model Class Initialized
INFO - 2023-04-20 09:44:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-04-20 09:44:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:44:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 09:44:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 09:44:38 --> Model Class Initialized
INFO - 2023-04-20 09:44:38 --> Model Class Initialized
INFO - 2023-04-20 09:44:38 --> Model Class Initialized
INFO - 2023-04-20 09:44:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 09:44:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 09:44:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 09:44:38 --> Final output sent to browser
DEBUG - 2023-04-20 09:44:38 --> Total execution time: 0.1577
ERROR - 2023-04-20 09:44:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:44:39 --> Config Class Initialized
INFO - 2023-04-20 09:44:39 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:44:39 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:44:39 --> Utf8 Class Initialized
INFO - 2023-04-20 09:44:39 --> URI Class Initialized
INFO - 2023-04-20 09:44:39 --> Router Class Initialized
INFO - 2023-04-20 09:44:39 --> Output Class Initialized
INFO - 2023-04-20 09:44:39 --> Security Class Initialized
DEBUG - 2023-04-20 09:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:44:39 --> Input Class Initialized
INFO - 2023-04-20 09:44:39 --> Language Class Initialized
INFO - 2023-04-20 09:44:39 --> Loader Class Initialized
INFO - 2023-04-20 09:44:39 --> Helper loaded: url_helper
INFO - 2023-04-20 09:44:39 --> Helper loaded: file_helper
INFO - 2023-04-20 09:44:39 --> Helper loaded: html_helper
INFO - 2023-04-20 09:44:39 --> Helper loaded: text_helper
INFO - 2023-04-20 09:44:39 --> Helper loaded: form_helper
INFO - 2023-04-20 09:44:39 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:44:39 --> Helper loaded: security_helper
INFO - 2023-04-20 09:44:39 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:44:39 --> Database Driver Class Initialized
INFO - 2023-04-20 09:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:44:39 --> Parser Class Initialized
INFO - 2023-04-20 09:44:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:44:39 --> Pagination Class Initialized
INFO - 2023-04-20 09:44:39 --> Form Validation Class Initialized
INFO - 2023-04-20 09:44:39 --> Controller Class Initialized
INFO - 2023-04-20 09:44:39 --> Model Class Initialized
DEBUG - 2023-04-20 09:44:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:44:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:44:39 --> Model Class Initialized
INFO - 2023-04-20 09:44:39 --> Final output sent to browser
DEBUG - 2023-04-20 09:44:39 --> Total execution time: 0.0309
ERROR - 2023-04-20 09:44:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:44:43 --> Config Class Initialized
INFO - 2023-04-20 09:44:43 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:44:43 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:44:43 --> Utf8 Class Initialized
INFO - 2023-04-20 09:44:43 --> URI Class Initialized
INFO - 2023-04-20 09:44:43 --> Router Class Initialized
INFO - 2023-04-20 09:44:43 --> Output Class Initialized
INFO - 2023-04-20 09:44:43 --> Security Class Initialized
DEBUG - 2023-04-20 09:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:44:43 --> Input Class Initialized
INFO - 2023-04-20 09:44:43 --> Language Class Initialized
INFO - 2023-04-20 09:44:43 --> Loader Class Initialized
INFO - 2023-04-20 09:44:43 --> Helper loaded: url_helper
INFO - 2023-04-20 09:44:43 --> Helper loaded: file_helper
INFO - 2023-04-20 09:44:43 --> Helper loaded: html_helper
INFO - 2023-04-20 09:44:43 --> Helper loaded: text_helper
INFO - 2023-04-20 09:44:43 --> Helper loaded: form_helper
INFO - 2023-04-20 09:44:43 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:44:43 --> Helper loaded: security_helper
INFO - 2023-04-20 09:44:43 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:44:43 --> Database Driver Class Initialized
INFO - 2023-04-20 09:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:44:43 --> Parser Class Initialized
INFO - 2023-04-20 09:44:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:44:43 --> Pagination Class Initialized
INFO - 2023-04-20 09:44:43 --> Form Validation Class Initialized
INFO - 2023-04-20 09:44:43 --> Controller Class Initialized
INFO - 2023-04-20 09:44:43 --> Model Class Initialized
DEBUG - 2023-04-20 09:44:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:44:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:44:43 --> Model Class Initialized
INFO - 2023-04-20 09:44:43 --> Final output sent to browser
DEBUG - 2023-04-20 09:44:43 --> Total execution time: 0.0340
ERROR - 2023-04-20 09:44:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:44:47 --> Config Class Initialized
INFO - 2023-04-20 09:44:47 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:44:47 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:44:47 --> Utf8 Class Initialized
INFO - 2023-04-20 09:44:47 --> URI Class Initialized
INFO - 2023-04-20 09:44:47 --> Router Class Initialized
INFO - 2023-04-20 09:44:47 --> Output Class Initialized
INFO - 2023-04-20 09:44:47 --> Security Class Initialized
DEBUG - 2023-04-20 09:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:44:47 --> Input Class Initialized
INFO - 2023-04-20 09:44:47 --> Language Class Initialized
INFO - 2023-04-20 09:44:47 --> Loader Class Initialized
INFO - 2023-04-20 09:44:47 --> Helper loaded: url_helper
INFO - 2023-04-20 09:44:47 --> Helper loaded: file_helper
INFO - 2023-04-20 09:44:47 --> Helper loaded: html_helper
INFO - 2023-04-20 09:44:47 --> Helper loaded: text_helper
INFO - 2023-04-20 09:44:47 --> Helper loaded: form_helper
INFO - 2023-04-20 09:44:47 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:44:47 --> Helper loaded: security_helper
INFO - 2023-04-20 09:44:47 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:44:47 --> Database Driver Class Initialized
INFO - 2023-04-20 09:44:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:44:47 --> Parser Class Initialized
INFO - 2023-04-20 09:44:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:44:47 --> Pagination Class Initialized
INFO - 2023-04-20 09:44:47 --> Form Validation Class Initialized
INFO - 2023-04-20 09:44:47 --> Controller Class Initialized
INFO - 2023-04-20 09:44:47 --> Model Class Initialized
DEBUG - 2023-04-20 09:44:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:44:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:44:47 --> Model Class Initialized
DEBUG - 2023-04-20 09:44:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:44:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-04-20 09:44:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:44:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 09:44:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 09:44:47 --> Model Class Initialized
INFO - 2023-04-20 09:44:47 --> Model Class Initialized
INFO - 2023-04-20 09:44:47 --> Model Class Initialized
INFO - 2023-04-20 09:44:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 09:44:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 09:44:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 09:44:47 --> Final output sent to browser
DEBUG - 2023-04-20 09:44:47 --> Total execution time: 0.1476
ERROR - 2023-04-20 09:44:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:44:50 --> Config Class Initialized
INFO - 2023-04-20 09:44:50 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:44:50 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:44:50 --> Utf8 Class Initialized
INFO - 2023-04-20 09:44:50 --> URI Class Initialized
INFO - 2023-04-20 09:44:50 --> Router Class Initialized
INFO - 2023-04-20 09:44:50 --> Output Class Initialized
INFO - 2023-04-20 09:44:50 --> Security Class Initialized
DEBUG - 2023-04-20 09:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:44:50 --> Input Class Initialized
INFO - 2023-04-20 09:44:50 --> Language Class Initialized
INFO - 2023-04-20 09:44:50 --> Loader Class Initialized
INFO - 2023-04-20 09:44:50 --> Helper loaded: url_helper
INFO - 2023-04-20 09:44:50 --> Helper loaded: file_helper
INFO - 2023-04-20 09:44:50 --> Helper loaded: html_helper
INFO - 2023-04-20 09:44:50 --> Helper loaded: text_helper
INFO - 2023-04-20 09:44:50 --> Helper loaded: form_helper
INFO - 2023-04-20 09:44:50 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:44:50 --> Helper loaded: security_helper
INFO - 2023-04-20 09:44:50 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:44:50 --> Database Driver Class Initialized
INFO - 2023-04-20 09:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:44:50 --> Parser Class Initialized
INFO - 2023-04-20 09:44:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:44:50 --> Pagination Class Initialized
INFO - 2023-04-20 09:44:50 --> Form Validation Class Initialized
INFO - 2023-04-20 09:44:50 --> Controller Class Initialized
INFO - 2023-04-20 09:44:50 --> Model Class Initialized
DEBUG - 2023-04-20 09:44:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:44:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:44:50 --> Model Class Initialized
INFO - 2023-04-20 09:44:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest.php
DEBUG - 2023-04-20 09:44:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:44:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 09:44:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 09:44:50 --> Model Class Initialized
INFO - 2023-04-20 09:44:50 --> Model Class Initialized
INFO - 2023-04-20 09:44:50 --> Model Class Initialized
INFO - 2023-04-20 09:44:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 09:44:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 09:44:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 09:44:51 --> Final output sent to browser
DEBUG - 2023-04-20 09:44:51 --> Total execution time: 0.1624
ERROR - 2023-04-20 09:44:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:44:51 --> Config Class Initialized
INFO - 2023-04-20 09:44:51 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:44:51 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:44:51 --> Utf8 Class Initialized
INFO - 2023-04-20 09:44:51 --> URI Class Initialized
INFO - 2023-04-20 09:44:51 --> Router Class Initialized
INFO - 2023-04-20 09:44:51 --> Output Class Initialized
INFO - 2023-04-20 09:44:51 --> Security Class Initialized
DEBUG - 2023-04-20 09:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:44:51 --> Input Class Initialized
INFO - 2023-04-20 09:44:51 --> Language Class Initialized
INFO - 2023-04-20 09:44:51 --> Loader Class Initialized
INFO - 2023-04-20 09:44:51 --> Helper loaded: url_helper
INFO - 2023-04-20 09:44:51 --> Helper loaded: file_helper
INFO - 2023-04-20 09:44:51 --> Helper loaded: html_helper
INFO - 2023-04-20 09:44:51 --> Helper loaded: text_helper
INFO - 2023-04-20 09:44:51 --> Helper loaded: form_helper
INFO - 2023-04-20 09:44:51 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:44:51 --> Helper loaded: security_helper
INFO - 2023-04-20 09:44:51 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:44:51 --> Database Driver Class Initialized
INFO - 2023-04-20 09:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:44:51 --> Parser Class Initialized
INFO - 2023-04-20 09:44:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:44:51 --> Pagination Class Initialized
INFO - 2023-04-20 09:44:51 --> Form Validation Class Initialized
INFO - 2023-04-20 09:44:51 --> Controller Class Initialized
INFO - 2023-04-20 09:44:51 --> Model Class Initialized
DEBUG - 2023-04-20 09:44:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:44:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:44:51 --> Model Class Initialized
INFO - 2023-04-20 09:44:51 --> Final output sent to browser
DEBUG - 2023-04-20 09:44:51 --> Total execution time: 0.0148
ERROR - 2023-04-20 09:44:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:44:55 --> Config Class Initialized
INFO - 2023-04-20 09:44:55 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:44:55 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:44:55 --> Utf8 Class Initialized
INFO - 2023-04-20 09:44:55 --> URI Class Initialized
INFO - 2023-04-20 09:44:55 --> Router Class Initialized
INFO - 2023-04-20 09:44:55 --> Output Class Initialized
INFO - 2023-04-20 09:44:55 --> Security Class Initialized
DEBUG - 2023-04-20 09:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:44:55 --> Input Class Initialized
INFO - 2023-04-20 09:44:55 --> Language Class Initialized
INFO - 2023-04-20 09:44:55 --> Loader Class Initialized
INFO - 2023-04-20 09:44:55 --> Helper loaded: url_helper
INFO - 2023-04-20 09:44:55 --> Helper loaded: file_helper
INFO - 2023-04-20 09:44:55 --> Helper loaded: html_helper
INFO - 2023-04-20 09:44:55 --> Helper loaded: text_helper
INFO - 2023-04-20 09:44:55 --> Helper loaded: form_helper
INFO - 2023-04-20 09:44:55 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:44:55 --> Helper loaded: security_helper
INFO - 2023-04-20 09:44:55 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:44:55 --> Database Driver Class Initialized
INFO - 2023-04-20 09:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:44:55 --> Parser Class Initialized
INFO - 2023-04-20 09:44:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:44:55 --> Pagination Class Initialized
INFO - 2023-04-20 09:44:55 --> Form Validation Class Initialized
INFO - 2023-04-20 09:44:55 --> Controller Class Initialized
INFO - 2023-04-20 09:44:55 --> Model Class Initialized
DEBUG - 2023-04-20 09:44:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:44:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:44:55 --> Model Class Initialized
INFO - 2023-04-20 09:44:55 --> Final output sent to browser
DEBUG - 2023-04-20 09:44:55 --> Total execution time: 0.0215
ERROR - 2023-04-20 09:44:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:44:57 --> Config Class Initialized
INFO - 2023-04-20 09:44:57 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:44:57 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:44:57 --> Utf8 Class Initialized
INFO - 2023-04-20 09:44:57 --> URI Class Initialized
INFO - 2023-04-20 09:44:57 --> Router Class Initialized
INFO - 2023-04-20 09:44:57 --> Output Class Initialized
INFO - 2023-04-20 09:44:57 --> Security Class Initialized
DEBUG - 2023-04-20 09:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:44:57 --> Input Class Initialized
INFO - 2023-04-20 09:44:57 --> Language Class Initialized
INFO - 2023-04-20 09:44:57 --> Loader Class Initialized
INFO - 2023-04-20 09:44:57 --> Helper loaded: url_helper
INFO - 2023-04-20 09:44:57 --> Helper loaded: file_helper
INFO - 2023-04-20 09:44:57 --> Helper loaded: html_helper
INFO - 2023-04-20 09:44:57 --> Helper loaded: text_helper
INFO - 2023-04-20 09:44:57 --> Helper loaded: form_helper
INFO - 2023-04-20 09:44:57 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:44:57 --> Helper loaded: security_helper
INFO - 2023-04-20 09:44:57 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:44:57 --> Database Driver Class Initialized
INFO - 2023-04-20 09:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:44:57 --> Parser Class Initialized
INFO - 2023-04-20 09:44:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:44:57 --> Pagination Class Initialized
INFO - 2023-04-20 09:44:57 --> Form Validation Class Initialized
INFO - 2023-04-20 09:44:57 --> Controller Class Initialized
INFO - 2023-04-20 09:44:57 --> Model Class Initialized
DEBUG - 2023-04-20 09:44:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:44:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:44:57 --> Model Class Initialized
INFO - 2023-04-20 09:44:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-04-20 09:44:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:44:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 09:44:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 09:44:57 --> Model Class Initialized
INFO - 2023-04-20 09:44:57 --> Model Class Initialized
INFO - 2023-04-20 09:44:57 --> Model Class Initialized
INFO - 2023-04-20 09:44:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 09:44:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 09:44:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 09:44:57 --> Final output sent to browser
DEBUG - 2023-04-20 09:44:57 --> Total execution time: 0.1449
ERROR - 2023-04-20 09:44:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:44:58 --> Config Class Initialized
INFO - 2023-04-20 09:44:58 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:44:58 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:44:58 --> Utf8 Class Initialized
INFO - 2023-04-20 09:44:58 --> URI Class Initialized
INFO - 2023-04-20 09:44:58 --> Router Class Initialized
INFO - 2023-04-20 09:44:58 --> Output Class Initialized
INFO - 2023-04-20 09:44:58 --> Security Class Initialized
DEBUG - 2023-04-20 09:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:44:58 --> Input Class Initialized
INFO - 2023-04-20 09:44:58 --> Language Class Initialized
INFO - 2023-04-20 09:44:58 --> Loader Class Initialized
INFO - 2023-04-20 09:44:58 --> Helper loaded: url_helper
INFO - 2023-04-20 09:44:58 --> Helper loaded: file_helper
INFO - 2023-04-20 09:44:58 --> Helper loaded: html_helper
INFO - 2023-04-20 09:44:58 --> Helper loaded: text_helper
INFO - 2023-04-20 09:44:58 --> Helper loaded: form_helper
INFO - 2023-04-20 09:44:58 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:44:58 --> Helper loaded: security_helper
INFO - 2023-04-20 09:44:58 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:44:58 --> Database Driver Class Initialized
INFO - 2023-04-20 09:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:44:58 --> Parser Class Initialized
INFO - 2023-04-20 09:44:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:44:58 --> Pagination Class Initialized
INFO - 2023-04-20 09:44:58 --> Form Validation Class Initialized
INFO - 2023-04-20 09:44:58 --> Controller Class Initialized
INFO - 2023-04-20 09:44:58 --> Model Class Initialized
DEBUG - 2023-04-20 09:44:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:44:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:44:58 --> Model Class Initialized
INFO - 2023-04-20 09:44:58 --> Final output sent to browser
DEBUG - 2023-04-20 09:44:58 --> Total execution time: 0.0278
ERROR - 2023-04-20 09:45:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:45:32 --> Config Class Initialized
INFO - 2023-04-20 09:45:32 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:45:32 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:45:32 --> Utf8 Class Initialized
INFO - 2023-04-20 09:45:32 --> URI Class Initialized
INFO - 2023-04-20 09:45:32 --> Router Class Initialized
INFO - 2023-04-20 09:45:32 --> Output Class Initialized
INFO - 2023-04-20 09:45:32 --> Security Class Initialized
DEBUG - 2023-04-20 09:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:45:32 --> Input Class Initialized
INFO - 2023-04-20 09:45:32 --> Language Class Initialized
INFO - 2023-04-20 09:45:32 --> Loader Class Initialized
INFO - 2023-04-20 09:45:32 --> Helper loaded: url_helper
INFO - 2023-04-20 09:45:32 --> Helper loaded: file_helper
INFO - 2023-04-20 09:45:32 --> Helper loaded: html_helper
INFO - 2023-04-20 09:45:32 --> Helper loaded: text_helper
INFO - 2023-04-20 09:45:32 --> Helper loaded: form_helper
INFO - 2023-04-20 09:45:32 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:45:32 --> Helper loaded: security_helper
INFO - 2023-04-20 09:45:32 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:45:32 --> Database Driver Class Initialized
INFO - 2023-04-20 09:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:45:32 --> Parser Class Initialized
INFO - 2023-04-20 09:45:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:45:32 --> Pagination Class Initialized
INFO - 2023-04-20 09:45:32 --> Form Validation Class Initialized
INFO - 2023-04-20 09:45:32 --> Controller Class Initialized
DEBUG - 2023-04-20 09:45:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:45:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:45:32 --> Model Class Initialized
DEBUG - 2023-04-20 09:45:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:45:32 --> Model Class Initialized
DEBUG - 2023-04-20 09:45:32 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:45:32 --> Model Class Initialized
INFO - 2023-04-20 09:45:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-04-20 09:45:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:45:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 09:45:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 09:45:32 --> Model Class Initialized
INFO - 2023-04-20 09:45:32 --> Model Class Initialized
INFO - 2023-04-20 09:45:32 --> Model Class Initialized
INFO - 2023-04-20 09:45:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 09:45:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 09:45:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 09:45:32 --> Final output sent to browser
DEBUG - 2023-04-20 09:45:32 --> Total execution time: 0.1468
ERROR - 2023-04-20 09:45:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:45:33 --> Config Class Initialized
INFO - 2023-04-20 09:45:33 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:45:33 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:45:33 --> Utf8 Class Initialized
INFO - 2023-04-20 09:45:33 --> URI Class Initialized
INFO - 2023-04-20 09:45:33 --> Router Class Initialized
INFO - 2023-04-20 09:45:33 --> Output Class Initialized
INFO - 2023-04-20 09:45:33 --> Security Class Initialized
DEBUG - 2023-04-20 09:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:45:33 --> Input Class Initialized
INFO - 2023-04-20 09:45:33 --> Language Class Initialized
INFO - 2023-04-20 09:45:33 --> Loader Class Initialized
INFO - 2023-04-20 09:45:33 --> Helper loaded: url_helper
INFO - 2023-04-20 09:45:33 --> Helper loaded: file_helper
INFO - 2023-04-20 09:45:33 --> Helper loaded: html_helper
INFO - 2023-04-20 09:45:33 --> Helper loaded: text_helper
INFO - 2023-04-20 09:45:33 --> Helper loaded: form_helper
INFO - 2023-04-20 09:45:33 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:45:33 --> Helper loaded: security_helper
INFO - 2023-04-20 09:45:33 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:45:33 --> Database Driver Class Initialized
INFO - 2023-04-20 09:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:45:33 --> Parser Class Initialized
INFO - 2023-04-20 09:45:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:45:33 --> Pagination Class Initialized
INFO - 2023-04-20 09:45:33 --> Form Validation Class Initialized
INFO - 2023-04-20 09:45:33 --> Controller Class Initialized
DEBUG - 2023-04-20 09:45:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:45:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:45:33 --> Model Class Initialized
DEBUG - 2023-04-20 09:45:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:45:33 --> Model Class Initialized
INFO - 2023-04-20 09:45:33 --> Final output sent to browser
DEBUG - 2023-04-20 09:45:33 --> Total execution time: 0.0301
ERROR - 2023-04-20 09:45:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:45:41 --> Config Class Initialized
INFO - 2023-04-20 09:45:41 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:45:41 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:45:41 --> Utf8 Class Initialized
INFO - 2023-04-20 09:45:41 --> URI Class Initialized
INFO - 2023-04-20 09:45:41 --> Router Class Initialized
INFO - 2023-04-20 09:45:41 --> Output Class Initialized
INFO - 2023-04-20 09:45:41 --> Security Class Initialized
DEBUG - 2023-04-20 09:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:45:41 --> Input Class Initialized
INFO - 2023-04-20 09:45:41 --> Language Class Initialized
INFO - 2023-04-20 09:45:41 --> Loader Class Initialized
INFO - 2023-04-20 09:45:41 --> Helper loaded: url_helper
INFO - 2023-04-20 09:45:41 --> Helper loaded: file_helper
INFO - 2023-04-20 09:45:41 --> Helper loaded: html_helper
INFO - 2023-04-20 09:45:41 --> Helper loaded: text_helper
INFO - 2023-04-20 09:45:41 --> Helper loaded: form_helper
INFO - 2023-04-20 09:45:41 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:45:41 --> Helper loaded: security_helper
INFO - 2023-04-20 09:45:41 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:45:41 --> Database Driver Class Initialized
INFO - 2023-04-20 09:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:45:41 --> Parser Class Initialized
INFO - 2023-04-20 09:45:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:45:41 --> Pagination Class Initialized
INFO - 2023-04-20 09:45:41 --> Form Validation Class Initialized
INFO - 2023-04-20 09:45:41 --> Controller Class Initialized
DEBUG - 2023-04-20 09:45:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:45:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:45:41 --> Model Class Initialized
DEBUG - 2023-04-20 09:45:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:45:41 --> Model Class Initialized
INFO - 2023-04-20 09:45:42 --> Final output sent to browser
DEBUG - 2023-04-20 09:45:42 --> Total execution time: 0.0878
ERROR - 2023-04-20 09:47:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:47:16 --> Config Class Initialized
INFO - 2023-04-20 09:47:16 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:47:16 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:47:16 --> Utf8 Class Initialized
INFO - 2023-04-20 09:47:16 --> URI Class Initialized
INFO - 2023-04-20 09:47:16 --> Router Class Initialized
INFO - 2023-04-20 09:47:16 --> Output Class Initialized
INFO - 2023-04-20 09:47:16 --> Security Class Initialized
DEBUG - 2023-04-20 09:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:47:16 --> Input Class Initialized
INFO - 2023-04-20 09:47:16 --> Language Class Initialized
INFO - 2023-04-20 09:47:16 --> Loader Class Initialized
INFO - 2023-04-20 09:47:16 --> Helper loaded: url_helper
INFO - 2023-04-20 09:47:16 --> Helper loaded: file_helper
INFO - 2023-04-20 09:47:16 --> Helper loaded: html_helper
INFO - 2023-04-20 09:47:16 --> Helper loaded: text_helper
INFO - 2023-04-20 09:47:16 --> Helper loaded: form_helper
INFO - 2023-04-20 09:47:16 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:47:16 --> Helper loaded: security_helper
INFO - 2023-04-20 09:47:16 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:47:16 --> Database Driver Class Initialized
INFO - 2023-04-20 09:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:47:16 --> Parser Class Initialized
INFO - 2023-04-20 09:47:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:47:16 --> Pagination Class Initialized
INFO - 2023-04-20 09:47:16 --> Form Validation Class Initialized
INFO - 2023-04-20 09:47:16 --> Controller Class Initialized
DEBUG - 2023-04-20 09:47:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:47:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:47:16 --> Model Class Initialized
DEBUG - 2023-04-20 09:47:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:47:16 --> Model Class Initialized
DEBUG - 2023-04-20 09:47:16 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:47:16 --> Model Class Initialized
INFO - 2023-04-20 09:47:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-04-20 09:47:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:47:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 09:47:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 09:47:16 --> Model Class Initialized
INFO - 2023-04-20 09:47:16 --> Model Class Initialized
INFO - 2023-04-20 09:47:16 --> Model Class Initialized
INFO - 2023-04-20 09:47:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 09:47:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 09:47:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 09:47:17 --> Final output sent to browser
DEBUG - 2023-04-20 09:47:17 --> Total execution time: 0.1568
ERROR - 2023-04-20 09:47:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:47:17 --> Config Class Initialized
INFO - 2023-04-20 09:47:17 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:47:17 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:47:17 --> Utf8 Class Initialized
INFO - 2023-04-20 09:47:17 --> URI Class Initialized
INFO - 2023-04-20 09:47:17 --> Router Class Initialized
INFO - 2023-04-20 09:47:17 --> Output Class Initialized
INFO - 2023-04-20 09:47:17 --> Security Class Initialized
DEBUG - 2023-04-20 09:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:47:17 --> Input Class Initialized
INFO - 2023-04-20 09:47:17 --> Language Class Initialized
INFO - 2023-04-20 09:47:17 --> Loader Class Initialized
INFO - 2023-04-20 09:47:17 --> Helper loaded: url_helper
INFO - 2023-04-20 09:47:17 --> Helper loaded: file_helper
INFO - 2023-04-20 09:47:17 --> Helper loaded: html_helper
INFO - 2023-04-20 09:47:17 --> Helper loaded: text_helper
INFO - 2023-04-20 09:47:17 --> Helper loaded: form_helper
INFO - 2023-04-20 09:47:17 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:47:17 --> Helper loaded: security_helper
INFO - 2023-04-20 09:47:17 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:47:17 --> Database Driver Class Initialized
INFO - 2023-04-20 09:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:47:17 --> Parser Class Initialized
INFO - 2023-04-20 09:47:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:47:17 --> Pagination Class Initialized
INFO - 2023-04-20 09:47:17 --> Form Validation Class Initialized
INFO - 2023-04-20 09:47:17 --> Controller Class Initialized
DEBUG - 2023-04-20 09:47:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:47:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:47:17 --> Model Class Initialized
DEBUG - 2023-04-20 09:47:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:47:17 --> Model Class Initialized
INFO - 2023-04-20 09:47:17 --> Final output sent to browser
DEBUG - 2023-04-20 09:47:17 --> Total execution time: 0.0369
ERROR - 2023-04-20 09:47:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:47:22 --> Config Class Initialized
INFO - 2023-04-20 09:47:22 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:47:22 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:47:22 --> Utf8 Class Initialized
INFO - 2023-04-20 09:47:22 --> URI Class Initialized
INFO - 2023-04-20 09:47:22 --> Router Class Initialized
INFO - 2023-04-20 09:47:22 --> Output Class Initialized
INFO - 2023-04-20 09:47:22 --> Security Class Initialized
DEBUG - 2023-04-20 09:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:47:22 --> Input Class Initialized
INFO - 2023-04-20 09:47:22 --> Language Class Initialized
INFO - 2023-04-20 09:47:22 --> Loader Class Initialized
INFO - 2023-04-20 09:47:22 --> Helper loaded: url_helper
INFO - 2023-04-20 09:47:22 --> Helper loaded: file_helper
INFO - 2023-04-20 09:47:22 --> Helper loaded: html_helper
INFO - 2023-04-20 09:47:22 --> Helper loaded: text_helper
INFO - 2023-04-20 09:47:22 --> Helper loaded: form_helper
INFO - 2023-04-20 09:47:22 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:47:22 --> Helper loaded: security_helper
INFO - 2023-04-20 09:47:22 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:47:22 --> Database Driver Class Initialized
INFO - 2023-04-20 09:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:47:22 --> Parser Class Initialized
INFO - 2023-04-20 09:47:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:47:22 --> Pagination Class Initialized
INFO - 2023-04-20 09:47:22 --> Form Validation Class Initialized
INFO - 2023-04-20 09:47:22 --> Controller Class Initialized
DEBUG - 2023-04-20 09:47:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:47:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:47:22 --> Model Class Initialized
DEBUG - 2023-04-20 09:47:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:47:22 --> Model Class Initialized
INFO - 2023-04-20 09:47:22 --> Final output sent to browser
DEBUG - 2023-04-20 09:47:22 --> Total execution time: 0.0955
ERROR - 2023-04-20 09:47:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:47:44 --> Config Class Initialized
INFO - 2023-04-20 09:47:44 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:47:44 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:47:44 --> Utf8 Class Initialized
INFO - 2023-04-20 09:47:44 --> URI Class Initialized
INFO - 2023-04-20 09:47:44 --> Router Class Initialized
INFO - 2023-04-20 09:47:44 --> Output Class Initialized
INFO - 2023-04-20 09:47:44 --> Security Class Initialized
DEBUG - 2023-04-20 09:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:47:44 --> Input Class Initialized
INFO - 2023-04-20 09:47:44 --> Language Class Initialized
INFO - 2023-04-20 09:47:44 --> Loader Class Initialized
INFO - 2023-04-20 09:47:44 --> Helper loaded: url_helper
INFO - 2023-04-20 09:47:44 --> Helper loaded: file_helper
INFO - 2023-04-20 09:47:44 --> Helper loaded: html_helper
INFO - 2023-04-20 09:47:44 --> Helper loaded: text_helper
INFO - 2023-04-20 09:47:44 --> Helper loaded: form_helper
INFO - 2023-04-20 09:47:44 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:47:44 --> Helper loaded: security_helper
INFO - 2023-04-20 09:47:44 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:47:44 --> Database Driver Class Initialized
INFO - 2023-04-20 09:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:47:44 --> Parser Class Initialized
INFO - 2023-04-20 09:47:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:47:44 --> Pagination Class Initialized
INFO - 2023-04-20 09:47:44 --> Form Validation Class Initialized
INFO - 2023-04-20 09:47:44 --> Controller Class Initialized
INFO - 2023-04-20 09:47:44 --> Model Class Initialized
DEBUG - 2023-04-20 09:47:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:47:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:47:44 --> Model Class Initialized
DEBUG - 2023-04-20 09:47:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:47:44 --> Model Class Initialized
INFO - 2023-04-20 09:47:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-04-20 09:47:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:47:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 09:47:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 09:47:44 --> Model Class Initialized
INFO - 2023-04-20 09:47:44 --> Model Class Initialized
INFO - 2023-04-20 09:47:44 --> Model Class Initialized
INFO - 2023-04-20 09:47:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 09:47:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 09:47:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 09:47:44 --> Final output sent to browser
DEBUG - 2023-04-20 09:47:44 --> Total execution time: 0.2020
ERROR - 2023-04-20 09:47:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:47:45 --> Config Class Initialized
INFO - 2023-04-20 09:47:45 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:47:45 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:47:45 --> Utf8 Class Initialized
INFO - 2023-04-20 09:47:45 --> URI Class Initialized
INFO - 2023-04-20 09:47:45 --> Router Class Initialized
INFO - 2023-04-20 09:47:45 --> Output Class Initialized
INFO - 2023-04-20 09:47:45 --> Security Class Initialized
DEBUG - 2023-04-20 09:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:47:45 --> Input Class Initialized
INFO - 2023-04-20 09:47:45 --> Language Class Initialized
INFO - 2023-04-20 09:47:45 --> Loader Class Initialized
INFO - 2023-04-20 09:47:45 --> Helper loaded: url_helper
INFO - 2023-04-20 09:47:45 --> Helper loaded: file_helper
INFO - 2023-04-20 09:47:45 --> Helper loaded: html_helper
INFO - 2023-04-20 09:47:45 --> Helper loaded: text_helper
INFO - 2023-04-20 09:47:45 --> Helper loaded: form_helper
INFO - 2023-04-20 09:47:45 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:47:45 --> Helper loaded: security_helper
INFO - 2023-04-20 09:47:45 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:47:45 --> Database Driver Class Initialized
INFO - 2023-04-20 09:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:47:45 --> Parser Class Initialized
INFO - 2023-04-20 09:47:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:47:45 --> Pagination Class Initialized
INFO - 2023-04-20 09:47:45 --> Form Validation Class Initialized
INFO - 2023-04-20 09:47:45 --> Controller Class Initialized
INFO - 2023-04-20 09:47:45 --> Model Class Initialized
DEBUG - 2023-04-20 09:47:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:47:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:47:45 --> Model Class Initialized
DEBUG - 2023-04-20 09:47:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:47:45 --> Model Class Initialized
INFO - 2023-04-20 09:47:45 --> Final output sent to browser
DEBUG - 2023-04-20 09:47:45 --> Total execution time: 0.0717
ERROR - 2023-04-20 09:48:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:48:12 --> Config Class Initialized
INFO - 2023-04-20 09:48:12 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:48:12 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:48:12 --> Utf8 Class Initialized
INFO - 2023-04-20 09:48:12 --> URI Class Initialized
INFO - 2023-04-20 09:48:12 --> Router Class Initialized
INFO - 2023-04-20 09:48:12 --> Output Class Initialized
INFO - 2023-04-20 09:48:12 --> Security Class Initialized
DEBUG - 2023-04-20 09:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:48:12 --> Input Class Initialized
INFO - 2023-04-20 09:48:12 --> Language Class Initialized
INFO - 2023-04-20 09:48:12 --> Loader Class Initialized
INFO - 2023-04-20 09:48:12 --> Helper loaded: url_helper
INFO - 2023-04-20 09:48:12 --> Helper loaded: file_helper
INFO - 2023-04-20 09:48:12 --> Helper loaded: html_helper
INFO - 2023-04-20 09:48:12 --> Helper loaded: text_helper
INFO - 2023-04-20 09:48:12 --> Helper loaded: form_helper
INFO - 2023-04-20 09:48:12 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:48:12 --> Helper loaded: security_helper
INFO - 2023-04-20 09:48:12 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:48:12 --> Database Driver Class Initialized
INFO - 2023-04-20 09:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:48:12 --> Parser Class Initialized
INFO - 2023-04-20 09:48:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:48:12 --> Pagination Class Initialized
INFO - 2023-04-20 09:48:12 --> Form Validation Class Initialized
INFO - 2023-04-20 09:48:12 --> Controller Class Initialized
DEBUG - 2023-04-20 09:48:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:48:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:48:12 --> Model Class Initialized
DEBUG - 2023-04-20 09:48:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:48:12 --> Model Class Initialized
DEBUG - 2023-04-20 09:48:12 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:48:12 --> Model Class Initialized
INFO - 2023-04-20 09:48:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-04-20 09:48:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:48:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 09:48:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 09:48:12 --> Model Class Initialized
INFO - 2023-04-20 09:48:12 --> Model Class Initialized
INFO - 2023-04-20 09:48:12 --> Model Class Initialized
INFO - 2023-04-20 09:48:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 09:48:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 09:48:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 09:48:13 --> Final output sent to browser
DEBUG - 2023-04-20 09:48:13 --> Total execution time: 0.1438
ERROR - 2023-04-20 09:48:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:48:14 --> Config Class Initialized
INFO - 2023-04-20 09:48:14 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:48:14 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:48:14 --> Utf8 Class Initialized
INFO - 2023-04-20 09:48:14 --> URI Class Initialized
INFO - 2023-04-20 09:48:14 --> Router Class Initialized
INFO - 2023-04-20 09:48:14 --> Output Class Initialized
INFO - 2023-04-20 09:48:14 --> Security Class Initialized
DEBUG - 2023-04-20 09:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:48:14 --> Input Class Initialized
INFO - 2023-04-20 09:48:14 --> Language Class Initialized
INFO - 2023-04-20 09:48:14 --> Loader Class Initialized
INFO - 2023-04-20 09:48:14 --> Helper loaded: url_helper
INFO - 2023-04-20 09:48:14 --> Helper loaded: file_helper
INFO - 2023-04-20 09:48:14 --> Helper loaded: html_helper
INFO - 2023-04-20 09:48:14 --> Helper loaded: text_helper
INFO - 2023-04-20 09:48:14 --> Helper loaded: form_helper
INFO - 2023-04-20 09:48:14 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:48:14 --> Helper loaded: security_helper
INFO - 2023-04-20 09:48:14 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:48:14 --> Database Driver Class Initialized
INFO - 2023-04-20 09:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:48:14 --> Parser Class Initialized
INFO - 2023-04-20 09:48:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:48:14 --> Pagination Class Initialized
INFO - 2023-04-20 09:48:14 --> Form Validation Class Initialized
INFO - 2023-04-20 09:48:14 --> Controller Class Initialized
DEBUG - 2023-04-20 09:48:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:48:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:48:14 --> Model Class Initialized
DEBUG - 2023-04-20 09:48:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:48:14 --> Model Class Initialized
INFO - 2023-04-20 09:48:14 --> Final output sent to browser
DEBUG - 2023-04-20 09:48:14 --> Total execution time: 0.0319
ERROR - 2023-04-20 09:51:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 09:51:38 --> Config Class Initialized
INFO - 2023-04-20 09:51:38 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:51:38 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:51:38 --> Utf8 Class Initialized
INFO - 2023-04-20 09:51:38 --> URI Class Initialized
DEBUG - 2023-04-20 09:51:38 --> No URI present. Default controller set.
INFO - 2023-04-20 09:51:38 --> Router Class Initialized
INFO - 2023-04-20 09:51:38 --> Output Class Initialized
INFO - 2023-04-20 09:51:38 --> Security Class Initialized
DEBUG - 2023-04-20 09:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:51:38 --> Input Class Initialized
INFO - 2023-04-20 09:51:38 --> Language Class Initialized
INFO - 2023-04-20 09:51:38 --> Loader Class Initialized
INFO - 2023-04-20 09:51:38 --> Helper loaded: url_helper
INFO - 2023-04-20 09:51:38 --> Helper loaded: file_helper
INFO - 2023-04-20 09:51:38 --> Helper loaded: html_helper
INFO - 2023-04-20 09:51:38 --> Helper loaded: text_helper
INFO - 2023-04-20 09:51:38 --> Helper loaded: form_helper
INFO - 2023-04-20 09:51:38 --> Helper loaded: lang_helper
INFO - 2023-04-20 09:51:38 --> Helper loaded: security_helper
INFO - 2023-04-20 09:51:38 --> Helper loaded: cookie_helper
INFO - 2023-04-20 09:51:38 --> Database Driver Class Initialized
INFO - 2023-04-20 09:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 09:51:38 --> Parser Class Initialized
INFO - 2023-04-20 09:51:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 09:51:38 --> Pagination Class Initialized
INFO - 2023-04-20 09:51:38 --> Form Validation Class Initialized
INFO - 2023-04-20 09:51:38 --> Controller Class Initialized
INFO - 2023-04-20 09:51:38 --> Model Class Initialized
DEBUG - 2023-04-20 09:51:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:51:38 --> Model Class Initialized
DEBUG - 2023-04-20 09:51:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:51:38 --> Model Class Initialized
INFO - 2023-04-20 09:51:38 --> Model Class Initialized
INFO - 2023-04-20 09:51:38 --> Model Class Initialized
INFO - 2023-04-20 09:51:38 --> Model Class Initialized
DEBUG - 2023-04-20 09:51:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 09:51:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:51:38 --> Model Class Initialized
INFO - 2023-04-20 09:51:38 --> Model Class Initialized
INFO - 2023-04-20 09:51:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-20 09:51:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 09:51:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 09:51:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 09:51:38 --> Model Class Initialized
INFO - 2023-04-20 09:51:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 09:51:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 09:51:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 09:51:38 --> Final output sent to browser
DEBUG - 2023-04-20 09:51:38 --> Total execution time: 0.1921
ERROR - 2023-04-20 10:07:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:07:22 --> Config Class Initialized
INFO - 2023-04-20 10:07:22 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:07:22 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:07:22 --> Utf8 Class Initialized
INFO - 2023-04-20 10:07:22 --> URI Class Initialized
INFO - 2023-04-20 10:07:22 --> Router Class Initialized
INFO - 2023-04-20 10:07:22 --> Output Class Initialized
INFO - 2023-04-20 10:07:22 --> Security Class Initialized
DEBUG - 2023-04-20 10:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:07:22 --> Input Class Initialized
INFO - 2023-04-20 10:07:22 --> Language Class Initialized
INFO - 2023-04-20 10:07:22 --> Loader Class Initialized
INFO - 2023-04-20 10:07:22 --> Helper loaded: url_helper
INFO - 2023-04-20 10:07:22 --> Helper loaded: file_helper
INFO - 2023-04-20 10:07:22 --> Helper loaded: html_helper
INFO - 2023-04-20 10:07:22 --> Helper loaded: text_helper
INFO - 2023-04-20 10:07:22 --> Helper loaded: form_helper
INFO - 2023-04-20 10:07:22 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:07:22 --> Helper loaded: security_helper
INFO - 2023-04-20 10:07:22 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:07:22 --> Database Driver Class Initialized
INFO - 2023-04-20 10:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:07:23 --> Parser Class Initialized
INFO - 2023-04-20 10:07:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:07:23 --> Pagination Class Initialized
INFO - 2023-04-20 10:07:23 --> Form Validation Class Initialized
INFO - 2023-04-20 10:07:23 --> Controller Class Initialized
INFO - 2023-04-20 10:07:23 --> Model Class Initialized
DEBUG - 2023-04-20 10:07:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:07:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:07:23 --> Model Class Initialized
DEBUG - 2023-04-20 10:07:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:07:23 --> Model Class Initialized
INFO - 2023-04-20 10:07:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-04-20 10:07:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:07:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 10:07:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 10:07:23 --> Model Class Initialized
INFO - 2023-04-20 10:07:23 --> Model Class Initialized
INFO - 2023-04-20 10:07:23 --> Model Class Initialized
INFO - 2023-04-20 10:07:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 10:07:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 10:07:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 10:07:23 --> Final output sent to browser
DEBUG - 2023-04-20 10:07:23 --> Total execution time: 0.1744
ERROR - 2023-04-20 10:07:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:07:23 --> Config Class Initialized
INFO - 2023-04-20 10:07:23 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:07:23 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:07:23 --> Utf8 Class Initialized
INFO - 2023-04-20 10:07:23 --> URI Class Initialized
INFO - 2023-04-20 10:07:23 --> Router Class Initialized
INFO - 2023-04-20 10:07:23 --> Output Class Initialized
INFO - 2023-04-20 10:07:23 --> Security Class Initialized
DEBUG - 2023-04-20 10:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:07:23 --> Input Class Initialized
INFO - 2023-04-20 10:07:23 --> Language Class Initialized
INFO - 2023-04-20 10:07:23 --> Loader Class Initialized
INFO - 2023-04-20 10:07:23 --> Helper loaded: url_helper
INFO - 2023-04-20 10:07:23 --> Helper loaded: file_helper
INFO - 2023-04-20 10:07:23 --> Helper loaded: html_helper
INFO - 2023-04-20 10:07:23 --> Helper loaded: text_helper
INFO - 2023-04-20 10:07:23 --> Helper loaded: form_helper
INFO - 2023-04-20 10:07:23 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:07:23 --> Helper loaded: security_helper
INFO - 2023-04-20 10:07:23 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:07:23 --> Database Driver Class Initialized
INFO - 2023-04-20 10:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:07:23 --> Parser Class Initialized
INFO - 2023-04-20 10:07:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:07:23 --> Pagination Class Initialized
INFO - 2023-04-20 10:07:23 --> Form Validation Class Initialized
INFO - 2023-04-20 10:07:23 --> Controller Class Initialized
INFO - 2023-04-20 10:07:23 --> Model Class Initialized
DEBUG - 2023-04-20 10:07:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:07:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:07:23 --> Model Class Initialized
DEBUG - 2023-04-20 10:07:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:07:23 --> Model Class Initialized
INFO - 2023-04-20 10:07:23 --> Final output sent to browser
DEBUG - 2023-04-20 10:07:23 --> Total execution time: 0.0594
ERROR - 2023-04-20 10:07:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:07:26 --> Config Class Initialized
INFO - 2023-04-20 10:07:26 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:07:26 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:07:26 --> Utf8 Class Initialized
INFO - 2023-04-20 10:07:26 --> URI Class Initialized
INFO - 2023-04-20 10:07:26 --> Router Class Initialized
INFO - 2023-04-20 10:07:26 --> Output Class Initialized
INFO - 2023-04-20 10:07:26 --> Security Class Initialized
DEBUG - 2023-04-20 10:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:07:26 --> Input Class Initialized
INFO - 2023-04-20 10:07:26 --> Language Class Initialized
INFO - 2023-04-20 10:07:26 --> Loader Class Initialized
INFO - 2023-04-20 10:07:26 --> Helper loaded: url_helper
INFO - 2023-04-20 10:07:26 --> Helper loaded: file_helper
INFO - 2023-04-20 10:07:26 --> Helper loaded: html_helper
INFO - 2023-04-20 10:07:26 --> Helper loaded: text_helper
INFO - 2023-04-20 10:07:26 --> Helper loaded: form_helper
INFO - 2023-04-20 10:07:26 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:07:26 --> Helper loaded: security_helper
INFO - 2023-04-20 10:07:26 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:07:26 --> Database Driver Class Initialized
INFO - 2023-04-20 10:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:07:26 --> Parser Class Initialized
INFO - 2023-04-20 10:07:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:07:26 --> Pagination Class Initialized
INFO - 2023-04-20 10:07:26 --> Form Validation Class Initialized
INFO - 2023-04-20 10:07:26 --> Controller Class Initialized
INFO - 2023-04-20 10:07:26 --> Model Class Initialized
DEBUG - 2023-04-20 10:07:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:07:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:07:26 --> Model Class Initialized
DEBUG - 2023-04-20 10:07:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:07:26 --> Model Class Initialized
INFO - 2023-04-20 10:07:26 --> Final output sent to browser
DEBUG - 2023-04-20 10:07:26 --> Total execution time: 0.0726
ERROR - 2023-04-20 10:07:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:07:35 --> Config Class Initialized
INFO - 2023-04-20 10:07:35 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:07:35 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:07:35 --> Utf8 Class Initialized
INFO - 2023-04-20 10:07:35 --> URI Class Initialized
INFO - 2023-04-20 10:07:35 --> Router Class Initialized
INFO - 2023-04-20 10:07:35 --> Output Class Initialized
INFO - 2023-04-20 10:07:35 --> Security Class Initialized
DEBUG - 2023-04-20 10:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:07:35 --> Input Class Initialized
INFO - 2023-04-20 10:07:35 --> Language Class Initialized
INFO - 2023-04-20 10:07:35 --> Loader Class Initialized
INFO - 2023-04-20 10:07:35 --> Helper loaded: url_helper
INFO - 2023-04-20 10:07:35 --> Helper loaded: file_helper
INFO - 2023-04-20 10:07:35 --> Helper loaded: html_helper
INFO - 2023-04-20 10:07:35 --> Helper loaded: text_helper
INFO - 2023-04-20 10:07:35 --> Helper loaded: form_helper
INFO - 2023-04-20 10:07:35 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:07:35 --> Helper loaded: security_helper
INFO - 2023-04-20 10:07:35 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:07:35 --> Database Driver Class Initialized
INFO - 2023-04-20 10:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:07:35 --> Parser Class Initialized
INFO - 2023-04-20 10:07:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:07:35 --> Pagination Class Initialized
INFO - 2023-04-20 10:07:35 --> Form Validation Class Initialized
INFO - 2023-04-20 10:07:35 --> Controller Class Initialized
INFO - 2023-04-20 10:07:35 --> Model Class Initialized
DEBUG - 2023-04-20 10:07:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:07:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:07:35 --> Model Class Initialized
DEBUG - 2023-04-20 10:07:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:07:35 --> Model Class Initialized
INFO - 2023-04-20 10:07:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-04-20 10:07:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:07:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 10:07:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 10:07:35 --> Model Class Initialized
INFO - 2023-04-20 10:07:35 --> Model Class Initialized
INFO - 2023-04-20 10:07:35 --> Model Class Initialized
INFO - 2023-04-20 10:07:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 10:07:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 10:07:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 10:07:35 --> Final output sent to browser
DEBUG - 2023-04-20 10:07:35 --> Total execution time: 0.1500
ERROR - 2023-04-20 10:07:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:07:36 --> Config Class Initialized
INFO - 2023-04-20 10:07:36 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:07:36 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:07:36 --> Utf8 Class Initialized
INFO - 2023-04-20 10:07:36 --> URI Class Initialized
INFO - 2023-04-20 10:07:36 --> Router Class Initialized
INFO - 2023-04-20 10:07:36 --> Output Class Initialized
INFO - 2023-04-20 10:07:36 --> Security Class Initialized
DEBUG - 2023-04-20 10:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:07:36 --> Input Class Initialized
INFO - 2023-04-20 10:07:36 --> Language Class Initialized
INFO - 2023-04-20 10:07:36 --> Loader Class Initialized
INFO - 2023-04-20 10:07:36 --> Helper loaded: url_helper
INFO - 2023-04-20 10:07:36 --> Helper loaded: file_helper
INFO - 2023-04-20 10:07:36 --> Helper loaded: html_helper
INFO - 2023-04-20 10:07:36 --> Helper loaded: text_helper
INFO - 2023-04-20 10:07:36 --> Helper loaded: form_helper
INFO - 2023-04-20 10:07:36 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:07:36 --> Helper loaded: security_helper
INFO - 2023-04-20 10:07:36 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:07:36 --> Database Driver Class Initialized
INFO - 2023-04-20 10:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:07:36 --> Parser Class Initialized
INFO - 2023-04-20 10:07:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:07:36 --> Pagination Class Initialized
INFO - 2023-04-20 10:07:36 --> Form Validation Class Initialized
INFO - 2023-04-20 10:07:36 --> Controller Class Initialized
INFO - 2023-04-20 10:07:36 --> Model Class Initialized
DEBUG - 2023-04-20 10:07:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:07:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:07:36 --> Model Class Initialized
DEBUG - 2023-04-20 10:07:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:07:36 --> Model Class Initialized
INFO - 2023-04-20 10:07:36 --> Final output sent to browser
DEBUG - 2023-04-20 10:07:36 --> Total execution time: 0.0638
ERROR - 2023-04-20 10:07:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:07:38 --> Config Class Initialized
INFO - 2023-04-20 10:07:38 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:07:38 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:07:38 --> Utf8 Class Initialized
INFO - 2023-04-20 10:07:38 --> URI Class Initialized
INFO - 2023-04-20 10:07:38 --> Router Class Initialized
INFO - 2023-04-20 10:07:38 --> Output Class Initialized
INFO - 2023-04-20 10:07:38 --> Security Class Initialized
DEBUG - 2023-04-20 10:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:07:38 --> Input Class Initialized
INFO - 2023-04-20 10:07:38 --> Language Class Initialized
INFO - 2023-04-20 10:07:38 --> Loader Class Initialized
INFO - 2023-04-20 10:07:38 --> Helper loaded: url_helper
INFO - 2023-04-20 10:07:38 --> Helper loaded: file_helper
INFO - 2023-04-20 10:07:38 --> Helper loaded: html_helper
INFO - 2023-04-20 10:07:38 --> Helper loaded: text_helper
INFO - 2023-04-20 10:07:38 --> Helper loaded: form_helper
INFO - 2023-04-20 10:07:38 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:07:38 --> Helper loaded: security_helper
INFO - 2023-04-20 10:07:38 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:07:38 --> Database Driver Class Initialized
INFO - 2023-04-20 10:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:07:38 --> Parser Class Initialized
INFO - 2023-04-20 10:07:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:07:38 --> Pagination Class Initialized
INFO - 2023-04-20 10:07:38 --> Form Validation Class Initialized
INFO - 2023-04-20 10:07:38 --> Controller Class Initialized
INFO - 2023-04-20 10:07:38 --> Model Class Initialized
INFO - 2023-04-20 10:07:38 --> Model Class Initialized
INFO - 2023-04-20 10:07:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2023-04-20 10:07:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:07:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 10:07:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 10:07:38 --> Model Class Initialized
INFO - 2023-04-20 10:07:38 --> Model Class Initialized
INFO - 2023-04-20 10:07:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 10:07:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 10:07:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 10:07:38 --> Final output sent to browser
DEBUG - 2023-04-20 10:07:38 --> Total execution time: 0.1387
ERROR - 2023-04-20 10:07:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:07:39 --> Config Class Initialized
INFO - 2023-04-20 10:07:39 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:07:39 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:07:39 --> Utf8 Class Initialized
INFO - 2023-04-20 10:07:39 --> URI Class Initialized
INFO - 2023-04-20 10:07:39 --> Router Class Initialized
INFO - 2023-04-20 10:07:39 --> Output Class Initialized
INFO - 2023-04-20 10:07:39 --> Security Class Initialized
DEBUG - 2023-04-20 10:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:07:39 --> Input Class Initialized
INFO - 2023-04-20 10:07:39 --> Language Class Initialized
INFO - 2023-04-20 10:07:39 --> Loader Class Initialized
INFO - 2023-04-20 10:07:39 --> Helper loaded: url_helper
INFO - 2023-04-20 10:07:39 --> Helper loaded: file_helper
INFO - 2023-04-20 10:07:39 --> Helper loaded: html_helper
INFO - 2023-04-20 10:07:39 --> Helper loaded: text_helper
INFO - 2023-04-20 10:07:39 --> Helper loaded: form_helper
INFO - 2023-04-20 10:07:39 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:07:39 --> Helper loaded: security_helper
INFO - 2023-04-20 10:07:39 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:07:39 --> Database Driver Class Initialized
INFO - 2023-04-20 10:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:07:39 --> Parser Class Initialized
INFO - 2023-04-20 10:07:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:07:39 --> Pagination Class Initialized
INFO - 2023-04-20 10:07:39 --> Form Validation Class Initialized
INFO - 2023-04-20 10:07:39 --> Controller Class Initialized
INFO - 2023-04-20 10:07:39 --> Model Class Initialized
INFO - 2023-04-20 10:07:39 --> Model Class Initialized
INFO - 2023-04-20 10:07:39 --> Final output sent to browser
DEBUG - 2023-04-20 10:07:39 --> Total execution time: 0.0183
ERROR - 2023-04-20 10:08:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:08:08 --> Config Class Initialized
INFO - 2023-04-20 10:08:08 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:08:08 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:08:08 --> Utf8 Class Initialized
INFO - 2023-04-20 10:08:08 --> URI Class Initialized
INFO - 2023-04-20 10:08:08 --> Router Class Initialized
INFO - 2023-04-20 10:08:08 --> Output Class Initialized
INFO - 2023-04-20 10:08:08 --> Security Class Initialized
DEBUG - 2023-04-20 10:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:08:08 --> Input Class Initialized
INFO - 2023-04-20 10:08:08 --> Language Class Initialized
INFO - 2023-04-20 10:08:08 --> Loader Class Initialized
INFO - 2023-04-20 10:08:08 --> Helper loaded: url_helper
INFO - 2023-04-20 10:08:08 --> Helper loaded: file_helper
INFO - 2023-04-20 10:08:08 --> Helper loaded: html_helper
INFO - 2023-04-20 10:08:08 --> Helper loaded: text_helper
INFO - 2023-04-20 10:08:08 --> Helper loaded: form_helper
INFO - 2023-04-20 10:08:08 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:08:08 --> Helper loaded: security_helper
INFO - 2023-04-20 10:08:08 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:08:08 --> Database Driver Class Initialized
INFO - 2023-04-20 10:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:08:08 --> Parser Class Initialized
INFO - 2023-04-20 10:08:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:08:08 --> Pagination Class Initialized
INFO - 2023-04-20 10:08:08 --> Form Validation Class Initialized
INFO - 2023-04-20 10:08:08 --> Controller Class Initialized
INFO - 2023-04-20 10:08:08 --> Model Class Initialized
DEBUG - 2023-04-20 10:08:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:08:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:08:08 --> Model Class Initialized
INFO - 2023-04-20 10:08:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-04-20 10:08:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:08:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 10:08:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 10:08:08 --> Model Class Initialized
INFO - 2023-04-20 10:08:08 --> Model Class Initialized
INFO - 2023-04-20 10:08:08 --> Model Class Initialized
INFO - 2023-04-20 10:08:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 10:08:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 10:08:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 10:08:08 --> Final output sent to browser
DEBUG - 2023-04-20 10:08:08 --> Total execution time: 0.1673
ERROR - 2023-04-20 10:08:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:08:09 --> Config Class Initialized
INFO - 2023-04-20 10:08:09 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:08:09 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:08:09 --> Utf8 Class Initialized
INFO - 2023-04-20 10:08:09 --> URI Class Initialized
INFO - 2023-04-20 10:08:09 --> Router Class Initialized
INFO - 2023-04-20 10:08:09 --> Output Class Initialized
INFO - 2023-04-20 10:08:09 --> Security Class Initialized
DEBUG - 2023-04-20 10:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:08:09 --> Input Class Initialized
INFO - 2023-04-20 10:08:09 --> Language Class Initialized
INFO - 2023-04-20 10:08:09 --> Loader Class Initialized
INFO - 2023-04-20 10:08:09 --> Helper loaded: url_helper
INFO - 2023-04-20 10:08:09 --> Helper loaded: file_helper
INFO - 2023-04-20 10:08:09 --> Helper loaded: html_helper
INFO - 2023-04-20 10:08:09 --> Helper loaded: text_helper
INFO - 2023-04-20 10:08:09 --> Helper loaded: form_helper
INFO - 2023-04-20 10:08:09 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:08:09 --> Helper loaded: security_helper
INFO - 2023-04-20 10:08:09 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:08:09 --> Database Driver Class Initialized
INFO - 2023-04-20 10:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:08:09 --> Parser Class Initialized
INFO - 2023-04-20 10:08:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:08:09 --> Pagination Class Initialized
INFO - 2023-04-20 10:08:09 --> Form Validation Class Initialized
INFO - 2023-04-20 10:08:09 --> Controller Class Initialized
INFO - 2023-04-20 10:08:09 --> Model Class Initialized
DEBUG - 2023-04-20 10:08:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:08:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:08:09 --> Model Class Initialized
INFO - 2023-04-20 10:08:09 --> Final output sent to browser
DEBUG - 2023-04-20 10:08:09 --> Total execution time: 0.0199
ERROR - 2023-04-20 10:08:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:08:15 --> Config Class Initialized
INFO - 2023-04-20 10:08:15 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:08:15 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:08:15 --> Utf8 Class Initialized
INFO - 2023-04-20 10:08:15 --> URI Class Initialized
INFO - 2023-04-20 10:08:15 --> Router Class Initialized
INFO - 2023-04-20 10:08:15 --> Output Class Initialized
INFO - 2023-04-20 10:08:15 --> Security Class Initialized
DEBUG - 2023-04-20 10:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:08:15 --> Input Class Initialized
INFO - 2023-04-20 10:08:15 --> Language Class Initialized
INFO - 2023-04-20 10:08:15 --> Loader Class Initialized
INFO - 2023-04-20 10:08:15 --> Helper loaded: url_helper
INFO - 2023-04-20 10:08:15 --> Helper loaded: file_helper
INFO - 2023-04-20 10:08:15 --> Helper loaded: html_helper
INFO - 2023-04-20 10:08:15 --> Helper loaded: text_helper
INFO - 2023-04-20 10:08:15 --> Helper loaded: form_helper
INFO - 2023-04-20 10:08:15 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:08:15 --> Helper loaded: security_helper
INFO - 2023-04-20 10:08:15 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:08:15 --> Database Driver Class Initialized
INFO - 2023-04-20 10:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:08:15 --> Parser Class Initialized
INFO - 2023-04-20 10:08:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:08:15 --> Pagination Class Initialized
INFO - 2023-04-20 10:08:15 --> Form Validation Class Initialized
INFO - 2023-04-20 10:08:15 --> Controller Class Initialized
INFO - 2023-04-20 10:08:15 --> Model Class Initialized
DEBUG - 2023-04-20 10:08:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:08:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:08:15 --> Model Class Initialized
INFO - 2023-04-20 10:08:15 --> Final output sent to browser
DEBUG - 2023-04-20 10:08:15 --> Total execution time: 0.0218
ERROR - 2023-04-20 10:08:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:08:31 --> Config Class Initialized
INFO - 2023-04-20 10:08:31 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:08:31 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:08:31 --> Utf8 Class Initialized
INFO - 2023-04-20 10:08:31 --> URI Class Initialized
INFO - 2023-04-20 10:08:31 --> Router Class Initialized
INFO - 2023-04-20 10:08:31 --> Output Class Initialized
INFO - 2023-04-20 10:08:31 --> Security Class Initialized
DEBUG - 2023-04-20 10:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:08:31 --> Input Class Initialized
INFO - 2023-04-20 10:08:31 --> Language Class Initialized
INFO - 2023-04-20 10:08:31 --> Loader Class Initialized
INFO - 2023-04-20 10:08:31 --> Helper loaded: url_helper
INFO - 2023-04-20 10:08:31 --> Helper loaded: file_helper
INFO - 2023-04-20 10:08:31 --> Helper loaded: html_helper
INFO - 2023-04-20 10:08:31 --> Helper loaded: text_helper
INFO - 2023-04-20 10:08:31 --> Helper loaded: form_helper
INFO - 2023-04-20 10:08:31 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:08:31 --> Helper loaded: security_helper
INFO - 2023-04-20 10:08:31 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:08:31 --> Database Driver Class Initialized
INFO - 2023-04-20 10:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:08:31 --> Parser Class Initialized
INFO - 2023-04-20 10:08:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:08:31 --> Pagination Class Initialized
INFO - 2023-04-20 10:08:31 --> Form Validation Class Initialized
INFO - 2023-04-20 10:08:31 --> Controller Class Initialized
INFO - 2023-04-20 10:08:31 --> Model Class Initialized
DEBUG - 2023-04-20 10:08:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:08:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:08:31 --> Model Class Initialized
INFO - 2023-04-20 10:08:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-04-20 10:08:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:08:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 10:08:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 10:08:31 --> Model Class Initialized
INFO - 2023-04-20 10:08:31 --> Model Class Initialized
INFO - 2023-04-20 10:08:31 --> Model Class Initialized
INFO - 2023-04-20 10:08:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 10:08:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 10:08:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 10:08:31 --> Final output sent to browser
DEBUG - 2023-04-20 10:08:31 --> Total execution time: 0.1507
ERROR - 2023-04-20 10:08:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:08:32 --> Config Class Initialized
INFO - 2023-04-20 10:08:32 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:08:32 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:08:32 --> Utf8 Class Initialized
INFO - 2023-04-20 10:08:32 --> URI Class Initialized
INFO - 2023-04-20 10:08:32 --> Router Class Initialized
INFO - 2023-04-20 10:08:32 --> Output Class Initialized
INFO - 2023-04-20 10:08:32 --> Security Class Initialized
DEBUG - 2023-04-20 10:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:08:32 --> Input Class Initialized
INFO - 2023-04-20 10:08:32 --> Language Class Initialized
INFO - 2023-04-20 10:08:32 --> Loader Class Initialized
INFO - 2023-04-20 10:08:32 --> Helper loaded: url_helper
INFO - 2023-04-20 10:08:32 --> Helper loaded: file_helper
INFO - 2023-04-20 10:08:32 --> Helper loaded: html_helper
INFO - 2023-04-20 10:08:32 --> Helper loaded: text_helper
INFO - 2023-04-20 10:08:32 --> Helper loaded: form_helper
INFO - 2023-04-20 10:08:32 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:08:32 --> Helper loaded: security_helper
INFO - 2023-04-20 10:08:32 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:08:32 --> Database Driver Class Initialized
INFO - 2023-04-20 10:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:08:32 --> Parser Class Initialized
INFO - 2023-04-20 10:08:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:08:32 --> Pagination Class Initialized
INFO - 2023-04-20 10:08:32 --> Form Validation Class Initialized
INFO - 2023-04-20 10:08:32 --> Controller Class Initialized
INFO - 2023-04-20 10:08:32 --> Model Class Initialized
DEBUG - 2023-04-20 10:08:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:08:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:08:32 --> Model Class Initialized
INFO - 2023-04-20 10:08:32 --> Final output sent to browser
DEBUG - 2023-04-20 10:08:32 --> Total execution time: 0.0189
ERROR - 2023-04-20 10:08:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:08:35 --> Config Class Initialized
INFO - 2023-04-20 10:08:35 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:08:35 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:08:35 --> Utf8 Class Initialized
INFO - 2023-04-20 10:08:35 --> URI Class Initialized
INFO - 2023-04-20 10:08:35 --> Router Class Initialized
INFO - 2023-04-20 10:08:35 --> Output Class Initialized
INFO - 2023-04-20 10:08:35 --> Security Class Initialized
DEBUG - 2023-04-20 10:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:08:35 --> Input Class Initialized
INFO - 2023-04-20 10:08:35 --> Language Class Initialized
INFO - 2023-04-20 10:08:35 --> Loader Class Initialized
INFO - 2023-04-20 10:08:35 --> Helper loaded: url_helper
INFO - 2023-04-20 10:08:35 --> Helper loaded: file_helper
INFO - 2023-04-20 10:08:35 --> Helper loaded: html_helper
INFO - 2023-04-20 10:08:35 --> Helper loaded: text_helper
INFO - 2023-04-20 10:08:35 --> Helper loaded: form_helper
INFO - 2023-04-20 10:08:35 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:08:35 --> Helper loaded: security_helper
INFO - 2023-04-20 10:08:35 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:08:35 --> Database Driver Class Initialized
INFO - 2023-04-20 10:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:08:35 --> Parser Class Initialized
INFO - 2023-04-20 10:08:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:08:35 --> Pagination Class Initialized
INFO - 2023-04-20 10:08:35 --> Form Validation Class Initialized
INFO - 2023-04-20 10:08:35 --> Controller Class Initialized
INFO - 2023-04-20 10:08:35 --> Model Class Initialized
INFO - 2023-04-20 10:08:35 --> Model Class Initialized
INFO - 2023-04-20 10:08:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2023-04-20 10:08:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:08:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 10:08:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 10:08:35 --> Model Class Initialized
INFO - 2023-04-20 10:08:35 --> Model Class Initialized
INFO - 2023-04-20 10:08:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 10:08:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 10:08:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 10:08:35 --> Final output sent to browser
DEBUG - 2023-04-20 10:08:35 --> Total execution time: 0.1391
ERROR - 2023-04-20 10:08:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:08:36 --> Config Class Initialized
INFO - 2023-04-20 10:08:36 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:08:36 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:08:36 --> Utf8 Class Initialized
INFO - 2023-04-20 10:08:36 --> URI Class Initialized
INFO - 2023-04-20 10:08:36 --> Router Class Initialized
INFO - 2023-04-20 10:08:36 --> Output Class Initialized
INFO - 2023-04-20 10:08:36 --> Security Class Initialized
DEBUG - 2023-04-20 10:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:08:36 --> Input Class Initialized
INFO - 2023-04-20 10:08:36 --> Language Class Initialized
INFO - 2023-04-20 10:08:36 --> Loader Class Initialized
INFO - 2023-04-20 10:08:36 --> Helper loaded: url_helper
INFO - 2023-04-20 10:08:36 --> Helper loaded: file_helper
INFO - 2023-04-20 10:08:36 --> Helper loaded: html_helper
INFO - 2023-04-20 10:08:36 --> Helper loaded: text_helper
INFO - 2023-04-20 10:08:36 --> Helper loaded: form_helper
INFO - 2023-04-20 10:08:36 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:08:36 --> Helper loaded: security_helper
INFO - 2023-04-20 10:08:36 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:08:36 --> Database Driver Class Initialized
INFO - 2023-04-20 10:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:08:36 --> Parser Class Initialized
INFO - 2023-04-20 10:08:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:08:36 --> Pagination Class Initialized
INFO - 2023-04-20 10:08:36 --> Form Validation Class Initialized
INFO - 2023-04-20 10:08:36 --> Controller Class Initialized
INFO - 2023-04-20 10:08:36 --> Model Class Initialized
INFO - 2023-04-20 10:08:36 --> Model Class Initialized
INFO - 2023-04-20 10:08:36 --> Final output sent to browser
DEBUG - 2023-04-20 10:08:36 --> Total execution time: 0.0182
ERROR - 2023-04-20 10:08:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:08:54 --> Config Class Initialized
INFO - 2023-04-20 10:08:54 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:08:54 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:08:54 --> Utf8 Class Initialized
INFO - 2023-04-20 10:08:54 --> URI Class Initialized
INFO - 2023-04-20 10:08:54 --> Router Class Initialized
INFO - 2023-04-20 10:08:54 --> Output Class Initialized
INFO - 2023-04-20 10:08:54 --> Security Class Initialized
DEBUG - 2023-04-20 10:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:08:54 --> Input Class Initialized
INFO - 2023-04-20 10:08:54 --> Language Class Initialized
INFO - 2023-04-20 10:08:54 --> Loader Class Initialized
INFO - 2023-04-20 10:08:54 --> Helper loaded: url_helper
INFO - 2023-04-20 10:08:54 --> Helper loaded: file_helper
INFO - 2023-04-20 10:08:54 --> Helper loaded: html_helper
INFO - 2023-04-20 10:08:54 --> Helper loaded: text_helper
INFO - 2023-04-20 10:08:54 --> Helper loaded: form_helper
INFO - 2023-04-20 10:08:54 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:08:54 --> Helper loaded: security_helper
INFO - 2023-04-20 10:08:54 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:08:54 --> Database Driver Class Initialized
INFO - 2023-04-20 10:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:08:54 --> Parser Class Initialized
INFO - 2023-04-20 10:08:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:08:54 --> Pagination Class Initialized
INFO - 2023-04-20 10:08:54 --> Form Validation Class Initialized
INFO - 2023-04-20 10:08:54 --> Controller Class Initialized
INFO - 2023-04-20 10:08:54 --> Model Class Initialized
INFO - 2023-04-20 10:08:54 --> Model Class Initialized
INFO - 2023-04-20 10:08:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-04-20 10:08:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:08:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 10:08:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 10:08:55 --> Model Class Initialized
INFO - 2023-04-20 10:08:55 --> Model Class Initialized
INFO - 2023-04-20 10:08:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 10:08:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 10:08:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 10:08:55 --> Final output sent to browser
DEBUG - 2023-04-20 10:08:55 --> Total execution time: 0.1494
ERROR - 2023-04-20 10:08:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:08:55 --> Config Class Initialized
INFO - 2023-04-20 10:08:55 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:08:55 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:08:55 --> Utf8 Class Initialized
INFO - 2023-04-20 10:08:55 --> URI Class Initialized
INFO - 2023-04-20 10:08:55 --> Router Class Initialized
INFO - 2023-04-20 10:08:55 --> Output Class Initialized
INFO - 2023-04-20 10:08:55 --> Security Class Initialized
DEBUG - 2023-04-20 10:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:08:55 --> Input Class Initialized
INFO - 2023-04-20 10:08:55 --> Language Class Initialized
INFO - 2023-04-20 10:08:55 --> Loader Class Initialized
INFO - 2023-04-20 10:08:55 --> Helper loaded: url_helper
INFO - 2023-04-20 10:08:55 --> Helper loaded: file_helper
INFO - 2023-04-20 10:08:55 --> Helper loaded: html_helper
INFO - 2023-04-20 10:08:55 --> Helper loaded: text_helper
INFO - 2023-04-20 10:08:55 --> Helper loaded: form_helper
INFO - 2023-04-20 10:08:55 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:08:55 --> Helper loaded: security_helper
INFO - 2023-04-20 10:08:55 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:08:55 --> Database Driver Class Initialized
INFO - 2023-04-20 10:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:08:55 --> Parser Class Initialized
INFO - 2023-04-20 10:08:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:08:55 --> Pagination Class Initialized
INFO - 2023-04-20 10:08:55 --> Form Validation Class Initialized
INFO - 2023-04-20 10:08:55 --> Controller Class Initialized
INFO - 2023-04-20 10:08:55 --> Model Class Initialized
INFO - 2023-04-20 10:08:55 --> Model Class Initialized
INFO - 2023-04-20 10:08:55 --> Final output sent to browser
DEBUG - 2023-04-20 10:08:55 --> Total execution time: 0.0173
ERROR - 2023-04-20 10:09:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:09:02 --> Config Class Initialized
INFO - 2023-04-20 10:09:02 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:09:02 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:09:02 --> Utf8 Class Initialized
INFO - 2023-04-20 10:09:02 --> URI Class Initialized
INFO - 2023-04-20 10:09:02 --> Router Class Initialized
INFO - 2023-04-20 10:09:02 --> Output Class Initialized
INFO - 2023-04-20 10:09:02 --> Security Class Initialized
DEBUG - 2023-04-20 10:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:09:02 --> Input Class Initialized
INFO - 2023-04-20 10:09:02 --> Language Class Initialized
INFO - 2023-04-20 10:09:02 --> Loader Class Initialized
INFO - 2023-04-20 10:09:02 --> Helper loaded: url_helper
INFO - 2023-04-20 10:09:02 --> Helper loaded: file_helper
INFO - 2023-04-20 10:09:02 --> Helper loaded: html_helper
INFO - 2023-04-20 10:09:02 --> Helper loaded: text_helper
INFO - 2023-04-20 10:09:02 --> Helper loaded: form_helper
INFO - 2023-04-20 10:09:02 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:09:02 --> Helper loaded: security_helper
INFO - 2023-04-20 10:09:02 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:09:02 --> Database Driver Class Initialized
INFO - 2023-04-20 10:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:09:02 --> Parser Class Initialized
INFO - 2023-04-20 10:09:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:09:02 --> Pagination Class Initialized
INFO - 2023-04-20 10:09:02 --> Form Validation Class Initialized
INFO - 2023-04-20 10:09:02 --> Controller Class Initialized
INFO - 2023-04-20 10:09:02 --> Model Class Initialized
DEBUG - 2023-04-20 10:09:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:09:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:09:02 --> Model Class Initialized
DEBUG - 2023-04-20 10:09:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:09:02 --> Model Class Initialized
INFO - 2023-04-20 10:09:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-04-20 10:09:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:09:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 10:09:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 10:09:02 --> Model Class Initialized
INFO - 2023-04-20 10:09:02 --> Model Class Initialized
INFO - 2023-04-20 10:09:02 --> Model Class Initialized
INFO - 2023-04-20 10:09:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 10:09:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 10:09:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 10:09:02 --> Final output sent to browser
DEBUG - 2023-04-20 10:09:02 --> Total execution time: 0.1681
ERROR - 2023-04-20 10:09:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:09:03 --> Config Class Initialized
INFO - 2023-04-20 10:09:03 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:09:03 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:09:03 --> Utf8 Class Initialized
INFO - 2023-04-20 10:09:03 --> URI Class Initialized
INFO - 2023-04-20 10:09:03 --> Router Class Initialized
INFO - 2023-04-20 10:09:03 --> Output Class Initialized
INFO - 2023-04-20 10:09:03 --> Security Class Initialized
DEBUG - 2023-04-20 10:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:09:03 --> Input Class Initialized
INFO - 2023-04-20 10:09:03 --> Language Class Initialized
INFO - 2023-04-20 10:09:03 --> Loader Class Initialized
INFO - 2023-04-20 10:09:03 --> Helper loaded: url_helper
INFO - 2023-04-20 10:09:03 --> Helper loaded: file_helper
INFO - 2023-04-20 10:09:03 --> Helper loaded: html_helper
INFO - 2023-04-20 10:09:03 --> Helper loaded: text_helper
INFO - 2023-04-20 10:09:03 --> Helper loaded: form_helper
INFO - 2023-04-20 10:09:03 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:09:03 --> Helper loaded: security_helper
INFO - 2023-04-20 10:09:03 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:09:03 --> Database Driver Class Initialized
INFO - 2023-04-20 10:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:09:03 --> Parser Class Initialized
INFO - 2023-04-20 10:09:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:09:03 --> Pagination Class Initialized
INFO - 2023-04-20 10:09:03 --> Form Validation Class Initialized
INFO - 2023-04-20 10:09:03 --> Controller Class Initialized
INFO - 2023-04-20 10:09:03 --> Model Class Initialized
DEBUG - 2023-04-20 10:09:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:09:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:09:03 --> Model Class Initialized
DEBUG - 2023-04-20 10:09:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:09:03 --> Model Class Initialized
INFO - 2023-04-20 10:09:03 --> Final output sent to browser
DEBUG - 2023-04-20 10:09:03 --> Total execution time: 0.0232
ERROR - 2023-04-20 10:09:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:09:58 --> Config Class Initialized
INFO - 2023-04-20 10:09:58 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:09:58 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:09:58 --> Utf8 Class Initialized
INFO - 2023-04-20 10:09:58 --> URI Class Initialized
INFO - 2023-04-20 10:09:58 --> Router Class Initialized
INFO - 2023-04-20 10:09:58 --> Output Class Initialized
INFO - 2023-04-20 10:09:58 --> Security Class Initialized
DEBUG - 2023-04-20 10:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:09:58 --> Input Class Initialized
INFO - 2023-04-20 10:09:58 --> Language Class Initialized
INFO - 2023-04-20 10:09:58 --> Loader Class Initialized
INFO - 2023-04-20 10:09:58 --> Helper loaded: url_helper
INFO - 2023-04-20 10:09:58 --> Helper loaded: file_helper
INFO - 2023-04-20 10:09:58 --> Helper loaded: html_helper
INFO - 2023-04-20 10:09:58 --> Helper loaded: text_helper
INFO - 2023-04-20 10:09:58 --> Helper loaded: form_helper
INFO - 2023-04-20 10:09:58 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:09:58 --> Helper loaded: security_helper
INFO - 2023-04-20 10:09:58 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:09:58 --> Database Driver Class Initialized
INFO - 2023-04-20 10:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:09:58 --> Parser Class Initialized
INFO - 2023-04-20 10:09:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:09:58 --> Pagination Class Initialized
INFO - 2023-04-20 10:09:58 --> Form Validation Class Initialized
INFO - 2023-04-20 10:09:58 --> Controller Class Initialized
INFO - 2023-04-20 10:09:58 --> Model Class Initialized
DEBUG - 2023-04-20 10:09:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:09:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:09:58 --> Model Class Initialized
DEBUG - 2023-04-20 10:09:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:09:58 --> Model Class Initialized
INFO - 2023-04-20 10:09:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-04-20 10:09:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:09:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 10:09:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 10:09:58 --> Model Class Initialized
INFO - 2023-04-20 10:09:58 --> Model Class Initialized
INFO - 2023-04-20 10:09:58 --> Model Class Initialized
INFO - 2023-04-20 10:09:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 10:09:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 10:09:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 10:09:58 --> Final output sent to browser
DEBUG - 2023-04-20 10:09:58 --> Total execution time: 0.1592
ERROR - 2023-04-20 10:09:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:09:59 --> Config Class Initialized
INFO - 2023-04-20 10:09:59 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:09:59 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:09:59 --> Utf8 Class Initialized
INFO - 2023-04-20 10:09:59 --> URI Class Initialized
INFO - 2023-04-20 10:09:59 --> Router Class Initialized
INFO - 2023-04-20 10:09:59 --> Output Class Initialized
INFO - 2023-04-20 10:09:59 --> Security Class Initialized
DEBUG - 2023-04-20 10:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:09:59 --> Input Class Initialized
INFO - 2023-04-20 10:09:59 --> Language Class Initialized
INFO - 2023-04-20 10:09:59 --> Loader Class Initialized
INFO - 2023-04-20 10:09:59 --> Helper loaded: url_helper
INFO - 2023-04-20 10:09:59 --> Helper loaded: file_helper
INFO - 2023-04-20 10:09:59 --> Helper loaded: html_helper
INFO - 2023-04-20 10:09:59 --> Helper loaded: text_helper
INFO - 2023-04-20 10:09:59 --> Helper loaded: form_helper
INFO - 2023-04-20 10:09:59 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:09:59 --> Helper loaded: security_helper
INFO - 2023-04-20 10:09:59 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:09:59 --> Database Driver Class Initialized
INFO - 2023-04-20 10:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:09:59 --> Parser Class Initialized
INFO - 2023-04-20 10:09:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:09:59 --> Pagination Class Initialized
INFO - 2023-04-20 10:09:59 --> Form Validation Class Initialized
INFO - 2023-04-20 10:09:59 --> Controller Class Initialized
INFO - 2023-04-20 10:09:59 --> Model Class Initialized
DEBUG - 2023-04-20 10:09:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:09:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:09:59 --> Model Class Initialized
DEBUG - 2023-04-20 10:09:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:09:59 --> Model Class Initialized
INFO - 2023-04-20 10:09:59 --> Final output sent to browser
DEBUG - 2023-04-20 10:09:59 --> Total execution time: 0.0657
ERROR - 2023-04-20 10:10:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:10:09 --> Config Class Initialized
INFO - 2023-04-20 10:10:09 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:10:09 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:10:09 --> Utf8 Class Initialized
INFO - 2023-04-20 10:10:09 --> URI Class Initialized
INFO - 2023-04-20 10:10:09 --> Router Class Initialized
INFO - 2023-04-20 10:10:09 --> Output Class Initialized
INFO - 2023-04-20 10:10:09 --> Security Class Initialized
DEBUG - 2023-04-20 10:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:10:09 --> Input Class Initialized
INFO - 2023-04-20 10:10:09 --> Language Class Initialized
INFO - 2023-04-20 10:10:09 --> Loader Class Initialized
INFO - 2023-04-20 10:10:09 --> Helper loaded: url_helper
INFO - 2023-04-20 10:10:09 --> Helper loaded: file_helper
INFO - 2023-04-20 10:10:09 --> Helper loaded: html_helper
INFO - 2023-04-20 10:10:09 --> Helper loaded: text_helper
INFO - 2023-04-20 10:10:09 --> Helper loaded: form_helper
INFO - 2023-04-20 10:10:09 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:10:09 --> Helper loaded: security_helper
INFO - 2023-04-20 10:10:09 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:10:09 --> Database Driver Class Initialized
INFO - 2023-04-20 10:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:10:09 --> Parser Class Initialized
INFO - 2023-04-20 10:10:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:10:09 --> Pagination Class Initialized
INFO - 2023-04-20 10:10:09 --> Form Validation Class Initialized
INFO - 2023-04-20 10:10:09 --> Controller Class Initialized
DEBUG - 2023-04-20 10:10:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:10:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:10:09 --> Model Class Initialized
DEBUG - 2023-04-20 10:10:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:10:09 --> Model Class Initialized
DEBUG - 2023-04-20 10:10:09 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:10:09 --> Model Class Initialized
INFO - 2023-04-20 10:10:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-04-20 10:10:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:10:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 10:10:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 10:10:09 --> Model Class Initialized
INFO - 2023-04-20 10:10:09 --> Model Class Initialized
INFO - 2023-04-20 10:10:09 --> Model Class Initialized
INFO - 2023-04-20 10:10:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 10:10:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 10:10:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 10:10:09 --> Final output sent to browser
DEBUG - 2023-04-20 10:10:09 --> Total execution time: 0.1596
ERROR - 2023-04-20 10:10:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:10:09 --> Config Class Initialized
INFO - 2023-04-20 10:10:09 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:10:09 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:10:09 --> Utf8 Class Initialized
INFO - 2023-04-20 10:10:09 --> URI Class Initialized
INFO - 2023-04-20 10:10:09 --> Router Class Initialized
INFO - 2023-04-20 10:10:09 --> Output Class Initialized
INFO - 2023-04-20 10:10:09 --> Security Class Initialized
DEBUG - 2023-04-20 10:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:10:09 --> Input Class Initialized
INFO - 2023-04-20 10:10:09 --> Language Class Initialized
INFO - 2023-04-20 10:10:09 --> Loader Class Initialized
INFO - 2023-04-20 10:10:09 --> Helper loaded: url_helper
INFO - 2023-04-20 10:10:09 --> Helper loaded: file_helper
INFO - 2023-04-20 10:10:09 --> Helper loaded: html_helper
INFO - 2023-04-20 10:10:09 --> Helper loaded: text_helper
INFO - 2023-04-20 10:10:09 --> Helper loaded: form_helper
INFO - 2023-04-20 10:10:09 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:10:09 --> Helper loaded: security_helper
INFO - 2023-04-20 10:10:09 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:10:09 --> Database Driver Class Initialized
INFO - 2023-04-20 10:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:10:09 --> Parser Class Initialized
INFO - 2023-04-20 10:10:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:10:09 --> Pagination Class Initialized
INFO - 2023-04-20 10:10:09 --> Form Validation Class Initialized
INFO - 2023-04-20 10:10:09 --> Controller Class Initialized
DEBUG - 2023-04-20 10:10:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:10:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:10:09 --> Model Class Initialized
DEBUG - 2023-04-20 10:10:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:10:09 --> Model Class Initialized
INFO - 2023-04-20 10:10:09 --> Final output sent to browser
DEBUG - 2023-04-20 10:10:09 --> Total execution time: 0.0342
ERROR - 2023-04-20 10:10:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:10:12 --> Config Class Initialized
INFO - 2023-04-20 10:10:12 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:10:12 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:10:12 --> Utf8 Class Initialized
INFO - 2023-04-20 10:10:12 --> URI Class Initialized
INFO - 2023-04-20 10:10:12 --> Router Class Initialized
INFO - 2023-04-20 10:10:12 --> Output Class Initialized
INFO - 2023-04-20 10:10:12 --> Security Class Initialized
DEBUG - 2023-04-20 10:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:10:12 --> Input Class Initialized
INFO - 2023-04-20 10:10:12 --> Language Class Initialized
INFO - 2023-04-20 10:10:12 --> Loader Class Initialized
INFO - 2023-04-20 10:10:12 --> Helper loaded: url_helper
INFO - 2023-04-20 10:10:12 --> Helper loaded: file_helper
INFO - 2023-04-20 10:10:12 --> Helper loaded: html_helper
INFO - 2023-04-20 10:10:12 --> Helper loaded: text_helper
INFO - 2023-04-20 10:10:12 --> Helper loaded: form_helper
INFO - 2023-04-20 10:10:12 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:10:12 --> Helper loaded: security_helper
INFO - 2023-04-20 10:10:12 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:10:12 --> Database Driver Class Initialized
INFO - 2023-04-20 10:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:10:12 --> Parser Class Initialized
INFO - 2023-04-20 10:10:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:10:12 --> Pagination Class Initialized
INFO - 2023-04-20 10:10:12 --> Form Validation Class Initialized
INFO - 2023-04-20 10:10:12 --> Controller Class Initialized
DEBUG - 2023-04-20 10:10:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:10:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:10:12 --> Model Class Initialized
DEBUG - 2023-04-20 10:10:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:10:12 --> Model Class Initialized
INFO - 2023-04-20 10:10:12 --> Final output sent to browser
DEBUG - 2023-04-20 10:10:12 --> Total execution time: 0.0897
ERROR - 2023-04-20 10:10:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:10:20 --> Config Class Initialized
INFO - 2023-04-20 10:10:20 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:10:20 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:10:20 --> Utf8 Class Initialized
INFO - 2023-04-20 10:10:20 --> URI Class Initialized
INFO - 2023-04-20 10:10:20 --> Router Class Initialized
INFO - 2023-04-20 10:10:20 --> Output Class Initialized
INFO - 2023-04-20 10:10:20 --> Security Class Initialized
DEBUG - 2023-04-20 10:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:10:20 --> Input Class Initialized
INFO - 2023-04-20 10:10:20 --> Language Class Initialized
INFO - 2023-04-20 10:10:20 --> Loader Class Initialized
INFO - 2023-04-20 10:10:20 --> Helper loaded: url_helper
INFO - 2023-04-20 10:10:20 --> Helper loaded: file_helper
INFO - 2023-04-20 10:10:20 --> Helper loaded: html_helper
INFO - 2023-04-20 10:10:20 --> Helper loaded: text_helper
INFO - 2023-04-20 10:10:20 --> Helper loaded: form_helper
INFO - 2023-04-20 10:10:20 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:10:20 --> Helper loaded: security_helper
INFO - 2023-04-20 10:10:20 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:10:20 --> Database Driver Class Initialized
INFO - 2023-04-20 10:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:10:20 --> Parser Class Initialized
INFO - 2023-04-20 10:10:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:10:20 --> Pagination Class Initialized
INFO - 2023-04-20 10:10:20 --> Form Validation Class Initialized
INFO - 2023-04-20 10:10:20 --> Controller Class Initialized
DEBUG - 2023-04-20 10:10:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:10:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:10:20 --> Model Class Initialized
DEBUG - 2023-04-20 10:10:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:10:20 --> Model Class Initialized
INFO - 2023-04-20 10:10:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/edit_customer_form.php
DEBUG - 2023-04-20 10:10:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:10:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 10:10:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 10:10:20 --> Model Class Initialized
INFO - 2023-04-20 10:10:20 --> Model Class Initialized
INFO - 2023-04-20 10:10:20 --> Model Class Initialized
INFO - 2023-04-20 10:10:20 --> Model Class Initialized
INFO - 2023-04-20 10:10:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 10:10:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 10:10:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 10:10:20 --> Final output sent to browser
DEBUG - 2023-04-20 10:10:20 --> Total execution time: 0.1737
ERROR - 2023-04-20 10:10:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:10:22 --> Config Class Initialized
INFO - 2023-04-20 10:10:22 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:10:22 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:10:22 --> Utf8 Class Initialized
INFO - 2023-04-20 10:10:22 --> URI Class Initialized
INFO - 2023-04-20 10:10:22 --> Router Class Initialized
INFO - 2023-04-20 10:10:22 --> Output Class Initialized
INFO - 2023-04-20 10:10:22 --> Security Class Initialized
DEBUG - 2023-04-20 10:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:10:22 --> Input Class Initialized
INFO - 2023-04-20 10:10:22 --> Language Class Initialized
INFO - 2023-04-20 10:10:22 --> Loader Class Initialized
INFO - 2023-04-20 10:10:22 --> Helper loaded: url_helper
INFO - 2023-04-20 10:10:22 --> Helper loaded: file_helper
INFO - 2023-04-20 10:10:22 --> Helper loaded: html_helper
INFO - 2023-04-20 10:10:22 --> Helper loaded: text_helper
INFO - 2023-04-20 10:10:22 --> Helper loaded: form_helper
INFO - 2023-04-20 10:10:22 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:10:22 --> Helper loaded: security_helper
INFO - 2023-04-20 10:10:22 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:10:22 --> Database Driver Class Initialized
INFO - 2023-04-20 10:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:10:22 --> Parser Class Initialized
INFO - 2023-04-20 10:10:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:10:22 --> Pagination Class Initialized
INFO - 2023-04-20 10:10:22 --> Form Validation Class Initialized
INFO - 2023-04-20 10:10:22 --> Controller Class Initialized
DEBUG - 2023-04-20 10:10:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:10:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:10:22 --> Model Class Initialized
DEBUG - 2023-04-20 10:10:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:10:22 --> Model Class Initialized
DEBUG - 2023-04-20 10:10:22 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:10:22 --> Model Class Initialized
INFO - 2023-04-20 10:10:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-04-20 10:10:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:10:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 10:10:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 10:10:22 --> Model Class Initialized
INFO - 2023-04-20 10:10:22 --> Model Class Initialized
INFO - 2023-04-20 10:10:22 --> Model Class Initialized
INFO - 2023-04-20 10:10:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 10:10:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 10:10:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 10:10:22 --> Final output sent to browser
DEBUG - 2023-04-20 10:10:22 --> Total execution time: 0.1668
ERROR - 2023-04-20 10:10:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:10:23 --> Config Class Initialized
INFO - 2023-04-20 10:10:23 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:10:23 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:10:23 --> Utf8 Class Initialized
INFO - 2023-04-20 10:10:23 --> URI Class Initialized
INFO - 2023-04-20 10:10:23 --> Router Class Initialized
INFO - 2023-04-20 10:10:23 --> Output Class Initialized
INFO - 2023-04-20 10:10:23 --> Security Class Initialized
DEBUG - 2023-04-20 10:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:10:23 --> Input Class Initialized
INFO - 2023-04-20 10:10:23 --> Language Class Initialized
INFO - 2023-04-20 10:10:23 --> Loader Class Initialized
INFO - 2023-04-20 10:10:23 --> Helper loaded: url_helper
INFO - 2023-04-20 10:10:23 --> Helper loaded: file_helper
INFO - 2023-04-20 10:10:23 --> Helper loaded: html_helper
INFO - 2023-04-20 10:10:23 --> Helper loaded: text_helper
INFO - 2023-04-20 10:10:23 --> Helper loaded: form_helper
INFO - 2023-04-20 10:10:23 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:10:23 --> Helper loaded: security_helper
INFO - 2023-04-20 10:10:23 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:10:23 --> Database Driver Class Initialized
INFO - 2023-04-20 10:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:10:23 --> Parser Class Initialized
INFO - 2023-04-20 10:10:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:10:23 --> Pagination Class Initialized
INFO - 2023-04-20 10:10:23 --> Form Validation Class Initialized
INFO - 2023-04-20 10:10:23 --> Controller Class Initialized
DEBUG - 2023-04-20 10:10:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:10:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:10:23 --> Model Class Initialized
DEBUG - 2023-04-20 10:10:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:10:23 --> Model Class Initialized
INFO - 2023-04-20 10:10:23 --> Final output sent to browser
DEBUG - 2023-04-20 10:10:23 --> Total execution time: 0.0326
ERROR - 2023-04-20 10:10:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:10:28 --> Config Class Initialized
INFO - 2023-04-20 10:10:28 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:10:28 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:10:28 --> Utf8 Class Initialized
INFO - 2023-04-20 10:10:28 --> URI Class Initialized
INFO - 2023-04-20 10:10:28 --> Router Class Initialized
INFO - 2023-04-20 10:10:28 --> Output Class Initialized
INFO - 2023-04-20 10:10:28 --> Security Class Initialized
DEBUG - 2023-04-20 10:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:10:28 --> Input Class Initialized
INFO - 2023-04-20 10:10:28 --> Language Class Initialized
INFO - 2023-04-20 10:10:28 --> Loader Class Initialized
INFO - 2023-04-20 10:10:28 --> Helper loaded: url_helper
INFO - 2023-04-20 10:10:28 --> Helper loaded: file_helper
INFO - 2023-04-20 10:10:28 --> Helper loaded: html_helper
INFO - 2023-04-20 10:10:28 --> Helper loaded: text_helper
INFO - 2023-04-20 10:10:28 --> Helper loaded: form_helper
INFO - 2023-04-20 10:10:28 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:10:28 --> Helper loaded: security_helper
INFO - 2023-04-20 10:10:28 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:10:28 --> Database Driver Class Initialized
INFO - 2023-04-20 10:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:10:28 --> Parser Class Initialized
INFO - 2023-04-20 10:10:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:10:28 --> Pagination Class Initialized
INFO - 2023-04-20 10:10:28 --> Form Validation Class Initialized
INFO - 2023-04-20 10:10:28 --> Controller Class Initialized
DEBUG - 2023-04-20 10:10:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:10:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:10:28 --> Model Class Initialized
DEBUG - 2023-04-20 10:10:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:10:28 --> Model Class Initialized
INFO - 2023-04-20 10:10:28 --> Final output sent to browser
DEBUG - 2023-04-20 10:10:28 --> Total execution time: 0.0830
ERROR - 2023-04-20 10:10:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:10:31 --> Config Class Initialized
INFO - 2023-04-20 10:10:31 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:10:31 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:10:31 --> Utf8 Class Initialized
INFO - 2023-04-20 10:10:31 --> URI Class Initialized
INFO - 2023-04-20 10:10:31 --> Router Class Initialized
INFO - 2023-04-20 10:10:31 --> Output Class Initialized
INFO - 2023-04-20 10:10:31 --> Security Class Initialized
DEBUG - 2023-04-20 10:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:10:31 --> Input Class Initialized
INFO - 2023-04-20 10:10:31 --> Language Class Initialized
INFO - 2023-04-20 10:10:31 --> Loader Class Initialized
INFO - 2023-04-20 10:10:31 --> Helper loaded: url_helper
INFO - 2023-04-20 10:10:31 --> Helper loaded: file_helper
INFO - 2023-04-20 10:10:31 --> Helper loaded: html_helper
INFO - 2023-04-20 10:10:31 --> Helper loaded: text_helper
INFO - 2023-04-20 10:10:31 --> Helper loaded: form_helper
INFO - 2023-04-20 10:10:31 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:10:31 --> Helper loaded: security_helper
INFO - 2023-04-20 10:10:31 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:10:31 --> Database Driver Class Initialized
INFO - 2023-04-20 10:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:10:31 --> Parser Class Initialized
INFO - 2023-04-20 10:10:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:10:31 --> Pagination Class Initialized
INFO - 2023-04-20 10:10:31 --> Form Validation Class Initialized
INFO - 2023-04-20 10:10:31 --> Controller Class Initialized
DEBUG - 2023-04-20 10:10:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:10:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:10:31 --> Model Class Initialized
DEBUG - 2023-04-20 10:10:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:10:31 --> Model Class Initialized
INFO - 2023-04-20 10:10:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/edit_customer_form.php
DEBUG - 2023-04-20 10:10:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:10:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 10:10:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 10:10:31 --> Model Class Initialized
INFO - 2023-04-20 10:10:31 --> Model Class Initialized
INFO - 2023-04-20 10:10:31 --> Model Class Initialized
INFO - 2023-04-20 10:10:31 --> Model Class Initialized
INFO - 2023-04-20 10:10:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 10:10:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 10:10:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 10:10:31 --> Final output sent to browser
DEBUG - 2023-04-20 10:10:31 --> Total execution time: 0.1828
ERROR - 2023-04-20 10:13:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:13:02 --> Config Class Initialized
INFO - 2023-04-20 10:13:02 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:13:02 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:13:02 --> Utf8 Class Initialized
INFO - 2023-04-20 10:13:02 --> URI Class Initialized
INFO - 2023-04-20 10:13:02 --> Router Class Initialized
INFO - 2023-04-20 10:13:02 --> Output Class Initialized
INFO - 2023-04-20 10:13:02 --> Security Class Initialized
DEBUG - 2023-04-20 10:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:13:02 --> Input Class Initialized
INFO - 2023-04-20 10:13:02 --> Language Class Initialized
INFO - 2023-04-20 10:13:02 --> Loader Class Initialized
INFO - 2023-04-20 10:13:02 --> Helper loaded: url_helper
INFO - 2023-04-20 10:13:02 --> Helper loaded: file_helper
INFO - 2023-04-20 10:13:02 --> Helper loaded: html_helper
INFO - 2023-04-20 10:13:02 --> Helper loaded: text_helper
INFO - 2023-04-20 10:13:02 --> Helper loaded: form_helper
INFO - 2023-04-20 10:13:02 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:13:02 --> Helper loaded: security_helper
INFO - 2023-04-20 10:13:02 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:13:02 --> Database Driver Class Initialized
INFO - 2023-04-20 10:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:13:02 --> Parser Class Initialized
INFO - 2023-04-20 10:13:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:13:02 --> Pagination Class Initialized
INFO - 2023-04-20 10:13:02 --> Form Validation Class Initialized
INFO - 2023-04-20 10:13:02 --> Controller Class Initialized
DEBUG - 2023-04-20 10:13:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:13:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:13:02 --> Model Class Initialized
DEBUG - 2023-04-20 10:13:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:13:02 --> Model Class Initialized
ERROR - 2023-04-20 10:13:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:13:03 --> Config Class Initialized
INFO - 2023-04-20 10:13:03 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:13:03 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:13:03 --> Utf8 Class Initialized
INFO - 2023-04-20 10:13:03 --> URI Class Initialized
INFO - 2023-04-20 10:13:03 --> Router Class Initialized
INFO - 2023-04-20 10:13:03 --> Output Class Initialized
INFO - 2023-04-20 10:13:03 --> Security Class Initialized
DEBUG - 2023-04-20 10:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:13:03 --> Input Class Initialized
INFO - 2023-04-20 10:13:03 --> Language Class Initialized
INFO - 2023-04-20 10:13:03 --> Loader Class Initialized
INFO - 2023-04-20 10:13:03 --> Helper loaded: url_helper
INFO - 2023-04-20 10:13:03 --> Helper loaded: file_helper
INFO - 2023-04-20 10:13:03 --> Helper loaded: html_helper
INFO - 2023-04-20 10:13:03 --> Helper loaded: text_helper
INFO - 2023-04-20 10:13:03 --> Helper loaded: form_helper
INFO - 2023-04-20 10:13:03 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:13:03 --> Helper loaded: security_helper
INFO - 2023-04-20 10:13:03 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:13:03 --> Database Driver Class Initialized
INFO - 2023-04-20 10:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:13:03 --> Parser Class Initialized
INFO - 2023-04-20 10:13:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:13:03 --> Pagination Class Initialized
INFO - 2023-04-20 10:13:03 --> Form Validation Class Initialized
INFO - 2023-04-20 10:13:03 --> Controller Class Initialized
DEBUG - 2023-04-20 10:13:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:13:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:13:03 --> Model Class Initialized
DEBUG - 2023-04-20 10:13:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:13:03 --> Model Class Initialized
DEBUG - 2023-04-20 10:13:03 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:13:03 --> Model Class Initialized
INFO - 2023-04-20 10:13:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-04-20 10:13:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:13:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 10:13:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 10:13:03 --> Model Class Initialized
INFO - 2023-04-20 10:13:03 --> Model Class Initialized
INFO - 2023-04-20 10:13:03 --> Model Class Initialized
INFO - 2023-04-20 10:13:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 10:13:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 10:13:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 10:13:03 --> Final output sent to browser
DEBUG - 2023-04-20 10:13:03 --> Total execution time: 0.1585
ERROR - 2023-04-20 10:13:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:13:04 --> Config Class Initialized
INFO - 2023-04-20 10:13:04 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:13:04 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:13:04 --> Utf8 Class Initialized
INFO - 2023-04-20 10:13:04 --> URI Class Initialized
INFO - 2023-04-20 10:13:04 --> Router Class Initialized
INFO - 2023-04-20 10:13:04 --> Output Class Initialized
INFO - 2023-04-20 10:13:04 --> Security Class Initialized
DEBUG - 2023-04-20 10:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:13:04 --> Input Class Initialized
INFO - 2023-04-20 10:13:04 --> Language Class Initialized
INFO - 2023-04-20 10:13:04 --> Loader Class Initialized
INFO - 2023-04-20 10:13:04 --> Helper loaded: url_helper
INFO - 2023-04-20 10:13:04 --> Helper loaded: file_helper
INFO - 2023-04-20 10:13:04 --> Helper loaded: html_helper
INFO - 2023-04-20 10:13:04 --> Helper loaded: text_helper
INFO - 2023-04-20 10:13:04 --> Helper loaded: form_helper
INFO - 2023-04-20 10:13:04 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:13:04 --> Helper loaded: security_helper
INFO - 2023-04-20 10:13:04 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:13:04 --> Database Driver Class Initialized
INFO - 2023-04-20 10:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:13:04 --> Parser Class Initialized
INFO - 2023-04-20 10:13:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:13:04 --> Pagination Class Initialized
INFO - 2023-04-20 10:13:04 --> Form Validation Class Initialized
INFO - 2023-04-20 10:13:04 --> Controller Class Initialized
DEBUG - 2023-04-20 10:13:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:13:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:13:04 --> Model Class Initialized
DEBUG - 2023-04-20 10:13:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:13:04 --> Model Class Initialized
INFO - 2023-04-20 10:13:04 --> Final output sent to browser
DEBUG - 2023-04-20 10:13:04 --> Total execution time: 0.0322
ERROR - 2023-04-20 10:14:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:14:12 --> Config Class Initialized
INFO - 2023-04-20 10:14:12 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:14:12 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:14:12 --> Utf8 Class Initialized
INFO - 2023-04-20 10:14:12 --> URI Class Initialized
INFO - 2023-04-20 10:14:12 --> Router Class Initialized
INFO - 2023-04-20 10:14:12 --> Output Class Initialized
INFO - 2023-04-20 10:14:12 --> Security Class Initialized
DEBUG - 2023-04-20 10:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:14:12 --> Input Class Initialized
INFO - 2023-04-20 10:14:12 --> Language Class Initialized
INFO - 2023-04-20 10:14:12 --> Loader Class Initialized
INFO - 2023-04-20 10:14:12 --> Helper loaded: url_helper
INFO - 2023-04-20 10:14:12 --> Helper loaded: file_helper
INFO - 2023-04-20 10:14:12 --> Helper loaded: html_helper
INFO - 2023-04-20 10:14:12 --> Helper loaded: text_helper
INFO - 2023-04-20 10:14:12 --> Helper loaded: form_helper
INFO - 2023-04-20 10:14:12 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:14:12 --> Helper loaded: security_helper
INFO - 2023-04-20 10:14:12 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:14:12 --> Database Driver Class Initialized
INFO - 2023-04-20 10:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:14:12 --> Parser Class Initialized
INFO - 2023-04-20 10:14:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:14:12 --> Pagination Class Initialized
INFO - 2023-04-20 10:14:12 --> Form Validation Class Initialized
INFO - 2023-04-20 10:14:12 --> Controller Class Initialized
DEBUG - 2023-04-20 10:14:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:14:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:14:12 --> Model Class Initialized
DEBUG - 2023-04-20 10:14:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:14:12 --> Model Class Initialized
INFO - 2023-04-20 10:14:12 --> Final output sent to browser
DEBUG - 2023-04-20 10:14:12 --> Total execution time: 0.0829
ERROR - 2023-04-20 10:14:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:14:39 --> Config Class Initialized
INFO - 2023-04-20 10:14:39 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:14:39 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:14:39 --> Utf8 Class Initialized
INFO - 2023-04-20 10:14:39 --> URI Class Initialized
INFO - 2023-04-20 10:14:39 --> Router Class Initialized
INFO - 2023-04-20 10:14:39 --> Output Class Initialized
INFO - 2023-04-20 10:14:39 --> Security Class Initialized
DEBUG - 2023-04-20 10:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:14:39 --> Input Class Initialized
INFO - 2023-04-20 10:14:39 --> Language Class Initialized
INFO - 2023-04-20 10:14:39 --> Loader Class Initialized
INFO - 2023-04-20 10:14:39 --> Helper loaded: url_helper
INFO - 2023-04-20 10:14:39 --> Helper loaded: file_helper
INFO - 2023-04-20 10:14:39 --> Helper loaded: html_helper
INFO - 2023-04-20 10:14:39 --> Helper loaded: text_helper
INFO - 2023-04-20 10:14:39 --> Helper loaded: form_helper
INFO - 2023-04-20 10:14:39 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:14:39 --> Helper loaded: security_helper
INFO - 2023-04-20 10:14:39 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:14:39 --> Database Driver Class Initialized
INFO - 2023-04-20 10:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:14:39 --> Parser Class Initialized
INFO - 2023-04-20 10:14:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:14:39 --> Pagination Class Initialized
INFO - 2023-04-20 10:14:39 --> Form Validation Class Initialized
INFO - 2023-04-20 10:14:39 --> Controller Class Initialized
DEBUG - 2023-04-20 10:14:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:14:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:14:39 --> Model Class Initialized
DEBUG - 2023-04-20 10:14:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:14:39 --> Model Class Initialized
INFO - 2023-04-20 10:14:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/view_customer.php
DEBUG - 2023-04-20 10:14:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:14:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 10:14:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 10:14:39 --> Model Class Initialized
INFO - 2023-04-20 10:14:39 --> Model Class Initialized
INFO - 2023-04-20 10:14:39 --> Model Class Initialized
INFO - 2023-04-20 10:14:39 --> Model Class Initialized
INFO - 2023-04-20 10:14:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 10:14:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 10:14:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 10:14:39 --> Final output sent to browser
DEBUG - 2023-04-20 10:14:39 --> Total execution time: 0.1501
ERROR - 2023-04-20 10:15:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:15:36 --> Config Class Initialized
INFO - 2023-04-20 10:15:36 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:15:36 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:15:36 --> Utf8 Class Initialized
INFO - 2023-04-20 10:15:36 --> URI Class Initialized
DEBUG - 2023-04-20 10:15:36 --> No URI present. Default controller set.
INFO - 2023-04-20 10:15:36 --> Router Class Initialized
INFO - 2023-04-20 10:15:36 --> Output Class Initialized
INFO - 2023-04-20 10:15:36 --> Security Class Initialized
DEBUG - 2023-04-20 10:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:15:36 --> Input Class Initialized
INFO - 2023-04-20 10:15:36 --> Language Class Initialized
INFO - 2023-04-20 10:15:36 --> Loader Class Initialized
INFO - 2023-04-20 10:15:36 --> Helper loaded: url_helper
INFO - 2023-04-20 10:15:36 --> Helper loaded: file_helper
INFO - 2023-04-20 10:15:36 --> Helper loaded: html_helper
INFO - 2023-04-20 10:15:36 --> Helper loaded: text_helper
INFO - 2023-04-20 10:15:36 --> Helper loaded: form_helper
INFO - 2023-04-20 10:15:36 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:15:36 --> Helper loaded: security_helper
INFO - 2023-04-20 10:15:36 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:15:36 --> Database Driver Class Initialized
INFO - 2023-04-20 10:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:15:36 --> Parser Class Initialized
INFO - 2023-04-20 10:15:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:15:36 --> Pagination Class Initialized
INFO - 2023-04-20 10:15:36 --> Form Validation Class Initialized
INFO - 2023-04-20 10:15:36 --> Controller Class Initialized
INFO - 2023-04-20 10:15:36 --> Model Class Initialized
DEBUG - 2023-04-20 10:15:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-20 10:15:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:15:36 --> Config Class Initialized
INFO - 2023-04-20 10:15:36 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:15:36 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:15:36 --> Utf8 Class Initialized
INFO - 2023-04-20 10:15:36 --> URI Class Initialized
INFO - 2023-04-20 10:15:36 --> Router Class Initialized
INFO - 2023-04-20 10:15:36 --> Output Class Initialized
INFO - 2023-04-20 10:15:36 --> Security Class Initialized
DEBUG - 2023-04-20 10:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:15:36 --> Input Class Initialized
INFO - 2023-04-20 10:15:36 --> Language Class Initialized
INFO - 2023-04-20 10:15:36 --> Loader Class Initialized
INFO - 2023-04-20 10:15:36 --> Helper loaded: url_helper
INFO - 2023-04-20 10:15:36 --> Helper loaded: file_helper
INFO - 2023-04-20 10:15:36 --> Helper loaded: html_helper
INFO - 2023-04-20 10:15:36 --> Helper loaded: text_helper
INFO - 2023-04-20 10:15:36 --> Helper loaded: form_helper
INFO - 2023-04-20 10:15:36 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:15:36 --> Helper loaded: security_helper
INFO - 2023-04-20 10:15:36 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:15:36 --> Database Driver Class Initialized
INFO - 2023-04-20 10:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:15:36 --> Parser Class Initialized
INFO - 2023-04-20 10:15:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:15:36 --> Pagination Class Initialized
INFO - 2023-04-20 10:15:36 --> Form Validation Class Initialized
INFO - 2023-04-20 10:15:36 --> Controller Class Initialized
INFO - 2023-04-20 10:15:36 --> Model Class Initialized
DEBUG - 2023-04-20 10:15:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:15:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-20 10:15:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:15:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 10:15:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 10:15:36 --> Model Class Initialized
INFO - 2023-04-20 10:15:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 10:15:36 --> Final output sent to browser
DEBUG - 2023-04-20 10:15:36 --> Total execution time: 0.0312
ERROR - 2023-04-20 10:15:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:15:59 --> Config Class Initialized
INFO - 2023-04-20 10:15:59 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:15:59 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:15:59 --> Utf8 Class Initialized
INFO - 2023-04-20 10:15:59 --> URI Class Initialized
INFO - 2023-04-20 10:15:59 --> Router Class Initialized
INFO - 2023-04-20 10:15:59 --> Output Class Initialized
INFO - 2023-04-20 10:15:59 --> Security Class Initialized
DEBUG - 2023-04-20 10:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:15:59 --> Input Class Initialized
INFO - 2023-04-20 10:15:59 --> Language Class Initialized
INFO - 2023-04-20 10:15:59 --> Loader Class Initialized
INFO - 2023-04-20 10:15:59 --> Helper loaded: url_helper
INFO - 2023-04-20 10:15:59 --> Helper loaded: file_helper
INFO - 2023-04-20 10:15:59 --> Helper loaded: html_helper
INFO - 2023-04-20 10:15:59 --> Helper loaded: text_helper
INFO - 2023-04-20 10:15:59 --> Helper loaded: form_helper
INFO - 2023-04-20 10:15:59 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:15:59 --> Helper loaded: security_helper
INFO - 2023-04-20 10:15:59 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:15:59 --> Database Driver Class Initialized
INFO - 2023-04-20 10:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:15:59 --> Parser Class Initialized
INFO - 2023-04-20 10:15:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:15:59 --> Pagination Class Initialized
INFO - 2023-04-20 10:15:59 --> Form Validation Class Initialized
INFO - 2023-04-20 10:15:59 --> Controller Class Initialized
INFO - 2023-04-20 10:15:59 --> Model Class Initialized
DEBUG - 2023-04-20 10:15:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:15:59 --> Model Class Initialized
INFO - 2023-04-20 10:15:59 --> Final output sent to browser
DEBUG - 2023-04-20 10:15:59 --> Total execution time: 0.0201
ERROR - 2023-04-20 10:16:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:16:00 --> Config Class Initialized
INFO - 2023-04-20 10:16:00 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:16:00 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:16:00 --> Utf8 Class Initialized
INFO - 2023-04-20 10:16:00 --> URI Class Initialized
INFO - 2023-04-20 10:16:00 --> Router Class Initialized
INFO - 2023-04-20 10:16:00 --> Output Class Initialized
INFO - 2023-04-20 10:16:00 --> Security Class Initialized
DEBUG - 2023-04-20 10:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:16:00 --> Input Class Initialized
INFO - 2023-04-20 10:16:00 --> Language Class Initialized
INFO - 2023-04-20 10:16:00 --> Loader Class Initialized
INFO - 2023-04-20 10:16:00 --> Helper loaded: url_helper
INFO - 2023-04-20 10:16:00 --> Helper loaded: file_helper
INFO - 2023-04-20 10:16:00 --> Helper loaded: html_helper
INFO - 2023-04-20 10:16:00 --> Helper loaded: text_helper
INFO - 2023-04-20 10:16:00 --> Helper loaded: form_helper
INFO - 2023-04-20 10:16:00 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:16:00 --> Helper loaded: security_helper
INFO - 2023-04-20 10:16:00 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:16:00 --> Database Driver Class Initialized
INFO - 2023-04-20 10:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:16:00 --> Parser Class Initialized
INFO - 2023-04-20 10:16:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:16:00 --> Pagination Class Initialized
INFO - 2023-04-20 10:16:00 --> Form Validation Class Initialized
INFO - 2023-04-20 10:16:00 --> Controller Class Initialized
INFO - 2023-04-20 10:16:00 --> Model Class Initialized
DEBUG - 2023-04-20 10:16:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:16:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-20 10:16:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:16:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 10:16:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 10:16:00 --> Model Class Initialized
INFO - 2023-04-20 10:16:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 10:16:00 --> Final output sent to browser
DEBUG - 2023-04-20 10:16:00 --> Total execution time: 0.0297
ERROR - 2023-04-20 10:16:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:16:04 --> Config Class Initialized
INFO - 2023-04-20 10:16:04 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:16:04 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:16:04 --> Utf8 Class Initialized
INFO - 2023-04-20 10:16:04 --> URI Class Initialized
INFO - 2023-04-20 10:16:04 --> Router Class Initialized
INFO - 2023-04-20 10:16:04 --> Output Class Initialized
INFO - 2023-04-20 10:16:04 --> Security Class Initialized
DEBUG - 2023-04-20 10:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:16:04 --> Input Class Initialized
INFO - 2023-04-20 10:16:04 --> Language Class Initialized
INFO - 2023-04-20 10:16:04 --> Loader Class Initialized
INFO - 2023-04-20 10:16:04 --> Helper loaded: url_helper
INFO - 2023-04-20 10:16:04 --> Helper loaded: file_helper
INFO - 2023-04-20 10:16:04 --> Helper loaded: html_helper
INFO - 2023-04-20 10:16:04 --> Helper loaded: text_helper
INFO - 2023-04-20 10:16:04 --> Helper loaded: form_helper
INFO - 2023-04-20 10:16:04 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:16:04 --> Helper loaded: security_helper
INFO - 2023-04-20 10:16:04 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:16:04 --> Database Driver Class Initialized
INFO - 2023-04-20 10:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:16:04 --> Parser Class Initialized
INFO - 2023-04-20 10:16:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:16:04 --> Pagination Class Initialized
INFO - 2023-04-20 10:16:04 --> Form Validation Class Initialized
INFO - 2023-04-20 10:16:04 --> Controller Class Initialized
DEBUG - 2023-04-20 10:16:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:16:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:16:04 --> Model Class Initialized
DEBUG - 2023-04-20 10:16:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:16:04 --> Model Class Initialized
DEBUG - 2023-04-20 10:16:04 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:16:04 --> Model Class Initialized
INFO - 2023-04-20 10:16:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-04-20 10:16:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:16:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 10:16:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 10:16:04 --> Model Class Initialized
INFO - 2023-04-20 10:16:04 --> Model Class Initialized
INFO - 2023-04-20 10:16:04 --> Model Class Initialized
INFO - 2023-04-20 10:16:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 10:16:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 10:16:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 10:16:04 --> Final output sent to browser
DEBUG - 2023-04-20 10:16:04 --> Total execution time: 0.1496
ERROR - 2023-04-20 10:16:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:16:05 --> Config Class Initialized
INFO - 2023-04-20 10:16:05 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:16:05 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:16:05 --> Utf8 Class Initialized
INFO - 2023-04-20 10:16:05 --> URI Class Initialized
INFO - 2023-04-20 10:16:05 --> Router Class Initialized
INFO - 2023-04-20 10:16:05 --> Output Class Initialized
INFO - 2023-04-20 10:16:05 --> Security Class Initialized
DEBUG - 2023-04-20 10:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:16:05 --> Input Class Initialized
INFO - 2023-04-20 10:16:05 --> Language Class Initialized
INFO - 2023-04-20 10:16:05 --> Loader Class Initialized
INFO - 2023-04-20 10:16:05 --> Helper loaded: url_helper
INFO - 2023-04-20 10:16:05 --> Helper loaded: file_helper
INFO - 2023-04-20 10:16:05 --> Helper loaded: html_helper
INFO - 2023-04-20 10:16:05 --> Helper loaded: text_helper
INFO - 2023-04-20 10:16:05 --> Helper loaded: form_helper
INFO - 2023-04-20 10:16:05 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:16:05 --> Helper loaded: security_helper
INFO - 2023-04-20 10:16:05 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:16:05 --> Database Driver Class Initialized
INFO - 2023-04-20 10:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:16:05 --> Parser Class Initialized
INFO - 2023-04-20 10:16:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:16:05 --> Pagination Class Initialized
INFO - 2023-04-20 10:16:05 --> Form Validation Class Initialized
INFO - 2023-04-20 10:16:05 --> Controller Class Initialized
DEBUG - 2023-04-20 10:16:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:16:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:16:05 --> Model Class Initialized
DEBUG - 2023-04-20 10:16:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:16:05 --> Model Class Initialized
INFO - 2023-04-20 10:16:05 --> Final output sent to browser
DEBUG - 2023-04-20 10:16:05 --> Total execution time: 0.0297
ERROR - 2023-04-20 10:16:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:16:09 --> Config Class Initialized
INFO - 2023-04-20 10:16:09 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:16:09 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:16:09 --> Utf8 Class Initialized
INFO - 2023-04-20 10:16:09 --> URI Class Initialized
INFO - 2023-04-20 10:16:09 --> Router Class Initialized
INFO - 2023-04-20 10:16:09 --> Output Class Initialized
INFO - 2023-04-20 10:16:09 --> Security Class Initialized
DEBUG - 2023-04-20 10:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:16:09 --> Input Class Initialized
INFO - 2023-04-20 10:16:09 --> Language Class Initialized
INFO - 2023-04-20 10:16:09 --> Loader Class Initialized
INFO - 2023-04-20 10:16:09 --> Helper loaded: url_helper
INFO - 2023-04-20 10:16:09 --> Helper loaded: file_helper
INFO - 2023-04-20 10:16:09 --> Helper loaded: html_helper
INFO - 2023-04-20 10:16:09 --> Helper loaded: text_helper
INFO - 2023-04-20 10:16:09 --> Helper loaded: form_helper
INFO - 2023-04-20 10:16:09 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:16:09 --> Helper loaded: security_helper
INFO - 2023-04-20 10:16:09 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:16:09 --> Database Driver Class Initialized
INFO - 2023-04-20 10:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:16:09 --> Parser Class Initialized
INFO - 2023-04-20 10:16:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:16:09 --> Pagination Class Initialized
INFO - 2023-04-20 10:16:09 --> Form Validation Class Initialized
INFO - 2023-04-20 10:16:09 --> Controller Class Initialized
DEBUG - 2023-04-20 10:16:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:16:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:16:09 --> Model Class Initialized
DEBUG - 2023-04-20 10:16:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:16:09 --> Model Class Initialized
INFO - 2023-04-20 10:16:09 --> Final output sent to browser
DEBUG - 2023-04-20 10:16:09 --> Total execution time: 0.0819
ERROR - 2023-04-20 10:16:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:16:19 --> Config Class Initialized
INFO - 2023-04-20 10:16:19 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:16:19 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:16:19 --> Utf8 Class Initialized
INFO - 2023-04-20 10:16:19 --> URI Class Initialized
INFO - 2023-04-20 10:16:19 --> Router Class Initialized
INFO - 2023-04-20 10:16:19 --> Output Class Initialized
INFO - 2023-04-20 10:16:19 --> Security Class Initialized
DEBUG - 2023-04-20 10:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:16:19 --> Input Class Initialized
INFO - 2023-04-20 10:16:19 --> Language Class Initialized
INFO - 2023-04-20 10:16:19 --> Loader Class Initialized
INFO - 2023-04-20 10:16:19 --> Helper loaded: url_helper
INFO - 2023-04-20 10:16:19 --> Helper loaded: file_helper
INFO - 2023-04-20 10:16:19 --> Helper loaded: html_helper
INFO - 2023-04-20 10:16:19 --> Helper loaded: text_helper
INFO - 2023-04-20 10:16:19 --> Helper loaded: form_helper
INFO - 2023-04-20 10:16:19 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:16:19 --> Helper loaded: security_helper
INFO - 2023-04-20 10:16:19 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:16:19 --> Database Driver Class Initialized
INFO - 2023-04-20 10:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:16:19 --> Parser Class Initialized
INFO - 2023-04-20 10:16:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:16:19 --> Pagination Class Initialized
INFO - 2023-04-20 10:16:19 --> Form Validation Class Initialized
INFO - 2023-04-20 10:16:19 --> Controller Class Initialized
DEBUG - 2023-04-20 10:16:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:16:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:16:19 --> Model Class Initialized
DEBUG - 2023-04-20 10:16:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:16:19 --> Model Class Initialized
INFO - 2023-04-20 10:16:19 --> Final output sent to browser
DEBUG - 2023-04-20 10:16:19 --> Total execution time: 0.0152
ERROR - 2023-04-20 10:16:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:16:22 --> Config Class Initialized
INFO - 2023-04-20 10:16:22 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:16:22 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:16:22 --> Utf8 Class Initialized
INFO - 2023-04-20 10:16:22 --> URI Class Initialized
INFO - 2023-04-20 10:16:22 --> Router Class Initialized
INFO - 2023-04-20 10:16:22 --> Output Class Initialized
INFO - 2023-04-20 10:16:22 --> Security Class Initialized
DEBUG - 2023-04-20 10:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:16:22 --> Input Class Initialized
INFO - 2023-04-20 10:16:22 --> Language Class Initialized
INFO - 2023-04-20 10:16:22 --> Loader Class Initialized
INFO - 2023-04-20 10:16:22 --> Helper loaded: url_helper
INFO - 2023-04-20 10:16:22 --> Helper loaded: file_helper
INFO - 2023-04-20 10:16:22 --> Helper loaded: html_helper
INFO - 2023-04-20 10:16:22 --> Helper loaded: text_helper
INFO - 2023-04-20 10:16:22 --> Helper loaded: form_helper
INFO - 2023-04-20 10:16:22 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:16:22 --> Helper loaded: security_helper
INFO - 2023-04-20 10:16:22 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:16:22 --> Database Driver Class Initialized
INFO - 2023-04-20 10:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:16:22 --> Parser Class Initialized
INFO - 2023-04-20 10:16:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:16:22 --> Pagination Class Initialized
INFO - 2023-04-20 10:16:22 --> Form Validation Class Initialized
INFO - 2023-04-20 10:16:22 --> Controller Class Initialized
DEBUG - 2023-04-20 10:16:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:16:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:16:22 --> Model Class Initialized
DEBUG - 2023-04-20 10:16:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:16:22 --> Model Class Initialized
DEBUG - 2023-04-20 10:16:22 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:16:22 --> Model Class Initialized
INFO - 2023-04-20 10:16:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-04-20 10:16:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:16:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 10:16:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 10:16:22 --> Model Class Initialized
INFO - 2023-04-20 10:16:22 --> Model Class Initialized
INFO - 2023-04-20 10:16:22 --> Model Class Initialized
INFO - 2023-04-20 10:16:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 10:16:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 10:16:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 10:16:22 --> Final output sent to browser
DEBUG - 2023-04-20 10:16:22 --> Total execution time: 0.1700
ERROR - 2023-04-20 10:16:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:16:22 --> Config Class Initialized
INFO - 2023-04-20 10:16:22 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:16:22 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:16:22 --> Utf8 Class Initialized
INFO - 2023-04-20 10:16:22 --> URI Class Initialized
INFO - 2023-04-20 10:16:22 --> Router Class Initialized
INFO - 2023-04-20 10:16:22 --> Output Class Initialized
INFO - 2023-04-20 10:16:22 --> Security Class Initialized
DEBUG - 2023-04-20 10:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:16:22 --> Input Class Initialized
INFO - 2023-04-20 10:16:22 --> Language Class Initialized
INFO - 2023-04-20 10:16:22 --> Loader Class Initialized
INFO - 2023-04-20 10:16:22 --> Helper loaded: url_helper
INFO - 2023-04-20 10:16:22 --> Helper loaded: file_helper
INFO - 2023-04-20 10:16:22 --> Helper loaded: html_helper
INFO - 2023-04-20 10:16:22 --> Helper loaded: text_helper
INFO - 2023-04-20 10:16:22 --> Helper loaded: form_helper
INFO - 2023-04-20 10:16:22 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:16:22 --> Helper loaded: security_helper
INFO - 2023-04-20 10:16:22 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:16:22 --> Database Driver Class Initialized
INFO - 2023-04-20 10:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:16:22 --> Parser Class Initialized
INFO - 2023-04-20 10:16:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:16:22 --> Pagination Class Initialized
INFO - 2023-04-20 10:16:22 --> Form Validation Class Initialized
INFO - 2023-04-20 10:16:22 --> Controller Class Initialized
DEBUG - 2023-04-20 10:16:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:16:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:16:22 --> Model Class Initialized
DEBUG - 2023-04-20 10:16:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:16:22 --> Model Class Initialized
INFO - 2023-04-20 10:16:22 --> Final output sent to browser
DEBUG - 2023-04-20 10:16:22 --> Total execution time: 0.0312
ERROR - 2023-04-20 10:16:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:16:26 --> Config Class Initialized
INFO - 2023-04-20 10:16:26 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:16:26 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:16:26 --> Utf8 Class Initialized
INFO - 2023-04-20 10:16:26 --> URI Class Initialized
INFO - 2023-04-20 10:16:26 --> Router Class Initialized
INFO - 2023-04-20 10:16:26 --> Output Class Initialized
INFO - 2023-04-20 10:16:26 --> Security Class Initialized
DEBUG - 2023-04-20 10:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:16:26 --> Input Class Initialized
INFO - 2023-04-20 10:16:26 --> Language Class Initialized
INFO - 2023-04-20 10:16:26 --> Loader Class Initialized
INFO - 2023-04-20 10:16:26 --> Helper loaded: url_helper
INFO - 2023-04-20 10:16:26 --> Helper loaded: file_helper
INFO - 2023-04-20 10:16:26 --> Helper loaded: html_helper
INFO - 2023-04-20 10:16:26 --> Helper loaded: text_helper
INFO - 2023-04-20 10:16:26 --> Helper loaded: form_helper
INFO - 2023-04-20 10:16:26 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:16:26 --> Helper loaded: security_helper
INFO - 2023-04-20 10:16:26 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:16:26 --> Database Driver Class Initialized
INFO - 2023-04-20 10:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:16:26 --> Parser Class Initialized
INFO - 2023-04-20 10:16:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:16:26 --> Pagination Class Initialized
INFO - 2023-04-20 10:16:26 --> Form Validation Class Initialized
INFO - 2023-04-20 10:16:26 --> Controller Class Initialized
DEBUG - 2023-04-20 10:16:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:16:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:16:26 --> Model Class Initialized
DEBUG - 2023-04-20 10:16:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:16:26 --> Model Class Initialized
INFO - 2023-04-20 10:16:26 --> Final output sent to browser
DEBUG - 2023-04-20 10:16:26 --> Total execution time: 0.0800
ERROR - 2023-04-20 10:16:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:16:33 --> Config Class Initialized
INFO - 2023-04-20 10:16:33 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:16:33 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:16:33 --> Utf8 Class Initialized
INFO - 2023-04-20 10:16:33 --> URI Class Initialized
INFO - 2023-04-20 10:16:33 --> Router Class Initialized
INFO - 2023-04-20 10:16:33 --> Output Class Initialized
INFO - 2023-04-20 10:16:33 --> Security Class Initialized
DEBUG - 2023-04-20 10:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:16:33 --> Input Class Initialized
INFO - 2023-04-20 10:16:33 --> Language Class Initialized
INFO - 2023-04-20 10:16:33 --> Loader Class Initialized
INFO - 2023-04-20 10:16:33 --> Helper loaded: url_helper
INFO - 2023-04-20 10:16:33 --> Helper loaded: file_helper
INFO - 2023-04-20 10:16:33 --> Helper loaded: html_helper
INFO - 2023-04-20 10:16:33 --> Helper loaded: text_helper
INFO - 2023-04-20 10:16:33 --> Helper loaded: form_helper
INFO - 2023-04-20 10:16:33 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:16:33 --> Helper loaded: security_helper
INFO - 2023-04-20 10:16:33 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:16:33 --> Database Driver Class Initialized
INFO - 2023-04-20 10:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:16:33 --> Parser Class Initialized
INFO - 2023-04-20 10:16:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:16:33 --> Pagination Class Initialized
INFO - 2023-04-20 10:16:33 --> Form Validation Class Initialized
INFO - 2023-04-20 10:16:33 --> Controller Class Initialized
DEBUG - 2023-04-20 10:16:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:16:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:16:33 --> Model Class Initialized
DEBUG - 2023-04-20 10:16:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:16:33 --> Model Class Initialized
DEBUG - 2023-04-20 10:16:33 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:16:33 --> Model Class Initialized
INFO - 2023-04-20 10:16:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-04-20 10:16:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:16:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 10:16:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 10:16:33 --> Model Class Initialized
INFO - 2023-04-20 10:16:33 --> Model Class Initialized
INFO - 2023-04-20 10:16:33 --> Model Class Initialized
INFO - 2023-04-20 10:16:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 10:16:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 10:16:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 10:16:33 --> Final output sent to browser
DEBUG - 2023-04-20 10:16:33 --> Total execution time: 0.1563
ERROR - 2023-04-20 10:16:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:16:34 --> Config Class Initialized
INFO - 2023-04-20 10:16:34 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:16:34 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:16:34 --> Utf8 Class Initialized
INFO - 2023-04-20 10:16:34 --> URI Class Initialized
INFO - 2023-04-20 10:16:34 --> Router Class Initialized
INFO - 2023-04-20 10:16:34 --> Output Class Initialized
INFO - 2023-04-20 10:16:34 --> Security Class Initialized
DEBUG - 2023-04-20 10:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:16:34 --> Input Class Initialized
INFO - 2023-04-20 10:16:34 --> Language Class Initialized
INFO - 2023-04-20 10:16:34 --> Loader Class Initialized
INFO - 2023-04-20 10:16:34 --> Helper loaded: url_helper
INFO - 2023-04-20 10:16:34 --> Helper loaded: file_helper
INFO - 2023-04-20 10:16:34 --> Helper loaded: html_helper
INFO - 2023-04-20 10:16:34 --> Helper loaded: text_helper
INFO - 2023-04-20 10:16:34 --> Helper loaded: form_helper
INFO - 2023-04-20 10:16:34 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:16:34 --> Helper loaded: security_helper
INFO - 2023-04-20 10:16:34 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:16:34 --> Database Driver Class Initialized
INFO - 2023-04-20 10:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:16:34 --> Parser Class Initialized
INFO - 2023-04-20 10:16:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:16:34 --> Pagination Class Initialized
INFO - 2023-04-20 10:16:34 --> Form Validation Class Initialized
INFO - 2023-04-20 10:16:34 --> Controller Class Initialized
DEBUG - 2023-04-20 10:16:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:16:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:16:34 --> Model Class Initialized
DEBUG - 2023-04-20 10:16:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:16:34 --> Model Class Initialized
INFO - 2023-04-20 10:16:34 --> Final output sent to browser
DEBUG - 2023-04-20 10:16:34 --> Total execution time: 0.0346
ERROR - 2023-04-20 10:16:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:16:37 --> Config Class Initialized
INFO - 2023-04-20 10:16:37 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:16:37 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:16:37 --> Utf8 Class Initialized
INFO - 2023-04-20 10:16:37 --> URI Class Initialized
INFO - 2023-04-20 10:16:37 --> Router Class Initialized
INFO - 2023-04-20 10:16:37 --> Output Class Initialized
INFO - 2023-04-20 10:16:37 --> Security Class Initialized
DEBUG - 2023-04-20 10:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:16:37 --> Input Class Initialized
INFO - 2023-04-20 10:16:37 --> Language Class Initialized
INFO - 2023-04-20 10:16:37 --> Loader Class Initialized
INFO - 2023-04-20 10:16:37 --> Helper loaded: url_helper
INFO - 2023-04-20 10:16:37 --> Helper loaded: file_helper
INFO - 2023-04-20 10:16:37 --> Helper loaded: html_helper
INFO - 2023-04-20 10:16:37 --> Helper loaded: text_helper
INFO - 2023-04-20 10:16:37 --> Helper loaded: form_helper
INFO - 2023-04-20 10:16:37 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:16:37 --> Helper loaded: security_helper
INFO - 2023-04-20 10:16:37 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:16:37 --> Database Driver Class Initialized
INFO - 2023-04-20 10:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:16:37 --> Parser Class Initialized
INFO - 2023-04-20 10:16:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:16:37 --> Pagination Class Initialized
INFO - 2023-04-20 10:16:37 --> Form Validation Class Initialized
INFO - 2023-04-20 10:16:37 --> Controller Class Initialized
DEBUG - 2023-04-20 10:16:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:16:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:16:37 --> Model Class Initialized
DEBUG - 2023-04-20 10:16:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:16:37 --> Model Class Initialized
INFO - 2023-04-20 10:16:37 --> Final output sent to browser
DEBUG - 2023-04-20 10:16:37 --> Total execution time: 0.0851
ERROR - 2023-04-20 10:16:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:16:51 --> Config Class Initialized
INFO - 2023-04-20 10:16:51 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:16:51 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:16:51 --> Utf8 Class Initialized
INFO - 2023-04-20 10:16:51 --> URI Class Initialized
INFO - 2023-04-20 10:16:51 --> Router Class Initialized
INFO - 2023-04-20 10:16:51 --> Output Class Initialized
INFO - 2023-04-20 10:16:51 --> Security Class Initialized
DEBUG - 2023-04-20 10:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:16:51 --> Input Class Initialized
INFO - 2023-04-20 10:16:51 --> Language Class Initialized
INFO - 2023-04-20 10:16:51 --> Loader Class Initialized
INFO - 2023-04-20 10:16:51 --> Helper loaded: url_helper
INFO - 2023-04-20 10:16:51 --> Helper loaded: file_helper
INFO - 2023-04-20 10:16:51 --> Helper loaded: html_helper
INFO - 2023-04-20 10:16:51 --> Helper loaded: text_helper
INFO - 2023-04-20 10:16:51 --> Helper loaded: form_helper
INFO - 2023-04-20 10:16:51 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:16:51 --> Helper loaded: security_helper
INFO - 2023-04-20 10:16:51 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:16:51 --> Database Driver Class Initialized
INFO - 2023-04-20 10:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:16:51 --> Parser Class Initialized
INFO - 2023-04-20 10:16:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:16:51 --> Pagination Class Initialized
INFO - 2023-04-20 10:16:51 --> Form Validation Class Initialized
INFO - 2023-04-20 10:16:51 --> Controller Class Initialized
DEBUG - 2023-04-20 10:16:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:16:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:16:51 --> Model Class Initialized
DEBUG - 2023-04-20 10:16:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:16:51 --> Model Class Initialized
INFO - 2023-04-20 10:16:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/view_customer.php
DEBUG - 2023-04-20 10:16:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:16:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 10:16:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 10:16:51 --> Model Class Initialized
INFO - 2023-04-20 10:16:51 --> Model Class Initialized
INFO - 2023-04-20 10:16:51 --> Model Class Initialized
INFO - 2023-04-20 10:16:51 --> Model Class Initialized
INFO - 2023-04-20 10:16:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 10:16:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 10:16:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 10:16:51 --> Final output sent to browser
DEBUG - 2023-04-20 10:16:51 --> Total execution time: 0.1514
ERROR - 2023-04-20 10:17:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:17:10 --> Config Class Initialized
INFO - 2023-04-20 10:17:10 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:17:10 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:17:10 --> Utf8 Class Initialized
INFO - 2023-04-20 10:17:10 --> URI Class Initialized
INFO - 2023-04-20 10:17:10 --> Router Class Initialized
INFO - 2023-04-20 10:17:10 --> Output Class Initialized
INFO - 2023-04-20 10:17:10 --> Security Class Initialized
DEBUG - 2023-04-20 10:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:17:10 --> Input Class Initialized
INFO - 2023-04-20 10:17:10 --> Language Class Initialized
INFO - 2023-04-20 10:17:10 --> Loader Class Initialized
INFO - 2023-04-20 10:17:10 --> Helper loaded: url_helper
INFO - 2023-04-20 10:17:10 --> Helper loaded: file_helper
INFO - 2023-04-20 10:17:10 --> Helper loaded: html_helper
INFO - 2023-04-20 10:17:10 --> Helper loaded: text_helper
INFO - 2023-04-20 10:17:10 --> Helper loaded: form_helper
INFO - 2023-04-20 10:17:10 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:17:10 --> Helper loaded: security_helper
INFO - 2023-04-20 10:17:10 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:17:10 --> Database Driver Class Initialized
INFO - 2023-04-20 10:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:17:10 --> Parser Class Initialized
INFO - 2023-04-20 10:17:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:17:10 --> Pagination Class Initialized
INFO - 2023-04-20 10:17:10 --> Form Validation Class Initialized
INFO - 2023-04-20 10:17:10 --> Controller Class Initialized
INFO - 2023-04-20 10:17:10 --> Model Class Initialized
DEBUG - 2023-04-20 10:17:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:17:10 --> Model Class Initialized
INFO - 2023-04-20 10:17:10 --> Final output sent to browser
DEBUG - 2023-04-20 10:17:10 --> Total execution time: 0.0195
ERROR - 2023-04-20 10:17:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:17:10 --> Config Class Initialized
INFO - 2023-04-20 10:17:10 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:17:10 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:17:10 --> Utf8 Class Initialized
INFO - 2023-04-20 10:17:10 --> URI Class Initialized
INFO - 2023-04-20 10:17:10 --> Router Class Initialized
INFO - 2023-04-20 10:17:10 --> Output Class Initialized
INFO - 2023-04-20 10:17:10 --> Security Class Initialized
DEBUG - 2023-04-20 10:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:17:10 --> Input Class Initialized
INFO - 2023-04-20 10:17:10 --> Language Class Initialized
INFO - 2023-04-20 10:17:10 --> Loader Class Initialized
INFO - 2023-04-20 10:17:10 --> Helper loaded: url_helper
INFO - 2023-04-20 10:17:10 --> Helper loaded: file_helper
INFO - 2023-04-20 10:17:10 --> Helper loaded: html_helper
INFO - 2023-04-20 10:17:10 --> Helper loaded: text_helper
INFO - 2023-04-20 10:17:10 --> Helper loaded: form_helper
INFO - 2023-04-20 10:17:10 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:17:10 --> Helper loaded: security_helper
INFO - 2023-04-20 10:17:10 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:17:10 --> Database Driver Class Initialized
INFO - 2023-04-20 10:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:17:10 --> Parser Class Initialized
INFO - 2023-04-20 10:17:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:17:10 --> Pagination Class Initialized
INFO - 2023-04-20 10:17:10 --> Form Validation Class Initialized
INFO - 2023-04-20 10:17:10 --> Controller Class Initialized
INFO - 2023-04-20 10:17:10 --> Model Class Initialized
DEBUG - 2023-04-20 10:17:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:17:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-20 10:17:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:17:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 10:17:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 10:17:10 --> Model Class Initialized
INFO - 2023-04-20 10:17:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 10:17:10 --> Final output sent to browser
DEBUG - 2023-04-20 10:17:10 --> Total execution time: 0.0352
ERROR - 2023-04-20 10:18:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:18:03 --> Config Class Initialized
INFO - 2023-04-20 10:18:03 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:18:03 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:18:03 --> Utf8 Class Initialized
INFO - 2023-04-20 10:18:03 --> URI Class Initialized
INFO - 2023-04-20 10:18:03 --> Router Class Initialized
INFO - 2023-04-20 10:18:03 --> Output Class Initialized
INFO - 2023-04-20 10:18:03 --> Security Class Initialized
DEBUG - 2023-04-20 10:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:18:03 --> Input Class Initialized
INFO - 2023-04-20 10:18:03 --> Language Class Initialized
INFO - 2023-04-20 10:18:03 --> Loader Class Initialized
INFO - 2023-04-20 10:18:03 --> Helper loaded: url_helper
INFO - 2023-04-20 10:18:03 --> Helper loaded: file_helper
INFO - 2023-04-20 10:18:03 --> Helper loaded: html_helper
INFO - 2023-04-20 10:18:03 --> Helper loaded: text_helper
INFO - 2023-04-20 10:18:03 --> Helper loaded: form_helper
INFO - 2023-04-20 10:18:03 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:18:03 --> Helper loaded: security_helper
INFO - 2023-04-20 10:18:03 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:18:03 --> Database Driver Class Initialized
INFO - 2023-04-20 10:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:18:03 --> Parser Class Initialized
INFO - 2023-04-20 10:18:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:18:03 --> Pagination Class Initialized
INFO - 2023-04-20 10:18:03 --> Form Validation Class Initialized
INFO - 2023-04-20 10:18:03 --> Controller Class Initialized
DEBUG - 2023-04-20 10:18:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:18:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:18:03 --> Model Class Initialized
DEBUG - 2023-04-20 10:18:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:18:03 --> Model Class Initialized
INFO - 2023-04-20 10:18:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/view_customer.php
DEBUG - 2023-04-20 10:18:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:18:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 10:18:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 10:18:03 --> Model Class Initialized
INFO - 2023-04-20 10:18:03 --> Model Class Initialized
INFO - 2023-04-20 10:18:03 --> Model Class Initialized
INFO - 2023-04-20 10:18:03 --> Model Class Initialized
INFO - 2023-04-20 10:18:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 10:18:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 10:18:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 10:18:03 --> Final output sent to browser
DEBUG - 2023-04-20 10:18:03 --> Total execution time: 0.1610
ERROR - 2023-04-20 10:18:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:18:13 --> Config Class Initialized
INFO - 2023-04-20 10:18:13 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:18:13 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:18:13 --> Utf8 Class Initialized
INFO - 2023-04-20 10:18:13 --> URI Class Initialized
DEBUG - 2023-04-20 10:18:13 --> No URI present. Default controller set.
INFO - 2023-04-20 10:18:13 --> Router Class Initialized
INFO - 2023-04-20 10:18:13 --> Output Class Initialized
INFO - 2023-04-20 10:18:13 --> Security Class Initialized
DEBUG - 2023-04-20 10:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:18:13 --> Input Class Initialized
INFO - 2023-04-20 10:18:13 --> Language Class Initialized
INFO - 2023-04-20 10:18:13 --> Loader Class Initialized
INFO - 2023-04-20 10:18:13 --> Helper loaded: url_helper
INFO - 2023-04-20 10:18:13 --> Helper loaded: file_helper
INFO - 2023-04-20 10:18:13 --> Helper loaded: html_helper
INFO - 2023-04-20 10:18:13 --> Helper loaded: text_helper
INFO - 2023-04-20 10:18:13 --> Helper loaded: form_helper
INFO - 2023-04-20 10:18:13 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:18:13 --> Helper loaded: security_helper
INFO - 2023-04-20 10:18:13 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:18:13 --> Database Driver Class Initialized
INFO - 2023-04-20 10:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:18:13 --> Parser Class Initialized
INFO - 2023-04-20 10:18:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:18:13 --> Pagination Class Initialized
INFO - 2023-04-20 10:18:13 --> Form Validation Class Initialized
INFO - 2023-04-20 10:18:13 --> Controller Class Initialized
INFO - 2023-04-20 10:18:13 --> Model Class Initialized
DEBUG - 2023-04-20 10:18:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-20 10:18:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:18:14 --> Config Class Initialized
INFO - 2023-04-20 10:18:14 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:18:14 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:18:14 --> Utf8 Class Initialized
INFO - 2023-04-20 10:18:14 --> URI Class Initialized
INFO - 2023-04-20 10:18:14 --> Router Class Initialized
INFO - 2023-04-20 10:18:14 --> Output Class Initialized
INFO - 2023-04-20 10:18:14 --> Security Class Initialized
DEBUG - 2023-04-20 10:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:18:14 --> Input Class Initialized
INFO - 2023-04-20 10:18:14 --> Language Class Initialized
ERROR - 2023-04-20 10:18:14 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2023-04-20 10:18:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:18:14 --> Config Class Initialized
INFO - 2023-04-20 10:18:14 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:18:14 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:18:14 --> Utf8 Class Initialized
INFO - 2023-04-20 10:18:14 --> URI Class Initialized
INFO - 2023-04-20 10:18:14 --> Router Class Initialized
INFO - 2023-04-20 10:18:14 --> Output Class Initialized
INFO - 2023-04-20 10:18:14 --> Security Class Initialized
DEBUG - 2023-04-20 10:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:18:14 --> Input Class Initialized
INFO - 2023-04-20 10:18:14 --> Language Class Initialized
INFO - 2023-04-20 10:18:14 --> Loader Class Initialized
INFO - 2023-04-20 10:18:14 --> Helper loaded: url_helper
INFO - 2023-04-20 10:18:14 --> Helper loaded: file_helper
INFO - 2023-04-20 10:18:14 --> Helper loaded: html_helper
INFO - 2023-04-20 10:18:14 --> Helper loaded: text_helper
INFO - 2023-04-20 10:18:14 --> Helper loaded: form_helper
INFO - 2023-04-20 10:18:14 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:18:14 --> Helper loaded: security_helper
INFO - 2023-04-20 10:18:14 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:18:14 --> Database Driver Class Initialized
INFO - 2023-04-20 10:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:18:14 --> Parser Class Initialized
INFO - 2023-04-20 10:18:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:18:14 --> Pagination Class Initialized
INFO - 2023-04-20 10:18:14 --> Form Validation Class Initialized
INFO - 2023-04-20 10:18:14 --> Controller Class Initialized
INFO - 2023-04-20 10:18:14 --> Model Class Initialized
DEBUG - 2023-04-20 10:18:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:18:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-20 10:18:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:18:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 10:18:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 10:18:14 --> Model Class Initialized
INFO - 2023-04-20 10:18:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 10:18:14 --> Final output sent to browser
DEBUG - 2023-04-20 10:18:14 --> Total execution time: 0.0300
ERROR - 2023-04-20 10:18:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:18:14 --> Config Class Initialized
INFO - 2023-04-20 10:18:14 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:18:14 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:18:14 --> Utf8 Class Initialized
INFO - 2023-04-20 10:18:14 --> URI Class Initialized
INFO - 2023-04-20 10:18:14 --> Router Class Initialized
INFO - 2023-04-20 10:18:14 --> Output Class Initialized
INFO - 2023-04-20 10:18:14 --> Security Class Initialized
DEBUG - 2023-04-20 10:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:18:14 --> Input Class Initialized
INFO - 2023-04-20 10:18:14 --> Language Class Initialized
ERROR - 2023-04-20 10:18:14 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2023-04-20 10:18:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:18:19 --> Config Class Initialized
INFO - 2023-04-20 10:18:19 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:18:19 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:18:19 --> Utf8 Class Initialized
INFO - 2023-04-20 10:18:19 --> URI Class Initialized
INFO - 2023-04-20 10:18:19 --> Router Class Initialized
INFO - 2023-04-20 10:18:19 --> Output Class Initialized
INFO - 2023-04-20 10:18:19 --> Security Class Initialized
DEBUG - 2023-04-20 10:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:18:19 --> Input Class Initialized
INFO - 2023-04-20 10:18:19 --> Language Class Initialized
INFO - 2023-04-20 10:18:19 --> Loader Class Initialized
INFO - 2023-04-20 10:18:19 --> Helper loaded: url_helper
INFO - 2023-04-20 10:18:19 --> Helper loaded: file_helper
INFO - 2023-04-20 10:18:19 --> Helper loaded: html_helper
INFO - 2023-04-20 10:18:19 --> Helper loaded: text_helper
INFO - 2023-04-20 10:18:19 --> Helper loaded: form_helper
INFO - 2023-04-20 10:18:19 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:18:19 --> Helper loaded: security_helper
INFO - 2023-04-20 10:18:19 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:18:19 --> Database Driver Class Initialized
INFO - 2023-04-20 10:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:18:19 --> Parser Class Initialized
INFO - 2023-04-20 10:18:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:18:19 --> Pagination Class Initialized
INFO - 2023-04-20 10:18:19 --> Form Validation Class Initialized
INFO - 2023-04-20 10:18:19 --> Controller Class Initialized
DEBUG - 2023-04-20 10:18:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:18:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:18:19 --> Model Class Initialized
DEBUG - 2023-04-20 10:18:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:18:19 --> Model Class Initialized
DEBUG - 2023-04-20 10:18:19 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:18:19 --> Model Class Initialized
INFO - 2023-04-20 10:18:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-04-20 10:18:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:18:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 10:18:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 10:18:19 --> Model Class Initialized
INFO - 2023-04-20 10:18:19 --> Model Class Initialized
INFO - 2023-04-20 10:18:19 --> Model Class Initialized
INFO - 2023-04-20 10:18:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 10:18:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 10:18:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 10:18:19 --> Final output sent to browser
DEBUG - 2023-04-20 10:18:19 --> Total execution time: 0.1704
ERROR - 2023-04-20 10:18:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:18:20 --> Config Class Initialized
INFO - 2023-04-20 10:18:20 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:18:20 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:18:20 --> Utf8 Class Initialized
INFO - 2023-04-20 10:18:20 --> URI Class Initialized
INFO - 2023-04-20 10:18:20 --> Router Class Initialized
INFO - 2023-04-20 10:18:20 --> Output Class Initialized
INFO - 2023-04-20 10:18:20 --> Security Class Initialized
DEBUG - 2023-04-20 10:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:18:20 --> Input Class Initialized
INFO - 2023-04-20 10:18:20 --> Language Class Initialized
INFO - 2023-04-20 10:18:20 --> Loader Class Initialized
INFO - 2023-04-20 10:18:20 --> Helper loaded: url_helper
INFO - 2023-04-20 10:18:20 --> Helper loaded: file_helper
INFO - 2023-04-20 10:18:20 --> Helper loaded: html_helper
INFO - 2023-04-20 10:18:20 --> Helper loaded: text_helper
INFO - 2023-04-20 10:18:20 --> Helper loaded: form_helper
INFO - 2023-04-20 10:18:20 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:18:20 --> Helper loaded: security_helper
INFO - 2023-04-20 10:18:20 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:18:20 --> Database Driver Class Initialized
INFO - 2023-04-20 10:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:18:20 --> Parser Class Initialized
INFO - 2023-04-20 10:18:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:18:20 --> Pagination Class Initialized
INFO - 2023-04-20 10:18:20 --> Form Validation Class Initialized
INFO - 2023-04-20 10:18:20 --> Controller Class Initialized
DEBUG - 2023-04-20 10:18:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:18:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:18:20 --> Model Class Initialized
DEBUG - 2023-04-20 10:18:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:18:20 --> Model Class Initialized
INFO - 2023-04-20 10:18:20 --> Final output sent to browser
DEBUG - 2023-04-20 10:18:20 --> Total execution time: 0.0313
ERROR - 2023-04-20 10:18:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:18:24 --> Config Class Initialized
INFO - 2023-04-20 10:18:24 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:18:24 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:18:24 --> Utf8 Class Initialized
INFO - 2023-04-20 10:18:24 --> URI Class Initialized
INFO - 2023-04-20 10:18:24 --> Router Class Initialized
INFO - 2023-04-20 10:18:24 --> Output Class Initialized
INFO - 2023-04-20 10:18:24 --> Security Class Initialized
DEBUG - 2023-04-20 10:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:18:24 --> Input Class Initialized
INFO - 2023-04-20 10:18:24 --> Language Class Initialized
INFO - 2023-04-20 10:18:24 --> Loader Class Initialized
INFO - 2023-04-20 10:18:24 --> Helper loaded: url_helper
INFO - 2023-04-20 10:18:24 --> Helper loaded: file_helper
INFO - 2023-04-20 10:18:24 --> Helper loaded: html_helper
INFO - 2023-04-20 10:18:24 --> Helper loaded: text_helper
INFO - 2023-04-20 10:18:24 --> Helper loaded: form_helper
INFO - 2023-04-20 10:18:24 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:18:24 --> Helper loaded: security_helper
INFO - 2023-04-20 10:18:24 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:18:24 --> Database Driver Class Initialized
INFO - 2023-04-20 10:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:18:24 --> Parser Class Initialized
INFO - 2023-04-20 10:18:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:18:24 --> Pagination Class Initialized
INFO - 2023-04-20 10:18:24 --> Form Validation Class Initialized
INFO - 2023-04-20 10:18:24 --> Controller Class Initialized
DEBUG - 2023-04-20 10:18:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:18:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:18:24 --> Model Class Initialized
DEBUG - 2023-04-20 10:18:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:18:24 --> Model Class Initialized
INFO - 2023-04-20 10:18:24 --> Final output sent to browser
DEBUG - 2023-04-20 10:18:24 --> Total execution time: 0.0818
ERROR - 2023-04-20 10:18:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:18:29 --> Config Class Initialized
INFO - 2023-04-20 10:18:29 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:18:29 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:18:29 --> Utf8 Class Initialized
INFO - 2023-04-20 10:18:29 --> URI Class Initialized
INFO - 2023-04-20 10:18:29 --> Router Class Initialized
INFO - 2023-04-20 10:18:29 --> Output Class Initialized
INFO - 2023-04-20 10:18:29 --> Security Class Initialized
DEBUG - 2023-04-20 10:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:18:29 --> Input Class Initialized
INFO - 2023-04-20 10:18:29 --> Language Class Initialized
INFO - 2023-04-20 10:18:29 --> Loader Class Initialized
INFO - 2023-04-20 10:18:29 --> Helper loaded: url_helper
INFO - 2023-04-20 10:18:29 --> Helper loaded: file_helper
INFO - 2023-04-20 10:18:29 --> Helper loaded: html_helper
INFO - 2023-04-20 10:18:29 --> Helper loaded: text_helper
INFO - 2023-04-20 10:18:29 --> Helper loaded: form_helper
INFO - 2023-04-20 10:18:29 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:18:29 --> Helper loaded: security_helper
INFO - 2023-04-20 10:18:29 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:18:29 --> Database Driver Class Initialized
INFO - 2023-04-20 10:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:18:29 --> Parser Class Initialized
INFO - 2023-04-20 10:18:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:18:29 --> Pagination Class Initialized
INFO - 2023-04-20 10:18:29 --> Form Validation Class Initialized
INFO - 2023-04-20 10:18:29 --> Controller Class Initialized
DEBUG - 2023-04-20 10:18:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:18:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:18:29 --> Model Class Initialized
DEBUG - 2023-04-20 10:18:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:18:29 --> Model Class Initialized
INFO - 2023-04-20 10:18:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/view_customer.php
DEBUG - 2023-04-20 10:18:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:18:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 10:18:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 10:18:29 --> Model Class Initialized
INFO - 2023-04-20 10:18:29 --> Model Class Initialized
INFO - 2023-04-20 10:18:29 --> Model Class Initialized
INFO - 2023-04-20 10:18:29 --> Model Class Initialized
INFO - 2023-04-20 10:18:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 10:18:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 10:18:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 10:18:30 --> Final output sent to browser
DEBUG - 2023-04-20 10:18:30 --> Total execution time: 0.1522
ERROR - 2023-04-20 10:18:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:18:51 --> Config Class Initialized
INFO - 2023-04-20 10:18:51 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:18:51 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:18:51 --> Utf8 Class Initialized
INFO - 2023-04-20 10:18:51 --> URI Class Initialized
INFO - 2023-04-20 10:18:51 --> Router Class Initialized
INFO - 2023-04-20 10:18:51 --> Output Class Initialized
INFO - 2023-04-20 10:18:51 --> Security Class Initialized
DEBUG - 2023-04-20 10:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:18:51 --> Input Class Initialized
INFO - 2023-04-20 10:18:51 --> Language Class Initialized
INFO - 2023-04-20 10:18:51 --> Loader Class Initialized
INFO - 2023-04-20 10:18:51 --> Helper loaded: url_helper
INFO - 2023-04-20 10:18:51 --> Helper loaded: file_helper
INFO - 2023-04-20 10:18:51 --> Helper loaded: html_helper
INFO - 2023-04-20 10:18:51 --> Helper loaded: text_helper
INFO - 2023-04-20 10:18:51 --> Helper loaded: form_helper
INFO - 2023-04-20 10:18:51 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:18:51 --> Helper loaded: security_helper
INFO - 2023-04-20 10:18:51 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:18:51 --> Database Driver Class Initialized
INFO - 2023-04-20 10:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:18:51 --> Parser Class Initialized
INFO - 2023-04-20 10:18:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:18:51 --> Pagination Class Initialized
INFO - 2023-04-20 10:18:51 --> Form Validation Class Initialized
INFO - 2023-04-20 10:18:51 --> Controller Class Initialized
INFO - 2023-04-20 10:18:51 --> Model Class Initialized
DEBUG - 2023-04-20 10:18:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:18:51 --> Model Class Initialized
INFO - 2023-04-20 10:18:51 --> Final output sent to browser
DEBUG - 2023-04-20 10:18:51 --> Total execution time: 0.0218
ERROR - 2023-04-20 10:18:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:18:51 --> Config Class Initialized
INFO - 2023-04-20 10:18:51 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:18:51 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:18:51 --> Utf8 Class Initialized
INFO - 2023-04-20 10:18:51 --> URI Class Initialized
INFO - 2023-04-20 10:18:51 --> Router Class Initialized
INFO - 2023-04-20 10:18:51 --> Output Class Initialized
INFO - 2023-04-20 10:18:51 --> Security Class Initialized
DEBUG - 2023-04-20 10:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:18:51 --> Input Class Initialized
INFO - 2023-04-20 10:18:51 --> Language Class Initialized
INFO - 2023-04-20 10:18:51 --> Loader Class Initialized
INFO - 2023-04-20 10:18:51 --> Helper loaded: url_helper
INFO - 2023-04-20 10:18:51 --> Helper loaded: file_helper
INFO - 2023-04-20 10:18:51 --> Helper loaded: html_helper
INFO - 2023-04-20 10:18:51 --> Helper loaded: text_helper
INFO - 2023-04-20 10:18:51 --> Helper loaded: form_helper
INFO - 2023-04-20 10:18:51 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:18:51 --> Helper loaded: security_helper
INFO - 2023-04-20 10:18:51 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:18:51 --> Database Driver Class Initialized
INFO - 2023-04-20 10:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:18:51 --> Parser Class Initialized
INFO - 2023-04-20 10:18:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:18:51 --> Pagination Class Initialized
INFO - 2023-04-20 10:18:51 --> Form Validation Class Initialized
INFO - 2023-04-20 10:18:51 --> Controller Class Initialized
INFO - 2023-04-20 10:18:51 --> Model Class Initialized
DEBUG - 2023-04-20 10:18:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:18:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-20 10:18:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:18:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 10:18:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 10:18:51 --> Model Class Initialized
INFO - 2023-04-20 10:18:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 10:18:51 --> Final output sent to browser
DEBUG - 2023-04-20 10:18:51 --> Total execution time: 0.0292
ERROR - 2023-04-20 10:21:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:21:33 --> Config Class Initialized
INFO - 2023-04-20 10:21:33 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:21:33 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:21:33 --> Utf8 Class Initialized
INFO - 2023-04-20 10:21:33 --> URI Class Initialized
INFO - 2023-04-20 10:21:33 --> Router Class Initialized
INFO - 2023-04-20 10:21:33 --> Output Class Initialized
INFO - 2023-04-20 10:21:33 --> Security Class Initialized
DEBUG - 2023-04-20 10:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:21:33 --> Input Class Initialized
INFO - 2023-04-20 10:21:33 --> Language Class Initialized
INFO - 2023-04-20 10:21:33 --> Loader Class Initialized
INFO - 2023-04-20 10:21:33 --> Helper loaded: url_helper
INFO - 2023-04-20 10:21:33 --> Helper loaded: file_helper
INFO - 2023-04-20 10:21:33 --> Helper loaded: html_helper
INFO - 2023-04-20 10:21:33 --> Helper loaded: text_helper
INFO - 2023-04-20 10:21:33 --> Helper loaded: form_helper
INFO - 2023-04-20 10:21:33 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:21:33 --> Helper loaded: security_helper
INFO - 2023-04-20 10:21:33 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:21:33 --> Database Driver Class Initialized
INFO - 2023-04-20 10:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:21:33 --> Parser Class Initialized
INFO - 2023-04-20 10:21:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:21:33 --> Pagination Class Initialized
INFO - 2023-04-20 10:21:33 --> Form Validation Class Initialized
INFO - 2023-04-20 10:21:33 --> Controller Class Initialized
DEBUG - 2023-04-20 10:21:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:21:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:21:33 --> Model Class Initialized
DEBUG - 2023-04-20 10:21:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:21:33 --> Model Class Initialized
DEBUG - 2023-04-20 10:21:33 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:21:33 --> Model Class Initialized
INFO - 2023-04-20 10:21:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-04-20 10:21:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:21:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 10:21:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 10:21:33 --> Model Class Initialized
INFO - 2023-04-20 10:21:33 --> Model Class Initialized
INFO - 2023-04-20 10:21:33 --> Model Class Initialized
INFO - 2023-04-20 10:21:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 10:21:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 10:21:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 10:21:33 --> Final output sent to browser
DEBUG - 2023-04-20 10:21:33 --> Total execution time: 0.1527
ERROR - 2023-04-20 10:21:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:21:34 --> Config Class Initialized
INFO - 2023-04-20 10:21:34 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:21:34 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:21:34 --> Utf8 Class Initialized
INFO - 2023-04-20 10:21:34 --> URI Class Initialized
INFO - 2023-04-20 10:21:34 --> Router Class Initialized
INFO - 2023-04-20 10:21:34 --> Output Class Initialized
INFO - 2023-04-20 10:21:34 --> Security Class Initialized
DEBUG - 2023-04-20 10:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:21:34 --> Input Class Initialized
INFO - 2023-04-20 10:21:34 --> Language Class Initialized
INFO - 2023-04-20 10:21:34 --> Loader Class Initialized
INFO - 2023-04-20 10:21:34 --> Helper loaded: url_helper
INFO - 2023-04-20 10:21:34 --> Helper loaded: file_helper
INFO - 2023-04-20 10:21:34 --> Helper loaded: html_helper
INFO - 2023-04-20 10:21:34 --> Helper loaded: text_helper
INFO - 2023-04-20 10:21:34 --> Helper loaded: form_helper
INFO - 2023-04-20 10:21:34 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:21:34 --> Helper loaded: security_helper
INFO - 2023-04-20 10:21:34 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:21:34 --> Database Driver Class Initialized
INFO - 2023-04-20 10:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:21:34 --> Parser Class Initialized
INFO - 2023-04-20 10:21:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:21:34 --> Pagination Class Initialized
INFO - 2023-04-20 10:21:34 --> Form Validation Class Initialized
INFO - 2023-04-20 10:21:34 --> Controller Class Initialized
DEBUG - 2023-04-20 10:21:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:21:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:21:34 --> Model Class Initialized
DEBUG - 2023-04-20 10:21:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:21:34 --> Model Class Initialized
INFO - 2023-04-20 10:21:34 --> Final output sent to browser
DEBUG - 2023-04-20 10:21:34 --> Total execution time: 0.0339
ERROR - 2023-04-20 10:21:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 10:21:37 --> Config Class Initialized
INFO - 2023-04-20 10:21:37 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:21:37 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:21:37 --> Utf8 Class Initialized
INFO - 2023-04-20 10:21:37 --> URI Class Initialized
INFO - 2023-04-20 10:21:37 --> Router Class Initialized
INFO - 2023-04-20 10:21:37 --> Output Class Initialized
INFO - 2023-04-20 10:21:37 --> Security Class Initialized
DEBUG - 2023-04-20 10:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:21:37 --> Input Class Initialized
INFO - 2023-04-20 10:21:37 --> Language Class Initialized
INFO - 2023-04-20 10:21:37 --> Loader Class Initialized
INFO - 2023-04-20 10:21:37 --> Helper loaded: url_helper
INFO - 2023-04-20 10:21:37 --> Helper loaded: file_helper
INFO - 2023-04-20 10:21:37 --> Helper loaded: html_helper
INFO - 2023-04-20 10:21:37 --> Helper loaded: text_helper
INFO - 2023-04-20 10:21:37 --> Helper loaded: form_helper
INFO - 2023-04-20 10:21:37 --> Helper loaded: lang_helper
INFO - 2023-04-20 10:21:37 --> Helper loaded: security_helper
INFO - 2023-04-20 10:21:37 --> Helper loaded: cookie_helper
INFO - 2023-04-20 10:21:37 --> Database Driver Class Initialized
INFO - 2023-04-20 10:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 10:21:37 --> Parser Class Initialized
INFO - 2023-04-20 10:21:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 10:21:37 --> Pagination Class Initialized
INFO - 2023-04-20 10:21:37 --> Form Validation Class Initialized
INFO - 2023-04-20 10:21:37 --> Controller Class Initialized
DEBUG - 2023-04-20 10:21:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 10:21:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:21:37 --> Model Class Initialized
DEBUG - 2023-04-20 10:21:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 10:21:37 --> Model Class Initialized
INFO - 2023-04-20 10:21:37 --> Final output sent to browser
DEBUG - 2023-04-20 10:21:37 --> Total execution time: 0.0895
ERROR - 2023-04-20 11:08:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 11:08:23 --> Config Class Initialized
INFO - 2023-04-20 11:08:23 --> Hooks Class Initialized
DEBUG - 2023-04-20 11:08:23 --> UTF-8 Support Enabled
INFO - 2023-04-20 11:08:23 --> Utf8 Class Initialized
INFO - 2023-04-20 11:08:23 --> URI Class Initialized
INFO - 2023-04-20 11:08:23 --> Router Class Initialized
INFO - 2023-04-20 11:08:23 --> Output Class Initialized
INFO - 2023-04-20 11:08:23 --> Security Class Initialized
DEBUG - 2023-04-20 11:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 11:08:23 --> Input Class Initialized
INFO - 2023-04-20 11:08:23 --> Language Class Initialized
INFO - 2023-04-20 11:08:23 --> Loader Class Initialized
INFO - 2023-04-20 11:08:23 --> Helper loaded: url_helper
INFO - 2023-04-20 11:08:23 --> Helper loaded: file_helper
INFO - 2023-04-20 11:08:23 --> Helper loaded: html_helper
INFO - 2023-04-20 11:08:23 --> Helper loaded: text_helper
INFO - 2023-04-20 11:08:23 --> Helper loaded: form_helper
INFO - 2023-04-20 11:08:23 --> Helper loaded: lang_helper
INFO - 2023-04-20 11:08:23 --> Helper loaded: security_helper
INFO - 2023-04-20 11:08:23 --> Helper loaded: cookie_helper
INFO - 2023-04-20 11:08:23 --> Database Driver Class Initialized
INFO - 2023-04-20 11:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 11:08:23 --> Parser Class Initialized
INFO - 2023-04-20 11:08:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 11:08:23 --> Pagination Class Initialized
INFO - 2023-04-20 11:08:23 --> Form Validation Class Initialized
INFO - 2023-04-20 11:08:23 --> Controller Class Initialized
DEBUG - 2023-04-20 11:08:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 11:08:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 11:08:23 --> Model Class Initialized
DEBUG - 2023-04-20 11:08:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 11:08:23 --> Model Class Initialized
INFO - 2023-04-20 11:08:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/edit_customer_form.php
DEBUG - 2023-04-20 11:08:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 11:08:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 11:08:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 11:08:23 --> Model Class Initialized
INFO - 2023-04-20 11:08:23 --> Model Class Initialized
INFO - 2023-04-20 11:08:23 --> Model Class Initialized
INFO - 2023-04-20 11:08:23 --> Model Class Initialized
INFO - 2023-04-20 11:08:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 11:08:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 11:08:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 11:08:24 --> Final output sent to browser
DEBUG - 2023-04-20 11:08:24 --> Total execution time: 0.1971
ERROR - 2023-04-20 11:09:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 11:09:46 --> Config Class Initialized
INFO - 2023-04-20 11:09:46 --> Hooks Class Initialized
DEBUG - 2023-04-20 11:09:46 --> UTF-8 Support Enabled
INFO - 2023-04-20 11:09:46 --> Utf8 Class Initialized
INFO - 2023-04-20 11:09:46 --> URI Class Initialized
INFO - 2023-04-20 11:09:46 --> Router Class Initialized
INFO - 2023-04-20 11:09:46 --> Output Class Initialized
INFO - 2023-04-20 11:09:46 --> Security Class Initialized
DEBUG - 2023-04-20 11:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 11:09:46 --> Input Class Initialized
INFO - 2023-04-20 11:09:46 --> Language Class Initialized
INFO - 2023-04-20 11:09:46 --> Loader Class Initialized
INFO - 2023-04-20 11:09:46 --> Helper loaded: url_helper
INFO - 2023-04-20 11:09:46 --> Helper loaded: file_helper
INFO - 2023-04-20 11:09:46 --> Helper loaded: html_helper
INFO - 2023-04-20 11:09:46 --> Helper loaded: text_helper
INFO - 2023-04-20 11:09:46 --> Helper loaded: form_helper
INFO - 2023-04-20 11:09:46 --> Helper loaded: lang_helper
INFO - 2023-04-20 11:09:46 --> Helper loaded: security_helper
INFO - 2023-04-20 11:09:46 --> Helper loaded: cookie_helper
INFO - 2023-04-20 11:09:46 --> Database Driver Class Initialized
INFO - 2023-04-20 11:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 11:09:46 --> Parser Class Initialized
INFO - 2023-04-20 11:09:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 11:09:46 --> Pagination Class Initialized
INFO - 2023-04-20 11:09:46 --> Form Validation Class Initialized
INFO - 2023-04-20 11:09:46 --> Controller Class Initialized
DEBUG - 2023-04-20 11:09:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 11:09:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 11:09:46 --> Model Class Initialized
DEBUG - 2023-04-20 11:09:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 11:09:46 --> Model Class Initialized
ERROR - 2023-04-20 11:09:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 11:09:47 --> Config Class Initialized
INFO - 2023-04-20 11:09:47 --> Hooks Class Initialized
DEBUG - 2023-04-20 11:09:47 --> UTF-8 Support Enabled
INFO - 2023-04-20 11:09:47 --> Utf8 Class Initialized
INFO - 2023-04-20 11:09:47 --> URI Class Initialized
INFO - 2023-04-20 11:09:47 --> Router Class Initialized
INFO - 2023-04-20 11:09:47 --> Output Class Initialized
INFO - 2023-04-20 11:09:47 --> Security Class Initialized
DEBUG - 2023-04-20 11:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 11:09:47 --> Input Class Initialized
INFO - 2023-04-20 11:09:47 --> Language Class Initialized
INFO - 2023-04-20 11:09:47 --> Loader Class Initialized
INFO - 2023-04-20 11:09:47 --> Helper loaded: url_helper
INFO - 2023-04-20 11:09:47 --> Helper loaded: file_helper
INFO - 2023-04-20 11:09:47 --> Helper loaded: html_helper
INFO - 2023-04-20 11:09:47 --> Helper loaded: text_helper
INFO - 2023-04-20 11:09:47 --> Helper loaded: form_helper
INFO - 2023-04-20 11:09:47 --> Helper loaded: lang_helper
INFO - 2023-04-20 11:09:47 --> Helper loaded: security_helper
INFO - 2023-04-20 11:09:47 --> Helper loaded: cookie_helper
INFO - 2023-04-20 11:09:47 --> Database Driver Class Initialized
INFO - 2023-04-20 11:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 11:09:47 --> Parser Class Initialized
INFO - 2023-04-20 11:09:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 11:09:47 --> Pagination Class Initialized
INFO - 2023-04-20 11:09:47 --> Form Validation Class Initialized
INFO - 2023-04-20 11:09:47 --> Controller Class Initialized
DEBUG - 2023-04-20 11:09:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 11:09:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 11:09:47 --> Model Class Initialized
DEBUG - 2023-04-20 11:09:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 11:09:47 --> Model Class Initialized
DEBUG - 2023-04-20 11:09:47 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-04-20 11:09:47 --> Model Class Initialized
INFO - 2023-04-20 11:09:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-04-20 11:09:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 11:09:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 11:09:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 11:09:47 --> Model Class Initialized
INFO - 2023-04-20 11:09:47 --> Model Class Initialized
INFO - 2023-04-20 11:09:47 --> Model Class Initialized
INFO - 2023-04-20 11:09:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 11:09:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 11:09:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 11:09:47 --> Final output sent to browser
DEBUG - 2023-04-20 11:09:47 --> Total execution time: 0.1486
ERROR - 2023-04-20 11:09:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 11:09:47 --> Config Class Initialized
INFO - 2023-04-20 11:09:47 --> Hooks Class Initialized
DEBUG - 2023-04-20 11:09:47 --> UTF-8 Support Enabled
INFO - 2023-04-20 11:09:47 --> Utf8 Class Initialized
INFO - 2023-04-20 11:09:47 --> URI Class Initialized
INFO - 2023-04-20 11:09:47 --> Router Class Initialized
INFO - 2023-04-20 11:09:47 --> Output Class Initialized
INFO - 2023-04-20 11:09:47 --> Security Class Initialized
DEBUG - 2023-04-20 11:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 11:09:47 --> Input Class Initialized
INFO - 2023-04-20 11:09:47 --> Language Class Initialized
INFO - 2023-04-20 11:09:47 --> Loader Class Initialized
INFO - 2023-04-20 11:09:47 --> Helper loaded: url_helper
INFO - 2023-04-20 11:09:47 --> Helper loaded: file_helper
INFO - 2023-04-20 11:09:47 --> Helper loaded: html_helper
INFO - 2023-04-20 11:09:47 --> Helper loaded: text_helper
INFO - 2023-04-20 11:09:47 --> Helper loaded: form_helper
INFO - 2023-04-20 11:09:47 --> Helper loaded: lang_helper
INFO - 2023-04-20 11:09:47 --> Helper loaded: security_helper
INFO - 2023-04-20 11:09:47 --> Helper loaded: cookie_helper
INFO - 2023-04-20 11:09:47 --> Database Driver Class Initialized
INFO - 2023-04-20 11:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 11:09:47 --> Parser Class Initialized
INFO - 2023-04-20 11:09:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 11:09:47 --> Pagination Class Initialized
INFO - 2023-04-20 11:09:47 --> Form Validation Class Initialized
INFO - 2023-04-20 11:09:47 --> Controller Class Initialized
DEBUG - 2023-04-20 11:09:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 11:09:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 11:09:47 --> Model Class Initialized
DEBUG - 2023-04-20 11:09:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 11:09:47 --> Model Class Initialized
INFO - 2023-04-20 11:09:47 --> Final output sent to browser
DEBUG - 2023-04-20 11:09:47 --> Total execution time: 0.0352
ERROR - 2023-04-20 11:09:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 11:09:55 --> Config Class Initialized
INFO - 2023-04-20 11:09:55 --> Hooks Class Initialized
DEBUG - 2023-04-20 11:09:55 --> UTF-8 Support Enabled
INFO - 2023-04-20 11:09:55 --> Utf8 Class Initialized
INFO - 2023-04-20 11:09:55 --> URI Class Initialized
INFO - 2023-04-20 11:09:55 --> Router Class Initialized
INFO - 2023-04-20 11:09:55 --> Output Class Initialized
INFO - 2023-04-20 11:09:55 --> Security Class Initialized
DEBUG - 2023-04-20 11:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 11:09:55 --> Input Class Initialized
INFO - 2023-04-20 11:09:55 --> Language Class Initialized
INFO - 2023-04-20 11:09:55 --> Loader Class Initialized
INFO - 2023-04-20 11:09:55 --> Helper loaded: url_helper
INFO - 2023-04-20 11:09:55 --> Helper loaded: file_helper
INFO - 2023-04-20 11:09:55 --> Helper loaded: html_helper
INFO - 2023-04-20 11:09:55 --> Helper loaded: text_helper
INFO - 2023-04-20 11:09:55 --> Helper loaded: form_helper
INFO - 2023-04-20 11:09:55 --> Helper loaded: lang_helper
INFO - 2023-04-20 11:09:55 --> Helper loaded: security_helper
INFO - 2023-04-20 11:09:55 --> Helper loaded: cookie_helper
INFO - 2023-04-20 11:09:55 --> Database Driver Class Initialized
INFO - 2023-04-20 11:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 11:09:55 --> Parser Class Initialized
INFO - 2023-04-20 11:09:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 11:09:55 --> Pagination Class Initialized
INFO - 2023-04-20 11:09:55 --> Form Validation Class Initialized
INFO - 2023-04-20 11:09:55 --> Controller Class Initialized
DEBUG - 2023-04-20 11:09:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 11:09:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 11:09:55 --> Model Class Initialized
DEBUG - 2023-04-20 11:09:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 11:09:55 --> Model Class Initialized
INFO - 2023-04-20 11:09:55 --> Final output sent to browser
DEBUG - 2023-04-20 11:09:55 --> Total execution time: 0.0725
ERROR - 2023-04-20 11:10:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 11:10:09 --> Config Class Initialized
INFO - 2023-04-20 11:10:09 --> Hooks Class Initialized
DEBUG - 2023-04-20 11:10:09 --> UTF-8 Support Enabled
INFO - 2023-04-20 11:10:09 --> Utf8 Class Initialized
INFO - 2023-04-20 11:10:09 --> URI Class Initialized
INFO - 2023-04-20 11:10:09 --> Router Class Initialized
INFO - 2023-04-20 11:10:09 --> Output Class Initialized
INFO - 2023-04-20 11:10:09 --> Security Class Initialized
DEBUG - 2023-04-20 11:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 11:10:09 --> Input Class Initialized
INFO - 2023-04-20 11:10:09 --> Language Class Initialized
INFO - 2023-04-20 11:10:09 --> Loader Class Initialized
INFO - 2023-04-20 11:10:09 --> Helper loaded: url_helper
INFO - 2023-04-20 11:10:09 --> Helper loaded: file_helper
INFO - 2023-04-20 11:10:09 --> Helper loaded: html_helper
INFO - 2023-04-20 11:10:09 --> Helper loaded: text_helper
INFO - 2023-04-20 11:10:09 --> Helper loaded: form_helper
INFO - 2023-04-20 11:10:09 --> Helper loaded: lang_helper
INFO - 2023-04-20 11:10:09 --> Helper loaded: security_helper
INFO - 2023-04-20 11:10:09 --> Helper loaded: cookie_helper
INFO - 2023-04-20 11:10:09 --> Database Driver Class Initialized
INFO - 2023-04-20 11:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 11:10:09 --> Parser Class Initialized
INFO - 2023-04-20 11:10:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 11:10:09 --> Pagination Class Initialized
INFO - 2023-04-20 11:10:09 --> Form Validation Class Initialized
INFO - 2023-04-20 11:10:09 --> Controller Class Initialized
DEBUG - 2023-04-20 11:10:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 11:10:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 11:10:09 --> Model Class Initialized
DEBUG - 2023-04-20 11:10:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 11:10:09 --> Model Class Initialized
INFO - 2023-04-20 11:10:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/edit_customer_form.php
DEBUG - 2023-04-20 11:10:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 11:10:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 11:10:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 11:10:09 --> Model Class Initialized
INFO - 2023-04-20 11:10:09 --> Model Class Initialized
INFO - 2023-04-20 11:10:09 --> Model Class Initialized
INFO - 2023-04-20 11:10:09 --> Model Class Initialized
INFO - 2023-04-20 11:10:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 11:10:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 11:10:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 11:10:09 --> Final output sent to browser
DEBUG - 2023-04-20 11:10:09 --> Total execution time: 0.1690
ERROR - 2023-04-20 11:10:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 11:10:40 --> Config Class Initialized
INFO - 2023-04-20 11:10:40 --> Hooks Class Initialized
DEBUG - 2023-04-20 11:10:40 --> UTF-8 Support Enabled
INFO - 2023-04-20 11:10:40 --> Utf8 Class Initialized
INFO - 2023-04-20 11:10:40 --> URI Class Initialized
INFO - 2023-04-20 11:10:40 --> Router Class Initialized
INFO - 2023-04-20 11:10:40 --> Output Class Initialized
INFO - 2023-04-20 11:10:40 --> Security Class Initialized
DEBUG - 2023-04-20 11:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 11:10:40 --> Input Class Initialized
INFO - 2023-04-20 11:10:40 --> Language Class Initialized
INFO - 2023-04-20 11:10:40 --> Loader Class Initialized
INFO - 2023-04-20 11:10:40 --> Helper loaded: url_helper
INFO - 2023-04-20 11:10:40 --> Helper loaded: file_helper
INFO - 2023-04-20 11:10:40 --> Helper loaded: html_helper
INFO - 2023-04-20 11:10:40 --> Helper loaded: text_helper
INFO - 2023-04-20 11:10:40 --> Helper loaded: form_helper
INFO - 2023-04-20 11:10:40 --> Helper loaded: lang_helper
INFO - 2023-04-20 11:10:40 --> Helper loaded: security_helper
INFO - 2023-04-20 11:10:40 --> Helper loaded: cookie_helper
INFO - 2023-04-20 11:10:40 --> Database Driver Class Initialized
INFO - 2023-04-20 11:10:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 11:10:40 --> Parser Class Initialized
INFO - 2023-04-20 11:10:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 11:10:40 --> Pagination Class Initialized
INFO - 2023-04-20 11:10:40 --> Form Validation Class Initialized
INFO - 2023-04-20 11:10:40 --> Controller Class Initialized
DEBUG - 2023-04-20 11:10:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 11:10:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 11:10:40 --> Model Class Initialized
DEBUG - 2023-04-20 11:10:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 11:10:40 --> Model Class Initialized
ERROR - 2023-04-20 11:10:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 11:10:40 --> Config Class Initialized
INFO - 2023-04-20 11:10:40 --> Hooks Class Initialized
DEBUG - 2023-04-20 11:10:40 --> UTF-8 Support Enabled
INFO - 2023-04-20 11:10:40 --> Utf8 Class Initialized
INFO - 2023-04-20 11:10:40 --> URI Class Initialized
INFO - 2023-04-20 11:10:40 --> Router Class Initialized
INFO - 2023-04-20 11:10:40 --> Output Class Initialized
INFO - 2023-04-20 11:10:40 --> Security Class Initialized
DEBUG - 2023-04-20 11:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 11:10:40 --> Input Class Initialized
INFO - 2023-04-20 11:10:40 --> Language Class Initialized
INFO - 2023-04-20 11:10:40 --> Loader Class Initialized
INFO - 2023-04-20 11:10:40 --> Helper loaded: url_helper
INFO - 2023-04-20 11:10:40 --> Helper loaded: file_helper
INFO - 2023-04-20 11:10:40 --> Helper loaded: html_helper
INFO - 2023-04-20 11:10:40 --> Helper loaded: text_helper
INFO - 2023-04-20 11:10:40 --> Helper loaded: form_helper
INFO - 2023-04-20 11:10:40 --> Helper loaded: lang_helper
INFO - 2023-04-20 11:10:40 --> Helper loaded: security_helper
INFO - 2023-04-20 11:10:40 --> Helper loaded: cookie_helper
INFO - 2023-04-20 11:10:40 --> Database Driver Class Initialized
INFO - 2023-04-20 11:10:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 11:10:40 --> Parser Class Initialized
INFO - 2023-04-20 11:10:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 11:10:40 --> Pagination Class Initialized
INFO - 2023-04-20 11:10:40 --> Form Validation Class Initialized
INFO - 2023-04-20 11:10:40 --> Controller Class Initialized
DEBUG - 2023-04-20 11:10:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 11:10:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 11:10:40 --> Model Class Initialized
DEBUG - 2023-04-20 11:10:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 11:10:40 --> Model Class Initialized
DEBUG - 2023-04-20 11:10:40 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-04-20 11:10:40 --> Model Class Initialized
INFO - 2023-04-20 11:10:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-04-20 11:10:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 11:10:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 11:10:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 11:10:40 --> Model Class Initialized
INFO - 2023-04-20 11:10:40 --> Model Class Initialized
INFO - 2023-04-20 11:10:40 --> Model Class Initialized
INFO - 2023-04-20 11:10:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 11:10:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 11:10:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 11:10:41 --> Final output sent to browser
DEBUG - 2023-04-20 11:10:41 --> Total execution time: 0.1377
ERROR - 2023-04-20 11:10:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 11:10:41 --> Config Class Initialized
INFO - 2023-04-20 11:10:41 --> Hooks Class Initialized
DEBUG - 2023-04-20 11:10:41 --> UTF-8 Support Enabled
INFO - 2023-04-20 11:10:41 --> Utf8 Class Initialized
INFO - 2023-04-20 11:10:41 --> URI Class Initialized
INFO - 2023-04-20 11:10:41 --> Router Class Initialized
INFO - 2023-04-20 11:10:41 --> Output Class Initialized
INFO - 2023-04-20 11:10:41 --> Security Class Initialized
DEBUG - 2023-04-20 11:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 11:10:41 --> Input Class Initialized
INFO - 2023-04-20 11:10:41 --> Language Class Initialized
INFO - 2023-04-20 11:10:41 --> Loader Class Initialized
INFO - 2023-04-20 11:10:41 --> Helper loaded: url_helper
INFO - 2023-04-20 11:10:41 --> Helper loaded: file_helper
INFO - 2023-04-20 11:10:41 --> Helper loaded: html_helper
INFO - 2023-04-20 11:10:41 --> Helper loaded: text_helper
INFO - 2023-04-20 11:10:41 --> Helper loaded: form_helper
INFO - 2023-04-20 11:10:41 --> Helper loaded: lang_helper
INFO - 2023-04-20 11:10:41 --> Helper loaded: security_helper
INFO - 2023-04-20 11:10:41 --> Helper loaded: cookie_helper
INFO - 2023-04-20 11:10:41 --> Database Driver Class Initialized
INFO - 2023-04-20 11:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 11:10:41 --> Parser Class Initialized
INFO - 2023-04-20 11:10:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 11:10:41 --> Pagination Class Initialized
INFO - 2023-04-20 11:10:41 --> Form Validation Class Initialized
INFO - 2023-04-20 11:10:41 --> Controller Class Initialized
DEBUG - 2023-04-20 11:10:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 11:10:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 11:10:41 --> Model Class Initialized
DEBUG - 2023-04-20 11:10:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 11:10:41 --> Model Class Initialized
INFO - 2023-04-20 11:10:41 --> Final output sent to browser
DEBUG - 2023-04-20 11:10:41 --> Total execution time: 0.0295
ERROR - 2023-04-20 11:13:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 11:13:27 --> Config Class Initialized
INFO - 2023-04-20 11:13:27 --> Hooks Class Initialized
DEBUG - 2023-04-20 11:13:27 --> UTF-8 Support Enabled
INFO - 2023-04-20 11:13:27 --> Utf8 Class Initialized
INFO - 2023-04-20 11:13:27 --> URI Class Initialized
INFO - 2023-04-20 11:13:27 --> Router Class Initialized
INFO - 2023-04-20 11:13:27 --> Output Class Initialized
INFO - 2023-04-20 11:13:27 --> Security Class Initialized
DEBUG - 2023-04-20 11:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 11:13:27 --> Input Class Initialized
INFO - 2023-04-20 11:13:27 --> Language Class Initialized
INFO - 2023-04-20 11:13:27 --> Loader Class Initialized
INFO - 2023-04-20 11:13:27 --> Helper loaded: url_helper
INFO - 2023-04-20 11:13:27 --> Helper loaded: file_helper
INFO - 2023-04-20 11:13:27 --> Helper loaded: html_helper
INFO - 2023-04-20 11:13:27 --> Helper loaded: text_helper
INFO - 2023-04-20 11:13:27 --> Helper loaded: form_helper
INFO - 2023-04-20 11:13:27 --> Helper loaded: lang_helper
INFO - 2023-04-20 11:13:27 --> Helper loaded: security_helper
INFO - 2023-04-20 11:13:27 --> Helper loaded: cookie_helper
INFO - 2023-04-20 11:13:27 --> Database Driver Class Initialized
INFO - 2023-04-20 11:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 11:13:27 --> Parser Class Initialized
INFO - 2023-04-20 11:13:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 11:13:27 --> Pagination Class Initialized
INFO - 2023-04-20 11:13:27 --> Form Validation Class Initialized
INFO - 2023-04-20 11:13:27 --> Controller Class Initialized
DEBUG - 2023-04-20 11:13:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 11:13:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 11:13:27 --> Model Class Initialized
DEBUG - 2023-04-20 11:13:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 11:13:27 --> Model Class Initialized
INFO - 2023-04-20 11:13:27 --> Final output sent to browser
DEBUG - 2023-04-20 11:13:27 --> Total execution time: 0.0921
ERROR - 2023-04-20 11:13:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 11:13:35 --> Config Class Initialized
INFO - 2023-04-20 11:13:35 --> Hooks Class Initialized
DEBUG - 2023-04-20 11:13:35 --> UTF-8 Support Enabled
INFO - 2023-04-20 11:13:35 --> Utf8 Class Initialized
INFO - 2023-04-20 11:13:35 --> URI Class Initialized
INFO - 2023-04-20 11:13:35 --> Router Class Initialized
INFO - 2023-04-20 11:13:35 --> Output Class Initialized
INFO - 2023-04-20 11:13:35 --> Security Class Initialized
DEBUG - 2023-04-20 11:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 11:13:35 --> Input Class Initialized
INFO - 2023-04-20 11:13:35 --> Language Class Initialized
INFO - 2023-04-20 11:13:35 --> Loader Class Initialized
INFO - 2023-04-20 11:13:35 --> Helper loaded: url_helper
INFO - 2023-04-20 11:13:35 --> Helper loaded: file_helper
INFO - 2023-04-20 11:13:35 --> Helper loaded: html_helper
INFO - 2023-04-20 11:13:35 --> Helper loaded: text_helper
INFO - 2023-04-20 11:13:35 --> Helper loaded: form_helper
INFO - 2023-04-20 11:13:35 --> Helper loaded: lang_helper
INFO - 2023-04-20 11:13:35 --> Helper loaded: security_helper
INFO - 2023-04-20 11:13:35 --> Helper loaded: cookie_helper
INFO - 2023-04-20 11:13:35 --> Database Driver Class Initialized
INFO - 2023-04-20 11:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 11:13:35 --> Parser Class Initialized
INFO - 2023-04-20 11:13:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 11:13:35 --> Pagination Class Initialized
INFO - 2023-04-20 11:13:35 --> Form Validation Class Initialized
INFO - 2023-04-20 11:13:35 --> Controller Class Initialized
DEBUG - 2023-04-20 11:13:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 11:13:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 11:13:35 --> Model Class Initialized
DEBUG - 2023-04-20 11:13:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 11:13:35 --> Model Class Initialized
INFO - 2023-04-20 11:13:35 --> Final output sent to browser
DEBUG - 2023-04-20 11:13:35 --> Total execution time: 0.0483
ERROR - 2023-04-20 11:13:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 11:13:38 --> Config Class Initialized
INFO - 2023-04-20 11:13:38 --> Hooks Class Initialized
DEBUG - 2023-04-20 11:13:38 --> UTF-8 Support Enabled
INFO - 2023-04-20 11:13:38 --> Utf8 Class Initialized
INFO - 2023-04-20 11:13:38 --> URI Class Initialized
INFO - 2023-04-20 11:13:38 --> Router Class Initialized
INFO - 2023-04-20 11:13:38 --> Output Class Initialized
INFO - 2023-04-20 11:13:38 --> Security Class Initialized
DEBUG - 2023-04-20 11:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 11:13:38 --> Input Class Initialized
INFO - 2023-04-20 11:13:38 --> Language Class Initialized
INFO - 2023-04-20 11:13:38 --> Loader Class Initialized
INFO - 2023-04-20 11:13:38 --> Helper loaded: url_helper
INFO - 2023-04-20 11:13:38 --> Helper loaded: file_helper
INFO - 2023-04-20 11:13:38 --> Helper loaded: html_helper
INFO - 2023-04-20 11:13:38 --> Helper loaded: text_helper
INFO - 2023-04-20 11:13:38 --> Helper loaded: form_helper
INFO - 2023-04-20 11:13:38 --> Helper loaded: lang_helper
INFO - 2023-04-20 11:13:38 --> Helper loaded: security_helper
INFO - 2023-04-20 11:13:38 --> Helper loaded: cookie_helper
INFO - 2023-04-20 11:13:38 --> Database Driver Class Initialized
INFO - 2023-04-20 11:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 11:13:38 --> Parser Class Initialized
INFO - 2023-04-20 11:13:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 11:13:38 --> Pagination Class Initialized
INFO - 2023-04-20 11:13:38 --> Form Validation Class Initialized
INFO - 2023-04-20 11:13:38 --> Controller Class Initialized
DEBUG - 2023-04-20 11:13:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 11:13:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 11:13:38 --> Model Class Initialized
DEBUG - 2023-04-20 11:13:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 11:13:38 --> Model Class Initialized
INFO - 2023-04-20 11:13:38 --> Final output sent to browser
DEBUG - 2023-04-20 11:13:38 --> Total execution time: 0.0455
ERROR - 2023-04-20 11:13:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 11:13:40 --> Config Class Initialized
INFO - 2023-04-20 11:13:40 --> Hooks Class Initialized
DEBUG - 2023-04-20 11:13:40 --> UTF-8 Support Enabled
INFO - 2023-04-20 11:13:40 --> Utf8 Class Initialized
INFO - 2023-04-20 11:13:40 --> URI Class Initialized
INFO - 2023-04-20 11:13:40 --> Router Class Initialized
INFO - 2023-04-20 11:13:40 --> Output Class Initialized
INFO - 2023-04-20 11:13:40 --> Security Class Initialized
DEBUG - 2023-04-20 11:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 11:13:40 --> Input Class Initialized
INFO - 2023-04-20 11:13:40 --> Language Class Initialized
INFO - 2023-04-20 11:13:40 --> Loader Class Initialized
INFO - 2023-04-20 11:13:40 --> Helper loaded: url_helper
INFO - 2023-04-20 11:13:40 --> Helper loaded: file_helper
INFO - 2023-04-20 11:13:40 --> Helper loaded: html_helper
INFO - 2023-04-20 11:13:40 --> Helper loaded: text_helper
INFO - 2023-04-20 11:13:40 --> Helper loaded: form_helper
INFO - 2023-04-20 11:13:40 --> Helper loaded: lang_helper
INFO - 2023-04-20 11:13:40 --> Helper loaded: security_helper
INFO - 2023-04-20 11:13:40 --> Helper loaded: cookie_helper
INFO - 2023-04-20 11:13:40 --> Database Driver Class Initialized
INFO - 2023-04-20 11:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 11:13:40 --> Parser Class Initialized
INFO - 2023-04-20 11:13:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 11:13:40 --> Pagination Class Initialized
INFO - 2023-04-20 11:13:40 --> Form Validation Class Initialized
INFO - 2023-04-20 11:13:40 --> Controller Class Initialized
DEBUG - 2023-04-20 11:13:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 11:13:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 11:13:40 --> Model Class Initialized
DEBUG - 2023-04-20 11:13:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 11:13:40 --> Model Class Initialized
INFO - 2023-04-20 11:13:40 --> Final output sent to browser
DEBUG - 2023-04-20 11:13:40 --> Total execution time: 0.0488
ERROR - 2023-04-20 12:13:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:13:25 --> Config Class Initialized
INFO - 2023-04-20 12:13:25 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:13:25 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:13:25 --> Utf8 Class Initialized
INFO - 2023-04-20 12:13:25 --> URI Class Initialized
DEBUG - 2023-04-20 12:13:25 --> No URI present. Default controller set.
INFO - 2023-04-20 12:13:25 --> Router Class Initialized
INFO - 2023-04-20 12:13:25 --> Output Class Initialized
INFO - 2023-04-20 12:13:25 --> Security Class Initialized
DEBUG - 2023-04-20 12:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:13:25 --> Input Class Initialized
INFO - 2023-04-20 12:13:25 --> Language Class Initialized
INFO - 2023-04-20 12:13:25 --> Loader Class Initialized
INFO - 2023-04-20 12:13:25 --> Helper loaded: url_helper
INFO - 2023-04-20 12:13:25 --> Helper loaded: file_helper
INFO - 2023-04-20 12:13:25 --> Helper loaded: html_helper
INFO - 2023-04-20 12:13:25 --> Helper loaded: text_helper
INFO - 2023-04-20 12:13:25 --> Helper loaded: form_helper
INFO - 2023-04-20 12:13:25 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:13:25 --> Helper loaded: security_helper
INFO - 2023-04-20 12:13:25 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:13:25 --> Database Driver Class Initialized
INFO - 2023-04-20 12:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:13:25 --> Parser Class Initialized
INFO - 2023-04-20 12:13:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:13:25 --> Pagination Class Initialized
INFO - 2023-04-20 12:13:25 --> Form Validation Class Initialized
INFO - 2023-04-20 12:13:25 --> Controller Class Initialized
INFO - 2023-04-20 12:13:25 --> Model Class Initialized
DEBUG - 2023-04-20 12:13:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:13:25 --> Model Class Initialized
DEBUG - 2023-04-20 12:13:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:13:25 --> Model Class Initialized
INFO - 2023-04-20 12:13:25 --> Model Class Initialized
INFO - 2023-04-20 12:13:25 --> Model Class Initialized
INFO - 2023-04-20 12:13:25 --> Model Class Initialized
DEBUG - 2023-04-20 12:13:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 12:13:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:13:25 --> Model Class Initialized
INFO - 2023-04-20 12:13:25 --> Model Class Initialized
INFO - 2023-04-20 12:13:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-20 12:13:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:13:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 12:13:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 12:13:25 --> Model Class Initialized
INFO - 2023-04-20 12:13:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 12:13:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 12:13:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 12:13:25 --> Final output sent to browser
DEBUG - 2023-04-20 12:13:25 --> Total execution time: 0.2635
ERROR - 2023-04-20 12:14:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:14:54 --> Config Class Initialized
INFO - 2023-04-20 12:14:54 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:14:54 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:14:54 --> Utf8 Class Initialized
INFO - 2023-04-20 12:14:54 --> URI Class Initialized
INFO - 2023-04-20 12:14:54 --> Router Class Initialized
INFO - 2023-04-20 12:14:54 --> Output Class Initialized
INFO - 2023-04-20 12:14:54 --> Security Class Initialized
DEBUG - 2023-04-20 12:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:14:54 --> Input Class Initialized
INFO - 2023-04-20 12:14:54 --> Language Class Initialized
INFO - 2023-04-20 12:14:54 --> Loader Class Initialized
INFO - 2023-04-20 12:14:54 --> Helper loaded: url_helper
INFO - 2023-04-20 12:14:54 --> Helper loaded: file_helper
INFO - 2023-04-20 12:14:54 --> Helper loaded: html_helper
INFO - 2023-04-20 12:14:54 --> Helper loaded: text_helper
INFO - 2023-04-20 12:14:54 --> Helper loaded: form_helper
INFO - 2023-04-20 12:14:54 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:14:54 --> Helper loaded: security_helper
INFO - 2023-04-20 12:14:54 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:14:54 --> Database Driver Class Initialized
INFO - 2023-04-20 12:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:14:54 --> Parser Class Initialized
INFO - 2023-04-20 12:14:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:14:54 --> Pagination Class Initialized
INFO - 2023-04-20 12:14:54 --> Form Validation Class Initialized
INFO - 2023-04-20 12:14:54 --> Controller Class Initialized
DEBUG - 2023-04-20 12:14:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 12:14:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:14:54 --> Model Class Initialized
DEBUG - 2023-04-20 12:14:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:14:54 --> Model Class Initialized
DEBUG - 2023-04-20 12:14:54 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:14:54 --> Model Class Initialized
INFO - 2023-04-20 12:14:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-04-20 12:14:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:14:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 12:14:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 12:14:54 --> Model Class Initialized
INFO - 2023-04-20 12:14:54 --> Model Class Initialized
INFO - 2023-04-20 12:14:54 --> Model Class Initialized
INFO - 2023-04-20 12:14:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 12:14:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 12:14:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 12:14:55 --> Final output sent to browser
DEBUG - 2023-04-20 12:14:55 --> Total execution time: 0.2108
ERROR - 2023-04-20 12:14:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:14:55 --> Config Class Initialized
INFO - 2023-04-20 12:14:55 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:14:55 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:14:55 --> Utf8 Class Initialized
INFO - 2023-04-20 12:14:55 --> URI Class Initialized
INFO - 2023-04-20 12:14:55 --> Router Class Initialized
INFO - 2023-04-20 12:14:55 --> Output Class Initialized
INFO - 2023-04-20 12:14:55 --> Security Class Initialized
DEBUG - 2023-04-20 12:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:14:55 --> Input Class Initialized
INFO - 2023-04-20 12:14:55 --> Language Class Initialized
INFO - 2023-04-20 12:14:55 --> Loader Class Initialized
INFO - 2023-04-20 12:14:55 --> Helper loaded: url_helper
INFO - 2023-04-20 12:14:55 --> Helper loaded: file_helper
INFO - 2023-04-20 12:14:55 --> Helper loaded: html_helper
INFO - 2023-04-20 12:14:55 --> Helper loaded: text_helper
INFO - 2023-04-20 12:14:55 --> Helper loaded: form_helper
INFO - 2023-04-20 12:14:55 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:14:55 --> Helper loaded: security_helper
INFO - 2023-04-20 12:14:55 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:14:55 --> Database Driver Class Initialized
INFO - 2023-04-20 12:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:14:55 --> Parser Class Initialized
INFO - 2023-04-20 12:14:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:14:55 --> Pagination Class Initialized
INFO - 2023-04-20 12:14:55 --> Form Validation Class Initialized
INFO - 2023-04-20 12:14:55 --> Controller Class Initialized
DEBUG - 2023-04-20 12:14:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 12:14:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:14:55 --> Model Class Initialized
DEBUG - 2023-04-20 12:14:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:14:55 --> Model Class Initialized
INFO - 2023-04-20 12:14:55 --> Final output sent to browser
DEBUG - 2023-04-20 12:14:55 --> Total execution time: 0.0382
ERROR - 2023-04-20 12:15:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:15:00 --> Config Class Initialized
INFO - 2023-04-20 12:15:00 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:15:00 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:15:00 --> Utf8 Class Initialized
INFO - 2023-04-20 12:15:00 --> URI Class Initialized
INFO - 2023-04-20 12:15:00 --> Router Class Initialized
INFO - 2023-04-20 12:15:00 --> Output Class Initialized
INFO - 2023-04-20 12:15:00 --> Security Class Initialized
DEBUG - 2023-04-20 12:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:15:00 --> Input Class Initialized
INFO - 2023-04-20 12:15:00 --> Language Class Initialized
INFO - 2023-04-20 12:15:00 --> Loader Class Initialized
INFO - 2023-04-20 12:15:00 --> Helper loaded: url_helper
INFO - 2023-04-20 12:15:00 --> Helper loaded: file_helper
INFO - 2023-04-20 12:15:00 --> Helper loaded: html_helper
INFO - 2023-04-20 12:15:00 --> Helper loaded: text_helper
INFO - 2023-04-20 12:15:00 --> Helper loaded: form_helper
INFO - 2023-04-20 12:15:00 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:15:00 --> Helper loaded: security_helper
INFO - 2023-04-20 12:15:00 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:15:00 --> Database Driver Class Initialized
INFO - 2023-04-20 12:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:15:00 --> Parser Class Initialized
INFO - 2023-04-20 12:15:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:15:00 --> Pagination Class Initialized
INFO - 2023-04-20 12:15:00 --> Form Validation Class Initialized
INFO - 2023-04-20 12:15:00 --> Controller Class Initialized
DEBUG - 2023-04-20 12:15:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 12:15:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:15:00 --> Model Class Initialized
DEBUG - 2023-04-20 12:15:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:15:00 --> Model Class Initialized
INFO - 2023-04-20 12:15:00 --> Final output sent to browser
DEBUG - 2023-04-20 12:15:00 --> Total execution time: 0.1189
ERROR - 2023-04-20 12:15:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:15:30 --> Config Class Initialized
INFO - 2023-04-20 12:15:30 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:15:30 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:15:30 --> Utf8 Class Initialized
INFO - 2023-04-20 12:15:30 --> URI Class Initialized
INFO - 2023-04-20 12:15:30 --> Router Class Initialized
INFO - 2023-04-20 12:15:30 --> Output Class Initialized
INFO - 2023-04-20 12:15:30 --> Security Class Initialized
DEBUG - 2023-04-20 12:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:15:30 --> Input Class Initialized
INFO - 2023-04-20 12:15:30 --> Language Class Initialized
INFO - 2023-04-20 12:15:30 --> Loader Class Initialized
INFO - 2023-04-20 12:15:30 --> Helper loaded: url_helper
INFO - 2023-04-20 12:15:30 --> Helper loaded: file_helper
INFO - 2023-04-20 12:15:30 --> Helper loaded: html_helper
INFO - 2023-04-20 12:15:30 --> Helper loaded: text_helper
INFO - 2023-04-20 12:15:30 --> Helper loaded: form_helper
INFO - 2023-04-20 12:15:30 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:15:30 --> Helper loaded: security_helper
INFO - 2023-04-20 12:15:30 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:15:30 --> Database Driver Class Initialized
INFO - 2023-04-20 12:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:15:30 --> Parser Class Initialized
INFO - 2023-04-20 12:15:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:15:30 --> Pagination Class Initialized
INFO - 2023-04-20 12:15:30 --> Form Validation Class Initialized
INFO - 2023-04-20 12:15:30 --> Controller Class Initialized
DEBUG - 2023-04-20 12:15:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 12:15:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:15:30 --> Model Class Initialized
DEBUG - 2023-04-20 12:15:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:15:30 --> Model Class Initialized
DEBUG - 2023-04-20 12:15:30 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:15:30 --> Model Class Initialized
INFO - 2023-04-20 12:15:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-04-20 12:15:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:15:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 12:15:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 12:15:30 --> Model Class Initialized
INFO - 2023-04-20 12:15:30 --> Model Class Initialized
INFO - 2023-04-20 12:15:30 --> Model Class Initialized
INFO - 2023-04-20 12:15:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 12:15:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 12:15:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 12:15:30 --> Final output sent to browser
DEBUG - 2023-04-20 12:15:30 --> Total execution time: 0.2058
ERROR - 2023-04-20 12:15:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:15:31 --> Config Class Initialized
INFO - 2023-04-20 12:15:31 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:15:31 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:15:31 --> Utf8 Class Initialized
INFO - 2023-04-20 12:15:31 --> URI Class Initialized
INFO - 2023-04-20 12:15:31 --> Router Class Initialized
INFO - 2023-04-20 12:15:31 --> Output Class Initialized
INFO - 2023-04-20 12:15:31 --> Security Class Initialized
DEBUG - 2023-04-20 12:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:15:31 --> Input Class Initialized
INFO - 2023-04-20 12:15:31 --> Language Class Initialized
INFO - 2023-04-20 12:15:31 --> Loader Class Initialized
INFO - 2023-04-20 12:15:31 --> Helper loaded: url_helper
INFO - 2023-04-20 12:15:31 --> Helper loaded: file_helper
INFO - 2023-04-20 12:15:31 --> Helper loaded: html_helper
INFO - 2023-04-20 12:15:31 --> Helper loaded: text_helper
INFO - 2023-04-20 12:15:31 --> Helper loaded: form_helper
INFO - 2023-04-20 12:15:31 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:15:31 --> Helper loaded: security_helper
INFO - 2023-04-20 12:15:31 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:15:31 --> Database Driver Class Initialized
INFO - 2023-04-20 12:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:15:31 --> Parser Class Initialized
INFO - 2023-04-20 12:15:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:15:31 --> Pagination Class Initialized
INFO - 2023-04-20 12:15:31 --> Form Validation Class Initialized
INFO - 2023-04-20 12:15:31 --> Controller Class Initialized
DEBUG - 2023-04-20 12:15:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 12:15:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:15:31 --> Model Class Initialized
DEBUG - 2023-04-20 12:15:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:15:31 --> Model Class Initialized
INFO - 2023-04-20 12:15:31 --> Final output sent to browser
DEBUG - 2023-04-20 12:15:31 --> Total execution time: 0.0384
ERROR - 2023-04-20 12:15:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:15:36 --> Config Class Initialized
INFO - 2023-04-20 12:15:36 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:15:36 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:15:36 --> Utf8 Class Initialized
INFO - 2023-04-20 12:15:36 --> URI Class Initialized
INFO - 2023-04-20 12:15:36 --> Router Class Initialized
INFO - 2023-04-20 12:15:36 --> Output Class Initialized
INFO - 2023-04-20 12:15:36 --> Security Class Initialized
DEBUG - 2023-04-20 12:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:15:36 --> Input Class Initialized
INFO - 2023-04-20 12:15:36 --> Language Class Initialized
INFO - 2023-04-20 12:15:36 --> Loader Class Initialized
INFO - 2023-04-20 12:15:36 --> Helper loaded: url_helper
INFO - 2023-04-20 12:15:36 --> Helper loaded: file_helper
INFO - 2023-04-20 12:15:36 --> Helper loaded: html_helper
INFO - 2023-04-20 12:15:36 --> Helper loaded: text_helper
INFO - 2023-04-20 12:15:36 --> Helper loaded: form_helper
INFO - 2023-04-20 12:15:36 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:15:36 --> Helper loaded: security_helper
INFO - 2023-04-20 12:15:36 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:15:36 --> Database Driver Class Initialized
INFO - 2023-04-20 12:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:15:36 --> Parser Class Initialized
INFO - 2023-04-20 12:15:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:15:36 --> Pagination Class Initialized
INFO - 2023-04-20 12:15:36 --> Form Validation Class Initialized
INFO - 2023-04-20 12:15:36 --> Controller Class Initialized
DEBUG - 2023-04-20 12:15:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 12:15:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:15:36 --> Model Class Initialized
DEBUG - 2023-04-20 12:15:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:15:36 --> Model Class Initialized
INFO - 2023-04-20 12:15:36 --> Final output sent to browser
DEBUG - 2023-04-20 12:15:36 --> Total execution time: 0.1134
ERROR - 2023-04-20 12:16:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:16:08 --> Config Class Initialized
INFO - 2023-04-20 12:16:08 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:16:08 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:16:08 --> Utf8 Class Initialized
INFO - 2023-04-20 12:16:08 --> URI Class Initialized
INFO - 2023-04-20 12:16:08 --> Router Class Initialized
INFO - 2023-04-20 12:16:08 --> Output Class Initialized
INFO - 2023-04-20 12:16:08 --> Security Class Initialized
DEBUG - 2023-04-20 12:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:16:08 --> Input Class Initialized
INFO - 2023-04-20 12:16:08 --> Language Class Initialized
INFO - 2023-04-20 12:16:08 --> Loader Class Initialized
INFO - 2023-04-20 12:16:08 --> Helper loaded: url_helper
INFO - 2023-04-20 12:16:08 --> Helper loaded: file_helper
INFO - 2023-04-20 12:16:08 --> Helper loaded: html_helper
INFO - 2023-04-20 12:16:08 --> Helper loaded: text_helper
INFO - 2023-04-20 12:16:08 --> Helper loaded: form_helper
INFO - 2023-04-20 12:16:08 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:16:08 --> Helper loaded: security_helper
INFO - 2023-04-20 12:16:08 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:16:08 --> Database Driver Class Initialized
INFO - 2023-04-20 12:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:16:08 --> Parser Class Initialized
INFO - 2023-04-20 12:16:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:16:08 --> Pagination Class Initialized
INFO - 2023-04-20 12:16:08 --> Form Validation Class Initialized
INFO - 2023-04-20 12:16:08 --> Controller Class Initialized
DEBUG - 2023-04-20 12:16:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 12:16:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:16:08 --> Model Class Initialized
DEBUG - 2023-04-20 12:16:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:16:08 --> Model Class Initialized
INFO - 2023-04-20 12:16:08 --> Final output sent to browser
DEBUG - 2023-04-20 12:16:08 --> Total execution time: 0.0976
ERROR - 2023-04-20 12:16:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:16:34 --> Config Class Initialized
INFO - 2023-04-20 12:16:34 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:16:34 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:16:34 --> Utf8 Class Initialized
INFO - 2023-04-20 12:16:34 --> URI Class Initialized
INFO - 2023-04-20 12:16:34 --> Router Class Initialized
INFO - 2023-04-20 12:16:34 --> Output Class Initialized
INFO - 2023-04-20 12:16:34 --> Security Class Initialized
DEBUG - 2023-04-20 12:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:16:34 --> Input Class Initialized
INFO - 2023-04-20 12:16:34 --> Language Class Initialized
INFO - 2023-04-20 12:16:34 --> Loader Class Initialized
INFO - 2023-04-20 12:16:34 --> Helper loaded: url_helper
INFO - 2023-04-20 12:16:34 --> Helper loaded: file_helper
INFO - 2023-04-20 12:16:34 --> Helper loaded: html_helper
INFO - 2023-04-20 12:16:34 --> Helper loaded: text_helper
INFO - 2023-04-20 12:16:34 --> Helper loaded: form_helper
INFO - 2023-04-20 12:16:34 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:16:34 --> Helper loaded: security_helper
INFO - 2023-04-20 12:16:34 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:16:34 --> Database Driver Class Initialized
INFO - 2023-04-20 12:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:16:34 --> Parser Class Initialized
INFO - 2023-04-20 12:16:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:16:34 --> Pagination Class Initialized
INFO - 2023-04-20 12:16:34 --> Form Validation Class Initialized
INFO - 2023-04-20 12:16:34 --> Controller Class Initialized
INFO - 2023-04-20 12:16:34 --> Model Class Initialized
DEBUG - 2023-04-20 12:16:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 12:16:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:16:34 --> Model Class Initialized
DEBUG - 2023-04-20 12:16:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:16:34 --> Model Class Initialized
INFO - 2023-04-20 12:16:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-04-20 12:16:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:16:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 12:16:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 12:16:34 --> Model Class Initialized
INFO - 2023-04-20 12:16:34 --> Model Class Initialized
INFO - 2023-04-20 12:16:34 --> Model Class Initialized
INFO - 2023-04-20 12:16:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 12:16:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 12:16:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 12:16:34 --> Final output sent to browser
DEBUG - 2023-04-20 12:16:34 --> Total execution time: 0.1716
ERROR - 2023-04-20 12:16:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:16:35 --> Config Class Initialized
INFO - 2023-04-20 12:16:35 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:16:35 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:16:35 --> Utf8 Class Initialized
INFO - 2023-04-20 12:16:35 --> URI Class Initialized
INFO - 2023-04-20 12:16:35 --> Router Class Initialized
INFO - 2023-04-20 12:16:35 --> Output Class Initialized
INFO - 2023-04-20 12:16:35 --> Security Class Initialized
DEBUG - 2023-04-20 12:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:16:35 --> Input Class Initialized
INFO - 2023-04-20 12:16:35 --> Language Class Initialized
INFO - 2023-04-20 12:16:35 --> Loader Class Initialized
INFO - 2023-04-20 12:16:35 --> Helper loaded: url_helper
INFO - 2023-04-20 12:16:35 --> Helper loaded: file_helper
INFO - 2023-04-20 12:16:35 --> Helper loaded: html_helper
INFO - 2023-04-20 12:16:35 --> Helper loaded: text_helper
INFO - 2023-04-20 12:16:35 --> Helper loaded: form_helper
INFO - 2023-04-20 12:16:35 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:16:35 --> Helper loaded: security_helper
INFO - 2023-04-20 12:16:35 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:16:35 --> Database Driver Class Initialized
INFO - 2023-04-20 12:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:16:35 --> Parser Class Initialized
INFO - 2023-04-20 12:16:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:16:35 --> Pagination Class Initialized
INFO - 2023-04-20 12:16:35 --> Form Validation Class Initialized
INFO - 2023-04-20 12:16:35 --> Controller Class Initialized
INFO - 2023-04-20 12:16:35 --> Model Class Initialized
DEBUG - 2023-04-20 12:16:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 12:16:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:16:35 --> Model Class Initialized
DEBUG - 2023-04-20 12:16:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:16:35 --> Model Class Initialized
INFO - 2023-04-20 12:16:35 --> Final output sent to browser
DEBUG - 2023-04-20 12:16:35 --> Total execution time: 0.0596
ERROR - 2023-04-20 12:16:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:16:38 --> Config Class Initialized
INFO - 2023-04-20 12:16:38 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:16:38 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:16:38 --> Utf8 Class Initialized
INFO - 2023-04-20 12:16:38 --> URI Class Initialized
INFO - 2023-04-20 12:16:38 --> Router Class Initialized
INFO - 2023-04-20 12:16:38 --> Output Class Initialized
INFO - 2023-04-20 12:16:38 --> Security Class Initialized
DEBUG - 2023-04-20 12:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:16:38 --> Input Class Initialized
INFO - 2023-04-20 12:16:38 --> Language Class Initialized
INFO - 2023-04-20 12:16:38 --> Loader Class Initialized
INFO - 2023-04-20 12:16:38 --> Helper loaded: url_helper
INFO - 2023-04-20 12:16:38 --> Helper loaded: file_helper
INFO - 2023-04-20 12:16:38 --> Helper loaded: html_helper
INFO - 2023-04-20 12:16:38 --> Helper loaded: text_helper
INFO - 2023-04-20 12:16:38 --> Helper loaded: form_helper
INFO - 2023-04-20 12:16:38 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:16:38 --> Helper loaded: security_helper
INFO - 2023-04-20 12:16:38 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:16:38 --> Database Driver Class Initialized
INFO - 2023-04-20 12:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:16:38 --> Parser Class Initialized
INFO - 2023-04-20 12:16:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:16:38 --> Pagination Class Initialized
INFO - 2023-04-20 12:16:38 --> Form Validation Class Initialized
INFO - 2023-04-20 12:16:38 --> Controller Class Initialized
INFO - 2023-04-20 12:16:38 --> Model Class Initialized
DEBUG - 2023-04-20 12:16:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 12:16:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:16:38 --> Model Class Initialized
DEBUG - 2023-04-20 12:16:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:16:38 --> Model Class Initialized
INFO - 2023-04-20 12:16:38 --> Final output sent to browser
DEBUG - 2023-04-20 12:16:38 --> Total execution time: 0.0714
ERROR - 2023-04-20 12:16:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:16:46 --> Config Class Initialized
INFO - 2023-04-20 12:16:46 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:16:46 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:16:46 --> Utf8 Class Initialized
INFO - 2023-04-20 12:16:46 --> URI Class Initialized
DEBUG - 2023-04-20 12:16:46 --> No URI present. Default controller set.
INFO - 2023-04-20 12:16:46 --> Router Class Initialized
INFO - 2023-04-20 12:16:46 --> Output Class Initialized
INFO - 2023-04-20 12:16:46 --> Security Class Initialized
DEBUG - 2023-04-20 12:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:16:46 --> Input Class Initialized
INFO - 2023-04-20 12:16:46 --> Language Class Initialized
INFO - 2023-04-20 12:16:46 --> Loader Class Initialized
INFO - 2023-04-20 12:16:46 --> Helper loaded: url_helper
INFO - 2023-04-20 12:16:46 --> Helper loaded: file_helper
INFO - 2023-04-20 12:16:46 --> Helper loaded: html_helper
INFO - 2023-04-20 12:16:46 --> Helper loaded: text_helper
INFO - 2023-04-20 12:16:46 --> Helper loaded: form_helper
INFO - 2023-04-20 12:16:46 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:16:46 --> Helper loaded: security_helper
INFO - 2023-04-20 12:16:46 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:16:46 --> Database Driver Class Initialized
INFO - 2023-04-20 12:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:16:46 --> Parser Class Initialized
INFO - 2023-04-20 12:16:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:16:46 --> Pagination Class Initialized
INFO - 2023-04-20 12:16:46 --> Form Validation Class Initialized
INFO - 2023-04-20 12:16:46 --> Controller Class Initialized
INFO - 2023-04-20 12:16:46 --> Model Class Initialized
DEBUG - 2023-04-20 12:16:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:16:46 --> Model Class Initialized
DEBUG - 2023-04-20 12:16:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:16:46 --> Model Class Initialized
INFO - 2023-04-20 12:16:46 --> Model Class Initialized
INFO - 2023-04-20 12:16:46 --> Model Class Initialized
INFO - 2023-04-20 12:16:46 --> Model Class Initialized
DEBUG - 2023-04-20 12:16:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 12:16:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:16:46 --> Model Class Initialized
INFO - 2023-04-20 12:16:46 --> Model Class Initialized
INFO - 2023-04-20 12:16:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-20 12:16:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:16:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 12:16:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 12:16:46 --> Model Class Initialized
INFO - 2023-04-20 12:16:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 12:16:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 12:16:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 12:16:46 --> Final output sent to browser
DEBUG - 2023-04-20 12:16:46 --> Total execution time: 0.1979
ERROR - 2023-04-20 12:19:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:19:20 --> Config Class Initialized
INFO - 2023-04-20 12:19:20 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:19:20 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:19:20 --> Utf8 Class Initialized
INFO - 2023-04-20 12:19:20 --> URI Class Initialized
INFO - 2023-04-20 12:19:20 --> Router Class Initialized
INFO - 2023-04-20 12:19:20 --> Output Class Initialized
INFO - 2023-04-20 12:19:20 --> Security Class Initialized
DEBUG - 2023-04-20 12:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:19:20 --> Input Class Initialized
INFO - 2023-04-20 12:19:20 --> Language Class Initialized
INFO - 2023-04-20 12:19:20 --> Loader Class Initialized
INFO - 2023-04-20 12:19:20 --> Helper loaded: url_helper
INFO - 2023-04-20 12:19:20 --> Helper loaded: file_helper
INFO - 2023-04-20 12:19:20 --> Helper loaded: html_helper
INFO - 2023-04-20 12:19:20 --> Helper loaded: text_helper
INFO - 2023-04-20 12:19:20 --> Helper loaded: form_helper
INFO - 2023-04-20 12:19:20 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:19:20 --> Helper loaded: security_helper
INFO - 2023-04-20 12:19:20 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:19:20 --> Database Driver Class Initialized
INFO - 2023-04-20 12:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:19:20 --> Parser Class Initialized
INFO - 2023-04-20 12:19:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:19:20 --> Pagination Class Initialized
INFO - 2023-04-20 12:19:20 --> Form Validation Class Initialized
INFO - 2023-04-20 12:19:20 --> Controller Class Initialized
DEBUG - 2023-04-20 12:19:20 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:19:20 --> Model Class Initialized
INFO - 2023-04-20 12:19:20 --> Model Class Initialized
INFO - 2023-04-20 12:19:20 --> Model Class Initialized
INFO - 2023-04-20 12:19:20 --> Model Class Initialized
INFO - 2023-04-20 12:19:20 --> Model Class Initialized
INFO - 2023-04-20 12:19:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/add_product_form.php
DEBUG - 2023-04-20 12:19:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:19:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 12:19:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 12:19:20 --> Model Class Initialized
INFO - 2023-04-20 12:19:20 --> Model Class Initialized
INFO - 2023-04-20 12:19:20 --> Model Class Initialized
INFO - 2023-04-20 12:19:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 12:19:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 12:19:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 12:19:20 --> Final output sent to browser
DEBUG - 2023-04-20 12:19:20 --> Total execution time: 0.2222
ERROR - 2023-04-20 12:19:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:19:37 --> Config Class Initialized
INFO - 2023-04-20 12:19:37 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:19:37 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:19:37 --> Utf8 Class Initialized
INFO - 2023-04-20 12:19:37 --> URI Class Initialized
INFO - 2023-04-20 12:19:37 --> Router Class Initialized
INFO - 2023-04-20 12:19:37 --> Output Class Initialized
INFO - 2023-04-20 12:19:37 --> Security Class Initialized
DEBUG - 2023-04-20 12:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:19:37 --> Input Class Initialized
INFO - 2023-04-20 12:19:37 --> Language Class Initialized
INFO - 2023-04-20 12:19:37 --> Loader Class Initialized
INFO - 2023-04-20 12:19:37 --> Helper loaded: url_helper
INFO - 2023-04-20 12:19:37 --> Helper loaded: file_helper
INFO - 2023-04-20 12:19:37 --> Helper loaded: html_helper
INFO - 2023-04-20 12:19:37 --> Helper loaded: text_helper
INFO - 2023-04-20 12:19:37 --> Helper loaded: form_helper
INFO - 2023-04-20 12:19:37 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:19:37 --> Helper loaded: security_helper
INFO - 2023-04-20 12:19:37 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:19:37 --> Database Driver Class Initialized
INFO - 2023-04-20 12:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:19:37 --> Parser Class Initialized
INFO - 2023-04-20 12:19:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:19:37 --> Pagination Class Initialized
INFO - 2023-04-20 12:19:37 --> Form Validation Class Initialized
INFO - 2023-04-20 12:19:37 --> Controller Class Initialized
INFO - 2023-04-20 12:19:37 --> Model Class Initialized
INFO - 2023-04-20 12:19:37 --> Model Class Initialized
ERROR - 2023-04-20 12:19:37 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/views/purchase/add_purchase_form.php 157
INFO - 2023-04-20 12:19:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/add_purchase_form.php
DEBUG - 2023-04-20 12:19:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:19:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 12:19:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 12:19:37 --> Model Class Initialized
INFO - 2023-04-20 12:19:37 --> Model Class Initialized
INFO - 2023-04-20 12:19:37 --> Model Class Initialized
INFO - 2023-04-20 12:19:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 12:19:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 12:19:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 12:19:37 --> Final output sent to browser
DEBUG - 2023-04-20 12:19:37 --> Total execution time: 0.1974
ERROR - 2023-04-20 12:21:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:21:10 --> Config Class Initialized
INFO - 2023-04-20 12:21:10 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:21:10 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:21:10 --> Utf8 Class Initialized
INFO - 2023-04-20 12:21:10 --> URI Class Initialized
INFO - 2023-04-20 12:21:10 --> Router Class Initialized
INFO - 2023-04-20 12:21:10 --> Output Class Initialized
INFO - 2023-04-20 12:21:10 --> Security Class Initialized
DEBUG - 2023-04-20 12:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:21:10 --> Input Class Initialized
INFO - 2023-04-20 12:21:10 --> Language Class Initialized
INFO - 2023-04-20 12:21:10 --> Loader Class Initialized
INFO - 2023-04-20 12:21:10 --> Helper loaded: url_helper
INFO - 2023-04-20 12:21:10 --> Helper loaded: file_helper
INFO - 2023-04-20 12:21:10 --> Helper loaded: html_helper
INFO - 2023-04-20 12:21:10 --> Helper loaded: text_helper
INFO - 2023-04-20 12:21:10 --> Helper loaded: form_helper
INFO - 2023-04-20 12:21:10 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:21:10 --> Helper loaded: security_helper
INFO - 2023-04-20 12:21:10 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:21:10 --> Database Driver Class Initialized
INFO - 2023-04-20 12:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:21:10 --> Parser Class Initialized
INFO - 2023-04-20 12:21:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:21:10 --> Pagination Class Initialized
INFO - 2023-04-20 12:21:10 --> Form Validation Class Initialized
INFO - 2023-04-20 12:21:10 --> Controller Class Initialized
INFO - 2023-04-20 12:21:10 --> Model Class Initialized
INFO - 2023-04-20 12:21:10 --> Final output sent to browser
DEBUG - 2023-04-20 12:21:10 --> Total execution time: 0.0167
ERROR - 2023-04-20 12:21:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:21:10 --> Config Class Initialized
INFO - 2023-04-20 12:21:10 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:21:10 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:21:10 --> Utf8 Class Initialized
INFO - 2023-04-20 12:21:10 --> URI Class Initialized
INFO - 2023-04-20 12:21:10 --> Router Class Initialized
INFO - 2023-04-20 12:21:10 --> Output Class Initialized
INFO - 2023-04-20 12:21:10 --> Security Class Initialized
DEBUG - 2023-04-20 12:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:21:10 --> Input Class Initialized
INFO - 2023-04-20 12:21:10 --> Language Class Initialized
INFO - 2023-04-20 12:21:10 --> Loader Class Initialized
INFO - 2023-04-20 12:21:10 --> Helper loaded: url_helper
INFO - 2023-04-20 12:21:10 --> Helper loaded: file_helper
INFO - 2023-04-20 12:21:10 --> Helper loaded: html_helper
INFO - 2023-04-20 12:21:10 --> Helper loaded: text_helper
INFO - 2023-04-20 12:21:10 --> Helper loaded: form_helper
INFO - 2023-04-20 12:21:10 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:21:10 --> Helper loaded: security_helper
INFO - 2023-04-20 12:21:10 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:21:10 --> Database Driver Class Initialized
INFO - 2023-04-20 12:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:21:10 --> Parser Class Initialized
INFO - 2023-04-20 12:21:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:21:10 --> Pagination Class Initialized
INFO - 2023-04-20 12:21:10 --> Form Validation Class Initialized
INFO - 2023-04-20 12:21:10 --> Controller Class Initialized
INFO - 2023-04-20 12:21:10 --> Model Class Initialized
INFO - 2023-04-20 12:21:10 --> Final output sent to browser
DEBUG - 2023-04-20 12:21:10 --> Total execution time: 0.0149
ERROR - 2023-04-20 12:21:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:21:11 --> Config Class Initialized
INFO - 2023-04-20 12:21:11 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:21:11 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:21:11 --> Utf8 Class Initialized
INFO - 2023-04-20 12:21:11 --> URI Class Initialized
INFO - 2023-04-20 12:21:11 --> Router Class Initialized
INFO - 2023-04-20 12:21:11 --> Output Class Initialized
INFO - 2023-04-20 12:21:11 --> Security Class Initialized
DEBUG - 2023-04-20 12:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:21:11 --> Input Class Initialized
INFO - 2023-04-20 12:21:11 --> Language Class Initialized
INFO - 2023-04-20 12:21:11 --> Loader Class Initialized
INFO - 2023-04-20 12:21:11 --> Helper loaded: url_helper
INFO - 2023-04-20 12:21:11 --> Helper loaded: file_helper
INFO - 2023-04-20 12:21:11 --> Helper loaded: html_helper
INFO - 2023-04-20 12:21:11 --> Helper loaded: text_helper
INFO - 2023-04-20 12:21:11 --> Helper loaded: form_helper
INFO - 2023-04-20 12:21:11 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:21:11 --> Helper loaded: security_helper
INFO - 2023-04-20 12:21:11 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:21:11 --> Database Driver Class Initialized
INFO - 2023-04-20 12:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:21:11 --> Parser Class Initialized
INFO - 2023-04-20 12:21:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:21:11 --> Pagination Class Initialized
INFO - 2023-04-20 12:21:11 --> Form Validation Class Initialized
INFO - 2023-04-20 12:21:11 --> Controller Class Initialized
INFO - 2023-04-20 12:21:11 --> Model Class Initialized
INFO - 2023-04-20 12:21:11 --> Final output sent to browser
DEBUG - 2023-04-20 12:21:11 --> Total execution time: 0.0180
ERROR - 2023-04-20 12:21:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:21:14 --> Config Class Initialized
INFO - 2023-04-20 12:21:14 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:21:14 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:21:14 --> Utf8 Class Initialized
INFO - 2023-04-20 12:21:14 --> URI Class Initialized
INFO - 2023-04-20 12:21:14 --> Router Class Initialized
INFO - 2023-04-20 12:21:14 --> Output Class Initialized
INFO - 2023-04-20 12:21:14 --> Security Class Initialized
DEBUG - 2023-04-20 12:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:21:14 --> Input Class Initialized
INFO - 2023-04-20 12:21:14 --> Language Class Initialized
INFO - 2023-04-20 12:21:14 --> Loader Class Initialized
INFO - 2023-04-20 12:21:14 --> Helper loaded: url_helper
INFO - 2023-04-20 12:21:14 --> Helper loaded: file_helper
INFO - 2023-04-20 12:21:14 --> Helper loaded: html_helper
INFO - 2023-04-20 12:21:14 --> Helper loaded: text_helper
INFO - 2023-04-20 12:21:14 --> Helper loaded: form_helper
INFO - 2023-04-20 12:21:14 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:21:14 --> Helper loaded: security_helper
INFO - 2023-04-20 12:21:14 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:21:14 --> Database Driver Class Initialized
INFO - 2023-04-20 12:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:21:14 --> Parser Class Initialized
INFO - 2023-04-20 12:21:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:21:14 --> Pagination Class Initialized
INFO - 2023-04-20 12:21:14 --> Form Validation Class Initialized
INFO - 2023-04-20 12:21:14 --> Controller Class Initialized
INFO - 2023-04-20 12:21:14 --> Model Class Initialized
DEBUG - 2023-04-20 12:21:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 12:21:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:21:14 --> Model Class Initialized
DEBUG - 2023-04-20 12:21:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:21:14 --> Model Class Initialized
INFO - 2023-04-20 12:21:14 --> Final output sent to browser
DEBUG - 2023-04-20 12:21:14 --> Total execution time: 0.0226
ERROR - 2023-04-20 12:23:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:23:15 --> Config Class Initialized
INFO - 2023-04-20 12:23:15 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:23:15 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:23:15 --> Utf8 Class Initialized
INFO - 2023-04-20 12:23:15 --> URI Class Initialized
INFO - 2023-04-20 12:23:15 --> Router Class Initialized
INFO - 2023-04-20 12:23:15 --> Output Class Initialized
INFO - 2023-04-20 12:23:15 --> Security Class Initialized
DEBUG - 2023-04-20 12:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:23:15 --> Input Class Initialized
INFO - 2023-04-20 12:23:15 --> Language Class Initialized
INFO - 2023-04-20 12:23:15 --> Loader Class Initialized
INFO - 2023-04-20 12:23:15 --> Helper loaded: url_helper
INFO - 2023-04-20 12:23:15 --> Helper loaded: file_helper
INFO - 2023-04-20 12:23:15 --> Helper loaded: html_helper
INFO - 2023-04-20 12:23:15 --> Helper loaded: text_helper
INFO - 2023-04-20 12:23:15 --> Helper loaded: form_helper
INFO - 2023-04-20 12:23:15 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:23:15 --> Helper loaded: security_helper
INFO - 2023-04-20 12:23:15 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:23:15 --> Database Driver Class Initialized
INFO - 2023-04-20 12:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:23:15 --> Parser Class Initialized
INFO - 2023-04-20 12:23:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:23:15 --> Pagination Class Initialized
INFO - 2023-04-20 12:23:15 --> Form Validation Class Initialized
INFO - 2023-04-20 12:23:15 --> Controller Class Initialized
INFO - 2023-04-20 12:23:15 --> Model Class Initialized
INFO - 2023-04-20 12:23:15 --> Model Class Initialized
INFO - 2023-04-20 12:23:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase.php
DEBUG - 2023-04-20 12:23:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:23:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 12:23:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 12:23:15 --> Model Class Initialized
INFO - 2023-04-20 12:23:15 --> Model Class Initialized
INFO - 2023-04-20 12:23:15 --> Model Class Initialized
INFO - 2023-04-20 12:23:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 12:23:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 12:23:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 12:23:15 --> Final output sent to browser
DEBUG - 2023-04-20 12:23:15 --> Total execution time: 0.1562
ERROR - 2023-04-20 12:23:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:23:16 --> Config Class Initialized
INFO - 2023-04-20 12:23:16 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:23:16 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:23:16 --> Utf8 Class Initialized
INFO - 2023-04-20 12:23:16 --> URI Class Initialized
INFO - 2023-04-20 12:23:16 --> Router Class Initialized
INFO - 2023-04-20 12:23:16 --> Output Class Initialized
INFO - 2023-04-20 12:23:16 --> Security Class Initialized
DEBUG - 2023-04-20 12:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:23:16 --> Input Class Initialized
INFO - 2023-04-20 12:23:16 --> Language Class Initialized
INFO - 2023-04-20 12:23:16 --> Loader Class Initialized
INFO - 2023-04-20 12:23:16 --> Helper loaded: url_helper
INFO - 2023-04-20 12:23:16 --> Helper loaded: file_helper
INFO - 2023-04-20 12:23:16 --> Helper loaded: html_helper
INFO - 2023-04-20 12:23:16 --> Helper loaded: text_helper
INFO - 2023-04-20 12:23:16 --> Helper loaded: form_helper
INFO - 2023-04-20 12:23:16 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:23:16 --> Helper loaded: security_helper
INFO - 2023-04-20 12:23:16 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:23:16 --> Database Driver Class Initialized
INFO - 2023-04-20 12:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:23:16 --> Parser Class Initialized
INFO - 2023-04-20 12:23:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:23:16 --> Pagination Class Initialized
INFO - 2023-04-20 12:23:16 --> Form Validation Class Initialized
INFO - 2023-04-20 12:23:16 --> Controller Class Initialized
INFO - 2023-04-20 12:23:16 --> Model Class Initialized
INFO - 2023-04-20 12:23:16 --> Model Class Initialized
INFO - 2023-04-20 12:23:16 --> Final output sent to browser
DEBUG - 2023-04-20 12:23:16 --> Total execution time: 0.0526
ERROR - 2023-04-20 12:23:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:23:26 --> Config Class Initialized
INFO - 2023-04-20 12:23:26 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:23:26 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:23:26 --> Utf8 Class Initialized
INFO - 2023-04-20 12:23:26 --> URI Class Initialized
INFO - 2023-04-20 12:23:26 --> Router Class Initialized
INFO - 2023-04-20 12:23:26 --> Output Class Initialized
INFO - 2023-04-20 12:23:26 --> Security Class Initialized
DEBUG - 2023-04-20 12:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:23:26 --> Input Class Initialized
INFO - 2023-04-20 12:23:26 --> Language Class Initialized
INFO - 2023-04-20 12:23:26 --> Loader Class Initialized
INFO - 2023-04-20 12:23:26 --> Helper loaded: url_helper
INFO - 2023-04-20 12:23:26 --> Helper loaded: file_helper
INFO - 2023-04-20 12:23:26 --> Helper loaded: html_helper
INFO - 2023-04-20 12:23:26 --> Helper loaded: text_helper
INFO - 2023-04-20 12:23:26 --> Helper loaded: form_helper
INFO - 2023-04-20 12:23:26 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:23:26 --> Helper loaded: security_helper
INFO - 2023-04-20 12:23:26 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:23:26 --> Database Driver Class Initialized
INFO - 2023-04-20 12:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:23:26 --> Parser Class Initialized
INFO - 2023-04-20 12:23:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:23:26 --> Pagination Class Initialized
INFO - 2023-04-20 12:23:26 --> Form Validation Class Initialized
INFO - 2023-04-20 12:23:26 --> Controller Class Initialized
INFO - 2023-04-20 12:23:26 --> Model Class Initialized
INFO - 2023-04-20 12:23:26 --> Model Class Initialized
ERROR - 2023-04-20 12:23:26 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/views/purchase/add_purchase_form.php 157
INFO - 2023-04-20 12:23:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/add_purchase_form.php
DEBUG - 2023-04-20 12:23:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:23:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 12:23:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 12:23:26 --> Model Class Initialized
INFO - 2023-04-20 12:23:26 --> Model Class Initialized
INFO - 2023-04-20 12:23:26 --> Model Class Initialized
INFO - 2023-04-20 12:23:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 12:23:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 12:23:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 12:23:26 --> Final output sent to browser
DEBUG - 2023-04-20 12:23:26 --> Total execution time: 0.2024
ERROR - 2023-04-20 12:23:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:23:55 --> Config Class Initialized
INFO - 2023-04-20 12:23:55 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:23:55 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:23:55 --> Utf8 Class Initialized
INFO - 2023-04-20 12:23:55 --> URI Class Initialized
INFO - 2023-04-20 12:23:55 --> Router Class Initialized
INFO - 2023-04-20 12:23:55 --> Output Class Initialized
INFO - 2023-04-20 12:23:55 --> Security Class Initialized
DEBUG - 2023-04-20 12:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:23:55 --> Input Class Initialized
INFO - 2023-04-20 12:23:55 --> Language Class Initialized
INFO - 2023-04-20 12:23:55 --> Loader Class Initialized
INFO - 2023-04-20 12:23:55 --> Helper loaded: url_helper
INFO - 2023-04-20 12:23:55 --> Helper loaded: file_helper
INFO - 2023-04-20 12:23:55 --> Helper loaded: html_helper
INFO - 2023-04-20 12:23:55 --> Helper loaded: text_helper
INFO - 2023-04-20 12:23:55 --> Helper loaded: form_helper
INFO - 2023-04-20 12:23:55 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:23:55 --> Helper loaded: security_helper
INFO - 2023-04-20 12:23:55 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:23:55 --> Database Driver Class Initialized
INFO - 2023-04-20 12:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:23:55 --> Parser Class Initialized
INFO - 2023-04-20 12:23:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:23:55 --> Pagination Class Initialized
INFO - 2023-04-20 12:23:55 --> Form Validation Class Initialized
INFO - 2023-04-20 12:23:55 --> Controller Class Initialized
DEBUG - 2023-04-20 12:23:55 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:23:55 --> Model Class Initialized
INFO - 2023-04-20 12:23:55 --> Model Class Initialized
INFO - 2023-04-20 12:23:55 --> Model Class Initialized
INFO - 2023-04-20 12:23:55 --> Model Class Initialized
INFO - 2023-04-20 12:23:55 --> Model Class Initialized
INFO - 2023-04-20 12:23:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/add_product_form.php
DEBUG - 2023-04-20 12:23:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:23:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 12:23:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 12:23:55 --> Model Class Initialized
INFO - 2023-04-20 12:23:55 --> Model Class Initialized
INFO - 2023-04-20 12:23:55 --> Model Class Initialized
INFO - 2023-04-20 12:23:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 12:23:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 12:23:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 12:23:55 --> Final output sent to browser
DEBUG - 2023-04-20 12:23:55 --> Total execution time: 0.2202
ERROR - 2023-04-20 12:52:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:52:26 --> Config Class Initialized
INFO - 2023-04-20 12:52:26 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:52:26 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:52:26 --> Utf8 Class Initialized
INFO - 2023-04-20 12:52:26 --> URI Class Initialized
DEBUG - 2023-04-20 12:52:26 --> No URI present. Default controller set.
INFO - 2023-04-20 12:52:26 --> Router Class Initialized
INFO - 2023-04-20 12:52:26 --> Output Class Initialized
INFO - 2023-04-20 12:52:26 --> Security Class Initialized
DEBUG - 2023-04-20 12:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:52:26 --> Input Class Initialized
INFO - 2023-04-20 12:52:26 --> Language Class Initialized
INFO - 2023-04-20 12:52:26 --> Loader Class Initialized
INFO - 2023-04-20 12:52:26 --> Helper loaded: url_helper
INFO - 2023-04-20 12:52:26 --> Helper loaded: file_helper
INFO - 2023-04-20 12:52:26 --> Helper loaded: html_helper
INFO - 2023-04-20 12:52:26 --> Helper loaded: text_helper
INFO - 2023-04-20 12:52:26 --> Helper loaded: form_helper
INFO - 2023-04-20 12:52:26 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:52:26 --> Helper loaded: security_helper
INFO - 2023-04-20 12:52:26 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:52:26 --> Database Driver Class Initialized
INFO - 2023-04-20 12:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:52:26 --> Parser Class Initialized
INFO - 2023-04-20 12:52:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:52:26 --> Pagination Class Initialized
INFO - 2023-04-20 12:52:26 --> Form Validation Class Initialized
INFO - 2023-04-20 12:52:26 --> Controller Class Initialized
INFO - 2023-04-20 12:52:26 --> Model Class Initialized
DEBUG - 2023-04-20 12:52:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:52:26 --> Model Class Initialized
DEBUG - 2023-04-20 12:52:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:52:26 --> Model Class Initialized
INFO - 2023-04-20 12:52:26 --> Model Class Initialized
INFO - 2023-04-20 12:52:26 --> Model Class Initialized
INFO - 2023-04-20 12:52:27 --> Model Class Initialized
DEBUG - 2023-04-20 12:52:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 12:52:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:52:27 --> Model Class Initialized
INFO - 2023-04-20 12:52:27 --> Model Class Initialized
INFO - 2023-04-20 12:52:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-20 12:52:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:52:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 12:52:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 12:52:27 --> Model Class Initialized
INFO - 2023-04-20 12:52:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 12:52:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 12:52:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 12:52:27 --> Final output sent to browser
DEBUG - 2023-04-20 12:52:27 --> Total execution time: 0.2088
ERROR - 2023-04-20 12:52:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:52:31 --> Config Class Initialized
INFO - 2023-04-20 12:52:31 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:52:31 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:52:31 --> Utf8 Class Initialized
INFO - 2023-04-20 12:52:31 --> URI Class Initialized
DEBUG - 2023-04-20 12:52:31 --> No URI present. Default controller set.
INFO - 2023-04-20 12:52:31 --> Router Class Initialized
INFO - 2023-04-20 12:52:31 --> Output Class Initialized
INFO - 2023-04-20 12:52:31 --> Security Class Initialized
DEBUG - 2023-04-20 12:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:52:31 --> Input Class Initialized
INFO - 2023-04-20 12:52:31 --> Language Class Initialized
INFO - 2023-04-20 12:52:31 --> Loader Class Initialized
INFO - 2023-04-20 12:52:31 --> Helper loaded: url_helper
INFO - 2023-04-20 12:52:31 --> Helper loaded: file_helper
INFO - 2023-04-20 12:52:31 --> Helper loaded: html_helper
INFO - 2023-04-20 12:52:31 --> Helper loaded: text_helper
INFO - 2023-04-20 12:52:31 --> Helper loaded: form_helper
INFO - 2023-04-20 12:52:31 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:52:31 --> Helper loaded: security_helper
INFO - 2023-04-20 12:52:31 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:52:31 --> Database Driver Class Initialized
INFO - 2023-04-20 12:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:52:32 --> Parser Class Initialized
INFO - 2023-04-20 12:52:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:52:32 --> Pagination Class Initialized
INFO - 2023-04-20 12:52:32 --> Form Validation Class Initialized
INFO - 2023-04-20 12:52:32 --> Controller Class Initialized
INFO - 2023-04-20 12:52:32 --> Model Class Initialized
DEBUG - 2023-04-20 12:52:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:52:32 --> Model Class Initialized
DEBUG - 2023-04-20 12:52:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:52:32 --> Model Class Initialized
INFO - 2023-04-20 12:52:32 --> Model Class Initialized
INFO - 2023-04-20 12:52:32 --> Model Class Initialized
INFO - 2023-04-20 12:52:32 --> Model Class Initialized
DEBUG - 2023-04-20 12:52:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 12:52:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:52:32 --> Model Class Initialized
INFO - 2023-04-20 12:52:32 --> Model Class Initialized
INFO - 2023-04-20 12:52:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-20 12:52:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:52:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 12:52:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 12:52:32 --> Model Class Initialized
INFO - 2023-04-20 12:52:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 12:52:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 12:52:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 12:52:32 --> Final output sent to browser
DEBUG - 2023-04-20 12:52:32 --> Total execution time: 0.1895
ERROR - 2023-04-20 12:53:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:53:29 --> Config Class Initialized
INFO - 2023-04-20 12:53:29 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:53:29 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:53:29 --> Utf8 Class Initialized
INFO - 2023-04-20 12:53:29 --> URI Class Initialized
INFO - 2023-04-20 12:53:29 --> Router Class Initialized
INFO - 2023-04-20 12:53:29 --> Output Class Initialized
INFO - 2023-04-20 12:53:29 --> Security Class Initialized
DEBUG - 2023-04-20 12:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:53:29 --> Input Class Initialized
INFO - 2023-04-20 12:53:29 --> Language Class Initialized
INFO - 2023-04-20 12:53:29 --> Loader Class Initialized
INFO - 2023-04-20 12:53:29 --> Helper loaded: url_helper
INFO - 2023-04-20 12:53:29 --> Helper loaded: file_helper
INFO - 2023-04-20 12:53:29 --> Helper loaded: html_helper
INFO - 2023-04-20 12:53:29 --> Helper loaded: text_helper
INFO - 2023-04-20 12:53:29 --> Helper loaded: form_helper
INFO - 2023-04-20 12:53:29 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:53:29 --> Helper loaded: security_helper
INFO - 2023-04-20 12:53:29 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:53:29 --> Database Driver Class Initialized
INFO - 2023-04-20 12:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:53:29 --> Parser Class Initialized
INFO - 2023-04-20 12:53:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:53:29 --> Pagination Class Initialized
INFO - 2023-04-20 12:53:29 --> Form Validation Class Initialized
INFO - 2023-04-20 12:53:29 --> Controller Class Initialized
INFO - 2023-04-20 12:53:29 --> Model Class Initialized
INFO - 2023-04-20 12:53:29 --> Model Class Initialized
INFO - 2023-04-20 12:53:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase.php
DEBUG - 2023-04-20 12:53:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:53:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 12:53:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 12:53:29 --> Model Class Initialized
INFO - 2023-04-20 12:53:29 --> Model Class Initialized
INFO - 2023-04-20 12:53:29 --> Model Class Initialized
INFO - 2023-04-20 12:53:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 12:53:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 12:53:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 12:53:29 --> Final output sent to browser
DEBUG - 2023-04-20 12:53:29 --> Total execution time: 0.1593
ERROR - 2023-04-20 12:53:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:53:30 --> Config Class Initialized
INFO - 2023-04-20 12:53:30 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:53:30 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:53:30 --> Utf8 Class Initialized
INFO - 2023-04-20 12:53:30 --> URI Class Initialized
INFO - 2023-04-20 12:53:30 --> Router Class Initialized
INFO - 2023-04-20 12:53:30 --> Output Class Initialized
INFO - 2023-04-20 12:53:30 --> Security Class Initialized
DEBUG - 2023-04-20 12:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:53:30 --> Input Class Initialized
INFO - 2023-04-20 12:53:30 --> Language Class Initialized
INFO - 2023-04-20 12:53:30 --> Loader Class Initialized
INFO - 2023-04-20 12:53:30 --> Helper loaded: url_helper
INFO - 2023-04-20 12:53:30 --> Helper loaded: file_helper
INFO - 2023-04-20 12:53:30 --> Helper loaded: html_helper
INFO - 2023-04-20 12:53:30 --> Helper loaded: text_helper
INFO - 2023-04-20 12:53:30 --> Helper loaded: form_helper
INFO - 2023-04-20 12:53:30 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:53:30 --> Helper loaded: security_helper
INFO - 2023-04-20 12:53:30 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:53:30 --> Database Driver Class Initialized
INFO - 2023-04-20 12:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:53:30 --> Parser Class Initialized
INFO - 2023-04-20 12:53:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:53:30 --> Pagination Class Initialized
INFO - 2023-04-20 12:53:30 --> Form Validation Class Initialized
INFO - 2023-04-20 12:53:30 --> Controller Class Initialized
INFO - 2023-04-20 12:53:30 --> Model Class Initialized
INFO - 2023-04-20 12:53:30 --> Model Class Initialized
INFO - 2023-04-20 12:53:30 --> Final output sent to browser
DEBUG - 2023-04-20 12:53:30 --> Total execution time: 0.0513
ERROR - 2023-04-20 12:53:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:53:34 --> Config Class Initialized
INFO - 2023-04-20 12:53:34 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:53:34 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:53:34 --> Utf8 Class Initialized
INFO - 2023-04-20 12:53:34 --> URI Class Initialized
INFO - 2023-04-20 12:53:34 --> Router Class Initialized
INFO - 2023-04-20 12:53:34 --> Output Class Initialized
INFO - 2023-04-20 12:53:34 --> Security Class Initialized
DEBUG - 2023-04-20 12:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:53:34 --> Input Class Initialized
INFO - 2023-04-20 12:53:34 --> Language Class Initialized
INFO - 2023-04-20 12:53:34 --> Loader Class Initialized
INFO - 2023-04-20 12:53:34 --> Helper loaded: url_helper
INFO - 2023-04-20 12:53:34 --> Helper loaded: file_helper
INFO - 2023-04-20 12:53:34 --> Helper loaded: html_helper
INFO - 2023-04-20 12:53:34 --> Helper loaded: text_helper
INFO - 2023-04-20 12:53:34 --> Helper loaded: form_helper
INFO - 2023-04-20 12:53:34 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:53:34 --> Helper loaded: security_helper
INFO - 2023-04-20 12:53:34 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:53:34 --> Database Driver Class Initialized
INFO - 2023-04-20 12:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:53:34 --> Parser Class Initialized
INFO - 2023-04-20 12:53:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:53:34 --> Pagination Class Initialized
INFO - 2023-04-20 12:53:34 --> Form Validation Class Initialized
INFO - 2023-04-20 12:53:34 --> Controller Class Initialized
INFO - 2023-04-20 12:53:34 --> Model Class Initialized
INFO - 2023-04-20 12:53:34 --> Model Class Initialized
INFO - 2023-04-20 12:53:34 --> Final output sent to browser
DEBUG - 2023-04-20 12:53:34 --> Total execution time: 0.0719
ERROR - 2023-04-20 12:53:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:53:59 --> Config Class Initialized
INFO - 2023-04-20 12:53:59 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:53:59 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:53:59 --> Utf8 Class Initialized
INFO - 2023-04-20 12:53:59 --> URI Class Initialized
INFO - 2023-04-20 12:53:59 --> Router Class Initialized
INFO - 2023-04-20 12:53:59 --> Output Class Initialized
INFO - 2023-04-20 12:53:59 --> Security Class Initialized
DEBUG - 2023-04-20 12:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:53:59 --> Input Class Initialized
INFO - 2023-04-20 12:53:59 --> Language Class Initialized
INFO - 2023-04-20 12:53:59 --> Loader Class Initialized
INFO - 2023-04-20 12:53:59 --> Helper loaded: url_helper
INFO - 2023-04-20 12:53:59 --> Helper loaded: file_helper
INFO - 2023-04-20 12:53:59 --> Helper loaded: html_helper
INFO - 2023-04-20 12:53:59 --> Helper loaded: text_helper
INFO - 2023-04-20 12:53:59 --> Helper loaded: form_helper
INFO - 2023-04-20 12:53:59 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:53:59 --> Helper loaded: security_helper
INFO - 2023-04-20 12:53:59 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:53:59 --> Database Driver Class Initialized
INFO - 2023-04-20 12:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:53:59 --> Parser Class Initialized
INFO - 2023-04-20 12:53:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:53:59 --> Pagination Class Initialized
INFO - 2023-04-20 12:53:59 --> Form Validation Class Initialized
INFO - 2023-04-20 12:53:59 --> Controller Class Initialized
INFO - 2023-04-20 12:53:59 --> Model Class Initialized
DEBUG - 2023-04-20 12:53:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 12:53:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:53:59 --> Model Class Initialized
INFO - 2023-04-20 12:53:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-04-20 12:53:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:53:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 12:53:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 12:53:59 --> Model Class Initialized
INFO - 2023-04-20 12:53:59 --> Model Class Initialized
INFO - 2023-04-20 12:53:59 --> Model Class Initialized
INFO - 2023-04-20 12:54:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 12:54:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 12:54:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 12:54:00 --> Final output sent to browser
DEBUG - 2023-04-20 12:54:00 --> Total execution time: 0.1473
ERROR - 2023-04-20 12:54:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:54:00 --> Config Class Initialized
INFO - 2023-04-20 12:54:00 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:54:00 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:54:00 --> Utf8 Class Initialized
INFO - 2023-04-20 12:54:00 --> URI Class Initialized
INFO - 2023-04-20 12:54:00 --> Router Class Initialized
INFO - 2023-04-20 12:54:00 --> Output Class Initialized
INFO - 2023-04-20 12:54:00 --> Security Class Initialized
DEBUG - 2023-04-20 12:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:54:00 --> Input Class Initialized
INFO - 2023-04-20 12:54:00 --> Language Class Initialized
INFO - 2023-04-20 12:54:00 --> Loader Class Initialized
INFO - 2023-04-20 12:54:00 --> Helper loaded: url_helper
INFO - 2023-04-20 12:54:00 --> Helper loaded: file_helper
INFO - 2023-04-20 12:54:00 --> Helper loaded: html_helper
INFO - 2023-04-20 12:54:00 --> Helper loaded: text_helper
INFO - 2023-04-20 12:54:00 --> Helper loaded: form_helper
INFO - 2023-04-20 12:54:00 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:54:00 --> Helper loaded: security_helper
INFO - 2023-04-20 12:54:00 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:54:00 --> Database Driver Class Initialized
INFO - 2023-04-20 12:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:54:00 --> Parser Class Initialized
INFO - 2023-04-20 12:54:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:54:00 --> Pagination Class Initialized
INFO - 2023-04-20 12:54:00 --> Form Validation Class Initialized
INFO - 2023-04-20 12:54:00 --> Controller Class Initialized
INFO - 2023-04-20 12:54:00 --> Model Class Initialized
DEBUG - 2023-04-20 12:54:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 12:54:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:54:00 --> Model Class Initialized
INFO - 2023-04-20 12:54:00 --> Final output sent to browser
DEBUG - 2023-04-20 12:54:00 --> Total execution time: 0.0194
ERROR - 2023-04-20 12:54:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:54:04 --> Config Class Initialized
INFO - 2023-04-20 12:54:04 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:54:04 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:54:04 --> Utf8 Class Initialized
INFO - 2023-04-20 12:54:04 --> URI Class Initialized
INFO - 2023-04-20 12:54:04 --> Router Class Initialized
INFO - 2023-04-20 12:54:04 --> Output Class Initialized
INFO - 2023-04-20 12:54:04 --> Security Class Initialized
DEBUG - 2023-04-20 12:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:54:04 --> Input Class Initialized
INFO - 2023-04-20 12:54:04 --> Language Class Initialized
INFO - 2023-04-20 12:54:04 --> Loader Class Initialized
INFO - 2023-04-20 12:54:04 --> Helper loaded: url_helper
INFO - 2023-04-20 12:54:04 --> Helper loaded: file_helper
INFO - 2023-04-20 12:54:04 --> Helper loaded: html_helper
INFO - 2023-04-20 12:54:04 --> Helper loaded: text_helper
INFO - 2023-04-20 12:54:04 --> Helper loaded: form_helper
INFO - 2023-04-20 12:54:04 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:54:04 --> Helper loaded: security_helper
INFO - 2023-04-20 12:54:04 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:54:04 --> Database Driver Class Initialized
INFO - 2023-04-20 12:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:54:04 --> Parser Class Initialized
INFO - 2023-04-20 12:54:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:54:04 --> Pagination Class Initialized
INFO - 2023-04-20 12:54:04 --> Form Validation Class Initialized
INFO - 2023-04-20 12:54:04 --> Controller Class Initialized
INFO - 2023-04-20 12:54:04 --> Model Class Initialized
DEBUG - 2023-04-20 12:54:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 12:54:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:54:04 --> Model Class Initialized
INFO - 2023-04-20 12:54:04 --> Final output sent to browser
DEBUG - 2023-04-20 12:54:04 --> Total execution time: 0.0191
ERROR - 2023-04-20 12:54:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:54:47 --> Config Class Initialized
INFO - 2023-04-20 12:54:47 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:54:47 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:54:47 --> Utf8 Class Initialized
INFO - 2023-04-20 12:54:47 --> URI Class Initialized
DEBUG - 2023-04-20 12:54:47 --> No URI present. Default controller set.
INFO - 2023-04-20 12:54:47 --> Router Class Initialized
INFO - 2023-04-20 12:54:47 --> Output Class Initialized
INFO - 2023-04-20 12:54:47 --> Security Class Initialized
DEBUG - 2023-04-20 12:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:54:47 --> Input Class Initialized
INFO - 2023-04-20 12:54:47 --> Language Class Initialized
INFO - 2023-04-20 12:54:47 --> Loader Class Initialized
INFO - 2023-04-20 12:54:47 --> Helper loaded: url_helper
INFO - 2023-04-20 12:54:47 --> Helper loaded: file_helper
INFO - 2023-04-20 12:54:47 --> Helper loaded: html_helper
INFO - 2023-04-20 12:54:47 --> Helper loaded: text_helper
INFO - 2023-04-20 12:54:47 --> Helper loaded: form_helper
INFO - 2023-04-20 12:54:47 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:54:47 --> Helper loaded: security_helper
INFO - 2023-04-20 12:54:47 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:54:47 --> Database Driver Class Initialized
INFO - 2023-04-20 12:54:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:54:47 --> Parser Class Initialized
INFO - 2023-04-20 12:54:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:54:47 --> Pagination Class Initialized
INFO - 2023-04-20 12:54:47 --> Form Validation Class Initialized
INFO - 2023-04-20 12:54:47 --> Controller Class Initialized
INFO - 2023-04-20 12:54:47 --> Model Class Initialized
DEBUG - 2023-04-20 12:54:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-20 12:54:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:54:48 --> Config Class Initialized
INFO - 2023-04-20 12:54:48 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:54:48 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:54:48 --> Utf8 Class Initialized
INFO - 2023-04-20 12:54:48 --> URI Class Initialized
INFO - 2023-04-20 12:54:48 --> Router Class Initialized
INFO - 2023-04-20 12:54:48 --> Output Class Initialized
INFO - 2023-04-20 12:54:48 --> Security Class Initialized
DEBUG - 2023-04-20 12:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:54:48 --> Input Class Initialized
INFO - 2023-04-20 12:54:48 --> Language Class Initialized
INFO - 2023-04-20 12:54:48 --> Loader Class Initialized
INFO - 2023-04-20 12:54:48 --> Helper loaded: url_helper
INFO - 2023-04-20 12:54:48 --> Helper loaded: file_helper
INFO - 2023-04-20 12:54:48 --> Helper loaded: html_helper
INFO - 2023-04-20 12:54:48 --> Helper loaded: text_helper
INFO - 2023-04-20 12:54:48 --> Helper loaded: form_helper
INFO - 2023-04-20 12:54:48 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:54:48 --> Helper loaded: security_helper
INFO - 2023-04-20 12:54:48 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:54:48 --> Database Driver Class Initialized
INFO - 2023-04-20 12:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:54:48 --> Parser Class Initialized
INFO - 2023-04-20 12:54:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:54:48 --> Pagination Class Initialized
INFO - 2023-04-20 12:54:48 --> Form Validation Class Initialized
INFO - 2023-04-20 12:54:48 --> Controller Class Initialized
INFO - 2023-04-20 12:54:48 --> Model Class Initialized
DEBUG - 2023-04-20 12:54:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:54:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-20 12:54:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:54:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 12:54:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 12:54:48 --> Model Class Initialized
INFO - 2023-04-20 12:54:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 12:54:48 --> Final output sent to browser
DEBUG - 2023-04-20 12:54:48 --> Total execution time: 0.0326
ERROR - 2023-04-20 12:54:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:54:51 --> Config Class Initialized
INFO - 2023-04-20 12:54:51 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:54:51 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:54:51 --> Utf8 Class Initialized
INFO - 2023-04-20 12:54:51 --> URI Class Initialized
INFO - 2023-04-20 12:54:51 --> Router Class Initialized
INFO - 2023-04-20 12:54:51 --> Output Class Initialized
INFO - 2023-04-20 12:54:51 --> Security Class Initialized
DEBUG - 2023-04-20 12:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:54:51 --> Input Class Initialized
INFO - 2023-04-20 12:54:51 --> Language Class Initialized
INFO - 2023-04-20 12:54:51 --> Loader Class Initialized
INFO - 2023-04-20 12:54:51 --> Helper loaded: url_helper
INFO - 2023-04-20 12:54:51 --> Helper loaded: file_helper
INFO - 2023-04-20 12:54:51 --> Helper loaded: html_helper
INFO - 2023-04-20 12:54:51 --> Helper loaded: text_helper
INFO - 2023-04-20 12:54:51 --> Helper loaded: form_helper
INFO - 2023-04-20 12:54:51 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:54:51 --> Helper loaded: security_helper
INFO - 2023-04-20 12:54:51 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:54:51 --> Database Driver Class Initialized
INFO - 2023-04-20 12:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:54:51 --> Parser Class Initialized
INFO - 2023-04-20 12:54:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:54:51 --> Pagination Class Initialized
INFO - 2023-04-20 12:54:51 --> Form Validation Class Initialized
INFO - 2023-04-20 12:54:51 --> Controller Class Initialized
DEBUG - 2023-04-20 12:54:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 12:54:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:54:51 --> Model Class Initialized
DEBUG - 2023-04-20 12:54:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:54:51 --> Model Class Initialized
DEBUG - 2023-04-20 12:54:51 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:54:51 --> Model Class Initialized
INFO - 2023-04-20 12:54:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-04-20 12:54:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:54:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 12:54:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 12:54:51 --> Model Class Initialized
INFO - 2023-04-20 12:54:51 --> Model Class Initialized
INFO - 2023-04-20 12:54:51 --> Model Class Initialized
INFO - 2023-04-20 12:54:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 12:54:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 12:54:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 12:54:51 --> Final output sent to browser
DEBUG - 2023-04-20 12:54:51 --> Total execution time: 0.1615
ERROR - 2023-04-20 12:54:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:54:52 --> Config Class Initialized
INFO - 2023-04-20 12:54:52 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:54:52 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:54:52 --> Utf8 Class Initialized
INFO - 2023-04-20 12:54:52 --> URI Class Initialized
INFO - 2023-04-20 12:54:52 --> Router Class Initialized
INFO - 2023-04-20 12:54:52 --> Output Class Initialized
INFO - 2023-04-20 12:54:52 --> Security Class Initialized
DEBUG - 2023-04-20 12:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:54:52 --> Input Class Initialized
INFO - 2023-04-20 12:54:52 --> Language Class Initialized
INFO - 2023-04-20 12:54:52 --> Loader Class Initialized
INFO - 2023-04-20 12:54:52 --> Helper loaded: url_helper
INFO - 2023-04-20 12:54:52 --> Helper loaded: file_helper
INFO - 2023-04-20 12:54:52 --> Helper loaded: html_helper
INFO - 2023-04-20 12:54:52 --> Helper loaded: text_helper
INFO - 2023-04-20 12:54:52 --> Helper loaded: form_helper
INFO - 2023-04-20 12:54:52 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:54:52 --> Helper loaded: security_helper
INFO - 2023-04-20 12:54:52 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:54:52 --> Database Driver Class Initialized
INFO - 2023-04-20 12:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:54:52 --> Parser Class Initialized
INFO - 2023-04-20 12:54:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:54:52 --> Pagination Class Initialized
INFO - 2023-04-20 12:54:52 --> Form Validation Class Initialized
INFO - 2023-04-20 12:54:52 --> Controller Class Initialized
DEBUG - 2023-04-20 12:54:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 12:54:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:54:52 --> Model Class Initialized
DEBUG - 2023-04-20 12:54:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:54:52 --> Model Class Initialized
INFO - 2023-04-20 12:54:52 --> Final output sent to browser
DEBUG - 2023-04-20 12:54:52 --> Total execution time: 0.0358
ERROR - 2023-04-20 12:54:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:54:56 --> Config Class Initialized
INFO - 2023-04-20 12:54:56 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:54:56 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:54:56 --> Utf8 Class Initialized
INFO - 2023-04-20 12:54:56 --> URI Class Initialized
INFO - 2023-04-20 12:54:56 --> Router Class Initialized
INFO - 2023-04-20 12:54:56 --> Output Class Initialized
INFO - 2023-04-20 12:54:56 --> Security Class Initialized
DEBUG - 2023-04-20 12:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:54:56 --> Input Class Initialized
INFO - 2023-04-20 12:54:56 --> Language Class Initialized
INFO - 2023-04-20 12:54:56 --> Loader Class Initialized
INFO - 2023-04-20 12:54:56 --> Helper loaded: url_helper
INFO - 2023-04-20 12:54:56 --> Helper loaded: file_helper
INFO - 2023-04-20 12:54:56 --> Helper loaded: html_helper
INFO - 2023-04-20 12:54:56 --> Helper loaded: text_helper
INFO - 2023-04-20 12:54:56 --> Helper loaded: form_helper
INFO - 2023-04-20 12:54:56 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:54:56 --> Helper loaded: security_helper
INFO - 2023-04-20 12:54:56 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:54:56 --> Database Driver Class Initialized
INFO - 2023-04-20 12:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:54:56 --> Parser Class Initialized
INFO - 2023-04-20 12:54:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:54:56 --> Pagination Class Initialized
INFO - 2023-04-20 12:54:56 --> Form Validation Class Initialized
INFO - 2023-04-20 12:54:56 --> Controller Class Initialized
DEBUG - 2023-04-20 12:54:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 12:54:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:54:56 --> Model Class Initialized
INFO - 2023-04-20 12:54:56 --> Model Class Initialized
DEBUG - 2023-04-20 12:54:56 --> Lmr class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:54:56 --> Model Class Initialized
INFO - 2023-04-20 12:54:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/mr/mr.php
DEBUG - 2023-04-20 12:54:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:54:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 12:54:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 12:54:56 --> Model Class Initialized
INFO - 2023-04-20 12:54:56 --> Model Class Initialized
INFO - 2023-04-20 12:54:56 --> Model Class Initialized
INFO - 2023-04-20 12:54:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 12:54:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 12:54:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 12:54:56 --> Final output sent to browser
DEBUG - 2023-04-20 12:54:56 --> Total execution time: 0.1383
ERROR - 2023-04-20 12:54:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:54:57 --> Config Class Initialized
INFO - 2023-04-20 12:54:57 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:54:57 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:54:57 --> Utf8 Class Initialized
INFO - 2023-04-20 12:54:57 --> URI Class Initialized
INFO - 2023-04-20 12:54:57 --> Router Class Initialized
INFO - 2023-04-20 12:54:57 --> Output Class Initialized
INFO - 2023-04-20 12:54:57 --> Security Class Initialized
DEBUG - 2023-04-20 12:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:54:57 --> Input Class Initialized
INFO - 2023-04-20 12:54:57 --> Language Class Initialized
INFO - 2023-04-20 12:54:57 --> Loader Class Initialized
INFO - 2023-04-20 12:54:57 --> Helper loaded: url_helper
INFO - 2023-04-20 12:54:57 --> Helper loaded: file_helper
INFO - 2023-04-20 12:54:57 --> Helper loaded: html_helper
INFO - 2023-04-20 12:54:57 --> Helper loaded: text_helper
INFO - 2023-04-20 12:54:57 --> Helper loaded: form_helper
INFO - 2023-04-20 12:54:57 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:54:57 --> Helper loaded: security_helper
INFO - 2023-04-20 12:54:57 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:54:57 --> Database Driver Class Initialized
INFO - 2023-04-20 12:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:54:57 --> Parser Class Initialized
INFO - 2023-04-20 12:54:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:54:57 --> Pagination Class Initialized
INFO - 2023-04-20 12:54:57 --> Form Validation Class Initialized
INFO - 2023-04-20 12:54:57 --> Controller Class Initialized
DEBUG - 2023-04-20 12:54:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 12:54:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:54:57 --> Model Class Initialized
INFO - 2023-04-20 12:54:57 --> Model Class Initialized
INFO - 2023-04-20 12:54:57 --> Final output sent to browser
DEBUG - 2023-04-20 12:54:57 --> Total execution time: 0.0190
ERROR - 2023-04-20 12:55:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:55:20 --> Config Class Initialized
INFO - 2023-04-20 12:55:20 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:55:20 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:55:20 --> Utf8 Class Initialized
INFO - 2023-04-20 12:55:20 --> URI Class Initialized
INFO - 2023-04-20 12:55:20 --> Router Class Initialized
INFO - 2023-04-20 12:55:20 --> Output Class Initialized
INFO - 2023-04-20 12:55:20 --> Security Class Initialized
DEBUG - 2023-04-20 12:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:55:20 --> Input Class Initialized
INFO - 2023-04-20 12:55:20 --> Language Class Initialized
INFO - 2023-04-20 12:55:20 --> Loader Class Initialized
INFO - 2023-04-20 12:55:20 --> Helper loaded: url_helper
INFO - 2023-04-20 12:55:20 --> Helper loaded: file_helper
INFO - 2023-04-20 12:55:20 --> Helper loaded: html_helper
INFO - 2023-04-20 12:55:20 --> Helper loaded: text_helper
INFO - 2023-04-20 12:55:20 --> Helper loaded: form_helper
INFO - 2023-04-20 12:55:20 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:55:20 --> Helper loaded: security_helper
INFO - 2023-04-20 12:55:20 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:55:20 --> Database Driver Class Initialized
INFO - 2023-04-20 12:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:55:20 --> Parser Class Initialized
INFO - 2023-04-20 12:55:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:55:20 --> Pagination Class Initialized
INFO - 2023-04-20 12:55:20 --> Form Validation Class Initialized
INFO - 2023-04-20 12:55:20 --> Controller Class Initialized
INFO - 2023-04-20 12:55:20 --> Model Class Initialized
DEBUG - 2023-04-20 12:55:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:55:20 --> Model Class Initialized
INFO - 2023-04-20 12:55:20 --> Final output sent to browser
DEBUG - 2023-04-20 12:55:20 --> Total execution time: 0.0205
ERROR - 2023-04-20 12:55:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:55:21 --> Config Class Initialized
INFO - 2023-04-20 12:55:21 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:55:21 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:55:21 --> Utf8 Class Initialized
INFO - 2023-04-20 12:55:21 --> URI Class Initialized
DEBUG - 2023-04-20 12:55:21 --> No URI present. Default controller set.
INFO - 2023-04-20 12:55:21 --> Router Class Initialized
INFO - 2023-04-20 12:55:21 --> Output Class Initialized
INFO - 2023-04-20 12:55:21 --> Security Class Initialized
DEBUG - 2023-04-20 12:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:55:21 --> Input Class Initialized
INFO - 2023-04-20 12:55:21 --> Language Class Initialized
INFO - 2023-04-20 12:55:21 --> Loader Class Initialized
INFO - 2023-04-20 12:55:21 --> Helper loaded: url_helper
INFO - 2023-04-20 12:55:21 --> Helper loaded: file_helper
INFO - 2023-04-20 12:55:21 --> Helper loaded: html_helper
INFO - 2023-04-20 12:55:21 --> Helper loaded: text_helper
INFO - 2023-04-20 12:55:21 --> Helper loaded: form_helper
INFO - 2023-04-20 12:55:21 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:55:21 --> Helper loaded: security_helper
INFO - 2023-04-20 12:55:21 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:55:21 --> Database Driver Class Initialized
INFO - 2023-04-20 12:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:55:21 --> Parser Class Initialized
INFO - 2023-04-20 12:55:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:55:21 --> Pagination Class Initialized
INFO - 2023-04-20 12:55:21 --> Form Validation Class Initialized
INFO - 2023-04-20 12:55:21 --> Controller Class Initialized
INFO - 2023-04-20 12:55:21 --> Model Class Initialized
DEBUG - 2023-04-20 12:55:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:55:21 --> Model Class Initialized
DEBUG - 2023-04-20 12:55:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:55:21 --> Model Class Initialized
INFO - 2023-04-20 12:55:21 --> Model Class Initialized
INFO - 2023-04-20 12:55:21 --> Model Class Initialized
INFO - 2023-04-20 12:55:21 --> Model Class Initialized
DEBUG - 2023-04-20 12:55:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 12:55:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:55:21 --> Model Class Initialized
INFO - 2023-04-20 12:55:21 --> Model Class Initialized
INFO - 2023-04-20 12:55:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-20 12:55:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:55:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 12:55:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 12:55:21 --> Model Class Initialized
INFO - 2023-04-20 12:55:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 12:55:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 12:55:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 12:55:21 --> Final output sent to browser
DEBUG - 2023-04-20 12:55:21 --> Total execution time: 0.0828
ERROR - 2023-04-20 12:55:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:55:30 --> Config Class Initialized
INFO - 2023-04-20 12:55:30 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:55:30 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:55:30 --> Utf8 Class Initialized
INFO - 2023-04-20 12:55:30 --> URI Class Initialized
INFO - 2023-04-20 12:55:30 --> Router Class Initialized
INFO - 2023-04-20 12:55:30 --> Output Class Initialized
INFO - 2023-04-20 12:55:30 --> Security Class Initialized
DEBUG - 2023-04-20 12:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:55:30 --> Input Class Initialized
INFO - 2023-04-20 12:55:30 --> Language Class Initialized
INFO - 2023-04-20 12:55:30 --> Loader Class Initialized
INFO - 2023-04-20 12:55:30 --> Helper loaded: url_helper
INFO - 2023-04-20 12:55:30 --> Helper loaded: file_helper
INFO - 2023-04-20 12:55:30 --> Helper loaded: html_helper
INFO - 2023-04-20 12:55:30 --> Helper loaded: text_helper
INFO - 2023-04-20 12:55:30 --> Helper loaded: form_helper
INFO - 2023-04-20 12:55:30 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:55:30 --> Helper loaded: security_helper
INFO - 2023-04-20 12:55:30 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:55:30 --> Database Driver Class Initialized
INFO - 2023-04-20 12:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:55:30 --> Parser Class Initialized
INFO - 2023-04-20 12:55:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:55:30 --> Pagination Class Initialized
INFO - 2023-04-20 12:55:30 --> Form Validation Class Initialized
INFO - 2023-04-20 12:55:30 --> Controller Class Initialized
INFO - 2023-04-20 12:55:30 --> Model Class Initialized
DEBUG - 2023-04-20 12:55:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 12:55:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:55:30 --> Model Class Initialized
INFO - 2023-04-20 12:55:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-04-20 12:55:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:55:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 12:55:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 12:55:30 --> Model Class Initialized
INFO - 2023-04-20 12:55:30 --> Model Class Initialized
INFO - 2023-04-20 12:55:30 --> Model Class Initialized
INFO - 2023-04-20 12:55:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 12:55:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 12:55:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 12:55:30 --> Final output sent to browser
DEBUG - 2023-04-20 12:55:30 --> Total execution time: 0.0639
ERROR - 2023-04-20 12:55:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:55:31 --> Config Class Initialized
INFO - 2023-04-20 12:55:31 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:55:31 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:55:31 --> Utf8 Class Initialized
INFO - 2023-04-20 12:55:31 --> URI Class Initialized
INFO - 2023-04-20 12:55:31 --> Router Class Initialized
INFO - 2023-04-20 12:55:31 --> Output Class Initialized
INFO - 2023-04-20 12:55:31 --> Security Class Initialized
DEBUG - 2023-04-20 12:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:55:31 --> Input Class Initialized
INFO - 2023-04-20 12:55:31 --> Language Class Initialized
INFO - 2023-04-20 12:55:31 --> Loader Class Initialized
INFO - 2023-04-20 12:55:31 --> Helper loaded: url_helper
INFO - 2023-04-20 12:55:31 --> Helper loaded: file_helper
INFO - 2023-04-20 12:55:31 --> Helper loaded: html_helper
INFO - 2023-04-20 12:55:31 --> Helper loaded: text_helper
INFO - 2023-04-20 12:55:31 --> Helper loaded: form_helper
INFO - 2023-04-20 12:55:31 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:55:31 --> Helper loaded: security_helper
INFO - 2023-04-20 12:55:31 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:55:31 --> Database Driver Class Initialized
INFO - 2023-04-20 12:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:55:31 --> Parser Class Initialized
INFO - 2023-04-20 12:55:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:55:31 --> Pagination Class Initialized
INFO - 2023-04-20 12:55:31 --> Form Validation Class Initialized
INFO - 2023-04-20 12:55:31 --> Controller Class Initialized
INFO - 2023-04-20 12:55:31 --> Model Class Initialized
DEBUG - 2023-04-20 12:55:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 12:55:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:55:31 --> Model Class Initialized
INFO - 2023-04-20 12:55:31 --> Final output sent to browser
DEBUG - 2023-04-20 12:55:31 --> Total execution time: 0.0192
ERROR - 2023-04-20 12:56:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:56:33 --> Config Class Initialized
INFO - 2023-04-20 12:56:33 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:56:33 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:56:33 --> Utf8 Class Initialized
INFO - 2023-04-20 12:56:33 --> URI Class Initialized
INFO - 2023-04-20 12:56:33 --> Router Class Initialized
INFO - 2023-04-20 12:56:33 --> Output Class Initialized
INFO - 2023-04-20 12:56:33 --> Security Class Initialized
DEBUG - 2023-04-20 12:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:56:33 --> Input Class Initialized
INFO - 2023-04-20 12:56:33 --> Language Class Initialized
INFO - 2023-04-20 12:56:33 --> Loader Class Initialized
INFO - 2023-04-20 12:56:33 --> Helper loaded: url_helper
INFO - 2023-04-20 12:56:33 --> Helper loaded: file_helper
INFO - 2023-04-20 12:56:33 --> Helper loaded: html_helper
INFO - 2023-04-20 12:56:33 --> Helper loaded: text_helper
INFO - 2023-04-20 12:56:33 --> Helper loaded: form_helper
INFO - 2023-04-20 12:56:33 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:56:33 --> Helper loaded: security_helper
INFO - 2023-04-20 12:56:33 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:56:33 --> Database Driver Class Initialized
INFO - 2023-04-20 12:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:56:33 --> Parser Class Initialized
INFO - 2023-04-20 12:56:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:56:33 --> Pagination Class Initialized
INFO - 2023-04-20 12:56:33 --> Form Validation Class Initialized
INFO - 2023-04-20 12:56:33 --> Controller Class Initialized
INFO - 2023-04-20 12:56:33 --> Model Class Initialized
DEBUG - 2023-04-20 12:56:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 12:56:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:56:33 --> Model Class Initialized
INFO - 2023-04-20 12:56:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-04-20 12:56:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:56:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 12:56:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 12:56:33 --> Model Class Initialized
INFO - 2023-04-20 12:56:33 --> Model Class Initialized
INFO - 2023-04-20 12:56:33 --> Model Class Initialized
INFO - 2023-04-20 12:56:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 12:56:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 12:56:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 12:56:33 --> Final output sent to browser
DEBUG - 2023-04-20 12:56:33 --> Total execution time: 0.1388
ERROR - 2023-04-20 12:56:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:56:34 --> Config Class Initialized
INFO - 2023-04-20 12:56:34 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:56:34 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:56:34 --> Utf8 Class Initialized
INFO - 2023-04-20 12:56:34 --> URI Class Initialized
INFO - 2023-04-20 12:56:34 --> Router Class Initialized
INFO - 2023-04-20 12:56:34 --> Output Class Initialized
INFO - 2023-04-20 12:56:34 --> Security Class Initialized
DEBUG - 2023-04-20 12:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:56:34 --> Input Class Initialized
INFO - 2023-04-20 12:56:34 --> Language Class Initialized
INFO - 2023-04-20 12:56:34 --> Loader Class Initialized
INFO - 2023-04-20 12:56:34 --> Helper loaded: url_helper
INFO - 2023-04-20 12:56:34 --> Helper loaded: file_helper
INFO - 2023-04-20 12:56:34 --> Helper loaded: html_helper
INFO - 2023-04-20 12:56:34 --> Helper loaded: text_helper
INFO - 2023-04-20 12:56:34 --> Helper loaded: form_helper
INFO - 2023-04-20 12:56:34 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:56:34 --> Helper loaded: security_helper
INFO - 2023-04-20 12:56:34 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:56:34 --> Database Driver Class Initialized
INFO - 2023-04-20 12:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:56:34 --> Parser Class Initialized
INFO - 2023-04-20 12:56:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:56:34 --> Pagination Class Initialized
INFO - 2023-04-20 12:56:34 --> Form Validation Class Initialized
INFO - 2023-04-20 12:56:34 --> Controller Class Initialized
INFO - 2023-04-20 12:56:34 --> Model Class Initialized
DEBUG - 2023-04-20 12:56:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 12:56:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:56:34 --> Model Class Initialized
INFO - 2023-04-20 12:56:34 --> Final output sent to browser
DEBUG - 2023-04-20 12:56:34 --> Total execution time: 0.0200
ERROR - 2023-04-20 12:56:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:56:42 --> Config Class Initialized
INFO - 2023-04-20 12:56:42 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:56:42 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:56:42 --> Utf8 Class Initialized
INFO - 2023-04-20 12:56:42 --> URI Class Initialized
INFO - 2023-04-20 12:56:42 --> Router Class Initialized
INFO - 2023-04-20 12:56:42 --> Output Class Initialized
INFO - 2023-04-20 12:56:42 --> Security Class Initialized
DEBUG - 2023-04-20 12:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:56:42 --> Input Class Initialized
INFO - 2023-04-20 12:56:42 --> Language Class Initialized
INFO - 2023-04-20 12:56:42 --> Loader Class Initialized
INFO - 2023-04-20 12:56:42 --> Helper loaded: url_helper
INFO - 2023-04-20 12:56:42 --> Helper loaded: file_helper
INFO - 2023-04-20 12:56:42 --> Helper loaded: html_helper
INFO - 2023-04-20 12:56:42 --> Helper loaded: text_helper
INFO - 2023-04-20 12:56:42 --> Helper loaded: form_helper
INFO - 2023-04-20 12:56:42 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:56:42 --> Helper loaded: security_helper
INFO - 2023-04-20 12:56:42 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:56:42 --> Database Driver Class Initialized
INFO - 2023-04-20 12:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:56:42 --> Parser Class Initialized
INFO - 2023-04-20 12:56:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:56:42 --> Pagination Class Initialized
INFO - 2023-04-20 12:56:42 --> Form Validation Class Initialized
INFO - 2023-04-20 12:56:42 --> Controller Class Initialized
INFO - 2023-04-20 12:56:42 --> Model Class Initialized
DEBUG - 2023-04-20 12:56:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 12:56:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:56:42 --> Model Class Initialized
INFO - 2023-04-20 12:56:42 --> Final output sent to browser
DEBUG - 2023-04-20 12:56:42 --> Total execution time: 0.0256
ERROR - 2023-04-20 12:56:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 12:56:45 --> Config Class Initialized
INFO - 2023-04-20 12:56:45 --> Hooks Class Initialized
DEBUG - 2023-04-20 12:56:45 --> UTF-8 Support Enabled
INFO - 2023-04-20 12:56:45 --> Utf8 Class Initialized
INFO - 2023-04-20 12:56:45 --> URI Class Initialized
INFO - 2023-04-20 12:56:45 --> Router Class Initialized
INFO - 2023-04-20 12:56:45 --> Output Class Initialized
INFO - 2023-04-20 12:56:45 --> Security Class Initialized
DEBUG - 2023-04-20 12:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 12:56:45 --> Input Class Initialized
INFO - 2023-04-20 12:56:45 --> Language Class Initialized
INFO - 2023-04-20 12:56:45 --> Loader Class Initialized
INFO - 2023-04-20 12:56:45 --> Helper loaded: url_helper
INFO - 2023-04-20 12:56:45 --> Helper loaded: file_helper
INFO - 2023-04-20 12:56:45 --> Helper loaded: html_helper
INFO - 2023-04-20 12:56:45 --> Helper loaded: text_helper
INFO - 2023-04-20 12:56:45 --> Helper loaded: form_helper
INFO - 2023-04-20 12:56:45 --> Helper loaded: lang_helper
INFO - 2023-04-20 12:56:45 --> Helper loaded: security_helper
INFO - 2023-04-20 12:56:45 --> Helper loaded: cookie_helper
INFO - 2023-04-20 12:56:45 --> Database Driver Class Initialized
INFO - 2023-04-20 12:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 12:56:45 --> Parser Class Initialized
INFO - 2023-04-20 12:56:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 12:56:45 --> Pagination Class Initialized
INFO - 2023-04-20 12:56:45 --> Form Validation Class Initialized
INFO - 2023-04-20 12:56:45 --> Controller Class Initialized
INFO - 2023-04-20 12:56:45 --> Model Class Initialized
DEBUG - 2023-04-20 12:56:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 12:56:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 12:56:45 --> Model Class Initialized
INFO - 2023-04-20 12:56:45 --> Final output sent to browser
DEBUG - 2023-04-20 12:56:45 --> Total execution time: 0.0199
ERROR - 2023-04-20 13:22:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 13:22:39 --> Config Class Initialized
INFO - 2023-04-20 13:22:39 --> Hooks Class Initialized
DEBUG - 2023-04-20 13:22:39 --> UTF-8 Support Enabled
INFO - 2023-04-20 13:22:39 --> Utf8 Class Initialized
INFO - 2023-04-20 13:22:39 --> URI Class Initialized
DEBUG - 2023-04-20 13:22:39 --> No URI present. Default controller set.
INFO - 2023-04-20 13:22:39 --> Router Class Initialized
INFO - 2023-04-20 13:22:39 --> Output Class Initialized
INFO - 2023-04-20 13:22:39 --> Security Class Initialized
DEBUG - 2023-04-20 13:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 13:22:39 --> Input Class Initialized
INFO - 2023-04-20 13:22:39 --> Language Class Initialized
INFO - 2023-04-20 13:22:39 --> Loader Class Initialized
INFO - 2023-04-20 13:22:39 --> Helper loaded: url_helper
INFO - 2023-04-20 13:22:39 --> Helper loaded: file_helper
INFO - 2023-04-20 13:22:39 --> Helper loaded: html_helper
INFO - 2023-04-20 13:22:39 --> Helper loaded: text_helper
INFO - 2023-04-20 13:22:39 --> Helper loaded: form_helper
INFO - 2023-04-20 13:22:39 --> Helper loaded: lang_helper
INFO - 2023-04-20 13:22:39 --> Helper loaded: security_helper
INFO - 2023-04-20 13:22:39 --> Helper loaded: cookie_helper
INFO - 2023-04-20 13:22:39 --> Database Driver Class Initialized
INFO - 2023-04-20 13:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 13:22:39 --> Parser Class Initialized
INFO - 2023-04-20 13:22:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 13:22:39 --> Pagination Class Initialized
INFO - 2023-04-20 13:22:39 --> Form Validation Class Initialized
INFO - 2023-04-20 13:22:39 --> Controller Class Initialized
INFO - 2023-04-20 13:22:39 --> Model Class Initialized
DEBUG - 2023-04-20 13:22:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-20 13:22:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 13:22:40 --> Config Class Initialized
INFO - 2023-04-20 13:22:40 --> Hooks Class Initialized
DEBUG - 2023-04-20 13:22:40 --> UTF-8 Support Enabled
INFO - 2023-04-20 13:22:40 --> Utf8 Class Initialized
INFO - 2023-04-20 13:22:40 --> URI Class Initialized
INFO - 2023-04-20 13:22:40 --> Router Class Initialized
INFO - 2023-04-20 13:22:40 --> Output Class Initialized
INFO - 2023-04-20 13:22:40 --> Security Class Initialized
DEBUG - 2023-04-20 13:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 13:22:40 --> Input Class Initialized
INFO - 2023-04-20 13:22:40 --> Language Class Initialized
INFO - 2023-04-20 13:22:40 --> Loader Class Initialized
INFO - 2023-04-20 13:22:40 --> Helper loaded: url_helper
INFO - 2023-04-20 13:22:40 --> Helper loaded: file_helper
INFO - 2023-04-20 13:22:40 --> Helper loaded: html_helper
INFO - 2023-04-20 13:22:40 --> Helper loaded: text_helper
INFO - 2023-04-20 13:22:40 --> Helper loaded: form_helper
INFO - 2023-04-20 13:22:40 --> Helper loaded: lang_helper
INFO - 2023-04-20 13:22:40 --> Helper loaded: security_helper
INFO - 2023-04-20 13:22:40 --> Helper loaded: cookie_helper
INFO - 2023-04-20 13:22:40 --> Database Driver Class Initialized
INFO - 2023-04-20 13:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 13:22:40 --> Parser Class Initialized
INFO - 2023-04-20 13:22:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 13:22:40 --> Pagination Class Initialized
INFO - 2023-04-20 13:22:40 --> Form Validation Class Initialized
INFO - 2023-04-20 13:22:40 --> Controller Class Initialized
INFO - 2023-04-20 13:22:40 --> Model Class Initialized
DEBUG - 2023-04-20 13:22:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 13:22:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-20 13:22:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 13:22:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 13:22:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 13:22:40 --> Model Class Initialized
INFO - 2023-04-20 13:22:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 13:22:40 --> Final output sent to browser
DEBUG - 2023-04-20 13:22:40 --> Total execution time: 0.0342
ERROR - 2023-04-20 14:17:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 14:17:41 --> Config Class Initialized
INFO - 2023-04-20 14:17:41 --> Hooks Class Initialized
DEBUG - 2023-04-20 14:17:41 --> UTF-8 Support Enabled
INFO - 2023-04-20 14:17:41 --> Utf8 Class Initialized
INFO - 2023-04-20 14:17:41 --> URI Class Initialized
DEBUG - 2023-04-20 14:17:41 --> No URI present. Default controller set.
INFO - 2023-04-20 14:17:41 --> Router Class Initialized
INFO - 2023-04-20 14:17:41 --> Output Class Initialized
INFO - 2023-04-20 14:17:41 --> Security Class Initialized
DEBUG - 2023-04-20 14:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 14:17:41 --> Input Class Initialized
INFO - 2023-04-20 14:17:41 --> Language Class Initialized
INFO - 2023-04-20 14:17:41 --> Loader Class Initialized
INFO - 2023-04-20 14:17:41 --> Helper loaded: url_helper
INFO - 2023-04-20 14:17:41 --> Helper loaded: file_helper
INFO - 2023-04-20 14:17:41 --> Helper loaded: html_helper
INFO - 2023-04-20 14:17:41 --> Helper loaded: text_helper
INFO - 2023-04-20 14:17:41 --> Helper loaded: form_helper
INFO - 2023-04-20 14:17:41 --> Helper loaded: lang_helper
INFO - 2023-04-20 14:17:41 --> Helper loaded: security_helper
INFO - 2023-04-20 14:17:41 --> Helper loaded: cookie_helper
INFO - 2023-04-20 14:17:41 --> Database Driver Class Initialized
INFO - 2023-04-20 14:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 14:17:41 --> Parser Class Initialized
INFO - 2023-04-20 14:17:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 14:17:41 --> Pagination Class Initialized
INFO - 2023-04-20 14:17:41 --> Form Validation Class Initialized
INFO - 2023-04-20 14:17:41 --> Controller Class Initialized
INFO - 2023-04-20 14:17:41 --> Model Class Initialized
DEBUG - 2023-04-20 14:17:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-20 15:11:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 15:11:57 --> Config Class Initialized
INFO - 2023-04-20 15:11:57 --> Hooks Class Initialized
DEBUG - 2023-04-20 15:11:57 --> UTF-8 Support Enabled
INFO - 2023-04-20 15:11:57 --> Utf8 Class Initialized
INFO - 2023-04-20 15:11:57 --> URI Class Initialized
DEBUG - 2023-04-20 15:11:57 --> No URI present. Default controller set.
INFO - 2023-04-20 15:11:57 --> Router Class Initialized
INFO - 2023-04-20 15:11:57 --> Output Class Initialized
INFO - 2023-04-20 15:11:57 --> Security Class Initialized
DEBUG - 2023-04-20 15:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 15:11:57 --> Input Class Initialized
INFO - 2023-04-20 15:11:57 --> Language Class Initialized
INFO - 2023-04-20 15:11:57 --> Loader Class Initialized
INFO - 2023-04-20 15:11:57 --> Helper loaded: url_helper
INFO - 2023-04-20 15:11:57 --> Helper loaded: file_helper
INFO - 2023-04-20 15:11:57 --> Helper loaded: html_helper
INFO - 2023-04-20 15:11:57 --> Helper loaded: text_helper
INFO - 2023-04-20 15:11:57 --> Helper loaded: form_helper
INFO - 2023-04-20 15:11:57 --> Helper loaded: lang_helper
INFO - 2023-04-20 15:11:57 --> Helper loaded: security_helper
INFO - 2023-04-20 15:11:57 --> Helper loaded: cookie_helper
INFO - 2023-04-20 15:11:57 --> Database Driver Class Initialized
INFO - 2023-04-20 15:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 15:11:57 --> Parser Class Initialized
INFO - 2023-04-20 15:11:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 15:11:57 --> Pagination Class Initialized
INFO - 2023-04-20 15:11:57 --> Form Validation Class Initialized
INFO - 2023-04-20 15:11:57 --> Controller Class Initialized
INFO - 2023-04-20 15:11:57 --> Model Class Initialized
DEBUG - 2023-04-20 15:11:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-20 15:11:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 15:11:58 --> Config Class Initialized
INFO - 2023-04-20 15:11:58 --> Hooks Class Initialized
DEBUG - 2023-04-20 15:11:58 --> UTF-8 Support Enabled
INFO - 2023-04-20 15:11:58 --> Utf8 Class Initialized
INFO - 2023-04-20 15:11:58 --> URI Class Initialized
INFO - 2023-04-20 15:11:58 --> Router Class Initialized
INFO - 2023-04-20 15:11:58 --> Output Class Initialized
INFO - 2023-04-20 15:11:58 --> Security Class Initialized
DEBUG - 2023-04-20 15:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 15:11:58 --> Input Class Initialized
INFO - 2023-04-20 15:11:58 --> Language Class Initialized
INFO - 2023-04-20 15:11:58 --> Loader Class Initialized
INFO - 2023-04-20 15:11:58 --> Helper loaded: url_helper
INFO - 2023-04-20 15:11:58 --> Helper loaded: file_helper
INFO - 2023-04-20 15:11:58 --> Helper loaded: html_helper
INFO - 2023-04-20 15:11:58 --> Helper loaded: text_helper
INFO - 2023-04-20 15:11:58 --> Helper loaded: form_helper
INFO - 2023-04-20 15:11:58 --> Helper loaded: lang_helper
INFO - 2023-04-20 15:11:58 --> Helper loaded: security_helper
INFO - 2023-04-20 15:11:58 --> Helper loaded: cookie_helper
INFO - 2023-04-20 15:11:58 --> Database Driver Class Initialized
INFO - 2023-04-20 15:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 15:11:58 --> Parser Class Initialized
INFO - 2023-04-20 15:11:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 15:11:58 --> Pagination Class Initialized
INFO - 2023-04-20 15:11:58 --> Form Validation Class Initialized
INFO - 2023-04-20 15:11:58 --> Controller Class Initialized
INFO - 2023-04-20 15:11:58 --> Model Class Initialized
DEBUG - 2023-04-20 15:11:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 15:11:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-20 15:11:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 15:11:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 15:11:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 15:11:58 --> Model Class Initialized
INFO - 2023-04-20 15:11:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 15:11:58 --> Final output sent to browser
DEBUG - 2023-04-20 15:11:58 --> Total execution time: 0.0370
ERROR - 2023-04-20 15:15:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 15:15:15 --> Config Class Initialized
INFO - 2023-04-20 15:15:15 --> Hooks Class Initialized
DEBUG - 2023-04-20 15:15:15 --> UTF-8 Support Enabled
INFO - 2023-04-20 15:15:15 --> Utf8 Class Initialized
INFO - 2023-04-20 15:15:15 --> URI Class Initialized
INFO - 2023-04-20 15:15:15 --> Router Class Initialized
INFO - 2023-04-20 15:15:15 --> Output Class Initialized
INFO - 2023-04-20 15:15:15 --> Security Class Initialized
DEBUG - 2023-04-20 15:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 15:15:15 --> Input Class Initialized
INFO - 2023-04-20 15:15:15 --> Language Class Initialized
INFO - 2023-04-20 15:15:15 --> Loader Class Initialized
INFO - 2023-04-20 15:15:15 --> Helper loaded: url_helper
INFO - 2023-04-20 15:15:15 --> Helper loaded: file_helper
INFO - 2023-04-20 15:15:15 --> Helper loaded: html_helper
INFO - 2023-04-20 15:15:15 --> Helper loaded: text_helper
INFO - 2023-04-20 15:15:15 --> Helper loaded: form_helper
INFO - 2023-04-20 15:15:15 --> Helper loaded: lang_helper
INFO - 2023-04-20 15:15:15 --> Helper loaded: security_helper
INFO - 2023-04-20 15:15:15 --> Helper loaded: cookie_helper
INFO - 2023-04-20 15:15:15 --> Database Driver Class Initialized
INFO - 2023-04-20 15:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 15:15:15 --> Parser Class Initialized
INFO - 2023-04-20 15:15:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 15:15:15 --> Pagination Class Initialized
INFO - 2023-04-20 15:15:15 --> Form Validation Class Initialized
INFO - 2023-04-20 15:15:15 --> Controller Class Initialized
INFO - 2023-04-20 15:15:15 --> Model Class Initialized
DEBUG - 2023-04-20 15:15:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 15:15:15 --> Model Class Initialized
INFO - 2023-04-20 15:15:15 --> Final output sent to browser
DEBUG - 2023-04-20 15:15:15 --> Total execution time: 0.0217
ERROR - 2023-04-20 15:15:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 15:15:16 --> Config Class Initialized
INFO - 2023-04-20 15:15:16 --> Hooks Class Initialized
DEBUG - 2023-04-20 15:15:16 --> UTF-8 Support Enabled
INFO - 2023-04-20 15:15:16 --> Utf8 Class Initialized
INFO - 2023-04-20 15:15:16 --> URI Class Initialized
DEBUG - 2023-04-20 15:15:16 --> No URI present. Default controller set.
INFO - 2023-04-20 15:15:16 --> Router Class Initialized
INFO - 2023-04-20 15:15:16 --> Output Class Initialized
INFO - 2023-04-20 15:15:16 --> Security Class Initialized
DEBUG - 2023-04-20 15:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 15:15:16 --> Input Class Initialized
INFO - 2023-04-20 15:15:16 --> Language Class Initialized
INFO - 2023-04-20 15:15:16 --> Loader Class Initialized
INFO - 2023-04-20 15:15:16 --> Helper loaded: url_helper
INFO - 2023-04-20 15:15:16 --> Helper loaded: file_helper
INFO - 2023-04-20 15:15:16 --> Helper loaded: html_helper
INFO - 2023-04-20 15:15:16 --> Helper loaded: text_helper
INFO - 2023-04-20 15:15:16 --> Helper loaded: form_helper
INFO - 2023-04-20 15:15:16 --> Helper loaded: lang_helper
INFO - 2023-04-20 15:15:16 --> Helper loaded: security_helper
INFO - 2023-04-20 15:15:16 --> Helper loaded: cookie_helper
INFO - 2023-04-20 15:15:16 --> Database Driver Class Initialized
INFO - 2023-04-20 15:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 15:15:16 --> Parser Class Initialized
INFO - 2023-04-20 15:15:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 15:15:16 --> Pagination Class Initialized
INFO - 2023-04-20 15:15:16 --> Form Validation Class Initialized
INFO - 2023-04-20 15:15:16 --> Controller Class Initialized
INFO - 2023-04-20 15:15:16 --> Model Class Initialized
DEBUG - 2023-04-20 15:15:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 15:15:16 --> Model Class Initialized
DEBUG - 2023-04-20 15:15:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 15:15:16 --> Model Class Initialized
INFO - 2023-04-20 15:15:16 --> Model Class Initialized
INFO - 2023-04-20 15:15:16 --> Model Class Initialized
INFO - 2023-04-20 15:15:16 --> Model Class Initialized
DEBUG - 2023-04-20 15:15:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 15:15:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 15:15:16 --> Model Class Initialized
INFO - 2023-04-20 15:15:16 --> Model Class Initialized
INFO - 2023-04-20 15:15:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-20 15:15:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 15:15:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 15:15:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 15:15:16 --> Model Class Initialized
INFO - 2023-04-20 15:15:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 15:15:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 15:15:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 15:15:16 --> Final output sent to browser
DEBUG - 2023-04-20 15:15:16 --> Total execution time: 0.0775
ERROR - 2023-04-20 15:15:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 15:15:34 --> Config Class Initialized
INFO - 2023-04-20 15:15:34 --> Hooks Class Initialized
DEBUG - 2023-04-20 15:15:34 --> UTF-8 Support Enabled
INFO - 2023-04-20 15:15:34 --> Utf8 Class Initialized
INFO - 2023-04-20 15:15:34 --> URI Class Initialized
INFO - 2023-04-20 15:15:34 --> Router Class Initialized
INFO - 2023-04-20 15:15:34 --> Output Class Initialized
INFO - 2023-04-20 15:15:34 --> Security Class Initialized
DEBUG - 2023-04-20 15:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 15:15:34 --> Input Class Initialized
INFO - 2023-04-20 15:15:34 --> Language Class Initialized
INFO - 2023-04-20 15:15:34 --> Loader Class Initialized
INFO - 2023-04-20 15:15:34 --> Helper loaded: url_helper
INFO - 2023-04-20 15:15:34 --> Helper loaded: file_helper
INFO - 2023-04-20 15:15:34 --> Helper loaded: html_helper
INFO - 2023-04-20 15:15:34 --> Helper loaded: text_helper
INFO - 2023-04-20 15:15:34 --> Helper loaded: form_helper
INFO - 2023-04-20 15:15:34 --> Helper loaded: lang_helper
INFO - 2023-04-20 15:15:34 --> Helper loaded: security_helper
INFO - 2023-04-20 15:15:34 --> Helper loaded: cookie_helper
INFO - 2023-04-20 15:15:34 --> Database Driver Class Initialized
INFO - 2023-04-20 15:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 15:15:34 --> Parser Class Initialized
INFO - 2023-04-20 15:15:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 15:15:34 --> Pagination Class Initialized
INFO - 2023-04-20 15:15:34 --> Form Validation Class Initialized
INFO - 2023-04-20 15:15:34 --> Controller Class Initialized
INFO - 2023-04-20 15:15:34 --> Model Class Initialized
DEBUG - 2023-04-20 15:15:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 15:15:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-20 15:15:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 15:15:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 15:15:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 15:15:34 --> Model Class Initialized
INFO - 2023-04-20 15:15:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 15:15:34 --> Final output sent to browser
DEBUG - 2023-04-20 15:15:34 --> Total execution time: 0.0314
ERROR - 2023-04-20 15:15:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 15:15:35 --> Config Class Initialized
INFO - 2023-04-20 15:15:35 --> Hooks Class Initialized
DEBUG - 2023-04-20 15:15:35 --> UTF-8 Support Enabled
INFO - 2023-04-20 15:15:35 --> Utf8 Class Initialized
INFO - 2023-04-20 15:15:35 --> URI Class Initialized
INFO - 2023-04-20 15:15:35 --> Router Class Initialized
INFO - 2023-04-20 15:15:35 --> Output Class Initialized
INFO - 2023-04-20 15:15:35 --> Security Class Initialized
DEBUG - 2023-04-20 15:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 15:15:35 --> Input Class Initialized
INFO - 2023-04-20 15:15:35 --> Language Class Initialized
INFO - 2023-04-20 15:15:35 --> Loader Class Initialized
INFO - 2023-04-20 15:15:35 --> Helper loaded: url_helper
INFO - 2023-04-20 15:15:35 --> Helper loaded: file_helper
INFO - 2023-04-20 15:15:35 --> Helper loaded: html_helper
INFO - 2023-04-20 15:15:35 --> Helper loaded: text_helper
INFO - 2023-04-20 15:15:35 --> Helper loaded: form_helper
INFO - 2023-04-20 15:15:35 --> Helper loaded: lang_helper
INFO - 2023-04-20 15:15:35 --> Helper loaded: security_helper
INFO - 2023-04-20 15:15:35 --> Helper loaded: cookie_helper
INFO - 2023-04-20 15:15:35 --> Database Driver Class Initialized
INFO - 2023-04-20 15:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 15:15:35 --> Parser Class Initialized
INFO - 2023-04-20 15:15:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 15:15:35 --> Pagination Class Initialized
INFO - 2023-04-20 15:15:35 --> Form Validation Class Initialized
INFO - 2023-04-20 15:15:35 --> Controller Class Initialized
INFO - 2023-04-20 15:15:35 --> Model Class Initialized
DEBUG - 2023-04-20 15:15:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 15:15:35 --> Model Class Initialized
DEBUG - 2023-04-20 15:15:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 15:15:35 --> Model Class Initialized
INFO - 2023-04-20 15:15:35 --> Model Class Initialized
INFO - 2023-04-20 15:15:35 --> Model Class Initialized
INFO - 2023-04-20 15:15:35 --> Model Class Initialized
DEBUG - 2023-04-20 15:15:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-20 15:15:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-20 15:15:35 --> Model Class Initialized
INFO - 2023-04-20 15:15:35 --> Model Class Initialized
INFO - 2023-04-20 15:15:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-20 15:15:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-20 15:15:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-20 15:15:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-20 15:15:35 --> Model Class Initialized
INFO - 2023-04-20 15:15:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-20 15:15:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-20 15:15:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-20 15:15:35 --> Final output sent to browser
DEBUG - 2023-04-20 15:15:35 --> Total execution time: 0.0865
ERROR - 2023-04-20 18:17:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-20 18:17:48 --> Config Class Initialized
INFO - 2023-04-20 18:17:48 --> Hooks Class Initialized
DEBUG - 2023-04-20 18:17:48 --> UTF-8 Support Enabled
INFO - 2023-04-20 18:17:48 --> Utf8 Class Initialized
INFO - 2023-04-20 18:17:48 --> URI Class Initialized
DEBUG - 2023-04-20 18:17:48 --> No URI present. Default controller set.
INFO - 2023-04-20 18:17:48 --> Router Class Initialized
INFO - 2023-04-20 18:17:48 --> Output Class Initialized
INFO - 2023-04-20 18:17:48 --> Security Class Initialized
DEBUG - 2023-04-20 18:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 18:17:48 --> Input Class Initialized
INFO - 2023-04-20 18:17:48 --> Language Class Initialized
INFO - 2023-04-20 18:17:48 --> Loader Class Initialized
INFO - 2023-04-20 18:17:48 --> Helper loaded: url_helper
INFO - 2023-04-20 18:17:48 --> Helper loaded: file_helper
INFO - 2023-04-20 18:17:48 --> Helper loaded: html_helper
INFO - 2023-04-20 18:17:48 --> Helper loaded: text_helper
INFO - 2023-04-20 18:17:48 --> Helper loaded: form_helper
INFO - 2023-04-20 18:17:48 --> Helper loaded: lang_helper
INFO - 2023-04-20 18:17:48 --> Helper loaded: security_helper
INFO - 2023-04-20 18:17:48 --> Helper loaded: cookie_helper
INFO - 2023-04-20 18:17:48 --> Database Driver Class Initialized
INFO - 2023-04-20 18:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-20 18:17:48 --> Parser Class Initialized
INFO - 2023-04-20 18:17:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-20 18:17:48 --> Pagination Class Initialized
INFO - 2023-04-20 18:17:48 --> Form Validation Class Initialized
INFO - 2023-04-20 18:17:48 --> Controller Class Initialized
INFO - 2023-04-20 18:17:48 --> Model Class Initialized
DEBUG - 2023-04-20 18:17:48 --> Session class already loaded. Second attempt ignored.
