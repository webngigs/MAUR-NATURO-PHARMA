<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-01-20 01:16:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 01:16:33 --> Config Class Initialized
INFO - 2024-01-20 01:16:33 --> Hooks Class Initialized
DEBUG - 2024-01-20 01:16:33 --> UTF-8 Support Enabled
INFO - 2024-01-20 01:16:33 --> Utf8 Class Initialized
INFO - 2024-01-20 01:16:33 --> URI Class Initialized
DEBUG - 2024-01-20 01:16:33 --> No URI present. Default controller set.
INFO - 2024-01-20 01:16:33 --> Router Class Initialized
INFO - 2024-01-20 01:16:33 --> Output Class Initialized
INFO - 2024-01-20 01:16:33 --> Security Class Initialized
DEBUG - 2024-01-20 01:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 01:16:33 --> Input Class Initialized
INFO - 2024-01-20 01:16:33 --> Language Class Initialized
INFO - 2024-01-20 01:16:33 --> Loader Class Initialized
INFO - 2024-01-20 01:16:33 --> Helper loaded: url_helper
INFO - 2024-01-20 01:16:33 --> Helper loaded: file_helper
INFO - 2024-01-20 01:16:33 --> Helper loaded: html_helper
INFO - 2024-01-20 01:16:33 --> Helper loaded: text_helper
INFO - 2024-01-20 01:16:33 --> Helper loaded: form_helper
INFO - 2024-01-20 01:16:33 --> Helper loaded: lang_helper
INFO - 2024-01-20 01:16:33 --> Helper loaded: security_helper
INFO - 2024-01-20 01:16:33 --> Helper loaded: cookie_helper
INFO - 2024-01-20 01:16:33 --> Database Driver Class Initialized
INFO - 2024-01-20 01:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 01:16:33 --> Parser Class Initialized
INFO - 2024-01-20 01:16:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 01:16:33 --> Pagination Class Initialized
INFO - 2024-01-20 01:16:33 --> Form Validation Class Initialized
INFO - 2024-01-20 01:16:33 --> Controller Class Initialized
INFO - 2024-01-20 01:16:33 --> Model Class Initialized
DEBUG - 2024-01-20 01:16:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-20 01:16:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 01:16:34 --> Config Class Initialized
INFO - 2024-01-20 01:16:34 --> Hooks Class Initialized
DEBUG - 2024-01-20 01:16:34 --> UTF-8 Support Enabled
INFO - 2024-01-20 01:16:34 --> Utf8 Class Initialized
INFO - 2024-01-20 01:16:34 --> URI Class Initialized
INFO - 2024-01-20 01:16:34 --> Router Class Initialized
INFO - 2024-01-20 01:16:34 --> Output Class Initialized
INFO - 2024-01-20 01:16:34 --> Security Class Initialized
DEBUG - 2024-01-20 01:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 01:16:34 --> Input Class Initialized
INFO - 2024-01-20 01:16:34 --> Language Class Initialized
INFO - 2024-01-20 01:16:34 --> Loader Class Initialized
INFO - 2024-01-20 01:16:34 --> Helper loaded: url_helper
INFO - 2024-01-20 01:16:34 --> Helper loaded: file_helper
INFO - 2024-01-20 01:16:34 --> Helper loaded: html_helper
INFO - 2024-01-20 01:16:34 --> Helper loaded: text_helper
INFO - 2024-01-20 01:16:34 --> Helper loaded: form_helper
INFO - 2024-01-20 01:16:34 --> Helper loaded: lang_helper
INFO - 2024-01-20 01:16:34 --> Helper loaded: security_helper
INFO - 2024-01-20 01:16:34 --> Helper loaded: cookie_helper
INFO - 2024-01-20 01:16:34 --> Database Driver Class Initialized
INFO - 2024-01-20 01:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 01:16:34 --> Parser Class Initialized
INFO - 2024-01-20 01:16:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 01:16:34 --> Pagination Class Initialized
INFO - 2024-01-20 01:16:34 --> Form Validation Class Initialized
INFO - 2024-01-20 01:16:34 --> Controller Class Initialized
INFO - 2024-01-20 01:16:34 --> Model Class Initialized
DEBUG - 2024-01-20 01:16:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:16:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-20 01:16:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:16:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 01:16:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 01:16:34 --> Model Class Initialized
INFO - 2024-01-20 01:16:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 01:16:34 --> Final output sent to browser
DEBUG - 2024-01-20 01:16:34 --> Total execution time: 0.0335
ERROR - 2024-01-20 01:17:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 01:17:18 --> Config Class Initialized
INFO - 2024-01-20 01:17:18 --> Hooks Class Initialized
DEBUG - 2024-01-20 01:17:18 --> UTF-8 Support Enabled
INFO - 2024-01-20 01:17:18 --> Utf8 Class Initialized
INFO - 2024-01-20 01:17:18 --> URI Class Initialized
DEBUG - 2024-01-20 01:17:18 --> No URI present. Default controller set.
INFO - 2024-01-20 01:17:18 --> Router Class Initialized
INFO - 2024-01-20 01:17:18 --> Output Class Initialized
INFO - 2024-01-20 01:17:18 --> Security Class Initialized
DEBUG - 2024-01-20 01:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 01:17:18 --> Input Class Initialized
INFO - 2024-01-20 01:17:18 --> Language Class Initialized
INFO - 2024-01-20 01:17:18 --> Loader Class Initialized
INFO - 2024-01-20 01:17:18 --> Helper loaded: url_helper
INFO - 2024-01-20 01:17:18 --> Helper loaded: file_helper
INFO - 2024-01-20 01:17:18 --> Helper loaded: html_helper
INFO - 2024-01-20 01:17:18 --> Helper loaded: text_helper
INFO - 2024-01-20 01:17:18 --> Helper loaded: form_helper
INFO - 2024-01-20 01:17:18 --> Helper loaded: lang_helper
INFO - 2024-01-20 01:17:18 --> Helper loaded: security_helper
INFO - 2024-01-20 01:17:18 --> Helper loaded: cookie_helper
INFO - 2024-01-20 01:17:18 --> Database Driver Class Initialized
INFO - 2024-01-20 01:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 01:17:18 --> Parser Class Initialized
INFO - 2024-01-20 01:17:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 01:17:18 --> Pagination Class Initialized
INFO - 2024-01-20 01:17:18 --> Form Validation Class Initialized
INFO - 2024-01-20 01:17:18 --> Controller Class Initialized
INFO - 2024-01-20 01:17:18 --> Model Class Initialized
DEBUG - 2024-01-20 01:17:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-20 01:17:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 01:17:18 --> Config Class Initialized
INFO - 2024-01-20 01:17:18 --> Hooks Class Initialized
DEBUG - 2024-01-20 01:17:18 --> UTF-8 Support Enabled
INFO - 2024-01-20 01:17:18 --> Utf8 Class Initialized
INFO - 2024-01-20 01:17:18 --> URI Class Initialized
INFO - 2024-01-20 01:17:18 --> Router Class Initialized
INFO - 2024-01-20 01:17:18 --> Output Class Initialized
INFO - 2024-01-20 01:17:18 --> Security Class Initialized
DEBUG - 2024-01-20 01:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 01:17:18 --> Input Class Initialized
INFO - 2024-01-20 01:17:18 --> Language Class Initialized
INFO - 2024-01-20 01:17:18 --> Loader Class Initialized
INFO - 2024-01-20 01:17:18 --> Helper loaded: url_helper
INFO - 2024-01-20 01:17:18 --> Helper loaded: file_helper
INFO - 2024-01-20 01:17:18 --> Helper loaded: html_helper
INFO - 2024-01-20 01:17:18 --> Helper loaded: text_helper
INFO - 2024-01-20 01:17:18 --> Helper loaded: form_helper
INFO - 2024-01-20 01:17:18 --> Helper loaded: lang_helper
INFO - 2024-01-20 01:17:18 --> Helper loaded: security_helper
INFO - 2024-01-20 01:17:18 --> Helper loaded: cookie_helper
INFO - 2024-01-20 01:17:18 --> Database Driver Class Initialized
INFO - 2024-01-20 01:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 01:17:18 --> Parser Class Initialized
INFO - 2024-01-20 01:17:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 01:17:18 --> Pagination Class Initialized
INFO - 2024-01-20 01:17:18 --> Form Validation Class Initialized
INFO - 2024-01-20 01:17:18 --> Controller Class Initialized
INFO - 2024-01-20 01:17:18 --> Model Class Initialized
DEBUG - 2024-01-20 01:17:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:17:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-20 01:17:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:17:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 01:17:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 01:17:18 --> Model Class Initialized
INFO - 2024-01-20 01:17:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 01:17:18 --> Final output sent to browser
DEBUG - 2024-01-20 01:17:18 --> Total execution time: 0.0293
ERROR - 2024-01-20 01:17:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 01:17:38 --> Config Class Initialized
INFO - 2024-01-20 01:17:38 --> Hooks Class Initialized
DEBUG - 2024-01-20 01:17:38 --> UTF-8 Support Enabled
INFO - 2024-01-20 01:17:38 --> Utf8 Class Initialized
INFO - 2024-01-20 01:17:38 --> URI Class Initialized
INFO - 2024-01-20 01:17:38 --> Router Class Initialized
INFO - 2024-01-20 01:17:38 --> Output Class Initialized
INFO - 2024-01-20 01:17:38 --> Security Class Initialized
DEBUG - 2024-01-20 01:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 01:17:38 --> Input Class Initialized
INFO - 2024-01-20 01:17:38 --> Language Class Initialized
INFO - 2024-01-20 01:17:38 --> Loader Class Initialized
INFO - 2024-01-20 01:17:38 --> Helper loaded: url_helper
INFO - 2024-01-20 01:17:38 --> Helper loaded: file_helper
INFO - 2024-01-20 01:17:38 --> Helper loaded: html_helper
INFO - 2024-01-20 01:17:38 --> Helper loaded: text_helper
INFO - 2024-01-20 01:17:38 --> Helper loaded: form_helper
INFO - 2024-01-20 01:17:38 --> Helper loaded: lang_helper
INFO - 2024-01-20 01:17:38 --> Helper loaded: security_helper
INFO - 2024-01-20 01:17:38 --> Helper loaded: cookie_helper
INFO - 2024-01-20 01:17:38 --> Database Driver Class Initialized
INFO - 2024-01-20 01:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 01:17:38 --> Parser Class Initialized
INFO - 2024-01-20 01:17:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 01:17:38 --> Pagination Class Initialized
INFO - 2024-01-20 01:17:38 --> Form Validation Class Initialized
INFO - 2024-01-20 01:17:38 --> Controller Class Initialized
INFO - 2024-01-20 01:17:38 --> Model Class Initialized
DEBUG - 2024-01-20 01:17:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:17:38 --> Model Class Initialized
INFO - 2024-01-20 01:17:39 --> Final output sent to browser
DEBUG - 2024-01-20 01:17:39 --> Total execution time: 0.3361
ERROR - 2024-01-20 01:17:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 01:17:39 --> Config Class Initialized
INFO - 2024-01-20 01:17:39 --> Hooks Class Initialized
DEBUG - 2024-01-20 01:17:39 --> UTF-8 Support Enabled
INFO - 2024-01-20 01:17:39 --> Utf8 Class Initialized
INFO - 2024-01-20 01:17:39 --> URI Class Initialized
DEBUG - 2024-01-20 01:17:39 --> No URI present. Default controller set.
INFO - 2024-01-20 01:17:39 --> Router Class Initialized
INFO - 2024-01-20 01:17:39 --> Output Class Initialized
INFO - 2024-01-20 01:17:39 --> Security Class Initialized
DEBUG - 2024-01-20 01:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 01:17:39 --> Input Class Initialized
INFO - 2024-01-20 01:17:39 --> Language Class Initialized
INFO - 2024-01-20 01:17:39 --> Loader Class Initialized
INFO - 2024-01-20 01:17:39 --> Helper loaded: url_helper
INFO - 2024-01-20 01:17:39 --> Helper loaded: file_helper
INFO - 2024-01-20 01:17:39 --> Helper loaded: html_helper
INFO - 2024-01-20 01:17:39 --> Helper loaded: text_helper
INFO - 2024-01-20 01:17:39 --> Helper loaded: form_helper
INFO - 2024-01-20 01:17:39 --> Helper loaded: lang_helper
INFO - 2024-01-20 01:17:39 --> Helper loaded: security_helper
INFO - 2024-01-20 01:17:39 --> Helper loaded: cookie_helper
INFO - 2024-01-20 01:17:39 --> Database Driver Class Initialized
INFO - 2024-01-20 01:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 01:17:39 --> Parser Class Initialized
INFO - 2024-01-20 01:17:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 01:17:39 --> Pagination Class Initialized
INFO - 2024-01-20 01:17:39 --> Form Validation Class Initialized
INFO - 2024-01-20 01:17:39 --> Controller Class Initialized
INFO - 2024-01-20 01:17:39 --> Model Class Initialized
DEBUG - 2024-01-20 01:17:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:17:39 --> Model Class Initialized
DEBUG - 2024-01-20 01:17:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:17:39 --> Model Class Initialized
INFO - 2024-01-20 01:17:39 --> Model Class Initialized
INFO - 2024-01-20 01:17:39 --> Model Class Initialized
INFO - 2024-01-20 01:17:39 --> Model Class Initialized
DEBUG - 2024-01-20 01:17:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 01:17:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:17:39 --> Model Class Initialized
INFO - 2024-01-20 01:17:39 --> Model Class Initialized
INFO - 2024-01-20 01:17:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-20 01:17:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:17:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 01:17:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 01:17:39 --> Model Class Initialized
INFO - 2024-01-20 01:17:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 01:17:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 01:17:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 01:17:39 --> Final output sent to browser
DEBUG - 2024-01-20 01:17:39 --> Total execution time: 0.2402
ERROR - 2024-01-20 01:17:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 01:17:59 --> Config Class Initialized
INFO - 2024-01-20 01:17:59 --> Hooks Class Initialized
DEBUG - 2024-01-20 01:17:59 --> UTF-8 Support Enabled
INFO - 2024-01-20 01:17:59 --> Utf8 Class Initialized
INFO - 2024-01-20 01:17:59 --> URI Class Initialized
INFO - 2024-01-20 01:17:59 --> Router Class Initialized
INFO - 2024-01-20 01:17:59 --> Output Class Initialized
INFO - 2024-01-20 01:17:59 --> Security Class Initialized
DEBUG - 2024-01-20 01:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 01:17:59 --> Input Class Initialized
INFO - 2024-01-20 01:17:59 --> Language Class Initialized
INFO - 2024-01-20 01:17:59 --> Loader Class Initialized
INFO - 2024-01-20 01:17:59 --> Helper loaded: url_helper
INFO - 2024-01-20 01:17:59 --> Helper loaded: file_helper
INFO - 2024-01-20 01:17:59 --> Helper loaded: html_helper
INFO - 2024-01-20 01:17:59 --> Helper loaded: text_helper
INFO - 2024-01-20 01:17:59 --> Helper loaded: form_helper
INFO - 2024-01-20 01:17:59 --> Helper loaded: lang_helper
INFO - 2024-01-20 01:17:59 --> Helper loaded: security_helper
INFO - 2024-01-20 01:17:59 --> Helper loaded: cookie_helper
INFO - 2024-01-20 01:17:59 --> Database Driver Class Initialized
INFO - 2024-01-20 01:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 01:17:59 --> Parser Class Initialized
INFO - 2024-01-20 01:17:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 01:17:59 --> Pagination Class Initialized
INFO - 2024-01-20 01:17:59 --> Form Validation Class Initialized
INFO - 2024-01-20 01:17:59 --> Controller Class Initialized
INFO - 2024-01-20 01:17:59 --> Model Class Initialized
DEBUG - 2024-01-20 01:17:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 01:17:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:17:59 --> Model Class Initialized
DEBUG - 2024-01-20 01:17:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:17:59 --> Model Class Initialized
INFO - 2024-01-20 01:17:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-20 01:17:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:17:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 01:17:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 01:17:59 --> Model Class Initialized
INFO - 2024-01-20 01:17:59 --> Model Class Initialized
INFO - 2024-01-20 01:17:59 --> Model Class Initialized
INFO - 2024-01-20 01:17:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 01:17:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 01:17:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 01:17:59 --> Final output sent to browser
DEBUG - 2024-01-20 01:17:59 --> Total execution time: 0.1518
ERROR - 2024-01-20 01:17:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 01:17:59 --> Config Class Initialized
INFO - 2024-01-20 01:17:59 --> Hooks Class Initialized
DEBUG - 2024-01-20 01:17:59 --> UTF-8 Support Enabled
INFO - 2024-01-20 01:17:59 --> Utf8 Class Initialized
INFO - 2024-01-20 01:17:59 --> URI Class Initialized
INFO - 2024-01-20 01:17:59 --> Router Class Initialized
INFO - 2024-01-20 01:17:59 --> Output Class Initialized
INFO - 2024-01-20 01:17:59 --> Security Class Initialized
DEBUG - 2024-01-20 01:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 01:17:59 --> Input Class Initialized
INFO - 2024-01-20 01:17:59 --> Language Class Initialized
INFO - 2024-01-20 01:17:59 --> Loader Class Initialized
INFO - 2024-01-20 01:17:59 --> Helper loaded: url_helper
INFO - 2024-01-20 01:17:59 --> Helper loaded: file_helper
INFO - 2024-01-20 01:17:59 --> Helper loaded: html_helper
INFO - 2024-01-20 01:17:59 --> Helper loaded: text_helper
INFO - 2024-01-20 01:17:59 --> Helper loaded: form_helper
INFO - 2024-01-20 01:17:59 --> Helper loaded: lang_helper
INFO - 2024-01-20 01:17:59 --> Helper loaded: security_helper
INFO - 2024-01-20 01:17:59 --> Helper loaded: cookie_helper
INFO - 2024-01-20 01:17:59 --> Database Driver Class Initialized
INFO - 2024-01-20 01:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 01:17:59 --> Parser Class Initialized
INFO - 2024-01-20 01:17:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 01:17:59 --> Pagination Class Initialized
INFO - 2024-01-20 01:17:59 --> Form Validation Class Initialized
INFO - 2024-01-20 01:17:59 --> Controller Class Initialized
INFO - 2024-01-20 01:17:59 --> Model Class Initialized
DEBUG - 2024-01-20 01:17:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 01:17:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:17:59 --> Model Class Initialized
DEBUG - 2024-01-20 01:17:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:17:59 --> Model Class Initialized
INFO - 2024-01-20 01:17:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-20 01:17:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:17:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 01:17:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 01:17:59 --> Model Class Initialized
INFO - 2024-01-20 01:17:59 --> Model Class Initialized
INFO - 2024-01-20 01:17:59 --> Model Class Initialized
INFO - 2024-01-20 01:17:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 01:17:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 01:17:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 01:17:59 --> Final output sent to browser
DEBUG - 2024-01-20 01:17:59 --> Total execution time: 0.1472
ERROR - 2024-01-20 01:18:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 01:18:00 --> Config Class Initialized
INFO - 2024-01-20 01:18:00 --> Hooks Class Initialized
DEBUG - 2024-01-20 01:18:00 --> UTF-8 Support Enabled
INFO - 2024-01-20 01:18:00 --> Utf8 Class Initialized
INFO - 2024-01-20 01:18:00 --> URI Class Initialized
INFO - 2024-01-20 01:18:00 --> Router Class Initialized
INFO - 2024-01-20 01:18:00 --> Output Class Initialized
INFO - 2024-01-20 01:18:00 --> Security Class Initialized
DEBUG - 2024-01-20 01:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 01:18:00 --> Input Class Initialized
INFO - 2024-01-20 01:18:00 --> Language Class Initialized
INFO - 2024-01-20 01:18:00 --> Loader Class Initialized
INFO - 2024-01-20 01:18:00 --> Helper loaded: url_helper
INFO - 2024-01-20 01:18:00 --> Helper loaded: file_helper
INFO - 2024-01-20 01:18:00 --> Helper loaded: html_helper
INFO - 2024-01-20 01:18:00 --> Helper loaded: text_helper
INFO - 2024-01-20 01:18:00 --> Helper loaded: form_helper
INFO - 2024-01-20 01:18:00 --> Helper loaded: lang_helper
INFO - 2024-01-20 01:18:00 --> Helper loaded: security_helper
INFO - 2024-01-20 01:18:00 --> Helper loaded: cookie_helper
INFO - 2024-01-20 01:18:00 --> Database Driver Class Initialized
INFO - 2024-01-20 01:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 01:18:00 --> Parser Class Initialized
INFO - 2024-01-20 01:18:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 01:18:00 --> Pagination Class Initialized
INFO - 2024-01-20 01:18:00 --> Form Validation Class Initialized
INFO - 2024-01-20 01:18:00 --> Controller Class Initialized
INFO - 2024-01-20 01:18:00 --> Model Class Initialized
DEBUG - 2024-01-20 01:18:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 01:18:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:18:00 --> Model Class Initialized
DEBUG - 2024-01-20 01:18:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:18:00 --> Model Class Initialized
INFO - 2024-01-20 01:18:00 --> Final output sent to browser
DEBUG - 2024-01-20 01:18:00 --> Total execution time: 0.0427
ERROR - 2024-01-20 01:18:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 01:18:04 --> Config Class Initialized
INFO - 2024-01-20 01:18:04 --> Hooks Class Initialized
DEBUG - 2024-01-20 01:18:04 --> UTF-8 Support Enabled
INFO - 2024-01-20 01:18:04 --> Utf8 Class Initialized
INFO - 2024-01-20 01:18:04 --> URI Class Initialized
INFO - 2024-01-20 01:18:04 --> Router Class Initialized
INFO - 2024-01-20 01:18:04 --> Output Class Initialized
INFO - 2024-01-20 01:18:04 --> Security Class Initialized
DEBUG - 2024-01-20 01:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 01:18:04 --> Input Class Initialized
INFO - 2024-01-20 01:18:04 --> Language Class Initialized
INFO - 2024-01-20 01:18:04 --> Loader Class Initialized
INFO - 2024-01-20 01:18:04 --> Helper loaded: url_helper
INFO - 2024-01-20 01:18:04 --> Helper loaded: file_helper
INFO - 2024-01-20 01:18:04 --> Helper loaded: html_helper
INFO - 2024-01-20 01:18:04 --> Helper loaded: text_helper
INFO - 2024-01-20 01:18:04 --> Helper loaded: form_helper
INFO - 2024-01-20 01:18:04 --> Helper loaded: lang_helper
INFO - 2024-01-20 01:18:04 --> Helper loaded: security_helper
INFO - 2024-01-20 01:18:04 --> Helper loaded: cookie_helper
INFO - 2024-01-20 01:18:04 --> Database Driver Class Initialized
INFO - 2024-01-20 01:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 01:18:04 --> Parser Class Initialized
INFO - 2024-01-20 01:18:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 01:18:04 --> Pagination Class Initialized
INFO - 2024-01-20 01:18:04 --> Form Validation Class Initialized
INFO - 2024-01-20 01:18:04 --> Controller Class Initialized
INFO - 2024-01-20 01:18:04 --> Model Class Initialized
DEBUG - 2024-01-20 01:18:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 01:18:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:18:04 --> Model Class Initialized
DEBUG - 2024-01-20 01:18:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:18:04 --> Model Class Initialized
INFO - 2024-01-20 01:18:04 --> Final output sent to browser
DEBUG - 2024-01-20 01:18:04 --> Total execution time: 0.1103
ERROR - 2024-01-20 01:19:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 01:19:09 --> Config Class Initialized
INFO - 2024-01-20 01:19:09 --> Hooks Class Initialized
DEBUG - 2024-01-20 01:19:09 --> UTF-8 Support Enabled
INFO - 2024-01-20 01:19:09 --> Utf8 Class Initialized
INFO - 2024-01-20 01:19:09 --> URI Class Initialized
INFO - 2024-01-20 01:19:09 --> Router Class Initialized
INFO - 2024-01-20 01:19:09 --> Output Class Initialized
INFO - 2024-01-20 01:19:09 --> Security Class Initialized
DEBUG - 2024-01-20 01:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 01:19:09 --> Input Class Initialized
INFO - 2024-01-20 01:19:09 --> Language Class Initialized
INFO - 2024-01-20 01:19:09 --> Loader Class Initialized
INFO - 2024-01-20 01:19:09 --> Helper loaded: url_helper
INFO - 2024-01-20 01:19:09 --> Helper loaded: file_helper
INFO - 2024-01-20 01:19:09 --> Helper loaded: html_helper
INFO - 2024-01-20 01:19:09 --> Helper loaded: text_helper
INFO - 2024-01-20 01:19:09 --> Helper loaded: form_helper
INFO - 2024-01-20 01:19:09 --> Helper loaded: lang_helper
INFO - 2024-01-20 01:19:09 --> Helper loaded: security_helper
INFO - 2024-01-20 01:19:09 --> Helper loaded: cookie_helper
INFO - 2024-01-20 01:19:09 --> Database Driver Class Initialized
INFO - 2024-01-20 01:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 01:19:09 --> Parser Class Initialized
INFO - 2024-01-20 01:19:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 01:19:09 --> Pagination Class Initialized
INFO - 2024-01-20 01:19:09 --> Form Validation Class Initialized
INFO - 2024-01-20 01:19:09 --> Controller Class Initialized
INFO - 2024-01-20 01:19:09 --> Model Class Initialized
DEBUG - 2024-01-20 01:19:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 01:19:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:19:09 --> Model Class Initialized
DEBUG - 2024-01-20 01:19:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:19:09 --> Model Class Initialized
DEBUG - 2024-01-20 01:19:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:19:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-01-20 01:19:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:19:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 01:19:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 01:19:09 --> Model Class Initialized
INFO - 2024-01-20 01:19:09 --> Model Class Initialized
INFO - 2024-01-20 01:19:09 --> Model Class Initialized
INFO - 2024-01-20 01:19:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 01:19:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 01:19:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 01:19:09 --> Final output sent to browser
DEBUG - 2024-01-20 01:19:09 --> Total execution time: 0.1607
ERROR - 2024-01-20 01:19:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 01:19:23 --> Config Class Initialized
INFO - 2024-01-20 01:19:23 --> Hooks Class Initialized
DEBUG - 2024-01-20 01:19:23 --> UTF-8 Support Enabled
INFO - 2024-01-20 01:19:23 --> Utf8 Class Initialized
INFO - 2024-01-20 01:19:23 --> URI Class Initialized
INFO - 2024-01-20 01:19:23 --> Router Class Initialized
INFO - 2024-01-20 01:19:23 --> Output Class Initialized
INFO - 2024-01-20 01:19:23 --> Security Class Initialized
DEBUG - 2024-01-20 01:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 01:19:23 --> Input Class Initialized
INFO - 2024-01-20 01:19:23 --> Language Class Initialized
INFO - 2024-01-20 01:19:23 --> Loader Class Initialized
INFO - 2024-01-20 01:19:23 --> Helper loaded: url_helper
INFO - 2024-01-20 01:19:23 --> Helper loaded: file_helper
INFO - 2024-01-20 01:19:23 --> Helper loaded: html_helper
INFO - 2024-01-20 01:19:23 --> Helper loaded: text_helper
INFO - 2024-01-20 01:19:23 --> Helper loaded: form_helper
INFO - 2024-01-20 01:19:23 --> Helper loaded: lang_helper
INFO - 2024-01-20 01:19:23 --> Helper loaded: security_helper
INFO - 2024-01-20 01:19:23 --> Helper loaded: cookie_helper
INFO - 2024-01-20 01:19:23 --> Database Driver Class Initialized
INFO - 2024-01-20 01:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 01:19:23 --> Parser Class Initialized
INFO - 2024-01-20 01:19:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 01:19:23 --> Pagination Class Initialized
INFO - 2024-01-20 01:19:23 --> Form Validation Class Initialized
INFO - 2024-01-20 01:19:23 --> Controller Class Initialized
INFO - 2024-01-20 01:19:23 --> Model Class Initialized
DEBUG - 2024-01-20 01:19:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 01:19:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:19:23 --> Model Class Initialized
DEBUG - 2024-01-20 01:19:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:19:23 --> Model Class Initialized
INFO - 2024-01-20 01:19:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-20 01:19:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:19:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 01:19:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 01:19:23 --> Model Class Initialized
INFO - 2024-01-20 01:19:23 --> Model Class Initialized
INFO - 2024-01-20 01:19:23 --> Model Class Initialized
INFO - 2024-01-20 01:19:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 01:19:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 01:19:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 01:19:23 --> Final output sent to browser
DEBUG - 2024-01-20 01:19:23 --> Total execution time: 0.1518
ERROR - 2024-01-20 01:19:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 01:19:25 --> Config Class Initialized
INFO - 2024-01-20 01:19:25 --> Hooks Class Initialized
DEBUG - 2024-01-20 01:19:25 --> UTF-8 Support Enabled
INFO - 2024-01-20 01:19:25 --> Utf8 Class Initialized
INFO - 2024-01-20 01:19:25 --> URI Class Initialized
INFO - 2024-01-20 01:19:25 --> Router Class Initialized
INFO - 2024-01-20 01:19:25 --> Output Class Initialized
INFO - 2024-01-20 01:19:25 --> Security Class Initialized
DEBUG - 2024-01-20 01:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 01:19:25 --> Input Class Initialized
INFO - 2024-01-20 01:19:25 --> Language Class Initialized
INFO - 2024-01-20 01:19:25 --> Loader Class Initialized
INFO - 2024-01-20 01:19:25 --> Helper loaded: url_helper
INFO - 2024-01-20 01:19:25 --> Helper loaded: file_helper
INFO - 2024-01-20 01:19:25 --> Helper loaded: html_helper
INFO - 2024-01-20 01:19:25 --> Helper loaded: text_helper
INFO - 2024-01-20 01:19:25 --> Helper loaded: form_helper
INFO - 2024-01-20 01:19:25 --> Helper loaded: lang_helper
INFO - 2024-01-20 01:19:25 --> Helper loaded: security_helper
INFO - 2024-01-20 01:19:25 --> Helper loaded: cookie_helper
INFO - 2024-01-20 01:19:25 --> Database Driver Class Initialized
INFO - 2024-01-20 01:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 01:19:25 --> Parser Class Initialized
INFO - 2024-01-20 01:19:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 01:19:25 --> Pagination Class Initialized
INFO - 2024-01-20 01:19:25 --> Form Validation Class Initialized
INFO - 2024-01-20 01:19:25 --> Controller Class Initialized
INFO - 2024-01-20 01:19:25 --> Model Class Initialized
DEBUG - 2024-01-20 01:19:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 01:19:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:19:25 --> Model Class Initialized
DEBUG - 2024-01-20 01:19:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:19:25 --> Model Class Initialized
INFO - 2024-01-20 01:19:25 --> Final output sent to browser
DEBUG - 2024-01-20 01:19:25 --> Total execution time: 0.0411
ERROR - 2024-01-20 01:19:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 01:19:28 --> Config Class Initialized
INFO - 2024-01-20 01:19:28 --> Hooks Class Initialized
DEBUG - 2024-01-20 01:19:28 --> UTF-8 Support Enabled
INFO - 2024-01-20 01:19:28 --> Utf8 Class Initialized
INFO - 2024-01-20 01:19:28 --> URI Class Initialized
DEBUG - 2024-01-20 01:19:28 --> No URI present. Default controller set.
INFO - 2024-01-20 01:19:28 --> Router Class Initialized
INFO - 2024-01-20 01:19:28 --> Output Class Initialized
INFO - 2024-01-20 01:19:28 --> Security Class Initialized
DEBUG - 2024-01-20 01:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 01:19:28 --> Input Class Initialized
INFO - 2024-01-20 01:19:28 --> Language Class Initialized
INFO - 2024-01-20 01:19:28 --> Loader Class Initialized
INFO - 2024-01-20 01:19:28 --> Helper loaded: url_helper
INFO - 2024-01-20 01:19:28 --> Helper loaded: file_helper
INFO - 2024-01-20 01:19:28 --> Helper loaded: html_helper
INFO - 2024-01-20 01:19:28 --> Helper loaded: text_helper
INFO - 2024-01-20 01:19:28 --> Helper loaded: form_helper
INFO - 2024-01-20 01:19:28 --> Helper loaded: lang_helper
INFO - 2024-01-20 01:19:28 --> Helper loaded: security_helper
INFO - 2024-01-20 01:19:28 --> Helper loaded: cookie_helper
INFO - 2024-01-20 01:19:28 --> Database Driver Class Initialized
INFO - 2024-01-20 01:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 01:19:28 --> Parser Class Initialized
INFO - 2024-01-20 01:19:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 01:19:28 --> Pagination Class Initialized
INFO - 2024-01-20 01:19:28 --> Form Validation Class Initialized
INFO - 2024-01-20 01:19:28 --> Controller Class Initialized
INFO - 2024-01-20 01:19:28 --> Model Class Initialized
DEBUG - 2024-01-20 01:19:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:19:28 --> Model Class Initialized
DEBUG - 2024-01-20 01:19:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:19:28 --> Model Class Initialized
INFO - 2024-01-20 01:19:28 --> Model Class Initialized
INFO - 2024-01-20 01:19:28 --> Model Class Initialized
INFO - 2024-01-20 01:19:28 --> Model Class Initialized
DEBUG - 2024-01-20 01:19:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 01:19:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:19:28 --> Model Class Initialized
INFO - 2024-01-20 01:19:28 --> Model Class Initialized
INFO - 2024-01-20 01:19:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-20 01:19:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:19:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 01:19:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 01:19:28 --> Model Class Initialized
INFO - 2024-01-20 01:19:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 01:19:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 01:19:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 01:19:28 --> Final output sent to browser
DEBUG - 2024-01-20 01:19:28 --> Total execution time: 0.2272
ERROR - 2024-01-20 01:19:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 01:19:58 --> Config Class Initialized
INFO - 2024-01-20 01:19:58 --> Hooks Class Initialized
DEBUG - 2024-01-20 01:19:58 --> UTF-8 Support Enabled
INFO - 2024-01-20 01:19:58 --> Utf8 Class Initialized
INFO - 2024-01-20 01:19:58 --> URI Class Initialized
INFO - 2024-01-20 01:19:58 --> Router Class Initialized
INFO - 2024-01-20 01:19:58 --> Output Class Initialized
INFO - 2024-01-20 01:19:58 --> Security Class Initialized
DEBUG - 2024-01-20 01:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 01:19:58 --> Input Class Initialized
INFO - 2024-01-20 01:19:58 --> Language Class Initialized
INFO - 2024-01-20 01:19:58 --> Loader Class Initialized
INFO - 2024-01-20 01:19:58 --> Helper loaded: url_helper
INFO - 2024-01-20 01:19:58 --> Helper loaded: file_helper
INFO - 2024-01-20 01:19:58 --> Helper loaded: html_helper
INFO - 2024-01-20 01:19:58 --> Helper loaded: text_helper
INFO - 2024-01-20 01:19:58 --> Helper loaded: form_helper
INFO - 2024-01-20 01:19:58 --> Helper loaded: lang_helper
INFO - 2024-01-20 01:19:58 --> Helper loaded: security_helper
INFO - 2024-01-20 01:19:58 --> Helper loaded: cookie_helper
INFO - 2024-01-20 01:19:58 --> Database Driver Class Initialized
INFO - 2024-01-20 01:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 01:19:58 --> Parser Class Initialized
INFO - 2024-01-20 01:19:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 01:19:58 --> Pagination Class Initialized
INFO - 2024-01-20 01:19:58 --> Form Validation Class Initialized
INFO - 2024-01-20 01:19:58 --> Controller Class Initialized
INFO - 2024-01-20 01:19:58 --> Model Class Initialized
DEBUG - 2024-01-20 01:19:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:19:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-20 01:19:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:19:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 01:19:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 01:19:58 --> Model Class Initialized
INFO - 2024-01-20 01:19:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 01:19:58 --> Final output sent to browser
DEBUG - 2024-01-20 01:19:58 --> Total execution time: 0.0388
ERROR - 2024-01-20 01:19:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 01:19:59 --> Config Class Initialized
INFO - 2024-01-20 01:19:59 --> Hooks Class Initialized
DEBUG - 2024-01-20 01:19:59 --> UTF-8 Support Enabled
INFO - 2024-01-20 01:19:59 --> Utf8 Class Initialized
INFO - 2024-01-20 01:19:59 --> URI Class Initialized
INFO - 2024-01-20 01:19:59 --> Router Class Initialized
INFO - 2024-01-20 01:19:59 --> Output Class Initialized
INFO - 2024-01-20 01:19:59 --> Security Class Initialized
DEBUG - 2024-01-20 01:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 01:19:59 --> Input Class Initialized
INFO - 2024-01-20 01:19:59 --> Language Class Initialized
INFO - 2024-01-20 01:19:59 --> Loader Class Initialized
INFO - 2024-01-20 01:19:59 --> Helper loaded: url_helper
INFO - 2024-01-20 01:19:59 --> Helper loaded: file_helper
INFO - 2024-01-20 01:19:59 --> Helper loaded: html_helper
INFO - 2024-01-20 01:19:59 --> Helper loaded: text_helper
INFO - 2024-01-20 01:19:59 --> Helper loaded: form_helper
INFO - 2024-01-20 01:19:59 --> Helper loaded: lang_helper
INFO - 2024-01-20 01:19:59 --> Helper loaded: security_helper
INFO - 2024-01-20 01:19:59 --> Helper loaded: cookie_helper
INFO - 2024-01-20 01:19:59 --> Database Driver Class Initialized
INFO - 2024-01-20 01:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 01:19:59 --> Parser Class Initialized
INFO - 2024-01-20 01:19:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 01:19:59 --> Pagination Class Initialized
INFO - 2024-01-20 01:19:59 --> Form Validation Class Initialized
INFO - 2024-01-20 01:19:59 --> Controller Class Initialized
INFO - 2024-01-20 01:19:59 --> Model Class Initialized
DEBUG - 2024-01-20 01:19:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:19:59 --> Model Class Initialized
DEBUG - 2024-01-20 01:19:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:19:59 --> Model Class Initialized
INFO - 2024-01-20 01:19:59 --> Model Class Initialized
INFO - 2024-01-20 01:19:59 --> Model Class Initialized
INFO - 2024-01-20 01:19:59 --> Model Class Initialized
DEBUG - 2024-01-20 01:19:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 01:19:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:19:59 --> Model Class Initialized
INFO - 2024-01-20 01:19:59 --> Model Class Initialized
INFO - 2024-01-20 01:19:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-20 01:19:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:19:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 01:19:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 01:19:59 --> Model Class Initialized
INFO - 2024-01-20 01:19:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 01:19:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 01:19:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 01:19:59 --> Final output sent to browser
DEBUG - 2024-01-20 01:19:59 --> Total execution time: 0.2302
ERROR - 2024-01-20 01:29:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 01:29:50 --> Config Class Initialized
INFO - 2024-01-20 01:29:50 --> Hooks Class Initialized
DEBUG - 2024-01-20 01:29:50 --> UTF-8 Support Enabled
INFO - 2024-01-20 01:29:50 --> Utf8 Class Initialized
INFO - 2024-01-20 01:29:50 --> URI Class Initialized
DEBUG - 2024-01-20 01:29:50 --> No URI present. Default controller set.
INFO - 2024-01-20 01:29:50 --> Router Class Initialized
INFO - 2024-01-20 01:29:50 --> Output Class Initialized
INFO - 2024-01-20 01:29:50 --> Security Class Initialized
DEBUG - 2024-01-20 01:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 01:29:50 --> Input Class Initialized
INFO - 2024-01-20 01:29:50 --> Language Class Initialized
INFO - 2024-01-20 01:29:50 --> Loader Class Initialized
INFO - 2024-01-20 01:29:50 --> Helper loaded: url_helper
INFO - 2024-01-20 01:29:50 --> Helper loaded: file_helper
INFO - 2024-01-20 01:29:50 --> Helper loaded: html_helper
INFO - 2024-01-20 01:29:50 --> Helper loaded: text_helper
INFO - 2024-01-20 01:29:50 --> Helper loaded: form_helper
INFO - 2024-01-20 01:29:50 --> Helper loaded: lang_helper
INFO - 2024-01-20 01:29:50 --> Helper loaded: security_helper
INFO - 2024-01-20 01:29:50 --> Helper loaded: cookie_helper
INFO - 2024-01-20 01:29:50 --> Database Driver Class Initialized
INFO - 2024-01-20 01:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 01:29:50 --> Parser Class Initialized
INFO - 2024-01-20 01:29:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 01:29:50 --> Pagination Class Initialized
INFO - 2024-01-20 01:29:50 --> Form Validation Class Initialized
INFO - 2024-01-20 01:29:50 --> Controller Class Initialized
INFO - 2024-01-20 01:29:50 --> Model Class Initialized
DEBUG - 2024-01-20 01:29:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-20 01:29:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 01:29:51 --> Config Class Initialized
INFO - 2024-01-20 01:29:51 --> Hooks Class Initialized
DEBUG - 2024-01-20 01:29:51 --> UTF-8 Support Enabled
INFO - 2024-01-20 01:29:51 --> Utf8 Class Initialized
INFO - 2024-01-20 01:29:51 --> URI Class Initialized
INFO - 2024-01-20 01:29:51 --> Router Class Initialized
INFO - 2024-01-20 01:29:51 --> Output Class Initialized
INFO - 2024-01-20 01:29:51 --> Security Class Initialized
DEBUG - 2024-01-20 01:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 01:29:51 --> Input Class Initialized
INFO - 2024-01-20 01:29:51 --> Language Class Initialized
INFO - 2024-01-20 01:29:51 --> Loader Class Initialized
INFO - 2024-01-20 01:29:51 --> Helper loaded: url_helper
INFO - 2024-01-20 01:29:51 --> Helper loaded: file_helper
INFO - 2024-01-20 01:29:51 --> Helper loaded: html_helper
INFO - 2024-01-20 01:29:51 --> Helper loaded: text_helper
INFO - 2024-01-20 01:29:51 --> Helper loaded: form_helper
INFO - 2024-01-20 01:29:51 --> Helper loaded: lang_helper
INFO - 2024-01-20 01:29:51 --> Helper loaded: security_helper
INFO - 2024-01-20 01:29:51 --> Helper loaded: cookie_helper
INFO - 2024-01-20 01:29:51 --> Database Driver Class Initialized
INFO - 2024-01-20 01:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 01:29:51 --> Parser Class Initialized
INFO - 2024-01-20 01:29:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 01:29:51 --> Pagination Class Initialized
INFO - 2024-01-20 01:29:51 --> Form Validation Class Initialized
INFO - 2024-01-20 01:29:51 --> Controller Class Initialized
INFO - 2024-01-20 01:29:51 --> Model Class Initialized
DEBUG - 2024-01-20 01:29:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:29:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-20 01:29:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:29:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 01:29:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 01:29:51 --> Model Class Initialized
INFO - 2024-01-20 01:29:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 01:29:51 --> Final output sent to browser
DEBUG - 2024-01-20 01:29:51 --> Total execution time: 0.0334
ERROR - 2024-01-20 01:29:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 01:29:51 --> Config Class Initialized
INFO - 2024-01-20 01:29:51 --> Hooks Class Initialized
DEBUG - 2024-01-20 01:29:51 --> UTF-8 Support Enabled
INFO - 2024-01-20 01:29:51 --> Utf8 Class Initialized
INFO - 2024-01-20 01:29:51 --> URI Class Initialized
DEBUG - 2024-01-20 01:29:51 --> No URI present. Default controller set.
INFO - 2024-01-20 01:29:51 --> Router Class Initialized
INFO - 2024-01-20 01:29:51 --> Output Class Initialized
INFO - 2024-01-20 01:29:51 --> Security Class Initialized
DEBUG - 2024-01-20 01:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 01:29:51 --> Input Class Initialized
INFO - 2024-01-20 01:29:51 --> Language Class Initialized
INFO - 2024-01-20 01:29:51 --> Loader Class Initialized
INFO - 2024-01-20 01:29:51 --> Helper loaded: url_helper
INFO - 2024-01-20 01:29:51 --> Helper loaded: file_helper
ERROR - 2024-01-20 01:29:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 01:29:51 --> Helper loaded: html_helper
INFO - 2024-01-20 01:29:51 --> Helper loaded: text_helper
INFO - 2024-01-20 01:29:51 --> Config Class Initialized
INFO - 2024-01-20 01:29:51 --> Hooks Class Initialized
INFO - 2024-01-20 01:29:51 --> Helper loaded: form_helper
INFO - 2024-01-20 01:29:51 --> Helper loaded: lang_helper
INFO - 2024-01-20 01:29:51 --> Helper loaded: security_helper
INFO - 2024-01-20 01:29:51 --> Helper loaded: cookie_helper
DEBUG - 2024-01-20 01:29:51 --> UTF-8 Support Enabled
INFO - 2024-01-20 01:29:51 --> Utf8 Class Initialized
INFO - 2024-01-20 01:29:51 --> URI Class Initialized
DEBUG - 2024-01-20 01:29:51 --> No URI present. Default controller set.
INFO - 2024-01-20 01:29:51 --> Router Class Initialized
INFO - 2024-01-20 01:29:51 --> Output Class Initialized
INFO - 2024-01-20 01:29:51 --> Security Class Initialized
INFO - 2024-01-20 01:29:51 --> Database Driver Class Initialized
DEBUG - 2024-01-20 01:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 01:29:51 --> Input Class Initialized
INFO - 2024-01-20 01:29:51 --> Language Class Initialized
INFO - 2024-01-20 01:29:51 --> Loader Class Initialized
INFO - 2024-01-20 01:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 01:29:51 --> Helper loaded: url_helper
INFO - 2024-01-20 01:29:51 --> Parser Class Initialized
INFO - 2024-01-20 01:29:51 --> Helper loaded: file_helper
INFO - 2024-01-20 01:29:51 --> Helper loaded: html_helper
INFO - 2024-01-20 01:29:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 01:29:51 --> Pagination Class Initialized
INFO - 2024-01-20 01:29:51 --> Helper loaded: text_helper
INFO - 2024-01-20 01:29:51 --> Helper loaded: form_helper
INFO - 2024-01-20 01:29:51 --> Helper loaded: lang_helper
INFO - 2024-01-20 01:29:51 --> Helper loaded: security_helper
INFO - 2024-01-20 01:29:51 --> Form Validation Class Initialized
INFO - 2024-01-20 01:29:51 --> Helper loaded: cookie_helper
INFO - 2024-01-20 01:29:51 --> Controller Class Initialized
INFO - 2024-01-20 01:29:51 --> Model Class Initialized
DEBUG - 2024-01-20 01:29:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:29:51 --> Database Driver Class Initialized
INFO - 2024-01-20 01:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 01:29:51 --> Parser Class Initialized
INFO - 2024-01-20 01:29:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 01:29:51 --> Pagination Class Initialized
INFO - 2024-01-20 01:29:51 --> Form Validation Class Initialized
INFO - 2024-01-20 01:29:51 --> Controller Class Initialized
INFO - 2024-01-20 01:29:51 --> Model Class Initialized
DEBUG - 2024-01-20 01:29:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-20 01:29:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 01:29:51 --> Config Class Initialized
INFO - 2024-01-20 01:29:51 --> Hooks Class Initialized
DEBUG - 2024-01-20 01:29:51 --> UTF-8 Support Enabled
INFO - 2024-01-20 01:29:51 --> Utf8 Class Initialized
INFO - 2024-01-20 01:29:51 --> URI Class Initialized
INFO - 2024-01-20 01:29:51 --> Router Class Initialized
INFO - 2024-01-20 01:29:51 --> Output Class Initialized
INFO - 2024-01-20 01:29:51 --> Security Class Initialized
DEBUG - 2024-01-20 01:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 01:29:51 --> Input Class Initialized
INFO - 2024-01-20 01:29:51 --> Language Class Initialized
INFO - 2024-01-20 01:29:51 --> Loader Class Initialized
INFO - 2024-01-20 01:29:51 --> Helper loaded: url_helper
INFO - 2024-01-20 01:29:51 --> Helper loaded: file_helper
INFO - 2024-01-20 01:29:51 --> Helper loaded: html_helper
INFO - 2024-01-20 01:29:51 --> Helper loaded: text_helper
INFO - 2024-01-20 01:29:51 --> Helper loaded: form_helper
INFO - 2024-01-20 01:29:51 --> Helper loaded: lang_helper
INFO - 2024-01-20 01:29:51 --> Helper loaded: security_helper
INFO - 2024-01-20 01:29:51 --> Helper loaded: cookie_helper
INFO - 2024-01-20 01:29:51 --> Database Driver Class Initialized
INFO - 2024-01-20 01:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 01:29:51 --> Parser Class Initialized
INFO - 2024-01-20 01:29:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 01:29:51 --> Pagination Class Initialized
INFO - 2024-01-20 01:29:51 --> Form Validation Class Initialized
INFO - 2024-01-20 01:29:51 --> Controller Class Initialized
INFO - 2024-01-20 01:29:51 --> Model Class Initialized
DEBUG - 2024-01-20 01:29:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:29:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-20 01:29:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:29:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 01:29:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 01:29:51 --> Model Class Initialized
INFO - 2024-01-20 01:29:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 01:29:51 --> Final output sent to browser
DEBUG - 2024-01-20 01:29:51 --> Total execution time: 0.0300
ERROR - 2024-01-20 01:29:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 01:29:51 --> Config Class Initialized
INFO - 2024-01-20 01:29:51 --> Hooks Class Initialized
DEBUG - 2024-01-20 01:29:51 --> UTF-8 Support Enabled
INFO - 2024-01-20 01:29:51 --> Utf8 Class Initialized
INFO - 2024-01-20 01:29:51 --> URI Class Initialized
INFO - 2024-01-20 01:29:51 --> Router Class Initialized
INFO - 2024-01-20 01:29:51 --> Output Class Initialized
INFO - 2024-01-20 01:29:51 --> Security Class Initialized
DEBUG - 2024-01-20 01:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 01:29:51 --> Input Class Initialized
INFO - 2024-01-20 01:29:51 --> Language Class Initialized
INFO - 2024-01-20 01:29:51 --> Loader Class Initialized
INFO - 2024-01-20 01:29:51 --> Helper loaded: url_helper
INFO - 2024-01-20 01:29:51 --> Helper loaded: file_helper
INFO - 2024-01-20 01:29:51 --> Helper loaded: html_helper
INFO - 2024-01-20 01:29:51 --> Helper loaded: text_helper
INFO - 2024-01-20 01:29:51 --> Helper loaded: form_helper
INFO - 2024-01-20 01:29:51 --> Helper loaded: lang_helper
INFO - 2024-01-20 01:29:51 --> Helper loaded: security_helper
INFO - 2024-01-20 01:29:51 --> Helper loaded: cookie_helper
INFO - 2024-01-20 01:29:51 --> Database Driver Class Initialized
INFO - 2024-01-20 01:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 01:29:51 --> Parser Class Initialized
INFO - 2024-01-20 01:29:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 01:29:51 --> Pagination Class Initialized
INFO - 2024-01-20 01:29:51 --> Form Validation Class Initialized
INFO - 2024-01-20 01:29:51 --> Controller Class Initialized
INFO - 2024-01-20 01:29:51 --> Model Class Initialized
DEBUG - 2024-01-20 01:29:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:29:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-20 01:29:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:29:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 01:29:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 01:29:51 --> Model Class Initialized
INFO - 2024-01-20 01:29:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 01:29:51 --> Final output sent to browser
DEBUG - 2024-01-20 01:29:51 --> Total execution time: 0.0307
ERROR - 2024-01-20 01:29:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 01:29:52 --> Config Class Initialized
INFO - 2024-01-20 01:29:52 --> Hooks Class Initialized
DEBUG - 2024-01-20 01:29:52 --> UTF-8 Support Enabled
INFO - 2024-01-20 01:29:52 --> Utf8 Class Initialized
INFO - 2024-01-20 01:29:52 --> URI Class Initialized
DEBUG - 2024-01-20 01:29:52 --> No URI present. Default controller set.
INFO - 2024-01-20 01:29:52 --> Router Class Initialized
INFO - 2024-01-20 01:29:52 --> Output Class Initialized
INFO - 2024-01-20 01:29:52 --> Security Class Initialized
DEBUG - 2024-01-20 01:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 01:29:52 --> Input Class Initialized
INFO - 2024-01-20 01:29:52 --> Language Class Initialized
INFO - 2024-01-20 01:29:52 --> Loader Class Initialized
INFO - 2024-01-20 01:29:52 --> Helper loaded: url_helper
INFO - 2024-01-20 01:29:52 --> Helper loaded: file_helper
INFO - 2024-01-20 01:29:52 --> Helper loaded: html_helper
INFO - 2024-01-20 01:29:52 --> Helper loaded: text_helper
INFO - 2024-01-20 01:29:52 --> Helper loaded: form_helper
INFO - 2024-01-20 01:29:52 --> Helper loaded: lang_helper
INFO - 2024-01-20 01:29:52 --> Helper loaded: security_helper
INFO - 2024-01-20 01:29:52 --> Helper loaded: cookie_helper
INFO - 2024-01-20 01:29:52 --> Database Driver Class Initialized
INFO - 2024-01-20 01:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 01:29:52 --> Parser Class Initialized
INFO - 2024-01-20 01:29:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 01:29:52 --> Pagination Class Initialized
INFO - 2024-01-20 01:29:52 --> Form Validation Class Initialized
INFO - 2024-01-20 01:29:52 --> Controller Class Initialized
INFO - 2024-01-20 01:29:52 --> Model Class Initialized
DEBUG - 2024-01-20 01:29:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-20 01:29:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 01:29:52 --> Config Class Initialized
INFO - 2024-01-20 01:29:52 --> Hooks Class Initialized
DEBUG - 2024-01-20 01:29:52 --> UTF-8 Support Enabled
INFO - 2024-01-20 01:29:52 --> Utf8 Class Initialized
INFO - 2024-01-20 01:29:52 --> URI Class Initialized
INFO - 2024-01-20 01:29:52 --> Router Class Initialized
INFO - 2024-01-20 01:29:52 --> Output Class Initialized
INFO - 2024-01-20 01:29:52 --> Security Class Initialized
DEBUG - 2024-01-20 01:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 01:29:52 --> Input Class Initialized
INFO - 2024-01-20 01:29:52 --> Language Class Initialized
INFO - 2024-01-20 01:29:52 --> Loader Class Initialized
INFO - 2024-01-20 01:29:52 --> Helper loaded: url_helper
INFO - 2024-01-20 01:29:52 --> Helper loaded: file_helper
INFO - 2024-01-20 01:29:52 --> Helper loaded: html_helper
INFO - 2024-01-20 01:29:52 --> Helper loaded: text_helper
INFO - 2024-01-20 01:29:52 --> Helper loaded: form_helper
INFO - 2024-01-20 01:29:52 --> Helper loaded: lang_helper
INFO - 2024-01-20 01:29:52 --> Helper loaded: security_helper
INFO - 2024-01-20 01:29:52 --> Helper loaded: cookie_helper
INFO - 2024-01-20 01:29:52 --> Database Driver Class Initialized
INFO - 2024-01-20 01:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 01:29:52 --> Parser Class Initialized
INFO - 2024-01-20 01:29:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 01:29:52 --> Pagination Class Initialized
INFO - 2024-01-20 01:29:52 --> Form Validation Class Initialized
INFO - 2024-01-20 01:29:52 --> Controller Class Initialized
INFO - 2024-01-20 01:29:52 --> Model Class Initialized
DEBUG - 2024-01-20 01:29:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:29:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-20 01:29:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 01:29:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 01:29:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 01:29:52 --> Model Class Initialized
INFO - 2024-01-20 01:29:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 01:29:52 --> Final output sent to browser
DEBUG - 2024-01-20 01:29:52 --> Total execution time: 0.0313
ERROR - 2024-01-20 02:38:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 02:38:44 --> Config Class Initialized
INFO - 2024-01-20 02:38:44 --> Hooks Class Initialized
DEBUG - 2024-01-20 02:38:44 --> UTF-8 Support Enabled
INFO - 2024-01-20 02:38:44 --> Utf8 Class Initialized
INFO - 2024-01-20 02:38:44 --> URI Class Initialized
DEBUG - 2024-01-20 02:38:44 --> No URI present. Default controller set.
INFO - 2024-01-20 02:38:44 --> Router Class Initialized
INFO - 2024-01-20 02:38:44 --> Output Class Initialized
INFO - 2024-01-20 02:38:44 --> Security Class Initialized
DEBUG - 2024-01-20 02:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 02:38:44 --> Input Class Initialized
INFO - 2024-01-20 02:38:44 --> Language Class Initialized
INFO - 2024-01-20 02:38:44 --> Loader Class Initialized
INFO - 2024-01-20 02:38:44 --> Helper loaded: url_helper
INFO - 2024-01-20 02:38:44 --> Helper loaded: file_helper
INFO - 2024-01-20 02:38:44 --> Helper loaded: html_helper
INFO - 2024-01-20 02:38:44 --> Helper loaded: text_helper
INFO - 2024-01-20 02:38:44 --> Helper loaded: form_helper
INFO - 2024-01-20 02:38:44 --> Helper loaded: lang_helper
INFO - 2024-01-20 02:38:44 --> Helper loaded: security_helper
INFO - 2024-01-20 02:38:44 --> Helper loaded: cookie_helper
INFO - 2024-01-20 02:38:44 --> Database Driver Class Initialized
INFO - 2024-01-20 02:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 02:38:44 --> Parser Class Initialized
INFO - 2024-01-20 02:38:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 02:38:44 --> Pagination Class Initialized
INFO - 2024-01-20 02:38:44 --> Form Validation Class Initialized
INFO - 2024-01-20 02:38:44 --> Controller Class Initialized
INFO - 2024-01-20 02:38:44 --> Model Class Initialized
DEBUG - 2024-01-20 02:38:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:38:44 --> Model Class Initialized
DEBUG - 2024-01-20 02:38:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:38:44 --> Model Class Initialized
INFO - 2024-01-20 02:38:44 --> Model Class Initialized
INFO - 2024-01-20 02:38:44 --> Model Class Initialized
INFO - 2024-01-20 02:38:44 --> Model Class Initialized
DEBUG - 2024-01-20 02:38:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 02:38:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:38:44 --> Model Class Initialized
INFO - 2024-01-20 02:38:44 --> Model Class Initialized
INFO - 2024-01-20 02:38:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-20 02:38:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:38:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 02:38:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 02:38:44 --> Model Class Initialized
INFO - 2024-01-20 02:38:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 02:38:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 02:38:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 02:38:44 --> Final output sent to browser
DEBUG - 2024-01-20 02:38:44 --> Total execution time: 0.2467
ERROR - 2024-01-20 02:38:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 02:38:50 --> Config Class Initialized
INFO - 2024-01-20 02:38:50 --> Hooks Class Initialized
DEBUG - 2024-01-20 02:38:51 --> UTF-8 Support Enabled
INFO - 2024-01-20 02:38:51 --> Utf8 Class Initialized
INFO - 2024-01-20 02:38:51 --> URI Class Initialized
INFO - 2024-01-20 02:38:51 --> Router Class Initialized
INFO - 2024-01-20 02:38:51 --> Output Class Initialized
INFO - 2024-01-20 02:38:51 --> Security Class Initialized
DEBUG - 2024-01-20 02:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 02:38:51 --> Input Class Initialized
INFO - 2024-01-20 02:38:51 --> Language Class Initialized
INFO - 2024-01-20 02:38:51 --> Loader Class Initialized
INFO - 2024-01-20 02:38:51 --> Helper loaded: url_helper
INFO - 2024-01-20 02:38:51 --> Helper loaded: file_helper
INFO - 2024-01-20 02:38:51 --> Helper loaded: html_helper
INFO - 2024-01-20 02:38:51 --> Helper loaded: text_helper
INFO - 2024-01-20 02:38:51 --> Helper loaded: form_helper
INFO - 2024-01-20 02:38:51 --> Helper loaded: lang_helper
INFO - 2024-01-20 02:38:51 --> Helper loaded: security_helper
INFO - 2024-01-20 02:38:51 --> Helper loaded: cookie_helper
INFO - 2024-01-20 02:38:51 --> Database Driver Class Initialized
INFO - 2024-01-20 02:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 02:38:51 --> Parser Class Initialized
INFO - 2024-01-20 02:38:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 02:38:51 --> Pagination Class Initialized
INFO - 2024-01-20 02:38:51 --> Form Validation Class Initialized
INFO - 2024-01-20 02:38:51 --> Controller Class Initialized
INFO - 2024-01-20 02:38:51 --> Model Class Initialized
DEBUG - 2024-01-20 02:38:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 02:38:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:38:51 --> Model Class Initialized
DEBUG - 2024-01-20 02:38:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:38:51 --> Model Class Initialized
INFO - 2024-01-20 02:38:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-20 02:38:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:38:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 02:38:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 02:38:51 --> Model Class Initialized
INFO - 2024-01-20 02:38:51 --> Model Class Initialized
INFO - 2024-01-20 02:38:51 --> Model Class Initialized
INFO - 2024-01-20 02:38:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 02:38:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 02:38:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 02:38:51 --> Final output sent to browser
DEBUG - 2024-01-20 02:38:51 --> Total execution time: 0.1459
ERROR - 2024-01-20 02:38:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 02:38:52 --> Config Class Initialized
INFO - 2024-01-20 02:38:52 --> Hooks Class Initialized
DEBUG - 2024-01-20 02:38:52 --> UTF-8 Support Enabled
INFO - 2024-01-20 02:38:52 --> Utf8 Class Initialized
INFO - 2024-01-20 02:38:52 --> URI Class Initialized
INFO - 2024-01-20 02:38:52 --> Router Class Initialized
INFO - 2024-01-20 02:38:52 --> Output Class Initialized
INFO - 2024-01-20 02:38:52 --> Security Class Initialized
DEBUG - 2024-01-20 02:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 02:38:52 --> Input Class Initialized
INFO - 2024-01-20 02:38:52 --> Language Class Initialized
INFO - 2024-01-20 02:38:52 --> Loader Class Initialized
INFO - 2024-01-20 02:38:52 --> Helper loaded: url_helper
INFO - 2024-01-20 02:38:52 --> Helper loaded: file_helper
INFO - 2024-01-20 02:38:52 --> Helper loaded: html_helper
INFO - 2024-01-20 02:38:52 --> Helper loaded: text_helper
INFO - 2024-01-20 02:38:52 --> Helper loaded: form_helper
INFO - 2024-01-20 02:38:52 --> Helper loaded: lang_helper
INFO - 2024-01-20 02:38:52 --> Helper loaded: security_helper
INFO - 2024-01-20 02:38:52 --> Helper loaded: cookie_helper
INFO - 2024-01-20 02:38:52 --> Database Driver Class Initialized
INFO - 2024-01-20 02:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 02:38:52 --> Parser Class Initialized
INFO - 2024-01-20 02:38:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 02:38:52 --> Pagination Class Initialized
INFO - 2024-01-20 02:38:52 --> Form Validation Class Initialized
INFO - 2024-01-20 02:38:52 --> Controller Class Initialized
INFO - 2024-01-20 02:38:52 --> Model Class Initialized
DEBUG - 2024-01-20 02:38:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 02:38:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:38:52 --> Model Class Initialized
DEBUG - 2024-01-20 02:38:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:38:52 --> Model Class Initialized
INFO - 2024-01-20 02:38:52 --> Final output sent to browser
DEBUG - 2024-01-20 02:38:52 --> Total execution time: 0.0403
ERROR - 2024-01-20 02:38:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 02:38:58 --> Config Class Initialized
INFO - 2024-01-20 02:38:58 --> Hooks Class Initialized
DEBUG - 2024-01-20 02:38:58 --> UTF-8 Support Enabled
INFO - 2024-01-20 02:38:58 --> Utf8 Class Initialized
INFO - 2024-01-20 02:38:58 --> URI Class Initialized
INFO - 2024-01-20 02:38:58 --> Router Class Initialized
INFO - 2024-01-20 02:38:58 --> Output Class Initialized
INFO - 2024-01-20 02:38:58 --> Security Class Initialized
DEBUG - 2024-01-20 02:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 02:38:58 --> Input Class Initialized
INFO - 2024-01-20 02:38:58 --> Language Class Initialized
INFO - 2024-01-20 02:38:58 --> Loader Class Initialized
INFO - 2024-01-20 02:38:58 --> Helper loaded: url_helper
INFO - 2024-01-20 02:38:58 --> Helper loaded: file_helper
INFO - 2024-01-20 02:38:58 --> Helper loaded: html_helper
INFO - 2024-01-20 02:38:58 --> Helper loaded: text_helper
INFO - 2024-01-20 02:38:58 --> Helper loaded: form_helper
INFO - 2024-01-20 02:38:58 --> Helper loaded: lang_helper
INFO - 2024-01-20 02:38:58 --> Helper loaded: security_helper
INFO - 2024-01-20 02:38:58 --> Helper loaded: cookie_helper
INFO - 2024-01-20 02:38:58 --> Database Driver Class Initialized
INFO - 2024-01-20 02:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 02:38:58 --> Parser Class Initialized
INFO - 2024-01-20 02:38:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 02:38:58 --> Pagination Class Initialized
INFO - 2024-01-20 02:38:58 --> Form Validation Class Initialized
INFO - 2024-01-20 02:38:58 --> Controller Class Initialized
INFO - 2024-01-20 02:38:58 --> Model Class Initialized
DEBUG - 2024-01-20 02:38:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 02:38:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:38:58 --> Model Class Initialized
DEBUG - 2024-01-20 02:38:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:38:58 --> Model Class Initialized
INFO - 2024-01-20 02:38:58 --> Final output sent to browser
DEBUG - 2024-01-20 02:38:58 --> Total execution time: 0.1141
ERROR - 2024-01-20 02:43:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 02:43:25 --> Config Class Initialized
INFO - 2024-01-20 02:43:25 --> Hooks Class Initialized
DEBUG - 2024-01-20 02:43:25 --> UTF-8 Support Enabled
INFO - 2024-01-20 02:43:25 --> Utf8 Class Initialized
INFO - 2024-01-20 02:43:25 --> URI Class Initialized
INFO - 2024-01-20 02:43:25 --> Router Class Initialized
INFO - 2024-01-20 02:43:25 --> Output Class Initialized
INFO - 2024-01-20 02:43:25 --> Security Class Initialized
DEBUG - 2024-01-20 02:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 02:43:25 --> Input Class Initialized
INFO - 2024-01-20 02:43:25 --> Language Class Initialized
INFO - 2024-01-20 02:43:25 --> Loader Class Initialized
INFO - 2024-01-20 02:43:25 --> Helper loaded: url_helper
INFO - 2024-01-20 02:43:25 --> Helper loaded: file_helper
INFO - 2024-01-20 02:43:25 --> Helper loaded: html_helper
INFO - 2024-01-20 02:43:25 --> Helper loaded: text_helper
INFO - 2024-01-20 02:43:25 --> Helper loaded: form_helper
INFO - 2024-01-20 02:43:25 --> Helper loaded: lang_helper
INFO - 2024-01-20 02:43:25 --> Helper loaded: security_helper
INFO - 2024-01-20 02:43:25 --> Helper loaded: cookie_helper
INFO - 2024-01-20 02:43:25 --> Database Driver Class Initialized
INFO - 2024-01-20 02:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 02:43:25 --> Parser Class Initialized
INFO - 2024-01-20 02:43:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 02:43:25 --> Pagination Class Initialized
INFO - 2024-01-20 02:43:25 --> Form Validation Class Initialized
INFO - 2024-01-20 02:43:25 --> Controller Class Initialized
INFO - 2024-01-20 02:43:25 --> Model Class Initialized
DEBUG - 2024-01-20 02:43:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 02:43:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:43:25 --> Model Class Initialized
DEBUG - 2024-01-20 02:43:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:43:25 --> Model Class Initialized
DEBUG - 2024-01-20 02:43:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:43:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-01-20 02:43:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:43:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 02:43:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 02:43:25 --> Model Class Initialized
INFO - 2024-01-20 02:43:25 --> Model Class Initialized
INFO - 2024-01-20 02:43:25 --> Model Class Initialized
INFO - 2024-01-20 02:43:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 02:43:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 02:43:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 02:43:25 --> Final output sent to browser
DEBUG - 2024-01-20 02:43:25 --> Total execution time: 0.1706
ERROR - 2024-01-20 02:46:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 02:46:36 --> Config Class Initialized
INFO - 2024-01-20 02:46:36 --> Hooks Class Initialized
DEBUG - 2024-01-20 02:46:36 --> UTF-8 Support Enabled
INFO - 2024-01-20 02:46:36 --> Utf8 Class Initialized
INFO - 2024-01-20 02:46:36 --> URI Class Initialized
INFO - 2024-01-20 02:46:36 --> Router Class Initialized
INFO - 2024-01-20 02:46:36 --> Output Class Initialized
INFO - 2024-01-20 02:46:36 --> Security Class Initialized
DEBUG - 2024-01-20 02:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 02:46:36 --> Input Class Initialized
INFO - 2024-01-20 02:46:36 --> Language Class Initialized
INFO - 2024-01-20 02:46:36 --> Loader Class Initialized
INFO - 2024-01-20 02:46:36 --> Helper loaded: url_helper
INFO - 2024-01-20 02:46:36 --> Helper loaded: file_helper
INFO - 2024-01-20 02:46:36 --> Helper loaded: html_helper
INFO - 2024-01-20 02:46:36 --> Helper loaded: text_helper
INFO - 2024-01-20 02:46:36 --> Helper loaded: form_helper
INFO - 2024-01-20 02:46:36 --> Helper loaded: lang_helper
INFO - 2024-01-20 02:46:36 --> Helper loaded: security_helper
INFO - 2024-01-20 02:46:36 --> Helper loaded: cookie_helper
INFO - 2024-01-20 02:46:36 --> Database Driver Class Initialized
INFO - 2024-01-20 02:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 02:46:36 --> Parser Class Initialized
INFO - 2024-01-20 02:46:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 02:46:36 --> Pagination Class Initialized
INFO - 2024-01-20 02:46:36 --> Form Validation Class Initialized
INFO - 2024-01-20 02:46:36 --> Controller Class Initialized
INFO - 2024-01-20 02:46:36 --> Model Class Initialized
DEBUG - 2024-01-20 02:46:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 02:46:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:46:36 --> Model Class Initialized
DEBUG - 2024-01-20 02:46:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:46:36 --> Model Class Initialized
INFO - 2024-01-20 02:46:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-20 02:46:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:46:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 02:46:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 02:46:36 --> Model Class Initialized
INFO - 2024-01-20 02:46:36 --> Model Class Initialized
INFO - 2024-01-20 02:46:36 --> Model Class Initialized
INFO - 2024-01-20 02:46:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 02:46:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 02:46:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 02:46:36 --> Final output sent to browser
DEBUG - 2024-01-20 02:46:36 --> Total execution time: 0.1907
ERROR - 2024-01-20 02:46:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 02:46:37 --> Config Class Initialized
INFO - 2024-01-20 02:46:37 --> Hooks Class Initialized
DEBUG - 2024-01-20 02:46:37 --> UTF-8 Support Enabled
INFO - 2024-01-20 02:46:37 --> Utf8 Class Initialized
INFO - 2024-01-20 02:46:37 --> URI Class Initialized
INFO - 2024-01-20 02:46:37 --> Router Class Initialized
INFO - 2024-01-20 02:46:37 --> Output Class Initialized
INFO - 2024-01-20 02:46:37 --> Security Class Initialized
DEBUG - 2024-01-20 02:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 02:46:37 --> Input Class Initialized
INFO - 2024-01-20 02:46:37 --> Language Class Initialized
INFO - 2024-01-20 02:46:37 --> Loader Class Initialized
INFO - 2024-01-20 02:46:37 --> Helper loaded: url_helper
INFO - 2024-01-20 02:46:37 --> Helper loaded: file_helper
INFO - 2024-01-20 02:46:37 --> Helper loaded: html_helper
INFO - 2024-01-20 02:46:37 --> Helper loaded: text_helper
INFO - 2024-01-20 02:46:37 --> Helper loaded: form_helper
INFO - 2024-01-20 02:46:37 --> Helper loaded: lang_helper
INFO - 2024-01-20 02:46:37 --> Helper loaded: security_helper
INFO - 2024-01-20 02:46:37 --> Helper loaded: cookie_helper
INFO - 2024-01-20 02:46:37 --> Database Driver Class Initialized
INFO - 2024-01-20 02:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 02:46:37 --> Parser Class Initialized
INFO - 2024-01-20 02:46:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 02:46:37 --> Pagination Class Initialized
INFO - 2024-01-20 02:46:37 --> Form Validation Class Initialized
INFO - 2024-01-20 02:46:37 --> Controller Class Initialized
INFO - 2024-01-20 02:46:37 --> Model Class Initialized
DEBUG - 2024-01-20 02:46:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 02:46:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:46:37 --> Model Class Initialized
DEBUG - 2024-01-20 02:46:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:46:37 --> Model Class Initialized
INFO - 2024-01-20 02:46:37 --> Final output sent to browser
DEBUG - 2024-01-20 02:46:37 --> Total execution time: 0.0404
ERROR - 2024-01-20 02:46:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 02:46:45 --> Config Class Initialized
INFO - 2024-01-20 02:46:45 --> Hooks Class Initialized
DEBUG - 2024-01-20 02:46:45 --> UTF-8 Support Enabled
INFO - 2024-01-20 02:46:45 --> Utf8 Class Initialized
INFO - 2024-01-20 02:46:45 --> URI Class Initialized
INFO - 2024-01-20 02:46:45 --> Router Class Initialized
INFO - 2024-01-20 02:46:45 --> Output Class Initialized
INFO - 2024-01-20 02:46:45 --> Security Class Initialized
DEBUG - 2024-01-20 02:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 02:46:45 --> Input Class Initialized
INFO - 2024-01-20 02:46:45 --> Language Class Initialized
INFO - 2024-01-20 02:46:45 --> Loader Class Initialized
INFO - 2024-01-20 02:46:45 --> Helper loaded: url_helper
INFO - 2024-01-20 02:46:45 --> Helper loaded: file_helper
INFO - 2024-01-20 02:46:45 --> Helper loaded: html_helper
INFO - 2024-01-20 02:46:45 --> Helper loaded: text_helper
INFO - 2024-01-20 02:46:45 --> Helper loaded: form_helper
INFO - 2024-01-20 02:46:45 --> Helper loaded: lang_helper
INFO - 2024-01-20 02:46:45 --> Helper loaded: security_helper
INFO - 2024-01-20 02:46:45 --> Helper loaded: cookie_helper
INFO - 2024-01-20 02:46:45 --> Database Driver Class Initialized
INFO - 2024-01-20 02:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 02:46:45 --> Parser Class Initialized
INFO - 2024-01-20 02:46:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 02:46:45 --> Pagination Class Initialized
INFO - 2024-01-20 02:46:45 --> Form Validation Class Initialized
INFO - 2024-01-20 02:46:45 --> Controller Class Initialized
INFO - 2024-01-20 02:46:45 --> Model Class Initialized
DEBUG - 2024-01-20 02:46:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 02:46:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:46:45 --> Model Class Initialized
DEBUG - 2024-01-20 02:46:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:46:45 --> Model Class Initialized
INFO - 2024-01-20 02:46:45 --> Final output sent to browser
DEBUG - 2024-01-20 02:46:45 --> Total execution time: 0.1168
ERROR - 2024-01-20 02:46:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 02:46:57 --> Config Class Initialized
INFO - 2024-01-20 02:46:57 --> Hooks Class Initialized
DEBUG - 2024-01-20 02:46:57 --> UTF-8 Support Enabled
INFO - 2024-01-20 02:46:57 --> Utf8 Class Initialized
INFO - 2024-01-20 02:46:57 --> URI Class Initialized
INFO - 2024-01-20 02:46:57 --> Router Class Initialized
INFO - 2024-01-20 02:46:57 --> Output Class Initialized
INFO - 2024-01-20 02:46:57 --> Security Class Initialized
DEBUG - 2024-01-20 02:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 02:46:57 --> Input Class Initialized
INFO - 2024-01-20 02:46:57 --> Language Class Initialized
INFO - 2024-01-20 02:46:57 --> Loader Class Initialized
INFO - 2024-01-20 02:46:57 --> Helper loaded: url_helper
INFO - 2024-01-20 02:46:57 --> Helper loaded: file_helper
INFO - 2024-01-20 02:46:57 --> Helper loaded: html_helper
INFO - 2024-01-20 02:46:57 --> Helper loaded: text_helper
INFO - 2024-01-20 02:46:57 --> Helper loaded: form_helper
INFO - 2024-01-20 02:46:57 --> Helper loaded: lang_helper
INFO - 2024-01-20 02:46:57 --> Helper loaded: security_helper
INFO - 2024-01-20 02:46:57 --> Helper loaded: cookie_helper
INFO - 2024-01-20 02:46:57 --> Database Driver Class Initialized
INFO - 2024-01-20 02:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 02:46:57 --> Parser Class Initialized
INFO - 2024-01-20 02:46:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 02:46:57 --> Pagination Class Initialized
INFO - 2024-01-20 02:46:57 --> Form Validation Class Initialized
INFO - 2024-01-20 02:46:57 --> Controller Class Initialized
INFO - 2024-01-20 02:46:57 --> Model Class Initialized
DEBUG - 2024-01-20 02:46:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 02:46:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:46:57 --> Model Class Initialized
DEBUG - 2024-01-20 02:46:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:46:57 --> Model Class Initialized
DEBUG - 2024-01-20 02:46:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:46:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-01-20 02:46:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:46:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 02:46:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 02:46:57 --> Model Class Initialized
INFO - 2024-01-20 02:46:57 --> Model Class Initialized
INFO - 2024-01-20 02:46:57 --> Model Class Initialized
INFO - 2024-01-20 02:46:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 02:46:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 02:46:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 02:46:57 --> Final output sent to browser
DEBUG - 2024-01-20 02:46:57 --> Total execution time: 0.1566
ERROR - 2024-01-20 02:47:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 02:47:17 --> Config Class Initialized
INFO - 2024-01-20 02:47:17 --> Hooks Class Initialized
DEBUG - 2024-01-20 02:47:17 --> UTF-8 Support Enabled
INFO - 2024-01-20 02:47:17 --> Utf8 Class Initialized
INFO - 2024-01-20 02:47:17 --> URI Class Initialized
INFO - 2024-01-20 02:47:17 --> Router Class Initialized
INFO - 2024-01-20 02:47:17 --> Output Class Initialized
INFO - 2024-01-20 02:47:17 --> Security Class Initialized
DEBUG - 2024-01-20 02:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 02:47:17 --> Input Class Initialized
INFO - 2024-01-20 02:47:17 --> Language Class Initialized
INFO - 2024-01-20 02:47:17 --> Loader Class Initialized
INFO - 2024-01-20 02:47:17 --> Helper loaded: url_helper
INFO - 2024-01-20 02:47:17 --> Helper loaded: file_helper
INFO - 2024-01-20 02:47:17 --> Helper loaded: html_helper
INFO - 2024-01-20 02:47:17 --> Helper loaded: text_helper
INFO - 2024-01-20 02:47:17 --> Helper loaded: form_helper
INFO - 2024-01-20 02:47:17 --> Helper loaded: lang_helper
INFO - 2024-01-20 02:47:17 --> Helper loaded: security_helper
INFO - 2024-01-20 02:47:17 --> Helper loaded: cookie_helper
INFO - 2024-01-20 02:47:18 --> Database Driver Class Initialized
INFO - 2024-01-20 02:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 02:47:18 --> Parser Class Initialized
INFO - 2024-01-20 02:47:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 02:47:18 --> Pagination Class Initialized
INFO - 2024-01-20 02:47:18 --> Form Validation Class Initialized
INFO - 2024-01-20 02:47:18 --> Controller Class Initialized
INFO - 2024-01-20 02:47:18 --> Model Class Initialized
DEBUG - 2024-01-20 02:47:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 02:47:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:47:18 --> Model Class Initialized
DEBUG - 2024-01-20 02:47:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:47:18 --> Model Class Initialized
INFO - 2024-01-20 02:47:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-20 02:47:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:47:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 02:47:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 02:47:18 --> Model Class Initialized
INFO - 2024-01-20 02:47:18 --> Model Class Initialized
INFO - 2024-01-20 02:47:18 --> Model Class Initialized
INFO - 2024-01-20 02:47:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 02:47:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 02:47:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 02:47:18 --> Final output sent to browser
DEBUG - 2024-01-20 02:47:18 --> Total execution time: 0.1544
ERROR - 2024-01-20 02:47:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 02:47:19 --> Config Class Initialized
INFO - 2024-01-20 02:47:19 --> Hooks Class Initialized
DEBUG - 2024-01-20 02:47:19 --> UTF-8 Support Enabled
INFO - 2024-01-20 02:47:19 --> Utf8 Class Initialized
INFO - 2024-01-20 02:47:19 --> URI Class Initialized
INFO - 2024-01-20 02:47:19 --> Router Class Initialized
INFO - 2024-01-20 02:47:19 --> Output Class Initialized
INFO - 2024-01-20 02:47:19 --> Security Class Initialized
DEBUG - 2024-01-20 02:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 02:47:19 --> Input Class Initialized
INFO - 2024-01-20 02:47:19 --> Language Class Initialized
INFO - 2024-01-20 02:47:19 --> Loader Class Initialized
INFO - 2024-01-20 02:47:19 --> Helper loaded: url_helper
INFO - 2024-01-20 02:47:19 --> Helper loaded: file_helper
INFO - 2024-01-20 02:47:19 --> Helper loaded: html_helper
INFO - 2024-01-20 02:47:19 --> Helper loaded: text_helper
INFO - 2024-01-20 02:47:19 --> Helper loaded: form_helper
INFO - 2024-01-20 02:47:19 --> Helper loaded: lang_helper
INFO - 2024-01-20 02:47:19 --> Helper loaded: security_helper
INFO - 2024-01-20 02:47:19 --> Helper loaded: cookie_helper
INFO - 2024-01-20 02:47:19 --> Database Driver Class Initialized
INFO - 2024-01-20 02:47:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 02:47:19 --> Parser Class Initialized
INFO - 2024-01-20 02:47:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 02:47:19 --> Pagination Class Initialized
INFO - 2024-01-20 02:47:19 --> Form Validation Class Initialized
INFO - 2024-01-20 02:47:19 --> Controller Class Initialized
INFO - 2024-01-20 02:47:19 --> Model Class Initialized
DEBUG - 2024-01-20 02:47:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 02:47:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:47:19 --> Model Class Initialized
DEBUG - 2024-01-20 02:47:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:47:19 --> Model Class Initialized
INFO - 2024-01-20 02:47:19 --> Final output sent to browser
DEBUG - 2024-01-20 02:47:19 --> Total execution time: 0.0417
ERROR - 2024-01-20 02:47:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 02:47:28 --> Config Class Initialized
INFO - 2024-01-20 02:47:28 --> Hooks Class Initialized
DEBUG - 2024-01-20 02:47:28 --> UTF-8 Support Enabled
INFO - 2024-01-20 02:47:28 --> Utf8 Class Initialized
INFO - 2024-01-20 02:47:28 --> URI Class Initialized
INFO - 2024-01-20 02:47:28 --> Router Class Initialized
INFO - 2024-01-20 02:47:28 --> Output Class Initialized
INFO - 2024-01-20 02:47:28 --> Security Class Initialized
DEBUG - 2024-01-20 02:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 02:47:28 --> Input Class Initialized
INFO - 2024-01-20 02:47:28 --> Language Class Initialized
INFO - 2024-01-20 02:47:28 --> Loader Class Initialized
INFO - 2024-01-20 02:47:28 --> Helper loaded: url_helper
INFO - 2024-01-20 02:47:28 --> Helper loaded: file_helper
INFO - 2024-01-20 02:47:28 --> Helper loaded: html_helper
INFO - 2024-01-20 02:47:28 --> Helper loaded: text_helper
INFO - 2024-01-20 02:47:28 --> Helper loaded: form_helper
INFO - 2024-01-20 02:47:28 --> Helper loaded: lang_helper
INFO - 2024-01-20 02:47:28 --> Helper loaded: security_helper
INFO - 2024-01-20 02:47:28 --> Helper loaded: cookie_helper
INFO - 2024-01-20 02:47:28 --> Database Driver Class Initialized
INFO - 2024-01-20 02:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 02:47:28 --> Parser Class Initialized
INFO - 2024-01-20 02:47:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 02:47:28 --> Pagination Class Initialized
INFO - 2024-01-20 02:47:28 --> Form Validation Class Initialized
INFO - 2024-01-20 02:47:28 --> Controller Class Initialized
INFO - 2024-01-20 02:47:28 --> Model Class Initialized
DEBUG - 2024-01-20 02:47:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 02:47:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:47:28 --> Model Class Initialized
DEBUG - 2024-01-20 02:47:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:47:28 --> Model Class Initialized
INFO - 2024-01-20 02:47:29 --> Final output sent to browser
DEBUG - 2024-01-20 02:47:29 --> Total execution time: 0.1098
ERROR - 2024-01-20 02:47:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 02:47:39 --> Config Class Initialized
INFO - 2024-01-20 02:47:39 --> Hooks Class Initialized
DEBUG - 2024-01-20 02:47:39 --> UTF-8 Support Enabled
INFO - 2024-01-20 02:47:39 --> Utf8 Class Initialized
INFO - 2024-01-20 02:47:39 --> URI Class Initialized
INFO - 2024-01-20 02:47:39 --> Router Class Initialized
INFO - 2024-01-20 02:47:39 --> Output Class Initialized
INFO - 2024-01-20 02:47:39 --> Security Class Initialized
DEBUG - 2024-01-20 02:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 02:47:39 --> Input Class Initialized
INFO - 2024-01-20 02:47:39 --> Language Class Initialized
INFO - 2024-01-20 02:47:39 --> Loader Class Initialized
INFO - 2024-01-20 02:47:39 --> Helper loaded: url_helper
INFO - 2024-01-20 02:47:39 --> Helper loaded: file_helper
INFO - 2024-01-20 02:47:39 --> Helper loaded: html_helper
INFO - 2024-01-20 02:47:39 --> Helper loaded: text_helper
INFO - 2024-01-20 02:47:39 --> Helper loaded: form_helper
INFO - 2024-01-20 02:47:39 --> Helper loaded: lang_helper
INFO - 2024-01-20 02:47:39 --> Helper loaded: security_helper
INFO - 2024-01-20 02:47:39 --> Helper loaded: cookie_helper
INFO - 2024-01-20 02:47:39 --> Database Driver Class Initialized
INFO - 2024-01-20 02:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 02:47:39 --> Parser Class Initialized
INFO - 2024-01-20 02:47:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 02:47:39 --> Pagination Class Initialized
INFO - 2024-01-20 02:47:39 --> Form Validation Class Initialized
INFO - 2024-01-20 02:47:39 --> Controller Class Initialized
INFO - 2024-01-20 02:47:39 --> Model Class Initialized
DEBUG - 2024-01-20 02:47:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 02:47:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:47:39 --> Model Class Initialized
DEBUG - 2024-01-20 02:47:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:47:39 --> Model Class Initialized
DEBUG - 2024-01-20 02:47:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:47:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-01-20 02:47:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:47:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 02:47:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 02:47:39 --> Model Class Initialized
INFO - 2024-01-20 02:47:39 --> Model Class Initialized
INFO - 2024-01-20 02:47:39 --> Model Class Initialized
INFO - 2024-01-20 02:47:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 02:47:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 02:47:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 02:47:40 --> Final output sent to browser
DEBUG - 2024-01-20 02:47:40 --> Total execution time: 0.1534
ERROR - 2024-01-20 02:54:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 02:54:58 --> Config Class Initialized
INFO - 2024-01-20 02:54:58 --> Hooks Class Initialized
DEBUG - 2024-01-20 02:54:58 --> UTF-8 Support Enabled
INFO - 2024-01-20 02:54:58 --> Utf8 Class Initialized
INFO - 2024-01-20 02:54:58 --> URI Class Initialized
INFO - 2024-01-20 02:54:58 --> Router Class Initialized
INFO - 2024-01-20 02:54:58 --> Output Class Initialized
INFO - 2024-01-20 02:54:58 --> Security Class Initialized
DEBUG - 2024-01-20 02:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 02:54:58 --> Input Class Initialized
INFO - 2024-01-20 02:54:58 --> Language Class Initialized
INFO - 2024-01-20 02:54:58 --> Loader Class Initialized
INFO - 2024-01-20 02:54:58 --> Helper loaded: url_helper
INFO - 2024-01-20 02:54:58 --> Helper loaded: file_helper
INFO - 2024-01-20 02:54:58 --> Helper loaded: html_helper
INFO - 2024-01-20 02:54:58 --> Helper loaded: text_helper
INFO - 2024-01-20 02:54:58 --> Helper loaded: form_helper
INFO - 2024-01-20 02:54:58 --> Helper loaded: lang_helper
INFO - 2024-01-20 02:54:58 --> Helper loaded: security_helper
INFO - 2024-01-20 02:54:58 --> Helper loaded: cookie_helper
INFO - 2024-01-20 02:54:58 --> Database Driver Class Initialized
INFO - 2024-01-20 02:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 02:54:58 --> Parser Class Initialized
INFO - 2024-01-20 02:54:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 02:54:58 --> Pagination Class Initialized
INFO - 2024-01-20 02:54:58 --> Form Validation Class Initialized
INFO - 2024-01-20 02:54:58 --> Controller Class Initialized
INFO - 2024-01-20 02:54:58 --> Model Class Initialized
DEBUG - 2024-01-20 02:54:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 02:54:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:54:58 --> Model Class Initialized
DEBUG - 2024-01-20 02:54:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:54:58 --> Model Class Initialized
INFO - 2024-01-20 02:54:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-20 02:54:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:54:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 02:54:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 02:54:58 --> Model Class Initialized
INFO - 2024-01-20 02:54:58 --> Model Class Initialized
INFO - 2024-01-20 02:54:58 --> Model Class Initialized
INFO - 2024-01-20 02:54:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 02:54:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 02:54:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 02:54:58 --> Final output sent to browser
DEBUG - 2024-01-20 02:54:58 --> Total execution time: 0.1609
ERROR - 2024-01-20 02:54:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 02:54:59 --> Config Class Initialized
INFO - 2024-01-20 02:54:59 --> Hooks Class Initialized
DEBUG - 2024-01-20 02:54:59 --> UTF-8 Support Enabled
INFO - 2024-01-20 02:54:59 --> Utf8 Class Initialized
INFO - 2024-01-20 02:54:59 --> URI Class Initialized
DEBUG - 2024-01-20 02:54:59 --> No URI present. Default controller set.
INFO - 2024-01-20 02:54:59 --> Router Class Initialized
INFO - 2024-01-20 02:54:59 --> Output Class Initialized
INFO - 2024-01-20 02:54:59 --> Security Class Initialized
DEBUG - 2024-01-20 02:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 02:54:59 --> Input Class Initialized
INFO - 2024-01-20 02:54:59 --> Language Class Initialized
INFO - 2024-01-20 02:54:59 --> Loader Class Initialized
INFO - 2024-01-20 02:54:59 --> Helper loaded: url_helper
INFO - 2024-01-20 02:54:59 --> Helper loaded: file_helper
INFO - 2024-01-20 02:54:59 --> Helper loaded: html_helper
INFO - 2024-01-20 02:54:59 --> Helper loaded: text_helper
INFO - 2024-01-20 02:54:59 --> Helper loaded: form_helper
INFO - 2024-01-20 02:54:59 --> Helper loaded: lang_helper
INFO - 2024-01-20 02:54:59 --> Helper loaded: security_helper
INFO - 2024-01-20 02:54:59 --> Helper loaded: cookie_helper
INFO - 2024-01-20 02:54:59 --> Database Driver Class Initialized
INFO - 2024-01-20 02:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 02:54:59 --> Parser Class Initialized
INFO - 2024-01-20 02:54:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 02:54:59 --> Pagination Class Initialized
INFO - 2024-01-20 02:54:59 --> Form Validation Class Initialized
INFO - 2024-01-20 02:54:59 --> Controller Class Initialized
INFO - 2024-01-20 02:54:59 --> Model Class Initialized
DEBUG - 2024-01-20 02:54:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:54:59 --> Model Class Initialized
DEBUG - 2024-01-20 02:54:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:54:59 --> Model Class Initialized
INFO - 2024-01-20 02:54:59 --> Model Class Initialized
INFO - 2024-01-20 02:54:59 --> Model Class Initialized
INFO - 2024-01-20 02:54:59 --> Model Class Initialized
DEBUG - 2024-01-20 02:54:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 02:54:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:54:59 --> Model Class Initialized
INFO - 2024-01-20 02:54:59 --> Model Class Initialized
ERROR - 2024-01-20 02:54:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 02:54:59 --> Config Class Initialized
INFO - 2024-01-20 02:54:59 --> Hooks Class Initialized
DEBUG - 2024-01-20 02:54:59 --> UTF-8 Support Enabled
INFO - 2024-01-20 02:54:59 --> Utf8 Class Initialized
INFO - 2024-01-20 02:54:59 --> URI Class Initialized
INFO - 2024-01-20 02:54:59 --> Router Class Initialized
INFO - 2024-01-20 02:54:59 --> Output Class Initialized
INFO - 2024-01-20 02:54:59 --> Security Class Initialized
DEBUG - 2024-01-20 02:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 02:54:59 --> Input Class Initialized
INFO - 2024-01-20 02:54:59 --> Language Class Initialized
INFO - 2024-01-20 02:54:59 --> Loader Class Initialized
INFO - 2024-01-20 02:54:59 --> Helper loaded: url_helper
INFO - 2024-01-20 02:54:59 --> Helper loaded: file_helper
INFO - 2024-01-20 02:54:59 --> Helper loaded: html_helper
INFO - 2024-01-20 02:54:59 --> Helper loaded: text_helper
INFO - 2024-01-20 02:54:59 --> Helper loaded: form_helper
INFO - 2024-01-20 02:54:59 --> Helper loaded: lang_helper
INFO - 2024-01-20 02:54:59 --> Helper loaded: security_helper
INFO - 2024-01-20 02:54:59 --> Helper loaded: cookie_helper
INFO - 2024-01-20 02:54:59 --> Database Driver Class Initialized
INFO - 2024-01-20 02:54:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-20 02:54:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:54:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 02:54:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 02:54:59 --> Model Class Initialized
INFO - 2024-01-20 02:54:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 02:54:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 02:54:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 02:54:59 --> Final output sent to browser
DEBUG - 2024-01-20 02:54:59 --> Total execution time: 0.2302
INFO - 2024-01-20 02:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 02:54:59 --> Parser Class Initialized
INFO - 2024-01-20 02:54:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 02:54:59 --> Pagination Class Initialized
INFO - 2024-01-20 02:54:59 --> Form Validation Class Initialized
INFO - 2024-01-20 02:54:59 --> Controller Class Initialized
INFO - 2024-01-20 02:54:59 --> Model Class Initialized
DEBUG - 2024-01-20 02:54:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 02:54:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:54:59 --> Model Class Initialized
DEBUG - 2024-01-20 02:54:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:54:59 --> Model Class Initialized
INFO - 2024-01-20 02:54:59 --> Final output sent to browser
DEBUG - 2024-01-20 02:54:59 --> Total execution time: 0.1558
ERROR - 2024-01-20 02:55:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 02:55:05 --> Config Class Initialized
INFO - 2024-01-20 02:55:05 --> Hooks Class Initialized
DEBUG - 2024-01-20 02:55:05 --> UTF-8 Support Enabled
INFO - 2024-01-20 02:55:05 --> Utf8 Class Initialized
INFO - 2024-01-20 02:55:05 --> URI Class Initialized
INFO - 2024-01-20 02:55:05 --> Router Class Initialized
INFO - 2024-01-20 02:55:05 --> Output Class Initialized
INFO - 2024-01-20 02:55:05 --> Security Class Initialized
DEBUG - 2024-01-20 02:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 02:55:05 --> Input Class Initialized
INFO - 2024-01-20 02:55:05 --> Language Class Initialized
INFO - 2024-01-20 02:55:05 --> Loader Class Initialized
INFO - 2024-01-20 02:55:05 --> Helper loaded: url_helper
INFO - 2024-01-20 02:55:05 --> Helper loaded: file_helper
INFO - 2024-01-20 02:55:05 --> Helper loaded: html_helper
INFO - 2024-01-20 02:55:05 --> Helper loaded: text_helper
INFO - 2024-01-20 02:55:05 --> Helper loaded: form_helper
INFO - 2024-01-20 02:55:05 --> Helper loaded: lang_helper
INFO - 2024-01-20 02:55:05 --> Helper loaded: security_helper
INFO - 2024-01-20 02:55:05 --> Helper loaded: cookie_helper
INFO - 2024-01-20 02:55:05 --> Database Driver Class Initialized
INFO - 2024-01-20 02:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 02:55:05 --> Parser Class Initialized
INFO - 2024-01-20 02:55:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 02:55:05 --> Pagination Class Initialized
INFO - 2024-01-20 02:55:05 --> Form Validation Class Initialized
INFO - 2024-01-20 02:55:05 --> Controller Class Initialized
INFO - 2024-01-20 02:55:05 --> Model Class Initialized
DEBUG - 2024-01-20 02:55:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 02:55:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:55:05 --> Model Class Initialized
DEBUG - 2024-01-20 02:55:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:55:05 --> Model Class Initialized
INFO - 2024-01-20 02:55:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-20 02:55:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:55:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 02:55:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 02:55:05 --> Model Class Initialized
INFO - 2024-01-20 02:55:05 --> Model Class Initialized
INFO - 2024-01-20 02:55:05 --> Model Class Initialized
INFO - 2024-01-20 02:55:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 02:55:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 02:55:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 02:55:05 --> Final output sent to browser
DEBUG - 2024-01-20 02:55:05 --> Total execution time: 0.1500
ERROR - 2024-01-20 02:55:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 02:55:05 --> Config Class Initialized
INFO - 2024-01-20 02:55:05 --> Hooks Class Initialized
DEBUG - 2024-01-20 02:55:05 --> UTF-8 Support Enabled
INFO - 2024-01-20 02:55:05 --> Utf8 Class Initialized
INFO - 2024-01-20 02:55:05 --> URI Class Initialized
INFO - 2024-01-20 02:55:05 --> Router Class Initialized
INFO - 2024-01-20 02:55:05 --> Output Class Initialized
INFO - 2024-01-20 02:55:05 --> Security Class Initialized
DEBUG - 2024-01-20 02:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 02:55:05 --> Input Class Initialized
INFO - 2024-01-20 02:55:05 --> Language Class Initialized
INFO - 2024-01-20 02:55:05 --> Loader Class Initialized
INFO - 2024-01-20 02:55:05 --> Helper loaded: url_helper
INFO - 2024-01-20 02:55:05 --> Helper loaded: file_helper
INFO - 2024-01-20 02:55:05 --> Helper loaded: html_helper
INFO - 2024-01-20 02:55:05 --> Helper loaded: text_helper
INFO - 2024-01-20 02:55:05 --> Helper loaded: form_helper
INFO - 2024-01-20 02:55:05 --> Helper loaded: lang_helper
INFO - 2024-01-20 02:55:05 --> Helper loaded: security_helper
INFO - 2024-01-20 02:55:05 --> Helper loaded: cookie_helper
INFO - 2024-01-20 02:55:05 --> Database Driver Class Initialized
INFO - 2024-01-20 02:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 02:55:05 --> Parser Class Initialized
INFO - 2024-01-20 02:55:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 02:55:05 --> Pagination Class Initialized
INFO - 2024-01-20 02:55:05 --> Form Validation Class Initialized
INFO - 2024-01-20 02:55:05 --> Controller Class Initialized
INFO - 2024-01-20 02:55:05 --> Model Class Initialized
DEBUG - 2024-01-20 02:55:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 02:55:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:55:05 --> Model Class Initialized
DEBUG - 2024-01-20 02:55:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:55:05 --> Model Class Initialized
INFO - 2024-01-20 02:55:05 --> Final output sent to browser
DEBUG - 2024-01-20 02:55:05 --> Total execution time: 0.0410
ERROR - 2024-01-20 02:55:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 02:55:08 --> Config Class Initialized
INFO - 2024-01-20 02:55:08 --> Hooks Class Initialized
DEBUG - 2024-01-20 02:55:08 --> UTF-8 Support Enabled
INFO - 2024-01-20 02:55:08 --> Utf8 Class Initialized
INFO - 2024-01-20 02:55:08 --> URI Class Initialized
INFO - 2024-01-20 02:55:08 --> Router Class Initialized
INFO - 2024-01-20 02:55:08 --> Output Class Initialized
INFO - 2024-01-20 02:55:08 --> Security Class Initialized
DEBUG - 2024-01-20 02:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 02:55:08 --> Input Class Initialized
INFO - 2024-01-20 02:55:08 --> Language Class Initialized
INFO - 2024-01-20 02:55:09 --> Loader Class Initialized
INFO - 2024-01-20 02:55:09 --> Helper loaded: url_helper
INFO - 2024-01-20 02:55:09 --> Helper loaded: file_helper
INFO - 2024-01-20 02:55:09 --> Helper loaded: html_helper
INFO - 2024-01-20 02:55:09 --> Helper loaded: text_helper
INFO - 2024-01-20 02:55:09 --> Helper loaded: form_helper
INFO - 2024-01-20 02:55:09 --> Helper loaded: lang_helper
INFO - 2024-01-20 02:55:09 --> Helper loaded: security_helper
INFO - 2024-01-20 02:55:09 --> Helper loaded: cookie_helper
INFO - 2024-01-20 02:55:09 --> Database Driver Class Initialized
INFO - 2024-01-20 02:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 02:55:09 --> Parser Class Initialized
INFO - 2024-01-20 02:55:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 02:55:09 --> Pagination Class Initialized
INFO - 2024-01-20 02:55:09 --> Form Validation Class Initialized
INFO - 2024-01-20 02:55:09 --> Controller Class Initialized
INFO - 2024-01-20 02:55:09 --> Model Class Initialized
DEBUG - 2024-01-20 02:55:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 02:55:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:55:09 --> Model Class Initialized
DEBUG - 2024-01-20 02:55:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:55:09 --> Model Class Initialized
INFO - 2024-01-20 02:55:09 --> Final output sent to browser
DEBUG - 2024-01-20 02:55:09 --> Total execution time: 0.1157
ERROR - 2024-01-20 02:55:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 02:55:27 --> Config Class Initialized
INFO - 2024-01-20 02:55:27 --> Hooks Class Initialized
DEBUG - 2024-01-20 02:55:27 --> UTF-8 Support Enabled
INFO - 2024-01-20 02:55:27 --> Utf8 Class Initialized
INFO - 2024-01-20 02:55:27 --> URI Class Initialized
INFO - 2024-01-20 02:55:27 --> Router Class Initialized
INFO - 2024-01-20 02:55:27 --> Output Class Initialized
INFO - 2024-01-20 02:55:27 --> Security Class Initialized
DEBUG - 2024-01-20 02:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 02:55:27 --> Input Class Initialized
INFO - 2024-01-20 02:55:27 --> Language Class Initialized
INFO - 2024-01-20 02:55:27 --> Loader Class Initialized
INFO - 2024-01-20 02:55:27 --> Helper loaded: url_helper
INFO - 2024-01-20 02:55:27 --> Helper loaded: file_helper
INFO - 2024-01-20 02:55:27 --> Helper loaded: html_helper
INFO - 2024-01-20 02:55:27 --> Helper loaded: text_helper
INFO - 2024-01-20 02:55:27 --> Helper loaded: form_helper
INFO - 2024-01-20 02:55:27 --> Helper loaded: lang_helper
INFO - 2024-01-20 02:55:27 --> Helper loaded: security_helper
INFO - 2024-01-20 02:55:27 --> Helper loaded: cookie_helper
INFO - 2024-01-20 02:55:27 --> Database Driver Class Initialized
INFO - 2024-01-20 02:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 02:55:27 --> Parser Class Initialized
INFO - 2024-01-20 02:55:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 02:55:27 --> Pagination Class Initialized
INFO - 2024-01-20 02:55:27 --> Form Validation Class Initialized
INFO - 2024-01-20 02:55:27 --> Controller Class Initialized
INFO - 2024-01-20 02:55:27 --> Model Class Initialized
DEBUG - 2024-01-20 02:55:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 02:55:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:55:27 --> Model Class Initialized
DEBUG - 2024-01-20 02:55:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:55:27 --> Model Class Initialized
DEBUG - 2024-01-20 02:55:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:55:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-01-20 02:55:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:55:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 02:55:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 02:55:27 --> Model Class Initialized
INFO - 2024-01-20 02:55:27 --> Model Class Initialized
INFO - 2024-01-20 02:55:27 --> Model Class Initialized
INFO - 2024-01-20 02:55:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 02:55:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 02:55:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 02:55:27 --> Final output sent to browser
DEBUG - 2024-01-20 02:55:27 --> Total execution time: 0.1578
ERROR - 2024-01-20 02:56:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 02:56:42 --> Config Class Initialized
INFO - 2024-01-20 02:56:42 --> Hooks Class Initialized
DEBUG - 2024-01-20 02:56:42 --> UTF-8 Support Enabled
INFO - 2024-01-20 02:56:42 --> Utf8 Class Initialized
INFO - 2024-01-20 02:56:42 --> URI Class Initialized
INFO - 2024-01-20 02:56:42 --> Router Class Initialized
INFO - 2024-01-20 02:56:42 --> Output Class Initialized
INFO - 2024-01-20 02:56:42 --> Security Class Initialized
DEBUG - 2024-01-20 02:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 02:56:42 --> Input Class Initialized
INFO - 2024-01-20 02:56:42 --> Language Class Initialized
INFO - 2024-01-20 02:56:42 --> Loader Class Initialized
INFO - 2024-01-20 02:56:42 --> Helper loaded: url_helper
INFO - 2024-01-20 02:56:42 --> Helper loaded: file_helper
INFO - 2024-01-20 02:56:42 --> Helper loaded: html_helper
INFO - 2024-01-20 02:56:42 --> Helper loaded: text_helper
INFO - 2024-01-20 02:56:42 --> Helper loaded: form_helper
INFO - 2024-01-20 02:56:42 --> Helper loaded: lang_helper
INFO - 2024-01-20 02:56:42 --> Helper loaded: security_helper
INFO - 2024-01-20 02:56:42 --> Helper loaded: cookie_helper
INFO - 2024-01-20 02:56:42 --> Database Driver Class Initialized
INFO - 2024-01-20 02:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 02:56:42 --> Parser Class Initialized
INFO - 2024-01-20 02:56:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 02:56:42 --> Pagination Class Initialized
INFO - 2024-01-20 02:56:42 --> Form Validation Class Initialized
INFO - 2024-01-20 02:56:42 --> Controller Class Initialized
INFO - 2024-01-20 02:56:42 --> Model Class Initialized
DEBUG - 2024-01-20 02:56:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 02:56:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:56:42 --> Model Class Initialized
DEBUG - 2024-01-20 02:56:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:56:42 --> Model Class Initialized
INFO - 2024-01-20 02:56:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-20 02:56:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:56:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 02:56:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 02:56:42 --> Model Class Initialized
INFO - 2024-01-20 02:56:42 --> Model Class Initialized
INFO - 2024-01-20 02:56:42 --> Model Class Initialized
INFO - 2024-01-20 02:56:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 02:56:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 02:56:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 02:56:42 --> Final output sent to browser
DEBUG - 2024-01-20 02:56:42 --> Total execution time: 0.1560
ERROR - 2024-01-20 02:56:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 02:56:44 --> Config Class Initialized
INFO - 2024-01-20 02:56:44 --> Hooks Class Initialized
DEBUG - 2024-01-20 02:56:44 --> UTF-8 Support Enabled
INFO - 2024-01-20 02:56:44 --> Utf8 Class Initialized
INFO - 2024-01-20 02:56:44 --> URI Class Initialized
INFO - 2024-01-20 02:56:44 --> Router Class Initialized
INFO - 2024-01-20 02:56:44 --> Output Class Initialized
INFO - 2024-01-20 02:56:44 --> Security Class Initialized
DEBUG - 2024-01-20 02:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 02:56:44 --> Input Class Initialized
INFO - 2024-01-20 02:56:44 --> Language Class Initialized
INFO - 2024-01-20 02:56:44 --> Loader Class Initialized
INFO - 2024-01-20 02:56:44 --> Helper loaded: url_helper
INFO - 2024-01-20 02:56:44 --> Helper loaded: file_helper
INFO - 2024-01-20 02:56:44 --> Helper loaded: html_helper
INFO - 2024-01-20 02:56:44 --> Helper loaded: text_helper
INFO - 2024-01-20 02:56:44 --> Helper loaded: form_helper
INFO - 2024-01-20 02:56:44 --> Helper loaded: lang_helper
INFO - 2024-01-20 02:56:44 --> Helper loaded: security_helper
INFO - 2024-01-20 02:56:44 --> Helper loaded: cookie_helper
INFO - 2024-01-20 02:56:44 --> Database Driver Class Initialized
INFO - 2024-01-20 02:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 02:56:44 --> Parser Class Initialized
INFO - 2024-01-20 02:56:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 02:56:44 --> Pagination Class Initialized
INFO - 2024-01-20 02:56:44 --> Form Validation Class Initialized
INFO - 2024-01-20 02:56:44 --> Controller Class Initialized
INFO - 2024-01-20 02:56:44 --> Model Class Initialized
DEBUG - 2024-01-20 02:56:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 02:56:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:56:44 --> Model Class Initialized
DEBUG - 2024-01-20 02:56:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:56:44 --> Model Class Initialized
INFO - 2024-01-20 02:56:44 --> Final output sent to browser
DEBUG - 2024-01-20 02:56:44 --> Total execution time: 0.0424
ERROR - 2024-01-20 02:56:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 02:56:57 --> Config Class Initialized
INFO - 2024-01-20 02:56:57 --> Hooks Class Initialized
DEBUG - 2024-01-20 02:56:57 --> UTF-8 Support Enabled
INFO - 2024-01-20 02:56:57 --> Utf8 Class Initialized
INFO - 2024-01-20 02:56:57 --> URI Class Initialized
INFO - 2024-01-20 02:56:57 --> Router Class Initialized
INFO - 2024-01-20 02:56:57 --> Output Class Initialized
INFO - 2024-01-20 02:56:57 --> Security Class Initialized
DEBUG - 2024-01-20 02:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 02:56:57 --> Input Class Initialized
INFO - 2024-01-20 02:56:57 --> Language Class Initialized
INFO - 2024-01-20 02:56:57 --> Loader Class Initialized
INFO - 2024-01-20 02:56:57 --> Helper loaded: url_helper
INFO - 2024-01-20 02:56:57 --> Helper loaded: file_helper
INFO - 2024-01-20 02:56:57 --> Helper loaded: html_helper
INFO - 2024-01-20 02:56:57 --> Helper loaded: text_helper
INFO - 2024-01-20 02:56:57 --> Helper loaded: form_helper
INFO - 2024-01-20 02:56:57 --> Helper loaded: lang_helper
INFO - 2024-01-20 02:56:57 --> Helper loaded: security_helper
INFO - 2024-01-20 02:56:57 --> Helper loaded: cookie_helper
INFO - 2024-01-20 02:56:57 --> Database Driver Class Initialized
INFO - 2024-01-20 02:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 02:56:57 --> Parser Class Initialized
INFO - 2024-01-20 02:56:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 02:56:57 --> Pagination Class Initialized
INFO - 2024-01-20 02:56:57 --> Form Validation Class Initialized
INFO - 2024-01-20 02:56:57 --> Controller Class Initialized
INFO - 2024-01-20 02:56:57 --> Model Class Initialized
DEBUG - 2024-01-20 02:56:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 02:56:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:56:57 --> Model Class Initialized
DEBUG - 2024-01-20 02:56:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:56:57 --> Model Class Initialized
INFO - 2024-01-20 02:56:57 --> Final output sent to browser
DEBUG - 2024-01-20 02:56:57 --> Total execution time: 0.1212
ERROR - 2024-01-20 02:57:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 02:57:15 --> Config Class Initialized
INFO - 2024-01-20 02:57:15 --> Hooks Class Initialized
DEBUG - 2024-01-20 02:57:15 --> UTF-8 Support Enabled
INFO - 2024-01-20 02:57:15 --> Utf8 Class Initialized
INFO - 2024-01-20 02:57:15 --> URI Class Initialized
INFO - 2024-01-20 02:57:15 --> Router Class Initialized
INFO - 2024-01-20 02:57:15 --> Output Class Initialized
INFO - 2024-01-20 02:57:15 --> Security Class Initialized
DEBUG - 2024-01-20 02:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 02:57:15 --> Input Class Initialized
INFO - 2024-01-20 02:57:15 --> Language Class Initialized
INFO - 2024-01-20 02:57:15 --> Loader Class Initialized
INFO - 2024-01-20 02:57:15 --> Helper loaded: url_helper
INFO - 2024-01-20 02:57:15 --> Helper loaded: file_helper
INFO - 2024-01-20 02:57:15 --> Helper loaded: html_helper
INFO - 2024-01-20 02:57:15 --> Helper loaded: text_helper
INFO - 2024-01-20 02:57:15 --> Helper loaded: form_helper
INFO - 2024-01-20 02:57:15 --> Helper loaded: lang_helper
INFO - 2024-01-20 02:57:15 --> Helper loaded: security_helper
INFO - 2024-01-20 02:57:15 --> Helper loaded: cookie_helper
INFO - 2024-01-20 02:57:15 --> Database Driver Class Initialized
INFO - 2024-01-20 02:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 02:57:15 --> Parser Class Initialized
INFO - 2024-01-20 02:57:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 02:57:15 --> Pagination Class Initialized
INFO - 2024-01-20 02:57:15 --> Form Validation Class Initialized
INFO - 2024-01-20 02:57:15 --> Controller Class Initialized
INFO - 2024-01-20 02:57:15 --> Model Class Initialized
DEBUG - 2024-01-20 02:57:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 02:57:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:57:15 --> Model Class Initialized
DEBUG - 2024-01-20 02:57:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:57:15 --> Model Class Initialized
DEBUG - 2024-01-20 02:57:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:57:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-01-20 02:57:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:57:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 02:57:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 02:57:15 --> Model Class Initialized
INFO - 2024-01-20 02:57:15 --> Model Class Initialized
INFO - 2024-01-20 02:57:15 --> Model Class Initialized
INFO - 2024-01-20 02:57:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 02:57:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 02:57:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 02:57:15 --> Final output sent to browser
DEBUG - 2024-01-20 02:57:15 --> Total execution time: 0.1667
ERROR - 2024-01-20 02:59:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 02:59:52 --> Config Class Initialized
INFO - 2024-01-20 02:59:52 --> Hooks Class Initialized
DEBUG - 2024-01-20 02:59:52 --> UTF-8 Support Enabled
INFO - 2024-01-20 02:59:52 --> Utf8 Class Initialized
INFO - 2024-01-20 02:59:52 --> URI Class Initialized
INFO - 2024-01-20 02:59:52 --> Router Class Initialized
INFO - 2024-01-20 02:59:52 --> Output Class Initialized
INFO - 2024-01-20 02:59:52 --> Security Class Initialized
DEBUG - 2024-01-20 02:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 02:59:52 --> Input Class Initialized
INFO - 2024-01-20 02:59:52 --> Language Class Initialized
INFO - 2024-01-20 02:59:52 --> Loader Class Initialized
INFO - 2024-01-20 02:59:52 --> Helper loaded: url_helper
INFO - 2024-01-20 02:59:52 --> Helper loaded: file_helper
INFO - 2024-01-20 02:59:52 --> Helper loaded: html_helper
INFO - 2024-01-20 02:59:52 --> Helper loaded: text_helper
INFO - 2024-01-20 02:59:52 --> Helper loaded: form_helper
INFO - 2024-01-20 02:59:52 --> Helper loaded: lang_helper
INFO - 2024-01-20 02:59:52 --> Helper loaded: security_helper
INFO - 2024-01-20 02:59:52 --> Helper loaded: cookie_helper
INFO - 2024-01-20 02:59:52 --> Database Driver Class Initialized
INFO - 2024-01-20 02:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 02:59:52 --> Parser Class Initialized
INFO - 2024-01-20 02:59:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 02:59:52 --> Pagination Class Initialized
INFO - 2024-01-20 02:59:52 --> Form Validation Class Initialized
INFO - 2024-01-20 02:59:52 --> Controller Class Initialized
INFO - 2024-01-20 02:59:52 --> Model Class Initialized
DEBUG - 2024-01-20 02:59:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 02:59:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:59:52 --> Model Class Initialized
DEBUG - 2024-01-20 02:59:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:59:52 --> Model Class Initialized
INFO - 2024-01-20 02:59:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-20 02:59:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:59:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 02:59:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 02:59:52 --> Model Class Initialized
INFO - 2024-01-20 02:59:52 --> Model Class Initialized
INFO - 2024-01-20 02:59:52 --> Model Class Initialized
INFO - 2024-01-20 02:59:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 02:59:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 02:59:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 02:59:52 --> Final output sent to browser
DEBUG - 2024-01-20 02:59:52 --> Total execution time: 0.1539
ERROR - 2024-01-20 02:59:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 02:59:54 --> Config Class Initialized
INFO - 2024-01-20 02:59:54 --> Hooks Class Initialized
DEBUG - 2024-01-20 02:59:54 --> UTF-8 Support Enabled
INFO - 2024-01-20 02:59:54 --> Utf8 Class Initialized
INFO - 2024-01-20 02:59:54 --> URI Class Initialized
INFO - 2024-01-20 02:59:54 --> Router Class Initialized
INFO - 2024-01-20 02:59:54 --> Output Class Initialized
INFO - 2024-01-20 02:59:54 --> Security Class Initialized
DEBUG - 2024-01-20 02:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 02:59:54 --> Input Class Initialized
INFO - 2024-01-20 02:59:54 --> Language Class Initialized
INFO - 2024-01-20 02:59:54 --> Loader Class Initialized
INFO - 2024-01-20 02:59:54 --> Helper loaded: url_helper
INFO - 2024-01-20 02:59:54 --> Helper loaded: file_helper
INFO - 2024-01-20 02:59:54 --> Helper loaded: html_helper
INFO - 2024-01-20 02:59:54 --> Helper loaded: text_helper
INFO - 2024-01-20 02:59:54 --> Helper loaded: form_helper
INFO - 2024-01-20 02:59:54 --> Helper loaded: lang_helper
INFO - 2024-01-20 02:59:54 --> Helper loaded: security_helper
INFO - 2024-01-20 02:59:54 --> Helper loaded: cookie_helper
INFO - 2024-01-20 02:59:54 --> Database Driver Class Initialized
INFO - 2024-01-20 02:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 02:59:54 --> Parser Class Initialized
INFO - 2024-01-20 02:59:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 02:59:54 --> Pagination Class Initialized
INFO - 2024-01-20 02:59:54 --> Form Validation Class Initialized
INFO - 2024-01-20 02:59:54 --> Controller Class Initialized
INFO - 2024-01-20 02:59:54 --> Model Class Initialized
DEBUG - 2024-01-20 02:59:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 02:59:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:59:54 --> Model Class Initialized
DEBUG - 2024-01-20 02:59:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:59:54 --> Model Class Initialized
INFO - 2024-01-20 02:59:54 --> Final output sent to browser
DEBUG - 2024-01-20 02:59:54 --> Total execution time: 0.0437
ERROR - 2024-01-20 02:59:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 02:59:57 --> Config Class Initialized
INFO - 2024-01-20 02:59:57 --> Hooks Class Initialized
DEBUG - 2024-01-20 02:59:57 --> UTF-8 Support Enabled
INFO - 2024-01-20 02:59:57 --> Utf8 Class Initialized
INFO - 2024-01-20 02:59:57 --> URI Class Initialized
INFO - 2024-01-20 02:59:57 --> Router Class Initialized
INFO - 2024-01-20 02:59:57 --> Output Class Initialized
INFO - 2024-01-20 02:59:57 --> Security Class Initialized
DEBUG - 2024-01-20 02:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 02:59:57 --> Input Class Initialized
INFO - 2024-01-20 02:59:57 --> Language Class Initialized
INFO - 2024-01-20 02:59:57 --> Loader Class Initialized
INFO - 2024-01-20 02:59:57 --> Helper loaded: url_helper
INFO - 2024-01-20 02:59:57 --> Helper loaded: file_helper
INFO - 2024-01-20 02:59:57 --> Helper loaded: html_helper
INFO - 2024-01-20 02:59:57 --> Helper loaded: text_helper
INFO - 2024-01-20 02:59:57 --> Helper loaded: form_helper
INFO - 2024-01-20 02:59:57 --> Helper loaded: lang_helper
INFO - 2024-01-20 02:59:57 --> Helper loaded: security_helper
INFO - 2024-01-20 02:59:57 --> Helper loaded: cookie_helper
INFO - 2024-01-20 02:59:57 --> Database Driver Class Initialized
INFO - 2024-01-20 02:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 02:59:57 --> Parser Class Initialized
INFO - 2024-01-20 02:59:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 02:59:57 --> Pagination Class Initialized
INFO - 2024-01-20 02:59:57 --> Form Validation Class Initialized
INFO - 2024-01-20 02:59:57 --> Controller Class Initialized
INFO - 2024-01-20 02:59:57 --> Model Class Initialized
DEBUG - 2024-01-20 02:59:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 02:59:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:59:57 --> Model Class Initialized
DEBUG - 2024-01-20 02:59:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 02:59:57 --> Model Class Initialized
INFO - 2024-01-20 02:59:57 --> Final output sent to browser
DEBUG - 2024-01-20 02:59:57 --> Total execution time: 0.1121
ERROR - 2024-01-20 03:00:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 03:00:40 --> Config Class Initialized
INFO - 2024-01-20 03:00:40 --> Hooks Class Initialized
DEBUG - 2024-01-20 03:00:40 --> UTF-8 Support Enabled
INFO - 2024-01-20 03:00:40 --> Utf8 Class Initialized
INFO - 2024-01-20 03:00:40 --> URI Class Initialized
DEBUG - 2024-01-20 03:00:40 --> No URI present. Default controller set.
INFO - 2024-01-20 03:00:40 --> Router Class Initialized
INFO - 2024-01-20 03:00:40 --> Output Class Initialized
INFO - 2024-01-20 03:00:40 --> Security Class Initialized
DEBUG - 2024-01-20 03:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 03:00:40 --> Input Class Initialized
INFO - 2024-01-20 03:00:40 --> Language Class Initialized
INFO - 2024-01-20 03:00:40 --> Loader Class Initialized
INFO - 2024-01-20 03:00:40 --> Helper loaded: url_helper
INFO - 2024-01-20 03:00:40 --> Helper loaded: file_helper
INFO - 2024-01-20 03:00:40 --> Helper loaded: html_helper
INFO - 2024-01-20 03:00:40 --> Helper loaded: text_helper
INFO - 2024-01-20 03:00:40 --> Helper loaded: form_helper
INFO - 2024-01-20 03:00:40 --> Helper loaded: lang_helper
INFO - 2024-01-20 03:00:40 --> Helper loaded: security_helper
INFO - 2024-01-20 03:00:40 --> Helper loaded: cookie_helper
INFO - 2024-01-20 03:00:40 --> Database Driver Class Initialized
INFO - 2024-01-20 03:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 03:00:40 --> Parser Class Initialized
INFO - 2024-01-20 03:00:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 03:00:40 --> Pagination Class Initialized
INFO - 2024-01-20 03:00:40 --> Form Validation Class Initialized
INFO - 2024-01-20 03:00:40 --> Controller Class Initialized
INFO - 2024-01-20 03:00:40 --> Model Class Initialized
DEBUG - 2024-01-20 03:00:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:00:40 --> Model Class Initialized
DEBUG - 2024-01-20 03:00:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:00:40 --> Model Class Initialized
INFO - 2024-01-20 03:00:40 --> Model Class Initialized
INFO - 2024-01-20 03:00:40 --> Model Class Initialized
INFO - 2024-01-20 03:00:40 --> Model Class Initialized
DEBUG - 2024-01-20 03:00:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 03:00:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:00:40 --> Model Class Initialized
INFO - 2024-01-20 03:00:40 --> Model Class Initialized
INFO - 2024-01-20 03:00:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-20 03:00:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:00:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 03:00:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 03:00:40 --> Model Class Initialized
INFO - 2024-01-20 03:00:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 03:00:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 03:00:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 03:00:40 --> Final output sent to browser
DEBUG - 2024-01-20 03:00:40 --> Total execution time: 0.2349
ERROR - 2024-01-20 03:00:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 03:00:45 --> Config Class Initialized
INFO - 2024-01-20 03:00:45 --> Hooks Class Initialized
DEBUG - 2024-01-20 03:00:45 --> UTF-8 Support Enabled
INFO - 2024-01-20 03:00:45 --> Utf8 Class Initialized
INFO - 2024-01-20 03:00:45 --> URI Class Initialized
INFO - 2024-01-20 03:00:45 --> Router Class Initialized
INFO - 2024-01-20 03:00:45 --> Output Class Initialized
INFO - 2024-01-20 03:00:45 --> Security Class Initialized
DEBUG - 2024-01-20 03:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 03:00:45 --> Input Class Initialized
INFO - 2024-01-20 03:00:45 --> Language Class Initialized
INFO - 2024-01-20 03:00:45 --> Loader Class Initialized
INFO - 2024-01-20 03:00:45 --> Helper loaded: url_helper
INFO - 2024-01-20 03:00:45 --> Helper loaded: file_helper
INFO - 2024-01-20 03:00:45 --> Helper loaded: html_helper
INFO - 2024-01-20 03:00:45 --> Helper loaded: text_helper
INFO - 2024-01-20 03:00:45 --> Helper loaded: form_helper
INFO - 2024-01-20 03:00:45 --> Helper loaded: lang_helper
INFO - 2024-01-20 03:00:45 --> Helper loaded: security_helper
INFO - 2024-01-20 03:00:45 --> Helper loaded: cookie_helper
INFO - 2024-01-20 03:00:45 --> Database Driver Class Initialized
INFO - 2024-01-20 03:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 03:00:45 --> Parser Class Initialized
INFO - 2024-01-20 03:00:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 03:00:45 --> Pagination Class Initialized
INFO - 2024-01-20 03:00:45 --> Form Validation Class Initialized
INFO - 2024-01-20 03:00:45 --> Controller Class Initialized
INFO - 2024-01-20 03:00:45 --> Model Class Initialized
DEBUG - 2024-01-20 03:00:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 03:00:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:00:45 --> Model Class Initialized
DEBUG - 2024-01-20 03:00:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:00:45 --> Model Class Initialized
INFO - 2024-01-20 03:00:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-20 03:00:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:00:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 03:00:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 03:00:45 --> Model Class Initialized
INFO - 2024-01-20 03:00:45 --> Model Class Initialized
INFO - 2024-01-20 03:00:45 --> Model Class Initialized
INFO - 2024-01-20 03:00:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 03:00:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 03:00:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 03:00:45 --> Final output sent to browser
DEBUG - 2024-01-20 03:00:45 --> Total execution time: 0.1434
ERROR - 2024-01-20 03:00:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 03:00:46 --> Config Class Initialized
INFO - 2024-01-20 03:00:46 --> Hooks Class Initialized
DEBUG - 2024-01-20 03:00:46 --> UTF-8 Support Enabled
INFO - 2024-01-20 03:00:46 --> Utf8 Class Initialized
INFO - 2024-01-20 03:00:46 --> URI Class Initialized
INFO - 2024-01-20 03:00:46 --> Router Class Initialized
INFO - 2024-01-20 03:00:46 --> Output Class Initialized
INFO - 2024-01-20 03:00:46 --> Security Class Initialized
DEBUG - 2024-01-20 03:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 03:00:46 --> Input Class Initialized
INFO - 2024-01-20 03:00:46 --> Language Class Initialized
INFO - 2024-01-20 03:00:46 --> Loader Class Initialized
INFO - 2024-01-20 03:00:46 --> Helper loaded: url_helper
INFO - 2024-01-20 03:00:46 --> Helper loaded: file_helper
INFO - 2024-01-20 03:00:46 --> Helper loaded: html_helper
INFO - 2024-01-20 03:00:46 --> Helper loaded: text_helper
INFO - 2024-01-20 03:00:46 --> Helper loaded: form_helper
INFO - 2024-01-20 03:00:46 --> Helper loaded: lang_helper
INFO - 2024-01-20 03:00:46 --> Helper loaded: security_helper
INFO - 2024-01-20 03:00:46 --> Helper loaded: cookie_helper
INFO - 2024-01-20 03:00:46 --> Database Driver Class Initialized
INFO - 2024-01-20 03:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 03:00:46 --> Parser Class Initialized
INFO - 2024-01-20 03:00:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 03:00:46 --> Pagination Class Initialized
INFO - 2024-01-20 03:00:46 --> Form Validation Class Initialized
INFO - 2024-01-20 03:00:46 --> Controller Class Initialized
INFO - 2024-01-20 03:00:46 --> Model Class Initialized
DEBUG - 2024-01-20 03:00:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 03:00:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:00:46 --> Model Class Initialized
DEBUG - 2024-01-20 03:00:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:00:46 --> Model Class Initialized
INFO - 2024-01-20 03:00:46 --> Final output sent to browser
DEBUG - 2024-01-20 03:00:46 --> Total execution time: 0.0405
ERROR - 2024-01-20 03:00:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 03:00:54 --> Config Class Initialized
INFO - 2024-01-20 03:00:54 --> Hooks Class Initialized
DEBUG - 2024-01-20 03:00:54 --> UTF-8 Support Enabled
INFO - 2024-01-20 03:00:54 --> Utf8 Class Initialized
INFO - 2024-01-20 03:00:54 --> URI Class Initialized
INFO - 2024-01-20 03:00:54 --> Router Class Initialized
INFO - 2024-01-20 03:00:54 --> Output Class Initialized
INFO - 2024-01-20 03:00:54 --> Security Class Initialized
DEBUG - 2024-01-20 03:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 03:00:54 --> Input Class Initialized
INFO - 2024-01-20 03:00:54 --> Language Class Initialized
INFO - 2024-01-20 03:00:54 --> Loader Class Initialized
INFO - 2024-01-20 03:00:54 --> Helper loaded: url_helper
INFO - 2024-01-20 03:00:54 --> Helper loaded: file_helper
INFO - 2024-01-20 03:00:54 --> Helper loaded: html_helper
INFO - 2024-01-20 03:00:54 --> Helper loaded: text_helper
INFO - 2024-01-20 03:00:54 --> Helper loaded: form_helper
INFO - 2024-01-20 03:00:54 --> Helper loaded: lang_helper
INFO - 2024-01-20 03:00:54 --> Helper loaded: security_helper
INFO - 2024-01-20 03:00:54 --> Helper loaded: cookie_helper
INFO - 2024-01-20 03:00:54 --> Database Driver Class Initialized
INFO - 2024-01-20 03:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 03:00:54 --> Parser Class Initialized
INFO - 2024-01-20 03:00:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 03:00:54 --> Pagination Class Initialized
INFO - 2024-01-20 03:00:54 --> Form Validation Class Initialized
INFO - 2024-01-20 03:00:54 --> Controller Class Initialized
INFO - 2024-01-20 03:00:54 --> Model Class Initialized
DEBUG - 2024-01-20 03:00:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 03:00:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:00:54 --> Model Class Initialized
DEBUG - 2024-01-20 03:00:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:00:54 --> Model Class Initialized
INFO - 2024-01-20 03:00:54 --> Final output sent to browser
DEBUG - 2024-01-20 03:00:54 --> Total execution time: 0.1192
ERROR - 2024-01-20 03:01:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 03:01:17 --> Config Class Initialized
INFO - 2024-01-20 03:01:17 --> Hooks Class Initialized
DEBUG - 2024-01-20 03:01:17 --> UTF-8 Support Enabled
INFO - 2024-01-20 03:01:17 --> Utf8 Class Initialized
INFO - 2024-01-20 03:01:17 --> URI Class Initialized
INFO - 2024-01-20 03:01:17 --> Router Class Initialized
INFO - 2024-01-20 03:01:17 --> Output Class Initialized
INFO - 2024-01-20 03:01:17 --> Security Class Initialized
DEBUG - 2024-01-20 03:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 03:01:17 --> Input Class Initialized
INFO - 2024-01-20 03:01:17 --> Language Class Initialized
INFO - 2024-01-20 03:01:17 --> Loader Class Initialized
INFO - 2024-01-20 03:01:17 --> Helper loaded: url_helper
INFO - 2024-01-20 03:01:17 --> Helper loaded: file_helper
INFO - 2024-01-20 03:01:17 --> Helper loaded: html_helper
INFO - 2024-01-20 03:01:17 --> Helper loaded: text_helper
INFO - 2024-01-20 03:01:17 --> Helper loaded: form_helper
INFO - 2024-01-20 03:01:17 --> Helper loaded: lang_helper
INFO - 2024-01-20 03:01:17 --> Helper loaded: security_helper
INFO - 2024-01-20 03:01:17 --> Helper loaded: cookie_helper
INFO - 2024-01-20 03:01:17 --> Database Driver Class Initialized
INFO - 2024-01-20 03:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 03:01:17 --> Parser Class Initialized
INFO - 2024-01-20 03:01:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 03:01:17 --> Pagination Class Initialized
INFO - 2024-01-20 03:01:17 --> Form Validation Class Initialized
INFO - 2024-01-20 03:01:17 --> Controller Class Initialized
INFO - 2024-01-20 03:01:17 --> Model Class Initialized
DEBUG - 2024-01-20 03:01:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 03:01:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:01:17 --> Model Class Initialized
DEBUG - 2024-01-20 03:01:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:01:17 --> Model Class Initialized
DEBUG - 2024-01-20 03:01:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:01:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-01-20 03:01:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:01:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 03:01:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 03:01:17 --> Model Class Initialized
INFO - 2024-01-20 03:01:17 --> Model Class Initialized
INFO - 2024-01-20 03:01:17 --> Model Class Initialized
INFO - 2024-01-20 03:01:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 03:01:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 03:01:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 03:01:17 --> Final output sent to browser
DEBUG - 2024-01-20 03:01:17 --> Total execution time: 0.1588
ERROR - 2024-01-20 03:08:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 03:08:43 --> Config Class Initialized
INFO - 2024-01-20 03:08:43 --> Hooks Class Initialized
DEBUG - 2024-01-20 03:08:43 --> UTF-8 Support Enabled
INFO - 2024-01-20 03:08:43 --> Utf8 Class Initialized
INFO - 2024-01-20 03:08:43 --> URI Class Initialized
INFO - 2024-01-20 03:08:43 --> Router Class Initialized
INFO - 2024-01-20 03:08:43 --> Output Class Initialized
INFO - 2024-01-20 03:08:43 --> Security Class Initialized
DEBUG - 2024-01-20 03:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 03:08:43 --> Input Class Initialized
INFO - 2024-01-20 03:08:43 --> Language Class Initialized
INFO - 2024-01-20 03:08:43 --> Loader Class Initialized
INFO - 2024-01-20 03:08:43 --> Helper loaded: url_helper
INFO - 2024-01-20 03:08:43 --> Helper loaded: file_helper
INFO - 2024-01-20 03:08:43 --> Helper loaded: html_helper
INFO - 2024-01-20 03:08:43 --> Helper loaded: text_helper
INFO - 2024-01-20 03:08:43 --> Helper loaded: form_helper
INFO - 2024-01-20 03:08:43 --> Helper loaded: lang_helper
INFO - 2024-01-20 03:08:43 --> Helper loaded: security_helper
INFO - 2024-01-20 03:08:43 --> Helper loaded: cookie_helper
INFO - 2024-01-20 03:08:43 --> Database Driver Class Initialized
INFO - 2024-01-20 03:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 03:08:43 --> Parser Class Initialized
INFO - 2024-01-20 03:08:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 03:08:43 --> Pagination Class Initialized
INFO - 2024-01-20 03:08:43 --> Form Validation Class Initialized
INFO - 2024-01-20 03:08:43 --> Controller Class Initialized
INFO - 2024-01-20 03:08:43 --> Model Class Initialized
DEBUG - 2024-01-20 03:08:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 03:08:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:08:43 --> Model Class Initialized
DEBUG - 2024-01-20 03:08:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:08:43 --> Model Class Initialized
INFO - 2024-01-20 03:08:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-20 03:08:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:08:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 03:08:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 03:08:43 --> Model Class Initialized
INFO - 2024-01-20 03:08:43 --> Model Class Initialized
INFO - 2024-01-20 03:08:43 --> Model Class Initialized
INFO - 2024-01-20 03:08:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 03:08:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 03:08:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 03:08:43 --> Final output sent to browser
DEBUG - 2024-01-20 03:08:43 --> Total execution time: 0.1645
ERROR - 2024-01-20 03:08:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 03:08:44 --> Config Class Initialized
INFO - 2024-01-20 03:08:44 --> Hooks Class Initialized
DEBUG - 2024-01-20 03:08:44 --> UTF-8 Support Enabled
INFO - 2024-01-20 03:08:44 --> Utf8 Class Initialized
INFO - 2024-01-20 03:08:44 --> URI Class Initialized
INFO - 2024-01-20 03:08:44 --> Router Class Initialized
INFO - 2024-01-20 03:08:44 --> Output Class Initialized
INFO - 2024-01-20 03:08:44 --> Security Class Initialized
DEBUG - 2024-01-20 03:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 03:08:44 --> Input Class Initialized
INFO - 2024-01-20 03:08:44 --> Language Class Initialized
INFO - 2024-01-20 03:08:44 --> Loader Class Initialized
INFO - 2024-01-20 03:08:44 --> Helper loaded: url_helper
INFO - 2024-01-20 03:08:44 --> Helper loaded: file_helper
INFO - 2024-01-20 03:08:44 --> Helper loaded: html_helper
INFO - 2024-01-20 03:08:44 --> Helper loaded: text_helper
INFO - 2024-01-20 03:08:44 --> Helper loaded: form_helper
INFO - 2024-01-20 03:08:44 --> Helper loaded: lang_helper
INFO - 2024-01-20 03:08:44 --> Helper loaded: security_helper
INFO - 2024-01-20 03:08:44 --> Helper loaded: cookie_helper
INFO - 2024-01-20 03:08:44 --> Database Driver Class Initialized
INFO - 2024-01-20 03:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 03:08:44 --> Parser Class Initialized
INFO - 2024-01-20 03:08:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 03:08:44 --> Pagination Class Initialized
INFO - 2024-01-20 03:08:44 --> Form Validation Class Initialized
INFO - 2024-01-20 03:08:44 --> Controller Class Initialized
INFO - 2024-01-20 03:08:44 --> Model Class Initialized
DEBUG - 2024-01-20 03:08:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 03:08:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:08:44 --> Model Class Initialized
DEBUG - 2024-01-20 03:08:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:08:44 --> Model Class Initialized
INFO - 2024-01-20 03:08:44 --> Final output sent to browser
DEBUG - 2024-01-20 03:08:44 --> Total execution time: 0.0434
ERROR - 2024-01-20 03:08:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 03:08:48 --> Config Class Initialized
INFO - 2024-01-20 03:08:48 --> Hooks Class Initialized
DEBUG - 2024-01-20 03:08:48 --> UTF-8 Support Enabled
INFO - 2024-01-20 03:08:48 --> Utf8 Class Initialized
INFO - 2024-01-20 03:08:48 --> URI Class Initialized
INFO - 2024-01-20 03:08:48 --> Router Class Initialized
INFO - 2024-01-20 03:08:48 --> Output Class Initialized
INFO - 2024-01-20 03:08:48 --> Security Class Initialized
DEBUG - 2024-01-20 03:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 03:08:48 --> Input Class Initialized
INFO - 2024-01-20 03:08:48 --> Language Class Initialized
INFO - 2024-01-20 03:08:48 --> Loader Class Initialized
INFO - 2024-01-20 03:08:48 --> Helper loaded: url_helper
INFO - 2024-01-20 03:08:48 --> Helper loaded: file_helper
INFO - 2024-01-20 03:08:48 --> Helper loaded: html_helper
INFO - 2024-01-20 03:08:48 --> Helper loaded: text_helper
INFO - 2024-01-20 03:08:48 --> Helper loaded: form_helper
INFO - 2024-01-20 03:08:48 --> Helper loaded: lang_helper
INFO - 2024-01-20 03:08:48 --> Helper loaded: security_helper
INFO - 2024-01-20 03:08:48 --> Helper loaded: cookie_helper
INFO - 2024-01-20 03:08:48 --> Database Driver Class Initialized
INFO - 2024-01-20 03:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 03:08:48 --> Parser Class Initialized
INFO - 2024-01-20 03:08:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 03:08:48 --> Pagination Class Initialized
INFO - 2024-01-20 03:08:48 --> Form Validation Class Initialized
INFO - 2024-01-20 03:08:48 --> Controller Class Initialized
INFO - 2024-01-20 03:08:48 --> Model Class Initialized
DEBUG - 2024-01-20 03:08:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 03:08:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:08:48 --> Model Class Initialized
DEBUG - 2024-01-20 03:08:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:08:48 --> Model Class Initialized
INFO - 2024-01-20 03:08:48 --> Final output sent to browser
DEBUG - 2024-01-20 03:08:48 --> Total execution time: 0.1181
ERROR - 2024-01-20 03:09:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 03:09:02 --> Config Class Initialized
INFO - 2024-01-20 03:09:02 --> Hooks Class Initialized
DEBUG - 2024-01-20 03:09:02 --> UTF-8 Support Enabled
INFO - 2024-01-20 03:09:02 --> Utf8 Class Initialized
INFO - 2024-01-20 03:09:02 --> URI Class Initialized
INFO - 2024-01-20 03:09:02 --> Router Class Initialized
INFO - 2024-01-20 03:09:02 --> Output Class Initialized
INFO - 2024-01-20 03:09:02 --> Security Class Initialized
DEBUG - 2024-01-20 03:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 03:09:02 --> Input Class Initialized
INFO - 2024-01-20 03:09:02 --> Language Class Initialized
INFO - 2024-01-20 03:09:02 --> Loader Class Initialized
INFO - 2024-01-20 03:09:02 --> Helper loaded: url_helper
INFO - 2024-01-20 03:09:02 --> Helper loaded: file_helper
INFO - 2024-01-20 03:09:02 --> Helper loaded: html_helper
INFO - 2024-01-20 03:09:02 --> Helper loaded: text_helper
INFO - 2024-01-20 03:09:02 --> Helper loaded: form_helper
INFO - 2024-01-20 03:09:02 --> Helper loaded: lang_helper
INFO - 2024-01-20 03:09:02 --> Helper loaded: security_helper
INFO - 2024-01-20 03:09:02 --> Helper loaded: cookie_helper
INFO - 2024-01-20 03:09:02 --> Database Driver Class Initialized
INFO - 2024-01-20 03:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 03:09:02 --> Parser Class Initialized
INFO - 2024-01-20 03:09:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 03:09:02 --> Pagination Class Initialized
INFO - 2024-01-20 03:09:02 --> Form Validation Class Initialized
INFO - 2024-01-20 03:09:02 --> Controller Class Initialized
INFO - 2024-01-20 03:09:02 --> Model Class Initialized
DEBUG - 2024-01-20 03:09:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 03:09:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:09:02 --> Model Class Initialized
DEBUG - 2024-01-20 03:09:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:09:02 --> Model Class Initialized
DEBUG - 2024-01-20 03:09:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:09:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-01-20 03:09:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:09:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 03:09:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 03:09:03 --> Model Class Initialized
INFO - 2024-01-20 03:09:03 --> Model Class Initialized
INFO - 2024-01-20 03:09:03 --> Model Class Initialized
INFO - 2024-01-20 03:09:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 03:09:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 03:09:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 03:09:03 --> Final output sent to browser
DEBUG - 2024-01-20 03:09:03 --> Total execution time: 0.1706
ERROR - 2024-01-20 03:12:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 03:12:40 --> Config Class Initialized
INFO - 2024-01-20 03:12:40 --> Hooks Class Initialized
DEBUG - 2024-01-20 03:12:40 --> UTF-8 Support Enabled
INFO - 2024-01-20 03:12:40 --> Utf8 Class Initialized
INFO - 2024-01-20 03:12:40 --> URI Class Initialized
INFO - 2024-01-20 03:12:40 --> Router Class Initialized
INFO - 2024-01-20 03:12:40 --> Output Class Initialized
INFO - 2024-01-20 03:12:40 --> Security Class Initialized
DEBUG - 2024-01-20 03:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 03:12:40 --> Input Class Initialized
INFO - 2024-01-20 03:12:40 --> Language Class Initialized
INFO - 2024-01-20 03:12:40 --> Loader Class Initialized
INFO - 2024-01-20 03:12:40 --> Helper loaded: url_helper
INFO - 2024-01-20 03:12:40 --> Helper loaded: file_helper
INFO - 2024-01-20 03:12:40 --> Helper loaded: html_helper
INFO - 2024-01-20 03:12:40 --> Helper loaded: text_helper
INFO - 2024-01-20 03:12:40 --> Helper loaded: form_helper
INFO - 2024-01-20 03:12:40 --> Helper loaded: lang_helper
INFO - 2024-01-20 03:12:40 --> Helper loaded: security_helper
INFO - 2024-01-20 03:12:40 --> Helper loaded: cookie_helper
INFO - 2024-01-20 03:12:40 --> Database Driver Class Initialized
INFO - 2024-01-20 03:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 03:12:40 --> Parser Class Initialized
INFO - 2024-01-20 03:12:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 03:12:40 --> Pagination Class Initialized
INFO - 2024-01-20 03:12:40 --> Form Validation Class Initialized
INFO - 2024-01-20 03:12:40 --> Controller Class Initialized
INFO - 2024-01-20 03:12:40 --> Model Class Initialized
DEBUG - 2024-01-20 03:12:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 03:12:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:12:40 --> Model Class Initialized
DEBUG - 2024-01-20 03:12:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:12:40 --> Model Class Initialized
INFO - 2024-01-20 03:12:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-20 03:12:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:12:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 03:12:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 03:12:40 --> Model Class Initialized
INFO - 2024-01-20 03:12:40 --> Model Class Initialized
INFO - 2024-01-20 03:12:40 --> Model Class Initialized
INFO - 2024-01-20 03:12:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 03:12:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 03:12:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 03:12:40 --> Final output sent to browser
DEBUG - 2024-01-20 03:12:40 --> Total execution time: 0.1562
ERROR - 2024-01-20 03:12:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 03:12:41 --> Config Class Initialized
INFO - 2024-01-20 03:12:41 --> Hooks Class Initialized
DEBUG - 2024-01-20 03:12:41 --> UTF-8 Support Enabled
INFO - 2024-01-20 03:12:41 --> Utf8 Class Initialized
INFO - 2024-01-20 03:12:41 --> URI Class Initialized
INFO - 2024-01-20 03:12:41 --> Router Class Initialized
INFO - 2024-01-20 03:12:41 --> Output Class Initialized
INFO - 2024-01-20 03:12:41 --> Security Class Initialized
DEBUG - 2024-01-20 03:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 03:12:41 --> Input Class Initialized
INFO - 2024-01-20 03:12:41 --> Language Class Initialized
INFO - 2024-01-20 03:12:41 --> Loader Class Initialized
INFO - 2024-01-20 03:12:41 --> Helper loaded: url_helper
INFO - 2024-01-20 03:12:41 --> Helper loaded: file_helper
INFO - 2024-01-20 03:12:41 --> Helper loaded: html_helper
INFO - 2024-01-20 03:12:41 --> Helper loaded: text_helper
INFO - 2024-01-20 03:12:41 --> Helper loaded: form_helper
INFO - 2024-01-20 03:12:41 --> Helper loaded: lang_helper
INFO - 2024-01-20 03:12:41 --> Helper loaded: security_helper
INFO - 2024-01-20 03:12:41 --> Helper loaded: cookie_helper
INFO - 2024-01-20 03:12:41 --> Database Driver Class Initialized
INFO - 2024-01-20 03:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 03:12:41 --> Parser Class Initialized
INFO - 2024-01-20 03:12:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 03:12:41 --> Pagination Class Initialized
INFO - 2024-01-20 03:12:41 --> Form Validation Class Initialized
INFO - 2024-01-20 03:12:41 --> Controller Class Initialized
INFO - 2024-01-20 03:12:41 --> Model Class Initialized
DEBUG - 2024-01-20 03:12:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 03:12:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:12:41 --> Model Class Initialized
DEBUG - 2024-01-20 03:12:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:12:41 --> Model Class Initialized
INFO - 2024-01-20 03:12:41 --> Final output sent to browser
DEBUG - 2024-01-20 03:12:41 --> Total execution time: 0.0452
ERROR - 2024-01-20 03:12:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 03:12:47 --> Config Class Initialized
INFO - 2024-01-20 03:12:47 --> Hooks Class Initialized
DEBUG - 2024-01-20 03:12:47 --> UTF-8 Support Enabled
INFO - 2024-01-20 03:12:47 --> Utf8 Class Initialized
INFO - 2024-01-20 03:12:47 --> URI Class Initialized
INFO - 2024-01-20 03:12:47 --> Router Class Initialized
INFO - 2024-01-20 03:12:47 --> Output Class Initialized
INFO - 2024-01-20 03:12:47 --> Security Class Initialized
DEBUG - 2024-01-20 03:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 03:12:47 --> Input Class Initialized
INFO - 2024-01-20 03:12:47 --> Language Class Initialized
INFO - 2024-01-20 03:12:47 --> Loader Class Initialized
INFO - 2024-01-20 03:12:47 --> Helper loaded: url_helper
INFO - 2024-01-20 03:12:47 --> Helper loaded: file_helper
INFO - 2024-01-20 03:12:47 --> Helper loaded: html_helper
INFO - 2024-01-20 03:12:47 --> Helper loaded: text_helper
INFO - 2024-01-20 03:12:47 --> Helper loaded: form_helper
INFO - 2024-01-20 03:12:47 --> Helper loaded: lang_helper
INFO - 2024-01-20 03:12:47 --> Helper loaded: security_helper
INFO - 2024-01-20 03:12:47 --> Helper loaded: cookie_helper
INFO - 2024-01-20 03:12:47 --> Database Driver Class Initialized
INFO - 2024-01-20 03:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 03:12:47 --> Parser Class Initialized
INFO - 2024-01-20 03:12:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 03:12:47 --> Pagination Class Initialized
INFO - 2024-01-20 03:12:47 --> Form Validation Class Initialized
INFO - 2024-01-20 03:12:47 --> Controller Class Initialized
INFO - 2024-01-20 03:12:47 --> Model Class Initialized
DEBUG - 2024-01-20 03:12:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 03:12:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:12:47 --> Model Class Initialized
DEBUG - 2024-01-20 03:12:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:12:47 --> Model Class Initialized
INFO - 2024-01-20 03:12:47 --> Final output sent to browser
DEBUG - 2024-01-20 03:12:47 --> Total execution time: 0.1139
ERROR - 2024-01-20 03:13:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 03:13:03 --> Config Class Initialized
INFO - 2024-01-20 03:13:03 --> Hooks Class Initialized
DEBUG - 2024-01-20 03:13:03 --> UTF-8 Support Enabled
INFO - 2024-01-20 03:13:03 --> Utf8 Class Initialized
INFO - 2024-01-20 03:13:03 --> URI Class Initialized
INFO - 2024-01-20 03:13:03 --> Router Class Initialized
INFO - 2024-01-20 03:13:03 --> Output Class Initialized
INFO - 2024-01-20 03:13:03 --> Security Class Initialized
DEBUG - 2024-01-20 03:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 03:13:03 --> Input Class Initialized
INFO - 2024-01-20 03:13:03 --> Language Class Initialized
INFO - 2024-01-20 03:13:03 --> Loader Class Initialized
INFO - 2024-01-20 03:13:03 --> Helper loaded: url_helper
INFO - 2024-01-20 03:13:03 --> Helper loaded: file_helper
INFO - 2024-01-20 03:13:03 --> Helper loaded: html_helper
INFO - 2024-01-20 03:13:03 --> Helper loaded: text_helper
INFO - 2024-01-20 03:13:03 --> Helper loaded: form_helper
INFO - 2024-01-20 03:13:03 --> Helper loaded: lang_helper
INFO - 2024-01-20 03:13:03 --> Helper loaded: security_helper
INFO - 2024-01-20 03:13:03 --> Helper loaded: cookie_helper
INFO - 2024-01-20 03:13:03 --> Database Driver Class Initialized
INFO - 2024-01-20 03:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 03:13:03 --> Parser Class Initialized
INFO - 2024-01-20 03:13:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 03:13:03 --> Pagination Class Initialized
INFO - 2024-01-20 03:13:03 --> Form Validation Class Initialized
INFO - 2024-01-20 03:13:03 --> Controller Class Initialized
INFO - 2024-01-20 03:13:03 --> Model Class Initialized
DEBUG - 2024-01-20 03:13:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 03:13:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:13:03 --> Model Class Initialized
DEBUG - 2024-01-20 03:13:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:13:03 --> Model Class Initialized
DEBUG - 2024-01-20 03:13:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:13:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-01-20 03:13:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:13:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 03:13:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 03:13:03 --> Model Class Initialized
INFO - 2024-01-20 03:13:03 --> Model Class Initialized
INFO - 2024-01-20 03:13:03 --> Model Class Initialized
INFO - 2024-01-20 03:13:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 03:13:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 03:13:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 03:13:03 --> Final output sent to browser
DEBUG - 2024-01-20 03:13:03 --> Total execution time: 0.1623
ERROR - 2024-01-20 03:15:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 03:15:55 --> Config Class Initialized
INFO - 2024-01-20 03:15:55 --> Hooks Class Initialized
DEBUG - 2024-01-20 03:15:55 --> UTF-8 Support Enabled
INFO - 2024-01-20 03:15:55 --> Utf8 Class Initialized
INFO - 2024-01-20 03:15:55 --> URI Class Initialized
INFO - 2024-01-20 03:15:55 --> Router Class Initialized
INFO - 2024-01-20 03:15:55 --> Output Class Initialized
INFO - 2024-01-20 03:15:55 --> Security Class Initialized
DEBUG - 2024-01-20 03:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 03:15:55 --> Input Class Initialized
INFO - 2024-01-20 03:15:55 --> Language Class Initialized
INFO - 2024-01-20 03:15:55 --> Loader Class Initialized
INFO - 2024-01-20 03:15:55 --> Helper loaded: url_helper
INFO - 2024-01-20 03:15:55 --> Helper loaded: file_helper
INFO - 2024-01-20 03:15:55 --> Helper loaded: html_helper
INFO - 2024-01-20 03:15:55 --> Helper loaded: text_helper
INFO - 2024-01-20 03:15:55 --> Helper loaded: form_helper
INFO - 2024-01-20 03:15:55 --> Helper loaded: lang_helper
INFO - 2024-01-20 03:15:55 --> Helper loaded: security_helper
INFO - 2024-01-20 03:15:55 --> Helper loaded: cookie_helper
INFO - 2024-01-20 03:15:55 --> Database Driver Class Initialized
INFO - 2024-01-20 03:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 03:15:55 --> Parser Class Initialized
INFO - 2024-01-20 03:15:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 03:15:55 --> Pagination Class Initialized
INFO - 2024-01-20 03:15:55 --> Form Validation Class Initialized
INFO - 2024-01-20 03:15:55 --> Controller Class Initialized
INFO - 2024-01-20 03:15:55 --> Model Class Initialized
DEBUG - 2024-01-20 03:15:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 03:15:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:15:55 --> Model Class Initialized
DEBUG - 2024-01-20 03:15:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:15:55 --> Model Class Initialized
INFO - 2024-01-20 03:15:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-20 03:15:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:15:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 03:15:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 03:15:55 --> Model Class Initialized
INFO - 2024-01-20 03:15:55 --> Model Class Initialized
INFO - 2024-01-20 03:15:55 --> Model Class Initialized
INFO - 2024-01-20 03:15:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 03:15:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 03:15:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 03:15:55 --> Final output sent to browser
DEBUG - 2024-01-20 03:15:55 --> Total execution time: 0.1514
ERROR - 2024-01-20 03:15:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 03:15:55 --> Config Class Initialized
INFO - 2024-01-20 03:15:55 --> Hooks Class Initialized
DEBUG - 2024-01-20 03:15:55 --> UTF-8 Support Enabled
INFO - 2024-01-20 03:15:55 --> Utf8 Class Initialized
INFO - 2024-01-20 03:15:55 --> URI Class Initialized
DEBUG - 2024-01-20 03:15:55 --> No URI present. Default controller set.
INFO - 2024-01-20 03:15:55 --> Router Class Initialized
INFO - 2024-01-20 03:15:55 --> Output Class Initialized
INFO - 2024-01-20 03:15:55 --> Security Class Initialized
DEBUG - 2024-01-20 03:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 03:15:55 --> Input Class Initialized
INFO - 2024-01-20 03:15:55 --> Language Class Initialized
INFO - 2024-01-20 03:15:55 --> Loader Class Initialized
INFO - 2024-01-20 03:15:55 --> Helper loaded: url_helper
INFO - 2024-01-20 03:15:55 --> Helper loaded: file_helper
INFO - 2024-01-20 03:15:55 --> Helper loaded: html_helper
INFO - 2024-01-20 03:15:55 --> Helper loaded: text_helper
INFO - 2024-01-20 03:15:55 --> Helper loaded: form_helper
INFO - 2024-01-20 03:15:55 --> Helper loaded: lang_helper
INFO - 2024-01-20 03:15:55 --> Helper loaded: security_helper
INFO - 2024-01-20 03:15:55 --> Helper loaded: cookie_helper
INFO - 2024-01-20 03:15:55 --> Database Driver Class Initialized
INFO - 2024-01-20 03:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 03:15:55 --> Parser Class Initialized
INFO - 2024-01-20 03:15:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 03:15:55 --> Pagination Class Initialized
INFO - 2024-01-20 03:15:55 --> Form Validation Class Initialized
INFO - 2024-01-20 03:15:55 --> Controller Class Initialized
INFO - 2024-01-20 03:15:55 --> Model Class Initialized
DEBUG - 2024-01-20 03:15:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:15:55 --> Model Class Initialized
DEBUG - 2024-01-20 03:15:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:15:55 --> Model Class Initialized
INFO - 2024-01-20 03:15:55 --> Model Class Initialized
INFO - 2024-01-20 03:15:55 --> Model Class Initialized
INFO - 2024-01-20 03:15:55 --> Model Class Initialized
DEBUG - 2024-01-20 03:15:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 03:15:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:15:55 --> Model Class Initialized
INFO - 2024-01-20 03:15:55 --> Model Class Initialized
INFO - 2024-01-20 03:15:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-20 03:15:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:15:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 03:15:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 03:15:55 --> Model Class Initialized
INFO - 2024-01-20 03:15:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 03:15:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 03:15:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 03:15:55 --> Final output sent to browser
DEBUG - 2024-01-20 03:15:55 --> Total execution time: 0.2332
ERROR - 2024-01-20 03:16:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 03:16:00 --> Config Class Initialized
INFO - 2024-01-20 03:16:00 --> Hooks Class Initialized
DEBUG - 2024-01-20 03:16:00 --> UTF-8 Support Enabled
INFO - 2024-01-20 03:16:00 --> Utf8 Class Initialized
INFO - 2024-01-20 03:16:00 --> URI Class Initialized
INFO - 2024-01-20 03:16:00 --> Router Class Initialized
INFO - 2024-01-20 03:16:00 --> Output Class Initialized
INFO - 2024-01-20 03:16:00 --> Security Class Initialized
DEBUG - 2024-01-20 03:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 03:16:00 --> Input Class Initialized
INFO - 2024-01-20 03:16:00 --> Language Class Initialized
INFO - 2024-01-20 03:16:00 --> Loader Class Initialized
INFO - 2024-01-20 03:16:00 --> Helper loaded: url_helper
INFO - 2024-01-20 03:16:00 --> Helper loaded: file_helper
INFO - 2024-01-20 03:16:00 --> Helper loaded: html_helper
INFO - 2024-01-20 03:16:00 --> Helper loaded: text_helper
INFO - 2024-01-20 03:16:00 --> Helper loaded: form_helper
INFO - 2024-01-20 03:16:00 --> Helper loaded: lang_helper
INFO - 2024-01-20 03:16:00 --> Helper loaded: security_helper
INFO - 2024-01-20 03:16:00 --> Helper loaded: cookie_helper
INFO - 2024-01-20 03:16:00 --> Database Driver Class Initialized
INFO - 2024-01-20 03:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 03:16:00 --> Parser Class Initialized
INFO - 2024-01-20 03:16:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 03:16:00 --> Pagination Class Initialized
INFO - 2024-01-20 03:16:00 --> Form Validation Class Initialized
INFO - 2024-01-20 03:16:00 --> Controller Class Initialized
INFO - 2024-01-20 03:16:00 --> Model Class Initialized
DEBUG - 2024-01-20 03:16:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 03:16:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:16:00 --> Model Class Initialized
DEBUG - 2024-01-20 03:16:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:16:00 --> Model Class Initialized
INFO - 2024-01-20 03:16:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-20 03:16:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:16:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 03:16:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 03:16:00 --> Model Class Initialized
INFO - 2024-01-20 03:16:00 --> Model Class Initialized
INFO - 2024-01-20 03:16:00 --> Model Class Initialized
INFO - 2024-01-20 03:16:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 03:16:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 03:16:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 03:16:00 --> Final output sent to browser
DEBUG - 2024-01-20 03:16:00 --> Total execution time: 0.1520
ERROR - 2024-01-20 03:16:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 03:16:01 --> Config Class Initialized
INFO - 2024-01-20 03:16:01 --> Hooks Class Initialized
DEBUG - 2024-01-20 03:16:01 --> UTF-8 Support Enabled
INFO - 2024-01-20 03:16:01 --> Utf8 Class Initialized
INFO - 2024-01-20 03:16:01 --> URI Class Initialized
INFO - 2024-01-20 03:16:01 --> Router Class Initialized
INFO - 2024-01-20 03:16:01 --> Output Class Initialized
INFO - 2024-01-20 03:16:01 --> Security Class Initialized
DEBUG - 2024-01-20 03:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 03:16:01 --> Input Class Initialized
INFO - 2024-01-20 03:16:01 --> Language Class Initialized
INFO - 2024-01-20 03:16:01 --> Loader Class Initialized
INFO - 2024-01-20 03:16:01 --> Helper loaded: url_helper
INFO - 2024-01-20 03:16:01 --> Helper loaded: file_helper
INFO - 2024-01-20 03:16:01 --> Helper loaded: html_helper
INFO - 2024-01-20 03:16:01 --> Helper loaded: text_helper
INFO - 2024-01-20 03:16:01 --> Helper loaded: form_helper
INFO - 2024-01-20 03:16:01 --> Helper loaded: lang_helper
INFO - 2024-01-20 03:16:01 --> Helper loaded: security_helper
INFO - 2024-01-20 03:16:01 --> Helper loaded: cookie_helper
INFO - 2024-01-20 03:16:01 --> Database Driver Class Initialized
INFO - 2024-01-20 03:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 03:16:01 --> Parser Class Initialized
INFO - 2024-01-20 03:16:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 03:16:01 --> Pagination Class Initialized
INFO - 2024-01-20 03:16:01 --> Form Validation Class Initialized
INFO - 2024-01-20 03:16:01 --> Controller Class Initialized
INFO - 2024-01-20 03:16:01 --> Model Class Initialized
DEBUG - 2024-01-20 03:16:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 03:16:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:16:01 --> Model Class Initialized
DEBUG - 2024-01-20 03:16:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:16:01 --> Model Class Initialized
INFO - 2024-01-20 03:16:01 --> Final output sent to browser
DEBUG - 2024-01-20 03:16:01 --> Total execution time: 0.0417
ERROR - 2024-01-20 03:16:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 03:16:05 --> Config Class Initialized
INFO - 2024-01-20 03:16:05 --> Hooks Class Initialized
DEBUG - 2024-01-20 03:16:05 --> UTF-8 Support Enabled
INFO - 2024-01-20 03:16:05 --> Utf8 Class Initialized
INFO - 2024-01-20 03:16:05 --> URI Class Initialized
INFO - 2024-01-20 03:16:05 --> Router Class Initialized
INFO - 2024-01-20 03:16:05 --> Output Class Initialized
INFO - 2024-01-20 03:16:05 --> Security Class Initialized
DEBUG - 2024-01-20 03:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 03:16:05 --> Input Class Initialized
INFO - 2024-01-20 03:16:05 --> Language Class Initialized
INFO - 2024-01-20 03:16:05 --> Loader Class Initialized
INFO - 2024-01-20 03:16:05 --> Helper loaded: url_helper
INFO - 2024-01-20 03:16:05 --> Helper loaded: file_helper
INFO - 2024-01-20 03:16:05 --> Helper loaded: html_helper
INFO - 2024-01-20 03:16:05 --> Helper loaded: text_helper
INFO - 2024-01-20 03:16:05 --> Helper loaded: form_helper
INFO - 2024-01-20 03:16:05 --> Helper loaded: lang_helper
INFO - 2024-01-20 03:16:05 --> Helper loaded: security_helper
INFO - 2024-01-20 03:16:05 --> Helper loaded: cookie_helper
INFO - 2024-01-20 03:16:05 --> Database Driver Class Initialized
INFO - 2024-01-20 03:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 03:16:05 --> Parser Class Initialized
INFO - 2024-01-20 03:16:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 03:16:05 --> Pagination Class Initialized
INFO - 2024-01-20 03:16:05 --> Form Validation Class Initialized
INFO - 2024-01-20 03:16:05 --> Controller Class Initialized
INFO - 2024-01-20 03:16:05 --> Model Class Initialized
DEBUG - 2024-01-20 03:16:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 03:16:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:16:05 --> Model Class Initialized
DEBUG - 2024-01-20 03:16:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:16:05 --> Model Class Initialized
INFO - 2024-01-20 03:16:06 --> Final output sent to browser
DEBUG - 2024-01-20 03:16:06 --> Total execution time: 0.1192
ERROR - 2024-01-20 03:16:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 03:16:21 --> Config Class Initialized
INFO - 2024-01-20 03:16:21 --> Hooks Class Initialized
DEBUG - 2024-01-20 03:16:21 --> UTF-8 Support Enabled
INFO - 2024-01-20 03:16:21 --> Utf8 Class Initialized
INFO - 2024-01-20 03:16:21 --> URI Class Initialized
INFO - 2024-01-20 03:16:21 --> Router Class Initialized
INFO - 2024-01-20 03:16:21 --> Output Class Initialized
INFO - 2024-01-20 03:16:21 --> Security Class Initialized
DEBUG - 2024-01-20 03:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 03:16:21 --> Input Class Initialized
INFO - 2024-01-20 03:16:21 --> Language Class Initialized
INFO - 2024-01-20 03:16:21 --> Loader Class Initialized
INFO - 2024-01-20 03:16:21 --> Helper loaded: url_helper
INFO - 2024-01-20 03:16:21 --> Helper loaded: file_helper
INFO - 2024-01-20 03:16:21 --> Helper loaded: html_helper
INFO - 2024-01-20 03:16:21 --> Helper loaded: text_helper
INFO - 2024-01-20 03:16:21 --> Helper loaded: form_helper
INFO - 2024-01-20 03:16:21 --> Helper loaded: lang_helper
INFO - 2024-01-20 03:16:21 --> Helper loaded: security_helper
INFO - 2024-01-20 03:16:21 --> Helper loaded: cookie_helper
INFO - 2024-01-20 03:16:21 --> Database Driver Class Initialized
INFO - 2024-01-20 03:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 03:16:21 --> Parser Class Initialized
INFO - 2024-01-20 03:16:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 03:16:21 --> Pagination Class Initialized
INFO - 2024-01-20 03:16:21 --> Form Validation Class Initialized
INFO - 2024-01-20 03:16:21 --> Controller Class Initialized
INFO - 2024-01-20 03:16:21 --> Model Class Initialized
DEBUG - 2024-01-20 03:16:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 03:16:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:16:21 --> Model Class Initialized
DEBUG - 2024-01-20 03:16:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:16:21 --> Model Class Initialized
DEBUG - 2024-01-20 03:16:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:16:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-01-20 03:16:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:16:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 03:16:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 03:16:21 --> Model Class Initialized
INFO - 2024-01-20 03:16:21 --> Model Class Initialized
INFO - 2024-01-20 03:16:21 --> Model Class Initialized
INFO - 2024-01-20 03:16:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 03:16:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 03:16:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 03:16:21 --> Final output sent to browser
DEBUG - 2024-01-20 03:16:21 --> Total execution time: 0.1605
ERROR - 2024-01-20 03:17:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 03:17:50 --> Config Class Initialized
INFO - 2024-01-20 03:17:50 --> Hooks Class Initialized
DEBUG - 2024-01-20 03:17:50 --> UTF-8 Support Enabled
INFO - 2024-01-20 03:17:50 --> Utf8 Class Initialized
INFO - 2024-01-20 03:17:50 --> URI Class Initialized
INFO - 2024-01-20 03:17:50 --> Router Class Initialized
INFO - 2024-01-20 03:17:50 --> Output Class Initialized
INFO - 2024-01-20 03:17:50 --> Security Class Initialized
DEBUG - 2024-01-20 03:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 03:17:50 --> Input Class Initialized
INFO - 2024-01-20 03:17:50 --> Language Class Initialized
INFO - 2024-01-20 03:17:50 --> Loader Class Initialized
INFO - 2024-01-20 03:17:50 --> Helper loaded: url_helper
INFO - 2024-01-20 03:17:50 --> Helper loaded: file_helper
INFO - 2024-01-20 03:17:50 --> Helper loaded: html_helper
INFO - 2024-01-20 03:17:50 --> Helper loaded: text_helper
INFO - 2024-01-20 03:17:50 --> Helper loaded: form_helper
INFO - 2024-01-20 03:17:50 --> Helper loaded: lang_helper
INFO - 2024-01-20 03:17:50 --> Helper loaded: security_helper
INFO - 2024-01-20 03:17:50 --> Helper loaded: cookie_helper
INFO - 2024-01-20 03:17:50 --> Database Driver Class Initialized
INFO - 2024-01-20 03:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 03:17:50 --> Parser Class Initialized
INFO - 2024-01-20 03:17:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 03:17:50 --> Pagination Class Initialized
INFO - 2024-01-20 03:17:50 --> Form Validation Class Initialized
INFO - 2024-01-20 03:17:50 --> Controller Class Initialized
INFO - 2024-01-20 03:17:50 --> Model Class Initialized
DEBUG - 2024-01-20 03:17:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 03:17:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:17:50 --> Model Class Initialized
DEBUG - 2024-01-20 03:17:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:17:50 --> Model Class Initialized
INFO - 2024-01-20 03:17:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-20 03:17:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:17:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 03:17:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 03:17:50 --> Model Class Initialized
INFO - 2024-01-20 03:17:50 --> Model Class Initialized
INFO - 2024-01-20 03:17:50 --> Model Class Initialized
INFO - 2024-01-20 03:17:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 03:17:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 03:17:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 03:17:50 --> Final output sent to browser
DEBUG - 2024-01-20 03:17:50 --> Total execution time: 0.1568
ERROR - 2024-01-20 03:17:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 03:17:51 --> Config Class Initialized
INFO - 2024-01-20 03:17:51 --> Hooks Class Initialized
DEBUG - 2024-01-20 03:17:51 --> UTF-8 Support Enabled
INFO - 2024-01-20 03:17:51 --> Utf8 Class Initialized
INFO - 2024-01-20 03:17:51 --> URI Class Initialized
DEBUG - 2024-01-20 03:17:51 --> No URI present. Default controller set.
INFO - 2024-01-20 03:17:51 --> Router Class Initialized
INFO - 2024-01-20 03:17:51 --> Output Class Initialized
INFO - 2024-01-20 03:17:51 --> Security Class Initialized
DEBUG - 2024-01-20 03:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 03:17:51 --> Input Class Initialized
INFO - 2024-01-20 03:17:51 --> Language Class Initialized
INFO - 2024-01-20 03:17:51 --> Loader Class Initialized
INFO - 2024-01-20 03:17:51 --> Helper loaded: url_helper
INFO - 2024-01-20 03:17:51 --> Helper loaded: file_helper
INFO - 2024-01-20 03:17:51 --> Helper loaded: html_helper
INFO - 2024-01-20 03:17:51 --> Helper loaded: text_helper
INFO - 2024-01-20 03:17:51 --> Helper loaded: form_helper
INFO - 2024-01-20 03:17:51 --> Helper loaded: lang_helper
INFO - 2024-01-20 03:17:51 --> Helper loaded: security_helper
INFO - 2024-01-20 03:17:51 --> Helper loaded: cookie_helper
INFO - 2024-01-20 03:17:51 --> Database Driver Class Initialized
INFO - 2024-01-20 03:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 03:17:51 --> Parser Class Initialized
INFO - 2024-01-20 03:17:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 03:17:51 --> Pagination Class Initialized
INFO - 2024-01-20 03:17:51 --> Form Validation Class Initialized
INFO - 2024-01-20 03:17:51 --> Controller Class Initialized
INFO - 2024-01-20 03:17:51 --> Model Class Initialized
DEBUG - 2024-01-20 03:17:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:17:51 --> Model Class Initialized
DEBUG - 2024-01-20 03:17:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:17:51 --> Model Class Initialized
INFO - 2024-01-20 03:17:51 --> Model Class Initialized
INFO - 2024-01-20 03:17:51 --> Model Class Initialized
INFO - 2024-01-20 03:17:51 --> Model Class Initialized
DEBUG - 2024-01-20 03:17:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 03:17:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:17:51 --> Model Class Initialized
INFO - 2024-01-20 03:17:51 --> Model Class Initialized
INFO - 2024-01-20 03:17:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-20 03:17:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:17:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 03:17:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 03:17:51 --> Model Class Initialized
INFO - 2024-01-20 03:17:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 03:17:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 03:17:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 03:17:51 --> Final output sent to browser
DEBUG - 2024-01-20 03:17:51 --> Total execution time: 0.2253
ERROR - 2024-01-20 03:17:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 03:17:51 --> Config Class Initialized
INFO - 2024-01-20 03:17:51 --> Hooks Class Initialized
DEBUG - 2024-01-20 03:17:51 --> UTF-8 Support Enabled
INFO - 2024-01-20 03:17:51 --> Utf8 Class Initialized
INFO - 2024-01-20 03:17:51 --> URI Class Initialized
INFO - 2024-01-20 03:17:51 --> Router Class Initialized
INFO - 2024-01-20 03:17:51 --> Output Class Initialized
INFO - 2024-01-20 03:17:51 --> Security Class Initialized
DEBUG - 2024-01-20 03:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 03:17:51 --> Input Class Initialized
INFO - 2024-01-20 03:17:51 --> Language Class Initialized
INFO - 2024-01-20 03:17:51 --> Loader Class Initialized
INFO - 2024-01-20 03:17:51 --> Helper loaded: url_helper
INFO - 2024-01-20 03:17:51 --> Helper loaded: file_helper
INFO - 2024-01-20 03:17:51 --> Helper loaded: html_helper
INFO - 2024-01-20 03:17:51 --> Helper loaded: text_helper
INFO - 2024-01-20 03:17:51 --> Helper loaded: form_helper
INFO - 2024-01-20 03:17:51 --> Helper loaded: lang_helper
INFO - 2024-01-20 03:17:51 --> Helper loaded: security_helper
INFO - 2024-01-20 03:17:51 --> Helper loaded: cookie_helper
INFO - 2024-01-20 03:17:51 --> Database Driver Class Initialized
INFO - 2024-01-20 03:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 03:17:51 --> Parser Class Initialized
INFO - 2024-01-20 03:17:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 03:17:51 --> Pagination Class Initialized
INFO - 2024-01-20 03:17:51 --> Form Validation Class Initialized
INFO - 2024-01-20 03:17:51 --> Controller Class Initialized
INFO - 2024-01-20 03:17:51 --> Model Class Initialized
DEBUG - 2024-01-20 03:17:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 03:17:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:17:51 --> Model Class Initialized
DEBUG - 2024-01-20 03:17:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:17:51 --> Model Class Initialized
INFO - 2024-01-20 03:17:51 --> Final output sent to browser
DEBUG - 2024-01-20 03:17:51 --> Total execution time: 0.0416
ERROR - 2024-01-20 03:17:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 03:17:57 --> Config Class Initialized
INFO - 2024-01-20 03:17:57 --> Hooks Class Initialized
DEBUG - 2024-01-20 03:17:57 --> UTF-8 Support Enabled
INFO - 2024-01-20 03:17:57 --> Utf8 Class Initialized
INFO - 2024-01-20 03:17:57 --> URI Class Initialized
INFO - 2024-01-20 03:17:57 --> Router Class Initialized
INFO - 2024-01-20 03:17:57 --> Output Class Initialized
INFO - 2024-01-20 03:17:57 --> Security Class Initialized
DEBUG - 2024-01-20 03:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 03:17:57 --> Input Class Initialized
INFO - 2024-01-20 03:17:57 --> Language Class Initialized
INFO - 2024-01-20 03:17:57 --> Loader Class Initialized
INFO - 2024-01-20 03:17:57 --> Helper loaded: url_helper
INFO - 2024-01-20 03:17:57 --> Helper loaded: file_helper
INFO - 2024-01-20 03:17:57 --> Helper loaded: html_helper
INFO - 2024-01-20 03:17:57 --> Helper loaded: text_helper
INFO - 2024-01-20 03:17:57 --> Helper loaded: form_helper
INFO - 2024-01-20 03:17:57 --> Helper loaded: lang_helper
INFO - 2024-01-20 03:17:57 --> Helper loaded: security_helper
INFO - 2024-01-20 03:17:57 --> Helper loaded: cookie_helper
INFO - 2024-01-20 03:17:57 --> Database Driver Class Initialized
INFO - 2024-01-20 03:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 03:17:57 --> Parser Class Initialized
INFO - 2024-01-20 03:17:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 03:17:57 --> Pagination Class Initialized
INFO - 2024-01-20 03:17:57 --> Form Validation Class Initialized
INFO - 2024-01-20 03:17:57 --> Controller Class Initialized
INFO - 2024-01-20 03:17:57 --> Model Class Initialized
DEBUG - 2024-01-20 03:17:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 03:17:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:17:57 --> Model Class Initialized
DEBUG - 2024-01-20 03:17:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:17:57 --> Model Class Initialized
INFO - 2024-01-20 03:17:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-20 03:17:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:17:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 03:17:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 03:17:57 --> Model Class Initialized
INFO - 2024-01-20 03:17:57 --> Model Class Initialized
INFO - 2024-01-20 03:17:57 --> Model Class Initialized
INFO - 2024-01-20 03:17:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 03:17:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 03:17:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 03:17:57 --> Final output sent to browser
DEBUG - 2024-01-20 03:17:57 --> Total execution time: 0.1660
ERROR - 2024-01-20 03:17:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 03:17:58 --> Config Class Initialized
INFO - 2024-01-20 03:17:58 --> Hooks Class Initialized
DEBUG - 2024-01-20 03:17:58 --> UTF-8 Support Enabled
INFO - 2024-01-20 03:17:58 --> Utf8 Class Initialized
INFO - 2024-01-20 03:17:58 --> URI Class Initialized
INFO - 2024-01-20 03:17:58 --> Router Class Initialized
INFO - 2024-01-20 03:17:58 --> Output Class Initialized
INFO - 2024-01-20 03:17:58 --> Security Class Initialized
DEBUG - 2024-01-20 03:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 03:17:58 --> Input Class Initialized
INFO - 2024-01-20 03:17:58 --> Language Class Initialized
INFO - 2024-01-20 03:17:58 --> Loader Class Initialized
INFO - 2024-01-20 03:17:58 --> Helper loaded: url_helper
INFO - 2024-01-20 03:17:58 --> Helper loaded: file_helper
INFO - 2024-01-20 03:17:58 --> Helper loaded: html_helper
INFO - 2024-01-20 03:17:58 --> Helper loaded: text_helper
INFO - 2024-01-20 03:17:58 --> Helper loaded: form_helper
INFO - 2024-01-20 03:17:58 --> Helper loaded: lang_helper
INFO - 2024-01-20 03:17:58 --> Helper loaded: security_helper
INFO - 2024-01-20 03:17:58 --> Helper loaded: cookie_helper
INFO - 2024-01-20 03:17:58 --> Database Driver Class Initialized
INFO - 2024-01-20 03:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 03:17:58 --> Parser Class Initialized
INFO - 2024-01-20 03:17:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 03:17:58 --> Pagination Class Initialized
INFO - 2024-01-20 03:17:58 --> Form Validation Class Initialized
INFO - 2024-01-20 03:17:58 --> Controller Class Initialized
INFO - 2024-01-20 03:17:58 --> Model Class Initialized
DEBUG - 2024-01-20 03:17:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 03:17:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:17:58 --> Model Class Initialized
DEBUG - 2024-01-20 03:17:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:17:58 --> Model Class Initialized
INFO - 2024-01-20 03:17:58 --> Final output sent to browser
DEBUG - 2024-01-20 03:17:58 --> Total execution time: 0.0405
ERROR - 2024-01-20 03:18:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 03:18:04 --> Config Class Initialized
INFO - 2024-01-20 03:18:04 --> Hooks Class Initialized
DEBUG - 2024-01-20 03:18:04 --> UTF-8 Support Enabled
INFO - 2024-01-20 03:18:04 --> Utf8 Class Initialized
INFO - 2024-01-20 03:18:04 --> URI Class Initialized
INFO - 2024-01-20 03:18:04 --> Router Class Initialized
INFO - 2024-01-20 03:18:04 --> Output Class Initialized
INFO - 2024-01-20 03:18:04 --> Security Class Initialized
DEBUG - 2024-01-20 03:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 03:18:04 --> Input Class Initialized
INFO - 2024-01-20 03:18:04 --> Language Class Initialized
INFO - 2024-01-20 03:18:04 --> Loader Class Initialized
INFO - 2024-01-20 03:18:04 --> Helper loaded: url_helper
INFO - 2024-01-20 03:18:04 --> Helper loaded: file_helper
INFO - 2024-01-20 03:18:04 --> Helper loaded: html_helper
INFO - 2024-01-20 03:18:04 --> Helper loaded: text_helper
INFO - 2024-01-20 03:18:04 --> Helper loaded: form_helper
INFO - 2024-01-20 03:18:04 --> Helper loaded: lang_helper
INFO - 2024-01-20 03:18:04 --> Helper loaded: security_helper
INFO - 2024-01-20 03:18:04 --> Helper loaded: cookie_helper
INFO - 2024-01-20 03:18:04 --> Database Driver Class Initialized
INFO - 2024-01-20 03:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 03:18:04 --> Parser Class Initialized
INFO - 2024-01-20 03:18:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 03:18:04 --> Pagination Class Initialized
INFO - 2024-01-20 03:18:04 --> Form Validation Class Initialized
INFO - 2024-01-20 03:18:04 --> Controller Class Initialized
INFO - 2024-01-20 03:18:04 --> Model Class Initialized
DEBUG - 2024-01-20 03:18:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 03:18:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:18:04 --> Model Class Initialized
DEBUG - 2024-01-20 03:18:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:18:04 --> Model Class Initialized
INFO - 2024-01-20 03:18:04 --> Final output sent to browser
DEBUG - 2024-01-20 03:18:04 --> Total execution time: 0.1150
ERROR - 2024-01-20 03:18:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 03:18:11 --> Config Class Initialized
INFO - 2024-01-20 03:18:11 --> Hooks Class Initialized
DEBUG - 2024-01-20 03:18:11 --> UTF-8 Support Enabled
INFO - 2024-01-20 03:18:11 --> Utf8 Class Initialized
INFO - 2024-01-20 03:18:11 --> URI Class Initialized
INFO - 2024-01-20 03:18:11 --> Router Class Initialized
INFO - 2024-01-20 03:18:11 --> Output Class Initialized
INFO - 2024-01-20 03:18:11 --> Security Class Initialized
DEBUG - 2024-01-20 03:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 03:18:11 --> Input Class Initialized
INFO - 2024-01-20 03:18:11 --> Language Class Initialized
INFO - 2024-01-20 03:18:11 --> Loader Class Initialized
INFO - 2024-01-20 03:18:11 --> Helper loaded: url_helper
INFO - 2024-01-20 03:18:11 --> Helper loaded: file_helper
INFO - 2024-01-20 03:18:11 --> Helper loaded: html_helper
INFO - 2024-01-20 03:18:11 --> Helper loaded: text_helper
INFO - 2024-01-20 03:18:11 --> Helper loaded: form_helper
INFO - 2024-01-20 03:18:11 --> Helper loaded: lang_helper
INFO - 2024-01-20 03:18:11 --> Helper loaded: security_helper
INFO - 2024-01-20 03:18:11 --> Helper loaded: cookie_helper
INFO - 2024-01-20 03:18:11 --> Database Driver Class Initialized
INFO - 2024-01-20 03:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 03:18:11 --> Parser Class Initialized
INFO - 2024-01-20 03:18:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 03:18:11 --> Pagination Class Initialized
INFO - 2024-01-20 03:18:11 --> Form Validation Class Initialized
INFO - 2024-01-20 03:18:11 --> Controller Class Initialized
INFO - 2024-01-20 03:18:11 --> Model Class Initialized
DEBUG - 2024-01-20 03:18:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 03:18:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:18:11 --> Model Class Initialized
DEBUG - 2024-01-20 03:18:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:18:11 --> Model Class Initialized
DEBUG - 2024-01-20 03:18:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:18:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-01-20 03:18:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 03:18:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 03:18:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 03:18:11 --> Model Class Initialized
INFO - 2024-01-20 03:18:11 --> Model Class Initialized
INFO - 2024-01-20 03:18:11 --> Model Class Initialized
INFO - 2024-01-20 03:18:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 03:18:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 03:18:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 03:18:11 --> Final output sent to browser
DEBUG - 2024-01-20 03:18:11 --> Total execution time: 0.1766
ERROR - 2024-01-20 07:28:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 07:28:38 --> Config Class Initialized
INFO - 2024-01-20 07:28:38 --> Hooks Class Initialized
DEBUG - 2024-01-20 07:28:38 --> UTF-8 Support Enabled
INFO - 2024-01-20 07:28:38 --> Utf8 Class Initialized
INFO - 2024-01-20 07:28:38 --> URI Class Initialized
DEBUG - 2024-01-20 07:28:38 --> No URI present. Default controller set.
INFO - 2024-01-20 07:28:38 --> Router Class Initialized
INFO - 2024-01-20 07:28:38 --> Output Class Initialized
INFO - 2024-01-20 07:28:38 --> Security Class Initialized
DEBUG - 2024-01-20 07:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 07:28:38 --> Input Class Initialized
INFO - 2024-01-20 07:28:38 --> Language Class Initialized
INFO - 2024-01-20 07:28:38 --> Loader Class Initialized
INFO - 2024-01-20 07:28:38 --> Helper loaded: url_helper
INFO - 2024-01-20 07:28:38 --> Helper loaded: file_helper
INFO - 2024-01-20 07:28:38 --> Helper loaded: html_helper
INFO - 2024-01-20 07:28:38 --> Helper loaded: text_helper
INFO - 2024-01-20 07:28:38 --> Helper loaded: form_helper
INFO - 2024-01-20 07:28:38 --> Helper loaded: lang_helper
INFO - 2024-01-20 07:28:38 --> Helper loaded: security_helper
INFO - 2024-01-20 07:28:38 --> Helper loaded: cookie_helper
INFO - 2024-01-20 07:28:38 --> Database Driver Class Initialized
INFO - 2024-01-20 07:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 07:28:38 --> Parser Class Initialized
INFO - 2024-01-20 07:28:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 07:28:38 --> Pagination Class Initialized
INFO - 2024-01-20 07:28:38 --> Form Validation Class Initialized
INFO - 2024-01-20 07:28:38 --> Controller Class Initialized
INFO - 2024-01-20 07:28:38 --> Model Class Initialized
DEBUG - 2024-01-20 07:28:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-20 07:28:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 07:28:38 --> Config Class Initialized
INFO - 2024-01-20 07:28:38 --> Hooks Class Initialized
DEBUG - 2024-01-20 07:28:38 --> UTF-8 Support Enabled
INFO - 2024-01-20 07:28:38 --> Utf8 Class Initialized
INFO - 2024-01-20 07:28:38 --> URI Class Initialized
INFO - 2024-01-20 07:28:38 --> Router Class Initialized
INFO - 2024-01-20 07:28:38 --> Output Class Initialized
INFO - 2024-01-20 07:28:38 --> Security Class Initialized
DEBUG - 2024-01-20 07:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 07:28:38 --> Input Class Initialized
INFO - 2024-01-20 07:28:38 --> Language Class Initialized
INFO - 2024-01-20 07:28:38 --> Loader Class Initialized
INFO - 2024-01-20 07:28:38 --> Helper loaded: url_helper
INFO - 2024-01-20 07:28:38 --> Helper loaded: file_helper
INFO - 2024-01-20 07:28:38 --> Helper loaded: html_helper
INFO - 2024-01-20 07:28:38 --> Helper loaded: text_helper
INFO - 2024-01-20 07:28:38 --> Helper loaded: form_helper
INFO - 2024-01-20 07:28:38 --> Helper loaded: lang_helper
INFO - 2024-01-20 07:28:38 --> Helper loaded: security_helper
INFO - 2024-01-20 07:28:38 --> Helper loaded: cookie_helper
INFO - 2024-01-20 07:28:38 --> Database Driver Class Initialized
INFO - 2024-01-20 07:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 07:28:38 --> Parser Class Initialized
INFO - 2024-01-20 07:28:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 07:28:38 --> Pagination Class Initialized
INFO - 2024-01-20 07:28:38 --> Form Validation Class Initialized
INFO - 2024-01-20 07:28:38 --> Controller Class Initialized
INFO - 2024-01-20 07:28:38 --> Model Class Initialized
DEBUG - 2024-01-20 07:28:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 07:28:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-20 07:28:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 07:28:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 07:28:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 07:28:38 --> Model Class Initialized
INFO - 2024-01-20 07:28:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 07:28:38 --> Final output sent to browser
DEBUG - 2024-01-20 07:28:38 --> Total execution time: 0.0339
ERROR - 2024-01-20 08:48:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 08:48:37 --> Config Class Initialized
INFO - 2024-01-20 08:48:37 --> Hooks Class Initialized
DEBUG - 2024-01-20 08:48:37 --> UTF-8 Support Enabled
INFO - 2024-01-20 08:48:37 --> Utf8 Class Initialized
INFO - 2024-01-20 08:48:37 --> URI Class Initialized
DEBUG - 2024-01-20 08:48:37 --> No URI present. Default controller set.
INFO - 2024-01-20 08:48:37 --> Router Class Initialized
INFO - 2024-01-20 08:48:37 --> Output Class Initialized
INFO - 2024-01-20 08:48:37 --> Security Class Initialized
DEBUG - 2024-01-20 08:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 08:48:37 --> Input Class Initialized
INFO - 2024-01-20 08:48:37 --> Language Class Initialized
INFO - 2024-01-20 08:48:37 --> Loader Class Initialized
INFO - 2024-01-20 08:48:37 --> Helper loaded: url_helper
INFO - 2024-01-20 08:48:37 --> Helper loaded: file_helper
INFO - 2024-01-20 08:48:37 --> Helper loaded: html_helper
INFO - 2024-01-20 08:48:37 --> Helper loaded: text_helper
INFO - 2024-01-20 08:48:37 --> Helper loaded: form_helper
INFO - 2024-01-20 08:48:37 --> Helper loaded: lang_helper
INFO - 2024-01-20 08:48:37 --> Helper loaded: security_helper
INFO - 2024-01-20 08:48:37 --> Helper loaded: cookie_helper
INFO - 2024-01-20 08:48:37 --> Database Driver Class Initialized
INFO - 2024-01-20 08:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 08:48:37 --> Parser Class Initialized
INFO - 2024-01-20 08:48:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 08:48:37 --> Pagination Class Initialized
INFO - 2024-01-20 08:48:37 --> Form Validation Class Initialized
INFO - 2024-01-20 08:48:37 --> Controller Class Initialized
INFO - 2024-01-20 08:48:37 --> Model Class Initialized
DEBUG - 2024-01-20 08:48:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-20 08:48:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 08:48:37 --> Config Class Initialized
INFO - 2024-01-20 08:48:37 --> Hooks Class Initialized
DEBUG - 2024-01-20 08:48:37 --> UTF-8 Support Enabled
INFO - 2024-01-20 08:48:37 --> Utf8 Class Initialized
INFO - 2024-01-20 08:48:37 --> URI Class Initialized
INFO - 2024-01-20 08:48:37 --> Router Class Initialized
INFO - 2024-01-20 08:48:37 --> Output Class Initialized
INFO - 2024-01-20 08:48:37 --> Security Class Initialized
DEBUG - 2024-01-20 08:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 08:48:37 --> Input Class Initialized
INFO - 2024-01-20 08:48:37 --> Language Class Initialized
INFO - 2024-01-20 08:48:37 --> Loader Class Initialized
INFO - 2024-01-20 08:48:37 --> Helper loaded: url_helper
INFO - 2024-01-20 08:48:37 --> Helper loaded: file_helper
INFO - 2024-01-20 08:48:37 --> Helper loaded: html_helper
INFO - 2024-01-20 08:48:37 --> Helper loaded: text_helper
INFO - 2024-01-20 08:48:37 --> Helper loaded: form_helper
INFO - 2024-01-20 08:48:37 --> Helper loaded: lang_helper
INFO - 2024-01-20 08:48:37 --> Helper loaded: security_helper
INFO - 2024-01-20 08:48:37 --> Helper loaded: cookie_helper
INFO - 2024-01-20 08:48:37 --> Database Driver Class Initialized
INFO - 2024-01-20 08:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 08:48:37 --> Parser Class Initialized
INFO - 2024-01-20 08:48:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 08:48:37 --> Pagination Class Initialized
INFO - 2024-01-20 08:48:37 --> Form Validation Class Initialized
INFO - 2024-01-20 08:48:37 --> Controller Class Initialized
INFO - 2024-01-20 08:48:37 --> Model Class Initialized
DEBUG - 2024-01-20 08:48:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 08:48:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-20 08:48:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 08:48:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 08:48:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 08:48:37 --> Model Class Initialized
INFO - 2024-01-20 08:48:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 08:48:37 --> Final output sent to browser
DEBUG - 2024-01-20 08:48:37 --> Total execution time: 0.0377
ERROR - 2024-01-20 09:39:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 09:39:59 --> Config Class Initialized
INFO - 2024-01-20 09:39:59 --> Hooks Class Initialized
DEBUG - 2024-01-20 09:39:59 --> UTF-8 Support Enabled
INFO - 2024-01-20 09:39:59 --> Utf8 Class Initialized
INFO - 2024-01-20 09:39:59 --> URI Class Initialized
DEBUG - 2024-01-20 09:39:59 --> No URI present. Default controller set.
INFO - 2024-01-20 09:39:59 --> Router Class Initialized
INFO - 2024-01-20 09:39:59 --> Output Class Initialized
INFO - 2024-01-20 09:39:59 --> Security Class Initialized
DEBUG - 2024-01-20 09:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 09:39:59 --> Input Class Initialized
INFO - 2024-01-20 09:39:59 --> Language Class Initialized
INFO - 2024-01-20 09:39:59 --> Loader Class Initialized
INFO - 2024-01-20 09:39:59 --> Helper loaded: url_helper
INFO - 2024-01-20 09:39:59 --> Helper loaded: file_helper
INFO - 2024-01-20 09:39:59 --> Helper loaded: html_helper
INFO - 2024-01-20 09:39:59 --> Helper loaded: text_helper
INFO - 2024-01-20 09:39:59 --> Helper loaded: form_helper
INFO - 2024-01-20 09:39:59 --> Helper loaded: lang_helper
INFO - 2024-01-20 09:39:59 --> Helper loaded: security_helper
INFO - 2024-01-20 09:39:59 --> Helper loaded: cookie_helper
INFO - 2024-01-20 09:39:59 --> Database Driver Class Initialized
INFO - 2024-01-20 09:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 09:39:59 --> Parser Class Initialized
INFO - 2024-01-20 09:39:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 09:39:59 --> Pagination Class Initialized
INFO - 2024-01-20 09:39:59 --> Form Validation Class Initialized
INFO - 2024-01-20 09:39:59 --> Controller Class Initialized
INFO - 2024-01-20 09:39:59 --> Model Class Initialized
DEBUG - 2024-01-20 09:39:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-20 09:40:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 09:40:00 --> Config Class Initialized
INFO - 2024-01-20 09:40:00 --> Hooks Class Initialized
DEBUG - 2024-01-20 09:40:00 --> UTF-8 Support Enabled
INFO - 2024-01-20 09:40:00 --> Utf8 Class Initialized
INFO - 2024-01-20 09:40:00 --> URI Class Initialized
INFO - 2024-01-20 09:40:00 --> Router Class Initialized
INFO - 2024-01-20 09:40:00 --> Output Class Initialized
INFO - 2024-01-20 09:40:00 --> Security Class Initialized
DEBUG - 2024-01-20 09:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 09:40:00 --> Input Class Initialized
INFO - 2024-01-20 09:40:00 --> Language Class Initialized
INFO - 2024-01-20 09:40:00 --> Loader Class Initialized
INFO - 2024-01-20 09:40:00 --> Helper loaded: url_helper
INFO - 2024-01-20 09:40:00 --> Helper loaded: file_helper
INFO - 2024-01-20 09:40:00 --> Helper loaded: html_helper
INFO - 2024-01-20 09:40:00 --> Helper loaded: text_helper
INFO - 2024-01-20 09:40:00 --> Helper loaded: form_helper
INFO - 2024-01-20 09:40:00 --> Helper loaded: lang_helper
INFO - 2024-01-20 09:40:00 --> Helper loaded: security_helper
INFO - 2024-01-20 09:40:00 --> Helper loaded: cookie_helper
INFO - 2024-01-20 09:40:00 --> Database Driver Class Initialized
INFO - 2024-01-20 09:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 09:40:00 --> Parser Class Initialized
INFO - 2024-01-20 09:40:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 09:40:00 --> Pagination Class Initialized
INFO - 2024-01-20 09:40:00 --> Form Validation Class Initialized
INFO - 2024-01-20 09:40:00 --> Controller Class Initialized
INFO - 2024-01-20 09:40:00 --> Model Class Initialized
DEBUG - 2024-01-20 09:40:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 09:40:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-20 09:40:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 09:40:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 09:40:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 09:40:00 --> Model Class Initialized
INFO - 2024-01-20 09:40:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 09:40:00 --> Final output sent to browser
DEBUG - 2024-01-20 09:40:00 --> Total execution time: 0.0318
ERROR - 2024-01-20 09:47:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 09:47:00 --> Config Class Initialized
INFO - 2024-01-20 09:47:00 --> Hooks Class Initialized
DEBUG - 2024-01-20 09:47:00 --> UTF-8 Support Enabled
INFO - 2024-01-20 09:47:00 --> Utf8 Class Initialized
INFO - 2024-01-20 09:47:00 --> URI Class Initialized
DEBUG - 2024-01-20 09:47:00 --> No URI present. Default controller set.
INFO - 2024-01-20 09:47:00 --> Router Class Initialized
INFO - 2024-01-20 09:47:00 --> Output Class Initialized
INFO - 2024-01-20 09:47:00 --> Security Class Initialized
DEBUG - 2024-01-20 09:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 09:47:00 --> Input Class Initialized
INFO - 2024-01-20 09:47:00 --> Language Class Initialized
INFO - 2024-01-20 09:47:00 --> Loader Class Initialized
INFO - 2024-01-20 09:47:00 --> Helper loaded: url_helper
INFO - 2024-01-20 09:47:00 --> Helper loaded: file_helper
INFO - 2024-01-20 09:47:00 --> Helper loaded: html_helper
INFO - 2024-01-20 09:47:00 --> Helper loaded: text_helper
INFO - 2024-01-20 09:47:00 --> Helper loaded: form_helper
INFO - 2024-01-20 09:47:00 --> Helper loaded: lang_helper
INFO - 2024-01-20 09:47:00 --> Helper loaded: security_helper
INFO - 2024-01-20 09:47:00 --> Helper loaded: cookie_helper
INFO - 2024-01-20 09:47:00 --> Database Driver Class Initialized
INFO - 2024-01-20 09:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 09:47:00 --> Parser Class Initialized
INFO - 2024-01-20 09:47:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 09:47:00 --> Pagination Class Initialized
INFO - 2024-01-20 09:47:00 --> Form Validation Class Initialized
INFO - 2024-01-20 09:47:00 --> Controller Class Initialized
INFO - 2024-01-20 09:47:00 --> Model Class Initialized
DEBUG - 2024-01-20 09:47:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-20 09:47:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 09:47:01 --> Config Class Initialized
INFO - 2024-01-20 09:47:01 --> Hooks Class Initialized
DEBUG - 2024-01-20 09:47:01 --> UTF-8 Support Enabled
INFO - 2024-01-20 09:47:01 --> Utf8 Class Initialized
INFO - 2024-01-20 09:47:01 --> URI Class Initialized
INFO - 2024-01-20 09:47:01 --> Router Class Initialized
INFO - 2024-01-20 09:47:01 --> Output Class Initialized
INFO - 2024-01-20 09:47:01 --> Security Class Initialized
DEBUG - 2024-01-20 09:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 09:47:01 --> Input Class Initialized
INFO - 2024-01-20 09:47:01 --> Language Class Initialized
INFO - 2024-01-20 09:47:01 --> Loader Class Initialized
INFO - 2024-01-20 09:47:01 --> Helper loaded: url_helper
INFO - 2024-01-20 09:47:01 --> Helper loaded: file_helper
INFO - 2024-01-20 09:47:01 --> Helper loaded: html_helper
INFO - 2024-01-20 09:47:01 --> Helper loaded: text_helper
INFO - 2024-01-20 09:47:01 --> Helper loaded: form_helper
INFO - 2024-01-20 09:47:01 --> Helper loaded: lang_helper
INFO - 2024-01-20 09:47:01 --> Helper loaded: security_helper
INFO - 2024-01-20 09:47:01 --> Helper loaded: cookie_helper
INFO - 2024-01-20 09:47:01 --> Database Driver Class Initialized
INFO - 2024-01-20 09:47:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 09:47:01 --> Parser Class Initialized
INFO - 2024-01-20 09:47:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 09:47:01 --> Pagination Class Initialized
INFO - 2024-01-20 09:47:01 --> Form Validation Class Initialized
INFO - 2024-01-20 09:47:01 --> Controller Class Initialized
INFO - 2024-01-20 09:47:01 --> Model Class Initialized
DEBUG - 2024-01-20 09:47:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 09:47:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-20 09:47:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 09:47:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 09:47:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 09:47:01 --> Model Class Initialized
INFO - 2024-01-20 09:47:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 09:47:01 --> Final output sent to browser
DEBUG - 2024-01-20 09:47:01 --> Total execution time: 0.0279
ERROR - 2024-01-20 09:47:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 09:47:44 --> Config Class Initialized
INFO - 2024-01-20 09:47:44 --> Hooks Class Initialized
DEBUG - 2024-01-20 09:47:44 --> UTF-8 Support Enabled
INFO - 2024-01-20 09:47:44 --> Utf8 Class Initialized
INFO - 2024-01-20 09:47:44 --> URI Class Initialized
INFO - 2024-01-20 09:47:44 --> Router Class Initialized
INFO - 2024-01-20 09:47:44 --> Output Class Initialized
INFO - 2024-01-20 09:47:44 --> Security Class Initialized
DEBUG - 2024-01-20 09:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 09:47:44 --> Input Class Initialized
INFO - 2024-01-20 09:47:44 --> Language Class Initialized
INFO - 2024-01-20 09:47:44 --> Loader Class Initialized
INFO - 2024-01-20 09:47:44 --> Helper loaded: url_helper
INFO - 2024-01-20 09:47:44 --> Helper loaded: file_helper
INFO - 2024-01-20 09:47:44 --> Helper loaded: html_helper
INFO - 2024-01-20 09:47:44 --> Helper loaded: text_helper
INFO - 2024-01-20 09:47:44 --> Helper loaded: form_helper
INFO - 2024-01-20 09:47:44 --> Helper loaded: lang_helper
INFO - 2024-01-20 09:47:44 --> Helper loaded: security_helper
INFO - 2024-01-20 09:47:44 --> Helper loaded: cookie_helper
INFO - 2024-01-20 09:47:44 --> Database Driver Class Initialized
INFO - 2024-01-20 09:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 09:47:44 --> Parser Class Initialized
INFO - 2024-01-20 09:47:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 09:47:44 --> Pagination Class Initialized
INFO - 2024-01-20 09:47:44 --> Form Validation Class Initialized
INFO - 2024-01-20 09:47:44 --> Controller Class Initialized
INFO - 2024-01-20 09:47:44 --> Model Class Initialized
DEBUG - 2024-01-20 09:47:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 09:47:44 --> Model Class Initialized
INFO - 2024-01-20 09:47:44 --> Final output sent to browser
DEBUG - 2024-01-20 09:47:44 --> Total execution time: 0.0197
ERROR - 2024-01-20 09:47:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 09:47:44 --> Config Class Initialized
INFO - 2024-01-20 09:47:44 --> Hooks Class Initialized
DEBUG - 2024-01-20 09:47:44 --> UTF-8 Support Enabled
INFO - 2024-01-20 09:47:44 --> Utf8 Class Initialized
INFO - 2024-01-20 09:47:44 --> URI Class Initialized
DEBUG - 2024-01-20 09:47:44 --> No URI present. Default controller set.
INFO - 2024-01-20 09:47:44 --> Router Class Initialized
INFO - 2024-01-20 09:47:44 --> Output Class Initialized
INFO - 2024-01-20 09:47:44 --> Security Class Initialized
DEBUG - 2024-01-20 09:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 09:47:44 --> Input Class Initialized
INFO - 2024-01-20 09:47:44 --> Language Class Initialized
INFO - 2024-01-20 09:47:44 --> Loader Class Initialized
INFO - 2024-01-20 09:47:44 --> Helper loaded: url_helper
INFO - 2024-01-20 09:47:44 --> Helper loaded: file_helper
INFO - 2024-01-20 09:47:44 --> Helper loaded: html_helper
INFO - 2024-01-20 09:47:44 --> Helper loaded: text_helper
INFO - 2024-01-20 09:47:44 --> Helper loaded: form_helper
INFO - 2024-01-20 09:47:44 --> Helper loaded: lang_helper
INFO - 2024-01-20 09:47:44 --> Helper loaded: security_helper
INFO - 2024-01-20 09:47:44 --> Helper loaded: cookie_helper
INFO - 2024-01-20 09:47:44 --> Database Driver Class Initialized
INFO - 2024-01-20 09:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 09:47:44 --> Parser Class Initialized
INFO - 2024-01-20 09:47:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 09:47:44 --> Pagination Class Initialized
INFO - 2024-01-20 09:47:44 --> Form Validation Class Initialized
INFO - 2024-01-20 09:47:44 --> Controller Class Initialized
INFO - 2024-01-20 09:47:44 --> Model Class Initialized
DEBUG - 2024-01-20 09:47:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 09:47:44 --> Model Class Initialized
DEBUG - 2024-01-20 09:47:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 09:47:44 --> Model Class Initialized
INFO - 2024-01-20 09:47:44 --> Model Class Initialized
INFO - 2024-01-20 09:47:44 --> Model Class Initialized
INFO - 2024-01-20 09:47:44 --> Model Class Initialized
DEBUG - 2024-01-20 09:47:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 09:47:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 09:47:44 --> Model Class Initialized
INFO - 2024-01-20 09:47:44 --> Model Class Initialized
INFO - 2024-01-20 09:47:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-20 09:47:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 09:47:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 09:47:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 09:47:44 --> Model Class Initialized
INFO - 2024-01-20 09:47:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 09:47:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 09:47:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 09:47:44 --> Final output sent to browser
DEBUG - 2024-01-20 09:47:44 --> Total execution time: 0.3892
ERROR - 2024-01-20 09:47:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 09:47:46 --> Config Class Initialized
INFO - 2024-01-20 09:47:46 --> Hooks Class Initialized
DEBUG - 2024-01-20 09:47:46 --> UTF-8 Support Enabled
INFO - 2024-01-20 09:47:46 --> Utf8 Class Initialized
INFO - 2024-01-20 09:47:46 --> URI Class Initialized
INFO - 2024-01-20 09:47:46 --> Router Class Initialized
INFO - 2024-01-20 09:47:46 --> Output Class Initialized
INFO - 2024-01-20 09:47:46 --> Security Class Initialized
DEBUG - 2024-01-20 09:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 09:47:46 --> Input Class Initialized
INFO - 2024-01-20 09:47:46 --> Language Class Initialized
INFO - 2024-01-20 09:47:46 --> Loader Class Initialized
INFO - 2024-01-20 09:47:46 --> Helper loaded: url_helper
INFO - 2024-01-20 09:47:46 --> Helper loaded: file_helper
INFO - 2024-01-20 09:47:46 --> Helper loaded: html_helper
INFO - 2024-01-20 09:47:46 --> Helper loaded: text_helper
INFO - 2024-01-20 09:47:46 --> Helper loaded: form_helper
INFO - 2024-01-20 09:47:46 --> Helper loaded: lang_helper
INFO - 2024-01-20 09:47:46 --> Helper loaded: security_helper
INFO - 2024-01-20 09:47:46 --> Helper loaded: cookie_helper
INFO - 2024-01-20 09:47:46 --> Database Driver Class Initialized
INFO - 2024-01-20 09:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 09:47:46 --> Parser Class Initialized
INFO - 2024-01-20 09:47:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 09:47:46 --> Pagination Class Initialized
INFO - 2024-01-20 09:47:46 --> Form Validation Class Initialized
INFO - 2024-01-20 09:47:46 --> Controller Class Initialized
DEBUG - 2024-01-20 09:47:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 09:47:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 09:47:46 --> Model Class Initialized
INFO - 2024-01-20 09:47:46 --> Final output sent to browser
DEBUG - 2024-01-20 09:47:46 --> Total execution time: 0.0138
ERROR - 2024-01-20 09:47:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 09:47:54 --> Config Class Initialized
INFO - 2024-01-20 09:47:54 --> Hooks Class Initialized
DEBUG - 2024-01-20 09:47:54 --> UTF-8 Support Enabled
INFO - 2024-01-20 09:47:54 --> Utf8 Class Initialized
INFO - 2024-01-20 09:47:54 --> URI Class Initialized
INFO - 2024-01-20 09:47:54 --> Router Class Initialized
INFO - 2024-01-20 09:47:54 --> Output Class Initialized
INFO - 2024-01-20 09:47:54 --> Security Class Initialized
DEBUG - 2024-01-20 09:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 09:47:54 --> Input Class Initialized
INFO - 2024-01-20 09:47:54 --> Language Class Initialized
INFO - 2024-01-20 09:47:54 --> Loader Class Initialized
INFO - 2024-01-20 09:47:54 --> Helper loaded: url_helper
INFO - 2024-01-20 09:47:54 --> Helper loaded: file_helper
INFO - 2024-01-20 09:47:54 --> Helper loaded: html_helper
INFO - 2024-01-20 09:47:54 --> Helper loaded: text_helper
INFO - 2024-01-20 09:47:54 --> Helper loaded: form_helper
INFO - 2024-01-20 09:47:54 --> Helper loaded: lang_helper
INFO - 2024-01-20 09:47:54 --> Helper loaded: security_helper
INFO - 2024-01-20 09:47:54 --> Helper loaded: cookie_helper
INFO - 2024-01-20 09:47:54 --> Database Driver Class Initialized
INFO - 2024-01-20 09:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 09:47:54 --> Parser Class Initialized
INFO - 2024-01-20 09:47:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 09:47:54 --> Pagination Class Initialized
INFO - 2024-01-20 09:47:54 --> Form Validation Class Initialized
INFO - 2024-01-20 09:47:54 --> Controller Class Initialized
INFO - 2024-01-20 09:47:54 --> Model Class Initialized
DEBUG - 2024-01-20 09:47:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 09:47:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 09:47:54 --> Model Class Initialized
DEBUG - 2024-01-20 09:47:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 09:47:54 --> Model Class Initialized
INFO - 2024-01-20 09:47:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-20 09:47:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 09:47:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 09:47:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 09:47:54 --> Model Class Initialized
INFO - 2024-01-20 09:47:54 --> Model Class Initialized
INFO - 2024-01-20 09:47:54 --> Model Class Initialized
INFO - 2024-01-20 09:47:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 09:47:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 09:47:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 09:47:54 --> Final output sent to browser
DEBUG - 2024-01-20 09:47:54 --> Total execution time: 0.3867
ERROR - 2024-01-20 09:47:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 09:47:56 --> Config Class Initialized
INFO - 2024-01-20 09:47:56 --> Hooks Class Initialized
DEBUG - 2024-01-20 09:47:56 --> UTF-8 Support Enabled
INFO - 2024-01-20 09:47:56 --> Utf8 Class Initialized
INFO - 2024-01-20 09:47:56 --> URI Class Initialized
INFO - 2024-01-20 09:47:56 --> Router Class Initialized
INFO - 2024-01-20 09:47:56 --> Output Class Initialized
INFO - 2024-01-20 09:47:56 --> Security Class Initialized
DEBUG - 2024-01-20 09:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 09:47:56 --> Input Class Initialized
INFO - 2024-01-20 09:47:56 --> Language Class Initialized
INFO - 2024-01-20 09:47:56 --> Loader Class Initialized
INFO - 2024-01-20 09:47:56 --> Helper loaded: url_helper
INFO - 2024-01-20 09:47:56 --> Helper loaded: file_helper
INFO - 2024-01-20 09:47:56 --> Helper loaded: html_helper
INFO - 2024-01-20 09:47:56 --> Helper loaded: text_helper
INFO - 2024-01-20 09:47:56 --> Helper loaded: form_helper
INFO - 2024-01-20 09:47:56 --> Helper loaded: lang_helper
INFO - 2024-01-20 09:47:56 --> Helper loaded: security_helper
INFO - 2024-01-20 09:47:56 --> Helper loaded: cookie_helper
INFO - 2024-01-20 09:47:56 --> Database Driver Class Initialized
INFO - 2024-01-20 09:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 09:47:56 --> Parser Class Initialized
INFO - 2024-01-20 09:47:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 09:47:56 --> Pagination Class Initialized
INFO - 2024-01-20 09:47:56 --> Form Validation Class Initialized
INFO - 2024-01-20 09:47:56 --> Controller Class Initialized
INFO - 2024-01-20 09:47:56 --> Model Class Initialized
DEBUG - 2024-01-20 09:47:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 09:47:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 09:47:56 --> Model Class Initialized
DEBUG - 2024-01-20 09:47:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 09:47:56 --> Model Class Initialized
INFO - 2024-01-20 09:47:56 --> Final output sent to browser
DEBUG - 2024-01-20 09:47:56 --> Total execution time: 0.0596
ERROR - 2024-01-20 09:48:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 09:48:13 --> Config Class Initialized
INFO - 2024-01-20 09:48:13 --> Hooks Class Initialized
DEBUG - 2024-01-20 09:48:13 --> UTF-8 Support Enabled
INFO - 2024-01-20 09:48:13 --> Utf8 Class Initialized
INFO - 2024-01-20 09:48:13 --> URI Class Initialized
INFO - 2024-01-20 09:48:13 --> Router Class Initialized
INFO - 2024-01-20 09:48:13 --> Output Class Initialized
INFO - 2024-01-20 09:48:13 --> Security Class Initialized
DEBUG - 2024-01-20 09:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 09:48:13 --> Input Class Initialized
INFO - 2024-01-20 09:48:13 --> Language Class Initialized
INFO - 2024-01-20 09:48:13 --> Loader Class Initialized
INFO - 2024-01-20 09:48:13 --> Helper loaded: url_helper
INFO - 2024-01-20 09:48:13 --> Helper loaded: file_helper
INFO - 2024-01-20 09:48:13 --> Helper loaded: html_helper
INFO - 2024-01-20 09:48:13 --> Helper loaded: text_helper
INFO - 2024-01-20 09:48:13 --> Helper loaded: form_helper
INFO - 2024-01-20 09:48:13 --> Helper loaded: lang_helper
INFO - 2024-01-20 09:48:13 --> Helper loaded: security_helper
INFO - 2024-01-20 09:48:13 --> Helper loaded: cookie_helper
INFO - 2024-01-20 09:48:13 --> Database Driver Class Initialized
INFO - 2024-01-20 09:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 09:48:13 --> Parser Class Initialized
INFO - 2024-01-20 09:48:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 09:48:13 --> Pagination Class Initialized
INFO - 2024-01-20 09:48:13 --> Form Validation Class Initialized
INFO - 2024-01-20 09:48:13 --> Controller Class Initialized
INFO - 2024-01-20 09:48:13 --> Model Class Initialized
DEBUG - 2024-01-20 09:48:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 09:48:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 09:48:13 --> Model Class Initialized
DEBUG - 2024-01-20 09:48:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 09:48:13 --> Model Class Initialized
DEBUG - 2024-01-20 09:48:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 09:48:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-01-20 09:48:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 09:48:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 09:48:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 09:48:13 --> Model Class Initialized
INFO - 2024-01-20 09:48:13 --> Model Class Initialized
INFO - 2024-01-20 09:48:13 --> Model Class Initialized
INFO - 2024-01-20 09:48:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 09:48:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 09:48:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 09:48:13 --> Final output sent to browser
DEBUG - 2024-01-20 09:48:13 --> Total execution time: 0.2290
ERROR - 2024-01-20 09:48:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 09:48:26 --> Config Class Initialized
INFO - 2024-01-20 09:48:26 --> Hooks Class Initialized
DEBUG - 2024-01-20 09:48:26 --> UTF-8 Support Enabled
INFO - 2024-01-20 09:48:26 --> Utf8 Class Initialized
INFO - 2024-01-20 09:48:26 --> URI Class Initialized
INFO - 2024-01-20 09:48:26 --> Router Class Initialized
INFO - 2024-01-20 09:48:26 --> Output Class Initialized
INFO - 2024-01-20 09:48:26 --> Security Class Initialized
DEBUG - 2024-01-20 09:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 09:48:26 --> Input Class Initialized
INFO - 2024-01-20 09:48:26 --> Language Class Initialized
INFO - 2024-01-20 09:48:26 --> Loader Class Initialized
INFO - 2024-01-20 09:48:26 --> Helper loaded: url_helper
INFO - 2024-01-20 09:48:26 --> Helper loaded: file_helper
INFO - 2024-01-20 09:48:26 --> Helper loaded: html_helper
INFO - 2024-01-20 09:48:26 --> Helper loaded: text_helper
INFO - 2024-01-20 09:48:26 --> Helper loaded: form_helper
INFO - 2024-01-20 09:48:26 --> Helper loaded: lang_helper
INFO - 2024-01-20 09:48:26 --> Helper loaded: security_helper
INFO - 2024-01-20 09:48:26 --> Helper loaded: cookie_helper
INFO - 2024-01-20 09:48:26 --> Database Driver Class Initialized
INFO - 2024-01-20 09:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 09:48:26 --> Parser Class Initialized
INFO - 2024-01-20 09:48:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 09:48:26 --> Pagination Class Initialized
INFO - 2024-01-20 09:48:26 --> Form Validation Class Initialized
INFO - 2024-01-20 09:48:26 --> Controller Class Initialized
INFO - 2024-01-20 09:48:26 --> Model Class Initialized
DEBUG - 2024-01-20 09:48:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 09:48:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 09:48:26 --> Model Class Initialized
DEBUG - 2024-01-20 09:48:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 09:48:26 --> Model Class Initialized
INFO - 2024-01-20 09:48:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-20 09:48:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 09:48:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 09:48:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 09:48:26 --> Model Class Initialized
INFO - 2024-01-20 09:48:26 --> Model Class Initialized
INFO - 2024-01-20 09:48:26 --> Model Class Initialized
INFO - 2024-01-20 09:48:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 09:48:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 09:48:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 09:48:26 --> Final output sent to browser
DEBUG - 2024-01-20 09:48:26 --> Total execution time: 0.2139
ERROR - 2024-01-20 09:48:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 09:48:27 --> Config Class Initialized
INFO - 2024-01-20 09:48:27 --> Hooks Class Initialized
DEBUG - 2024-01-20 09:48:27 --> UTF-8 Support Enabled
INFO - 2024-01-20 09:48:27 --> Utf8 Class Initialized
INFO - 2024-01-20 09:48:27 --> URI Class Initialized
INFO - 2024-01-20 09:48:27 --> Router Class Initialized
INFO - 2024-01-20 09:48:27 --> Output Class Initialized
INFO - 2024-01-20 09:48:27 --> Security Class Initialized
DEBUG - 2024-01-20 09:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 09:48:27 --> Input Class Initialized
INFO - 2024-01-20 09:48:27 --> Language Class Initialized
INFO - 2024-01-20 09:48:27 --> Loader Class Initialized
INFO - 2024-01-20 09:48:27 --> Helper loaded: url_helper
INFO - 2024-01-20 09:48:27 --> Helper loaded: file_helper
INFO - 2024-01-20 09:48:27 --> Helper loaded: html_helper
INFO - 2024-01-20 09:48:27 --> Helper loaded: text_helper
INFO - 2024-01-20 09:48:27 --> Helper loaded: form_helper
INFO - 2024-01-20 09:48:27 --> Helper loaded: lang_helper
INFO - 2024-01-20 09:48:27 --> Helper loaded: security_helper
INFO - 2024-01-20 09:48:27 --> Helper loaded: cookie_helper
INFO - 2024-01-20 09:48:27 --> Database Driver Class Initialized
INFO - 2024-01-20 09:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 09:48:27 --> Parser Class Initialized
INFO - 2024-01-20 09:48:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 09:48:27 --> Pagination Class Initialized
INFO - 2024-01-20 09:48:27 --> Form Validation Class Initialized
INFO - 2024-01-20 09:48:27 --> Controller Class Initialized
INFO - 2024-01-20 09:48:27 --> Model Class Initialized
DEBUG - 2024-01-20 09:48:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 09:48:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 09:48:27 --> Model Class Initialized
DEBUG - 2024-01-20 09:48:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 09:48:27 --> Model Class Initialized
INFO - 2024-01-20 09:48:27 --> Final output sent to browser
DEBUG - 2024-01-20 09:48:27 --> Total execution time: 0.0561
ERROR - 2024-01-20 09:48:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 09:48:29 --> Config Class Initialized
INFO - 2024-01-20 09:48:29 --> Hooks Class Initialized
DEBUG - 2024-01-20 09:48:29 --> UTF-8 Support Enabled
INFO - 2024-01-20 09:48:29 --> Utf8 Class Initialized
INFO - 2024-01-20 09:48:29 --> URI Class Initialized
DEBUG - 2024-01-20 09:48:29 --> No URI present. Default controller set.
INFO - 2024-01-20 09:48:29 --> Router Class Initialized
INFO - 2024-01-20 09:48:29 --> Output Class Initialized
INFO - 2024-01-20 09:48:29 --> Security Class Initialized
DEBUG - 2024-01-20 09:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 09:48:29 --> Input Class Initialized
INFO - 2024-01-20 09:48:29 --> Language Class Initialized
INFO - 2024-01-20 09:48:29 --> Loader Class Initialized
INFO - 2024-01-20 09:48:29 --> Helper loaded: url_helper
INFO - 2024-01-20 09:48:29 --> Helper loaded: file_helper
INFO - 2024-01-20 09:48:29 --> Helper loaded: html_helper
INFO - 2024-01-20 09:48:29 --> Helper loaded: text_helper
INFO - 2024-01-20 09:48:29 --> Helper loaded: form_helper
INFO - 2024-01-20 09:48:29 --> Helper loaded: lang_helper
INFO - 2024-01-20 09:48:29 --> Helper loaded: security_helper
INFO - 2024-01-20 09:48:29 --> Helper loaded: cookie_helper
INFO - 2024-01-20 09:48:29 --> Database Driver Class Initialized
INFO - 2024-01-20 09:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 09:48:29 --> Parser Class Initialized
INFO - 2024-01-20 09:48:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 09:48:29 --> Pagination Class Initialized
INFO - 2024-01-20 09:48:29 --> Form Validation Class Initialized
INFO - 2024-01-20 09:48:29 --> Controller Class Initialized
INFO - 2024-01-20 09:48:29 --> Model Class Initialized
DEBUG - 2024-01-20 09:48:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 09:48:29 --> Model Class Initialized
DEBUG - 2024-01-20 09:48:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 09:48:29 --> Model Class Initialized
INFO - 2024-01-20 09:48:29 --> Model Class Initialized
INFO - 2024-01-20 09:48:29 --> Model Class Initialized
INFO - 2024-01-20 09:48:29 --> Model Class Initialized
DEBUG - 2024-01-20 09:48:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 09:48:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 09:48:29 --> Model Class Initialized
INFO - 2024-01-20 09:48:29 --> Model Class Initialized
INFO - 2024-01-20 09:48:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-20 09:48:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 09:48:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 09:48:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 09:48:29 --> Model Class Initialized
INFO - 2024-01-20 09:48:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 09:48:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 09:48:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 09:48:29 --> Final output sent to browser
DEBUG - 2024-01-20 09:48:29 --> Total execution time: 0.3802
ERROR - 2024-01-20 09:48:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 09:48:35 --> Config Class Initialized
INFO - 2024-01-20 09:48:35 --> Hooks Class Initialized
DEBUG - 2024-01-20 09:48:35 --> UTF-8 Support Enabled
INFO - 2024-01-20 09:48:35 --> Utf8 Class Initialized
INFO - 2024-01-20 09:48:35 --> URI Class Initialized
INFO - 2024-01-20 09:48:35 --> Router Class Initialized
INFO - 2024-01-20 09:48:35 --> Output Class Initialized
INFO - 2024-01-20 09:48:35 --> Security Class Initialized
DEBUG - 2024-01-20 09:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 09:48:35 --> Input Class Initialized
INFO - 2024-01-20 09:48:35 --> Language Class Initialized
INFO - 2024-01-20 09:48:35 --> Loader Class Initialized
INFO - 2024-01-20 09:48:35 --> Helper loaded: url_helper
INFO - 2024-01-20 09:48:35 --> Helper loaded: file_helper
INFO - 2024-01-20 09:48:35 --> Helper loaded: html_helper
INFO - 2024-01-20 09:48:35 --> Helper loaded: text_helper
INFO - 2024-01-20 09:48:35 --> Helper loaded: form_helper
INFO - 2024-01-20 09:48:35 --> Helper loaded: lang_helper
INFO - 2024-01-20 09:48:35 --> Helper loaded: security_helper
INFO - 2024-01-20 09:48:35 --> Helper loaded: cookie_helper
INFO - 2024-01-20 09:48:35 --> Database Driver Class Initialized
INFO - 2024-01-20 09:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 09:48:35 --> Parser Class Initialized
INFO - 2024-01-20 09:48:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 09:48:35 --> Pagination Class Initialized
INFO - 2024-01-20 09:48:35 --> Form Validation Class Initialized
INFO - 2024-01-20 09:48:35 --> Controller Class Initialized
INFO - 2024-01-20 09:48:35 --> Model Class Initialized
DEBUG - 2024-01-20 09:48:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 09:48:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-20 09:48:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 09:48:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 09:48:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 09:48:35 --> Model Class Initialized
INFO - 2024-01-20 09:48:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 09:48:35 --> Final output sent to browser
DEBUG - 2024-01-20 09:48:35 --> Total execution time: 0.0275
ERROR - 2024-01-20 09:48:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 09:48:35 --> Config Class Initialized
INFO - 2024-01-20 09:48:35 --> Hooks Class Initialized
DEBUG - 2024-01-20 09:48:35 --> UTF-8 Support Enabled
INFO - 2024-01-20 09:48:35 --> Utf8 Class Initialized
INFO - 2024-01-20 09:48:35 --> URI Class Initialized
INFO - 2024-01-20 09:48:35 --> Router Class Initialized
INFO - 2024-01-20 09:48:35 --> Output Class Initialized
INFO - 2024-01-20 09:48:35 --> Security Class Initialized
DEBUG - 2024-01-20 09:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 09:48:35 --> Input Class Initialized
INFO - 2024-01-20 09:48:35 --> Language Class Initialized
INFO - 2024-01-20 09:48:35 --> Loader Class Initialized
INFO - 2024-01-20 09:48:35 --> Helper loaded: url_helper
INFO - 2024-01-20 09:48:35 --> Helper loaded: file_helper
INFO - 2024-01-20 09:48:35 --> Helper loaded: html_helper
INFO - 2024-01-20 09:48:35 --> Helper loaded: text_helper
INFO - 2024-01-20 09:48:35 --> Helper loaded: form_helper
INFO - 2024-01-20 09:48:35 --> Helper loaded: lang_helper
INFO - 2024-01-20 09:48:35 --> Helper loaded: security_helper
INFO - 2024-01-20 09:48:35 --> Helper loaded: cookie_helper
INFO - 2024-01-20 09:48:35 --> Database Driver Class Initialized
INFO - 2024-01-20 09:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 09:48:35 --> Parser Class Initialized
INFO - 2024-01-20 09:48:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 09:48:35 --> Pagination Class Initialized
INFO - 2024-01-20 09:48:35 --> Form Validation Class Initialized
INFO - 2024-01-20 09:48:35 --> Controller Class Initialized
INFO - 2024-01-20 09:48:35 --> Model Class Initialized
DEBUG - 2024-01-20 09:48:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 09:48:35 --> Model Class Initialized
DEBUG - 2024-01-20 09:48:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 09:48:35 --> Model Class Initialized
INFO - 2024-01-20 09:48:35 --> Model Class Initialized
INFO - 2024-01-20 09:48:35 --> Model Class Initialized
INFO - 2024-01-20 09:48:35 --> Model Class Initialized
DEBUG - 2024-01-20 09:48:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 09:48:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 09:48:35 --> Model Class Initialized
INFO - 2024-01-20 09:48:35 --> Model Class Initialized
INFO - 2024-01-20 09:48:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-20 09:48:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 09:48:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 09:48:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 09:48:36 --> Model Class Initialized
INFO - 2024-01-20 09:48:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 09:48:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 09:48:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 09:48:36 --> Final output sent to browser
DEBUG - 2024-01-20 09:48:36 --> Total execution time: 0.3754
ERROR - 2024-01-20 10:16:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 10:16:50 --> Config Class Initialized
INFO - 2024-01-20 10:16:50 --> Hooks Class Initialized
DEBUG - 2024-01-20 10:16:50 --> UTF-8 Support Enabled
INFO - 2024-01-20 10:16:50 --> Utf8 Class Initialized
INFO - 2024-01-20 10:16:50 --> URI Class Initialized
DEBUG - 2024-01-20 10:16:50 --> No URI present. Default controller set.
INFO - 2024-01-20 10:16:50 --> Router Class Initialized
INFO - 2024-01-20 10:16:50 --> Output Class Initialized
INFO - 2024-01-20 10:16:50 --> Security Class Initialized
DEBUG - 2024-01-20 10:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 10:16:50 --> Input Class Initialized
INFO - 2024-01-20 10:16:50 --> Language Class Initialized
INFO - 2024-01-20 10:16:50 --> Loader Class Initialized
INFO - 2024-01-20 10:16:50 --> Helper loaded: url_helper
INFO - 2024-01-20 10:16:50 --> Helper loaded: file_helper
INFO - 2024-01-20 10:16:50 --> Helper loaded: html_helper
INFO - 2024-01-20 10:16:50 --> Helper loaded: text_helper
INFO - 2024-01-20 10:16:50 --> Helper loaded: form_helper
INFO - 2024-01-20 10:16:50 --> Helper loaded: lang_helper
INFO - 2024-01-20 10:16:50 --> Helper loaded: security_helper
INFO - 2024-01-20 10:16:50 --> Helper loaded: cookie_helper
INFO - 2024-01-20 10:16:50 --> Database Driver Class Initialized
INFO - 2024-01-20 10:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 10:16:50 --> Parser Class Initialized
INFO - 2024-01-20 10:16:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 10:16:50 --> Pagination Class Initialized
INFO - 2024-01-20 10:16:50 --> Form Validation Class Initialized
INFO - 2024-01-20 10:16:50 --> Controller Class Initialized
INFO - 2024-01-20 10:16:50 --> Model Class Initialized
DEBUG - 2024-01-20 10:16:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 10:16:50 --> Model Class Initialized
DEBUG - 2024-01-20 10:16:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 10:16:50 --> Model Class Initialized
INFO - 2024-01-20 10:16:50 --> Model Class Initialized
INFO - 2024-01-20 10:16:50 --> Model Class Initialized
INFO - 2024-01-20 10:16:50 --> Model Class Initialized
DEBUG - 2024-01-20 10:16:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 10:16:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 10:16:50 --> Model Class Initialized
INFO - 2024-01-20 10:16:50 --> Model Class Initialized
INFO - 2024-01-20 10:16:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-20 10:16:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 10:16:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 10:16:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 10:16:51 --> Model Class Initialized
INFO - 2024-01-20 10:16:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 10:16:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 10:16:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 10:16:51 --> Final output sent to browser
DEBUG - 2024-01-20 10:16:51 --> Total execution time: 0.3927
ERROR - 2024-01-20 10:26:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 10:26:41 --> Config Class Initialized
INFO - 2024-01-20 10:26:41 --> Hooks Class Initialized
DEBUG - 2024-01-20 10:26:41 --> UTF-8 Support Enabled
INFO - 2024-01-20 10:26:41 --> Utf8 Class Initialized
INFO - 2024-01-20 10:26:41 --> URI Class Initialized
DEBUG - 2024-01-20 10:26:41 --> No URI present. Default controller set.
INFO - 2024-01-20 10:26:41 --> Router Class Initialized
INFO - 2024-01-20 10:26:41 --> Output Class Initialized
INFO - 2024-01-20 10:26:41 --> Security Class Initialized
DEBUG - 2024-01-20 10:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 10:26:41 --> Input Class Initialized
INFO - 2024-01-20 10:26:41 --> Language Class Initialized
INFO - 2024-01-20 10:26:41 --> Loader Class Initialized
INFO - 2024-01-20 10:26:41 --> Helper loaded: url_helper
INFO - 2024-01-20 10:26:41 --> Helper loaded: file_helper
INFO - 2024-01-20 10:26:41 --> Helper loaded: html_helper
INFO - 2024-01-20 10:26:41 --> Helper loaded: text_helper
INFO - 2024-01-20 10:26:41 --> Helper loaded: form_helper
INFO - 2024-01-20 10:26:41 --> Helper loaded: lang_helper
INFO - 2024-01-20 10:26:41 --> Helper loaded: security_helper
INFO - 2024-01-20 10:26:41 --> Helper loaded: cookie_helper
INFO - 2024-01-20 10:26:41 --> Database Driver Class Initialized
INFO - 2024-01-20 10:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 10:26:41 --> Parser Class Initialized
INFO - 2024-01-20 10:26:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 10:26:41 --> Pagination Class Initialized
INFO - 2024-01-20 10:26:41 --> Form Validation Class Initialized
INFO - 2024-01-20 10:26:41 --> Controller Class Initialized
INFO - 2024-01-20 10:26:41 --> Model Class Initialized
DEBUG - 2024-01-20 10:26:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 10:26:41 --> Model Class Initialized
DEBUG - 2024-01-20 10:26:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 10:26:41 --> Model Class Initialized
INFO - 2024-01-20 10:26:41 --> Model Class Initialized
INFO - 2024-01-20 10:26:41 --> Model Class Initialized
INFO - 2024-01-20 10:26:41 --> Model Class Initialized
DEBUG - 2024-01-20 10:26:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-20 10:26:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 10:26:41 --> Model Class Initialized
INFO - 2024-01-20 10:26:41 --> Model Class Initialized
INFO - 2024-01-20 10:26:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-20 10:26:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 10:26:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 10:26:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 10:26:41 --> Model Class Initialized
INFO - 2024-01-20 10:26:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-20 10:26:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-20 10:26:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 10:26:41 --> Final output sent to browser
DEBUG - 2024-01-20 10:26:41 --> Total execution time: 0.3884
ERROR - 2024-01-20 13:58:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 13:58:16 --> Config Class Initialized
INFO - 2024-01-20 13:58:16 --> Hooks Class Initialized
DEBUG - 2024-01-20 13:58:16 --> UTF-8 Support Enabled
INFO - 2024-01-20 13:58:16 --> Utf8 Class Initialized
INFO - 2024-01-20 13:58:16 --> URI Class Initialized
DEBUG - 2024-01-20 13:58:16 --> No URI present. Default controller set.
INFO - 2024-01-20 13:58:16 --> Router Class Initialized
INFO - 2024-01-20 13:58:16 --> Output Class Initialized
INFO - 2024-01-20 13:58:16 --> Security Class Initialized
DEBUG - 2024-01-20 13:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 13:58:16 --> Input Class Initialized
INFO - 2024-01-20 13:58:16 --> Language Class Initialized
INFO - 2024-01-20 13:58:16 --> Loader Class Initialized
INFO - 2024-01-20 13:58:16 --> Helper loaded: url_helper
INFO - 2024-01-20 13:58:16 --> Helper loaded: file_helper
INFO - 2024-01-20 13:58:16 --> Helper loaded: html_helper
INFO - 2024-01-20 13:58:16 --> Helper loaded: text_helper
INFO - 2024-01-20 13:58:16 --> Helper loaded: form_helper
INFO - 2024-01-20 13:58:16 --> Helper loaded: lang_helper
INFO - 2024-01-20 13:58:16 --> Helper loaded: security_helper
INFO - 2024-01-20 13:58:16 --> Helper loaded: cookie_helper
INFO - 2024-01-20 13:58:16 --> Database Driver Class Initialized
INFO - 2024-01-20 13:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 13:58:16 --> Parser Class Initialized
INFO - 2024-01-20 13:58:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 13:58:16 --> Pagination Class Initialized
INFO - 2024-01-20 13:58:16 --> Form Validation Class Initialized
INFO - 2024-01-20 13:58:16 --> Controller Class Initialized
INFO - 2024-01-20 13:58:16 --> Model Class Initialized
DEBUG - 2024-01-20 13:58:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-20 13:58:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 13:58:19 --> Config Class Initialized
INFO - 2024-01-20 13:58:19 --> Hooks Class Initialized
DEBUG - 2024-01-20 13:58:19 --> UTF-8 Support Enabled
INFO - 2024-01-20 13:58:19 --> Utf8 Class Initialized
INFO - 2024-01-20 13:58:19 --> URI Class Initialized
INFO - 2024-01-20 13:58:19 --> Router Class Initialized
INFO - 2024-01-20 13:58:19 --> Output Class Initialized
INFO - 2024-01-20 13:58:19 --> Security Class Initialized
DEBUG - 2024-01-20 13:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 13:58:19 --> Input Class Initialized
INFO - 2024-01-20 13:58:19 --> Language Class Initialized
INFO - 2024-01-20 13:58:19 --> Loader Class Initialized
INFO - 2024-01-20 13:58:19 --> Helper loaded: url_helper
INFO - 2024-01-20 13:58:19 --> Helper loaded: file_helper
INFO - 2024-01-20 13:58:19 --> Helper loaded: html_helper
INFO - 2024-01-20 13:58:19 --> Helper loaded: text_helper
INFO - 2024-01-20 13:58:19 --> Helper loaded: form_helper
INFO - 2024-01-20 13:58:19 --> Helper loaded: lang_helper
INFO - 2024-01-20 13:58:19 --> Helper loaded: security_helper
INFO - 2024-01-20 13:58:19 --> Helper loaded: cookie_helper
INFO - 2024-01-20 13:58:19 --> Database Driver Class Initialized
INFO - 2024-01-20 13:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 13:58:19 --> Parser Class Initialized
INFO - 2024-01-20 13:58:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-20 13:58:19 --> Pagination Class Initialized
INFO - 2024-01-20 13:58:19 --> Form Validation Class Initialized
INFO - 2024-01-20 13:58:19 --> Controller Class Initialized
INFO - 2024-01-20 13:58:19 --> Model Class Initialized
DEBUG - 2024-01-20 13:58:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-20 13:58:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-20 13:58:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-20 13:58:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-20 13:58:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-20 13:58:19 --> Model Class Initialized
INFO - 2024-01-20 13:58:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-20 13:58:19 --> Final output sent to browser
DEBUG - 2024-01-20 13:58:19 --> Total execution time: 0.0447
ERROR - 2024-01-20 20:59:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 20:59:01 --> Config Class Initialized
INFO - 2024-01-20 20:59:01 --> Hooks Class Initialized
DEBUG - 2024-01-20 20:59:01 --> UTF-8 Support Enabled
INFO - 2024-01-20 20:59:01 --> Utf8 Class Initialized
INFO - 2024-01-20 20:59:01 --> URI Class Initialized
INFO - 2024-01-20 20:59:01 --> Router Class Initialized
INFO - 2024-01-20 20:59:01 --> Output Class Initialized
INFO - 2024-01-20 20:59:01 --> Security Class Initialized
DEBUG - 2024-01-20 20:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 20:59:01 --> Input Class Initialized
INFO - 2024-01-20 20:59:01 --> Language Class Initialized
ERROR - 2024-01-20 20:59:01 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-01-20 23:45:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-20 23:45:57 --> Config Class Initialized
INFO - 2024-01-20 23:45:57 --> Hooks Class Initialized
DEBUG - 2024-01-20 23:45:57 --> UTF-8 Support Enabled
INFO - 2024-01-20 23:45:57 --> Utf8 Class Initialized
INFO - 2024-01-20 23:45:57 --> URI Class Initialized
INFO - 2024-01-20 23:45:57 --> Router Class Initialized
INFO - 2024-01-20 23:45:57 --> Output Class Initialized
INFO - 2024-01-20 23:45:57 --> Security Class Initialized
DEBUG - 2024-01-20 23:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 23:45:57 --> Input Class Initialized
INFO - 2024-01-20 23:45:57 --> Language Class Initialized
ERROR - 2024-01-20 23:45:57 --> 404 Page Not Found: Well-known/assetlinks.json
