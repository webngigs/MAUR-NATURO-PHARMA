<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-22 05:13:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:13:20 --> Config Class Initialized
INFO - 2023-09-22 05:13:20 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:13:20 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:13:20 --> Utf8 Class Initialized
INFO - 2023-09-22 05:13:20 --> URI Class Initialized
DEBUG - 2023-09-22 05:13:20 --> No URI present. Default controller set.
INFO - 2023-09-22 05:13:20 --> Router Class Initialized
INFO - 2023-09-22 05:13:20 --> Output Class Initialized
INFO - 2023-09-22 05:13:20 --> Security Class Initialized
DEBUG - 2023-09-22 05:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:13:20 --> Input Class Initialized
INFO - 2023-09-22 05:13:20 --> Language Class Initialized
INFO - 2023-09-22 05:13:20 --> Loader Class Initialized
INFO - 2023-09-22 05:13:20 --> Helper loaded: url_helper
INFO - 2023-09-22 05:13:20 --> Helper loaded: file_helper
INFO - 2023-09-22 05:13:20 --> Helper loaded: html_helper
INFO - 2023-09-22 05:13:20 --> Helper loaded: text_helper
INFO - 2023-09-22 05:13:20 --> Helper loaded: form_helper
INFO - 2023-09-22 05:13:20 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:13:20 --> Helper loaded: security_helper
INFO - 2023-09-22 05:13:20 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:13:20 --> Database Driver Class Initialized
INFO - 2023-09-22 05:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:13:20 --> Parser Class Initialized
INFO - 2023-09-22 05:13:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:13:20 --> Pagination Class Initialized
INFO - 2023-09-22 05:13:20 --> Form Validation Class Initialized
INFO - 2023-09-22 05:13:20 --> Controller Class Initialized
INFO - 2023-09-22 05:13:20 --> Model Class Initialized
DEBUG - 2023-09-22 05:13:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-22 05:13:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:13:20 --> Config Class Initialized
INFO - 2023-09-22 05:13:20 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:13:20 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:13:20 --> Utf8 Class Initialized
INFO - 2023-09-22 05:13:20 --> URI Class Initialized
INFO - 2023-09-22 05:13:20 --> Router Class Initialized
INFO - 2023-09-22 05:13:20 --> Output Class Initialized
INFO - 2023-09-22 05:13:20 --> Security Class Initialized
DEBUG - 2023-09-22 05:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:13:20 --> Input Class Initialized
INFO - 2023-09-22 05:13:20 --> Language Class Initialized
INFO - 2023-09-22 05:13:20 --> Loader Class Initialized
INFO - 2023-09-22 05:13:20 --> Helper loaded: url_helper
INFO - 2023-09-22 05:13:20 --> Helper loaded: file_helper
INFO - 2023-09-22 05:13:20 --> Helper loaded: html_helper
INFO - 2023-09-22 05:13:20 --> Helper loaded: text_helper
INFO - 2023-09-22 05:13:20 --> Helper loaded: form_helper
INFO - 2023-09-22 05:13:20 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:13:20 --> Helper loaded: security_helper
INFO - 2023-09-22 05:13:20 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:13:20 --> Database Driver Class Initialized
INFO - 2023-09-22 05:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:13:20 --> Parser Class Initialized
INFO - 2023-09-22 05:13:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:13:20 --> Pagination Class Initialized
INFO - 2023-09-22 05:13:20 --> Form Validation Class Initialized
INFO - 2023-09-22 05:13:20 --> Controller Class Initialized
INFO - 2023-09-22 05:13:20 --> Model Class Initialized
DEBUG - 2023-09-22 05:13:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:13:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-22 05:13:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:13:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-22 05:13:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-22 05:13:20 --> Model Class Initialized
INFO - 2023-09-22 05:13:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-22 05:13:20 --> Final output sent to browser
DEBUG - 2023-09-22 05:13:20 --> Total execution time: 0.0352
ERROR - 2023-09-22 05:13:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:13:51 --> Config Class Initialized
INFO - 2023-09-22 05:13:51 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:13:51 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:13:51 --> Utf8 Class Initialized
INFO - 2023-09-22 05:13:51 --> URI Class Initialized
INFO - 2023-09-22 05:13:51 --> Router Class Initialized
INFO - 2023-09-22 05:13:51 --> Output Class Initialized
INFO - 2023-09-22 05:13:51 --> Security Class Initialized
DEBUG - 2023-09-22 05:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:13:51 --> Input Class Initialized
INFO - 2023-09-22 05:13:51 --> Language Class Initialized
INFO - 2023-09-22 05:13:51 --> Loader Class Initialized
INFO - 2023-09-22 05:13:51 --> Helper loaded: url_helper
INFO - 2023-09-22 05:13:51 --> Helper loaded: file_helper
INFO - 2023-09-22 05:13:51 --> Helper loaded: html_helper
INFO - 2023-09-22 05:13:51 --> Helper loaded: text_helper
INFO - 2023-09-22 05:13:51 --> Helper loaded: form_helper
INFO - 2023-09-22 05:13:51 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:13:51 --> Helper loaded: security_helper
INFO - 2023-09-22 05:13:51 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:13:51 --> Database Driver Class Initialized
INFO - 2023-09-22 05:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:13:51 --> Parser Class Initialized
INFO - 2023-09-22 05:13:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:13:51 --> Pagination Class Initialized
INFO - 2023-09-22 05:13:51 --> Form Validation Class Initialized
INFO - 2023-09-22 05:13:51 --> Controller Class Initialized
INFO - 2023-09-22 05:13:51 --> Model Class Initialized
DEBUG - 2023-09-22 05:13:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:13:51 --> Model Class Initialized
INFO - 2023-09-22 05:13:51 --> Final output sent to browser
DEBUG - 2023-09-22 05:13:51 --> Total execution time: 0.0209
ERROR - 2023-09-22 05:13:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:13:52 --> Config Class Initialized
INFO - 2023-09-22 05:13:52 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:13:52 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:13:52 --> Utf8 Class Initialized
INFO - 2023-09-22 05:13:52 --> URI Class Initialized
DEBUG - 2023-09-22 05:13:52 --> No URI present. Default controller set.
INFO - 2023-09-22 05:13:52 --> Router Class Initialized
INFO - 2023-09-22 05:13:52 --> Output Class Initialized
INFO - 2023-09-22 05:13:52 --> Security Class Initialized
DEBUG - 2023-09-22 05:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:13:52 --> Input Class Initialized
INFO - 2023-09-22 05:13:52 --> Language Class Initialized
INFO - 2023-09-22 05:13:52 --> Loader Class Initialized
INFO - 2023-09-22 05:13:52 --> Helper loaded: url_helper
INFO - 2023-09-22 05:13:52 --> Helper loaded: file_helper
INFO - 2023-09-22 05:13:52 --> Helper loaded: html_helper
INFO - 2023-09-22 05:13:52 --> Helper loaded: text_helper
INFO - 2023-09-22 05:13:52 --> Helper loaded: form_helper
INFO - 2023-09-22 05:13:52 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:13:52 --> Helper loaded: security_helper
INFO - 2023-09-22 05:13:52 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:13:52 --> Database Driver Class Initialized
INFO - 2023-09-22 05:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:13:52 --> Parser Class Initialized
INFO - 2023-09-22 05:13:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:13:52 --> Pagination Class Initialized
INFO - 2023-09-22 05:13:52 --> Form Validation Class Initialized
INFO - 2023-09-22 05:13:52 --> Controller Class Initialized
INFO - 2023-09-22 05:13:52 --> Model Class Initialized
DEBUG - 2023-09-22 05:13:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:13:52 --> Model Class Initialized
DEBUG - 2023-09-22 05:13:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:13:52 --> Model Class Initialized
INFO - 2023-09-22 05:13:52 --> Model Class Initialized
INFO - 2023-09-22 05:13:52 --> Model Class Initialized
INFO - 2023-09-22 05:13:52 --> Model Class Initialized
DEBUG - 2023-09-22 05:13:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:13:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:13:52 --> Model Class Initialized
INFO - 2023-09-22 05:13:52 --> Model Class Initialized
INFO - 2023-09-22 05:13:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-22 05:13:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:13:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-22 05:13:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-22 05:13:52 --> Model Class Initialized
INFO - 2023-09-22 05:13:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-22 05:13:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-22 05:13:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-22 05:13:52 --> Final output sent to browser
DEBUG - 2023-09-22 05:13:52 --> Total execution time: 0.1170
ERROR - 2023-09-22 05:15:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:15:17 --> Config Class Initialized
INFO - 2023-09-22 05:15:17 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:15:17 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:15:17 --> Utf8 Class Initialized
INFO - 2023-09-22 05:15:17 --> URI Class Initialized
INFO - 2023-09-22 05:15:17 --> Router Class Initialized
INFO - 2023-09-22 05:15:17 --> Output Class Initialized
INFO - 2023-09-22 05:15:17 --> Security Class Initialized
DEBUG - 2023-09-22 05:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:15:17 --> Input Class Initialized
INFO - 2023-09-22 05:15:17 --> Language Class Initialized
INFO - 2023-09-22 05:15:17 --> Loader Class Initialized
INFO - 2023-09-22 05:15:17 --> Helper loaded: url_helper
INFO - 2023-09-22 05:15:17 --> Helper loaded: file_helper
INFO - 2023-09-22 05:15:17 --> Helper loaded: html_helper
INFO - 2023-09-22 05:15:17 --> Helper loaded: text_helper
INFO - 2023-09-22 05:15:17 --> Helper loaded: form_helper
INFO - 2023-09-22 05:15:17 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:15:17 --> Helper loaded: security_helper
INFO - 2023-09-22 05:15:17 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:15:17 --> Database Driver Class Initialized
INFO - 2023-09-22 05:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:15:17 --> Parser Class Initialized
INFO - 2023-09-22 05:15:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:15:17 --> Pagination Class Initialized
INFO - 2023-09-22 05:15:17 --> Form Validation Class Initialized
INFO - 2023-09-22 05:15:17 --> Controller Class Initialized
INFO - 2023-09-22 05:15:17 --> Model Class Initialized
DEBUG - 2023-09-22 05:15:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:15:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:15:17 --> Model Class Initialized
DEBUG - 2023-09-22 05:15:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:15:17 --> Model Class Initialized
INFO - 2023-09-22 05:15:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-09-22 05:15:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:15:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-22 05:15:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-22 05:15:17 --> Model Class Initialized
INFO - 2023-09-22 05:15:17 --> Model Class Initialized
INFO - 2023-09-22 05:15:17 --> Model Class Initialized
INFO - 2023-09-22 05:15:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-22 05:15:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-22 05:15:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-22 05:15:17 --> Final output sent to browser
DEBUG - 2023-09-22 05:15:17 --> Total execution time: 0.1174
ERROR - 2023-09-22 05:15:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:15:20 --> Config Class Initialized
INFO - 2023-09-22 05:15:20 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:15:20 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:15:20 --> Utf8 Class Initialized
INFO - 2023-09-22 05:15:20 --> URI Class Initialized
INFO - 2023-09-22 05:15:20 --> Router Class Initialized
INFO - 2023-09-22 05:15:20 --> Output Class Initialized
INFO - 2023-09-22 05:15:20 --> Security Class Initialized
DEBUG - 2023-09-22 05:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:15:20 --> Input Class Initialized
INFO - 2023-09-22 05:15:20 --> Language Class Initialized
INFO - 2023-09-22 05:15:20 --> Loader Class Initialized
INFO - 2023-09-22 05:15:20 --> Helper loaded: url_helper
INFO - 2023-09-22 05:15:20 --> Helper loaded: file_helper
INFO - 2023-09-22 05:15:20 --> Helper loaded: html_helper
INFO - 2023-09-22 05:15:20 --> Helper loaded: text_helper
INFO - 2023-09-22 05:15:20 --> Helper loaded: form_helper
INFO - 2023-09-22 05:15:20 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:15:20 --> Helper loaded: security_helper
INFO - 2023-09-22 05:15:20 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:15:20 --> Database Driver Class Initialized
INFO - 2023-09-22 05:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:15:20 --> Parser Class Initialized
INFO - 2023-09-22 05:15:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:15:20 --> Pagination Class Initialized
INFO - 2023-09-22 05:15:20 --> Form Validation Class Initialized
INFO - 2023-09-22 05:15:20 --> Controller Class Initialized
INFO - 2023-09-22 05:15:20 --> Model Class Initialized
DEBUG - 2023-09-22 05:15:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:15:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:15:20 --> Model Class Initialized
DEBUG - 2023-09-22 05:15:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:15:20 --> Model Class Initialized
INFO - 2023-09-22 05:15:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-22 05:15:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:15:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-22 05:15:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-22 05:15:20 --> Model Class Initialized
INFO - 2023-09-22 05:15:20 --> Model Class Initialized
INFO - 2023-09-22 05:15:20 --> Model Class Initialized
INFO - 2023-09-22 05:15:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-22 05:15:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-22 05:15:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-22 05:15:20 --> Final output sent to browser
DEBUG - 2023-09-22 05:15:20 --> Total execution time: 0.0810
ERROR - 2023-09-22 05:15:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:15:21 --> Config Class Initialized
INFO - 2023-09-22 05:15:21 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:15:21 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:15:21 --> Utf8 Class Initialized
INFO - 2023-09-22 05:15:21 --> URI Class Initialized
INFO - 2023-09-22 05:15:21 --> Router Class Initialized
INFO - 2023-09-22 05:15:21 --> Output Class Initialized
INFO - 2023-09-22 05:15:21 --> Security Class Initialized
DEBUG - 2023-09-22 05:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:15:21 --> Input Class Initialized
INFO - 2023-09-22 05:15:21 --> Language Class Initialized
INFO - 2023-09-22 05:15:21 --> Loader Class Initialized
INFO - 2023-09-22 05:15:21 --> Helper loaded: url_helper
INFO - 2023-09-22 05:15:21 --> Helper loaded: file_helper
INFO - 2023-09-22 05:15:21 --> Helper loaded: html_helper
INFO - 2023-09-22 05:15:21 --> Helper loaded: text_helper
INFO - 2023-09-22 05:15:21 --> Helper loaded: form_helper
INFO - 2023-09-22 05:15:21 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:15:21 --> Helper loaded: security_helper
INFO - 2023-09-22 05:15:21 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:15:21 --> Database Driver Class Initialized
INFO - 2023-09-22 05:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:15:21 --> Parser Class Initialized
INFO - 2023-09-22 05:15:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:15:21 --> Pagination Class Initialized
INFO - 2023-09-22 05:15:21 --> Form Validation Class Initialized
INFO - 2023-09-22 05:15:21 --> Controller Class Initialized
INFO - 2023-09-22 05:15:21 --> Model Class Initialized
DEBUG - 2023-09-22 05:15:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:15:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:15:21 --> Model Class Initialized
DEBUG - 2023-09-22 05:15:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:15:21 --> Model Class Initialized
INFO - 2023-09-22 05:15:21 --> Final output sent to browser
DEBUG - 2023-09-22 05:15:21 --> Total execution time: 0.0375
ERROR - 2023-09-22 05:15:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:15:25 --> Config Class Initialized
INFO - 2023-09-22 05:15:25 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:15:25 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:15:25 --> Utf8 Class Initialized
INFO - 2023-09-22 05:15:25 --> URI Class Initialized
INFO - 2023-09-22 05:15:25 --> Router Class Initialized
INFO - 2023-09-22 05:15:25 --> Output Class Initialized
INFO - 2023-09-22 05:15:25 --> Security Class Initialized
DEBUG - 2023-09-22 05:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:15:25 --> Input Class Initialized
INFO - 2023-09-22 05:15:25 --> Language Class Initialized
INFO - 2023-09-22 05:15:25 --> Loader Class Initialized
INFO - 2023-09-22 05:15:25 --> Helper loaded: url_helper
INFO - 2023-09-22 05:15:25 --> Helper loaded: file_helper
INFO - 2023-09-22 05:15:25 --> Helper loaded: html_helper
INFO - 2023-09-22 05:15:25 --> Helper loaded: text_helper
INFO - 2023-09-22 05:15:25 --> Helper loaded: form_helper
INFO - 2023-09-22 05:15:25 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:15:25 --> Helper loaded: security_helper
INFO - 2023-09-22 05:15:25 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:15:25 --> Database Driver Class Initialized
INFO - 2023-09-22 05:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:15:25 --> Parser Class Initialized
INFO - 2023-09-22 05:15:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:15:25 --> Pagination Class Initialized
INFO - 2023-09-22 05:15:25 --> Form Validation Class Initialized
INFO - 2023-09-22 05:15:25 --> Controller Class Initialized
INFO - 2023-09-22 05:15:25 --> Model Class Initialized
DEBUG - 2023-09-22 05:15:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:15:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:15:25 --> Model Class Initialized
DEBUG - 2023-09-22 05:15:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:15:25 --> Model Class Initialized
INFO - 2023-09-22 05:15:25 --> Final output sent to browser
DEBUG - 2023-09-22 05:15:25 --> Total execution time: 0.0389
ERROR - 2023-09-22 05:15:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:15:26 --> Config Class Initialized
INFO - 2023-09-22 05:15:26 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:15:26 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:15:26 --> Utf8 Class Initialized
INFO - 2023-09-22 05:15:26 --> URI Class Initialized
INFO - 2023-09-22 05:15:26 --> Router Class Initialized
INFO - 2023-09-22 05:15:26 --> Output Class Initialized
INFO - 2023-09-22 05:15:26 --> Security Class Initialized
DEBUG - 2023-09-22 05:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:15:26 --> Input Class Initialized
INFO - 2023-09-22 05:15:26 --> Language Class Initialized
INFO - 2023-09-22 05:15:26 --> Loader Class Initialized
INFO - 2023-09-22 05:15:26 --> Helper loaded: url_helper
INFO - 2023-09-22 05:15:26 --> Helper loaded: file_helper
INFO - 2023-09-22 05:15:26 --> Helper loaded: html_helper
INFO - 2023-09-22 05:15:26 --> Helper loaded: text_helper
INFO - 2023-09-22 05:15:26 --> Helper loaded: form_helper
INFO - 2023-09-22 05:15:26 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:15:26 --> Helper loaded: security_helper
INFO - 2023-09-22 05:15:26 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:15:26 --> Database Driver Class Initialized
INFO - 2023-09-22 05:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:15:26 --> Parser Class Initialized
INFO - 2023-09-22 05:15:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:15:26 --> Pagination Class Initialized
INFO - 2023-09-22 05:15:26 --> Form Validation Class Initialized
INFO - 2023-09-22 05:15:26 --> Controller Class Initialized
INFO - 2023-09-22 05:15:26 --> Model Class Initialized
DEBUG - 2023-09-22 05:15:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:15:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:15:26 --> Model Class Initialized
DEBUG - 2023-09-22 05:15:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:15:26 --> Model Class Initialized
INFO - 2023-09-22 05:15:26 --> Final output sent to browser
DEBUG - 2023-09-22 05:15:26 --> Total execution time: 0.0417
ERROR - 2023-09-22 05:15:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:15:27 --> Config Class Initialized
INFO - 2023-09-22 05:15:27 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:15:27 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:15:27 --> Utf8 Class Initialized
INFO - 2023-09-22 05:15:27 --> URI Class Initialized
INFO - 2023-09-22 05:15:27 --> Router Class Initialized
INFO - 2023-09-22 05:15:27 --> Output Class Initialized
INFO - 2023-09-22 05:15:27 --> Security Class Initialized
DEBUG - 2023-09-22 05:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:15:27 --> Input Class Initialized
INFO - 2023-09-22 05:15:27 --> Language Class Initialized
INFO - 2023-09-22 05:15:27 --> Loader Class Initialized
INFO - 2023-09-22 05:15:27 --> Helper loaded: url_helper
INFO - 2023-09-22 05:15:27 --> Helper loaded: file_helper
INFO - 2023-09-22 05:15:27 --> Helper loaded: html_helper
INFO - 2023-09-22 05:15:27 --> Helper loaded: text_helper
INFO - 2023-09-22 05:15:27 --> Helper loaded: form_helper
INFO - 2023-09-22 05:15:27 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:15:27 --> Helper loaded: security_helper
INFO - 2023-09-22 05:15:27 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:15:27 --> Database Driver Class Initialized
INFO - 2023-09-22 05:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:15:27 --> Parser Class Initialized
INFO - 2023-09-22 05:15:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:15:27 --> Pagination Class Initialized
INFO - 2023-09-22 05:15:27 --> Form Validation Class Initialized
INFO - 2023-09-22 05:15:27 --> Controller Class Initialized
INFO - 2023-09-22 05:15:27 --> Model Class Initialized
DEBUG - 2023-09-22 05:15:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:15:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:15:27 --> Model Class Initialized
DEBUG - 2023-09-22 05:15:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:15:27 --> Model Class Initialized
INFO - 2023-09-22 05:15:27 --> Final output sent to browser
DEBUG - 2023-09-22 05:15:27 --> Total execution time: 0.0507
ERROR - 2023-09-22 05:15:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:15:28 --> Config Class Initialized
INFO - 2023-09-22 05:15:28 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:15:28 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:15:28 --> Utf8 Class Initialized
INFO - 2023-09-22 05:15:28 --> URI Class Initialized
INFO - 2023-09-22 05:15:28 --> Router Class Initialized
INFO - 2023-09-22 05:15:28 --> Output Class Initialized
INFO - 2023-09-22 05:15:28 --> Security Class Initialized
DEBUG - 2023-09-22 05:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:15:28 --> Input Class Initialized
INFO - 2023-09-22 05:15:28 --> Language Class Initialized
INFO - 2023-09-22 05:15:28 --> Loader Class Initialized
INFO - 2023-09-22 05:15:28 --> Helper loaded: url_helper
INFO - 2023-09-22 05:15:28 --> Helper loaded: file_helper
INFO - 2023-09-22 05:15:28 --> Helper loaded: html_helper
INFO - 2023-09-22 05:15:28 --> Helper loaded: text_helper
INFO - 2023-09-22 05:15:28 --> Helper loaded: form_helper
INFO - 2023-09-22 05:15:28 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:15:28 --> Helper loaded: security_helper
INFO - 2023-09-22 05:15:28 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:15:28 --> Database Driver Class Initialized
INFO - 2023-09-22 05:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:15:28 --> Parser Class Initialized
INFO - 2023-09-22 05:15:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:15:28 --> Pagination Class Initialized
INFO - 2023-09-22 05:15:28 --> Form Validation Class Initialized
INFO - 2023-09-22 05:15:28 --> Controller Class Initialized
INFO - 2023-09-22 05:15:28 --> Model Class Initialized
DEBUG - 2023-09-22 05:15:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:15:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:15:28 --> Model Class Initialized
DEBUG - 2023-09-22 05:15:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:15:28 --> Model Class Initialized
INFO - 2023-09-22 05:15:28 --> Final output sent to browser
DEBUG - 2023-09-22 05:15:28 --> Total execution time: 0.0447
ERROR - 2023-09-22 05:16:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:16:03 --> Config Class Initialized
INFO - 2023-09-22 05:16:03 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:16:03 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:16:03 --> Utf8 Class Initialized
INFO - 2023-09-22 05:16:03 --> URI Class Initialized
INFO - 2023-09-22 05:16:03 --> Router Class Initialized
INFO - 2023-09-22 05:16:03 --> Output Class Initialized
INFO - 2023-09-22 05:16:03 --> Security Class Initialized
DEBUG - 2023-09-22 05:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:16:03 --> Input Class Initialized
INFO - 2023-09-22 05:16:03 --> Language Class Initialized
INFO - 2023-09-22 05:16:03 --> Loader Class Initialized
INFO - 2023-09-22 05:16:03 --> Helper loaded: url_helper
INFO - 2023-09-22 05:16:03 --> Helper loaded: file_helper
INFO - 2023-09-22 05:16:03 --> Helper loaded: html_helper
INFO - 2023-09-22 05:16:03 --> Helper loaded: text_helper
INFO - 2023-09-22 05:16:03 --> Helper loaded: form_helper
INFO - 2023-09-22 05:16:03 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:16:03 --> Helper loaded: security_helper
INFO - 2023-09-22 05:16:03 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:16:03 --> Database Driver Class Initialized
INFO - 2023-09-22 05:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:16:03 --> Parser Class Initialized
INFO - 2023-09-22 05:16:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:16:03 --> Pagination Class Initialized
INFO - 2023-09-22 05:16:03 --> Form Validation Class Initialized
INFO - 2023-09-22 05:16:03 --> Controller Class Initialized
INFO - 2023-09-22 05:16:03 --> Model Class Initialized
DEBUG - 2023-09-22 05:16:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:16:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:16:03 --> Model Class Initialized
DEBUG - 2023-09-22 05:16:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:16:03 --> Model Class Initialized
INFO - 2023-09-22 05:16:03 --> Final output sent to browser
DEBUG - 2023-09-22 05:16:03 --> Total execution time: 0.0501
ERROR - 2023-09-22 05:28:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:28:56 --> Config Class Initialized
INFO - 2023-09-22 05:28:56 --> Hooks Class Initialized
ERROR - 2023-09-22 05:28:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
DEBUG - 2023-09-22 05:28:56 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:28:56 --> Utf8 Class Initialized
INFO - 2023-09-22 05:28:56 --> Config Class Initialized
INFO - 2023-09-22 05:28:56 --> Hooks Class Initialized
INFO - 2023-09-22 05:28:56 --> URI Class Initialized
INFO - 2023-09-22 05:28:56 --> Router Class Initialized
DEBUG - 2023-09-22 05:28:56 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:28:56 --> Utf8 Class Initialized
INFO - 2023-09-22 05:28:56 --> Output Class Initialized
INFO - 2023-09-22 05:28:56 --> URI Class Initialized
INFO - 2023-09-22 05:28:56 --> Security Class Initialized
INFO - 2023-09-22 05:28:56 --> Router Class Initialized
DEBUG - 2023-09-22 05:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:28:56 --> Input Class Initialized
INFO - 2023-09-22 05:28:56 --> Output Class Initialized
INFO - 2023-09-22 05:28:56 --> Language Class Initialized
INFO - 2023-09-22 05:28:56 --> Security Class Initialized
DEBUG - 2023-09-22 05:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:28:56 --> Input Class Initialized
INFO - 2023-09-22 05:28:56 --> Language Class Initialized
INFO - 2023-09-22 05:28:56 --> Loader Class Initialized
INFO - 2023-09-22 05:28:56 --> Helper loaded: url_helper
INFO - 2023-09-22 05:28:56 --> Helper loaded: file_helper
INFO - 2023-09-22 05:28:56 --> Helper loaded: html_helper
INFO - 2023-09-22 05:28:56 --> Loader Class Initialized
INFO - 2023-09-22 05:28:56 --> Helper loaded: text_helper
INFO - 2023-09-22 05:28:56 --> Helper loaded: url_helper
INFO - 2023-09-22 05:28:56 --> Helper loaded: form_helper
INFO - 2023-09-22 05:28:56 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:28:56 --> Helper loaded: file_helper
INFO - 2023-09-22 05:28:56 --> Helper loaded: security_helper
INFO - 2023-09-22 05:28:56 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:28:56 --> Helper loaded: html_helper
INFO - 2023-09-22 05:28:56 --> Helper loaded: text_helper
INFO - 2023-09-22 05:28:56 --> Helper loaded: form_helper
INFO - 2023-09-22 05:28:56 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:28:56 --> Helper loaded: security_helper
INFO - 2023-09-22 05:28:56 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:28:56 --> Database Driver Class Initialized
INFO - 2023-09-22 05:28:56 --> Database Driver Class Initialized
INFO - 2023-09-22 05:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:28:56 --> Parser Class Initialized
INFO - 2023-09-22 05:28:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:28:56 --> Pagination Class Initialized
INFO - 2023-09-22 05:28:56 --> Form Validation Class Initialized
INFO - 2023-09-22 05:28:56 --> Controller Class Initialized
INFO - 2023-09-22 05:28:56 --> Model Class Initialized
DEBUG - 2023-09-22 05:28:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:28:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:28:56 --> Model Class Initialized
DEBUG - 2023-09-22 05:28:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:28:56 --> Model Class Initialized
INFO - 2023-09-22 05:28:56 --> Final output sent to browser
DEBUG - 2023-09-22 05:28:56 --> Total execution time: 0.0738
INFO - 2023-09-22 05:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:28:56 --> Parser Class Initialized
INFO - 2023-09-22 05:28:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:28:56 --> Pagination Class Initialized
INFO - 2023-09-22 05:28:56 --> Form Validation Class Initialized
INFO - 2023-09-22 05:28:56 --> Controller Class Initialized
INFO - 2023-09-22 05:28:56 --> Model Class Initialized
DEBUG - 2023-09-22 05:28:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:28:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:28:56 --> Model Class Initialized
DEBUG - 2023-09-22 05:28:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:28:56 --> Model Class Initialized
INFO - 2023-09-22 05:28:56 --> Final output sent to browser
DEBUG - 2023-09-22 05:28:56 --> Total execution time: 0.1178
ERROR - 2023-09-22 05:28:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:28:56 --> Config Class Initialized
INFO - 2023-09-22 05:28:56 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:28:56 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:28:56 --> Utf8 Class Initialized
INFO - 2023-09-22 05:28:56 --> URI Class Initialized
INFO - 2023-09-22 05:28:56 --> Router Class Initialized
INFO - 2023-09-22 05:28:56 --> Output Class Initialized
INFO - 2023-09-22 05:28:56 --> Security Class Initialized
DEBUG - 2023-09-22 05:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:28:56 --> Input Class Initialized
INFO - 2023-09-22 05:28:56 --> Language Class Initialized
INFO - 2023-09-22 05:28:56 --> Loader Class Initialized
INFO - 2023-09-22 05:28:56 --> Helper loaded: url_helper
INFO - 2023-09-22 05:28:56 --> Helper loaded: file_helper
INFO - 2023-09-22 05:28:56 --> Helper loaded: html_helper
INFO - 2023-09-22 05:28:56 --> Helper loaded: text_helper
INFO - 2023-09-22 05:28:56 --> Helper loaded: form_helper
INFO - 2023-09-22 05:28:56 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:28:56 --> Helper loaded: security_helper
INFO - 2023-09-22 05:28:56 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:28:56 --> Database Driver Class Initialized
INFO - 2023-09-22 05:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:28:56 --> Parser Class Initialized
INFO - 2023-09-22 05:28:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:28:56 --> Pagination Class Initialized
INFO - 2023-09-22 05:28:56 --> Form Validation Class Initialized
INFO - 2023-09-22 05:28:56 --> Controller Class Initialized
INFO - 2023-09-22 05:28:56 --> Model Class Initialized
DEBUG - 2023-09-22 05:28:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:28:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:28:56 --> Model Class Initialized
DEBUG - 2023-09-22 05:28:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:28:56 --> Model Class Initialized
INFO - 2023-09-22 05:28:56 --> Final output sent to browser
DEBUG - 2023-09-22 05:28:56 --> Total execution time: 0.0696
ERROR - 2023-09-22 05:28:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:28:56 --> Config Class Initialized
INFO - 2023-09-22 05:28:56 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:28:56 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:28:56 --> Utf8 Class Initialized
INFO - 2023-09-22 05:28:56 --> URI Class Initialized
INFO - 2023-09-22 05:28:56 --> Router Class Initialized
INFO - 2023-09-22 05:28:56 --> Output Class Initialized
INFO - 2023-09-22 05:28:56 --> Security Class Initialized
DEBUG - 2023-09-22 05:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:28:56 --> Input Class Initialized
INFO - 2023-09-22 05:28:56 --> Language Class Initialized
INFO - 2023-09-22 05:28:56 --> Loader Class Initialized
INFO - 2023-09-22 05:28:56 --> Helper loaded: url_helper
INFO - 2023-09-22 05:28:56 --> Helper loaded: file_helper
INFO - 2023-09-22 05:28:56 --> Helper loaded: html_helper
INFO - 2023-09-22 05:28:56 --> Helper loaded: text_helper
INFO - 2023-09-22 05:28:56 --> Helper loaded: form_helper
INFO - 2023-09-22 05:28:56 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:28:56 --> Helper loaded: security_helper
INFO - 2023-09-22 05:28:56 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:28:56 --> Database Driver Class Initialized
INFO - 2023-09-22 05:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:28:56 --> Parser Class Initialized
INFO - 2023-09-22 05:28:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:28:56 --> Pagination Class Initialized
INFO - 2023-09-22 05:28:56 --> Form Validation Class Initialized
INFO - 2023-09-22 05:28:56 --> Controller Class Initialized
INFO - 2023-09-22 05:28:56 --> Model Class Initialized
DEBUG - 2023-09-22 05:28:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:28:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:28:56 --> Model Class Initialized
DEBUG - 2023-09-22 05:28:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:28:56 --> Model Class Initialized
INFO - 2023-09-22 05:28:56 --> Final output sent to browser
DEBUG - 2023-09-22 05:28:56 --> Total execution time: 0.0569
ERROR - 2023-09-22 05:28:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:28:57 --> Config Class Initialized
INFO - 2023-09-22 05:28:57 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:28:57 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:28:57 --> Utf8 Class Initialized
INFO - 2023-09-22 05:28:57 --> URI Class Initialized
INFO - 2023-09-22 05:28:57 --> Router Class Initialized
INFO - 2023-09-22 05:28:57 --> Output Class Initialized
INFO - 2023-09-22 05:28:57 --> Security Class Initialized
DEBUG - 2023-09-22 05:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:28:57 --> Input Class Initialized
INFO - 2023-09-22 05:28:57 --> Language Class Initialized
INFO - 2023-09-22 05:28:57 --> Loader Class Initialized
INFO - 2023-09-22 05:28:57 --> Helper loaded: url_helper
INFO - 2023-09-22 05:28:57 --> Helper loaded: file_helper
INFO - 2023-09-22 05:28:57 --> Helper loaded: html_helper
INFO - 2023-09-22 05:28:57 --> Helper loaded: text_helper
INFO - 2023-09-22 05:28:57 --> Helper loaded: form_helper
INFO - 2023-09-22 05:28:57 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:28:57 --> Helper loaded: security_helper
INFO - 2023-09-22 05:28:57 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:28:57 --> Database Driver Class Initialized
INFO - 2023-09-22 05:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:28:57 --> Parser Class Initialized
INFO - 2023-09-22 05:28:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:28:57 --> Pagination Class Initialized
INFO - 2023-09-22 05:28:57 --> Form Validation Class Initialized
INFO - 2023-09-22 05:28:57 --> Controller Class Initialized
INFO - 2023-09-22 05:28:57 --> Model Class Initialized
DEBUG - 2023-09-22 05:28:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:28:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:28:57 --> Model Class Initialized
DEBUG - 2023-09-22 05:28:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:28:57 --> Model Class Initialized
INFO - 2023-09-22 05:28:57 --> Final output sent to browser
DEBUG - 2023-09-22 05:28:57 --> Total execution time: 0.0318
ERROR - 2023-09-22 05:28:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:28:58 --> Config Class Initialized
INFO - 2023-09-22 05:28:58 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:28:58 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:28:58 --> Utf8 Class Initialized
INFO - 2023-09-22 05:28:58 --> URI Class Initialized
INFO - 2023-09-22 05:28:58 --> Router Class Initialized
INFO - 2023-09-22 05:28:58 --> Output Class Initialized
INFO - 2023-09-22 05:28:58 --> Security Class Initialized
DEBUG - 2023-09-22 05:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:28:58 --> Input Class Initialized
INFO - 2023-09-22 05:28:58 --> Language Class Initialized
INFO - 2023-09-22 05:28:58 --> Loader Class Initialized
INFO - 2023-09-22 05:28:58 --> Helper loaded: url_helper
INFO - 2023-09-22 05:28:58 --> Helper loaded: file_helper
INFO - 2023-09-22 05:28:58 --> Helper loaded: html_helper
INFO - 2023-09-22 05:28:58 --> Helper loaded: text_helper
INFO - 2023-09-22 05:28:58 --> Helper loaded: form_helper
INFO - 2023-09-22 05:28:58 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:28:58 --> Helper loaded: security_helper
INFO - 2023-09-22 05:28:58 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:28:58 --> Database Driver Class Initialized
INFO - 2023-09-22 05:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:28:58 --> Parser Class Initialized
INFO - 2023-09-22 05:28:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:28:58 --> Pagination Class Initialized
INFO - 2023-09-22 05:28:58 --> Form Validation Class Initialized
INFO - 2023-09-22 05:28:58 --> Controller Class Initialized
INFO - 2023-09-22 05:28:58 --> Model Class Initialized
DEBUG - 2023-09-22 05:28:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:28:58 --> Model Class Initialized
DEBUG - 2023-09-22 05:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:28:58 --> Model Class Initialized
INFO - 2023-09-22 05:28:58 --> Final output sent to browser
DEBUG - 2023-09-22 05:28:58 --> Total execution time: 0.0321
ERROR - 2023-09-22 05:29:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:29:30 --> Config Class Initialized
INFO - 2023-09-22 05:29:30 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:29:30 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:29:30 --> Utf8 Class Initialized
INFO - 2023-09-22 05:29:30 --> URI Class Initialized
INFO - 2023-09-22 05:29:30 --> Router Class Initialized
INFO - 2023-09-22 05:29:30 --> Output Class Initialized
INFO - 2023-09-22 05:29:30 --> Security Class Initialized
DEBUG - 2023-09-22 05:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:29:30 --> Input Class Initialized
INFO - 2023-09-22 05:29:30 --> Language Class Initialized
INFO - 2023-09-22 05:29:30 --> Loader Class Initialized
INFO - 2023-09-22 05:29:30 --> Helper loaded: url_helper
INFO - 2023-09-22 05:29:30 --> Helper loaded: file_helper
INFO - 2023-09-22 05:29:30 --> Helper loaded: html_helper
INFO - 2023-09-22 05:29:30 --> Helper loaded: text_helper
INFO - 2023-09-22 05:29:30 --> Helper loaded: form_helper
INFO - 2023-09-22 05:29:30 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:29:30 --> Helper loaded: security_helper
INFO - 2023-09-22 05:29:30 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:29:30 --> Database Driver Class Initialized
INFO - 2023-09-22 05:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:29:30 --> Parser Class Initialized
INFO - 2023-09-22 05:29:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:29:30 --> Pagination Class Initialized
INFO - 2023-09-22 05:29:30 --> Form Validation Class Initialized
INFO - 2023-09-22 05:29:30 --> Controller Class Initialized
INFO - 2023-09-22 05:29:30 --> Model Class Initialized
DEBUG - 2023-09-22 05:29:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:29:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:29:30 --> Model Class Initialized
DEBUG - 2023-09-22 05:29:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:29:30 --> Model Class Initialized
INFO - 2023-09-22 05:29:30 --> Final output sent to browser
DEBUG - 2023-09-22 05:29:30 --> Total execution time: 0.0354
ERROR - 2023-09-22 05:29:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:29:31 --> Config Class Initialized
INFO - 2023-09-22 05:29:31 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:29:31 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:29:31 --> Utf8 Class Initialized
INFO - 2023-09-22 05:29:31 --> URI Class Initialized
INFO - 2023-09-22 05:29:31 --> Router Class Initialized
INFO - 2023-09-22 05:29:31 --> Output Class Initialized
INFO - 2023-09-22 05:29:31 --> Security Class Initialized
DEBUG - 2023-09-22 05:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:29:31 --> Input Class Initialized
INFO - 2023-09-22 05:29:31 --> Language Class Initialized
INFO - 2023-09-22 05:29:31 --> Loader Class Initialized
INFO - 2023-09-22 05:29:31 --> Helper loaded: url_helper
INFO - 2023-09-22 05:29:31 --> Helper loaded: file_helper
INFO - 2023-09-22 05:29:31 --> Helper loaded: html_helper
INFO - 2023-09-22 05:29:31 --> Helper loaded: text_helper
INFO - 2023-09-22 05:29:31 --> Helper loaded: form_helper
INFO - 2023-09-22 05:29:31 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:29:31 --> Helper loaded: security_helper
INFO - 2023-09-22 05:29:31 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:29:31 --> Database Driver Class Initialized
INFO - 2023-09-22 05:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:29:31 --> Parser Class Initialized
INFO - 2023-09-22 05:29:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:29:31 --> Pagination Class Initialized
INFO - 2023-09-22 05:29:31 --> Form Validation Class Initialized
INFO - 2023-09-22 05:29:31 --> Controller Class Initialized
INFO - 2023-09-22 05:29:31 --> Model Class Initialized
DEBUG - 2023-09-22 05:29:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:29:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:29:31 --> Model Class Initialized
DEBUG - 2023-09-22 05:29:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:29:31 --> Model Class Initialized
INFO - 2023-09-22 05:29:31 --> Final output sent to browser
DEBUG - 2023-09-22 05:29:31 --> Total execution time: 0.0629
ERROR - 2023-09-22 05:29:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:29:31 --> Config Class Initialized
INFO - 2023-09-22 05:29:31 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:29:31 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:29:31 --> Utf8 Class Initialized
INFO - 2023-09-22 05:29:31 --> URI Class Initialized
INFO - 2023-09-22 05:29:31 --> Router Class Initialized
INFO - 2023-09-22 05:29:31 --> Output Class Initialized
INFO - 2023-09-22 05:29:31 --> Security Class Initialized
DEBUG - 2023-09-22 05:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:29:31 --> Input Class Initialized
INFO - 2023-09-22 05:29:31 --> Language Class Initialized
INFO - 2023-09-22 05:29:31 --> Loader Class Initialized
INFO - 2023-09-22 05:29:31 --> Helper loaded: url_helper
INFO - 2023-09-22 05:29:31 --> Helper loaded: file_helper
INFO - 2023-09-22 05:29:31 --> Helper loaded: html_helper
INFO - 2023-09-22 05:29:31 --> Helper loaded: text_helper
INFO - 2023-09-22 05:29:31 --> Helper loaded: form_helper
INFO - 2023-09-22 05:29:31 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:29:31 --> Helper loaded: security_helper
INFO - 2023-09-22 05:29:31 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:29:31 --> Database Driver Class Initialized
INFO - 2023-09-22 05:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:29:31 --> Parser Class Initialized
INFO - 2023-09-22 05:29:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:29:31 --> Pagination Class Initialized
INFO - 2023-09-22 05:29:31 --> Form Validation Class Initialized
INFO - 2023-09-22 05:29:31 --> Controller Class Initialized
INFO - 2023-09-22 05:29:31 --> Model Class Initialized
DEBUG - 2023-09-22 05:29:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:29:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:29:31 --> Model Class Initialized
DEBUG - 2023-09-22 05:29:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:29:31 --> Model Class Initialized
INFO - 2023-09-22 05:29:31 --> Final output sent to browser
DEBUG - 2023-09-22 05:29:31 --> Total execution time: 0.0722
ERROR - 2023-09-22 05:29:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:29:32 --> Config Class Initialized
INFO - 2023-09-22 05:29:32 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:29:32 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:29:32 --> Utf8 Class Initialized
INFO - 2023-09-22 05:29:32 --> URI Class Initialized
INFO - 2023-09-22 05:29:32 --> Router Class Initialized
INFO - 2023-09-22 05:29:32 --> Output Class Initialized
INFO - 2023-09-22 05:29:32 --> Security Class Initialized
DEBUG - 2023-09-22 05:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:29:32 --> Input Class Initialized
INFO - 2023-09-22 05:29:32 --> Language Class Initialized
INFO - 2023-09-22 05:29:32 --> Loader Class Initialized
INFO - 2023-09-22 05:29:32 --> Helper loaded: url_helper
INFO - 2023-09-22 05:29:32 --> Helper loaded: file_helper
INFO - 2023-09-22 05:29:32 --> Helper loaded: html_helper
INFO - 2023-09-22 05:29:32 --> Helper loaded: text_helper
INFO - 2023-09-22 05:29:32 --> Helper loaded: form_helper
INFO - 2023-09-22 05:29:32 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:29:32 --> Helper loaded: security_helper
INFO - 2023-09-22 05:29:32 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:29:32 --> Database Driver Class Initialized
INFO - 2023-09-22 05:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:29:32 --> Parser Class Initialized
INFO - 2023-09-22 05:29:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:29:32 --> Pagination Class Initialized
INFO - 2023-09-22 05:29:32 --> Form Validation Class Initialized
INFO - 2023-09-22 05:29:32 --> Controller Class Initialized
INFO - 2023-09-22 05:29:32 --> Model Class Initialized
DEBUG - 2023-09-22 05:29:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:29:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:29:32 --> Model Class Initialized
DEBUG - 2023-09-22 05:29:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:29:32 --> Model Class Initialized
INFO - 2023-09-22 05:29:32 --> Final output sent to browser
DEBUG - 2023-09-22 05:29:32 --> Total execution time: 0.0709
ERROR - 2023-09-22 05:29:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:29:33 --> Config Class Initialized
INFO - 2023-09-22 05:29:33 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:29:33 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:29:33 --> Utf8 Class Initialized
INFO - 2023-09-22 05:29:33 --> URI Class Initialized
INFO - 2023-09-22 05:29:33 --> Router Class Initialized
INFO - 2023-09-22 05:29:33 --> Output Class Initialized
INFO - 2023-09-22 05:29:33 --> Security Class Initialized
DEBUG - 2023-09-22 05:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:29:33 --> Input Class Initialized
INFO - 2023-09-22 05:29:33 --> Language Class Initialized
INFO - 2023-09-22 05:29:33 --> Loader Class Initialized
INFO - 2023-09-22 05:29:33 --> Helper loaded: url_helper
INFO - 2023-09-22 05:29:33 --> Helper loaded: file_helper
INFO - 2023-09-22 05:29:33 --> Helper loaded: html_helper
INFO - 2023-09-22 05:29:33 --> Helper loaded: text_helper
INFO - 2023-09-22 05:29:33 --> Helper loaded: form_helper
INFO - 2023-09-22 05:29:33 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:29:33 --> Helper loaded: security_helper
INFO - 2023-09-22 05:29:33 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:29:33 --> Database Driver Class Initialized
INFO - 2023-09-22 05:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:29:33 --> Parser Class Initialized
INFO - 2023-09-22 05:29:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:29:33 --> Pagination Class Initialized
INFO - 2023-09-22 05:29:33 --> Form Validation Class Initialized
INFO - 2023-09-22 05:29:33 --> Controller Class Initialized
INFO - 2023-09-22 05:29:33 --> Model Class Initialized
DEBUG - 2023-09-22 05:29:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:29:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:29:33 --> Model Class Initialized
DEBUG - 2023-09-22 05:29:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:29:33 --> Model Class Initialized
INFO - 2023-09-22 05:29:33 --> Final output sent to browser
DEBUG - 2023-09-22 05:29:33 --> Total execution time: 0.0666
ERROR - 2023-09-22 05:29:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:29:34 --> Config Class Initialized
INFO - 2023-09-22 05:29:34 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:29:34 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:29:34 --> Utf8 Class Initialized
INFO - 2023-09-22 05:29:34 --> URI Class Initialized
INFO - 2023-09-22 05:29:34 --> Router Class Initialized
INFO - 2023-09-22 05:29:34 --> Output Class Initialized
INFO - 2023-09-22 05:29:34 --> Security Class Initialized
DEBUG - 2023-09-22 05:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:29:34 --> Input Class Initialized
INFO - 2023-09-22 05:29:34 --> Language Class Initialized
INFO - 2023-09-22 05:29:34 --> Loader Class Initialized
INFO - 2023-09-22 05:29:34 --> Helper loaded: url_helper
INFO - 2023-09-22 05:29:34 --> Helper loaded: file_helper
INFO - 2023-09-22 05:29:34 --> Helper loaded: html_helper
INFO - 2023-09-22 05:29:34 --> Helper loaded: text_helper
INFO - 2023-09-22 05:29:34 --> Helper loaded: form_helper
INFO - 2023-09-22 05:29:34 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:29:34 --> Helper loaded: security_helper
INFO - 2023-09-22 05:29:34 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:29:34 --> Database Driver Class Initialized
INFO - 2023-09-22 05:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:29:34 --> Parser Class Initialized
INFO - 2023-09-22 05:29:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:29:34 --> Pagination Class Initialized
INFO - 2023-09-22 05:29:34 --> Form Validation Class Initialized
INFO - 2023-09-22 05:29:34 --> Controller Class Initialized
INFO - 2023-09-22 05:29:34 --> Model Class Initialized
DEBUG - 2023-09-22 05:29:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:29:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:29:34 --> Model Class Initialized
DEBUG - 2023-09-22 05:29:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:29:34 --> Model Class Initialized
INFO - 2023-09-22 05:29:34 --> Final output sent to browser
DEBUG - 2023-09-22 05:29:34 --> Total execution time: 0.0728
ERROR - 2023-09-22 05:29:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:29:35 --> Config Class Initialized
INFO - 2023-09-22 05:29:35 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:29:35 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:29:35 --> Utf8 Class Initialized
INFO - 2023-09-22 05:29:35 --> URI Class Initialized
INFO - 2023-09-22 05:29:35 --> Router Class Initialized
INFO - 2023-09-22 05:29:35 --> Output Class Initialized
INFO - 2023-09-22 05:29:35 --> Security Class Initialized
DEBUG - 2023-09-22 05:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:29:35 --> Input Class Initialized
INFO - 2023-09-22 05:29:35 --> Language Class Initialized
INFO - 2023-09-22 05:29:35 --> Loader Class Initialized
INFO - 2023-09-22 05:29:35 --> Helper loaded: url_helper
INFO - 2023-09-22 05:29:35 --> Helper loaded: file_helper
INFO - 2023-09-22 05:29:35 --> Helper loaded: html_helper
INFO - 2023-09-22 05:29:35 --> Helper loaded: text_helper
INFO - 2023-09-22 05:29:35 --> Helper loaded: form_helper
INFO - 2023-09-22 05:29:35 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:29:35 --> Helper loaded: security_helper
INFO - 2023-09-22 05:29:35 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:29:35 --> Database Driver Class Initialized
INFO - 2023-09-22 05:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:29:35 --> Parser Class Initialized
INFO - 2023-09-22 05:29:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:29:35 --> Pagination Class Initialized
INFO - 2023-09-22 05:29:35 --> Form Validation Class Initialized
INFO - 2023-09-22 05:29:35 --> Controller Class Initialized
INFO - 2023-09-22 05:29:35 --> Model Class Initialized
DEBUG - 2023-09-22 05:29:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:29:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:29:35 --> Model Class Initialized
DEBUG - 2023-09-22 05:29:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:29:35 --> Model Class Initialized
INFO - 2023-09-22 05:29:35 --> Final output sent to browser
DEBUG - 2023-09-22 05:29:35 --> Total execution time: 0.0334
ERROR - 2023-09-22 05:29:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:29:35 --> Config Class Initialized
INFO - 2023-09-22 05:29:35 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:29:35 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:29:35 --> Utf8 Class Initialized
INFO - 2023-09-22 05:29:35 --> URI Class Initialized
INFO - 2023-09-22 05:29:35 --> Router Class Initialized
INFO - 2023-09-22 05:29:35 --> Output Class Initialized
INFO - 2023-09-22 05:29:35 --> Security Class Initialized
DEBUG - 2023-09-22 05:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:29:35 --> Input Class Initialized
INFO - 2023-09-22 05:29:35 --> Language Class Initialized
INFO - 2023-09-22 05:29:35 --> Loader Class Initialized
INFO - 2023-09-22 05:29:35 --> Helper loaded: url_helper
INFO - 2023-09-22 05:29:35 --> Helper loaded: file_helper
INFO - 2023-09-22 05:29:35 --> Helper loaded: html_helper
INFO - 2023-09-22 05:29:35 --> Helper loaded: text_helper
INFO - 2023-09-22 05:29:35 --> Helper loaded: form_helper
INFO - 2023-09-22 05:29:35 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:29:35 --> Helper loaded: security_helper
INFO - 2023-09-22 05:29:35 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:29:35 --> Database Driver Class Initialized
INFO - 2023-09-22 05:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:29:35 --> Parser Class Initialized
INFO - 2023-09-22 05:29:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:29:35 --> Pagination Class Initialized
INFO - 2023-09-22 05:29:35 --> Form Validation Class Initialized
INFO - 2023-09-22 05:29:35 --> Controller Class Initialized
INFO - 2023-09-22 05:29:35 --> Model Class Initialized
DEBUG - 2023-09-22 05:29:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:29:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:29:35 --> Model Class Initialized
DEBUG - 2023-09-22 05:29:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:29:35 --> Model Class Initialized
INFO - 2023-09-22 05:29:35 --> Final output sent to browser
DEBUG - 2023-09-22 05:29:35 --> Total execution time: 0.0325
ERROR - 2023-09-22 05:30:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:30:25 --> Config Class Initialized
INFO - 2023-09-22 05:30:25 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:30:25 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:30:25 --> Utf8 Class Initialized
INFO - 2023-09-22 05:30:25 --> URI Class Initialized
INFO - 2023-09-22 05:30:25 --> Router Class Initialized
INFO - 2023-09-22 05:30:25 --> Output Class Initialized
INFO - 2023-09-22 05:30:25 --> Security Class Initialized
DEBUG - 2023-09-22 05:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:30:25 --> Input Class Initialized
INFO - 2023-09-22 05:30:25 --> Language Class Initialized
INFO - 2023-09-22 05:30:25 --> Loader Class Initialized
INFO - 2023-09-22 05:30:25 --> Helper loaded: url_helper
INFO - 2023-09-22 05:30:25 --> Helper loaded: file_helper
INFO - 2023-09-22 05:30:25 --> Helper loaded: html_helper
INFO - 2023-09-22 05:30:25 --> Helper loaded: text_helper
INFO - 2023-09-22 05:30:25 --> Helper loaded: form_helper
INFO - 2023-09-22 05:30:25 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:30:25 --> Helper loaded: security_helper
INFO - 2023-09-22 05:30:25 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:30:25 --> Database Driver Class Initialized
INFO - 2023-09-22 05:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:30:25 --> Parser Class Initialized
INFO - 2023-09-22 05:30:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:30:25 --> Pagination Class Initialized
INFO - 2023-09-22 05:30:25 --> Form Validation Class Initialized
INFO - 2023-09-22 05:30:25 --> Controller Class Initialized
INFO - 2023-09-22 05:30:25 --> Model Class Initialized
DEBUG - 2023-09-22 05:30:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:30:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:30:25 --> Model Class Initialized
DEBUG - 2023-09-22 05:30:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:30:25 --> Model Class Initialized
INFO - 2023-09-22 05:30:25 --> Final output sent to browser
DEBUG - 2023-09-22 05:30:25 --> Total execution time: 0.0347
ERROR - 2023-09-22 05:30:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:30:26 --> Config Class Initialized
INFO - 2023-09-22 05:30:26 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:30:26 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:30:26 --> Utf8 Class Initialized
INFO - 2023-09-22 05:30:26 --> URI Class Initialized
INFO - 2023-09-22 05:30:26 --> Router Class Initialized
INFO - 2023-09-22 05:30:26 --> Output Class Initialized
INFO - 2023-09-22 05:30:26 --> Security Class Initialized
DEBUG - 2023-09-22 05:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:30:26 --> Input Class Initialized
INFO - 2023-09-22 05:30:26 --> Language Class Initialized
INFO - 2023-09-22 05:30:26 --> Loader Class Initialized
INFO - 2023-09-22 05:30:26 --> Helper loaded: url_helper
INFO - 2023-09-22 05:30:26 --> Helper loaded: file_helper
INFO - 2023-09-22 05:30:26 --> Helper loaded: html_helper
INFO - 2023-09-22 05:30:26 --> Helper loaded: text_helper
INFO - 2023-09-22 05:30:26 --> Helper loaded: form_helper
INFO - 2023-09-22 05:30:26 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:30:26 --> Helper loaded: security_helper
INFO - 2023-09-22 05:30:26 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:30:26 --> Database Driver Class Initialized
INFO - 2023-09-22 05:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:30:26 --> Parser Class Initialized
INFO - 2023-09-22 05:30:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:30:26 --> Pagination Class Initialized
INFO - 2023-09-22 05:30:26 --> Form Validation Class Initialized
INFO - 2023-09-22 05:30:26 --> Controller Class Initialized
INFO - 2023-09-22 05:30:26 --> Model Class Initialized
DEBUG - 2023-09-22 05:30:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:30:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:30:26 --> Model Class Initialized
DEBUG - 2023-09-22 05:30:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:30:26 --> Model Class Initialized
INFO - 2023-09-22 05:30:26 --> Final output sent to browser
DEBUG - 2023-09-22 05:30:26 --> Total execution time: 0.0687
ERROR - 2023-09-22 05:30:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:30:27 --> Config Class Initialized
INFO - 2023-09-22 05:30:27 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:30:27 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:30:27 --> Utf8 Class Initialized
INFO - 2023-09-22 05:30:27 --> URI Class Initialized
INFO - 2023-09-22 05:30:27 --> Router Class Initialized
INFO - 2023-09-22 05:30:27 --> Output Class Initialized
INFO - 2023-09-22 05:30:27 --> Security Class Initialized
DEBUG - 2023-09-22 05:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:30:27 --> Input Class Initialized
INFO - 2023-09-22 05:30:27 --> Language Class Initialized
INFO - 2023-09-22 05:30:27 --> Loader Class Initialized
INFO - 2023-09-22 05:30:27 --> Helper loaded: url_helper
INFO - 2023-09-22 05:30:27 --> Helper loaded: file_helper
INFO - 2023-09-22 05:30:27 --> Helper loaded: html_helper
INFO - 2023-09-22 05:30:27 --> Helper loaded: text_helper
INFO - 2023-09-22 05:30:27 --> Helper loaded: form_helper
INFO - 2023-09-22 05:30:27 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:30:27 --> Helper loaded: security_helper
INFO - 2023-09-22 05:30:27 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:30:27 --> Database Driver Class Initialized
INFO - 2023-09-22 05:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:30:27 --> Parser Class Initialized
INFO - 2023-09-22 05:30:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:30:27 --> Pagination Class Initialized
INFO - 2023-09-22 05:30:27 --> Form Validation Class Initialized
INFO - 2023-09-22 05:30:27 --> Controller Class Initialized
INFO - 2023-09-22 05:30:27 --> Model Class Initialized
DEBUG - 2023-09-22 05:30:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:30:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:30:27 --> Model Class Initialized
DEBUG - 2023-09-22 05:30:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:30:27 --> Model Class Initialized
INFO - 2023-09-22 05:30:27 --> Final output sent to browser
DEBUG - 2023-09-22 05:30:27 --> Total execution time: 0.0722
ERROR - 2023-09-22 05:30:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:30:28 --> Config Class Initialized
INFO - 2023-09-22 05:30:28 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:30:28 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:30:28 --> Utf8 Class Initialized
INFO - 2023-09-22 05:30:28 --> URI Class Initialized
INFO - 2023-09-22 05:30:28 --> Router Class Initialized
INFO - 2023-09-22 05:30:28 --> Output Class Initialized
INFO - 2023-09-22 05:30:28 --> Security Class Initialized
DEBUG - 2023-09-22 05:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:30:28 --> Input Class Initialized
INFO - 2023-09-22 05:30:28 --> Language Class Initialized
INFO - 2023-09-22 05:30:28 --> Loader Class Initialized
INFO - 2023-09-22 05:30:28 --> Helper loaded: url_helper
INFO - 2023-09-22 05:30:28 --> Helper loaded: file_helper
INFO - 2023-09-22 05:30:28 --> Helper loaded: html_helper
INFO - 2023-09-22 05:30:28 --> Helper loaded: text_helper
INFO - 2023-09-22 05:30:28 --> Helper loaded: form_helper
INFO - 2023-09-22 05:30:28 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:30:28 --> Helper loaded: security_helper
INFO - 2023-09-22 05:30:28 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:30:28 --> Database Driver Class Initialized
INFO - 2023-09-22 05:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:30:28 --> Parser Class Initialized
INFO - 2023-09-22 05:30:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:30:28 --> Pagination Class Initialized
INFO - 2023-09-22 05:30:28 --> Form Validation Class Initialized
INFO - 2023-09-22 05:30:28 --> Controller Class Initialized
INFO - 2023-09-22 05:30:28 --> Model Class Initialized
DEBUG - 2023-09-22 05:30:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:30:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:30:28 --> Model Class Initialized
DEBUG - 2023-09-22 05:30:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:30:28 --> Model Class Initialized
INFO - 2023-09-22 05:30:28 --> Final output sent to browser
DEBUG - 2023-09-22 05:30:28 --> Total execution time: 0.0741
ERROR - 2023-09-22 05:30:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:30:29 --> Config Class Initialized
INFO - 2023-09-22 05:30:29 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:30:29 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:30:29 --> Utf8 Class Initialized
INFO - 2023-09-22 05:30:29 --> URI Class Initialized
INFO - 2023-09-22 05:30:29 --> Router Class Initialized
INFO - 2023-09-22 05:30:29 --> Output Class Initialized
INFO - 2023-09-22 05:30:29 --> Security Class Initialized
DEBUG - 2023-09-22 05:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:30:29 --> Input Class Initialized
INFO - 2023-09-22 05:30:29 --> Language Class Initialized
INFO - 2023-09-22 05:30:29 --> Loader Class Initialized
INFO - 2023-09-22 05:30:29 --> Helper loaded: url_helper
INFO - 2023-09-22 05:30:29 --> Helper loaded: file_helper
INFO - 2023-09-22 05:30:29 --> Helper loaded: html_helper
INFO - 2023-09-22 05:30:29 --> Helper loaded: text_helper
INFO - 2023-09-22 05:30:29 --> Helper loaded: form_helper
INFO - 2023-09-22 05:30:29 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:30:29 --> Helper loaded: security_helper
INFO - 2023-09-22 05:30:29 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:30:29 --> Database Driver Class Initialized
INFO - 2023-09-22 05:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:30:29 --> Parser Class Initialized
INFO - 2023-09-22 05:30:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:30:29 --> Pagination Class Initialized
INFO - 2023-09-22 05:30:29 --> Form Validation Class Initialized
INFO - 2023-09-22 05:30:29 --> Controller Class Initialized
INFO - 2023-09-22 05:30:29 --> Model Class Initialized
DEBUG - 2023-09-22 05:30:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:30:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:30:29 --> Model Class Initialized
DEBUG - 2023-09-22 05:30:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:30:29 --> Model Class Initialized
INFO - 2023-09-22 05:30:29 --> Final output sent to browser
DEBUG - 2023-09-22 05:30:29 --> Total execution time: 0.0351
ERROR - 2023-09-22 05:30:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:30:30 --> Config Class Initialized
INFO - 2023-09-22 05:30:30 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:30:30 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:30:30 --> Utf8 Class Initialized
INFO - 2023-09-22 05:30:30 --> URI Class Initialized
INFO - 2023-09-22 05:30:30 --> Router Class Initialized
INFO - 2023-09-22 05:30:30 --> Output Class Initialized
INFO - 2023-09-22 05:30:30 --> Security Class Initialized
DEBUG - 2023-09-22 05:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:30:30 --> Input Class Initialized
INFO - 2023-09-22 05:30:30 --> Language Class Initialized
INFO - 2023-09-22 05:30:30 --> Loader Class Initialized
INFO - 2023-09-22 05:30:30 --> Helper loaded: url_helper
INFO - 2023-09-22 05:30:30 --> Helper loaded: file_helper
INFO - 2023-09-22 05:30:30 --> Helper loaded: html_helper
INFO - 2023-09-22 05:30:30 --> Helper loaded: text_helper
INFO - 2023-09-22 05:30:30 --> Helper loaded: form_helper
INFO - 2023-09-22 05:30:30 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:30:30 --> Helper loaded: security_helper
INFO - 2023-09-22 05:30:30 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:30:30 --> Database Driver Class Initialized
INFO - 2023-09-22 05:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:30:30 --> Parser Class Initialized
INFO - 2023-09-22 05:30:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:30:30 --> Pagination Class Initialized
INFO - 2023-09-22 05:30:30 --> Form Validation Class Initialized
INFO - 2023-09-22 05:30:30 --> Controller Class Initialized
INFO - 2023-09-22 05:30:30 --> Model Class Initialized
DEBUG - 2023-09-22 05:30:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:30:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:30:30 --> Model Class Initialized
DEBUG - 2023-09-22 05:30:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:30:30 --> Model Class Initialized
INFO - 2023-09-22 05:30:30 --> Final output sent to browser
DEBUG - 2023-09-22 05:30:30 --> Total execution time: 0.0386
ERROR - 2023-09-22 05:30:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:30:40 --> Config Class Initialized
INFO - 2023-09-22 05:30:40 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:30:40 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:30:40 --> Utf8 Class Initialized
INFO - 2023-09-22 05:30:40 --> URI Class Initialized
INFO - 2023-09-22 05:30:40 --> Router Class Initialized
INFO - 2023-09-22 05:30:40 --> Output Class Initialized
INFO - 2023-09-22 05:30:40 --> Security Class Initialized
DEBUG - 2023-09-22 05:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:30:40 --> Input Class Initialized
INFO - 2023-09-22 05:30:40 --> Language Class Initialized
INFO - 2023-09-22 05:30:40 --> Loader Class Initialized
INFO - 2023-09-22 05:30:40 --> Helper loaded: url_helper
INFO - 2023-09-22 05:30:40 --> Helper loaded: file_helper
INFO - 2023-09-22 05:30:40 --> Helper loaded: html_helper
INFO - 2023-09-22 05:30:40 --> Helper loaded: text_helper
INFO - 2023-09-22 05:30:40 --> Helper loaded: form_helper
INFO - 2023-09-22 05:30:40 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:30:40 --> Helper loaded: security_helper
INFO - 2023-09-22 05:30:40 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:30:40 --> Database Driver Class Initialized
INFO - 2023-09-22 05:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:30:40 --> Parser Class Initialized
INFO - 2023-09-22 05:30:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:30:40 --> Pagination Class Initialized
INFO - 2023-09-22 05:30:40 --> Form Validation Class Initialized
INFO - 2023-09-22 05:30:40 --> Controller Class Initialized
INFO - 2023-09-22 05:30:40 --> Model Class Initialized
DEBUG - 2023-09-22 05:30:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:30:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:30:40 --> Model Class Initialized
DEBUG - 2023-09-22 05:30:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:30:40 --> Model Class Initialized
INFO - 2023-09-22 05:30:40 --> Final output sent to browser
DEBUG - 2023-09-22 05:30:40 --> Total execution time: 0.0324
ERROR - 2023-09-22 05:30:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:30:41 --> Config Class Initialized
INFO - 2023-09-22 05:30:41 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:30:41 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:30:41 --> Utf8 Class Initialized
INFO - 2023-09-22 05:30:41 --> URI Class Initialized
INFO - 2023-09-22 05:30:41 --> Router Class Initialized
INFO - 2023-09-22 05:30:41 --> Output Class Initialized
INFO - 2023-09-22 05:30:41 --> Security Class Initialized
DEBUG - 2023-09-22 05:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:30:41 --> Input Class Initialized
INFO - 2023-09-22 05:30:41 --> Language Class Initialized
INFO - 2023-09-22 05:30:41 --> Loader Class Initialized
INFO - 2023-09-22 05:30:41 --> Helper loaded: url_helper
INFO - 2023-09-22 05:30:41 --> Helper loaded: file_helper
INFO - 2023-09-22 05:30:41 --> Helper loaded: html_helper
INFO - 2023-09-22 05:30:41 --> Helper loaded: text_helper
INFO - 2023-09-22 05:30:41 --> Helper loaded: form_helper
INFO - 2023-09-22 05:30:41 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:30:41 --> Helper loaded: security_helper
INFO - 2023-09-22 05:30:41 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:30:41 --> Database Driver Class Initialized
INFO - 2023-09-22 05:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:30:41 --> Parser Class Initialized
INFO - 2023-09-22 05:30:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:30:41 --> Pagination Class Initialized
INFO - 2023-09-22 05:30:41 --> Form Validation Class Initialized
INFO - 2023-09-22 05:30:41 --> Controller Class Initialized
INFO - 2023-09-22 05:30:41 --> Model Class Initialized
DEBUG - 2023-09-22 05:30:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:30:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:30:41 --> Model Class Initialized
DEBUG - 2023-09-22 05:30:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:30:41 --> Model Class Initialized
INFO - 2023-09-22 05:30:41 --> Final output sent to browser
DEBUG - 2023-09-22 05:30:41 --> Total execution time: 0.0290
ERROR - 2023-09-22 05:32:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:32:55 --> Config Class Initialized
INFO - 2023-09-22 05:32:55 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:32:55 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:32:55 --> Utf8 Class Initialized
INFO - 2023-09-22 05:32:55 --> URI Class Initialized
INFO - 2023-09-22 05:32:55 --> Router Class Initialized
INFO - 2023-09-22 05:32:55 --> Output Class Initialized
INFO - 2023-09-22 05:32:55 --> Security Class Initialized
DEBUG - 2023-09-22 05:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:32:55 --> Input Class Initialized
INFO - 2023-09-22 05:32:55 --> Language Class Initialized
INFO - 2023-09-22 05:32:55 --> Loader Class Initialized
INFO - 2023-09-22 05:32:55 --> Helper loaded: url_helper
INFO - 2023-09-22 05:32:55 --> Helper loaded: file_helper
INFO - 2023-09-22 05:32:55 --> Helper loaded: html_helper
INFO - 2023-09-22 05:32:55 --> Helper loaded: text_helper
INFO - 2023-09-22 05:32:55 --> Helper loaded: form_helper
INFO - 2023-09-22 05:32:55 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:32:55 --> Helper loaded: security_helper
INFO - 2023-09-22 05:32:55 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:32:55 --> Database Driver Class Initialized
INFO - 2023-09-22 05:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:32:55 --> Parser Class Initialized
INFO - 2023-09-22 05:32:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:32:55 --> Pagination Class Initialized
INFO - 2023-09-22 05:32:55 --> Form Validation Class Initialized
INFO - 2023-09-22 05:32:55 --> Controller Class Initialized
INFO - 2023-09-22 05:32:55 --> Model Class Initialized
DEBUG - 2023-09-22 05:32:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:32:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:32:55 --> Model Class Initialized
DEBUG - 2023-09-22 05:32:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:32:55 --> Model Class Initialized
INFO - 2023-09-22 05:32:55 --> Final output sent to browser
DEBUG - 2023-09-22 05:32:55 --> Total execution time: 0.0338
ERROR - 2023-09-22 05:32:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:32:56 --> Config Class Initialized
INFO - 2023-09-22 05:32:56 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:32:56 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:32:56 --> Utf8 Class Initialized
INFO - 2023-09-22 05:32:56 --> URI Class Initialized
INFO - 2023-09-22 05:32:56 --> Router Class Initialized
INFO - 2023-09-22 05:32:56 --> Output Class Initialized
INFO - 2023-09-22 05:32:56 --> Security Class Initialized
DEBUG - 2023-09-22 05:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:32:56 --> Input Class Initialized
INFO - 2023-09-22 05:32:56 --> Language Class Initialized
INFO - 2023-09-22 05:32:56 --> Loader Class Initialized
INFO - 2023-09-22 05:32:56 --> Helper loaded: url_helper
INFO - 2023-09-22 05:32:56 --> Helper loaded: file_helper
INFO - 2023-09-22 05:32:56 --> Helper loaded: html_helper
INFO - 2023-09-22 05:32:56 --> Helper loaded: text_helper
INFO - 2023-09-22 05:32:56 --> Helper loaded: form_helper
INFO - 2023-09-22 05:32:56 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:32:56 --> Helper loaded: security_helper
INFO - 2023-09-22 05:32:56 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:32:56 --> Database Driver Class Initialized
INFO - 2023-09-22 05:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:32:56 --> Parser Class Initialized
INFO - 2023-09-22 05:32:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:32:56 --> Pagination Class Initialized
INFO - 2023-09-22 05:32:56 --> Form Validation Class Initialized
INFO - 2023-09-22 05:32:56 --> Controller Class Initialized
INFO - 2023-09-22 05:32:56 --> Model Class Initialized
DEBUG - 2023-09-22 05:32:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:32:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:32:56 --> Model Class Initialized
DEBUG - 2023-09-22 05:32:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:32:56 --> Model Class Initialized
INFO - 2023-09-22 05:32:56 --> Final output sent to browser
DEBUG - 2023-09-22 05:32:56 --> Total execution time: 0.0348
ERROR - 2023-09-22 05:32:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:32:56 --> Config Class Initialized
INFO - 2023-09-22 05:32:56 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:32:56 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:32:56 --> Utf8 Class Initialized
INFO - 2023-09-22 05:32:56 --> URI Class Initialized
INFO - 2023-09-22 05:32:56 --> Router Class Initialized
INFO - 2023-09-22 05:32:56 --> Output Class Initialized
INFO - 2023-09-22 05:32:56 --> Security Class Initialized
DEBUG - 2023-09-22 05:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:32:56 --> Input Class Initialized
INFO - 2023-09-22 05:32:56 --> Language Class Initialized
INFO - 2023-09-22 05:32:56 --> Loader Class Initialized
INFO - 2023-09-22 05:32:56 --> Helper loaded: url_helper
INFO - 2023-09-22 05:32:56 --> Helper loaded: file_helper
INFO - 2023-09-22 05:32:56 --> Helper loaded: html_helper
INFO - 2023-09-22 05:32:56 --> Helper loaded: text_helper
INFO - 2023-09-22 05:32:56 --> Helper loaded: form_helper
INFO - 2023-09-22 05:32:56 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:32:56 --> Helper loaded: security_helper
INFO - 2023-09-22 05:32:56 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:32:56 --> Database Driver Class Initialized
INFO - 2023-09-22 05:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:32:56 --> Parser Class Initialized
INFO - 2023-09-22 05:32:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:32:56 --> Pagination Class Initialized
INFO - 2023-09-22 05:32:56 --> Form Validation Class Initialized
INFO - 2023-09-22 05:32:56 --> Controller Class Initialized
INFO - 2023-09-22 05:32:56 --> Model Class Initialized
DEBUG - 2023-09-22 05:32:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:32:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:32:56 --> Model Class Initialized
DEBUG - 2023-09-22 05:32:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:32:56 --> Model Class Initialized
INFO - 2023-09-22 05:32:56 --> Final output sent to browser
DEBUG - 2023-09-22 05:32:56 --> Total execution time: 0.0678
ERROR - 2023-09-22 05:32:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:32:57 --> Config Class Initialized
INFO - 2023-09-22 05:32:57 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:32:57 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:32:57 --> Utf8 Class Initialized
INFO - 2023-09-22 05:32:57 --> URI Class Initialized
INFO - 2023-09-22 05:32:57 --> Router Class Initialized
INFO - 2023-09-22 05:32:57 --> Output Class Initialized
INFO - 2023-09-22 05:32:57 --> Security Class Initialized
DEBUG - 2023-09-22 05:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:32:57 --> Input Class Initialized
INFO - 2023-09-22 05:32:57 --> Language Class Initialized
INFO - 2023-09-22 05:32:57 --> Loader Class Initialized
INFO - 2023-09-22 05:32:57 --> Helper loaded: url_helper
INFO - 2023-09-22 05:32:57 --> Helper loaded: file_helper
INFO - 2023-09-22 05:32:57 --> Helper loaded: html_helper
INFO - 2023-09-22 05:32:57 --> Helper loaded: text_helper
INFO - 2023-09-22 05:32:57 --> Helper loaded: form_helper
INFO - 2023-09-22 05:32:57 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:32:57 --> Helper loaded: security_helper
INFO - 2023-09-22 05:32:57 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:32:57 --> Database Driver Class Initialized
INFO - 2023-09-22 05:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:32:57 --> Parser Class Initialized
INFO - 2023-09-22 05:32:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:32:57 --> Pagination Class Initialized
INFO - 2023-09-22 05:32:57 --> Form Validation Class Initialized
INFO - 2023-09-22 05:32:57 --> Controller Class Initialized
INFO - 2023-09-22 05:32:57 --> Model Class Initialized
DEBUG - 2023-09-22 05:32:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:32:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:32:57 --> Model Class Initialized
DEBUG - 2023-09-22 05:32:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:32:57 --> Model Class Initialized
INFO - 2023-09-22 05:32:57 --> Final output sent to browser
DEBUG - 2023-09-22 05:32:57 --> Total execution time: 0.0722
ERROR - 2023-09-22 05:32:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:32:57 --> Config Class Initialized
INFO - 2023-09-22 05:32:57 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:32:57 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:32:57 --> Utf8 Class Initialized
INFO - 2023-09-22 05:32:57 --> URI Class Initialized
INFO - 2023-09-22 05:32:57 --> Router Class Initialized
INFO - 2023-09-22 05:32:57 --> Output Class Initialized
INFO - 2023-09-22 05:32:57 --> Security Class Initialized
DEBUG - 2023-09-22 05:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:32:57 --> Input Class Initialized
INFO - 2023-09-22 05:32:57 --> Language Class Initialized
INFO - 2023-09-22 05:32:57 --> Loader Class Initialized
INFO - 2023-09-22 05:32:57 --> Helper loaded: url_helper
INFO - 2023-09-22 05:32:57 --> Helper loaded: file_helper
INFO - 2023-09-22 05:32:57 --> Helper loaded: html_helper
INFO - 2023-09-22 05:32:57 --> Helper loaded: text_helper
INFO - 2023-09-22 05:32:57 --> Helper loaded: form_helper
INFO - 2023-09-22 05:32:57 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:32:57 --> Helper loaded: security_helper
INFO - 2023-09-22 05:32:57 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:32:57 --> Database Driver Class Initialized
INFO - 2023-09-22 05:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:32:57 --> Parser Class Initialized
INFO - 2023-09-22 05:32:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:32:57 --> Pagination Class Initialized
INFO - 2023-09-22 05:32:57 --> Form Validation Class Initialized
INFO - 2023-09-22 05:32:57 --> Controller Class Initialized
INFO - 2023-09-22 05:32:57 --> Model Class Initialized
DEBUG - 2023-09-22 05:32:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:32:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:32:57 --> Model Class Initialized
DEBUG - 2023-09-22 05:32:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:32:57 --> Model Class Initialized
INFO - 2023-09-22 05:32:57 --> Final output sent to browser
DEBUG - 2023-09-22 05:32:57 --> Total execution time: 0.0643
ERROR - 2023-09-22 05:32:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:32:58 --> Config Class Initialized
INFO - 2023-09-22 05:32:58 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:32:58 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:32:58 --> Utf8 Class Initialized
INFO - 2023-09-22 05:32:58 --> URI Class Initialized
INFO - 2023-09-22 05:32:58 --> Router Class Initialized
INFO - 2023-09-22 05:32:58 --> Output Class Initialized
INFO - 2023-09-22 05:32:58 --> Security Class Initialized
DEBUG - 2023-09-22 05:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:32:58 --> Input Class Initialized
INFO - 2023-09-22 05:32:58 --> Language Class Initialized
INFO - 2023-09-22 05:32:58 --> Loader Class Initialized
INFO - 2023-09-22 05:32:58 --> Helper loaded: url_helper
INFO - 2023-09-22 05:32:58 --> Helper loaded: file_helper
INFO - 2023-09-22 05:32:58 --> Helper loaded: html_helper
INFO - 2023-09-22 05:32:58 --> Helper loaded: text_helper
INFO - 2023-09-22 05:32:58 --> Helper loaded: form_helper
INFO - 2023-09-22 05:32:58 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:32:58 --> Helper loaded: security_helper
INFO - 2023-09-22 05:32:58 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:32:58 --> Database Driver Class Initialized
INFO - 2023-09-22 05:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:32:58 --> Parser Class Initialized
INFO - 2023-09-22 05:32:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:32:58 --> Pagination Class Initialized
INFO - 2023-09-22 05:32:58 --> Form Validation Class Initialized
INFO - 2023-09-22 05:32:58 --> Controller Class Initialized
INFO - 2023-09-22 05:32:58 --> Model Class Initialized
DEBUG - 2023-09-22 05:32:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:32:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:32:58 --> Model Class Initialized
DEBUG - 2023-09-22 05:32:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:32:58 --> Model Class Initialized
INFO - 2023-09-22 05:32:58 --> Final output sent to browser
DEBUG - 2023-09-22 05:32:58 --> Total execution time: 0.0769
ERROR - 2023-09-22 05:32:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:32:58 --> Config Class Initialized
INFO - 2023-09-22 05:32:58 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:32:58 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:32:58 --> Utf8 Class Initialized
INFO - 2023-09-22 05:32:58 --> URI Class Initialized
INFO - 2023-09-22 05:32:58 --> Router Class Initialized
INFO - 2023-09-22 05:32:58 --> Output Class Initialized
INFO - 2023-09-22 05:32:58 --> Security Class Initialized
DEBUG - 2023-09-22 05:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:32:58 --> Input Class Initialized
INFO - 2023-09-22 05:32:58 --> Language Class Initialized
INFO - 2023-09-22 05:32:58 --> Loader Class Initialized
INFO - 2023-09-22 05:32:58 --> Helper loaded: url_helper
INFO - 2023-09-22 05:32:58 --> Helper loaded: file_helper
INFO - 2023-09-22 05:32:58 --> Helper loaded: html_helper
INFO - 2023-09-22 05:32:58 --> Helper loaded: text_helper
INFO - 2023-09-22 05:32:58 --> Helper loaded: form_helper
INFO - 2023-09-22 05:32:58 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:32:58 --> Helper loaded: security_helper
INFO - 2023-09-22 05:32:58 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:32:58 --> Database Driver Class Initialized
INFO - 2023-09-22 05:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:32:58 --> Parser Class Initialized
INFO - 2023-09-22 05:32:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:32:58 --> Pagination Class Initialized
INFO - 2023-09-22 05:32:58 --> Form Validation Class Initialized
INFO - 2023-09-22 05:32:58 --> Controller Class Initialized
INFO - 2023-09-22 05:32:58 --> Model Class Initialized
DEBUG - 2023-09-22 05:32:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:32:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:32:58 --> Model Class Initialized
DEBUG - 2023-09-22 05:32:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:32:58 --> Model Class Initialized
INFO - 2023-09-22 05:32:58 --> Final output sent to browser
DEBUG - 2023-09-22 05:32:58 --> Total execution time: 0.0653
ERROR - 2023-09-22 05:33:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:33:00 --> Config Class Initialized
INFO - 2023-09-22 05:33:00 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:33:00 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:33:00 --> Utf8 Class Initialized
INFO - 2023-09-22 05:33:00 --> URI Class Initialized
INFO - 2023-09-22 05:33:00 --> Router Class Initialized
INFO - 2023-09-22 05:33:00 --> Output Class Initialized
INFO - 2023-09-22 05:33:00 --> Security Class Initialized
DEBUG - 2023-09-22 05:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:33:00 --> Input Class Initialized
INFO - 2023-09-22 05:33:00 --> Language Class Initialized
INFO - 2023-09-22 05:33:00 --> Loader Class Initialized
INFO - 2023-09-22 05:33:00 --> Helper loaded: url_helper
INFO - 2023-09-22 05:33:00 --> Helper loaded: file_helper
INFO - 2023-09-22 05:33:00 --> Helper loaded: html_helper
INFO - 2023-09-22 05:33:00 --> Helper loaded: text_helper
INFO - 2023-09-22 05:33:00 --> Helper loaded: form_helper
INFO - 2023-09-22 05:33:00 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:33:00 --> Helper loaded: security_helper
INFO - 2023-09-22 05:33:00 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:33:00 --> Database Driver Class Initialized
INFO - 2023-09-22 05:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:33:00 --> Parser Class Initialized
INFO - 2023-09-22 05:33:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:33:00 --> Pagination Class Initialized
INFO - 2023-09-22 05:33:00 --> Form Validation Class Initialized
INFO - 2023-09-22 05:33:00 --> Controller Class Initialized
INFO - 2023-09-22 05:33:00 --> Model Class Initialized
DEBUG - 2023-09-22 05:33:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:33:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:33:00 --> Model Class Initialized
DEBUG - 2023-09-22 05:33:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:33:00 --> Model Class Initialized
INFO - 2023-09-22 05:33:00 --> Final output sent to browser
DEBUG - 2023-09-22 05:33:00 --> Total execution time: 0.0305
ERROR - 2023-09-22 05:33:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:33:19 --> Config Class Initialized
INFO - 2023-09-22 05:33:19 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:33:19 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:33:19 --> Utf8 Class Initialized
INFO - 2023-09-22 05:33:19 --> URI Class Initialized
INFO - 2023-09-22 05:33:19 --> Router Class Initialized
INFO - 2023-09-22 05:33:19 --> Output Class Initialized
INFO - 2023-09-22 05:33:19 --> Security Class Initialized
DEBUG - 2023-09-22 05:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:33:19 --> Input Class Initialized
INFO - 2023-09-22 05:33:19 --> Language Class Initialized
INFO - 2023-09-22 05:33:19 --> Loader Class Initialized
INFO - 2023-09-22 05:33:19 --> Helper loaded: url_helper
INFO - 2023-09-22 05:33:19 --> Helper loaded: file_helper
INFO - 2023-09-22 05:33:19 --> Helper loaded: html_helper
INFO - 2023-09-22 05:33:19 --> Helper loaded: text_helper
INFO - 2023-09-22 05:33:19 --> Helper loaded: form_helper
INFO - 2023-09-22 05:33:19 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:33:19 --> Helper loaded: security_helper
INFO - 2023-09-22 05:33:19 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:33:19 --> Database Driver Class Initialized
INFO - 2023-09-22 05:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:33:19 --> Parser Class Initialized
INFO - 2023-09-22 05:33:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:33:19 --> Pagination Class Initialized
INFO - 2023-09-22 05:33:19 --> Form Validation Class Initialized
INFO - 2023-09-22 05:33:19 --> Controller Class Initialized
INFO - 2023-09-22 05:33:19 --> Model Class Initialized
DEBUG - 2023-09-22 05:33:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:33:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:33:19 --> Model Class Initialized
DEBUG - 2023-09-22 05:33:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:33:19 --> Model Class Initialized
INFO - 2023-09-22 05:33:19 --> Final output sent to browser
DEBUG - 2023-09-22 05:33:19 --> Total execution time: 0.0328
ERROR - 2023-09-22 05:33:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:33:28 --> Config Class Initialized
INFO - 2023-09-22 05:33:28 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:33:28 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:33:28 --> Utf8 Class Initialized
INFO - 2023-09-22 05:33:28 --> URI Class Initialized
INFO - 2023-09-22 05:33:28 --> Router Class Initialized
INFO - 2023-09-22 05:33:28 --> Output Class Initialized
INFO - 2023-09-22 05:33:28 --> Security Class Initialized
DEBUG - 2023-09-22 05:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:33:28 --> Input Class Initialized
INFO - 2023-09-22 05:33:28 --> Language Class Initialized
INFO - 2023-09-22 05:33:28 --> Loader Class Initialized
INFO - 2023-09-22 05:33:28 --> Helper loaded: url_helper
INFO - 2023-09-22 05:33:28 --> Helper loaded: file_helper
INFO - 2023-09-22 05:33:28 --> Helper loaded: html_helper
INFO - 2023-09-22 05:33:28 --> Helper loaded: text_helper
INFO - 2023-09-22 05:33:28 --> Helper loaded: form_helper
INFO - 2023-09-22 05:33:28 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:33:28 --> Helper loaded: security_helper
INFO - 2023-09-22 05:33:28 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:33:28 --> Database Driver Class Initialized
INFO - 2023-09-22 05:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:33:28 --> Parser Class Initialized
INFO - 2023-09-22 05:33:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:33:28 --> Pagination Class Initialized
INFO - 2023-09-22 05:33:28 --> Form Validation Class Initialized
INFO - 2023-09-22 05:33:28 --> Controller Class Initialized
INFO - 2023-09-22 05:33:28 --> Model Class Initialized
DEBUG - 2023-09-22 05:33:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:33:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:33:28 --> Model Class Initialized
DEBUG - 2023-09-22 05:33:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:33:28 --> Model Class Initialized
INFO - 2023-09-22 05:33:28 --> Final output sent to browser
DEBUG - 2023-09-22 05:33:28 --> Total execution time: 0.0315
ERROR - 2023-09-22 05:33:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:33:28 --> Config Class Initialized
INFO - 2023-09-22 05:33:28 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:33:28 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:33:28 --> Utf8 Class Initialized
INFO - 2023-09-22 05:33:28 --> URI Class Initialized
INFO - 2023-09-22 05:33:28 --> Router Class Initialized
INFO - 2023-09-22 05:33:28 --> Output Class Initialized
INFO - 2023-09-22 05:33:28 --> Security Class Initialized
DEBUG - 2023-09-22 05:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:33:28 --> Input Class Initialized
INFO - 2023-09-22 05:33:28 --> Language Class Initialized
INFO - 2023-09-22 05:33:28 --> Loader Class Initialized
INFO - 2023-09-22 05:33:28 --> Helper loaded: url_helper
INFO - 2023-09-22 05:33:28 --> Helper loaded: file_helper
INFO - 2023-09-22 05:33:28 --> Helper loaded: html_helper
INFO - 2023-09-22 05:33:28 --> Helper loaded: text_helper
INFO - 2023-09-22 05:33:28 --> Helper loaded: form_helper
INFO - 2023-09-22 05:33:28 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:33:28 --> Helper loaded: security_helper
INFO - 2023-09-22 05:33:28 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:33:28 --> Database Driver Class Initialized
INFO - 2023-09-22 05:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:33:28 --> Parser Class Initialized
INFO - 2023-09-22 05:33:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:33:28 --> Pagination Class Initialized
INFO - 2023-09-22 05:33:28 --> Form Validation Class Initialized
INFO - 2023-09-22 05:33:28 --> Controller Class Initialized
INFO - 2023-09-22 05:33:28 --> Model Class Initialized
DEBUG - 2023-09-22 05:33:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:33:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:33:28 --> Model Class Initialized
DEBUG - 2023-09-22 05:33:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:33:28 --> Model Class Initialized
INFO - 2023-09-22 05:33:28 --> Final output sent to browser
DEBUG - 2023-09-22 05:33:28 --> Total execution time: 0.0211
ERROR - 2023-09-22 05:33:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:33:30 --> Config Class Initialized
INFO - 2023-09-22 05:33:30 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:33:30 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:33:30 --> Utf8 Class Initialized
INFO - 2023-09-22 05:33:30 --> URI Class Initialized
INFO - 2023-09-22 05:33:30 --> Router Class Initialized
INFO - 2023-09-22 05:33:30 --> Output Class Initialized
INFO - 2023-09-22 05:33:30 --> Security Class Initialized
DEBUG - 2023-09-22 05:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:33:30 --> Input Class Initialized
INFO - 2023-09-22 05:33:30 --> Language Class Initialized
INFO - 2023-09-22 05:33:30 --> Loader Class Initialized
INFO - 2023-09-22 05:33:30 --> Helper loaded: url_helper
INFO - 2023-09-22 05:33:30 --> Helper loaded: file_helper
INFO - 2023-09-22 05:33:30 --> Helper loaded: html_helper
INFO - 2023-09-22 05:33:30 --> Helper loaded: text_helper
INFO - 2023-09-22 05:33:30 --> Helper loaded: form_helper
INFO - 2023-09-22 05:33:30 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:33:30 --> Helper loaded: security_helper
INFO - 2023-09-22 05:33:30 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:33:30 --> Database Driver Class Initialized
INFO - 2023-09-22 05:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:33:30 --> Parser Class Initialized
INFO - 2023-09-22 05:33:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:33:30 --> Pagination Class Initialized
INFO - 2023-09-22 05:33:30 --> Form Validation Class Initialized
INFO - 2023-09-22 05:33:30 --> Controller Class Initialized
INFO - 2023-09-22 05:33:30 --> Model Class Initialized
DEBUG - 2023-09-22 05:33:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:33:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:33:30 --> Model Class Initialized
DEBUG - 2023-09-22 05:33:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:33:30 --> Model Class Initialized
INFO - 2023-09-22 05:33:30 --> Final output sent to browser
DEBUG - 2023-09-22 05:33:30 --> Total execution time: 0.0213
ERROR - 2023-09-22 05:33:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:33:37 --> Config Class Initialized
INFO - 2023-09-22 05:33:37 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:33:37 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:33:37 --> Utf8 Class Initialized
INFO - 2023-09-22 05:33:37 --> URI Class Initialized
INFO - 2023-09-22 05:33:37 --> Router Class Initialized
INFO - 2023-09-22 05:33:37 --> Output Class Initialized
INFO - 2023-09-22 05:33:37 --> Security Class Initialized
DEBUG - 2023-09-22 05:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:33:37 --> Input Class Initialized
INFO - 2023-09-22 05:33:37 --> Language Class Initialized
INFO - 2023-09-22 05:33:37 --> Loader Class Initialized
INFO - 2023-09-22 05:33:37 --> Helper loaded: url_helper
INFO - 2023-09-22 05:33:37 --> Helper loaded: file_helper
INFO - 2023-09-22 05:33:37 --> Helper loaded: html_helper
INFO - 2023-09-22 05:33:37 --> Helper loaded: text_helper
INFO - 2023-09-22 05:33:37 --> Helper loaded: form_helper
INFO - 2023-09-22 05:33:37 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:33:37 --> Helper loaded: security_helper
INFO - 2023-09-22 05:33:37 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:33:37 --> Database Driver Class Initialized
INFO - 2023-09-22 05:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:33:37 --> Parser Class Initialized
INFO - 2023-09-22 05:33:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:33:37 --> Pagination Class Initialized
INFO - 2023-09-22 05:33:37 --> Form Validation Class Initialized
INFO - 2023-09-22 05:33:37 --> Controller Class Initialized
INFO - 2023-09-22 05:33:37 --> Model Class Initialized
DEBUG - 2023-09-22 05:33:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:33:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:33:37 --> Model Class Initialized
DEBUG - 2023-09-22 05:33:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:33:37 --> Model Class Initialized
INFO - 2023-09-22 05:33:37 --> Final output sent to browser
DEBUG - 2023-09-22 05:33:37 --> Total execution time: 0.0219
ERROR - 2023-09-22 05:33:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:33:46 --> Config Class Initialized
INFO - 2023-09-22 05:33:46 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:33:46 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:33:46 --> Utf8 Class Initialized
INFO - 2023-09-22 05:33:46 --> URI Class Initialized
INFO - 2023-09-22 05:33:46 --> Router Class Initialized
INFO - 2023-09-22 05:33:46 --> Output Class Initialized
INFO - 2023-09-22 05:33:46 --> Security Class Initialized
DEBUG - 2023-09-22 05:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:33:46 --> Input Class Initialized
INFO - 2023-09-22 05:33:46 --> Language Class Initialized
INFO - 2023-09-22 05:33:46 --> Loader Class Initialized
INFO - 2023-09-22 05:33:46 --> Helper loaded: url_helper
INFO - 2023-09-22 05:33:46 --> Helper loaded: file_helper
INFO - 2023-09-22 05:33:46 --> Helper loaded: html_helper
INFO - 2023-09-22 05:33:46 --> Helper loaded: text_helper
INFO - 2023-09-22 05:33:46 --> Helper loaded: form_helper
INFO - 2023-09-22 05:33:46 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:33:46 --> Helper loaded: security_helper
INFO - 2023-09-22 05:33:46 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:33:46 --> Database Driver Class Initialized
INFO - 2023-09-22 05:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:33:46 --> Parser Class Initialized
INFO - 2023-09-22 05:33:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:33:46 --> Pagination Class Initialized
INFO - 2023-09-22 05:33:46 --> Form Validation Class Initialized
INFO - 2023-09-22 05:33:46 --> Controller Class Initialized
INFO - 2023-09-22 05:33:46 --> Model Class Initialized
DEBUG - 2023-09-22 05:33:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:33:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:33:46 --> Model Class Initialized
DEBUG - 2023-09-22 05:33:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:33:46 --> Model Class Initialized
INFO - 2023-09-22 05:33:46 --> Final output sent to browser
DEBUG - 2023-09-22 05:33:46 --> Total execution time: 0.0248
ERROR - 2023-09-22 05:34:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:34:14 --> Config Class Initialized
INFO - 2023-09-22 05:34:14 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:34:14 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:34:14 --> Utf8 Class Initialized
INFO - 2023-09-22 05:34:14 --> URI Class Initialized
INFO - 2023-09-22 05:34:14 --> Router Class Initialized
INFO - 2023-09-22 05:34:14 --> Output Class Initialized
INFO - 2023-09-22 05:34:14 --> Security Class Initialized
DEBUG - 2023-09-22 05:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:34:14 --> Input Class Initialized
INFO - 2023-09-22 05:34:14 --> Language Class Initialized
INFO - 2023-09-22 05:34:14 --> Loader Class Initialized
INFO - 2023-09-22 05:34:14 --> Helper loaded: url_helper
INFO - 2023-09-22 05:34:14 --> Helper loaded: file_helper
INFO - 2023-09-22 05:34:14 --> Helper loaded: html_helper
INFO - 2023-09-22 05:34:14 --> Helper loaded: text_helper
INFO - 2023-09-22 05:34:14 --> Helper loaded: form_helper
INFO - 2023-09-22 05:34:14 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:34:14 --> Helper loaded: security_helper
INFO - 2023-09-22 05:34:14 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:34:14 --> Database Driver Class Initialized
INFO - 2023-09-22 05:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:34:14 --> Parser Class Initialized
INFO - 2023-09-22 05:34:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:34:14 --> Pagination Class Initialized
INFO - 2023-09-22 05:34:14 --> Form Validation Class Initialized
INFO - 2023-09-22 05:34:14 --> Controller Class Initialized
INFO - 2023-09-22 05:34:14 --> Model Class Initialized
DEBUG - 2023-09-22 05:34:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:34:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:34:14 --> Model Class Initialized
DEBUG - 2023-09-22 05:34:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:34:14 --> Model Class Initialized
INFO - 2023-09-22 05:34:14 --> Final output sent to browser
DEBUG - 2023-09-22 05:34:14 --> Total execution time: 0.0336
ERROR - 2023-09-22 05:34:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:34:15 --> Config Class Initialized
INFO - 2023-09-22 05:34:15 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:34:15 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:34:15 --> Utf8 Class Initialized
INFO - 2023-09-22 05:34:15 --> URI Class Initialized
INFO - 2023-09-22 05:34:15 --> Router Class Initialized
INFO - 2023-09-22 05:34:15 --> Output Class Initialized
INFO - 2023-09-22 05:34:15 --> Security Class Initialized
DEBUG - 2023-09-22 05:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:34:15 --> Input Class Initialized
INFO - 2023-09-22 05:34:15 --> Language Class Initialized
INFO - 2023-09-22 05:34:15 --> Loader Class Initialized
INFO - 2023-09-22 05:34:15 --> Helper loaded: url_helper
INFO - 2023-09-22 05:34:15 --> Helper loaded: file_helper
INFO - 2023-09-22 05:34:15 --> Helper loaded: html_helper
INFO - 2023-09-22 05:34:15 --> Helper loaded: text_helper
INFO - 2023-09-22 05:34:15 --> Helper loaded: form_helper
INFO - 2023-09-22 05:34:15 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:34:15 --> Helper loaded: security_helper
INFO - 2023-09-22 05:34:15 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:34:15 --> Database Driver Class Initialized
INFO - 2023-09-22 05:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:34:15 --> Parser Class Initialized
INFO - 2023-09-22 05:34:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:34:15 --> Pagination Class Initialized
INFO - 2023-09-22 05:34:15 --> Form Validation Class Initialized
INFO - 2023-09-22 05:34:15 --> Controller Class Initialized
INFO - 2023-09-22 05:34:15 --> Model Class Initialized
DEBUG - 2023-09-22 05:34:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:34:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:34:15 --> Model Class Initialized
DEBUG - 2023-09-22 05:34:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:34:15 --> Model Class Initialized
INFO - 2023-09-22 05:34:15 --> Final output sent to browser
DEBUG - 2023-09-22 05:34:15 --> Total execution time: 0.0786
ERROR - 2023-09-22 05:34:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:34:15 --> Config Class Initialized
INFO - 2023-09-22 05:34:15 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:34:15 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:34:15 --> Utf8 Class Initialized
INFO - 2023-09-22 05:34:15 --> URI Class Initialized
INFO - 2023-09-22 05:34:15 --> Router Class Initialized
INFO - 2023-09-22 05:34:15 --> Output Class Initialized
INFO - 2023-09-22 05:34:15 --> Security Class Initialized
DEBUG - 2023-09-22 05:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:34:15 --> Input Class Initialized
INFO - 2023-09-22 05:34:15 --> Language Class Initialized
INFO - 2023-09-22 05:34:15 --> Loader Class Initialized
INFO - 2023-09-22 05:34:15 --> Helper loaded: url_helper
INFO - 2023-09-22 05:34:15 --> Helper loaded: file_helper
INFO - 2023-09-22 05:34:15 --> Helper loaded: html_helper
INFO - 2023-09-22 05:34:15 --> Helper loaded: text_helper
INFO - 2023-09-22 05:34:15 --> Helper loaded: form_helper
INFO - 2023-09-22 05:34:15 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:34:15 --> Helper loaded: security_helper
INFO - 2023-09-22 05:34:15 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:34:15 --> Database Driver Class Initialized
INFO - 2023-09-22 05:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:34:15 --> Parser Class Initialized
INFO - 2023-09-22 05:34:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:34:15 --> Pagination Class Initialized
INFO - 2023-09-22 05:34:15 --> Form Validation Class Initialized
INFO - 2023-09-22 05:34:15 --> Controller Class Initialized
INFO - 2023-09-22 05:34:15 --> Model Class Initialized
DEBUG - 2023-09-22 05:34:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:34:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:34:15 --> Model Class Initialized
DEBUG - 2023-09-22 05:34:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:34:15 --> Model Class Initialized
INFO - 2023-09-22 05:34:15 --> Final output sent to browser
DEBUG - 2023-09-22 05:34:15 --> Total execution time: 0.0635
ERROR - 2023-09-22 05:34:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:34:16 --> Config Class Initialized
INFO - 2023-09-22 05:34:16 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:34:16 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:34:16 --> Utf8 Class Initialized
INFO - 2023-09-22 05:34:16 --> URI Class Initialized
INFO - 2023-09-22 05:34:16 --> Router Class Initialized
INFO - 2023-09-22 05:34:16 --> Output Class Initialized
INFO - 2023-09-22 05:34:16 --> Security Class Initialized
DEBUG - 2023-09-22 05:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:34:16 --> Input Class Initialized
INFO - 2023-09-22 05:34:16 --> Language Class Initialized
INFO - 2023-09-22 05:34:16 --> Loader Class Initialized
INFO - 2023-09-22 05:34:16 --> Helper loaded: url_helper
INFO - 2023-09-22 05:34:16 --> Helper loaded: file_helper
INFO - 2023-09-22 05:34:16 --> Helper loaded: html_helper
INFO - 2023-09-22 05:34:16 --> Helper loaded: text_helper
INFO - 2023-09-22 05:34:16 --> Helper loaded: form_helper
INFO - 2023-09-22 05:34:16 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:34:16 --> Helper loaded: security_helper
INFO - 2023-09-22 05:34:16 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:34:16 --> Database Driver Class Initialized
INFO - 2023-09-22 05:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:34:16 --> Parser Class Initialized
INFO - 2023-09-22 05:34:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:34:16 --> Pagination Class Initialized
INFO - 2023-09-22 05:34:16 --> Form Validation Class Initialized
INFO - 2023-09-22 05:34:16 --> Controller Class Initialized
INFO - 2023-09-22 05:34:16 --> Model Class Initialized
DEBUG - 2023-09-22 05:34:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:34:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:34:16 --> Model Class Initialized
DEBUG - 2023-09-22 05:34:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:34:16 --> Model Class Initialized
INFO - 2023-09-22 05:34:16 --> Final output sent to browser
DEBUG - 2023-09-22 05:34:16 --> Total execution time: 0.0675
ERROR - 2023-09-22 05:34:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:34:17 --> Config Class Initialized
INFO - 2023-09-22 05:34:17 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:34:17 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:34:17 --> Utf8 Class Initialized
INFO - 2023-09-22 05:34:17 --> URI Class Initialized
INFO - 2023-09-22 05:34:17 --> Router Class Initialized
INFO - 2023-09-22 05:34:17 --> Output Class Initialized
INFO - 2023-09-22 05:34:17 --> Security Class Initialized
DEBUG - 2023-09-22 05:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:34:17 --> Input Class Initialized
INFO - 2023-09-22 05:34:17 --> Language Class Initialized
INFO - 2023-09-22 05:34:17 --> Loader Class Initialized
INFO - 2023-09-22 05:34:17 --> Helper loaded: url_helper
INFO - 2023-09-22 05:34:17 --> Helper loaded: file_helper
INFO - 2023-09-22 05:34:17 --> Helper loaded: html_helper
INFO - 2023-09-22 05:34:17 --> Helper loaded: text_helper
INFO - 2023-09-22 05:34:17 --> Helper loaded: form_helper
INFO - 2023-09-22 05:34:17 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:34:17 --> Helper loaded: security_helper
INFO - 2023-09-22 05:34:17 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:34:17 --> Database Driver Class Initialized
INFO - 2023-09-22 05:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:34:17 --> Parser Class Initialized
INFO - 2023-09-22 05:34:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:34:17 --> Pagination Class Initialized
INFO - 2023-09-22 05:34:17 --> Form Validation Class Initialized
INFO - 2023-09-22 05:34:17 --> Controller Class Initialized
INFO - 2023-09-22 05:34:17 --> Model Class Initialized
DEBUG - 2023-09-22 05:34:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:34:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:34:17 --> Model Class Initialized
DEBUG - 2023-09-22 05:34:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:34:17 --> Model Class Initialized
INFO - 2023-09-22 05:34:17 --> Final output sent to browser
DEBUG - 2023-09-22 05:34:17 --> Total execution time: 0.0522
ERROR - 2023-09-22 05:34:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:34:18 --> Config Class Initialized
INFO - 2023-09-22 05:34:18 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:34:18 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:34:18 --> Utf8 Class Initialized
INFO - 2023-09-22 05:34:18 --> URI Class Initialized
INFO - 2023-09-22 05:34:18 --> Router Class Initialized
INFO - 2023-09-22 05:34:18 --> Output Class Initialized
INFO - 2023-09-22 05:34:18 --> Security Class Initialized
DEBUG - 2023-09-22 05:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:34:18 --> Input Class Initialized
INFO - 2023-09-22 05:34:18 --> Language Class Initialized
INFO - 2023-09-22 05:34:18 --> Loader Class Initialized
INFO - 2023-09-22 05:34:18 --> Helper loaded: url_helper
INFO - 2023-09-22 05:34:18 --> Helper loaded: file_helper
INFO - 2023-09-22 05:34:18 --> Helper loaded: html_helper
INFO - 2023-09-22 05:34:18 --> Helper loaded: text_helper
INFO - 2023-09-22 05:34:18 --> Helper loaded: form_helper
INFO - 2023-09-22 05:34:18 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:34:18 --> Helper loaded: security_helper
INFO - 2023-09-22 05:34:18 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:34:18 --> Database Driver Class Initialized
INFO - 2023-09-22 05:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:34:18 --> Parser Class Initialized
INFO - 2023-09-22 05:34:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:34:18 --> Pagination Class Initialized
INFO - 2023-09-22 05:34:18 --> Form Validation Class Initialized
INFO - 2023-09-22 05:34:18 --> Controller Class Initialized
INFO - 2023-09-22 05:34:18 --> Model Class Initialized
DEBUG - 2023-09-22 05:34:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:34:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:34:18 --> Model Class Initialized
DEBUG - 2023-09-22 05:34:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:34:18 --> Model Class Initialized
INFO - 2023-09-22 05:34:18 --> Final output sent to browser
DEBUG - 2023-09-22 05:34:18 --> Total execution time: 0.0258
ERROR - 2023-09-22 05:34:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:34:31 --> Config Class Initialized
INFO - 2023-09-22 05:34:31 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:34:31 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:34:31 --> Utf8 Class Initialized
INFO - 2023-09-22 05:34:31 --> URI Class Initialized
INFO - 2023-09-22 05:34:31 --> Router Class Initialized
INFO - 2023-09-22 05:34:31 --> Output Class Initialized
INFO - 2023-09-22 05:34:31 --> Security Class Initialized
DEBUG - 2023-09-22 05:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:34:31 --> Input Class Initialized
INFO - 2023-09-22 05:34:31 --> Language Class Initialized
INFO - 2023-09-22 05:34:31 --> Loader Class Initialized
INFO - 2023-09-22 05:34:31 --> Helper loaded: url_helper
INFO - 2023-09-22 05:34:31 --> Helper loaded: file_helper
INFO - 2023-09-22 05:34:31 --> Helper loaded: html_helper
INFO - 2023-09-22 05:34:31 --> Helper loaded: text_helper
INFO - 2023-09-22 05:34:31 --> Helper loaded: form_helper
INFO - 2023-09-22 05:34:31 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:34:31 --> Helper loaded: security_helper
INFO - 2023-09-22 05:34:31 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:34:31 --> Database Driver Class Initialized
INFO - 2023-09-22 05:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:34:31 --> Parser Class Initialized
INFO - 2023-09-22 05:34:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:34:31 --> Pagination Class Initialized
INFO - 2023-09-22 05:34:31 --> Form Validation Class Initialized
INFO - 2023-09-22 05:34:31 --> Controller Class Initialized
INFO - 2023-09-22 05:34:31 --> Model Class Initialized
DEBUG - 2023-09-22 05:34:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:34:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:34:31 --> Model Class Initialized
DEBUG - 2023-09-22 05:34:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:34:31 --> Model Class Initialized
INFO - 2023-09-22 05:34:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-09-22 05:34:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:34:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-22 05:34:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-22 05:34:31 --> Model Class Initialized
INFO - 2023-09-22 05:34:31 --> Model Class Initialized
INFO - 2023-09-22 05:34:31 --> Model Class Initialized
INFO - 2023-09-22 05:34:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-22 05:34:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-22 05:34:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-22 05:34:31 --> Final output sent to browser
DEBUG - 2023-09-22 05:34:31 --> Total execution time: 0.1162
ERROR - 2023-09-22 05:34:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:34:35 --> Config Class Initialized
INFO - 2023-09-22 05:34:35 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:34:35 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:34:35 --> Utf8 Class Initialized
INFO - 2023-09-22 05:34:35 --> URI Class Initialized
DEBUG - 2023-09-22 05:34:35 --> No URI present. Default controller set.
INFO - 2023-09-22 05:34:35 --> Router Class Initialized
INFO - 2023-09-22 05:34:35 --> Output Class Initialized
INFO - 2023-09-22 05:34:35 --> Security Class Initialized
DEBUG - 2023-09-22 05:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:34:35 --> Input Class Initialized
INFO - 2023-09-22 05:34:35 --> Language Class Initialized
INFO - 2023-09-22 05:34:35 --> Loader Class Initialized
INFO - 2023-09-22 05:34:35 --> Helper loaded: url_helper
INFO - 2023-09-22 05:34:35 --> Helper loaded: file_helper
INFO - 2023-09-22 05:34:35 --> Helper loaded: html_helper
INFO - 2023-09-22 05:34:35 --> Helper loaded: text_helper
INFO - 2023-09-22 05:34:35 --> Helper loaded: form_helper
INFO - 2023-09-22 05:34:35 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:34:35 --> Helper loaded: security_helper
INFO - 2023-09-22 05:34:35 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:34:35 --> Database Driver Class Initialized
INFO - 2023-09-22 05:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:34:35 --> Parser Class Initialized
INFO - 2023-09-22 05:34:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:34:35 --> Pagination Class Initialized
INFO - 2023-09-22 05:34:35 --> Form Validation Class Initialized
INFO - 2023-09-22 05:34:35 --> Controller Class Initialized
INFO - 2023-09-22 05:34:35 --> Model Class Initialized
DEBUG - 2023-09-22 05:34:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:34:35 --> Model Class Initialized
DEBUG - 2023-09-22 05:34:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:34:35 --> Model Class Initialized
INFO - 2023-09-22 05:34:35 --> Model Class Initialized
INFO - 2023-09-22 05:34:35 --> Model Class Initialized
INFO - 2023-09-22 05:34:35 --> Model Class Initialized
DEBUG - 2023-09-22 05:34:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:34:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:34:35 --> Model Class Initialized
INFO - 2023-09-22 05:34:35 --> Model Class Initialized
INFO - 2023-09-22 05:34:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-22 05:34:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:34:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-22 05:34:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-22 05:34:35 --> Model Class Initialized
INFO - 2023-09-22 05:34:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-22 05:34:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-22 05:34:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-22 05:34:36 --> Final output sent to browser
DEBUG - 2023-09-22 05:34:36 --> Total execution time: 0.1112
ERROR - 2023-09-22 05:34:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:34:42 --> Config Class Initialized
INFO - 2023-09-22 05:34:42 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:34:42 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:34:42 --> Utf8 Class Initialized
INFO - 2023-09-22 05:34:42 --> URI Class Initialized
INFO - 2023-09-22 05:34:42 --> Router Class Initialized
INFO - 2023-09-22 05:34:42 --> Output Class Initialized
INFO - 2023-09-22 05:34:42 --> Security Class Initialized
DEBUG - 2023-09-22 05:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:34:42 --> Input Class Initialized
INFO - 2023-09-22 05:34:42 --> Language Class Initialized
INFO - 2023-09-22 05:34:42 --> Loader Class Initialized
INFO - 2023-09-22 05:34:42 --> Helper loaded: url_helper
INFO - 2023-09-22 05:34:42 --> Helper loaded: file_helper
INFO - 2023-09-22 05:34:42 --> Helper loaded: html_helper
INFO - 2023-09-22 05:34:42 --> Helper loaded: text_helper
INFO - 2023-09-22 05:34:42 --> Helper loaded: form_helper
INFO - 2023-09-22 05:34:42 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:34:42 --> Helper loaded: security_helper
INFO - 2023-09-22 05:34:42 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:34:42 --> Database Driver Class Initialized
INFO - 2023-09-22 05:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:34:42 --> Parser Class Initialized
INFO - 2023-09-22 05:34:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:34:42 --> Pagination Class Initialized
INFO - 2023-09-22 05:34:42 --> Form Validation Class Initialized
INFO - 2023-09-22 05:34:42 --> Controller Class Initialized
INFO - 2023-09-22 05:34:42 --> Model Class Initialized
DEBUG - 2023-09-22 05:34:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:34:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:34:42 --> Model Class Initialized
DEBUG - 2023-09-22 05:34:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:34:42 --> Model Class Initialized
INFO - 2023-09-22 05:34:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-22 05:34:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:34:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-22 05:34:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-22 05:34:42 --> Model Class Initialized
INFO - 2023-09-22 05:34:42 --> Model Class Initialized
INFO - 2023-09-22 05:34:42 --> Model Class Initialized
INFO - 2023-09-22 05:34:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-22 05:34:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-22 05:34:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-22 05:34:42 --> Final output sent to browser
DEBUG - 2023-09-22 05:34:42 --> Total execution time: 0.0919
ERROR - 2023-09-22 05:34:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:34:43 --> Config Class Initialized
INFO - 2023-09-22 05:34:43 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:34:43 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:34:43 --> Utf8 Class Initialized
INFO - 2023-09-22 05:34:43 --> URI Class Initialized
INFO - 2023-09-22 05:34:43 --> Router Class Initialized
INFO - 2023-09-22 05:34:43 --> Output Class Initialized
INFO - 2023-09-22 05:34:43 --> Security Class Initialized
DEBUG - 2023-09-22 05:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:34:43 --> Input Class Initialized
INFO - 2023-09-22 05:34:43 --> Language Class Initialized
INFO - 2023-09-22 05:34:43 --> Loader Class Initialized
INFO - 2023-09-22 05:34:43 --> Helper loaded: url_helper
INFO - 2023-09-22 05:34:43 --> Helper loaded: file_helper
INFO - 2023-09-22 05:34:43 --> Helper loaded: html_helper
INFO - 2023-09-22 05:34:43 --> Helper loaded: text_helper
INFO - 2023-09-22 05:34:43 --> Helper loaded: form_helper
INFO - 2023-09-22 05:34:43 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:34:43 --> Helper loaded: security_helper
INFO - 2023-09-22 05:34:43 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:34:43 --> Database Driver Class Initialized
INFO - 2023-09-22 05:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:34:43 --> Parser Class Initialized
INFO - 2023-09-22 05:34:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:34:43 --> Pagination Class Initialized
INFO - 2023-09-22 05:34:43 --> Form Validation Class Initialized
INFO - 2023-09-22 05:34:43 --> Controller Class Initialized
INFO - 2023-09-22 05:34:43 --> Model Class Initialized
DEBUG - 2023-09-22 05:34:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:34:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:34:43 --> Model Class Initialized
DEBUG - 2023-09-22 05:34:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:34:43 --> Model Class Initialized
INFO - 2023-09-22 05:34:43 --> Final output sent to browser
DEBUG - 2023-09-22 05:34:43 --> Total execution time: 0.0381
ERROR - 2023-09-22 05:34:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:34:48 --> Config Class Initialized
INFO - 2023-09-22 05:34:48 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:34:48 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:34:48 --> Utf8 Class Initialized
INFO - 2023-09-22 05:34:48 --> URI Class Initialized
INFO - 2023-09-22 05:34:48 --> Router Class Initialized
INFO - 2023-09-22 05:34:48 --> Output Class Initialized
INFO - 2023-09-22 05:34:48 --> Security Class Initialized
DEBUG - 2023-09-22 05:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:34:48 --> Input Class Initialized
INFO - 2023-09-22 05:34:48 --> Language Class Initialized
INFO - 2023-09-22 05:34:48 --> Loader Class Initialized
INFO - 2023-09-22 05:34:48 --> Helper loaded: url_helper
INFO - 2023-09-22 05:34:48 --> Helper loaded: file_helper
INFO - 2023-09-22 05:34:48 --> Helper loaded: html_helper
INFO - 2023-09-22 05:34:48 --> Helper loaded: text_helper
INFO - 2023-09-22 05:34:48 --> Helper loaded: form_helper
INFO - 2023-09-22 05:34:48 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:34:48 --> Helper loaded: security_helper
INFO - 2023-09-22 05:34:48 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:34:48 --> Database Driver Class Initialized
INFO - 2023-09-22 05:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:34:48 --> Parser Class Initialized
INFO - 2023-09-22 05:34:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:34:48 --> Pagination Class Initialized
INFO - 2023-09-22 05:34:48 --> Form Validation Class Initialized
INFO - 2023-09-22 05:34:48 --> Controller Class Initialized
INFO - 2023-09-22 05:34:48 --> Model Class Initialized
DEBUG - 2023-09-22 05:34:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:34:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:34:48 --> Model Class Initialized
DEBUG - 2023-09-22 05:34:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:34:48 --> Model Class Initialized
INFO - 2023-09-22 05:34:48 --> Final output sent to browser
DEBUG - 2023-09-22 05:34:48 --> Total execution time: 0.0419
ERROR - 2023-09-22 05:34:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:34:49 --> Config Class Initialized
INFO - 2023-09-22 05:34:49 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:34:49 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:34:49 --> Utf8 Class Initialized
INFO - 2023-09-22 05:34:49 --> URI Class Initialized
INFO - 2023-09-22 05:34:49 --> Router Class Initialized
INFO - 2023-09-22 05:34:49 --> Output Class Initialized
INFO - 2023-09-22 05:34:49 --> Security Class Initialized
DEBUG - 2023-09-22 05:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:34:49 --> Input Class Initialized
INFO - 2023-09-22 05:34:49 --> Language Class Initialized
INFO - 2023-09-22 05:34:49 --> Loader Class Initialized
INFO - 2023-09-22 05:34:49 --> Helper loaded: url_helper
INFO - 2023-09-22 05:34:49 --> Helper loaded: file_helper
INFO - 2023-09-22 05:34:49 --> Helper loaded: html_helper
INFO - 2023-09-22 05:34:49 --> Helper loaded: text_helper
INFO - 2023-09-22 05:34:49 --> Helper loaded: form_helper
INFO - 2023-09-22 05:34:49 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:34:49 --> Helper loaded: security_helper
INFO - 2023-09-22 05:34:49 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:34:49 --> Database Driver Class Initialized
INFO - 2023-09-22 05:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:34:49 --> Parser Class Initialized
INFO - 2023-09-22 05:34:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:34:49 --> Pagination Class Initialized
INFO - 2023-09-22 05:34:49 --> Form Validation Class Initialized
INFO - 2023-09-22 05:34:49 --> Controller Class Initialized
INFO - 2023-09-22 05:34:49 --> Model Class Initialized
DEBUG - 2023-09-22 05:34:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:34:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:34:49 --> Model Class Initialized
DEBUG - 2023-09-22 05:34:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:34:49 --> Model Class Initialized
INFO - 2023-09-22 05:34:49 --> Final output sent to browser
DEBUG - 2023-09-22 05:34:49 --> Total execution time: 0.0385
ERROR - 2023-09-22 05:34:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:34:50 --> Config Class Initialized
INFO - 2023-09-22 05:34:50 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:34:50 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:34:50 --> Utf8 Class Initialized
INFO - 2023-09-22 05:34:50 --> URI Class Initialized
INFO - 2023-09-22 05:34:50 --> Router Class Initialized
INFO - 2023-09-22 05:34:50 --> Output Class Initialized
INFO - 2023-09-22 05:34:50 --> Security Class Initialized
DEBUG - 2023-09-22 05:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:34:50 --> Input Class Initialized
INFO - 2023-09-22 05:34:50 --> Language Class Initialized
INFO - 2023-09-22 05:34:50 --> Loader Class Initialized
INFO - 2023-09-22 05:34:50 --> Helper loaded: url_helper
INFO - 2023-09-22 05:34:50 --> Helper loaded: file_helper
INFO - 2023-09-22 05:34:50 --> Helper loaded: html_helper
INFO - 2023-09-22 05:34:50 --> Helper loaded: text_helper
INFO - 2023-09-22 05:34:50 --> Helper loaded: form_helper
INFO - 2023-09-22 05:34:50 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:34:50 --> Helper loaded: security_helper
INFO - 2023-09-22 05:34:50 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:34:50 --> Database Driver Class Initialized
INFO - 2023-09-22 05:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:34:50 --> Parser Class Initialized
INFO - 2023-09-22 05:34:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:34:50 --> Pagination Class Initialized
INFO - 2023-09-22 05:34:50 --> Form Validation Class Initialized
INFO - 2023-09-22 05:34:50 --> Controller Class Initialized
INFO - 2023-09-22 05:34:50 --> Model Class Initialized
DEBUG - 2023-09-22 05:34:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:34:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:34:50 --> Model Class Initialized
DEBUG - 2023-09-22 05:34:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:34:50 --> Model Class Initialized
INFO - 2023-09-22 05:34:50 --> Final output sent to browser
DEBUG - 2023-09-22 05:34:50 --> Total execution time: 0.0385
ERROR - 2023-09-22 05:41:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:41:46 --> Config Class Initialized
INFO - 2023-09-22 05:41:46 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:41:46 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:41:46 --> Utf8 Class Initialized
INFO - 2023-09-22 05:41:46 --> URI Class Initialized
DEBUG - 2023-09-22 05:41:46 --> No URI present. Default controller set.
INFO - 2023-09-22 05:41:46 --> Router Class Initialized
INFO - 2023-09-22 05:41:46 --> Output Class Initialized
INFO - 2023-09-22 05:41:46 --> Security Class Initialized
DEBUG - 2023-09-22 05:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:41:46 --> Input Class Initialized
INFO - 2023-09-22 05:41:46 --> Language Class Initialized
INFO - 2023-09-22 05:41:46 --> Loader Class Initialized
INFO - 2023-09-22 05:41:46 --> Helper loaded: url_helper
INFO - 2023-09-22 05:41:46 --> Helper loaded: file_helper
INFO - 2023-09-22 05:41:46 --> Helper loaded: html_helper
INFO - 2023-09-22 05:41:46 --> Helper loaded: text_helper
INFO - 2023-09-22 05:41:46 --> Helper loaded: form_helper
INFO - 2023-09-22 05:41:46 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:41:46 --> Helper loaded: security_helper
INFO - 2023-09-22 05:41:46 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:41:46 --> Database Driver Class Initialized
INFO - 2023-09-22 05:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:41:46 --> Parser Class Initialized
INFO - 2023-09-22 05:41:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:41:46 --> Pagination Class Initialized
INFO - 2023-09-22 05:41:46 --> Form Validation Class Initialized
INFO - 2023-09-22 05:41:46 --> Controller Class Initialized
INFO - 2023-09-22 05:41:46 --> Model Class Initialized
DEBUG - 2023-09-22 05:41:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-22 05:41:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:41:47 --> Config Class Initialized
INFO - 2023-09-22 05:41:47 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:41:47 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:41:47 --> Utf8 Class Initialized
INFO - 2023-09-22 05:41:47 --> URI Class Initialized
INFO - 2023-09-22 05:41:47 --> Router Class Initialized
INFO - 2023-09-22 05:41:47 --> Output Class Initialized
INFO - 2023-09-22 05:41:47 --> Security Class Initialized
DEBUG - 2023-09-22 05:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:41:47 --> Input Class Initialized
INFO - 2023-09-22 05:41:47 --> Language Class Initialized
INFO - 2023-09-22 05:41:47 --> Loader Class Initialized
INFO - 2023-09-22 05:41:47 --> Helper loaded: url_helper
INFO - 2023-09-22 05:41:47 --> Helper loaded: file_helper
INFO - 2023-09-22 05:41:47 --> Helper loaded: html_helper
INFO - 2023-09-22 05:41:47 --> Helper loaded: text_helper
INFO - 2023-09-22 05:41:47 --> Helper loaded: form_helper
INFO - 2023-09-22 05:41:47 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:41:47 --> Helper loaded: security_helper
INFO - 2023-09-22 05:41:47 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:41:47 --> Database Driver Class Initialized
INFO - 2023-09-22 05:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:41:47 --> Parser Class Initialized
INFO - 2023-09-22 05:41:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:41:47 --> Pagination Class Initialized
INFO - 2023-09-22 05:41:47 --> Form Validation Class Initialized
INFO - 2023-09-22 05:41:47 --> Controller Class Initialized
INFO - 2023-09-22 05:41:47 --> Model Class Initialized
DEBUG - 2023-09-22 05:41:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:41:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-22 05:41:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:41:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-22 05:41:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-22 05:41:47 --> Model Class Initialized
INFO - 2023-09-22 05:41:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-22 05:41:47 --> Final output sent to browser
DEBUG - 2023-09-22 05:41:47 --> Total execution time: 0.0336
ERROR - 2023-09-22 05:41:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:41:51 --> Config Class Initialized
INFO - 2023-09-22 05:41:51 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:41:51 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:41:51 --> Utf8 Class Initialized
INFO - 2023-09-22 05:41:51 --> URI Class Initialized
INFO - 2023-09-22 05:41:51 --> Router Class Initialized
INFO - 2023-09-22 05:41:51 --> Output Class Initialized
INFO - 2023-09-22 05:41:51 --> Security Class Initialized
DEBUG - 2023-09-22 05:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:41:51 --> Input Class Initialized
INFO - 2023-09-22 05:41:51 --> Language Class Initialized
INFO - 2023-09-22 05:41:51 --> Loader Class Initialized
INFO - 2023-09-22 05:41:51 --> Helper loaded: url_helper
INFO - 2023-09-22 05:41:51 --> Helper loaded: file_helper
INFO - 2023-09-22 05:41:51 --> Helper loaded: html_helper
INFO - 2023-09-22 05:41:51 --> Helper loaded: text_helper
INFO - 2023-09-22 05:41:51 --> Helper loaded: form_helper
INFO - 2023-09-22 05:41:51 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:41:51 --> Helper loaded: security_helper
INFO - 2023-09-22 05:41:51 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:41:51 --> Database Driver Class Initialized
INFO - 2023-09-22 05:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:41:51 --> Parser Class Initialized
INFO - 2023-09-22 05:41:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:41:51 --> Pagination Class Initialized
INFO - 2023-09-22 05:41:51 --> Form Validation Class Initialized
INFO - 2023-09-22 05:41:51 --> Controller Class Initialized
INFO - 2023-09-22 05:41:51 --> Model Class Initialized
DEBUG - 2023-09-22 05:41:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:41:51 --> Model Class Initialized
INFO - 2023-09-22 05:41:51 --> Final output sent to browser
DEBUG - 2023-09-22 05:41:51 --> Total execution time: 0.0169
ERROR - 2023-09-22 05:41:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:41:51 --> Config Class Initialized
INFO - 2023-09-22 05:41:51 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:41:51 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:41:51 --> Utf8 Class Initialized
INFO - 2023-09-22 05:41:51 --> URI Class Initialized
DEBUG - 2023-09-22 05:41:51 --> No URI present. Default controller set.
INFO - 2023-09-22 05:41:51 --> Router Class Initialized
INFO - 2023-09-22 05:41:51 --> Output Class Initialized
INFO - 2023-09-22 05:41:51 --> Security Class Initialized
DEBUG - 2023-09-22 05:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:41:51 --> Input Class Initialized
INFO - 2023-09-22 05:41:51 --> Language Class Initialized
INFO - 2023-09-22 05:41:51 --> Loader Class Initialized
INFO - 2023-09-22 05:41:51 --> Helper loaded: url_helper
INFO - 2023-09-22 05:41:51 --> Helper loaded: file_helper
INFO - 2023-09-22 05:41:51 --> Helper loaded: html_helper
INFO - 2023-09-22 05:41:51 --> Helper loaded: text_helper
INFO - 2023-09-22 05:41:51 --> Helper loaded: form_helper
INFO - 2023-09-22 05:41:51 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:41:51 --> Helper loaded: security_helper
INFO - 2023-09-22 05:41:51 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:41:51 --> Database Driver Class Initialized
INFO - 2023-09-22 05:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:41:51 --> Parser Class Initialized
INFO - 2023-09-22 05:41:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:41:51 --> Pagination Class Initialized
INFO - 2023-09-22 05:41:51 --> Form Validation Class Initialized
INFO - 2023-09-22 05:41:51 --> Controller Class Initialized
INFO - 2023-09-22 05:41:51 --> Model Class Initialized
DEBUG - 2023-09-22 05:41:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:41:51 --> Model Class Initialized
DEBUG - 2023-09-22 05:41:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:41:51 --> Model Class Initialized
INFO - 2023-09-22 05:41:51 --> Model Class Initialized
INFO - 2023-09-22 05:41:51 --> Model Class Initialized
INFO - 2023-09-22 05:41:51 --> Model Class Initialized
DEBUG - 2023-09-22 05:41:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:41:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:41:51 --> Model Class Initialized
INFO - 2023-09-22 05:41:51 --> Model Class Initialized
INFO - 2023-09-22 05:41:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-22 05:41:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:41:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-22 05:41:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-22 05:41:52 --> Model Class Initialized
INFO - 2023-09-22 05:41:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-22 05:41:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-22 05:41:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-22 05:41:52 --> Final output sent to browser
DEBUG - 2023-09-22 05:41:52 --> Total execution time: 0.1107
ERROR - 2023-09-22 05:42:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:42:02 --> Config Class Initialized
INFO - 2023-09-22 05:42:02 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:42:02 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:42:02 --> Utf8 Class Initialized
INFO - 2023-09-22 05:42:02 --> URI Class Initialized
INFO - 2023-09-22 05:42:02 --> Router Class Initialized
INFO - 2023-09-22 05:42:02 --> Output Class Initialized
INFO - 2023-09-22 05:42:02 --> Security Class Initialized
DEBUG - 2023-09-22 05:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:42:02 --> Input Class Initialized
INFO - 2023-09-22 05:42:02 --> Language Class Initialized
INFO - 2023-09-22 05:42:02 --> Loader Class Initialized
INFO - 2023-09-22 05:42:02 --> Helper loaded: url_helper
INFO - 2023-09-22 05:42:02 --> Helper loaded: file_helper
INFO - 2023-09-22 05:42:02 --> Helper loaded: html_helper
INFO - 2023-09-22 05:42:02 --> Helper loaded: text_helper
INFO - 2023-09-22 05:42:02 --> Helper loaded: form_helper
INFO - 2023-09-22 05:42:02 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:42:02 --> Helper loaded: security_helper
INFO - 2023-09-22 05:42:02 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:42:02 --> Database Driver Class Initialized
INFO - 2023-09-22 05:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:42:02 --> Parser Class Initialized
INFO - 2023-09-22 05:42:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:42:02 --> Pagination Class Initialized
INFO - 2023-09-22 05:42:02 --> Form Validation Class Initialized
INFO - 2023-09-22 05:42:02 --> Controller Class Initialized
INFO - 2023-09-22 05:42:02 --> Model Class Initialized
DEBUG - 2023-09-22 05:42:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:42:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:42:02 --> Model Class Initialized
DEBUG - 2023-09-22 05:42:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:42:02 --> Model Class Initialized
INFO - 2023-09-22 05:42:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-22 05:42:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:42:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-22 05:42:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-22 05:42:02 --> Model Class Initialized
INFO - 2023-09-22 05:42:02 --> Model Class Initialized
INFO - 2023-09-22 05:42:02 --> Model Class Initialized
INFO - 2023-09-22 05:42:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-22 05:42:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-22 05:42:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-22 05:42:02 --> Final output sent to browser
DEBUG - 2023-09-22 05:42:02 --> Total execution time: 0.0855
ERROR - 2023-09-22 05:42:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:42:03 --> Config Class Initialized
INFO - 2023-09-22 05:42:03 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:42:03 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:42:03 --> Utf8 Class Initialized
INFO - 2023-09-22 05:42:03 --> URI Class Initialized
INFO - 2023-09-22 05:42:03 --> Router Class Initialized
INFO - 2023-09-22 05:42:03 --> Output Class Initialized
INFO - 2023-09-22 05:42:03 --> Security Class Initialized
DEBUG - 2023-09-22 05:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:42:03 --> Input Class Initialized
INFO - 2023-09-22 05:42:03 --> Language Class Initialized
INFO - 2023-09-22 05:42:03 --> Loader Class Initialized
INFO - 2023-09-22 05:42:03 --> Helper loaded: url_helper
INFO - 2023-09-22 05:42:03 --> Helper loaded: file_helper
INFO - 2023-09-22 05:42:03 --> Helper loaded: html_helper
INFO - 2023-09-22 05:42:03 --> Helper loaded: text_helper
INFO - 2023-09-22 05:42:03 --> Helper loaded: form_helper
INFO - 2023-09-22 05:42:03 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:42:03 --> Helper loaded: security_helper
INFO - 2023-09-22 05:42:03 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:42:03 --> Database Driver Class Initialized
INFO - 2023-09-22 05:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:42:03 --> Parser Class Initialized
INFO - 2023-09-22 05:42:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:42:03 --> Pagination Class Initialized
INFO - 2023-09-22 05:42:03 --> Form Validation Class Initialized
INFO - 2023-09-22 05:42:03 --> Controller Class Initialized
INFO - 2023-09-22 05:42:03 --> Model Class Initialized
DEBUG - 2023-09-22 05:42:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:42:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:42:03 --> Model Class Initialized
DEBUG - 2023-09-22 05:42:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:42:03 --> Model Class Initialized
INFO - 2023-09-22 05:42:03 --> Final output sent to browser
DEBUG - 2023-09-22 05:42:03 --> Total execution time: 0.0441
ERROR - 2023-09-22 05:42:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 05:42:06 --> Config Class Initialized
INFO - 2023-09-22 05:42:06 --> Hooks Class Initialized
DEBUG - 2023-09-22 05:42:06 --> UTF-8 Support Enabled
INFO - 2023-09-22 05:42:06 --> Utf8 Class Initialized
INFO - 2023-09-22 05:42:06 --> URI Class Initialized
INFO - 2023-09-22 05:42:06 --> Router Class Initialized
INFO - 2023-09-22 05:42:06 --> Output Class Initialized
INFO - 2023-09-22 05:42:06 --> Security Class Initialized
DEBUG - 2023-09-22 05:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 05:42:06 --> Input Class Initialized
INFO - 2023-09-22 05:42:06 --> Language Class Initialized
INFO - 2023-09-22 05:42:06 --> Loader Class Initialized
INFO - 2023-09-22 05:42:06 --> Helper loaded: url_helper
INFO - 2023-09-22 05:42:06 --> Helper loaded: file_helper
INFO - 2023-09-22 05:42:06 --> Helper loaded: html_helper
INFO - 2023-09-22 05:42:06 --> Helper loaded: text_helper
INFO - 2023-09-22 05:42:06 --> Helper loaded: form_helper
INFO - 2023-09-22 05:42:06 --> Helper loaded: lang_helper
INFO - 2023-09-22 05:42:06 --> Helper loaded: security_helper
INFO - 2023-09-22 05:42:06 --> Helper loaded: cookie_helper
INFO - 2023-09-22 05:42:06 --> Database Driver Class Initialized
INFO - 2023-09-22 05:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 05:42:06 --> Parser Class Initialized
INFO - 2023-09-22 05:42:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 05:42:06 --> Pagination Class Initialized
INFO - 2023-09-22 05:42:06 --> Form Validation Class Initialized
INFO - 2023-09-22 05:42:06 --> Controller Class Initialized
INFO - 2023-09-22 05:42:06 --> Model Class Initialized
DEBUG - 2023-09-22 05:42:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 05:42:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:42:06 --> Model Class Initialized
DEBUG - 2023-09-22 05:42:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 05:42:06 --> Model Class Initialized
INFO - 2023-09-22 05:42:07 --> Final output sent to browser
DEBUG - 2023-09-22 05:42:07 --> Total execution time: 0.3686
ERROR - 2023-09-22 09:17:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 09:17:21 --> Config Class Initialized
INFO - 2023-09-22 09:17:21 --> Hooks Class Initialized
DEBUG - 2023-09-22 09:17:21 --> UTF-8 Support Enabled
INFO - 2023-09-22 09:17:21 --> Utf8 Class Initialized
INFO - 2023-09-22 09:17:21 --> URI Class Initialized
DEBUG - 2023-09-22 09:17:21 --> No URI present. Default controller set.
INFO - 2023-09-22 09:17:21 --> Router Class Initialized
INFO - 2023-09-22 09:17:21 --> Output Class Initialized
INFO - 2023-09-22 09:17:21 --> Security Class Initialized
DEBUG - 2023-09-22 09:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 09:17:21 --> Input Class Initialized
INFO - 2023-09-22 09:17:21 --> Language Class Initialized
INFO - 2023-09-22 09:17:21 --> Loader Class Initialized
INFO - 2023-09-22 09:17:21 --> Helper loaded: url_helper
INFO - 2023-09-22 09:17:21 --> Helper loaded: file_helper
INFO - 2023-09-22 09:17:21 --> Helper loaded: html_helper
INFO - 2023-09-22 09:17:21 --> Helper loaded: text_helper
INFO - 2023-09-22 09:17:21 --> Helper loaded: form_helper
INFO - 2023-09-22 09:17:21 --> Helper loaded: lang_helper
INFO - 2023-09-22 09:17:21 --> Helper loaded: security_helper
INFO - 2023-09-22 09:17:21 --> Helper loaded: cookie_helper
INFO - 2023-09-22 09:17:21 --> Database Driver Class Initialized
INFO - 2023-09-22 09:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 09:17:21 --> Parser Class Initialized
INFO - 2023-09-22 09:17:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 09:17:21 --> Pagination Class Initialized
INFO - 2023-09-22 09:17:21 --> Form Validation Class Initialized
INFO - 2023-09-22 09:17:21 --> Controller Class Initialized
INFO - 2023-09-22 09:17:21 --> Model Class Initialized
DEBUG - 2023-09-22 09:17:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-22 15:56:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 15:56:53 --> Config Class Initialized
INFO - 2023-09-22 15:56:53 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:56:53 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:56:53 --> Utf8 Class Initialized
INFO - 2023-09-22 15:56:53 --> URI Class Initialized
INFO - 2023-09-22 15:56:53 --> Router Class Initialized
INFO - 2023-09-22 15:56:53 --> Output Class Initialized
INFO - 2023-09-22 15:56:53 --> Security Class Initialized
DEBUG - 2023-09-22 15:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:56:53 --> Input Class Initialized
INFO - 2023-09-22 15:56:53 --> Language Class Initialized
INFO - 2023-09-22 15:56:53 --> Loader Class Initialized
INFO - 2023-09-22 15:56:53 --> Helper loaded: url_helper
INFO - 2023-09-22 15:56:53 --> Helper loaded: file_helper
INFO - 2023-09-22 15:56:53 --> Helper loaded: html_helper
INFO - 2023-09-22 15:56:53 --> Helper loaded: text_helper
INFO - 2023-09-22 15:56:53 --> Helper loaded: form_helper
INFO - 2023-09-22 15:56:53 --> Helper loaded: lang_helper
INFO - 2023-09-22 15:56:53 --> Helper loaded: security_helper
INFO - 2023-09-22 15:56:53 --> Helper loaded: cookie_helper
INFO - 2023-09-22 15:56:53 --> Database Driver Class Initialized
INFO - 2023-09-22 15:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:56:53 --> Parser Class Initialized
INFO - 2023-09-22 15:56:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 15:56:53 --> Pagination Class Initialized
INFO - 2023-09-22 15:56:53 --> Form Validation Class Initialized
INFO - 2023-09-22 15:56:53 --> Controller Class Initialized
ERROR - 2023-09-22 15:56:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 15:56:54 --> Config Class Initialized
INFO - 2023-09-22 15:56:54 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:56:54 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:56:54 --> Utf8 Class Initialized
INFO - 2023-09-22 15:56:54 --> URI Class Initialized
INFO - 2023-09-22 15:56:54 --> Router Class Initialized
INFO - 2023-09-22 15:56:54 --> Output Class Initialized
INFO - 2023-09-22 15:56:54 --> Security Class Initialized
DEBUG - 2023-09-22 15:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:56:54 --> Input Class Initialized
INFO - 2023-09-22 15:56:54 --> Language Class Initialized
INFO - 2023-09-22 15:56:54 --> Loader Class Initialized
INFO - 2023-09-22 15:56:54 --> Helper loaded: url_helper
INFO - 2023-09-22 15:56:54 --> Helper loaded: file_helper
INFO - 2023-09-22 15:56:54 --> Helper loaded: html_helper
INFO - 2023-09-22 15:56:54 --> Helper loaded: text_helper
INFO - 2023-09-22 15:56:54 --> Helper loaded: form_helper
INFO - 2023-09-22 15:56:54 --> Helper loaded: lang_helper
INFO - 2023-09-22 15:56:54 --> Helper loaded: security_helper
INFO - 2023-09-22 15:56:54 --> Helper loaded: cookie_helper
INFO - 2023-09-22 15:56:54 --> Database Driver Class Initialized
INFO - 2023-09-22 15:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:56:54 --> Parser Class Initialized
INFO - 2023-09-22 15:56:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 15:56:54 --> Pagination Class Initialized
INFO - 2023-09-22 15:56:54 --> Form Validation Class Initialized
INFO - 2023-09-22 15:56:54 --> Controller Class Initialized
INFO - 2023-09-22 15:56:54 --> Model Class Initialized
DEBUG - 2023-09-22 15:56:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 15:56:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-22 15:56:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-22 15:56:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-22 15:56:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-22 15:56:54 --> Model Class Initialized
INFO - 2023-09-22 15:56:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-22 15:56:54 --> Final output sent to browser
DEBUG - 2023-09-22 15:56:54 --> Total execution time: 0.0346
ERROR - 2023-09-22 15:56:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 15:56:59 --> Config Class Initialized
INFO - 2023-09-22 15:56:59 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:56:59 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:56:59 --> Utf8 Class Initialized
INFO - 2023-09-22 15:56:59 --> URI Class Initialized
INFO - 2023-09-22 15:56:59 --> Router Class Initialized
INFO - 2023-09-22 15:56:59 --> Output Class Initialized
INFO - 2023-09-22 15:56:59 --> Security Class Initialized
DEBUG - 2023-09-22 15:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:56:59 --> Input Class Initialized
INFO - 2023-09-22 15:56:59 --> Language Class Initialized
INFO - 2023-09-22 15:56:59 --> Loader Class Initialized
INFO - 2023-09-22 15:56:59 --> Helper loaded: url_helper
INFO - 2023-09-22 15:56:59 --> Helper loaded: file_helper
INFO - 2023-09-22 15:56:59 --> Helper loaded: html_helper
INFO - 2023-09-22 15:56:59 --> Helper loaded: text_helper
INFO - 2023-09-22 15:56:59 --> Helper loaded: form_helper
INFO - 2023-09-22 15:56:59 --> Helper loaded: lang_helper
INFO - 2023-09-22 15:56:59 --> Helper loaded: security_helper
INFO - 2023-09-22 15:56:59 --> Helper loaded: cookie_helper
INFO - 2023-09-22 15:56:59 --> Database Driver Class Initialized
INFO - 2023-09-22 15:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:56:59 --> Parser Class Initialized
INFO - 2023-09-22 15:56:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 15:56:59 --> Pagination Class Initialized
INFO - 2023-09-22 15:56:59 --> Form Validation Class Initialized
INFO - 2023-09-22 15:56:59 --> Controller Class Initialized
INFO - 2023-09-22 15:56:59 --> Model Class Initialized
DEBUG - 2023-09-22 15:56:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 15:56:59 --> Model Class Initialized
INFO - 2023-09-22 15:56:59 --> Final output sent to browser
DEBUG - 2023-09-22 15:56:59 --> Total execution time: 0.0200
ERROR - 2023-09-22 15:57:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 15:57:00 --> Config Class Initialized
INFO - 2023-09-22 15:57:00 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:57:00 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:57:00 --> Utf8 Class Initialized
INFO - 2023-09-22 15:57:00 --> URI Class Initialized
DEBUG - 2023-09-22 15:57:00 --> No URI present. Default controller set.
INFO - 2023-09-22 15:57:00 --> Router Class Initialized
INFO - 2023-09-22 15:57:00 --> Output Class Initialized
INFO - 2023-09-22 15:57:00 --> Security Class Initialized
DEBUG - 2023-09-22 15:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:57:00 --> Input Class Initialized
INFO - 2023-09-22 15:57:00 --> Language Class Initialized
INFO - 2023-09-22 15:57:00 --> Loader Class Initialized
INFO - 2023-09-22 15:57:00 --> Helper loaded: url_helper
INFO - 2023-09-22 15:57:00 --> Helper loaded: file_helper
INFO - 2023-09-22 15:57:00 --> Helper loaded: html_helper
INFO - 2023-09-22 15:57:00 --> Helper loaded: text_helper
INFO - 2023-09-22 15:57:00 --> Helper loaded: form_helper
INFO - 2023-09-22 15:57:00 --> Helper loaded: lang_helper
INFO - 2023-09-22 15:57:00 --> Helper loaded: security_helper
INFO - 2023-09-22 15:57:00 --> Helper loaded: cookie_helper
INFO - 2023-09-22 15:57:00 --> Database Driver Class Initialized
INFO - 2023-09-22 15:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:57:00 --> Parser Class Initialized
INFO - 2023-09-22 15:57:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 15:57:00 --> Pagination Class Initialized
INFO - 2023-09-22 15:57:00 --> Form Validation Class Initialized
INFO - 2023-09-22 15:57:00 --> Controller Class Initialized
INFO - 2023-09-22 15:57:00 --> Model Class Initialized
DEBUG - 2023-09-22 15:57:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 15:57:00 --> Model Class Initialized
DEBUG - 2023-09-22 15:57:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 15:57:00 --> Model Class Initialized
INFO - 2023-09-22 15:57:00 --> Model Class Initialized
INFO - 2023-09-22 15:57:00 --> Model Class Initialized
INFO - 2023-09-22 15:57:00 --> Model Class Initialized
DEBUG - 2023-09-22 15:57:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 15:57:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 15:57:00 --> Model Class Initialized
INFO - 2023-09-22 15:57:00 --> Model Class Initialized
INFO - 2023-09-22 15:57:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-22 15:57:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-22 15:57:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-22 15:57:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-22 15:57:00 --> Model Class Initialized
INFO - 2023-09-22 15:57:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-22 15:57:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-22 15:57:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-22 15:57:00 --> Final output sent to browser
DEBUG - 2023-09-22 15:57:00 --> Total execution time: 0.2177
ERROR - 2023-09-22 15:57:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 15:57:01 --> Config Class Initialized
INFO - 2023-09-22 15:57:01 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:57:01 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:57:01 --> Utf8 Class Initialized
INFO - 2023-09-22 15:57:01 --> URI Class Initialized
INFO - 2023-09-22 15:57:01 --> Router Class Initialized
INFO - 2023-09-22 15:57:01 --> Output Class Initialized
INFO - 2023-09-22 15:57:01 --> Security Class Initialized
DEBUG - 2023-09-22 15:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:57:01 --> Input Class Initialized
INFO - 2023-09-22 15:57:01 --> Language Class Initialized
INFO - 2023-09-22 15:57:01 --> Loader Class Initialized
INFO - 2023-09-22 15:57:01 --> Helper loaded: url_helper
INFO - 2023-09-22 15:57:01 --> Helper loaded: file_helper
INFO - 2023-09-22 15:57:01 --> Helper loaded: html_helper
INFO - 2023-09-22 15:57:01 --> Helper loaded: text_helper
INFO - 2023-09-22 15:57:01 --> Helper loaded: form_helper
INFO - 2023-09-22 15:57:01 --> Helper loaded: lang_helper
INFO - 2023-09-22 15:57:01 --> Helper loaded: security_helper
INFO - 2023-09-22 15:57:01 --> Helper loaded: cookie_helper
INFO - 2023-09-22 15:57:01 --> Database Driver Class Initialized
INFO - 2023-09-22 15:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:57:01 --> Parser Class Initialized
INFO - 2023-09-22 15:57:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 15:57:01 --> Pagination Class Initialized
INFO - 2023-09-22 15:57:01 --> Form Validation Class Initialized
INFO - 2023-09-22 15:57:01 --> Controller Class Initialized
DEBUG - 2023-09-22 15:57:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 15:57:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 15:57:01 --> Model Class Initialized
INFO - 2023-09-22 15:57:01 --> Final output sent to browser
DEBUG - 2023-09-22 15:57:01 --> Total execution time: 0.0138
ERROR - 2023-09-22 15:57:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 15:57:49 --> Config Class Initialized
INFO - 2023-09-22 15:57:49 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:57:49 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:57:49 --> Utf8 Class Initialized
INFO - 2023-09-22 15:57:49 --> URI Class Initialized
DEBUG - 2023-09-22 15:57:49 --> No URI present. Default controller set.
INFO - 2023-09-22 15:57:49 --> Router Class Initialized
INFO - 2023-09-22 15:57:49 --> Output Class Initialized
INFO - 2023-09-22 15:57:49 --> Security Class Initialized
DEBUG - 2023-09-22 15:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:57:49 --> Input Class Initialized
INFO - 2023-09-22 15:57:49 --> Language Class Initialized
INFO - 2023-09-22 15:57:49 --> Loader Class Initialized
INFO - 2023-09-22 15:57:49 --> Helper loaded: url_helper
INFO - 2023-09-22 15:57:49 --> Helper loaded: file_helper
INFO - 2023-09-22 15:57:49 --> Helper loaded: html_helper
INFO - 2023-09-22 15:57:49 --> Helper loaded: text_helper
INFO - 2023-09-22 15:57:49 --> Helper loaded: form_helper
INFO - 2023-09-22 15:57:49 --> Helper loaded: lang_helper
INFO - 2023-09-22 15:57:49 --> Helper loaded: security_helper
INFO - 2023-09-22 15:57:49 --> Helper loaded: cookie_helper
INFO - 2023-09-22 15:57:49 --> Database Driver Class Initialized
INFO - 2023-09-22 15:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:57:49 --> Parser Class Initialized
INFO - 2023-09-22 15:57:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 15:57:49 --> Pagination Class Initialized
INFO - 2023-09-22 15:57:49 --> Form Validation Class Initialized
INFO - 2023-09-22 15:57:49 --> Controller Class Initialized
INFO - 2023-09-22 15:57:49 --> Model Class Initialized
DEBUG - 2023-09-22 15:57:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-22 15:57:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 15:57:50 --> Config Class Initialized
INFO - 2023-09-22 15:57:50 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:57:50 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:57:50 --> Utf8 Class Initialized
INFO - 2023-09-22 15:57:50 --> URI Class Initialized
INFO - 2023-09-22 15:57:50 --> Router Class Initialized
INFO - 2023-09-22 15:57:50 --> Output Class Initialized
INFO - 2023-09-22 15:57:50 --> Security Class Initialized
DEBUG - 2023-09-22 15:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:57:50 --> Input Class Initialized
INFO - 2023-09-22 15:57:50 --> Language Class Initialized
INFO - 2023-09-22 15:57:50 --> Loader Class Initialized
INFO - 2023-09-22 15:57:50 --> Helper loaded: url_helper
INFO - 2023-09-22 15:57:50 --> Helper loaded: file_helper
INFO - 2023-09-22 15:57:50 --> Helper loaded: html_helper
INFO - 2023-09-22 15:57:50 --> Helper loaded: text_helper
INFO - 2023-09-22 15:57:50 --> Helper loaded: form_helper
INFO - 2023-09-22 15:57:50 --> Helper loaded: lang_helper
INFO - 2023-09-22 15:57:50 --> Helper loaded: security_helper
INFO - 2023-09-22 15:57:50 --> Helper loaded: cookie_helper
INFO - 2023-09-22 15:57:50 --> Database Driver Class Initialized
INFO - 2023-09-22 15:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:57:50 --> Parser Class Initialized
INFO - 2023-09-22 15:57:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 15:57:50 --> Pagination Class Initialized
INFO - 2023-09-22 15:57:50 --> Form Validation Class Initialized
INFO - 2023-09-22 15:57:50 --> Controller Class Initialized
INFO - 2023-09-22 15:57:50 --> Model Class Initialized
DEBUG - 2023-09-22 15:57:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 15:57:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-22 15:57:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-22 15:57:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-22 15:57:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-22 15:57:50 --> Model Class Initialized
INFO - 2023-09-22 15:57:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-22 15:57:50 --> Final output sent to browser
DEBUG - 2023-09-22 15:57:50 --> Total execution time: 0.0298
ERROR - 2023-09-22 15:57:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 15:57:54 --> Config Class Initialized
INFO - 2023-09-22 15:57:54 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:57:54 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:57:54 --> Utf8 Class Initialized
INFO - 2023-09-22 15:57:54 --> URI Class Initialized
DEBUG - 2023-09-22 15:57:54 --> No URI present. Default controller set.
INFO - 2023-09-22 15:57:54 --> Router Class Initialized
INFO - 2023-09-22 15:57:54 --> Output Class Initialized
INFO - 2023-09-22 15:57:54 --> Security Class Initialized
DEBUG - 2023-09-22 15:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:57:54 --> Input Class Initialized
INFO - 2023-09-22 15:57:54 --> Language Class Initialized
INFO - 2023-09-22 15:57:54 --> Loader Class Initialized
INFO - 2023-09-22 15:57:54 --> Helper loaded: url_helper
INFO - 2023-09-22 15:57:54 --> Helper loaded: file_helper
INFO - 2023-09-22 15:57:54 --> Helper loaded: html_helper
INFO - 2023-09-22 15:57:54 --> Helper loaded: text_helper
INFO - 2023-09-22 15:57:54 --> Helper loaded: form_helper
INFO - 2023-09-22 15:57:54 --> Helper loaded: lang_helper
INFO - 2023-09-22 15:57:54 --> Helper loaded: security_helper
INFO - 2023-09-22 15:57:54 --> Helper loaded: cookie_helper
INFO - 2023-09-22 15:57:54 --> Database Driver Class Initialized
INFO - 2023-09-22 15:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:57:54 --> Parser Class Initialized
INFO - 2023-09-22 15:57:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 15:57:54 --> Pagination Class Initialized
INFO - 2023-09-22 15:57:54 --> Form Validation Class Initialized
INFO - 2023-09-22 15:57:54 --> Controller Class Initialized
INFO - 2023-09-22 15:57:54 --> Model Class Initialized
DEBUG - 2023-09-22 15:57:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-22 15:57:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 15:57:55 --> Config Class Initialized
INFO - 2023-09-22 15:57:55 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:57:55 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:57:55 --> Utf8 Class Initialized
INFO - 2023-09-22 15:57:55 --> URI Class Initialized
INFO - 2023-09-22 15:57:55 --> Router Class Initialized
INFO - 2023-09-22 15:57:55 --> Output Class Initialized
INFO - 2023-09-22 15:57:55 --> Security Class Initialized
DEBUG - 2023-09-22 15:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:57:55 --> Input Class Initialized
INFO - 2023-09-22 15:57:55 --> Language Class Initialized
INFO - 2023-09-22 15:57:55 --> Loader Class Initialized
INFO - 2023-09-22 15:57:55 --> Helper loaded: url_helper
INFO - 2023-09-22 15:57:55 --> Helper loaded: file_helper
INFO - 2023-09-22 15:57:55 --> Helper loaded: html_helper
INFO - 2023-09-22 15:57:55 --> Helper loaded: text_helper
INFO - 2023-09-22 15:57:55 --> Helper loaded: form_helper
INFO - 2023-09-22 15:57:55 --> Helper loaded: lang_helper
INFO - 2023-09-22 15:57:55 --> Helper loaded: security_helper
INFO - 2023-09-22 15:57:55 --> Helper loaded: cookie_helper
INFO - 2023-09-22 15:57:55 --> Database Driver Class Initialized
INFO - 2023-09-22 15:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:57:55 --> Parser Class Initialized
INFO - 2023-09-22 15:57:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 15:57:55 --> Pagination Class Initialized
INFO - 2023-09-22 15:57:55 --> Form Validation Class Initialized
INFO - 2023-09-22 15:57:55 --> Controller Class Initialized
INFO - 2023-09-22 15:57:55 --> Model Class Initialized
DEBUG - 2023-09-22 15:57:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 15:57:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-22 15:57:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-22 15:57:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-22 15:57:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-22 15:57:55 --> Model Class Initialized
INFO - 2023-09-22 15:57:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-22 15:57:55 --> Final output sent to browser
DEBUG - 2023-09-22 15:57:55 --> Total execution time: 0.0292
ERROR - 2023-09-22 15:58:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 15:58:22 --> Config Class Initialized
INFO - 2023-09-22 15:58:22 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:58:22 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:58:22 --> Utf8 Class Initialized
INFO - 2023-09-22 15:58:22 --> URI Class Initialized
INFO - 2023-09-22 15:58:22 --> Router Class Initialized
INFO - 2023-09-22 15:58:22 --> Output Class Initialized
INFO - 2023-09-22 15:58:22 --> Security Class Initialized
DEBUG - 2023-09-22 15:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:58:22 --> Input Class Initialized
INFO - 2023-09-22 15:58:22 --> Language Class Initialized
INFO - 2023-09-22 15:58:22 --> Loader Class Initialized
INFO - 2023-09-22 15:58:22 --> Helper loaded: url_helper
INFO - 2023-09-22 15:58:22 --> Helper loaded: file_helper
INFO - 2023-09-22 15:58:22 --> Helper loaded: html_helper
INFO - 2023-09-22 15:58:22 --> Helper loaded: text_helper
INFO - 2023-09-22 15:58:22 --> Helper loaded: form_helper
INFO - 2023-09-22 15:58:22 --> Helper loaded: lang_helper
INFO - 2023-09-22 15:58:22 --> Helper loaded: security_helper
INFO - 2023-09-22 15:58:22 --> Helper loaded: cookie_helper
INFO - 2023-09-22 15:58:22 --> Database Driver Class Initialized
INFO - 2023-09-22 15:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:58:22 --> Parser Class Initialized
INFO - 2023-09-22 15:58:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 15:58:22 --> Pagination Class Initialized
INFO - 2023-09-22 15:58:22 --> Form Validation Class Initialized
INFO - 2023-09-22 15:58:22 --> Controller Class Initialized
INFO - 2023-09-22 15:58:22 --> Model Class Initialized
DEBUG - 2023-09-22 15:58:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 15:58:22 --> Model Class Initialized
INFO - 2023-09-22 15:58:22 --> Final output sent to browser
DEBUG - 2023-09-22 15:58:22 --> Total execution time: 0.0205
ERROR - 2023-09-22 15:58:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 15:58:22 --> Config Class Initialized
INFO - 2023-09-22 15:58:22 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:58:22 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:58:22 --> Utf8 Class Initialized
INFO - 2023-09-22 15:58:22 --> URI Class Initialized
DEBUG - 2023-09-22 15:58:22 --> No URI present. Default controller set.
INFO - 2023-09-22 15:58:22 --> Router Class Initialized
INFO - 2023-09-22 15:58:22 --> Output Class Initialized
INFO - 2023-09-22 15:58:22 --> Security Class Initialized
DEBUG - 2023-09-22 15:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:58:22 --> Input Class Initialized
INFO - 2023-09-22 15:58:22 --> Language Class Initialized
INFO - 2023-09-22 15:58:22 --> Loader Class Initialized
INFO - 2023-09-22 15:58:22 --> Helper loaded: url_helper
INFO - 2023-09-22 15:58:22 --> Helper loaded: file_helper
INFO - 2023-09-22 15:58:22 --> Helper loaded: html_helper
INFO - 2023-09-22 15:58:22 --> Helper loaded: text_helper
INFO - 2023-09-22 15:58:22 --> Helper loaded: form_helper
INFO - 2023-09-22 15:58:22 --> Helper loaded: lang_helper
INFO - 2023-09-22 15:58:22 --> Helper loaded: security_helper
INFO - 2023-09-22 15:58:22 --> Helper loaded: cookie_helper
INFO - 2023-09-22 15:58:22 --> Database Driver Class Initialized
INFO - 2023-09-22 15:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:58:22 --> Parser Class Initialized
INFO - 2023-09-22 15:58:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 15:58:22 --> Pagination Class Initialized
INFO - 2023-09-22 15:58:22 --> Form Validation Class Initialized
INFO - 2023-09-22 15:58:22 --> Controller Class Initialized
INFO - 2023-09-22 15:58:22 --> Model Class Initialized
DEBUG - 2023-09-22 15:58:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 15:58:22 --> Model Class Initialized
DEBUG - 2023-09-22 15:58:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 15:58:22 --> Model Class Initialized
INFO - 2023-09-22 15:58:22 --> Model Class Initialized
INFO - 2023-09-22 15:58:22 --> Model Class Initialized
INFO - 2023-09-22 15:58:22 --> Model Class Initialized
DEBUG - 2023-09-22 15:58:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 15:58:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 15:58:22 --> Model Class Initialized
INFO - 2023-09-22 15:58:22 --> Model Class Initialized
INFO - 2023-09-22 15:58:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-22 15:58:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-22 15:58:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-22 15:58:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-22 15:58:22 --> Model Class Initialized
INFO - 2023-09-22 15:58:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-22 15:58:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-22 15:58:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-22 15:58:22 --> Final output sent to browser
DEBUG - 2023-09-22 15:58:22 --> Total execution time: 0.1166
ERROR - 2023-09-22 15:58:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 15:58:28 --> Config Class Initialized
INFO - 2023-09-22 15:58:28 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:58:28 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:58:28 --> Utf8 Class Initialized
INFO - 2023-09-22 15:58:28 --> URI Class Initialized
INFO - 2023-09-22 15:58:28 --> Router Class Initialized
INFO - 2023-09-22 15:58:28 --> Output Class Initialized
INFO - 2023-09-22 15:58:28 --> Security Class Initialized
DEBUG - 2023-09-22 15:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:58:28 --> Input Class Initialized
INFO - 2023-09-22 15:58:28 --> Language Class Initialized
INFO - 2023-09-22 15:58:28 --> Loader Class Initialized
INFO - 2023-09-22 15:58:28 --> Helper loaded: url_helper
INFO - 2023-09-22 15:58:28 --> Helper loaded: file_helper
INFO - 2023-09-22 15:58:28 --> Helper loaded: html_helper
INFO - 2023-09-22 15:58:28 --> Helper loaded: text_helper
INFO - 2023-09-22 15:58:28 --> Helper loaded: form_helper
INFO - 2023-09-22 15:58:28 --> Helper loaded: lang_helper
INFO - 2023-09-22 15:58:28 --> Helper loaded: security_helper
INFO - 2023-09-22 15:58:28 --> Helper loaded: cookie_helper
INFO - 2023-09-22 15:58:28 --> Database Driver Class Initialized
INFO - 2023-09-22 15:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:58:28 --> Parser Class Initialized
INFO - 2023-09-22 15:58:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 15:58:28 --> Pagination Class Initialized
INFO - 2023-09-22 15:58:28 --> Form Validation Class Initialized
INFO - 2023-09-22 15:58:28 --> Controller Class Initialized
INFO - 2023-09-22 15:58:28 --> Model Class Initialized
DEBUG - 2023-09-22 15:58:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 15:58:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 15:58:28 --> Model Class Initialized
DEBUG - 2023-09-22 15:58:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 15:58:28 --> Model Class Initialized
INFO - 2023-09-22 15:58:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-22 15:58:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-22 15:58:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-22 15:58:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-22 15:58:28 --> Model Class Initialized
INFO - 2023-09-22 15:58:28 --> Model Class Initialized
INFO - 2023-09-22 15:58:28 --> Model Class Initialized
INFO - 2023-09-22 15:58:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-22 15:58:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-22 15:58:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-22 15:58:28 --> Final output sent to browser
DEBUG - 2023-09-22 15:58:28 --> Total execution time: 0.0897
ERROR - 2023-09-22 15:58:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 15:58:28 --> Config Class Initialized
INFO - 2023-09-22 15:58:28 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:58:28 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:58:28 --> Utf8 Class Initialized
INFO - 2023-09-22 15:58:28 --> URI Class Initialized
INFO - 2023-09-22 15:58:28 --> Router Class Initialized
INFO - 2023-09-22 15:58:28 --> Output Class Initialized
INFO - 2023-09-22 15:58:28 --> Security Class Initialized
DEBUG - 2023-09-22 15:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:58:28 --> Input Class Initialized
INFO - 2023-09-22 15:58:28 --> Language Class Initialized
INFO - 2023-09-22 15:58:28 --> Loader Class Initialized
INFO - 2023-09-22 15:58:28 --> Helper loaded: url_helper
INFO - 2023-09-22 15:58:28 --> Helper loaded: file_helper
INFO - 2023-09-22 15:58:28 --> Helper loaded: html_helper
INFO - 2023-09-22 15:58:28 --> Helper loaded: text_helper
INFO - 2023-09-22 15:58:28 --> Helper loaded: form_helper
INFO - 2023-09-22 15:58:28 --> Helper loaded: lang_helper
INFO - 2023-09-22 15:58:28 --> Helper loaded: security_helper
INFO - 2023-09-22 15:58:28 --> Helper loaded: cookie_helper
INFO - 2023-09-22 15:58:28 --> Database Driver Class Initialized
INFO - 2023-09-22 15:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:58:28 --> Parser Class Initialized
INFO - 2023-09-22 15:58:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 15:58:28 --> Pagination Class Initialized
INFO - 2023-09-22 15:58:28 --> Form Validation Class Initialized
INFO - 2023-09-22 15:58:28 --> Controller Class Initialized
INFO - 2023-09-22 15:58:28 --> Model Class Initialized
DEBUG - 2023-09-22 15:58:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 15:58:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 15:58:28 --> Model Class Initialized
DEBUG - 2023-09-22 15:58:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 15:58:28 --> Model Class Initialized
INFO - 2023-09-22 15:58:28 --> Final output sent to browser
DEBUG - 2023-09-22 15:58:28 --> Total execution time: 0.0403
ERROR - 2023-09-22 15:58:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 15:58:32 --> Config Class Initialized
INFO - 2023-09-22 15:58:32 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:58:32 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:58:32 --> Utf8 Class Initialized
INFO - 2023-09-22 15:58:32 --> URI Class Initialized
INFO - 2023-09-22 15:58:32 --> Router Class Initialized
INFO - 2023-09-22 15:58:32 --> Output Class Initialized
INFO - 2023-09-22 15:58:32 --> Security Class Initialized
DEBUG - 2023-09-22 15:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:58:32 --> Input Class Initialized
INFO - 2023-09-22 15:58:32 --> Language Class Initialized
INFO - 2023-09-22 15:58:32 --> Loader Class Initialized
INFO - 2023-09-22 15:58:32 --> Helper loaded: url_helper
INFO - 2023-09-22 15:58:32 --> Helper loaded: file_helper
INFO - 2023-09-22 15:58:32 --> Helper loaded: html_helper
INFO - 2023-09-22 15:58:32 --> Helper loaded: text_helper
INFO - 2023-09-22 15:58:32 --> Helper loaded: form_helper
INFO - 2023-09-22 15:58:32 --> Helper loaded: lang_helper
INFO - 2023-09-22 15:58:32 --> Helper loaded: security_helper
INFO - 2023-09-22 15:58:32 --> Helper loaded: cookie_helper
INFO - 2023-09-22 15:58:32 --> Database Driver Class Initialized
INFO - 2023-09-22 15:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:58:32 --> Parser Class Initialized
INFO - 2023-09-22 15:58:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 15:58:32 --> Pagination Class Initialized
INFO - 2023-09-22 15:58:32 --> Form Validation Class Initialized
INFO - 2023-09-22 15:58:32 --> Controller Class Initialized
INFO - 2023-09-22 15:58:32 --> Model Class Initialized
DEBUG - 2023-09-22 15:58:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 15:58:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 15:58:32 --> Model Class Initialized
DEBUG - 2023-09-22 15:58:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 15:58:32 --> Model Class Initialized
DEBUG - 2023-09-22 15:58:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 15:58:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-09-22 15:58:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-22 15:58:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-22 15:58:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-22 15:58:32 --> Model Class Initialized
INFO - 2023-09-22 15:58:32 --> Model Class Initialized
INFO - 2023-09-22 15:58:32 --> Model Class Initialized
INFO - 2023-09-22 15:58:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-22 15:58:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-22 15:58:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-22 15:58:32 --> Final output sent to browser
DEBUG - 2023-09-22 15:58:32 --> Total execution time: 0.0983
ERROR - 2023-09-22 15:59:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 15:59:42 --> Config Class Initialized
INFO - 2023-09-22 15:59:42 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:59:42 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:59:42 --> Utf8 Class Initialized
INFO - 2023-09-22 15:59:42 --> URI Class Initialized
INFO - 2023-09-22 15:59:42 --> Router Class Initialized
INFO - 2023-09-22 15:59:42 --> Output Class Initialized
INFO - 2023-09-22 15:59:42 --> Security Class Initialized
DEBUG - 2023-09-22 15:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:59:42 --> Input Class Initialized
INFO - 2023-09-22 15:59:42 --> Language Class Initialized
INFO - 2023-09-22 15:59:42 --> Loader Class Initialized
INFO - 2023-09-22 15:59:42 --> Helper loaded: url_helper
INFO - 2023-09-22 15:59:42 --> Helper loaded: file_helper
INFO - 2023-09-22 15:59:42 --> Helper loaded: html_helper
INFO - 2023-09-22 15:59:42 --> Helper loaded: text_helper
INFO - 2023-09-22 15:59:42 --> Helper loaded: form_helper
INFO - 2023-09-22 15:59:42 --> Helper loaded: lang_helper
INFO - 2023-09-22 15:59:42 --> Helper loaded: security_helper
INFO - 2023-09-22 15:59:42 --> Helper loaded: cookie_helper
INFO - 2023-09-22 15:59:42 --> Database Driver Class Initialized
INFO - 2023-09-22 15:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:59:42 --> Parser Class Initialized
INFO - 2023-09-22 15:59:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 15:59:42 --> Pagination Class Initialized
INFO - 2023-09-22 15:59:42 --> Form Validation Class Initialized
INFO - 2023-09-22 15:59:42 --> Controller Class Initialized
INFO - 2023-09-22 15:59:42 --> Model Class Initialized
DEBUG - 2023-09-22 15:59:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 15:59:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 15:59:42 --> Model Class Initialized
DEBUG - 2023-09-22 15:59:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 15:59:42 --> Model Class Initialized
INFO - 2023-09-22 15:59:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-22 15:59:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-22 15:59:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-22 15:59:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-22 15:59:42 --> Model Class Initialized
INFO - 2023-09-22 15:59:42 --> Model Class Initialized
INFO - 2023-09-22 15:59:42 --> Model Class Initialized
INFO - 2023-09-22 15:59:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-22 15:59:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-22 15:59:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-22 15:59:43 --> Final output sent to browser
DEBUG - 2023-09-22 15:59:43 --> Total execution time: 0.0887
ERROR - 2023-09-22 15:59:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 15:59:43 --> Config Class Initialized
INFO - 2023-09-22 15:59:43 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:59:43 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:59:43 --> Utf8 Class Initialized
INFO - 2023-09-22 15:59:43 --> URI Class Initialized
INFO - 2023-09-22 15:59:43 --> Router Class Initialized
INFO - 2023-09-22 15:59:43 --> Output Class Initialized
INFO - 2023-09-22 15:59:43 --> Security Class Initialized
DEBUG - 2023-09-22 15:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:59:43 --> Input Class Initialized
INFO - 2023-09-22 15:59:43 --> Language Class Initialized
INFO - 2023-09-22 15:59:43 --> Loader Class Initialized
INFO - 2023-09-22 15:59:43 --> Helper loaded: url_helper
INFO - 2023-09-22 15:59:43 --> Helper loaded: file_helper
INFO - 2023-09-22 15:59:43 --> Helper loaded: html_helper
INFO - 2023-09-22 15:59:43 --> Helper loaded: text_helper
INFO - 2023-09-22 15:59:43 --> Helper loaded: form_helper
INFO - 2023-09-22 15:59:43 --> Helper loaded: lang_helper
INFO - 2023-09-22 15:59:43 --> Helper loaded: security_helper
INFO - 2023-09-22 15:59:43 --> Helper loaded: cookie_helper
INFO - 2023-09-22 15:59:43 --> Database Driver Class Initialized
INFO - 2023-09-22 15:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:59:43 --> Parser Class Initialized
INFO - 2023-09-22 15:59:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 15:59:43 --> Pagination Class Initialized
INFO - 2023-09-22 15:59:43 --> Form Validation Class Initialized
INFO - 2023-09-22 15:59:43 --> Controller Class Initialized
INFO - 2023-09-22 15:59:43 --> Model Class Initialized
DEBUG - 2023-09-22 15:59:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 15:59:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 15:59:43 --> Model Class Initialized
DEBUG - 2023-09-22 15:59:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 15:59:43 --> Model Class Initialized
INFO - 2023-09-22 15:59:43 --> Final output sent to browser
DEBUG - 2023-09-22 15:59:43 --> Total execution time: 0.0464
ERROR - 2023-09-22 15:59:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 15:59:46 --> Config Class Initialized
INFO - 2023-09-22 15:59:46 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:59:46 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:59:46 --> Utf8 Class Initialized
INFO - 2023-09-22 15:59:46 --> URI Class Initialized
INFO - 2023-09-22 15:59:46 --> Router Class Initialized
INFO - 2023-09-22 15:59:46 --> Output Class Initialized
INFO - 2023-09-22 15:59:46 --> Security Class Initialized
DEBUG - 2023-09-22 15:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:59:46 --> Input Class Initialized
INFO - 2023-09-22 15:59:46 --> Language Class Initialized
INFO - 2023-09-22 15:59:46 --> Loader Class Initialized
INFO - 2023-09-22 15:59:46 --> Helper loaded: url_helper
INFO - 2023-09-22 15:59:46 --> Helper loaded: file_helper
INFO - 2023-09-22 15:59:46 --> Helper loaded: html_helper
INFO - 2023-09-22 15:59:46 --> Helper loaded: text_helper
INFO - 2023-09-22 15:59:46 --> Helper loaded: form_helper
INFO - 2023-09-22 15:59:46 --> Helper loaded: lang_helper
INFO - 2023-09-22 15:59:46 --> Helper loaded: security_helper
INFO - 2023-09-22 15:59:46 --> Helper loaded: cookie_helper
INFO - 2023-09-22 15:59:46 --> Database Driver Class Initialized
INFO - 2023-09-22 15:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:59:46 --> Parser Class Initialized
INFO - 2023-09-22 15:59:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 15:59:46 --> Pagination Class Initialized
INFO - 2023-09-22 15:59:46 --> Form Validation Class Initialized
INFO - 2023-09-22 15:59:46 --> Controller Class Initialized
INFO - 2023-09-22 15:59:46 --> Model Class Initialized
DEBUG - 2023-09-22 15:59:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 15:59:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 15:59:46 --> Model Class Initialized
DEBUG - 2023-09-22 15:59:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 15:59:46 --> Model Class Initialized
INFO - 2023-09-22 15:59:47 --> Final output sent to browser
DEBUG - 2023-09-22 15:59:47 --> Total execution time: 0.0423
ERROR - 2023-09-22 15:59:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 15:59:47 --> Config Class Initialized
INFO - 2023-09-22 15:59:47 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:59:47 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:59:47 --> Utf8 Class Initialized
INFO - 2023-09-22 15:59:47 --> URI Class Initialized
INFO - 2023-09-22 15:59:47 --> Router Class Initialized
INFO - 2023-09-22 15:59:47 --> Output Class Initialized
INFO - 2023-09-22 15:59:47 --> Security Class Initialized
DEBUG - 2023-09-22 15:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:59:47 --> Input Class Initialized
INFO - 2023-09-22 15:59:47 --> Language Class Initialized
INFO - 2023-09-22 15:59:47 --> Loader Class Initialized
INFO - 2023-09-22 15:59:47 --> Helper loaded: url_helper
INFO - 2023-09-22 15:59:47 --> Helper loaded: file_helper
INFO - 2023-09-22 15:59:47 --> Helper loaded: html_helper
INFO - 2023-09-22 15:59:47 --> Helper loaded: text_helper
INFO - 2023-09-22 15:59:47 --> Helper loaded: form_helper
INFO - 2023-09-22 15:59:47 --> Helper loaded: lang_helper
INFO - 2023-09-22 15:59:47 --> Helper loaded: security_helper
INFO - 2023-09-22 15:59:47 --> Helper loaded: cookie_helper
INFO - 2023-09-22 15:59:47 --> Database Driver Class Initialized
INFO - 2023-09-22 15:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:59:47 --> Parser Class Initialized
INFO - 2023-09-22 15:59:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 15:59:47 --> Pagination Class Initialized
INFO - 2023-09-22 15:59:47 --> Form Validation Class Initialized
INFO - 2023-09-22 15:59:47 --> Controller Class Initialized
INFO - 2023-09-22 15:59:47 --> Model Class Initialized
DEBUG - 2023-09-22 15:59:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 15:59:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 15:59:47 --> Model Class Initialized
DEBUG - 2023-09-22 15:59:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 15:59:47 --> Model Class Initialized
INFO - 2023-09-22 15:59:47 --> Final output sent to browser
DEBUG - 2023-09-22 15:59:47 --> Total execution time: 0.0430
ERROR - 2023-09-22 15:59:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 15:59:57 --> Config Class Initialized
INFO - 2023-09-22 15:59:57 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:59:57 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:59:57 --> Utf8 Class Initialized
INFO - 2023-09-22 15:59:57 --> URI Class Initialized
INFO - 2023-09-22 15:59:57 --> Router Class Initialized
INFO - 2023-09-22 15:59:57 --> Output Class Initialized
INFO - 2023-09-22 15:59:57 --> Security Class Initialized
DEBUG - 2023-09-22 15:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:59:57 --> Input Class Initialized
INFO - 2023-09-22 15:59:57 --> Language Class Initialized
INFO - 2023-09-22 15:59:57 --> Loader Class Initialized
INFO - 2023-09-22 15:59:57 --> Helper loaded: url_helper
INFO - 2023-09-22 15:59:57 --> Helper loaded: file_helper
INFO - 2023-09-22 15:59:57 --> Helper loaded: html_helper
INFO - 2023-09-22 15:59:57 --> Helper loaded: text_helper
INFO - 2023-09-22 15:59:57 --> Helper loaded: form_helper
INFO - 2023-09-22 15:59:57 --> Helper loaded: lang_helper
INFO - 2023-09-22 15:59:57 --> Helper loaded: security_helper
INFO - 2023-09-22 15:59:57 --> Helper loaded: cookie_helper
INFO - 2023-09-22 15:59:57 --> Database Driver Class Initialized
INFO - 2023-09-22 15:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:59:57 --> Parser Class Initialized
INFO - 2023-09-22 15:59:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 15:59:57 --> Pagination Class Initialized
INFO - 2023-09-22 15:59:57 --> Form Validation Class Initialized
INFO - 2023-09-22 15:59:57 --> Controller Class Initialized
INFO - 2023-09-22 15:59:57 --> Model Class Initialized
DEBUG - 2023-09-22 15:59:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 15:59:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 15:59:57 --> Model Class Initialized
DEBUG - 2023-09-22 15:59:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 15:59:57 --> Model Class Initialized
INFO - 2023-09-22 15:59:57 --> Final output sent to browser
DEBUG - 2023-09-22 15:59:57 --> Total execution time: 0.0302
ERROR - 2023-09-22 16:00:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 16:00:02 --> Config Class Initialized
INFO - 2023-09-22 16:00:02 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:00:02 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:00:02 --> Utf8 Class Initialized
INFO - 2023-09-22 16:00:02 --> URI Class Initialized
INFO - 2023-09-22 16:00:02 --> Router Class Initialized
INFO - 2023-09-22 16:00:02 --> Output Class Initialized
INFO - 2023-09-22 16:00:02 --> Security Class Initialized
DEBUG - 2023-09-22 16:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:00:02 --> Input Class Initialized
INFO - 2023-09-22 16:00:02 --> Language Class Initialized
INFO - 2023-09-22 16:00:02 --> Loader Class Initialized
INFO - 2023-09-22 16:00:02 --> Helper loaded: url_helper
INFO - 2023-09-22 16:00:02 --> Helper loaded: file_helper
INFO - 2023-09-22 16:00:02 --> Helper loaded: html_helper
INFO - 2023-09-22 16:00:02 --> Helper loaded: text_helper
INFO - 2023-09-22 16:00:02 --> Helper loaded: form_helper
INFO - 2023-09-22 16:00:02 --> Helper loaded: lang_helper
INFO - 2023-09-22 16:00:02 --> Helper loaded: security_helper
INFO - 2023-09-22 16:00:02 --> Helper loaded: cookie_helper
INFO - 2023-09-22 16:00:02 --> Database Driver Class Initialized
INFO - 2023-09-22 16:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:00:02 --> Parser Class Initialized
INFO - 2023-09-22 16:00:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 16:00:02 --> Pagination Class Initialized
INFO - 2023-09-22 16:00:02 --> Form Validation Class Initialized
INFO - 2023-09-22 16:00:02 --> Controller Class Initialized
INFO - 2023-09-22 16:00:02 --> Model Class Initialized
DEBUG - 2023-09-22 16:00:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 16:00:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:00:02 --> Model Class Initialized
DEBUG - 2023-09-22 16:00:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:00:02 --> Model Class Initialized
DEBUG - 2023-09-22 16:00:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:00:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-09-22 16:00:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:00:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-22 16:00:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-22 16:00:02 --> Model Class Initialized
INFO - 2023-09-22 16:00:02 --> Model Class Initialized
INFO - 2023-09-22 16:00:02 --> Model Class Initialized
INFO - 2023-09-22 16:00:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-22 16:00:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-22 16:00:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-22 16:00:02 --> Final output sent to browser
DEBUG - 2023-09-22 16:00:02 --> Total execution time: 0.1316
ERROR - 2023-09-22 16:01:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 16:01:25 --> Config Class Initialized
INFO - 2023-09-22 16:01:25 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:01:25 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:01:25 --> Utf8 Class Initialized
INFO - 2023-09-22 16:01:25 --> URI Class Initialized
INFO - 2023-09-22 16:01:25 --> Router Class Initialized
INFO - 2023-09-22 16:01:25 --> Output Class Initialized
INFO - 2023-09-22 16:01:25 --> Security Class Initialized
DEBUG - 2023-09-22 16:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:01:25 --> Input Class Initialized
INFO - 2023-09-22 16:01:25 --> Language Class Initialized
ERROR - 2023-09-22 16:01:25 --> 404 Page Not Found: Authorizephp/index
ERROR - 2023-09-22 16:01:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 16:01:27 --> Config Class Initialized
INFO - 2023-09-22 16:01:27 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:01:27 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:01:27 --> Utf8 Class Initialized
INFO - 2023-09-22 16:01:27 --> URI Class Initialized
INFO - 2023-09-22 16:01:27 --> Router Class Initialized
INFO - 2023-09-22 16:01:27 --> Output Class Initialized
INFO - 2023-09-22 16:01:27 --> Security Class Initialized
DEBUG - 2023-09-22 16:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:01:27 --> Input Class Initialized
INFO - 2023-09-22 16:01:27 --> Language Class Initialized
INFO - 2023-09-22 16:01:27 --> Loader Class Initialized
INFO - 2023-09-22 16:01:27 --> Helper loaded: url_helper
INFO - 2023-09-22 16:01:27 --> Helper loaded: file_helper
INFO - 2023-09-22 16:01:27 --> Helper loaded: html_helper
INFO - 2023-09-22 16:01:27 --> Helper loaded: text_helper
INFO - 2023-09-22 16:01:27 --> Helper loaded: form_helper
INFO - 2023-09-22 16:01:27 --> Helper loaded: lang_helper
INFO - 2023-09-22 16:01:27 --> Helper loaded: security_helper
INFO - 2023-09-22 16:01:27 --> Helper loaded: cookie_helper
INFO - 2023-09-22 16:01:27 --> Database Driver Class Initialized
INFO - 2023-09-22 16:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:01:27 --> Parser Class Initialized
INFO - 2023-09-22 16:01:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 16:01:27 --> Pagination Class Initialized
INFO - 2023-09-22 16:01:27 --> Form Validation Class Initialized
INFO - 2023-09-22 16:01:27 --> Controller Class Initialized
INFO - 2023-09-22 16:01:27 --> Model Class Initialized
DEBUG - 2023-09-22 16:01:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 16:01:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:01:27 --> Model Class Initialized
DEBUG - 2023-09-22 16:01:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:01:27 --> Model Class Initialized
INFO - 2023-09-22 16:01:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-22 16:01:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:01:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-22 16:01:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-22 16:01:27 --> Model Class Initialized
INFO - 2023-09-22 16:01:27 --> Model Class Initialized
INFO - 2023-09-22 16:01:27 --> Model Class Initialized
INFO - 2023-09-22 16:01:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-22 16:01:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-22 16:01:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-22 16:01:27 --> Final output sent to browser
DEBUG - 2023-09-22 16:01:27 --> Total execution time: 0.1081
ERROR - 2023-09-22 16:01:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 16:01:27 --> Config Class Initialized
INFO - 2023-09-22 16:01:27 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:01:27 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:01:27 --> Utf8 Class Initialized
INFO - 2023-09-22 16:01:27 --> URI Class Initialized
INFO - 2023-09-22 16:01:27 --> Router Class Initialized
INFO - 2023-09-22 16:01:27 --> Output Class Initialized
INFO - 2023-09-22 16:01:27 --> Security Class Initialized
DEBUG - 2023-09-22 16:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:01:27 --> Input Class Initialized
INFO - 2023-09-22 16:01:27 --> Language Class Initialized
INFO - 2023-09-22 16:01:27 --> Loader Class Initialized
INFO - 2023-09-22 16:01:27 --> Helper loaded: url_helper
INFO - 2023-09-22 16:01:27 --> Helper loaded: file_helper
INFO - 2023-09-22 16:01:27 --> Helper loaded: html_helper
INFO - 2023-09-22 16:01:27 --> Helper loaded: text_helper
INFO - 2023-09-22 16:01:27 --> Helper loaded: form_helper
INFO - 2023-09-22 16:01:27 --> Helper loaded: lang_helper
INFO - 2023-09-22 16:01:27 --> Helper loaded: security_helper
INFO - 2023-09-22 16:01:27 --> Helper loaded: cookie_helper
INFO - 2023-09-22 16:01:27 --> Database Driver Class Initialized
INFO - 2023-09-22 16:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:01:27 --> Parser Class Initialized
INFO - 2023-09-22 16:01:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 16:01:27 --> Pagination Class Initialized
INFO - 2023-09-22 16:01:27 --> Form Validation Class Initialized
INFO - 2023-09-22 16:01:27 --> Controller Class Initialized
INFO - 2023-09-22 16:01:27 --> Model Class Initialized
DEBUG - 2023-09-22 16:01:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 16:01:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:01:27 --> Model Class Initialized
DEBUG - 2023-09-22 16:01:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:01:27 --> Model Class Initialized
INFO - 2023-09-22 16:01:27 --> Final output sent to browser
DEBUG - 2023-09-22 16:01:27 --> Total execution time: 0.0401
ERROR - 2023-09-22 16:01:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 16:01:31 --> Config Class Initialized
INFO - 2023-09-22 16:01:31 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:01:31 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:01:31 --> Utf8 Class Initialized
INFO - 2023-09-22 16:01:31 --> URI Class Initialized
INFO - 2023-09-22 16:01:31 --> Router Class Initialized
INFO - 2023-09-22 16:01:31 --> Output Class Initialized
INFO - 2023-09-22 16:01:31 --> Security Class Initialized
DEBUG - 2023-09-22 16:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:01:31 --> Input Class Initialized
INFO - 2023-09-22 16:01:31 --> Language Class Initialized
INFO - 2023-09-22 16:01:31 --> Loader Class Initialized
INFO - 2023-09-22 16:01:31 --> Helper loaded: url_helper
INFO - 2023-09-22 16:01:31 --> Helper loaded: file_helper
INFO - 2023-09-22 16:01:31 --> Helper loaded: html_helper
INFO - 2023-09-22 16:01:31 --> Helper loaded: text_helper
INFO - 2023-09-22 16:01:31 --> Helper loaded: form_helper
INFO - 2023-09-22 16:01:31 --> Helper loaded: lang_helper
INFO - 2023-09-22 16:01:31 --> Helper loaded: security_helper
INFO - 2023-09-22 16:01:31 --> Helper loaded: cookie_helper
INFO - 2023-09-22 16:01:31 --> Database Driver Class Initialized
INFO - 2023-09-22 16:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:01:31 --> Parser Class Initialized
INFO - 2023-09-22 16:01:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 16:01:31 --> Pagination Class Initialized
INFO - 2023-09-22 16:01:31 --> Form Validation Class Initialized
INFO - 2023-09-22 16:01:31 --> Controller Class Initialized
INFO - 2023-09-22 16:01:31 --> Model Class Initialized
DEBUG - 2023-09-22 16:01:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 16:01:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:01:31 --> Model Class Initialized
DEBUG - 2023-09-22 16:01:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:01:31 --> Model Class Initialized
INFO - 2023-09-22 16:01:31 --> Final output sent to browser
DEBUG - 2023-09-22 16:01:31 --> Total execution time: 0.0430
ERROR - 2023-09-22 16:01:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 16:01:34 --> Config Class Initialized
INFO - 2023-09-22 16:01:34 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:01:34 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:01:34 --> Utf8 Class Initialized
INFO - 2023-09-22 16:01:34 --> URI Class Initialized
INFO - 2023-09-22 16:01:34 --> Router Class Initialized
INFO - 2023-09-22 16:01:34 --> Output Class Initialized
INFO - 2023-09-22 16:01:34 --> Security Class Initialized
DEBUG - 2023-09-22 16:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:01:34 --> Input Class Initialized
INFO - 2023-09-22 16:01:34 --> Language Class Initialized
INFO - 2023-09-22 16:01:34 --> Loader Class Initialized
INFO - 2023-09-22 16:01:34 --> Helper loaded: url_helper
INFO - 2023-09-22 16:01:34 --> Helper loaded: file_helper
INFO - 2023-09-22 16:01:34 --> Helper loaded: html_helper
INFO - 2023-09-22 16:01:34 --> Helper loaded: text_helper
INFO - 2023-09-22 16:01:34 --> Helper loaded: form_helper
INFO - 2023-09-22 16:01:34 --> Helper loaded: lang_helper
INFO - 2023-09-22 16:01:34 --> Helper loaded: security_helper
INFO - 2023-09-22 16:01:34 --> Helper loaded: cookie_helper
INFO - 2023-09-22 16:01:34 --> Database Driver Class Initialized
INFO - 2023-09-22 16:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:01:34 --> Parser Class Initialized
INFO - 2023-09-22 16:01:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 16:01:34 --> Pagination Class Initialized
INFO - 2023-09-22 16:01:34 --> Form Validation Class Initialized
INFO - 2023-09-22 16:01:34 --> Controller Class Initialized
INFO - 2023-09-22 16:01:34 --> Model Class Initialized
DEBUG - 2023-09-22 16:01:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 16:01:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:01:34 --> Model Class Initialized
DEBUG - 2023-09-22 16:01:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:01:34 --> Model Class Initialized
INFO - 2023-09-22 16:01:34 --> Final output sent to browser
DEBUG - 2023-09-22 16:01:34 --> Total execution time: 0.0401
ERROR - 2023-09-22 16:01:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 16:01:34 --> Config Class Initialized
INFO - 2023-09-22 16:01:34 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:01:34 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:01:34 --> Utf8 Class Initialized
INFO - 2023-09-22 16:01:34 --> URI Class Initialized
INFO - 2023-09-22 16:01:34 --> Router Class Initialized
INFO - 2023-09-22 16:01:34 --> Output Class Initialized
INFO - 2023-09-22 16:01:34 --> Security Class Initialized
DEBUG - 2023-09-22 16:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:01:34 --> Input Class Initialized
INFO - 2023-09-22 16:01:34 --> Language Class Initialized
INFO - 2023-09-22 16:01:34 --> Loader Class Initialized
INFO - 2023-09-22 16:01:34 --> Helper loaded: url_helper
INFO - 2023-09-22 16:01:34 --> Helper loaded: file_helper
INFO - 2023-09-22 16:01:34 --> Helper loaded: html_helper
INFO - 2023-09-22 16:01:34 --> Helper loaded: text_helper
INFO - 2023-09-22 16:01:34 --> Helper loaded: form_helper
INFO - 2023-09-22 16:01:34 --> Helper loaded: lang_helper
INFO - 2023-09-22 16:01:34 --> Helper loaded: security_helper
INFO - 2023-09-22 16:01:34 --> Helper loaded: cookie_helper
INFO - 2023-09-22 16:01:34 --> Database Driver Class Initialized
INFO - 2023-09-22 16:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:01:34 --> Parser Class Initialized
INFO - 2023-09-22 16:01:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 16:01:34 --> Pagination Class Initialized
INFO - 2023-09-22 16:01:34 --> Form Validation Class Initialized
INFO - 2023-09-22 16:01:34 --> Controller Class Initialized
INFO - 2023-09-22 16:01:34 --> Model Class Initialized
DEBUG - 2023-09-22 16:01:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 16:01:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:01:34 --> Model Class Initialized
DEBUG - 2023-09-22 16:01:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:01:34 --> Model Class Initialized
INFO - 2023-09-22 16:01:34 --> Final output sent to browser
DEBUG - 2023-09-22 16:01:34 --> Total execution time: 0.0251
ERROR - 2023-09-22 16:01:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 16:01:39 --> Config Class Initialized
INFO - 2023-09-22 16:01:39 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:01:39 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:01:39 --> Utf8 Class Initialized
INFO - 2023-09-22 16:01:39 --> URI Class Initialized
INFO - 2023-09-22 16:01:39 --> Router Class Initialized
INFO - 2023-09-22 16:01:39 --> Output Class Initialized
INFO - 2023-09-22 16:01:39 --> Security Class Initialized
DEBUG - 2023-09-22 16:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:01:39 --> Input Class Initialized
INFO - 2023-09-22 16:01:39 --> Language Class Initialized
INFO - 2023-09-22 16:01:39 --> Loader Class Initialized
INFO - 2023-09-22 16:01:39 --> Helper loaded: url_helper
INFO - 2023-09-22 16:01:39 --> Helper loaded: file_helper
INFO - 2023-09-22 16:01:39 --> Helper loaded: html_helper
INFO - 2023-09-22 16:01:39 --> Helper loaded: text_helper
INFO - 2023-09-22 16:01:39 --> Helper loaded: form_helper
INFO - 2023-09-22 16:01:39 --> Helper loaded: lang_helper
INFO - 2023-09-22 16:01:39 --> Helper loaded: security_helper
INFO - 2023-09-22 16:01:39 --> Helper loaded: cookie_helper
INFO - 2023-09-22 16:01:39 --> Database Driver Class Initialized
INFO - 2023-09-22 16:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:01:39 --> Parser Class Initialized
INFO - 2023-09-22 16:01:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 16:01:39 --> Pagination Class Initialized
INFO - 2023-09-22 16:01:39 --> Form Validation Class Initialized
INFO - 2023-09-22 16:01:39 --> Controller Class Initialized
INFO - 2023-09-22 16:01:39 --> Model Class Initialized
DEBUG - 2023-09-22 16:01:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 16:01:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:01:39 --> Model Class Initialized
DEBUG - 2023-09-22 16:01:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:01:39 --> Model Class Initialized
DEBUG - 2023-09-22 16:01:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:01:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-09-22 16:01:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:01:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-22 16:01:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-22 16:01:39 --> Model Class Initialized
INFO - 2023-09-22 16:01:39 --> Model Class Initialized
INFO - 2023-09-22 16:01:39 --> Model Class Initialized
INFO - 2023-09-22 16:01:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-22 16:01:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-22 16:01:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-22 16:01:39 --> Final output sent to browser
DEBUG - 2023-09-22 16:01:39 --> Total execution time: 0.1100
ERROR - 2023-09-22 16:02:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 16:02:05 --> Config Class Initialized
INFO - 2023-09-22 16:02:05 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:02:05 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:02:05 --> Utf8 Class Initialized
INFO - 2023-09-22 16:02:05 --> URI Class Initialized
INFO - 2023-09-22 16:02:05 --> Router Class Initialized
INFO - 2023-09-22 16:02:05 --> Output Class Initialized
INFO - 2023-09-22 16:02:05 --> Security Class Initialized
DEBUG - 2023-09-22 16:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:02:05 --> Input Class Initialized
INFO - 2023-09-22 16:02:05 --> Language Class Initialized
INFO - 2023-09-22 16:02:05 --> Loader Class Initialized
INFO - 2023-09-22 16:02:05 --> Helper loaded: url_helper
INFO - 2023-09-22 16:02:05 --> Helper loaded: file_helper
INFO - 2023-09-22 16:02:05 --> Helper loaded: html_helper
INFO - 2023-09-22 16:02:05 --> Helper loaded: text_helper
INFO - 2023-09-22 16:02:05 --> Helper loaded: form_helper
INFO - 2023-09-22 16:02:05 --> Helper loaded: lang_helper
INFO - 2023-09-22 16:02:05 --> Helper loaded: security_helper
INFO - 2023-09-22 16:02:05 --> Helper loaded: cookie_helper
INFO - 2023-09-22 16:02:05 --> Database Driver Class Initialized
INFO - 2023-09-22 16:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:02:05 --> Parser Class Initialized
INFO - 2023-09-22 16:02:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 16:02:05 --> Pagination Class Initialized
INFO - 2023-09-22 16:02:05 --> Form Validation Class Initialized
INFO - 2023-09-22 16:02:05 --> Controller Class Initialized
INFO - 2023-09-22 16:02:05 --> Model Class Initialized
DEBUG - 2023-09-22 16:02:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 16:02:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:02:05 --> Model Class Initialized
DEBUG - 2023-09-22 16:02:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:02:05 --> Model Class Initialized
INFO - 2023-09-22 16:02:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-22 16:02:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:02:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-22 16:02:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-22 16:02:05 --> Model Class Initialized
INFO - 2023-09-22 16:02:05 --> Model Class Initialized
INFO - 2023-09-22 16:02:05 --> Model Class Initialized
INFO - 2023-09-22 16:02:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-22 16:02:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-22 16:02:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-22 16:02:05 --> Final output sent to browser
DEBUG - 2023-09-22 16:02:05 --> Total execution time: 0.0891
ERROR - 2023-09-22 16:02:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 16:02:06 --> Config Class Initialized
INFO - 2023-09-22 16:02:06 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:02:06 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:02:06 --> Utf8 Class Initialized
INFO - 2023-09-22 16:02:06 --> URI Class Initialized
INFO - 2023-09-22 16:02:06 --> Router Class Initialized
INFO - 2023-09-22 16:02:06 --> Output Class Initialized
INFO - 2023-09-22 16:02:06 --> Security Class Initialized
DEBUG - 2023-09-22 16:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:02:06 --> Input Class Initialized
INFO - 2023-09-22 16:02:06 --> Language Class Initialized
INFO - 2023-09-22 16:02:06 --> Loader Class Initialized
INFO - 2023-09-22 16:02:06 --> Helper loaded: url_helper
INFO - 2023-09-22 16:02:06 --> Helper loaded: file_helper
INFO - 2023-09-22 16:02:06 --> Helper loaded: html_helper
INFO - 2023-09-22 16:02:06 --> Helper loaded: text_helper
INFO - 2023-09-22 16:02:06 --> Helper loaded: form_helper
INFO - 2023-09-22 16:02:06 --> Helper loaded: lang_helper
INFO - 2023-09-22 16:02:06 --> Helper loaded: security_helper
INFO - 2023-09-22 16:02:06 --> Helper loaded: cookie_helper
INFO - 2023-09-22 16:02:06 --> Database Driver Class Initialized
INFO - 2023-09-22 16:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:02:06 --> Parser Class Initialized
INFO - 2023-09-22 16:02:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 16:02:06 --> Pagination Class Initialized
INFO - 2023-09-22 16:02:06 --> Form Validation Class Initialized
INFO - 2023-09-22 16:02:06 --> Controller Class Initialized
INFO - 2023-09-22 16:02:06 --> Model Class Initialized
DEBUG - 2023-09-22 16:02:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 16:02:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:02:06 --> Model Class Initialized
DEBUG - 2023-09-22 16:02:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:02:06 --> Model Class Initialized
INFO - 2023-09-22 16:02:06 --> Final output sent to browser
DEBUG - 2023-09-22 16:02:06 --> Total execution time: 0.0429
ERROR - 2023-09-22 16:02:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 16:02:10 --> Config Class Initialized
INFO - 2023-09-22 16:02:10 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:02:10 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:02:10 --> Utf8 Class Initialized
INFO - 2023-09-22 16:02:10 --> URI Class Initialized
INFO - 2023-09-22 16:02:10 --> Router Class Initialized
INFO - 2023-09-22 16:02:10 --> Output Class Initialized
INFO - 2023-09-22 16:02:10 --> Security Class Initialized
DEBUG - 2023-09-22 16:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:02:10 --> Input Class Initialized
INFO - 2023-09-22 16:02:10 --> Language Class Initialized
INFO - 2023-09-22 16:02:10 --> Loader Class Initialized
INFO - 2023-09-22 16:02:10 --> Helper loaded: url_helper
INFO - 2023-09-22 16:02:10 --> Helper loaded: file_helper
INFO - 2023-09-22 16:02:10 --> Helper loaded: html_helper
INFO - 2023-09-22 16:02:10 --> Helper loaded: text_helper
INFO - 2023-09-22 16:02:10 --> Helper loaded: form_helper
INFO - 2023-09-22 16:02:10 --> Helper loaded: lang_helper
INFO - 2023-09-22 16:02:10 --> Helper loaded: security_helper
INFO - 2023-09-22 16:02:10 --> Helper loaded: cookie_helper
INFO - 2023-09-22 16:02:10 --> Database Driver Class Initialized
INFO - 2023-09-22 16:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:02:10 --> Parser Class Initialized
INFO - 2023-09-22 16:02:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 16:02:10 --> Pagination Class Initialized
INFO - 2023-09-22 16:02:10 --> Form Validation Class Initialized
INFO - 2023-09-22 16:02:10 --> Controller Class Initialized
INFO - 2023-09-22 16:02:10 --> Model Class Initialized
DEBUG - 2023-09-22 16:02:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 16:02:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:02:10 --> Model Class Initialized
DEBUG - 2023-09-22 16:02:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:02:10 --> Model Class Initialized
INFO - 2023-09-22 16:02:10 --> Final output sent to browser
DEBUG - 2023-09-22 16:02:10 --> Total execution time: 0.0389
ERROR - 2023-09-22 16:02:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 16:02:10 --> Config Class Initialized
INFO - 2023-09-22 16:02:10 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:02:10 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:02:10 --> Utf8 Class Initialized
INFO - 2023-09-22 16:02:10 --> URI Class Initialized
INFO - 2023-09-22 16:02:10 --> Router Class Initialized
INFO - 2023-09-22 16:02:10 --> Output Class Initialized
INFO - 2023-09-22 16:02:10 --> Security Class Initialized
DEBUG - 2023-09-22 16:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:02:10 --> Input Class Initialized
INFO - 2023-09-22 16:02:10 --> Language Class Initialized
INFO - 2023-09-22 16:02:10 --> Loader Class Initialized
INFO - 2023-09-22 16:02:10 --> Helper loaded: url_helper
INFO - 2023-09-22 16:02:10 --> Helper loaded: file_helper
INFO - 2023-09-22 16:02:10 --> Helper loaded: html_helper
INFO - 2023-09-22 16:02:10 --> Helper loaded: text_helper
INFO - 2023-09-22 16:02:10 --> Helper loaded: form_helper
INFO - 2023-09-22 16:02:10 --> Helper loaded: lang_helper
INFO - 2023-09-22 16:02:10 --> Helper loaded: security_helper
INFO - 2023-09-22 16:02:10 --> Helper loaded: cookie_helper
INFO - 2023-09-22 16:02:10 --> Database Driver Class Initialized
INFO - 2023-09-22 16:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:02:10 --> Parser Class Initialized
INFO - 2023-09-22 16:02:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 16:02:10 --> Pagination Class Initialized
INFO - 2023-09-22 16:02:10 --> Form Validation Class Initialized
INFO - 2023-09-22 16:02:10 --> Controller Class Initialized
INFO - 2023-09-22 16:02:10 --> Model Class Initialized
DEBUG - 2023-09-22 16:02:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 16:02:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:02:10 --> Model Class Initialized
DEBUG - 2023-09-22 16:02:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:02:10 --> Model Class Initialized
INFO - 2023-09-22 16:02:10 --> Final output sent to browser
DEBUG - 2023-09-22 16:02:10 --> Total execution time: 0.0392
ERROR - 2023-09-22 16:02:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 16:02:15 --> Config Class Initialized
INFO - 2023-09-22 16:02:15 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:02:15 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:02:15 --> Utf8 Class Initialized
INFO - 2023-09-22 16:02:15 --> URI Class Initialized
INFO - 2023-09-22 16:02:15 --> Router Class Initialized
INFO - 2023-09-22 16:02:15 --> Output Class Initialized
INFO - 2023-09-22 16:02:15 --> Security Class Initialized
DEBUG - 2023-09-22 16:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:02:15 --> Input Class Initialized
INFO - 2023-09-22 16:02:15 --> Language Class Initialized
INFO - 2023-09-22 16:02:15 --> Loader Class Initialized
INFO - 2023-09-22 16:02:15 --> Helper loaded: url_helper
INFO - 2023-09-22 16:02:15 --> Helper loaded: file_helper
INFO - 2023-09-22 16:02:15 --> Helper loaded: html_helper
INFO - 2023-09-22 16:02:15 --> Helper loaded: text_helper
INFO - 2023-09-22 16:02:15 --> Helper loaded: form_helper
INFO - 2023-09-22 16:02:15 --> Helper loaded: lang_helper
INFO - 2023-09-22 16:02:15 --> Helper loaded: security_helper
INFO - 2023-09-22 16:02:15 --> Helper loaded: cookie_helper
INFO - 2023-09-22 16:02:15 --> Database Driver Class Initialized
INFO - 2023-09-22 16:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:02:15 --> Parser Class Initialized
INFO - 2023-09-22 16:02:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 16:02:15 --> Pagination Class Initialized
INFO - 2023-09-22 16:02:15 --> Form Validation Class Initialized
INFO - 2023-09-22 16:02:15 --> Controller Class Initialized
INFO - 2023-09-22 16:02:15 --> Model Class Initialized
DEBUG - 2023-09-22 16:02:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 16:02:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:02:15 --> Model Class Initialized
DEBUG - 2023-09-22 16:02:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:02:15 --> Model Class Initialized
INFO - 2023-09-22 16:02:15 --> Final output sent to browser
DEBUG - 2023-09-22 16:02:15 --> Total execution time: 0.0259
ERROR - 2023-09-22 16:02:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 16:02:15 --> Config Class Initialized
INFO - 2023-09-22 16:02:15 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:02:15 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:02:15 --> Utf8 Class Initialized
INFO - 2023-09-22 16:02:15 --> URI Class Initialized
INFO - 2023-09-22 16:02:15 --> Router Class Initialized
INFO - 2023-09-22 16:02:15 --> Output Class Initialized
INFO - 2023-09-22 16:02:15 --> Security Class Initialized
DEBUG - 2023-09-22 16:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:02:15 --> Input Class Initialized
INFO - 2023-09-22 16:02:15 --> Language Class Initialized
INFO - 2023-09-22 16:02:15 --> Loader Class Initialized
INFO - 2023-09-22 16:02:15 --> Helper loaded: url_helper
INFO - 2023-09-22 16:02:15 --> Helper loaded: file_helper
INFO - 2023-09-22 16:02:15 --> Helper loaded: html_helper
INFO - 2023-09-22 16:02:15 --> Helper loaded: text_helper
INFO - 2023-09-22 16:02:15 --> Helper loaded: form_helper
INFO - 2023-09-22 16:02:15 --> Helper loaded: lang_helper
INFO - 2023-09-22 16:02:15 --> Helper loaded: security_helper
INFO - 2023-09-22 16:02:15 --> Helper loaded: cookie_helper
INFO - 2023-09-22 16:02:15 --> Database Driver Class Initialized
INFO - 2023-09-22 16:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:02:15 --> Parser Class Initialized
INFO - 2023-09-22 16:02:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 16:02:15 --> Pagination Class Initialized
INFO - 2023-09-22 16:02:15 --> Form Validation Class Initialized
INFO - 2023-09-22 16:02:15 --> Controller Class Initialized
INFO - 2023-09-22 16:02:15 --> Model Class Initialized
DEBUG - 2023-09-22 16:02:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 16:02:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:02:15 --> Model Class Initialized
DEBUG - 2023-09-22 16:02:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:02:15 --> Model Class Initialized
INFO - 2023-09-22 16:02:15 --> Final output sent to browser
DEBUG - 2023-09-22 16:02:15 --> Total execution time: 0.0250
ERROR - 2023-09-22 16:02:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 16:02:17 --> Config Class Initialized
INFO - 2023-09-22 16:02:17 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:02:17 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:02:17 --> Utf8 Class Initialized
INFO - 2023-09-22 16:02:17 --> URI Class Initialized
INFO - 2023-09-22 16:02:17 --> Router Class Initialized
INFO - 2023-09-22 16:02:17 --> Output Class Initialized
INFO - 2023-09-22 16:02:17 --> Security Class Initialized
DEBUG - 2023-09-22 16:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:02:17 --> Input Class Initialized
INFO - 2023-09-22 16:02:17 --> Language Class Initialized
INFO - 2023-09-22 16:02:17 --> Loader Class Initialized
INFO - 2023-09-22 16:02:17 --> Helper loaded: url_helper
INFO - 2023-09-22 16:02:17 --> Helper loaded: file_helper
INFO - 2023-09-22 16:02:17 --> Helper loaded: html_helper
INFO - 2023-09-22 16:02:17 --> Helper loaded: text_helper
INFO - 2023-09-22 16:02:17 --> Helper loaded: form_helper
INFO - 2023-09-22 16:02:17 --> Helper loaded: lang_helper
INFO - 2023-09-22 16:02:17 --> Helper loaded: security_helper
INFO - 2023-09-22 16:02:17 --> Helper loaded: cookie_helper
INFO - 2023-09-22 16:02:17 --> Database Driver Class Initialized
INFO - 2023-09-22 16:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:02:17 --> Parser Class Initialized
INFO - 2023-09-22 16:02:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 16:02:17 --> Pagination Class Initialized
INFO - 2023-09-22 16:02:17 --> Form Validation Class Initialized
INFO - 2023-09-22 16:02:17 --> Controller Class Initialized
INFO - 2023-09-22 16:02:17 --> Model Class Initialized
DEBUG - 2023-09-22 16:02:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 16:02:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:02:17 --> Model Class Initialized
DEBUG - 2023-09-22 16:02:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:02:17 --> Model Class Initialized
INFO - 2023-09-22 16:02:18 --> Final output sent to browser
DEBUG - 2023-09-22 16:02:18 --> Total execution time: 0.0258
ERROR - 2023-09-22 16:02:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 16:02:18 --> Config Class Initialized
INFO - 2023-09-22 16:02:18 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:02:18 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:02:18 --> Utf8 Class Initialized
INFO - 2023-09-22 16:02:18 --> URI Class Initialized
INFO - 2023-09-22 16:02:18 --> Router Class Initialized
INFO - 2023-09-22 16:02:18 --> Output Class Initialized
INFO - 2023-09-22 16:02:18 --> Security Class Initialized
DEBUG - 2023-09-22 16:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:02:18 --> Input Class Initialized
INFO - 2023-09-22 16:02:18 --> Language Class Initialized
INFO - 2023-09-22 16:02:18 --> Loader Class Initialized
INFO - 2023-09-22 16:02:18 --> Helper loaded: url_helper
INFO - 2023-09-22 16:02:18 --> Helper loaded: file_helper
INFO - 2023-09-22 16:02:18 --> Helper loaded: html_helper
INFO - 2023-09-22 16:02:18 --> Helper loaded: text_helper
INFO - 2023-09-22 16:02:18 --> Helper loaded: form_helper
INFO - 2023-09-22 16:02:18 --> Helper loaded: lang_helper
INFO - 2023-09-22 16:02:18 --> Helper loaded: security_helper
INFO - 2023-09-22 16:02:18 --> Helper loaded: cookie_helper
INFO - 2023-09-22 16:02:18 --> Database Driver Class Initialized
INFO - 2023-09-22 16:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:02:18 --> Parser Class Initialized
INFO - 2023-09-22 16:02:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 16:02:18 --> Pagination Class Initialized
INFO - 2023-09-22 16:02:18 --> Form Validation Class Initialized
INFO - 2023-09-22 16:02:18 --> Controller Class Initialized
INFO - 2023-09-22 16:02:18 --> Model Class Initialized
DEBUG - 2023-09-22 16:02:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 16:02:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:02:18 --> Model Class Initialized
DEBUG - 2023-09-22 16:02:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:02:18 --> Model Class Initialized
DEBUG - 2023-09-22 16:02:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:02:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-09-22 16:02:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:02:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-22 16:02:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-22 16:02:18 --> Model Class Initialized
INFO - 2023-09-22 16:02:18 --> Model Class Initialized
INFO - 2023-09-22 16:02:18 --> Model Class Initialized
INFO - 2023-09-22 16:02:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-22 16:02:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-22 16:02:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-22 16:02:18 --> Final output sent to browser
DEBUG - 2023-09-22 16:02:18 --> Total execution time: 0.0985
ERROR - 2023-09-22 16:02:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 16:02:18 --> Config Class Initialized
INFO - 2023-09-22 16:02:18 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:02:18 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:02:18 --> Utf8 Class Initialized
INFO - 2023-09-22 16:02:18 --> URI Class Initialized
INFO - 2023-09-22 16:02:18 --> Router Class Initialized
INFO - 2023-09-22 16:02:18 --> Output Class Initialized
INFO - 2023-09-22 16:02:18 --> Security Class Initialized
DEBUG - 2023-09-22 16:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:02:18 --> Input Class Initialized
INFO - 2023-09-22 16:02:18 --> Language Class Initialized
INFO - 2023-09-22 16:02:18 --> Loader Class Initialized
INFO - 2023-09-22 16:02:18 --> Helper loaded: url_helper
INFO - 2023-09-22 16:02:18 --> Helper loaded: file_helper
INFO - 2023-09-22 16:02:18 --> Helper loaded: html_helper
INFO - 2023-09-22 16:02:18 --> Helper loaded: text_helper
INFO - 2023-09-22 16:02:18 --> Helper loaded: form_helper
INFO - 2023-09-22 16:02:18 --> Helper loaded: lang_helper
INFO - 2023-09-22 16:02:18 --> Helper loaded: security_helper
INFO - 2023-09-22 16:02:18 --> Helper loaded: cookie_helper
INFO - 2023-09-22 16:02:18 --> Database Driver Class Initialized
INFO - 2023-09-22 16:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:02:18 --> Parser Class Initialized
INFO - 2023-09-22 16:02:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 16:02:18 --> Pagination Class Initialized
INFO - 2023-09-22 16:02:18 --> Form Validation Class Initialized
INFO - 2023-09-22 16:02:18 --> Controller Class Initialized
INFO - 2023-09-22 16:02:18 --> Model Class Initialized
DEBUG - 2023-09-22 16:02:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 16:02:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:02:18 --> Model Class Initialized
DEBUG - 2023-09-22 16:02:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:02:18 --> Model Class Initialized
DEBUG - 2023-09-22 16:02:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:02:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-09-22 16:02:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:02:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-22 16:02:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-22 16:02:18 --> Model Class Initialized
INFO - 2023-09-22 16:02:18 --> Model Class Initialized
INFO - 2023-09-22 16:02:18 --> Model Class Initialized
INFO - 2023-09-22 16:02:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-22 16:02:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-22 16:02:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-22 16:02:18 --> Final output sent to browser
DEBUG - 2023-09-22 16:02:18 --> Total execution time: 0.0862
ERROR - 2023-09-22 16:07:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 16:07:42 --> Config Class Initialized
INFO - 2023-09-22 16:07:42 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:07:42 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:07:42 --> Utf8 Class Initialized
INFO - 2023-09-22 16:07:42 --> URI Class Initialized
DEBUG - 2023-09-22 16:07:42 --> No URI present. Default controller set.
INFO - 2023-09-22 16:07:42 --> Router Class Initialized
INFO - 2023-09-22 16:07:42 --> Output Class Initialized
INFO - 2023-09-22 16:07:42 --> Security Class Initialized
DEBUG - 2023-09-22 16:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:07:42 --> Input Class Initialized
INFO - 2023-09-22 16:07:42 --> Language Class Initialized
INFO - 2023-09-22 16:07:42 --> Loader Class Initialized
INFO - 2023-09-22 16:07:42 --> Helper loaded: url_helper
INFO - 2023-09-22 16:07:42 --> Helper loaded: file_helper
INFO - 2023-09-22 16:07:42 --> Helper loaded: html_helper
INFO - 2023-09-22 16:07:42 --> Helper loaded: text_helper
INFO - 2023-09-22 16:07:42 --> Helper loaded: form_helper
INFO - 2023-09-22 16:07:42 --> Helper loaded: lang_helper
INFO - 2023-09-22 16:07:42 --> Helper loaded: security_helper
INFO - 2023-09-22 16:07:42 --> Helper loaded: cookie_helper
INFO - 2023-09-22 16:07:42 --> Database Driver Class Initialized
INFO - 2023-09-22 16:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:07:42 --> Parser Class Initialized
INFO - 2023-09-22 16:07:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 16:07:42 --> Pagination Class Initialized
INFO - 2023-09-22 16:07:42 --> Form Validation Class Initialized
INFO - 2023-09-22 16:07:42 --> Controller Class Initialized
INFO - 2023-09-22 16:07:42 --> Model Class Initialized
DEBUG - 2023-09-22 16:07:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:07:42 --> Model Class Initialized
DEBUG - 2023-09-22 16:07:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:07:42 --> Model Class Initialized
INFO - 2023-09-22 16:07:42 --> Model Class Initialized
INFO - 2023-09-22 16:07:42 --> Model Class Initialized
INFO - 2023-09-22 16:07:42 --> Model Class Initialized
DEBUG - 2023-09-22 16:07:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 16:07:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:07:42 --> Model Class Initialized
INFO - 2023-09-22 16:07:42 --> Model Class Initialized
INFO - 2023-09-22 16:07:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-22 16:07:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:07:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-22 16:07:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-22 16:07:42 --> Model Class Initialized
INFO - 2023-09-22 16:07:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-22 16:07:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-22 16:07:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-22 16:07:42 --> Final output sent to browser
DEBUG - 2023-09-22 16:07:42 --> Total execution time: 0.1064
ERROR - 2023-09-22 16:07:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 16:07:51 --> Config Class Initialized
INFO - 2023-09-22 16:07:51 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:07:51 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:07:51 --> Utf8 Class Initialized
INFO - 2023-09-22 16:07:51 --> URI Class Initialized
INFO - 2023-09-22 16:07:51 --> Router Class Initialized
INFO - 2023-09-22 16:07:51 --> Output Class Initialized
INFO - 2023-09-22 16:07:51 --> Security Class Initialized
DEBUG - 2023-09-22 16:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:07:51 --> Input Class Initialized
INFO - 2023-09-22 16:07:51 --> Language Class Initialized
INFO - 2023-09-22 16:07:51 --> Loader Class Initialized
INFO - 2023-09-22 16:07:51 --> Helper loaded: url_helper
INFO - 2023-09-22 16:07:51 --> Helper loaded: file_helper
INFO - 2023-09-22 16:07:51 --> Helper loaded: html_helper
INFO - 2023-09-22 16:07:51 --> Helper loaded: text_helper
INFO - 2023-09-22 16:07:51 --> Helper loaded: form_helper
INFO - 2023-09-22 16:07:51 --> Helper loaded: lang_helper
INFO - 2023-09-22 16:07:51 --> Helper loaded: security_helper
INFO - 2023-09-22 16:07:51 --> Helper loaded: cookie_helper
INFO - 2023-09-22 16:07:51 --> Database Driver Class Initialized
INFO - 2023-09-22 16:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:07:51 --> Parser Class Initialized
INFO - 2023-09-22 16:07:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 16:07:51 --> Pagination Class Initialized
INFO - 2023-09-22 16:07:51 --> Form Validation Class Initialized
INFO - 2023-09-22 16:07:51 --> Controller Class Initialized
INFO - 2023-09-22 16:07:51 --> Model Class Initialized
DEBUG - 2023-09-22 16:07:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 16:07:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:07:51 --> Model Class Initialized
DEBUG - 2023-09-22 16:07:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:07:51 --> Model Class Initialized
INFO - 2023-09-22 16:07:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-22 16:07:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:07:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-22 16:07:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-22 16:07:51 --> Model Class Initialized
INFO - 2023-09-22 16:07:51 --> Model Class Initialized
INFO - 2023-09-22 16:07:51 --> Model Class Initialized
INFO - 2023-09-22 16:07:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-22 16:07:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-22 16:07:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-22 16:07:51 --> Final output sent to browser
DEBUG - 2023-09-22 16:07:51 --> Total execution time: 0.0884
ERROR - 2023-09-22 16:07:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 16:07:51 --> Config Class Initialized
INFO - 2023-09-22 16:07:51 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:07:51 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:07:51 --> Utf8 Class Initialized
INFO - 2023-09-22 16:07:51 --> URI Class Initialized
INFO - 2023-09-22 16:07:51 --> Router Class Initialized
INFO - 2023-09-22 16:07:51 --> Output Class Initialized
INFO - 2023-09-22 16:07:51 --> Security Class Initialized
DEBUG - 2023-09-22 16:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:07:51 --> Input Class Initialized
INFO - 2023-09-22 16:07:51 --> Language Class Initialized
INFO - 2023-09-22 16:07:51 --> Loader Class Initialized
INFO - 2023-09-22 16:07:51 --> Helper loaded: url_helper
INFO - 2023-09-22 16:07:51 --> Helper loaded: file_helper
INFO - 2023-09-22 16:07:51 --> Helper loaded: html_helper
INFO - 2023-09-22 16:07:51 --> Helper loaded: text_helper
INFO - 2023-09-22 16:07:51 --> Helper loaded: form_helper
INFO - 2023-09-22 16:07:51 --> Helper loaded: lang_helper
INFO - 2023-09-22 16:07:51 --> Helper loaded: security_helper
INFO - 2023-09-22 16:07:51 --> Helper loaded: cookie_helper
INFO - 2023-09-22 16:07:51 --> Database Driver Class Initialized
INFO - 2023-09-22 16:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:07:51 --> Parser Class Initialized
INFO - 2023-09-22 16:07:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 16:07:51 --> Pagination Class Initialized
INFO - 2023-09-22 16:07:51 --> Form Validation Class Initialized
INFO - 2023-09-22 16:07:51 --> Controller Class Initialized
INFO - 2023-09-22 16:07:51 --> Model Class Initialized
DEBUG - 2023-09-22 16:07:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 16:07:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:07:51 --> Model Class Initialized
DEBUG - 2023-09-22 16:07:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:07:51 --> Model Class Initialized
INFO - 2023-09-22 16:07:51 --> Final output sent to browser
DEBUG - 2023-09-22 16:07:51 --> Total execution time: 0.0423
ERROR - 2023-09-22 16:07:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 16:07:54 --> Config Class Initialized
INFO - 2023-09-22 16:07:54 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:07:54 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:07:54 --> Utf8 Class Initialized
INFO - 2023-09-22 16:07:54 --> URI Class Initialized
INFO - 2023-09-22 16:07:54 --> Router Class Initialized
INFO - 2023-09-22 16:07:54 --> Output Class Initialized
INFO - 2023-09-22 16:07:54 --> Security Class Initialized
DEBUG - 2023-09-22 16:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:07:54 --> Input Class Initialized
INFO - 2023-09-22 16:07:54 --> Language Class Initialized
INFO - 2023-09-22 16:07:54 --> Loader Class Initialized
INFO - 2023-09-22 16:07:54 --> Helper loaded: url_helper
INFO - 2023-09-22 16:07:54 --> Helper loaded: file_helper
INFO - 2023-09-22 16:07:54 --> Helper loaded: html_helper
INFO - 2023-09-22 16:07:54 --> Helper loaded: text_helper
INFO - 2023-09-22 16:07:54 --> Helper loaded: form_helper
INFO - 2023-09-22 16:07:54 --> Helper loaded: lang_helper
INFO - 2023-09-22 16:07:54 --> Helper loaded: security_helper
INFO - 2023-09-22 16:07:54 --> Helper loaded: cookie_helper
INFO - 2023-09-22 16:07:54 --> Database Driver Class Initialized
INFO - 2023-09-22 16:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:07:54 --> Parser Class Initialized
INFO - 2023-09-22 16:07:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-22 16:07:54 --> Pagination Class Initialized
INFO - 2023-09-22 16:07:54 --> Form Validation Class Initialized
INFO - 2023-09-22 16:07:54 --> Controller Class Initialized
INFO - 2023-09-22 16:07:54 --> Model Class Initialized
DEBUG - 2023-09-22 16:07:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-22 16:07:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:07:54 --> Model Class Initialized
DEBUG - 2023-09-22 16:07:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-22 16:07:54 --> Model Class Initialized
INFO - 2023-09-22 16:07:54 --> Final output sent to browser
DEBUG - 2023-09-22 16:07:54 --> Total execution time: 0.3535
ERROR - 2023-09-22 16:10:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-22 16:10:57 --> Config Class Initialized
INFO - 2023-09-22 16:10:57 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:10:57 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:10:57 --> Utf8 Class Initialized
INFO - 2023-09-22 16:10:57 --> URI Class Initialized
INFO - 2023-09-22 16:10:57 --> Router Class Initialized
INFO - 2023-09-22 16:10:57 --> Output Class Initialized
INFO - 2023-09-22 16:10:57 --> Security Class Initialized
DEBUG - 2023-09-22 16:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:10:57 --> Input Class Initialized
INFO - 2023-09-22 16:10:57 --> Language Class Initialized
ERROR - 2023-09-22 16:10:57 --> 404 Page Not Found: Authorizephp/index
