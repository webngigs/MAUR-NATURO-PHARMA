<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-21 03:36:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 03:36:52 --> Config Class Initialized
INFO - 2023-07-21 03:36:52 --> Hooks Class Initialized
DEBUG - 2023-07-21 03:36:52 --> UTF-8 Support Enabled
INFO - 2023-07-21 03:36:52 --> Utf8 Class Initialized
INFO - 2023-07-21 03:36:52 --> URI Class Initialized
DEBUG - 2023-07-21 03:36:52 --> No URI present. Default controller set.
INFO - 2023-07-21 03:36:52 --> Router Class Initialized
INFO - 2023-07-21 03:36:52 --> Output Class Initialized
INFO - 2023-07-21 03:36:52 --> Security Class Initialized
DEBUG - 2023-07-21 03:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 03:36:52 --> Input Class Initialized
INFO - 2023-07-21 03:36:52 --> Language Class Initialized
INFO - 2023-07-21 03:36:52 --> Loader Class Initialized
INFO - 2023-07-21 03:36:52 --> Helper loaded: url_helper
INFO - 2023-07-21 03:36:52 --> Helper loaded: file_helper
INFO - 2023-07-21 03:36:52 --> Helper loaded: html_helper
INFO - 2023-07-21 03:36:52 --> Helper loaded: text_helper
INFO - 2023-07-21 03:36:52 --> Helper loaded: form_helper
INFO - 2023-07-21 03:36:52 --> Helper loaded: lang_helper
INFO - 2023-07-21 03:36:52 --> Helper loaded: security_helper
INFO - 2023-07-21 03:36:52 --> Helper loaded: cookie_helper
INFO - 2023-07-21 03:36:52 --> Database Driver Class Initialized
INFO - 2023-07-21 03:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 03:36:52 --> Parser Class Initialized
INFO - 2023-07-21 03:36:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 03:36:52 --> Pagination Class Initialized
INFO - 2023-07-21 03:36:52 --> Form Validation Class Initialized
INFO - 2023-07-21 03:36:52 --> Controller Class Initialized
INFO - 2023-07-21 03:36:52 --> Model Class Initialized
DEBUG - 2023-07-21 03:36:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-21 03:36:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 03:36:52 --> Config Class Initialized
INFO - 2023-07-21 03:36:52 --> Hooks Class Initialized
DEBUG - 2023-07-21 03:36:52 --> UTF-8 Support Enabled
INFO - 2023-07-21 03:36:52 --> Utf8 Class Initialized
INFO - 2023-07-21 03:36:52 --> URI Class Initialized
INFO - 2023-07-21 03:36:52 --> Router Class Initialized
INFO - 2023-07-21 03:36:52 --> Output Class Initialized
INFO - 2023-07-21 03:36:52 --> Security Class Initialized
DEBUG - 2023-07-21 03:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 03:36:52 --> Input Class Initialized
INFO - 2023-07-21 03:36:52 --> Language Class Initialized
INFO - 2023-07-21 03:36:52 --> Loader Class Initialized
INFO - 2023-07-21 03:36:52 --> Helper loaded: url_helper
INFO - 2023-07-21 03:36:52 --> Helper loaded: file_helper
INFO - 2023-07-21 03:36:52 --> Helper loaded: html_helper
INFO - 2023-07-21 03:36:52 --> Helper loaded: text_helper
INFO - 2023-07-21 03:36:52 --> Helper loaded: form_helper
INFO - 2023-07-21 03:36:52 --> Helper loaded: lang_helper
INFO - 2023-07-21 03:36:52 --> Helper loaded: security_helper
INFO - 2023-07-21 03:36:52 --> Helper loaded: cookie_helper
INFO - 2023-07-21 03:36:52 --> Database Driver Class Initialized
INFO - 2023-07-21 03:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 03:36:52 --> Parser Class Initialized
INFO - 2023-07-21 03:36:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 03:36:52 --> Pagination Class Initialized
INFO - 2023-07-21 03:36:52 --> Form Validation Class Initialized
INFO - 2023-07-21 03:36:52 --> Controller Class Initialized
INFO - 2023-07-21 03:36:52 --> Model Class Initialized
DEBUG - 2023-07-21 03:36:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 03:36:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-21 03:36:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 03:36:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 03:36:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 03:36:52 --> Model Class Initialized
INFO - 2023-07-21 03:36:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 03:36:52 --> Final output sent to browser
DEBUG - 2023-07-21 03:36:52 --> Total execution time: 0.0314
ERROR - 2023-07-21 03:37:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 03:37:16 --> Config Class Initialized
INFO - 2023-07-21 03:37:16 --> Hooks Class Initialized
DEBUG - 2023-07-21 03:37:16 --> UTF-8 Support Enabled
INFO - 2023-07-21 03:37:16 --> Utf8 Class Initialized
INFO - 2023-07-21 03:37:16 --> URI Class Initialized
INFO - 2023-07-21 03:37:16 --> Router Class Initialized
INFO - 2023-07-21 03:37:16 --> Output Class Initialized
INFO - 2023-07-21 03:37:16 --> Security Class Initialized
DEBUG - 2023-07-21 03:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 03:37:16 --> Input Class Initialized
INFO - 2023-07-21 03:37:16 --> Language Class Initialized
INFO - 2023-07-21 03:37:16 --> Loader Class Initialized
INFO - 2023-07-21 03:37:16 --> Helper loaded: url_helper
INFO - 2023-07-21 03:37:16 --> Helper loaded: file_helper
INFO - 2023-07-21 03:37:16 --> Helper loaded: html_helper
INFO - 2023-07-21 03:37:16 --> Helper loaded: text_helper
INFO - 2023-07-21 03:37:16 --> Helper loaded: form_helper
INFO - 2023-07-21 03:37:16 --> Helper loaded: lang_helper
INFO - 2023-07-21 03:37:16 --> Helper loaded: security_helper
INFO - 2023-07-21 03:37:16 --> Helper loaded: cookie_helper
INFO - 2023-07-21 03:37:16 --> Database Driver Class Initialized
INFO - 2023-07-21 03:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 03:37:16 --> Parser Class Initialized
INFO - 2023-07-21 03:37:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 03:37:16 --> Pagination Class Initialized
INFO - 2023-07-21 03:37:16 --> Form Validation Class Initialized
INFO - 2023-07-21 03:37:16 --> Controller Class Initialized
INFO - 2023-07-21 03:37:16 --> Model Class Initialized
DEBUG - 2023-07-21 03:37:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 03:37:16 --> Model Class Initialized
INFO - 2023-07-21 03:37:16 --> Final output sent to browser
DEBUG - 2023-07-21 03:37:16 --> Total execution time: 0.0222
ERROR - 2023-07-21 03:37:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 03:37:16 --> Config Class Initialized
INFO - 2023-07-21 03:37:16 --> Hooks Class Initialized
DEBUG - 2023-07-21 03:37:16 --> UTF-8 Support Enabled
INFO - 2023-07-21 03:37:16 --> Utf8 Class Initialized
INFO - 2023-07-21 03:37:16 --> URI Class Initialized
DEBUG - 2023-07-21 03:37:16 --> No URI present. Default controller set.
INFO - 2023-07-21 03:37:16 --> Router Class Initialized
INFO - 2023-07-21 03:37:16 --> Output Class Initialized
INFO - 2023-07-21 03:37:16 --> Security Class Initialized
DEBUG - 2023-07-21 03:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 03:37:16 --> Input Class Initialized
INFO - 2023-07-21 03:37:16 --> Language Class Initialized
INFO - 2023-07-21 03:37:16 --> Loader Class Initialized
INFO - 2023-07-21 03:37:16 --> Helper loaded: url_helper
INFO - 2023-07-21 03:37:16 --> Helper loaded: file_helper
INFO - 2023-07-21 03:37:16 --> Helper loaded: html_helper
INFO - 2023-07-21 03:37:16 --> Helper loaded: text_helper
INFO - 2023-07-21 03:37:16 --> Helper loaded: form_helper
INFO - 2023-07-21 03:37:16 --> Helper loaded: lang_helper
INFO - 2023-07-21 03:37:16 --> Helper loaded: security_helper
INFO - 2023-07-21 03:37:16 --> Helper loaded: cookie_helper
INFO - 2023-07-21 03:37:16 --> Database Driver Class Initialized
INFO - 2023-07-21 03:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 03:37:17 --> Parser Class Initialized
INFO - 2023-07-21 03:37:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 03:37:17 --> Pagination Class Initialized
INFO - 2023-07-21 03:37:17 --> Form Validation Class Initialized
INFO - 2023-07-21 03:37:17 --> Controller Class Initialized
INFO - 2023-07-21 03:37:17 --> Model Class Initialized
DEBUG - 2023-07-21 03:37:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 03:37:17 --> Model Class Initialized
DEBUG - 2023-07-21 03:37:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 03:37:17 --> Model Class Initialized
INFO - 2023-07-21 03:37:17 --> Model Class Initialized
INFO - 2023-07-21 03:37:17 --> Model Class Initialized
INFO - 2023-07-21 03:37:17 --> Model Class Initialized
DEBUG - 2023-07-21 03:37:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 03:37:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 03:37:17 --> Model Class Initialized
INFO - 2023-07-21 03:37:17 --> Model Class Initialized
INFO - 2023-07-21 03:37:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-21 03:37:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 03:37:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 03:37:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 03:37:17 --> Model Class Initialized
INFO - 2023-07-21 03:37:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 03:37:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 03:37:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 03:37:17 --> Final output sent to browser
DEBUG - 2023-07-21 03:37:17 --> Total execution time: 0.1741
ERROR - 2023-07-21 03:37:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 03:37:47 --> Config Class Initialized
INFO - 2023-07-21 03:37:47 --> Hooks Class Initialized
DEBUG - 2023-07-21 03:37:47 --> UTF-8 Support Enabled
INFO - 2023-07-21 03:37:47 --> Utf8 Class Initialized
INFO - 2023-07-21 03:37:47 --> URI Class Initialized
INFO - 2023-07-21 03:37:47 --> Router Class Initialized
INFO - 2023-07-21 03:37:47 --> Output Class Initialized
INFO - 2023-07-21 03:37:47 --> Security Class Initialized
DEBUG - 2023-07-21 03:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 03:37:47 --> Input Class Initialized
INFO - 2023-07-21 03:37:47 --> Language Class Initialized
INFO - 2023-07-21 03:37:47 --> Loader Class Initialized
INFO - 2023-07-21 03:37:47 --> Helper loaded: url_helper
INFO - 2023-07-21 03:37:47 --> Helper loaded: file_helper
INFO - 2023-07-21 03:37:47 --> Helper loaded: html_helper
INFO - 2023-07-21 03:37:47 --> Helper loaded: text_helper
INFO - 2023-07-21 03:37:47 --> Helper loaded: form_helper
INFO - 2023-07-21 03:37:47 --> Helper loaded: lang_helper
INFO - 2023-07-21 03:37:47 --> Helper loaded: security_helper
INFO - 2023-07-21 03:37:47 --> Helper loaded: cookie_helper
INFO - 2023-07-21 03:37:47 --> Database Driver Class Initialized
INFO - 2023-07-21 03:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 03:37:47 --> Parser Class Initialized
INFO - 2023-07-21 03:37:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 03:37:47 --> Pagination Class Initialized
INFO - 2023-07-21 03:37:47 --> Form Validation Class Initialized
INFO - 2023-07-21 03:37:47 --> Controller Class Initialized
INFO - 2023-07-21 03:37:47 --> Model Class Initialized
DEBUG - 2023-07-21 03:37:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 03:37:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 03:37:47 --> Model Class Initialized
DEBUG - 2023-07-21 03:37:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 03:37:47 --> Model Class Initialized
INFO - 2023-07-21 03:37:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-21 03:37:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 03:37:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 03:37:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 03:37:47 --> Model Class Initialized
INFO - 2023-07-21 03:37:47 --> Model Class Initialized
INFO - 2023-07-21 03:37:47 --> Model Class Initialized
INFO - 2023-07-21 03:37:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 03:37:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 03:37:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 03:37:47 --> Final output sent to browser
DEBUG - 2023-07-21 03:37:47 --> Total execution time: 0.0795
ERROR - 2023-07-21 03:37:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 03:37:48 --> Config Class Initialized
INFO - 2023-07-21 03:37:48 --> Hooks Class Initialized
DEBUG - 2023-07-21 03:37:48 --> UTF-8 Support Enabled
INFO - 2023-07-21 03:37:48 --> Utf8 Class Initialized
INFO - 2023-07-21 03:37:48 --> URI Class Initialized
INFO - 2023-07-21 03:37:48 --> Router Class Initialized
INFO - 2023-07-21 03:37:48 --> Output Class Initialized
INFO - 2023-07-21 03:37:48 --> Security Class Initialized
DEBUG - 2023-07-21 03:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 03:37:48 --> Input Class Initialized
INFO - 2023-07-21 03:37:48 --> Language Class Initialized
INFO - 2023-07-21 03:37:48 --> Loader Class Initialized
INFO - 2023-07-21 03:37:48 --> Helper loaded: url_helper
INFO - 2023-07-21 03:37:48 --> Helper loaded: file_helper
INFO - 2023-07-21 03:37:48 --> Helper loaded: html_helper
INFO - 2023-07-21 03:37:48 --> Helper loaded: text_helper
INFO - 2023-07-21 03:37:48 --> Helper loaded: form_helper
INFO - 2023-07-21 03:37:48 --> Helper loaded: lang_helper
INFO - 2023-07-21 03:37:48 --> Helper loaded: security_helper
INFO - 2023-07-21 03:37:48 --> Helper loaded: cookie_helper
INFO - 2023-07-21 03:37:48 --> Database Driver Class Initialized
INFO - 2023-07-21 03:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 03:37:48 --> Parser Class Initialized
INFO - 2023-07-21 03:37:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 03:37:48 --> Pagination Class Initialized
INFO - 2023-07-21 03:37:48 --> Form Validation Class Initialized
INFO - 2023-07-21 03:37:48 --> Controller Class Initialized
INFO - 2023-07-21 03:37:48 --> Model Class Initialized
DEBUG - 2023-07-21 03:37:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 03:37:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 03:37:48 --> Model Class Initialized
DEBUG - 2023-07-21 03:37:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 03:37:48 --> Model Class Initialized
INFO - 2023-07-21 03:37:48 --> Final output sent to browser
DEBUG - 2023-07-21 03:37:48 --> Total execution time: 0.0462
ERROR - 2023-07-21 03:38:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 03:38:24 --> Config Class Initialized
INFO - 2023-07-21 03:38:24 --> Hooks Class Initialized
DEBUG - 2023-07-21 03:38:24 --> UTF-8 Support Enabled
INFO - 2023-07-21 03:38:24 --> Utf8 Class Initialized
INFO - 2023-07-21 03:38:24 --> URI Class Initialized
INFO - 2023-07-21 03:38:24 --> Router Class Initialized
INFO - 2023-07-21 03:38:24 --> Output Class Initialized
INFO - 2023-07-21 03:38:24 --> Security Class Initialized
DEBUG - 2023-07-21 03:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 03:38:24 --> Input Class Initialized
INFO - 2023-07-21 03:38:24 --> Language Class Initialized
INFO - 2023-07-21 03:38:24 --> Loader Class Initialized
INFO - 2023-07-21 03:38:24 --> Helper loaded: url_helper
INFO - 2023-07-21 03:38:24 --> Helper loaded: file_helper
INFO - 2023-07-21 03:38:24 --> Helper loaded: html_helper
INFO - 2023-07-21 03:38:24 --> Helper loaded: text_helper
INFO - 2023-07-21 03:38:24 --> Helper loaded: form_helper
INFO - 2023-07-21 03:38:24 --> Helper loaded: lang_helper
INFO - 2023-07-21 03:38:24 --> Helper loaded: security_helper
INFO - 2023-07-21 03:38:24 --> Helper loaded: cookie_helper
INFO - 2023-07-21 03:38:24 --> Database Driver Class Initialized
INFO - 2023-07-21 03:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 03:38:24 --> Parser Class Initialized
INFO - 2023-07-21 03:38:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 03:38:24 --> Pagination Class Initialized
INFO - 2023-07-21 03:38:24 --> Form Validation Class Initialized
INFO - 2023-07-21 03:38:24 --> Controller Class Initialized
INFO - 2023-07-21 03:38:24 --> Model Class Initialized
DEBUG - 2023-07-21 03:38:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 03:38:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 03:38:24 --> Model Class Initialized
DEBUG - 2023-07-21 03:38:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 03:38:24 --> Model Class Initialized
INFO - 2023-07-21 03:38:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html.php
DEBUG - 2023-07-21 03:38:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 03:38:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 03:38:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 03:38:24 --> Model Class Initialized
INFO - 2023-07-21 03:38:24 --> Model Class Initialized
INFO - 2023-07-21 03:38:24 --> Model Class Initialized
INFO - 2023-07-21 03:38:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 03:38:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 03:38:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 03:38:24 --> Final output sent to browser
DEBUG - 2023-07-21 03:38:24 --> Total execution time: 0.0771
ERROR - 2023-07-21 04:24:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 04:24:35 --> Config Class Initialized
INFO - 2023-07-21 04:24:35 --> Hooks Class Initialized
DEBUG - 2023-07-21 04:24:35 --> UTF-8 Support Enabled
INFO - 2023-07-21 04:24:35 --> Utf8 Class Initialized
INFO - 2023-07-21 04:24:35 --> URI Class Initialized
DEBUG - 2023-07-21 04:24:35 --> No URI present. Default controller set.
INFO - 2023-07-21 04:24:35 --> Router Class Initialized
INFO - 2023-07-21 04:24:35 --> Output Class Initialized
INFO - 2023-07-21 04:24:35 --> Security Class Initialized
DEBUG - 2023-07-21 04:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 04:24:35 --> Input Class Initialized
INFO - 2023-07-21 04:24:35 --> Language Class Initialized
INFO - 2023-07-21 04:24:35 --> Loader Class Initialized
INFO - 2023-07-21 04:24:35 --> Helper loaded: url_helper
INFO - 2023-07-21 04:24:35 --> Helper loaded: file_helper
INFO - 2023-07-21 04:24:35 --> Helper loaded: html_helper
INFO - 2023-07-21 04:24:35 --> Helper loaded: text_helper
INFO - 2023-07-21 04:24:35 --> Helper loaded: form_helper
INFO - 2023-07-21 04:24:35 --> Helper loaded: lang_helper
INFO - 2023-07-21 04:24:35 --> Helper loaded: security_helper
INFO - 2023-07-21 04:24:35 --> Helper loaded: cookie_helper
INFO - 2023-07-21 04:24:35 --> Database Driver Class Initialized
INFO - 2023-07-21 04:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 04:24:35 --> Parser Class Initialized
INFO - 2023-07-21 04:24:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 04:24:35 --> Pagination Class Initialized
INFO - 2023-07-21 04:24:35 --> Form Validation Class Initialized
INFO - 2023-07-21 04:24:35 --> Controller Class Initialized
INFO - 2023-07-21 04:24:35 --> Model Class Initialized
DEBUG - 2023-07-21 04:24:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-21 04:24:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 04:24:35 --> Config Class Initialized
INFO - 2023-07-21 04:24:35 --> Hooks Class Initialized
DEBUG - 2023-07-21 04:24:35 --> UTF-8 Support Enabled
INFO - 2023-07-21 04:24:35 --> Utf8 Class Initialized
INFO - 2023-07-21 04:24:35 --> URI Class Initialized
INFO - 2023-07-21 04:24:35 --> Router Class Initialized
INFO - 2023-07-21 04:24:35 --> Output Class Initialized
INFO - 2023-07-21 04:24:35 --> Security Class Initialized
DEBUG - 2023-07-21 04:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 04:24:35 --> Input Class Initialized
INFO - 2023-07-21 04:24:35 --> Language Class Initialized
INFO - 2023-07-21 04:24:35 --> Loader Class Initialized
INFO - 2023-07-21 04:24:35 --> Helper loaded: url_helper
INFO - 2023-07-21 04:24:35 --> Helper loaded: file_helper
INFO - 2023-07-21 04:24:35 --> Helper loaded: html_helper
INFO - 2023-07-21 04:24:35 --> Helper loaded: text_helper
INFO - 2023-07-21 04:24:35 --> Helper loaded: form_helper
INFO - 2023-07-21 04:24:35 --> Helper loaded: lang_helper
INFO - 2023-07-21 04:24:35 --> Helper loaded: security_helper
INFO - 2023-07-21 04:24:35 --> Helper loaded: cookie_helper
INFO - 2023-07-21 04:24:35 --> Database Driver Class Initialized
INFO - 2023-07-21 04:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 04:24:35 --> Parser Class Initialized
INFO - 2023-07-21 04:24:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 04:24:35 --> Pagination Class Initialized
INFO - 2023-07-21 04:24:35 --> Form Validation Class Initialized
INFO - 2023-07-21 04:24:35 --> Controller Class Initialized
INFO - 2023-07-21 04:24:35 --> Model Class Initialized
DEBUG - 2023-07-21 04:24:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 04:24:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-21 04:24:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 04:24:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 04:24:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 04:24:35 --> Model Class Initialized
INFO - 2023-07-21 04:24:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 04:24:35 --> Final output sent to browser
DEBUG - 2023-07-21 04:24:35 --> Total execution time: 0.0290
ERROR - 2023-07-21 04:24:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 04:24:47 --> Config Class Initialized
INFO - 2023-07-21 04:24:47 --> Hooks Class Initialized
DEBUG - 2023-07-21 04:24:47 --> UTF-8 Support Enabled
INFO - 2023-07-21 04:24:47 --> Utf8 Class Initialized
INFO - 2023-07-21 04:24:47 --> URI Class Initialized
DEBUG - 2023-07-21 04:24:47 --> No URI present. Default controller set.
INFO - 2023-07-21 04:24:47 --> Router Class Initialized
INFO - 2023-07-21 04:24:47 --> Output Class Initialized
INFO - 2023-07-21 04:24:47 --> Security Class Initialized
DEBUG - 2023-07-21 04:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 04:24:47 --> Input Class Initialized
INFO - 2023-07-21 04:24:47 --> Language Class Initialized
INFO - 2023-07-21 04:24:47 --> Loader Class Initialized
INFO - 2023-07-21 04:24:47 --> Helper loaded: url_helper
INFO - 2023-07-21 04:24:47 --> Helper loaded: file_helper
INFO - 2023-07-21 04:24:47 --> Helper loaded: html_helper
INFO - 2023-07-21 04:24:47 --> Helper loaded: text_helper
INFO - 2023-07-21 04:24:47 --> Helper loaded: form_helper
INFO - 2023-07-21 04:24:47 --> Helper loaded: lang_helper
INFO - 2023-07-21 04:24:47 --> Helper loaded: security_helper
INFO - 2023-07-21 04:24:47 --> Helper loaded: cookie_helper
INFO - 2023-07-21 04:24:47 --> Database Driver Class Initialized
INFO - 2023-07-21 04:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 04:24:47 --> Parser Class Initialized
INFO - 2023-07-21 04:24:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 04:24:47 --> Pagination Class Initialized
INFO - 2023-07-21 04:24:47 --> Form Validation Class Initialized
INFO - 2023-07-21 04:24:47 --> Controller Class Initialized
INFO - 2023-07-21 04:24:47 --> Model Class Initialized
DEBUG - 2023-07-21 04:24:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-21 04:24:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 04:24:48 --> Config Class Initialized
INFO - 2023-07-21 04:24:48 --> Hooks Class Initialized
DEBUG - 2023-07-21 04:24:48 --> UTF-8 Support Enabled
INFO - 2023-07-21 04:24:48 --> Utf8 Class Initialized
INFO - 2023-07-21 04:24:48 --> URI Class Initialized
INFO - 2023-07-21 04:24:48 --> Router Class Initialized
INFO - 2023-07-21 04:24:48 --> Output Class Initialized
INFO - 2023-07-21 04:24:48 --> Security Class Initialized
DEBUG - 2023-07-21 04:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 04:24:48 --> Input Class Initialized
INFO - 2023-07-21 04:24:48 --> Language Class Initialized
INFO - 2023-07-21 04:24:48 --> Loader Class Initialized
INFO - 2023-07-21 04:24:48 --> Helper loaded: url_helper
INFO - 2023-07-21 04:24:48 --> Helper loaded: file_helper
INFO - 2023-07-21 04:24:48 --> Helper loaded: html_helper
INFO - 2023-07-21 04:24:48 --> Helper loaded: text_helper
INFO - 2023-07-21 04:24:48 --> Helper loaded: form_helper
INFO - 2023-07-21 04:24:48 --> Helper loaded: lang_helper
INFO - 2023-07-21 04:24:48 --> Helper loaded: security_helper
INFO - 2023-07-21 04:24:48 --> Helper loaded: cookie_helper
INFO - 2023-07-21 04:24:48 --> Database Driver Class Initialized
INFO - 2023-07-21 04:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 04:24:48 --> Parser Class Initialized
INFO - 2023-07-21 04:24:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 04:24:48 --> Pagination Class Initialized
INFO - 2023-07-21 04:24:48 --> Form Validation Class Initialized
INFO - 2023-07-21 04:24:48 --> Controller Class Initialized
INFO - 2023-07-21 04:24:48 --> Model Class Initialized
DEBUG - 2023-07-21 04:24:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 04:24:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-21 04:24:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 04:24:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 04:24:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 04:24:48 --> Model Class Initialized
INFO - 2023-07-21 04:24:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 04:24:48 --> Final output sent to browser
DEBUG - 2023-07-21 04:24:48 --> Total execution time: 0.0277
ERROR - 2023-07-21 04:24:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 04:24:54 --> Config Class Initialized
INFO - 2023-07-21 04:24:54 --> Hooks Class Initialized
DEBUG - 2023-07-21 04:24:54 --> UTF-8 Support Enabled
INFO - 2023-07-21 04:24:54 --> Utf8 Class Initialized
INFO - 2023-07-21 04:24:54 --> URI Class Initialized
INFO - 2023-07-21 04:24:54 --> Router Class Initialized
INFO - 2023-07-21 04:24:54 --> Output Class Initialized
INFO - 2023-07-21 04:24:54 --> Security Class Initialized
DEBUG - 2023-07-21 04:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 04:24:54 --> Input Class Initialized
INFO - 2023-07-21 04:24:54 --> Language Class Initialized
INFO - 2023-07-21 04:24:54 --> Loader Class Initialized
INFO - 2023-07-21 04:24:54 --> Helper loaded: url_helper
INFO - 2023-07-21 04:24:54 --> Helper loaded: file_helper
INFO - 2023-07-21 04:24:54 --> Helper loaded: html_helper
INFO - 2023-07-21 04:24:54 --> Helper loaded: text_helper
INFO - 2023-07-21 04:24:54 --> Helper loaded: form_helper
INFO - 2023-07-21 04:24:54 --> Helper loaded: lang_helper
INFO - 2023-07-21 04:24:54 --> Helper loaded: security_helper
INFO - 2023-07-21 04:24:54 --> Helper loaded: cookie_helper
INFO - 2023-07-21 04:24:54 --> Database Driver Class Initialized
INFO - 2023-07-21 04:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 04:24:54 --> Parser Class Initialized
INFO - 2023-07-21 04:24:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 04:24:54 --> Pagination Class Initialized
INFO - 2023-07-21 04:24:54 --> Form Validation Class Initialized
INFO - 2023-07-21 04:24:54 --> Controller Class Initialized
INFO - 2023-07-21 04:24:54 --> Model Class Initialized
DEBUG - 2023-07-21 04:24:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 04:24:54 --> Model Class Initialized
INFO - 2023-07-21 04:24:54 --> Final output sent to browser
DEBUG - 2023-07-21 04:24:54 --> Total execution time: 0.0172
ERROR - 2023-07-21 04:24:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 04:24:54 --> Config Class Initialized
INFO - 2023-07-21 04:24:54 --> Hooks Class Initialized
DEBUG - 2023-07-21 04:24:54 --> UTF-8 Support Enabled
INFO - 2023-07-21 04:24:54 --> Utf8 Class Initialized
INFO - 2023-07-21 04:24:54 --> URI Class Initialized
DEBUG - 2023-07-21 04:24:54 --> No URI present. Default controller set.
INFO - 2023-07-21 04:24:54 --> Router Class Initialized
INFO - 2023-07-21 04:24:54 --> Output Class Initialized
INFO - 2023-07-21 04:24:54 --> Security Class Initialized
DEBUG - 2023-07-21 04:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 04:24:54 --> Input Class Initialized
INFO - 2023-07-21 04:24:54 --> Language Class Initialized
INFO - 2023-07-21 04:24:54 --> Loader Class Initialized
INFO - 2023-07-21 04:24:54 --> Helper loaded: url_helper
INFO - 2023-07-21 04:24:54 --> Helper loaded: file_helper
INFO - 2023-07-21 04:24:54 --> Helper loaded: html_helper
INFO - 2023-07-21 04:24:54 --> Helper loaded: text_helper
INFO - 2023-07-21 04:24:54 --> Helper loaded: form_helper
INFO - 2023-07-21 04:24:54 --> Helper loaded: lang_helper
INFO - 2023-07-21 04:24:54 --> Helper loaded: security_helper
INFO - 2023-07-21 04:24:54 --> Helper loaded: cookie_helper
INFO - 2023-07-21 04:24:54 --> Database Driver Class Initialized
INFO - 2023-07-21 04:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 04:24:54 --> Parser Class Initialized
INFO - 2023-07-21 04:24:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 04:24:54 --> Pagination Class Initialized
INFO - 2023-07-21 04:24:54 --> Form Validation Class Initialized
INFO - 2023-07-21 04:24:54 --> Controller Class Initialized
INFO - 2023-07-21 04:24:54 --> Model Class Initialized
DEBUG - 2023-07-21 04:24:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 04:24:54 --> Model Class Initialized
DEBUG - 2023-07-21 04:24:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 04:24:54 --> Model Class Initialized
INFO - 2023-07-21 04:24:54 --> Model Class Initialized
INFO - 2023-07-21 04:24:54 --> Model Class Initialized
INFO - 2023-07-21 04:24:54 --> Model Class Initialized
DEBUG - 2023-07-21 04:24:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 04:24:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 04:24:54 --> Model Class Initialized
INFO - 2023-07-21 04:24:54 --> Model Class Initialized
INFO - 2023-07-21 04:24:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-21 04:24:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 04:24:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 04:24:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 04:24:55 --> Model Class Initialized
INFO - 2023-07-21 04:24:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 04:24:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 04:24:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 04:24:55 --> Final output sent to browser
DEBUG - 2023-07-21 04:24:55 --> Total execution time: 0.1883
ERROR - 2023-07-21 04:24:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 04:24:56 --> Config Class Initialized
INFO - 2023-07-21 04:24:56 --> Hooks Class Initialized
DEBUG - 2023-07-21 04:24:56 --> UTF-8 Support Enabled
INFO - 2023-07-21 04:24:56 --> Utf8 Class Initialized
INFO - 2023-07-21 04:24:56 --> URI Class Initialized
INFO - 2023-07-21 04:24:56 --> Router Class Initialized
INFO - 2023-07-21 04:24:56 --> Output Class Initialized
INFO - 2023-07-21 04:24:56 --> Security Class Initialized
DEBUG - 2023-07-21 04:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 04:24:56 --> Input Class Initialized
INFO - 2023-07-21 04:24:56 --> Language Class Initialized
INFO - 2023-07-21 04:24:56 --> Loader Class Initialized
INFO - 2023-07-21 04:24:56 --> Helper loaded: url_helper
INFO - 2023-07-21 04:24:56 --> Helper loaded: file_helper
INFO - 2023-07-21 04:24:56 --> Helper loaded: html_helper
INFO - 2023-07-21 04:24:56 --> Helper loaded: text_helper
INFO - 2023-07-21 04:24:56 --> Helper loaded: form_helper
INFO - 2023-07-21 04:24:56 --> Helper loaded: lang_helper
INFO - 2023-07-21 04:24:56 --> Helper loaded: security_helper
INFO - 2023-07-21 04:24:56 --> Helper loaded: cookie_helper
INFO - 2023-07-21 04:24:56 --> Database Driver Class Initialized
INFO - 2023-07-21 04:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 04:24:56 --> Parser Class Initialized
INFO - 2023-07-21 04:24:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 04:24:56 --> Pagination Class Initialized
INFO - 2023-07-21 04:24:56 --> Form Validation Class Initialized
INFO - 2023-07-21 04:24:56 --> Controller Class Initialized
DEBUG - 2023-07-21 04:24:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 04:24:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 04:24:56 --> Model Class Initialized
INFO - 2023-07-21 04:24:56 --> Final output sent to browser
DEBUG - 2023-07-21 04:24:56 --> Total execution time: 0.0125
ERROR - 2023-07-21 05:38:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 05:38:08 --> Config Class Initialized
INFO - 2023-07-21 05:38:08 --> Hooks Class Initialized
DEBUG - 2023-07-21 05:38:08 --> UTF-8 Support Enabled
INFO - 2023-07-21 05:38:08 --> Utf8 Class Initialized
INFO - 2023-07-21 05:38:08 --> URI Class Initialized
DEBUG - 2023-07-21 05:38:08 --> No URI present. Default controller set.
INFO - 2023-07-21 05:38:08 --> Router Class Initialized
INFO - 2023-07-21 05:38:08 --> Output Class Initialized
INFO - 2023-07-21 05:38:08 --> Security Class Initialized
DEBUG - 2023-07-21 05:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 05:38:08 --> Input Class Initialized
INFO - 2023-07-21 05:38:08 --> Language Class Initialized
INFO - 2023-07-21 05:38:08 --> Loader Class Initialized
INFO - 2023-07-21 05:38:08 --> Helper loaded: url_helper
INFO - 2023-07-21 05:38:08 --> Helper loaded: file_helper
INFO - 2023-07-21 05:38:08 --> Helper loaded: html_helper
INFO - 2023-07-21 05:38:08 --> Helper loaded: text_helper
INFO - 2023-07-21 05:38:08 --> Helper loaded: form_helper
INFO - 2023-07-21 05:38:08 --> Helper loaded: lang_helper
INFO - 2023-07-21 05:38:08 --> Helper loaded: security_helper
INFO - 2023-07-21 05:38:08 --> Helper loaded: cookie_helper
INFO - 2023-07-21 05:38:08 --> Database Driver Class Initialized
INFO - 2023-07-21 05:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 05:38:08 --> Parser Class Initialized
INFO - 2023-07-21 05:38:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 05:38:08 --> Pagination Class Initialized
INFO - 2023-07-21 05:38:08 --> Form Validation Class Initialized
INFO - 2023-07-21 05:38:08 --> Controller Class Initialized
INFO - 2023-07-21 05:38:08 --> Model Class Initialized
DEBUG - 2023-07-21 05:38:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-21 05:38:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 05:38:08 --> Config Class Initialized
INFO - 2023-07-21 05:38:08 --> Hooks Class Initialized
DEBUG - 2023-07-21 05:38:08 --> UTF-8 Support Enabled
INFO - 2023-07-21 05:38:08 --> Utf8 Class Initialized
INFO - 2023-07-21 05:38:08 --> URI Class Initialized
INFO - 2023-07-21 05:38:08 --> Router Class Initialized
INFO - 2023-07-21 05:38:08 --> Output Class Initialized
INFO - 2023-07-21 05:38:08 --> Security Class Initialized
DEBUG - 2023-07-21 05:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 05:38:08 --> Input Class Initialized
INFO - 2023-07-21 05:38:08 --> Language Class Initialized
INFO - 2023-07-21 05:38:08 --> Loader Class Initialized
INFO - 2023-07-21 05:38:08 --> Helper loaded: url_helper
INFO - 2023-07-21 05:38:08 --> Helper loaded: file_helper
INFO - 2023-07-21 05:38:08 --> Helper loaded: html_helper
INFO - 2023-07-21 05:38:08 --> Helper loaded: text_helper
INFO - 2023-07-21 05:38:08 --> Helper loaded: form_helper
INFO - 2023-07-21 05:38:08 --> Helper loaded: lang_helper
INFO - 2023-07-21 05:38:08 --> Helper loaded: security_helper
INFO - 2023-07-21 05:38:08 --> Helper loaded: cookie_helper
INFO - 2023-07-21 05:38:08 --> Database Driver Class Initialized
INFO - 2023-07-21 05:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 05:38:08 --> Parser Class Initialized
INFO - 2023-07-21 05:38:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 05:38:08 --> Pagination Class Initialized
INFO - 2023-07-21 05:38:08 --> Form Validation Class Initialized
INFO - 2023-07-21 05:38:08 --> Controller Class Initialized
INFO - 2023-07-21 05:38:08 --> Model Class Initialized
DEBUG - 2023-07-21 05:38:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 05:38:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-21 05:38:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 05:38:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 05:38:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 05:38:08 --> Model Class Initialized
INFO - 2023-07-21 05:38:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 05:38:08 --> Final output sent to browser
DEBUG - 2023-07-21 05:38:08 --> Total execution time: 0.0300
ERROR - 2023-07-21 16:22:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:22:57 --> Config Class Initialized
INFO - 2023-07-21 16:22:57 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:22:57 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:22:57 --> Utf8 Class Initialized
INFO - 2023-07-21 16:22:57 --> URI Class Initialized
DEBUG - 2023-07-21 16:22:57 --> No URI present. Default controller set.
INFO - 2023-07-21 16:22:57 --> Router Class Initialized
INFO - 2023-07-21 16:22:57 --> Output Class Initialized
INFO - 2023-07-21 16:22:57 --> Security Class Initialized
DEBUG - 2023-07-21 16:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:22:57 --> Input Class Initialized
INFO - 2023-07-21 16:22:57 --> Language Class Initialized
INFO - 2023-07-21 16:22:57 --> Loader Class Initialized
INFO - 2023-07-21 16:22:57 --> Helper loaded: url_helper
INFO - 2023-07-21 16:22:57 --> Helper loaded: file_helper
INFO - 2023-07-21 16:22:57 --> Helper loaded: html_helper
INFO - 2023-07-21 16:22:57 --> Helper loaded: text_helper
INFO - 2023-07-21 16:22:57 --> Helper loaded: form_helper
INFO - 2023-07-21 16:22:57 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:22:57 --> Helper loaded: security_helper
INFO - 2023-07-21 16:22:57 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:22:57 --> Database Driver Class Initialized
INFO - 2023-07-21 16:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:22:57 --> Parser Class Initialized
INFO - 2023-07-21 16:22:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:22:57 --> Pagination Class Initialized
INFO - 2023-07-21 16:22:57 --> Form Validation Class Initialized
INFO - 2023-07-21 16:22:57 --> Controller Class Initialized
INFO - 2023-07-21 16:22:57 --> Model Class Initialized
DEBUG - 2023-07-21 16:22:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-21 16:22:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:22:59 --> Config Class Initialized
INFO - 2023-07-21 16:22:59 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:22:59 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:22:59 --> Utf8 Class Initialized
INFO - 2023-07-21 16:22:59 --> URI Class Initialized
INFO - 2023-07-21 16:22:59 --> Router Class Initialized
INFO - 2023-07-21 16:22:59 --> Output Class Initialized
INFO - 2023-07-21 16:22:59 --> Security Class Initialized
DEBUG - 2023-07-21 16:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:22:59 --> Input Class Initialized
INFO - 2023-07-21 16:22:59 --> Language Class Initialized
INFO - 2023-07-21 16:22:59 --> Loader Class Initialized
INFO - 2023-07-21 16:22:59 --> Helper loaded: url_helper
INFO - 2023-07-21 16:22:59 --> Helper loaded: file_helper
INFO - 2023-07-21 16:22:59 --> Helper loaded: html_helper
INFO - 2023-07-21 16:22:59 --> Helper loaded: text_helper
INFO - 2023-07-21 16:22:59 --> Helper loaded: form_helper
INFO - 2023-07-21 16:22:59 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:22:59 --> Helper loaded: security_helper
INFO - 2023-07-21 16:22:59 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:22:59 --> Database Driver Class Initialized
INFO - 2023-07-21 16:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:22:59 --> Parser Class Initialized
INFO - 2023-07-21 16:22:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:22:59 --> Pagination Class Initialized
INFO - 2023-07-21 16:22:59 --> Form Validation Class Initialized
INFO - 2023-07-21 16:22:59 --> Controller Class Initialized
INFO - 2023-07-21 16:22:59 --> Model Class Initialized
DEBUG - 2023-07-21 16:22:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:22:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-21 16:22:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:22:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:22:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:22:59 --> Model Class Initialized
INFO - 2023-07-21 16:22:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:22:59 --> Final output sent to browser
DEBUG - 2023-07-21 16:22:59 --> Total execution time: 0.0324
ERROR - 2023-07-21 16:23:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:23:30 --> Config Class Initialized
INFO - 2023-07-21 16:23:30 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:23:30 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:23:30 --> Utf8 Class Initialized
INFO - 2023-07-21 16:23:30 --> URI Class Initialized
DEBUG - 2023-07-21 16:23:30 --> No URI present. Default controller set.
INFO - 2023-07-21 16:23:30 --> Router Class Initialized
INFO - 2023-07-21 16:23:30 --> Output Class Initialized
INFO - 2023-07-21 16:23:30 --> Security Class Initialized
DEBUG - 2023-07-21 16:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:23:30 --> Input Class Initialized
INFO - 2023-07-21 16:23:30 --> Language Class Initialized
INFO - 2023-07-21 16:23:30 --> Loader Class Initialized
INFO - 2023-07-21 16:23:30 --> Helper loaded: url_helper
INFO - 2023-07-21 16:23:30 --> Helper loaded: file_helper
INFO - 2023-07-21 16:23:30 --> Helper loaded: html_helper
INFO - 2023-07-21 16:23:30 --> Helper loaded: text_helper
INFO - 2023-07-21 16:23:30 --> Helper loaded: form_helper
INFO - 2023-07-21 16:23:30 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:23:30 --> Helper loaded: security_helper
INFO - 2023-07-21 16:23:30 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:23:30 --> Database Driver Class Initialized
INFO - 2023-07-21 16:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:23:30 --> Parser Class Initialized
INFO - 2023-07-21 16:23:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:23:30 --> Pagination Class Initialized
INFO - 2023-07-21 16:23:30 --> Form Validation Class Initialized
INFO - 2023-07-21 16:23:30 --> Controller Class Initialized
INFO - 2023-07-21 16:23:30 --> Model Class Initialized
DEBUG - 2023-07-21 16:23:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-21 16:23:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:23:31 --> Config Class Initialized
INFO - 2023-07-21 16:23:31 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:23:31 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:23:31 --> Utf8 Class Initialized
INFO - 2023-07-21 16:23:31 --> URI Class Initialized
INFO - 2023-07-21 16:23:31 --> Router Class Initialized
INFO - 2023-07-21 16:23:31 --> Output Class Initialized
INFO - 2023-07-21 16:23:31 --> Security Class Initialized
DEBUG - 2023-07-21 16:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:23:31 --> Input Class Initialized
INFO - 2023-07-21 16:23:31 --> Language Class Initialized
INFO - 2023-07-21 16:23:31 --> Loader Class Initialized
INFO - 2023-07-21 16:23:31 --> Helper loaded: url_helper
INFO - 2023-07-21 16:23:31 --> Helper loaded: file_helper
INFO - 2023-07-21 16:23:31 --> Helper loaded: html_helper
INFO - 2023-07-21 16:23:31 --> Helper loaded: text_helper
INFO - 2023-07-21 16:23:31 --> Helper loaded: form_helper
INFO - 2023-07-21 16:23:31 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:23:31 --> Helper loaded: security_helper
INFO - 2023-07-21 16:23:31 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:23:31 --> Database Driver Class Initialized
INFO - 2023-07-21 16:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:23:31 --> Parser Class Initialized
INFO - 2023-07-21 16:23:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:23:31 --> Pagination Class Initialized
INFO - 2023-07-21 16:23:31 --> Form Validation Class Initialized
INFO - 2023-07-21 16:23:31 --> Controller Class Initialized
INFO - 2023-07-21 16:23:31 --> Model Class Initialized
DEBUG - 2023-07-21 16:23:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:23:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-21 16:23:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:23:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:23:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:23:31 --> Model Class Initialized
INFO - 2023-07-21 16:23:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:23:31 --> Final output sent to browser
DEBUG - 2023-07-21 16:23:31 --> Total execution time: 0.0332
ERROR - 2023-07-21 16:24:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:24:06 --> Config Class Initialized
INFO - 2023-07-21 16:24:06 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:24:06 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:24:06 --> Utf8 Class Initialized
INFO - 2023-07-21 16:24:06 --> URI Class Initialized
INFO - 2023-07-21 16:24:06 --> Router Class Initialized
INFO - 2023-07-21 16:24:06 --> Output Class Initialized
INFO - 2023-07-21 16:24:06 --> Security Class Initialized
DEBUG - 2023-07-21 16:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:24:06 --> Input Class Initialized
INFO - 2023-07-21 16:24:06 --> Language Class Initialized
INFO - 2023-07-21 16:24:06 --> Loader Class Initialized
INFO - 2023-07-21 16:24:06 --> Helper loaded: url_helper
INFO - 2023-07-21 16:24:06 --> Helper loaded: file_helper
INFO - 2023-07-21 16:24:06 --> Helper loaded: html_helper
INFO - 2023-07-21 16:24:06 --> Helper loaded: text_helper
INFO - 2023-07-21 16:24:06 --> Helper loaded: form_helper
INFO - 2023-07-21 16:24:06 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:24:06 --> Helper loaded: security_helper
INFO - 2023-07-21 16:24:06 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:24:06 --> Database Driver Class Initialized
INFO - 2023-07-21 16:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:24:06 --> Parser Class Initialized
INFO - 2023-07-21 16:24:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:24:06 --> Pagination Class Initialized
INFO - 2023-07-21 16:24:06 --> Form Validation Class Initialized
INFO - 2023-07-21 16:24:06 --> Controller Class Initialized
INFO - 2023-07-21 16:24:06 --> Model Class Initialized
DEBUG - 2023-07-21 16:24:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:24:06 --> Model Class Initialized
INFO - 2023-07-21 16:24:06 --> Final output sent to browser
DEBUG - 2023-07-21 16:24:06 --> Total execution time: 0.0202
ERROR - 2023-07-21 16:24:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:24:06 --> Config Class Initialized
INFO - 2023-07-21 16:24:06 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:24:06 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:24:06 --> Utf8 Class Initialized
INFO - 2023-07-21 16:24:06 --> URI Class Initialized
DEBUG - 2023-07-21 16:24:06 --> No URI present. Default controller set.
INFO - 2023-07-21 16:24:06 --> Router Class Initialized
INFO - 2023-07-21 16:24:06 --> Output Class Initialized
INFO - 2023-07-21 16:24:06 --> Security Class Initialized
DEBUG - 2023-07-21 16:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:24:06 --> Input Class Initialized
INFO - 2023-07-21 16:24:06 --> Language Class Initialized
INFO - 2023-07-21 16:24:06 --> Loader Class Initialized
INFO - 2023-07-21 16:24:06 --> Helper loaded: url_helper
INFO - 2023-07-21 16:24:06 --> Helper loaded: file_helper
INFO - 2023-07-21 16:24:06 --> Helper loaded: html_helper
INFO - 2023-07-21 16:24:06 --> Helper loaded: text_helper
INFO - 2023-07-21 16:24:06 --> Helper loaded: form_helper
INFO - 2023-07-21 16:24:06 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:24:06 --> Helper loaded: security_helper
INFO - 2023-07-21 16:24:06 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:24:06 --> Database Driver Class Initialized
INFO - 2023-07-21 16:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:24:06 --> Parser Class Initialized
INFO - 2023-07-21 16:24:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:24:06 --> Pagination Class Initialized
INFO - 2023-07-21 16:24:06 --> Form Validation Class Initialized
INFO - 2023-07-21 16:24:06 --> Controller Class Initialized
INFO - 2023-07-21 16:24:06 --> Model Class Initialized
DEBUG - 2023-07-21 16:24:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:24:06 --> Model Class Initialized
DEBUG - 2023-07-21 16:24:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:24:06 --> Model Class Initialized
INFO - 2023-07-21 16:24:06 --> Model Class Initialized
INFO - 2023-07-21 16:24:06 --> Model Class Initialized
INFO - 2023-07-21 16:24:06 --> Model Class Initialized
DEBUG - 2023-07-21 16:24:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:24:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:24:06 --> Model Class Initialized
INFO - 2023-07-21 16:24:06 --> Model Class Initialized
INFO - 2023-07-21 16:24:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-21 16:24:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:24:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:24:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:24:06 --> Model Class Initialized
INFO - 2023-07-21 16:24:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 16:24:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 16:24:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:24:06 --> Final output sent to browser
DEBUG - 2023-07-21 16:24:06 --> Total execution time: 0.1713
ERROR - 2023-07-21 16:24:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:24:07 --> Config Class Initialized
INFO - 2023-07-21 16:24:07 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:24:07 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:24:07 --> Utf8 Class Initialized
INFO - 2023-07-21 16:24:07 --> URI Class Initialized
INFO - 2023-07-21 16:24:07 --> Router Class Initialized
INFO - 2023-07-21 16:24:07 --> Output Class Initialized
INFO - 2023-07-21 16:24:07 --> Security Class Initialized
DEBUG - 2023-07-21 16:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:24:07 --> Input Class Initialized
INFO - 2023-07-21 16:24:07 --> Language Class Initialized
INFO - 2023-07-21 16:24:07 --> Loader Class Initialized
INFO - 2023-07-21 16:24:07 --> Helper loaded: url_helper
INFO - 2023-07-21 16:24:07 --> Helper loaded: file_helper
INFO - 2023-07-21 16:24:07 --> Helper loaded: html_helper
INFO - 2023-07-21 16:24:07 --> Helper loaded: text_helper
INFO - 2023-07-21 16:24:07 --> Helper loaded: form_helper
INFO - 2023-07-21 16:24:07 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:24:07 --> Helper loaded: security_helper
INFO - 2023-07-21 16:24:07 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:24:07 --> Database Driver Class Initialized
INFO - 2023-07-21 16:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:24:07 --> Parser Class Initialized
INFO - 2023-07-21 16:24:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:24:07 --> Pagination Class Initialized
INFO - 2023-07-21 16:24:07 --> Form Validation Class Initialized
INFO - 2023-07-21 16:24:07 --> Controller Class Initialized
DEBUG - 2023-07-21 16:24:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:24:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:24:07 --> Model Class Initialized
INFO - 2023-07-21 16:24:07 --> Final output sent to browser
DEBUG - 2023-07-21 16:24:07 --> Total execution time: 0.0155
ERROR - 2023-07-21 16:24:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:24:33 --> Config Class Initialized
INFO - 2023-07-21 16:24:33 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:24:33 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:24:33 --> Utf8 Class Initialized
INFO - 2023-07-21 16:24:33 --> URI Class Initialized
INFO - 2023-07-21 16:24:33 --> Router Class Initialized
INFO - 2023-07-21 16:24:33 --> Output Class Initialized
INFO - 2023-07-21 16:24:33 --> Security Class Initialized
DEBUG - 2023-07-21 16:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:24:33 --> Input Class Initialized
INFO - 2023-07-21 16:24:33 --> Language Class Initialized
INFO - 2023-07-21 16:24:33 --> Loader Class Initialized
INFO - 2023-07-21 16:24:33 --> Helper loaded: url_helper
INFO - 2023-07-21 16:24:33 --> Helper loaded: file_helper
INFO - 2023-07-21 16:24:33 --> Helper loaded: html_helper
INFO - 2023-07-21 16:24:33 --> Helper loaded: text_helper
INFO - 2023-07-21 16:24:33 --> Helper loaded: form_helper
INFO - 2023-07-21 16:24:33 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:24:33 --> Helper loaded: security_helper
INFO - 2023-07-21 16:24:33 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:24:33 --> Database Driver Class Initialized
INFO - 2023-07-21 16:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:24:33 --> Parser Class Initialized
INFO - 2023-07-21 16:24:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:24:33 --> Pagination Class Initialized
INFO - 2023-07-21 16:24:33 --> Form Validation Class Initialized
INFO - 2023-07-21 16:24:33 --> Controller Class Initialized
INFO - 2023-07-21 16:24:33 --> Model Class Initialized
DEBUG - 2023-07-21 16:24:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:24:33 --> Model Class Initialized
INFO - 2023-07-21 16:24:33 --> Final output sent to browser
DEBUG - 2023-07-21 16:24:33 --> Total execution time: 0.0184
ERROR - 2023-07-21 16:24:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:24:35 --> Config Class Initialized
INFO - 2023-07-21 16:24:35 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:24:35 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:24:35 --> Utf8 Class Initialized
INFO - 2023-07-21 16:24:35 --> URI Class Initialized
INFO - 2023-07-21 16:24:35 --> Router Class Initialized
INFO - 2023-07-21 16:24:35 --> Output Class Initialized
INFO - 2023-07-21 16:24:35 --> Security Class Initialized
DEBUG - 2023-07-21 16:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:24:35 --> Input Class Initialized
INFO - 2023-07-21 16:24:35 --> Language Class Initialized
INFO - 2023-07-21 16:24:35 --> Loader Class Initialized
INFO - 2023-07-21 16:24:35 --> Helper loaded: url_helper
INFO - 2023-07-21 16:24:35 --> Helper loaded: file_helper
INFO - 2023-07-21 16:24:35 --> Helper loaded: html_helper
INFO - 2023-07-21 16:24:35 --> Helper loaded: text_helper
INFO - 2023-07-21 16:24:35 --> Helper loaded: form_helper
INFO - 2023-07-21 16:24:35 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:24:35 --> Helper loaded: security_helper
INFO - 2023-07-21 16:24:35 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:24:35 --> Database Driver Class Initialized
INFO - 2023-07-21 16:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:24:35 --> Parser Class Initialized
INFO - 2023-07-21 16:24:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:24:35 --> Pagination Class Initialized
INFO - 2023-07-21 16:24:35 --> Form Validation Class Initialized
INFO - 2023-07-21 16:24:35 --> Controller Class Initialized
INFO - 2023-07-21 16:24:35 --> Model Class Initialized
DEBUG - 2023-07-21 16:24:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:24:35 --> Model Class Initialized
INFO - 2023-07-21 16:24:35 --> Final output sent to browser
DEBUG - 2023-07-21 16:24:35 --> Total execution time: 0.0155
ERROR - 2023-07-21 16:24:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:24:35 --> Config Class Initialized
INFO - 2023-07-21 16:24:35 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:24:35 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:24:35 --> Utf8 Class Initialized
INFO - 2023-07-21 16:24:35 --> URI Class Initialized
DEBUG - 2023-07-21 16:24:35 --> No URI present. Default controller set.
INFO - 2023-07-21 16:24:35 --> Router Class Initialized
INFO - 2023-07-21 16:24:35 --> Output Class Initialized
INFO - 2023-07-21 16:24:35 --> Security Class Initialized
DEBUG - 2023-07-21 16:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:24:35 --> Input Class Initialized
INFO - 2023-07-21 16:24:35 --> Language Class Initialized
INFO - 2023-07-21 16:24:35 --> Loader Class Initialized
INFO - 2023-07-21 16:24:35 --> Helper loaded: url_helper
INFO - 2023-07-21 16:24:35 --> Helper loaded: file_helper
INFO - 2023-07-21 16:24:35 --> Helper loaded: html_helper
INFO - 2023-07-21 16:24:35 --> Helper loaded: text_helper
INFO - 2023-07-21 16:24:35 --> Helper loaded: form_helper
INFO - 2023-07-21 16:24:35 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:24:35 --> Helper loaded: security_helper
INFO - 2023-07-21 16:24:35 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:24:35 --> Database Driver Class Initialized
INFO - 2023-07-21 16:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:24:35 --> Parser Class Initialized
INFO - 2023-07-21 16:24:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:24:35 --> Pagination Class Initialized
INFO - 2023-07-21 16:24:35 --> Form Validation Class Initialized
INFO - 2023-07-21 16:24:35 --> Controller Class Initialized
INFO - 2023-07-21 16:24:35 --> Model Class Initialized
DEBUG - 2023-07-21 16:24:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:24:35 --> Model Class Initialized
DEBUG - 2023-07-21 16:24:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:24:35 --> Model Class Initialized
INFO - 2023-07-21 16:24:35 --> Model Class Initialized
INFO - 2023-07-21 16:24:35 --> Model Class Initialized
INFO - 2023-07-21 16:24:35 --> Model Class Initialized
DEBUG - 2023-07-21 16:24:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:24:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:24:35 --> Model Class Initialized
INFO - 2023-07-21 16:24:35 --> Model Class Initialized
INFO - 2023-07-21 16:24:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-21 16:24:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:24:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:24:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:24:35 --> Model Class Initialized
INFO - 2023-07-21 16:24:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 16:24:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 16:24:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:24:35 --> Final output sent to browser
DEBUG - 2023-07-21 16:24:35 --> Total execution time: 0.1804
ERROR - 2023-07-21 16:25:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:25:43 --> Config Class Initialized
INFO - 2023-07-21 16:25:43 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:25:43 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:25:43 --> Utf8 Class Initialized
INFO - 2023-07-21 16:25:43 --> URI Class Initialized
INFO - 2023-07-21 16:25:43 --> Router Class Initialized
INFO - 2023-07-21 16:25:43 --> Output Class Initialized
INFO - 2023-07-21 16:25:43 --> Security Class Initialized
DEBUG - 2023-07-21 16:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:25:43 --> Input Class Initialized
INFO - 2023-07-21 16:25:43 --> Language Class Initialized
INFO - 2023-07-21 16:25:43 --> Loader Class Initialized
INFO - 2023-07-21 16:25:43 --> Helper loaded: url_helper
INFO - 2023-07-21 16:25:43 --> Helper loaded: file_helper
INFO - 2023-07-21 16:25:43 --> Helper loaded: html_helper
INFO - 2023-07-21 16:25:43 --> Helper loaded: text_helper
INFO - 2023-07-21 16:25:43 --> Helper loaded: form_helper
INFO - 2023-07-21 16:25:43 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:25:43 --> Helper loaded: security_helper
INFO - 2023-07-21 16:25:43 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:25:43 --> Database Driver Class Initialized
INFO - 2023-07-21 16:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:25:43 --> Parser Class Initialized
INFO - 2023-07-21 16:25:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:25:43 --> Pagination Class Initialized
INFO - 2023-07-21 16:25:43 --> Form Validation Class Initialized
INFO - 2023-07-21 16:25:43 --> Controller Class Initialized
DEBUG - 2023-07-21 16:25:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:25:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:25:43 --> Model Class Initialized
INFO - 2023-07-21 16:25:43 --> Final output sent to browser
DEBUG - 2023-07-21 16:25:43 --> Total execution time: 0.0138
ERROR - 2023-07-21 16:25:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:25:55 --> Config Class Initialized
INFO - 2023-07-21 16:25:55 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:25:55 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:25:55 --> Utf8 Class Initialized
INFO - 2023-07-21 16:25:55 --> URI Class Initialized
INFO - 2023-07-21 16:25:55 --> Router Class Initialized
INFO - 2023-07-21 16:25:55 --> Output Class Initialized
INFO - 2023-07-21 16:25:55 --> Security Class Initialized
DEBUG - 2023-07-21 16:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:25:55 --> Input Class Initialized
INFO - 2023-07-21 16:25:55 --> Language Class Initialized
INFO - 2023-07-21 16:25:55 --> Loader Class Initialized
INFO - 2023-07-21 16:25:55 --> Helper loaded: url_helper
INFO - 2023-07-21 16:25:55 --> Helper loaded: file_helper
INFO - 2023-07-21 16:25:55 --> Helper loaded: html_helper
INFO - 2023-07-21 16:25:55 --> Helper loaded: text_helper
INFO - 2023-07-21 16:25:55 --> Helper loaded: form_helper
INFO - 2023-07-21 16:25:55 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:25:55 --> Helper loaded: security_helper
INFO - 2023-07-21 16:25:55 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:25:55 --> Database Driver Class Initialized
INFO - 2023-07-21 16:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:25:55 --> Parser Class Initialized
INFO - 2023-07-21 16:25:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:25:55 --> Pagination Class Initialized
INFO - 2023-07-21 16:25:55 --> Form Validation Class Initialized
INFO - 2023-07-21 16:25:55 --> Controller Class Initialized
DEBUG - 2023-07-21 16:25:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:25:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:25:55 --> Model Class Initialized
DEBUG - 2023-07-21 16:25:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:25:55 --> Model Class Initialized
DEBUG - 2023-07-21 16:25:55 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:25:55 --> Model Class Initialized
INFO - 2023-07-21 16:25:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-07-21 16:25:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:25:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:25:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:25:55 --> Model Class Initialized
INFO - 2023-07-21 16:25:55 --> Model Class Initialized
INFO - 2023-07-21 16:25:55 --> Model Class Initialized
INFO - 2023-07-21 16:25:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 16:25:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 16:25:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:25:56 --> Final output sent to browser
DEBUG - 2023-07-21 16:25:56 --> Total execution time: 0.1370
ERROR - 2023-07-21 16:25:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:25:56 --> Config Class Initialized
INFO - 2023-07-21 16:25:56 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:25:56 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:25:56 --> Utf8 Class Initialized
INFO - 2023-07-21 16:25:56 --> URI Class Initialized
INFO - 2023-07-21 16:25:56 --> Router Class Initialized
INFO - 2023-07-21 16:25:56 --> Output Class Initialized
INFO - 2023-07-21 16:25:56 --> Security Class Initialized
DEBUG - 2023-07-21 16:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:25:56 --> Input Class Initialized
INFO - 2023-07-21 16:25:56 --> Language Class Initialized
INFO - 2023-07-21 16:25:56 --> Loader Class Initialized
INFO - 2023-07-21 16:25:56 --> Helper loaded: url_helper
INFO - 2023-07-21 16:25:56 --> Helper loaded: file_helper
INFO - 2023-07-21 16:25:56 --> Helper loaded: html_helper
INFO - 2023-07-21 16:25:56 --> Helper loaded: text_helper
INFO - 2023-07-21 16:25:56 --> Helper loaded: form_helper
INFO - 2023-07-21 16:25:56 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:25:56 --> Helper loaded: security_helper
INFO - 2023-07-21 16:25:56 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:25:56 --> Database Driver Class Initialized
INFO - 2023-07-21 16:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:25:56 --> Parser Class Initialized
INFO - 2023-07-21 16:25:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:25:56 --> Pagination Class Initialized
INFO - 2023-07-21 16:25:56 --> Form Validation Class Initialized
INFO - 2023-07-21 16:25:56 --> Controller Class Initialized
DEBUG - 2023-07-21 16:25:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:25:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:25:56 --> Model Class Initialized
DEBUG - 2023-07-21 16:25:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:25:56 --> Model Class Initialized
INFO - 2023-07-21 16:25:56 --> Final output sent to browser
DEBUG - 2023-07-21 16:25:56 --> Total execution time: 0.0306
ERROR - 2023-07-21 16:26:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:26:01 --> Config Class Initialized
INFO - 2023-07-21 16:26:01 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:26:01 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:26:01 --> Utf8 Class Initialized
INFO - 2023-07-21 16:26:01 --> URI Class Initialized
INFO - 2023-07-21 16:26:01 --> Router Class Initialized
INFO - 2023-07-21 16:26:01 --> Output Class Initialized
INFO - 2023-07-21 16:26:01 --> Security Class Initialized
DEBUG - 2023-07-21 16:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:26:01 --> Input Class Initialized
INFO - 2023-07-21 16:26:01 --> Language Class Initialized
INFO - 2023-07-21 16:26:01 --> Loader Class Initialized
INFO - 2023-07-21 16:26:01 --> Helper loaded: url_helper
INFO - 2023-07-21 16:26:01 --> Helper loaded: file_helper
INFO - 2023-07-21 16:26:01 --> Helper loaded: html_helper
INFO - 2023-07-21 16:26:01 --> Helper loaded: text_helper
INFO - 2023-07-21 16:26:01 --> Helper loaded: form_helper
INFO - 2023-07-21 16:26:01 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:26:01 --> Helper loaded: security_helper
INFO - 2023-07-21 16:26:01 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:26:01 --> Database Driver Class Initialized
INFO - 2023-07-21 16:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:26:01 --> Parser Class Initialized
INFO - 2023-07-21 16:26:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:26:01 --> Pagination Class Initialized
INFO - 2023-07-21 16:26:01 --> Form Validation Class Initialized
INFO - 2023-07-21 16:26:01 --> Controller Class Initialized
DEBUG - 2023-07-21 16:26:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:26:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:26:01 --> Model Class Initialized
DEBUG - 2023-07-21 16:26:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:26:01 --> Model Class Initialized
INFO - 2023-07-21 16:26:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/view_customer.php
DEBUG - 2023-07-21 16:26:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:26:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:26:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:26:01 --> Model Class Initialized
INFO - 2023-07-21 16:26:01 --> Model Class Initialized
INFO - 2023-07-21 16:26:01 --> Model Class Initialized
INFO - 2023-07-21 16:26:01 --> Model Class Initialized
INFO - 2023-07-21 16:26:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 16:26:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 16:26:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:26:01 --> Final output sent to browser
DEBUG - 2023-07-21 16:26:01 --> Total execution time: 0.1443
ERROR - 2023-07-21 16:26:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:26:14 --> Config Class Initialized
INFO - 2023-07-21 16:26:14 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:26:14 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:26:14 --> Utf8 Class Initialized
INFO - 2023-07-21 16:26:14 --> URI Class Initialized
DEBUG - 2023-07-21 16:26:14 --> No URI present. Default controller set.
INFO - 2023-07-21 16:26:14 --> Router Class Initialized
INFO - 2023-07-21 16:26:14 --> Output Class Initialized
INFO - 2023-07-21 16:26:14 --> Security Class Initialized
DEBUG - 2023-07-21 16:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:26:14 --> Input Class Initialized
INFO - 2023-07-21 16:26:14 --> Language Class Initialized
INFO - 2023-07-21 16:26:14 --> Loader Class Initialized
INFO - 2023-07-21 16:26:14 --> Helper loaded: url_helper
INFO - 2023-07-21 16:26:14 --> Helper loaded: file_helper
INFO - 2023-07-21 16:26:14 --> Helper loaded: html_helper
INFO - 2023-07-21 16:26:14 --> Helper loaded: text_helper
INFO - 2023-07-21 16:26:14 --> Helper loaded: form_helper
INFO - 2023-07-21 16:26:14 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:26:14 --> Helper loaded: security_helper
INFO - 2023-07-21 16:26:14 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:26:14 --> Database Driver Class Initialized
INFO - 2023-07-21 16:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:26:14 --> Parser Class Initialized
INFO - 2023-07-21 16:26:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:26:14 --> Pagination Class Initialized
INFO - 2023-07-21 16:26:14 --> Form Validation Class Initialized
INFO - 2023-07-21 16:26:14 --> Controller Class Initialized
INFO - 2023-07-21 16:26:14 --> Model Class Initialized
DEBUG - 2023-07-21 16:26:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-21 16:26:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:26:15 --> Config Class Initialized
INFO - 2023-07-21 16:26:15 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:26:15 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:26:15 --> Utf8 Class Initialized
INFO - 2023-07-21 16:26:15 --> URI Class Initialized
INFO - 2023-07-21 16:26:15 --> Router Class Initialized
INFO - 2023-07-21 16:26:15 --> Output Class Initialized
INFO - 2023-07-21 16:26:15 --> Security Class Initialized
DEBUG - 2023-07-21 16:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:26:15 --> Input Class Initialized
INFO - 2023-07-21 16:26:15 --> Language Class Initialized
INFO - 2023-07-21 16:26:15 --> Loader Class Initialized
INFO - 2023-07-21 16:26:15 --> Helper loaded: url_helper
INFO - 2023-07-21 16:26:15 --> Helper loaded: file_helper
INFO - 2023-07-21 16:26:15 --> Helper loaded: html_helper
INFO - 2023-07-21 16:26:15 --> Helper loaded: text_helper
INFO - 2023-07-21 16:26:15 --> Helper loaded: form_helper
INFO - 2023-07-21 16:26:15 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:26:15 --> Helper loaded: security_helper
INFO - 2023-07-21 16:26:15 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:26:15 --> Database Driver Class Initialized
INFO - 2023-07-21 16:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:26:15 --> Parser Class Initialized
INFO - 2023-07-21 16:26:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:26:15 --> Pagination Class Initialized
INFO - 2023-07-21 16:26:15 --> Form Validation Class Initialized
INFO - 2023-07-21 16:26:15 --> Controller Class Initialized
INFO - 2023-07-21 16:26:15 --> Model Class Initialized
DEBUG - 2023-07-21 16:26:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:26:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-21 16:26:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:26:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:26:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:26:15 --> Model Class Initialized
INFO - 2023-07-21 16:26:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:26:15 --> Final output sent to browser
DEBUG - 2023-07-21 16:26:15 --> Total execution time: 0.0264
ERROR - 2023-07-21 16:26:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:26:46 --> Config Class Initialized
INFO - 2023-07-21 16:26:46 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:26:46 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:26:46 --> Utf8 Class Initialized
INFO - 2023-07-21 16:26:46 --> URI Class Initialized
INFO - 2023-07-21 16:26:46 --> Router Class Initialized
INFO - 2023-07-21 16:26:46 --> Output Class Initialized
INFO - 2023-07-21 16:26:46 --> Security Class Initialized
DEBUG - 2023-07-21 16:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:26:46 --> Input Class Initialized
INFO - 2023-07-21 16:26:46 --> Language Class Initialized
INFO - 2023-07-21 16:26:46 --> Loader Class Initialized
INFO - 2023-07-21 16:26:46 --> Helper loaded: url_helper
INFO - 2023-07-21 16:26:46 --> Helper loaded: file_helper
INFO - 2023-07-21 16:26:46 --> Helper loaded: html_helper
INFO - 2023-07-21 16:26:46 --> Helper loaded: text_helper
INFO - 2023-07-21 16:26:46 --> Helper loaded: form_helper
INFO - 2023-07-21 16:26:46 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:26:46 --> Helper loaded: security_helper
INFO - 2023-07-21 16:26:46 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:26:46 --> Database Driver Class Initialized
INFO - 2023-07-21 16:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:26:46 --> Parser Class Initialized
INFO - 2023-07-21 16:26:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:26:46 --> Pagination Class Initialized
INFO - 2023-07-21 16:26:46 --> Form Validation Class Initialized
INFO - 2023-07-21 16:26:46 --> Controller Class Initialized
INFO - 2023-07-21 16:26:46 --> Model Class Initialized
DEBUG - 2023-07-21 16:26:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:26:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:26:46 --> Model Class Initialized
DEBUG - 2023-07-21 16:26:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:26:46 --> Model Class Initialized
INFO - 2023-07-21 16:26:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-21 16:26:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:26:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:26:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:26:46 --> Model Class Initialized
INFO - 2023-07-21 16:26:46 --> Model Class Initialized
INFO - 2023-07-21 16:26:46 --> Model Class Initialized
INFO - 2023-07-21 16:26:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 16:26:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 16:26:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:26:46 --> Final output sent to browser
DEBUG - 2023-07-21 16:26:46 --> Total execution time: 0.1566
ERROR - 2023-07-21 16:26:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:26:46 --> Config Class Initialized
INFO - 2023-07-21 16:26:46 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:26:46 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:26:46 --> Utf8 Class Initialized
INFO - 2023-07-21 16:26:46 --> URI Class Initialized
INFO - 2023-07-21 16:26:46 --> Router Class Initialized
INFO - 2023-07-21 16:26:46 --> Output Class Initialized
INFO - 2023-07-21 16:26:46 --> Security Class Initialized
DEBUG - 2023-07-21 16:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:26:46 --> Input Class Initialized
INFO - 2023-07-21 16:26:46 --> Language Class Initialized
INFO - 2023-07-21 16:26:46 --> Loader Class Initialized
INFO - 2023-07-21 16:26:46 --> Helper loaded: url_helper
INFO - 2023-07-21 16:26:46 --> Helper loaded: file_helper
INFO - 2023-07-21 16:26:46 --> Helper loaded: html_helper
INFO - 2023-07-21 16:26:46 --> Helper loaded: text_helper
INFO - 2023-07-21 16:26:46 --> Helper loaded: form_helper
INFO - 2023-07-21 16:26:46 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:26:46 --> Helper loaded: security_helper
INFO - 2023-07-21 16:26:46 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:26:46 --> Database Driver Class Initialized
INFO - 2023-07-21 16:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:26:46 --> Parser Class Initialized
INFO - 2023-07-21 16:26:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:26:46 --> Pagination Class Initialized
INFO - 2023-07-21 16:26:46 --> Form Validation Class Initialized
INFO - 2023-07-21 16:26:46 --> Controller Class Initialized
INFO - 2023-07-21 16:26:46 --> Model Class Initialized
DEBUG - 2023-07-21 16:26:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:26:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:26:46 --> Model Class Initialized
DEBUG - 2023-07-21 16:26:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:26:46 --> Model Class Initialized
INFO - 2023-07-21 16:26:46 --> Final output sent to browser
DEBUG - 2023-07-21 16:26:46 --> Total execution time: 0.0527
ERROR - 2023-07-21 16:26:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:26:55 --> Config Class Initialized
INFO - 2023-07-21 16:26:55 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:26:55 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:26:55 --> Utf8 Class Initialized
INFO - 2023-07-21 16:26:55 --> URI Class Initialized
INFO - 2023-07-21 16:26:55 --> Router Class Initialized
INFO - 2023-07-21 16:26:55 --> Output Class Initialized
INFO - 2023-07-21 16:26:55 --> Security Class Initialized
DEBUG - 2023-07-21 16:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:26:55 --> Input Class Initialized
INFO - 2023-07-21 16:26:55 --> Language Class Initialized
INFO - 2023-07-21 16:26:55 --> Loader Class Initialized
INFO - 2023-07-21 16:26:55 --> Helper loaded: url_helper
INFO - 2023-07-21 16:26:55 --> Helper loaded: file_helper
INFO - 2023-07-21 16:26:55 --> Helper loaded: html_helper
INFO - 2023-07-21 16:26:55 --> Helper loaded: text_helper
INFO - 2023-07-21 16:26:55 --> Helper loaded: form_helper
INFO - 2023-07-21 16:26:55 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:26:55 --> Helper loaded: security_helper
INFO - 2023-07-21 16:26:55 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:26:55 --> Database Driver Class Initialized
INFO - 2023-07-21 16:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:26:55 --> Parser Class Initialized
INFO - 2023-07-21 16:26:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:26:55 --> Pagination Class Initialized
INFO - 2023-07-21 16:26:55 --> Form Validation Class Initialized
INFO - 2023-07-21 16:26:55 --> Controller Class Initialized
DEBUG - 2023-07-21 16:26:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:26:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:26:55 --> Database Forge Class Initialized
INFO - 2023-07-21 16:26:55 --> Model Class Initialized
INFO - 2023-07-21 16:26:55 --> Model Class Initialized
INFO - 2023-07-21 22:26:55 --> Model Class Initialized
INFO - 2023-07-21 22:26:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/accounts/invoice_wise_tax_report.php
DEBUG - 2023-07-21 22:26:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 22:26:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 22:26:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 22:26:55 --> Model Class Initialized
INFO - 2023-07-21 22:26:55 --> Model Class Initialized
INFO - 2023-07-21 22:26:55 --> Model Class Initialized
INFO - 2023-07-21 22:26:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 22:26:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 22:26:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 22:26:55 --> Final output sent to browser
DEBUG - 2023-07-21 22:26:55 --> Total execution time: 0.1387
ERROR - 2023-07-21 16:26:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:26:59 --> Config Class Initialized
INFO - 2023-07-21 16:26:59 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:26:59 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:26:59 --> Utf8 Class Initialized
INFO - 2023-07-21 16:26:59 --> URI Class Initialized
DEBUG - 2023-07-21 16:26:59 --> No URI present. Default controller set.
INFO - 2023-07-21 16:26:59 --> Router Class Initialized
INFO - 2023-07-21 16:26:59 --> Output Class Initialized
INFO - 2023-07-21 16:26:59 --> Security Class Initialized
DEBUG - 2023-07-21 16:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:26:59 --> Input Class Initialized
INFO - 2023-07-21 16:26:59 --> Language Class Initialized
INFO - 2023-07-21 16:26:59 --> Loader Class Initialized
INFO - 2023-07-21 16:26:59 --> Helper loaded: url_helper
INFO - 2023-07-21 16:26:59 --> Helper loaded: file_helper
INFO - 2023-07-21 16:26:59 --> Helper loaded: html_helper
INFO - 2023-07-21 16:26:59 --> Helper loaded: text_helper
INFO - 2023-07-21 16:26:59 --> Helper loaded: form_helper
INFO - 2023-07-21 16:26:59 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:26:59 --> Helper loaded: security_helper
INFO - 2023-07-21 16:26:59 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:26:59 --> Database Driver Class Initialized
INFO - 2023-07-21 16:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:26:59 --> Parser Class Initialized
INFO - 2023-07-21 16:26:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:26:59 --> Pagination Class Initialized
INFO - 2023-07-21 16:26:59 --> Form Validation Class Initialized
INFO - 2023-07-21 16:26:59 --> Controller Class Initialized
INFO - 2023-07-21 16:26:59 --> Model Class Initialized
DEBUG - 2023-07-21 16:26:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:26:59 --> Model Class Initialized
DEBUG - 2023-07-21 16:26:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:26:59 --> Model Class Initialized
INFO - 2023-07-21 16:26:59 --> Model Class Initialized
INFO - 2023-07-21 16:26:59 --> Model Class Initialized
INFO - 2023-07-21 16:26:59 --> Model Class Initialized
DEBUG - 2023-07-21 16:26:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:26:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:26:59 --> Model Class Initialized
INFO - 2023-07-21 16:26:59 --> Model Class Initialized
INFO - 2023-07-21 16:26:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-21 16:26:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:26:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:26:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:26:59 --> Model Class Initialized
INFO - 2023-07-21 16:26:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 16:26:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 16:26:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:26:59 --> Final output sent to browser
DEBUG - 2023-07-21 16:26:59 --> Total execution time: 0.1637
ERROR - 2023-07-21 16:27:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:27:37 --> Config Class Initialized
INFO - 2023-07-21 16:27:37 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:27:37 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:27:37 --> Utf8 Class Initialized
INFO - 2023-07-21 16:27:37 --> URI Class Initialized
INFO - 2023-07-21 16:27:37 --> Router Class Initialized
INFO - 2023-07-21 16:27:37 --> Output Class Initialized
INFO - 2023-07-21 16:27:37 --> Security Class Initialized
DEBUG - 2023-07-21 16:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:27:37 --> Input Class Initialized
INFO - 2023-07-21 16:27:37 --> Language Class Initialized
INFO - 2023-07-21 16:27:37 --> Loader Class Initialized
INFO - 2023-07-21 16:27:37 --> Helper loaded: url_helper
INFO - 2023-07-21 16:27:37 --> Helper loaded: file_helper
INFO - 2023-07-21 16:27:37 --> Helper loaded: html_helper
INFO - 2023-07-21 16:27:37 --> Helper loaded: text_helper
INFO - 2023-07-21 16:27:37 --> Helper loaded: form_helper
INFO - 2023-07-21 16:27:37 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:27:37 --> Helper loaded: security_helper
INFO - 2023-07-21 16:27:37 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:27:37 --> Database Driver Class Initialized
INFO - 2023-07-21 16:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:27:37 --> Parser Class Initialized
INFO - 2023-07-21 16:27:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:27:37 --> Pagination Class Initialized
INFO - 2023-07-21 16:27:37 --> Form Validation Class Initialized
INFO - 2023-07-21 16:27:37 --> Controller Class Initialized
INFO - 2023-07-21 16:27:37 --> Model Class Initialized
DEBUG - 2023-07-21 16:27:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:27:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:27:37 --> Model Class Initialized
DEBUG - 2023-07-21 16:27:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:27:37 --> Model Class Initialized
INFO - 2023-07-21 16:27:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-21 16:27:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:27:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:27:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:27:37 --> Model Class Initialized
INFO - 2023-07-21 16:27:37 --> Model Class Initialized
INFO - 2023-07-21 16:27:37 --> Model Class Initialized
INFO - 2023-07-21 16:27:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 16:27:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 16:27:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:27:38 --> Final output sent to browser
DEBUG - 2023-07-21 16:27:38 --> Total execution time: 0.1505
ERROR - 2023-07-21 16:27:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:27:38 --> Config Class Initialized
INFO - 2023-07-21 16:27:38 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:27:38 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:27:38 --> Utf8 Class Initialized
INFO - 2023-07-21 16:27:38 --> URI Class Initialized
INFO - 2023-07-21 16:27:38 --> Router Class Initialized
INFO - 2023-07-21 16:27:38 --> Output Class Initialized
INFO - 2023-07-21 16:27:38 --> Security Class Initialized
DEBUG - 2023-07-21 16:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:27:38 --> Input Class Initialized
INFO - 2023-07-21 16:27:38 --> Language Class Initialized
INFO - 2023-07-21 16:27:38 --> Loader Class Initialized
INFO - 2023-07-21 16:27:38 --> Helper loaded: url_helper
INFO - 2023-07-21 16:27:38 --> Helper loaded: file_helper
INFO - 2023-07-21 16:27:38 --> Helper loaded: html_helper
INFO - 2023-07-21 16:27:38 --> Helper loaded: text_helper
INFO - 2023-07-21 16:27:38 --> Helper loaded: form_helper
INFO - 2023-07-21 16:27:38 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:27:38 --> Helper loaded: security_helper
INFO - 2023-07-21 16:27:38 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:27:38 --> Database Driver Class Initialized
INFO - 2023-07-21 16:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:27:38 --> Parser Class Initialized
INFO - 2023-07-21 16:27:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:27:38 --> Pagination Class Initialized
INFO - 2023-07-21 16:27:38 --> Form Validation Class Initialized
INFO - 2023-07-21 16:27:38 --> Controller Class Initialized
INFO - 2023-07-21 16:27:38 --> Model Class Initialized
DEBUG - 2023-07-21 16:27:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:27:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:27:38 --> Model Class Initialized
DEBUG - 2023-07-21 16:27:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:27:38 --> Model Class Initialized
INFO - 2023-07-21 16:27:38 --> Final output sent to browser
DEBUG - 2023-07-21 16:27:38 --> Total execution time: 0.0634
ERROR - 2023-07-21 16:27:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:27:45 --> Config Class Initialized
INFO - 2023-07-21 16:27:45 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:27:45 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:27:45 --> Utf8 Class Initialized
INFO - 2023-07-21 16:27:45 --> URI Class Initialized
INFO - 2023-07-21 16:27:45 --> Router Class Initialized
INFO - 2023-07-21 16:27:45 --> Output Class Initialized
INFO - 2023-07-21 16:27:45 --> Security Class Initialized
DEBUG - 2023-07-21 16:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:27:45 --> Input Class Initialized
INFO - 2023-07-21 16:27:45 --> Language Class Initialized
INFO - 2023-07-21 16:27:45 --> Loader Class Initialized
INFO - 2023-07-21 16:27:45 --> Helper loaded: url_helper
INFO - 2023-07-21 16:27:45 --> Helper loaded: file_helper
INFO - 2023-07-21 16:27:45 --> Helper loaded: html_helper
INFO - 2023-07-21 16:27:45 --> Helper loaded: text_helper
INFO - 2023-07-21 16:27:45 --> Helper loaded: form_helper
INFO - 2023-07-21 16:27:45 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:27:45 --> Helper loaded: security_helper
INFO - 2023-07-21 16:27:45 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:27:45 --> Database Driver Class Initialized
INFO - 2023-07-21 16:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:27:45 --> Parser Class Initialized
INFO - 2023-07-21 16:27:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:27:45 --> Pagination Class Initialized
INFO - 2023-07-21 16:27:45 --> Form Validation Class Initialized
INFO - 2023-07-21 16:27:45 --> Controller Class Initialized
INFO - 2023-07-21 16:27:45 --> Model Class Initialized
DEBUG - 2023-07-21 16:27:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:27:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:27:45 --> Model Class Initialized
DEBUG - 2023-07-21 16:27:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:27:45 --> Model Class Initialized
INFO - 2023-07-21 16:27:45 --> Final output sent to browser
DEBUG - 2023-07-21 16:27:45 --> Total execution time: 0.3339
ERROR - 2023-07-21 16:28:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:28:32 --> Config Class Initialized
INFO - 2023-07-21 16:28:32 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:28:32 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:28:32 --> Utf8 Class Initialized
INFO - 2023-07-21 16:28:32 --> URI Class Initialized
DEBUG - 2023-07-21 16:28:32 --> No URI present. Default controller set.
INFO - 2023-07-21 16:28:32 --> Router Class Initialized
INFO - 2023-07-21 16:28:32 --> Output Class Initialized
INFO - 2023-07-21 16:28:32 --> Security Class Initialized
DEBUG - 2023-07-21 16:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:28:32 --> Input Class Initialized
INFO - 2023-07-21 16:28:32 --> Language Class Initialized
INFO - 2023-07-21 16:28:32 --> Loader Class Initialized
INFO - 2023-07-21 16:28:32 --> Helper loaded: url_helper
INFO - 2023-07-21 16:28:32 --> Helper loaded: file_helper
INFO - 2023-07-21 16:28:32 --> Helper loaded: html_helper
INFO - 2023-07-21 16:28:32 --> Helper loaded: text_helper
INFO - 2023-07-21 16:28:32 --> Helper loaded: form_helper
INFO - 2023-07-21 16:28:32 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:28:32 --> Helper loaded: security_helper
INFO - 2023-07-21 16:28:32 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:28:32 --> Database Driver Class Initialized
INFO - 2023-07-21 16:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:28:32 --> Parser Class Initialized
INFO - 2023-07-21 16:28:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:28:32 --> Pagination Class Initialized
INFO - 2023-07-21 16:28:32 --> Form Validation Class Initialized
INFO - 2023-07-21 16:28:32 --> Controller Class Initialized
INFO - 2023-07-21 16:28:32 --> Model Class Initialized
DEBUG - 2023-07-21 16:28:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-21 16:28:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:28:33 --> Config Class Initialized
INFO - 2023-07-21 16:28:33 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:28:33 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:28:33 --> Utf8 Class Initialized
INFO - 2023-07-21 16:28:33 --> URI Class Initialized
INFO - 2023-07-21 16:28:33 --> Router Class Initialized
INFO - 2023-07-21 16:28:33 --> Output Class Initialized
INFO - 2023-07-21 16:28:33 --> Security Class Initialized
DEBUG - 2023-07-21 16:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:28:33 --> Input Class Initialized
INFO - 2023-07-21 16:28:33 --> Language Class Initialized
INFO - 2023-07-21 16:28:33 --> Loader Class Initialized
INFO - 2023-07-21 16:28:33 --> Helper loaded: url_helper
INFO - 2023-07-21 16:28:33 --> Helper loaded: file_helper
INFO - 2023-07-21 16:28:33 --> Helper loaded: html_helper
INFO - 2023-07-21 16:28:33 --> Helper loaded: text_helper
INFO - 2023-07-21 16:28:33 --> Helper loaded: form_helper
INFO - 2023-07-21 16:28:33 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:28:33 --> Helper loaded: security_helper
INFO - 2023-07-21 16:28:33 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:28:33 --> Database Driver Class Initialized
INFO - 2023-07-21 16:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:28:33 --> Parser Class Initialized
INFO - 2023-07-21 16:28:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:28:33 --> Pagination Class Initialized
INFO - 2023-07-21 16:28:33 --> Form Validation Class Initialized
INFO - 2023-07-21 16:28:33 --> Controller Class Initialized
INFO - 2023-07-21 16:28:33 --> Model Class Initialized
DEBUG - 2023-07-21 16:28:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:28:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-21 16:28:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:28:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:28:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:28:33 --> Model Class Initialized
INFO - 2023-07-21 16:28:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:28:33 --> Final output sent to browser
DEBUG - 2023-07-21 16:28:33 --> Total execution time: 0.0339
ERROR - 2023-07-21 16:30:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:30:14 --> Config Class Initialized
INFO - 2023-07-21 16:30:14 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:30:14 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:30:14 --> Utf8 Class Initialized
INFO - 2023-07-21 16:30:14 --> URI Class Initialized
INFO - 2023-07-21 16:30:14 --> Router Class Initialized
INFO - 2023-07-21 16:30:14 --> Output Class Initialized
INFO - 2023-07-21 16:30:14 --> Security Class Initialized
DEBUG - 2023-07-21 16:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:30:14 --> Input Class Initialized
INFO - 2023-07-21 16:30:14 --> Language Class Initialized
INFO - 2023-07-21 16:30:14 --> Loader Class Initialized
INFO - 2023-07-21 16:30:14 --> Helper loaded: url_helper
INFO - 2023-07-21 16:30:14 --> Helper loaded: file_helper
INFO - 2023-07-21 16:30:14 --> Helper loaded: html_helper
INFO - 2023-07-21 16:30:14 --> Helper loaded: text_helper
INFO - 2023-07-21 16:30:14 --> Helper loaded: form_helper
INFO - 2023-07-21 16:30:14 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:30:14 --> Helper loaded: security_helper
INFO - 2023-07-21 16:30:14 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:30:14 --> Database Driver Class Initialized
INFO - 2023-07-21 16:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:30:14 --> Parser Class Initialized
INFO - 2023-07-21 16:30:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:30:14 --> Pagination Class Initialized
INFO - 2023-07-21 16:30:14 --> Form Validation Class Initialized
INFO - 2023-07-21 16:30:14 --> Controller Class Initialized
INFO - 2023-07-21 16:30:14 --> Model Class Initialized
DEBUG - 2023-07-21 16:30:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:30:14 --> Final output sent to browser
DEBUG - 2023-07-21 16:30:14 --> Total execution time: 0.0182
ERROR - 2023-07-21 16:30:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:30:14 --> Config Class Initialized
INFO - 2023-07-21 16:30:14 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:30:14 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:30:14 --> Utf8 Class Initialized
INFO - 2023-07-21 16:30:14 --> URI Class Initialized
INFO - 2023-07-21 16:30:14 --> Router Class Initialized
INFO - 2023-07-21 16:30:14 --> Output Class Initialized
INFO - 2023-07-21 16:30:14 --> Security Class Initialized
DEBUG - 2023-07-21 16:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:30:14 --> Input Class Initialized
INFO - 2023-07-21 16:30:14 --> Language Class Initialized
INFO - 2023-07-21 16:30:14 --> Loader Class Initialized
INFO - 2023-07-21 16:30:14 --> Helper loaded: url_helper
INFO - 2023-07-21 16:30:14 --> Helper loaded: file_helper
INFO - 2023-07-21 16:30:14 --> Helper loaded: html_helper
INFO - 2023-07-21 16:30:14 --> Helper loaded: text_helper
INFO - 2023-07-21 16:30:14 --> Helper loaded: form_helper
INFO - 2023-07-21 16:30:14 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:30:14 --> Helper loaded: security_helper
INFO - 2023-07-21 16:30:14 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:30:14 --> Database Driver Class Initialized
INFO - 2023-07-21 16:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:30:14 --> Parser Class Initialized
INFO - 2023-07-21 16:30:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:30:14 --> Pagination Class Initialized
INFO - 2023-07-21 16:30:14 --> Form Validation Class Initialized
INFO - 2023-07-21 16:30:14 --> Controller Class Initialized
INFO - 2023-07-21 16:30:14 --> Model Class Initialized
DEBUG - 2023-07-21 16:30:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:30:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-21 16:30:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:30:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:30:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:30:14 --> Model Class Initialized
INFO - 2023-07-21 16:30:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:30:14 --> Final output sent to browser
DEBUG - 2023-07-21 16:30:14 --> Total execution time: 0.0285
ERROR - 2023-07-21 16:30:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:30:15 --> Config Class Initialized
INFO - 2023-07-21 16:30:15 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:30:15 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:30:15 --> Utf8 Class Initialized
INFO - 2023-07-21 16:30:15 --> URI Class Initialized
INFO - 2023-07-21 16:30:15 --> Router Class Initialized
INFO - 2023-07-21 16:30:15 --> Output Class Initialized
INFO - 2023-07-21 16:30:15 --> Security Class Initialized
DEBUG - 2023-07-21 16:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:30:15 --> Input Class Initialized
INFO - 2023-07-21 16:30:15 --> Language Class Initialized
INFO - 2023-07-21 16:30:15 --> Loader Class Initialized
INFO - 2023-07-21 16:30:15 --> Helper loaded: url_helper
INFO - 2023-07-21 16:30:15 --> Helper loaded: file_helper
INFO - 2023-07-21 16:30:15 --> Helper loaded: html_helper
INFO - 2023-07-21 16:30:15 --> Helper loaded: text_helper
INFO - 2023-07-21 16:30:15 --> Helper loaded: form_helper
INFO - 2023-07-21 16:30:15 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:30:15 --> Helper loaded: security_helper
INFO - 2023-07-21 16:30:15 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:30:15 --> Database Driver Class Initialized
INFO - 2023-07-21 16:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:30:15 --> Parser Class Initialized
INFO - 2023-07-21 16:30:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:30:15 --> Pagination Class Initialized
INFO - 2023-07-21 16:30:15 --> Form Validation Class Initialized
INFO - 2023-07-21 16:30:15 --> Controller Class Initialized
INFO - 2023-07-21 16:30:15 --> Model Class Initialized
DEBUG - 2023-07-21 16:30:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:30:15 --> Model Class Initialized
DEBUG - 2023-07-21 16:30:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:30:15 --> Model Class Initialized
INFO - 2023-07-21 16:30:15 --> Model Class Initialized
INFO - 2023-07-21 16:30:15 --> Model Class Initialized
INFO - 2023-07-21 16:30:15 --> Model Class Initialized
DEBUG - 2023-07-21 16:30:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:30:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:30:15 --> Model Class Initialized
INFO - 2023-07-21 16:30:15 --> Model Class Initialized
INFO - 2023-07-21 16:30:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-21 16:30:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:30:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:30:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:30:15 --> Model Class Initialized
INFO - 2023-07-21 16:30:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 16:30:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 16:30:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:30:15 --> Final output sent to browser
DEBUG - 2023-07-21 16:30:15 --> Total execution time: 0.1875
ERROR - 2023-07-21 16:30:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:30:41 --> Config Class Initialized
INFO - 2023-07-21 16:30:41 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:30:41 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:30:41 --> Utf8 Class Initialized
INFO - 2023-07-21 16:30:41 --> URI Class Initialized
DEBUG - 2023-07-21 16:30:41 --> No URI present. Default controller set.
INFO - 2023-07-21 16:30:41 --> Router Class Initialized
INFO - 2023-07-21 16:30:41 --> Output Class Initialized
INFO - 2023-07-21 16:30:41 --> Security Class Initialized
DEBUG - 2023-07-21 16:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:30:41 --> Input Class Initialized
INFO - 2023-07-21 16:30:41 --> Language Class Initialized
INFO - 2023-07-21 16:30:41 --> Loader Class Initialized
INFO - 2023-07-21 16:30:41 --> Helper loaded: url_helper
INFO - 2023-07-21 16:30:41 --> Helper loaded: file_helper
INFO - 2023-07-21 16:30:41 --> Helper loaded: html_helper
INFO - 2023-07-21 16:30:41 --> Helper loaded: text_helper
INFO - 2023-07-21 16:30:41 --> Helper loaded: form_helper
INFO - 2023-07-21 16:30:41 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:30:41 --> Helper loaded: security_helper
INFO - 2023-07-21 16:30:41 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:30:41 --> Database Driver Class Initialized
INFO - 2023-07-21 16:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:30:41 --> Parser Class Initialized
INFO - 2023-07-21 16:30:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:30:41 --> Pagination Class Initialized
INFO - 2023-07-21 16:30:41 --> Form Validation Class Initialized
INFO - 2023-07-21 16:30:41 --> Controller Class Initialized
INFO - 2023-07-21 16:30:41 --> Model Class Initialized
DEBUG - 2023-07-21 16:30:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-21 16:30:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:30:41 --> Config Class Initialized
INFO - 2023-07-21 16:30:41 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:30:41 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:30:41 --> Utf8 Class Initialized
INFO - 2023-07-21 16:30:41 --> URI Class Initialized
INFO - 2023-07-21 16:30:41 --> Router Class Initialized
INFO - 2023-07-21 16:30:41 --> Output Class Initialized
INFO - 2023-07-21 16:30:41 --> Security Class Initialized
DEBUG - 2023-07-21 16:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:30:41 --> Input Class Initialized
INFO - 2023-07-21 16:30:41 --> Language Class Initialized
INFO - 2023-07-21 16:30:41 --> Loader Class Initialized
INFO - 2023-07-21 16:30:41 --> Helper loaded: url_helper
INFO - 2023-07-21 16:30:41 --> Helper loaded: file_helper
INFO - 2023-07-21 16:30:41 --> Helper loaded: html_helper
INFO - 2023-07-21 16:30:41 --> Helper loaded: text_helper
INFO - 2023-07-21 16:30:41 --> Helper loaded: form_helper
INFO - 2023-07-21 16:30:41 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:30:41 --> Helper loaded: security_helper
INFO - 2023-07-21 16:30:41 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:30:41 --> Database Driver Class Initialized
INFO - 2023-07-21 16:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:30:41 --> Parser Class Initialized
INFO - 2023-07-21 16:30:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:30:41 --> Pagination Class Initialized
INFO - 2023-07-21 16:30:41 --> Form Validation Class Initialized
INFO - 2023-07-21 16:30:41 --> Controller Class Initialized
INFO - 2023-07-21 16:30:41 --> Model Class Initialized
DEBUG - 2023-07-21 16:30:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:30:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-21 16:30:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:30:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:30:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:30:41 --> Model Class Initialized
INFO - 2023-07-21 16:30:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:30:41 --> Final output sent to browser
DEBUG - 2023-07-21 16:30:41 --> Total execution time: 0.0325
ERROR - 2023-07-21 16:30:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:30:54 --> Config Class Initialized
INFO - 2023-07-21 16:30:54 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:30:54 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:30:54 --> Utf8 Class Initialized
INFO - 2023-07-21 16:30:54 --> URI Class Initialized
INFO - 2023-07-21 16:30:54 --> Router Class Initialized
INFO - 2023-07-21 16:30:54 --> Output Class Initialized
INFO - 2023-07-21 16:30:54 --> Security Class Initialized
DEBUG - 2023-07-21 16:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:30:54 --> Input Class Initialized
INFO - 2023-07-21 16:30:54 --> Language Class Initialized
INFO - 2023-07-21 16:30:54 --> Loader Class Initialized
INFO - 2023-07-21 16:30:54 --> Helper loaded: url_helper
INFO - 2023-07-21 16:30:54 --> Helper loaded: file_helper
INFO - 2023-07-21 16:30:54 --> Helper loaded: html_helper
INFO - 2023-07-21 16:30:54 --> Helper loaded: text_helper
INFO - 2023-07-21 16:30:54 --> Helper loaded: form_helper
INFO - 2023-07-21 16:30:54 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:30:54 --> Helper loaded: security_helper
INFO - 2023-07-21 16:30:54 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:30:54 --> Database Driver Class Initialized
INFO - 2023-07-21 16:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:30:54 --> Parser Class Initialized
INFO - 2023-07-21 16:30:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:30:54 --> Pagination Class Initialized
INFO - 2023-07-21 16:30:54 --> Form Validation Class Initialized
INFO - 2023-07-21 16:30:54 --> Controller Class Initialized
INFO - 2023-07-21 16:30:54 --> Model Class Initialized
DEBUG - 2023-07-21 16:30:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:30:54 --> Model Class Initialized
INFO - 2023-07-21 16:30:54 --> Final output sent to browser
DEBUG - 2023-07-21 16:30:54 --> Total execution time: 0.0202
ERROR - 2023-07-21 16:30:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:30:55 --> Config Class Initialized
INFO - 2023-07-21 16:30:55 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:30:55 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:30:55 --> Utf8 Class Initialized
INFO - 2023-07-21 16:30:55 --> URI Class Initialized
DEBUG - 2023-07-21 16:30:55 --> No URI present. Default controller set.
INFO - 2023-07-21 16:30:55 --> Router Class Initialized
INFO - 2023-07-21 16:30:55 --> Output Class Initialized
INFO - 2023-07-21 16:30:55 --> Security Class Initialized
DEBUG - 2023-07-21 16:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:30:55 --> Input Class Initialized
INFO - 2023-07-21 16:30:55 --> Language Class Initialized
INFO - 2023-07-21 16:30:55 --> Loader Class Initialized
INFO - 2023-07-21 16:30:55 --> Helper loaded: url_helper
INFO - 2023-07-21 16:30:55 --> Helper loaded: file_helper
INFO - 2023-07-21 16:30:55 --> Helper loaded: html_helper
INFO - 2023-07-21 16:30:55 --> Helper loaded: text_helper
INFO - 2023-07-21 16:30:55 --> Helper loaded: form_helper
INFO - 2023-07-21 16:30:55 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:30:55 --> Helper loaded: security_helper
INFO - 2023-07-21 16:30:55 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:30:55 --> Database Driver Class Initialized
INFO - 2023-07-21 16:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:30:55 --> Parser Class Initialized
INFO - 2023-07-21 16:30:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:30:55 --> Pagination Class Initialized
INFO - 2023-07-21 16:30:55 --> Form Validation Class Initialized
INFO - 2023-07-21 16:30:55 --> Controller Class Initialized
INFO - 2023-07-21 16:30:55 --> Model Class Initialized
DEBUG - 2023-07-21 16:30:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:30:55 --> Model Class Initialized
DEBUG - 2023-07-21 16:30:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:30:55 --> Model Class Initialized
INFO - 2023-07-21 16:30:55 --> Model Class Initialized
INFO - 2023-07-21 16:30:55 --> Model Class Initialized
INFO - 2023-07-21 16:30:55 --> Model Class Initialized
DEBUG - 2023-07-21 16:30:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:30:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:30:55 --> Model Class Initialized
INFO - 2023-07-21 16:30:55 --> Model Class Initialized
INFO - 2023-07-21 16:30:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-21 16:30:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:30:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:30:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:30:55 --> Model Class Initialized
INFO - 2023-07-21 16:30:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 16:30:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 16:30:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:30:55 --> Final output sent to browser
DEBUG - 2023-07-21 16:30:55 --> Total execution time: 0.0677
ERROR - 2023-07-21 16:30:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:30:58 --> Config Class Initialized
INFO - 2023-07-21 16:30:58 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:30:58 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:30:58 --> Utf8 Class Initialized
INFO - 2023-07-21 16:30:58 --> URI Class Initialized
INFO - 2023-07-21 16:30:58 --> Router Class Initialized
INFO - 2023-07-21 16:30:58 --> Output Class Initialized
INFO - 2023-07-21 16:30:58 --> Security Class Initialized
DEBUG - 2023-07-21 16:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:30:58 --> Input Class Initialized
INFO - 2023-07-21 16:30:58 --> Language Class Initialized
INFO - 2023-07-21 16:30:58 --> Loader Class Initialized
INFO - 2023-07-21 16:30:58 --> Helper loaded: url_helper
INFO - 2023-07-21 16:30:58 --> Helper loaded: file_helper
INFO - 2023-07-21 16:30:58 --> Helper loaded: html_helper
INFO - 2023-07-21 16:30:58 --> Helper loaded: text_helper
INFO - 2023-07-21 16:30:58 --> Helper loaded: form_helper
INFO - 2023-07-21 16:30:58 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:30:58 --> Helper loaded: security_helper
INFO - 2023-07-21 16:30:58 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:30:58 --> Database Driver Class Initialized
INFO - 2023-07-21 16:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:30:58 --> Parser Class Initialized
INFO - 2023-07-21 16:30:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:30:58 --> Pagination Class Initialized
INFO - 2023-07-21 16:30:58 --> Form Validation Class Initialized
INFO - 2023-07-21 16:30:58 --> Controller Class Initialized
INFO - 2023-07-21 16:30:58 --> Model Class Initialized
DEBUG - 2023-07-21 16:30:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:30:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-21 16:30:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:30:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:30:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:30:58 --> Model Class Initialized
INFO - 2023-07-21 16:30:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:30:58 --> Final output sent to browser
DEBUG - 2023-07-21 16:30:58 --> Total execution time: 0.0310
ERROR - 2023-07-21 16:30:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:30:58 --> Config Class Initialized
INFO - 2023-07-21 16:30:58 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:30:58 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:30:58 --> Utf8 Class Initialized
INFO - 2023-07-21 16:30:58 --> URI Class Initialized
INFO - 2023-07-21 16:30:58 --> Router Class Initialized
INFO - 2023-07-21 16:30:58 --> Output Class Initialized
INFO - 2023-07-21 16:30:58 --> Security Class Initialized
DEBUG - 2023-07-21 16:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:30:58 --> Input Class Initialized
INFO - 2023-07-21 16:30:58 --> Language Class Initialized
INFO - 2023-07-21 16:30:58 --> Loader Class Initialized
INFO - 2023-07-21 16:30:58 --> Helper loaded: url_helper
INFO - 2023-07-21 16:30:58 --> Helper loaded: file_helper
INFO - 2023-07-21 16:30:58 --> Helper loaded: html_helper
INFO - 2023-07-21 16:30:58 --> Helper loaded: text_helper
INFO - 2023-07-21 16:30:58 --> Helper loaded: form_helper
INFO - 2023-07-21 16:30:58 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:30:58 --> Helper loaded: security_helper
INFO - 2023-07-21 16:30:58 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:30:58 --> Database Driver Class Initialized
INFO - 2023-07-21 16:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:30:58 --> Parser Class Initialized
INFO - 2023-07-21 16:30:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:30:58 --> Pagination Class Initialized
INFO - 2023-07-21 16:30:58 --> Form Validation Class Initialized
INFO - 2023-07-21 16:30:58 --> Controller Class Initialized
INFO - 2023-07-21 16:30:58 --> Model Class Initialized
DEBUG - 2023-07-21 16:30:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:30:58 --> Model Class Initialized
DEBUG - 2023-07-21 16:30:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:30:58 --> Model Class Initialized
INFO - 2023-07-21 16:30:58 --> Model Class Initialized
INFO - 2023-07-21 16:30:58 --> Model Class Initialized
INFO - 2023-07-21 16:30:58 --> Model Class Initialized
DEBUG - 2023-07-21 16:30:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:30:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:30:58 --> Model Class Initialized
INFO - 2023-07-21 16:30:58 --> Model Class Initialized
INFO - 2023-07-21 16:30:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-21 16:30:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:30:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:30:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:30:58 --> Model Class Initialized
INFO - 2023-07-21 16:30:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 16:30:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 16:30:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:30:59 --> Final output sent to browser
DEBUG - 2023-07-21 16:30:59 --> Total execution time: 0.0674
ERROR - 2023-07-21 16:31:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:31:21 --> Config Class Initialized
INFO - 2023-07-21 16:31:21 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:31:21 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:31:21 --> Utf8 Class Initialized
INFO - 2023-07-21 16:31:21 --> URI Class Initialized
DEBUG - 2023-07-21 16:31:21 --> No URI present. Default controller set.
INFO - 2023-07-21 16:31:21 --> Router Class Initialized
INFO - 2023-07-21 16:31:21 --> Output Class Initialized
INFO - 2023-07-21 16:31:21 --> Security Class Initialized
DEBUG - 2023-07-21 16:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:31:21 --> Input Class Initialized
INFO - 2023-07-21 16:31:21 --> Language Class Initialized
INFO - 2023-07-21 16:31:21 --> Loader Class Initialized
INFO - 2023-07-21 16:31:21 --> Helper loaded: url_helper
INFO - 2023-07-21 16:31:21 --> Helper loaded: file_helper
INFO - 2023-07-21 16:31:21 --> Helper loaded: html_helper
INFO - 2023-07-21 16:31:21 --> Helper loaded: text_helper
INFO - 2023-07-21 16:31:21 --> Helper loaded: form_helper
INFO - 2023-07-21 16:31:21 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:31:21 --> Helper loaded: security_helper
INFO - 2023-07-21 16:31:21 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:31:21 --> Database Driver Class Initialized
INFO - 2023-07-21 16:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:31:21 --> Parser Class Initialized
INFO - 2023-07-21 16:31:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:31:21 --> Pagination Class Initialized
INFO - 2023-07-21 16:31:21 --> Form Validation Class Initialized
INFO - 2023-07-21 16:31:21 --> Controller Class Initialized
INFO - 2023-07-21 16:31:21 --> Model Class Initialized
DEBUG - 2023-07-21 16:31:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:31:21 --> Model Class Initialized
DEBUG - 2023-07-21 16:31:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:31:21 --> Model Class Initialized
INFO - 2023-07-21 16:31:21 --> Model Class Initialized
INFO - 2023-07-21 16:31:21 --> Model Class Initialized
INFO - 2023-07-21 16:31:21 --> Model Class Initialized
DEBUG - 2023-07-21 16:31:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:31:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:31:21 --> Model Class Initialized
INFO - 2023-07-21 16:31:21 --> Model Class Initialized
INFO - 2023-07-21 16:31:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-21 16:31:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:31:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:31:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:31:21 --> Model Class Initialized
INFO - 2023-07-21 16:31:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 16:31:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 16:31:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:31:21 --> Final output sent to browser
DEBUG - 2023-07-21 16:31:21 --> Total execution time: 0.0696
ERROR - 2023-07-21 16:31:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:31:27 --> Config Class Initialized
INFO - 2023-07-21 16:31:27 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:31:27 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:31:27 --> Utf8 Class Initialized
INFO - 2023-07-21 16:31:27 --> URI Class Initialized
INFO - 2023-07-21 16:31:27 --> Router Class Initialized
INFO - 2023-07-21 16:31:27 --> Output Class Initialized
INFO - 2023-07-21 16:31:27 --> Security Class Initialized
DEBUG - 2023-07-21 16:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:31:27 --> Input Class Initialized
INFO - 2023-07-21 16:31:27 --> Language Class Initialized
INFO - 2023-07-21 16:31:27 --> Loader Class Initialized
INFO - 2023-07-21 16:31:27 --> Helper loaded: url_helper
INFO - 2023-07-21 16:31:27 --> Helper loaded: file_helper
INFO - 2023-07-21 16:31:27 --> Helper loaded: html_helper
INFO - 2023-07-21 16:31:27 --> Helper loaded: text_helper
INFO - 2023-07-21 16:31:27 --> Helper loaded: form_helper
INFO - 2023-07-21 16:31:27 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:31:27 --> Helper loaded: security_helper
INFO - 2023-07-21 16:31:27 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:31:27 --> Database Driver Class Initialized
INFO - 2023-07-21 16:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:31:27 --> Parser Class Initialized
INFO - 2023-07-21 16:31:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:31:27 --> Pagination Class Initialized
INFO - 2023-07-21 16:31:27 --> Form Validation Class Initialized
INFO - 2023-07-21 16:31:27 --> Controller Class Initialized
INFO - 2023-07-21 16:31:27 --> Model Class Initialized
DEBUG - 2023-07-21 16:31:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:31:27 --> Final output sent to browser
DEBUG - 2023-07-21 16:31:27 --> Total execution time: 0.0129
ERROR - 2023-07-21 16:31:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:31:27 --> Config Class Initialized
INFO - 2023-07-21 16:31:27 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:31:27 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:31:27 --> Utf8 Class Initialized
INFO - 2023-07-21 16:31:27 --> URI Class Initialized
INFO - 2023-07-21 16:31:27 --> Router Class Initialized
INFO - 2023-07-21 16:31:27 --> Output Class Initialized
INFO - 2023-07-21 16:31:27 --> Security Class Initialized
DEBUG - 2023-07-21 16:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:31:27 --> Input Class Initialized
INFO - 2023-07-21 16:31:27 --> Language Class Initialized
INFO - 2023-07-21 16:31:27 --> Loader Class Initialized
INFO - 2023-07-21 16:31:27 --> Helper loaded: url_helper
INFO - 2023-07-21 16:31:27 --> Helper loaded: file_helper
INFO - 2023-07-21 16:31:27 --> Helper loaded: html_helper
INFO - 2023-07-21 16:31:27 --> Helper loaded: text_helper
INFO - 2023-07-21 16:31:27 --> Helper loaded: form_helper
INFO - 2023-07-21 16:31:27 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:31:27 --> Helper loaded: security_helper
INFO - 2023-07-21 16:31:27 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:31:27 --> Database Driver Class Initialized
INFO - 2023-07-21 16:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:31:27 --> Parser Class Initialized
INFO - 2023-07-21 16:31:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:31:27 --> Pagination Class Initialized
INFO - 2023-07-21 16:31:27 --> Form Validation Class Initialized
INFO - 2023-07-21 16:31:27 --> Controller Class Initialized
INFO - 2023-07-21 16:31:27 --> Model Class Initialized
DEBUG - 2023-07-21 16:31:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:31:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-21 16:31:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:31:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:31:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:31:27 --> Model Class Initialized
INFO - 2023-07-21 16:31:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:31:27 --> Final output sent to browser
DEBUG - 2023-07-21 16:31:27 --> Total execution time: 0.0275
ERROR - 2023-07-21 16:31:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:31:37 --> Config Class Initialized
INFO - 2023-07-21 16:31:37 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:31:37 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:31:37 --> Utf8 Class Initialized
INFO - 2023-07-21 16:31:37 --> URI Class Initialized
INFO - 2023-07-21 16:31:37 --> Router Class Initialized
INFO - 2023-07-21 16:31:37 --> Output Class Initialized
INFO - 2023-07-21 16:31:37 --> Security Class Initialized
DEBUG - 2023-07-21 16:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:31:37 --> Input Class Initialized
INFO - 2023-07-21 16:31:37 --> Language Class Initialized
INFO - 2023-07-21 16:31:37 --> Loader Class Initialized
INFO - 2023-07-21 16:31:37 --> Helper loaded: url_helper
INFO - 2023-07-21 16:31:37 --> Helper loaded: file_helper
INFO - 2023-07-21 16:31:37 --> Helper loaded: html_helper
INFO - 2023-07-21 16:31:37 --> Helper loaded: text_helper
INFO - 2023-07-21 16:31:37 --> Helper loaded: form_helper
INFO - 2023-07-21 16:31:37 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:31:37 --> Helper loaded: security_helper
INFO - 2023-07-21 16:31:37 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:31:37 --> Database Driver Class Initialized
INFO - 2023-07-21 16:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:31:37 --> Parser Class Initialized
INFO - 2023-07-21 16:31:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:31:37 --> Pagination Class Initialized
INFO - 2023-07-21 16:31:37 --> Form Validation Class Initialized
INFO - 2023-07-21 16:31:37 --> Controller Class Initialized
INFO - 2023-07-21 16:31:37 --> Model Class Initialized
DEBUG - 2023-07-21 16:31:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:31:37 --> Model Class Initialized
INFO - 2023-07-21 16:31:37 --> Final output sent to browser
DEBUG - 2023-07-21 16:31:37 --> Total execution time: 0.0165
ERROR - 2023-07-21 16:31:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:31:37 --> Config Class Initialized
INFO - 2023-07-21 16:31:37 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:31:37 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:31:37 --> Utf8 Class Initialized
INFO - 2023-07-21 16:31:37 --> URI Class Initialized
DEBUG - 2023-07-21 16:31:37 --> No URI present. Default controller set.
INFO - 2023-07-21 16:31:37 --> Router Class Initialized
INFO - 2023-07-21 16:31:37 --> Output Class Initialized
INFO - 2023-07-21 16:31:37 --> Security Class Initialized
DEBUG - 2023-07-21 16:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:31:37 --> Input Class Initialized
INFO - 2023-07-21 16:31:37 --> Language Class Initialized
INFO - 2023-07-21 16:31:37 --> Loader Class Initialized
INFO - 2023-07-21 16:31:37 --> Helper loaded: url_helper
INFO - 2023-07-21 16:31:37 --> Helper loaded: file_helper
INFO - 2023-07-21 16:31:37 --> Helper loaded: html_helper
INFO - 2023-07-21 16:31:37 --> Helper loaded: text_helper
INFO - 2023-07-21 16:31:37 --> Helper loaded: form_helper
INFO - 2023-07-21 16:31:37 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:31:37 --> Helper loaded: security_helper
INFO - 2023-07-21 16:31:37 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:31:37 --> Database Driver Class Initialized
INFO - 2023-07-21 16:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:31:37 --> Parser Class Initialized
INFO - 2023-07-21 16:31:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:31:37 --> Pagination Class Initialized
INFO - 2023-07-21 16:31:37 --> Form Validation Class Initialized
INFO - 2023-07-21 16:31:37 --> Controller Class Initialized
INFO - 2023-07-21 16:31:37 --> Model Class Initialized
DEBUG - 2023-07-21 16:31:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:31:37 --> Model Class Initialized
DEBUG - 2023-07-21 16:31:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:31:37 --> Model Class Initialized
INFO - 2023-07-21 16:31:37 --> Model Class Initialized
INFO - 2023-07-21 16:31:37 --> Model Class Initialized
INFO - 2023-07-21 16:31:37 --> Model Class Initialized
DEBUG - 2023-07-21 16:31:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:31:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:31:37 --> Model Class Initialized
INFO - 2023-07-21 16:31:37 --> Model Class Initialized
INFO - 2023-07-21 16:31:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-21 16:31:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:31:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:31:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:31:37 --> Model Class Initialized
INFO - 2023-07-21 16:31:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 16:31:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 16:31:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:31:37 --> Final output sent to browser
DEBUG - 2023-07-21 16:31:37 --> Total execution time: 0.0656
ERROR - 2023-07-21 16:32:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:32:23 --> Config Class Initialized
INFO - 2023-07-21 16:32:23 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:32:23 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:32:23 --> Utf8 Class Initialized
INFO - 2023-07-21 16:32:23 --> URI Class Initialized
INFO - 2023-07-21 16:32:23 --> Router Class Initialized
INFO - 2023-07-21 16:32:23 --> Output Class Initialized
INFO - 2023-07-21 16:32:23 --> Security Class Initialized
DEBUG - 2023-07-21 16:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:32:23 --> Input Class Initialized
INFO - 2023-07-21 16:32:23 --> Language Class Initialized
INFO - 2023-07-21 16:32:23 --> Loader Class Initialized
INFO - 2023-07-21 16:32:23 --> Helper loaded: url_helper
INFO - 2023-07-21 16:32:23 --> Helper loaded: file_helper
INFO - 2023-07-21 16:32:23 --> Helper loaded: html_helper
INFO - 2023-07-21 16:32:23 --> Helper loaded: text_helper
INFO - 2023-07-21 16:32:23 --> Helper loaded: form_helper
INFO - 2023-07-21 16:32:23 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:32:23 --> Helper loaded: security_helper
INFO - 2023-07-21 16:32:23 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:32:23 --> Database Driver Class Initialized
INFO - 2023-07-21 16:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:32:23 --> Parser Class Initialized
INFO - 2023-07-21 16:32:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:32:23 --> Pagination Class Initialized
INFO - 2023-07-21 16:32:23 --> Form Validation Class Initialized
INFO - 2023-07-21 16:32:23 --> Controller Class Initialized
INFO - 2023-07-21 16:32:23 --> Model Class Initialized
DEBUG - 2023-07-21 16:32:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:32:23 --> Final output sent to browser
DEBUG - 2023-07-21 16:32:23 --> Total execution time: 0.0179
ERROR - 2023-07-21 16:32:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:32:25 --> Config Class Initialized
INFO - 2023-07-21 16:32:25 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:32:25 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:32:25 --> Utf8 Class Initialized
INFO - 2023-07-21 16:32:25 --> URI Class Initialized
INFO - 2023-07-21 16:32:25 --> Router Class Initialized
INFO - 2023-07-21 16:32:25 --> Output Class Initialized
INFO - 2023-07-21 16:32:25 --> Security Class Initialized
DEBUG - 2023-07-21 16:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:32:25 --> Input Class Initialized
INFO - 2023-07-21 16:32:25 --> Language Class Initialized
INFO - 2023-07-21 16:32:25 --> Loader Class Initialized
INFO - 2023-07-21 16:32:25 --> Helper loaded: url_helper
INFO - 2023-07-21 16:32:25 --> Helper loaded: file_helper
INFO - 2023-07-21 16:32:25 --> Helper loaded: html_helper
INFO - 2023-07-21 16:32:25 --> Helper loaded: text_helper
INFO - 2023-07-21 16:32:25 --> Helper loaded: form_helper
INFO - 2023-07-21 16:32:25 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:32:25 --> Helper loaded: security_helper
INFO - 2023-07-21 16:32:25 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:32:25 --> Database Driver Class Initialized
INFO - 2023-07-21 16:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:32:25 --> Parser Class Initialized
INFO - 2023-07-21 16:32:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:32:25 --> Pagination Class Initialized
INFO - 2023-07-21 16:32:25 --> Form Validation Class Initialized
INFO - 2023-07-21 16:32:25 --> Controller Class Initialized
INFO - 2023-07-21 16:32:25 --> Model Class Initialized
DEBUG - 2023-07-21 16:32:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:32:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-21 16:32:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:32:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:32:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:32:25 --> Model Class Initialized
INFO - 2023-07-21 16:32:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:32:25 --> Final output sent to browser
DEBUG - 2023-07-21 16:32:25 --> Total execution time: 0.0262
ERROR - 2023-07-21 16:32:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:32:25 --> Config Class Initialized
INFO - 2023-07-21 16:32:25 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:32:25 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:32:25 --> Utf8 Class Initialized
INFO - 2023-07-21 16:32:25 --> URI Class Initialized
INFO - 2023-07-21 16:32:25 --> Router Class Initialized
INFO - 2023-07-21 16:32:25 --> Output Class Initialized
INFO - 2023-07-21 16:32:25 --> Security Class Initialized
DEBUG - 2023-07-21 16:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:32:25 --> Input Class Initialized
INFO - 2023-07-21 16:32:25 --> Language Class Initialized
INFO - 2023-07-21 16:32:25 --> Loader Class Initialized
INFO - 2023-07-21 16:32:25 --> Helper loaded: url_helper
INFO - 2023-07-21 16:32:25 --> Helper loaded: file_helper
INFO - 2023-07-21 16:32:25 --> Helper loaded: html_helper
INFO - 2023-07-21 16:32:25 --> Helper loaded: text_helper
INFO - 2023-07-21 16:32:25 --> Helper loaded: form_helper
INFO - 2023-07-21 16:32:25 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:32:25 --> Helper loaded: security_helper
INFO - 2023-07-21 16:32:25 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:32:25 --> Database Driver Class Initialized
INFO - 2023-07-21 16:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:32:25 --> Parser Class Initialized
INFO - 2023-07-21 16:32:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:32:25 --> Pagination Class Initialized
INFO - 2023-07-21 16:32:25 --> Form Validation Class Initialized
INFO - 2023-07-21 16:32:25 --> Controller Class Initialized
INFO - 2023-07-21 16:32:25 --> Model Class Initialized
DEBUG - 2023-07-21 16:32:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:32:25 --> Model Class Initialized
DEBUG - 2023-07-21 16:32:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:32:25 --> Model Class Initialized
INFO - 2023-07-21 16:32:25 --> Model Class Initialized
INFO - 2023-07-21 16:32:25 --> Model Class Initialized
INFO - 2023-07-21 16:32:25 --> Model Class Initialized
DEBUG - 2023-07-21 16:32:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:32:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:32:25 --> Model Class Initialized
INFO - 2023-07-21 16:32:25 --> Model Class Initialized
INFO - 2023-07-21 16:32:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-21 16:32:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:32:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:32:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:32:25 --> Model Class Initialized
INFO - 2023-07-21 16:32:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 16:32:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 16:32:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:32:25 --> Final output sent to browser
DEBUG - 2023-07-21 16:32:25 --> Total execution time: 0.1570
ERROR - 2023-07-21 16:32:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:32:31 --> Config Class Initialized
INFO - 2023-07-21 16:32:31 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:32:31 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:32:31 --> Utf8 Class Initialized
INFO - 2023-07-21 16:32:31 --> URI Class Initialized
INFO - 2023-07-21 16:32:31 --> Router Class Initialized
INFO - 2023-07-21 16:32:31 --> Output Class Initialized
INFO - 2023-07-21 16:32:31 --> Security Class Initialized
DEBUG - 2023-07-21 16:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:32:31 --> Input Class Initialized
INFO - 2023-07-21 16:32:31 --> Language Class Initialized
INFO - 2023-07-21 16:32:31 --> Loader Class Initialized
INFO - 2023-07-21 16:32:31 --> Helper loaded: url_helper
INFO - 2023-07-21 16:32:31 --> Helper loaded: file_helper
INFO - 2023-07-21 16:32:31 --> Helper loaded: html_helper
INFO - 2023-07-21 16:32:31 --> Helper loaded: text_helper
INFO - 2023-07-21 16:32:31 --> Helper loaded: form_helper
INFO - 2023-07-21 16:32:31 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:32:31 --> Helper loaded: security_helper
INFO - 2023-07-21 16:32:31 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:32:31 --> Database Driver Class Initialized
INFO - 2023-07-21 16:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:32:31 --> Parser Class Initialized
INFO - 2023-07-21 16:32:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:32:31 --> Pagination Class Initialized
INFO - 2023-07-21 16:32:31 --> Form Validation Class Initialized
INFO - 2023-07-21 16:32:31 --> Controller Class Initialized
INFO - 2023-07-21 16:32:31 --> Model Class Initialized
DEBUG - 2023-07-21 16:32:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:32:31 --> Final output sent to browser
DEBUG - 2023-07-21 16:32:31 --> Total execution time: 0.0131
ERROR - 2023-07-21 16:32:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:32:32 --> Config Class Initialized
INFO - 2023-07-21 16:32:32 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:32:32 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:32:32 --> Utf8 Class Initialized
INFO - 2023-07-21 16:32:32 --> URI Class Initialized
INFO - 2023-07-21 16:32:32 --> Router Class Initialized
INFO - 2023-07-21 16:32:32 --> Output Class Initialized
INFO - 2023-07-21 16:32:32 --> Security Class Initialized
DEBUG - 2023-07-21 16:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:32:32 --> Input Class Initialized
INFO - 2023-07-21 16:32:32 --> Language Class Initialized
INFO - 2023-07-21 16:32:32 --> Loader Class Initialized
INFO - 2023-07-21 16:32:32 --> Helper loaded: url_helper
INFO - 2023-07-21 16:32:32 --> Helper loaded: file_helper
INFO - 2023-07-21 16:32:32 --> Helper loaded: html_helper
INFO - 2023-07-21 16:32:32 --> Helper loaded: text_helper
INFO - 2023-07-21 16:32:32 --> Helper loaded: form_helper
INFO - 2023-07-21 16:32:32 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:32:32 --> Helper loaded: security_helper
INFO - 2023-07-21 16:32:32 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:32:32 --> Database Driver Class Initialized
INFO - 2023-07-21 16:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:32:32 --> Parser Class Initialized
INFO - 2023-07-21 16:32:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:32:32 --> Pagination Class Initialized
INFO - 2023-07-21 16:32:32 --> Form Validation Class Initialized
INFO - 2023-07-21 16:32:32 --> Controller Class Initialized
INFO - 2023-07-21 16:32:32 --> Model Class Initialized
DEBUG - 2023-07-21 16:32:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:32:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-21 16:32:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:32:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:32:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:32:32 --> Model Class Initialized
INFO - 2023-07-21 16:32:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:32:32 --> Final output sent to browser
DEBUG - 2023-07-21 16:32:32 --> Total execution time: 0.0253
ERROR - 2023-07-21 16:32:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:32:38 --> Config Class Initialized
INFO - 2023-07-21 16:32:38 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:32:38 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:32:38 --> Utf8 Class Initialized
INFO - 2023-07-21 16:32:38 --> URI Class Initialized
DEBUG - 2023-07-21 16:32:38 --> No URI present. Default controller set.
INFO - 2023-07-21 16:32:38 --> Router Class Initialized
INFO - 2023-07-21 16:32:38 --> Output Class Initialized
INFO - 2023-07-21 16:32:38 --> Security Class Initialized
DEBUG - 2023-07-21 16:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:32:38 --> Input Class Initialized
INFO - 2023-07-21 16:32:38 --> Language Class Initialized
INFO - 2023-07-21 16:32:38 --> Loader Class Initialized
INFO - 2023-07-21 16:32:38 --> Helper loaded: url_helper
INFO - 2023-07-21 16:32:38 --> Helper loaded: file_helper
INFO - 2023-07-21 16:32:38 --> Helper loaded: html_helper
INFO - 2023-07-21 16:32:38 --> Helper loaded: text_helper
INFO - 2023-07-21 16:32:38 --> Helper loaded: form_helper
INFO - 2023-07-21 16:32:38 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:32:38 --> Helper loaded: security_helper
INFO - 2023-07-21 16:32:38 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:32:38 --> Database Driver Class Initialized
INFO - 2023-07-21 16:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:32:38 --> Parser Class Initialized
INFO - 2023-07-21 16:32:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:32:38 --> Pagination Class Initialized
INFO - 2023-07-21 16:32:38 --> Form Validation Class Initialized
INFO - 2023-07-21 16:32:38 --> Controller Class Initialized
INFO - 2023-07-21 16:32:38 --> Model Class Initialized
DEBUG - 2023-07-21 16:32:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-21 16:32:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:32:39 --> Config Class Initialized
INFO - 2023-07-21 16:32:39 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:32:39 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:32:39 --> Utf8 Class Initialized
INFO - 2023-07-21 16:32:39 --> URI Class Initialized
INFO - 2023-07-21 16:32:39 --> Router Class Initialized
INFO - 2023-07-21 16:32:39 --> Output Class Initialized
INFO - 2023-07-21 16:32:39 --> Security Class Initialized
DEBUG - 2023-07-21 16:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:32:39 --> Input Class Initialized
INFO - 2023-07-21 16:32:39 --> Language Class Initialized
INFO - 2023-07-21 16:32:39 --> Loader Class Initialized
INFO - 2023-07-21 16:32:39 --> Helper loaded: url_helper
INFO - 2023-07-21 16:32:39 --> Helper loaded: file_helper
INFO - 2023-07-21 16:32:39 --> Helper loaded: html_helper
INFO - 2023-07-21 16:32:39 --> Helper loaded: text_helper
INFO - 2023-07-21 16:32:39 --> Helper loaded: form_helper
INFO - 2023-07-21 16:32:39 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:32:39 --> Helper loaded: security_helper
INFO - 2023-07-21 16:32:39 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:32:39 --> Database Driver Class Initialized
INFO - 2023-07-21 16:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:32:39 --> Parser Class Initialized
INFO - 2023-07-21 16:32:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:32:39 --> Pagination Class Initialized
INFO - 2023-07-21 16:32:39 --> Form Validation Class Initialized
INFO - 2023-07-21 16:32:39 --> Controller Class Initialized
INFO - 2023-07-21 16:32:39 --> Model Class Initialized
DEBUG - 2023-07-21 16:32:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:32:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-21 16:32:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:32:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:32:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:32:39 --> Model Class Initialized
INFO - 2023-07-21 16:32:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:32:39 --> Final output sent to browser
DEBUG - 2023-07-21 16:32:39 --> Total execution time: 0.0253
ERROR - 2023-07-21 16:32:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:32:52 --> Config Class Initialized
INFO - 2023-07-21 16:32:52 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:32:52 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:32:52 --> Utf8 Class Initialized
INFO - 2023-07-21 16:32:52 --> URI Class Initialized
INFO - 2023-07-21 16:32:52 --> Router Class Initialized
INFO - 2023-07-21 16:32:52 --> Output Class Initialized
INFO - 2023-07-21 16:32:52 --> Security Class Initialized
DEBUG - 2023-07-21 16:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:32:52 --> Input Class Initialized
INFO - 2023-07-21 16:32:52 --> Language Class Initialized
INFO - 2023-07-21 16:32:52 --> Loader Class Initialized
INFO - 2023-07-21 16:32:52 --> Helper loaded: url_helper
INFO - 2023-07-21 16:32:52 --> Helper loaded: file_helper
INFO - 2023-07-21 16:32:52 --> Helper loaded: html_helper
INFO - 2023-07-21 16:32:52 --> Helper loaded: text_helper
INFO - 2023-07-21 16:32:52 --> Helper loaded: form_helper
INFO - 2023-07-21 16:32:52 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:32:52 --> Helper loaded: security_helper
INFO - 2023-07-21 16:32:52 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:32:52 --> Database Driver Class Initialized
INFO - 2023-07-21 16:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:32:52 --> Parser Class Initialized
INFO - 2023-07-21 16:32:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:32:52 --> Pagination Class Initialized
INFO - 2023-07-21 16:32:52 --> Form Validation Class Initialized
INFO - 2023-07-21 16:32:52 --> Controller Class Initialized
INFO - 2023-07-21 16:32:52 --> Model Class Initialized
DEBUG - 2023-07-21 16:32:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:32:52 --> Model Class Initialized
INFO - 2023-07-21 16:32:52 --> Final output sent to browser
DEBUG - 2023-07-21 16:32:52 --> Total execution time: 0.0181
ERROR - 2023-07-21 16:32:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:32:53 --> Config Class Initialized
INFO - 2023-07-21 16:32:53 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:32:53 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:32:53 --> Utf8 Class Initialized
INFO - 2023-07-21 16:32:53 --> URI Class Initialized
DEBUG - 2023-07-21 16:32:53 --> No URI present. Default controller set.
INFO - 2023-07-21 16:32:53 --> Router Class Initialized
INFO - 2023-07-21 16:32:53 --> Output Class Initialized
INFO - 2023-07-21 16:32:53 --> Security Class Initialized
DEBUG - 2023-07-21 16:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:32:53 --> Input Class Initialized
INFO - 2023-07-21 16:32:53 --> Language Class Initialized
INFO - 2023-07-21 16:32:53 --> Loader Class Initialized
INFO - 2023-07-21 16:32:53 --> Helper loaded: url_helper
INFO - 2023-07-21 16:32:53 --> Helper loaded: file_helper
INFO - 2023-07-21 16:32:53 --> Helper loaded: html_helper
INFO - 2023-07-21 16:32:53 --> Helper loaded: text_helper
INFO - 2023-07-21 16:32:53 --> Helper loaded: form_helper
INFO - 2023-07-21 16:32:53 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:32:53 --> Helper loaded: security_helper
INFO - 2023-07-21 16:32:53 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:32:53 --> Database Driver Class Initialized
INFO - 2023-07-21 16:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:32:53 --> Parser Class Initialized
INFO - 2023-07-21 16:32:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:32:53 --> Pagination Class Initialized
INFO - 2023-07-21 16:32:53 --> Form Validation Class Initialized
INFO - 2023-07-21 16:32:53 --> Controller Class Initialized
INFO - 2023-07-21 16:32:53 --> Model Class Initialized
DEBUG - 2023-07-21 16:32:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:32:53 --> Model Class Initialized
DEBUG - 2023-07-21 16:32:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:32:53 --> Model Class Initialized
INFO - 2023-07-21 16:32:53 --> Model Class Initialized
INFO - 2023-07-21 16:32:53 --> Model Class Initialized
INFO - 2023-07-21 16:32:53 --> Model Class Initialized
DEBUG - 2023-07-21 16:32:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:32:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:32:53 --> Model Class Initialized
INFO - 2023-07-21 16:32:53 --> Model Class Initialized
INFO - 2023-07-21 16:32:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-21 16:32:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:32:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:32:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:32:53 --> Model Class Initialized
INFO - 2023-07-21 16:32:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 16:32:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 16:32:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:32:53 --> Final output sent to browser
DEBUG - 2023-07-21 16:32:53 --> Total execution time: 0.1661
ERROR - 2023-07-21 16:32:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:32:55 --> Config Class Initialized
INFO - 2023-07-21 16:32:55 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:32:55 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:32:55 --> Utf8 Class Initialized
INFO - 2023-07-21 16:32:55 --> URI Class Initialized
INFO - 2023-07-21 16:32:55 --> Router Class Initialized
INFO - 2023-07-21 16:32:55 --> Output Class Initialized
INFO - 2023-07-21 16:32:55 --> Security Class Initialized
DEBUG - 2023-07-21 16:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:32:55 --> Input Class Initialized
INFO - 2023-07-21 16:32:55 --> Language Class Initialized
INFO - 2023-07-21 16:32:55 --> Loader Class Initialized
INFO - 2023-07-21 16:32:55 --> Helper loaded: url_helper
INFO - 2023-07-21 16:32:55 --> Helper loaded: file_helper
INFO - 2023-07-21 16:32:55 --> Helper loaded: html_helper
INFO - 2023-07-21 16:32:55 --> Helper loaded: text_helper
INFO - 2023-07-21 16:32:55 --> Helper loaded: form_helper
INFO - 2023-07-21 16:32:55 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:32:55 --> Helper loaded: security_helper
INFO - 2023-07-21 16:32:55 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:32:55 --> Database Driver Class Initialized
INFO - 2023-07-21 16:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:32:55 --> Parser Class Initialized
INFO - 2023-07-21 16:32:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:32:55 --> Pagination Class Initialized
INFO - 2023-07-21 16:32:55 --> Form Validation Class Initialized
INFO - 2023-07-21 16:32:55 --> Controller Class Initialized
DEBUG - 2023-07-21 16:32:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:32:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:32:55 --> Model Class Initialized
INFO - 2023-07-21 16:32:55 --> Final output sent to browser
DEBUG - 2023-07-21 16:32:55 --> Total execution time: 0.0129
ERROR - 2023-07-21 16:33:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:33:38 --> Config Class Initialized
INFO - 2023-07-21 16:33:38 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:33:38 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:33:38 --> Utf8 Class Initialized
INFO - 2023-07-21 16:33:38 --> URI Class Initialized
INFO - 2023-07-21 16:33:38 --> Router Class Initialized
INFO - 2023-07-21 16:33:38 --> Output Class Initialized
INFO - 2023-07-21 16:33:38 --> Security Class Initialized
DEBUG - 2023-07-21 16:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:33:38 --> Input Class Initialized
INFO - 2023-07-21 16:33:38 --> Language Class Initialized
INFO - 2023-07-21 16:33:38 --> Loader Class Initialized
INFO - 2023-07-21 16:33:38 --> Helper loaded: url_helper
INFO - 2023-07-21 16:33:38 --> Helper loaded: file_helper
INFO - 2023-07-21 16:33:38 --> Helper loaded: html_helper
INFO - 2023-07-21 16:33:38 --> Helper loaded: text_helper
INFO - 2023-07-21 16:33:38 --> Helper loaded: form_helper
INFO - 2023-07-21 16:33:38 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:33:38 --> Helper loaded: security_helper
INFO - 2023-07-21 16:33:38 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:33:38 --> Database Driver Class Initialized
INFO - 2023-07-21 16:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:33:38 --> Parser Class Initialized
INFO - 2023-07-21 16:33:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:33:38 --> Pagination Class Initialized
INFO - 2023-07-21 16:33:38 --> Form Validation Class Initialized
INFO - 2023-07-21 16:33:38 --> Controller Class Initialized
INFO - 2023-07-21 16:33:38 --> Model Class Initialized
DEBUG - 2023-07-21 16:33:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:33:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:33:38 --> Model Class Initialized
DEBUG - 2023-07-21 16:33:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:33:38 --> Model Class Initialized
INFO - 2023-07-21 16:33:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-07-21 16:33:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:33:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:33:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:33:38 --> Model Class Initialized
INFO - 2023-07-21 16:33:38 --> Model Class Initialized
INFO - 2023-07-21 16:33:38 --> Model Class Initialized
INFO - 2023-07-21 16:33:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 16:33:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 16:33:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:33:38 --> Final output sent to browser
DEBUG - 2023-07-21 16:33:38 --> Total execution time: 0.1643
ERROR - 2023-07-21 16:33:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:33:40 --> Config Class Initialized
INFO - 2023-07-21 16:33:40 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:33:40 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:33:40 --> Utf8 Class Initialized
INFO - 2023-07-21 16:33:40 --> URI Class Initialized
INFO - 2023-07-21 16:33:40 --> Router Class Initialized
INFO - 2023-07-21 16:33:40 --> Output Class Initialized
INFO - 2023-07-21 16:33:40 --> Security Class Initialized
DEBUG - 2023-07-21 16:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:33:40 --> Input Class Initialized
INFO - 2023-07-21 16:33:40 --> Language Class Initialized
INFO - 2023-07-21 16:33:40 --> Loader Class Initialized
INFO - 2023-07-21 16:33:40 --> Helper loaded: url_helper
INFO - 2023-07-21 16:33:40 --> Helper loaded: file_helper
INFO - 2023-07-21 16:33:40 --> Helper loaded: html_helper
INFO - 2023-07-21 16:33:40 --> Helper loaded: text_helper
INFO - 2023-07-21 16:33:40 --> Helper loaded: form_helper
INFO - 2023-07-21 16:33:40 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:33:40 --> Helper loaded: security_helper
INFO - 2023-07-21 16:33:40 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:33:40 --> Database Driver Class Initialized
INFO - 2023-07-21 16:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:33:40 --> Parser Class Initialized
INFO - 2023-07-21 16:33:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:33:40 --> Pagination Class Initialized
INFO - 2023-07-21 16:33:40 --> Form Validation Class Initialized
INFO - 2023-07-21 16:33:40 --> Controller Class Initialized
INFO - 2023-07-21 16:33:40 --> Model Class Initialized
DEBUG - 2023-07-21 16:33:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:33:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:33:40 --> Model Class Initialized
DEBUG - 2023-07-21 16:33:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:33:40 --> Model Class Initialized
INFO - 2023-07-21 16:33:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-21 16:33:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:33:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:33:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:33:40 --> Model Class Initialized
INFO - 2023-07-21 16:33:40 --> Model Class Initialized
INFO - 2023-07-21 16:33:40 --> Model Class Initialized
INFO - 2023-07-21 16:33:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 16:33:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 16:33:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:33:40 --> Final output sent to browser
DEBUG - 2023-07-21 16:33:40 --> Total execution time: 0.1333
ERROR - 2023-07-21 16:33:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:33:40 --> Config Class Initialized
INFO - 2023-07-21 16:33:40 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:33:40 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:33:40 --> Utf8 Class Initialized
INFO - 2023-07-21 16:33:40 --> URI Class Initialized
INFO - 2023-07-21 16:33:40 --> Router Class Initialized
INFO - 2023-07-21 16:33:40 --> Output Class Initialized
INFO - 2023-07-21 16:33:40 --> Security Class Initialized
DEBUG - 2023-07-21 16:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:33:40 --> Input Class Initialized
INFO - 2023-07-21 16:33:40 --> Language Class Initialized
INFO - 2023-07-21 16:33:40 --> Loader Class Initialized
INFO - 2023-07-21 16:33:40 --> Helper loaded: url_helper
INFO - 2023-07-21 16:33:40 --> Helper loaded: file_helper
INFO - 2023-07-21 16:33:40 --> Helper loaded: html_helper
INFO - 2023-07-21 16:33:40 --> Helper loaded: text_helper
INFO - 2023-07-21 16:33:40 --> Helper loaded: form_helper
INFO - 2023-07-21 16:33:40 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:33:40 --> Helper loaded: security_helper
INFO - 2023-07-21 16:33:40 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:33:40 --> Database Driver Class Initialized
INFO - 2023-07-21 16:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:33:40 --> Parser Class Initialized
INFO - 2023-07-21 16:33:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:33:40 --> Pagination Class Initialized
INFO - 2023-07-21 16:33:40 --> Form Validation Class Initialized
INFO - 2023-07-21 16:33:40 --> Controller Class Initialized
INFO - 2023-07-21 16:33:40 --> Model Class Initialized
DEBUG - 2023-07-21 16:33:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:33:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:33:40 --> Model Class Initialized
DEBUG - 2023-07-21 16:33:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:33:40 --> Model Class Initialized
INFO - 2023-07-21 16:33:40 --> Final output sent to browser
DEBUG - 2023-07-21 16:33:40 --> Total execution time: 0.0616
ERROR - 2023-07-21 16:33:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:33:43 --> Config Class Initialized
INFO - 2023-07-21 16:33:43 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:33:43 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:33:43 --> Utf8 Class Initialized
INFO - 2023-07-21 16:33:43 --> URI Class Initialized
INFO - 2023-07-21 16:33:43 --> Router Class Initialized
INFO - 2023-07-21 16:33:43 --> Output Class Initialized
INFO - 2023-07-21 16:33:43 --> Security Class Initialized
DEBUG - 2023-07-21 16:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:33:43 --> Input Class Initialized
INFO - 2023-07-21 16:33:43 --> Language Class Initialized
INFO - 2023-07-21 16:33:43 --> Loader Class Initialized
INFO - 2023-07-21 16:33:43 --> Helper loaded: url_helper
INFO - 2023-07-21 16:33:43 --> Helper loaded: file_helper
INFO - 2023-07-21 16:33:43 --> Helper loaded: html_helper
INFO - 2023-07-21 16:33:43 --> Helper loaded: text_helper
INFO - 2023-07-21 16:33:43 --> Helper loaded: form_helper
INFO - 2023-07-21 16:33:43 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:33:43 --> Helper loaded: security_helper
INFO - 2023-07-21 16:33:43 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:33:43 --> Database Driver Class Initialized
INFO - 2023-07-21 16:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:33:43 --> Parser Class Initialized
INFO - 2023-07-21 16:33:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:33:43 --> Pagination Class Initialized
INFO - 2023-07-21 16:33:43 --> Form Validation Class Initialized
INFO - 2023-07-21 16:33:43 --> Controller Class Initialized
INFO - 2023-07-21 16:33:43 --> Model Class Initialized
DEBUG - 2023-07-21 16:33:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:33:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:33:43 --> Model Class Initialized
DEBUG - 2023-07-21 16:33:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:33:43 --> Model Class Initialized
INFO - 2023-07-21 16:33:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-07-21 16:33:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:33:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:33:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:33:43 --> Model Class Initialized
INFO - 2023-07-21 16:33:43 --> Model Class Initialized
INFO - 2023-07-21 16:33:43 --> Model Class Initialized
INFO - 2023-07-21 16:33:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 16:33:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 16:33:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:33:43 --> Final output sent to browser
DEBUG - 2023-07-21 16:33:43 --> Total execution time: 0.1585
ERROR - 2023-07-21 16:34:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:34:25 --> Config Class Initialized
INFO - 2023-07-21 16:34:25 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:34:25 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:34:25 --> Utf8 Class Initialized
INFO - 2023-07-21 16:34:25 --> URI Class Initialized
INFO - 2023-07-21 16:34:25 --> Router Class Initialized
INFO - 2023-07-21 16:34:25 --> Output Class Initialized
INFO - 2023-07-21 16:34:25 --> Security Class Initialized
DEBUG - 2023-07-21 16:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:34:25 --> Input Class Initialized
INFO - 2023-07-21 16:34:25 --> Language Class Initialized
INFO - 2023-07-21 16:34:25 --> Loader Class Initialized
INFO - 2023-07-21 16:34:25 --> Helper loaded: url_helper
INFO - 2023-07-21 16:34:25 --> Helper loaded: file_helper
INFO - 2023-07-21 16:34:25 --> Helper loaded: html_helper
INFO - 2023-07-21 16:34:25 --> Helper loaded: text_helper
INFO - 2023-07-21 16:34:25 --> Helper loaded: form_helper
INFO - 2023-07-21 16:34:25 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:34:25 --> Helper loaded: security_helper
INFO - 2023-07-21 16:34:25 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:34:25 --> Database Driver Class Initialized
INFO - 2023-07-21 16:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:34:25 --> Parser Class Initialized
INFO - 2023-07-21 16:34:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:34:25 --> Pagination Class Initialized
INFO - 2023-07-21 16:34:25 --> Form Validation Class Initialized
INFO - 2023-07-21 16:34:25 --> Controller Class Initialized
INFO - 2023-07-21 16:34:25 --> Model Class Initialized
DEBUG - 2023-07-21 16:34:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:34:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:34:25 --> Model Class Initialized
DEBUG - 2023-07-21 16:34:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:34:25 --> Model Class Initialized
INFO - 2023-07-21 16:34:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-21 16:34:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:34:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:34:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:34:25 --> Model Class Initialized
INFO - 2023-07-21 16:34:25 --> Model Class Initialized
INFO - 2023-07-21 16:34:25 --> Model Class Initialized
INFO - 2023-07-21 16:34:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 16:34:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 16:34:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:34:25 --> Final output sent to browser
DEBUG - 2023-07-21 16:34:25 --> Total execution time: 0.1379
ERROR - 2023-07-21 16:34:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:34:26 --> Config Class Initialized
INFO - 2023-07-21 16:34:26 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:34:26 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:34:26 --> Utf8 Class Initialized
INFO - 2023-07-21 16:34:26 --> URI Class Initialized
INFO - 2023-07-21 16:34:26 --> Router Class Initialized
INFO - 2023-07-21 16:34:26 --> Output Class Initialized
INFO - 2023-07-21 16:34:26 --> Security Class Initialized
DEBUG - 2023-07-21 16:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:34:26 --> Input Class Initialized
INFO - 2023-07-21 16:34:26 --> Language Class Initialized
INFO - 2023-07-21 16:34:26 --> Loader Class Initialized
INFO - 2023-07-21 16:34:26 --> Helper loaded: url_helper
INFO - 2023-07-21 16:34:26 --> Helper loaded: file_helper
INFO - 2023-07-21 16:34:26 --> Helper loaded: html_helper
INFO - 2023-07-21 16:34:26 --> Helper loaded: text_helper
INFO - 2023-07-21 16:34:26 --> Helper loaded: form_helper
INFO - 2023-07-21 16:34:26 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:34:26 --> Helper loaded: security_helper
INFO - 2023-07-21 16:34:26 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:34:26 --> Database Driver Class Initialized
INFO - 2023-07-21 16:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:34:26 --> Parser Class Initialized
INFO - 2023-07-21 16:34:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:34:26 --> Pagination Class Initialized
INFO - 2023-07-21 16:34:26 --> Form Validation Class Initialized
INFO - 2023-07-21 16:34:26 --> Controller Class Initialized
INFO - 2023-07-21 16:34:26 --> Model Class Initialized
DEBUG - 2023-07-21 16:34:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:34:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:34:26 --> Model Class Initialized
DEBUG - 2023-07-21 16:34:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:34:26 --> Model Class Initialized
INFO - 2023-07-21 16:34:26 --> Final output sent to browser
DEBUG - 2023-07-21 16:34:26 --> Total execution time: 0.0554
ERROR - 2023-07-21 16:34:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:34:40 --> Config Class Initialized
INFO - 2023-07-21 16:34:40 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:34:40 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:34:40 --> Utf8 Class Initialized
INFO - 2023-07-21 16:34:40 --> URI Class Initialized
INFO - 2023-07-21 16:34:40 --> Router Class Initialized
INFO - 2023-07-21 16:34:40 --> Output Class Initialized
INFO - 2023-07-21 16:34:40 --> Security Class Initialized
DEBUG - 2023-07-21 16:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:34:40 --> Input Class Initialized
INFO - 2023-07-21 16:34:40 --> Language Class Initialized
INFO - 2023-07-21 16:34:40 --> Loader Class Initialized
INFO - 2023-07-21 16:34:40 --> Helper loaded: url_helper
INFO - 2023-07-21 16:34:40 --> Helper loaded: file_helper
INFO - 2023-07-21 16:34:40 --> Helper loaded: html_helper
INFO - 2023-07-21 16:34:40 --> Helper loaded: text_helper
INFO - 2023-07-21 16:34:40 --> Helper loaded: form_helper
INFO - 2023-07-21 16:34:40 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:34:40 --> Helper loaded: security_helper
INFO - 2023-07-21 16:34:40 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:34:40 --> Database Driver Class Initialized
INFO - 2023-07-21 16:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:34:40 --> Parser Class Initialized
INFO - 2023-07-21 16:34:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:34:40 --> Pagination Class Initialized
INFO - 2023-07-21 16:34:40 --> Form Validation Class Initialized
INFO - 2023-07-21 16:34:40 --> Controller Class Initialized
DEBUG - 2023-07-21 16:34:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:34:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:34:40 --> Model Class Initialized
DEBUG - 2023-07-21 16:34:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:34:40 --> Model Class Initialized
INFO - 2023-07-21 16:34:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2023-07-21 16:34:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:34:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:34:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:34:40 --> Model Class Initialized
INFO - 2023-07-21 16:34:40 --> Model Class Initialized
INFO - 2023-07-21 16:34:40 --> Model Class Initialized
INFO - 2023-07-21 16:34:40 --> Model Class Initialized
INFO - 2023-07-21 16:34:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 16:34:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 16:34:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:34:40 --> Final output sent to browser
DEBUG - 2023-07-21 16:34:40 --> Total execution time: 0.1635
ERROR - 2023-07-21 16:34:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:34:55 --> Config Class Initialized
INFO - 2023-07-21 16:34:55 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:34:55 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:34:55 --> Utf8 Class Initialized
INFO - 2023-07-21 16:34:55 --> URI Class Initialized
INFO - 2023-07-21 16:34:55 --> Router Class Initialized
INFO - 2023-07-21 16:34:55 --> Output Class Initialized
INFO - 2023-07-21 16:34:55 --> Security Class Initialized
DEBUG - 2023-07-21 16:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:34:55 --> Input Class Initialized
INFO - 2023-07-21 16:34:55 --> Language Class Initialized
INFO - 2023-07-21 16:34:55 --> Loader Class Initialized
INFO - 2023-07-21 16:34:55 --> Helper loaded: url_helper
INFO - 2023-07-21 16:34:55 --> Helper loaded: file_helper
INFO - 2023-07-21 16:34:55 --> Helper loaded: html_helper
INFO - 2023-07-21 16:34:55 --> Helper loaded: text_helper
INFO - 2023-07-21 16:34:55 --> Helper loaded: form_helper
INFO - 2023-07-21 16:34:55 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:34:55 --> Helper loaded: security_helper
INFO - 2023-07-21 16:34:55 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:34:55 --> Database Driver Class Initialized
INFO - 2023-07-21 16:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:34:55 --> Parser Class Initialized
INFO - 2023-07-21 16:34:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:34:55 --> Pagination Class Initialized
INFO - 2023-07-21 16:34:55 --> Form Validation Class Initialized
INFO - 2023-07-21 16:34:55 --> Controller Class Initialized
DEBUG - 2023-07-21 16:34:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:34:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:34:55 --> Model Class Initialized
DEBUG - 2023-07-21 16:34:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:34:55 --> Model Class Initialized
DEBUG - 2023-07-21 16:34:55 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:34:55 --> Model Class Initialized
INFO - 2023-07-21 16:34:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-07-21 16:34:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:34:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:34:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:34:55 --> Model Class Initialized
INFO - 2023-07-21 16:34:55 --> Model Class Initialized
INFO - 2023-07-21 16:34:55 --> Model Class Initialized
INFO - 2023-07-21 16:34:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 16:34:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 16:34:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:34:55 --> Final output sent to browser
DEBUG - 2023-07-21 16:34:55 --> Total execution time: 0.1280
ERROR - 2023-07-21 16:34:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:34:56 --> Config Class Initialized
INFO - 2023-07-21 16:34:56 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:34:56 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:34:56 --> Utf8 Class Initialized
INFO - 2023-07-21 16:34:56 --> URI Class Initialized
INFO - 2023-07-21 16:34:56 --> Router Class Initialized
INFO - 2023-07-21 16:34:56 --> Output Class Initialized
INFO - 2023-07-21 16:34:56 --> Security Class Initialized
DEBUG - 2023-07-21 16:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:34:56 --> Input Class Initialized
INFO - 2023-07-21 16:34:56 --> Language Class Initialized
INFO - 2023-07-21 16:34:56 --> Loader Class Initialized
INFO - 2023-07-21 16:34:56 --> Helper loaded: url_helper
INFO - 2023-07-21 16:34:56 --> Helper loaded: file_helper
INFO - 2023-07-21 16:34:56 --> Helper loaded: html_helper
INFO - 2023-07-21 16:34:56 --> Helper loaded: text_helper
INFO - 2023-07-21 16:34:56 --> Helper loaded: form_helper
INFO - 2023-07-21 16:34:56 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:34:56 --> Helper loaded: security_helper
INFO - 2023-07-21 16:34:56 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:34:56 --> Database Driver Class Initialized
INFO - 2023-07-21 16:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:34:56 --> Parser Class Initialized
INFO - 2023-07-21 16:34:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:34:56 --> Pagination Class Initialized
INFO - 2023-07-21 16:34:56 --> Form Validation Class Initialized
INFO - 2023-07-21 16:34:56 --> Controller Class Initialized
DEBUG - 2023-07-21 16:34:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:34:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:34:56 --> Model Class Initialized
DEBUG - 2023-07-21 16:34:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:34:56 --> Model Class Initialized
INFO - 2023-07-21 16:34:56 --> Final output sent to browser
DEBUG - 2023-07-21 16:34:56 --> Total execution time: 0.0331
ERROR - 2023-07-21 16:35:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:35:05 --> Config Class Initialized
INFO - 2023-07-21 16:35:05 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:35:05 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:35:05 --> Utf8 Class Initialized
INFO - 2023-07-21 16:35:05 --> URI Class Initialized
INFO - 2023-07-21 16:35:05 --> Router Class Initialized
INFO - 2023-07-21 16:35:05 --> Output Class Initialized
INFO - 2023-07-21 16:35:05 --> Security Class Initialized
DEBUG - 2023-07-21 16:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:35:05 --> Input Class Initialized
INFO - 2023-07-21 16:35:05 --> Language Class Initialized
INFO - 2023-07-21 16:35:05 --> Loader Class Initialized
INFO - 2023-07-21 16:35:05 --> Helper loaded: url_helper
INFO - 2023-07-21 16:35:05 --> Helper loaded: file_helper
INFO - 2023-07-21 16:35:05 --> Helper loaded: html_helper
INFO - 2023-07-21 16:35:05 --> Helper loaded: text_helper
INFO - 2023-07-21 16:35:05 --> Helper loaded: form_helper
INFO - 2023-07-21 16:35:05 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:35:05 --> Helper loaded: security_helper
INFO - 2023-07-21 16:35:05 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:35:05 --> Database Driver Class Initialized
INFO - 2023-07-21 16:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:35:05 --> Parser Class Initialized
INFO - 2023-07-21 16:35:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:35:05 --> Pagination Class Initialized
INFO - 2023-07-21 16:35:05 --> Form Validation Class Initialized
INFO - 2023-07-21 16:35:05 --> Controller Class Initialized
DEBUG - 2023-07-21 16:35:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:35:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:35:05 --> Model Class Initialized
DEBUG - 2023-07-21 16:35:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:35:05 --> Model Class Initialized
INFO - 2023-07-21 16:35:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/edit_customer_form.php
DEBUG - 2023-07-21 16:35:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:35:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:35:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:35:05 --> Model Class Initialized
INFO - 2023-07-21 16:35:05 --> Model Class Initialized
INFO - 2023-07-21 16:35:05 --> Model Class Initialized
INFO - 2023-07-21 16:35:05 --> Model Class Initialized
INFO - 2023-07-21 16:35:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 16:35:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 16:35:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:35:05 --> Final output sent to browser
DEBUG - 2023-07-21 16:35:05 --> Total execution time: 0.1516
ERROR - 2023-07-21 16:35:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:35:13 --> Config Class Initialized
INFO - 2023-07-21 16:35:13 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:35:13 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:35:13 --> Utf8 Class Initialized
INFO - 2023-07-21 16:35:13 --> URI Class Initialized
INFO - 2023-07-21 16:35:13 --> Router Class Initialized
INFO - 2023-07-21 16:35:13 --> Output Class Initialized
INFO - 2023-07-21 16:35:13 --> Security Class Initialized
DEBUG - 2023-07-21 16:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:35:13 --> Input Class Initialized
INFO - 2023-07-21 16:35:13 --> Language Class Initialized
INFO - 2023-07-21 16:35:13 --> Loader Class Initialized
INFO - 2023-07-21 16:35:13 --> Helper loaded: url_helper
INFO - 2023-07-21 16:35:13 --> Helper loaded: file_helper
INFO - 2023-07-21 16:35:13 --> Helper loaded: html_helper
INFO - 2023-07-21 16:35:13 --> Helper loaded: text_helper
INFO - 2023-07-21 16:35:13 --> Helper loaded: form_helper
INFO - 2023-07-21 16:35:13 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:35:13 --> Helper loaded: security_helper
INFO - 2023-07-21 16:35:13 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:35:13 --> Database Driver Class Initialized
INFO - 2023-07-21 16:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:35:13 --> Parser Class Initialized
INFO - 2023-07-21 16:35:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:35:13 --> Pagination Class Initialized
INFO - 2023-07-21 16:35:13 --> Form Validation Class Initialized
INFO - 2023-07-21 16:35:13 --> Controller Class Initialized
DEBUG - 2023-07-21 16:35:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:35:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:35:13 --> Model Class Initialized
DEBUG - 2023-07-21 16:35:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:35:13 --> Model Class Initialized
DEBUG - 2023-07-21 16:35:13 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:35:13 --> Model Class Initialized
INFO - 2023-07-21 16:35:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-07-21 16:35:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:35:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:35:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:35:13 --> Model Class Initialized
INFO - 2023-07-21 16:35:13 --> Model Class Initialized
INFO - 2023-07-21 16:35:13 --> Model Class Initialized
INFO - 2023-07-21 16:35:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 16:35:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 16:35:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:35:13 --> Final output sent to browser
DEBUG - 2023-07-21 16:35:13 --> Total execution time: 0.1300
ERROR - 2023-07-21 16:35:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:35:13 --> Config Class Initialized
INFO - 2023-07-21 16:35:13 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:35:13 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:35:13 --> Utf8 Class Initialized
INFO - 2023-07-21 16:35:13 --> URI Class Initialized
INFO - 2023-07-21 16:35:13 --> Router Class Initialized
INFO - 2023-07-21 16:35:13 --> Output Class Initialized
INFO - 2023-07-21 16:35:13 --> Security Class Initialized
DEBUG - 2023-07-21 16:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:35:13 --> Input Class Initialized
INFO - 2023-07-21 16:35:13 --> Language Class Initialized
INFO - 2023-07-21 16:35:13 --> Loader Class Initialized
INFO - 2023-07-21 16:35:13 --> Helper loaded: url_helper
INFO - 2023-07-21 16:35:13 --> Helper loaded: file_helper
INFO - 2023-07-21 16:35:13 --> Helper loaded: html_helper
INFO - 2023-07-21 16:35:13 --> Helper loaded: text_helper
INFO - 2023-07-21 16:35:13 --> Helper loaded: form_helper
INFO - 2023-07-21 16:35:13 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:35:13 --> Helper loaded: security_helper
INFO - 2023-07-21 16:35:13 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:35:13 --> Database Driver Class Initialized
INFO - 2023-07-21 16:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:35:13 --> Parser Class Initialized
INFO - 2023-07-21 16:35:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:35:13 --> Pagination Class Initialized
INFO - 2023-07-21 16:35:13 --> Form Validation Class Initialized
INFO - 2023-07-21 16:35:13 --> Controller Class Initialized
DEBUG - 2023-07-21 16:35:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:35:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:35:13 --> Model Class Initialized
DEBUG - 2023-07-21 16:35:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:35:13 --> Model Class Initialized
INFO - 2023-07-21 16:35:13 --> Final output sent to browser
DEBUG - 2023-07-21 16:35:13 --> Total execution time: 0.0280
ERROR - 2023-07-21 16:35:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:35:48 --> Config Class Initialized
INFO - 2023-07-21 16:35:48 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:35:48 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:35:48 --> Utf8 Class Initialized
INFO - 2023-07-21 16:35:48 --> URI Class Initialized
INFO - 2023-07-21 16:35:48 --> Router Class Initialized
INFO - 2023-07-21 16:35:48 --> Output Class Initialized
INFO - 2023-07-21 16:35:48 --> Security Class Initialized
DEBUG - 2023-07-21 16:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:35:48 --> Input Class Initialized
INFO - 2023-07-21 16:35:48 --> Language Class Initialized
INFO - 2023-07-21 16:35:48 --> Loader Class Initialized
INFO - 2023-07-21 16:35:48 --> Helper loaded: url_helper
INFO - 2023-07-21 16:35:48 --> Helper loaded: file_helper
INFO - 2023-07-21 16:35:48 --> Helper loaded: html_helper
INFO - 2023-07-21 16:35:48 --> Helper loaded: text_helper
INFO - 2023-07-21 16:35:48 --> Helper loaded: form_helper
INFO - 2023-07-21 16:35:48 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:35:48 --> Helper loaded: security_helper
INFO - 2023-07-21 16:35:48 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:35:48 --> Database Driver Class Initialized
INFO - 2023-07-21 16:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:35:48 --> Parser Class Initialized
INFO - 2023-07-21 16:35:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:35:48 --> Pagination Class Initialized
INFO - 2023-07-21 16:35:48 --> Form Validation Class Initialized
INFO - 2023-07-21 16:35:48 --> Controller Class Initialized
DEBUG - 2023-07-21 16:35:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:35:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:35:48 --> Model Class Initialized
DEBUG - 2023-07-21 16:35:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:35:48 --> Model Class Initialized
INFO - 2023-07-21 16:35:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2023-07-21 16:35:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:35:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:35:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:35:48 --> Model Class Initialized
INFO - 2023-07-21 16:35:48 --> Model Class Initialized
INFO - 2023-07-21 16:35:48 --> Model Class Initialized
INFO - 2023-07-21 16:35:48 --> Model Class Initialized
INFO - 2023-07-21 16:35:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 16:35:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 16:35:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:35:48 --> Final output sent to browser
DEBUG - 2023-07-21 16:35:48 --> Total execution time: 0.1731
ERROR - 2023-07-21 16:35:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:35:57 --> Config Class Initialized
INFO - 2023-07-21 16:35:57 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:35:57 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:35:57 --> Utf8 Class Initialized
INFO - 2023-07-21 16:35:57 --> URI Class Initialized
INFO - 2023-07-21 16:35:57 --> Router Class Initialized
INFO - 2023-07-21 16:35:57 --> Output Class Initialized
INFO - 2023-07-21 16:35:57 --> Security Class Initialized
DEBUG - 2023-07-21 16:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:35:57 --> Input Class Initialized
INFO - 2023-07-21 16:35:57 --> Language Class Initialized
INFO - 2023-07-21 16:35:57 --> Loader Class Initialized
INFO - 2023-07-21 16:35:57 --> Helper loaded: url_helper
INFO - 2023-07-21 16:35:57 --> Helper loaded: file_helper
INFO - 2023-07-21 16:35:57 --> Helper loaded: html_helper
INFO - 2023-07-21 16:35:57 --> Helper loaded: text_helper
INFO - 2023-07-21 16:35:57 --> Helper loaded: form_helper
INFO - 2023-07-21 16:35:57 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:35:57 --> Helper loaded: security_helper
INFO - 2023-07-21 16:35:57 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:35:57 --> Database Driver Class Initialized
INFO - 2023-07-21 16:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:35:57 --> Parser Class Initialized
INFO - 2023-07-21 16:35:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:35:57 --> Pagination Class Initialized
INFO - 2023-07-21 16:35:57 --> Form Validation Class Initialized
INFO - 2023-07-21 16:35:57 --> Controller Class Initialized
DEBUG - 2023-07-21 16:35:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:35:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:35:57 --> Model Class Initialized
DEBUG - 2023-07-21 16:35:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:35:57 --> Model Class Initialized
DEBUG - 2023-07-21 16:35:57 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:35:57 --> Model Class Initialized
INFO - 2023-07-21 16:35:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-07-21 16:35:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:35:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:35:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:35:57 --> Model Class Initialized
INFO - 2023-07-21 16:35:57 --> Model Class Initialized
INFO - 2023-07-21 16:35:57 --> Model Class Initialized
INFO - 2023-07-21 16:35:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 16:35:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 16:35:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:35:57 --> Final output sent to browser
DEBUG - 2023-07-21 16:35:57 --> Total execution time: 0.1265
ERROR - 2023-07-21 16:35:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:35:57 --> Config Class Initialized
INFO - 2023-07-21 16:35:57 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:35:57 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:35:57 --> Utf8 Class Initialized
INFO - 2023-07-21 16:35:57 --> URI Class Initialized
INFO - 2023-07-21 16:35:57 --> Router Class Initialized
INFO - 2023-07-21 16:35:57 --> Output Class Initialized
INFO - 2023-07-21 16:35:57 --> Security Class Initialized
DEBUG - 2023-07-21 16:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:35:57 --> Input Class Initialized
INFO - 2023-07-21 16:35:57 --> Language Class Initialized
INFO - 2023-07-21 16:35:57 --> Loader Class Initialized
INFO - 2023-07-21 16:35:57 --> Helper loaded: url_helper
INFO - 2023-07-21 16:35:57 --> Helper loaded: file_helper
INFO - 2023-07-21 16:35:57 --> Helper loaded: html_helper
INFO - 2023-07-21 16:35:57 --> Helper loaded: text_helper
INFO - 2023-07-21 16:35:57 --> Helper loaded: form_helper
INFO - 2023-07-21 16:35:57 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:35:57 --> Helper loaded: security_helper
INFO - 2023-07-21 16:35:57 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:35:57 --> Database Driver Class Initialized
INFO - 2023-07-21 16:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:35:57 --> Parser Class Initialized
INFO - 2023-07-21 16:35:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:35:57 --> Pagination Class Initialized
INFO - 2023-07-21 16:35:57 --> Form Validation Class Initialized
INFO - 2023-07-21 16:35:57 --> Controller Class Initialized
DEBUG - 2023-07-21 16:35:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:35:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:35:57 --> Model Class Initialized
DEBUG - 2023-07-21 16:35:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:35:57 --> Model Class Initialized
INFO - 2023-07-21 16:35:57 --> Final output sent to browser
DEBUG - 2023-07-21 16:35:57 --> Total execution time: 0.0283
ERROR - 2023-07-21 16:36:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:36:42 --> Config Class Initialized
INFO - 2023-07-21 16:36:42 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:36:42 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:36:42 --> Utf8 Class Initialized
INFO - 2023-07-21 16:36:42 --> URI Class Initialized
INFO - 2023-07-21 16:36:42 --> Router Class Initialized
INFO - 2023-07-21 16:36:42 --> Output Class Initialized
INFO - 2023-07-21 16:36:42 --> Security Class Initialized
DEBUG - 2023-07-21 16:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:36:42 --> Input Class Initialized
INFO - 2023-07-21 16:36:42 --> Language Class Initialized
INFO - 2023-07-21 16:36:42 --> Loader Class Initialized
INFO - 2023-07-21 16:36:42 --> Helper loaded: url_helper
INFO - 2023-07-21 16:36:42 --> Helper loaded: file_helper
INFO - 2023-07-21 16:36:42 --> Helper loaded: html_helper
INFO - 2023-07-21 16:36:42 --> Helper loaded: text_helper
INFO - 2023-07-21 16:36:42 --> Helper loaded: form_helper
INFO - 2023-07-21 16:36:42 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:36:42 --> Helper loaded: security_helper
INFO - 2023-07-21 16:36:42 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:36:42 --> Database Driver Class Initialized
INFO - 2023-07-21 16:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:36:42 --> Parser Class Initialized
INFO - 2023-07-21 16:36:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:36:42 --> Pagination Class Initialized
INFO - 2023-07-21 16:36:42 --> Form Validation Class Initialized
INFO - 2023-07-21 16:36:42 --> Controller Class Initialized
DEBUG - 2023-07-21 16:36:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:36:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:36:42 --> Model Class Initialized
DEBUG - 2023-07-21 16:36:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:36:42 --> Model Class Initialized
INFO - 2023-07-21 16:36:42 --> Final output sent to browser
DEBUG - 2023-07-21 16:36:42 --> Total execution time: 0.0329
ERROR - 2023-07-21 16:36:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:36:43 --> Config Class Initialized
INFO - 2023-07-21 16:36:43 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:36:43 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:36:43 --> Utf8 Class Initialized
INFO - 2023-07-21 16:36:43 --> URI Class Initialized
INFO - 2023-07-21 16:36:43 --> Router Class Initialized
INFO - 2023-07-21 16:36:43 --> Output Class Initialized
INFO - 2023-07-21 16:36:43 --> Security Class Initialized
DEBUG - 2023-07-21 16:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:36:43 --> Input Class Initialized
INFO - 2023-07-21 16:36:43 --> Language Class Initialized
INFO - 2023-07-21 16:36:43 --> Loader Class Initialized
INFO - 2023-07-21 16:36:43 --> Helper loaded: url_helper
INFO - 2023-07-21 16:36:43 --> Helper loaded: file_helper
INFO - 2023-07-21 16:36:43 --> Helper loaded: html_helper
INFO - 2023-07-21 16:36:43 --> Helper loaded: text_helper
INFO - 2023-07-21 16:36:43 --> Helper loaded: form_helper
INFO - 2023-07-21 16:36:43 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:36:43 --> Helper loaded: security_helper
INFO - 2023-07-21 16:36:43 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:36:43 --> Database Driver Class Initialized
INFO - 2023-07-21 16:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:36:43 --> Parser Class Initialized
INFO - 2023-07-21 16:36:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:36:43 --> Pagination Class Initialized
INFO - 2023-07-21 16:36:43 --> Form Validation Class Initialized
INFO - 2023-07-21 16:36:43 --> Controller Class Initialized
DEBUG - 2023-07-21 16:36:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:36:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:36:43 --> Model Class Initialized
DEBUG - 2023-07-21 16:36:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:36:43 --> Model Class Initialized
INFO - 2023-07-21 16:36:43 --> Final output sent to browser
DEBUG - 2023-07-21 16:36:43 --> Total execution time: 0.0286
ERROR - 2023-07-21 16:36:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:36:44 --> Config Class Initialized
INFO - 2023-07-21 16:36:44 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:36:44 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:36:44 --> Utf8 Class Initialized
INFO - 2023-07-21 16:36:44 --> URI Class Initialized
INFO - 2023-07-21 16:36:44 --> Router Class Initialized
INFO - 2023-07-21 16:36:44 --> Output Class Initialized
INFO - 2023-07-21 16:36:44 --> Security Class Initialized
DEBUG - 2023-07-21 16:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:36:44 --> Input Class Initialized
INFO - 2023-07-21 16:36:44 --> Language Class Initialized
INFO - 2023-07-21 16:36:44 --> Loader Class Initialized
INFO - 2023-07-21 16:36:44 --> Helper loaded: url_helper
INFO - 2023-07-21 16:36:44 --> Helper loaded: file_helper
INFO - 2023-07-21 16:36:44 --> Helper loaded: html_helper
INFO - 2023-07-21 16:36:44 --> Helper loaded: text_helper
INFO - 2023-07-21 16:36:44 --> Helper loaded: form_helper
INFO - 2023-07-21 16:36:44 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:36:44 --> Helper loaded: security_helper
INFO - 2023-07-21 16:36:44 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:36:44 --> Database Driver Class Initialized
INFO - 2023-07-21 16:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:36:44 --> Parser Class Initialized
INFO - 2023-07-21 16:36:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:36:44 --> Pagination Class Initialized
INFO - 2023-07-21 16:36:44 --> Form Validation Class Initialized
INFO - 2023-07-21 16:36:44 --> Controller Class Initialized
DEBUG - 2023-07-21 16:36:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:36:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:36:44 --> Model Class Initialized
DEBUG - 2023-07-21 16:36:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:36:44 --> Model Class Initialized
INFO - 2023-07-21 16:36:44 --> Final output sent to browser
DEBUG - 2023-07-21 16:36:44 --> Total execution time: 0.0258
ERROR - 2023-07-21 16:36:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:36:45 --> Config Class Initialized
INFO - 2023-07-21 16:36:45 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:36:45 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:36:45 --> Utf8 Class Initialized
INFO - 2023-07-21 16:36:45 --> URI Class Initialized
INFO - 2023-07-21 16:36:45 --> Router Class Initialized
INFO - 2023-07-21 16:36:45 --> Output Class Initialized
INFO - 2023-07-21 16:36:45 --> Security Class Initialized
DEBUG - 2023-07-21 16:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:36:45 --> Input Class Initialized
INFO - 2023-07-21 16:36:45 --> Language Class Initialized
INFO - 2023-07-21 16:36:45 --> Loader Class Initialized
INFO - 2023-07-21 16:36:45 --> Helper loaded: url_helper
INFO - 2023-07-21 16:36:45 --> Helper loaded: file_helper
INFO - 2023-07-21 16:36:45 --> Helper loaded: html_helper
INFO - 2023-07-21 16:36:45 --> Helper loaded: text_helper
INFO - 2023-07-21 16:36:45 --> Helper loaded: form_helper
INFO - 2023-07-21 16:36:45 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:36:45 --> Helper loaded: security_helper
INFO - 2023-07-21 16:36:45 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:36:45 --> Database Driver Class Initialized
INFO - 2023-07-21 16:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:36:45 --> Parser Class Initialized
INFO - 2023-07-21 16:36:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:36:45 --> Pagination Class Initialized
INFO - 2023-07-21 16:36:45 --> Form Validation Class Initialized
INFO - 2023-07-21 16:36:45 --> Controller Class Initialized
DEBUG - 2023-07-21 16:36:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:36:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:36:45 --> Model Class Initialized
DEBUG - 2023-07-21 16:36:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:36:45 --> Model Class Initialized
INFO - 2023-07-21 16:36:45 --> Final output sent to browser
DEBUG - 2023-07-21 16:36:45 --> Total execution time: 0.0184
ERROR - 2023-07-21 16:36:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:36:45 --> Config Class Initialized
INFO - 2023-07-21 16:36:45 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:36:45 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:36:45 --> Utf8 Class Initialized
INFO - 2023-07-21 16:36:45 --> URI Class Initialized
INFO - 2023-07-21 16:36:45 --> Router Class Initialized
INFO - 2023-07-21 16:36:45 --> Output Class Initialized
INFO - 2023-07-21 16:36:45 --> Security Class Initialized
DEBUG - 2023-07-21 16:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:36:45 --> Input Class Initialized
INFO - 2023-07-21 16:36:45 --> Language Class Initialized
INFO - 2023-07-21 16:36:45 --> Loader Class Initialized
INFO - 2023-07-21 16:36:45 --> Helper loaded: url_helper
INFO - 2023-07-21 16:36:45 --> Helper loaded: file_helper
INFO - 2023-07-21 16:36:45 --> Helper loaded: html_helper
INFO - 2023-07-21 16:36:45 --> Helper loaded: text_helper
INFO - 2023-07-21 16:36:45 --> Helper loaded: form_helper
INFO - 2023-07-21 16:36:45 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:36:45 --> Helper loaded: security_helper
INFO - 2023-07-21 16:36:45 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:36:45 --> Database Driver Class Initialized
INFO - 2023-07-21 16:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:36:45 --> Parser Class Initialized
INFO - 2023-07-21 16:36:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:36:45 --> Pagination Class Initialized
INFO - 2023-07-21 16:36:45 --> Form Validation Class Initialized
INFO - 2023-07-21 16:36:45 --> Controller Class Initialized
DEBUG - 2023-07-21 16:36:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:36:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:36:45 --> Model Class Initialized
DEBUG - 2023-07-21 16:36:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:36:45 --> Model Class Initialized
INFO - 2023-07-21 16:36:45 --> Final output sent to browser
DEBUG - 2023-07-21 16:36:45 --> Total execution time: 0.0186
ERROR - 2023-07-21 16:36:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:36:49 --> Config Class Initialized
INFO - 2023-07-21 16:36:49 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:36:49 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:36:49 --> Utf8 Class Initialized
INFO - 2023-07-21 16:36:49 --> URI Class Initialized
INFO - 2023-07-21 16:36:49 --> Router Class Initialized
INFO - 2023-07-21 16:36:49 --> Output Class Initialized
INFO - 2023-07-21 16:36:49 --> Security Class Initialized
DEBUG - 2023-07-21 16:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:36:49 --> Input Class Initialized
INFO - 2023-07-21 16:36:49 --> Language Class Initialized
INFO - 2023-07-21 16:36:49 --> Loader Class Initialized
INFO - 2023-07-21 16:36:49 --> Helper loaded: url_helper
INFO - 2023-07-21 16:36:49 --> Helper loaded: file_helper
INFO - 2023-07-21 16:36:49 --> Helper loaded: html_helper
INFO - 2023-07-21 16:36:49 --> Helper loaded: text_helper
INFO - 2023-07-21 16:36:49 --> Helper loaded: form_helper
INFO - 2023-07-21 16:36:49 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:36:49 --> Helper loaded: security_helper
INFO - 2023-07-21 16:36:49 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:36:49 --> Database Driver Class Initialized
INFO - 2023-07-21 16:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:36:49 --> Parser Class Initialized
INFO - 2023-07-21 16:36:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:36:49 --> Pagination Class Initialized
INFO - 2023-07-21 16:36:49 --> Form Validation Class Initialized
INFO - 2023-07-21 16:36:49 --> Controller Class Initialized
DEBUG - 2023-07-21 16:36:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:36:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:36:49 --> Model Class Initialized
DEBUG - 2023-07-21 16:36:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:36:49 --> Model Class Initialized
INFO - 2023-07-21 16:36:49 --> Final output sent to browser
DEBUG - 2023-07-21 16:36:49 --> Total execution time: 0.0217
ERROR - 2023-07-21 16:36:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:36:50 --> Config Class Initialized
INFO - 2023-07-21 16:36:50 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:36:50 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:36:50 --> Utf8 Class Initialized
INFO - 2023-07-21 16:36:50 --> URI Class Initialized
INFO - 2023-07-21 16:36:50 --> Router Class Initialized
INFO - 2023-07-21 16:36:50 --> Output Class Initialized
INFO - 2023-07-21 16:36:50 --> Security Class Initialized
DEBUG - 2023-07-21 16:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:36:50 --> Input Class Initialized
INFO - 2023-07-21 16:36:50 --> Language Class Initialized
INFO - 2023-07-21 16:36:50 --> Loader Class Initialized
INFO - 2023-07-21 16:36:50 --> Helper loaded: url_helper
INFO - 2023-07-21 16:36:50 --> Helper loaded: file_helper
INFO - 2023-07-21 16:36:50 --> Helper loaded: html_helper
INFO - 2023-07-21 16:36:50 --> Helper loaded: text_helper
INFO - 2023-07-21 16:36:50 --> Helper loaded: form_helper
INFO - 2023-07-21 16:36:50 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:36:50 --> Helper loaded: security_helper
INFO - 2023-07-21 16:36:50 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:36:50 --> Database Driver Class Initialized
INFO - 2023-07-21 16:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:36:50 --> Parser Class Initialized
INFO - 2023-07-21 16:36:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:36:50 --> Pagination Class Initialized
INFO - 2023-07-21 16:36:50 --> Form Validation Class Initialized
INFO - 2023-07-21 16:36:50 --> Controller Class Initialized
DEBUG - 2023-07-21 16:36:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:36:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:36:50 --> Model Class Initialized
DEBUG - 2023-07-21 16:36:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:36:50 --> Model Class Initialized
INFO - 2023-07-21 16:36:50 --> Final output sent to browser
DEBUG - 2023-07-21 16:36:50 --> Total execution time: 0.0291
ERROR - 2023-07-21 16:36:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:36:51 --> Config Class Initialized
INFO - 2023-07-21 16:36:51 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:36:51 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:36:51 --> Utf8 Class Initialized
INFO - 2023-07-21 16:36:51 --> URI Class Initialized
INFO - 2023-07-21 16:36:51 --> Router Class Initialized
INFO - 2023-07-21 16:36:51 --> Output Class Initialized
INFO - 2023-07-21 16:36:51 --> Security Class Initialized
DEBUG - 2023-07-21 16:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:36:51 --> Input Class Initialized
INFO - 2023-07-21 16:36:51 --> Language Class Initialized
INFO - 2023-07-21 16:36:51 --> Loader Class Initialized
INFO - 2023-07-21 16:36:51 --> Helper loaded: url_helper
INFO - 2023-07-21 16:36:51 --> Helper loaded: file_helper
INFO - 2023-07-21 16:36:51 --> Helper loaded: html_helper
INFO - 2023-07-21 16:36:51 --> Helper loaded: text_helper
INFO - 2023-07-21 16:36:51 --> Helper loaded: form_helper
INFO - 2023-07-21 16:36:51 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:36:51 --> Helper loaded: security_helper
INFO - 2023-07-21 16:36:51 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:36:51 --> Database Driver Class Initialized
INFO - 2023-07-21 16:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:36:51 --> Parser Class Initialized
INFO - 2023-07-21 16:36:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:36:51 --> Pagination Class Initialized
INFO - 2023-07-21 16:36:51 --> Form Validation Class Initialized
INFO - 2023-07-21 16:36:51 --> Controller Class Initialized
DEBUG - 2023-07-21 16:36:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:36:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:36:51 --> Model Class Initialized
DEBUG - 2023-07-21 16:36:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:36:51 --> Model Class Initialized
INFO - 2023-07-21 16:36:51 --> Final output sent to browser
DEBUG - 2023-07-21 16:36:51 --> Total execution time: 0.0191
ERROR - 2023-07-21 16:36:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:36:51 --> Config Class Initialized
INFO - 2023-07-21 16:36:51 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:36:51 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:36:51 --> Utf8 Class Initialized
INFO - 2023-07-21 16:36:51 --> URI Class Initialized
INFO - 2023-07-21 16:36:51 --> Router Class Initialized
INFO - 2023-07-21 16:36:51 --> Output Class Initialized
INFO - 2023-07-21 16:36:51 --> Security Class Initialized
DEBUG - 2023-07-21 16:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:36:51 --> Input Class Initialized
INFO - 2023-07-21 16:36:51 --> Language Class Initialized
INFO - 2023-07-21 16:36:51 --> Loader Class Initialized
INFO - 2023-07-21 16:36:51 --> Helper loaded: url_helper
INFO - 2023-07-21 16:36:51 --> Helper loaded: file_helper
INFO - 2023-07-21 16:36:51 --> Helper loaded: html_helper
INFO - 2023-07-21 16:36:51 --> Helper loaded: text_helper
INFO - 2023-07-21 16:36:51 --> Helper loaded: form_helper
INFO - 2023-07-21 16:36:51 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:36:51 --> Helper loaded: security_helper
INFO - 2023-07-21 16:36:51 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:36:51 --> Database Driver Class Initialized
INFO - 2023-07-21 16:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:36:51 --> Parser Class Initialized
INFO - 2023-07-21 16:36:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:36:51 --> Pagination Class Initialized
INFO - 2023-07-21 16:36:51 --> Form Validation Class Initialized
INFO - 2023-07-21 16:36:51 --> Controller Class Initialized
DEBUG - 2023-07-21 16:36:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:36:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:36:51 --> Model Class Initialized
DEBUG - 2023-07-21 16:36:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:36:51 --> Model Class Initialized
INFO - 2023-07-21 16:36:51 --> Final output sent to browser
DEBUG - 2023-07-21 16:36:51 --> Total execution time: 0.0191
ERROR - 2023-07-21 16:37:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:37:11 --> Config Class Initialized
INFO - 2023-07-21 16:37:11 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:37:11 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:37:11 --> Utf8 Class Initialized
INFO - 2023-07-21 16:37:11 --> URI Class Initialized
INFO - 2023-07-21 16:37:11 --> Router Class Initialized
INFO - 2023-07-21 16:37:11 --> Output Class Initialized
INFO - 2023-07-21 16:37:11 --> Security Class Initialized
DEBUG - 2023-07-21 16:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:37:11 --> Input Class Initialized
INFO - 2023-07-21 16:37:11 --> Language Class Initialized
INFO - 2023-07-21 16:37:11 --> Loader Class Initialized
INFO - 2023-07-21 16:37:11 --> Helper loaded: url_helper
INFO - 2023-07-21 16:37:11 --> Helper loaded: file_helper
INFO - 2023-07-21 16:37:11 --> Helper loaded: html_helper
INFO - 2023-07-21 16:37:11 --> Helper loaded: text_helper
INFO - 2023-07-21 16:37:11 --> Helper loaded: form_helper
INFO - 2023-07-21 16:37:11 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:37:11 --> Helper loaded: security_helper
INFO - 2023-07-21 16:37:11 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:37:11 --> Database Driver Class Initialized
INFO - 2023-07-21 16:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:37:11 --> Parser Class Initialized
INFO - 2023-07-21 16:37:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:37:11 --> Pagination Class Initialized
INFO - 2023-07-21 16:37:11 --> Form Validation Class Initialized
INFO - 2023-07-21 16:37:11 --> Controller Class Initialized
INFO - 2023-07-21 16:37:11 --> Model Class Initialized
DEBUG - 2023-07-21 16:37:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:37:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:37:11 --> Model Class Initialized
DEBUG - 2023-07-21 16:37:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:37:11 --> Model Class Initialized
INFO - 2023-07-21 16:37:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-21 16:37:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:37:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:37:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:37:11 --> Model Class Initialized
INFO - 2023-07-21 16:37:11 --> Model Class Initialized
INFO - 2023-07-21 16:37:11 --> Model Class Initialized
INFO - 2023-07-21 16:37:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 16:37:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 16:37:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:37:11 --> Final output sent to browser
DEBUG - 2023-07-21 16:37:11 --> Total execution time: 0.1490
ERROR - 2023-07-21 16:37:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:37:12 --> Config Class Initialized
INFO - 2023-07-21 16:37:12 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:37:12 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:37:12 --> Utf8 Class Initialized
INFO - 2023-07-21 16:37:12 --> URI Class Initialized
INFO - 2023-07-21 16:37:12 --> Router Class Initialized
INFO - 2023-07-21 16:37:12 --> Output Class Initialized
INFO - 2023-07-21 16:37:12 --> Security Class Initialized
DEBUG - 2023-07-21 16:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:37:12 --> Input Class Initialized
INFO - 2023-07-21 16:37:12 --> Language Class Initialized
INFO - 2023-07-21 16:37:12 --> Loader Class Initialized
INFO - 2023-07-21 16:37:12 --> Helper loaded: url_helper
INFO - 2023-07-21 16:37:12 --> Helper loaded: file_helper
INFO - 2023-07-21 16:37:12 --> Helper loaded: html_helper
INFO - 2023-07-21 16:37:12 --> Helper loaded: text_helper
INFO - 2023-07-21 16:37:12 --> Helper loaded: form_helper
INFO - 2023-07-21 16:37:12 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:37:12 --> Helper loaded: security_helper
INFO - 2023-07-21 16:37:12 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:37:12 --> Database Driver Class Initialized
INFO - 2023-07-21 16:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:37:12 --> Parser Class Initialized
INFO - 2023-07-21 16:37:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:37:12 --> Pagination Class Initialized
INFO - 2023-07-21 16:37:12 --> Form Validation Class Initialized
INFO - 2023-07-21 16:37:12 --> Controller Class Initialized
INFO - 2023-07-21 16:37:12 --> Model Class Initialized
DEBUG - 2023-07-21 16:37:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:37:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:37:12 --> Model Class Initialized
DEBUG - 2023-07-21 16:37:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:37:12 --> Model Class Initialized
INFO - 2023-07-21 16:37:12 --> Final output sent to browser
DEBUG - 2023-07-21 16:37:12 --> Total execution time: 0.0618
ERROR - 2023-07-21 16:39:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:39:04 --> Config Class Initialized
INFO - 2023-07-21 16:39:04 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:39:04 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:39:04 --> Utf8 Class Initialized
INFO - 2023-07-21 16:39:04 --> URI Class Initialized
INFO - 2023-07-21 16:39:04 --> Router Class Initialized
INFO - 2023-07-21 16:39:04 --> Output Class Initialized
INFO - 2023-07-21 16:39:04 --> Security Class Initialized
DEBUG - 2023-07-21 16:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:39:04 --> Input Class Initialized
INFO - 2023-07-21 16:39:04 --> Language Class Initialized
INFO - 2023-07-21 16:39:04 --> Loader Class Initialized
INFO - 2023-07-21 16:39:04 --> Helper loaded: url_helper
INFO - 2023-07-21 16:39:04 --> Helper loaded: file_helper
INFO - 2023-07-21 16:39:04 --> Helper loaded: html_helper
INFO - 2023-07-21 16:39:04 --> Helper loaded: text_helper
INFO - 2023-07-21 16:39:04 --> Helper loaded: form_helper
INFO - 2023-07-21 16:39:04 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:39:04 --> Helper loaded: security_helper
INFO - 2023-07-21 16:39:04 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:39:04 --> Database Driver Class Initialized
INFO - 2023-07-21 16:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:39:04 --> Parser Class Initialized
INFO - 2023-07-21 16:39:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:39:04 --> Pagination Class Initialized
INFO - 2023-07-21 16:39:04 --> Form Validation Class Initialized
INFO - 2023-07-21 16:39:04 --> Controller Class Initialized
ERROR - 2023-07-21 16:39:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:39:05 --> Config Class Initialized
INFO - 2023-07-21 16:39:05 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:39:05 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:39:05 --> Utf8 Class Initialized
INFO - 2023-07-21 16:39:05 --> URI Class Initialized
INFO - 2023-07-21 16:39:05 --> Router Class Initialized
INFO - 2023-07-21 16:39:05 --> Output Class Initialized
INFO - 2023-07-21 16:39:05 --> Security Class Initialized
DEBUG - 2023-07-21 16:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:39:05 --> Input Class Initialized
INFO - 2023-07-21 16:39:05 --> Language Class Initialized
INFO - 2023-07-21 16:39:05 --> Loader Class Initialized
INFO - 2023-07-21 16:39:05 --> Helper loaded: url_helper
INFO - 2023-07-21 16:39:05 --> Helper loaded: file_helper
INFO - 2023-07-21 16:39:05 --> Helper loaded: html_helper
INFO - 2023-07-21 16:39:05 --> Helper loaded: text_helper
INFO - 2023-07-21 16:39:05 --> Helper loaded: form_helper
INFO - 2023-07-21 16:39:05 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:39:05 --> Helper loaded: security_helper
INFO - 2023-07-21 16:39:05 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:39:05 --> Database Driver Class Initialized
INFO - 2023-07-21 16:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:39:05 --> Parser Class Initialized
INFO - 2023-07-21 16:39:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:39:05 --> Pagination Class Initialized
INFO - 2023-07-21 16:39:05 --> Form Validation Class Initialized
INFO - 2023-07-21 16:39:05 --> Controller Class Initialized
INFO - 2023-07-21 16:39:05 --> Model Class Initialized
DEBUG - 2023-07-21 16:39:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:39:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-21 16:39:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:39:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:39:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:39:05 --> Model Class Initialized
INFO - 2023-07-21 16:39:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:39:05 --> Final output sent to browser
DEBUG - 2023-07-21 16:39:05 --> Total execution time: 0.0359
ERROR - 2023-07-21 16:39:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:39:05 --> Config Class Initialized
INFO - 2023-07-21 16:39:05 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:39:05 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:39:05 --> Utf8 Class Initialized
INFO - 2023-07-21 16:39:05 --> URI Class Initialized
INFO - 2023-07-21 16:39:05 --> Router Class Initialized
INFO - 2023-07-21 16:39:05 --> Output Class Initialized
INFO - 2023-07-21 16:39:05 --> Security Class Initialized
DEBUG - 2023-07-21 16:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:39:05 --> Input Class Initialized
INFO - 2023-07-21 16:39:05 --> Language Class Initialized
ERROR - 2023-07-21 16:39:05 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2023-07-21 16:39:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:39:05 --> Config Class Initialized
INFO - 2023-07-21 16:39:05 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:39:05 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:39:05 --> Utf8 Class Initialized
INFO - 2023-07-21 16:39:05 --> URI Class Initialized
INFO - 2023-07-21 16:39:05 --> Router Class Initialized
INFO - 2023-07-21 16:39:05 --> Output Class Initialized
INFO - 2023-07-21 16:39:05 --> Security Class Initialized
DEBUG - 2023-07-21 16:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:39:05 --> Input Class Initialized
INFO - 2023-07-21 16:39:05 --> Language Class Initialized
ERROR - 2023-07-21 16:39:05 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2023-07-21 16:39:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:39:16 --> Config Class Initialized
INFO - 2023-07-21 16:39:16 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:39:16 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:39:16 --> Utf8 Class Initialized
INFO - 2023-07-21 16:39:16 --> URI Class Initialized
INFO - 2023-07-21 16:39:16 --> Router Class Initialized
INFO - 2023-07-21 16:39:16 --> Output Class Initialized
INFO - 2023-07-21 16:39:16 --> Security Class Initialized
DEBUG - 2023-07-21 16:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:39:16 --> Input Class Initialized
INFO - 2023-07-21 16:39:16 --> Language Class Initialized
INFO - 2023-07-21 16:39:16 --> Loader Class Initialized
INFO - 2023-07-21 16:39:16 --> Helper loaded: url_helper
INFO - 2023-07-21 16:39:16 --> Helper loaded: file_helper
INFO - 2023-07-21 16:39:16 --> Helper loaded: html_helper
INFO - 2023-07-21 16:39:16 --> Helper loaded: text_helper
INFO - 2023-07-21 16:39:16 --> Helper loaded: form_helper
INFO - 2023-07-21 16:39:16 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:39:16 --> Helper loaded: security_helper
INFO - 2023-07-21 16:39:16 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:39:16 --> Database Driver Class Initialized
INFO - 2023-07-21 16:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:39:16 --> Parser Class Initialized
INFO - 2023-07-21 16:39:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:39:16 --> Pagination Class Initialized
INFO - 2023-07-21 16:39:16 --> Form Validation Class Initialized
INFO - 2023-07-21 16:39:16 --> Controller Class Initialized
INFO - 2023-07-21 16:39:16 --> Model Class Initialized
DEBUG - 2023-07-21 16:39:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:39:16 --> Model Class Initialized
INFO - 2023-07-21 16:39:16 --> Final output sent to browser
DEBUG - 2023-07-21 16:39:16 --> Total execution time: 0.0173
ERROR - 2023-07-21 16:39:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:39:16 --> Config Class Initialized
INFO - 2023-07-21 16:39:16 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:39:16 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:39:16 --> Utf8 Class Initialized
INFO - 2023-07-21 16:39:16 --> URI Class Initialized
DEBUG - 2023-07-21 16:39:16 --> No URI present. Default controller set.
INFO - 2023-07-21 16:39:16 --> Router Class Initialized
INFO - 2023-07-21 16:39:16 --> Output Class Initialized
INFO - 2023-07-21 16:39:16 --> Security Class Initialized
DEBUG - 2023-07-21 16:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:39:16 --> Input Class Initialized
INFO - 2023-07-21 16:39:16 --> Language Class Initialized
INFO - 2023-07-21 16:39:16 --> Loader Class Initialized
INFO - 2023-07-21 16:39:16 --> Helper loaded: url_helper
INFO - 2023-07-21 16:39:16 --> Helper loaded: file_helper
INFO - 2023-07-21 16:39:16 --> Helper loaded: html_helper
INFO - 2023-07-21 16:39:16 --> Helper loaded: text_helper
INFO - 2023-07-21 16:39:16 --> Helper loaded: form_helper
INFO - 2023-07-21 16:39:16 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:39:16 --> Helper loaded: security_helper
INFO - 2023-07-21 16:39:16 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:39:16 --> Database Driver Class Initialized
INFO - 2023-07-21 16:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:39:16 --> Parser Class Initialized
INFO - 2023-07-21 16:39:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:39:16 --> Pagination Class Initialized
INFO - 2023-07-21 16:39:16 --> Form Validation Class Initialized
INFO - 2023-07-21 16:39:16 --> Controller Class Initialized
INFO - 2023-07-21 16:39:16 --> Model Class Initialized
DEBUG - 2023-07-21 16:39:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:39:16 --> Model Class Initialized
DEBUG - 2023-07-21 16:39:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:39:16 --> Model Class Initialized
INFO - 2023-07-21 16:39:16 --> Model Class Initialized
INFO - 2023-07-21 16:39:16 --> Model Class Initialized
INFO - 2023-07-21 16:39:16 --> Model Class Initialized
DEBUG - 2023-07-21 16:39:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:39:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:39:16 --> Model Class Initialized
INFO - 2023-07-21 16:39:16 --> Model Class Initialized
INFO - 2023-07-21 16:39:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-21 16:39:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:39:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:39:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:39:16 --> Model Class Initialized
INFO - 2023-07-21 16:39:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 16:39:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 16:39:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:39:17 --> Final output sent to browser
DEBUG - 2023-07-21 16:39:17 --> Total execution time: 0.0777
ERROR - 2023-07-21 16:39:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:39:23 --> Config Class Initialized
INFO - 2023-07-21 16:39:23 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:39:23 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:39:23 --> Utf8 Class Initialized
INFO - 2023-07-21 16:39:23 --> URI Class Initialized
INFO - 2023-07-21 16:39:23 --> Router Class Initialized
INFO - 2023-07-21 16:39:23 --> Output Class Initialized
INFO - 2023-07-21 16:39:23 --> Security Class Initialized
DEBUG - 2023-07-21 16:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:39:23 --> Input Class Initialized
INFO - 2023-07-21 16:39:23 --> Language Class Initialized
INFO - 2023-07-21 16:39:23 --> Loader Class Initialized
INFO - 2023-07-21 16:39:23 --> Helper loaded: url_helper
INFO - 2023-07-21 16:39:23 --> Helper loaded: file_helper
INFO - 2023-07-21 16:39:23 --> Helper loaded: html_helper
INFO - 2023-07-21 16:39:23 --> Helper loaded: text_helper
INFO - 2023-07-21 16:39:23 --> Helper loaded: form_helper
INFO - 2023-07-21 16:39:23 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:39:23 --> Helper loaded: security_helper
INFO - 2023-07-21 16:39:23 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:39:23 --> Database Driver Class Initialized
INFO - 2023-07-21 16:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:39:23 --> Parser Class Initialized
INFO - 2023-07-21 16:39:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:39:23 --> Pagination Class Initialized
INFO - 2023-07-21 16:39:23 --> Form Validation Class Initialized
INFO - 2023-07-21 16:39:23 --> Controller Class Initialized
INFO - 2023-07-21 16:39:23 --> Model Class Initialized
DEBUG - 2023-07-21 16:39:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:39:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:39:23 --> Model Class Initialized
DEBUG - 2023-07-21 16:39:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:39:23 --> Model Class Initialized
INFO - 2023-07-21 16:39:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-21 16:39:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:39:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:39:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:39:23 --> Model Class Initialized
INFO - 2023-07-21 16:39:23 --> Model Class Initialized
INFO - 2023-07-21 16:39:23 --> Model Class Initialized
INFO - 2023-07-21 16:39:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 16:39:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 16:39:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:39:23 --> Final output sent to browser
DEBUG - 2023-07-21 16:39:23 --> Total execution time: 0.0734
ERROR - 2023-07-21 16:39:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:39:24 --> Config Class Initialized
INFO - 2023-07-21 16:39:24 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:39:24 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:39:24 --> Utf8 Class Initialized
INFO - 2023-07-21 16:39:24 --> URI Class Initialized
INFO - 2023-07-21 16:39:24 --> Router Class Initialized
INFO - 2023-07-21 16:39:24 --> Output Class Initialized
INFO - 2023-07-21 16:39:24 --> Security Class Initialized
DEBUG - 2023-07-21 16:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:39:24 --> Input Class Initialized
INFO - 2023-07-21 16:39:24 --> Language Class Initialized
INFO - 2023-07-21 16:39:24 --> Loader Class Initialized
INFO - 2023-07-21 16:39:24 --> Helper loaded: url_helper
INFO - 2023-07-21 16:39:24 --> Helper loaded: file_helper
INFO - 2023-07-21 16:39:24 --> Helper loaded: html_helper
INFO - 2023-07-21 16:39:24 --> Helper loaded: text_helper
INFO - 2023-07-21 16:39:24 --> Helper loaded: form_helper
INFO - 2023-07-21 16:39:24 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:39:24 --> Helper loaded: security_helper
INFO - 2023-07-21 16:39:24 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:39:24 --> Database Driver Class Initialized
INFO - 2023-07-21 16:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:39:24 --> Parser Class Initialized
INFO - 2023-07-21 16:39:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:39:24 --> Pagination Class Initialized
INFO - 2023-07-21 16:39:24 --> Form Validation Class Initialized
INFO - 2023-07-21 16:39:24 --> Controller Class Initialized
INFO - 2023-07-21 16:39:24 --> Model Class Initialized
DEBUG - 2023-07-21 16:39:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:39:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:39:24 --> Model Class Initialized
DEBUG - 2023-07-21 16:39:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:39:24 --> Model Class Initialized
INFO - 2023-07-21 16:39:24 --> Final output sent to browser
DEBUG - 2023-07-21 16:39:24 --> Total execution time: 0.0417
ERROR - 2023-07-21 16:43:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:43:17 --> Config Class Initialized
INFO - 2023-07-21 16:43:17 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:43:17 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:43:17 --> Utf8 Class Initialized
INFO - 2023-07-21 16:43:17 --> URI Class Initialized
INFO - 2023-07-21 16:43:17 --> Router Class Initialized
INFO - 2023-07-21 16:43:17 --> Output Class Initialized
INFO - 2023-07-21 16:43:17 --> Security Class Initialized
DEBUG - 2023-07-21 16:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:43:17 --> Input Class Initialized
INFO - 2023-07-21 16:43:17 --> Language Class Initialized
INFO - 2023-07-21 16:43:17 --> Loader Class Initialized
INFO - 2023-07-21 16:43:17 --> Helper loaded: url_helper
INFO - 2023-07-21 16:43:17 --> Helper loaded: file_helper
INFO - 2023-07-21 16:43:17 --> Helper loaded: html_helper
INFO - 2023-07-21 16:43:17 --> Helper loaded: text_helper
INFO - 2023-07-21 16:43:17 --> Helper loaded: form_helper
INFO - 2023-07-21 16:43:17 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:43:17 --> Helper loaded: security_helper
INFO - 2023-07-21 16:43:17 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:43:17 --> Database Driver Class Initialized
INFO - 2023-07-21 16:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:43:17 --> Parser Class Initialized
INFO - 2023-07-21 16:43:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:43:17 --> Pagination Class Initialized
INFO - 2023-07-21 16:43:17 --> Form Validation Class Initialized
INFO - 2023-07-21 16:43:17 --> Controller Class Initialized
INFO - 2023-07-21 16:43:17 --> Model Class Initialized
DEBUG - 2023-07-21 16:43:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:43:17 --> Model Class Initialized
DEBUG - 2023-07-21 16:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:43:17 --> Model Class Initialized
INFO - 2023-07-21 16:43:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-07-21 16:43:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:43:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:43:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:43:17 --> Model Class Initialized
INFO - 2023-07-21 16:43:17 --> Model Class Initialized
INFO - 2023-07-21 16:43:17 --> Model Class Initialized
INFO - 2023-07-21 16:43:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 16:43:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 16:43:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:43:17 --> Final output sent to browser
DEBUG - 2023-07-21 16:43:17 --> Total execution time: 0.1511
ERROR - 2023-07-21 16:43:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:43:48 --> Config Class Initialized
INFO - 2023-07-21 16:43:48 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:43:48 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:43:48 --> Utf8 Class Initialized
INFO - 2023-07-21 16:43:48 --> URI Class Initialized
INFO - 2023-07-21 16:43:48 --> Router Class Initialized
INFO - 2023-07-21 16:43:48 --> Output Class Initialized
INFO - 2023-07-21 16:43:48 --> Security Class Initialized
DEBUG - 2023-07-21 16:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:43:48 --> Input Class Initialized
INFO - 2023-07-21 16:43:48 --> Language Class Initialized
INFO - 2023-07-21 16:43:48 --> Loader Class Initialized
INFO - 2023-07-21 16:43:48 --> Helper loaded: url_helper
INFO - 2023-07-21 16:43:48 --> Helper loaded: file_helper
INFO - 2023-07-21 16:43:48 --> Helper loaded: html_helper
INFO - 2023-07-21 16:43:48 --> Helper loaded: text_helper
INFO - 2023-07-21 16:43:48 --> Helper loaded: form_helper
INFO - 2023-07-21 16:43:48 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:43:48 --> Helper loaded: security_helper
INFO - 2023-07-21 16:43:48 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:43:48 --> Database Driver Class Initialized
INFO - 2023-07-21 16:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:43:48 --> Parser Class Initialized
INFO - 2023-07-21 16:43:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:43:48 --> Pagination Class Initialized
INFO - 2023-07-21 16:43:48 --> Form Validation Class Initialized
INFO - 2023-07-21 16:43:48 --> Controller Class Initialized
INFO - 2023-07-21 16:43:48 --> Model Class Initialized
DEBUG - 2023-07-21 16:43:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:43:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:43:48 --> Model Class Initialized
DEBUG - 2023-07-21 16:43:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:43:48 --> Model Class Initialized
INFO - 2023-07-21 16:43:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-07-21 16:43:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:43:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:43:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:43:48 --> Model Class Initialized
INFO - 2023-07-21 16:43:48 --> Model Class Initialized
INFO - 2023-07-21 16:43:48 --> Model Class Initialized
INFO - 2023-07-21 16:43:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 16:43:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 16:43:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:43:49 --> Final output sent to browser
DEBUG - 2023-07-21 16:43:49 --> Total execution time: 0.1634
ERROR - 2023-07-21 16:45:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:45:43 --> Config Class Initialized
INFO - 2023-07-21 16:45:43 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:45:43 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:45:43 --> Utf8 Class Initialized
INFO - 2023-07-21 16:45:43 --> URI Class Initialized
INFO - 2023-07-21 16:45:43 --> Router Class Initialized
INFO - 2023-07-21 16:45:43 --> Output Class Initialized
INFO - 2023-07-21 16:45:43 --> Security Class Initialized
DEBUG - 2023-07-21 16:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:45:43 --> Input Class Initialized
INFO - 2023-07-21 16:45:43 --> Language Class Initialized
INFO - 2023-07-21 16:45:43 --> Loader Class Initialized
INFO - 2023-07-21 16:45:43 --> Helper loaded: url_helper
INFO - 2023-07-21 16:45:43 --> Helper loaded: file_helper
INFO - 2023-07-21 16:45:43 --> Helper loaded: html_helper
INFO - 2023-07-21 16:45:43 --> Helper loaded: text_helper
INFO - 2023-07-21 16:45:43 --> Helper loaded: form_helper
INFO - 2023-07-21 16:45:43 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:45:43 --> Helper loaded: security_helper
INFO - 2023-07-21 16:45:43 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:45:43 --> Database Driver Class Initialized
INFO - 2023-07-21 16:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:45:43 --> Parser Class Initialized
INFO - 2023-07-21 16:45:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:45:43 --> Pagination Class Initialized
INFO - 2023-07-21 16:45:43 --> Form Validation Class Initialized
INFO - 2023-07-21 16:45:43 --> Controller Class Initialized
INFO - 2023-07-21 16:45:43 --> Model Class Initialized
DEBUG - 2023-07-21 16:45:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:45:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:45:43 --> Model Class Initialized
DEBUG - 2023-07-21 16:45:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:45:43 --> Model Class Initialized
INFO - 2023-07-21 16:45:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-21 16:45:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:45:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:45:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:45:44 --> Model Class Initialized
INFO - 2023-07-21 16:45:44 --> Model Class Initialized
INFO - 2023-07-21 16:45:44 --> Model Class Initialized
INFO - 2023-07-21 16:45:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 16:45:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 16:45:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:45:44 --> Final output sent to browser
DEBUG - 2023-07-21 16:45:44 --> Total execution time: 0.1575
ERROR - 2023-07-21 16:45:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:45:44 --> Config Class Initialized
INFO - 2023-07-21 16:45:44 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:45:44 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:45:44 --> Utf8 Class Initialized
INFO - 2023-07-21 16:45:44 --> URI Class Initialized
INFO - 2023-07-21 16:45:44 --> Router Class Initialized
INFO - 2023-07-21 16:45:44 --> Output Class Initialized
INFO - 2023-07-21 16:45:44 --> Security Class Initialized
DEBUG - 2023-07-21 16:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:45:44 --> Input Class Initialized
INFO - 2023-07-21 16:45:44 --> Language Class Initialized
INFO - 2023-07-21 16:45:44 --> Loader Class Initialized
INFO - 2023-07-21 16:45:44 --> Helper loaded: url_helper
INFO - 2023-07-21 16:45:44 --> Helper loaded: file_helper
INFO - 2023-07-21 16:45:44 --> Helper loaded: html_helper
INFO - 2023-07-21 16:45:44 --> Helper loaded: text_helper
INFO - 2023-07-21 16:45:44 --> Helper loaded: form_helper
INFO - 2023-07-21 16:45:44 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:45:44 --> Helper loaded: security_helper
INFO - 2023-07-21 16:45:44 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:45:44 --> Database Driver Class Initialized
INFO - 2023-07-21 16:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:45:44 --> Parser Class Initialized
INFO - 2023-07-21 16:45:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:45:44 --> Pagination Class Initialized
INFO - 2023-07-21 16:45:44 --> Form Validation Class Initialized
INFO - 2023-07-21 16:45:44 --> Controller Class Initialized
INFO - 2023-07-21 16:45:44 --> Model Class Initialized
DEBUG - 2023-07-21 16:45:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:45:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:45:44 --> Model Class Initialized
DEBUG - 2023-07-21 16:45:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:45:44 --> Model Class Initialized
INFO - 2023-07-21 16:45:44 --> Final output sent to browser
DEBUG - 2023-07-21 16:45:44 --> Total execution time: 0.0604
ERROR - 2023-07-21 16:50:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:50:16 --> Config Class Initialized
INFO - 2023-07-21 16:50:16 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:50:16 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:50:16 --> Utf8 Class Initialized
INFO - 2023-07-21 16:50:16 --> URI Class Initialized
INFO - 2023-07-21 16:50:16 --> Router Class Initialized
INFO - 2023-07-21 16:50:16 --> Output Class Initialized
INFO - 2023-07-21 16:50:16 --> Security Class Initialized
DEBUG - 2023-07-21 16:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:50:16 --> Input Class Initialized
INFO - 2023-07-21 16:50:16 --> Language Class Initialized
INFO - 2023-07-21 16:50:16 --> Loader Class Initialized
INFO - 2023-07-21 16:50:16 --> Helper loaded: url_helper
INFO - 2023-07-21 16:50:16 --> Helper loaded: file_helper
INFO - 2023-07-21 16:50:16 --> Helper loaded: html_helper
INFO - 2023-07-21 16:50:16 --> Helper loaded: text_helper
INFO - 2023-07-21 16:50:16 --> Helper loaded: form_helper
INFO - 2023-07-21 16:50:16 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:50:16 --> Helper loaded: security_helper
INFO - 2023-07-21 16:50:16 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:50:16 --> Database Driver Class Initialized
INFO - 2023-07-21 16:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:50:16 --> Parser Class Initialized
INFO - 2023-07-21 16:50:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:50:16 --> Pagination Class Initialized
INFO - 2023-07-21 16:50:16 --> Form Validation Class Initialized
INFO - 2023-07-21 16:50:16 --> Controller Class Initialized
INFO - 2023-07-21 16:50:16 --> Model Class Initialized
DEBUG - 2023-07-21 16:50:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:50:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:50:16 --> Model Class Initialized
DEBUG - 2023-07-21 16:50:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:50:16 --> Model Class Initialized
INFO - 2023-07-21 16:50:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-21 16:50:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:50:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:50:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:50:16 --> Model Class Initialized
INFO - 2023-07-21 16:50:16 --> Model Class Initialized
INFO - 2023-07-21 16:50:16 --> Model Class Initialized
INFO - 2023-07-21 16:50:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 16:50:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 16:50:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:50:16 --> Final output sent to browser
DEBUG - 2023-07-21 16:50:16 --> Total execution time: 0.1458
ERROR - 2023-07-21 16:50:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:50:17 --> Config Class Initialized
INFO - 2023-07-21 16:50:17 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:50:17 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:50:17 --> Utf8 Class Initialized
INFO - 2023-07-21 16:50:17 --> URI Class Initialized
INFO - 2023-07-21 16:50:17 --> Router Class Initialized
INFO - 2023-07-21 16:50:17 --> Output Class Initialized
INFO - 2023-07-21 16:50:17 --> Security Class Initialized
DEBUG - 2023-07-21 16:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:50:17 --> Input Class Initialized
INFO - 2023-07-21 16:50:17 --> Language Class Initialized
INFO - 2023-07-21 16:50:17 --> Loader Class Initialized
INFO - 2023-07-21 16:50:17 --> Helper loaded: url_helper
INFO - 2023-07-21 16:50:17 --> Helper loaded: file_helper
INFO - 2023-07-21 16:50:17 --> Helper loaded: html_helper
INFO - 2023-07-21 16:50:17 --> Helper loaded: text_helper
INFO - 2023-07-21 16:50:17 --> Helper loaded: form_helper
INFO - 2023-07-21 16:50:17 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:50:17 --> Helper loaded: security_helper
INFO - 2023-07-21 16:50:17 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:50:17 --> Database Driver Class Initialized
INFO - 2023-07-21 16:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:50:17 --> Parser Class Initialized
INFO - 2023-07-21 16:50:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:50:17 --> Pagination Class Initialized
INFO - 2023-07-21 16:50:17 --> Form Validation Class Initialized
INFO - 2023-07-21 16:50:17 --> Controller Class Initialized
INFO - 2023-07-21 16:50:17 --> Model Class Initialized
DEBUG - 2023-07-21 16:50:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:50:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:50:17 --> Model Class Initialized
DEBUG - 2023-07-21 16:50:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:50:17 --> Model Class Initialized
INFO - 2023-07-21 16:50:17 --> Final output sent to browser
DEBUG - 2023-07-21 16:50:17 --> Total execution time: 0.0457
ERROR - 2023-07-21 16:50:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:50:20 --> Config Class Initialized
INFO - 2023-07-21 16:50:20 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:50:20 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:50:20 --> Utf8 Class Initialized
INFO - 2023-07-21 16:50:20 --> URI Class Initialized
INFO - 2023-07-21 16:50:20 --> Router Class Initialized
INFO - 2023-07-21 16:50:20 --> Output Class Initialized
INFO - 2023-07-21 16:50:20 --> Security Class Initialized
DEBUG - 2023-07-21 16:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:50:20 --> Input Class Initialized
INFO - 2023-07-21 16:50:20 --> Language Class Initialized
INFO - 2023-07-21 16:50:20 --> Loader Class Initialized
INFO - 2023-07-21 16:50:20 --> Helper loaded: url_helper
INFO - 2023-07-21 16:50:20 --> Helper loaded: file_helper
INFO - 2023-07-21 16:50:20 --> Helper loaded: html_helper
INFO - 2023-07-21 16:50:20 --> Helper loaded: text_helper
INFO - 2023-07-21 16:50:20 --> Helper loaded: form_helper
INFO - 2023-07-21 16:50:20 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:50:20 --> Helper loaded: security_helper
INFO - 2023-07-21 16:50:20 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:50:20 --> Database Driver Class Initialized
INFO - 2023-07-21 16:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:50:20 --> Parser Class Initialized
INFO - 2023-07-21 16:50:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:50:20 --> Pagination Class Initialized
INFO - 2023-07-21 16:50:20 --> Form Validation Class Initialized
INFO - 2023-07-21 16:50:20 --> Controller Class Initialized
INFO - 2023-07-21 16:50:20 --> Model Class Initialized
DEBUG - 2023-07-21 16:50:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:50:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:50:20 --> Model Class Initialized
DEBUG - 2023-07-21 16:50:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:50:20 --> Model Class Initialized
INFO - 2023-07-21 16:50:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html.php
DEBUG - 2023-07-21 16:50:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:50:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:50:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:50:20 --> Model Class Initialized
INFO - 2023-07-21 16:50:20 --> Model Class Initialized
INFO - 2023-07-21 16:50:20 --> Model Class Initialized
INFO - 2023-07-21 16:50:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 16:50:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 16:50:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:50:20 --> Final output sent to browser
DEBUG - 2023-07-21 16:50:20 --> Total execution time: 0.1520
ERROR - 2023-07-21 16:50:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:50:47 --> Config Class Initialized
INFO - 2023-07-21 16:50:47 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:50:47 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:50:47 --> Utf8 Class Initialized
INFO - 2023-07-21 16:50:47 --> URI Class Initialized
DEBUG - 2023-07-21 16:50:47 --> No URI present. Default controller set.
INFO - 2023-07-21 16:50:47 --> Router Class Initialized
INFO - 2023-07-21 16:50:47 --> Output Class Initialized
INFO - 2023-07-21 16:50:48 --> Security Class Initialized
DEBUG - 2023-07-21 16:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:50:48 --> Input Class Initialized
INFO - 2023-07-21 16:50:48 --> Language Class Initialized
INFO - 2023-07-21 16:50:48 --> Loader Class Initialized
INFO - 2023-07-21 16:50:48 --> Helper loaded: url_helper
INFO - 2023-07-21 16:50:48 --> Helper loaded: file_helper
INFO - 2023-07-21 16:50:48 --> Helper loaded: html_helper
INFO - 2023-07-21 16:50:48 --> Helper loaded: text_helper
INFO - 2023-07-21 16:50:48 --> Helper loaded: form_helper
INFO - 2023-07-21 16:50:48 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:50:48 --> Helper loaded: security_helper
INFO - 2023-07-21 16:50:48 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:50:48 --> Database Driver Class Initialized
INFO - 2023-07-21 16:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:50:48 --> Parser Class Initialized
INFO - 2023-07-21 16:50:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:50:48 --> Pagination Class Initialized
INFO - 2023-07-21 16:50:48 --> Form Validation Class Initialized
INFO - 2023-07-21 16:50:48 --> Controller Class Initialized
INFO - 2023-07-21 16:50:48 --> Model Class Initialized
DEBUG - 2023-07-21 16:50:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-21 16:50:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:50:48 --> Config Class Initialized
INFO - 2023-07-21 16:50:48 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:50:48 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:50:48 --> Utf8 Class Initialized
INFO - 2023-07-21 16:50:48 --> URI Class Initialized
INFO - 2023-07-21 16:50:48 --> Router Class Initialized
INFO - 2023-07-21 16:50:48 --> Output Class Initialized
INFO - 2023-07-21 16:50:48 --> Security Class Initialized
DEBUG - 2023-07-21 16:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:50:48 --> Input Class Initialized
INFO - 2023-07-21 16:50:48 --> Language Class Initialized
INFO - 2023-07-21 16:50:48 --> Loader Class Initialized
INFO - 2023-07-21 16:50:48 --> Helper loaded: url_helper
INFO - 2023-07-21 16:50:48 --> Helper loaded: file_helper
INFO - 2023-07-21 16:50:48 --> Helper loaded: html_helper
INFO - 2023-07-21 16:50:48 --> Helper loaded: text_helper
INFO - 2023-07-21 16:50:48 --> Helper loaded: form_helper
INFO - 2023-07-21 16:50:48 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:50:48 --> Helper loaded: security_helper
INFO - 2023-07-21 16:50:48 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:50:48 --> Database Driver Class Initialized
INFO - 2023-07-21 16:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:50:48 --> Parser Class Initialized
INFO - 2023-07-21 16:50:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:50:48 --> Pagination Class Initialized
INFO - 2023-07-21 16:50:48 --> Form Validation Class Initialized
INFO - 2023-07-21 16:50:48 --> Controller Class Initialized
INFO - 2023-07-21 16:50:48 --> Model Class Initialized
DEBUG - 2023-07-21 16:50:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:50:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-21 16:50:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:50:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:50:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:50:48 --> Model Class Initialized
INFO - 2023-07-21 16:50:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:50:48 --> Final output sent to browser
DEBUG - 2023-07-21 16:50:48 --> Total execution time: 0.0301
ERROR - 2023-07-21 16:51:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:51:08 --> Config Class Initialized
INFO - 2023-07-21 16:51:08 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:51:08 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:51:08 --> Utf8 Class Initialized
INFO - 2023-07-21 16:51:08 --> URI Class Initialized
INFO - 2023-07-21 16:51:08 --> Router Class Initialized
INFO - 2023-07-21 16:51:08 --> Output Class Initialized
INFO - 2023-07-21 16:51:08 --> Security Class Initialized
DEBUG - 2023-07-21 16:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:51:08 --> Input Class Initialized
INFO - 2023-07-21 16:51:08 --> Language Class Initialized
INFO - 2023-07-21 16:51:08 --> Loader Class Initialized
INFO - 2023-07-21 16:51:08 --> Helper loaded: url_helper
INFO - 2023-07-21 16:51:08 --> Helper loaded: file_helper
INFO - 2023-07-21 16:51:08 --> Helper loaded: html_helper
INFO - 2023-07-21 16:51:08 --> Helper loaded: text_helper
INFO - 2023-07-21 16:51:08 --> Helper loaded: form_helper
INFO - 2023-07-21 16:51:08 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:51:08 --> Helper loaded: security_helper
INFO - 2023-07-21 16:51:08 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:51:08 --> Database Driver Class Initialized
INFO - 2023-07-21 16:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:51:08 --> Parser Class Initialized
INFO - 2023-07-21 16:51:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:51:08 --> Pagination Class Initialized
INFO - 2023-07-21 16:51:08 --> Form Validation Class Initialized
INFO - 2023-07-21 16:51:08 --> Controller Class Initialized
INFO - 2023-07-21 16:51:08 --> Model Class Initialized
DEBUG - 2023-07-21 16:51:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:51:08 --> Model Class Initialized
INFO - 2023-07-21 16:51:08 --> Final output sent to browser
DEBUG - 2023-07-21 16:51:08 --> Total execution time: 0.0214
ERROR - 2023-07-21 16:51:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:51:08 --> Config Class Initialized
INFO - 2023-07-21 16:51:08 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:51:08 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:51:08 --> Utf8 Class Initialized
INFO - 2023-07-21 16:51:08 --> URI Class Initialized
INFO - 2023-07-21 16:51:08 --> Router Class Initialized
INFO - 2023-07-21 16:51:08 --> Output Class Initialized
INFO - 2023-07-21 16:51:08 --> Security Class Initialized
DEBUG - 2023-07-21 16:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:51:08 --> Input Class Initialized
INFO - 2023-07-21 16:51:08 --> Language Class Initialized
INFO - 2023-07-21 16:51:08 --> Loader Class Initialized
INFO - 2023-07-21 16:51:08 --> Helper loaded: url_helper
INFO - 2023-07-21 16:51:08 --> Helper loaded: file_helper
INFO - 2023-07-21 16:51:08 --> Helper loaded: html_helper
INFO - 2023-07-21 16:51:08 --> Helper loaded: text_helper
INFO - 2023-07-21 16:51:08 --> Helper loaded: form_helper
INFO - 2023-07-21 16:51:08 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:51:08 --> Helper loaded: security_helper
INFO - 2023-07-21 16:51:08 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:51:08 --> Database Driver Class Initialized
INFO - 2023-07-21 16:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:51:08 --> Parser Class Initialized
INFO - 2023-07-21 16:51:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:51:08 --> Pagination Class Initialized
INFO - 2023-07-21 16:51:08 --> Form Validation Class Initialized
INFO - 2023-07-21 16:51:08 --> Controller Class Initialized
INFO - 2023-07-21 16:51:08 --> Model Class Initialized
DEBUG - 2023-07-21 16:51:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:51:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-21 16:51:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:51:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:51:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:51:08 --> Model Class Initialized
INFO - 2023-07-21 16:51:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:51:08 --> Final output sent to browser
DEBUG - 2023-07-21 16:51:08 --> Total execution time: 0.0356
ERROR - 2023-07-21 16:51:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:51:17 --> Config Class Initialized
INFO - 2023-07-21 16:51:17 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:51:17 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:51:17 --> Utf8 Class Initialized
INFO - 2023-07-21 16:51:17 --> URI Class Initialized
INFO - 2023-07-21 16:51:17 --> Router Class Initialized
INFO - 2023-07-21 16:51:17 --> Output Class Initialized
INFO - 2023-07-21 16:51:17 --> Security Class Initialized
DEBUG - 2023-07-21 16:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:51:17 --> Input Class Initialized
INFO - 2023-07-21 16:51:17 --> Language Class Initialized
INFO - 2023-07-21 16:51:17 --> Loader Class Initialized
INFO - 2023-07-21 16:51:17 --> Helper loaded: url_helper
INFO - 2023-07-21 16:51:17 --> Helper loaded: file_helper
INFO - 2023-07-21 16:51:17 --> Helper loaded: html_helper
INFO - 2023-07-21 16:51:17 --> Helper loaded: text_helper
INFO - 2023-07-21 16:51:17 --> Helper loaded: form_helper
INFO - 2023-07-21 16:51:17 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:51:17 --> Helper loaded: security_helper
INFO - 2023-07-21 16:51:17 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:51:17 --> Database Driver Class Initialized
INFO - 2023-07-21 16:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:51:17 --> Parser Class Initialized
INFO - 2023-07-21 16:51:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:51:17 --> Pagination Class Initialized
INFO - 2023-07-21 16:51:17 --> Form Validation Class Initialized
INFO - 2023-07-21 16:51:17 --> Controller Class Initialized
DEBUG - 2023-07-21 16:51:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:51:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:51:17 --> Model Class Initialized
DEBUG - 2023-07-21 16:51:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:51:17 --> Model Class Initialized
DEBUG - 2023-07-21 16:51:17 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:51:17 --> Model Class Initialized
INFO - 2023-07-21 16:51:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-07-21 16:51:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:51:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:51:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:51:17 --> Model Class Initialized
INFO - 2023-07-21 16:51:17 --> Model Class Initialized
INFO - 2023-07-21 16:51:17 --> Model Class Initialized
INFO - 2023-07-21 16:51:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 16:51:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 16:51:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:51:17 --> Final output sent to browser
DEBUG - 2023-07-21 16:51:17 --> Total execution time: 0.1435
ERROR - 2023-07-21 16:51:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:51:17 --> Config Class Initialized
INFO - 2023-07-21 16:51:17 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:51:17 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:51:17 --> Utf8 Class Initialized
INFO - 2023-07-21 16:51:17 --> URI Class Initialized
INFO - 2023-07-21 16:51:17 --> Router Class Initialized
INFO - 2023-07-21 16:51:17 --> Output Class Initialized
INFO - 2023-07-21 16:51:17 --> Security Class Initialized
DEBUG - 2023-07-21 16:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:51:17 --> Input Class Initialized
INFO - 2023-07-21 16:51:17 --> Language Class Initialized
INFO - 2023-07-21 16:51:17 --> Loader Class Initialized
INFO - 2023-07-21 16:51:17 --> Helper loaded: url_helper
INFO - 2023-07-21 16:51:17 --> Helper loaded: file_helper
INFO - 2023-07-21 16:51:17 --> Helper loaded: html_helper
INFO - 2023-07-21 16:51:17 --> Helper loaded: text_helper
INFO - 2023-07-21 16:51:17 --> Helper loaded: form_helper
INFO - 2023-07-21 16:51:17 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:51:17 --> Helper loaded: security_helper
INFO - 2023-07-21 16:51:17 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:51:17 --> Database Driver Class Initialized
INFO - 2023-07-21 16:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:51:17 --> Parser Class Initialized
INFO - 2023-07-21 16:51:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:51:17 --> Pagination Class Initialized
INFO - 2023-07-21 16:51:17 --> Form Validation Class Initialized
INFO - 2023-07-21 16:51:17 --> Controller Class Initialized
DEBUG - 2023-07-21 16:51:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:51:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:51:17 --> Model Class Initialized
DEBUG - 2023-07-21 16:51:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:51:17 --> Model Class Initialized
INFO - 2023-07-21 16:51:18 --> Final output sent to browser
DEBUG - 2023-07-21 16:51:18 --> Total execution time: 0.0345
ERROR - 2023-07-21 16:51:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:51:26 --> Config Class Initialized
INFO - 2023-07-21 16:51:26 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:51:26 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:51:26 --> Utf8 Class Initialized
INFO - 2023-07-21 16:51:26 --> URI Class Initialized
INFO - 2023-07-21 16:51:26 --> Router Class Initialized
INFO - 2023-07-21 16:51:26 --> Output Class Initialized
INFO - 2023-07-21 16:51:26 --> Security Class Initialized
DEBUG - 2023-07-21 16:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:51:26 --> Input Class Initialized
INFO - 2023-07-21 16:51:26 --> Language Class Initialized
INFO - 2023-07-21 16:51:26 --> Loader Class Initialized
INFO - 2023-07-21 16:51:26 --> Helper loaded: url_helper
INFO - 2023-07-21 16:51:26 --> Helper loaded: file_helper
INFO - 2023-07-21 16:51:26 --> Helper loaded: html_helper
INFO - 2023-07-21 16:51:26 --> Helper loaded: text_helper
INFO - 2023-07-21 16:51:26 --> Helper loaded: form_helper
INFO - 2023-07-21 16:51:26 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:51:26 --> Helper loaded: security_helper
INFO - 2023-07-21 16:51:26 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:51:26 --> Database Driver Class Initialized
INFO - 2023-07-21 16:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:51:26 --> Parser Class Initialized
INFO - 2023-07-21 16:51:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:51:26 --> Pagination Class Initialized
INFO - 2023-07-21 16:51:26 --> Form Validation Class Initialized
INFO - 2023-07-21 16:51:26 --> Controller Class Initialized
DEBUG - 2023-07-21 16:51:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:51:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:51:26 --> Model Class Initialized
DEBUG - 2023-07-21 16:51:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:51:26 --> Model Class Initialized
INFO - 2023-07-21 16:51:26 --> Final output sent to browser
DEBUG - 2023-07-21 16:51:26 --> Total execution time: 0.0367
ERROR - 2023-07-21 16:51:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:51:26 --> Config Class Initialized
INFO - 2023-07-21 16:51:26 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:51:26 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:51:26 --> Utf8 Class Initialized
INFO - 2023-07-21 16:51:26 --> URI Class Initialized
INFO - 2023-07-21 16:51:26 --> Router Class Initialized
INFO - 2023-07-21 16:51:26 --> Output Class Initialized
INFO - 2023-07-21 16:51:26 --> Security Class Initialized
DEBUG - 2023-07-21 16:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:51:26 --> Input Class Initialized
INFO - 2023-07-21 16:51:26 --> Language Class Initialized
INFO - 2023-07-21 16:51:26 --> Loader Class Initialized
INFO - 2023-07-21 16:51:26 --> Helper loaded: url_helper
INFO - 2023-07-21 16:51:26 --> Helper loaded: file_helper
INFO - 2023-07-21 16:51:26 --> Helper loaded: html_helper
INFO - 2023-07-21 16:51:26 --> Helper loaded: text_helper
INFO - 2023-07-21 16:51:26 --> Helper loaded: form_helper
INFO - 2023-07-21 16:51:26 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:51:26 --> Helper loaded: security_helper
INFO - 2023-07-21 16:51:26 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:51:26 --> Database Driver Class Initialized
INFO - 2023-07-21 16:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:51:26 --> Parser Class Initialized
INFO - 2023-07-21 16:51:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:51:26 --> Pagination Class Initialized
INFO - 2023-07-21 16:51:26 --> Form Validation Class Initialized
INFO - 2023-07-21 16:51:26 --> Controller Class Initialized
DEBUG - 2023-07-21 16:51:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:51:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:51:26 --> Model Class Initialized
DEBUG - 2023-07-21 16:51:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:51:26 --> Model Class Initialized
INFO - 2023-07-21 16:51:26 --> Final output sent to browser
DEBUG - 2023-07-21 16:51:26 --> Total execution time: 0.0308
ERROR - 2023-07-21 16:51:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:51:27 --> Config Class Initialized
INFO - 2023-07-21 16:51:27 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:51:27 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:51:27 --> Utf8 Class Initialized
INFO - 2023-07-21 16:51:27 --> URI Class Initialized
INFO - 2023-07-21 16:51:27 --> Router Class Initialized
INFO - 2023-07-21 16:51:27 --> Output Class Initialized
INFO - 2023-07-21 16:51:27 --> Security Class Initialized
DEBUG - 2023-07-21 16:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:51:27 --> Input Class Initialized
INFO - 2023-07-21 16:51:27 --> Language Class Initialized
INFO - 2023-07-21 16:51:27 --> Loader Class Initialized
INFO - 2023-07-21 16:51:27 --> Helper loaded: url_helper
INFO - 2023-07-21 16:51:27 --> Helper loaded: file_helper
INFO - 2023-07-21 16:51:27 --> Helper loaded: html_helper
INFO - 2023-07-21 16:51:27 --> Helper loaded: text_helper
INFO - 2023-07-21 16:51:27 --> Helper loaded: form_helper
INFO - 2023-07-21 16:51:27 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:51:27 --> Helper loaded: security_helper
INFO - 2023-07-21 16:51:27 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:51:27 --> Database Driver Class Initialized
INFO - 2023-07-21 16:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:51:27 --> Parser Class Initialized
INFO - 2023-07-21 16:51:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:51:27 --> Pagination Class Initialized
INFO - 2023-07-21 16:51:27 --> Form Validation Class Initialized
INFO - 2023-07-21 16:51:27 --> Controller Class Initialized
DEBUG - 2023-07-21 16:51:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:51:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:51:27 --> Model Class Initialized
DEBUG - 2023-07-21 16:51:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:51:27 --> Model Class Initialized
INFO - 2023-07-21 16:51:27 --> Final output sent to browser
DEBUG - 2023-07-21 16:51:27 --> Total execution time: 0.0309
ERROR - 2023-07-21 16:51:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:51:28 --> Config Class Initialized
INFO - 2023-07-21 16:51:28 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:51:28 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:51:28 --> Utf8 Class Initialized
INFO - 2023-07-21 16:51:28 --> URI Class Initialized
INFO - 2023-07-21 16:51:28 --> Router Class Initialized
INFO - 2023-07-21 16:51:28 --> Output Class Initialized
INFO - 2023-07-21 16:51:28 --> Security Class Initialized
DEBUG - 2023-07-21 16:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:51:28 --> Input Class Initialized
INFO - 2023-07-21 16:51:28 --> Language Class Initialized
INFO - 2023-07-21 16:51:28 --> Loader Class Initialized
INFO - 2023-07-21 16:51:28 --> Helper loaded: url_helper
INFO - 2023-07-21 16:51:28 --> Helper loaded: file_helper
INFO - 2023-07-21 16:51:28 --> Helper loaded: html_helper
INFO - 2023-07-21 16:51:28 --> Helper loaded: text_helper
INFO - 2023-07-21 16:51:28 --> Helper loaded: form_helper
INFO - 2023-07-21 16:51:28 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:51:28 --> Helper loaded: security_helper
INFO - 2023-07-21 16:51:28 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:51:28 --> Database Driver Class Initialized
INFO - 2023-07-21 16:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:51:28 --> Parser Class Initialized
INFO - 2023-07-21 16:51:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:51:28 --> Pagination Class Initialized
INFO - 2023-07-21 16:51:28 --> Form Validation Class Initialized
INFO - 2023-07-21 16:51:28 --> Controller Class Initialized
DEBUG - 2023-07-21 16:51:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:51:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:51:28 --> Model Class Initialized
DEBUG - 2023-07-21 16:51:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:51:28 --> Model Class Initialized
INFO - 2023-07-21 16:51:28 --> Final output sent to browser
DEBUG - 2023-07-21 16:51:28 --> Total execution time: 0.0242
ERROR - 2023-07-21 16:51:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:51:29 --> Config Class Initialized
INFO - 2023-07-21 16:51:29 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:51:29 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:51:29 --> Utf8 Class Initialized
INFO - 2023-07-21 16:51:29 --> URI Class Initialized
INFO - 2023-07-21 16:51:29 --> Router Class Initialized
INFO - 2023-07-21 16:51:29 --> Output Class Initialized
INFO - 2023-07-21 16:51:29 --> Security Class Initialized
DEBUG - 2023-07-21 16:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:51:29 --> Input Class Initialized
INFO - 2023-07-21 16:51:29 --> Language Class Initialized
INFO - 2023-07-21 16:51:29 --> Loader Class Initialized
INFO - 2023-07-21 16:51:29 --> Helper loaded: url_helper
INFO - 2023-07-21 16:51:29 --> Helper loaded: file_helper
INFO - 2023-07-21 16:51:29 --> Helper loaded: html_helper
INFO - 2023-07-21 16:51:29 --> Helper loaded: text_helper
INFO - 2023-07-21 16:51:29 --> Helper loaded: form_helper
INFO - 2023-07-21 16:51:29 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:51:29 --> Helper loaded: security_helper
INFO - 2023-07-21 16:51:29 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:51:29 --> Database Driver Class Initialized
INFO - 2023-07-21 16:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:51:29 --> Parser Class Initialized
INFO - 2023-07-21 16:51:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:51:29 --> Pagination Class Initialized
INFO - 2023-07-21 16:51:29 --> Form Validation Class Initialized
INFO - 2023-07-21 16:51:29 --> Controller Class Initialized
DEBUG - 2023-07-21 16:51:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:51:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:51:29 --> Model Class Initialized
DEBUG - 2023-07-21 16:51:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:51:29 --> Model Class Initialized
INFO - 2023-07-21 16:51:29 --> Final output sent to browser
DEBUG - 2023-07-21 16:51:29 --> Total execution time: 0.0222
ERROR - 2023-07-21 16:51:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:51:33 --> Config Class Initialized
INFO - 2023-07-21 16:51:33 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:51:33 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:51:33 --> Utf8 Class Initialized
INFO - 2023-07-21 16:51:33 --> URI Class Initialized
INFO - 2023-07-21 16:51:33 --> Router Class Initialized
INFO - 2023-07-21 16:51:33 --> Output Class Initialized
INFO - 2023-07-21 16:51:33 --> Security Class Initialized
DEBUG - 2023-07-21 16:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:51:33 --> Input Class Initialized
INFO - 2023-07-21 16:51:33 --> Language Class Initialized
INFO - 2023-07-21 16:51:33 --> Loader Class Initialized
INFO - 2023-07-21 16:51:33 --> Helper loaded: url_helper
INFO - 2023-07-21 16:51:33 --> Helper loaded: file_helper
INFO - 2023-07-21 16:51:33 --> Helper loaded: html_helper
INFO - 2023-07-21 16:51:33 --> Helper loaded: text_helper
INFO - 2023-07-21 16:51:33 --> Helper loaded: form_helper
INFO - 2023-07-21 16:51:33 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:51:33 --> Helper loaded: security_helper
INFO - 2023-07-21 16:51:33 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:51:33 --> Database Driver Class Initialized
INFO - 2023-07-21 16:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:51:33 --> Parser Class Initialized
INFO - 2023-07-21 16:51:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:51:33 --> Pagination Class Initialized
INFO - 2023-07-21 16:51:33 --> Form Validation Class Initialized
INFO - 2023-07-21 16:51:33 --> Controller Class Initialized
DEBUG - 2023-07-21 16:51:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:51:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:51:33 --> Model Class Initialized
DEBUG - 2023-07-21 16:51:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:51:33 --> Model Class Initialized
INFO - 2023-07-21 16:51:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/view_customer.php
DEBUG - 2023-07-21 16:51:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:51:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:51:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:51:33 --> Model Class Initialized
INFO - 2023-07-21 16:51:33 --> Model Class Initialized
INFO - 2023-07-21 16:51:33 --> Model Class Initialized
INFO - 2023-07-21 16:51:33 --> Model Class Initialized
INFO - 2023-07-21 16:51:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 16:51:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 16:51:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:51:33 --> Final output sent to browser
DEBUG - 2023-07-21 16:51:33 --> Total execution time: 0.1428
ERROR - 2023-07-21 16:51:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:51:53 --> Config Class Initialized
INFO - 2023-07-21 16:51:53 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:51:53 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:51:53 --> Utf8 Class Initialized
INFO - 2023-07-21 16:51:53 --> URI Class Initialized
INFO - 2023-07-21 16:51:53 --> Router Class Initialized
INFO - 2023-07-21 16:51:53 --> Output Class Initialized
INFO - 2023-07-21 16:51:53 --> Security Class Initialized
DEBUG - 2023-07-21 16:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:51:53 --> Input Class Initialized
INFO - 2023-07-21 16:51:53 --> Language Class Initialized
INFO - 2023-07-21 16:51:53 --> Loader Class Initialized
INFO - 2023-07-21 16:51:53 --> Helper loaded: url_helper
INFO - 2023-07-21 16:51:53 --> Helper loaded: file_helper
INFO - 2023-07-21 16:51:53 --> Helper loaded: html_helper
INFO - 2023-07-21 16:51:53 --> Helper loaded: text_helper
INFO - 2023-07-21 16:51:53 --> Helper loaded: form_helper
INFO - 2023-07-21 16:51:53 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:51:53 --> Helper loaded: security_helper
INFO - 2023-07-21 16:51:53 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:51:53 --> Database Driver Class Initialized
INFO - 2023-07-21 16:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:51:53 --> Parser Class Initialized
INFO - 2023-07-21 16:51:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:51:53 --> Pagination Class Initialized
INFO - 2023-07-21 16:51:53 --> Form Validation Class Initialized
INFO - 2023-07-21 16:51:53 --> Controller Class Initialized
INFO - 2023-07-21 16:51:53 --> Model Class Initialized
DEBUG - 2023-07-21 16:51:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:51:53 --> Model Class Initialized
INFO - 2023-07-21 16:51:53 --> Final output sent to browser
DEBUG - 2023-07-21 16:51:53 --> Total execution time: 0.0187
ERROR - 2023-07-21 16:51:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:51:53 --> Config Class Initialized
INFO - 2023-07-21 16:51:53 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:51:53 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:51:53 --> Utf8 Class Initialized
INFO - 2023-07-21 16:51:53 --> URI Class Initialized
DEBUG - 2023-07-21 16:51:53 --> No URI present. Default controller set.
INFO - 2023-07-21 16:51:53 --> Router Class Initialized
INFO - 2023-07-21 16:51:53 --> Output Class Initialized
INFO - 2023-07-21 16:51:53 --> Security Class Initialized
DEBUG - 2023-07-21 16:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:51:53 --> Input Class Initialized
INFO - 2023-07-21 16:51:53 --> Language Class Initialized
INFO - 2023-07-21 16:51:53 --> Loader Class Initialized
INFO - 2023-07-21 16:51:53 --> Helper loaded: url_helper
INFO - 2023-07-21 16:51:53 --> Helper loaded: file_helper
INFO - 2023-07-21 16:51:53 --> Helper loaded: html_helper
INFO - 2023-07-21 16:51:53 --> Helper loaded: text_helper
INFO - 2023-07-21 16:51:53 --> Helper loaded: form_helper
INFO - 2023-07-21 16:51:53 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:51:53 --> Helper loaded: security_helper
INFO - 2023-07-21 16:51:53 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:51:53 --> Database Driver Class Initialized
INFO - 2023-07-21 16:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:51:53 --> Parser Class Initialized
INFO - 2023-07-21 16:51:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:51:53 --> Pagination Class Initialized
INFO - 2023-07-21 16:51:53 --> Form Validation Class Initialized
INFO - 2023-07-21 16:51:53 --> Controller Class Initialized
INFO - 2023-07-21 16:51:53 --> Model Class Initialized
DEBUG - 2023-07-21 16:51:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:51:53 --> Model Class Initialized
DEBUG - 2023-07-21 16:51:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:51:53 --> Model Class Initialized
INFO - 2023-07-21 16:51:53 --> Model Class Initialized
INFO - 2023-07-21 16:51:53 --> Model Class Initialized
INFO - 2023-07-21 16:51:53 --> Model Class Initialized
DEBUG - 2023-07-21 16:51:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:51:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:51:53 --> Model Class Initialized
INFO - 2023-07-21 16:51:53 --> Model Class Initialized
INFO - 2023-07-21 16:51:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-21 16:51:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:51:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:51:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:51:53 --> Model Class Initialized
INFO - 2023-07-21 16:51:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 16:51:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 16:51:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:51:53 --> Final output sent to browser
DEBUG - 2023-07-21 16:51:53 --> Total execution time: 0.0689
ERROR - 2023-07-21 16:52:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:52:05 --> Config Class Initialized
INFO - 2023-07-21 16:52:05 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:52:05 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:52:05 --> Utf8 Class Initialized
INFO - 2023-07-21 16:52:05 --> URI Class Initialized
INFO - 2023-07-21 16:52:05 --> Router Class Initialized
INFO - 2023-07-21 16:52:05 --> Output Class Initialized
INFO - 2023-07-21 16:52:05 --> Security Class Initialized
DEBUG - 2023-07-21 16:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:52:05 --> Input Class Initialized
INFO - 2023-07-21 16:52:05 --> Language Class Initialized
INFO - 2023-07-21 16:52:05 --> Loader Class Initialized
INFO - 2023-07-21 16:52:05 --> Helper loaded: url_helper
INFO - 2023-07-21 16:52:05 --> Helper loaded: file_helper
INFO - 2023-07-21 16:52:05 --> Helper loaded: html_helper
INFO - 2023-07-21 16:52:05 --> Helper loaded: text_helper
INFO - 2023-07-21 16:52:05 --> Helper loaded: form_helper
INFO - 2023-07-21 16:52:05 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:52:05 --> Helper loaded: security_helper
INFO - 2023-07-21 16:52:05 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:52:05 --> Database Driver Class Initialized
INFO - 2023-07-21 16:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:52:05 --> Parser Class Initialized
INFO - 2023-07-21 16:52:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:52:05 --> Pagination Class Initialized
INFO - 2023-07-21 16:52:05 --> Form Validation Class Initialized
INFO - 2023-07-21 16:52:05 --> Controller Class Initialized
INFO - 2023-07-21 16:52:05 --> Model Class Initialized
DEBUG - 2023-07-21 16:52:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:52:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:52:05 --> Model Class Initialized
DEBUG - 2023-07-21 16:52:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:52:05 --> Model Class Initialized
INFO - 2023-07-21 16:52:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-21 16:52:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:52:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:52:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:52:05 --> Model Class Initialized
INFO - 2023-07-21 16:52:05 --> Model Class Initialized
INFO - 2023-07-21 16:52:05 --> Model Class Initialized
INFO - 2023-07-21 16:52:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 16:52:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 16:52:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:52:05 --> Final output sent to browser
DEBUG - 2023-07-21 16:52:05 --> Total execution time: 0.0685
ERROR - 2023-07-21 16:52:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:52:06 --> Config Class Initialized
INFO - 2023-07-21 16:52:06 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:52:06 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:52:06 --> Utf8 Class Initialized
INFO - 2023-07-21 16:52:06 --> URI Class Initialized
INFO - 2023-07-21 16:52:06 --> Router Class Initialized
INFO - 2023-07-21 16:52:06 --> Output Class Initialized
INFO - 2023-07-21 16:52:06 --> Security Class Initialized
DEBUG - 2023-07-21 16:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:52:06 --> Input Class Initialized
INFO - 2023-07-21 16:52:06 --> Language Class Initialized
INFO - 2023-07-21 16:52:06 --> Loader Class Initialized
INFO - 2023-07-21 16:52:06 --> Helper loaded: url_helper
INFO - 2023-07-21 16:52:06 --> Helper loaded: file_helper
INFO - 2023-07-21 16:52:06 --> Helper loaded: html_helper
INFO - 2023-07-21 16:52:06 --> Helper loaded: text_helper
INFO - 2023-07-21 16:52:06 --> Helper loaded: form_helper
INFO - 2023-07-21 16:52:06 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:52:06 --> Helper loaded: security_helper
INFO - 2023-07-21 16:52:06 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:52:06 --> Database Driver Class Initialized
INFO - 2023-07-21 16:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:52:06 --> Parser Class Initialized
INFO - 2023-07-21 16:52:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:52:06 --> Pagination Class Initialized
INFO - 2023-07-21 16:52:06 --> Form Validation Class Initialized
INFO - 2023-07-21 16:52:06 --> Controller Class Initialized
INFO - 2023-07-21 16:52:06 --> Model Class Initialized
DEBUG - 2023-07-21 16:52:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:52:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:52:06 --> Model Class Initialized
DEBUG - 2023-07-21 16:52:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:52:06 --> Model Class Initialized
INFO - 2023-07-21 16:52:06 --> Final output sent to browser
DEBUG - 2023-07-21 16:52:06 --> Total execution time: 0.0217
ERROR - 2023-07-21 16:52:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:52:09 --> Config Class Initialized
INFO - 2023-07-21 16:52:09 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:52:09 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:52:09 --> Utf8 Class Initialized
INFO - 2023-07-21 16:52:09 --> URI Class Initialized
INFO - 2023-07-21 16:52:09 --> Router Class Initialized
INFO - 2023-07-21 16:52:09 --> Output Class Initialized
INFO - 2023-07-21 16:52:09 --> Security Class Initialized
DEBUG - 2023-07-21 16:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:52:09 --> Input Class Initialized
INFO - 2023-07-21 16:52:09 --> Language Class Initialized
INFO - 2023-07-21 16:52:09 --> Loader Class Initialized
INFO - 2023-07-21 16:52:09 --> Helper loaded: url_helper
INFO - 2023-07-21 16:52:09 --> Helper loaded: file_helper
INFO - 2023-07-21 16:52:09 --> Helper loaded: html_helper
INFO - 2023-07-21 16:52:09 --> Helper loaded: text_helper
INFO - 2023-07-21 16:52:09 --> Helper loaded: form_helper
INFO - 2023-07-21 16:52:09 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:52:09 --> Helper loaded: security_helper
INFO - 2023-07-21 16:52:09 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:52:09 --> Database Driver Class Initialized
INFO - 2023-07-21 16:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:52:09 --> Parser Class Initialized
INFO - 2023-07-21 16:52:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:52:09 --> Pagination Class Initialized
INFO - 2023-07-21 16:52:09 --> Form Validation Class Initialized
INFO - 2023-07-21 16:52:09 --> Controller Class Initialized
INFO - 2023-07-21 16:52:09 --> Model Class Initialized
DEBUG - 2023-07-21 16:52:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:52:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:52:09 --> Model Class Initialized
DEBUG - 2023-07-21 16:52:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:52:09 --> Model Class Initialized
INFO - 2023-07-21 16:52:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html.php
DEBUG - 2023-07-21 16:52:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:52:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:52:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:52:09 --> Model Class Initialized
INFO - 2023-07-21 16:52:09 --> Model Class Initialized
INFO - 2023-07-21 16:52:09 --> Model Class Initialized
INFO - 2023-07-21 16:52:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 16:52:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 16:52:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:52:09 --> Final output sent to browser
DEBUG - 2023-07-21 16:52:09 --> Total execution time: 0.0702
ERROR - 2023-07-21 16:52:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:52:14 --> Config Class Initialized
INFO - 2023-07-21 16:52:14 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:52:14 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:52:14 --> Utf8 Class Initialized
INFO - 2023-07-21 16:52:14 --> URI Class Initialized
INFO - 2023-07-21 16:52:14 --> Router Class Initialized
INFO - 2023-07-21 16:52:14 --> Output Class Initialized
INFO - 2023-07-21 16:52:14 --> Security Class Initialized
DEBUG - 2023-07-21 16:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:52:14 --> Input Class Initialized
INFO - 2023-07-21 16:52:14 --> Language Class Initialized
INFO - 2023-07-21 16:52:14 --> Loader Class Initialized
INFO - 2023-07-21 16:52:14 --> Helper loaded: url_helper
INFO - 2023-07-21 16:52:14 --> Helper loaded: file_helper
INFO - 2023-07-21 16:52:14 --> Helper loaded: html_helper
INFO - 2023-07-21 16:52:14 --> Helper loaded: text_helper
INFO - 2023-07-21 16:52:14 --> Helper loaded: form_helper
INFO - 2023-07-21 16:52:14 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:52:14 --> Helper loaded: security_helper
INFO - 2023-07-21 16:52:14 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:52:14 --> Database Driver Class Initialized
INFO - 2023-07-21 16:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:52:14 --> Parser Class Initialized
INFO - 2023-07-21 16:52:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:52:14 --> Pagination Class Initialized
INFO - 2023-07-21 16:52:14 --> Form Validation Class Initialized
INFO - 2023-07-21 16:52:14 --> Controller Class Initialized
DEBUG - 2023-07-21 16:52:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:52:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:52:14 --> Model Class Initialized
DEBUG - 2023-07-21 16:52:14 --> Lgift class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:52:14 --> Model Class Initialized
DEBUG - 2023-07-21 16:52:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:52:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:52:14 --> Model Class Initialized
DEBUG - 2023-07-21 16:52:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:52:14 --> Model Class Initialized
INFO - 2023-07-21 16:52:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/gift.php
DEBUG - 2023-07-21 16:52:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:52:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:52:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:52:14 --> Model Class Initialized
INFO - 2023-07-21 16:52:14 --> Model Class Initialized
INFO - 2023-07-21 16:52:14 --> Model Class Initialized
INFO - 2023-07-21 16:52:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 16:52:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 16:52:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:52:14 --> Final output sent to browser
DEBUG - 2023-07-21 16:52:14 --> Total execution time: 0.0699
ERROR - 2023-07-21 16:52:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:52:16 --> Config Class Initialized
INFO - 2023-07-21 16:52:16 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:52:16 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:52:16 --> Utf8 Class Initialized
INFO - 2023-07-21 16:52:16 --> URI Class Initialized
INFO - 2023-07-21 16:52:16 --> Router Class Initialized
INFO - 2023-07-21 16:52:16 --> Output Class Initialized
INFO - 2023-07-21 16:52:16 --> Security Class Initialized
DEBUG - 2023-07-21 16:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:52:16 --> Input Class Initialized
INFO - 2023-07-21 16:52:16 --> Language Class Initialized
INFO - 2023-07-21 16:52:16 --> Loader Class Initialized
INFO - 2023-07-21 16:52:16 --> Helper loaded: url_helper
INFO - 2023-07-21 16:52:16 --> Helper loaded: file_helper
INFO - 2023-07-21 16:52:16 --> Helper loaded: html_helper
INFO - 2023-07-21 16:52:16 --> Helper loaded: text_helper
INFO - 2023-07-21 16:52:16 --> Helper loaded: form_helper
INFO - 2023-07-21 16:52:16 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:52:16 --> Helper loaded: security_helper
INFO - 2023-07-21 16:52:16 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:52:16 --> Database Driver Class Initialized
INFO - 2023-07-21 16:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:52:16 --> Parser Class Initialized
INFO - 2023-07-21 16:52:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:52:16 --> Pagination Class Initialized
INFO - 2023-07-21 16:52:16 --> Form Validation Class Initialized
INFO - 2023-07-21 16:52:16 --> Controller Class Initialized
DEBUG - 2023-07-21 16:52:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:52:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:52:16 --> Model Class Initialized
INFO - 2023-07-21 16:52:16 --> Final output sent to browser
DEBUG - 2023-07-21 16:52:16 --> Total execution time: 0.0175
ERROR - 2023-07-21 16:53:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:53:13 --> Config Class Initialized
INFO - 2023-07-21 16:53:13 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:53:13 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:53:13 --> Utf8 Class Initialized
INFO - 2023-07-21 16:53:13 --> URI Class Initialized
INFO - 2023-07-21 16:53:13 --> Router Class Initialized
INFO - 2023-07-21 16:53:13 --> Output Class Initialized
INFO - 2023-07-21 16:53:13 --> Security Class Initialized
DEBUG - 2023-07-21 16:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:53:13 --> Input Class Initialized
INFO - 2023-07-21 16:53:13 --> Language Class Initialized
INFO - 2023-07-21 16:53:13 --> Loader Class Initialized
INFO - 2023-07-21 16:53:13 --> Helper loaded: url_helper
INFO - 2023-07-21 16:53:13 --> Helper loaded: file_helper
INFO - 2023-07-21 16:53:13 --> Helper loaded: html_helper
INFO - 2023-07-21 16:53:13 --> Helper loaded: text_helper
INFO - 2023-07-21 16:53:13 --> Helper loaded: form_helper
INFO - 2023-07-21 16:53:13 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:53:13 --> Helper loaded: security_helper
INFO - 2023-07-21 16:53:13 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:53:13 --> Database Driver Class Initialized
INFO - 2023-07-21 16:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:53:13 --> Parser Class Initialized
INFO - 2023-07-21 16:53:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:53:13 --> Pagination Class Initialized
INFO - 2023-07-21 16:53:13 --> Form Validation Class Initialized
INFO - 2023-07-21 16:53:13 --> Controller Class Initialized
INFO - 2023-07-21 16:53:13 --> Model Class Initialized
DEBUG - 2023-07-21 16:53:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:53:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:53:13 --> Model Class Initialized
DEBUG - 2023-07-21 16:53:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:53:13 --> Model Class Initialized
INFO - 2023-07-21 16:53:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-21 16:53:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:53:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:53:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:53:13 --> Model Class Initialized
INFO - 2023-07-21 16:53:13 --> Model Class Initialized
INFO - 2023-07-21 16:53:13 --> Model Class Initialized
INFO - 2023-07-21 16:53:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 16:53:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 16:53:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:53:13 --> Final output sent to browser
DEBUG - 2023-07-21 16:53:13 --> Total execution time: 0.1323
ERROR - 2023-07-21 16:53:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:53:14 --> Config Class Initialized
INFO - 2023-07-21 16:53:14 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:53:14 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:53:14 --> Utf8 Class Initialized
INFO - 2023-07-21 16:53:14 --> URI Class Initialized
INFO - 2023-07-21 16:53:14 --> Router Class Initialized
INFO - 2023-07-21 16:53:14 --> Output Class Initialized
INFO - 2023-07-21 16:53:14 --> Security Class Initialized
DEBUG - 2023-07-21 16:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:53:14 --> Input Class Initialized
INFO - 2023-07-21 16:53:14 --> Language Class Initialized
INFO - 2023-07-21 16:53:14 --> Loader Class Initialized
INFO - 2023-07-21 16:53:14 --> Helper loaded: url_helper
INFO - 2023-07-21 16:53:14 --> Helper loaded: file_helper
INFO - 2023-07-21 16:53:14 --> Helper loaded: html_helper
INFO - 2023-07-21 16:53:14 --> Helper loaded: text_helper
INFO - 2023-07-21 16:53:14 --> Helper loaded: form_helper
INFO - 2023-07-21 16:53:14 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:53:14 --> Helper loaded: security_helper
INFO - 2023-07-21 16:53:14 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:53:14 --> Database Driver Class Initialized
INFO - 2023-07-21 16:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:53:14 --> Parser Class Initialized
INFO - 2023-07-21 16:53:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:53:14 --> Pagination Class Initialized
INFO - 2023-07-21 16:53:14 --> Form Validation Class Initialized
INFO - 2023-07-21 16:53:14 --> Controller Class Initialized
INFO - 2023-07-21 16:53:14 --> Model Class Initialized
DEBUG - 2023-07-21 16:53:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:53:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:53:14 --> Model Class Initialized
DEBUG - 2023-07-21 16:53:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:53:14 --> Model Class Initialized
INFO - 2023-07-21 16:53:14 --> Final output sent to browser
DEBUG - 2023-07-21 16:53:14 --> Total execution time: 0.0524
ERROR - 2023-07-21 16:59:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:59:26 --> Config Class Initialized
INFO - 2023-07-21 16:59:26 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:59:26 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:59:26 --> Utf8 Class Initialized
INFO - 2023-07-21 16:59:26 --> URI Class Initialized
INFO - 2023-07-21 16:59:26 --> Router Class Initialized
INFO - 2023-07-21 16:59:26 --> Output Class Initialized
INFO - 2023-07-21 16:59:26 --> Security Class Initialized
DEBUG - 2023-07-21 16:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:59:26 --> Input Class Initialized
INFO - 2023-07-21 16:59:26 --> Language Class Initialized
INFO - 2023-07-21 16:59:26 --> Loader Class Initialized
INFO - 2023-07-21 16:59:26 --> Helper loaded: url_helper
INFO - 2023-07-21 16:59:26 --> Helper loaded: file_helper
INFO - 2023-07-21 16:59:26 --> Helper loaded: html_helper
INFO - 2023-07-21 16:59:26 --> Helper loaded: text_helper
INFO - 2023-07-21 16:59:26 --> Helper loaded: form_helper
INFO - 2023-07-21 16:59:26 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:59:26 --> Helper loaded: security_helper
INFO - 2023-07-21 16:59:26 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:59:26 --> Database Driver Class Initialized
INFO - 2023-07-21 16:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:59:26 --> Parser Class Initialized
INFO - 2023-07-21 16:59:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:59:26 --> Pagination Class Initialized
INFO - 2023-07-21 16:59:26 --> Form Validation Class Initialized
INFO - 2023-07-21 16:59:26 --> Controller Class Initialized
INFO - 2023-07-21 16:59:26 --> Model Class Initialized
DEBUG - 2023-07-21 16:59:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:59:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:59:26 --> Model Class Initialized
DEBUG - 2023-07-21 16:59:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:59:26 --> Model Class Initialized
INFO - 2023-07-21 16:59:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-21 16:59:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:59:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:59:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:59:26 --> Model Class Initialized
INFO - 2023-07-21 16:59:26 --> Model Class Initialized
INFO - 2023-07-21 16:59:26 --> Model Class Initialized
INFO - 2023-07-21 16:59:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 16:59:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 16:59:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:59:26 --> Final output sent to browser
DEBUG - 2023-07-21 16:59:26 --> Total execution time: 0.1644
ERROR - 2023-07-21 16:59:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:59:27 --> Config Class Initialized
INFO - 2023-07-21 16:59:27 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:59:27 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:59:27 --> Utf8 Class Initialized
INFO - 2023-07-21 16:59:27 --> URI Class Initialized
INFO - 2023-07-21 16:59:27 --> Router Class Initialized
INFO - 2023-07-21 16:59:27 --> Output Class Initialized
INFO - 2023-07-21 16:59:27 --> Security Class Initialized
DEBUG - 2023-07-21 16:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:59:27 --> Input Class Initialized
INFO - 2023-07-21 16:59:27 --> Language Class Initialized
INFO - 2023-07-21 16:59:27 --> Loader Class Initialized
INFO - 2023-07-21 16:59:27 --> Helper loaded: url_helper
INFO - 2023-07-21 16:59:27 --> Helper loaded: file_helper
INFO - 2023-07-21 16:59:27 --> Helper loaded: html_helper
INFO - 2023-07-21 16:59:27 --> Helper loaded: text_helper
INFO - 2023-07-21 16:59:27 --> Helper loaded: form_helper
INFO - 2023-07-21 16:59:27 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:59:27 --> Helper loaded: security_helper
INFO - 2023-07-21 16:59:27 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:59:27 --> Database Driver Class Initialized
INFO - 2023-07-21 16:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:59:27 --> Parser Class Initialized
INFO - 2023-07-21 16:59:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:59:27 --> Pagination Class Initialized
INFO - 2023-07-21 16:59:27 --> Form Validation Class Initialized
INFO - 2023-07-21 16:59:27 --> Controller Class Initialized
INFO - 2023-07-21 16:59:27 --> Model Class Initialized
DEBUG - 2023-07-21 16:59:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:59:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:59:27 --> Model Class Initialized
DEBUG - 2023-07-21 16:59:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:59:27 --> Model Class Initialized
INFO - 2023-07-21 16:59:27 --> Final output sent to browser
DEBUG - 2023-07-21 16:59:27 --> Total execution time: 0.0633
ERROR - 2023-07-21 16:59:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:59:31 --> Config Class Initialized
INFO - 2023-07-21 16:59:31 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:59:31 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:59:31 --> Utf8 Class Initialized
INFO - 2023-07-21 16:59:31 --> URI Class Initialized
INFO - 2023-07-21 16:59:31 --> Router Class Initialized
INFO - 2023-07-21 16:59:31 --> Output Class Initialized
INFO - 2023-07-21 16:59:31 --> Security Class Initialized
DEBUG - 2023-07-21 16:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:59:31 --> Input Class Initialized
INFO - 2023-07-21 16:59:31 --> Language Class Initialized
INFO - 2023-07-21 16:59:31 --> Loader Class Initialized
INFO - 2023-07-21 16:59:31 --> Helper loaded: url_helper
INFO - 2023-07-21 16:59:31 --> Helper loaded: file_helper
INFO - 2023-07-21 16:59:31 --> Helper loaded: html_helper
INFO - 2023-07-21 16:59:31 --> Helper loaded: text_helper
INFO - 2023-07-21 16:59:31 --> Helper loaded: form_helper
INFO - 2023-07-21 16:59:31 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:59:31 --> Helper loaded: security_helper
INFO - 2023-07-21 16:59:31 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:59:31 --> Database Driver Class Initialized
INFO - 2023-07-21 16:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:59:31 --> Parser Class Initialized
INFO - 2023-07-21 16:59:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:59:31 --> Pagination Class Initialized
INFO - 2023-07-21 16:59:31 --> Form Validation Class Initialized
INFO - 2023-07-21 16:59:31 --> Controller Class Initialized
INFO - 2023-07-21 16:59:31 --> Model Class Initialized
DEBUG - 2023-07-21 16:59:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:59:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:59:31 --> Model Class Initialized
DEBUG - 2023-07-21 16:59:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:59:31 --> Model Class Initialized
INFO - 2023-07-21 16:59:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html.php
DEBUG - 2023-07-21 16:59:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:59:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:59:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:59:31 --> Model Class Initialized
INFO - 2023-07-21 16:59:32 --> Model Class Initialized
INFO - 2023-07-21 16:59:32 --> Model Class Initialized
INFO - 2023-07-21 16:59:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 16:59:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 16:59:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:59:32 --> Final output sent to browser
DEBUG - 2023-07-21 16:59:32 --> Total execution time: 0.1335
ERROR - 2023-07-21 16:59:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:59:48 --> Config Class Initialized
INFO - 2023-07-21 16:59:48 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:59:48 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:59:48 --> Utf8 Class Initialized
INFO - 2023-07-21 16:59:48 --> URI Class Initialized
INFO - 2023-07-21 16:59:48 --> Router Class Initialized
INFO - 2023-07-21 16:59:48 --> Output Class Initialized
INFO - 2023-07-21 16:59:48 --> Security Class Initialized
DEBUG - 2023-07-21 16:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:59:48 --> Input Class Initialized
INFO - 2023-07-21 16:59:48 --> Language Class Initialized
INFO - 2023-07-21 16:59:48 --> Loader Class Initialized
INFO - 2023-07-21 16:59:48 --> Helper loaded: url_helper
INFO - 2023-07-21 16:59:48 --> Helper loaded: file_helper
INFO - 2023-07-21 16:59:48 --> Helper loaded: html_helper
INFO - 2023-07-21 16:59:48 --> Helper loaded: text_helper
INFO - 2023-07-21 16:59:48 --> Helper loaded: form_helper
INFO - 2023-07-21 16:59:48 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:59:48 --> Helper loaded: security_helper
INFO - 2023-07-21 16:59:48 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:59:48 --> Database Driver Class Initialized
INFO - 2023-07-21 16:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:59:48 --> Parser Class Initialized
INFO - 2023-07-21 16:59:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:59:48 --> Pagination Class Initialized
INFO - 2023-07-21 16:59:48 --> Form Validation Class Initialized
INFO - 2023-07-21 16:59:48 --> Controller Class Initialized
INFO - 2023-07-21 16:59:48 --> Model Class Initialized
DEBUG - 2023-07-21 16:59:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:59:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:59:48 --> Model Class Initialized
DEBUG - 2023-07-21 16:59:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:59:48 --> Model Class Initialized
INFO - 2023-07-21 16:59:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-21 16:59:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:59:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:59:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:59:48 --> Model Class Initialized
INFO - 2023-07-21 16:59:48 --> Model Class Initialized
INFO - 2023-07-21 16:59:48 --> Model Class Initialized
INFO - 2023-07-21 16:59:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 16:59:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 16:59:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:59:48 --> Final output sent to browser
DEBUG - 2023-07-21 16:59:48 --> Total execution time: 0.1352
ERROR - 2023-07-21 16:59:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:59:48 --> Config Class Initialized
INFO - 2023-07-21 16:59:48 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:59:48 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:59:48 --> Utf8 Class Initialized
INFO - 2023-07-21 16:59:48 --> URI Class Initialized
INFO - 2023-07-21 16:59:48 --> Router Class Initialized
INFO - 2023-07-21 16:59:48 --> Output Class Initialized
INFO - 2023-07-21 16:59:48 --> Security Class Initialized
DEBUG - 2023-07-21 16:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:59:48 --> Input Class Initialized
INFO - 2023-07-21 16:59:48 --> Language Class Initialized
INFO - 2023-07-21 16:59:48 --> Loader Class Initialized
INFO - 2023-07-21 16:59:48 --> Helper loaded: url_helper
INFO - 2023-07-21 16:59:48 --> Helper loaded: file_helper
INFO - 2023-07-21 16:59:48 --> Helper loaded: html_helper
INFO - 2023-07-21 16:59:48 --> Helper loaded: text_helper
INFO - 2023-07-21 16:59:48 --> Helper loaded: form_helper
INFO - 2023-07-21 16:59:48 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:59:48 --> Helper loaded: security_helper
INFO - 2023-07-21 16:59:48 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:59:48 --> Database Driver Class Initialized
INFO - 2023-07-21 16:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:59:48 --> Parser Class Initialized
INFO - 2023-07-21 16:59:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:59:48 --> Pagination Class Initialized
INFO - 2023-07-21 16:59:48 --> Form Validation Class Initialized
INFO - 2023-07-21 16:59:48 --> Controller Class Initialized
INFO - 2023-07-21 16:59:48 --> Model Class Initialized
DEBUG - 2023-07-21 16:59:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:59:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:59:48 --> Model Class Initialized
DEBUG - 2023-07-21 16:59:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:59:48 --> Model Class Initialized
INFO - 2023-07-21 16:59:49 --> Final output sent to browser
DEBUG - 2023-07-21 16:59:49 --> Total execution time: 0.0512
ERROR - 2023-07-21 16:59:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 16:59:52 --> Config Class Initialized
INFO - 2023-07-21 16:59:52 --> Hooks Class Initialized
DEBUG - 2023-07-21 16:59:52 --> UTF-8 Support Enabled
INFO - 2023-07-21 16:59:52 --> Utf8 Class Initialized
INFO - 2023-07-21 16:59:52 --> URI Class Initialized
INFO - 2023-07-21 16:59:52 --> Router Class Initialized
INFO - 2023-07-21 16:59:52 --> Output Class Initialized
INFO - 2023-07-21 16:59:52 --> Security Class Initialized
DEBUG - 2023-07-21 16:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 16:59:52 --> Input Class Initialized
INFO - 2023-07-21 16:59:52 --> Language Class Initialized
INFO - 2023-07-21 16:59:52 --> Loader Class Initialized
INFO - 2023-07-21 16:59:52 --> Helper loaded: url_helper
INFO - 2023-07-21 16:59:52 --> Helper loaded: file_helper
INFO - 2023-07-21 16:59:52 --> Helper loaded: html_helper
INFO - 2023-07-21 16:59:52 --> Helper loaded: text_helper
INFO - 2023-07-21 16:59:52 --> Helper loaded: form_helper
INFO - 2023-07-21 16:59:52 --> Helper loaded: lang_helper
INFO - 2023-07-21 16:59:52 --> Helper loaded: security_helper
INFO - 2023-07-21 16:59:52 --> Helper loaded: cookie_helper
INFO - 2023-07-21 16:59:52 --> Database Driver Class Initialized
INFO - 2023-07-21 16:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 16:59:52 --> Parser Class Initialized
INFO - 2023-07-21 16:59:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 16:59:52 --> Pagination Class Initialized
INFO - 2023-07-21 16:59:52 --> Form Validation Class Initialized
INFO - 2023-07-21 16:59:52 --> Controller Class Initialized
INFO - 2023-07-21 16:59:52 --> Model Class Initialized
DEBUG - 2023-07-21 16:59:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 16:59:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:59:52 --> Model Class Initialized
DEBUG - 2023-07-21 16:59:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:59:52 --> Model Class Initialized
INFO - 2023-07-21 16:59:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html.php
DEBUG - 2023-07-21 16:59:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 16:59:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 16:59:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 16:59:52 --> Model Class Initialized
INFO - 2023-07-21 16:59:52 --> Model Class Initialized
INFO - 2023-07-21 16:59:52 --> Model Class Initialized
INFO - 2023-07-21 16:59:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 16:59:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 16:59:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 16:59:53 --> Final output sent to browser
DEBUG - 2023-07-21 16:59:53 --> Total execution time: 0.1494
ERROR - 2023-07-21 17:09:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 17:09:15 --> Config Class Initialized
INFO - 2023-07-21 17:09:15 --> Hooks Class Initialized
DEBUG - 2023-07-21 17:09:15 --> UTF-8 Support Enabled
INFO - 2023-07-21 17:09:15 --> Utf8 Class Initialized
INFO - 2023-07-21 17:09:15 --> URI Class Initialized
DEBUG - 2023-07-21 17:09:15 --> No URI present. Default controller set.
INFO - 2023-07-21 17:09:15 --> Router Class Initialized
INFO - 2023-07-21 17:09:15 --> Output Class Initialized
INFO - 2023-07-21 17:09:15 --> Security Class Initialized
DEBUG - 2023-07-21 17:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 17:09:15 --> Input Class Initialized
INFO - 2023-07-21 17:09:15 --> Language Class Initialized
INFO - 2023-07-21 17:09:15 --> Loader Class Initialized
INFO - 2023-07-21 17:09:15 --> Helper loaded: url_helper
INFO - 2023-07-21 17:09:15 --> Helper loaded: file_helper
INFO - 2023-07-21 17:09:15 --> Helper loaded: html_helper
INFO - 2023-07-21 17:09:15 --> Helper loaded: text_helper
INFO - 2023-07-21 17:09:15 --> Helper loaded: form_helper
INFO - 2023-07-21 17:09:15 --> Helper loaded: lang_helper
INFO - 2023-07-21 17:09:15 --> Helper loaded: security_helper
INFO - 2023-07-21 17:09:15 --> Helper loaded: cookie_helper
INFO - 2023-07-21 17:09:15 --> Database Driver Class Initialized
INFO - 2023-07-21 17:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 17:09:15 --> Parser Class Initialized
INFO - 2023-07-21 17:09:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 17:09:15 --> Pagination Class Initialized
INFO - 2023-07-21 17:09:15 --> Form Validation Class Initialized
INFO - 2023-07-21 17:09:15 --> Controller Class Initialized
INFO - 2023-07-21 17:09:15 --> Model Class Initialized
DEBUG - 2023-07-21 17:09:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 17:09:15 --> Model Class Initialized
DEBUG - 2023-07-21 17:09:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 17:09:15 --> Model Class Initialized
INFO - 2023-07-21 17:09:15 --> Model Class Initialized
INFO - 2023-07-21 17:09:15 --> Model Class Initialized
INFO - 2023-07-21 17:09:15 --> Model Class Initialized
DEBUG - 2023-07-21 17:09:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 17:09:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 17:09:15 --> Model Class Initialized
INFO - 2023-07-21 17:09:15 --> Model Class Initialized
INFO - 2023-07-21 17:09:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-21 17:09:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 17:09:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 17:09:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 17:09:15 --> Model Class Initialized
INFO - 2023-07-21 17:09:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 17:09:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 17:09:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 17:09:16 --> Final output sent to browser
DEBUG - 2023-07-21 17:09:16 --> Total execution time: 0.1748
ERROR - 2023-07-21 17:10:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 17:10:52 --> Config Class Initialized
INFO - 2023-07-21 17:10:52 --> Hooks Class Initialized
DEBUG - 2023-07-21 17:10:52 --> UTF-8 Support Enabled
INFO - 2023-07-21 17:10:52 --> Utf8 Class Initialized
INFO - 2023-07-21 17:10:52 --> URI Class Initialized
DEBUG - 2023-07-21 17:10:52 --> No URI present. Default controller set.
INFO - 2023-07-21 17:10:52 --> Router Class Initialized
INFO - 2023-07-21 17:10:52 --> Output Class Initialized
INFO - 2023-07-21 17:10:52 --> Security Class Initialized
DEBUG - 2023-07-21 17:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 17:10:52 --> Input Class Initialized
INFO - 2023-07-21 17:10:52 --> Language Class Initialized
INFO - 2023-07-21 17:10:52 --> Loader Class Initialized
INFO - 2023-07-21 17:10:52 --> Helper loaded: url_helper
INFO - 2023-07-21 17:10:52 --> Helper loaded: file_helper
INFO - 2023-07-21 17:10:52 --> Helper loaded: html_helper
INFO - 2023-07-21 17:10:52 --> Helper loaded: text_helper
INFO - 2023-07-21 17:10:52 --> Helper loaded: form_helper
INFO - 2023-07-21 17:10:52 --> Helper loaded: lang_helper
INFO - 2023-07-21 17:10:52 --> Helper loaded: security_helper
INFO - 2023-07-21 17:10:52 --> Helper loaded: cookie_helper
INFO - 2023-07-21 17:10:52 --> Database Driver Class Initialized
INFO - 2023-07-21 17:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 17:10:52 --> Parser Class Initialized
INFO - 2023-07-21 17:10:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 17:10:52 --> Pagination Class Initialized
INFO - 2023-07-21 17:10:52 --> Form Validation Class Initialized
INFO - 2023-07-21 17:10:52 --> Controller Class Initialized
INFO - 2023-07-21 17:10:52 --> Model Class Initialized
DEBUG - 2023-07-21 17:10:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 17:10:52 --> Model Class Initialized
DEBUG - 2023-07-21 17:10:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 17:10:52 --> Model Class Initialized
INFO - 2023-07-21 17:10:53 --> Model Class Initialized
INFO - 2023-07-21 17:10:53 --> Model Class Initialized
INFO - 2023-07-21 17:10:53 --> Model Class Initialized
DEBUG - 2023-07-21 17:10:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 17:10:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 17:10:53 --> Model Class Initialized
INFO - 2023-07-21 17:10:53 --> Model Class Initialized
INFO - 2023-07-21 17:10:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-21 17:10:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 17:10:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 17:10:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 17:10:53 --> Model Class Initialized
INFO - 2023-07-21 17:10:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 17:10:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 17:10:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 17:10:53 --> Final output sent to browser
DEBUG - 2023-07-21 17:10:53 --> Total execution time: 0.1672
ERROR - 2023-07-21 17:10:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 17:10:56 --> Config Class Initialized
INFO - 2023-07-21 17:10:56 --> Hooks Class Initialized
DEBUG - 2023-07-21 17:10:56 --> UTF-8 Support Enabled
INFO - 2023-07-21 17:10:56 --> Utf8 Class Initialized
INFO - 2023-07-21 17:10:56 --> URI Class Initialized
INFO - 2023-07-21 17:10:56 --> Router Class Initialized
INFO - 2023-07-21 17:10:56 --> Output Class Initialized
INFO - 2023-07-21 17:10:56 --> Security Class Initialized
DEBUG - 2023-07-21 17:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 17:10:56 --> Input Class Initialized
INFO - 2023-07-21 17:10:56 --> Language Class Initialized
INFO - 2023-07-21 17:10:56 --> Loader Class Initialized
INFO - 2023-07-21 17:10:56 --> Helper loaded: url_helper
INFO - 2023-07-21 17:10:56 --> Helper loaded: file_helper
INFO - 2023-07-21 17:10:56 --> Helper loaded: html_helper
INFO - 2023-07-21 17:10:56 --> Helper loaded: text_helper
INFO - 2023-07-21 17:10:56 --> Helper loaded: form_helper
INFO - 2023-07-21 17:10:56 --> Helper loaded: lang_helper
INFO - 2023-07-21 17:10:56 --> Helper loaded: security_helper
INFO - 2023-07-21 17:10:56 --> Helper loaded: cookie_helper
INFO - 2023-07-21 17:10:56 --> Database Driver Class Initialized
INFO - 2023-07-21 17:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 17:10:56 --> Parser Class Initialized
INFO - 2023-07-21 17:10:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 17:10:56 --> Pagination Class Initialized
INFO - 2023-07-21 17:10:56 --> Form Validation Class Initialized
INFO - 2023-07-21 17:10:56 --> Controller Class Initialized
INFO - 2023-07-21 17:10:56 --> Model Class Initialized
DEBUG - 2023-07-21 17:10:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 17:10:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 17:10:56 --> Model Class Initialized
DEBUG - 2023-07-21 17:10:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 17:10:56 --> Model Class Initialized
INFO - 2023-07-21 17:10:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-21 17:10:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 17:10:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 17:10:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 17:10:56 --> Model Class Initialized
INFO - 2023-07-21 17:10:56 --> Model Class Initialized
INFO - 2023-07-21 17:10:56 --> Model Class Initialized
INFO - 2023-07-21 17:10:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 17:10:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 17:10:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 17:10:56 --> Final output sent to browser
DEBUG - 2023-07-21 17:10:56 --> Total execution time: 0.1331
ERROR - 2023-07-21 17:10:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 17:10:57 --> Config Class Initialized
INFO - 2023-07-21 17:10:57 --> Hooks Class Initialized
DEBUG - 2023-07-21 17:10:57 --> UTF-8 Support Enabled
INFO - 2023-07-21 17:10:57 --> Utf8 Class Initialized
INFO - 2023-07-21 17:10:57 --> URI Class Initialized
INFO - 2023-07-21 17:10:57 --> Router Class Initialized
INFO - 2023-07-21 17:10:57 --> Output Class Initialized
INFO - 2023-07-21 17:10:57 --> Security Class Initialized
DEBUG - 2023-07-21 17:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 17:10:57 --> Input Class Initialized
INFO - 2023-07-21 17:10:57 --> Language Class Initialized
INFO - 2023-07-21 17:10:57 --> Loader Class Initialized
INFO - 2023-07-21 17:10:57 --> Helper loaded: url_helper
INFO - 2023-07-21 17:10:57 --> Helper loaded: file_helper
INFO - 2023-07-21 17:10:57 --> Helper loaded: html_helper
INFO - 2023-07-21 17:10:57 --> Helper loaded: text_helper
INFO - 2023-07-21 17:10:57 --> Helper loaded: form_helper
INFO - 2023-07-21 17:10:57 --> Helper loaded: lang_helper
INFO - 2023-07-21 17:10:57 --> Helper loaded: security_helper
INFO - 2023-07-21 17:10:57 --> Helper loaded: cookie_helper
INFO - 2023-07-21 17:10:57 --> Database Driver Class Initialized
INFO - 2023-07-21 17:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 17:10:57 --> Parser Class Initialized
INFO - 2023-07-21 17:10:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 17:10:57 --> Pagination Class Initialized
INFO - 2023-07-21 17:10:57 --> Form Validation Class Initialized
INFO - 2023-07-21 17:10:57 --> Controller Class Initialized
INFO - 2023-07-21 17:10:57 --> Model Class Initialized
DEBUG - 2023-07-21 17:10:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 17:10:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 17:10:57 --> Model Class Initialized
DEBUG - 2023-07-21 17:10:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 17:10:57 --> Model Class Initialized
INFO - 2023-07-21 17:10:57 --> Final output sent to browser
DEBUG - 2023-07-21 17:10:57 --> Total execution time: 0.0454
ERROR - 2023-07-21 17:11:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 17:11:01 --> Config Class Initialized
INFO - 2023-07-21 17:11:01 --> Hooks Class Initialized
DEBUG - 2023-07-21 17:11:01 --> UTF-8 Support Enabled
INFO - 2023-07-21 17:11:01 --> Utf8 Class Initialized
INFO - 2023-07-21 17:11:01 --> URI Class Initialized
INFO - 2023-07-21 17:11:01 --> Router Class Initialized
INFO - 2023-07-21 17:11:01 --> Output Class Initialized
INFO - 2023-07-21 17:11:01 --> Security Class Initialized
DEBUG - 2023-07-21 17:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 17:11:01 --> Input Class Initialized
INFO - 2023-07-21 17:11:01 --> Language Class Initialized
INFO - 2023-07-21 17:11:01 --> Loader Class Initialized
INFO - 2023-07-21 17:11:01 --> Helper loaded: url_helper
INFO - 2023-07-21 17:11:01 --> Helper loaded: file_helper
INFO - 2023-07-21 17:11:01 --> Helper loaded: html_helper
INFO - 2023-07-21 17:11:01 --> Helper loaded: text_helper
INFO - 2023-07-21 17:11:01 --> Helper loaded: form_helper
INFO - 2023-07-21 17:11:01 --> Helper loaded: lang_helper
INFO - 2023-07-21 17:11:01 --> Helper loaded: security_helper
INFO - 2023-07-21 17:11:01 --> Helper loaded: cookie_helper
INFO - 2023-07-21 17:11:01 --> Database Driver Class Initialized
INFO - 2023-07-21 17:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 17:11:01 --> Parser Class Initialized
INFO - 2023-07-21 17:11:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 17:11:01 --> Pagination Class Initialized
INFO - 2023-07-21 17:11:01 --> Form Validation Class Initialized
INFO - 2023-07-21 17:11:01 --> Controller Class Initialized
INFO - 2023-07-21 17:11:01 --> Model Class Initialized
DEBUG - 2023-07-21 17:11:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 17:11:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 17:11:01 --> Model Class Initialized
DEBUG - 2023-07-21 17:11:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 17:11:01 --> Model Class Initialized
INFO - 2023-07-21 17:11:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-21 17:11:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 17:11:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 17:11:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 17:11:01 --> Model Class Initialized
INFO - 2023-07-21 17:11:01 --> Model Class Initialized
INFO - 2023-07-21 17:11:01 --> Model Class Initialized
INFO - 2023-07-21 17:11:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 17:11:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 17:11:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 17:11:01 --> Final output sent to browser
DEBUG - 2023-07-21 17:11:01 --> Total execution time: 0.1655
ERROR - 2023-07-21 17:11:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 17:11:01 --> Config Class Initialized
INFO - 2023-07-21 17:11:01 --> Hooks Class Initialized
DEBUG - 2023-07-21 17:11:01 --> UTF-8 Support Enabled
INFO - 2023-07-21 17:11:01 --> Utf8 Class Initialized
INFO - 2023-07-21 17:11:01 --> URI Class Initialized
INFO - 2023-07-21 17:11:01 --> Router Class Initialized
INFO - 2023-07-21 17:11:01 --> Output Class Initialized
INFO - 2023-07-21 17:11:01 --> Security Class Initialized
DEBUG - 2023-07-21 17:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 17:11:01 --> Input Class Initialized
INFO - 2023-07-21 17:11:01 --> Language Class Initialized
INFO - 2023-07-21 17:11:01 --> Loader Class Initialized
INFO - 2023-07-21 17:11:01 --> Helper loaded: url_helper
INFO - 2023-07-21 17:11:01 --> Helper loaded: file_helper
INFO - 2023-07-21 17:11:01 --> Helper loaded: html_helper
INFO - 2023-07-21 17:11:01 --> Helper loaded: text_helper
INFO - 2023-07-21 17:11:01 --> Helper loaded: form_helper
INFO - 2023-07-21 17:11:01 --> Helper loaded: lang_helper
INFO - 2023-07-21 17:11:01 --> Helper loaded: security_helper
INFO - 2023-07-21 17:11:01 --> Helper loaded: cookie_helper
INFO - 2023-07-21 17:11:01 --> Database Driver Class Initialized
INFO - 2023-07-21 17:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 17:11:01 --> Parser Class Initialized
INFO - 2023-07-21 17:11:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 17:11:01 --> Pagination Class Initialized
INFO - 2023-07-21 17:11:01 --> Form Validation Class Initialized
INFO - 2023-07-21 17:11:01 --> Controller Class Initialized
INFO - 2023-07-21 17:11:01 --> Model Class Initialized
DEBUG - 2023-07-21 17:11:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 17:11:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 17:11:01 --> Model Class Initialized
DEBUG - 2023-07-21 17:11:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 17:11:01 --> Model Class Initialized
INFO - 2023-07-21 17:11:01 --> Final output sent to browser
DEBUG - 2023-07-21 17:11:01 --> Total execution time: 0.0554
ERROR - 2023-07-21 17:11:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 17:11:04 --> Config Class Initialized
INFO - 2023-07-21 17:11:04 --> Hooks Class Initialized
DEBUG - 2023-07-21 17:11:04 --> UTF-8 Support Enabled
INFO - 2023-07-21 17:11:04 --> Utf8 Class Initialized
INFO - 2023-07-21 17:11:04 --> URI Class Initialized
DEBUG - 2023-07-21 17:11:04 --> No URI present. Default controller set.
INFO - 2023-07-21 17:11:04 --> Router Class Initialized
INFO - 2023-07-21 17:11:04 --> Output Class Initialized
INFO - 2023-07-21 17:11:04 --> Security Class Initialized
DEBUG - 2023-07-21 17:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 17:11:04 --> Input Class Initialized
INFO - 2023-07-21 17:11:04 --> Language Class Initialized
INFO - 2023-07-21 17:11:04 --> Loader Class Initialized
INFO - 2023-07-21 17:11:04 --> Helper loaded: url_helper
INFO - 2023-07-21 17:11:04 --> Helper loaded: file_helper
INFO - 2023-07-21 17:11:04 --> Helper loaded: html_helper
INFO - 2023-07-21 17:11:04 --> Helper loaded: text_helper
INFO - 2023-07-21 17:11:04 --> Helper loaded: form_helper
INFO - 2023-07-21 17:11:04 --> Helper loaded: lang_helper
INFO - 2023-07-21 17:11:04 --> Helper loaded: security_helper
INFO - 2023-07-21 17:11:04 --> Helper loaded: cookie_helper
INFO - 2023-07-21 17:11:04 --> Database Driver Class Initialized
INFO - 2023-07-21 17:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 17:11:04 --> Parser Class Initialized
INFO - 2023-07-21 17:11:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 17:11:04 --> Pagination Class Initialized
INFO - 2023-07-21 17:11:04 --> Form Validation Class Initialized
INFO - 2023-07-21 17:11:04 --> Controller Class Initialized
INFO - 2023-07-21 17:11:04 --> Model Class Initialized
DEBUG - 2023-07-21 17:11:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 17:11:04 --> Model Class Initialized
DEBUG - 2023-07-21 17:11:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 17:11:04 --> Model Class Initialized
INFO - 2023-07-21 17:11:04 --> Model Class Initialized
INFO - 2023-07-21 17:11:04 --> Model Class Initialized
INFO - 2023-07-21 17:11:04 --> Model Class Initialized
DEBUG - 2023-07-21 17:11:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 17:11:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 17:11:04 --> Model Class Initialized
INFO - 2023-07-21 17:11:04 --> Model Class Initialized
INFO - 2023-07-21 17:11:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-21 17:11:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 17:11:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 17:11:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 17:11:04 --> Model Class Initialized
INFO - 2023-07-21 17:11:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 17:11:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 17:11:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 17:11:04 --> Final output sent to browser
DEBUG - 2023-07-21 17:11:04 --> Total execution time: 0.1799
ERROR - 2023-07-21 17:11:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 17:11:16 --> Config Class Initialized
INFO - 2023-07-21 17:11:16 --> Hooks Class Initialized
DEBUG - 2023-07-21 17:11:16 --> UTF-8 Support Enabled
INFO - 2023-07-21 17:11:16 --> Utf8 Class Initialized
INFO - 2023-07-21 17:11:16 --> URI Class Initialized
INFO - 2023-07-21 17:11:16 --> Router Class Initialized
INFO - 2023-07-21 17:11:16 --> Output Class Initialized
INFO - 2023-07-21 17:11:16 --> Security Class Initialized
DEBUG - 2023-07-21 17:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 17:11:16 --> Input Class Initialized
INFO - 2023-07-21 17:11:16 --> Language Class Initialized
INFO - 2023-07-21 17:11:16 --> Loader Class Initialized
INFO - 2023-07-21 17:11:16 --> Helper loaded: url_helper
INFO - 2023-07-21 17:11:16 --> Helper loaded: file_helper
INFO - 2023-07-21 17:11:16 --> Helper loaded: html_helper
INFO - 2023-07-21 17:11:16 --> Helper loaded: text_helper
INFO - 2023-07-21 17:11:16 --> Helper loaded: form_helper
INFO - 2023-07-21 17:11:16 --> Helper loaded: lang_helper
INFO - 2023-07-21 17:11:16 --> Helper loaded: security_helper
INFO - 2023-07-21 17:11:16 --> Helper loaded: cookie_helper
INFO - 2023-07-21 17:11:16 --> Database Driver Class Initialized
INFO - 2023-07-21 17:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 17:11:16 --> Parser Class Initialized
INFO - 2023-07-21 17:11:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 17:11:16 --> Pagination Class Initialized
INFO - 2023-07-21 17:11:16 --> Form Validation Class Initialized
INFO - 2023-07-21 17:11:16 --> Controller Class Initialized
INFO - 2023-07-21 17:11:16 --> Model Class Initialized
DEBUG - 2023-07-21 17:11:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 17:11:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 17:11:16 --> Model Class Initialized
DEBUG - 2023-07-21 17:11:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 17:11:16 --> Model Class Initialized
INFO - 2023-07-21 17:11:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-21 17:11:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 17:11:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 17:11:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 17:11:16 --> Model Class Initialized
INFO - 2023-07-21 17:11:16 --> Model Class Initialized
INFO - 2023-07-21 17:11:16 --> Model Class Initialized
INFO - 2023-07-21 17:11:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-21 17:11:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-21 17:11:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 17:11:16 --> Final output sent to browser
DEBUG - 2023-07-21 17:11:16 --> Total execution time: 0.1330
ERROR - 2023-07-21 17:11:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 17:11:16 --> Config Class Initialized
INFO - 2023-07-21 17:11:16 --> Hooks Class Initialized
DEBUG - 2023-07-21 17:11:16 --> UTF-8 Support Enabled
INFO - 2023-07-21 17:11:16 --> Utf8 Class Initialized
INFO - 2023-07-21 17:11:16 --> URI Class Initialized
INFO - 2023-07-21 17:11:16 --> Router Class Initialized
INFO - 2023-07-21 17:11:16 --> Output Class Initialized
INFO - 2023-07-21 17:11:16 --> Security Class Initialized
DEBUG - 2023-07-21 17:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 17:11:16 --> Input Class Initialized
INFO - 2023-07-21 17:11:16 --> Language Class Initialized
INFO - 2023-07-21 17:11:16 --> Loader Class Initialized
INFO - 2023-07-21 17:11:16 --> Helper loaded: url_helper
INFO - 2023-07-21 17:11:16 --> Helper loaded: file_helper
INFO - 2023-07-21 17:11:16 --> Helper loaded: html_helper
INFO - 2023-07-21 17:11:16 --> Helper loaded: text_helper
INFO - 2023-07-21 17:11:16 --> Helper loaded: form_helper
INFO - 2023-07-21 17:11:16 --> Helper loaded: lang_helper
INFO - 2023-07-21 17:11:16 --> Helper loaded: security_helper
INFO - 2023-07-21 17:11:16 --> Helper loaded: cookie_helper
INFO - 2023-07-21 17:11:16 --> Database Driver Class Initialized
INFO - 2023-07-21 17:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 17:11:16 --> Parser Class Initialized
INFO - 2023-07-21 17:11:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 17:11:16 --> Pagination Class Initialized
INFO - 2023-07-21 17:11:16 --> Form Validation Class Initialized
INFO - 2023-07-21 17:11:16 --> Controller Class Initialized
INFO - 2023-07-21 17:11:16 --> Model Class Initialized
DEBUG - 2023-07-21 17:11:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-21 17:11:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 17:11:16 --> Model Class Initialized
DEBUG - 2023-07-21 17:11:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 17:11:16 --> Model Class Initialized
INFO - 2023-07-21 17:11:16 --> Final output sent to browser
DEBUG - 2023-07-21 17:11:16 --> Total execution time: 0.0455
ERROR - 2023-07-21 20:25:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-21 20:25:42 --> Config Class Initialized
INFO - 2023-07-21 20:25:42 --> Hooks Class Initialized
DEBUG - 2023-07-21 20:25:42 --> UTF-8 Support Enabled
INFO - 2023-07-21 20:25:42 --> Utf8 Class Initialized
INFO - 2023-07-21 20:25:42 --> URI Class Initialized
INFO - 2023-07-21 20:25:42 --> Router Class Initialized
INFO - 2023-07-21 20:25:42 --> Output Class Initialized
INFO - 2023-07-21 20:25:42 --> Security Class Initialized
DEBUG - 2023-07-21 20:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 20:25:42 --> Input Class Initialized
INFO - 2023-07-21 20:25:42 --> Language Class Initialized
INFO - 2023-07-21 20:25:42 --> Loader Class Initialized
INFO - 2023-07-21 20:25:42 --> Helper loaded: url_helper
INFO - 2023-07-21 20:25:42 --> Helper loaded: file_helper
INFO - 2023-07-21 20:25:42 --> Helper loaded: html_helper
INFO - 2023-07-21 20:25:42 --> Helper loaded: text_helper
INFO - 2023-07-21 20:25:42 --> Helper loaded: form_helper
INFO - 2023-07-21 20:25:42 --> Helper loaded: lang_helper
INFO - 2023-07-21 20:25:42 --> Helper loaded: security_helper
INFO - 2023-07-21 20:25:42 --> Helper loaded: cookie_helper
INFO - 2023-07-21 20:25:42 --> Database Driver Class Initialized
INFO - 2023-07-21 20:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 20:25:42 --> Parser Class Initialized
INFO - 2023-07-21 20:25:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-21 20:25:42 --> Pagination Class Initialized
INFO - 2023-07-21 20:25:42 --> Form Validation Class Initialized
INFO - 2023-07-21 20:25:42 --> Controller Class Initialized
INFO - 2023-07-21 20:25:42 --> Model Class Initialized
DEBUG - 2023-07-21 20:25:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-21 20:25:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-21 20:25:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-21 20:25:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-21 20:25:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-21 20:25:42 --> Model Class Initialized
INFO - 2023-07-21 20:25:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-21 20:25:42 --> Final output sent to browser
DEBUG - 2023-07-21 20:25:42 --> Total execution time: 0.0372
