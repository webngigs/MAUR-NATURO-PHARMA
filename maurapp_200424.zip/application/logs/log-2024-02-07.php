<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-02-07 01:37:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 01:37:41 --> Config Class Initialized
INFO - 2024-02-07 01:37:41 --> Hooks Class Initialized
DEBUG - 2024-02-07 01:37:41 --> UTF-8 Support Enabled
INFO - 2024-02-07 01:37:41 --> Utf8 Class Initialized
INFO - 2024-02-07 01:37:41 --> URI Class Initialized
INFO - 2024-02-07 01:37:41 --> Router Class Initialized
INFO - 2024-02-07 01:37:41 --> Output Class Initialized
INFO - 2024-02-07 01:37:41 --> Security Class Initialized
DEBUG - 2024-02-07 01:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 01:37:41 --> Input Class Initialized
INFO - 2024-02-07 01:37:41 --> Language Class Initialized
ERROR - 2024-02-07 01:37:41 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-02-07 02:18:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 02:18:15 --> Config Class Initialized
INFO - 2024-02-07 02:18:15 --> Hooks Class Initialized
DEBUG - 2024-02-07 02:18:15 --> UTF-8 Support Enabled
INFO - 2024-02-07 02:18:15 --> Utf8 Class Initialized
INFO - 2024-02-07 02:18:15 --> URI Class Initialized
DEBUG - 2024-02-07 02:18:15 --> No URI present. Default controller set.
INFO - 2024-02-07 02:18:15 --> Router Class Initialized
INFO - 2024-02-07 02:18:15 --> Output Class Initialized
INFO - 2024-02-07 02:18:15 --> Security Class Initialized
DEBUG - 2024-02-07 02:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 02:18:15 --> Input Class Initialized
INFO - 2024-02-07 02:18:15 --> Language Class Initialized
INFO - 2024-02-07 02:18:15 --> Loader Class Initialized
INFO - 2024-02-07 02:18:15 --> Helper loaded: url_helper
INFO - 2024-02-07 02:18:15 --> Helper loaded: file_helper
INFO - 2024-02-07 02:18:15 --> Helper loaded: html_helper
INFO - 2024-02-07 02:18:15 --> Helper loaded: text_helper
INFO - 2024-02-07 02:18:15 --> Helper loaded: form_helper
INFO - 2024-02-07 02:18:15 --> Helper loaded: lang_helper
INFO - 2024-02-07 02:18:15 --> Helper loaded: security_helper
INFO - 2024-02-07 02:18:15 --> Helper loaded: cookie_helper
INFO - 2024-02-07 02:18:15 --> Database Driver Class Initialized
INFO - 2024-02-07 02:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 02:18:15 --> Parser Class Initialized
INFO - 2024-02-07 02:18:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 02:18:15 --> Pagination Class Initialized
INFO - 2024-02-07 02:18:15 --> Form Validation Class Initialized
INFO - 2024-02-07 02:18:15 --> Controller Class Initialized
INFO - 2024-02-07 02:18:15 --> Model Class Initialized
DEBUG - 2024-02-07 02:18:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-07 02:18:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 02:18:16 --> Config Class Initialized
INFO - 2024-02-07 02:18:16 --> Hooks Class Initialized
DEBUG - 2024-02-07 02:18:16 --> UTF-8 Support Enabled
INFO - 2024-02-07 02:18:16 --> Utf8 Class Initialized
INFO - 2024-02-07 02:18:16 --> URI Class Initialized
INFO - 2024-02-07 02:18:16 --> Router Class Initialized
INFO - 2024-02-07 02:18:16 --> Output Class Initialized
INFO - 2024-02-07 02:18:16 --> Security Class Initialized
DEBUG - 2024-02-07 02:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 02:18:16 --> Input Class Initialized
INFO - 2024-02-07 02:18:16 --> Language Class Initialized
INFO - 2024-02-07 02:18:16 --> Loader Class Initialized
INFO - 2024-02-07 02:18:16 --> Helper loaded: url_helper
INFO - 2024-02-07 02:18:16 --> Helper loaded: file_helper
INFO - 2024-02-07 02:18:16 --> Helper loaded: html_helper
INFO - 2024-02-07 02:18:16 --> Helper loaded: text_helper
INFO - 2024-02-07 02:18:16 --> Helper loaded: form_helper
INFO - 2024-02-07 02:18:16 --> Helper loaded: lang_helper
INFO - 2024-02-07 02:18:16 --> Helper loaded: security_helper
INFO - 2024-02-07 02:18:16 --> Helper loaded: cookie_helper
INFO - 2024-02-07 02:18:16 --> Database Driver Class Initialized
INFO - 2024-02-07 02:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 02:18:16 --> Parser Class Initialized
INFO - 2024-02-07 02:18:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 02:18:16 --> Pagination Class Initialized
INFO - 2024-02-07 02:18:16 --> Form Validation Class Initialized
INFO - 2024-02-07 02:18:16 --> Controller Class Initialized
INFO - 2024-02-07 02:18:16 --> Model Class Initialized
DEBUG - 2024-02-07 02:18:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 02:18:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-07 02:18:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 02:18:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 02:18:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 02:18:16 --> Model Class Initialized
INFO - 2024-02-07 02:18:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 02:18:16 --> Final output sent to browser
DEBUG - 2024-02-07 02:18:16 --> Total execution time: 0.0335
ERROR - 2024-02-07 05:54:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 05:54:30 --> Config Class Initialized
INFO - 2024-02-07 05:54:30 --> Hooks Class Initialized
DEBUG - 2024-02-07 05:54:30 --> UTF-8 Support Enabled
INFO - 2024-02-07 05:54:30 --> Utf8 Class Initialized
INFO - 2024-02-07 05:54:30 --> URI Class Initialized
DEBUG - 2024-02-07 05:54:30 --> No URI present. Default controller set.
INFO - 2024-02-07 05:54:30 --> Router Class Initialized
INFO - 2024-02-07 05:54:30 --> Output Class Initialized
INFO - 2024-02-07 05:54:30 --> Security Class Initialized
DEBUG - 2024-02-07 05:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 05:54:30 --> Input Class Initialized
INFO - 2024-02-07 05:54:30 --> Language Class Initialized
INFO - 2024-02-07 05:54:30 --> Loader Class Initialized
INFO - 2024-02-07 05:54:30 --> Helper loaded: url_helper
INFO - 2024-02-07 05:54:30 --> Helper loaded: file_helper
INFO - 2024-02-07 05:54:30 --> Helper loaded: html_helper
INFO - 2024-02-07 05:54:30 --> Helper loaded: text_helper
INFO - 2024-02-07 05:54:30 --> Helper loaded: form_helper
INFO - 2024-02-07 05:54:30 --> Helper loaded: lang_helper
INFO - 2024-02-07 05:54:30 --> Helper loaded: security_helper
INFO - 2024-02-07 05:54:30 --> Helper loaded: cookie_helper
INFO - 2024-02-07 05:54:30 --> Database Driver Class Initialized
INFO - 2024-02-07 05:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 05:54:30 --> Parser Class Initialized
INFO - 2024-02-07 05:54:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 05:54:30 --> Pagination Class Initialized
INFO - 2024-02-07 05:54:30 --> Form Validation Class Initialized
INFO - 2024-02-07 05:54:30 --> Controller Class Initialized
INFO - 2024-02-07 05:54:30 --> Model Class Initialized
DEBUG - 2024-02-07 05:54:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-07 05:54:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 05:54:30 --> Config Class Initialized
INFO - 2024-02-07 05:54:30 --> Hooks Class Initialized
DEBUG - 2024-02-07 05:54:30 --> UTF-8 Support Enabled
INFO - 2024-02-07 05:54:30 --> Utf8 Class Initialized
INFO - 2024-02-07 05:54:30 --> URI Class Initialized
INFO - 2024-02-07 05:54:30 --> Router Class Initialized
INFO - 2024-02-07 05:54:30 --> Output Class Initialized
INFO - 2024-02-07 05:54:30 --> Security Class Initialized
DEBUG - 2024-02-07 05:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 05:54:30 --> Input Class Initialized
INFO - 2024-02-07 05:54:30 --> Language Class Initialized
INFO - 2024-02-07 05:54:30 --> Loader Class Initialized
INFO - 2024-02-07 05:54:30 --> Helper loaded: url_helper
INFO - 2024-02-07 05:54:30 --> Helper loaded: file_helper
INFO - 2024-02-07 05:54:30 --> Helper loaded: html_helper
INFO - 2024-02-07 05:54:30 --> Helper loaded: text_helper
INFO - 2024-02-07 05:54:30 --> Helper loaded: form_helper
INFO - 2024-02-07 05:54:30 --> Helper loaded: lang_helper
INFO - 2024-02-07 05:54:30 --> Helper loaded: security_helper
INFO - 2024-02-07 05:54:30 --> Helper loaded: cookie_helper
INFO - 2024-02-07 05:54:30 --> Database Driver Class Initialized
INFO - 2024-02-07 05:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 05:54:30 --> Parser Class Initialized
INFO - 2024-02-07 05:54:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 05:54:30 --> Pagination Class Initialized
INFO - 2024-02-07 05:54:30 --> Form Validation Class Initialized
INFO - 2024-02-07 05:54:30 --> Controller Class Initialized
INFO - 2024-02-07 05:54:30 --> Model Class Initialized
DEBUG - 2024-02-07 05:54:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:54:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-07 05:54:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:54:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 05:54:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 05:54:30 --> Model Class Initialized
INFO - 2024-02-07 05:54:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 05:54:30 --> Final output sent to browser
DEBUG - 2024-02-07 05:54:30 --> Total execution time: 0.0342
ERROR - 2024-02-07 05:57:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 05:57:17 --> Config Class Initialized
INFO - 2024-02-07 05:57:17 --> Hooks Class Initialized
DEBUG - 2024-02-07 05:57:17 --> UTF-8 Support Enabled
INFO - 2024-02-07 05:57:17 --> Utf8 Class Initialized
INFO - 2024-02-07 05:57:17 --> URI Class Initialized
DEBUG - 2024-02-07 05:57:17 --> No URI present. Default controller set.
INFO - 2024-02-07 05:57:17 --> Router Class Initialized
INFO - 2024-02-07 05:57:17 --> Output Class Initialized
INFO - 2024-02-07 05:57:17 --> Security Class Initialized
DEBUG - 2024-02-07 05:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 05:57:17 --> Input Class Initialized
INFO - 2024-02-07 05:57:17 --> Language Class Initialized
INFO - 2024-02-07 05:57:17 --> Loader Class Initialized
INFO - 2024-02-07 05:57:17 --> Helper loaded: url_helper
INFO - 2024-02-07 05:57:17 --> Helper loaded: file_helper
INFO - 2024-02-07 05:57:17 --> Helper loaded: html_helper
INFO - 2024-02-07 05:57:17 --> Helper loaded: text_helper
INFO - 2024-02-07 05:57:17 --> Helper loaded: form_helper
INFO - 2024-02-07 05:57:17 --> Helper loaded: lang_helper
INFO - 2024-02-07 05:57:17 --> Helper loaded: security_helper
INFO - 2024-02-07 05:57:17 --> Helper loaded: cookie_helper
INFO - 2024-02-07 05:57:17 --> Database Driver Class Initialized
INFO - 2024-02-07 05:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 05:57:17 --> Parser Class Initialized
INFO - 2024-02-07 05:57:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 05:57:17 --> Pagination Class Initialized
INFO - 2024-02-07 05:57:17 --> Form Validation Class Initialized
INFO - 2024-02-07 05:57:17 --> Controller Class Initialized
INFO - 2024-02-07 05:57:17 --> Model Class Initialized
DEBUG - 2024-02-07 05:57:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-07 05:57:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 05:57:17 --> Config Class Initialized
INFO - 2024-02-07 05:57:17 --> Hooks Class Initialized
DEBUG - 2024-02-07 05:57:17 --> UTF-8 Support Enabled
INFO - 2024-02-07 05:57:17 --> Utf8 Class Initialized
INFO - 2024-02-07 05:57:17 --> URI Class Initialized
INFO - 2024-02-07 05:57:17 --> Router Class Initialized
INFO - 2024-02-07 05:57:17 --> Output Class Initialized
INFO - 2024-02-07 05:57:17 --> Security Class Initialized
DEBUG - 2024-02-07 05:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 05:57:17 --> Input Class Initialized
INFO - 2024-02-07 05:57:17 --> Language Class Initialized
INFO - 2024-02-07 05:57:17 --> Loader Class Initialized
INFO - 2024-02-07 05:57:17 --> Helper loaded: url_helper
INFO - 2024-02-07 05:57:17 --> Helper loaded: file_helper
INFO - 2024-02-07 05:57:17 --> Helper loaded: html_helper
INFO - 2024-02-07 05:57:17 --> Helper loaded: text_helper
INFO - 2024-02-07 05:57:17 --> Helper loaded: form_helper
INFO - 2024-02-07 05:57:17 --> Helper loaded: lang_helper
INFO - 2024-02-07 05:57:17 --> Helper loaded: security_helper
INFO - 2024-02-07 05:57:17 --> Helper loaded: cookie_helper
INFO - 2024-02-07 05:57:17 --> Database Driver Class Initialized
INFO - 2024-02-07 05:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 05:57:17 --> Parser Class Initialized
INFO - 2024-02-07 05:57:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 05:57:17 --> Pagination Class Initialized
INFO - 2024-02-07 05:57:17 --> Form Validation Class Initialized
INFO - 2024-02-07 05:57:17 --> Controller Class Initialized
INFO - 2024-02-07 05:57:17 --> Model Class Initialized
DEBUG - 2024-02-07 05:57:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-07 05:57:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 05:57:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 05:57:17 --> Model Class Initialized
INFO - 2024-02-07 05:57:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 05:57:17 --> Final output sent to browser
DEBUG - 2024-02-07 05:57:17 --> Total execution time: 0.0314
ERROR - 2024-02-07 05:57:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 05:57:25 --> Config Class Initialized
INFO - 2024-02-07 05:57:25 --> Hooks Class Initialized
DEBUG - 2024-02-07 05:57:25 --> UTF-8 Support Enabled
INFO - 2024-02-07 05:57:25 --> Utf8 Class Initialized
INFO - 2024-02-07 05:57:25 --> URI Class Initialized
INFO - 2024-02-07 05:57:25 --> Router Class Initialized
INFO - 2024-02-07 05:57:25 --> Output Class Initialized
INFO - 2024-02-07 05:57:25 --> Security Class Initialized
DEBUG - 2024-02-07 05:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 05:57:25 --> Input Class Initialized
INFO - 2024-02-07 05:57:25 --> Language Class Initialized
INFO - 2024-02-07 05:57:25 --> Loader Class Initialized
INFO - 2024-02-07 05:57:25 --> Helper loaded: url_helper
INFO - 2024-02-07 05:57:25 --> Helper loaded: file_helper
INFO - 2024-02-07 05:57:25 --> Helper loaded: html_helper
INFO - 2024-02-07 05:57:25 --> Helper loaded: text_helper
INFO - 2024-02-07 05:57:25 --> Helper loaded: form_helper
INFO - 2024-02-07 05:57:25 --> Helper loaded: lang_helper
INFO - 2024-02-07 05:57:25 --> Helper loaded: security_helper
INFO - 2024-02-07 05:57:25 --> Helper loaded: cookie_helper
INFO - 2024-02-07 05:57:25 --> Database Driver Class Initialized
INFO - 2024-02-07 05:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 05:57:25 --> Parser Class Initialized
INFO - 2024-02-07 05:57:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 05:57:25 --> Pagination Class Initialized
INFO - 2024-02-07 05:57:25 --> Form Validation Class Initialized
INFO - 2024-02-07 05:57:25 --> Controller Class Initialized
INFO - 2024-02-07 05:57:25 --> Model Class Initialized
DEBUG - 2024-02-07 05:57:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:25 --> Model Class Initialized
INFO - 2024-02-07 05:57:25 --> Final output sent to browser
DEBUG - 2024-02-07 05:57:25 --> Total execution time: 0.0223
ERROR - 2024-02-07 05:57:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 05:57:25 --> Config Class Initialized
INFO - 2024-02-07 05:57:25 --> Hooks Class Initialized
DEBUG - 2024-02-07 05:57:25 --> UTF-8 Support Enabled
INFO - 2024-02-07 05:57:25 --> Utf8 Class Initialized
INFO - 2024-02-07 05:57:25 --> URI Class Initialized
INFO - 2024-02-07 05:57:25 --> Router Class Initialized
INFO - 2024-02-07 05:57:25 --> Output Class Initialized
INFO - 2024-02-07 05:57:25 --> Security Class Initialized
DEBUG - 2024-02-07 05:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 05:57:25 --> Input Class Initialized
INFO - 2024-02-07 05:57:25 --> Language Class Initialized
INFO - 2024-02-07 05:57:25 --> Loader Class Initialized
INFO - 2024-02-07 05:57:25 --> Helper loaded: url_helper
INFO - 2024-02-07 05:57:25 --> Helper loaded: file_helper
INFO - 2024-02-07 05:57:25 --> Helper loaded: html_helper
INFO - 2024-02-07 05:57:25 --> Helper loaded: text_helper
INFO - 2024-02-07 05:57:25 --> Helper loaded: form_helper
INFO - 2024-02-07 05:57:25 --> Helper loaded: lang_helper
INFO - 2024-02-07 05:57:25 --> Helper loaded: security_helper
INFO - 2024-02-07 05:57:25 --> Helper loaded: cookie_helper
INFO - 2024-02-07 05:57:25 --> Database Driver Class Initialized
INFO - 2024-02-07 05:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 05:57:25 --> Parser Class Initialized
INFO - 2024-02-07 05:57:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 05:57:25 --> Pagination Class Initialized
INFO - 2024-02-07 05:57:25 --> Form Validation Class Initialized
INFO - 2024-02-07 05:57:25 --> Controller Class Initialized
INFO - 2024-02-07 05:57:25 --> Model Class Initialized
DEBUG - 2024-02-07 05:57:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:25 --> Model Class Initialized
INFO - 2024-02-07 05:57:25 --> Final output sent to browser
DEBUG - 2024-02-07 05:57:25 --> Total execution time: 0.0162
ERROR - 2024-02-07 05:57:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 05:57:25 --> Config Class Initialized
INFO - 2024-02-07 05:57:25 --> Hooks Class Initialized
DEBUG - 2024-02-07 05:57:25 --> UTF-8 Support Enabled
INFO - 2024-02-07 05:57:25 --> Utf8 Class Initialized
INFO - 2024-02-07 05:57:25 --> URI Class Initialized
DEBUG - 2024-02-07 05:57:25 --> No URI present. Default controller set.
INFO - 2024-02-07 05:57:25 --> Router Class Initialized
INFO - 2024-02-07 05:57:25 --> Output Class Initialized
INFO - 2024-02-07 05:57:25 --> Security Class Initialized
DEBUG - 2024-02-07 05:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 05:57:25 --> Input Class Initialized
INFO - 2024-02-07 05:57:25 --> Language Class Initialized
INFO - 2024-02-07 05:57:25 --> Loader Class Initialized
INFO - 2024-02-07 05:57:25 --> Helper loaded: url_helper
INFO - 2024-02-07 05:57:25 --> Helper loaded: file_helper
INFO - 2024-02-07 05:57:25 --> Helper loaded: html_helper
INFO - 2024-02-07 05:57:25 --> Helper loaded: text_helper
INFO - 2024-02-07 05:57:25 --> Helper loaded: form_helper
INFO - 2024-02-07 05:57:25 --> Helper loaded: lang_helper
INFO - 2024-02-07 05:57:25 --> Helper loaded: security_helper
INFO - 2024-02-07 05:57:25 --> Helper loaded: cookie_helper
INFO - 2024-02-07 05:57:25 --> Database Driver Class Initialized
INFO - 2024-02-07 05:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 05:57:25 --> Parser Class Initialized
INFO - 2024-02-07 05:57:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 05:57:25 --> Pagination Class Initialized
INFO - 2024-02-07 05:57:25 --> Form Validation Class Initialized
INFO - 2024-02-07 05:57:25 --> Controller Class Initialized
INFO - 2024-02-07 05:57:25 --> Model Class Initialized
DEBUG - 2024-02-07 05:57:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:25 --> Model Class Initialized
DEBUG - 2024-02-07 05:57:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:25 --> Model Class Initialized
INFO - 2024-02-07 05:57:25 --> Model Class Initialized
INFO - 2024-02-07 05:57:25 --> Model Class Initialized
INFO - 2024-02-07 05:57:25 --> Model Class Initialized
DEBUG - 2024-02-07 05:57:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 05:57:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:25 --> Model Class Initialized
INFO - 2024-02-07 05:57:25 --> Model Class Initialized
INFO - 2024-02-07 05:57:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-07 05:57:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 05:57:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 05:57:25 --> Model Class Initialized
INFO - 2024-02-07 05:57:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 05:57:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 05:57:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 05:57:26 --> Final output sent to browser
DEBUG - 2024-02-07 05:57:26 --> Total execution time: 0.4013
ERROR - 2024-02-07 05:57:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 05:57:27 --> Config Class Initialized
INFO - 2024-02-07 05:57:27 --> Hooks Class Initialized
DEBUG - 2024-02-07 05:57:27 --> UTF-8 Support Enabled
INFO - 2024-02-07 05:57:27 --> Utf8 Class Initialized
INFO - 2024-02-07 05:57:27 --> URI Class Initialized
INFO - 2024-02-07 05:57:27 --> Router Class Initialized
INFO - 2024-02-07 05:57:27 --> Output Class Initialized
INFO - 2024-02-07 05:57:27 --> Security Class Initialized
DEBUG - 2024-02-07 05:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 05:57:27 --> Input Class Initialized
INFO - 2024-02-07 05:57:27 --> Language Class Initialized
INFO - 2024-02-07 05:57:27 --> Loader Class Initialized
INFO - 2024-02-07 05:57:27 --> Helper loaded: url_helper
INFO - 2024-02-07 05:57:27 --> Helper loaded: file_helper
INFO - 2024-02-07 05:57:27 --> Helper loaded: html_helper
INFO - 2024-02-07 05:57:27 --> Helper loaded: text_helper
INFO - 2024-02-07 05:57:27 --> Helper loaded: form_helper
INFO - 2024-02-07 05:57:27 --> Helper loaded: lang_helper
INFO - 2024-02-07 05:57:27 --> Helper loaded: security_helper
INFO - 2024-02-07 05:57:27 --> Helper loaded: cookie_helper
INFO - 2024-02-07 05:57:27 --> Database Driver Class Initialized
INFO - 2024-02-07 05:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 05:57:27 --> Parser Class Initialized
INFO - 2024-02-07 05:57:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 05:57:27 --> Pagination Class Initialized
INFO - 2024-02-07 05:57:27 --> Form Validation Class Initialized
INFO - 2024-02-07 05:57:27 --> Controller Class Initialized
DEBUG - 2024-02-07 05:57:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 05:57:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:27 --> Model Class Initialized
INFO - 2024-02-07 05:57:27 --> Final output sent to browser
DEBUG - 2024-02-07 05:57:27 --> Total execution time: 0.0134
ERROR - 2024-02-07 05:57:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 05:57:36 --> Config Class Initialized
INFO - 2024-02-07 05:57:36 --> Hooks Class Initialized
DEBUG - 2024-02-07 05:57:36 --> UTF-8 Support Enabled
INFO - 2024-02-07 05:57:36 --> Utf8 Class Initialized
INFO - 2024-02-07 05:57:36 --> URI Class Initialized
INFO - 2024-02-07 05:57:36 --> Router Class Initialized
INFO - 2024-02-07 05:57:36 --> Output Class Initialized
INFO - 2024-02-07 05:57:36 --> Security Class Initialized
DEBUG - 2024-02-07 05:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 05:57:36 --> Input Class Initialized
INFO - 2024-02-07 05:57:36 --> Language Class Initialized
INFO - 2024-02-07 05:57:36 --> Loader Class Initialized
INFO - 2024-02-07 05:57:36 --> Helper loaded: url_helper
INFO - 2024-02-07 05:57:36 --> Helper loaded: file_helper
INFO - 2024-02-07 05:57:36 --> Helper loaded: html_helper
INFO - 2024-02-07 05:57:36 --> Helper loaded: text_helper
INFO - 2024-02-07 05:57:36 --> Helper loaded: form_helper
INFO - 2024-02-07 05:57:36 --> Helper loaded: lang_helper
INFO - 2024-02-07 05:57:36 --> Helper loaded: security_helper
INFO - 2024-02-07 05:57:36 --> Helper loaded: cookie_helper
INFO - 2024-02-07 05:57:36 --> Database Driver Class Initialized
INFO - 2024-02-07 05:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 05:57:36 --> Parser Class Initialized
INFO - 2024-02-07 05:57:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 05:57:36 --> Pagination Class Initialized
INFO - 2024-02-07 05:57:36 --> Form Validation Class Initialized
INFO - 2024-02-07 05:57:36 --> Controller Class Initialized
DEBUG - 2024-02-07 05:57:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 05:57:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:36 --> Model Class Initialized
DEBUG - 2024-02-07 05:57:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:36 --> Model Class Initialized
DEBUG - 2024-02-07 05:57:36 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:36 --> Model Class Initialized
INFO - 2024-02-07 05:57:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-07 05:57:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 05:57:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 05:57:36 --> Model Class Initialized
INFO - 2024-02-07 05:57:36 --> Model Class Initialized
INFO - 2024-02-07 05:57:36 --> Model Class Initialized
INFO - 2024-02-07 05:57:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 05:57:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 05:57:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 05:57:36 --> Final output sent to browser
DEBUG - 2024-02-07 05:57:36 --> Total execution time: 0.4370
ERROR - 2024-02-07 05:57:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 05:57:38 --> Config Class Initialized
INFO - 2024-02-07 05:57:38 --> Hooks Class Initialized
DEBUG - 2024-02-07 05:57:38 --> UTF-8 Support Enabled
INFO - 2024-02-07 05:57:38 --> Utf8 Class Initialized
INFO - 2024-02-07 05:57:38 --> URI Class Initialized
INFO - 2024-02-07 05:57:38 --> Router Class Initialized
INFO - 2024-02-07 05:57:38 --> Output Class Initialized
INFO - 2024-02-07 05:57:38 --> Security Class Initialized
DEBUG - 2024-02-07 05:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 05:57:38 --> Input Class Initialized
INFO - 2024-02-07 05:57:38 --> Language Class Initialized
INFO - 2024-02-07 05:57:38 --> Loader Class Initialized
INFO - 2024-02-07 05:57:38 --> Helper loaded: url_helper
INFO - 2024-02-07 05:57:38 --> Helper loaded: file_helper
INFO - 2024-02-07 05:57:38 --> Helper loaded: html_helper
INFO - 2024-02-07 05:57:38 --> Helper loaded: text_helper
INFO - 2024-02-07 05:57:38 --> Helper loaded: form_helper
INFO - 2024-02-07 05:57:38 --> Helper loaded: lang_helper
INFO - 2024-02-07 05:57:38 --> Helper loaded: security_helper
INFO - 2024-02-07 05:57:38 --> Helper loaded: cookie_helper
INFO - 2024-02-07 05:57:38 --> Database Driver Class Initialized
INFO - 2024-02-07 05:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 05:57:38 --> Parser Class Initialized
INFO - 2024-02-07 05:57:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 05:57:38 --> Pagination Class Initialized
INFO - 2024-02-07 05:57:38 --> Form Validation Class Initialized
INFO - 2024-02-07 05:57:38 --> Controller Class Initialized
DEBUG - 2024-02-07 05:57:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 05:57:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:38 --> Model Class Initialized
DEBUG - 2024-02-07 05:57:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:38 --> Model Class Initialized
INFO - 2024-02-07 05:57:38 --> Final output sent to browser
DEBUG - 2024-02-07 05:57:38 --> Total execution time: 0.0316
ERROR - 2024-02-07 05:57:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 05:57:41 --> Config Class Initialized
INFO - 2024-02-07 05:57:41 --> Hooks Class Initialized
DEBUG - 2024-02-07 05:57:41 --> UTF-8 Support Enabled
INFO - 2024-02-07 05:57:41 --> Utf8 Class Initialized
INFO - 2024-02-07 05:57:41 --> URI Class Initialized
INFO - 2024-02-07 05:57:41 --> Router Class Initialized
INFO - 2024-02-07 05:57:41 --> Output Class Initialized
INFO - 2024-02-07 05:57:41 --> Security Class Initialized
DEBUG - 2024-02-07 05:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 05:57:41 --> Input Class Initialized
INFO - 2024-02-07 05:57:41 --> Language Class Initialized
INFO - 2024-02-07 05:57:41 --> Loader Class Initialized
INFO - 2024-02-07 05:57:41 --> Helper loaded: url_helper
INFO - 2024-02-07 05:57:41 --> Helper loaded: file_helper
INFO - 2024-02-07 05:57:41 --> Helper loaded: html_helper
INFO - 2024-02-07 05:57:41 --> Helper loaded: text_helper
INFO - 2024-02-07 05:57:41 --> Helper loaded: form_helper
INFO - 2024-02-07 05:57:41 --> Helper loaded: lang_helper
INFO - 2024-02-07 05:57:41 --> Helper loaded: security_helper
INFO - 2024-02-07 05:57:41 --> Helper loaded: cookie_helper
INFO - 2024-02-07 05:57:41 --> Database Driver Class Initialized
INFO - 2024-02-07 05:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 05:57:41 --> Parser Class Initialized
INFO - 2024-02-07 05:57:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 05:57:41 --> Pagination Class Initialized
INFO - 2024-02-07 05:57:41 --> Form Validation Class Initialized
INFO - 2024-02-07 05:57:41 --> Controller Class Initialized
DEBUG - 2024-02-07 05:57:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 05:57:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:41 --> Model Class Initialized
DEBUG - 2024-02-07 05:57:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:41 --> Model Class Initialized
INFO - 2024-02-07 05:57:41 --> Final output sent to browser
DEBUG - 2024-02-07 05:57:41 --> Total execution time: 0.0314
ERROR - 2024-02-07 05:57:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 05:57:42 --> Config Class Initialized
INFO - 2024-02-07 05:57:42 --> Hooks Class Initialized
DEBUG - 2024-02-07 05:57:42 --> UTF-8 Support Enabled
INFO - 2024-02-07 05:57:42 --> Utf8 Class Initialized
INFO - 2024-02-07 05:57:42 --> URI Class Initialized
INFO - 2024-02-07 05:57:42 --> Router Class Initialized
INFO - 2024-02-07 05:57:42 --> Output Class Initialized
INFO - 2024-02-07 05:57:42 --> Security Class Initialized
DEBUG - 2024-02-07 05:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 05:57:42 --> Input Class Initialized
INFO - 2024-02-07 05:57:42 --> Language Class Initialized
INFO - 2024-02-07 05:57:42 --> Loader Class Initialized
INFO - 2024-02-07 05:57:42 --> Helper loaded: url_helper
INFO - 2024-02-07 05:57:42 --> Helper loaded: file_helper
INFO - 2024-02-07 05:57:42 --> Helper loaded: html_helper
INFO - 2024-02-07 05:57:42 --> Helper loaded: text_helper
INFO - 2024-02-07 05:57:42 --> Helper loaded: form_helper
INFO - 2024-02-07 05:57:42 --> Helper loaded: lang_helper
INFO - 2024-02-07 05:57:42 --> Helper loaded: security_helper
INFO - 2024-02-07 05:57:42 --> Helper loaded: cookie_helper
INFO - 2024-02-07 05:57:42 --> Database Driver Class Initialized
INFO - 2024-02-07 05:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 05:57:42 --> Parser Class Initialized
INFO - 2024-02-07 05:57:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 05:57:42 --> Pagination Class Initialized
INFO - 2024-02-07 05:57:42 --> Form Validation Class Initialized
INFO - 2024-02-07 05:57:42 --> Controller Class Initialized
DEBUG - 2024-02-07 05:57:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 05:57:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:42 --> Model Class Initialized
DEBUG - 2024-02-07 05:57:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:42 --> Model Class Initialized
INFO - 2024-02-07 05:57:42 --> Final output sent to browser
DEBUG - 2024-02-07 05:57:42 --> Total execution time: 0.0335
ERROR - 2024-02-07 05:57:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 05:57:42 --> Config Class Initialized
INFO - 2024-02-07 05:57:42 --> Hooks Class Initialized
DEBUG - 2024-02-07 05:57:42 --> UTF-8 Support Enabled
INFO - 2024-02-07 05:57:42 --> Utf8 Class Initialized
INFO - 2024-02-07 05:57:42 --> URI Class Initialized
INFO - 2024-02-07 05:57:42 --> Router Class Initialized
INFO - 2024-02-07 05:57:42 --> Output Class Initialized
INFO - 2024-02-07 05:57:42 --> Security Class Initialized
DEBUG - 2024-02-07 05:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 05:57:42 --> Input Class Initialized
INFO - 2024-02-07 05:57:42 --> Language Class Initialized
INFO - 2024-02-07 05:57:42 --> Loader Class Initialized
INFO - 2024-02-07 05:57:42 --> Helper loaded: url_helper
INFO - 2024-02-07 05:57:42 --> Helper loaded: file_helper
INFO - 2024-02-07 05:57:42 --> Helper loaded: html_helper
INFO - 2024-02-07 05:57:42 --> Helper loaded: text_helper
INFO - 2024-02-07 05:57:42 --> Helper loaded: form_helper
INFO - 2024-02-07 05:57:42 --> Helper loaded: lang_helper
INFO - 2024-02-07 05:57:42 --> Helper loaded: security_helper
INFO - 2024-02-07 05:57:42 --> Helper loaded: cookie_helper
INFO - 2024-02-07 05:57:42 --> Database Driver Class Initialized
INFO - 2024-02-07 05:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 05:57:42 --> Parser Class Initialized
INFO - 2024-02-07 05:57:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 05:57:42 --> Pagination Class Initialized
INFO - 2024-02-07 05:57:42 --> Form Validation Class Initialized
INFO - 2024-02-07 05:57:42 --> Controller Class Initialized
DEBUG - 2024-02-07 05:57:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 05:57:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:42 --> Model Class Initialized
DEBUG - 2024-02-07 05:57:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:42 --> Model Class Initialized
INFO - 2024-02-07 05:57:42 --> Final output sent to browser
DEBUG - 2024-02-07 05:57:42 --> Total execution time: 0.0236
ERROR - 2024-02-07 05:57:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 05:57:43 --> Config Class Initialized
INFO - 2024-02-07 05:57:43 --> Hooks Class Initialized
DEBUG - 2024-02-07 05:57:43 --> UTF-8 Support Enabled
INFO - 2024-02-07 05:57:43 --> Utf8 Class Initialized
INFO - 2024-02-07 05:57:43 --> URI Class Initialized
INFO - 2024-02-07 05:57:43 --> Router Class Initialized
INFO - 2024-02-07 05:57:43 --> Output Class Initialized
INFO - 2024-02-07 05:57:43 --> Security Class Initialized
DEBUG - 2024-02-07 05:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 05:57:43 --> Input Class Initialized
INFO - 2024-02-07 05:57:43 --> Language Class Initialized
INFO - 2024-02-07 05:57:43 --> Loader Class Initialized
INFO - 2024-02-07 05:57:43 --> Helper loaded: url_helper
INFO - 2024-02-07 05:57:43 --> Helper loaded: file_helper
INFO - 2024-02-07 05:57:43 --> Helper loaded: html_helper
INFO - 2024-02-07 05:57:43 --> Helper loaded: text_helper
INFO - 2024-02-07 05:57:43 --> Helper loaded: form_helper
INFO - 2024-02-07 05:57:43 --> Helper loaded: lang_helper
INFO - 2024-02-07 05:57:43 --> Helper loaded: security_helper
INFO - 2024-02-07 05:57:43 --> Helper loaded: cookie_helper
INFO - 2024-02-07 05:57:43 --> Database Driver Class Initialized
INFO - 2024-02-07 05:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 05:57:43 --> Parser Class Initialized
INFO - 2024-02-07 05:57:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 05:57:43 --> Pagination Class Initialized
INFO - 2024-02-07 05:57:43 --> Form Validation Class Initialized
INFO - 2024-02-07 05:57:43 --> Controller Class Initialized
DEBUG - 2024-02-07 05:57:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 05:57:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:43 --> Model Class Initialized
DEBUG - 2024-02-07 05:57:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:43 --> Model Class Initialized
INFO - 2024-02-07 05:57:43 --> Final output sent to browser
DEBUG - 2024-02-07 05:57:43 --> Total execution time: 0.0182
ERROR - 2024-02-07 05:57:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 05:57:43 --> Config Class Initialized
INFO - 2024-02-07 05:57:43 --> Hooks Class Initialized
DEBUG - 2024-02-07 05:57:43 --> UTF-8 Support Enabled
INFO - 2024-02-07 05:57:43 --> Utf8 Class Initialized
INFO - 2024-02-07 05:57:43 --> URI Class Initialized
INFO - 2024-02-07 05:57:43 --> Router Class Initialized
INFO - 2024-02-07 05:57:43 --> Output Class Initialized
INFO - 2024-02-07 05:57:43 --> Security Class Initialized
DEBUG - 2024-02-07 05:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 05:57:43 --> Input Class Initialized
INFO - 2024-02-07 05:57:43 --> Language Class Initialized
INFO - 2024-02-07 05:57:43 --> Loader Class Initialized
INFO - 2024-02-07 05:57:43 --> Helper loaded: url_helper
INFO - 2024-02-07 05:57:43 --> Helper loaded: file_helper
INFO - 2024-02-07 05:57:43 --> Helper loaded: html_helper
INFO - 2024-02-07 05:57:43 --> Helper loaded: text_helper
INFO - 2024-02-07 05:57:43 --> Helper loaded: form_helper
INFO - 2024-02-07 05:57:43 --> Helper loaded: lang_helper
INFO - 2024-02-07 05:57:43 --> Helper loaded: security_helper
INFO - 2024-02-07 05:57:43 --> Helper loaded: cookie_helper
INFO - 2024-02-07 05:57:43 --> Database Driver Class Initialized
INFO - 2024-02-07 05:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 05:57:43 --> Parser Class Initialized
INFO - 2024-02-07 05:57:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 05:57:43 --> Pagination Class Initialized
INFO - 2024-02-07 05:57:43 --> Form Validation Class Initialized
INFO - 2024-02-07 05:57:43 --> Controller Class Initialized
DEBUG - 2024-02-07 05:57:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 05:57:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:43 --> Model Class Initialized
DEBUG - 2024-02-07 05:57:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:43 --> Model Class Initialized
INFO - 2024-02-07 05:57:43 --> Final output sent to browser
DEBUG - 2024-02-07 05:57:43 --> Total execution time: 0.0180
ERROR - 2024-02-07 05:57:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 05:57:44 --> Config Class Initialized
INFO - 2024-02-07 05:57:44 --> Hooks Class Initialized
DEBUG - 2024-02-07 05:57:44 --> UTF-8 Support Enabled
INFO - 2024-02-07 05:57:44 --> Utf8 Class Initialized
INFO - 2024-02-07 05:57:44 --> URI Class Initialized
INFO - 2024-02-07 05:57:44 --> Router Class Initialized
INFO - 2024-02-07 05:57:44 --> Output Class Initialized
INFO - 2024-02-07 05:57:44 --> Security Class Initialized
DEBUG - 2024-02-07 05:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 05:57:44 --> Input Class Initialized
INFO - 2024-02-07 05:57:44 --> Language Class Initialized
INFO - 2024-02-07 05:57:44 --> Loader Class Initialized
INFO - 2024-02-07 05:57:44 --> Helper loaded: url_helper
INFO - 2024-02-07 05:57:44 --> Helper loaded: file_helper
INFO - 2024-02-07 05:57:44 --> Helper loaded: html_helper
INFO - 2024-02-07 05:57:44 --> Helper loaded: text_helper
INFO - 2024-02-07 05:57:44 --> Helper loaded: form_helper
INFO - 2024-02-07 05:57:44 --> Helper loaded: lang_helper
INFO - 2024-02-07 05:57:44 --> Helper loaded: security_helper
INFO - 2024-02-07 05:57:44 --> Helper loaded: cookie_helper
INFO - 2024-02-07 05:57:44 --> Database Driver Class Initialized
INFO - 2024-02-07 05:57:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 05:57:44 --> Parser Class Initialized
INFO - 2024-02-07 05:57:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 05:57:44 --> Pagination Class Initialized
INFO - 2024-02-07 05:57:44 --> Form Validation Class Initialized
INFO - 2024-02-07 05:57:44 --> Controller Class Initialized
DEBUG - 2024-02-07 05:57:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 05:57:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:44 --> Model Class Initialized
DEBUG - 2024-02-07 05:57:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:44 --> Model Class Initialized
INFO - 2024-02-07 05:57:44 --> Final output sent to browser
DEBUG - 2024-02-07 05:57:44 --> Total execution time: 0.0184
ERROR - 2024-02-07 05:57:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 05:57:45 --> Config Class Initialized
INFO - 2024-02-07 05:57:45 --> Hooks Class Initialized
DEBUG - 2024-02-07 05:57:45 --> UTF-8 Support Enabled
INFO - 2024-02-07 05:57:45 --> Utf8 Class Initialized
INFO - 2024-02-07 05:57:45 --> URI Class Initialized
INFO - 2024-02-07 05:57:45 --> Router Class Initialized
INFO - 2024-02-07 05:57:45 --> Output Class Initialized
INFO - 2024-02-07 05:57:45 --> Security Class Initialized
DEBUG - 2024-02-07 05:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 05:57:45 --> Input Class Initialized
INFO - 2024-02-07 05:57:45 --> Language Class Initialized
INFO - 2024-02-07 05:57:45 --> Loader Class Initialized
INFO - 2024-02-07 05:57:45 --> Helper loaded: url_helper
INFO - 2024-02-07 05:57:45 --> Helper loaded: file_helper
INFO - 2024-02-07 05:57:45 --> Helper loaded: html_helper
INFO - 2024-02-07 05:57:45 --> Helper loaded: text_helper
INFO - 2024-02-07 05:57:45 --> Helper loaded: form_helper
INFO - 2024-02-07 05:57:45 --> Helper loaded: lang_helper
INFO - 2024-02-07 05:57:45 --> Helper loaded: security_helper
INFO - 2024-02-07 05:57:45 --> Helper loaded: cookie_helper
INFO - 2024-02-07 05:57:45 --> Database Driver Class Initialized
INFO - 2024-02-07 05:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 05:57:45 --> Parser Class Initialized
INFO - 2024-02-07 05:57:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 05:57:45 --> Pagination Class Initialized
INFO - 2024-02-07 05:57:45 --> Form Validation Class Initialized
INFO - 2024-02-07 05:57:45 --> Controller Class Initialized
DEBUG - 2024-02-07 05:57:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 05:57:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:45 --> Model Class Initialized
DEBUG - 2024-02-07 05:57:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:45 --> Model Class Initialized
INFO - 2024-02-07 05:57:45 --> Final output sent to browser
DEBUG - 2024-02-07 05:57:45 --> Total execution time: 0.0163
ERROR - 2024-02-07 05:57:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 05:57:46 --> Config Class Initialized
INFO - 2024-02-07 05:57:46 --> Hooks Class Initialized
DEBUG - 2024-02-07 05:57:46 --> UTF-8 Support Enabled
INFO - 2024-02-07 05:57:46 --> Utf8 Class Initialized
INFO - 2024-02-07 05:57:46 --> URI Class Initialized
INFO - 2024-02-07 05:57:46 --> Router Class Initialized
INFO - 2024-02-07 05:57:46 --> Output Class Initialized
INFO - 2024-02-07 05:57:46 --> Security Class Initialized
DEBUG - 2024-02-07 05:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 05:57:46 --> Input Class Initialized
INFO - 2024-02-07 05:57:46 --> Language Class Initialized
INFO - 2024-02-07 05:57:46 --> Loader Class Initialized
INFO - 2024-02-07 05:57:46 --> Helper loaded: url_helper
INFO - 2024-02-07 05:57:46 --> Helper loaded: file_helper
INFO - 2024-02-07 05:57:46 --> Helper loaded: html_helper
INFO - 2024-02-07 05:57:46 --> Helper loaded: text_helper
INFO - 2024-02-07 05:57:46 --> Helper loaded: form_helper
INFO - 2024-02-07 05:57:46 --> Helper loaded: lang_helper
INFO - 2024-02-07 05:57:46 --> Helper loaded: security_helper
INFO - 2024-02-07 05:57:46 --> Helper loaded: cookie_helper
INFO - 2024-02-07 05:57:46 --> Database Driver Class Initialized
INFO - 2024-02-07 05:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 05:57:46 --> Parser Class Initialized
INFO - 2024-02-07 05:57:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 05:57:46 --> Pagination Class Initialized
INFO - 2024-02-07 05:57:46 --> Form Validation Class Initialized
INFO - 2024-02-07 05:57:46 --> Controller Class Initialized
DEBUG - 2024-02-07 05:57:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 05:57:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:46 --> Model Class Initialized
DEBUG - 2024-02-07 05:57:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:46 --> Model Class Initialized
INFO - 2024-02-07 05:57:46 --> Final output sent to browser
DEBUG - 2024-02-07 05:57:46 --> Total execution time: 0.0218
ERROR - 2024-02-07 05:57:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 05:57:47 --> Config Class Initialized
INFO - 2024-02-07 05:57:47 --> Hooks Class Initialized
DEBUG - 2024-02-07 05:57:47 --> UTF-8 Support Enabled
INFO - 2024-02-07 05:57:47 --> Utf8 Class Initialized
INFO - 2024-02-07 05:57:47 --> URI Class Initialized
INFO - 2024-02-07 05:57:47 --> Router Class Initialized
INFO - 2024-02-07 05:57:47 --> Output Class Initialized
INFO - 2024-02-07 05:57:47 --> Security Class Initialized
DEBUG - 2024-02-07 05:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 05:57:47 --> Input Class Initialized
INFO - 2024-02-07 05:57:47 --> Language Class Initialized
INFO - 2024-02-07 05:57:47 --> Loader Class Initialized
INFO - 2024-02-07 05:57:47 --> Helper loaded: url_helper
INFO - 2024-02-07 05:57:47 --> Helper loaded: file_helper
INFO - 2024-02-07 05:57:47 --> Helper loaded: html_helper
INFO - 2024-02-07 05:57:47 --> Helper loaded: text_helper
INFO - 2024-02-07 05:57:47 --> Helper loaded: form_helper
INFO - 2024-02-07 05:57:47 --> Helper loaded: lang_helper
INFO - 2024-02-07 05:57:47 --> Helper loaded: security_helper
INFO - 2024-02-07 05:57:47 --> Helper loaded: cookie_helper
INFO - 2024-02-07 05:57:47 --> Database Driver Class Initialized
INFO - 2024-02-07 05:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 05:57:47 --> Parser Class Initialized
INFO - 2024-02-07 05:57:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 05:57:47 --> Pagination Class Initialized
INFO - 2024-02-07 05:57:47 --> Form Validation Class Initialized
INFO - 2024-02-07 05:57:47 --> Controller Class Initialized
DEBUG - 2024-02-07 05:57:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 05:57:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:47 --> Model Class Initialized
DEBUG - 2024-02-07 05:57:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:47 --> Model Class Initialized
INFO - 2024-02-07 05:57:47 --> Final output sent to browser
DEBUG - 2024-02-07 05:57:47 --> Total execution time: 0.0217
ERROR - 2024-02-07 05:57:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 05:57:47 --> Config Class Initialized
INFO - 2024-02-07 05:57:47 --> Hooks Class Initialized
DEBUG - 2024-02-07 05:57:47 --> UTF-8 Support Enabled
INFO - 2024-02-07 05:57:47 --> Utf8 Class Initialized
INFO - 2024-02-07 05:57:47 --> URI Class Initialized
INFO - 2024-02-07 05:57:47 --> Router Class Initialized
INFO - 2024-02-07 05:57:47 --> Output Class Initialized
INFO - 2024-02-07 05:57:47 --> Security Class Initialized
DEBUG - 2024-02-07 05:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 05:57:47 --> Input Class Initialized
INFO - 2024-02-07 05:57:47 --> Language Class Initialized
INFO - 2024-02-07 05:57:47 --> Loader Class Initialized
INFO - 2024-02-07 05:57:47 --> Helper loaded: url_helper
INFO - 2024-02-07 05:57:47 --> Helper loaded: file_helper
INFO - 2024-02-07 05:57:47 --> Helper loaded: html_helper
INFO - 2024-02-07 05:57:47 --> Helper loaded: text_helper
INFO - 2024-02-07 05:57:47 --> Helper loaded: form_helper
INFO - 2024-02-07 05:57:47 --> Helper loaded: lang_helper
INFO - 2024-02-07 05:57:47 --> Helper loaded: security_helper
INFO - 2024-02-07 05:57:47 --> Helper loaded: cookie_helper
INFO - 2024-02-07 05:57:47 --> Database Driver Class Initialized
INFO - 2024-02-07 05:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 05:57:47 --> Parser Class Initialized
INFO - 2024-02-07 05:57:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 05:57:47 --> Pagination Class Initialized
INFO - 2024-02-07 05:57:47 --> Form Validation Class Initialized
INFO - 2024-02-07 05:57:47 --> Controller Class Initialized
DEBUG - 2024-02-07 05:57:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 05:57:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:47 --> Model Class Initialized
DEBUG - 2024-02-07 05:57:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:47 --> Model Class Initialized
INFO - 2024-02-07 05:57:47 --> Final output sent to browser
DEBUG - 2024-02-07 05:57:47 --> Total execution time: 0.0298
ERROR - 2024-02-07 05:57:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 05:57:48 --> Config Class Initialized
INFO - 2024-02-07 05:57:48 --> Hooks Class Initialized
DEBUG - 2024-02-07 05:57:48 --> UTF-8 Support Enabled
INFO - 2024-02-07 05:57:48 --> Utf8 Class Initialized
INFO - 2024-02-07 05:57:48 --> URI Class Initialized
INFO - 2024-02-07 05:57:48 --> Router Class Initialized
INFO - 2024-02-07 05:57:48 --> Output Class Initialized
INFO - 2024-02-07 05:57:48 --> Security Class Initialized
DEBUG - 2024-02-07 05:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 05:57:48 --> Input Class Initialized
INFO - 2024-02-07 05:57:48 --> Language Class Initialized
INFO - 2024-02-07 05:57:48 --> Loader Class Initialized
INFO - 2024-02-07 05:57:48 --> Helper loaded: url_helper
INFO - 2024-02-07 05:57:48 --> Helper loaded: file_helper
INFO - 2024-02-07 05:57:48 --> Helper loaded: html_helper
INFO - 2024-02-07 05:57:48 --> Helper loaded: text_helper
INFO - 2024-02-07 05:57:48 --> Helper loaded: form_helper
INFO - 2024-02-07 05:57:48 --> Helper loaded: lang_helper
INFO - 2024-02-07 05:57:48 --> Helper loaded: security_helper
INFO - 2024-02-07 05:57:48 --> Helper loaded: cookie_helper
INFO - 2024-02-07 05:57:48 --> Database Driver Class Initialized
INFO - 2024-02-07 05:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 05:57:48 --> Parser Class Initialized
INFO - 2024-02-07 05:57:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 05:57:48 --> Pagination Class Initialized
INFO - 2024-02-07 05:57:48 --> Form Validation Class Initialized
INFO - 2024-02-07 05:57:48 --> Controller Class Initialized
DEBUG - 2024-02-07 05:57:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 05:57:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:48 --> Model Class Initialized
DEBUG - 2024-02-07 05:57:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:48 --> Model Class Initialized
INFO - 2024-02-07 05:57:48 --> Final output sent to browser
DEBUG - 2024-02-07 05:57:48 --> Total execution time: 0.0303
ERROR - 2024-02-07 05:57:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 05:57:48 --> Config Class Initialized
INFO - 2024-02-07 05:57:48 --> Hooks Class Initialized
DEBUG - 2024-02-07 05:57:48 --> UTF-8 Support Enabled
INFO - 2024-02-07 05:57:48 --> Utf8 Class Initialized
INFO - 2024-02-07 05:57:48 --> URI Class Initialized
INFO - 2024-02-07 05:57:48 --> Router Class Initialized
INFO - 2024-02-07 05:57:48 --> Output Class Initialized
INFO - 2024-02-07 05:57:48 --> Security Class Initialized
DEBUG - 2024-02-07 05:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 05:57:48 --> Input Class Initialized
INFO - 2024-02-07 05:57:48 --> Language Class Initialized
INFO - 2024-02-07 05:57:48 --> Loader Class Initialized
INFO - 2024-02-07 05:57:48 --> Helper loaded: url_helper
INFO - 2024-02-07 05:57:48 --> Helper loaded: file_helper
INFO - 2024-02-07 05:57:48 --> Helper loaded: html_helper
INFO - 2024-02-07 05:57:48 --> Helper loaded: text_helper
INFO - 2024-02-07 05:57:48 --> Helper loaded: form_helper
INFO - 2024-02-07 05:57:48 --> Helper loaded: lang_helper
INFO - 2024-02-07 05:57:48 --> Helper loaded: security_helper
INFO - 2024-02-07 05:57:48 --> Helper loaded: cookie_helper
INFO - 2024-02-07 05:57:48 --> Database Driver Class Initialized
INFO - 2024-02-07 05:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 05:57:48 --> Parser Class Initialized
INFO - 2024-02-07 05:57:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 05:57:48 --> Pagination Class Initialized
INFO - 2024-02-07 05:57:48 --> Form Validation Class Initialized
INFO - 2024-02-07 05:57:48 --> Controller Class Initialized
DEBUG - 2024-02-07 05:57:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 05:57:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:48 --> Model Class Initialized
DEBUG - 2024-02-07 05:57:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:48 --> Model Class Initialized
INFO - 2024-02-07 05:57:48 --> Final output sent to browser
DEBUG - 2024-02-07 05:57:48 --> Total execution time: 0.0303
ERROR - 2024-02-07 05:57:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 05:57:49 --> Config Class Initialized
INFO - 2024-02-07 05:57:49 --> Hooks Class Initialized
DEBUG - 2024-02-07 05:57:49 --> UTF-8 Support Enabled
INFO - 2024-02-07 05:57:49 --> Utf8 Class Initialized
INFO - 2024-02-07 05:57:49 --> URI Class Initialized
INFO - 2024-02-07 05:57:49 --> Router Class Initialized
INFO - 2024-02-07 05:57:49 --> Output Class Initialized
INFO - 2024-02-07 05:57:49 --> Security Class Initialized
DEBUG - 2024-02-07 05:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 05:57:49 --> Input Class Initialized
INFO - 2024-02-07 05:57:49 --> Language Class Initialized
INFO - 2024-02-07 05:57:49 --> Loader Class Initialized
INFO - 2024-02-07 05:57:49 --> Helper loaded: url_helper
INFO - 2024-02-07 05:57:49 --> Helper loaded: file_helper
INFO - 2024-02-07 05:57:49 --> Helper loaded: html_helper
INFO - 2024-02-07 05:57:49 --> Helper loaded: text_helper
INFO - 2024-02-07 05:57:49 --> Helper loaded: form_helper
INFO - 2024-02-07 05:57:49 --> Helper loaded: lang_helper
INFO - 2024-02-07 05:57:49 --> Helper loaded: security_helper
INFO - 2024-02-07 05:57:49 --> Helper loaded: cookie_helper
INFO - 2024-02-07 05:57:49 --> Database Driver Class Initialized
INFO - 2024-02-07 05:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 05:57:49 --> Parser Class Initialized
INFO - 2024-02-07 05:57:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 05:57:49 --> Pagination Class Initialized
INFO - 2024-02-07 05:57:49 --> Form Validation Class Initialized
INFO - 2024-02-07 05:57:49 --> Controller Class Initialized
DEBUG - 2024-02-07 05:57:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 05:57:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:49 --> Model Class Initialized
DEBUG - 2024-02-07 05:57:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:49 --> Model Class Initialized
INFO - 2024-02-07 05:57:49 --> Final output sent to browser
DEBUG - 2024-02-07 05:57:49 --> Total execution time: 0.0306
ERROR - 2024-02-07 05:57:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 05:57:49 --> Config Class Initialized
INFO - 2024-02-07 05:57:49 --> Hooks Class Initialized
DEBUG - 2024-02-07 05:57:49 --> UTF-8 Support Enabled
INFO - 2024-02-07 05:57:49 --> Utf8 Class Initialized
INFO - 2024-02-07 05:57:49 --> URI Class Initialized
INFO - 2024-02-07 05:57:49 --> Router Class Initialized
INFO - 2024-02-07 05:57:49 --> Output Class Initialized
INFO - 2024-02-07 05:57:49 --> Security Class Initialized
DEBUG - 2024-02-07 05:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 05:57:49 --> Input Class Initialized
INFO - 2024-02-07 05:57:49 --> Language Class Initialized
INFO - 2024-02-07 05:57:49 --> Loader Class Initialized
INFO - 2024-02-07 05:57:49 --> Helper loaded: url_helper
INFO - 2024-02-07 05:57:49 --> Helper loaded: file_helper
INFO - 2024-02-07 05:57:49 --> Helper loaded: html_helper
INFO - 2024-02-07 05:57:49 --> Helper loaded: text_helper
INFO - 2024-02-07 05:57:49 --> Helper loaded: form_helper
INFO - 2024-02-07 05:57:49 --> Helper loaded: lang_helper
INFO - 2024-02-07 05:57:49 --> Helper loaded: security_helper
INFO - 2024-02-07 05:57:49 --> Helper loaded: cookie_helper
INFO - 2024-02-07 05:57:49 --> Database Driver Class Initialized
INFO - 2024-02-07 05:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 05:57:49 --> Parser Class Initialized
INFO - 2024-02-07 05:57:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 05:57:49 --> Pagination Class Initialized
INFO - 2024-02-07 05:57:49 --> Form Validation Class Initialized
INFO - 2024-02-07 05:57:49 --> Controller Class Initialized
DEBUG - 2024-02-07 05:57:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 05:57:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:49 --> Model Class Initialized
DEBUG - 2024-02-07 05:57:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:49 --> Model Class Initialized
INFO - 2024-02-07 05:57:49 --> Final output sent to browser
DEBUG - 2024-02-07 05:57:49 --> Total execution time: 0.0318
ERROR - 2024-02-07 05:57:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 05:57:50 --> Config Class Initialized
INFO - 2024-02-07 05:57:50 --> Hooks Class Initialized
DEBUG - 2024-02-07 05:57:50 --> UTF-8 Support Enabled
INFO - 2024-02-07 05:57:50 --> Utf8 Class Initialized
INFO - 2024-02-07 05:57:50 --> URI Class Initialized
INFO - 2024-02-07 05:57:50 --> Router Class Initialized
INFO - 2024-02-07 05:57:50 --> Output Class Initialized
INFO - 2024-02-07 05:57:50 --> Security Class Initialized
DEBUG - 2024-02-07 05:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 05:57:50 --> Input Class Initialized
INFO - 2024-02-07 05:57:50 --> Language Class Initialized
INFO - 2024-02-07 05:57:50 --> Loader Class Initialized
INFO - 2024-02-07 05:57:50 --> Helper loaded: url_helper
INFO - 2024-02-07 05:57:50 --> Helper loaded: file_helper
INFO - 2024-02-07 05:57:50 --> Helper loaded: html_helper
INFO - 2024-02-07 05:57:50 --> Helper loaded: text_helper
INFO - 2024-02-07 05:57:50 --> Helper loaded: form_helper
INFO - 2024-02-07 05:57:50 --> Helper loaded: lang_helper
INFO - 2024-02-07 05:57:50 --> Helper loaded: security_helper
INFO - 2024-02-07 05:57:50 --> Helper loaded: cookie_helper
INFO - 2024-02-07 05:57:50 --> Database Driver Class Initialized
INFO - 2024-02-07 05:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 05:57:50 --> Parser Class Initialized
INFO - 2024-02-07 05:57:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 05:57:50 --> Pagination Class Initialized
INFO - 2024-02-07 05:57:50 --> Form Validation Class Initialized
INFO - 2024-02-07 05:57:50 --> Controller Class Initialized
DEBUG - 2024-02-07 05:57:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 05:57:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:50 --> Model Class Initialized
DEBUG - 2024-02-07 05:57:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:50 --> Model Class Initialized
INFO - 2024-02-07 05:57:50 --> Final output sent to browser
DEBUG - 2024-02-07 05:57:50 --> Total execution time: 0.0217
ERROR - 2024-02-07 05:57:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 05:57:52 --> Config Class Initialized
INFO - 2024-02-07 05:57:52 --> Hooks Class Initialized
DEBUG - 2024-02-07 05:57:52 --> UTF-8 Support Enabled
INFO - 2024-02-07 05:57:52 --> Utf8 Class Initialized
INFO - 2024-02-07 05:57:52 --> URI Class Initialized
INFO - 2024-02-07 05:57:52 --> Router Class Initialized
INFO - 2024-02-07 05:57:52 --> Output Class Initialized
INFO - 2024-02-07 05:57:52 --> Security Class Initialized
DEBUG - 2024-02-07 05:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 05:57:52 --> Input Class Initialized
INFO - 2024-02-07 05:57:52 --> Language Class Initialized
INFO - 2024-02-07 05:57:52 --> Loader Class Initialized
INFO - 2024-02-07 05:57:52 --> Helper loaded: url_helper
INFO - 2024-02-07 05:57:52 --> Helper loaded: file_helper
INFO - 2024-02-07 05:57:52 --> Helper loaded: html_helper
INFO - 2024-02-07 05:57:52 --> Helper loaded: text_helper
INFO - 2024-02-07 05:57:52 --> Helper loaded: form_helper
INFO - 2024-02-07 05:57:52 --> Helper loaded: lang_helper
INFO - 2024-02-07 05:57:52 --> Helper loaded: security_helper
INFO - 2024-02-07 05:57:52 --> Helper loaded: cookie_helper
INFO - 2024-02-07 05:57:52 --> Database Driver Class Initialized
INFO - 2024-02-07 05:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 05:57:52 --> Parser Class Initialized
INFO - 2024-02-07 05:57:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 05:57:52 --> Pagination Class Initialized
INFO - 2024-02-07 05:57:52 --> Form Validation Class Initialized
INFO - 2024-02-07 05:57:52 --> Controller Class Initialized
DEBUG - 2024-02-07 05:57:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 05:57:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:52 --> Model Class Initialized
DEBUG - 2024-02-07 05:57:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:52 --> Model Class Initialized
INFO - 2024-02-07 05:57:52 --> Final output sent to browser
DEBUG - 2024-02-07 05:57:52 --> Total execution time: 0.0216
ERROR - 2024-02-07 05:57:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 05:57:56 --> Config Class Initialized
INFO - 2024-02-07 05:57:56 --> Hooks Class Initialized
DEBUG - 2024-02-07 05:57:56 --> UTF-8 Support Enabled
INFO - 2024-02-07 05:57:56 --> Utf8 Class Initialized
INFO - 2024-02-07 05:57:56 --> URI Class Initialized
INFO - 2024-02-07 05:57:56 --> Router Class Initialized
INFO - 2024-02-07 05:57:56 --> Output Class Initialized
INFO - 2024-02-07 05:57:56 --> Security Class Initialized
DEBUG - 2024-02-07 05:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 05:57:56 --> Input Class Initialized
INFO - 2024-02-07 05:57:56 --> Language Class Initialized
INFO - 2024-02-07 05:57:56 --> Loader Class Initialized
INFO - 2024-02-07 05:57:56 --> Helper loaded: url_helper
INFO - 2024-02-07 05:57:56 --> Helper loaded: file_helper
INFO - 2024-02-07 05:57:56 --> Helper loaded: html_helper
INFO - 2024-02-07 05:57:56 --> Helper loaded: text_helper
INFO - 2024-02-07 05:57:56 --> Helper loaded: form_helper
INFO - 2024-02-07 05:57:56 --> Helper loaded: lang_helper
INFO - 2024-02-07 05:57:56 --> Helper loaded: security_helper
INFO - 2024-02-07 05:57:56 --> Helper loaded: cookie_helper
INFO - 2024-02-07 05:57:56 --> Database Driver Class Initialized
INFO - 2024-02-07 05:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 05:57:56 --> Parser Class Initialized
INFO - 2024-02-07 05:57:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 05:57:56 --> Pagination Class Initialized
INFO - 2024-02-07 05:57:56 --> Form Validation Class Initialized
INFO - 2024-02-07 05:57:56 --> Controller Class Initialized
DEBUG - 2024-02-07 05:57:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 05:57:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:56 --> Model Class Initialized
DEBUG - 2024-02-07 05:57:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:56 --> Model Class Initialized
INFO - 2024-02-07 05:57:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/edit_customer_form.php
DEBUG - 2024-02-07 05:57:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 05:57:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 05:57:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 05:57:56 --> Model Class Initialized
INFO - 2024-02-07 05:57:56 --> Model Class Initialized
INFO - 2024-02-07 05:57:56 --> Model Class Initialized
INFO - 2024-02-07 05:57:56 --> Model Class Initialized
INFO - 2024-02-07 05:57:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 05:57:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 05:57:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 05:57:57 --> Final output sent to browser
DEBUG - 2024-02-07 05:57:57 --> Total execution time: 0.2209
ERROR - 2024-02-07 06:06:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:06:22 --> Config Class Initialized
INFO - 2024-02-07 06:06:22 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:06:22 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:06:22 --> Utf8 Class Initialized
INFO - 2024-02-07 06:06:22 --> URI Class Initialized
INFO - 2024-02-07 06:06:22 --> Router Class Initialized
INFO - 2024-02-07 06:06:22 --> Output Class Initialized
INFO - 2024-02-07 06:06:22 --> Security Class Initialized
DEBUG - 2024-02-07 06:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:06:22 --> Input Class Initialized
INFO - 2024-02-07 06:06:22 --> Language Class Initialized
INFO - 2024-02-07 06:06:22 --> Loader Class Initialized
INFO - 2024-02-07 06:06:22 --> Helper loaded: url_helper
INFO - 2024-02-07 06:06:22 --> Helper loaded: file_helper
INFO - 2024-02-07 06:06:22 --> Helper loaded: html_helper
INFO - 2024-02-07 06:06:22 --> Helper loaded: text_helper
INFO - 2024-02-07 06:06:22 --> Helper loaded: form_helper
INFO - 2024-02-07 06:06:22 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:06:22 --> Helper loaded: security_helper
INFO - 2024-02-07 06:06:22 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:06:22 --> Database Driver Class Initialized
INFO - 2024-02-07 06:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:06:22 --> Parser Class Initialized
INFO - 2024-02-07 06:06:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:06:22 --> Pagination Class Initialized
INFO - 2024-02-07 06:06:22 --> Form Validation Class Initialized
INFO - 2024-02-07 06:06:22 --> Controller Class Initialized
INFO - 2024-02-07 06:06:22 --> Model Class Initialized
DEBUG - 2024-02-07 06:06:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:06:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:06:22 --> Model Class Initialized
DEBUG - 2024-02-07 06:06:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:06:22 --> Model Class Initialized
INFO - 2024-02-07 06:06:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-07 06:06:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:06:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:06:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:06:22 --> Model Class Initialized
INFO - 2024-02-07 06:06:22 --> Model Class Initialized
INFO - 2024-02-07 06:06:22 --> Model Class Initialized
INFO - 2024-02-07 06:06:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 06:06:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 06:06:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:06:22 --> Final output sent to browser
DEBUG - 2024-02-07 06:06:22 --> Total execution time: 0.2211
ERROR - 2024-02-07 06:06:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:06:23 --> Config Class Initialized
INFO - 2024-02-07 06:06:23 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:06:23 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:06:23 --> Utf8 Class Initialized
INFO - 2024-02-07 06:06:23 --> URI Class Initialized
INFO - 2024-02-07 06:06:23 --> Router Class Initialized
INFO - 2024-02-07 06:06:23 --> Output Class Initialized
INFO - 2024-02-07 06:06:23 --> Security Class Initialized
DEBUG - 2024-02-07 06:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:06:23 --> Input Class Initialized
INFO - 2024-02-07 06:06:23 --> Language Class Initialized
INFO - 2024-02-07 06:06:23 --> Loader Class Initialized
INFO - 2024-02-07 06:06:23 --> Helper loaded: url_helper
INFO - 2024-02-07 06:06:23 --> Helper loaded: file_helper
INFO - 2024-02-07 06:06:23 --> Helper loaded: html_helper
INFO - 2024-02-07 06:06:23 --> Helper loaded: text_helper
INFO - 2024-02-07 06:06:23 --> Helper loaded: form_helper
INFO - 2024-02-07 06:06:23 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:06:23 --> Helper loaded: security_helper
INFO - 2024-02-07 06:06:23 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:06:23 --> Database Driver Class Initialized
INFO - 2024-02-07 06:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:06:23 --> Parser Class Initialized
INFO - 2024-02-07 06:06:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:06:23 --> Pagination Class Initialized
INFO - 2024-02-07 06:06:23 --> Form Validation Class Initialized
INFO - 2024-02-07 06:06:23 --> Controller Class Initialized
INFO - 2024-02-07 06:06:23 --> Model Class Initialized
DEBUG - 2024-02-07 06:06:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:06:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:06:23 --> Model Class Initialized
DEBUG - 2024-02-07 06:06:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:06:23 --> Model Class Initialized
INFO - 2024-02-07 06:06:23 --> Final output sent to browser
DEBUG - 2024-02-07 06:06:23 --> Total execution time: 0.0655
ERROR - 2024-02-07 06:06:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:06:26 --> Config Class Initialized
INFO - 2024-02-07 06:06:26 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:06:26 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:06:26 --> Utf8 Class Initialized
INFO - 2024-02-07 06:06:26 --> URI Class Initialized
INFO - 2024-02-07 06:06:26 --> Router Class Initialized
INFO - 2024-02-07 06:06:26 --> Output Class Initialized
INFO - 2024-02-07 06:06:26 --> Security Class Initialized
DEBUG - 2024-02-07 06:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:06:26 --> Input Class Initialized
INFO - 2024-02-07 06:06:26 --> Language Class Initialized
INFO - 2024-02-07 06:06:26 --> Loader Class Initialized
INFO - 2024-02-07 06:06:26 --> Helper loaded: url_helper
INFO - 2024-02-07 06:06:26 --> Helper loaded: file_helper
INFO - 2024-02-07 06:06:26 --> Helper loaded: html_helper
INFO - 2024-02-07 06:06:26 --> Helper loaded: text_helper
INFO - 2024-02-07 06:06:26 --> Helper loaded: form_helper
INFO - 2024-02-07 06:06:26 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:06:26 --> Helper loaded: security_helper
INFO - 2024-02-07 06:06:26 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:06:26 --> Database Driver Class Initialized
INFO - 2024-02-07 06:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:06:26 --> Parser Class Initialized
INFO - 2024-02-07 06:06:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:06:26 --> Pagination Class Initialized
INFO - 2024-02-07 06:06:26 --> Form Validation Class Initialized
INFO - 2024-02-07 06:06:26 --> Controller Class Initialized
INFO - 2024-02-07 06:06:26 --> Model Class Initialized
DEBUG - 2024-02-07 06:06:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:06:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:06:26 --> Model Class Initialized
DEBUG - 2024-02-07 06:06:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:06:26 --> Model Class Initialized
INFO - 2024-02-07 06:06:27 --> Final output sent to browser
DEBUG - 2024-02-07 06:06:27 --> Total execution time: 0.0650
ERROR - 2024-02-07 06:06:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:06:27 --> Config Class Initialized
INFO - 2024-02-07 06:06:27 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:06:27 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:06:27 --> Utf8 Class Initialized
INFO - 2024-02-07 06:06:27 --> URI Class Initialized
INFO - 2024-02-07 06:06:27 --> Router Class Initialized
INFO - 2024-02-07 06:06:27 --> Output Class Initialized
INFO - 2024-02-07 06:06:27 --> Security Class Initialized
DEBUG - 2024-02-07 06:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:06:27 --> Input Class Initialized
INFO - 2024-02-07 06:06:27 --> Language Class Initialized
INFO - 2024-02-07 06:06:27 --> Loader Class Initialized
INFO - 2024-02-07 06:06:27 --> Helper loaded: url_helper
INFO - 2024-02-07 06:06:27 --> Helper loaded: file_helper
INFO - 2024-02-07 06:06:27 --> Helper loaded: html_helper
INFO - 2024-02-07 06:06:27 --> Helper loaded: text_helper
INFO - 2024-02-07 06:06:27 --> Helper loaded: form_helper
INFO - 2024-02-07 06:06:27 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:06:27 --> Helper loaded: security_helper
INFO - 2024-02-07 06:06:27 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:06:27 --> Database Driver Class Initialized
INFO - 2024-02-07 06:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:06:27 --> Parser Class Initialized
INFO - 2024-02-07 06:06:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:06:27 --> Pagination Class Initialized
INFO - 2024-02-07 06:06:27 --> Form Validation Class Initialized
INFO - 2024-02-07 06:06:27 --> Controller Class Initialized
INFO - 2024-02-07 06:06:27 --> Model Class Initialized
DEBUG - 2024-02-07 06:06:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:06:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:06:27 --> Model Class Initialized
DEBUG - 2024-02-07 06:06:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:06:27 --> Model Class Initialized
INFO - 2024-02-07 06:06:27 --> Final output sent to browser
DEBUG - 2024-02-07 06:06:27 --> Total execution time: 0.0581
ERROR - 2024-02-07 06:06:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:06:28 --> Config Class Initialized
INFO - 2024-02-07 06:06:28 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:06:28 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:06:28 --> Utf8 Class Initialized
INFO - 2024-02-07 06:06:28 --> URI Class Initialized
INFO - 2024-02-07 06:06:28 --> Router Class Initialized
INFO - 2024-02-07 06:06:28 --> Output Class Initialized
INFO - 2024-02-07 06:06:28 --> Security Class Initialized
DEBUG - 2024-02-07 06:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:06:28 --> Input Class Initialized
INFO - 2024-02-07 06:06:28 --> Language Class Initialized
INFO - 2024-02-07 06:06:28 --> Loader Class Initialized
INFO - 2024-02-07 06:06:28 --> Helper loaded: url_helper
INFO - 2024-02-07 06:06:28 --> Helper loaded: file_helper
INFO - 2024-02-07 06:06:28 --> Helper loaded: html_helper
INFO - 2024-02-07 06:06:28 --> Helper loaded: text_helper
INFO - 2024-02-07 06:06:28 --> Helper loaded: form_helper
INFO - 2024-02-07 06:06:28 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:06:28 --> Helper loaded: security_helper
INFO - 2024-02-07 06:06:28 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:06:28 --> Database Driver Class Initialized
INFO - 2024-02-07 06:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:06:28 --> Parser Class Initialized
INFO - 2024-02-07 06:06:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:06:28 --> Pagination Class Initialized
INFO - 2024-02-07 06:06:28 --> Form Validation Class Initialized
INFO - 2024-02-07 06:06:28 --> Controller Class Initialized
INFO - 2024-02-07 06:06:28 --> Model Class Initialized
DEBUG - 2024-02-07 06:06:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:06:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:06:28 --> Model Class Initialized
DEBUG - 2024-02-07 06:06:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:06:28 --> Model Class Initialized
INFO - 2024-02-07 06:06:28 --> Final output sent to browser
DEBUG - 2024-02-07 06:06:28 --> Total execution time: 0.0585
ERROR - 2024-02-07 06:06:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:06:33 --> Config Class Initialized
INFO - 2024-02-07 06:06:33 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:06:33 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:06:33 --> Utf8 Class Initialized
INFO - 2024-02-07 06:06:33 --> URI Class Initialized
INFO - 2024-02-07 06:06:33 --> Router Class Initialized
INFO - 2024-02-07 06:06:33 --> Output Class Initialized
INFO - 2024-02-07 06:06:33 --> Security Class Initialized
DEBUG - 2024-02-07 06:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:06:33 --> Input Class Initialized
INFO - 2024-02-07 06:06:33 --> Language Class Initialized
INFO - 2024-02-07 06:06:33 --> Loader Class Initialized
INFO - 2024-02-07 06:06:33 --> Helper loaded: url_helper
INFO - 2024-02-07 06:06:33 --> Helper loaded: file_helper
INFO - 2024-02-07 06:06:33 --> Helper loaded: html_helper
INFO - 2024-02-07 06:06:33 --> Helper loaded: text_helper
INFO - 2024-02-07 06:06:33 --> Helper loaded: form_helper
INFO - 2024-02-07 06:06:33 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:06:33 --> Helper loaded: security_helper
INFO - 2024-02-07 06:06:33 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:06:33 --> Database Driver Class Initialized
INFO - 2024-02-07 06:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:06:33 --> Parser Class Initialized
INFO - 2024-02-07 06:06:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:06:33 --> Pagination Class Initialized
INFO - 2024-02-07 06:06:33 --> Form Validation Class Initialized
INFO - 2024-02-07 06:06:33 --> Controller Class Initialized
INFO - 2024-02-07 06:06:33 --> Model Class Initialized
DEBUG - 2024-02-07 06:06:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:06:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:06:33 --> Model Class Initialized
DEBUG - 2024-02-07 06:06:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:06:33 --> Model Class Initialized
DEBUG - 2024-02-07 06:06:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:06:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-02-07 06:06:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:06:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:06:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:06:33 --> Model Class Initialized
INFO - 2024-02-07 06:06:33 --> Model Class Initialized
INFO - 2024-02-07 06:06:33 --> Model Class Initialized
INFO - 2024-02-07 06:06:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 06:06:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 06:06:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:06:33 --> Final output sent to browser
DEBUG - 2024-02-07 06:06:33 --> Total execution time: 0.2090
ERROR - 2024-02-07 06:07:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:07:34 --> Config Class Initialized
INFO - 2024-02-07 06:07:34 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:07:34 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:07:34 --> Utf8 Class Initialized
INFO - 2024-02-07 06:07:34 --> URI Class Initialized
INFO - 2024-02-07 06:07:34 --> Router Class Initialized
INFO - 2024-02-07 06:07:34 --> Output Class Initialized
INFO - 2024-02-07 06:07:34 --> Security Class Initialized
DEBUG - 2024-02-07 06:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:07:34 --> Input Class Initialized
INFO - 2024-02-07 06:07:34 --> Language Class Initialized
INFO - 2024-02-07 06:07:34 --> Loader Class Initialized
INFO - 2024-02-07 06:07:34 --> Helper loaded: url_helper
INFO - 2024-02-07 06:07:34 --> Helper loaded: file_helper
INFO - 2024-02-07 06:07:34 --> Helper loaded: html_helper
INFO - 2024-02-07 06:07:34 --> Helper loaded: text_helper
INFO - 2024-02-07 06:07:34 --> Helper loaded: form_helper
INFO - 2024-02-07 06:07:34 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:07:34 --> Helper loaded: security_helper
INFO - 2024-02-07 06:07:34 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:07:34 --> Database Driver Class Initialized
INFO - 2024-02-07 06:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:07:34 --> Parser Class Initialized
INFO - 2024-02-07 06:07:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:07:34 --> Pagination Class Initialized
INFO - 2024-02-07 06:07:34 --> Form Validation Class Initialized
INFO - 2024-02-07 06:07:34 --> Controller Class Initialized
INFO - 2024-02-07 06:07:34 --> Model Class Initialized
DEBUG - 2024-02-07 06:07:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:07:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:07:34 --> Model Class Initialized
DEBUG - 2024-02-07 06:07:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:07:34 --> Model Class Initialized
INFO - 2024-02-07 06:07:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-07 06:07:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:07:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:07:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:07:34 --> Model Class Initialized
INFO - 2024-02-07 06:07:34 --> Model Class Initialized
INFO - 2024-02-07 06:07:34 --> Model Class Initialized
INFO - 2024-02-07 06:07:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 06:07:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 06:07:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:07:34 --> Final output sent to browser
DEBUG - 2024-02-07 06:07:34 --> Total execution time: 0.2163
ERROR - 2024-02-07 06:07:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:07:35 --> Config Class Initialized
INFO - 2024-02-07 06:07:35 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:07:35 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:07:35 --> Utf8 Class Initialized
INFO - 2024-02-07 06:07:35 --> URI Class Initialized
INFO - 2024-02-07 06:07:35 --> Router Class Initialized
INFO - 2024-02-07 06:07:35 --> Output Class Initialized
INFO - 2024-02-07 06:07:35 --> Security Class Initialized
DEBUG - 2024-02-07 06:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:07:35 --> Input Class Initialized
INFO - 2024-02-07 06:07:35 --> Language Class Initialized
INFO - 2024-02-07 06:07:35 --> Loader Class Initialized
INFO - 2024-02-07 06:07:35 --> Helper loaded: url_helper
INFO - 2024-02-07 06:07:35 --> Helper loaded: file_helper
INFO - 2024-02-07 06:07:35 --> Helper loaded: html_helper
INFO - 2024-02-07 06:07:35 --> Helper loaded: text_helper
INFO - 2024-02-07 06:07:35 --> Helper loaded: form_helper
INFO - 2024-02-07 06:07:35 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:07:35 --> Helper loaded: security_helper
INFO - 2024-02-07 06:07:35 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:07:35 --> Database Driver Class Initialized
INFO - 2024-02-07 06:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:07:35 --> Parser Class Initialized
INFO - 2024-02-07 06:07:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:07:35 --> Pagination Class Initialized
INFO - 2024-02-07 06:07:35 --> Form Validation Class Initialized
INFO - 2024-02-07 06:07:35 --> Controller Class Initialized
INFO - 2024-02-07 06:07:35 --> Model Class Initialized
DEBUG - 2024-02-07 06:07:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:07:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:07:35 --> Model Class Initialized
DEBUG - 2024-02-07 06:07:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:07:35 --> Model Class Initialized
INFO - 2024-02-07 06:07:35 --> Final output sent to browser
DEBUG - 2024-02-07 06:07:35 --> Total execution time: 0.0601
ERROR - 2024-02-07 06:07:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:07:39 --> Config Class Initialized
INFO - 2024-02-07 06:07:39 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:07:39 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:07:39 --> Utf8 Class Initialized
INFO - 2024-02-07 06:07:39 --> URI Class Initialized
INFO - 2024-02-07 06:07:39 --> Router Class Initialized
INFO - 2024-02-07 06:07:39 --> Output Class Initialized
INFO - 2024-02-07 06:07:39 --> Security Class Initialized
DEBUG - 2024-02-07 06:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:07:39 --> Input Class Initialized
INFO - 2024-02-07 06:07:39 --> Language Class Initialized
INFO - 2024-02-07 06:07:39 --> Loader Class Initialized
INFO - 2024-02-07 06:07:39 --> Helper loaded: url_helper
INFO - 2024-02-07 06:07:39 --> Helper loaded: file_helper
INFO - 2024-02-07 06:07:39 --> Helper loaded: html_helper
INFO - 2024-02-07 06:07:39 --> Helper loaded: text_helper
INFO - 2024-02-07 06:07:39 --> Helper loaded: form_helper
INFO - 2024-02-07 06:07:39 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:07:39 --> Helper loaded: security_helper
INFO - 2024-02-07 06:07:39 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:07:39 --> Database Driver Class Initialized
INFO - 2024-02-07 06:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:07:39 --> Parser Class Initialized
INFO - 2024-02-07 06:07:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:07:39 --> Pagination Class Initialized
INFO - 2024-02-07 06:07:39 --> Form Validation Class Initialized
INFO - 2024-02-07 06:07:39 --> Controller Class Initialized
INFO - 2024-02-07 06:07:39 --> Model Class Initialized
DEBUG - 2024-02-07 06:07:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:07:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:07:39 --> Model Class Initialized
DEBUG - 2024-02-07 06:07:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:07:39 --> Model Class Initialized
INFO - 2024-02-07 06:07:39 --> Final output sent to browser
DEBUG - 2024-02-07 06:07:39 --> Total execution time: 0.0562
ERROR - 2024-02-07 06:07:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:07:39 --> Config Class Initialized
INFO - 2024-02-07 06:07:39 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:07:39 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:07:39 --> Utf8 Class Initialized
INFO - 2024-02-07 06:07:39 --> URI Class Initialized
INFO - 2024-02-07 06:07:39 --> Router Class Initialized
INFO - 2024-02-07 06:07:39 --> Output Class Initialized
INFO - 2024-02-07 06:07:39 --> Security Class Initialized
DEBUG - 2024-02-07 06:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:07:39 --> Input Class Initialized
INFO - 2024-02-07 06:07:39 --> Language Class Initialized
INFO - 2024-02-07 06:07:39 --> Loader Class Initialized
INFO - 2024-02-07 06:07:39 --> Helper loaded: url_helper
INFO - 2024-02-07 06:07:39 --> Helper loaded: file_helper
INFO - 2024-02-07 06:07:39 --> Helper loaded: html_helper
INFO - 2024-02-07 06:07:39 --> Helper loaded: text_helper
INFO - 2024-02-07 06:07:39 --> Helper loaded: form_helper
INFO - 2024-02-07 06:07:39 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:07:39 --> Helper loaded: security_helper
INFO - 2024-02-07 06:07:39 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:07:39 --> Database Driver Class Initialized
INFO - 2024-02-07 06:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:07:39 --> Parser Class Initialized
INFO - 2024-02-07 06:07:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:07:39 --> Pagination Class Initialized
INFO - 2024-02-07 06:07:39 --> Form Validation Class Initialized
INFO - 2024-02-07 06:07:39 --> Controller Class Initialized
INFO - 2024-02-07 06:07:39 --> Model Class Initialized
DEBUG - 2024-02-07 06:07:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:07:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:07:39 --> Model Class Initialized
DEBUG - 2024-02-07 06:07:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:07:39 --> Model Class Initialized
INFO - 2024-02-07 06:07:39 --> Final output sent to browser
DEBUG - 2024-02-07 06:07:39 --> Total execution time: 0.0546
ERROR - 2024-02-07 06:07:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:07:39 --> Config Class Initialized
INFO - 2024-02-07 06:07:39 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:07:39 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:07:39 --> Utf8 Class Initialized
INFO - 2024-02-07 06:07:39 --> URI Class Initialized
INFO - 2024-02-07 06:07:39 --> Router Class Initialized
INFO - 2024-02-07 06:07:39 --> Output Class Initialized
INFO - 2024-02-07 06:07:39 --> Security Class Initialized
DEBUG - 2024-02-07 06:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:07:39 --> Input Class Initialized
INFO - 2024-02-07 06:07:39 --> Language Class Initialized
INFO - 2024-02-07 06:07:39 --> Loader Class Initialized
INFO - 2024-02-07 06:07:39 --> Helper loaded: url_helper
INFO - 2024-02-07 06:07:39 --> Helper loaded: file_helper
INFO - 2024-02-07 06:07:39 --> Helper loaded: html_helper
INFO - 2024-02-07 06:07:39 --> Helper loaded: text_helper
INFO - 2024-02-07 06:07:39 --> Helper loaded: form_helper
INFO - 2024-02-07 06:07:39 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:07:39 --> Helper loaded: security_helper
INFO - 2024-02-07 06:07:39 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:07:39 --> Database Driver Class Initialized
INFO - 2024-02-07 06:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:07:39 --> Parser Class Initialized
INFO - 2024-02-07 06:07:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:07:39 --> Pagination Class Initialized
INFO - 2024-02-07 06:07:39 --> Form Validation Class Initialized
INFO - 2024-02-07 06:07:39 --> Controller Class Initialized
INFO - 2024-02-07 06:07:39 --> Model Class Initialized
DEBUG - 2024-02-07 06:07:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:07:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:07:39 --> Model Class Initialized
DEBUG - 2024-02-07 06:07:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:07:39 --> Model Class Initialized
INFO - 2024-02-07 06:07:39 --> Final output sent to browser
DEBUG - 2024-02-07 06:07:39 --> Total execution time: 0.0637
ERROR - 2024-02-07 06:07:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:07:40 --> Config Class Initialized
INFO - 2024-02-07 06:07:40 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:07:40 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:07:40 --> Utf8 Class Initialized
INFO - 2024-02-07 06:07:40 --> URI Class Initialized
INFO - 2024-02-07 06:07:40 --> Router Class Initialized
INFO - 2024-02-07 06:07:40 --> Output Class Initialized
INFO - 2024-02-07 06:07:40 --> Security Class Initialized
DEBUG - 2024-02-07 06:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:07:40 --> Input Class Initialized
INFO - 2024-02-07 06:07:40 --> Language Class Initialized
INFO - 2024-02-07 06:07:40 --> Loader Class Initialized
INFO - 2024-02-07 06:07:40 --> Helper loaded: url_helper
INFO - 2024-02-07 06:07:40 --> Helper loaded: file_helper
INFO - 2024-02-07 06:07:40 --> Helper loaded: html_helper
INFO - 2024-02-07 06:07:40 --> Helper loaded: text_helper
INFO - 2024-02-07 06:07:40 --> Helper loaded: form_helper
INFO - 2024-02-07 06:07:40 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:07:40 --> Helper loaded: security_helper
INFO - 2024-02-07 06:07:40 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:07:40 --> Database Driver Class Initialized
INFO - 2024-02-07 06:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:07:40 --> Parser Class Initialized
INFO - 2024-02-07 06:07:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:07:40 --> Pagination Class Initialized
INFO - 2024-02-07 06:07:40 --> Form Validation Class Initialized
INFO - 2024-02-07 06:07:40 --> Controller Class Initialized
INFO - 2024-02-07 06:07:40 --> Model Class Initialized
DEBUG - 2024-02-07 06:07:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:07:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:07:40 --> Model Class Initialized
DEBUG - 2024-02-07 06:07:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:07:40 --> Model Class Initialized
INFO - 2024-02-07 06:07:40 --> Final output sent to browser
DEBUG - 2024-02-07 06:07:40 --> Total execution time: 0.0534
ERROR - 2024-02-07 06:07:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:07:42 --> Config Class Initialized
INFO - 2024-02-07 06:07:42 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:07:42 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:07:42 --> Utf8 Class Initialized
INFO - 2024-02-07 06:07:42 --> URI Class Initialized
INFO - 2024-02-07 06:07:42 --> Router Class Initialized
INFO - 2024-02-07 06:07:42 --> Output Class Initialized
INFO - 2024-02-07 06:07:42 --> Security Class Initialized
DEBUG - 2024-02-07 06:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:07:42 --> Input Class Initialized
INFO - 2024-02-07 06:07:42 --> Language Class Initialized
INFO - 2024-02-07 06:07:42 --> Loader Class Initialized
INFO - 2024-02-07 06:07:42 --> Helper loaded: url_helper
INFO - 2024-02-07 06:07:42 --> Helper loaded: file_helper
INFO - 2024-02-07 06:07:42 --> Helper loaded: html_helper
INFO - 2024-02-07 06:07:42 --> Helper loaded: text_helper
INFO - 2024-02-07 06:07:42 --> Helper loaded: form_helper
INFO - 2024-02-07 06:07:42 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:07:42 --> Helper loaded: security_helper
INFO - 2024-02-07 06:07:42 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:07:42 --> Database Driver Class Initialized
INFO - 2024-02-07 06:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:07:42 --> Parser Class Initialized
INFO - 2024-02-07 06:07:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:07:42 --> Pagination Class Initialized
INFO - 2024-02-07 06:07:42 --> Form Validation Class Initialized
INFO - 2024-02-07 06:07:42 --> Controller Class Initialized
INFO - 2024-02-07 06:07:42 --> Model Class Initialized
DEBUG - 2024-02-07 06:07:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:07:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:07:42 --> Model Class Initialized
DEBUG - 2024-02-07 06:07:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:07:42 --> Model Class Initialized
INFO - 2024-02-07 06:07:42 --> Final output sent to browser
DEBUG - 2024-02-07 06:07:42 --> Total execution time: 0.0244
ERROR - 2024-02-07 06:07:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:07:45 --> Config Class Initialized
INFO - 2024-02-07 06:07:45 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:07:45 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:07:45 --> Utf8 Class Initialized
INFO - 2024-02-07 06:07:45 --> URI Class Initialized
INFO - 2024-02-07 06:07:45 --> Router Class Initialized
INFO - 2024-02-07 06:07:45 --> Output Class Initialized
INFO - 2024-02-07 06:07:45 --> Security Class Initialized
DEBUG - 2024-02-07 06:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:07:45 --> Input Class Initialized
INFO - 2024-02-07 06:07:45 --> Language Class Initialized
INFO - 2024-02-07 06:07:45 --> Loader Class Initialized
INFO - 2024-02-07 06:07:45 --> Helper loaded: url_helper
INFO - 2024-02-07 06:07:45 --> Helper loaded: file_helper
INFO - 2024-02-07 06:07:45 --> Helper loaded: html_helper
INFO - 2024-02-07 06:07:45 --> Helper loaded: text_helper
INFO - 2024-02-07 06:07:45 --> Helper loaded: form_helper
INFO - 2024-02-07 06:07:45 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:07:45 --> Helper loaded: security_helper
INFO - 2024-02-07 06:07:45 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:07:45 --> Database Driver Class Initialized
INFO - 2024-02-07 06:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:07:45 --> Parser Class Initialized
INFO - 2024-02-07 06:07:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:07:45 --> Pagination Class Initialized
INFO - 2024-02-07 06:07:45 --> Form Validation Class Initialized
INFO - 2024-02-07 06:07:45 --> Controller Class Initialized
INFO - 2024-02-07 06:07:45 --> Model Class Initialized
DEBUG - 2024-02-07 06:07:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:07:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:07:45 --> Model Class Initialized
DEBUG - 2024-02-07 06:07:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:07:45 --> Model Class Initialized
INFO - 2024-02-07 06:07:45 --> Final output sent to browser
DEBUG - 2024-02-07 06:07:45 --> Total execution time: 0.0553
ERROR - 2024-02-07 06:07:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:07:46 --> Config Class Initialized
INFO - 2024-02-07 06:07:46 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:07:46 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:07:46 --> Utf8 Class Initialized
INFO - 2024-02-07 06:07:46 --> URI Class Initialized
INFO - 2024-02-07 06:07:46 --> Router Class Initialized
INFO - 2024-02-07 06:07:46 --> Output Class Initialized
INFO - 2024-02-07 06:07:46 --> Security Class Initialized
DEBUG - 2024-02-07 06:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:07:46 --> Input Class Initialized
INFO - 2024-02-07 06:07:46 --> Language Class Initialized
INFO - 2024-02-07 06:07:46 --> Loader Class Initialized
INFO - 2024-02-07 06:07:46 --> Helper loaded: url_helper
INFO - 2024-02-07 06:07:46 --> Helper loaded: file_helper
INFO - 2024-02-07 06:07:46 --> Helper loaded: html_helper
INFO - 2024-02-07 06:07:46 --> Helper loaded: text_helper
INFO - 2024-02-07 06:07:46 --> Helper loaded: form_helper
INFO - 2024-02-07 06:07:46 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:07:46 --> Helper loaded: security_helper
INFO - 2024-02-07 06:07:46 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:07:46 --> Database Driver Class Initialized
INFO - 2024-02-07 06:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:07:46 --> Parser Class Initialized
INFO - 2024-02-07 06:07:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:07:46 --> Pagination Class Initialized
INFO - 2024-02-07 06:07:46 --> Form Validation Class Initialized
INFO - 2024-02-07 06:07:46 --> Controller Class Initialized
INFO - 2024-02-07 06:07:46 --> Model Class Initialized
DEBUG - 2024-02-07 06:07:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:07:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:07:46 --> Model Class Initialized
DEBUG - 2024-02-07 06:07:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:07:46 --> Model Class Initialized
INFO - 2024-02-07 06:07:46 --> Final output sent to browser
DEBUG - 2024-02-07 06:07:46 --> Total execution time: 0.0569
ERROR - 2024-02-07 06:08:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:08:01 --> Config Class Initialized
INFO - 2024-02-07 06:08:01 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:08:01 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:08:01 --> Utf8 Class Initialized
INFO - 2024-02-07 06:08:01 --> URI Class Initialized
INFO - 2024-02-07 06:08:01 --> Router Class Initialized
INFO - 2024-02-07 06:08:01 --> Output Class Initialized
INFO - 2024-02-07 06:08:01 --> Security Class Initialized
DEBUG - 2024-02-07 06:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:08:01 --> Input Class Initialized
INFO - 2024-02-07 06:08:01 --> Language Class Initialized
INFO - 2024-02-07 06:08:01 --> Loader Class Initialized
INFO - 2024-02-07 06:08:01 --> Helper loaded: url_helper
INFO - 2024-02-07 06:08:01 --> Helper loaded: file_helper
INFO - 2024-02-07 06:08:01 --> Helper loaded: html_helper
INFO - 2024-02-07 06:08:01 --> Helper loaded: text_helper
INFO - 2024-02-07 06:08:01 --> Helper loaded: form_helper
INFO - 2024-02-07 06:08:01 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:08:01 --> Helper loaded: security_helper
INFO - 2024-02-07 06:08:01 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:08:01 --> Database Driver Class Initialized
INFO - 2024-02-07 06:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:08:01 --> Parser Class Initialized
INFO - 2024-02-07 06:08:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:08:01 --> Pagination Class Initialized
INFO - 2024-02-07 06:08:01 --> Form Validation Class Initialized
INFO - 2024-02-07 06:08:01 --> Controller Class Initialized
INFO - 2024-02-07 06:08:01 --> Model Class Initialized
DEBUG - 2024-02-07 06:08:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:08:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:08:01 --> Model Class Initialized
DEBUG - 2024-02-07 06:08:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:08:01 --> Model Class Initialized
DEBUG - 2024-02-07 06:08:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:08:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-02-07 06:08:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:08:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:08:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:08:01 --> Model Class Initialized
INFO - 2024-02-07 06:08:01 --> Model Class Initialized
INFO - 2024-02-07 06:08:01 --> Model Class Initialized
INFO - 2024-02-07 06:08:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 06:08:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 06:08:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:08:02 --> Final output sent to browser
DEBUG - 2024-02-07 06:08:02 --> Total execution time: 0.2231
ERROR - 2024-02-07 06:10:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:10:52 --> Config Class Initialized
INFO - 2024-02-07 06:10:52 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:10:52 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:10:52 --> Utf8 Class Initialized
INFO - 2024-02-07 06:10:52 --> URI Class Initialized
INFO - 2024-02-07 06:10:52 --> Router Class Initialized
INFO - 2024-02-07 06:10:52 --> Output Class Initialized
INFO - 2024-02-07 06:10:52 --> Security Class Initialized
DEBUG - 2024-02-07 06:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:10:52 --> Input Class Initialized
INFO - 2024-02-07 06:10:52 --> Language Class Initialized
INFO - 2024-02-07 06:10:52 --> Loader Class Initialized
INFO - 2024-02-07 06:10:52 --> Helper loaded: url_helper
INFO - 2024-02-07 06:10:52 --> Helper loaded: file_helper
INFO - 2024-02-07 06:10:52 --> Helper loaded: html_helper
INFO - 2024-02-07 06:10:52 --> Helper loaded: text_helper
INFO - 2024-02-07 06:10:52 --> Helper loaded: form_helper
INFO - 2024-02-07 06:10:52 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:10:52 --> Helper loaded: security_helper
INFO - 2024-02-07 06:10:52 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:10:52 --> Database Driver Class Initialized
INFO - 2024-02-07 06:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:10:52 --> Parser Class Initialized
INFO - 2024-02-07 06:10:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:10:52 --> Pagination Class Initialized
INFO - 2024-02-07 06:10:52 --> Form Validation Class Initialized
INFO - 2024-02-07 06:10:52 --> Controller Class Initialized
DEBUG - 2024-02-07 06:10:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:10:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:10:52 --> Model Class Initialized
DEBUG - 2024-02-07 06:10:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:10:52 --> Model Class Initialized
DEBUG - 2024-02-07 06:10:52 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:10:52 --> Model Class Initialized
INFO - 2024-02-07 06:10:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-07 06:10:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:10:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:10:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:10:52 --> Model Class Initialized
INFO - 2024-02-07 06:10:52 --> Model Class Initialized
INFO - 2024-02-07 06:10:52 --> Model Class Initialized
INFO - 2024-02-07 06:10:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 06:10:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 06:10:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:10:52 --> Final output sent to browser
DEBUG - 2024-02-07 06:10:52 --> Total execution time: 0.1972
ERROR - 2024-02-07 06:10:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:10:53 --> Config Class Initialized
INFO - 2024-02-07 06:10:53 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:10:53 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:10:53 --> Utf8 Class Initialized
INFO - 2024-02-07 06:10:53 --> URI Class Initialized
INFO - 2024-02-07 06:10:53 --> Router Class Initialized
INFO - 2024-02-07 06:10:53 --> Output Class Initialized
INFO - 2024-02-07 06:10:53 --> Security Class Initialized
DEBUG - 2024-02-07 06:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:10:53 --> Input Class Initialized
INFO - 2024-02-07 06:10:53 --> Language Class Initialized
INFO - 2024-02-07 06:10:53 --> Loader Class Initialized
INFO - 2024-02-07 06:10:53 --> Helper loaded: url_helper
INFO - 2024-02-07 06:10:53 --> Helper loaded: file_helper
INFO - 2024-02-07 06:10:53 --> Helper loaded: html_helper
INFO - 2024-02-07 06:10:53 --> Helper loaded: text_helper
INFO - 2024-02-07 06:10:53 --> Helper loaded: form_helper
INFO - 2024-02-07 06:10:53 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:10:53 --> Helper loaded: security_helper
INFO - 2024-02-07 06:10:53 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:10:53 --> Database Driver Class Initialized
INFO - 2024-02-07 06:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:10:53 --> Parser Class Initialized
INFO - 2024-02-07 06:10:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:10:53 --> Pagination Class Initialized
INFO - 2024-02-07 06:10:53 --> Form Validation Class Initialized
INFO - 2024-02-07 06:10:53 --> Controller Class Initialized
DEBUG - 2024-02-07 06:10:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:10:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:10:53 --> Model Class Initialized
DEBUG - 2024-02-07 06:10:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:10:53 --> Model Class Initialized
INFO - 2024-02-07 06:10:53 --> Final output sent to browser
DEBUG - 2024-02-07 06:10:53 --> Total execution time: 0.0291
ERROR - 2024-02-07 06:11:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:11:02 --> Config Class Initialized
INFO - 2024-02-07 06:11:02 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:11:02 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:11:02 --> Utf8 Class Initialized
INFO - 2024-02-07 06:11:02 --> URI Class Initialized
INFO - 2024-02-07 06:11:02 --> Router Class Initialized
INFO - 2024-02-07 06:11:02 --> Output Class Initialized
INFO - 2024-02-07 06:11:02 --> Security Class Initialized
DEBUG - 2024-02-07 06:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:11:02 --> Input Class Initialized
INFO - 2024-02-07 06:11:02 --> Language Class Initialized
INFO - 2024-02-07 06:11:02 --> Loader Class Initialized
INFO - 2024-02-07 06:11:02 --> Helper loaded: url_helper
INFO - 2024-02-07 06:11:02 --> Helper loaded: file_helper
INFO - 2024-02-07 06:11:02 --> Helper loaded: html_helper
INFO - 2024-02-07 06:11:02 --> Helper loaded: text_helper
INFO - 2024-02-07 06:11:02 --> Helper loaded: form_helper
INFO - 2024-02-07 06:11:02 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:11:02 --> Helper loaded: security_helper
INFO - 2024-02-07 06:11:02 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:11:02 --> Database Driver Class Initialized
INFO - 2024-02-07 06:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:11:02 --> Parser Class Initialized
INFO - 2024-02-07 06:11:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:11:02 --> Pagination Class Initialized
INFO - 2024-02-07 06:11:02 --> Form Validation Class Initialized
INFO - 2024-02-07 06:11:02 --> Controller Class Initialized
DEBUG - 2024-02-07 06:11:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:11:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:02 --> Model Class Initialized
DEBUG - 2024-02-07 06:11:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:02 --> Model Class Initialized
INFO - 2024-02-07 06:11:02 --> Final output sent to browser
DEBUG - 2024-02-07 06:11:02 --> Total execution time: 0.1853
ERROR - 2024-02-07 06:11:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:11:09 --> Config Class Initialized
INFO - 2024-02-07 06:11:09 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:11:09 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:11:09 --> Utf8 Class Initialized
INFO - 2024-02-07 06:11:09 --> URI Class Initialized
INFO - 2024-02-07 06:11:09 --> Router Class Initialized
INFO - 2024-02-07 06:11:09 --> Output Class Initialized
INFO - 2024-02-07 06:11:09 --> Security Class Initialized
DEBUG - 2024-02-07 06:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:11:09 --> Input Class Initialized
INFO - 2024-02-07 06:11:09 --> Language Class Initialized
INFO - 2024-02-07 06:11:09 --> Loader Class Initialized
INFO - 2024-02-07 06:11:09 --> Helper loaded: url_helper
INFO - 2024-02-07 06:11:09 --> Helper loaded: file_helper
INFO - 2024-02-07 06:11:09 --> Helper loaded: html_helper
INFO - 2024-02-07 06:11:09 --> Helper loaded: text_helper
INFO - 2024-02-07 06:11:09 --> Helper loaded: form_helper
INFO - 2024-02-07 06:11:09 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:11:09 --> Helper loaded: security_helper
INFO - 2024-02-07 06:11:09 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:11:09 --> Database Driver Class Initialized
INFO - 2024-02-07 06:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:11:09 --> Parser Class Initialized
INFO - 2024-02-07 06:11:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:11:09 --> Pagination Class Initialized
INFO - 2024-02-07 06:11:09 --> Form Validation Class Initialized
INFO - 2024-02-07 06:11:09 --> Controller Class Initialized
DEBUG - 2024-02-07 06:11:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:11:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:09 --> Model Class Initialized
DEBUG - 2024-02-07 06:11:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:09 --> Model Class Initialized
INFO - 2024-02-07 06:11:09 --> Final output sent to browser
DEBUG - 2024-02-07 06:11:09 --> Total execution time: 0.1600
ERROR - 2024-02-07 06:11:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:11:09 --> Config Class Initialized
INFO - 2024-02-07 06:11:09 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:11:09 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:11:09 --> Utf8 Class Initialized
INFO - 2024-02-07 06:11:09 --> URI Class Initialized
INFO - 2024-02-07 06:11:09 --> Router Class Initialized
INFO - 2024-02-07 06:11:09 --> Output Class Initialized
INFO - 2024-02-07 06:11:09 --> Security Class Initialized
DEBUG - 2024-02-07 06:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:11:09 --> Input Class Initialized
INFO - 2024-02-07 06:11:09 --> Language Class Initialized
INFO - 2024-02-07 06:11:09 --> Loader Class Initialized
INFO - 2024-02-07 06:11:09 --> Helper loaded: url_helper
INFO - 2024-02-07 06:11:09 --> Helper loaded: file_helper
INFO - 2024-02-07 06:11:09 --> Helper loaded: html_helper
INFO - 2024-02-07 06:11:09 --> Helper loaded: text_helper
INFO - 2024-02-07 06:11:09 --> Helper loaded: form_helper
INFO - 2024-02-07 06:11:09 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:11:09 --> Helper loaded: security_helper
INFO - 2024-02-07 06:11:09 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:11:09 --> Database Driver Class Initialized
INFO - 2024-02-07 06:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:11:09 --> Parser Class Initialized
INFO - 2024-02-07 06:11:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:11:09 --> Pagination Class Initialized
INFO - 2024-02-07 06:11:09 --> Form Validation Class Initialized
INFO - 2024-02-07 06:11:09 --> Controller Class Initialized
DEBUG - 2024-02-07 06:11:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:11:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:09 --> Model Class Initialized
DEBUG - 2024-02-07 06:11:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:09 --> Model Class Initialized
INFO - 2024-02-07 06:11:09 --> Final output sent to browser
DEBUG - 2024-02-07 06:11:09 --> Total execution time: 0.0395
ERROR - 2024-02-07 06:11:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:11:10 --> Config Class Initialized
INFO - 2024-02-07 06:11:10 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:11:10 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:11:10 --> Utf8 Class Initialized
INFO - 2024-02-07 06:11:10 --> URI Class Initialized
INFO - 2024-02-07 06:11:10 --> Router Class Initialized
INFO - 2024-02-07 06:11:10 --> Output Class Initialized
INFO - 2024-02-07 06:11:10 --> Security Class Initialized
DEBUG - 2024-02-07 06:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:11:10 --> Input Class Initialized
INFO - 2024-02-07 06:11:10 --> Language Class Initialized
INFO - 2024-02-07 06:11:10 --> Loader Class Initialized
INFO - 2024-02-07 06:11:10 --> Helper loaded: url_helper
INFO - 2024-02-07 06:11:10 --> Helper loaded: file_helper
INFO - 2024-02-07 06:11:10 --> Helper loaded: html_helper
INFO - 2024-02-07 06:11:10 --> Helper loaded: text_helper
INFO - 2024-02-07 06:11:10 --> Helper loaded: form_helper
INFO - 2024-02-07 06:11:10 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:11:10 --> Helper loaded: security_helper
INFO - 2024-02-07 06:11:10 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:11:10 --> Database Driver Class Initialized
INFO - 2024-02-07 06:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:11:10 --> Parser Class Initialized
INFO - 2024-02-07 06:11:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:11:10 --> Pagination Class Initialized
INFO - 2024-02-07 06:11:10 --> Form Validation Class Initialized
INFO - 2024-02-07 06:11:10 --> Controller Class Initialized
DEBUG - 2024-02-07 06:11:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:11:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:10 --> Model Class Initialized
DEBUG - 2024-02-07 06:11:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:10 --> Model Class Initialized
INFO - 2024-02-07 06:11:10 --> Final output sent to browser
DEBUG - 2024-02-07 06:11:10 --> Total execution time: 0.0220
ERROR - 2024-02-07 06:11:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:11:11 --> Config Class Initialized
INFO - 2024-02-07 06:11:11 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:11:11 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:11:11 --> Utf8 Class Initialized
INFO - 2024-02-07 06:11:11 --> URI Class Initialized
INFO - 2024-02-07 06:11:11 --> Router Class Initialized
INFO - 2024-02-07 06:11:11 --> Output Class Initialized
INFO - 2024-02-07 06:11:11 --> Security Class Initialized
DEBUG - 2024-02-07 06:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:11:11 --> Input Class Initialized
INFO - 2024-02-07 06:11:11 --> Language Class Initialized
INFO - 2024-02-07 06:11:11 --> Loader Class Initialized
INFO - 2024-02-07 06:11:11 --> Helper loaded: url_helper
INFO - 2024-02-07 06:11:11 --> Helper loaded: file_helper
INFO - 2024-02-07 06:11:11 --> Helper loaded: html_helper
INFO - 2024-02-07 06:11:11 --> Helper loaded: text_helper
INFO - 2024-02-07 06:11:11 --> Helper loaded: form_helper
INFO - 2024-02-07 06:11:11 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:11:11 --> Helper loaded: security_helper
INFO - 2024-02-07 06:11:11 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:11:11 --> Database Driver Class Initialized
INFO - 2024-02-07 06:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:11:11 --> Parser Class Initialized
INFO - 2024-02-07 06:11:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:11:11 --> Pagination Class Initialized
INFO - 2024-02-07 06:11:11 --> Form Validation Class Initialized
INFO - 2024-02-07 06:11:11 --> Controller Class Initialized
DEBUG - 2024-02-07 06:11:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:11:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:11 --> Model Class Initialized
DEBUG - 2024-02-07 06:11:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:11 --> Model Class Initialized
INFO - 2024-02-07 06:11:11 --> Final output sent to browser
DEBUG - 2024-02-07 06:11:11 --> Total execution time: 0.0169
ERROR - 2024-02-07 06:11:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:11:12 --> Config Class Initialized
INFO - 2024-02-07 06:11:12 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:11:12 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:11:12 --> Utf8 Class Initialized
INFO - 2024-02-07 06:11:12 --> URI Class Initialized
INFO - 2024-02-07 06:11:12 --> Router Class Initialized
INFO - 2024-02-07 06:11:12 --> Output Class Initialized
INFO - 2024-02-07 06:11:12 --> Security Class Initialized
DEBUG - 2024-02-07 06:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:11:12 --> Input Class Initialized
INFO - 2024-02-07 06:11:12 --> Language Class Initialized
INFO - 2024-02-07 06:11:12 --> Loader Class Initialized
INFO - 2024-02-07 06:11:12 --> Helper loaded: url_helper
INFO - 2024-02-07 06:11:12 --> Helper loaded: file_helper
INFO - 2024-02-07 06:11:12 --> Helper loaded: html_helper
INFO - 2024-02-07 06:11:12 --> Helper loaded: text_helper
INFO - 2024-02-07 06:11:12 --> Helper loaded: form_helper
INFO - 2024-02-07 06:11:12 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:11:12 --> Helper loaded: security_helper
INFO - 2024-02-07 06:11:12 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:11:12 --> Database Driver Class Initialized
INFO - 2024-02-07 06:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:11:12 --> Parser Class Initialized
INFO - 2024-02-07 06:11:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:11:12 --> Pagination Class Initialized
INFO - 2024-02-07 06:11:12 --> Form Validation Class Initialized
INFO - 2024-02-07 06:11:12 --> Controller Class Initialized
DEBUG - 2024-02-07 06:11:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:11:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:12 --> Model Class Initialized
DEBUG - 2024-02-07 06:11:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:12 --> Model Class Initialized
INFO - 2024-02-07 06:11:12 --> Final output sent to browser
DEBUG - 2024-02-07 06:11:12 --> Total execution time: 0.0220
ERROR - 2024-02-07 06:11:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:11:17 --> Config Class Initialized
INFO - 2024-02-07 06:11:17 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:11:17 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:11:17 --> Utf8 Class Initialized
INFO - 2024-02-07 06:11:17 --> URI Class Initialized
INFO - 2024-02-07 06:11:17 --> Router Class Initialized
INFO - 2024-02-07 06:11:17 --> Output Class Initialized
INFO - 2024-02-07 06:11:17 --> Security Class Initialized
DEBUG - 2024-02-07 06:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:11:17 --> Input Class Initialized
INFO - 2024-02-07 06:11:17 --> Language Class Initialized
INFO - 2024-02-07 06:11:17 --> Loader Class Initialized
INFO - 2024-02-07 06:11:17 --> Helper loaded: url_helper
INFO - 2024-02-07 06:11:17 --> Helper loaded: file_helper
INFO - 2024-02-07 06:11:17 --> Helper loaded: html_helper
INFO - 2024-02-07 06:11:17 --> Helper loaded: text_helper
INFO - 2024-02-07 06:11:17 --> Helper loaded: form_helper
INFO - 2024-02-07 06:11:17 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:11:17 --> Helper loaded: security_helper
INFO - 2024-02-07 06:11:17 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:11:17 --> Database Driver Class Initialized
INFO - 2024-02-07 06:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:11:17 --> Parser Class Initialized
INFO - 2024-02-07 06:11:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:11:17 --> Pagination Class Initialized
INFO - 2024-02-07 06:11:17 --> Form Validation Class Initialized
INFO - 2024-02-07 06:11:17 --> Controller Class Initialized
DEBUG - 2024-02-07 06:11:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:11:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:17 --> Model Class Initialized
DEBUG - 2024-02-07 06:11:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:17 --> Model Class Initialized
INFO - 2024-02-07 06:11:17 --> Final output sent to browser
DEBUG - 2024-02-07 06:11:17 --> Total execution time: 0.0462
ERROR - 2024-02-07 06:11:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:11:17 --> Config Class Initialized
INFO - 2024-02-07 06:11:17 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:11:17 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:11:17 --> Utf8 Class Initialized
INFO - 2024-02-07 06:11:17 --> URI Class Initialized
INFO - 2024-02-07 06:11:17 --> Router Class Initialized
INFO - 2024-02-07 06:11:17 --> Output Class Initialized
INFO - 2024-02-07 06:11:17 --> Security Class Initialized
DEBUG - 2024-02-07 06:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:11:17 --> Input Class Initialized
INFO - 2024-02-07 06:11:17 --> Language Class Initialized
INFO - 2024-02-07 06:11:17 --> Loader Class Initialized
INFO - 2024-02-07 06:11:17 --> Helper loaded: url_helper
INFO - 2024-02-07 06:11:17 --> Helper loaded: file_helper
INFO - 2024-02-07 06:11:17 --> Helper loaded: html_helper
INFO - 2024-02-07 06:11:17 --> Helper loaded: text_helper
INFO - 2024-02-07 06:11:17 --> Helper loaded: form_helper
INFO - 2024-02-07 06:11:17 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:11:17 --> Helper loaded: security_helper
INFO - 2024-02-07 06:11:17 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:11:17 --> Database Driver Class Initialized
INFO - 2024-02-07 06:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:11:17 --> Parser Class Initialized
INFO - 2024-02-07 06:11:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:11:17 --> Pagination Class Initialized
INFO - 2024-02-07 06:11:17 --> Form Validation Class Initialized
INFO - 2024-02-07 06:11:17 --> Controller Class Initialized
DEBUG - 2024-02-07 06:11:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:11:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:17 --> Model Class Initialized
DEBUG - 2024-02-07 06:11:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:17 --> Model Class Initialized
INFO - 2024-02-07 06:11:17 --> Final output sent to browser
DEBUG - 2024-02-07 06:11:17 --> Total execution time: 0.1824
ERROR - 2024-02-07 06:11:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:11:19 --> Config Class Initialized
INFO - 2024-02-07 06:11:19 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:11:19 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:11:19 --> Utf8 Class Initialized
INFO - 2024-02-07 06:11:19 --> URI Class Initialized
INFO - 2024-02-07 06:11:19 --> Router Class Initialized
INFO - 2024-02-07 06:11:19 --> Output Class Initialized
INFO - 2024-02-07 06:11:19 --> Security Class Initialized
DEBUG - 2024-02-07 06:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:11:19 --> Input Class Initialized
INFO - 2024-02-07 06:11:19 --> Language Class Initialized
INFO - 2024-02-07 06:11:19 --> Loader Class Initialized
INFO - 2024-02-07 06:11:19 --> Helper loaded: url_helper
INFO - 2024-02-07 06:11:19 --> Helper loaded: file_helper
INFO - 2024-02-07 06:11:19 --> Helper loaded: html_helper
INFO - 2024-02-07 06:11:19 --> Helper loaded: text_helper
INFO - 2024-02-07 06:11:19 --> Helper loaded: form_helper
INFO - 2024-02-07 06:11:19 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:11:19 --> Helper loaded: security_helper
INFO - 2024-02-07 06:11:19 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:11:19 --> Database Driver Class Initialized
INFO - 2024-02-07 06:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:11:19 --> Parser Class Initialized
INFO - 2024-02-07 06:11:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:11:19 --> Pagination Class Initialized
INFO - 2024-02-07 06:11:19 --> Form Validation Class Initialized
INFO - 2024-02-07 06:11:19 --> Controller Class Initialized
DEBUG - 2024-02-07 06:11:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:11:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:19 --> Model Class Initialized
DEBUG - 2024-02-07 06:11:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:19 --> Model Class Initialized
INFO - 2024-02-07 06:11:19 --> Final output sent to browser
DEBUG - 2024-02-07 06:11:19 --> Total execution time: 0.1842
ERROR - 2024-02-07 06:11:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:11:20 --> Config Class Initialized
INFO - 2024-02-07 06:11:20 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:11:20 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:11:20 --> Utf8 Class Initialized
INFO - 2024-02-07 06:11:20 --> URI Class Initialized
INFO - 2024-02-07 06:11:20 --> Router Class Initialized
INFO - 2024-02-07 06:11:20 --> Output Class Initialized
INFO - 2024-02-07 06:11:20 --> Security Class Initialized
DEBUG - 2024-02-07 06:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:11:20 --> Input Class Initialized
INFO - 2024-02-07 06:11:20 --> Language Class Initialized
INFO - 2024-02-07 06:11:20 --> Loader Class Initialized
INFO - 2024-02-07 06:11:20 --> Helper loaded: url_helper
INFO - 2024-02-07 06:11:20 --> Helper loaded: file_helper
INFO - 2024-02-07 06:11:20 --> Helper loaded: html_helper
INFO - 2024-02-07 06:11:20 --> Helper loaded: text_helper
INFO - 2024-02-07 06:11:20 --> Helper loaded: form_helper
INFO - 2024-02-07 06:11:20 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:11:20 --> Helper loaded: security_helper
INFO - 2024-02-07 06:11:20 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:11:20 --> Database Driver Class Initialized
INFO - 2024-02-07 06:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:11:20 --> Parser Class Initialized
INFO - 2024-02-07 06:11:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:11:20 --> Pagination Class Initialized
INFO - 2024-02-07 06:11:20 --> Form Validation Class Initialized
INFO - 2024-02-07 06:11:20 --> Controller Class Initialized
DEBUG - 2024-02-07 06:11:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:11:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:20 --> Model Class Initialized
DEBUG - 2024-02-07 06:11:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:20 --> Model Class Initialized
INFO - 2024-02-07 06:11:20 --> Final output sent to browser
DEBUG - 2024-02-07 06:11:20 --> Total execution time: 0.1889
ERROR - 2024-02-07 06:11:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:11:21 --> Config Class Initialized
INFO - 2024-02-07 06:11:21 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:11:21 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:11:21 --> Utf8 Class Initialized
INFO - 2024-02-07 06:11:21 --> URI Class Initialized
INFO - 2024-02-07 06:11:21 --> Router Class Initialized
INFO - 2024-02-07 06:11:21 --> Output Class Initialized
INFO - 2024-02-07 06:11:21 --> Security Class Initialized
DEBUG - 2024-02-07 06:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:11:21 --> Input Class Initialized
INFO - 2024-02-07 06:11:21 --> Language Class Initialized
INFO - 2024-02-07 06:11:21 --> Loader Class Initialized
INFO - 2024-02-07 06:11:21 --> Helper loaded: url_helper
INFO - 2024-02-07 06:11:21 --> Helper loaded: file_helper
INFO - 2024-02-07 06:11:21 --> Helper loaded: html_helper
INFO - 2024-02-07 06:11:21 --> Helper loaded: text_helper
INFO - 2024-02-07 06:11:21 --> Helper loaded: form_helper
INFO - 2024-02-07 06:11:21 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:11:21 --> Helper loaded: security_helper
INFO - 2024-02-07 06:11:21 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:11:21 --> Database Driver Class Initialized
INFO - 2024-02-07 06:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:11:21 --> Parser Class Initialized
INFO - 2024-02-07 06:11:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:11:21 --> Pagination Class Initialized
INFO - 2024-02-07 06:11:21 --> Form Validation Class Initialized
INFO - 2024-02-07 06:11:21 --> Controller Class Initialized
DEBUG - 2024-02-07 06:11:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:11:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:21 --> Model Class Initialized
DEBUG - 2024-02-07 06:11:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:21 --> Model Class Initialized
INFO - 2024-02-07 06:11:21 --> Final output sent to browser
DEBUG - 2024-02-07 06:11:21 --> Total execution time: 0.1661
ERROR - 2024-02-07 06:11:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:11:21 --> Config Class Initialized
INFO - 2024-02-07 06:11:21 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:11:21 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:11:21 --> Utf8 Class Initialized
INFO - 2024-02-07 06:11:21 --> URI Class Initialized
INFO - 2024-02-07 06:11:21 --> Router Class Initialized
INFO - 2024-02-07 06:11:21 --> Output Class Initialized
INFO - 2024-02-07 06:11:21 --> Security Class Initialized
DEBUG - 2024-02-07 06:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:11:21 --> Input Class Initialized
INFO - 2024-02-07 06:11:21 --> Language Class Initialized
INFO - 2024-02-07 06:11:21 --> Loader Class Initialized
INFO - 2024-02-07 06:11:22 --> Helper loaded: url_helper
INFO - 2024-02-07 06:11:22 --> Helper loaded: file_helper
INFO - 2024-02-07 06:11:22 --> Helper loaded: html_helper
INFO - 2024-02-07 06:11:22 --> Helper loaded: text_helper
INFO - 2024-02-07 06:11:22 --> Helper loaded: form_helper
INFO - 2024-02-07 06:11:22 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:11:22 --> Helper loaded: security_helper
INFO - 2024-02-07 06:11:22 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:11:22 --> Database Driver Class Initialized
INFO - 2024-02-07 06:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:11:22 --> Parser Class Initialized
INFO - 2024-02-07 06:11:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:11:22 --> Pagination Class Initialized
INFO - 2024-02-07 06:11:22 --> Form Validation Class Initialized
INFO - 2024-02-07 06:11:22 --> Controller Class Initialized
DEBUG - 2024-02-07 06:11:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:11:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:22 --> Model Class Initialized
DEBUG - 2024-02-07 06:11:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:22 --> Model Class Initialized
INFO - 2024-02-07 06:11:22 --> Final output sent to browser
DEBUG - 2024-02-07 06:11:22 --> Total execution time: 0.0730
ERROR - 2024-02-07 06:11:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:11:22 --> Config Class Initialized
INFO - 2024-02-07 06:11:22 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:11:22 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:11:22 --> Utf8 Class Initialized
INFO - 2024-02-07 06:11:22 --> URI Class Initialized
INFO - 2024-02-07 06:11:22 --> Router Class Initialized
INFO - 2024-02-07 06:11:22 --> Output Class Initialized
INFO - 2024-02-07 06:11:22 --> Security Class Initialized
DEBUG - 2024-02-07 06:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:11:22 --> Input Class Initialized
INFO - 2024-02-07 06:11:22 --> Language Class Initialized
INFO - 2024-02-07 06:11:22 --> Loader Class Initialized
INFO - 2024-02-07 06:11:22 --> Helper loaded: url_helper
INFO - 2024-02-07 06:11:22 --> Helper loaded: file_helper
INFO - 2024-02-07 06:11:22 --> Helper loaded: html_helper
INFO - 2024-02-07 06:11:22 --> Helper loaded: text_helper
INFO - 2024-02-07 06:11:22 --> Helper loaded: form_helper
INFO - 2024-02-07 06:11:22 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:11:22 --> Helper loaded: security_helper
INFO - 2024-02-07 06:11:22 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:11:22 --> Database Driver Class Initialized
INFO - 2024-02-07 06:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:11:22 --> Parser Class Initialized
INFO - 2024-02-07 06:11:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:11:22 --> Pagination Class Initialized
INFO - 2024-02-07 06:11:22 --> Form Validation Class Initialized
INFO - 2024-02-07 06:11:22 --> Controller Class Initialized
DEBUG - 2024-02-07 06:11:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:11:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:22 --> Model Class Initialized
DEBUG - 2024-02-07 06:11:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:22 --> Model Class Initialized
INFO - 2024-02-07 06:11:22 --> Final output sent to browser
DEBUG - 2024-02-07 06:11:22 --> Total execution time: 0.0298
ERROR - 2024-02-07 06:11:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:11:22 --> Config Class Initialized
INFO - 2024-02-07 06:11:22 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:11:22 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:11:22 --> Utf8 Class Initialized
INFO - 2024-02-07 06:11:22 --> URI Class Initialized
INFO - 2024-02-07 06:11:22 --> Router Class Initialized
INFO - 2024-02-07 06:11:22 --> Output Class Initialized
INFO - 2024-02-07 06:11:22 --> Security Class Initialized
DEBUG - 2024-02-07 06:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:11:22 --> Input Class Initialized
INFO - 2024-02-07 06:11:22 --> Language Class Initialized
INFO - 2024-02-07 06:11:22 --> Loader Class Initialized
INFO - 2024-02-07 06:11:22 --> Helper loaded: url_helper
INFO - 2024-02-07 06:11:22 --> Helper loaded: file_helper
INFO - 2024-02-07 06:11:22 --> Helper loaded: html_helper
INFO - 2024-02-07 06:11:22 --> Helper loaded: text_helper
INFO - 2024-02-07 06:11:22 --> Helper loaded: form_helper
INFO - 2024-02-07 06:11:22 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:11:22 --> Helper loaded: security_helper
INFO - 2024-02-07 06:11:22 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:11:22 --> Database Driver Class Initialized
INFO - 2024-02-07 06:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:11:22 --> Parser Class Initialized
INFO - 2024-02-07 06:11:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:11:22 --> Pagination Class Initialized
INFO - 2024-02-07 06:11:22 --> Form Validation Class Initialized
INFO - 2024-02-07 06:11:22 --> Controller Class Initialized
DEBUG - 2024-02-07 06:11:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:11:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:22 --> Model Class Initialized
DEBUG - 2024-02-07 06:11:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:22 --> Model Class Initialized
INFO - 2024-02-07 06:11:22 --> Final output sent to browser
DEBUG - 2024-02-07 06:11:22 --> Total execution time: 0.0268
ERROR - 2024-02-07 06:11:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:11:23 --> Config Class Initialized
INFO - 2024-02-07 06:11:23 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:11:23 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:11:23 --> Utf8 Class Initialized
INFO - 2024-02-07 06:11:23 --> URI Class Initialized
INFO - 2024-02-07 06:11:23 --> Router Class Initialized
INFO - 2024-02-07 06:11:23 --> Output Class Initialized
INFO - 2024-02-07 06:11:23 --> Security Class Initialized
DEBUG - 2024-02-07 06:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:11:23 --> Input Class Initialized
INFO - 2024-02-07 06:11:23 --> Language Class Initialized
INFO - 2024-02-07 06:11:23 --> Loader Class Initialized
INFO - 2024-02-07 06:11:23 --> Helper loaded: url_helper
INFO - 2024-02-07 06:11:23 --> Helper loaded: file_helper
INFO - 2024-02-07 06:11:23 --> Helper loaded: html_helper
INFO - 2024-02-07 06:11:23 --> Helper loaded: text_helper
INFO - 2024-02-07 06:11:23 --> Helper loaded: form_helper
INFO - 2024-02-07 06:11:23 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:11:23 --> Helper loaded: security_helper
INFO - 2024-02-07 06:11:23 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:11:23 --> Database Driver Class Initialized
INFO - 2024-02-07 06:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:11:23 --> Parser Class Initialized
INFO - 2024-02-07 06:11:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:11:23 --> Pagination Class Initialized
INFO - 2024-02-07 06:11:23 --> Form Validation Class Initialized
INFO - 2024-02-07 06:11:23 --> Controller Class Initialized
DEBUG - 2024-02-07 06:11:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:11:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:23 --> Model Class Initialized
DEBUG - 2024-02-07 06:11:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:23 --> Model Class Initialized
INFO - 2024-02-07 06:11:23 --> Final output sent to browser
DEBUG - 2024-02-07 06:11:23 --> Total execution time: 0.0263
ERROR - 2024-02-07 06:11:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:11:23 --> Config Class Initialized
INFO - 2024-02-07 06:11:23 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:11:23 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:11:23 --> Utf8 Class Initialized
INFO - 2024-02-07 06:11:23 --> URI Class Initialized
INFO - 2024-02-07 06:11:23 --> Router Class Initialized
INFO - 2024-02-07 06:11:23 --> Output Class Initialized
INFO - 2024-02-07 06:11:23 --> Security Class Initialized
DEBUG - 2024-02-07 06:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:11:23 --> Input Class Initialized
INFO - 2024-02-07 06:11:23 --> Language Class Initialized
INFO - 2024-02-07 06:11:23 --> Loader Class Initialized
INFO - 2024-02-07 06:11:23 --> Helper loaded: url_helper
INFO - 2024-02-07 06:11:23 --> Helper loaded: file_helper
INFO - 2024-02-07 06:11:23 --> Helper loaded: html_helper
INFO - 2024-02-07 06:11:23 --> Helper loaded: text_helper
INFO - 2024-02-07 06:11:23 --> Helper loaded: form_helper
INFO - 2024-02-07 06:11:23 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:11:23 --> Helper loaded: security_helper
INFO - 2024-02-07 06:11:23 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:11:23 --> Database Driver Class Initialized
INFO - 2024-02-07 06:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:11:23 --> Parser Class Initialized
INFO - 2024-02-07 06:11:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:11:23 --> Pagination Class Initialized
INFO - 2024-02-07 06:11:23 --> Form Validation Class Initialized
INFO - 2024-02-07 06:11:23 --> Controller Class Initialized
DEBUG - 2024-02-07 06:11:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:11:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:23 --> Model Class Initialized
DEBUG - 2024-02-07 06:11:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:23 --> Model Class Initialized
INFO - 2024-02-07 06:11:23 --> Final output sent to browser
DEBUG - 2024-02-07 06:11:23 --> Total execution time: 0.0224
ERROR - 2024-02-07 06:11:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:11:31 --> Config Class Initialized
INFO - 2024-02-07 06:11:31 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:11:31 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:11:31 --> Utf8 Class Initialized
INFO - 2024-02-07 06:11:31 --> URI Class Initialized
INFO - 2024-02-07 06:11:31 --> Router Class Initialized
INFO - 2024-02-07 06:11:31 --> Output Class Initialized
INFO - 2024-02-07 06:11:31 --> Security Class Initialized
DEBUG - 2024-02-07 06:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:11:31 --> Input Class Initialized
INFO - 2024-02-07 06:11:31 --> Language Class Initialized
INFO - 2024-02-07 06:11:31 --> Loader Class Initialized
INFO - 2024-02-07 06:11:31 --> Helper loaded: url_helper
INFO - 2024-02-07 06:11:31 --> Helper loaded: file_helper
INFO - 2024-02-07 06:11:31 --> Helper loaded: html_helper
INFO - 2024-02-07 06:11:31 --> Helper loaded: text_helper
INFO - 2024-02-07 06:11:31 --> Helper loaded: form_helper
INFO - 2024-02-07 06:11:31 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:11:31 --> Helper loaded: security_helper
INFO - 2024-02-07 06:11:31 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:11:31 --> Database Driver Class Initialized
INFO - 2024-02-07 06:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:11:31 --> Parser Class Initialized
INFO - 2024-02-07 06:11:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:11:31 --> Pagination Class Initialized
INFO - 2024-02-07 06:11:31 --> Form Validation Class Initialized
INFO - 2024-02-07 06:11:31 --> Controller Class Initialized
DEBUG - 2024-02-07 06:11:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:11:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:31 --> Model Class Initialized
DEBUG - 2024-02-07 06:11:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:31 --> Model Class Initialized
INFO - 2024-02-07 06:11:31 --> Final output sent to browser
DEBUG - 2024-02-07 06:11:31 --> Total execution time: 0.0179
ERROR - 2024-02-07 06:11:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:11:34 --> Config Class Initialized
INFO - 2024-02-07 06:11:34 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:11:34 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:11:34 --> Utf8 Class Initialized
INFO - 2024-02-07 06:11:34 --> URI Class Initialized
INFO - 2024-02-07 06:11:34 --> Router Class Initialized
INFO - 2024-02-07 06:11:34 --> Output Class Initialized
INFO - 2024-02-07 06:11:34 --> Security Class Initialized
DEBUG - 2024-02-07 06:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:11:34 --> Input Class Initialized
INFO - 2024-02-07 06:11:34 --> Language Class Initialized
INFO - 2024-02-07 06:11:34 --> Loader Class Initialized
INFO - 2024-02-07 06:11:34 --> Helper loaded: url_helper
INFO - 2024-02-07 06:11:34 --> Helper loaded: file_helper
INFO - 2024-02-07 06:11:34 --> Helper loaded: html_helper
INFO - 2024-02-07 06:11:34 --> Helper loaded: text_helper
INFO - 2024-02-07 06:11:34 --> Helper loaded: form_helper
INFO - 2024-02-07 06:11:34 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:11:34 --> Helper loaded: security_helper
INFO - 2024-02-07 06:11:34 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:11:34 --> Database Driver Class Initialized
INFO - 2024-02-07 06:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:11:34 --> Parser Class Initialized
INFO - 2024-02-07 06:11:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:11:34 --> Pagination Class Initialized
INFO - 2024-02-07 06:11:34 --> Form Validation Class Initialized
INFO - 2024-02-07 06:11:34 --> Controller Class Initialized
DEBUG - 2024-02-07 06:11:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:11:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:34 --> Model Class Initialized
DEBUG - 2024-02-07 06:11:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:34 --> Model Class Initialized
INFO - 2024-02-07 06:11:34 --> Final output sent to browser
DEBUG - 2024-02-07 06:11:34 --> Total execution time: 0.0226
ERROR - 2024-02-07 06:11:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:11:35 --> Config Class Initialized
INFO - 2024-02-07 06:11:35 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:11:35 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:11:35 --> Utf8 Class Initialized
INFO - 2024-02-07 06:11:35 --> URI Class Initialized
INFO - 2024-02-07 06:11:35 --> Router Class Initialized
INFO - 2024-02-07 06:11:35 --> Output Class Initialized
INFO - 2024-02-07 06:11:35 --> Security Class Initialized
DEBUG - 2024-02-07 06:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:11:35 --> Input Class Initialized
INFO - 2024-02-07 06:11:35 --> Language Class Initialized
INFO - 2024-02-07 06:11:35 --> Loader Class Initialized
INFO - 2024-02-07 06:11:35 --> Helper loaded: url_helper
INFO - 2024-02-07 06:11:35 --> Helper loaded: file_helper
INFO - 2024-02-07 06:11:35 --> Helper loaded: html_helper
INFO - 2024-02-07 06:11:35 --> Helper loaded: text_helper
INFO - 2024-02-07 06:11:35 --> Helper loaded: form_helper
INFO - 2024-02-07 06:11:35 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:11:35 --> Helper loaded: security_helper
INFO - 2024-02-07 06:11:35 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:11:35 --> Database Driver Class Initialized
INFO - 2024-02-07 06:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:11:35 --> Parser Class Initialized
INFO - 2024-02-07 06:11:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:11:35 --> Pagination Class Initialized
INFO - 2024-02-07 06:11:35 --> Form Validation Class Initialized
INFO - 2024-02-07 06:11:35 --> Controller Class Initialized
DEBUG - 2024-02-07 06:11:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:11:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:35 --> Model Class Initialized
DEBUG - 2024-02-07 06:11:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:35 --> Model Class Initialized
INFO - 2024-02-07 06:11:35 --> Final output sent to browser
DEBUG - 2024-02-07 06:11:35 --> Total execution time: 0.0307
ERROR - 2024-02-07 06:11:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:11:35 --> Config Class Initialized
INFO - 2024-02-07 06:11:35 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:11:35 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:11:35 --> Utf8 Class Initialized
INFO - 2024-02-07 06:11:35 --> URI Class Initialized
INFO - 2024-02-07 06:11:35 --> Router Class Initialized
INFO - 2024-02-07 06:11:35 --> Output Class Initialized
INFO - 2024-02-07 06:11:35 --> Security Class Initialized
DEBUG - 2024-02-07 06:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:11:35 --> Input Class Initialized
INFO - 2024-02-07 06:11:35 --> Language Class Initialized
INFO - 2024-02-07 06:11:35 --> Loader Class Initialized
INFO - 2024-02-07 06:11:35 --> Helper loaded: url_helper
INFO - 2024-02-07 06:11:35 --> Helper loaded: file_helper
INFO - 2024-02-07 06:11:35 --> Helper loaded: html_helper
INFO - 2024-02-07 06:11:35 --> Helper loaded: text_helper
INFO - 2024-02-07 06:11:35 --> Helper loaded: form_helper
INFO - 2024-02-07 06:11:35 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:11:35 --> Helper loaded: security_helper
INFO - 2024-02-07 06:11:35 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:11:35 --> Database Driver Class Initialized
INFO - 2024-02-07 06:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:11:35 --> Parser Class Initialized
INFO - 2024-02-07 06:11:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:11:35 --> Pagination Class Initialized
INFO - 2024-02-07 06:11:35 --> Form Validation Class Initialized
INFO - 2024-02-07 06:11:35 --> Controller Class Initialized
DEBUG - 2024-02-07 06:11:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:11:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:35 --> Model Class Initialized
DEBUG - 2024-02-07 06:11:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:35 --> Model Class Initialized
INFO - 2024-02-07 06:11:35 --> Final output sent to browser
DEBUG - 2024-02-07 06:11:35 --> Total execution time: 0.1835
ERROR - 2024-02-07 06:11:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:11:36 --> Config Class Initialized
INFO - 2024-02-07 06:11:36 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:11:36 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:11:36 --> Utf8 Class Initialized
INFO - 2024-02-07 06:11:36 --> URI Class Initialized
INFO - 2024-02-07 06:11:36 --> Router Class Initialized
INFO - 2024-02-07 06:11:36 --> Output Class Initialized
INFO - 2024-02-07 06:11:36 --> Security Class Initialized
DEBUG - 2024-02-07 06:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:11:36 --> Input Class Initialized
INFO - 2024-02-07 06:11:36 --> Language Class Initialized
INFO - 2024-02-07 06:11:36 --> Loader Class Initialized
INFO - 2024-02-07 06:11:36 --> Helper loaded: url_helper
INFO - 2024-02-07 06:11:36 --> Helper loaded: file_helper
INFO - 2024-02-07 06:11:36 --> Helper loaded: html_helper
INFO - 2024-02-07 06:11:36 --> Helper loaded: text_helper
INFO - 2024-02-07 06:11:36 --> Helper loaded: form_helper
INFO - 2024-02-07 06:11:36 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:11:36 --> Helper loaded: security_helper
INFO - 2024-02-07 06:11:36 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:11:36 --> Database Driver Class Initialized
INFO - 2024-02-07 06:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:11:36 --> Parser Class Initialized
INFO - 2024-02-07 06:11:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:11:36 --> Pagination Class Initialized
INFO - 2024-02-07 06:11:36 --> Form Validation Class Initialized
INFO - 2024-02-07 06:11:36 --> Controller Class Initialized
DEBUG - 2024-02-07 06:11:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:11:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:36 --> Model Class Initialized
DEBUG - 2024-02-07 06:11:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:36 --> Model Class Initialized
INFO - 2024-02-07 06:11:37 --> Final output sent to browser
DEBUG - 2024-02-07 06:11:37 --> Total execution time: 0.1633
ERROR - 2024-02-07 06:11:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:11:37 --> Config Class Initialized
INFO - 2024-02-07 06:11:37 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:11:37 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:11:37 --> Utf8 Class Initialized
INFO - 2024-02-07 06:11:37 --> URI Class Initialized
INFO - 2024-02-07 06:11:37 --> Router Class Initialized
INFO - 2024-02-07 06:11:37 --> Output Class Initialized
INFO - 2024-02-07 06:11:37 --> Security Class Initialized
DEBUG - 2024-02-07 06:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:11:37 --> Input Class Initialized
INFO - 2024-02-07 06:11:37 --> Language Class Initialized
INFO - 2024-02-07 06:11:37 --> Loader Class Initialized
INFO - 2024-02-07 06:11:37 --> Helper loaded: url_helper
INFO - 2024-02-07 06:11:37 --> Helper loaded: file_helper
INFO - 2024-02-07 06:11:37 --> Helper loaded: html_helper
INFO - 2024-02-07 06:11:37 --> Helper loaded: text_helper
INFO - 2024-02-07 06:11:37 --> Helper loaded: form_helper
INFO - 2024-02-07 06:11:37 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:11:37 --> Helper loaded: security_helper
INFO - 2024-02-07 06:11:37 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:11:37 --> Database Driver Class Initialized
INFO - 2024-02-07 06:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:11:37 --> Parser Class Initialized
INFO - 2024-02-07 06:11:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:11:37 --> Pagination Class Initialized
INFO - 2024-02-07 06:11:37 --> Form Validation Class Initialized
INFO - 2024-02-07 06:11:37 --> Controller Class Initialized
DEBUG - 2024-02-07 06:11:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:11:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:37 --> Model Class Initialized
DEBUG - 2024-02-07 06:11:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:37 --> Model Class Initialized
INFO - 2024-02-07 06:11:37 --> Final output sent to browser
DEBUG - 2024-02-07 06:11:37 --> Total execution time: 0.0721
ERROR - 2024-02-07 06:11:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:11:37 --> Config Class Initialized
INFO - 2024-02-07 06:11:37 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:11:37 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:11:37 --> Utf8 Class Initialized
INFO - 2024-02-07 06:11:37 --> URI Class Initialized
INFO - 2024-02-07 06:11:37 --> Router Class Initialized
INFO - 2024-02-07 06:11:37 --> Output Class Initialized
INFO - 2024-02-07 06:11:37 --> Security Class Initialized
DEBUG - 2024-02-07 06:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:11:37 --> Input Class Initialized
INFO - 2024-02-07 06:11:37 --> Language Class Initialized
INFO - 2024-02-07 06:11:37 --> Loader Class Initialized
INFO - 2024-02-07 06:11:37 --> Helper loaded: url_helper
INFO - 2024-02-07 06:11:37 --> Helper loaded: file_helper
INFO - 2024-02-07 06:11:37 --> Helper loaded: html_helper
INFO - 2024-02-07 06:11:37 --> Helper loaded: text_helper
INFO - 2024-02-07 06:11:37 --> Helper loaded: form_helper
INFO - 2024-02-07 06:11:37 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:11:37 --> Helper loaded: security_helper
INFO - 2024-02-07 06:11:37 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:11:37 --> Database Driver Class Initialized
INFO - 2024-02-07 06:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:11:37 --> Parser Class Initialized
INFO - 2024-02-07 06:11:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:11:37 --> Pagination Class Initialized
INFO - 2024-02-07 06:11:37 --> Form Validation Class Initialized
INFO - 2024-02-07 06:11:37 --> Controller Class Initialized
DEBUG - 2024-02-07 06:11:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:11:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:37 --> Model Class Initialized
DEBUG - 2024-02-07 06:11:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:37 --> Model Class Initialized
INFO - 2024-02-07 06:11:37 --> Final output sent to browser
DEBUG - 2024-02-07 06:11:37 --> Total execution time: 0.0311
ERROR - 2024-02-07 06:11:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:11:38 --> Config Class Initialized
INFO - 2024-02-07 06:11:38 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:11:38 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:11:38 --> Utf8 Class Initialized
INFO - 2024-02-07 06:11:38 --> URI Class Initialized
INFO - 2024-02-07 06:11:38 --> Router Class Initialized
INFO - 2024-02-07 06:11:38 --> Output Class Initialized
INFO - 2024-02-07 06:11:38 --> Security Class Initialized
DEBUG - 2024-02-07 06:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:11:38 --> Input Class Initialized
INFO - 2024-02-07 06:11:38 --> Language Class Initialized
INFO - 2024-02-07 06:11:38 --> Loader Class Initialized
INFO - 2024-02-07 06:11:38 --> Helper loaded: url_helper
INFO - 2024-02-07 06:11:38 --> Helper loaded: file_helper
INFO - 2024-02-07 06:11:38 --> Helper loaded: html_helper
INFO - 2024-02-07 06:11:38 --> Helper loaded: text_helper
INFO - 2024-02-07 06:11:38 --> Helper loaded: form_helper
INFO - 2024-02-07 06:11:38 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:11:38 --> Helper loaded: security_helper
INFO - 2024-02-07 06:11:38 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:11:38 --> Database Driver Class Initialized
INFO - 2024-02-07 06:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:11:38 --> Parser Class Initialized
INFO - 2024-02-07 06:11:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:11:38 --> Pagination Class Initialized
INFO - 2024-02-07 06:11:38 --> Form Validation Class Initialized
INFO - 2024-02-07 06:11:38 --> Controller Class Initialized
DEBUG - 2024-02-07 06:11:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:11:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:38 --> Model Class Initialized
DEBUG - 2024-02-07 06:11:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:38 --> Model Class Initialized
INFO - 2024-02-07 06:11:38 --> Final output sent to browser
DEBUG - 2024-02-07 06:11:38 --> Total execution time: 0.0268
ERROR - 2024-02-07 06:11:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:11:38 --> Config Class Initialized
INFO - 2024-02-07 06:11:38 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:11:38 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:11:38 --> Utf8 Class Initialized
INFO - 2024-02-07 06:11:38 --> URI Class Initialized
INFO - 2024-02-07 06:11:38 --> Router Class Initialized
INFO - 2024-02-07 06:11:38 --> Output Class Initialized
INFO - 2024-02-07 06:11:38 --> Security Class Initialized
DEBUG - 2024-02-07 06:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:11:38 --> Input Class Initialized
INFO - 2024-02-07 06:11:38 --> Language Class Initialized
INFO - 2024-02-07 06:11:38 --> Loader Class Initialized
INFO - 2024-02-07 06:11:38 --> Helper loaded: url_helper
INFO - 2024-02-07 06:11:38 --> Helper loaded: file_helper
INFO - 2024-02-07 06:11:38 --> Helper loaded: html_helper
INFO - 2024-02-07 06:11:38 --> Helper loaded: text_helper
INFO - 2024-02-07 06:11:38 --> Helper loaded: form_helper
INFO - 2024-02-07 06:11:38 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:11:38 --> Helper loaded: security_helper
INFO - 2024-02-07 06:11:38 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:11:38 --> Database Driver Class Initialized
INFO - 2024-02-07 06:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:11:38 --> Parser Class Initialized
INFO - 2024-02-07 06:11:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:11:38 --> Pagination Class Initialized
INFO - 2024-02-07 06:11:38 --> Form Validation Class Initialized
INFO - 2024-02-07 06:11:38 --> Controller Class Initialized
DEBUG - 2024-02-07 06:11:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:11:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:38 --> Model Class Initialized
DEBUG - 2024-02-07 06:11:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:38 --> Model Class Initialized
INFO - 2024-02-07 06:11:38 --> Final output sent to browser
DEBUG - 2024-02-07 06:11:38 --> Total execution time: 0.0226
ERROR - 2024-02-07 06:11:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:11:39 --> Config Class Initialized
INFO - 2024-02-07 06:11:39 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:11:39 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:11:39 --> Utf8 Class Initialized
INFO - 2024-02-07 06:11:39 --> URI Class Initialized
INFO - 2024-02-07 06:11:39 --> Router Class Initialized
INFO - 2024-02-07 06:11:39 --> Output Class Initialized
INFO - 2024-02-07 06:11:39 --> Security Class Initialized
DEBUG - 2024-02-07 06:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:11:39 --> Input Class Initialized
INFO - 2024-02-07 06:11:39 --> Language Class Initialized
INFO - 2024-02-07 06:11:39 --> Loader Class Initialized
INFO - 2024-02-07 06:11:39 --> Helper loaded: url_helper
INFO - 2024-02-07 06:11:39 --> Helper loaded: file_helper
INFO - 2024-02-07 06:11:39 --> Helper loaded: html_helper
INFO - 2024-02-07 06:11:39 --> Helper loaded: text_helper
INFO - 2024-02-07 06:11:39 --> Helper loaded: form_helper
INFO - 2024-02-07 06:11:39 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:11:39 --> Helper loaded: security_helper
INFO - 2024-02-07 06:11:39 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:11:39 --> Database Driver Class Initialized
INFO - 2024-02-07 06:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:11:39 --> Parser Class Initialized
INFO - 2024-02-07 06:11:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:11:39 --> Pagination Class Initialized
INFO - 2024-02-07 06:11:39 --> Form Validation Class Initialized
INFO - 2024-02-07 06:11:39 --> Controller Class Initialized
DEBUG - 2024-02-07 06:11:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:11:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:39 --> Model Class Initialized
DEBUG - 2024-02-07 06:11:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:39 --> Model Class Initialized
INFO - 2024-02-07 06:11:39 --> Final output sent to browser
DEBUG - 2024-02-07 06:11:39 --> Total execution time: 0.0167
ERROR - 2024-02-07 06:11:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:11:39 --> Config Class Initialized
INFO - 2024-02-07 06:11:39 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:11:39 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:11:39 --> Utf8 Class Initialized
INFO - 2024-02-07 06:11:39 --> URI Class Initialized
INFO - 2024-02-07 06:11:39 --> Router Class Initialized
INFO - 2024-02-07 06:11:39 --> Output Class Initialized
INFO - 2024-02-07 06:11:39 --> Security Class Initialized
DEBUG - 2024-02-07 06:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:11:39 --> Input Class Initialized
INFO - 2024-02-07 06:11:39 --> Language Class Initialized
INFO - 2024-02-07 06:11:39 --> Loader Class Initialized
INFO - 2024-02-07 06:11:39 --> Helper loaded: url_helper
INFO - 2024-02-07 06:11:39 --> Helper loaded: file_helper
INFO - 2024-02-07 06:11:39 --> Helper loaded: html_helper
INFO - 2024-02-07 06:11:39 --> Helper loaded: text_helper
INFO - 2024-02-07 06:11:39 --> Helper loaded: form_helper
INFO - 2024-02-07 06:11:39 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:11:39 --> Helper loaded: security_helper
INFO - 2024-02-07 06:11:39 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:11:39 --> Database Driver Class Initialized
INFO - 2024-02-07 06:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:11:39 --> Parser Class Initialized
INFO - 2024-02-07 06:11:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:11:39 --> Pagination Class Initialized
INFO - 2024-02-07 06:11:39 --> Form Validation Class Initialized
INFO - 2024-02-07 06:11:39 --> Controller Class Initialized
DEBUG - 2024-02-07 06:11:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:11:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:39 --> Model Class Initialized
DEBUG - 2024-02-07 06:11:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:39 --> Model Class Initialized
INFO - 2024-02-07 06:11:39 --> Final output sent to browser
DEBUG - 2024-02-07 06:11:39 --> Total execution time: 0.0175
ERROR - 2024-02-07 06:11:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:11:40 --> Config Class Initialized
INFO - 2024-02-07 06:11:40 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:11:40 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:11:40 --> Utf8 Class Initialized
INFO - 2024-02-07 06:11:40 --> URI Class Initialized
INFO - 2024-02-07 06:11:40 --> Router Class Initialized
INFO - 2024-02-07 06:11:40 --> Output Class Initialized
INFO - 2024-02-07 06:11:40 --> Security Class Initialized
DEBUG - 2024-02-07 06:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:11:40 --> Input Class Initialized
INFO - 2024-02-07 06:11:40 --> Language Class Initialized
INFO - 2024-02-07 06:11:40 --> Loader Class Initialized
INFO - 2024-02-07 06:11:40 --> Helper loaded: url_helper
INFO - 2024-02-07 06:11:40 --> Helper loaded: file_helper
INFO - 2024-02-07 06:11:40 --> Helper loaded: html_helper
INFO - 2024-02-07 06:11:40 --> Helper loaded: text_helper
INFO - 2024-02-07 06:11:40 --> Helper loaded: form_helper
INFO - 2024-02-07 06:11:40 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:11:40 --> Helper loaded: security_helper
INFO - 2024-02-07 06:11:40 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:11:40 --> Database Driver Class Initialized
INFO - 2024-02-07 06:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:11:40 --> Parser Class Initialized
INFO - 2024-02-07 06:11:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:11:40 --> Pagination Class Initialized
INFO - 2024-02-07 06:11:40 --> Form Validation Class Initialized
INFO - 2024-02-07 06:11:40 --> Controller Class Initialized
DEBUG - 2024-02-07 06:11:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:11:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:40 --> Model Class Initialized
DEBUG - 2024-02-07 06:11:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:40 --> Model Class Initialized
INFO - 2024-02-07 06:11:40 --> Final output sent to browser
DEBUG - 2024-02-07 06:11:40 --> Total execution time: 0.0166
ERROR - 2024-02-07 06:11:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:11:41 --> Config Class Initialized
INFO - 2024-02-07 06:11:41 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:11:41 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:11:41 --> Utf8 Class Initialized
INFO - 2024-02-07 06:11:41 --> URI Class Initialized
INFO - 2024-02-07 06:11:41 --> Router Class Initialized
INFO - 2024-02-07 06:11:41 --> Output Class Initialized
INFO - 2024-02-07 06:11:41 --> Security Class Initialized
DEBUG - 2024-02-07 06:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:11:41 --> Input Class Initialized
INFO - 2024-02-07 06:11:41 --> Language Class Initialized
INFO - 2024-02-07 06:11:41 --> Loader Class Initialized
INFO - 2024-02-07 06:11:41 --> Helper loaded: url_helper
INFO - 2024-02-07 06:11:41 --> Helper loaded: file_helper
INFO - 2024-02-07 06:11:41 --> Helper loaded: html_helper
INFO - 2024-02-07 06:11:41 --> Helper loaded: text_helper
INFO - 2024-02-07 06:11:41 --> Helper loaded: form_helper
INFO - 2024-02-07 06:11:41 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:11:41 --> Helper loaded: security_helper
INFO - 2024-02-07 06:11:41 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:11:41 --> Database Driver Class Initialized
INFO - 2024-02-07 06:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:11:41 --> Parser Class Initialized
INFO - 2024-02-07 06:11:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:11:41 --> Pagination Class Initialized
INFO - 2024-02-07 06:11:41 --> Form Validation Class Initialized
INFO - 2024-02-07 06:11:41 --> Controller Class Initialized
DEBUG - 2024-02-07 06:11:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:11:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:41 --> Model Class Initialized
DEBUG - 2024-02-07 06:11:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:41 --> Model Class Initialized
INFO - 2024-02-07 06:11:41 --> Final output sent to browser
DEBUG - 2024-02-07 06:11:41 --> Total execution time: 0.0174
ERROR - 2024-02-07 06:11:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:11:42 --> Config Class Initialized
INFO - 2024-02-07 06:11:42 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:11:42 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:11:42 --> Utf8 Class Initialized
INFO - 2024-02-07 06:11:42 --> URI Class Initialized
INFO - 2024-02-07 06:11:42 --> Router Class Initialized
INFO - 2024-02-07 06:11:42 --> Output Class Initialized
INFO - 2024-02-07 06:11:42 --> Security Class Initialized
DEBUG - 2024-02-07 06:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:11:42 --> Input Class Initialized
INFO - 2024-02-07 06:11:42 --> Language Class Initialized
INFO - 2024-02-07 06:11:42 --> Loader Class Initialized
INFO - 2024-02-07 06:11:42 --> Helper loaded: url_helper
INFO - 2024-02-07 06:11:42 --> Helper loaded: file_helper
INFO - 2024-02-07 06:11:42 --> Helper loaded: html_helper
INFO - 2024-02-07 06:11:42 --> Helper loaded: text_helper
INFO - 2024-02-07 06:11:42 --> Helper loaded: form_helper
INFO - 2024-02-07 06:11:42 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:11:42 --> Helper loaded: security_helper
INFO - 2024-02-07 06:11:42 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:11:42 --> Database Driver Class Initialized
INFO - 2024-02-07 06:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:11:42 --> Parser Class Initialized
INFO - 2024-02-07 06:11:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:11:42 --> Pagination Class Initialized
INFO - 2024-02-07 06:11:42 --> Form Validation Class Initialized
INFO - 2024-02-07 06:11:42 --> Controller Class Initialized
DEBUG - 2024-02-07 06:11:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:11:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:42 --> Model Class Initialized
DEBUG - 2024-02-07 06:11:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:42 --> Model Class Initialized
INFO - 2024-02-07 06:11:42 --> Final output sent to browser
DEBUG - 2024-02-07 06:11:42 --> Total execution time: 0.0179
ERROR - 2024-02-07 06:11:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:11:42 --> Config Class Initialized
INFO - 2024-02-07 06:11:42 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:11:42 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:11:42 --> Utf8 Class Initialized
INFO - 2024-02-07 06:11:42 --> URI Class Initialized
INFO - 2024-02-07 06:11:42 --> Router Class Initialized
INFO - 2024-02-07 06:11:42 --> Output Class Initialized
INFO - 2024-02-07 06:11:42 --> Security Class Initialized
DEBUG - 2024-02-07 06:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:11:42 --> Input Class Initialized
INFO - 2024-02-07 06:11:42 --> Language Class Initialized
INFO - 2024-02-07 06:11:42 --> Loader Class Initialized
INFO - 2024-02-07 06:11:42 --> Helper loaded: url_helper
INFO - 2024-02-07 06:11:42 --> Helper loaded: file_helper
INFO - 2024-02-07 06:11:42 --> Helper loaded: html_helper
INFO - 2024-02-07 06:11:42 --> Helper loaded: text_helper
INFO - 2024-02-07 06:11:42 --> Helper loaded: form_helper
INFO - 2024-02-07 06:11:42 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:11:42 --> Helper loaded: security_helper
INFO - 2024-02-07 06:11:42 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:11:42 --> Database Driver Class Initialized
INFO - 2024-02-07 06:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:11:42 --> Parser Class Initialized
INFO - 2024-02-07 06:11:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:11:42 --> Pagination Class Initialized
INFO - 2024-02-07 06:11:42 --> Form Validation Class Initialized
INFO - 2024-02-07 06:11:42 --> Controller Class Initialized
DEBUG - 2024-02-07 06:11:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:11:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:42 --> Model Class Initialized
DEBUG - 2024-02-07 06:11:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:42 --> Model Class Initialized
INFO - 2024-02-07 06:11:42 --> Final output sent to browser
DEBUG - 2024-02-07 06:11:42 --> Total execution time: 0.0173
ERROR - 2024-02-07 06:11:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:11:43 --> Config Class Initialized
INFO - 2024-02-07 06:11:43 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:11:43 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:11:43 --> Utf8 Class Initialized
INFO - 2024-02-07 06:11:43 --> URI Class Initialized
INFO - 2024-02-07 06:11:43 --> Router Class Initialized
INFO - 2024-02-07 06:11:43 --> Output Class Initialized
INFO - 2024-02-07 06:11:43 --> Security Class Initialized
DEBUG - 2024-02-07 06:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:11:43 --> Input Class Initialized
INFO - 2024-02-07 06:11:43 --> Language Class Initialized
INFO - 2024-02-07 06:11:43 --> Loader Class Initialized
INFO - 2024-02-07 06:11:43 --> Helper loaded: url_helper
INFO - 2024-02-07 06:11:43 --> Helper loaded: file_helper
INFO - 2024-02-07 06:11:43 --> Helper loaded: html_helper
INFO - 2024-02-07 06:11:43 --> Helper loaded: text_helper
INFO - 2024-02-07 06:11:43 --> Helper loaded: form_helper
INFO - 2024-02-07 06:11:43 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:11:43 --> Helper loaded: security_helper
INFO - 2024-02-07 06:11:43 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:11:43 --> Database Driver Class Initialized
INFO - 2024-02-07 06:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:11:43 --> Parser Class Initialized
INFO - 2024-02-07 06:11:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:11:43 --> Pagination Class Initialized
INFO - 2024-02-07 06:11:43 --> Form Validation Class Initialized
INFO - 2024-02-07 06:11:43 --> Controller Class Initialized
DEBUG - 2024-02-07 06:11:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:11:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:43 --> Model Class Initialized
DEBUG - 2024-02-07 06:11:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:43 --> Model Class Initialized
INFO - 2024-02-07 06:11:43 --> Final output sent to browser
DEBUG - 2024-02-07 06:11:43 --> Total execution time: 0.0221
ERROR - 2024-02-07 06:11:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:11:45 --> Config Class Initialized
INFO - 2024-02-07 06:11:45 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:11:45 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:11:45 --> Utf8 Class Initialized
INFO - 2024-02-07 06:11:45 --> URI Class Initialized
INFO - 2024-02-07 06:11:45 --> Router Class Initialized
INFO - 2024-02-07 06:11:45 --> Output Class Initialized
INFO - 2024-02-07 06:11:45 --> Security Class Initialized
DEBUG - 2024-02-07 06:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:11:45 --> Input Class Initialized
INFO - 2024-02-07 06:11:45 --> Language Class Initialized
INFO - 2024-02-07 06:11:45 --> Loader Class Initialized
INFO - 2024-02-07 06:11:45 --> Helper loaded: url_helper
INFO - 2024-02-07 06:11:45 --> Helper loaded: file_helper
INFO - 2024-02-07 06:11:45 --> Helper loaded: html_helper
INFO - 2024-02-07 06:11:45 --> Helper loaded: text_helper
INFO - 2024-02-07 06:11:45 --> Helper loaded: form_helper
INFO - 2024-02-07 06:11:45 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:11:45 --> Helper loaded: security_helper
INFO - 2024-02-07 06:11:45 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:11:45 --> Database Driver Class Initialized
INFO - 2024-02-07 06:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:11:45 --> Parser Class Initialized
INFO - 2024-02-07 06:11:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:11:45 --> Pagination Class Initialized
INFO - 2024-02-07 06:11:45 --> Form Validation Class Initialized
INFO - 2024-02-07 06:11:45 --> Controller Class Initialized
DEBUG - 2024-02-07 06:11:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:11:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:45 --> Model Class Initialized
DEBUG - 2024-02-07 06:11:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:45 --> Model Class Initialized
INFO - 2024-02-07 06:11:45 --> Final output sent to browser
DEBUG - 2024-02-07 06:11:45 --> Total execution time: 0.0264
ERROR - 2024-02-07 06:11:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:11:45 --> Config Class Initialized
INFO - 2024-02-07 06:11:45 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:11:45 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:11:45 --> Utf8 Class Initialized
INFO - 2024-02-07 06:11:45 --> URI Class Initialized
INFO - 2024-02-07 06:11:45 --> Router Class Initialized
INFO - 2024-02-07 06:11:45 --> Output Class Initialized
INFO - 2024-02-07 06:11:45 --> Security Class Initialized
DEBUG - 2024-02-07 06:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:11:45 --> Input Class Initialized
INFO - 2024-02-07 06:11:45 --> Language Class Initialized
INFO - 2024-02-07 06:11:45 --> Loader Class Initialized
INFO - 2024-02-07 06:11:45 --> Helper loaded: url_helper
INFO - 2024-02-07 06:11:45 --> Helper loaded: file_helper
INFO - 2024-02-07 06:11:45 --> Helper loaded: html_helper
INFO - 2024-02-07 06:11:45 --> Helper loaded: text_helper
INFO - 2024-02-07 06:11:45 --> Helper loaded: form_helper
INFO - 2024-02-07 06:11:45 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:11:45 --> Helper loaded: security_helper
INFO - 2024-02-07 06:11:45 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:11:45 --> Database Driver Class Initialized
INFO - 2024-02-07 06:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:11:45 --> Parser Class Initialized
INFO - 2024-02-07 06:11:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:11:45 --> Pagination Class Initialized
INFO - 2024-02-07 06:11:45 --> Form Validation Class Initialized
INFO - 2024-02-07 06:11:45 --> Controller Class Initialized
DEBUG - 2024-02-07 06:11:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:11:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:45 --> Model Class Initialized
DEBUG - 2024-02-07 06:11:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:45 --> Model Class Initialized
INFO - 2024-02-07 06:11:45 --> Final output sent to browser
DEBUG - 2024-02-07 06:11:45 --> Total execution time: 0.0265
ERROR - 2024-02-07 06:11:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:11:45 --> Config Class Initialized
INFO - 2024-02-07 06:11:45 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:11:45 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:11:45 --> Utf8 Class Initialized
INFO - 2024-02-07 06:11:45 --> URI Class Initialized
INFO - 2024-02-07 06:11:45 --> Router Class Initialized
INFO - 2024-02-07 06:11:45 --> Output Class Initialized
INFO - 2024-02-07 06:11:45 --> Security Class Initialized
DEBUG - 2024-02-07 06:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:11:45 --> Input Class Initialized
INFO - 2024-02-07 06:11:45 --> Language Class Initialized
INFO - 2024-02-07 06:11:45 --> Loader Class Initialized
INFO - 2024-02-07 06:11:45 --> Helper loaded: url_helper
INFO - 2024-02-07 06:11:45 --> Helper loaded: file_helper
INFO - 2024-02-07 06:11:45 --> Helper loaded: html_helper
INFO - 2024-02-07 06:11:45 --> Helper loaded: text_helper
INFO - 2024-02-07 06:11:45 --> Helper loaded: form_helper
INFO - 2024-02-07 06:11:45 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:11:45 --> Helper loaded: security_helper
INFO - 2024-02-07 06:11:45 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:11:45 --> Database Driver Class Initialized
INFO - 2024-02-07 06:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:11:45 --> Parser Class Initialized
INFO - 2024-02-07 06:11:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:11:45 --> Pagination Class Initialized
INFO - 2024-02-07 06:11:45 --> Form Validation Class Initialized
INFO - 2024-02-07 06:11:45 --> Controller Class Initialized
DEBUG - 2024-02-07 06:11:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:11:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:45 --> Model Class Initialized
DEBUG - 2024-02-07 06:11:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:45 --> Model Class Initialized
INFO - 2024-02-07 06:11:45 --> Final output sent to browser
DEBUG - 2024-02-07 06:11:45 --> Total execution time: 0.0854
ERROR - 2024-02-07 06:11:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:11:46 --> Config Class Initialized
INFO - 2024-02-07 06:11:46 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:11:46 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:11:46 --> Utf8 Class Initialized
INFO - 2024-02-07 06:11:46 --> URI Class Initialized
INFO - 2024-02-07 06:11:46 --> Router Class Initialized
INFO - 2024-02-07 06:11:46 --> Output Class Initialized
INFO - 2024-02-07 06:11:46 --> Security Class Initialized
DEBUG - 2024-02-07 06:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:11:46 --> Input Class Initialized
INFO - 2024-02-07 06:11:46 --> Language Class Initialized
INFO - 2024-02-07 06:11:46 --> Loader Class Initialized
INFO - 2024-02-07 06:11:46 --> Helper loaded: url_helper
INFO - 2024-02-07 06:11:46 --> Helper loaded: file_helper
INFO - 2024-02-07 06:11:46 --> Helper loaded: html_helper
INFO - 2024-02-07 06:11:46 --> Helper loaded: text_helper
INFO - 2024-02-07 06:11:46 --> Helper loaded: form_helper
INFO - 2024-02-07 06:11:46 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:11:46 --> Helper loaded: security_helper
INFO - 2024-02-07 06:11:46 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:11:46 --> Database Driver Class Initialized
INFO - 2024-02-07 06:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:11:46 --> Parser Class Initialized
INFO - 2024-02-07 06:11:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:11:46 --> Pagination Class Initialized
INFO - 2024-02-07 06:11:46 --> Form Validation Class Initialized
INFO - 2024-02-07 06:11:46 --> Controller Class Initialized
DEBUG - 2024-02-07 06:11:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:11:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:46 --> Model Class Initialized
DEBUG - 2024-02-07 06:11:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:46 --> Model Class Initialized
INFO - 2024-02-07 06:11:46 --> Final output sent to browser
DEBUG - 2024-02-07 06:11:46 --> Total execution time: 0.1823
ERROR - 2024-02-07 06:11:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:11:47 --> Config Class Initialized
INFO - 2024-02-07 06:11:47 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:11:47 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:11:47 --> Utf8 Class Initialized
INFO - 2024-02-07 06:11:47 --> URI Class Initialized
INFO - 2024-02-07 06:11:47 --> Router Class Initialized
INFO - 2024-02-07 06:11:47 --> Output Class Initialized
INFO - 2024-02-07 06:11:47 --> Security Class Initialized
DEBUG - 2024-02-07 06:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:11:47 --> Input Class Initialized
INFO - 2024-02-07 06:11:47 --> Language Class Initialized
INFO - 2024-02-07 06:11:47 --> Loader Class Initialized
INFO - 2024-02-07 06:11:47 --> Helper loaded: url_helper
INFO - 2024-02-07 06:11:47 --> Helper loaded: file_helper
INFO - 2024-02-07 06:11:47 --> Helper loaded: html_helper
INFO - 2024-02-07 06:11:47 --> Helper loaded: text_helper
INFO - 2024-02-07 06:11:47 --> Helper loaded: form_helper
INFO - 2024-02-07 06:11:47 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:11:47 --> Helper loaded: security_helper
INFO - 2024-02-07 06:11:47 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:11:47 --> Database Driver Class Initialized
INFO - 2024-02-07 06:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:11:47 --> Parser Class Initialized
INFO - 2024-02-07 06:11:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:11:47 --> Pagination Class Initialized
INFO - 2024-02-07 06:11:47 --> Form Validation Class Initialized
INFO - 2024-02-07 06:11:47 --> Controller Class Initialized
DEBUG - 2024-02-07 06:11:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:11:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:47 --> Model Class Initialized
DEBUG - 2024-02-07 06:11:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:47 --> Model Class Initialized
INFO - 2024-02-07 06:11:47 --> Final output sent to browser
DEBUG - 2024-02-07 06:11:47 --> Total execution time: 0.0928
ERROR - 2024-02-07 06:11:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:11:48 --> Config Class Initialized
INFO - 2024-02-07 06:11:48 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:11:48 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:11:48 --> Utf8 Class Initialized
INFO - 2024-02-07 06:11:48 --> URI Class Initialized
INFO - 2024-02-07 06:11:48 --> Router Class Initialized
INFO - 2024-02-07 06:11:48 --> Output Class Initialized
INFO - 2024-02-07 06:11:48 --> Security Class Initialized
DEBUG - 2024-02-07 06:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:11:48 --> Input Class Initialized
INFO - 2024-02-07 06:11:48 --> Language Class Initialized
INFO - 2024-02-07 06:11:48 --> Loader Class Initialized
INFO - 2024-02-07 06:11:48 --> Helper loaded: url_helper
INFO - 2024-02-07 06:11:48 --> Helper loaded: file_helper
INFO - 2024-02-07 06:11:48 --> Helper loaded: html_helper
INFO - 2024-02-07 06:11:48 --> Helper loaded: text_helper
INFO - 2024-02-07 06:11:48 --> Helper loaded: form_helper
INFO - 2024-02-07 06:11:48 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:11:48 --> Helper loaded: security_helper
INFO - 2024-02-07 06:11:48 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:11:48 --> Database Driver Class Initialized
INFO - 2024-02-07 06:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:11:48 --> Parser Class Initialized
INFO - 2024-02-07 06:11:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:11:48 --> Pagination Class Initialized
INFO - 2024-02-07 06:11:48 --> Form Validation Class Initialized
INFO - 2024-02-07 06:11:48 --> Controller Class Initialized
DEBUG - 2024-02-07 06:11:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:11:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:48 --> Model Class Initialized
DEBUG - 2024-02-07 06:11:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:48 --> Model Class Initialized
INFO - 2024-02-07 06:11:48 --> Final output sent to browser
DEBUG - 2024-02-07 06:11:48 --> Total execution time: 0.1039
ERROR - 2024-02-07 06:11:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:11:48 --> Config Class Initialized
INFO - 2024-02-07 06:11:48 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:11:48 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:11:48 --> Utf8 Class Initialized
INFO - 2024-02-07 06:11:48 --> URI Class Initialized
INFO - 2024-02-07 06:11:48 --> Router Class Initialized
INFO - 2024-02-07 06:11:48 --> Output Class Initialized
INFO - 2024-02-07 06:11:48 --> Security Class Initialized
DEBUG - 2024-02-07 06:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:11:48 --> Input Class Initialized
INFO - 2024-02-07 06:11:48 --> Language Class Initialized
INFO - 2024-02-07 06:11:48 --> Loader Class Initialized
INFO - 2024-02-07 06:11:48 --> Helper loaded: url_helper
INFO - 2024-02-07 06:11:48 --> Helper loaded: file_helper
INFO - 2024-02-07 06:11:48 --> Helper loaded: html_helper
INFO - 2024-02-07 06:11:48 --> Helper loaded: text_helper
INFO - 2024-02-07 06:11:48 --> Helper loaded: form_helper
INFO - 2024-02-07 06:11:48 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:11:48 --> Helper loaded: security_helper
INFO - 2024-02-07 06:11:48 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:11:48 --> Database Driver Class Initialized
INFO - 2024-02-07 06:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:11:48 --> Parser Class Initialized
INFO - 2024-02-07 06:11:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:11:48 --> Pagination Class Initialized
INFO - 2024-02-07 06:11:48 --> Form Validation Class Initialized
INFO - 2024-02-07 06:11:48 --> Controller Class Initialized
DEBUG - 2024-02-07 06:11:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:11:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:48 --> Model Class Initialized
DEBUG - 2024-02-07 06:11:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:48 --> Model Class Initialized
INFO - 2024-02-07 06:11:48 --> Final output sent to browser
DEBUG - 2024-02-07 06:11:48 --> Total execution time: 0.0251
ERROR - 2024-02-07 06:11:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:11:51 --> Config Class Initialized
INFO - 2024-02-07 06:11:51 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:11:51 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:11:51 --> Utf8 Class Initialized
INFO - 2024-02-07 06:11:51 --> URI Class Initialized
INFO - 2024-02-07 06:11:51 --> Router Class Initialized
INFO - 2024-02-07 06:11:51 --> Output Class Initialized
INFO - 2024-02-07 06:11:51 --> Security Class Initialized
DEBUG - 2024-02-07 06:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:11:51 --> Input Class Initialized
INFO - 2024-02-07 06:11:51 --> Language Class Initialized
INFO - 2024-02-07 06:11:51 --> Loader Class Initialized
INFO - 2024-02-07 06:11:51 --> Helper loaded: url_helper
INFO - 2024-02-07 06:11:51 --> Helper loaded: file_helper
INFO - 2024-02-07 06:11:51 --> Helper loaded: html_helper
INFO - 2024-02-07 06:11:51 --> Helper loaded: text_helper
INFO - 2024-02-07 06:11:51 --> Helper loaded: form_helper
INFO - 2024-02-07 06:11:51 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:11:51 --> Helper loaded: security_helper
INFO - 2024-02-07 06:11:51 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:11:51 --> Database Driver Class Initialized
INFO - 2024-02-07 06:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:11:51 --> Parser Class Initialized
INFO - 2024-02-07 06:11:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:11:51 --> Pagination Class Initialized
INFO - 2024-02-07 06:11:51 --> Form Validation Class Initialized
INFO - 2024-02-07 06:11:51 --> Controller Class Initialized
DEBUG - 2024-02-07 06:11:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:11:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:51 --> Model Class Initialized
DEBUG - 2024-02-07 06:11:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:51 --> Model Class Initialized
INFO - 2024-02-07 06:11:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/edit_customer_form.php
DEBUG - 2024-02-07 06:11:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:11:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:11:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:11:52 --> Model Class Initialized
INFO - 2024-02-07 06:11:52 --> Model Class Initialized
INFO - 2024-02-07 06:11:52 --> Model Class Initialized
INFO - 2024-02-07 06:11:52 --> Model Class Initialized
INFO - 2024-02-07 06:11:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 06:11:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 06:11:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:11:52 --> Final output sent to browser
DEBUG - 2024-02-07 06:11:52 --> Total execution time: 0.2176
ERROR - 2024-02-07 06:27:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:27:37 --> Config Class Initialized
INFO - 2024-02-07 06:27:37 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:27:37 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:27:37 --> Utf8 Class Initialized
INFO - 2024-02-07 06:27:37 --> URI Class Initialized
INFO - 2024-02-07 06:27:37 --> Router Class Initialized
INFO - 2024-02-07 06:27:37 --> Output Class Initialized
INFO - 2024-02-07 06:27:37 --> Security Class Initialized
DEBUG - 2024-02-07 06:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:27:37 --> Input Class Initialized
INFO - 2024-02-07 06:27:37 --> Language Class Initialized
INFO - 2024-02-07 06:27:37 --> Loader Class Initialized
INFO - 2024-02-07 06:27:37 --> Helper loaded: url_helper
INFO - 2024-02-07 06:27:37 --> Helper loaded: file_helper
INFO - 2024-02-07 06:27:37 --> Helper loaded: html_helper
INFO - 2024-02-07 06:27:37 --> Helper loaded: text_helper
INFO - 2024-02-07 06:27:37 --> Helper loaded: form_helper
INFO - 2024-02-07 06:27:37 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:27:37 --> Helper loaded: security_helper
INFO - 2024-02-07 06:27:37 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:27:37 --> Database Driver Class Initialized
INFO - 2024-02-07 06:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:27:37 --> Parser Class Initialized
INFO - 2024-02-07 06:27:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:27:37 --> Pagination Class Initialized
INFO - 2024-02-07 06:27:37 --> Form Validation Class Initialized
INFO - 2024-02-07 06:27:37 --> Controller Class Initialized
DEBUG - 2024-02-07 06:27:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:27:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:27:37 --> Model Class Initialized
DEBUG - 2024-02-07 06:27:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:27:37 --> Model Class Initialized
ERROR - 2024-02-07 06:27:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:27:38 --> Config Class Initialized
INFO - 2024-02-07 06:27:38 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:27:38 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:27:38 --> Utf8 Class Initialized
INFO - 2024-02-07 06:27:38 --> URI Class Initialized
INFO - 2024-02-07 06:27:38 --> Router Class Initialized
INFO - 2024-02-07 06:27:38 --> Output Class Initialized
INFO - 2024-02-07 06:27:38 --> Security Class Initialized
DEBUG - 2024-02-07 06:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:27:38 --> Input Class Initialized
INFO - 2024-02-07 06:27:38 --> Language Class Initialized
INFO - 2024-02-07 06:27:38 --> Loader Class Initialized
INFO - 2024-02-07 06:27:38 --> Helper loaded: url_helper
INFO - 2024-02-07 06:27:38 --> Helper loaded: file_helper
INFO - 2024-02-07 06:27:38 --> Helper loaded: html_helper
INFO - 2024-02-07 06:27:38 --> Helper loaded: text_helper
INFO - 2024-02-07 06:27:38 --> Helper loaded: form_helper
INFO - 2024-02-07 06:27:38 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:27:38 --> Helper loaded: security_helper
INFO - 2024-02-07 06:27:38 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:27:38 --> Database Driver Class Initialized
INFO - 2024-02-07 06:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:27:38 --> Parser Class Initialized
INFO - 2024-02-07 06:27:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:27:38 --> Pagination Class Initialized
INFO - 2024-02-07 06:27:38 --> Form Validation Class Initialized
INFO - 2024-02-07 06:27:38 --> Controller Class Initialized
DEBUG - 2024-02-07 06:27:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:27:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:27:38 --> Model Class Initialized
DEBUG - 2024-02-07 06:27:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:27:38 --> Model Class Initialized
DEBUG - 2024-02-07 06:27:38 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:27:38 --> Model Class Initialized
INFO - 2024-02-07 06:27:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-07 06:27:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:27:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:27:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:27:38 --> Model Class Initialized
INFO - 2024-02-07 06:27:38 --> Model Class Initialized
INFO - 2024-02-07 06:27:38 --> Model Class Initialized
INFO - 2024-02-07 06:27:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 06:27:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 06:27:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:27:38 --> Final output sent to browser
DEBUG - 2024-02-07 06:27:38 --> Total execution time: 0.2016
ERROR - 2024-02-07 06:27:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:27:40 --> Config Class Initialized
INFO - 2024-02-07 06:27:40 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:27:40 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:27:40 --> Utf8 Class Initialized
INFO - 2024-02-07 06:27:40 --> URI Class Initialized
INFO - 2024-02-07 06:27:40 --> Router Class Initialized
INFO - 2024-02-07 06:27:40 --> Output Class Initialized
INFO - 2024-02-07 06:27:40 --> Security Class Initialized
DEBUG - 2024-02-07 06:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:27:40 --> Input Class Initialized
INFO - 2024-02-07 06:27:40 --> Language Class Initialized
INFO - 2024-02-07 06:27:40 --> Loader Class Initialized
INFO - 2024-02-07 06:27:40 --> Helper loaded: url_helper
INFO - 2024-02-07 06:27:40 --> Helper loaded: file_helper
INFO - 2024-02-07 06:27:40 --> Helper loaded: html_helper
INFO - 2024-02-07 06:27:40 --> Helper loaded: text_helper
INFO - 2024-02-07 06:27:40 --> Helper loaded: form_helper
INFO - 2024-02-07 06:27:40 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:27:40 --> Helper loaded: security_helper
INFO - 2024-02-07 06:27:40 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:27:40 --> Database Driver Class Initialized
INFO - 2024-02-07 06:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:27:40 --> Parser Class Initialized
INFO - 2024-02-07 06:27:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:27:40 --> Pagination Class Initialized
INFO - 2024-02-07 06:27:40 --> Form Validation Class Initialized
INFO - 2024-02-07 06:27:40 --> Controller Class Initialized
DEBUG - 2024-02-07 06:27:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:27:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:27:40 --> Model Class Initialized
DEBUG - 2024-02-07 06:27:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:27:40 --> Model Class Initialized
INFO - 2024-02-07 06:27:40 --> Final output sent to browser
DEBUG - 2024-02-07 06:27:40 --> Total execution time: 0.0302
ERROR - 2024-02-07 06:27:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:27:50 --> Config Class Initialized
INFO - 2024-02-07 06:27:50 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:27:50 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:27:50 --> Utf8 Class Initialized
INFO - 2024-02-07 06:27:50 --> URI Class Initialized
DEBUG - 2024-02-07 06:27:50 --> No URI present. Default controller set.
INFO - 2024-02-07 06:27:50 --> Router Class Initialized
INFO - 2024-02-07 06:27:50 --> Output Class Initialized
INFO - 2024-02-07 06:27:50 --> Security Class Initialized
DEBUG - 2024-02-07 06:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:27:50 --> Input Class Initialized
INFO - 2024-02-07 06:27:50 --> Language Class Initialized
INFO - 2024-02-07 06:27:50 --> Loader Class Initialized
INFO - 2024-02-07 06:27:50 --> Helper loaded: url_helper
INFO - 2024-02-07 06:27:50 --> Helper loaded: file_helper
INFO - 2024-02-07 06:27:50 --> Helper loaded: html_helper
INFO - 2024-02-07 06:27:50 --> Helper loaded: text_helper
INFO - 2024-02-07 06:27:50 --> Helper loaded: form_helper
INFO - 2024-02-07 06:27:50 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:27:50 --> Helper loaded: security_helper
INFO - 2024-02-07 06:27:50 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:27:50 --> Database Driver Class Initialized
INFO - 2024-02-07 06:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:27:50 --> Parser Class Initialized
INFO - 2024-02-07 06:27:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:27:50 --> Pagination Class Initialized
INFO - 2024-02-07 06:27:50 --> Form Validation Class Initialized
INFO - 2024-02-07 06:27:50 --> Controller Class Initialized
INFO - 2024-02-07 06:27:50 --> Model Class Initialized
DEBUG - 2024-02-07 06:27:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-07 06:27:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:27:50 --> Config Class Initialized
INFO - 2024-02-07 06:27:50 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:27:50 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:27:50 --> Utf8 Class Initialized
INFO - 2024-02-07 06:27:50 --> URI Class Initialized
INFO - 2024-02-07 06:27:50 --> Router Class Initialized
INFO - 2024-02-07 06:27:50 --> Output Class Initialized
INFO - 2024-02-07 06:27:50 --> Security Class Initialized
DEBUG - 2024-02-07 06:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:27:50 --> Input Class Initialized
INFO - 2024-02-07 06:27:50 --> Language Class Initialized
INFO - 2024-02-07 06:27:50 --> Loader Class Initialized
INFO - 2024-02-07 06:27:50 --> Helper loaded: url_helper
INFO - 2024-02-07 06:27:50 --> Helper loaded: file_helper
INFO - 2024-02-07 06:27:50 --> Helper loaded: html_helper
INFO - 2024-02-07 06:27:50 --> Helper loaded: text_helper
INFO - 2024-02-07 06:27:50 --> Helper loaded: form_helper
INFO - 2024-02-07 06:27:50 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:27:50 --> Helper loaded: security_helper
INFO - 2024-02-07 06:27:50 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:27:50 --> Database Driver Class Initialized
INFO - 2024-02-07 06:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:27:50 --> Parser Class Initialized
INFO - 2024-02-07 06:27:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:27:50 --> Pagination Class Initialized
INFO - 2024-02-07 06:27:50 --> Form Validation Class Initialized
INFO - 2024-02-07 06:27:50 --> Controller Class Initialized
INFO - 2024-02-07 06:27:50 --> Model Class Initialized
DEBUG - 2024-02-07 06:27:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:27:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-07 06:27:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:27:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:27:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:27:50 --> Model Class Initialized
INFO - 2024-02-07 06:27:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:27:50 --> Final output sent to browser
DEBUG - 2024-02-07 06:27:50 --> Total execution time: 0.2757
ERROR - 2024-02-07 06:27:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:27:57 --> Config Class Initialized
INFO - 2024-02-07 06:27:57 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:27:57 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:27:57 --> Utf8 Class Initialized
INFO - 2024-02-07 06:27:57 --> URI Class Initialized
INFO - 2024-02-07 06:27:57 --> Router Class Initialized
INFO - 2024-02-07 06:27:57 --> Output Class Initialized
INFO - 2024-02-07 06:27:57 --> Security Class Initialized
DEBUG - 2024-02-07 06:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:27:57 --> Input Class Initialized
INFO - 2024-02-07 06:27:57 --> Language Class Initialized
INFO - 2024-02-07 06:27:57 --> Loader Class Initialized
INFO - 2024-02-07 06:27:57 --> Helper loaded: url_helper
INFO - 2024-02-07 06:27:57 --> Helper loaded: file_helper
INFO - 2024-02-07 06:27:57 --> Helper loaded: html_helper
INFO - 2024-02-07 06:27:57 --> Helper loaded: text_helper
INFO - 2024-02-07 06:27:57 --> Helper loaded: form_helper
INFO - 2024-02-07 06:27:57 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:27:57 --> Helper loaded: security_helper
INFO - 2024-02-07 06:27:57 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:27:57 --> Database Driver Class Initialized
INFO - 2024-02-07 06:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:27:57 --> Parser Class Initialized
INFO - 2024-02-07 06:27:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:27:57 --> Pagination Class Initialized
INFO - 2024-02-07 06:27:57 --> Form Validation Class Initialized
INFO - 2024-02-07 06:27:57 --> Controller Class Initialized
DEBUG - 2024-02-07 06:27:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:27:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:27:57 --> Model Class Initialized
DEBUG - 2024-02-07 06:27:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:27:57 --> Model Class Initialized
INFO - 2024-02-07 06:27:57 --> Final output sent to browser
DEBUG - 2024-02-07 06:27:57 --> Total execution time: 0.0300
ERROR - 2024-02-07 06:27:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:27:57 --> Config Class Initialized
INFO - 2024-02-07 06:27:57 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:27:57 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:27:57 --> Utf8 Class Initialized
INFO - 2024-02-07 06:27:57 --> URI Class Initialized
INFO - 2024-02-07 06:27:57 --> Router Class Initialized
INFO - 2024-02-07 06:27:57 --> Output Class Initialized
INFO - 2024-02-07 06:27:57 --> Security Class Initialized
DEBUG - 2024-02-07 06:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:27:57 --> Input Class Initialized
INFO - 2024-02-07 06:27:57 --> Language Class Initialized
INFO - 2024-02-07 06:27:57 --> Loader Class Initialized
INFO - 2024-02-07 06:27:57 --> Helper loaded: url_helper
INFO - 2024-02-07 06:27:57 --> Helper loaded: file_helper
INFO - 2024-02-07 06:27:57 --> Helper loaded: html_helper
INFO - 2024-02-07 06:27:57 --> Helper loaded: text_helper
INFO - 2024-02-07 06:27:57 --> Helper loaded: form_helper
INFO - 2024-02-07 06:27:57 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:27:57 --> Helper loaded: security_helper
INFO - 2024-02-07 06:27:57 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:27:57 --> Database Driver Class Initialized
INFO - 2024-02-07 06:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:27:57 --> Parser Class Initialized
INFO - 2024-02-07 06:27:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:27:57 --> Pagination Class Initialized
INFO - 2024-02-07 06:27:57 --> Form Validation Class Initialized
INFO - 2024-02-07 06:27:57 --> Controller Class Initialized
DEBUG - 2024-02-07 06:27:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:27:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:27:57 --> Model Class Initialized
DEBUG - 2024-02-07 06:27:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:27:57 --> Model Class Initialized
INFO - 2024-02-07 06:27:57 --> Final output sent to browser
DEBUG - 2024-02-07 06:27:57 --> Total execution time: 0.0171
ERROR - 2024-02-07 06:27:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:27:58 --> Config Class Initialized
INFO - 2024-02-07 06:27:58 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:27:58 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:27:58 --> Utf8 Class Initialized
INFO - 2024-02-07 06:27:58 --> URI Class Initialized
INFO - 2024-02-07 06:27:58 --> Router Class Initialized
INFO - 2024-02-07 06:27:58 --> Output Class Initialized
INFO - 2024-02-07 06:27:58 --> Security Class Initialized
DEBUG - 2024-02-07 06:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:27:58 --> Input Class Initialized
INFO - 2024-02-07 06:27:58 --> Language Class Initialized
INFO - 2024-02-07 06:27:58 --> Loader Class Initialized
INFO - 2024-02-07 06:27:58 --> Helper loaded: url_helper
INFO - 2024-02-07 06:27:58 --> Helper loaded: file_helper
INFO - 2024-02-07 06:27:58 --> Helper loaded: html_helper
INFO - 2024-02-07 06:27:58 --> Helper loaded: text_helper
INFO - 2024-02-07 06:27:58 --> Helper loaded: form_helper
INFO - 2024-02-07 06:27:58 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:27:58 --> Helper loaded: security_helper
INFO - 2024-02-07 06:27:58 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:27:58 --> Database Driver Class Initialized
INFO - 2024-02-07 06:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:27:58 --> Parser Class Initialized
INFO - 2024-02-07 06:27:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:27:58 --> Pagination Class Initialized
INFO - 2024-02-07 06:27:58 --> Form Validation Class Initialized
INFO - 2024-02-07 06:27:58 --> Controller Class Initialized
DEBUG - 2024-02-07 06:27:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:27:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:27:58 --> Model Class Initialized
DEBUG - 2024-02-07 06:27:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:27:58 --> Model Class Initialized
INFO - 2024-02-07 06:27:58 --> Final output sent to browser
DEBUG - 2024-02-07 06:27:58 --> Total execution time: 0.0161
ERROR - 2024-02-07 06:27:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:27:59 --> Config Class Initialized
INFO - 2024-02-07 06:27:59 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:27:59 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:27:59 --> Utf8 Class Initialized
INFO - 2024-02-07 06:27:59 --> URI Class Initialized
INFO - 2024-02-07 06:27:59 --> Router Class Initialized
INFO - 2024-02-07 06:27:59 --> Output Class Initialized
INFO - 2024-02-07 06:27:59 --> Security Class Initialized
DEBUG - 2024-02-07 06:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:27:59 --> Input Class Initialized
INFO - 2024-02-07 06:27:59 --> Language Class Initialized
INFO - 2024-02-07 06:27:59 --> Loader Class Initialized
INFO - 2024-02-07 06:27:59 --> Helper loaded: url_helper
INFO - 2024-02-07 06:27:59 --> Helper loaded: file_helper
INFO - 2024-02-07 06:27:59 --> Helper loaded: html_helper
INFO - 2024-02-07 06:27:59 --> Helper loaded: text_helper
INFO - 2024-02-07 06:27:59 --> Helper loaded: form_helper
INFO - 2024-02-07 06:27:59 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:27:59 --> Helper loaded: security_helper
INFO - 2024-02-07 06:27:59 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:27:59 --> Database Driver Class Initialized
INFO - 2024-02-07 06:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:27:59 --> Parser Class Initialized
INFO - 2024-02-07 06:27:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:27:59 --> Pagination Class Initialized
INFO - 2024-02-07 06:27:59 --> Form Validation Class Initialized
INFO - 2024-02-07 06:27:59 --> Controller Class Initialized
DEBUG - 2024-02-07 06:27:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:27:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:27:59 --> Model Class Initialized
DEBUG - 2024-02-07 06:27:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:27:59 --> Model Class Initialized
INFO - 2024-02-07 06:27:59 --> Final output sent to browser
DEBUG - 2024-02-07 06:27:59 --> Total execution time: 0.0169
ERROR - 2024-02-07 06:27:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:27:59 --> Config Class Initialized
INFO - 2024-02-07 06:27:59 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:27:59 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:27:59 --> Utf8 Class Initialized
INFO - 2024-02-07 06:27:59 --> URI Class Initialized
INFO - 2024-02-07 06:27:59 --> Router Class Initialized
INFO - 2024-02-07 06:27:59 --> Output Class Initialized
INFO - 2024-02-07 06:27:59 --> Security Class Initialized
DEBUG - 2024-02-07 06:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:27:59 --> Input Class Initialized
INFO - 2024-02-07 06:27:59 --> Language Class Initialized
INFO - 2024-02-07 06:27:59 --> Loader Class Initialized
INFO - 2024-02-07 06:27:59 --> Helper loaded: url_helper
INFO - 2024-02-07 06:27:59 --> Helper loaded: file_helper
INFO - 2024-02-07 06:27:59 --> Helper loaded: html_helper
INFO - 2024-02-07 06:27:59 --> Helper loaded: text_helper
INFO - 2024-02-07 06:27:59 --> Helper loaded: form_helper
INFO - 2024-02-07 06:27:59 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:27:59 --> Helper loaded: security_helper
INFO - 2024-02-07 06:27:59 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:27:59 --> Database Driver Class Initialized
INFO - 2024-02-07 06:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:27:59 --> Parser Class Initialized
INFO - 2024-02-07 06:27:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:27:59 --> Pagination Class Initialized
INFO - 2024-02-07 06:27:59 --> Form Validation Class Initialized
INFO - 2024-02-07 06:27:59 --> Controller Class Initialized
DEBUG - 2024-02-07 06:27:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:27:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:27:59 --> Model Class Initialized
DEBUG - 2024-02-07 06:27:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:27:59 --> Model Class Initialized
INFO - 2024-02-07 06:27:59 --> Final output sent to browser
DEBUG - 2024-02-07 06:27:59 --> Total execution time: 0.0294
ERROR - 2024-02-07 06:28:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:28:00 --> Config Class Initialized
INFO - 2024-02-07 06:28:00 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:28:00 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:28:00 --> Utf8 Class Initialized
INFO - 2024-02-07 06:28:00 --> URI Class Initialized
INFO - 2024-02-07 06:28:00 --> Router Class Initialized
INFO - 2024-02-07 06:28:00 --> Output Class Initialized
INFO - 2024-02-07 06:28:00 --> Security Class Initialized
DEBUG - 2024-02-07 06:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:28:00 --> Input Class Initialized
INFO - 2024-02-07 06:28:00 --> Language Class Initialized
INFO - 2024-02-07 06:28:00 --> Loader Class Initialized
INFO - 2024-02-07 06:28:00 --> Helper loaded: url_helper
INFO - 2024-02-07 06:28:00 --> Helper loaded: file_helper
INFO - 2024-02-07 06:28:00 --> Helper loaded: html_helper
INFO - 2024-02-07 06:28:00 --> Helper loaded: text_helper
INFO - 2024-02-07 06:28:00 --> Helper loaded: form_helper
INFO - 2024-02-07 06:28:00 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:28:00 --> Helper loaded: security_helper
INFO - 2024-02-07 06:28:00 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:28:00 --> Database Driver Class Initialized
INFO - 2024-02-07 06:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:28:00 --> Parser Class Initialized
INFO - 2024-02-07 06:28:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:28:00 --> Pagination Class Initialized
INFO - 2024-02-07 06:28:00 --> Form Validation Class Initialized
INFO - 2024-02-07 06:28:00 --> Controller Class Initialized
DEBUG - 2024-02-07 06:28:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:28:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:00 --> Model Class Initialized
DEBUG - 2024-02-07 06:28:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:00 --> Model Class Initialized
INFO - 2024-02-07 06:28:00 --> Final output sent to browser
DEBUG - 2024-02-07 06:28:00 --> Total execution time: 0.0324
ERROR - 2024-02-07 06:28:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:28:00 --> Config Class Initialized
INFO - 2024-02-07 06:28:00 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:28:00 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:28:00 --> Utf8 Class Initialized
INFO - 2024-02-07 06:28:00 --> URI Class Initialized
INFO - 2024-02-07 06:28:00 --> Router Class Initialized
INFO - 2024-02-07 06:28:00 --> Output Class Initialized
INFO - 2024-02-07 06:28:00 --> Security Class Initialized
DEBUG - 2024-02-07 06:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:28:00 --> Input Class Initialized
INFO - 2024-02-07 06:28:00 --> Language Class Initialized
INFO - 2024-02-07 06:28:00 --> Loader Class Initialized
INFO - 2024-02-07 06:28:00 --> Helper loaded: url_helper
INFO - 2024-02-07 06:28:00 --> Helper loaded: file_helper
INFO - 2024-02-07 06:28:00 --> Helper loaded: html_helper
INFO - 2024-02-07 06:28:00 --> Helper loaded: text_helper
INFO - 2024-02-07 06:28:00 --> Helper loaded: form_helper
INFO - 2024-02-07 06:28:00 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:28:00 --> Helper loaded: security_helper
INFO - 2024-02-07 06:28:00 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:28:00 --> Database Driver Class Initialized
INFO - 2024-02-07 06:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:28:00 --> Parser Class Initialized
INFO - 2024-02-07 06:28:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:28:00 --> Pagination Class Initialized
INFO - 2024-02-07 06:28:00 --> Form Validation Class Initialized
INFO - 2024-02-07 06:28:00 --> Controller Class Initialized
DEBUG - 2024-02-07 06:28:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:28:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:00 --> Model Class Initialized
DEBUG - 2024-02-07 06:28:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:00 --> Model Class Initialized
INFO - 2024-02-07 06:28:00 --> Final output sent to browser
DEBUG - 2024-02-07 06:28:00 --> Total execution time: 0.0305
ERROR - 2024-02-07 06:28:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:28:00 --> Config Class Initialized
INFO - 2024-02-07 06:28:00 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:28:00 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:28:00 --> Utf8 Class Initialized
INFO - 2024-02-07 06:28:00 --> URI Class Initialized
INFO - 2024-02-07 06:28:00 --> Router Class Initialized
INFO - 2024-02-07 06:28:00 --> Output Class Initialized
INFO - 2024-02-07 06:28:00 --> Security Class Initialized
DEBUG - 2024-02-07 06:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:28:00 --> Input Class Initialized
INFO - 2024-02-07 06:28:00 --> Language Class Initialized
INFO - 2024-02-07 06:28:00 --> Loader Class Initialized
INFO - 2024-02-07 06:28:00 --> Helper loaded: url_helper
INFO - 2024-02-07 06:28:00 --> Helper loaded: file_helper
INFO - 2024-02-07 06:28:00 --> Helper loaded: html_helper
INFO - 2024-02-07 06:28:00 --> Helper loaded: text_helper
INFO - 2024-02-07 06:28:00 --> Helper loaded: form_helper
INFO - 2024-02-07 06:28:00 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:28:00 --> Helper loaded: security_helper
INFO - 2024-02-07 06:28:00 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:28:00 --> Database Driver Class Initialized
INFO - 2024-02-07 06:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:28:00 --> Parser Class Initialized
INFO - 2024-02-07 06:28:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:28:00 --> Pagination Class Initialized
INFO - 2024-02-07 06:28:00 --> Form Validation Class Initialized
INFO - 2024-02-07 06:28:00 --> Controller Class Initialized
DEBUG - 2024-02-07 06:28:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:28:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:00 --> Model Class Initialized
DEBUG - 2024-02-07 06:28:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:00 --> Model Class Initialized
INFO - 2024-02-07 06:28:01 --> Final output sent to browser
DEBUG - 2024-02-07 06:28:01 --> Total execution time: 0.0297
ERROR - 2024-02-07 06:28:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:28:01 --> Config Class Initialized
INFO - 2024-02-07 06:28:01 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:28:01 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:28:01 --> Utf8 Class Initialized
INFO - 2024-02-07 06:28:01 --> URI Class Initialized
INFO - 2024-02-07 06:28:01 --> Router Class Initialized
INFO - 2024-02-07 06:28:01 --> Output Class Initialized
INFO - 2024-02-07 06:28:01 --> Security Class Initialized
DEBUG - 2024-02-07 06:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:28:01 --> Input Class Initialized
INFO - 2024-02-07 06:28:01 --> Language Class Initialized
INFO - 2024-02-07 06:28:01 --> Loader Class Initialized
INFO - 2024-02-07 06:28:01 --> Helper loaded: url_helper
INFO - 2024-02-07 06:28:01 --> Helper loaded: file_helper
INFO - 2024-02-07 06:28:01 --> Helper loaded: html_helper
INFO - 2024-02-07 06:28:01 --> Helper loaded: text_helper
INFO - 2024-02-07 06:28:01 --> Helper loaded: form_helper
INFO - 2024-02-07 06:28:01 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:28:01 --> Helper loaded: security_helper
INFO - 2024-02-07 06:28:01 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:28:01 --> Database Driver Class Initialized
INFO - 2024-02-07 06:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:28:01 --> Parser Class Initialized
INFO - 2024-02-07 06:28:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:28:01 --> Pagination Class Initialized
INFO - 2024-02-07 06:28:01 --> Form Validation Class Initialized
INFO - 2024-02-07 06:28:01 --> Controller Class Initialized
DEBUG - 2024-02-07 06:28:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:28:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:01 --> Model Class Initialized
DEBUG - 2024-02-07 06:28:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:01 --> Model Class Initialized
INFO - 2024-02-07 06:28:01 --> Final output sent to browser
DEBUG - 2024-02-07 06:28:01 --> Total execution time: 0.0167
ERROR - 2024-02-07 06:28:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:28:02 --> Config Class Initialized
INFO - 2024-02-07 06:28:02 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:28:02 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:28:02 --> Utf8 Class Initialized
INFO - 2024-02-07 06:28:02 --> URI Class Initialized
INFO - 2024-02-07 06:28:02 --> Router Class Initialized
INFO - 2024-02-07 06:28:02 --> Output Class Initialized
INFO - 2024-02-07 06:28:02 --> Security Class Initialized
DEBUG - 2024-02-07 06:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:28:02 --> Input Class Initialized
INFO - 2024-02-07 06:28:02 --> Language Class Initialized
INFO - 2024-02-07 06:28:02 --> Loader Class Initialized
INFO - 2024-02-07 06:28:02 --> Helper loaded: url_helper
INFO - 2024-02-07 06:28:02 --> Helper loaded: file_helper
INFO - 2024-02-07 06:28:02 --> Helper loaded: html_helper
INFO - 2024-02-07 06:28:02 --> Helper loaded: text_helper
INFO - 2024-02-07 06:28:02 --> Helper loaded: form_helper
INFO - 2024-02-07 06:28:02 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:28:02 --> Helper loaded: security_helper
INFO - 2024-02-07 06:28:02 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:28:02 --> Database Driver Class Initialized
INFO - 2024-02-07 06:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:28:02 --> Parser Class Initialized
INFO - 2024-02-07 06:28:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:28:02 --> Pagination Class Initialized
INFO - 2024-02-07 06:28:02 --> Form Validation Class Initialized
INFO - 2024-02-07 06:28:02 --> Controller Class Initialized
DEBUG - 2024-02-07 06:28:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:28:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:02 --> Model Class Initialized
DEBUG - 2024-02-07 06:28:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:02 --> Model Class Initialized
INFO - 2024-02-07 06:28:02 --> Final output sent to browser
DEBUG - 2024-02-07 06:28:02 --> Total execution time: 0.0217
ERROR - 2024-02-07 06:28:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:28:03 --> Config Class Initialized
INFO - 2024-02-07 06:28:03 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:28:03 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:28:03 --> Utf8 Class Initialized
INFO - 2024-02-07 06:28:03 --> URI Class Initialized
INFO - 2024-02-07 06:28:03 --> Router Class Initialized
INFO - 2024-02-07 06:28:03 --> Output Class Initialized
INFO - 2024-02-07 06:28:03 --> Security Class Initialized
DEBUG - 2024-02-07 06:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:28:03 --> Input Class Initialized
INFO - 2024-02-07 06:28:03 --> Language Class Initialized
INFO - 2024-02-07 06:28:03 --> Loader Class Initialized
INFO - 2024-02-07 06:28:03 --> Helper loaded: url_helper
INFO - 2024-02-07 06:28:03 --> Helper loaded: file_helper
INFO - 2024-02-07 06:28:03 --> Helper loaded: html_helper
INFO - 2024-02-07 06:28:03 --> Helper loaded: text_helper
INFO - 2024-02-07 06:28:03 --> Helper loaded: form_helper
INFO - 2024-02-07 06:28:03 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:28:03 --> Helper loaded: security_helper
INFO - 2024-02-07 06:28:03 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:28:03 --> Database Driver Class Initialized
INFO - 2024-02-07 06:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:28:03 --> Parser Class Initialized
INFO - 2024-02-07 06:28:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:28:03 --> Pagination Class Initialized
INFO - 2024-02-07 06:28:03 --> Form Validation Class Initialized
INFO - 2024-02-07 06:28:03 --> Controller Class Initialized
DEBUG - 2024-02-07 06:28:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:28:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:03 --> Model Class Initialized
DEBUG - 2024-02-07 06:28:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:03 --> Model Class Initialized
INFO - 2024-02-07 06:28:03 --> Final output sent to browser
DEBUG - 2024-02-07 06:28:03 --> Total execution time: 0.0171
ERROR - 2024-02-07 06:28:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:28:04 --> Config Class Initialized
INFO - 2024-02-07 06:28:04 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:28:04 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:28:04 --> Utf8 Class Initialized
INFO - 2024-02-07 06:28:04 --> URI Class Initialized
INFO - 2024-02-07 06:28:04 --> Router Class Initialized
INFO - 2024-02-07 06:28:04 --> Output Class Initialized
INFO - 2024-02-07 06:28:04 --> Security Class Initialized
DEBUG - 2024-02-07 06:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:28:04 --> Input Class Initialized
INFO - 2024-02-07 06:28:04 --> Language Class Initialized
INFO - 2024-02-07 06:28:04 --> Loader Class Initialized
INFO - 2024-02-07 06:28:04 --> Helper loaded: url_helper
INFO - 2024-02-07 06:28:04 --> Helper loaded: file_helper
INFO - 2024-02-07 06:28:04 --> Helper loaded: html_helper
INFO - 2024-02-07 06:28:04 --> Helper loaded: text_helper
INFO - 2024-02-07 06:28:04 --> Helper loaded: form_helper
INFO - 2024-02-07 06:28:04 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:28:04 --> Helper loaded: security_helper
INFO - 2024-02-07 06:28:04 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:28:04 --> Database Driver Class Initialized
INFO - 2024-02-07 06:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:28:04 --> Parser Class Initialized
INFO - 2024-02-07 06:28:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:28:04 --> Pagination Class Initialized
INFO - 2024-02-07 06:28:04 --> Form Validation Class Initialized
INFO - 2024-02-07 06:28:04 --> Controller Class Initialized
DEBUG - 2024-02-07 06:28:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:28:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:04 --> Model Class Initialized
DEBUG - 2024-02-07 06:28:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:04 --> Model Class Initialized
INFO - 2024-02-07 06:28:04 --> Final output sent to browser
DEBUG - 2024-02-07 06:28:04 --> Total execution time: 0.0298
ERROR - 2024-02-07 06:28:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:28:04 --> Config Class Initialized
INFO - 2024-02-07 06:28:04 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:28:04 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:28:04 --> Utf8 Class Initialized
INFO - 2024-02-07 06:28:04 --> URI Class Initialized
INFO - 2024-02-07 06:28:04 --> Router Class Initialized
INFO - 2024-02-07 06:28:04 --> Output Class Initialized
INFO - 2024-02-07 06:28:04 --> Security Class Initialized
DEBUG - 2024-02-07 06:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:28:04 --> Input Class Initialized
INFO - 2024-02-07 06:28:04 --> Language Class Initialized
INFO - 2024-02-07 06:28:04 --> Loader Class Initialized
INFO - 2024-02-07 06:28:04 --> Helper loaded: url_helper
INFO - 2024-02-07 06:28:04 --> Helper loaded: file_helper
INFO - 2024-02-07 06:28:04 --> Helper loaded: html_helper
INFO - 2024-02-07 06:28:04 --> Helper loaded: text_helper
INFO - 2024-02-07 06:28:04 --> Helper loaded: form_helper
INFO - 2024-02-07 06:28:04 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:28:04 --> Helper loaded: security_helper
INFO - 2024-02-07 06:28:04 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:28:04 --> Database Driver Class Initialized
INFO - 2024-02-07 06:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:28:04 --> Parser Class Initialized
INFO - 2024-02-07 06:28:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:28:04 --> Pagination Class Initialized
INFO - 2024-02-07 06:28:04 --> Form Validation Class Initialized
INFO - 2024-02-07 06:28:04 --> Controller Class Initialized
DEBUG - 2024-02-07 06:28:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:28:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:04 --> Model Class Initialized
DEBUG - 2024-02-07 06:28:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:04 --> Model Class Initialized
INFO - 2024-02-07 06:28:04 --> Final output sent to browser
DEBUG - 2024-02-07 06:28:04 --> Total execution time: 0.0291
ERROR - 2024-02-07 06:28:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:28:05 --> Config Class Initialized
INFO - 2024-02-07 06:28:05 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:28:05 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:28:05 --> Utf8 Class Initialized
INFO - 2024-02-07 06:28:05 --> URI Class Initialized
INFO - 2024-02-07 06:28:05 --> Router Class Initialized
INFO - 2024-02-07 06:28:05 --> Output Class Initialized
INFO - 2024-02-07 06:28:05 --> Security Class Initialized
DEBUG - 2024-02-07 06:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:28:05 --> Input Class Initialized
INFO - 2024-02-07 06:28:05 --> Language Class Initialized
INFO - 2024-02-07 06:28:05 --> Loader Class Initialized
INFO - 2024-02-07 06:28:05 --> Helper loaded: url_helper
INFO - 2024-02-07 06:28:05 --> Helper loaded: file_helper
INFO - 2024-02-07 06:28:05 --> Helper loaded: html_helper
INFO - 2024-02-07 06:28:05 --> Helper loaded: text_helper
INFO - 2024-02-07 06:28:05 --> Helper loaded: form_helper
INFO - 2024-02-07 06:28:05 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:28:05 --> Helper loaded: security_helper
INFO - 2024-02-07 06:28:05 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:28:05 --> Database Driver Class Initialized
INFO - 2024-02-07 06:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:28:05 --> Parser Class Initialized
INFO - 2024-02-07 06:28:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:28:05 --> Pagination Class Initialized
INFO - 2024-02-07 06:28:05 --> Form Validation Class Initialized
INFO - 2024-02-07 06:28:05 --> Controller Class Initialized
DEBUG - 2024-02-07 06:28:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:28:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:05 --> Model Class Initialized
DEBUG - 2024-02-07 06:28:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:05 --> Model Class Initialized
INFO - 2024-02-07 06:28:05 --> Final output sent to browser
DEBUG - 2024-02-07 06:28:05 --> Total execution time: 0.0304
ERROR - 2024-02-07 06:28:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:28:05 --> Config Class Initialized
INFO - 2024-02-07 06:28:05 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:28:05 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:28:05 --> Utf8 Class Initialized
INFO - 2024-02-07 06:28:05 --> URI Class Initialized
INFO - 2024-02-07 06:28:05 --> Router Class Initialized
INFO - 2024-02-07 06:28:05 --> Output Class Initialized
INFO - 2024-02-07 06:28:06 --> Security Class Initialized
DEBUG - 2024-02-07 06:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:28:06 --> Input Class Initialized
INFO - 2024-02-07 06:28:06 --> Language Class Initialized
INFO - 2024-02-07 06:28:06 --> Loader Class Initialized
INFO - 2024-02-07 06:28:06 --> Helper loaded: url_helper
INFO - 2024-02-07 06:28:06 --> Helper loaded: file_helper
INFO - 2024-02-07 06:28:06 --> Helper loaded: html_helper
INFO - 2024-02-07 06:28:06 --> Helper loaded: text_helper
INFO - 2024-02-07 06:28:06 --> Helper loaded: form_helper
INFO - 2024-02-07 06:28:06 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:28:06 --> Helper loaded: security_helper
INFO - 2024-02-07 06:28:06 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:28:06 --> Database Driver Class Initialized
INFO - 2024-02-07 06:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:28:06 --> Parser Class Initialized
INFO - 2024-02-07 06:28:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:28:06 --> Pagination Class Initialized
INFO - 2024-02-07 06:28:06 --> Form Validation Class Initialized
INFO - 2024-02-07 06:28:06 --> Controller Class Initialized
DEBUG - 2024-02-07 06:28:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:28:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:06 --> Model Class Initialized
DEBUG - 2024-02-07 06:28:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:06 --> Model Class Initialized
INFO - 2024-02-07 06:28:06 --> Final output sent to browser
DEBUG - 2024-02-07 06:28:06 --> Total execution time: 0.0281
ERROR - 2024-02-07 06:28:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:28:06 --> Config Class Initialized
INFO - 2024-02-07 06:28:06 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:28:06 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:28:06 --> Utf8 Class Initialized
INFO - 2024-02-07 06:28:06 --> URI Class Initialized
INFO - 2024-02-07 06:28:06 --> Router Class Initialized
INFO - 2024-02-07 06:28:06 --> Output Class Initialized
INFO - 2024-02-07 06:28:06 --> Security Class Initialized
DEBUG - 2024-02-07 06:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:28:06 --> Input Class Initialized
INFO - 2024-02-07 06:28:06 --> Language Class Initialized
INFO - 2024-02-07 06:28:06 --> Loader Class Initialized
INFO - 2024-02-07 06:28:06 --> Helper loaded: url_helper
INFO - 2024-02-07 06:28:06 --> Helper loaded: file_helper
INFO - 2024-02-07 06:28:06 --> Helper loaded: html_helper
INFO - 2024-02-07 06:28:06 --> Helper loaded: text_helper
INFO - 2024-02-07 06:28:06 --> Helper loaded: form_helper
INFO - 2024-02-07 06:28:06 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:28:06 --> Helper loaded: security_helper
INFO - 2024-02-07 06:28:06 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:28:06 --> Database Driver Class Initialized
INFO - 2024-02-07 06:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:28:06 --> Parser Class Initialized
INFO - 2024-02-07 06:28:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:28:06 --> Pagination Class Initialized
INFO - 2024-02-07 06:28:06 --> Form Validation Class Initialized
INFO - 2024-02-07 06:28:06 --> Controller Class Initialized
DEBUG - 2024-02-07 06:28:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:28:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:06 --> Model Class Initialized
DEBUG - 2024-02-07 06:28:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:06 --> Model Class Initialized
INFO - 2024-02-07 06:28:06 --> Final output sent to browser
DEBUG - 2024-02-07 06:28:06 --> Total execution time: 0.0252
ERROR - 2024-02-07 06:28:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:28:07 --> Config Class Initialized
INFO - 2024-02-07 06:28:07 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:28:07 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:28:07 --> Utf8 Class Initialized
INFO - 2024-02-07 06:28:07 --> URI Class Initialized
INFO - 2024-02-07 06:28:07 --> Router Class Initialized
INFO - 2024-02-07 06:28:07 --> Output Class Initialized
INFO - 2024-02-07 06:28:07 --> Security Class Initialized
DEBUG - 2024-02-07 06:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:28:07 --> Input Class Initialized
INFO - 2024-02-07 06:28:07 --> Language Class Initialized
INFO - 2024-02-07 06:28:07 --> Loader Class Initialized
INFO - 2024-02-07 06:28:07 --> Helper loaded: url_helper
INFO - 2024-02-07 06:28:07 --> Helper loaded: file_helper
INFO - 2024-02-07 06:28:07 --> Helper loaded: html_helper
INFO - 2024-02-07 06:28:07 --> Helper loaded: text_helper
INFO - 2024-02-07 06:28:07 --> Helper loaded: form_helper
INFO - 2024-02-07 06:28:07 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:28:07 --> Helper loaded: security_helper
INFO - 2024-02-07 06:28:07 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:28:07 --> Database Driver Class Initialized
INFO - 2024-02-07 06:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:28:07 --> Parser Class Initialized
INFO - 2024-02-07 06:28:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:28:07 --> Pagination Class Initialized
INFO - 2024-02-07 06:28:07 --> Form Validation Class Initialized
INFO - 2024-02-07 06:28:07 --> Controller Class Initialized
DEBUG - 2024-02-07 06:28:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:28:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:07 --> Model Class Initialized
DEBUG - 2024-02-07 06:28:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:07 --> Model Class Initialized
INFO - 2024-02-07 06:28:07 --> Final output sent to browser
DEBUG - 2024-02-07 06:28:07 --> Total execution time: 0.0246
ERROR - 2024-02-07 06:28:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:28:08 --> Config Class Initialized
INFO - 2024-02-07 06:28:08 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:28:08 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:28:08 --> Utf8 Class Initialized
INFO - 2024-02-07 06:28:08 --> URI Class Initialized
INFO - 2024-02-07 06:28:08 --> Router Class Initialized
INFO - 2024-02-07 06:28:08 --> Output Class Initialized
INFO - 2024-02-07 06:28:08 --> Security Class Initialized
DEBUG - 2024-02-07 06:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:28:08 --> Input Class Initialized
INFO - 2024-02-07 06:28:08 --> Language Class Initialized
INFO - 2024-02-07 06:28:08 --> Loader Class Initialized
INFO - 2024-02-07 06:28:08 --> Helper loaded: url_helper
INFO - 2024-02-07 06:28:08 --> Helper loaded: file_helper
INFO - 2024-02-07 06:28:08 --> Helper loaded: html_helper
INFO - 2024-02-07 06:28:08 --> Helper loaded: text_helper
INFO - 2024-02-07 06:28:08 --> Helper loaded: form_helper
INFO - 2024-02-07 06:28:08 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:28:08 --> Helper loaded: security_helper
INFO - 2024-02-07 06:28:08 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:28:08 --> Database Driver Class Initialized
INFO - 2024-02-07 06:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:28:08 --> Parser Class Initialized
INFO - 2024-02-07 06:28:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:28:08 --> Pagination Class Initialized
INFO - 2024-02-07 06:28:08 --> Form Validation Class Initialized
INFO - 2024-02-07 06:28:08 --> Controller Class Initialized
DEBUG - 2024-02-07 06:28:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:28:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:08 --> Model Class Initialized
DEBUG - 2024-02-07 06:28:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:08 --> Model Class Initialized
INFO - 2024-02-07 06:28:08 --> Final output sent to browser
DEBUG - 2024-02-07 06:28:08 --> Total execution time: 0.0172
ERROR - 2024-02-07 06:28:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:28:08 --> Config Class Initialized
INFO - 2024-02-07 06:28:08 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:28:08 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:28:08 --> Utf8 Class Initialized
INFO - 2024-02-07 06:28:08 --> URI Class Initialized
INFO - 2024-02-07 06:28:08 --> Router Class Initialized
INFO - 2024-02-07 06:28:08 --> Output Class Initialized
INFO - 2024-02-07 06:28:08 --> Security Class Initialized
DEBUG - 2024-02-07 06:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:28:08 --> Input Class Initialized
INFO - 2024-02-07 06:28:08 --> Language Class Initialized
INFO - 2024-02-07 06:28:08 --> Loader Class Initialized
INFO - 2024-02-07 06:28:08 --> Helper loaded: url_helper
INFO - 2024-02-07 06:28:08 --> Helper loaded: file_helper
INFO - 2024-02-07 06:28:08 --> Helper loaded: html_helper
INFO - 2024-02-07 06:28:08 --> Helper loaded: text_helper
INFO - 2024-02-07 06:28:08 --> Helper loaded: form_helper
INFO - 2024-02-07 06:28:08 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:28:08 --> Helper loaded: security_helper
INFO - 2024-02-07 06:28:08 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:28:08 --> Database Driver Class Initialized
INFO - 2024-02-07 06:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:28:08 --> Parser Class Initialized
INFO - 2024-02-07 06:28:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:28:08 --> Pagination Class Initialized
INFO - 2024-02-07 06:28:08 --> Form Validation Class Initialized
INFO - 2024-02-07 06:28:08 --> Controller Class Initialized
DEBUG - 2024-02-07 06:28:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:28:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:08 --> Model Class Initialized
DEBUG - 2024-02-07 06:28:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:08 --> Model Class Initialized
INFO - 2024-02-07 06:28:08 --> Final output sent to browser
DEBUG - 2024-02-07 06:28:08 --> Total execution time: 0.0174
ERROR - 2024-02-07 06:28:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:28:09 --> Config Class Initialized
INFO - 2024-02-07 06:28:09 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:28:09 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:28:09 --> Utf8 Class Initialized
INFO - 2024-02-07 06:28:09 --> URI Class Initialized
INFO - 2024-02-07 06:28:09 --> Router Class Initialized
INFO - 2024-02-07 06:28:09 --> Output Class Initialized
INFO - 2024-02-07 06:28:09 --> Security Class Initialized
DEBUG - 2024-02-07 06:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:28:09 --> Input Class Initialized
INFO - 2024-02-07 06:28:09 --> Language Class Initialized
INFO - 2024-02-07 06:28:09 --> Loader Class Initialized
INFO - 2024-02-07 06:28:09 --> Helper loaded: url_helper
INFO - 2024-02-07 06:28:09 --> Helper loaded: file_helper
INFO - 2024-02-07 06:28:09 --> Helper loaded: html_helper
INFO - 2024-02-07 06:28:09 --> Helper loaded: text_helper
INFO - 2024-02-07 06:28:09 --> Helper loaded: form_helper
INFO - 2024-02-07 06:28:09 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:28:09 --> Helper loaded: security_helper
INFO - 2024-02-07 06:28:09 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:28:09 --> Database Driver Class Initialized
INFO - 2024-02-07 06:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:28:09 --> Parser Class Initialized
INFO - 2024-02-07 06:28:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:28:09 --> Pagination Class Initialized
INFO - 2024-02-07 06:28:09 --> Form Validation Class Initialized
INFO - 2024-02-07 06:28:09 --> Controller Class Initialized
DEBUG - 2024-02-07 06:28:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:28:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:09 --> Model Class Initialized
DEBUG - 2024-02-07 06:28:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:09 --> Model Class Initialized
INFO - 2024-02-07 06:28:09 --> Final output sent to browser
DEBUG - 2024-02-07 06:28:09 --> Total execution time: 0.0174
ERROR - 2024-02-07 06:28:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:28:09 --> Config Class Initialized
INFO - 2024-02-07 06:28:09 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:28:09 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:28:09 --> Utf8 Class Initialized
INFO - 2024-02-07 06:28:09 --> URI Class Initialized
INFO - 2024-02-07 06:28:09 --> Router Class Initialized
INFO - 2024-02-07 06:28:09 --> Output Class Initialized
INFO - 2024-02-07 06:28:09 --> Security Class Initialized
DEBUG - 2024-02-07 06:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:28:09 --> Input Class Initialized
INFO - 2024-02-07 06:28:09 --> Language Class Initialized
INFO - 2024-02-07 06:28:09 --> Loader Class Initialized
INFO - 2024-02-07 06:28:09 --> Helper loaded: url_helper
INFO - 2024-02-07 06:28:09 --> Helper loaded: file_helper
INFO - 2024-02-07 06:28:09 --> Helper loaded: html_helper
INFO - 2024-02-07 06:28:09 --> Helper loaded: text_helper
INFO - 2024-02-07 06:28:09 --> Helper loaded: form_helper
INFO - 2024-02-07 06:28:09 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:28:09 --> Helper loaded: security_helper
INFO - 2024-02-07 06:28:09 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:28:09 --> Database Driver Class Initialized
INFO - 2024-02-07 06:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:28:09 --> Parser Class Initialized
INFO - 2024-02-07 06:28:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:28:09 --> Pagination Class Initialized
INFO - 2024-02-07 06:28:09 --> Form Validation Class Initialized
INFO - 2024-02-07 06:28:09 --> Controller Class Initialized
DEBUG - 2024-02-07 06:28:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:28:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:09 --> Model Class Initialized
DEBUG - 2024-02-07 06:28:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:09 --> Model Class Initialized
INFO - 2024-02-07 06:28:09 --> Final output sent to browser
DEBUG - 2024-02-07 06:28:09 --> Total execution time: 0.0191
ERROR - 2024-02-07 06:28:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:28:09 --> Config Class Initialized
INFO - 2024-02-07 06:28:09 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:28:09 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:28:09 --> Utf8 Class Initialized
INFO - 2024-02-07 06:28:09 --> URI Class Initialized
INFO - 2024-02-07 06:28:09 --> Router Class Initialized
INFO - 2024-02-07 06:28:09 --> Output Class Initialized
INFO - 2024-02-07 06:28:09 --> Security Class Initialized
DEBUG - 2024-02-07 06:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:28:09 --> Input Class Initialized
INFO - 2024-02-07 06:28:09 --> Language Class Initialized
INFO - 2024-02-07 06:28:09 --> Loader Class Initialized
INFO - 2024-02-07 06:28:09 --> Helper loaded: url_helper
INFO - 2024-02-07 06:28:09 --> Helper loaded: file_helper
INFO - 2024-02-07 06:28:09 --> Helper loaded: html_helper
INFO - 2024-02-07 06:28:09 --> Helper loaded: text_helper
INFO - 2024-02-07 06:28:09 --> Helper loaded: form_helper
INFO - 2024-02-07 06:28:09 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:28:09 --> Helper loaded: security_helper
INFO - 2024-02-07 06:28:09 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:28:09 --> Database Driver Class Initialized
INFO - 2024-02-07 06:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:28:09 --> Parser Class Initialized
INFO - 2024-02-07 06:28:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:28:09 --> Pagination Class Initialized
INFO - 2024-02-07 06:28:09 --> Form Validation Class Initialized
INFO - 2024-02-07 06:28:09 --> Controller Class Initialized
DEBUG - 2024-02-07 06:28:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:28:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:09 --> Model Class Initialized
DEBUG - 2024-02-07 06:28:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:09 --> Model Class Initialized
INFO - 2024-02-07 06:28:09 --> Final output sent to browser
DEBUG - 2024-02-07 06:28:09 --> Total execution time: 0.0160
ERROR - 2024-02-07 06:28:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:28:10 --> Config Class Initialized
INFO - 2024-02-07 06:28:10 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:28:10 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:28:10 --> Utf8 Class Initialized
INFO - 2024-02-07 06:28:10 --> URI Class Initialized
INFO - 2024-02-07 06:28:10 --> Router Class Initialized
INFO - 2024-02-07 06:28:10 --> Output Class Initialized
INFO - 2024-02-07 06:28:10 --> Security Class Initialized
DEBUG - 2024-02-07 06:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:28:10 --> Input Class Initialized
INFO - 2024-02-07 06:28:10 --> Language Class Initialized
INFO - 2024-02-07 06:28:10 --> Loader Class Initialized
INFO - 2024-02-07 06:28:10 --> Helper loaded: url_helper
INFO - 2024-02-07 06:28:10 --> Helper loaded: file_helper
INFO - 2024-02-07 06:28:10 --> Helper loaded: html_helper
INFO - 2024-02-07 06:28:10 --> Helper loaded: text_helper
INFO - 2024-02-07 06:28:10 --> Helper loaded: form_helper
INFO - 2024-02-07 06:28:10 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:28:10 --> Helper loaded: security_helper
INFO - 2024-02-07 06:28:10 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:28:10 --> Database Driver Class Initialized
INFO - 2024-02-07 06:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:28:10 --> Parser Class Initialized
INFO - 2024-02-07 06:28:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:28:10 --> Pagination Class Initialized
INFO - 2024-02-07 06:28:10 --> Form Validation Class Initialized
INFO - 2024-02-07 06:28:10 --> Controller Class Initialized
DEBUG - 2024-02-07 06:28:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:28:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:10 --> Model Class Initialized
DEBUG - 2024-02-07 06:28:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:10 --> Model Class Initialized
INFO - 2024-02-07 06:28:10 --> Final output sent to browser
DEBUG - 2024-02-07 06:28:10 --> Total execution time: 0.0210
ERROR - 2024-02-07 06:28:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:28:11 --> Config Class Initialized
INFO - 2024-02-07 06:28:11 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:28:11 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:28:11 --> Utf8 Class Initialized
INFO - 2024-02-07 06:28:11 --> URI Class Initialized
INFO - 2024-02-07 06:28:11 --> Router Class Initialized
INFO - 2024-02-07 06:28:11 --> Output Class Initialized
INFO - 2024-02-07 06:28:11 --> Security Class Initialized
DEBUG - 2024-02-07 06:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:28:11 --> Input Class Initialized
INFO - 2024-02-07 06:28:11 --> Language Class Initialized
INFO - 2024-02-07 06:28:11 --> Loader Class Initialized
INFO - 2024-02-07 06:28:11 --> Helper loaded: url_helper
INFO - 2024-02-07 06:28:11 --> Helper loaded: file_helper
INFO - 2024-02-07 06:28:11 --> Helper loaded: html_helper
INFO - 2024-02-07 06:28:11 --> Helper loaded: text_helper
INFO - 2024-02-07 06:28:11 --> Helper loaded: form_helper
INFO - 2024-02-07 06:28:11 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:28:11 --> Helper loaded: security_helper
INFO - 2024-02-07 06:28:11 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:28:11 --> Database Driver Class Initialized
INFO - 2024-02-07 06:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:28:11 --> Parser Class Initialized
INFO - 2024-02-07 06:28:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:28:11 --> Pagination Class Initialized
INFO - 2024-02-07 06:28:11 --> Form Validation Class Initialized
INFO - 2024-02-07 06:28:11 --> Controller Class Initialized
DEBUG - 2024-02-07 06:28:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:28:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:11 --> Model Class Initialized
DEBUG - 2024-02-07 06:28:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:11 --> Model Class Initialized
INFO - 2024-02-07 06:28:11 --> Final output sent to browser
DEBUG - 2024-02-07 06:28:11 --> Total execution time: 0.0314
ERROR - 2024-02-07 06:28:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:28:23 --> Config Class Initialized
INFO - 2024-02-07 06:28:23 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:28:23 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:28:23 --> Utf8 Class Initialized
INFO - 2024-02-07 06:28:23 --> URI Class Initialized
INFO - 2024-02-07 06:28:23 --> Router Class Initialized
INFO - 2024-02-07 06:28:23 --> Output Class Initialized
INFO - 2024-02-07 06:28:23 --> Security Class Initialized
DEBUG - 2024-02-07 06:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:28:23 --> Input Class Initialized
INFO - 2024-02-07 06:28:23 --> Language Class Initialized
INFO - 2024-02-07 06:28:23 --> Loader Class Initialized
INFO - 2024-02-07 06:28:23 --> Helper loaded: url_helper
INFO - 2024-02-07 06:28:23 --> Helper loaded: file_helper
INFO - 2024-02-07 06:28:23 --> Helper loaded: html_helper
INFO - 2024-02-07 06:28:23 --> Helper loaded: text_helper
INFO - 2024-02-07 06:28:23 --> Helper loaded: form_helper
INFO - 2024-02-07 06:28:23 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:28:23 --> Helper loaded: security_helper
INFO - 2024-02-07 06:28:23 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:28:23 --> Database Driver Class Initialized
INFO - 2024-02-07 06:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:28:23 --> Parser Class Initialized
INFO - 2024-02-07 06:28:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:28:23 --> Pagination Class Initialized
INFO - 2024-02-07 06:28:23 --> Form Validation Class Initialized
INFO - 2024-02-07 06:28:23 --> Controller Class Initialized
DEBUG - 2024-02-07 06:28:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:28:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:23 --> Model Class Initialized
DEBUG - 2024-02-07 06:28:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:23 --> Model Class Initialized
DEBUG - 2024-02-07 06:28:23 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:23 --> Model Class Initialized
INFO - 2024-02-07 06:28:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-07 06:28:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:28:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:28:23 --> Model Class Initialized
INFO - 2024-02-07 06:28:23 --> Model Class Initialized
INFO - 2024-02-07 06:28:23 --> Model Class Initialized
INFO - 2024-02-07 06:28:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 06:28:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 06:28:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:28:23 --> Final output sent to browser
DEBUG - 2024-02-07 06:28:23 --> Total execution time: 0.2112
ERROR - 2024-02-07 06:28:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:28:23 --> Config Class Initialized
INFO - 2024-02-07 06:28:23 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:28:23 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:28:23 --> Utf8 Class Initialized
INFO - 2024-02-07 06:28:23 --> URI Class Initialized
INFO - 2024-02-07 06:28:23 --> Router Class Initialized
INFO - 2024-02-07 06:28:23 --> Output Class Initialized
INFO - 2024-02-07 06:28:23 --> Security Class Initialized
DEBUG - 2024-02-07 06:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:28:23 --> Input Class Initialized
INFO - 2024-02-07 06:28:23 --> Language Class Initialized
INFO - 2024-02-07 06:28:23 --> Loader Class Initialized
INFO - 2024-02-07 06:28:23 --> Helper loaded: url_helper
INFO - 2024-02-07 06:28:23 --> Helper loaded: file_helper
INFO - 2024-02-07 06:28:23 --> Helper loaded: html_helper
INFO - 2024-02-07 06:28:23 --> Helper loaded: text_helper
INFO - 2024-02-07 06:28:23 --> Helper loaded: form_helper
INFO - 2024-02-07 06:28:23 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:28:23 --> Helper loaded: security_helper
INFO - 2024-02-07 06:28:23 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:28:23 --> Database Driver Class Initialized
INFO - 2024-02-07 06:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:28:23 --> Parser Class Initialized
INFO - 2024-02-07 06:28:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:28:23 --> Pagination Class Initialized
INFO - 2024-02-07 06:28:23 --> Form Validation Class Initialized
INFO - 2024-02-07 06:28:23 --> Controller Class Initialized
DEBUG - 2024-02-07 06:28:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:28:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:23 --> Model Class Initialized
DEBUG - 2024-02-07 06:28:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:23 --> Model Class Initialized
INFO - 2024-02-07 06:28:23 --> Final output sent to browser
DEBUG - 2024-02-07 06:28:23 --> Total execution time: 0.0332
ERROR - 2024-02-07 06:28:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:28:27 --> Config Class Initialized
INFO - 2024-02-07 06:28:27 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:28:27 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:28:27 --> Utf8 Class Initialized
INFO - 2024-02-07 06:28:27 --> URI Class Initialized
INFO - 2024-02-07 06:28:27 --> Router Class Initialized
INFO - 2024-02-07 06:28:27 --> Output Class Initialized
INFO - 2024-02-07 06:28:27 --> Security Class Initialized
DEBUG - 2024-02-07 06:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:28:27 --> Input Class Initialized
INFO - 2024-02-07 06:28:27 --> Language Class Initialized
INFO - 2024-02-07 06:28:27 --> Loader Class Initialized
INFO - 2024-02-07 06:28:27 --> Helper loaded: url_helper
INFO - 2024-02-07 06:28:27 --> Helper loaded: file_helper
INFO - 2024-02-07 06:28:27 --> Helper loaded: html_helper
INFO - 2024-02-07 06:28:27 --> Helper loaded: text_helper
INFO - 2024-02-07 06:28:27 --> Helper loaded: form_helper
INFO - 2024-02-07 06:28:27 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:28:27 --> Helper loaded: security_helper
INFO - 2024-02-07 06:28:27 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:28:27 --> Database Driver Class Initialized
INFO - 2024-02-07 06:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:28:27 --> Parser Class Initialized
INFO - 2024-02-07 06:28:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:28:27 --> Pagination Class Initialized
INFO - 2024-02-07 06:28:27 --> Form Validation Class Initialized
INFO - 2024-02-07 06:28:27 --> Controller Class Initialized
DEBUG - 2024-02-07 06:28:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:28:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:27 --> Model Class Initialized
DEBUG - 2024-02-07 06:28:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:27 --> Model Class Initialized
INFO - 2024-02-07 06:28:27 --> Final output sent to browser
DEBUG - 2024-02-07 06:28:27 --> Total execution time: 0.0301
ERROR - 2024-02-07 06:28:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:28:28 --> Config Class Initialized
INFO - 2024-02-07 06:28:28 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:28:28 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:28:28 --> Utf8 Class Initialized
INFO - 2024-02-07 06:28:28 --> URI Class Initialized
INFO - 2024-02-07 06:28:28 --> Router Class Initialized
INFO - 2024-02-07 06:28:28 --> Output Class Initialized
INFO - 2024-02-07 06:28:28 --> Security Class Initialized
DEBUG - 2024-02-07 06:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:28:28 --> Input Class Initialized
INFO - 2024-02-07 06:28:28 --> Language Class Initialized
INFO - 2024-02-07 06:28:28 --> Loader Class Initialized
INFO - 2024-02-07 06:28:28 --> Helper loaded: url_helper
INFO - 2024-02-07 06:28:28 --> Helper loaded: file_helper
INFO - 2024-02-07 06:28:28 --> Helper loaded: html_helper
INFO - 2024-02-07 06:28:28 --> Helper loaded: text_helper
INFO - 2024-02-07 06:28:28 --> Helper loaded: form_helper
INFO - 2024-02-07 06:28:28 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:28:28 --> Helper loaded: security_helper
INFO - 2024-02-07 06:28:28 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:28:28 --> Database Driver Class Initialized
INFO - 2024-02-07 06:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:28:28 --> Parser Class Initialized
INFO - 2024-02-07 06:28:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:28:28 --> Pagination Class Initialized
INFO - 2024-02-07 06:28:28 --> Form Validation Class Initialized
INFO - 2024-02-07 06:28:28 --> Controller Class Initialized
DEBUG - 2024-02-07 06:28:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:28:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:28 --> Model Class Initialized
DEBUG - 2024-02-07 06:28:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:28 --> Model Class Initialized
INFO - 2024-02-07 06:28:28 --> Final output sent to browser
DEBUG - 2024-02-07 06:28:28 --> Total execution time: 0.0302
ERROR - 2024-02-07 06:28:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:28:28 --> Config Class Initialized
INFO - 2024-02-07 06:28:28 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:28:28 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:28:28 --> Utf8 Class Initialized
INFO - 2024-02-07 06:28:28 --> URI Class Initialized
INFO - 2024-02-07 06:28:28 --> Router Class Initialized
INFO - 2024-02-07 06:28:28 --> Output Class Initialized
INFO - 2024-02-07 06:28:28 --> Security Class Initialized
DEBUG - 2024-02-07 06:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:28:28 --> Input Class Initialized
INFO - 2024-02-07 06:28:28 --> Language Class Initialized
INFO - 2024-02-07 06:28:28 --> Loader Class Initialized
INFO - 2024-02-07 06:28:28 --> Helper loaded: url_helper
INFO - 2024-02-07 06:28:28 --> Helper loaded: file_helper
INFO - 2024-02-07 06:28:28 --> Helper loaded: html_helper
INFO - 2024-02-07 06:28:28 --> Helper loaded: text_helper
INFO - 2024-02-07 06:28:28 --> Helper loaded: form_helper
INFO - 2024-02-07 06:28:28 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:28:28 --> Helper loaded: security_helper
INFO - 2024-02-07 06:28:28 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:28:28 --> Database Driver Class Initialized
INFO - 2024-02-07 06:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:28:28 --> Parser Class Initialized
INFO - 2024-02-07 06:28:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:28:28 --> Pagination Class Initialized
INFO - 2024-02-07 06:28:28 --> Form Validation Class Initialized
INFO - 2024-02-07 06:28:28 --> Controller Class Initialized
DEBUG - 2024-02-07 06:28:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:28:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:28 --> Model Class Initialized
DEBUG - 2024-02-07 06:28:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:28 --> Model Class Initialized
INFO - 2024-02-07 06:28:28 --> Final output sent to browser
DEBUG - 2024-02-07 06:28:28 --> Total execution time: 0.0233
ERROR - 2024-02-07 06:28:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:28:33 --> Config Class Initialized
INFO - 2024-02-07 06:28:33 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:28:33 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:28:33 --> Utf8 Class Initialized
INFO - 2024-02-07 06:28:33 --> URI Class Initialized
INFO - 2024-02-07 06:28:33 --> Router Class Initialized
INFO - 2024-02-07 06:28:33 --> Output Class Initialized
INFO - 2024-02-07 06:28:33 --> Security Class Initialized
DEBUG - 2024-02-07 06:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:28:33 --> Input Class Initialized
INFO - 2024-02-07 06:28:33 --> Language Class Initialized
INFO - 2024-02-07 06:28:33 --> Loader Class Initialized
INFO - 2024-02-07 06:28:33 --> Helper loaded: url_helper
INFO - 2024-02-07 06:28:33 --> Helper loaded: file_helper
INFO - 2024-02-07 06:28:33 --> Helper loaded: html_helper
INFO - 2024-02-07 06:28:33 --> Helper loaded: text_helper
INFO - 2024-02-07 06:28:33 --> Helper loaded: form_helper
INFO - 2024-02-07 06:28:33 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:28:33 --> Helper loaded: security_helper
INFO - 2024-02-07 06:28:33 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:28:33 --> Database Driver Class Initialized
INFO - 2024-02-07 06:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:28:33 --> Parser Class Initialized
INFO - 2024-02-07 06:28:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:28:33 --> Pagination Class Initialized
INFO - 2024-02-07 06:28:33 --> Form Validation Class Initialized
INFO - 2024-02-07 06:28:33 --> Controller Class Initialized
DEBUG - 2024-02-07 06:28:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:28:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:33 --> Model Class Initialized
DEBUG - 2024-02-07 06:28:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:33 --> Model Class Initialized
INFO - 2024-02-07 06:28:33 --> Final output sent to browser
DEBUG - 2024-02-07 06:28:33 --> Total execution time: 0.0333
ERROR - 2024-02-07 06:28:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:28:33 --> Config Class Initialized
INFO - 2024-02-07 06:28:33 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:28:33 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:28:33 --> Utf8 Class Initialized
INFO - 2024-02-07 06:28:33 --> URI Class Initialized
INFO - 2024-02-07 06:28:33 --> Router Class Initialized
INFO - 2024-02-07 06:28:33 --> Output Class Initialized
INFO - 2024-02-07 06:28:33 --> Security Class Initialized
DEBUG - 2024-02-07 06:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:28:33 --> Input Class Initialized
INFO - 2024-02-07 06:28:33 --> Language Class Initialized
INFO - 2024-02-07 06:28:33 --> Loader Class Initialized
INFO - 2024-02-07 06:28:33 --> Helper loaded: url_helper
INFO - 2024-02-07 06:28:33 --> Helper loaded: file_helper
INFO - 2024-02-07 06:28:33 --> Helper loaded: html_helper
INFO - 2024-02-07 06:28:33 --> Helper loaded: text_helper
INFO - 2024-02-07 06:28:33 --> Helper loaded: form_helper
INFO - 2024-02-07 06:28:33 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:28:33 --> Helper loaded: security_helper
INFO - 2024-02-07 06:28:33 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:28:33 --> Database Driver Class Initialized
INFO - 2024-02-07 06:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:28:33 --> Parser Class Initialized
INFO - 2024-02-07 06:28:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:28:33 --> Pagination Class Initialized
INFO - 2024-02-07 06:28:33 --> Form Validation Class Initialized
INFO - 2024-02-07 06:28:33 --> Controller Class Initialized
DEBUG - 2024-02-07 06:28:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:28:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:33 --> Model Class Initialized
DEBUG - 2024-02-07 06:28:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:33 --> Model Class Initialized
INFO - 2024-02-07 06:28:33 --> Final output sent to browser
DEBUG - 2024-02-07 06:28:33 --> Total execution time: 0.0311
ERROR - 2024-02-07 06:28:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:28:34 --> Config Class Initialized
INFO - 2024-02-07 06:28:34 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:28:34 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:28:34 --> Utf8 Class Initialized
INFO - 2024-02-07 06:28:34 --> URI Class Initialized
INFO - 2024-02-07 06:28:34 --> Router Class Initialized
INFO - 2024-02-07 06:28:34 --> Output Class Initialized
INFO - 2024-02-07 06:28:34 --> Security Class Initialized
DEBUG - 2024-02-07 06:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:28:34 --> Input Class Initialized
INFO - 2024-02-07 06:28:34 --> Language Class Initialized
INFO - 2024-02-07 06:28:34 --> Loader Class Initialized
INFO - 2024-02-07 06:28:34 --> Helper loaded: url_helper
INFO - 2024-02-07 06:28:34 --> Helper loaded: file_helper
INFO - 2024-02-07 06:28:34 --> Helper loaded: html_helper
INFO - 2024-02-07 06:28:34 --> Helper loaded: text_helper
INFO - 2024-02-07 06:28:34 --> Helper loaded: form_helper
INFO - 2024-02-07 06:28:34 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:28:34 --> Helper loaded: security_helper
INFO - 2024-02-07 06:28:34 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:28:34 --> Database Driver Class Initialized
INFO - 2024-02-07 06:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:28:34 --> Parser Class Initialized
INFO - 2024-02-07 06:28:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:28:34 --> Pagination Class Initialized
INFO - 2024-02-07 06:28:34 --> Form Validation Class Initialized
INFO - 2024-02-07 06:28:34 --> Controller Class Initialized
DEBUG - 2024-02-07 06:28:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:28:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:34 --> Model Class Initialized
DEBUG - 2024-02-07 06:28:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:34 --> Model Class Initialized
INFO - 2024-02-07 06:28:34 --> Final output sent to browser
DEBUG - 2024-02-07 06:28:34 --> Total execution time: 0.0308
ERROR - 2024-02-07 06:28:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:28:35 --> Config Class Initialized
INFO - 2024-02-07 06:28:35 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:28:35 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:28:35 --> Utf8 Class Initialized
INFO - 2024-02-07 06:28:35 --> URI Class Initialized
INFO - 2024-02-07 06:28:35 --> Router Class Initialized
INFO - 2024-02-07 06:28:35 --> Output Class Initialized
INFO - 2024-02-07 06:28:35 --> Security Class Initialized
DEBUG - 2024-02-07 06:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:28:35 --> Input Class Initialized
INFO - 2024-02-07 06:28:35 --> Language Class Initialized
INFO - 2024-02-07 06:28:35 --> Loader Class Initialized
INFO - 2024-02-07 06:28:35 --> Helper loaded: url_helper
INFO - 2024-02-07 06:28:35 --> Helper loaded: file_helper
INFO - 2024-02-07 06:28:35 --> Helper loaded: html_helper
INFO - 2024-02-07 06:28:35 --> Helper loaded: text_helper
INFO - 2024-02-07 06:28:35 --> Helper loaded: form_helper
INFO - 2024-02-07 06:28:35 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:28:35 --> Helper loaded: security_helper
INFO - 2024-02-07 06:28:35 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:28:35 --> Database Driver Class Initialized
INFO - 2024-02-07 06:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:28:35 --> Parser Class Initialized
INFO - 2024-02-07 06:28:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:28:35 --> Pagination Class Initialized
INFO - 2024-02-07 06:28:35 --> Form Validation Class Initialized
INFO - 2024-02-07 06:28:35 --> Controller Class Initialized
DEBUG - 2024-02-07 06:28:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:28:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:35 --> Model Class Initialized
DEBUG - 2024-02-07 06:28:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:35 --> Model Class Initialized
INFO - 2024-02-07 06:28:35 --> Final output sent to browser
DEBUG - 2024-02-07 06:28:35 --> Total execution time: 0.0265
ERROR - 2024-02-07 06:28:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:28:36 --> Config Class Initialized
INFO - 2024-02-07 06:28:36 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:28:36 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:28:36 --> Utf8 Class Initialized
INFO - 2024-02-07 06:28:36 --> URI Class Initialized
INFO - 2024-02-07 06:28:36 --> Router Class Initialized
INFO - 2024-02-07 06:28:36 --> Output Class Initialized
INFO - 2024-02-07 06:28:36 --> Security Class Initialized
DEBUG - 2024-02-07 06:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:28:36 --> Input Class Initialized
INFO - 2024-02-07 06:28:36 --> Language Class Initialized
INFO - 2024-02-07 06:28:36 --> Loader Class Initialized
INFO - 2024-02-07 06:28:36 --> Helper loaded: url_helper
INFO - 2024-02-07 06:28:36 --> Helper loaded: file_helper
INFO - 2024-02-07 06:28:36 --> Helper loaded: html_helper
INFO - 2024-02-07 06:28:36 --> Helper loaded: text_helper
INFO - 2024-02-07 06:28:36 --> Helper loaded: form_helper
INFO - 2024-02-07 06:28:36 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:28:36 --> Helper loaded: security_helper
INFO - 2024-02-07 06:28:36 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:28:36 --> Database Driver Class Initialized
INFO - 2024-02-07 06:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:28:36 --> Parser Class Initialized
INFO - 2024-02-07 06:28:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:28:36 --> Pagination Class Initialized
INFO - 2024-02-07 06:28:36 --> Form Validation Class Initialized
INFO - 2024-02-07 06:28:36 --> Controller Class Initialized
DEBUG - 2024-02-07 06:28:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:28:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:36 --> Model Class Initialized
DEBUG - 2024-02-07 06:28:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:36 --> Model Class Initialized
INFO - 2024-02-07 06:28:36 --> Final output sent to browser
DEBUG - 2024-02-07 06:28:36 --> Total execution time: 0.0253
ERROR - 2024-02-07 06:28:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:28:38 --> Config Class Initialized
INFO - 2024-02-07 06:28:38 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:28:38 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:28:38 --> Utf8 Class Initialized
INFO - 2024-02-07 06:28:38 --> URI Class Initialized
INFO - 2024-02-07 06:28:38 --> Router Class Initialized
INFO - 2024-02-07 06:28:38 --> Output Class Initialized
INFO - 2024-02-07 06:28:38 --> Security Class Initialized
DEBUG - 2024-02-07 06:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:28:38 --> Input Class Initialized
INFO - 2024-02-07 06:28:38 --> Language Class Initialized
INFO - 2024-02-07 06:28:38 --> Loader Class Initialized
INFO - 2024-02-07 06:28:38 --> Helper loaded: url_helper
INFO - 2024-02-07 06:28:38 --> Helper loaded: file_helper
INFO - 2024-02-07 06:28:38 --> Helper loaded: html_helper
INFO - 2024-02-07 06:28:38 --> Helper loaded: text_helper
INFO - 2024-02-07 06:28:38 --> Helper loaded: form_helper
INFO - 2024-02-07 06:28:38 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:28:38 --> Helper loaded: security_helper
INFO - 2024-02-07 06:28:38 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:28:38 --> Database Driver Class Initialized
INFO - 2024-02-07 06:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:28:38 --> Parser Class Initialized
INFO - 2024-02-07 06:28:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:28:38 --> Pagination Class Initialized
INFO - 2024-02-07 06:28:38 --> Form Validation Class Initialized
INFO - 2024-02-07 06:28:38 --> Controller Class Initialized
DEBUG - 2024-02-07 06:28:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:28:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:38 --> Model Class Initialized
DEBUG - 2024-02-07 06:28:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:38 --> Model Class Initialized
INFO - 2024-02-07 06:28:38 --> Final output sent to browser
DEBUG - 2024-02-07 06:28:38 --> Total execution time: 0.0164
ERROR - 2024-02-07 06:28:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:28:38 --> Config Class Initialized
INFO - 2024-02-07 06:28:38 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:28:38 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:28:38 --> Utf8 Class Initialized
INFO - 2024-02-07 06:28:38 --> URI Class Initialized
INFO - 2024-02-07 06:28:38 --> Router Class Initialized
INFO - 2024-02-07 06:28:38 --> Output Class Initialized
INFO - 2024-02-07 06:28:38 --> Security Class Initialized
DEBUG - 2024-02-07 06:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:28:38 --> Input Class Initialized
INFO - 2024-02-07 06:28:38 --> Language Class Initialized
INFO - 2024-02-07 06:28:38 --> Loader Class Initialized
INFO - 2024-02-07 06:28:38 --> Helper loaded: url_helper
INFO - 2024-02-07 06:28:38 --> Helper loaded: file_helper
INFO - 2024-02-07 06:28:38 --> Helper loaded: html_helper
INFO - 2024-02-07 06:28:38 --> Helper loaded: text_helper
INFO - 2024-02-07 06:28:38 --> Helper loaded: form_helper
INFO - 2024-02-07 06:28:38 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:28:38 --> Helper loaded: security_helper
INFO - 2024-02-07 06:28:38 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:28:38 --> Database Driver Class Initialized
INFO - 2024-02-07 06:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:28:38 --> Parser Class Initialized
INFO - 2024-02-07 06:28:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:28:38 --> Pagination Class Initialized
INFO - 2024-02-07 06:28:38 --> Form Validation Class Initialized
INFO - 2024-02-07 06:28:38 --> Controller Class Initialized
DEBUG - 2024-02-07 06:28:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:28:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:38 --> Model Class Initialized
DEBUG - 2024-02-07 06:28:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:38 --> Model Class Initialized
INFO - 2024-02-07 06:28:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/edit_customer_form.php
DEBUG - 2024-02-07 06:28:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:28:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:28:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:28:38 --> Model Class Initialized
INFO - 2024-02-07 06:28:38 --> Model Class Initialized
INFO - 2024-02-07 06:28:38 --> Model Class Initialized
INFO - 2024-02-07 06:28:38 --> Model Class Initialized
INFO - 2024-02-07 06:28:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 06:28:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 06:28:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:28:39 --> Final output sent to browser
DEBUG - 2024-02-07 06:28:39 --> Total execution time: 0.2224
ERROR - 2024-02-07 06:29:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:29:09 --> Config Class Initialized
INFO - 2024-02-07 06:29:09 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:29:09 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:29:09 --> Utf8 Class Initialized
INFO - 2024-02-07 06:29:09 --> URI Class Initialized
INFO - 2024-02-07 06:29:09 --> Router Class Initialized
INFO - 2024-02-07 06:29:09 --> Output Class Initialized
INFO - 2024-02-07 06:29:09 --> Security Class Initialized
DEBUG - 2024-02-07 06:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:29:09 --> Input Class Initialized
INFO - 2024-02-07 06:29:09 --> Language Class Initialized
INFO - 2024-02-07 06:29:09 --> Loader Class Initialized
INFO - 2024-02-07 06:29:09 --> Helper loaded: url_helper
INFO - 2024-02-07 06:29:09 --> Helper loaded: file_helper
INFO - 2024-02-07 06:29:09 --> Helper loaded: html_helper
INFO - 2024-02-07 06:29:09 --> Helper loaded: text_helper
INFO - 2024-02-07 06:29:09 --> Helper loaded: form_helper
INFO - 2024-02-07 06:29:09 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:29:09 --> Helper loaded: security_helper
INFO - 2024-02-07 06:29:09 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:29:09 --> Database Driver Class Initialized
INFO - 2024-02-07 06:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:29:09 --> Parser Class Initialized
INFO - 2024-02-07 06:29:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:29:09 --> Pagination Class Initialized
INFO - 2024-02-07 06:29:09 --> Form Validation Class Initialized
INFO - 2024-02-07 06:29:09 --> Controller Class Initialized
INFO - 2024-02-07 06:29:09 --> Model Class Initialized
DEBUG - 2024-02-07 06:29:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:29:09 --> Model Class Initialized
INFO - 2024-02-07 06:29:09 --> Final output sent to browser
DEBUG - 2024-02-07 06:29:09 --> Total execution time: 0.0186
ERROR - 2024-02-07 06:29:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:29:10 --> Config Class Initialized
INFO - 2024-02-07 06:29:10 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:29:10 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:29:10 --> Utf8 Class Initialized
INFO - 2024-02-07 06:29:10 --> URI Class Initialized
INFO - 2024-02-07 06:29:10 --> Router Class Initialized
INFO - 2024-02-07 06:29:10 --> Output Class Initialized
INFO - 2024-02-07 06:29:10 --> Security Class Initialized
DEBUG - 2024-02-07 06:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:29:10 --> Input Class Initialized
INFO - 2024-02-07 06:29:10 --> Language Class Initialized
INFO - 2024-02-07 06:29:10 --> Loader Class Initialized
INFO - 2024-02-07 06:29:10 --> Helper loaded: url_helper
INFO - 2024-02-07 06:29:10 --> Helper loaded: file_helper
INFO - 2024-02-07 06:29:10 --> Helper loaded: html_helper
INFO - 2024-02-07 06:29:10 --> Helper loaded: text_helper
INFO - 2024-02-07 06:29:10 --> Helper loaded: form_helper
INFO - 2024-02-07 06:29:10 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:29:10 --> Helper loaded: security_helper
INFO - 2024-02-07 06:29:10 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:29:10 --> Database Driver Class Initialized
INFO - 2024-02-07 06:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:29:10 --> Parser Class Initialized
INFO - 2024-02-07 06:29:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:29:10 --> Pagination Class Initialized
INFO - 2024-02-07 06:29:10 --> Form Validation Class Initialized
INFO - 2024-02-07 06:29:10 --> Controller Class Initialized
INFO - 2024-02-07 06:29:10 --> Model Class Initialized
DEBUG - 2024-02-07 06:29:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:29:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-07 06:29:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:29:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:29:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:29:10 --> Model Class Initialized
INFO - 2024-02-07 06:29:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:29:10 --> Final output sent to browser
DEBUG - 2024-02-07 06:29:10 --> Total execution time: 0.0315
ERROR - 2024-02-07 06:30:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:30:06 --> Config Class Initialized
INFO - 2024-02-07 06:30:06 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:30:06 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:30:06 --> Utf8 Class Initialized
INFO - 2024-02-07 06:30:06 --> URI Class Initialized
INFO - 2024-02-07 06:30:06 --> Router Class Initialized
INFO - 2024-02-07 06:30:06 --> Output Class Initialized
INFO - 2024-02-07 06:30:06 --> Security Class Initialized
DEBUG - 2024-02-07 06:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:30:06 --> Input Class Initialized
INFO - 2024-02-07 06:30:06 --> Language Class Initialized
INFO - 2024-02-07 06:30:06 --> Loader Class Initialized
INFO - 2024-02-07 06:30:06 --> Helper loaded: url_helper
INFO - 2024-02-07 06:30:06 --> Helper loaded: file_helper
INFO - 2024-02-07 06:30:06 --> Helper loaded: html_helper
INFO - 2024-02-07 06:30:06 --> Helper loaded: text_helper
INFO - 2024-02-07 06:30:06 --> Helper loaded: form_helper
INFO - 2024-02-07 06:30:06 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:30:06 --> Helper loaded: security_helper
INFO - 2024-02-07 06:30:06 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:30:06 --> Database Driver Class Initialized
INFO - 2024-02-07 06:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:30:06 --> Parser Class Initialized
INFO - 2024-02-07 06:30:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:30:06 --> Pagination Class Initialized
INFO - 2024-02-07 06:30:06 --> Form Validation Class Initialized
INFO - 2024-02-07 06:30:06 --> Controller Class Initialized
INFO - 2024-02-07 06:30:06 --> Model Class Initialized
DEBUG - 2024-02-07 06:30:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:30:06 --> Model Class Initialized
INFO - 2024-02-07 06:30:06 --> Final output sent to browser
DEBUG - 2024-02-07 06:30:06 --> Total execution time: 0.0190
ERROR - 2024-02-07 06:30:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:30:07 --> Config Class Initialized
INFO - 2024-02-07 06:30:07 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:30:07 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:30:07 --> Utf8 Class Initialized
INFO - 2024-02-07 06:30:07 --> URI Class Initialized
INFO - 2024-02-07 06:30:07 --> Router Class Initialized
INFO - 2024-02-07 06:30:07 --> Output Class Initialized
INFO - 2024-02-07 06:30:07 --> Security Class Initialized
DEBUG - 2024-02-07 06:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:30:07 --> Input Class Initialized
INFO - 2024-02-07 06:30:07 --> Language Class Initialized
INFO - 2024-02-07 06:30:07 --> Loader Class Initialized
INFO - 2024-02-07 06:30:07 --> Helper loaded: url_helper
INFO - 2024-02-07 06:30:07 --> Helper loaded: file_helper
INFO - 2024-02-07 06:30:07 --> Helper loaded: html_helper
INFO - 2024-02-07 06:30:07 --> Helper loaded: text_helper
INFO - 2024-02-07 06:30:07 --> Helper loaded: form_helper
INFO - 2024-02-07 06:30:07 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:30:07 --> Helper loaded: security_helper
INFO - 2024-02-07 06:30:07 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:30:07 --> Database Driver Class Initialized
INFO - 2024-02-07 06:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:30:07 --> Parser Class Initialized
INFO - 2024-02-07 06:30:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:30:07 --> Pagination Class Initialized
INFO - 2024-02-07 06:30:07 --> Form Validation Class Initialized
INFO - 2024-02-07 06:30:07 --> Controller Class Initialized
INFO - 2024-02-07 06:30:07 --> Model Class Initialized
DEBUG - 2024-02-07 06:30:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:30:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-07 06:30:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:30:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:30:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:30:07 --> Model Class Initialized
INFO - 2024-02-07 06:30:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:30:07 --> Final output sent to browser
DEBUG - 2024-02-07 06:30:07 --> Total execution time: 0.0342
ERROR - 2024-02-07 06:33:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:33:16 --> Config Class Initialized
INFO - 2024-02-07 06:33:16 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:33:16 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:33:16 --> Utf8 Class Initialized
INFO - 2024-02-07 06:33:16 --> URI Class Initialized
INFO - 2024-02-07 06:33:16 --> Router Class Initialized
INFO - 2024-02-07 06:33:16 --> Output Class Initialized
INFO - 2024-02-07 06:33:16 --> Security Class Initialized
DEBUG - 2024-02-07 06:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:33:16 --> Input Class Initialized
INFO - 2024-02-07 06:33:16 --> Language Class Initialized
INFO - 2024-02-07 06:33:16 --> Loader Class Initialized
INFO - 2024-02-07 06:33:16 --> Helper loaded: url_helper
INFO - 2024-02-07 06:33:16 --> Helper loaded: file_helper
INFO - 2024-02-07 06:33:16 --> Helper loaded: html_helper
INFO - 2024-02-07 06:33:16 --> Helper loaded: text_helper
INFO - 2024-02-07 06:33:16 --> Helper loaded: form_helper
INFO - 2024-02-07 06:33:16 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:33:16 --> Helper loaded: security_helper
INFO - 2024-02-07 06:33:16 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:33:16 --> Database Driver Class Initialized
INFO - 2024-02-07 06:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:33:16 --> Parser Class Initialized
INFO - 2024-02-07 06:33:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:33:16 --> Pagination Class Initialized
INFO - 2024-02-07 06:33:16 --> Form Validation Class Initialized
INFO - 2024-02-07 06:33:16 --> Controller Class Initialized
INFO - 2024-02-07 06:33:16 --> Model Class Initialized
DEBUG - 2024-02-07 06:33:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:33:16 --> Model Class Initialized
INFO - 2024-02-07 06:33:16 --> Final output sent to browser
DEBUG - 2024-02-07 06:33:16 --> Total execution time: 0.0208
ERROR - 2024-02-07 06:33:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:33:17 --> Config Class Initialized
INFO - 2024-02-07 06:33:17 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:33:17 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:33:17 --> Utf8 Class Initialized
INFO - 2024-02-07 06:33:17 --> URI Class Initialized
INFO - 2024-02-07 06:33:17 --> Router Class Initialized
INFO - 2024-02-07 06:33:17 --> Output Class Initialized
INFO - 2024-02-07 06:33:17 --> Security Class Initialized
DEBUG - 2024-02-07 06:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:33:17 --> Input Class Initialized
INFO - 2024-02-07 06:33:17 --> Language Class Initialized
INFO - 2024-02-07 06:33:17 --> Loader Class Initialized
INFO - 2024-02-07 06:33:17 --> Helper loaded: url_helper
INFO - 2024-02-07 06:33:17 --> Helper loaded: file_helper
INFO - 2024-02-07 06:33:17 --> Helper loaded: html_helper
INFO - 2024-02-07 06:33:17 --> Helper loaded: text_helper
INFO - 2024-02-07 06:33:17 --> Helper loaded: form_helper
INFO - 2024-02-07 06:33:17 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:33:17 --> Helper loaded: security_helper
INFO - 2024-02-07 06:33:17 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:33:17 --> Database Driver Class Initialized
INFO - 2024-02-07 06:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:33:17 --> Parser Class Initialized
INFO - 2024-02-07 06:33:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:33:17 --> Pagination Class Initialized
INFO - 2024-02-07 06:33:17 --> Form Validation Class Initialized
INFO - 2024-02-07 06:33:17 --> Controller Class Initialized
INFO - 2024-02-07 06:33:17 --> Model Class Initialized
DEBUG - 2024-02-07 06:33:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:33:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-07 06:33:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:33:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:33:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:33:17 --> Model Class Initialized
INFO - 2024-02-07 06:33:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:33:17 --> Final output sent to browser
DEBUG - 2024-02-07 06:33:17 --> Total execution time: 0.0285
ERROR - 2024-02-07 06:33:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:33:28 --> Config Class Initialized
INFO - 2024-02-07 06:33:28 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:33:28 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:33:28 --> Utf8 Class Initialized
INFO - 2024-02-07 06:33:28 --> URI Class Initialized
INFO - 2024-02-07 06:33:28 --> Router Class Initialized
INFO - 2024-02-07 06:33:28 --> Output Class Initialized
INFO - 2024-02-07 06:33:28 --> Security Class Initialized
DEBUG - 2024-02-07 06:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:33:28 --> Input Class Initialized
INFO - 2024-02-07 06:33:28 --> Language Class Initialized
INFO - 2024-02-07 06:33:28 --> Loader Class Initialized
INFO - 2024-02-07 06:33:28 --> Helper loaded: url_helper
INFO - 2024-02-07 06:33:28 --> Helper loaded: file_helper
INFO - 2024-02-07 06:33:28 --> Helper loaded: html_helper
INFO - 2024-02-07 06:33:28 --> Helper loaded: text_helper
INFO - 2024-02-07 06:33:28 --> Helper loaded: form_helper
INFO - 2024-02-07 06:33:28 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:33:28 --> Helper loaded: security_helper
INFO - 2024-02-07 06:33:28 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:33:28 --> Database Driver Class Initialized
INFO - 2024-02-07 06:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:33:28 --> Parser Class Initialized
INFO - 2024-02-07 06:33:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:33:28 --> Pagination Class Initialized
INFO - 2024-02-07 06:33:28 --> Form Validation Class Initialized
INFO - 2024-02-07 06:33:28 --> Controller Class Initialized
DEBUG - 2024-02-07 06:33:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:33:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:33:28 --> Model Class Initialized
DEBUG - 2024-02-07 06:33:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:33:28 --> Model Class Initialized
DEBUG - 2024-02-07 06:33:28 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:33:28 --> Model Class Initialized
INFO - 2024-02-07 06:33:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-07 06:33:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:33:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:33:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:33:28 --> Model Class Initialized
INFO - 2024-02-07 06:33:28 --> Model Class Initialized
INFO - 2024-02-07 06:33:29 --> Model Class Initialized
INFO - 2024-02-07 06:33:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 06:33:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 06:33:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:33:29 --> Final output sent to browser
DEBUG - 2024-02-07 06:33:29 --> Total execution time: 0.1960
ERROR - 2024-02-07 06:33:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:33:29 --> Config Class Initialized
INFO - 2024-02-07 06:33:29 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:33:29 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:33:29 --> Utf8 Class Initialized
INFO - 2024-02-07 06:33:29 --> URI Class Initialized
INFO - 2024-02-07 06:33:29 --> Router Class Initialized
INFO - 2024-02-07 06:33:29 --> Output Class Initialized
INFO - 2024-02-07 06:33:29 --> Security Class Initialized
DEBUG - 2024-02-07 06:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:33:29 --> Input Class Initialized
INFO - 2024-02-07 06:33:29 --> Language Class Initialized
INFO - 2024-02-07 06:33:29 --> Loader Class Initialized
INFO - 2024-02-07 06:33:29 --> Helper loaded: url_helper
INFO - 2024-02-07 06:33:29 --> Helper loaded: file_helper
INFO - 2024-02-07 06:33:29 --> Helper loaded: html_helper
INFO - 2024-02-07 06:33:29 --> Helper loaded: text_helper
INFO - 2024-02-07 06:33:29 --> Helper loaded: form_helper
INFO - 2024-02-07 06:33:29 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:33:29 --> Helper loaded: security_helper
INFO - 2024-02-07 06:33:29 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:33:29 --> Database Driver Class Initialized
INFO - 2024-02-07 06:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:33:29 --> Parser Class Initialized
INFO - 2024-02-07 06:33:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:33:29 --> Pagination Class Initialized
INFO - 2024-02-07 06:33:29 --> Form Validation Class Initialized
INFO - 2024-02-07 06:33:29 --> Controller Class Initialized
DEBUG - 2024-02-07 06:33:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:33:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:33:29 --> Model Class Initialized
DEBUG - 2024-02-07 06:33:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:33:29 --> Model Class Initialized
INFO - 2024-02-07 06:33:29 --> Final output sent to browser
DEBUG - 2024-02-07 06:33:29 --> Total execution time: 0.0310
ERROR - 2024-02-07 06:33:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:33:33 --> Config Class Initialized
INFO - 2024-02-07 06:33:33 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:33:33 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:33:33 --> Utf8 Class Initialized
INFO - 2024-02-07 06:33:33 --> URI Class Initialized
INFO - 2024-02-07 06:33:33 --> Router Class Initialized
INFO - 2024-02-07 06:33:33 --> Output Class Initialized
INFO - 2024-02-07 06:33:33 --> Security Class Initialized
DEBUG - 2024-02-07 06:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:33:33 --> Input Class Initialized
INFO - 2024-02-07 06:33:33 --> Language Class Initialized
INFO - 2024-02-07 06:33:33 --> Loader Class Initialized
INFO - 2024-02-07 06:33:33 --> Helper loaded: url_helper
INFO - 2024-02-07 06:33:33 --> Helper loaded: file_helper
INFO - 2024-02-07 06:33:33 --> Helper loaded: html_helper
INFO - 2024-02-07 06:33:33 --> Helper loaded: text_helper
INFO - 2024-02-07 06:33:33 --> Helper loaded: form_helper
INFO - 2024-02-07 06:33:33 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:33:33 --> Helper loaded: security_helper
INFO - 2024-02-07 06:33:33 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:33:33 --> Database Driver Class Initialized
INFO - 2024-02-07 06:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:33:33 --> Parser Class Initialized
INFO - 2024-02-07 06:33:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:33:33 --> Pagination Class Initialized
INFO - 2024-02-07 06:33:33 --> Form Validation Class Initialized
INFO - 2024-02-07 06:33:33 --> Controller Class Initialized
DEBUG - 2024-02-07 06:33:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:33:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:33:33 --> Model Class Initialized
DEBUG - 2024-02-07 06:33:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:33:33 --> Model Class Initialized
INFO - 2024-02-07 06:33:33 --> Final output sent to browser
DEBUG - 2024-02-07 06:33:33 --> Total execution time: 0.0340
ERROR - 2024-02-07 06:33:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:33:33 --> Config Class Initialized
INFO - 2024-02-07 06:33:33 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:33:33 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:33:33 --> Utf8 Class Initialized
INFO - 2024-02-07 06:33:33 --> URI Class Initialized
INFO - 2024-02-07 06:33:33 --> Router Class Initialized
INFO - 2024-02-07 06:33:33 --> Output Class Initialized
INFO - 2024-02-07 06:33:33 --> Security Class Initialized
DEBUG - 2024-02-07 06:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:33:33 --> Input Class Initialized
INFO - 2024-02-07 06:33:33 --> Language Class Initialized
INFO - 2024-02-07 06:33:33 --> Loader Class Initialized
INFO - 2024-02-07 06:33:33 --> Helper loaded: url_helper
INFO - 2024-02-07 06:33:33 --> Helper loaded: file_helper
INFO - 2024-02-07 06:33:33 --> Helper loaded: html_helper
INFO - 2024-02-07 06:33:33 --> Helper loaded: text_helper
INFO - 2024-02-07 06:33:33 --> Helper loaded: form_helper
INFO - 2024-02-07 06:33:33 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:33:33 --> Helper loaded: security_helper
INFO - 2024-02-07 06:33:33 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:33:33 --> Database Driver Class Initialized
INFO - 2024-02-07 06:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:33:33 --> Parser Class Initialized
INFO - 2024-02-07 06:33:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:33:33 --> Pagination Class Initialized
INFO - 2024-02-07 06:33:33 --> Form Validation Class Initialized
INFO - 2024-02-07 06:33:33 --> Controller Class Initialized
DEBUG - 2024-02-07 06:33:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:33:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:33:33 --> Model Class Initialized
DEBUG - 2024-02-07 06:33:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:33:33 --> Model Class Initialized
INFO - 2024-02-07 06:33:33 --> Final output sent to browser
DEBUG - 2024-02-07 06:33:33 --> Total execution time: 0.0322
ERROR - 2024-02-07 06:33:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:33:35 --> Config Class Initialized
INFO - 2024-02-07 06:33:35 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:33:35 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:33:35 --> Utf8 Class Initialized
INFO - 2024-02-07 06:33:35 --> URI Class Initialized
INFO - 2024-02-07 06:33:35 --> Router Class Initialized
INFO - 2024-02-07 06:33:35 --> Output Class Initialized
INFO - 2024-02-07 06:33:35 --> Security Class Initialized
DEBUG - 2024-02-07 06:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:33:35 --> Input Class Initialized
INFO - 2024-02-07 06:33:35 --> Language Class Initialized
INFO - 2024-02-07 06:33:35 --> Loader Class Initialized
INFO - 2024-02-07 06:33:35 --> Helper loaded: url_helper
INFO - 2024-02-07 06:33:35 --> Helper loaded: file_helper
INFO - 2024-02-07 06:33:35 --> Helper loaded: html_helper
INFO - 2024-02-07 06:33:35 --> Helper loaded: text_helper
INFO - 2024-02-07 06:33:35 --> Helper loaded: form_helper
INFO - 2024-02-07 06:33:35 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:33:35 --> Helper loaded: security_helper
INFO - 2024-02-07 06:33:35 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:33:35 --> Database Driver Class Initialized
INFO - 2024-02-07 06:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:33:35 --> Parser Class Initialized
INFO - 2024-02-07 06:33:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:33:35 --> Pagination Class Initialized
INFO - 2024-02-07 06:33:35 --> Form Validation Class Initialized
INFO - 2024-02-07 06:33:35 --> Controller Class Initialized
DEBUG - 2024-02-07 06:33:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:33:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:33:35 --> Model Class Initialized
DEBUG - 2024-02-07 06:33:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:33:35 --> Model Class Initialized
INFO - 2024-02-07 06:33:35 --> Final output sent to browser
DEBUG - 2024-02-07 06:33:35 --> Total execution time: 0.0255
ERROR - 2024-02-07 06:33:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:33:36 --> Config Class Initialized
INFO - 2024-02-07 06:33:36 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:33:36 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:33:36 --> Utf8 Class Initialized
INFO - 2024-02-07 06:33:36 --> URI Class Initialized
INFO - 2024-02-07 06:33:36 --> Router Class Initialized
INFO - 2024-02-07 06:33:36 --> Output Class Initialized
INFO - 2024-02-07 06:33:36 --> Security Class Initialized
DEBUG - 2024-02-07 06:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:33:36 --> Input Class Initialized
INFO - 2024-02-07 06:33:36 --> Language Class Initialized
INFO - 2024-02-07 06:33:36 --> Loader Class Initialized
INFO - 2024-02-07 06:33:36 --> Helper loaded: url_helper
INFO - 2024-02-07 06:33:36 --> Helper loaded: file_helper
INFO - 2024-02-07 06:33:36 --> Helper loaded: html_helper
INFO - 2024-02-07 06:33:36 --> Helper loaded: text_helper
INFO - 2024-02-07 06:33:36 --> Helper loaded: form_helper
INFO - 2024-02-07 06:33:36 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:33:36 --> Helper loaded: security_helper
INFO - 2024-02-07 06:33:36 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:33:36 --> Database Driver Class Initialized
INFO - 2024-02-07 06:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:33:36 --> Parser Class Initialized
INFO - 2024-02-07 06:33:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:33:36 --> Pagination Class Initialized
INFO - 2024-02-07 06:33:36 --> Form Validation Class Initialized
INFO - 2024-02-07 06:33:36 --> Controller Class Initialized
DEBUG - 2024-02-07 06:33:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:33:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:33:36 --> Model Class Initialized
DEBUG - 2024-02-07 06:33:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:33:36 --> Model Class Initialized
INFO - 2024-02-07 06:33:36 --> Final output sent to browser
DEBUG - 2024-02-07 06:33:36 --> Total execution time: 0.0211
ERROR - 2024-02-07 06:33:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:33:40 --> Config Class Initialized
INFO - 2024-02-07 06:33:40 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:33:40 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:33:40 --> Utf8 Class Initialized
INFO - 2024-02-07 06:33:40 --> URI Class Initialized
INFO - 2024-02-07 06:33:40 --> Router Class Initialized
INFO - 2024-02-07 06:33:40 --> Output Class Initialized
INFO - 2024-02-07 06:33:40 --> Security Class Initialized
DEBUG - 2024-02-07 06:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:33:40 --> Input Class Initialized
INFO - 2024-02-07 06:33:40 --> Language Class Initialized
INFO - 2024-02-07 06:33:40 --> Loader Class Initialized
INFO - 2024-02-07 06:33:40 --> Helper loaded: url_helper
INFO - 2024-02-07 06:33:40 --> Helper loaded: file_helper
INFO - 2024-02-07 06:33:40 --> Helper loaded: html_helper
INFO - 2024-02-07 06:33:40 --> Helper loaded: text_helper
INFO - 2024-02-07 06:33:40 --> Helper loaded: form_helper
INFO - 2024-02-07 06:33:40 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:33:40 --> Helper loaded: security_helper
INFO - 2024-02-07 06:33:40 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:33:40 --> Database Driver Class Initialized
INFO - 2024-02-07 06:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:33:40 --> Parser Class Initialized
INFO - 2024-02-07 06:33:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:33:40 --> Pagination Class Initialized
INFO - 2024-02-07 06:33:40 --> Form Validation Class Initialized
INFO - 2024-02-07 06:33:40 --> Controller Class Initialized
DEBUG - 2024-02-07 06:33:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:33:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:33:40 --> Model Class Initialized
DEBUG - 2024-02-07 06:33:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:33:40 --> Model Class Initialized
INFO - 2024-02-07 06:33:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer_change_password_form.php
DEBUG - 2024-02-07 06:33:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:33:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:33:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:33:40 --> Model Class Initialized
INFO - 2024-02-07 06:33:40 --> Model Class Initialized
INFO - 2024-02-07 06:33:40 --> Model Class Initialized
INFO - 2024-02-07 06:33:40 --> Model Class Initialized
INFO - 2024-02-07 06:33:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 06:33:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 06:33:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:33:41 --> Final output sent to browser
DEBUG - 2024-02-07 06:33:41 --> Total execution time: 0.1818
ERROR - 2024-02-07 06:34:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:34:54 --> Config Class Initialized
INFO - 2024-02-07 06:34:54 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:34:54 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:34:54 --> Utf8 Class Initialized
INFO - 2024-02-07 06:34:54 --> URI Class Initialized
INFO - 2024-02-07 06:34:54 --> Router Class Initialized
INFO - 2024-02-07 06:34:54 --> Output Class Initialized
INFO - 2024-02-07 06:34:54 --> Security Class Initialized
DEBUG - 2024-02-07 06:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:34:54 --> Input Class Initialized
INFO - 2024-02-07 06:34:54 --> Language Class Initialized
INFO - 2024-02-07 06:34:54 --> Loader Class Initialized
INFO - 2024-02-07 06:34:54 --> Helper loaded: url_helper
INFO - 2024-02-07 06:34:54 --> Helper loaded: file_helper
INFO - 2024-02-07 06:34:54 --> Helper loaded: html_helper
INFO - 2024-02-07 06:34:54 --> Helper loaded: text_helper
INFO - 2024-02-07 06:34:54 --> Helper loaded: form_helper
INFO - 2024-02-07 06:34:54 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:34:54 --> Helper loaded: security_helper
INFO - 2024-02-07 06:34:54 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:34:54 --> Database Driver Class Initialized
INFO - 2024-02-07 06:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:34:54 --> Parser Class Initialized
INFO - 2024-02-07 06:34:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:34:54 --> Pagination Class Initialized
INFO - 2024-02-07 06:34:54 --> Form Validation Class Initialized
INFO - 2024-02-07 06:34:54 --> Controller Class Initialized
INFO - 2024-02-07 06:34:54 --> Model Class Initialized
DEBUG - 2024-02-07 06:34:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:34:54 --> Model Class Initialized
INFO - 2024-02-07 06:34:54 --> Final output sent to browser
DEBUG - 2024-02-07 06:34:54 --> Total execution time: 0.0206
ERROR - 2024-02-07 06:34:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:34:54 --> Config Class Initialized
INFO - 2024-02-07 06:34:54 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:34:54 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:34:54 --> Utf8 Class Initialized
INFO - 2024-02-07 06:34:54 --> URI Class Initialized
INFO - 2024-02-07 06:34:54 --> Router Class Initialized
INFO - 2024-02-07 06:34:54 --> Output Class Initialized
INFO - 2024-02-07 06:34:54 --> Security Class Initialized
DEBUG - 2024-02-07 06:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:34:54 --> Input Class Initialized
INFO - 2024-02-07 06:34:54 --> Language Class Initialized
INFO - 2024-02-07 06:34:54 --> Loader Class Initialized
INFO - 2024-02-07 06:34:54 --> Helper loaded: url_helper
INFO - 2024-02-07 06:34:54 --> Helper loaded: file_helper
INFO - 2024-02-07 06:34:54 --> Helper loaded: html_helper
INFO - 2024-02-07 06:34:54 --> Helper loaded: text_helper
INFO - 2024-02-07 06:34:54 --> Helper loaded: form_helper
INFO - 2024-02-07 06:34:54 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:34:54 --> Helper loaded: security_helper
INFO - 2024-02-07 06:34:54 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:34:54 --> Database Driver Class Initialized
INFO - 2024-02-07 06:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:34:54 --> Parser Class Initialized
INFO - 2024-02-07 06:34:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:34:54 --> Pagination Class Initialized
INFO - 2024-02-07 06:34:54 --> Form Validation Class Initialized
INFO - 2024-02-07 06:34:54 --> Controller Class Initialized
INFO - 2024-02-07 06:34:54 --> Model Class Initialized
DEBUG - 2024-02-07 06:34:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:34:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-07 06:34:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:34:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:34:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:34:54 --> Model Class Initialized
INFO - 2024-02-07 06:34:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:34:54 --> Final output sent to browser
DEBUG - 2024-02-07 06:34:54 --> Total execution time: 0.0302
ERROR - 2024-02-07 06:35:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:35:06 --> Config Class Initialized
INFO - 2024-02-07 06:35:06 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:35:06 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:35:06 --> Utf8 Class Initialized
INFO - 2024-02-07 06:35:06 --> URI Class Initialized
INFO - 2024-02-07 06:35:06 --> Router Class Initialized
INFO - 2024-02-07 06:35:06 --> Output Class Initialized
INFO - 2024-02-07 06:35:06 --> Security Class Initialized
DEBUG - 2024-02-07 06:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:35:06 --> Input Class Initialized
INFO - 2024-02-07 06:35:06 --> Language Class Initialized
INFO - 2024-02-07 06:35:06 --> Loader Class Initialized
INFO - 2024-02-07 06:35:06 --> Helper loaded: url_helper
INFO - 2024-02-07 06:35:06 --> Helper loaded: file_helper
INFO - 2024-02-07 06:35:06 --> Helper loaded: html_helper
INFO - 2024-02-07 06:35:06 --> Helper loaded: text_helper
INFO - 2024-02-07 06:35:06 --> Helper loaded: form_helper
INFO - 2024-02-07 06:35:06 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:35:06 --> Helper loaded: security_helper
INFO - 2024-02-07 06:35:06 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:35:06 --> Database Driver Class Initialized
INFO - 2024-02-07 06:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:35:06 --> Parser Class Initialized
INFO - 2024-02-07 06:35:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:35:06 --> Pagination Class Initialized
INFO - 2024-02-07 06:35:06 --> Form Validation Class Initialized
INFO - 2024-02-07 06:35:06 --> Controller Class Initialized
DEBUG - 2024-02-07 06:35:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:35:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:06 --> Model Class Initialized
DEBUG - 2024-02-07 06:35:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:06 --> Model Class Initialized
ERROR - 2024-02-07 06:35:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:35:06 --> Config Class Initialized
INFO - 2024-02-07 06:35:06 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:35:06 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:35:06 --> Utf8 Class Initialized
INFO - 2024-02-07 06:35:06 --> URI Class Initialized
INFO - 2024-02-07 06:35:06 --> Router Class Initialized
INFO - 2024-02-07 06:35:06 --> Output Class Initialized
INFO - 2024-02-07 06:35:06 --> Security Class Initialized
DEBUG - 2024-02-07 06:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:35:06 --> Input Class Initialized
INFO - 2024-02-07 06:35:06 --> Language Class Initialized
INFO - 2024-02-07 06:35:06 --> Loader Class Initialized
INFO - 2024-02-07 06:35:06 --> Helper loaded: url_helper
INFO - 2024-02-07 06:35:06 --> Helper loaded: file_helper
INFO - 2024-02-07 06:35:06 --> Helper loaded: html_helper
INFO - 2024-02-07 06:35:06 --> Helper loaded: text_helper
INFO - 2024-02-07 06:35:06 --> Helper loaded: form_helper
INFO - 2024-02-07 06:35:06 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:35:06 --> Helper loaded: security_helper
INFO - 2024-02-07 06:35:06 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:35:06 --> Database Driver Class Initialized
INFO - 2024-02-07 06:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:35:06 --> Parser Class Initialized
INFO - 2024-02-07 06:35:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:35:06 --> Pagination Class Initialized
INFO - 2024-02-07 06:35:06 --> Form Validation Class Initialized
INFO - 2024-02-07 06:35:06 --> Controller Class Initialized
DEBUG - 2024-02-07 06:35:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:35:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:06 --> Model Class Initialized
DEBUG - 2024-02-07 06:35:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:06 --> Model Class Initialized
DEBUG - 2024-02-07 06:35:06 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:06 --> Model Class Initialized
INFO - 2024-02-07 06:35:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-07 06:35:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:35:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:35:06 --> Model Class Initialized
INFO - 2024-02-07 06:35:06 --> Model Class Initialized
INFO - 2024-02-07 06:35:06 --> Model Class Initialized
INFO - 2024-02-07 06:35:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 06:35:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 06:35:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:35:07 --> Final output sent to browser
DEBUG - 2024-02-07 06:35:07 --> Total execution time: 0.2042
ERROR - 2024-02-07 06:35:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:35:07 --> Config Class Initialized
INFO - 2024-02-07 06:35:07 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:35:07 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:35:07 --> Utf8 Class Initialized
INFO - 2024-02-07 06:35:07 --> URI Class Initialized
INFO - 2024-02-07 06:35:07 --> Router Class Initialized
INFO - 2024-02-07 06:35:07 --> Output Class Initialized
INFO - 2024-02-07 06:35:07 --> Security Class Initialized
DEBUG - 2024-02-07 06:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:35:07 --> Input Class Initialized
INFO - 2024-02-07 06:35:07 --> Language Class Initialized
INFO - 2024-02-07 06:35:07 --> Loader Class Initialized
INFO - 2024-02-07 06:35:07 --> Helper loaded: url_helper
INFO - 2024-02-07 06:35:07 --> Helper loaded: file_helper
INFO - 2024-02-07 06:35:07 --> Helper loaded: html_helper
INFO - 2024-02-07 06:35:07 --> Helper loaded: text_helper
INFO - 2024-02-07 06:35:07 --> Helper loaded: form_helper
INFO - 2024-02-07 06:35:07 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:35:07 --> Helper loaded: security_helper
INFO - 2024-02-07 06:35:07 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:35:07 --> Database Driver Class Initialized
INFO - 2024-02-07 06:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:35:07 --> Parser Class Initialized
INFO - 2024-02-07 06:35:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:35:07 --> Pagination Class Initialized
INFO - 2024-02-07 06:35:07 --> Form Validation Class Initialized
INFO - 2024-02-07 06:35:07 --> Controller Class Initialized
DEBUG - 2024-02-07 06:35:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:35:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:07 --> Model Class Initialized
DEBUG - 2024-02-07 06:35:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:07 --> Model Class Initialized
INFO - 2024-02-07 06:35:07 --> Final output sent to browser
DEBUG - 2024-02-07 06:35:07 --> Total execution time: 0.0300
ERROR - 2024-02-07 06:35:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:35:13 --> Config Class Initialized
INFO - 2024-02-07 06:35:13 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:35:13 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:35:13 --> Utf8 Class Initialized
INFO - 2024-02-07 06:35:13 --> URI Class Initialized
INFO - 2024-02-07 06:35:13 --> Router Class Initialized
INFO - 2024-02-07 06:35:13 --> Output Class Initialized
INFO - 2024-02-07 06:35:13 --> Security Class Initialized
DEBUG - 2024-02-07 06:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:35:13 --> Input Class Initialized
INFO - 2024-02-07 06:35:13 --> Language Class Initialized
INFO - 2024-02-07 06:35:13 --> Loader Class Initialized
INFO - 2024-02-07 06:35:13 --> Helper loaded: url_helper
INFO - 2024-02-07 06:35:13 --> Helper loaded: file_helper
INFO - 2024-02-07 06:35:13 --> Helper loaded: html_helper
INFO - 2024-02-07 06:35:13 --> Helper loaded: text_helper
INFO - 2024-02-07 06:35:13 --> Helper loaded: form_helper
INFO - 2024-02-07 06:35:13 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:35:13 --> Helper loaded: security_helper
INFO - 2024-02-07 06:35:13 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:35:13 --> Database Driver Class Initialized
INFO - 2024-02-07 06:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:35:13 --> Parser Class Initialized
INFO - 2024-02-07 06:35:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:35:13 --> Pagination Class Initialized
INFO - 2024-02-07 06:35:13 --> Form Validation Class Initialized
INFO - 2024-02-07 06:35:13 --> Controller Class Initialized
DEBUG - 2024-02-07 06:35:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:35:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:13 --> Model Class Initialized
DEBUG - 2024-02-07 06:35:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:13 --> Model Class Initialized
INFO - 2024-02-07 06:35:13 --> Final output sent to browser
DEBUG - 2024-02-07 06:35:13 --> Total execution time: 0.0328
ERROR - 2024-02-07 06:35:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:35:14 --> Config Class Initialized
INFO - 2024-02-07 06:35:14 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:35:14 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:35:14 --> Utf8 Class Initialized
INFO - 2024-02-07 06:35:14 --> URI Class Initialized
INFO - 2024-02-07 06:35:14 --> Router Class Initialized
INFO - 2024-02-07 06:35:14 --> Output Class Initialized
INFO - 2024-02-07 06:35:14 --> Security Class Initialized
DEBUG - 2024-02-07 06:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:35:14 --> Input Class Initialized
INFO - 2024-02-07 06:35:14 --> Language Class Initialized
INFO - 2024-02-07 06:35:14 --> Loader Class Initialized
INFO - 2024-02-07 06:35:14 --> Helper loaded: url_helper
INFO - 2024-02-07 06:35:14 --> Helper loaded: file_helper
INFO - 2024-02-07 06:35:14 --> Helper loaded: html_helper
INFO - 2024-02-07 06:35:14 --> Helper loaded: text_helper
INFO - 2024-02-07 06:35:14 --> Helper loaded: form_helper
INFO - 2024-02-07 06:35:14 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:35:14 --> Helper loaded: security_helper
INFO - 2024-02-07 06:35:14 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:35:14 --> Database Driver Class Initialized
INFO - 2024-02-07 06:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:35:14 --> Parser Class Initialized
INFO - 2024-02-07 06:35:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:35:14 --> Pagination Class Initialized
INFO - 2024-02-07 06:35:14 --> Form Validation Class Initialized
INFO - 2024-02-07 06:35:14 --> Controller Class Initialized
DEBUG - 2024-02-07 06:35:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:35:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:14 --> Model Class Initialized
DEBUG - 2024-02-07 06:35:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:14 --> Model Class Initialized
INFO - 2024-02-07 06:35:14 --> Final output sent to browser
DEBUG - 2024-02-07 06:35:14 --> Total execution time: 0.0316
ERROR - 2024-02-07 06:35:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:35:14 --> Config Class Initialized
INFO - 2024-02-07 06:35:14 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:35:14 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:35:14 --> Utf8 Class Initialized
INFO - 2024-02-07 06:35:14 --> URI Class Initialized
INFO - 2024-02-07 06:35:14 --> Router Class Initialized
INFO - 2024-02-07 06:35:14 --> Output Class Initialized
INFO - 2024-02-07 06:35:14 --> Security Class Initialized
DEBUG - 2024-02-07 06:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:35:14 --> Input Class Initialized
INFO - 2024-02-07 06:35:14 --> Language Class Initialized
INFO - 2024-02-07 06:35:14 --> Loader Class Initialized
INFO - 2024-02-07 06:35:14 --> Helper loaded: url_helper
INFO - 2024-02-07 06:35:14 --> Helper loaded: file_helper
INFO - 2024-02-07 06:35:14 --> Helper loaded: html_helper
INFO - 2024-02-07 06:35:14 --> Helper loaded: text_helper
INFO - 2024-02-07 06:35:14 --> Helper loaded: form_helper
INFO - 2024-02-07 06:35:14 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:35:14 --> Helper loaded: security_helper
INFO - 2024-02-07 06:35:14 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:35:14 --> Database Driver Class Initialized
INFO - 2024-02-07 06:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:35:14 --> Parser Class Initialized
INFO - 2024-02-07 06:35:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:35:14 --> Pagination Class Initialized
INFO - 2024-02-07 06:35:14 --> Form Validation Class Initialized
INFO - 2024-02-07 06:35:14 --> Controller Class Initialized
DEBUG - 2024-02-07 06:35:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:35:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:14 --> Model Class Initialized
DEBUG - 2024-02-07 06:35:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:14 --> Model Class Initialized
INFO - 2024-02-07 06:35:14 --> Final output sent to browser
DEBUG - 2024-02-07 06:35:14 --> Total execution time: 0.0307
ERROR - 2024-02-07 06:35:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:35:15 --> Config Class Initialized
INFO - 2024-02-07 06:35:15 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:35:15 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:35:15 --> Utf8 Class Initialized
INFO - 2024-02-07 06:35:15 --> URI Class Initialized
INFO - 2024-02-07 06:35:15 --> Router Class Initialized
INFO - 2024-02-07 06:35:15 --> Output Class Initialized
INFO - 2024-02-07 06:35:15 --> Security Class Initialized
DEBUG - 2024-02-07 06:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:35:15 --> Input Class Initialized
INFO - 2024-02-07 06:35:15 --> Language Class Initialized
INFO - 2024-02-07 06:35:15 --> Loader Class Initialized
INFO - 2024-02-07 06:35:15 --> Helper loaded: url_helper
INFO - 2024-02-07 06:35:15 --> Helper loaded: file_helper
INFO - 2024-02-07 06:35:15 --> Helper loaded: html_helper
INFO - 2024-02-07 06:35:15 --> Helper loaded: text_helper
INFO - 2024-02-07 06:35:15 --> Helper loaded: form_helper
INFO - 2024-02-07 06:35:15 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:35:15 --> Helper loaded: security_helper
INFO - 2024-02-07 06:35:15 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:35:15 --> Database Driver Class Initialized
INFO - 2024-02-07 06:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:35:15 --> Parser Class Initialized
INFO - 2024-02-07 06:35:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:35:15 --> Pagination Class Initialized
INFO - 2024-02-07 06:35:15 --> Form Validation Class Initialized
INFO - 2024-02-07 06:35:15 --> Controller Class Initialized
DEBUG - 2024-02-07 06:35:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:35:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:15 --> Model Class Initialized
DEBUG - 2024-02-07 06:35:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:15 --> Model Class Initialized
INFO - 2024-02-07 06:35:15 --> Final output sent to browser
DEBUG - 2024-02-07 06:35:15 --> Total execution time: 0.0237
ERROR - 2024-02-07 06:35:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:35:16 --> Config Class Initialized
INFO - 2024-02-07 06:35:16 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:35:16 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:35:16 --> Utf8 Class Initialized
INFO - 2024-02-07 06:35:16 --> URI Class Initialized
INFO - 2024-02-07 06:35:16 --> Router Class Initialized
INFO - 2024-02-07 06:35:16 --> Output Class Initialized
INFO - 2024-02-07 06:35:16 --> Security Class Initialized
DEBUG - 2024-02-07 06:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:35:16 --> Input Class Initialized
INFO - 2024-02-07 06:35:16 --> Language Class Initialized
INFO - 2024-02-07 06:35:16 --> Loader Class Initialized
INFO - 2024-02-07 06:35:16 --> Helper loaded: url_helper
INFO - 2024-02-07 06:35:16 --> Helper loaded: file_helper
INFO - 2024-02-07 06:35:16 --> Helper loaded: html_helper
INFO - 2024-02-07 06:35:16 --> Helper loaded: text_helper
INFO - 2024-02-07 06:35:16 --> Helper loaded: form_helper
INFO - 2024-02-07 06:35:16 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:35:16 --> Helper loaded: security_helper
INFO - 2024-02-07 06:35:16 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:35:16 --> Database Driver Class Initialized
INFO - 2024-02-07 06:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:35:16 --> Parser Class Initialized
INFO - 2024-02-07 06:35:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:35:16 --> Pagination Class Initialized
INFO - 2024-02-07 06:35:16 --> Form Validation Class Initialized
INFO - 2024-02-07 06:35:16 --> Controller Class Initialized
DEBUG - 2024-02-07 06:35:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:35:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:16 --> Model Class Initialized
DEBUG - 2024-02-07 06:35:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:16 --> Model Class Initialized
INFO - 2024-02-07 06:35:16 --> Final output sent to browser
DEBUG - 2024-02-07 06:35:16 --> Total execution time: 0.0217
ERROR - 2024-02-07 06:35:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:35:16 --> Config Class Initialized
INFO - 2024-02-07 06:35:16 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:35:16 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:35:16 --> Utf8 Class Initialized
INFO - 2024-02-07 06:35:16 --> URI Class Initialized
INFO - 2024-02-07 06:35:16 --> Router Class Initialized
INFO - 2024-02-07 06:35:16 --> Output Class Initialized
INFO - 2024-02-07 06:35:16 --> Security Class Initialized
DEBUG - 2024-02-07 06:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:35:16 --> Input Class Initialized
INFO - 2024-02-07 06:35:16 --> Language Class Initialized
INFO - 2024-02-07 06:35:16 --> Loader Class Initialized
INFO - 2024-02-07 06:35:16 --> Helper loaded: url_helper
INFO - 2024-02-07 06:35:16 --> Helper loaded: file_helper
INFO - 2024-02-07 06:35:16 --> Helper loaded: html_helper
INFO - 2024-02-07 06:35:16 --> Helper loaded: text_helper
INFO - 2024-02-07 06:35:16 --> Helper loaded: form_helper
INFO - 2024-02-07 06:35:16 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:35:16 --> Helper loaded: security_helper
INFO - 2024-02-07 06:35:16 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:35:16 --> Database Driver Class Initialized
INFO - 2024-02-07 06:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:35:16 --> Parser Class Initialized
INFO - 2024-02-07 06:35:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:35:16 --> Pagination Class Initialized
INFO - 2024-02-07 06:35:16 --> Form Validation Class Initialized
INFO - 2024-02-07 06:35:16 --> Controller Class Initialized
DEBUG - 2024-02-07 06:35:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:35:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:16 --> Model Class Initialized
DEBUG - 2024-02-07 06:35:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:16 --> Model Class Initialized
INFO - 2024-02-07 06:35:16 --> Final output sent to browser
DEBUG - 2024-02-07 06:35:16 --> Total execution time: 0.0176
ERROR - 2024-02-07 06:35:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:35:17 --> Config Class Initialized
INFO - 2024-02-07 06:35:17 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:35:17 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:35:17 --> Utf8 Class Initialized
INFO - 2024-02-07 06:35:17 --> URI Class Initialized
INFO - 2024-02-07 06:35:17 --> Router Class Initialized
INFO - 2024-02-07 06:35:17 --> Output Class Initialized
INFO - 2024-02-07 06:35:17 --> Security Class Initialized
DEBUG - 2024-02-07 06:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:35:17 --> Input Class Initialized
INFO - 2024-02-07 06:35:17 --> Language Class Initialized
INFO - 2024-02-07 06:35:17 --> Loader Class Initialized
INFO - 2024-02-07 06:35:17 --> Helper loaded: url_helper
INFO - 2024-02-07 06:35:17 --> Helper loaded: file_helper
INFO - 2024-02-07 06:35:17 --> Helper loaded: html_helper
INFO - 2024-02-07 06:35:17 --> Helper loaded: text_helper
INFO - 2024-02-07 06:35:17 --> Helper loaded: form_helper
INFO - 2024-02-07 06:35:17 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:35:17 --> Helper loaded: security_helper
INFO - 2024-02-07 06:35:17 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:35:17 --> Database Driver Class Initialized
INFO - 2024-02-07 06:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:35:17 --> Parser Class Initialized
INFO - 2024-02-07 06:35:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:35:17 --> Pagination Class Initialized
INFO - 2024-02-07 06:35:17 --> Form Validation Class Initialized
INFO - 2024-02-07 06:35:17 --> Controller Class Initialized
DEBUG - 2024-02-07 06:35:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:35:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:17 --> Model Class Initialized
DEBUG - 2024-02-07 06:35:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:17 --> Model Class Initialized
INFO - 2024-02-07 06:35:17 --> Final output sent to browser
DEBUG - 2024-02-07 06:35:17 --> Total execution time: 0.0171
ERROR - 2024-02-07 06:35:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:35:17 --> Config Class Initialized
INFO - 2024-02-07 06:35:17 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:35:17 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:35:17 --> Utf8 Class Initialized
INFO - 2024-02-07 06:35:17 --> URI Class Initialized
INFO - 2024-02-07 06:35:17 --> Router Class Initialized
INFO - 2024-02-07 06:35:17 --> Output Class Initialized
INFO - 2024-02-07 06:35:17 --> Security Class Initialized
DEBUG - 2024-02-07 06:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:35:17 --> Input Class Initialized
INFO - 2024-02-07 06:35:17 --> Language Class Initialized
INFO - 2024-02-07 06:35:17 --> Loader Class Initialized
INFO - 2024-02-07 06:35:17 --> Helper loaded: url_helper
INFO - 2024-02-07 06:35:17 --> Helper loaded: file_helper
INFO - 2024-02-07 06:35:17 --> Helper loaded: html_helper
INFO - 2024-02-07 06:35:17 --> Helper loaded: text_helper
INFO - 2024-02-07 06:35:17 --> Helper loaded: form_helper
INFO - 2024-02-07 06:35:17 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:35:17 --> Helper loaded: security_helper
INFO - 2024-02-07 06:35:17 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:35:17 --> Database Driver Class Initialized
INFO - 2024-02-07 06:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:35:17 --> Parser Class Initialized
INFO - 2024-02-07 06:35:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:35:17 --> Pagination Class Initialized
INFO - 2024-02-07 06:35:17 --> Form Validation Class Initialized
INFO - 2024-02-07 06:35:17 --> Controller Class Initialized
DEBUG - 2024-02-07 06:35:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:35:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:17 --> Model Class Initialized
DEBUG - 2024-02-07 06:35:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:17 --> Model Class Initialized
INFO - 2024-02-07 06:35:17 --> Final output sent to browser
DEBUG - 2024-02-07 06:35:17 --> Total execution time: 0.0169
ERROR - 2024-02-07 06:35:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:35:18 --> Config Class Initialized
INFO - 2024-02-07 06:35:18 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:35:18 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:35:18 --> Utf8 Class Initialized
INFO - 2024-02-07 06:35:18 --> URI Class Initialized
INFO - 2024-02-07 06:35:18 --> Router Class Initialized
INFO - 2024-02-07 06:35:18 --> Output Class Initialized
INFO - 2024-02-07 06:35:18 --> Security Class Initialized
DEBUG - 2024-02-07 06:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:35:18 --> Input Class Initialized
INFO - 2024-02-07 06:35:18 --> Language Class Initialized
INFO - 2024-02-07 06:35:18 --> Loader Class Initialized
INFO - 2024-02-07 06:35:18 --> Helper loaded: url_helper
INFO - 2024-02-07 06:35:18 --> Helper loaded: file_helper
INFO - 2024-02-07 06:35:18 --> Helper loaded: html_helper
INFO - 2024-02-07 06:35:18 --> Helper loaded: text_helper
INFO - 2024-02-07 06:35:18 --> Helper loaded: form_helper
INFO - 2024-02-07 06:35:18 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:35:18 --> Helper loaded: security_helper
INFO - 2024-02-07 06:35:18 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:35:18 --> Database Driver Class Initialized
INFO - 2024-02-07 06:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:35:18 --> Parser Class Initialized
INFO - 2024-02-07 06:35:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:35:18 --> Pagination Class Initialized
INFO - 2024-02-07 06:35:18 --> Form Validation Class Initialized
INFO - 2024-02-07 06:35:18 --> Controller Class Initialized
DEBUG - 2024-02-07 06:35:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:35:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:18 --> Model Class Initialized
DEBUG - 2024-02-07 06:35:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:18 --> Model Class Initialized
INFO - 2024-02-07 06:35:18 --> Final output sent to browser
DEBUG - 2024-02-07 06:35:18 --> Total execution time: 0.0180
ERROR - 2024-02-07 06:35:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:35:20 --> Config Class Initialized
INFO - 2024-02-07 06:35:20 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:35:20 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:35:20 --> Utf8 Class Initialized
INFO - 2024-02-07 06:35:20 --> URI Class Initialized
INFO - 2024-02-07 06:35:20 --> Router Class Initialized
INFO - 2024-02-07 06:35:20 --> Output Class Initialized
INFO - 2024-02-07 06:35:20 --> Security Class Initialized
DEBUG - 2024-02-07 06:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:35:20 --> Input Class Initialized
INFO - 2024-02-07 06:35:20 --> Language Class Initialized
INFO - 2024-02-07 06:35:20 --> Loader Class Initialized
INFO - 2024-02-07 06:35:20 --> Helper loaded: url_helper
INFO - 2024-02-07 06:35:20 --> Helper loaded: file_helper
INFO - 2024-02-07 06:35:20 --> Helper loaded: html_helper
INFO - 2024-02-07 06:35:20 --> Helper loaded: text_helper
INFO - 2024-02-07 06:35:20 --> Helper loaded: form_helper
INFO - 2024-02-07 06:35:20 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:35:20 --> Helper loaded: security_helper
INFO - 2024-02-07 06:35:20 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:35:20 --> Database Driver Class Initialized
INFO - 2024-02-07 06:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:35:20 --> Parser Class Initialized
INFO - 2024-02-07 06:35:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:35:20 --> Pagination Class Initialized
INFO - 2024-02-07 06:35:20 --> Form Validation Class Initialized
INFO - 2024-02-07 06:35:20 --> Controller Class Initialized
DEBUG - 2024-02-07 06:35:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:35:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:20 --> Model Class Initialized
DEBUG - 2024-02-07 06:35:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:20 --> Model Class Initialized
INFO - 2024-02-07 06:35:20 --> Final output sent to browser
DEBUG - 2024-02-07 06:35:20 --> Total execution time: 0.0174
ERROR - 2024-02-07 06:35:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:35:20 --> Config Class Initialized
INFO - 2024-02-07 06:35:20 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:35:20 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:35:20 --> Utf8 Class Initialized
INFO - 2024-02-07 06:35:20 --> URI Class Initialized
INFO - 2024-02-07 06:35:20 --> Router Class Initialized
INFO - 2024-02-07 06:35:20 --> Output Class Initialized
INFO - 2024-02-07 06:35:20 --> Security Class Initialized
DEBUG - 2024-02-07 06:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:35:20 --> Input Class Initialized
INFO - 2024-02-07 06:35:20 --> Language Class Initialized
INFO - 2024-02-07 06:35:20 --> Loader Class Initialized
INFO - 2024-02-07 06:35:20 --> Helper loaded: url_helper
INFO - 2024-02-07 06:35:20 --> Helper loaded: file_helper
INFO - 2024-02-07 06:35:20 --> Helper loaded: html_helper
INFO - 2024-02-07 06:35:20 --> Helper loaded: text_helper
INFO - 2024-02-07 06:35:20 --> Helper loaded: form_helper
INFO - 2024-02-07 06:35:20 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:35:20 --> Helper loaded: security_helper
INFO - 2024-02-07 06:35:20 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:35:20 --> Database Driver Class Initialized
INFO - 2024-02-07 06:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:35:20 --> Parser Class Initialized
INFO - 2024-02-07 06:35:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:35:20 --> Pagination Class Initialized
INFO - 2024-02-07 06:35:20 --> Form Validation Class Initialized
INFO - 2024-02-07 06:35:20 --> Controller Class Initialized
DEBUG - 2024-02-07 06:35:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:35:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:20 --> Model Class Initialized
DEBUG - 2024-02-07 06:35:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:20 --> Model Class Initialized
INFO - 2024-02-07 06:35:20 --> Final output sent to browser
DEBUG - 2024-02-07 06:35:20 --> Total execution time: 0.0206
ERROR - 2024-02-07 06:35:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:35:21 --> Config Class Initialized
INFO - 2024-02-07 06:35:21 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:35:21 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:35:21 --> Utf8 Class Initialized
INFO - 2024-02-07 06:35:21 --> URI Class Initialized
INFO - 2024-02-07 06:35:21 --> Router Class Initialized
INFO - 2024-02-07 06:35:21 --> Output Class Initialized
INFO - 2024-02-07 06:35:21 --> Security Class Initialized
DEBUG - 2024-02-07 06:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:35:21 --> Input Class Initialized
INFO - 2024-02-07 06:35:21 --> Language Class Initialized
INFO - 2024-02-07 06:35:21 --> Loader Class Initialized
INFO - 2024-02-07 06:35:21 --> Helper loaded: url_helper
INFO - 2024-02-07 06:35:21 --> Helper loaded: file_helper
INFO - 2024-02-07 06:35:21 --> Helper loaded: html_helper
INFO - 2024-02-07 06:35:21 --> Helper loaded: text_helper
INFO - 2024-02-07 06:35:21 --> Helper loaded: form_helper
INFO - 2024-02-07 06:35:21 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:35:21 --> Helper loaded: security_helper
INFO - 2024-02-07 06:35:21 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:35:21 --> Database Driver Class Initialized
INFO - 2024-02-07 06:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:35:21 --> Parser Class Initialized
INFO - 2024-02-07 06:35:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:35:21 --> Pagination Class Initialized
INFO - 2024-02-07 06:35:21 --> Form Validation Class Initialized
INFO - 2024-02-07 06:35:21 --> Controller Class Initialized
DEBUG - 2024-02-07 06:35:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:35:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:21 --> Model Class Initialized
DEBUG - 2024-02-07 06:35:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:21 --> Model Class Initialized
INFO - 2024-02-07 06:35:21 --> Final output sent to browser
DEBUG - 2024-02-07 06:35:21 --> Total execution time: 0.0378
ERROR - 2024-02-07 06:35:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:35:21 --> Config Class Initialized
INFO - 2024-02-07 06:35:21 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:35:21 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:35:21 --> Utf8 Class Initialized
INFO - 2024-02-07 06:35:21 --> URI Class Initialized
INFO - 2024-02-07 06:35:21 --> Router Class Initialized
INFO - 2024-02-07 06:35:21 --> Output Class Initialized
INFO - 2024-02-07 06:35:21 --> Security Class Initialized
DEBUG - 2024-02-07 06:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:35:21 --> Input Class Initialized
INFO - 2024-02-07 06:35:21 --> Language Class Initialized
INFO - 2024-02-07 06:35:21 --> Loader Class Initialized
INFO - 2024-02-07 06:35:21 --> Helper loaded: url_helper
INFO - 2024-02-07 06:35:21 --> Helper loaded: file_helper
INFO - 2024-02-07 06:35:21 --> Helper loaded: html_helper
INFO - 2024-02-07 06:35:21 --> Helper loaded: text_helper
INFO - 2024-02-07 06:35:21 --> Helper loaded: form_helper
INFO - 2024-02-07 06:35:21 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:35:21 --> Helper loaded: security_helper
INFO - 2024-02-07 06:35:21 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:35:21 --> Database Driver Class Initialized
INFO - 2024-02-07 06:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:35:21 --> Parser Class Initialized
INFO - 2024-02-07 06:35:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:35:21 --> Pagination Class Initialized
INFO - 2024-02-07 06:35:21 --> Form Validation Class Initialized
INFO - 2024-02-07 06:35:21 --> Controller Class Initialized
DEBUG - 2024-02-07 06:35:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:35:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:21 --> Model Class Initialized
DEBUG - 2024-02-07 06:35:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:21 --> Model Class Initialized
INFO - 2024-02-07 06:35:21 --> Final output sent to browser
DEBUG - 2024-02-07 06:35:21 --> Total execution time: 0.0301
ERROR - 2024-02-07 06:35:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:35:22 --> Config Class Initialized
INFO - 2024-02-07 06:35:22 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:35:22 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:35:22 --> Utf8 Class Initialized
INFO - 2024-02-07 06:35:22 --> URI Class Initialized
INFO - 2024-02-07 06:35:22 --> Router Class Initialized
INFO - 2024-02-07 06:35:22 --> Output Class Initialized
INFO - 2024-02-07 06:35:22 --> Security Class Initialized
DEBUG - 2024-02-07 06:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:35:22 --> Input Class Initialized
INFO - 2024-02-07 06:35:22 --> Language Class Initialized
INFO - 2024-02-07 06:35:22 --> Loader Class Initialized
INFO - 2024-02-07 06:35:22 --> Helper loaded: url_helper
INFO - 2024-02-07 06:35:22 --> Helper loaded: file_helper
INFO - 2024-02-07 06:35:22 --> Helper loaded: html_helper
INFO - 2024-02-07 06:35:22 --> Helper loaded: text_helper
INFO - 2024-02-07 06:35:22 --> Helper loaded: form_helper
INFO - 2024-02-07 06:35:22 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:35:22 --> Helper loaded: security_helper
INFO - 2024-02-07 06:35:22 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:35:22 --> Database Driver Class Initialized
INFO - 2024-02-07 06:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:35:22 --> Parser Class Initialized
INFO - 2024-02-07 06:35:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:35:22 --> Pagination Class Initialized
INFO - 2024-02-07 06:35:22 --> Form Validation Class Initialized
INFO - 2024-02-07 06:35:22 --> Controller Class Initialized
DEBUG - 2024-02-07 06:35:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:35:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:22 --> Model Class Initialized
DEBUG - 2024-02-07 06:35:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:22 --> Model Class Initialized
INFO - 2024-02-07 06:35:22 --> Final output sent to browser
DEBUG - 2024-02-07 06:35:22 --> Total execution time: 0.0309
ERROR - 2024-02-07 06:35:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:35:23 --> Config Class Initialized
INFO - 2024-02-07 06:35:23 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:35:23 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:35:23 --> Utf8 Class Initialized
INFO - 2024-02-07 06:35:23 --> URI Class Initialized
INFO - 2024-02-07 06:35:23 --> Router Class Initialized
INFO - 2024-02-07 06:35:23 --> Output Class Initialized
INFO - 2024-02-07 06:35:23 --> Security Class Initialized
DEBUG - 2024-02-07 06:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:35:23 --> Input Class Initialized
INFO - 2024-02-07 06:35:23 --> Language Class Initialized
INFO - 2024-02-07 06:35:23 --> Loader Class Initialized
INFO - 2024-02-07 06:35:23 --> Helper loaded: url_helper
INFO - 2024-02-07 06:35:23 --> Helper loaded: file_helper
INFO - 2024-02-07 06:35:23 --> Helper loaded: html_helper
INFO - 2024-02-07 06:35:23 --> Helper loaded: text_helper
INFO - 2024-02-07 06:35:23 --> Helper loaded: form_helper
INFO - 2024-02-07 06:35:23 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:35:23 --> Helper loaded: security_helper
INFO - 2024-02-07 06:35:23 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:35:23 --> Database Driver Class Initialized
INFO - 2024-02-07 06:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:35:23 --> Parser Class Initialized
INFO - 2024-02-07 06:35:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:35:23 --> Pagination Class Initialized
INFO - 2024-02-07 06:35:23 --> Form Validation Class Initialized
INFO - 2024-02-07 06:35:23 --> Controller Class Initialized
DEBUG - 2024-02-07 06:35:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:35:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:23 --> Model Class Initialized
DEBUG - 2024-02-07 06:35:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:23 --> Model Class Initialized
INFO - 2024-02-07 06:35:23 --> Final output sent to browser
DEBUG - 2024-02-07 06:35:23 --> Total execution time: 0.0304
ERROR - 2024-02-07 06:35:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:35:24 --> Config Class Initialized
INFO - 2024-02-07 06:35:24 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:35:24 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:35:24 --> Utf8 Class Initialized
INFO - 2024-02-07 06:35:24 --> URI Class Initialized
INFO - 2024-02-07 06:35:24 --> Router Class Initialized
INFO - 2024-02-07 06:35:24 --> Output Class Initialized
INFO - 2024-02-07 06:35:24 --> Security Class Initialized
DEBUG - 2024-02-07 06:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:35:24 --> Input Class Initialized
INFO - 2024-02-07 06:35:24 --> Language Class Initialized
INFO - 2024-02-07 06:35:24 --> Loader Class Initialized
INFO - 2024-02-07 06:35:24 --> Helper loaded: url_helper
INFO - 2024-02-07 06:35:24 --> Helper loaded: file_helper
INFO - 2024-02-07 06:35:24 --> Helper loaded: html_helper
INFO - 2024-02-07 06:35:24 --> Helper loaded: text_helper
INFO - 2024-02-07 06:35:24 --> Helper loaded: form_helper
INFO - 2024-02-07 06:35:24 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:35:24 --> Helper loaded: security_helper
INFO - 2024-02-07 06:35:24 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:35:24 --> Database Driver Class Initialized
INFO - 2024-02-07 06:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:35:24 --> Parser Class Initialized
INFO - 2024-02-07 06:35:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:35:24 --> Pagination Class Initialized
INFO - 2024-02-07 06:35:24 --> Form Validation Class Initialized
INFO - 2024-02-07 06:35:24 --> Controller Class Initialized
DEBUG - 2024-02-07 06:35:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:35:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:24 --> Model Class Initialized
DEBUG - 2024-02-07 06:35:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:24 --> Model Class Initialized
INFO - 2024-02-07 06:35:24 --> Final output sent to browser
DEBUG - 2024-02-07 06:35:24 --> Total execution time: 0.0336
ERROR - 2024-02-07 06:35:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:35:25 --> Config Class Initialized
INFO - 2024-02-07 06:35:25 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:35:25 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:35:25 --> Utf8 Class Initialized
INFO - 2024-02-07 06:35:25 --> URI Class Initialized
INFO - 2024-02-07 06:35:25 --> Router Class Initialized
INFO - 2024-02-07 06:35:25 --> Output Class Initialized
INFO - 2024-02-07 06:35:25 --> Security Class Initialized
DEBUG - 2024-02-07 06:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:35:25 --> Input Class Initialized
INFO - 2024-02-07 06:35:25 --> Language Class Initialized
INFO - 2024-02-07 06:35:25 --> Loader Class Initialized
INFO - 2024-02-07 06:35:25 --> Helper loaded: url_helper
INFO - 2024-02-07 06:35:25 --> Helper loaded: file_helper
INFO - 2024-02-07 06:35:25 --> Helper loaded: html_helper
INFO - 2024-02-07 06:35:25 --> Helper loaded: text_helper
INFO - 2024-02-07 06:35:25 --> Helper loaded: form_helper
INFO - 2024-02-07 06:35:25 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:35:25 --> Helper loaded: security_helper
INFO - 2024-02-07 06:35:25 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:35:25 --> Database Driver Class Initialized
INFO - 2024-02-07 06:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:35:25 --> Parser Class Initialized
INFO - 2024-02-07 06:35:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:35:25 --> Pagination Class Initialized
INFO - 2024-02-07 06:35:25 --> Form Validation Class Initialized
INFO - 2024-02-07 06:35:25 --> Controller Class Initialized
DEBUG - 2024-02-07 06:35:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:35:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:25 --> Model Class Initialized
DEBUG - 2024-02-07 06:35:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:25 --> Model Class Initialized
INFO - 2024-02-07 06:35:25 --> Final output sent to browser
DEBUG - 2024-02-07 06:35:25 --> Total execution time: 0.0346
ERROR - 2024-02-07 06:35:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:35:26 --> Config Class Initialized
INFO - 2024-02-07 06:35:26 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:35:26 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:35:26 --> Utf8 Class Initialized
INFO - 2024-02-07 06:35:26 --> URI Class Initialized
INFO - 2024-02-07 06:35:26 --> Router Class Initialized
INFO - 2024-02-07 06:35:26 --> Output Class Initialized
INFO - 2024-02-07 06:35:26 --> Security Class Initialized
DEBUG - 2024-02-07 06:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:35:26 --> Input Class Initialized
INFO - 2024-02-07 06:35:26 --> Language Class Initialized
INFO - 2024-02-07 06:35:26 --> Loader Class Initialized
INFO - 2024-02-07 06:35:26 --> Helper loaded: url_helper
INFO - 2024-02-07 06:35:26 --> Helper loaded: file_helper
INFO - 2024-02-07 06:35:26 --> Helper loaded: html_helper
INFO - 2024-02-07 06:35:26 --> Helper loaded: text_helper
INFO - 2024-02-07 06:35:26 --> Helper loaded: form_helper
INFO - 2024-02-07 06:35:26 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:35:26 --> Helper loaded: security_helper
INFO - 2024-02-07 06:35:26 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:35:26 --> Database Driver Class Initialized
INFO - 2024-02-07 06:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:35:26 --> Parser Class Initialized
INFO - 2024-02-07 06:35:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:35:26 --> Pagination Class Initialized
INFO - 2024-02-07 06:35:26 --> Form Validation Class Initialized
INFO - 2024-02-07 06:35:26 --> Controller Class Initialized
DEBUG - 2024-02-07 06:35:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:35:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:26 --> Model Class Initialized
DEBUG - 2024-02-07 06:35:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:26 --> Model Class Initialized
INFO - 2024-02-07 06:35:26 --> Final output sent to browser
DEBUG - 2024-02-07 06:35:26 --> Total execution time: 0.0221
ERROR - 2024-02-07 06:35:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:35:29 --> Config Class Initialized
INFO - 2024-02-07 06:35:29 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:35:29 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:35:29 --> Utf8 Class Initialized
INFO - 2024-02-07 06:35:29 --> URI Class Initialized
INFO - 2024-02-07 06:35:29 --> Router Class Initialized
INFO - 2024-02-07 06:35:29 --> Output Class Initialized
INFO - 2024-02-07 06:35:29 --> Security Class Initialized
DEBUG - 2024-02-07 06:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:35:29 --> Input Class Initialized
INFO - 2024-02-07 06:35:29 --> Language Class Initialized
INFO - 2024-02-07 06:35:29 --> Loader Class Initialized
INFO - 2024-02-07 06:35:29 --> Helper loaded: url_helper
INFO - 2024-02-07 06:35:29 --> Helper loaded: file_helper
INFO - 2024-02-07 06:35:29 --> Helper loaded: html_helper
INFO - 2024-02-07 06:35:29 --> Helper loaded: text_helper
INFO - 2024-02-07 06:35:29 --> Helper loaded: form_helper
INFO - 2024-02-07 06:35:29 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:35:29 --> Helper loaded: security_helper
INFO - 2024-02-07 06:35:29 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:35:29 --> Database Driver Class Initialized
INFO - 2024-02-07 06:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:35:29 --> Parser Class Initialized
INFO - 2024-02-07 06:35:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:35:29 --> Pagination Class Initialized
INFO - 2024-02-07 06:35:29 --> Form Validation Class Initialized
INFO - 2024-02-07 06:35:29 --> Controller Class Initialized
DEBUG - 2024-02-07 06:35:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:35:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:29 --> Model Class Initialized
DEBUG - 2024-02-07 06:35:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:29 --> Model Class Initialized
INFO - 2024-02-07 06:35:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/edit_customer_form.php
DEBUG - 2024-02-07 06:35:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:35:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:35:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:35:29 --> Model Class Initialized
INFO - 2024-02-07 06:35:29 --> Model Class Initialized
INFO - 2024-02-07 06:35:29 --> Model Class Initialized
INFO - 2024-02-07 06:35:29 --> Model Class Initialized
INFO - 2024-02-07 06:35:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 06:35:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 06:35:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:35:30 --> Final output sent to browser
DEBUG - 2024-02-07 06:35:30 --> Total execution time: 0.2516
ERROR - 2024-02-07 06:36:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:36:35 --> Config Class Initialized
INFO - 2024-02-07 06:36:35 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:36:35 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:36:35 --> Utf8 Class Initialized
INFO - 2024-02-07 06:36:35 --> URI Class Initialized
INFO - 2024-02-07 06:36:35 --> Router Class Initialized
INFO - 2024-02-07 06:36:35 --> Output Class Initialized
INFO - 2024-02-07 06:36:35 --> Security Class Initialized
DEBUG - 2024-02-07 06:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:36:35 --> Input Class Initialized
INFO - 2024-02-07 06:36:35 --> Language Class Initialized
INFO - 2024-02-07 06:36:35 --> Loader Class Initialized
INFO - 2024-02-07 06:36:35 --> Helper loaded: url_helper
INFO - 2024-02-07 06:36:35 --> Helper loaded: file_helper
INFO - 2024-02-07 06:36:35 --> Helper loaded: html_helper
INFO - 2024-02-07 06:36:35 --> Helper loaded: text_helper
INFO - 2024-02-07 06:36:35 --> Helper loaded: form_helper
INFO - 2024-02-07 06:36:35 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:36:35 --> Helper loaded: security_helper
INFO - 2024-02-07 06:36:35 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:36:35 --> Database Driver Class Initialized
INFO - 2024-02-07 06:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:36:35 --> Parser Class Initialized
INFO - 2024-02-07 06:36:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:36:35 --> Pagination Class Initialized
INFO - 2024-02-07 06:36:35 --> Form Validation Class Initialized
INFO - 2024-02-07 06:36:35 --> Controller Class Initialized
INFO - 2024-02-07 06:36:35 --> Model Class Initialized
DEBUG - 2024-02-07 06:36:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:36:35 --> Model Class Initialized
INFO - 2024-02-07 06:36:35 --> Final output sent to browser
DEBUG - 2024-02-07 06:36:35 --> Total execution time: 0.0191
ERROR - 2024-02-07 06:36:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:36:35 --> Config Class Initialized
INFO - 2024-02-07 06:36:35 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:36:35 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:36:35 --> Utf8 Class Initialized
INFO - 2024-02-07 06:36:35 --> URI Class Initialized
DEBUG - 2024-02-07 06:36:35 --> No URI present. Default controller set.
INFO - 2024-02-07 06:36:35 --> Router Class Initialized
INFO - 2024-02-07 06:36:35 --> Output Class Initialized
INFO - 2024-02-07 06:36:35 --> Security Class Initialized
DEBUG - 2024-02-07 06:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:36:35 --> Input Class Initialized
INFO - 2024-02-07 06:36:35 --> Language Class Initialized
INFO - 2024-02-07 06:36:35 --> Loader Class Initialized
INFO - 2024-02-07 06:36:35 --> Helper loaded: url_helper
INFO - 2024-02-07 06:36:35 --> Helper loaded: file_helper
INFO - 2024-02-07 06:36:35 --> Helper loaded: html_helper
INFO - 2024-02-07 06:36:35 --> Helper loaded: text_helper
INFO - 2024-02-07 06:36:35 --> Helper loaded: form_helper
INFO - 2024-02-07 06:36:35 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:36:35 --> Helper loaded: security_helper
INFO - 2024-02-07 06:36:35 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:36:35 --> Database Driver Class Initialized
INFO - 2024-02-07 06:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:36:35 --> Parser Class Initialized
INFO - 2024-02-07 06:36:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:36:35 --> Pagination Class Initialized
INFO - 2024-02-07 06:36:35 --> Form Validation Class Initialized
INFO - 2024-02-07 06:36:35 --> Controller Class Initialized
INFO - 2024-02-07 06:36:35 --> Model Class Initialized
DEBUG - 2024-02-07 06:36:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:36:35 --> Model Class Initialized
DEBUG - 2024-02-07 06:36:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:36:35 --> Model Class Initialized
INFO - 2024-02-07 06:36:35 --> Model Class Initialized
INFO - 2024-02-07 06:36:35 --> Model Class Initialized
INFO - 2024-02-07 06:36:35 --> Model Class Initialized
DEBUG - 2024-02-07 06:36:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:36:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:36:35 --> Model Class Initialized
INFO - 2024-02-07 06:36:35 --> Model Class Initialized
INFO - 2024-02-07 06:36:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-07 06:36:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:36:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:36:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:36:35 --> Model Class Initialized
INFO - 2024-02-07 06:36:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 06:36:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 06:36:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:36:35 --> Final output sent to browser
DEBUG - 2024-02-07 06:36:35 --> Total execution time: 0.2133
ERROR - 2024-02-07 06:36:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:36:53 --> Config Class Initialized
INFO - 2024-02-07 06:36:53 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:36:53 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:36:53 --> Utf8 Class Initialized
INFO - 2024-02-07 06:36:53 --> URI Class Initialized
INFO - 2024-02-07 06:36:53 --> Router Class Initialized
INFO - 2024-02-07 06:36:53 --> Output Class Initialized
INFO - 2024-02-07 06:36:53 --> Security Class Initialized
DEBUG - 2024-02-07 06:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:36:53 --> Input Class Initialized
INFO - 2024-02-07 06:36:53 --> Language Class Initialized
INFO - 2024-02-07 06:36:53 --> Loader Class Initialized
INFO - 2024-02-07 06:36:53 --> Helper loaded: url_helper
INFO - 2024-02-07 06:36:53 --> Helper loaded: file_helper
INFO - 2024-02-07 06:36:53 --> Helper loaded: html_helper
INFO - 2024-02-07 06:36:53 --> Helper loaded: text_helper
INFO - 2024-02-07 06:36:53 --> Helper loaded: form_helper
INFO - 2024-02-07 06:36:53 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:36:53 --> Helper loaded: security_helper
INFO - 2024-02-07 06:36:53 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:36:53 --> Database Driver Class Initialized
INFO - 2024-02-07 06:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:36:53 --> Parser Class Initialized
INFO - 2024-02-07 06:36:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:36:53 --> Pagination Class Initialized
INFO - 2024-02-07 06:36:53 --> Form Validation Class Initialized
INFO - 2024-02-07 06:36:53 --> Controller Class Initialized
DEBUG - 2024-02-07 06:36:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:36:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:36:53 --> Model Class Initialized
DEBUG - 2024-02-07 06:36:53 --> Lgift class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:36:53 --> Model Class Initialized
DEBUG - 2024-02-07 06:36:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:36:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:36:53 --> Model Class Initialized
DEBUG - 2024-02-07 06:36:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:36:53 --> Model Class Initialized
INFO - 2024-02-07 06:36:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/gift.php
DEBUG - 2024-02-07 06:36:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:36:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:36:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:36:53 --> Model Class Initialized
INFO - 2024-02-07 06:36:53 --> Model Class Initialized
INFO - 2024-02-07 06:36:53 --> Model Class Initialized
INFO - 2024-02-07 06:36:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 06:36:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 06:36:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:36:53 --> Final output sent to browser
DEBUG - 2024-02-07 06:36:53 --> Total execution time: 0.1342
ERROR - 2024-02-07 06:36:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:36:54 --> Config Class Initialized
INFO - 2024-02-07 06:36:54 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:36:54 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:36:54 --> Utf8 Class Initialized
INFO - 2024-02-07 06:36:54 --> URI Class Initialized
INFO - 2024-02-07 06:36:54 --> Router Class Initialized
INFO - 2024-02-07 06:36:54 --> Output Class Initialized
INFO - 2024-02-07 06:36:54 --> Security Class Initialized
DEBUG - 2024-02-07 06:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:36:54 --> Input Class Initialized
INFO - 2024-02-07 06:36:54 --> Language Class Initialized
INFO - 2024-02-07 06:36:54 --> Loader Class Initialized
INFO - 2024-02-07 06:36:54 --> Helper loaded: url_helper
INFO - 2024-02-07 06:36:54 --> Helper loaded: file_helper
INFO - 2024-02-07 06:36:54 --> Helper loaded: html_helper
INFO - 2024-02-07 06:36:54 --> Helper loaded: text_helper
INFO - 2024-02-07 06:36:54 --> Helper loaded: form_helper
INFO - 2024-02-07 06:36:54 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:36:54 --> Helper loaded: security_helper
INFO - 2024-02-07 06:36:54 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:36:54 --> Database Driver Class Initialized
INFO - 2024-02-07 06:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:36:54 --> Parser Class Initialized
INFO - 2024-02-07 06:36:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:36:54 --> Pagination Class Initialized
INFO - 2024-02-07 06:36:54 --> Form Validation Class Initialized
INFO - 2024-02-07 06:36:54 --> Controller Class Initialized
DEBUG - 2024-02-07 06:36:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:36:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:36:54 --> Model Class Initialized
INFO - 2024-02-07 06:36:54 --> Final output sent to browser
DEBUG - 2024-02-07 06:36:54 --> Total execution time: 0.0184
ERROR - 2024-02-07 06:38:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:38:35 --> Config Class Initialized
INFO - 2024-02-07 06:38:35 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:38:35 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:38:35 --> Utf8 Class Initialized
INFO - 2024-02-07 06:38:35 --> URI Class Initialized
DEBUG - 2024-02-07 06:38:35 --> No URI present. Default controller set.
INFO - 2024-02-07 06:38:35 --> Router Class Initialized
INFO - 2024-02-07 06:38:35 --> Output Class Initialized
INFO - 2024-02-07 06:38:35 --> Security Class Initialized
DEBUG - 2024-02-07 06:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:38:35 --> Input Class Initialized
INFO - 2024-02-07 06:38:35 --> Language Class Initialized
INFO - 2024-02-07 06:38:35 --> Loader Class Initialized
INFO - 2024-02-07 06:38:35 --> Helper loaded: url_helper
INFO - 2024-02-07 06:38:35 --> Helper loaded: file_helper
INFO - 2024-02-07 06:38:35 --> Helper loaded: html_helper
INFO - 2024-02-07 06:38:35 --> Helper loaded: text_helper
INFO - 2024-02-07 06:38:35 --> Helper loaded: form_helper
INFO - 2024-02-07 06:38:35 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:38:35 --> Helper loaded: security_helper
INFO - 2024-02-07 06:38:35 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:38:35 --> Database Driver Class Initialized
INFO - 2024-02-07 06:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:38:35 --> Parser Class Initialized
INFO - 2024-02-07 06:38:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:38:35 --> Pagination Class Initialized
INFO - 2024-02-07 06:38:35 --> Form Validation Class Initialized
INFO - 2024-02-07 06:38:35 --> Controller Class Initialized
INFO - 2024-02-07 06:38:35 --> Model Class Initialized
DEBUG - 2024-02-07 06:38:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:38:35 --> Model Class Initialized
DEBUG - 2024-02-07 06:38:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:38:35 --> Model Class Initialized
INFO - 2024-02-07 06:38:35 --> Model Class Initialized
INFO - 2024-02-07 06:38:35 --> Model Class Initialized
INFO - 2024-02-07 06:38:35 --> Model Class Initialized
DEBUG - 2024-02-07 06:38:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:38:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:38:35 --> Model Class Initialized
INFO - 2024-02-07 06:38:35 --> Model Class Initialized
INFO - 2024-02-07 06:38:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-07 06:38:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:38:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:38:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:38:35 --> Model Class Initialized
INFO - 2024-02-07 06:38:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 06:38:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 06:38:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:38:35 --> Final output sent to browser
DEBUG - 2024-02-07 06:38:35 --> Total execution time: 0.2228
ERROR - 2024-02-07 06:38:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:38:38 --> Config Class Initialized
INFO - 2024-02-07 06:38:38 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:38:38 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:38:38 --> Utf8 Class Initialized
INFO - 2024-02-07 06:38:38 --> URI Class Initialized
INFO - 2024-02-07 06:38:38 --> Router Class Initialized
INFO - 2024-02-07 06:38:38 --> Output Class Initialized
INFO - 2024-02-07 06:38:38 --> Security Class Initialized
DEBUG - 2024-02-07 06:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:38:38 --> Input Class Initialized
INFO - 2024-02-07 06:38:38 --> Language Class Initialized
INFO - 2024-02-07 06:38:38 --> Loader Class Initialized
INFO - 2024-02-07 06:38:38 --> Helper loaded: url_helper
INFO - 2024-02-07 06:38:38 --> Helper loaded: file_helper
INFO - 2024-02-07 06:38:38 --> Helper loaded: html_helper
INFO - 2024-02-07 06:38:38 --> Helper loaded: text_helper
INFO - 2024-02-07 06:38:38 --> Helper loaded: form_helper
INFO - 2024-02-07 06:38:38 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:38:38 --> Helper loaded: security_helper
INFO - 2024-02-07 06:38:38 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:38:38 --> Database Driver Class Initialized
INFO - 2024-02-07 06:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:38:38 --> Parser Class Initialized
INFO - 2024-02-07 06:38:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:38:38 --> Pagination Class Initialized
INFO - 2024-02-07 06:38:38 --> Form Validation Class Initialized
INFO - 2024-02-07 06:38:38 --> Controller Class Initialized
INFO - 2024-02-07 06:38:38 --> Model Class Initialized
DEBUG - 2024-02-07 06:38:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:38:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-07 06:38:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:38:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:38:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:38:38 --> Model Class Initialized
INFO - 2024-02-07 06:38:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:38:38 --> Final output sent to browser
DEBUG - 2024-02-07 06:38:38 --> Total execution time: 0.0266
ERROR - 2024-02-07 06:38:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:38:38 --> Config Class Initialized
INFO - 2024-02-07 06:38:38 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:38:38 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:38:38 --> Utf8 Class Initialized
INFO - 2024-02-07 06:38:38 --> URI Class Initialized
INFO - 2024-02-07 06:38:38 --> Router Class Initialized
INFO - 2024-02-07 06:38:38 --> Output Class Initialized
INFO - 2024-02-07 06:38:38 --> Security Class Initialized
DEBUG - 2024-02-07 06:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:38:38 --> Input Class Initialized
INFO - 2024-02-07 06:38:38 --> Language Class Initialized
INFO - 2024-02-07 06:38:38 --> Loader Class Initialized
INFO - 2024-02-07 06:38:38 --> Helper loaded: url_helper
INFO - 2024-02-07 06:38:38 --> Helper loaded: file_helper
INFO - 2024-02-07 06:38:38 --> Helper loaded: html_helper
INFO - 2024-02-07 06:38:38 --> Helper loaded: text_helper
INFO - 2024-02-07 06:38:38 --> Helper loaded: form_helper
INFO - 2024-02-07 06:38:38 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:38:38 --> Helper loaded: security_helper
INFO - 2024-02-07 06:38:38 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:38:38 --> Database Driver Class Initialized
INFO - 2024-02-07 06:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:38:38 --> Parser Class Initialized
INFO - 2024-02-07 06:38:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:38:38 --> Pagination Class Initialized
INFO - 2024-02-07 06:38:38 --> Form Validation Class Initialized
INFO - 2024-02-07 06:38:38 --> Controller Class Initialized
INFO - 2024-02-07 06:38:38 --> Model Class Initialized
DEBUG - 2024-02-07 06:38:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:38:38 --> Model Class Initialized
DEBUG - 2024-02-07 06:38:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:38:38 --> Model Class Initialized
INFO - 2024-02-07 06:38:38 --> Model Class Initialized
INFO - 2024-02-07 06:38:38 --> Model Class Initialized
INFO - 2024-02-07 06:38:38 --> Model Class Initialized
DEBUG - 2024-02-07 06:38:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:38:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:38:38 --> Model Class Initialized
INFO - 2024-02-07 06:38:38 --> Model Class Initialized
INFO - 2024-02-07 06:38:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-07 06:38:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:38:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:38:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:38:38 --> Model Class Initialized
INFO - 2024-02-07 06:38:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 06:38:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 06:38:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:38:38 --> Final output sent to browser
DEBUG - 2024-02-07 06:38:38 --> Total execution time: 0.2289
ERROR - 2024-02-07 06:38:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:38:40 --> Config Class Initialized
INFO - 2024-02-07 06:38:40 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:38:40 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:38:40 --> Utf8 Class Initialized
INFO - 2024-02-07 06:38:40 --> URI Class Initialized
INFO - 2024-02-07 06:38:40 --> Router Class Initialized
INFO - 2024-02-07 06:38:40 --> Output Class Initialized
INFO - 2024-02-07 06:38:40 --> Security Class Initialized
DEBUG - 2024-02-07 06:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:38:40 --> Input Class Initialized
INFO - 2024-02-07 06:38:40 --> Language Class Initialized
INFO - 2024-02-07 06:38:40 --> Loader Class Initialized
INFO - 2024-02-07 06:38:40 --> Helper loaded: url_helper
INFO - 2024-02-07 06:38:40 --> Helper loaded: file_helper
INFO - 2024-02-07 06:38:40 --> Helper loaded: html_helper
INFO - 2024-02-07 06:38:40 --> Helper loaded: text_helper
INFO - 2024-02-07 06:38:40 --> Helper loaded: form_helper
INFO - 2024-02-07 06:38:40 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:38:40 --> Helper loaded: security_helper
INFO - 2024-02-07 06:38:40 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:38:40 --> Database Driver Class Initialized
INFO - 2024-02-07 06:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:38:40 --> Parser Class Initialized
INFO - 2024-02-07 06:38:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:38:40 --> Pagination Class Initialized
INFO - 2024-02-07 06:38:40 --> Form Validation Class Initialized
INFO - 2024-02-07 06:38:40 --> Controller Class Initialized
INFO - 2024-02-07 06:38:40 --> Model Class Initialized
DEBUG - 2024-02-07 06:38:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:38:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-07 06:38:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:38:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:38:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:38:40 --> Model Class Initialized
INFO - 2024-02-07 06:38:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:38:40 --> Final output sent to browser
DEBUG - 2024-02-07 06:38:40 --> Total execution time: 0.0299
ERROR - 2024-02-07 06:38:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:38:40 --> Config Class Initialized
INFO - 2024-02-07 06:38:40 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:38:40 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:38:40 --> Utf8 Class Initialized
INFO - 2024-02-07 06:38:40 --> URI Class Initialized
INFO - 2024-02-07 06:38:40 --> Router Class Initialized
INFO - 2024-02-07 06:38:40 --> Output Class Initialized
INFO - 2024-02-07 06:38:40 --> Security Class Initialized
DEBUG - 2024-02-07 06:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:38:40 --> Input Class Initialized
INFO - 2024-02-07 06:38:40 --> Language Class Initialized
INFO - 2024-02-07 06:38:40 --> Loader Class Initialized
INFO - 2024-02-07 06:38:40 --> Helper loaded: url_helper
INFO - 2024-02-07 06:38:40 --> Helper loaded: file_helper
INFO - 2024-02-07 06:38:40 --> Helper loaded: html_helper
INFO - 2024-02-07 06:38:40 --> Helper loaded: text_helper
INFO - 2024-02-07 06:38:40 --> Helper loaded: form_helper
INFO - 2024-02-07 06:38:40 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:38:40 --> Helper loaded: security_helper
INFO - 2024-02-07 06:38:40 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:38:40 --> Database Driver Class Initialized
INFO - 2024-02-07 06:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:38:40 --> Parser Class Initialized
INFO - 2024-02-07 06:38:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:38:40 --> Pagination Class Initialized
INFO - 2024-02-07 06:38:40 --> Form Validation Class Initialized
INFO - 2024-02-07 06:38:40 --> Controller Class Initialized
INFO - 2024-02-07 06:38:40 --> Model Class Initialized
DEBUG - 2024-02-07 06:38:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:38:40 --> Model Class Initialized
DEBUG - 2024-02-07 06:38:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:38:40 --> Model Class Initialized
INFO - 2024-02-07 06:38:40 --> Model Class Initialized
INFO - 2024-02-07 06:38:40 --> Model Class Initialized
INFO - 2024-02-07 06:38:40 --> Model Class Initialized
DEBUG - 2024-02-07 06:38:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:38:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:38:40 --> Model Class Initialized
INFO - 2024-02-07 06:38:40 --> Model Class Initialized
INFO - 2024-02-07 06:38:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-07 06:38:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:38:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:38:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:38:40 --> Model Class Initialized
INFO - 2024-02-07 06:38:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 06:38:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 06:38:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:38:40 --> Final output sent to browser
DEBUG - 2024-02-07 06:38:40 --> Total execution time: 0.2129
ERROR - 2024-02-07 06:38:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:38:42 --> Config Class Initialized
INFO - 2024-02-07 06:38:42 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:38:42 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:38:42 --> Utf8 Class Initialized
INFO - 2024-02-07 06:38:42 --> URI Class Initialized
INFO - 2024-02-07 06:38:42 --> Router Class Initialized
INFO - 2024-02-07 06:38:42 --> Output Class Initialized
INFO - 2024-02-07 06:38:42 --> Security Class Initialized
DEBUG - 2024-02-07 06:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:38:42 --> Input Class Initialized
INFO - 2024-02-07 06:38:42 --> Language Class Initialized
INFO - 2024-02-07 06:38:42 --> Loader Class Initialized
INFO - 2024-02-07 06:38:42 --> Helper loaded: url_helper
INFO - 2024-02-07 06:38:42 --> Helper loaded: file_helper
INFO - 2024-02-07 06:38:42 --> Helper loaded: html_helper
INFO - 2024-02-07 06:38:42 --> Helper loaded: text_helper
INFO - 2024-02-07 06:38:42 --> Helper loaded: form_helper
INFO - 2024-02-07 06:38:42 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:38:42 --> Helper loaded: security_helper
INFO - 2024-02-07 06:38:42 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:38:42 --> Database Driver Class Initialized
INFO - 2024-02-07 06:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:38:42 --> Parser Class Initialized
INFO - 2024-02-07 06:38:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:38:42 --> Pagination Class Initialized
INFO - 2024-02-07 06:38:42 --> Form Validation Class Initialized
INFO - 2024-02-07 06:38:42 --> Controller Class Initialized
INFO - 2024-02-07 06:38:42 --> Model Class Initialized
DEBUG - 2024-02-07 06:38:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:38:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-07 06:38:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:38:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:38:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:38:42 --> Model Class Initialized
INFO - 2024-02-07 06:38:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:38:42 --> Final output sent to browser
DEBUG - 2024-02-07 06:38:42 --> Total execution time: 0.0287
ERROR - 2024-02-07 06:38:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:38:42 --> Config Class Initialized
INFO - 2024-02-07 06:38:42 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:38:42 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:38:42 --> Utf8 Class Initialized
INFO - 2024-02-07 06:38:42 --> URI Class Initialized
INFO - 2024-02-07 06:38:42 --> Router Class Initialized
INFO - 2024-02-07 06:38:42 --> Output Class Initialized
INFO - 2024-02-07 06:38:42 --> Security Class Initialized
DEBUG - 2024-02-07 06:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:38:42 --> Input Class Initialized
INFO - 2024-02-07 06:38:42 --> Language Class Initialized
INFO - 2024-02-07 06:38:42 --> Loader Class Initialized
INFO - 2024-02-07 06:38:42 --> Helper loaded: url_helper
INFO - 2024-02-07 06:38:42 --> Helper loaded: file_helper
INFO - 2024-02-07 06:38:42 --> Helper loaded: html_helper
INFO - 2024-02-07 06:38:42 --> Helper loaded: text_helper
INFO - 2024-02-07 06:38:42 --> Helper loaded: form_helper
INFO - 2024-02-07 06:38:42 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:38:42 --> Helper loaded: security_helper
INFO - 2024-02-07 06:38:42 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:38:42 --> Database Driver Class Initialized
INFO - 2024-02-07 06:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:38:42 --> Parser Class Initialized
INFO - 2024-02-07 06:38:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:38:42 --> Pagination Class Initialized
INFO - 2024-02-07 06:38:42 --> Form Validation Class Initialized
INFO - 2024-02-07 06:38:42 --> Controller Class Initialized
INFO - 2024-02-07 06:38:42 --> Model Class Initialized
DEBUG - 2024-02-07 06:38:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:38:42 --> Model Class Initialized
DEBUG - 2024-02-07 06:38:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:38:42 --> Model Class Initialized
INFO - 2024-02-07 06:38:42 --> Model Class Initialized
INFO - 2024-02-07 06:38:42 --> Model Class Initialized
INFO - 2024-02-07 06:38:42 --> Model Class Initialized
DEBUG - 2024-02-07 06:38:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:38:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:38:42 --> Model Class Initialized
INFO - 2024-02-07 06:38:42 --> Model Class Initialized
INFO - 2024-02-07 06:38:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-07 06:38:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:38:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:38:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:38:42 --> Model Class Initialized
INFO - 2024-02-07 06:38:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 06:38:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 06:38:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:38:42 --> Final output sent to browser
DEBUG - 2024-02-07 06:38:42 --> Total execution time: 0.2039
ERROR - 2024-02-07 06:38:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:38:44 --> Config Class Initialized
INFO - 2024-02-07 06:38:44 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:38:44 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:38:44 --> Utf8 Class Initialized
INFO - 2024-02-07 06:38:44 --> URI Class Initialized
INFO - 2024-02-07 06:38:44 --> Router Class Initialized
INFO - 2024-02-07 06:38:44 --> Output Class Initialized
INFO - 2024-02-07 06:38:44 --> Security Class Initialized
DEBUG - 2024-02-07 06:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:38:44 --> Input Class Initialized
INFO - 2024-02-07 06:38:44 --> Language Class Initialized
INFO - 2024-02-07 06:38:44 --> Loader Class Initialized
INFO - 2024-02-07 06:38:44 --> Helper loaded: url_helper
INFO - 2024-02-07 06:38:44 --> Helper loaded: file_helper
INFO - 2024-02-07 06:38:44 --> Helper loaded: html_helper
INFO - 2024-02-07 06:38:44 --> Helper loaded: text_helper
INFO - 2024-02-07 06:38:44 --> Helper loaded: form_helper
INFO - 2024-02-07 06:38:44 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:38:44 --> Helper loaded: security_helper
INFO - 2024-02-07 06:38:44 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:38:44 --> Database Driver Class Initialized
INFO - 2024-02-07 06:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:38:44 --> Parser Class Initialized
INFO - 2024-02-07 06:38:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:38:44 --> Pagination Class Initialized
INFO - 2024-02-07 06:38:44 --> Form Validation Class Initialized
INFO - 2024-02-07 06:38:44 --> Controller Class Initialized
INFO - 2024-02-07 06:38:44 --> Model Class Initialized
DEBUG - 2024-02-07 06:38:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:38:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-07 06:38:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:38:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:38:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:38:44 --> Model Class Initialized
INFO - 2024-02-07 06:38:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:38:44 --> Final output sent to browser
DEBUG - 2024-02-07 06:38:44 --> Total execution time: 0.0275
ERROR - 2024-02-07 06:38:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:38:44 --> Config Class Initialized
INFO - 2024-02-07 06:38:44 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:38:44 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:38:44 --> Utf8 Class Initialized
INFO - 2024-02-07 06:38:44 --> URI Class Initialized
INFO - 2024-02-07 06:38:44 --> Router Class Initialized
INFO - 2024-02-07 06:38:44 --> Output Class Initialized
INFO - 2024-02-07 06:38:44 --> Security Class Initialized
DEBUG - 2024-02-07 06:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:38:44 --> Input Class Initialized
INFO - 2024-02-07 06:38:44 --> Language Class Initialized
INFO - 2024-02-07 06:38:44 --> Loader Class Initialized
INFO - 2024-02-07 06:38:44 --> Helper loaded: url_helper
INFO - 2024-02-07 06:38:44 --> Helper loaded: file_helper
INFO - 2024-02-07 06:38:44 --> Helper loaded: html_helper
INFO - 2024-02-07 06:38:44 --> Helper loaded: text_helper
INFO - 2024-02-07 06:38:44 --> Helper loaded: form_helper
INFO - 2024-02-07 06:38:44 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:38:44 --> Helper loaded: security_helper
INFO - 2024-02-07 06:38:44 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:38:44 --> Database Driver Class Initialized
INFO - 2024-02-07 06:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:38:44 --> Parser Class Initialized
INFO - 2024-02-07 06:38:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:38:44 --> Pagination Class Initialized
INFO - 2024-02-07 06:38:44 --> Form Validation Class Initialized
INFO - 2024-02-07 06:38:44 --> Controller Class Initialized
INFO - 2024-02-07 06:38:44 --> Model Class Initialized
DEBUG - 2024-02-07 06:38:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:38:44 --> Model Class Initialized
DEBUG - 2024-02-07 06:38:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:38:44 --> Model Class Initialized
INFO - 2024-02-07 06:38:44 --> Model Class Initialized
INFO - 2024-02-07 06:38:44 --> Model Class Initialized
INFO - 2024-02-07 06:38:44 --> Model Class Initialized
DEBUG - 2024-02-07 06:38:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:38:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:38:44 --> Model Class Initialized
INFO - 2024-02-07 06:38:44 --> Model Class Initialized
INFO - 2024-02-07 06:38:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-07 06:38:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:38:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:38:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:38:44 --> Model Class Initialized
INFO - 2024-02-07 06:38:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 06:38:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 06:38:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:38:44 --> Final output sent to browser
DEBUG - 2024-02-07 06:38:44 --> Total execution time: 0.2183
ERROR - 2024-02-07 06:38:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:38:55 --> Config Class Initialized
INFO - 2024-02-07 06:38:55 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:38:55 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:38:55 --> Utf8 Class Initialized
INFO - 2024-02-07 06:38:55 --> URI Class Initialized
INFO - 2024-02-07 06:38:55 --> Router Class Initialized
INFO - 2024-02-07 06:38:55 --> Output Class Initialized
INFO - 2024-02-07 06:38:55 --> Security Class Initialized
DEBUG - 2024-02-07 06:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:38:55 --> Input Class Initialized
INFO - 2024-02-07 06:38:55 --> Language Class Initialized
INFO - 2024-02-07 06:38:55 --> Loader Class Initialized
INFO - 2024-02-07 06:38:55 --> Helper loaded: url_helper
INFO - 2024-02-07 06:38:55 --> Helper loaded: file_helper
INFO - 2024-02-07 06:38:55 --> Helper loaded: html_helper
INFO - 2024-02-07 06:38:55 --> Helper loaded: text_helper
INFO - 2024-02-07 06:38:55 --> Helper loaded: form_helper
INFO - 2024-02-07 06:38:55 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:38:55 --> Helper loaded: security_helper
INFO - 2024-02-07 06:38:55 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:38:55 --> Database Driver Class Initialized
INFO - 2024-02-07 06:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:38:55 --> Parser Class Initialized
INFO - 2024-02-07 06:38:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:38:55 --> Pagination Class Initialized
INFO - 2024-02-07 06:38:55 --> Form Validation Class Initialized
INFO - 2024-02-07 06:38:55 --> Controller Class Initialized
DEBUG - 2024-02-07 06:38:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:38:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:38:55 --> Model Class Initialized
DEBUG - 2024-02-07 06:38:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:38:55 --> Model Class Initialized
INFO - 2024-02-07 06:38:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/edit_customer_form.php
DEBUG - 2024-02-07 06:38:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:38:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:38:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:38:55 --> Model Class Initialized
INFO - 2024-02-07 06:38:55 --> Model Class Initialized
INFO - 2024-02-07 06:38:55 --> Model Class Initialized
INFO - 2024-02-07 06:38:55 --> Model Class Initialized
INFO - 2024-02-07 06:38:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 06:38:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 06:38:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:38:55 --> Final output sent to browser
DEBUG - 2024-02-07 06:38:55 --> Total execution time: 0.2530
ERROR - 2024-02-07 06:38:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:38:56 --> Config Class Initialized
INFO - 2024-02-07 06:38:56 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:38:56 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:38:56 --> Utf8 Class Initialized
INFO - 2024-02-07 06:38:56 --> URI Class Initialized
INFO - 2024-02-07 06:38:56 --> Router Class Initialized
INFO - 2024-02-07 06:38:56 --> Output Class Initialized
INFO - 2024-02-07 06:38:56 --> Security Class Initialized
DEBUG - 2024-02-07 06:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:38:56 --> Input Class Initialized
INFO - 2024-02-07 06:38:56 --> Language Class Initialized
INFO - 2024-02-07 06:38:56 --> Loader Class Initialized
INFO - 2024-02-07 06:38:56 --> Helper loaded: url_helper
INFO - 2024-02-07 06:38:56 --> Helper loaded: file_helper
INFO - 2024-02-07 06:38:56 --> Helper loaded: html_helper
INFO - 2024-02-07 06:38:56 --> Helper loaded: text_helper
INFO - 2024-02-07 06:38:56 --> Helper loaded: form_helper
INFO - 2024-02-07 06:38:56 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:38:56 --> Helper loaded: security_helper
INFO - 2024-02-07 06:38:56 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:38:56 --> Database Driver Class Initialized
INFO - 2024-02-07 06:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:38:56 --> Parser Class Initialized
INFO - 2024-02-07 06:38:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:38:56 --> Pagination Class Initialized
INFO - 2024-02-07 06:38:56 --> Form Validation Class Initialized
INFO - 2024-02-07 06:38:56 --> Controller Class Initialized
INFO - 2024-02-07 06:38:56 --> Model Class Initialized
DEBUG - 2024-02-07 06:38:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:38:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-07 06:38:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:38:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:38:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:38:56 --> Model Class Initialized
INFO - 2024-02-07 06:38:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:38:56 --> Final output sent to browser
DEBUG - 2024-02-07 06:38:56 --> Total execution time: 0.0285
ERROR - 2024-02-07 06:38:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:38:56 --> Config Class Initialized
INFO - 2024-02-07 06:38:56 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:38:56 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:38:56 --> Utf8 Class Initialized
INFO - 2024-02-07 06:38:56 --> URI Class Initialized
INFO - 2024-02-07 06:38:56 --> Router Class Initialized
INFO - 2024-02-07 06:38:56 --> Output Class Initialized
INFO - 2024-02-07 06:38:56 --> Security Class Initialized
DEBUG - 2024-02-07 06:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:38:56 --> Input Class Initialized
INFO - 2024-02-07 06:38:56 --> Language Class Initialized
INFO - 2024-02-07 06:38:56 --> Loader Class Initialized
INFO - 2024-02-07 06:38:56 --> Helper loaded: url_helper
INFO - 2024-02-07 06:38:56 --> Helper loaded: file_helper
INFO - 2024-02-07 06:38:56 --> Helper loaded: html_helper
INFO - 2024-02-07 06:38:56 --> Helper loaded: text_helper
INFO - 2024-02-07 06:38:56 --> Helper loaded: form_helper
INFO - 2024-02-07 06:38:56 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:38:56 --> Helper loaded: security_helper
INFO - 2024-02-07 06:38:56 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:38:56 --> Database Driver Class Initialized
INFO - 2024-02-07 06:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:38:56 --> Parser Class Initialized
INFO - 2024-02-07 06:38:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:38:56 --> Pagination Class Initialized
INFO - 2024-02-07 06:38:56 --> Form Validation Class Initialized
INFO - 2024-02-07 06:38:56 --> Controller Class Initialized
INFO - 2024-02-07 06:38:56 --> Model Class Initialized
DEBUG - 2024-02-07 06:38:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:38:56 --> Model Class Initialized
DEBUG - 2024-02-07 06:38:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:38:56 --> Model Class Initialized
INFO - 2024-02-07 06:38:56 --> Model Class Initialized
INFO - 2024-02-07 06:38:56 --> Model Class Initialized
INFO - 2024-02-07 06:38:56 --> Model Class Initialized
DEBUG - 2024-02-07 06:38:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:38:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:38:56 --> Model Class Initialized
INFO - 2024-02-07 06:38:56 --> Model Class Initialized
INFO - 2024-02-07 06:38:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-07 06:38:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:38:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:38:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:38:56 --> Model Class Initialized
INFO - 2024-02-07 06:38:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 06:38:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 06:38:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:38:56 --> Final output sent to browser
DEBUG - 2024-02-07 06:38:56 --> Total execution time: 0.2290
ERROR - 2024-02-07 06:38:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:38:59 --> Config Class Initialized
INFO - 2024-02-07 06:38:59 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:38:59 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:38:59 --> Utf8 Class Initialized
INFO - 2024-02-07 06:38:59 --> URI Class Initialized
DEBUG - 2024-02-07 06:38:59 --> No URI present. Default controller set.
INFO - 2024-02-07 06:38:59 --> Router Class Initialized
INFO - 2024-02-07 06:38:59 --> Output Class Initialized
INFO - 2024-02-07 06:38:59 --> Security Class Initialized
DEBUG - 2024-02-07 06:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:38:59 --> Input Class Initialized
INFO - 2024-02-07 06:38:59 --> Language Class Initialized
INFO - 2024-02-07 06:38:59 --> Loader Class Initialized
INFO - 2024-02-07 06:38:59 --> Helper loaded: url_helper
INFO - 2024-02-07 06:38:59 --> Helper loaded: file_helper
INFO - 2024-02-07 06:38:59 --> Helper loaded: html_helper
INFO - 2024-02-07 06:38:59 --> Helper loaded: text_helper
INFO - 2024-02-07 06:38:59 --> Helper loaded: form_helper
INFO - 2024-02-07 06:38:59 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:38:59 --> Helper loaded: security_helper
INFO - 2024-02-07 06:38:59 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:38:59 --> Database Driver Class Initialized
INFO - 2024-02-07 06:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:38:59 --> Parser Class Initialized
INFO - 2024-02-07 06:38:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:38:59 --> Pagination Class Initialized
INFO - 2024-02-07 06:38:59 --> Form Validation Class Initialized
INFO - 2024-02-07 06:38:59 --> Controller Class Initialized
INFO - 2024-02-07 06:38:59 --> Model Class Initialized
DEBUG - 2024-02-07 06:38:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:38:59 --> Model Class Initialized
DEBUG - 2024-02-07 06:38:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:38:59 --> Model Class Initialized
INFO - 2024-02-07 06:38:59 --> Model Class Initialized
INFO - 2024-02-07 06:38:59 --> Model Class Initialized
INFO - 2024-02-07 06:38:59 --> Model Class Initialized
DEBUG - 2024-02-07 06:38:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:38:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:38:59 --> Model Class Initialized
INFO - 2024-02-07 06:38:59 --> Model Class Initialized
INFO - 2024-02-07 06:38:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-07 06:38:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:38:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:38:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:38:59 --> Model Class Initialized
INFO - 2024-02-07 06:38:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 06:38:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 06:38:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:38:59 --> Final output sent to browser
DEBUG - 2024-02-07 06:38:59 --> Total execution time: 0.2222
ERROR - 2024-02-07 06:39:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:39:02 --> Config Class Initialized
INFO - 2024-02-07 06:39:02 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:39:02 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:39:02 --> Utf8 Class Initialized
INFO - 2024-02-07 06:39:02 --> URI Class Initialized
INFO - 2024-02-07 06:39:02 --> Router Class Initialized
INFO - 2024-02-07 06:39:02 --> Output Class Initialized
INFO - 2024-02-07 06:39:02 --> Security Class Initialized
DEBUG - 2024-02-07 06:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:39:02 --> Input Class Initialized
INFO - 2024-02-07 06:39:02 --> Language Class Initialized
INFO - 2024-02-07 06:39:02 --> Loader Class Initialized
INFO - 2024-02-07 06:39:02 --> Helper loaded: url_helper
INFO - 2024-02-07 06:39:02 --> Helper loaded: file_helper
INFO - 2024-02-07 06:39:02 --> Helper loaded: html_helper
INFO - 2024-02-07 06:39:02 --> Helper loaded: text_helper
INFO - 2024-02-07 06:39:02 --> Helper loaded: form_helper
INFO - 2024-02-07 06:39:02 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:39:02 --> Helper loaded: security_helper
INFO - 2024-02-07 06:39:02 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:39:02 --> Database Driver Class Initialized
INFO - 2024-02-07 06:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:39:02 --> Parser Class Initialized
INFO - 2024-02-07 06:39:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:39:02 --> Pagination Class Initialized
INFO - 2024-02-07 06:39:02 --> Form Validation Class Initialized
INFO - 2024-02-07 06:39:02 --> Controller Class Initialized
DEBUG - 2024-02-07 06:39:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:39:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:39:02 --> Model Class Initialized
DEBUG - 2024-02-07 06:39:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:39:02 --> Model Class Initialized
ERROR - 2024-02-07 06:39:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:39:02 --> Config Class Initialized
INFO - 2024-02-07 06:39:02 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:39:02 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:39:02 --> Utf8 Class Initialized
INFO - 2024-02-07 06:39:02 --> URI Class Initialized
INFO - 2024-02-07 06:39:02 --> Router Class Initialized
INFO - 2024-02-07 06:39:02 --> Output Class Initialized
INFO - 2024-02-07 06:39:02 --> Security Class Initialized
DEBUG - 2024-02-07 06:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:39:02 --> Input Class Initialized
INFO - 2024-02-07 06:39:02 --> Language Class Initialized
INFO - 2024-02-07 06:39:02 --> Loader Class Initialized
INFO - 2024-02-07 06:39:02 --> Helper loaded: url_helper
INFO - 2024-02-07 06:39:02 --> Helper loaded: file_helper
INFO - 2024-02-07 06:39:02 --> Helper loaded: html_helper
INFO - 2024-02-07 06:39:02 --> Helper loaded: text_helper
INFO - 2024-02-07 06:39:02 --> Helper loaded: form_helper
INFO - 2024-02-07 06:39:02 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:39:02 --> Helper loaded: security_helper
INFO - 2024-02-07 06:39:02 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:39:02 --> Database Driver Class Initialized
INFO - 2024-02-07 06:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:39:02 --> Parser Class Initialized
INFO - 2024-02-07 06:39:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:39:02 --> Pagination Class Initialized
INFO - 2024-02-07 06:39:02 --> Form Validation Class Initialized
INFO - 2024-02-07 06:39:02 --> Controller Class Initialized
DEBUG - 2024-02-07 06:39:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:39:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:39:02 --> Model Class Initialized
DEBUG - 2024-02-07 06:39:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:39:02 --> Model Class Initialized
DEBUG - 2024-02-07 06:39:02 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:39:02 --> Model Class Initialized
INFO - 2024-02-07 06:39:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-07 06:39:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:39:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:39:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:39:02 --> Model Class Initialized
INFO - 2024-02-07 06:39:02 --> Model Class Initialized
INFO - 2024-02-07 06:39:02 --> Model Class Initialized
INFO - 2024-02-07 06:39:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 06:39:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 06:39:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:39:02 --> Final output sent to browser
DEBUG - 2024-02-07 06:39:02 --> Total execution time: 0.2275
ERROR - 2024-02-07 06:39:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:39:02 --> Config Class Initialized
INFO - 2024-02-07 06:39:02 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:39:02 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:39:02 --> Utf8 Class Initialized
INFO - 2024-02-07 06:39:02 --> URI Class Initialized
INFO - 2024-02-07 06:39:02 --> Router Class Initialized
INFO - 2024-02-07 06:39:02 --> Output Class Initialized
INFO - 2024-02-07 06:39:02 --> Security Class Initialized
DEBUG - 2024-02-07 06:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:39:02 --> Input Class Initialized
INFO - 2024-02-07 06:39:02 --> Language Class Initialized
INFO - 2024-02-07 06:39:02 --> Loader Class Initialized
INFO - 2024-02-07 06:39:02 --> Helper loaded: url_helper
INFO - 2024-02-07 06:39:02 --> Helper loaded: file_helper
INFO - 2024-02-07 06:39:02 --> Helper loaded: html_helper
INFO - 2024-02-07 06:39:02 --> Helper loaded: text_helper
INFO - 2024-02-07 06:39:02 --> Helper loaded: form_helper
INFO - 2024-02-07 06:39:02 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:39:02 --> Helper loaded: security_helper
INFO - 2024-02-07 06:39:02 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:39:02 --> Database Driver Class Initialized
INFO - 2024-02-07 06:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:39:02 --> Parser Class Initialized
INFO - 2024-02-07 06:39:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:39:02 --> Pagination Class Initialized
INFO - 2024-02-07 06:39:02 --> Form Validation Class Initialized
INFO - 2024-02-07 06:39:02 --> Controller Class Initialized
INFO - 2024-02-07 06:39:02 --> Model Class Initialized
DEBUG - 2024-02-07 06:39:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:39:02 --> Final output sent to browser
DEBUG - 2024-02-07 06:39:02 --> Total execution time: 0.0146
ERROR - 2024-02-07 06:39:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:39:03 --> Config Class Initialized
INFO - 2024-02-07 06:39:03 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:39:03 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:39:03 --> Utf8 Class Initialized
INFO - 2024-02-07 06:39:03 --> URI Class Initialized
INFO - 2024-02-07 06:39:03 --> Router Class Initialized
INFO - 2024-02-07 06:39:03 --> Output Class Initialized
INFO - 2024-02-07 06:39:03 --> Security Class Initialized
DEBUG - 2024-02-07 06:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:39:03 --> Input Class Initialized
INFO - 2024-02-07 06:39:03 --> Language Class Initialized
INFO - 2024-02-07 06:39:03 --> Loader Class Initialized
INFO - 2024-02-07 06:39:03 --> Helper loaded: url_helper
INFO - 2024-02-07 06:39:03 --> Helper loaded: file_helper
INFO - 2024-02-07 06:39:03 --> Helper loaded: html_helper
INFO - 2024-02-07 06:39:03 --> Helper loaded: text_helper
INFO - 2024-02-07 06:39:03 --> Helper loaded: form_helper
INFO - 2024-02-07 06:39:03 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:39:03 --> Helper loaded: security_helper
INFO - 2024-02-07 06:39:03 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:39:03 --> Database Driver Class Initialized
INFO - 2024-02-07 06:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:39:03 --> Parser Class Initialized
INFO - 2024-02-07 06:39:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:39:03 --> Pagination Class Initialized
INFO - 2024-02-07 06:39:03 --> Form Validation Class Initialized
INFO - 2024-02-07 06:39:03 --> Controller Class Initialized
INFO - 2024-02-07 06:39:03 --> Model Class Initialized
DEBUG - 2024-02-07 06:39:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:39:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-07 06:39:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:39:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:39:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:39:03 --> Model Class Initialized
INFO - 2024-02-07 06:39:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:39:03 --> Final output sent to browser
DEBUG - 2024-02-07 06:39:03 --> Total execution time: 0.0283
ERROR - 2024-02-07 06:39:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:39:03 --> Config Class Initialized
INFO - 2024-02-07 06:39:03 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:39:03 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:39:03 --> Utf8 Class Initialized
INFO - 2024-02-07 06:39:03 --> URI Class Initialized
INFO - 2024-02-07 06:39:03 --> Router Class Initialized
INFO - 2024-02-07 06:39:03 --> Output Class Initialized
INFO - 2024-02-07 06:39:03 --> Security Class Initialized
DEBUG - 2024-02-07 06:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:39:03 --> Input Class Initialized
INFO - 2024-02-07 06:39:03 --> Language Class Initialized
INFO - 2024-02-07 06:39:03 --> Loader Class Initialized
INFO - 2024-02-07 06:39:03 --> Helper loaded: url_helper
INFO - 2024-02-07 06:39:03 --> Helper loaded: file_helper
INFO - 2024-02-07 06:39:03 --> Helper loaded: html_helper
INFO - 2024-02-07 06:39:03 --> Helper loaded: text_helper
INFO - 2024-02-07 06:39:03 --> Helper loaded: form_helper
INFO - 2024-02-07 06:39:03 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:39:03 --> Helper loaded: security_helper
INFO - 2024-02-07 06:39:03 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:39:03 --> Database Driver Class Initialized
INFO - 2024-02-07 06:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:39:03 --> Parser Class Initialized
INFO - 2024-02-07 06:39:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:39:03 --> Pagination Class Initialized
INFO - 2024-02-07 06:39:03 --> Form Validation Class Initialized
INFO - 2024-02-07 06:39:03 --> Controller Class Initialized
DEBUG - 2024-02-07 06:39:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:39:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:39:03 --> Model Class Initialized
DEBUG - 2024-02-07 06:39:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:39:03 --> Model Class Initialized
INFO - 2024-02-07 06:39:03 --> Final output sent to browser
DEBUG - 2024-02-07 06:39:03 --> Total execution time: 0.0299
ERROR - 2024-02-07 06:39:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:39:32 --> Config Class Initialized
INFO - 2024-02-07 06:39:32 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:39:32 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:39:32 --> Utf8 Class Initialized
INFO - 2024-02-07 06:39:32 --> URI Class Initialized
DEBUG - 2024-02-07 06:39:32 --> No URI present. Default controller set.
INFO - 2024-02-07 06:39:32 --> Router Class Initialized
INFO - 2024-02-07 06:39:32 --> Output Class Initialized
INFO - 2024-02-07 06:39:32 --> Security Class Initialized
DEBUG - 2024-02-07 06:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:39:32 --> Input Class Initialized
INFO - 2024-02-07 06:39:32 --> Language Class Initialized
INFO - 2024-02-07 06:39:32 --> Loader Class Initialized
INFO - 2024-02-07 06:39:32 --> Helper loaded: url_helper
INFO - 2024-02-07 06:39:32 --> Helper loaded: file_helper
INFO - 2024-02-07 06:39:32 --> Helper loaded: html_helper
INFO - 2024-02-07 06:39:32 --> Helper loaded: text_helper
INFO - 2024-02-07 06:39:32 --> Helper loaded: form_helper
INFO - 2024-02-07 06:39:32 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:39:32 --> Helper loaded: security_helper
INFO - 2024-02-07 06:39:32 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:39:32 --> Database Driver Class Initialized
INFO - 2024-02-07 06:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:39:32 --> Parser Class Initialized
INFO - 2024-02-07 06:39:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:39:32 --> Pagination Class Initialized
INFO - 2024-02-07 06:39:32 --> Form Validation Class Initialized
INFO - 2024-02-07 06:39:32 --> Controller Class Initialized
INFO - 2024-02-07 06:39:32 --> Model Class Initialized
DEBUG - 2024-02-07 06:39:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:39:32 --> Model Class Initialized
DEBUG - 2024-02-07 06:39:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:39:32 --> Model Class Initialized
INFO - 2024-02-07 06:39:32 --> Model Class Initialized
INFO - 2024-02-07 06:39:32 --> Model Class Initialized
INFO - 2024-02-07 06:39:32 --> Model Class Initialized
DEBUG - 2024-02-07 06:39:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:39:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:39:32 --> Model Class Initialized
INFO - 2024-02-07 06:39:32 --> Model Class Initialized
INFO - 2024-02-07 06:39:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-07 06:39:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:39:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:39:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:39:32 --> Model Class Initialized
INFO - 2024-02-07 06:39:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 06:39:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 06:39:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:39:32 --> Final output sent to browser
DEBUG - 2024-02-07 06:39:32 --> Total execution time: 0.4035
ERROR - 2024-02-07 06:42:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:42:48 --> Config Class Initialized
INFO - 2024-02-07 06:42:48 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:42:48 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:42:48 --> Utf8 Class Initialized
INFO - 2024-02-07 06:42:48 --> URI Class Initialized
INFO - 2024-02-07 06:42:48 --> Router Class Initialized
INFO - 2024-02-07 06:42:48 --> Output Class Initialized
INFO - 2024-02-07 06:42:48 --> Security Class Initialized
DEBUG - 2024-02-07 06:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:42:48 --> Input Class Initialized
INFO - 2024-02-07 06:42:48 --> Language Class Initialized
INFO - 2024-02-07 06:42:48 --> Loader Class Initialized
INFO - 2024-02-07 06:42:48 --> Helper loaded: url_helper
INFO - 2024-02-07 06:42:48 --> Helper loaded: file_helper
INFO - 2024-02-07 06:42:48 --> Helper loaded: html_helper
INFO - 2024-02-07 06:42:48 --> Helper loaded: text_helper
INFO - 2024-02-07 06:42:48 --> Helper loaded: form_helper
INFO - 2024-02-07 06:42:48 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:42:48 --> Helper loaded: security_helper
INFO - 2024-02-07 06:42:48 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:42:48 --> Database Driver Class Initialized
INFO - 2024-02-07 06:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:42:48 --> Parser Class Initialized
INFO - 2024-02-07 06:42:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:42:48 --> Pagination Class Initialized
INFO - 2024-02-07 06:42:48 --> Form Validation Class Initialized
INFO - 2024-02-07 06:42:48 --> Controller Class Initialized
INFO - 2024-02-07 06:42:48 --> Model Class Initialized
DEBUG - 2024-02-07 06:42:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:42:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:42:48 --> Model Class Initialized
DEBUG - 2024-02-07 06:42:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:42:48 --> Model Class Initialized
INFO - 2024-02-07 06:42:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-07 06:42:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:42:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:42:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:42:48 --> Model Class Initialized
INFO - 2024-02-07 06:42:48 --> Model Class Initialized
INFO - 2024-02-07 06:42:48 --> Model Class Initialized
INFO - 2024-02-07 06:42:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 06:42:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 06:42:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:42:48 --> Final output sent to browser
DEBUG - 2024-02-07 06:42:48 --> Total execution time: 0.2224
ERROR - 2024-02-07 06:42:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:42:49 --> Config Class Initialized
INFO - 2024-02-07 06:42:49 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:42:49 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:42:49 --> Utf8 Class Initialized
INFO - 2024-02-07 06:42:49 --> URI Class Initialized
INFO - 2024-02-07 06:42:49 --> Router Class Initialized
INFO - 2024-02-07 06:42:49 --> Output Class Initialized
INFO - 2024-02-07 06:42:49 --> Security Class Initialized
DEBUG - 2024-02-07 06:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:42:49 --> Input Class Initialized
INFO - 2024-02-07 06:42:49 --> Language Class Initialized
INFO - 2024-02-07 06:42:49 --> Loader Class Initialized
INFO - 2024-02-07 06:42:49 --> Helper loaded: url_helper
INFO - 2024-02-07 06:42:49 --> Helper loaded: file_helper
INFO - 2024-02-07 06:42:49 --> Helper loaded: html_helper
INFO - 2024-02-07 06:42:49 --> Helper loaded: text_helper
INFO - 2024-02-07 06:42:49 --> Helper loaded: form_helper
INFO - 2024-02-07 06:42:49 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:42:49 --> Helper loaded: security_helper
INFO - 2024-02-07 06:42:49 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:42:49 --> Database Driver Class Initialized
INFO - 2024-02-07 06:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:42:49 --> Parser Class Initialized
INFO - 2024-02-07 06:42:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:42:49 --> Pagination Class Initialized
INFO - 2024-02-07 06:42:49 --> Form Validation Class Initialized
INFO - 2024-02-07 06:42:49 --> Controller Class Initialized
INFO - 2024-02-07 06:42:49 --> Model Class Initialized
DEBUG - 2024-02-07 06:42:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:42:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:42:49 --> Model Class Initialized
DEBUG - 2024-02-07 06:42:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:42:49 --> Model Class Initialized
INFO - 2024-02-07 06:42:49 --> Final output sent to browser
DEBUG - 2024-02-07 06:42:49 --> Total execution time: 0.0797
ERROR - 2024-02-07 06:43:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:43:19 --> Config Class Initialized
INFO - 2024-02-07 06:43:19 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:43:19 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:43:19 --> Utf8 Class Initialized
INFO - 2024-02-07 06:43:19 --> URI Class Initialized
INFO - 2024-02-07 06:43:19 --> Router Class Initialized
INFO - 2024-02-07 06:43:19 --> Output Class Initialized
INFO - 2024-02-07 06:43:19 --> Security Class Initialized
DEBUG - 2024-02-07 06:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:43:19 --> Input Class Initialized
INFO - 2024-02-07 06:43:19 --> Language Class Initialized
INFO - 2024-02-07 06:43:19 --> Loader Class Initialized
INFO - 2024-02-07 06:43:19 --> Helper loaded: url_helper
INFO - 2024-02-07 06:43:19 --> Helper loaded: file_helper
INFO - 2024-02-07 06:43:19 --> Helper loaded: html_helper
INFO - 2024-02-07 06:43:19 --> Helper loaded: text_helper
INFO - 2024-02-07 06:43:19 --> Helper loaded: form_helper
INFO - 2024-02-07 06:43:19 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:43:19 --> Helper loaded: security_helper
INFO - 2024-02-07 06:43:19 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:43:19 --> Database Driver Class Initialized
INFO - 2024-02-07 06:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:43:19 --> Parser Class Initialized
INFO - 2024-02-07 06:43:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:43:19 --> Pagination Class Initialized
INFO - 2024-02-07 06:43:19 --> Form Validation Class Initialized
INFO - 2024-02-07 06:43:19 --> Controller Class Initialized
INFO - 2024-02-07 06:43:19 --> Model Class Initialized
DEBUG - 2024-02-07 06:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:43:19 --> Final output sent to browser
DEBUG - 2024-02-07 06:43:19 --> Total execution time: 0.0153
ERROR - 2024-02-07 06:43:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:43:19 --> Config Class Initialized
INFO - 2024-02-07 06:43:19 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:43:19 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:43:19 --> Utf8 Class Initialized
INFO - 2024-02-07 06:43:19 --> URI Class Initialized
INFO - 2024-02-07 06:43:19 --> Router Class Initialized
INFO - 2024-02-07 06:43:19 --> Output Class Initialized
INFO - 2024-02-07 06:43:19 --> Security Class Initialized
DEBUG - 2024-02-07 06:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:43:19 --> Input Class Initialized
INFO - 2024-02-07 06:43:19 --> Language Class Initialized
INFO - 2024-02-07 06:43:19 --> Loader Class Initialized
INFO - 2024-02-07 06:43:19 --> Helper loaded: url_helper
INFO - 2024-02-07 06:43:19 --> Helper loaded: file_helper
INFO - 2024-02-07 06:43:19 --> Helper loaded: html_helper
INFO - 2024-02-07 06:43:19 --> Helper loaded: text_helper
INFO - 2024-02-07 06:43:19 --> Helper loaded: form_helper
INFO - 2024-02-07 06:43:19 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:43:19 --> Helper loaded: security_helper
INFO - 2024-02-07 06:43:19 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:43:19 --> Database Driver Class Initialized
INFO - 2024-02-07 06:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:43:19 --> Parser Class Initialized
INFO - 2024-02-07 06:43:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:43:19 --> Pagination Class Initialized
INFO - 2024-02-07 06:43:19 --> Form Validation Class Initialized
INFO - 2024-02-07 06:43:19 --> Controller Class Initialized
INFO - 2024-02-07 06:43:19 --> Model Class Initialized
DEBUG - 2024-02-07 06:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:43:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-07 06:43:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:43:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:43:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:43:19 --> Model Class Initialized
INFO - 2024-02-07 06:43:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:43:19 --> Final output sent to browser
DEBUG - 2024-02-07 06:43:19 --> Total execution time: 0.0293
ERROR - 2024-02-07 06:43:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:43:27 --> Config Class Initialized
INFO - 2024-02-07 06:43:27 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:43:27 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:43:27 --> Utf8 Class Initialized
INFO - 2024-02-07 06:43:27 --> URI Class Initialized
INFO - 2024-02-07 06:43:27 --> Router Class Initialized
INFO - 2024-02-07 06:43:27 --> Output Class Initialized
INFO - 2024-02-07 06:43:27 --> Security Class Initialized
DEBUG - 2024-02-07 06:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:43:27 --> Input Class Initialized
INFO - 2024-02-07 06:43:27 --> Language Class Initialized
INFO - 2024-02-07 06:43:27 --> Loader Class Initialized
INFO - 2024-02-07 06:43:27 --> Helper loaded: url_helper
INFO - 2024-02-07 06:43:27 --> Helper loaded: file_helper
INFO - 2024-02-07 06:43:27 --> Helper loaded: html_helper
INFO - 2024-02-07 06:43:27 --> Helper loaded: text_helper
INFO - 2024-02-07 06:43:27 --> Helper loaded: form_helper
INFO - 2024-02-07 06:43:27 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:43:27 --> Helper loaded: security_helper
INFO - 2024-02-07 06:43:27 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:43:27 --> Database Driver Class Initialized
INFO - 2024-02-07 06:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:43:27 --> Parser Class Initialized
INFO - 2024-02-07 06:43:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:43:27 --> Pagination Class Initialized
INFO - 2024-02-07 06:43:27 --> Form Validation Class Initialized
INFO - 2024-02-07 06:43:27 --> Controller Class Initialized
INFO - 2024-02-07 06:43:27 --> Model Class Initialized
DEBUG - 2024-02-07 06:43:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:43:27 --> Model Class Initialized
INFO - 2024-02-07 06:43:27 --> Final output sent to browser
DEBUG - 2024-02-07 06:43:27 --> Total execution time: 0.0170
ERROR - 2024-02-07 06:43:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:43:27 --> Config Class Initialized
INFO - 2024-02-07 06:43:27 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:43:27 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:43:27 --> Utf8 Class Initialized
INFO - 2024-02-07 06:43:27 --> URI Class Initialized
DEBUG - 2024-02-07 06:43:27 --> No URI present. Default controller set.
INFO - 2024-02-07 06:43:27 --> Router Class Initialized
INFO - 2024-02-07 06:43:27 --> Output Class Initialized
INFO - 2024-02-07 06:43:27 --> Security Class Initialized
DEBUG - 2024-02-07 06:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:43:27 --> Input Class Initialized
INFO - 2024-02-07 06:43:27 --> Language Class Initialized
INFO - 2024-02-07 06:43:27 --> Loader Class Initialized
INFO - 2024-02-07 06:43:27 --> Helper loaded: url_helper
INFO - 2024-02-07 06:43:27 --> Helper loaded: file_helper
INFO - 2024-02-07 06:43:27 --> Helper loaded: html_helper
INFO - 2024-02-07 06:43:27 --> Helper loaded: text_helper
INFO - 2024-02-07 06:43:27 --> Helper loaded: form_helper
INFO - 2024-02-07 06:43:27 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:43:27 --> Helper loaded: security_helper
INFO - 2024-02-07 06:43:27 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:43:27 --> Database Driver Class Initialized
INFO - 2024-02-07 06:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:43:27 --> Parser Class Initialized
INFO - 2024-02-07 06:43:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:43:27 --> Pagination Class Initialized
INFO - 2024-02-07 06:43:27 --> Form Validation Class Initialized
INFO - 2024-02-07 06:43:27 --> Controller Class Initialized
INFO - 2024-02-07 06:43:27 --> Model Class Initialized
DEBUG - 2024-02-07 06:43:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:43:27 --> Model Class Initialized
DEBUG - 2024-02-07 06:43:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:43:27 --> Model Class Initialized
INFO - 2024-02-07 06:43:27 --> Model Class Initialized
INFO - 2024-02-07 06:43:27 --> Model Class Initialized
INFO - 2024-02-07 06:43:27 --> Model Class Initialized
DEBUG - 2024-02-07 06:43:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:43:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:43:27 --> Model Class Initialized
INFO - 2024-02-07 06:43:27 --> Model Class Initialized
INFO - 2024-02-07 06:43:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-07 06:43:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:43:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:43:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:43:27 --> Model Class Initialized
INFO - 2024-02-07 06:43:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 06:43:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 06:43:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:43:27 --> Final output sent to browser
DEBUG - 2024-02-07 06:43:27 --> Total execution time: 0.2196
ERROR - 2024-02-07 06:43:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:43:32 --> Config Class Initialized
INFO - 2024-02-07 06:43:32 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:43:32 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:43:32 --> Utf8 Class Initialized
INFO - 2024-02-07 06:43:32 --> URI Class Initialized
INFO - 2024-02-07 06:43:32 --> Router Class Initialized
INFO - 2024-02-07 06:43:32 --> Output Class Initialized
INFO - 2024-02-07 06:43:32 --> Security Class Initialized
DEBUG - 2024-02-07 06:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:43:32 --> Input Class Initialized
INFO - 2024-02-07 06:43:32 --> Language Class Initialized
INFO - 2024-02-07 06:43:32 --> Loader Class Initialized
INFO - 2024-02-07 06:43:32 --> Helper loaded: url_helper
INFO - 2024-02-07 06:43:32 --> Helper loaded: file_helper
INFO - 2024-02-07 06:43:32 --> Helper loaded: html_helper
INFO - 2024-02-07 06:43:32 --> Helper loaded: text_helper
INFO - 2024-02-07 06:43:32 --> Helper loaded: form_helper
INFO - 2024-02-07 06:43:32 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:43:32 --> Helper loaded: security_helper
INFO - 2024-02-07 06:43:32 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:43:32 --> Database Driver Class Initialized
INFO - 2024-02-07 06:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:43:32 --> Parser Class Initialized
INFO - 2024-02-07 06:43:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:43:32 --> Pagination Class Initialized
INFO - 2024-02-07 06:43:32 --> Form Validation Class Initialized
INFO - 2024-02-07 06:43:32 --> Controller Class Initialized
INFO - 2024-02-07 06:43:32 --> Model Class Initialized
DEBUG - 2024-02-07 06:43:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:43:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:43:32 --> Model Class Initialized
DEBUG - 2024-02-07 06:43:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:43:32 --> Model Class Initialized
INFO - 2024-02-07 06:43:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-02-07 06:43:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:43:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:43:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:43:32 --> Model Class Initialized
INFO - 2024-02-07 06:43:32 --> Model Class Initialized
INFO - 2024-02-07 06:43:32 --> Model Class Initialized
INFO - 2024-02-07 06:43:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 06:43:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 06:43:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:43:32 --> Final output sent to browser
DEBUG - 2024-02-07 06:43:32 --> Total execution time: 0.1794
ERROR - 2024-02-07 06:43:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:43:37 --> Config Class Initialized
INFO - 2024-02-07 06:43:37 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:43:37 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:43:37 --> Utf8 Class Initialized
INFO - 2024-02-07 06:43:37 --> URI Class Initialized
INFO - 2024-02-07 06:43:37 --> Router Class Initialized
INFO - 2024-02-07 06:43:37 --> Output Class Initialized
INFO - 2024-02-07 06:43:37 --> Security Class Initialized
DEBUG - 2024-02-07 06:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:43:37 --> Input Class Initialized
INFO - 2024-02-07 06:43:37 --> Language Class Initialized
INFO - 2024-02-07 06:43:37 --> Loader Class Initialized
INFO - 2024-02-07 06:43:37 --> Helper loaded: url_helper
INFO - 2024-02-07 06:43:37 --> Helper loaded: file_helper
INFO - 2024-02-07 06:43:37 --> Helper loaded: html_helper
INFO - 2024-02-07 06:43:37 --> Helper loaded: text_helper
INFO - 2024-02-07 06:43:37 --> Helper loaded: form_helper
INFO - 2024-02-07 06:43:37 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:43:37 --> Helper loaded: security_helper
INFO - 2024-02-07 06:43:37 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:43:37 --> Database Driver Class Initialized
INFO - 2024-02-07 06:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:43:37 --> Parser Class Initialized
INFO - 2024-02-07 06:43:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:43:37 --> Pagination Class Initialized
INFO - 2024-02-07 06:43:37 --> Form Validation Class Initialized
INFO - 2024-02-07 06:43:37 --> Controller Class Initialized
INFO - 2024-02-07 06:43:37 --> Model Class Initialized
DEBUG - 2024-02-07 06:43:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:43:37 --> Final output sent to browser
DEBUG - 2024-02-07 06:43:37 --> Total execution time: 0.0389
ERROR - 2024-02-07 06:43:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:43:39 --> Config Class Initialized
INFO - 2024-02-07 06:43:39 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:43:39 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:43:39 --> Utf8 Class Initialized
INFO - 2024-02-07 06:43:39 --> URI Class Initialized
INFO - 2024-02-07 06:43:39 --> Router Class Initialized
INFO - 2024-02-07 06:43:39 --> Output Class Initialized
INFO - 2024-02-07 06:43:39 --> Security Class Initialized
DEBUG - 2024-02-07 06:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:43:39 --> Input Class Initialized
INFO - 2024-02-07 06:43:39 --> Language Class Initialized
INFO - 2024-02-07 06:43:39 --> Loader Class Initialized
INFO - 2024-02-07 06:43:39 --> Helper loaded: url_helper
INFO - 2024-02-07 06:43:39 --> Helper loaded: file_helper
INFO - 2024-02-07 06:43:39 --> Helper loaded: html_helper
INFO - 2024-02-07 06:43:39 --> Helper loaded: text_helper
INFO - 2024-02-07 06:43:39 --> Helper loaded: form_helper
INFO - 2024-02-07 06:43:39 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:43:39 --> Helper loaded: security_helper
INFO - 2024-02-07 06:43:39 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:43:39 --> Database Driver Class Initialized
INFO - 2024-02-07 06:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:43:39 --> Parser Class Initialized
INFO - 2024-02-07 06:43:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:43:39 --> Pagination Class Initialized
INFO - 2024-02-07 06:43:39 --> Form Validation Class Initialized
INFO - 2024-02-07 06:43:39 --> Controller Class Initialized
INFO - 2024-02-07 06:43:39 --> Model Class Initialized
DEBUG - 2024-02-07 06:43:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:43:39 --> Final output sent to browser
DEBUG - 2024-02-07 06:43:39 --> Total execution time: 0.0153
ERROR - 2024-02-07 06:43:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:43:40 --> Config Class Initialized
INFO - 2024-02-07 06:43:40 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:43:40 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:43:40 --> Utf8 Class Initialized
INFO - 2024-02-07 06:43:40 --> URI Class Initialized
INFO - 2024-02-07 06:43:40 --> Router Class Initialized
INFO - 2024-02-07 06:43:40 --> Output Class Initialized
INFO - 2024-02-07 06:43:40 --> Security Class Initialized
DEBUG - 2024-02-07 06:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:43:40 --> Input Class Initialized
INFO - 2024-02-07 06:43:40 --> Language Class Initialized
INFO - 2024-02-07 06:43:40 --> Loader Class Initialized
INFO - 2024-02-07 06:43:40 --> Helper loaded: url_helper
INFO - 2024-02-07 06:43:40 --> Helper loaded: file_helper
INFO - 2024-02-07 06:43:40 --> Helper loaded: html_helper
INFO - 2024-02-07 06:43:40 --> Helper loaded: text_helper
INFO - 2024-02-07 06:43:40 --> Helper loaded: form_helper
INFO - 2024-02-07 06:43:40 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:43:40 --> Helper loaded: security_helper
INFO - 2024-02-07 06:43:40 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:43:40 --> Database Driver Class Initialized
INFO - 2024-02-07 06:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:43:40 --> Parser Class Initialized
INFO - 2024-02-07 06:43:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:43:40 --> Pagination Class Initialized
INFO - 2024-02-07 06:43:40 --> Form Validation Class Initialized
INFO - 2024-02-07 06:43:40 --> Controller Class Initialized
INFO - 2024-02-07 06:43:40 --> Model Class Initialized
DEBUG - 2024-02-07 06:43:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:43:40 --> Final output sent to browser
DEBUG - 2024-02-07 06:43:40 --> Total execution time: 0.0158
ERROR - 2024-02-07 06:43:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:43:41 --> Config Class Initialized
INFO - 2024-02-07 06:43:41 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:43:41 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:43:41 --> Utf8 Class Initialized
INFO - 2024-02-07 06:43:41 --> URI Class Initialized
INFO - 2024-02-07 06:43:41 --> Router Class Initialized
INFO - 2024-02-07 06:43:41 --> Output Class Initialized
INFO - 2024-02-07 06:43:41 --> Security Class Initialized
DEBUG - 2024-02-07 06:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:43:41 --> Input Class Initialized
INFO - 2024-02-07 06:43:41 --> Language Class Initialized
INFO - 2024-02-07 06:43:41 --> Loader Class Initialized
INFO - 2024-02-07 06:43:41 --> Helper loaded: url_helper
INFO - 2024-02-07 06:43:41 --> Helper loaded: file_helper
INFO - 2024-02-07 06:43:41 --> Helper loaded: html_helper
INFO - 2024-02-07 06:43:41 --> Helper loaded: text_helper
INFO - 2024-02-07 06:43:41 --> Helper loaded: form_helper
INFO - 2024-02-07 06:43:41 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:43:41 --> Helper loaded: security_helper
INFO - 2024-02-07 06:43:41 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:43:41 --> Database Driver Class Initialized
INFO - 2024-02-07 06:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:43:41 --> Parser Class Initialized
INFO - 2024-02-07 06:43:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:43:41 --> Pagination Class Initialized
INFO - 2024-02-07 06:43:41 --> Form Validation Class Initialized
INFO - 2024-02-07 06:43:41 --> Controller Class Initialized
INFO - 2024-02-07 06:43:41 --> Final output sent to browser
DEBUG - 2024-02-07 06:43:41 --> Total execution time: 0.0148
ERROR - 2024-02-07 06:44:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:44:02 --> Config Class Initialized
INFO - 2024-02-07 06:44:02 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:44:02 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:44:02 --> Utf8 Class Initialized
INFO - 2024-02-07 06:44:02 --> URI Class Initialized
INFO - 2024-02-07 06:44:02 --> Router Class Initialized
INFO - 2024-02-07 06:44:02 --> Output Class Initialized
INFO - 2024-02-07 06:44:02 --> Security Class Initialized
DEBUG - 2024-02-07 06:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:44:02 --> Input Class Initialized
INFO - 2024-02-07 06:44:02 --> Language Class Initialized
INFO - 2024-02-07 06:44:02 --> Loader Class Initialized
INFO - 2024-02-07 06:44:02 --> Helper loaded: url_helper
INFO - 2024-02-07 06:44:02 --> Helper loaded: file_helper
INFO - 2024-02-07 06:44:02 --> Helper loaded: html_helper
INFO - 2024-02-07 06:44:02 --> Helper loaded: text_helper
INFO - 2024-02-07 06:44:02 --> Helper loaded: form_helper
INFO - 2024-02-07 06:44:02 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:44:02 --> Helper loaded: security_helper
INFO - 2024-02-07 06:44:02 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:44:02 --> Database Driver Class Initialized
INFO - 2024-02-07 06:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:44:02 --> Parser Class Initialized
INFO - 2024-02-07 06:44:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:44:02 --> Pagination Class Initialized
INFO - 2024-02-07 06:44:02 --> Form Validation Class Initialized
INFO - 2024-02-07 06:44:02 --> Controller Class Initialized
INFO - 2024-02-07 06:44:02 --> Model Class Initialized
DEBUG - 2024-02-07 06:44:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:44:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:44:02 --> Model Class Initialized
DEBUG - 2024-02-07 06:44:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:44:02 --> Model Class Initialized
INFO - 2024-02-07 06:44:02 --> Final output sent to browser
DEBUG - 2024-02-07 06:44:02 --> Total execution time: 0.0956
ERROR - 2024-02-07 06:44:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:44:03 --> Config Class Initialized
INFO - 2024-02-07 06:44:03 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:44:03 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:44:03 --> Utf8 Class Initialized
INFO - 2024-02-07 06:44:03 --> URI Class Initialized
INFO - 2024-02-07 06:44:03 --> Router Class Initialized
INFO - 2024-02-07 06:44:03 --> Output Class Initialized
INFO - 2024-02-07 06:44:03 --> Security Class Initialized
DEBUG - 2024-02-07 06:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:44:03 --> Input Class Initialized
INFO - 2024-02-07 06:44:03 --> Language Class Initialized
INFO - 2024-02-07 06:44:03 --> Loader Class Initialized
INFO - 2024-02-07 06:44:03 --> Helper loaded: url_helper
INFO - 2024-02-07 06:44:03 --> Helper loaded: file_helper
INFO - 2024-02-07 06:44:03 --> Helper loaded: html_helper
INFO - 2024-02-07 06:44:03 --> Helper loaded: text_helper
INFO - 2024-02-07 06:44:03 --> Helper loaded: form_helper
INFO - 2024-02-07 06:44:03 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:44:03 --> Helper loaded: security_helper
INFO - 2024-02-07 06:44:03 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:44:03 --> Database Driver Class Initialized
INFO - 2024-02-07 06:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:44:03 --> Parser Class Initialized
INFO - 2024-02-07 06:44:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:44:03 --> Pagination Class Initialized
INFO - 2024-02-07 06:44:03 --> Form Validation Class Initialized
INFO - 2024-02-07 06:44:03 --> Controller Class Initialized
INFO - 2024-02-07 06:44:03 --> Model Class Initialized
DEBUG - 2024-02-07 06:44:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:44:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:44:03 --> Model Class Initialized
DEBUG - 2024-02-07 06:44:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:44:03 --> Model Class Initialized
INFO - 2024-02-07 06:44:03 --> Final output sent to browser
DEBUG - 2024-02-07 06:44:03 --> Total execution time: 0.0910
ERROR - 2024-02-07 06:44:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:44:04 --> Config Class Initialized
INFO - 2024-02-07 06:44:04 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:44:04 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:44:04 --> Utf8 Class Initialized
INFO - 2024-02-07 06:44:04 --> URI Class Initialized
INFO - 2024-02-07 06:44:04 --> Router Class Initialized
INFO - 2024-02-07 06:44:04 --> Output Class Initialized
INFO - 2024-02-07 06:44:04 --> Security Class Initialized
DEBUG - 2024-02-07 06:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:44:04 --> Input Class Initialized
INFO - 2024-02-07 06:44:04 --> Language Class Initialized
INFO - 2024-02-07 06:44:04 --> Loader Class Initialized
INFO - 2024-02-07 06:44:04 --> Helper loaded: url_helper
INFO - 2024-02-07 06:44:04 --> Helper loaded: file_helper
INFO - 2024-02-07 06:44:04 --> Helper loaded: html_helper
INFO - 2024-02-07 06:44:04 --> Helper loaded: text_helper
INFO - 2024-02-07 06:44:04 --> Helper loaded: form_helper
INFO - 2024-02-07 06:44:04 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:44:04 --> Helper loaded: security_helper
INFO - 2024-02-07 06:44:04 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:44:04 --> Database Driver Class Initialized
INFO - 2024-02-07 06:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:44:04 --> Parser Class Initialized
INFO - 2024-02-07 06:44:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:44:04 --> Pagination Class Initialized
INFO - 2024-02-07 06:44:04 --> Form Validation Class Initialized
INFO - 2024-02-07 06:44:04 --> Controller Class Initialized
INFO - 2024-02-07 06:44:04 --> Model Class Initialized
DEBUG - 2024-02-07 06:44:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:44:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:44:04 --> Model Class Initialized
DEBUG - 2024-02-07 06:44:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:44:04 --> Model Class Initialized
INFO - 2024-02-07 06:44:04 --> Final output sent to browser
DEBUG - 2024-02-07 06:44:04 --> Total execution time: 0.0383
ERROR - 2024-02-07 06:44:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:44:06 --> Config Class Initialized
INFO - 2024-02-07 06:44:06 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:44:06 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:44:06 --> Utf8 Class Initialized
INFO - 2024-02-07 06:44:06 --> URI Class Initialized
INFO - 2024-02-07 06:44:06 --> Router Class Initialized
INFO - 2024-02-07 06:44:06 --> Output Class Initialized
INFO - 2024-02-07 06:44:06 --> Security Class Initialized
DEBUG - 2024-02-07 06:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:44:06 --> Input Class Initialized
INFO - 2024-02-07 06:44:06 --> Language Class Initialized
INFO - 2024-02-07 06:44:06 --> Loader Class Initialized
INFO - 2024-02-07 06:44:06 --> Helper loaded: url_helper
INFO - 2024-02-07 06:44:06 --> Helper loaded: file_helper
INFO - 2024-02-07 06:44:06 --> Helper loaded: html_helper
INFO - 2024-02-07 06:44:06 --> Helper loaded: text_helper
INFO - 2024-02-07 06:44:06 --> Helper loaded: form_helper
INFO - 2024-02-07 06:44:06 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:44:06 --> Helper loaded: security_helper
INFO - 2024-02-07 06:44:06 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:44:06 --> Database Driver Class Initialized
INFO - 2024-02-07 06:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:44:06 --> Parser Class Initialized
INFO - 2024-02-07 06:44:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:44:06 --> Pagination Class Initialized
INFO - 2024-02-07 06:44:06 --> Form Validation Class Initialized
INFO - 2024-02-07 06:44:06 --> Controller Class Initialized
INFO - 2024-02-07 06:44:06 --> Model Class Initialized
DEBUG - 2024-02-07 06:44:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:44:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:44:06 --> Model Class Initialized
INFO - 2024-02-07 06:44:06 --> Model Class Initialized
INFO - 2024-02-07 06:44:06 --> Final output sent to browser
DEBUG - 2024-02-07 06:44:06 --> Total execution time: 0.0198
ERROR - 2024-02-07 06:44:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:44:08 --> Config Class Initialized
INFO - 2024-02-07 06:44:08 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:44:08 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:44:08 --> Utf8 Class Initialized
INFO - 2024-02-07 06:44:08 --> URI Class Initialized
INFO - 2024-02-07 06:44:08 --> Router Class Initialized
INFO - 2024-02-07 06:44:08 --> Output Class Initialized
INFO - 2024-02-07 06:44:08 --> Security Class Initialized
DEBUG - 2024-02-07 06:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:44:08 --> Input Class Initialized
INFO - 2024-02-07 06:44:08 --> Language Class Initialized
INFO - 2024-02-07 06:44:08 --> Loader Class Initialized
INFO - 2024-02-07 06:44:08 --> Helper loaded: url_helper
INFO - 2024-02-07 06:44:08 --> Helper loaded: file_helper
INFO - 2024-02-07 06:44:08 --> Helper loaded: html_helper
INFO - 2024-02-07 06:44:08 --> Helper loaded: text_helper
INFO - 2024-02-07 06:44:08 --> Helper loaded: form_helper
INFO - 2024-02-07 06:44:08 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:44:08 --> Helper loaded: security_helper
INFO - 2024-02-07 06:44:08 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:44:08 --> Database Driver Class Initialized
INFO - 2024-02-07 06:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:44:08 --> Parser Class Initialized
INFO - 2024-02-07 06:44:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:44:08 --> Pagination Class Initialized
INFO - 2024-02-07 06:44:08 --> Form Validation Class Initialized
INFO - 2024-02-07 06:44:08 --> Controller Class Initialized
INFO - 2024-02-07 06:44:08 --> Model Class Initialized
DEBUG - 2024-02-07 06:44:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:44:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:44:08 --> Model Class Initialized
INFO - 2024-02-07 06:44:08 --> Final output sent to browser
DEBUG - 2024-02-07 06:44:08 --> Total execution time: 0.0155
ERROR - 2024-02-07 06:44:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:44:21 --> Config Class Initialized
INFO - 2024-02-07 06:44:21 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:44:21 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:44:21 --> Utf8 Class Initialized
INFO - 2024-02-07 06:44:21 --> URI Class Initialized
INFO - 2024-02-07 06:44:21 --> Router Class Initialized
INFO - 2024-02-07 06:44:21 --> Output Class Initialized
INFO - 2024-02-07 06:44:21 --> Security Class Initialized
DEBUG - 2024-02-07 06:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:44:21 --> Input Class Initialized
INFO - 2024-02-07 06:44:21 --> Language Class Initialized
INFO - 2024-02-07 06:44:21 --> Loader Class Initialized
INFO - 2024-02-07 06:44:21 --> Helper loaded: url_helper
INFO - 2024-02-07 06:44:21 --> Helper loaded: file_helper
INFO - 2024-02-07 06:44:21 --> Helper loaded: html_helper
INFO - 2024-02-07 06:44:21 --> Helper loaded: text_helper
INFO - 2024-02-07 06:44:21 --> Helper loaded: form_helper
INFO - 2024-02-07 06:44:21 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:44:21 --> Helper loaded: security_helper
INFO - 2024-02-07 06:44:21 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:44:21 --> Database Driver Class Initialized
INFO - 2024-02-07 06:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:44:21 --> Parser Class Initialized
INFO - 2024-02-07 06:44:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:44:21 --> Pagination Class Initialized
INFO - 2024-02-07 06:44:21 --> Form Validation Class Initialized
INFO - 2024-02-07 06:44:21 --> Controller Class Initialized
INFO - 2024-02-07 06:44:21 --> Model Class Initialized
DEBUG - 2024-02-07 06:44:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:44:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:44:21 --> Model Class Initialized
DEBUG - 2024-02-07 06:44:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:44:21 --> Model Class Initialized
INFO - 2024-02-07 06:44:21 --> Final output sent to browser
DEBUG - 2024-02-07 06:44:21 --> Total execution time: 0.1356
ERROR - 2024-02-07 06:44:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:44:23 --> Config Class Initialized
INFO - 2024-02-07 06:44:23 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:44:23 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:44:23 --> Utf8 Class Initialized
INFO - 2024-02-07 06:44:23 --> URI Class Initialized
INFO - 2024-02-07 06:44:23 --> Router Class Initialized
INFO - 2024-02-07 06:44:23 --> Output Class Initialized
INFO - 2024-02-07 06:44:23 --> Security Class Initialized
DEBUG - 2024-02-07 06:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:44:23 --> Input Class Initialized
INFO - 2024-02-07 06:44:23 --> Language Class Initialized
INFO - 2024-02-07 06:44:23 --> Loader Class Initialized
INFO - 2024-02-07 06:44:23 --> Helper loaded: url_helper
INFO - 2024-02-07 06:44:23 --> Helper loaded: file_helper
INFO - 2024-02-07 06:44:23 --> Helper loaded: html_helper
INFO - 2024-02-07 06:44:23 --> Helper loaded: text_helper
INFO - 2024-02-07 06:44:23 --> Helper loaded: form_helper
INFO - 2024-02-07 06:44:23 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:44:23 --> Helper loaded: security_helper
INFO - 2024-02-07 06:44:23 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:44:23 --> Database Driver Class Initialized
INFO - 2024-02-07 06:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:44:23 --> Parser Class Initialized
INFO - 2024-02-07 06:44:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:44:23 --> Pagination Class Initialized
INFO - 2024-02-07 06:44:23 --> Form Validation Class Initialized
INFO - 2024-02-07 06:44:23 --> Controller Class Initialized
INFO - 2024-02-07 06:44:23 --> Model Class Initialized
DEBUG - 2024-02-07 06:44:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:44:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:44:23 --> Model Class Initialized
INFO - 2024-02-07 06:44:23 --> Model Class Initialized
INFO - 2024-02-07 06:44:23 --> Final output sent to browser
DEBUG - 2024-02-07 06:44:23 --> Total execution time: 0.0199
ERROR - 2024-02-07 06:44:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:44:25 --> Config Class Initialized
INFO - 2024-02-07 06:44:25 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:44:25 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:44:25 --> Utf8 Class Initialized
INFO - 2024-02-07 06:44:25 --> URI Class Initialized
INFO - 2024-02-07 06:44:25 --> Router Class Initialized
INFO - 2024-02-07 06:44:25 --> Output Class Initialized
INFO - 2024-02-07 06:44:25 --> Security Class Initialized
DEBUG - 2024-02-07 06:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:44:25 --> Input Class Initialized
INFO - 2024-02-07 06:44:25 --> Language Class Initialized
INFO - 2024-02-07 06:44:25 --> Loader Class Initialized
INFO - 2024-02-07 06:44:25 --> Helper loaded: url_helper
INFO - 2024-02-07 06:44:25 --> Helper loaded: file_helper
INFO - 2024-02-07 06:44:25 --> Helper loaded: html_helper
INFO - 2024-02-07 06:44:25 --> Helper loaded: text_helper
INFO - 2024-02-07 06:44:25 --> Helper loaded: form_helper
INFO - 2024-02-07 06:44:25 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:44:25 --> Helper loaded: security_helper
INFO - 2024-02-07 06:44:25 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:44:25 --> Database Driver Class Initialized
INFO - 2024-02-07 06:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:44:25 --> Parser Class Initialized
INFO - 2024-02-07 06:44:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:44:25 --> Pagination Class Initialized
INFO - 2024-02-07 06:44:25 --> Form Validation Class Initialized
INFO - 2024-02-07 06:44:25 --> Controller Class Initialized
INFO - 2024-02-07 06:44:25 --> Model Class Initialized
DEBUG - 2024-02-07 06:44:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:44:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:44:25 --> Model Class Initialized
INFO - 2024-02-07 06:44:25 --> Final output sent to browser
DEBUG - 2024-02-07 06:44:25 --> Total execution time: 0.0167
ERROR - 2024-02-07 06:44:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:44:45 --> Config Class Initialized
INFO - 2024-02-07 06:44:45 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:44:45 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:44:45 --> Utf8 Class Initialized
INFO - 2024-02-07 06:44:45 --> URI Class Initialized
INFO - 2024-02-07 06:44:45 --> Router Class Initialized
INFO - 2024-02-07 06:44:45 --> Output Class Initialized
INFO - 2024-02-07 06:44:45 --> Security Class Initialized
DEBUG - 2024-02-07 06:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:44:45 --> Input Class Initialized
INFO - 2024-02-07 06:44:45 --> Language Class Initialized
INFO - 2024-02-07 06:44:45 --> Loader Class Initialized
INFO - 2024-02-07 06:44:45 --> Helper loaded: url_helper
INFO - 2024-02-07 06:44:45 --> Helper loaded: file_helper
INFO - 2024-02-07 06:44:45 --> Helper loaded: html_helper
INFO - 2024-02-07 06:44:45 --> Helper loaded: text_helper
INFO - 2024-02-07 06:44:45 --> Helper loaded: form_helper
INFO - 2024-02-07 06:44:45 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:44:45 --> Helper loaded: security_helper
INFO - 2024-02-07 06:44:45 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:44:45 --> Database Driver Class Initialized
INFO - 2024-02-07 06:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:44:45 --> Parser Class Initialized
INFO - 2024-02-07 06:44:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:44:45 --> Pagination Class Initialized
INFO - 2024-02-07 06:44:45 --> Form Validation Class Initialized
INFO - 2024-02-07 06:44:45 --> Controller Class Initialized
INFO - 2024-02-07 06:44:45 --> Model Class Initialized
DEBUG - 2024-02-07 06:44:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:44:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:44:45 --> Model Class Initialized
DEBUG - 2024-02-07 06:44:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:44:45 --> Model Class Initialized
INFO - 2024-02-07 06:44:45 --> Final output sent to browser
DEBUG - 2024-02-07 06:44:45 --> Total execution time: 0.0202
ERROR - 2024-02-07 06:44:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:44:49 --> Config Class Initialized
INFO - 2024-02-07 06:44:49 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:44:49 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:44:49 --> Utf8 Class Initialized
INFO - 2024-02-07 06:44:49 --> URI Class Initialized
INFO - 2024-02-07 06:44:49 --> Router Class Initialized
INFO - 2024-02-07 06:44:49 --> Output Class Initialized
INFO - 2024-02-07 06:44:49 --> Security Class Initialized
DEBUG - 2024-02-07 06:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:44:49 --> Input Class Initialized
INFO - 2024-02-07 06:44:49 --> Language Class Initialized
INFO - 2024-02-07 06:44:49 --> Loader Class Initialized
INFO - 2024-02-07 06:44:49 --> Helper loaded: url_helper
INFO - 2024-02-07 06:44:49 --> Helper loaded: file_helper
INFO - 2024-02-07 06:44:49 --> Helper loaded: html_helper
INFO - 2024-02-07 06:44:49 --> Helper loaded: text_helper
INFO - 2024-02-07 06:44:49 --> Helper loaded: form_helper
INFO - 2024-02-07 06:44:49 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:44:49 --> Helper loaded: security_helper
INFO - 2024-02-07 06:44:49 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:44:49 --> Database Driver Class Initialized
INFO - 2024-02-07 06:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:44:49 --> Parser Class Initialized
INFO - 2024-02-07 06:44:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:44:49 --> Pagination Class Initialized
INFO - 2024-02-07 06:44:49 --> Form Validation Class Initialized
INFO - 2024-02-07 06:44:49 --> Controller Class Initialized
INFO - 2024-02-07 06:44:49 --> Model Class Initialized
DEBUG - 2024-02-07 06:44:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:44:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:44:49 --> Model Class Initialized
DEBUG - 2024-02-07 06:44:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:44:49 --> Model Class Initialized
INFO - 2024-02-07 06:44:49 --> Final output sent to browser
DEBUG - 2024-02-07 06:44:49 --> Total execution time: 0.0954
ERROR - 2024-02-07 06:44:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:44:50 --> Config Class Initialized
INFO - 2024-02-07 06:44:50 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:44:50 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:44:50 --> Utf8 Class Initialized
INFO - 2024-02-07 06:44:50 --> URI Class Initialized
INFO - 2024-02-07 06:44:50 --> Router Class Initialized
INFO - 2024-02-07 06:44:50 --> Output Class Initialized
INFO - 2024-02-07 06:44:50 --> Security Class Initialized
DEBUG - 2024-02-07 06:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:44:50 --> Input Class Initialized
INFO - 2024-02-07 06:44:50 --> Language Class Initialized
INFO - 2024-02-07 06:44:50 --> Loader Class Initialized
INFO - 2024-02-07 06:44:50 --> Helper loaded: url_helper
INFO - 2024-02-07 06:44:50 --> Helper loaded: file_helper
INFO - 2024-02-07 06:44:50 --> Helper loaded: html_helper
INFO - 2024-02-07 06:44:50 --> Helper loaded: text_helper
INFO - 2024-02-07 06:44:50 --> Helper loaded: form_helper
INFO - 2024-02-07 06:44:50 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:44:50 --> Helper loaded: security_helper
INFO - 2024-02-07 06:44:50 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:44:50 --> Database Driver Class Initialized
INFO - 2024-02-07 06:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:44:50 --> Parser Class Initialized
INFO - 2024-02-07 06:44:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:44:50 --> Pagination Class Initialized
INFO - 2024-02-07 06:44:50 --> Form Validation Class Initialized
INFO - 2024-02-07 06:44:50 --> Controller Class Initialized
INFO - 2024-02-07 06:44:50 --> Model Class Initialized
DEBUG - 2024-02-07 06:44:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:44:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:44:50 --> Model Class Initialized
DEBUG - 2024-02-07 06:44:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:44:50 --> Model Class Initialized
INFO - 2024-02-07 06:44:50 --> Final output sent to browser
DEBUG - 2024-02-07 06:44:50 --> Total execution time: 0.1160
ERROR - 2024-02-07 06:44:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:44:54 --> Config Class Initialized
INFO - 2024-02-07 06:44:54 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:44:54 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:44:54 --> Utf8 Class Initialized
INFO - 2024-02-07 06:44:54 --> URI Class Initialized
INFO - 2024-02-07 06:44:54 --> Router Class Initialized
INFO - 2024-02-07 06:44:54 --> Output Class Initialized
INFO - 2024-02-07 06:44:54 --> Security Class Initialized
DEBUG - 2024-02-07 06:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:44:54 --> Input Class Initialized
INFO - 2024-02-07 06:44:54 --> Language Class Initialized
INFO - 2024-02-07 06:44:54 --> Loader Class Initialized
INFO - 2024-02-07 06:44:54 --> Helper loaded: url_helper
INFO - 2024-02-07 06:44:54 --> Helper loaded: file_helper
INFO - 2024-02-07 06:44:54 --> Helper loaded: html_helper
INFO - 2024-02-07 06:44:54 --> Helper loaded: text_helper
INFO - 2024-02-07 06:44:54 --> Helper loaded: form_helper
INFO - 2024-02-07 06:44:54 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:44:54 --> Helper loaded: security_helper
INFO - 2024-02-07 06:44:54 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:44:54 --> Database Driver Class Initialized
INFO - 2024-02-07 06:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:44:54 --> Parser Class Initialized
INFO - 2024-02-07 06:44:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:44:54 --> Pagination Class Initialized
INFO - 2024-02-07 06:44:54 --> Form Validation Class Initialized
INFO - 2024-02-07 06:44:54 --> Controller Class Initialized
INFO - 2024-02-07 06:44:54 --> Model Class Initialized
DEBUG - 2024-02-07 06:44:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:44:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:44:54 --> Model Class Initialized
INFO - 2024-02-07 06:44:54 --> Model Class Initialized
INFO - 2024-02-07 06:44:54 --> Final output sent to browser
DEBUG - 2024-02-07 06:44:54 --> Total execution time: 0.0226
ERROR - 2024-02-07 06:44:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:44:57 --> Config Class Initialized
INFO - 2024-02-07 06:44:57 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:44:57 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:44:57 --> Utf8 Class Initialized
INFO - 2024-02-07 06:44:57 --> URI Class Initialized
INFO - 2024-02-07 06:44:57 --> Router Class Initialized
INFO - 2024-02-07 06:44:57 --> Output Class Initialized
INFO - 2024-02-07 06:44:57 --> Security Class Initialized
DEBUG - 2024-02-07 06:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:44:57 --> Input Class Initialized
INFO - 2024-02-07 06:44:57 --> Language Class Initialized
INFO - 2024-02-07 06:44:57 --> Loader Class Initialized
INFO - 2024-02-07 06:44:57 --> Helper loaded: url_helper
INFO - 2024-02-07 06:44:57 --> Helper loaded: file_helper
INFO - 2024-02-07 06:44:57 --> Helper loaded: html_helper
INFO - 2024-02-07 06:44:57 --> Helper loaded: text_helper
INFO - 2024-02-07 06:44:57 --> Helper loaded: form_helper
INFO - 2024-02-07 06:44:57 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:44:57 --> Helper loaded: security_helper
INFO - 2024-02-07 06:44:57 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:44:57 --> Database Driver Class Initialized
INFO - 2024-02-07 06:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:44:57 --> Parser Class Initialized
INFO - 2024-02-07 06:44:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:44:57 --> Pagination Class Initialized
INFO - 2024-02-07 06:44:57 --> Form Validation Class Initialized
INFO - 2024-02-07 06:44:57 --> Controller Class Initialized
INFO - 2024-02-07 06:44:57 --> Model Class Initialized
DEBUG - 2024-02-07 06:44:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:44:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:44:57 --> Model Class Initialized
INFO - 2024-02-07 06:44:57 --> Final output sent to browser
DEBUG - 2024-02-07 06:44:57 --> Total execution time: 0.1052
ERROR - 2024-02-07 06:46:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:46:26 --> Config Class Initialized
INFO - 2024-02-07 06:46:26 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:46:26 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:46:26 --> Utf8 Class Initialized
INFO - 2024-02-07 06:46:26 --> URI Class Initialized
INFO - 2024-02-07 06:46:26 --> Router Class Initialized
INFO - 2024-02-07 06:46:26 --> Output Class Initialized
INFO - 2024-02-07 06:46:26 --> Security Class Initialized
DEBUG - 2024-02-07 06:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:46:26 --> Input Class Initialized
INFO - 2024-02-07 06:46:26 --> Language Class Initialized
INFO - 2024-02-07 06:46:26 --> Loader Class Initialized
INFO - 2024-02-07 06:46:26 --> Helper loaded: url_helper
INFO - 2024-02-07 06:46:26 --> Helper loaded: file_helper
INFO - 2024-02-07 06:46:26 --> Helper loaded: html_helper
INFO - 2024-02-07 06:46:26 --> Helper loaded: text_helper
INFO - 2024-02-07 06:46:26 --> Helper loaded: form_helper
INFO - 2024-02-07 06:46:26 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:46:26 --> Helper loaded: security_helper
INFO - 2024-02-07 06:46:26 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:46:26 --> Database Driver Class Initialized
INFO - 2024-02-07 06:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:46:26 --> Parser Class Initialized
INFO - 2024-02-07 06:46:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:46:26 --> Pagination Class Initialized
INFO - 2024-02-07 06:46:26 --> Form Validation Class Initialized
INFO - 2024-02-07 06:46:26 --> Controller Class Initialized
INFO - 2024-02-07 06:46:26 --> Model Class Initialized
DEBUG - 2024-02-07 06:46:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:46:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:46:26 --> Model Class Initialized
DEBUG - 2024-02-07 06:46:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:46:26 --> Model Class Initialized
INFO - 2024-02-07 06:46:26 --> Email Class Initialized
DEBUG - 2024-02-07 06:46:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:46:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2024-02-07 06:46:26 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-02-07 06:46:26 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-02-07 06:46:26 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-02-07 06:46:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-07 06:46:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-07 06:46:26 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-07 06:46:26 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-07 06:46:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-02-07 06:46:27 --> Language file loaded: language/english/email_lang.php
INFO - 2024-02-07 06:46:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2024-02-07 06:46:27 --> Final output sent to browser
DEBUG - 2024-02-07 06:46:27 --> Total execution time: 0.2366
ERROR - 2024-02-07 06:46:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:46:28 --> Config Class Initialized
INFO - 2024-02-07 06:46:28 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:46:28 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:46:28 --> Utf8 Class Initialized
INFO - 2024-02-07 06:46:28 --> URI Class Initialized
INFO - 2024-02-07 06:46:28 --> Router Class Initialized
INFO - 2024-02-07 06:46:28 --> Output Class Initialized
INFO - 2024-02-07 06:46:28 --> Security Class Initialized
DEBUG - 2024-02-07 06:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:46:28 --> Input Class Initialized
INFO - 2024-02-07 06:46:28 --> Language Class Initialized
INFO - 2024-02-07 06:46:28 --> Loader Class Initialized
INFO - 2024-02-07 06:46:28 --> Helper loaded: url_helper
INFO - 2024-02-07 06:46:28 --> Helper loaded: file_helper
INFO - 2024-02-07 06:46:28 --> Helper loaded: html_helper
INFO - 2024-02-07 06:46:28 --> Helper loaded: text_helper
INFO - 2024-02-07 06:46:28 --> Helper loaded: form_helper
INFO - 2024-02-07 06:46:28 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:46:28 --> Helper loaded: security_helper
INFO - 2024-02-07 06:46:28 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:46:28 --> Database Driver Class Initialized
INFO - 2024-02-07 06:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:46:28 --> Parser Class Initialized
INFO - 2024-02-07 06:46:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:46:28 --> Pagination Class Initialized
INFO - 2024-02-07 06:46:28 --> Form Validation Class Initialized
INFO - 2024-02-07 06:46:28 --> Controller Class Initialized
INFO - 2024-02-07 06:46:28 --> Model Class Initialized
DEBUG - 2024-02-07 06:46:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:46:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:46:28 --> Model Class Initialized
DEBUG - 2024-02-07 06:46:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:46:28 --> Model Class Initialized
INFO - 2024-02-07 06:46:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-02-07 06:46:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:46:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:46:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:46:28 --> Model Class Initialized
INFO - 2024-02-07 06:46:28 --> Model Class Initialized
INFO - 2024-02-07 06:46:28 --> Model Class Initialized
INFO - 2024-02-07 06:46:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 06:46:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 06:46:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:46:29 --> Final output sent to browser
DEBUG - 2024-02-07 06:46:29 --> Total execution time: 0.1782
ERROR - 2024-02-07 06:46:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:46:39 --> Config Class Initialized
INFO - 2024-02-07 06:46:39 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:46:39 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:46:39 --> Utf8 Class Initialized
INFO - 2024-02-07 06:46:39 --> URI Class Initialized
INFO - 2024-02-07 06:46:39 --> Router Class Initialized
INFO - 2024-02-07 06:46:39 --> Output Class Initialized
INFO - 2024-02-07 06:46:39 --> Security Class Initialized
DEBUG - 2024-02-07 06:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:46:39 --> Input Class Initialized
INFO - 2024-02-07 06:46:39 --> Language Class Initialized
INFO - 2024-02-07 06:46:39 --> Loader Class Initialized
INFO - 2024-02-07 06:46:39 --> Helper loaded: url_helper
INFO - 2024-02-07 06:46:39 --> Helper loaded: file_helper
INFO - 2024-02-07 06:46:39 --> Helper loaded: html_helper
INFO - 2024-02-07 06:46:39 --> Helper loaded: text_helper
INFO - 2024-02-07 06:46:39 --> Helper loaded: form_helper
INFO - 2024-02-07 06:46:39 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:46:39 --> Helper loaded: security_helper
INFO - 2024-02-07 06:46:39 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:46:39 --> Database Driver Class Initialized
INFO - 2024-02-07 06:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:46:39 --> Parser Class Initialized
INFO - 2024-02-07 06:46:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:46:39 --> Pagination Class Initialized
INFO - 2024-02-07 06:46:39 --> Form Validation Class Initialized
INFO - 2024-02-07 06:46:39 --> Controller Class Initialized
INFO - 2024-02-07 06:46:39 --> Model Class Initialized
DEBUG - 2024-02-07 06:46:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:46:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:46:39 --> Model Class Initialized
INFO - 2024-02-07 06:46:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2024-02-07 06:46:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:46:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:46:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:46:39 --> Model Class Initialized
INFO - 2024-02-07 06:46:39 --> Model Class Initialized
INFO - 2024-02-07 06:46:39 --> Model Class Initialized
INFO - 2024-02-07 06:46:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 06:46:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 06:46:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:46:39 --> Final output sent to browser
DEBUG - 2024-02-07 06:46:39 --> Total execution time: 0.1470
ERROR - 2024-02-07 06:46:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:46:39 --> Config Class Initialized
INFO - 2024-02-07 06:46:39 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:46:39 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:46:39 --> Utf8 Class Initialized
INFO - 2024-02-07 06:46:39 --> URI Class Initialized
INFO - 2024-02-07 06:46:39 --> Router Class Initialized
INFO - 2024-02-07 06:46:39 --> Output Class Initialized
INFO - 2024-02-07 06:46:39 --> Security Class Initialized
DEBUG - 2024-02-07 06:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:46:39 --> Input Class Initialized
INFO - 2024-02-07 06:46:39 --> Language Class Initialized
INFO - 2024-02-07 06:46:39 --> Loader Class Initialized
INFO - 2024-02-07 06:46:39 --> Helper loaded: url_helper
INFO - 2024-02-07 06:46:39 --> Helper loaded: file_helper
INFO - 2024-02-07 06:46:39 --> Helper loaded: html_helper
INFO - 2024-02-07 06:46:39 --> Helper loaded: text_helper
INFO - 2024-02-07 06:46:39 --> Helper loaded: form_helper
INFO - 2024-02-07 06:46:39 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:46:39 --> Helper loaded: security_helper
INFO - 2024-02-07 06:46:39 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:46:39 --> Database Driver Class Initialized
INFO - 2024-02-07 06:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:46:39 --> Parser Class Initialized
INFO - 2024-02-07 06:46:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:46:39 --> Pagination Class Initialized
INFO - 2024-02-07 06:46:39 --> Form Validation Class Initialized
INFO - 2024-02-07 06:46:39 --> Controller Class Initialized
INFO - 2024-02-07 06:46:39 --> Model Class Initialized
DEBUG - 2024-02-07 06:46:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:46:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:46:39 --> Model Class Initialized
INFO - 2024-02-07 06:46:39 --> Final output sent to browser
DEBUG - 2024-02-07 06:46:39 --> Total execution time: 0.0320
ERROR - 2024-02-07 06:46:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:46:43 --> Config Class Initialized
INFO - 2024-02-07 06:46:43 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:46:43 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:46:43 --> Utf8 Class Initialized
INFO - 2024-02-07 06:46:43 --> URI Class Initialized
INFO - 2024-02-07 06:46:43 --> Router Class Initialized
INFO - 2024-02-07 06:46:43 --> Output Class Initialized
INFO - 2024-02-07 06:46:43 --> Security Class Initialized
DEBUG - 2024-02-07 06:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:46:43 --> Input Class Initialized
INFO - 2024-02-07 06:46:43 --> Language Class Initialized
INFO - 2024-02-07 06:46:43 --> Loader Class Initialized
INFO - 2024-02-07 06:46:43 --> Helper loaded: url_helper
INFO - 2024-02-07 06:46:43 --> Helper loaded: file_helper
INFO - 2024-02-07 06:46:43 --> Helper loaded: html_helper
INFO - 2024-02-07 06:46:43 --> Helper loaded: text_helper
INFO - 2024-02-07 06:46:43 --> Helper loaded: form_helper
INFO - 2024-02-07 06:46:43 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:46:43 --> Helper loaded: security_helper
INFO - 2024-02-07 06:46:43 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:46:43 --> Database Driver Class Initialized
INFO - 2024-02-07 06:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:46:43 --> Parser Class Initialized
INFO - 2024-02-07 06:46:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:46:43 --> Pagination Class Initialized
INFO - 2024-02-07 06:46:43 --> Form Validation Class Initialized
INFO - 2024-02-07 06:46:43 --> Controller Class Initialized
INFO - 2024-02-07 06:46:43 --> Model Class Initialized
DEBUG - 2024-02-07 06:46:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:46:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:46:43 --> Model Class Initialized
INFO - 2024-02-07 06:46:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2024-02-07 06:46:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:46:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:46:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:46:43 --> Model Class Initialized
INFO - 2024-02-07 06:46:43 --> Model Class Initialized
INFO - 2024-02-07 06:46:43 --> Model Class Initialized
INFO - 2024-02-07 06:46:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 06:46:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 06:46:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:46:43 --> Final output sent to browser
DEBUG - 2024-02-07 06:46:43 --> Total execution time: 0.1340
ERROR - 2024-02-07 06:46:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:46:43 --> Config Class Initialized
INFO - 2024-02-07 06:46:43 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:46:43 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:46:43 --> Utf8 Class Initialized
INFO - 2024-02-07 06:46:43 --> URI Class Initialized
INFO - 2024-02-07 06:46:43 --> Router Class Initialized
INFO - 2024-02-07 06:46:43 --> Output Class Initialized
INFO - 2024-02-07 06:46:43 --> Security Class Initialized
DEBUG - 2024-02-07 06:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:46:43 --> Input Class Initialized
INFO - 2024-02-07 06:46:43 --> Language Class Initialized
INFO - 2024-02-07 06:46:43 --> Loader Class Initialized
INFO - 2024-02-07 06:46:43 --> Helper loaded: url_helper
INFO - 2024-02-07 06:46:43 --> Helper loaded: file_helper
INFO - 2024-02-07 06:46:43 --> Helper loaded: html_helper
INFO - 2024-02-07 06:46:43 --> Helper loaded: text_helper
INFO - 2024-02-07 06:46:43 --> Helper loaded: form_helper
INFO - 2024-02-07 06:46:43 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:46:43 --> Helper loaded: security_helper
INFO - 2024-02-07 06:46:43 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:46:43 --> Database Driver Class Initialized
INFO - 2024-02-07 06:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:46:43 --> Parser Class Initialized
INFO - 2024-02-07 06:46:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:46:43 --> Pagination Class Initialized
INFO - 2024-02-07 06:46:43 --> Form Validation Class Initialized
INFO - 2024-02-07 06:46:43 --> Controller Class Initialized
INFO - 2024-02-07 06:46:43 --> Model Class Initialized
DEBUG - 2024-02-07 06:46:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:46:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:46:43 --> Model Class Initialized
INFO - 2024-02-07 06:46:43 --> Final output sent to browser
DEBUG - 2024-02-07 06:46:43 --> Total execution time: 0.0526
ERROR - 2024-02-07 06:46:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:46:49 --> Config Class Initialized
INFO - 2024-02-07 06:46:49 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:46:49 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:46:49 --> Utf8 Class Initialized
INFO - 2024-02-07 06:46:49 --> URI Class Initialized
INFO - 2024-02-07 06:46:49 --> Router Class Initialized
INFO - 2024-02-07 06:46:49 --> Output Class Initialized
INFO - 2024-02-07 06:46:49 --> Security Class Initialized
DEBUG - 2024-02-07 06:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:46:49 --> Input Class Initialized
INFO - 2024-02-07 06:46:49 --> Language Class Initialized
INFO - 2024-02-07 06:46:49 --> Loader Class Initialized
INFO - 2024-02-07 06:46:49 --> Helper loaded: url_helper
INFO - 2024-02-07 06:46:49 --> Helper loaded: file_helper
INFO - 2024-02-07 06:46:49 --> Helper loaded: html_helper
INFO - 2024-02-07 06:46:49 --> Helper loaded: text_helper
INFO - 2024-02-07 06:46:49 --> Helper loaded: form_helper
INFO - 2024-02-07 06:46:49 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:46:49 --> Helper loaded: security_helper
INFO - 2024-02-07 06:46:49 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:46:49 --> Database Driver Class Initialized
INFO - 2024-02-07 06:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:46:49 --> Parser Class Initialized
INFO - 2024-02-07 06:46:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:46:49 --> Pagination Class Initialized
INFO - 2024-02-07 06:46:49 --> Form Validation Class Initialized
INFO - 2024-02-07 06:46:49 --> Controller Class Initialized
INFO - 2024-02-07 06:46:49 --> Model Class Initialized
DEBUG - 2024-02-07 06:46:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:46:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:46:49 --> Model Class Initialized
INFO - 2024-02-07 06:46:49 --> Final output sent to browser
DEBUG - 2024-02-07 06:46:49 --> Total execution time: 0.0533
ERROR - 2024-02-07 06:47:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:47:31 --> Config Class Initialized
INFO - 2024-02-07 06:47:31 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:47:31 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:47:31 --> Utf8 Class Initialized
INFO - 2024-02-07 06:47:31 --> URI Class Initialized
INFO - 2024-02-07 06:47:31 --> Router Class Initialized
INFO - 2024-02-07 06:47:31 --> Output Class Initialized
INFO - 2024-02-07 06:47:31 --> Security Class Initialized
DEBUG - 2024-02-07 06:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:47:31 --> Input Class Initialized
INFO - 2024-02-07 06:47:31 --> Language Class Initialized
INFO - 2024-02-07 06:47:31 --> Loader Class Initialized
INFO - 2024-02-07 06:47:31 --> Helper loaded: url_helper
INFO - 2024-02-07 06:47:31 --> Helper loaded: file_helper
INFO - 2024-02-07 06:47:31 --> Helper loaded: html_helper
INFO - 2024-02-07 06:47:31 --> Helper loaded: text_helper
INFO - 2024-02-07 06:47:31 --> Helper loaded: form_helper
INFO - 2024-02-07 06:47:31 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:47:31 --> Helper loaded: security_helper
INFO - 2024-02-07 06:47:31 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:47:31 --> Database Driver Class Initialized
INFO - 2024-02-07 06:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:47:31 --> Parser Class Initialized
INFO - 2024-02-07 06:47:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:47:31 --> Pagination Class Initialized
INFO - 2024-02-07 06:47:31 --> Form Validation Class Initialized
INFO - 2024-02-07 06:47:31 --> Controller Class Initialized
INFO - 2024-02-07 06:47:31 --> Model Class Initialized
DEBUG - 2024-02-07 06:47:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:47:31 --> Final output sent to browser
DEBUG - 2024-02-07 06:47:31 --> Total execution time: 0.0144
ERROR - 2024-02-07 06:47:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:47:31 --> Config Class Initialized
INFO - 2024-02-07 06:47:31 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:47:31 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:47:31 --> Utf8 Class Initialized
INFO - 2024-02-07 06:47:31 --> URI Class Initialized
INFO - 2024-02-07 06:47:31 --> Router Class Initialized
INFO - 2024-02-07 06:47:31 --> Output Class Initialized
INFO - 2024-02-07 06:47:31 --> Security Class Initialized
DEBUG - 2024-02-07 06:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:47:31 --> Input Class Initialized
INFO - 2024-02-07 06:47:31 --> Language Class Initialized
INFO - 2024-02-07 06:47:31 --> Loader Class Initialized
INFO - 2024-02-07 06:47:31 --> Helper loaded: url_helper
INFO - 2024-02-07 06:47:31 --> Helper loaded: file_helper
INFO - 2024-02-07 06:47:31 --> Helper loaded: html_helper
INFO - 2024-02-07 06:47:31 --> Helper loaded: text_helper
INFO - 2024-02-07 06:47:31 --> Helper loaded: form_helper
INFO - 2024-02-07 06:47:31 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:47:31 --> Helper loaded: security_helper
INFO - 2024-02-07 06:47:31 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:47:31 --> Database Driver Class Initialized
INFO - 2024-02-07 06:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:47:31 --> Parser Class Initialized
INFO - 2024-02-07 06:47:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:47:31 --> Pagination Class Initialized
INFO - 2024-02-07 06:47:31 --> Form Validation Class Initialized
INFO - 2024-02-07 06:47:31 --> Controller Class Initialized
INFO - 2024-02-07 06:47:31 --> Model Class Initialized
DEBUG - 2024-02-07 06:47:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:47:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-07 06:47:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:47:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:47:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:47:31 --> Model Class Initialized
INFO - 2024-02-07 06:47:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:47:31 --> Final output sent to browser
DEBUG - 2024-02-07 06:47:31 --> Total execution time: 0.0316
ERROR - 2024-02-07 06:47:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:47:42 --> Config Class Initialized
INFO - 2024-02-07 06:47:42 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:47:42 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:47:42 --> Utf8 Class Initialized
INFO - 2024-02-07 06:47:42 --> URI Class Initialized
INFO - 2024-02-07 06:47:42 --> Router Class Initialized
INFO - 2024-02-07 06:47:42 --> Output Class Initialized
INFO - 2024-02-07 06:47:42 --> Security Class Initialized
DEBUG - 2024-02-07 06:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:47:42 --> Input Class Initialized
INFO - 2024-02-07 06:47:42 --> Language Class Initialized
INFO - 2024-02-07 06:47:42 --> Loader Class Initialized
INFO - 2024-02-07 06:47:42 --> Helper loaded: url_helper
INFO - 2024-02-07 06:47:42 --> Helper loaded: file_helper
INFO - 2024-02-07 06:47:42 --> Helper loaded: html_helper
INFO - 2024-02-07 06:47:42 --> Helper loaded: text_helper
INFO - 2024-02-07 06:47:42 --> Helper loaded: form_helper
INFO - 2024-02-07 06:47:42 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:47:42 --> Helper loaded: security_helper
INFO - 2024-02-07 06:47:42 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:47:42 --> Database Driver Class Initialized
INFO - 2024-02-07 06:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:47:42 --> Parser Class Initialized
INFO - 2024-02-07 06:47:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:47:42 --> Pagination Class Initialized
INFO - 2024-02-07 06:47:42 --> Form Validation Class Initialized
INFO - 2024-02-07 06:47:42 --> Controller Class Initialized
INFO - 2024-02-07 06:47:42 --> Model Class Initialized
DEBUG - 2024-02-07 06:47:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:47:42 --> Model Class Initialized
INFO - 2024-02-07 06:47:42 --> Final output sent to browser
DEBUG - 2024-02-07 06:47:42 --> Total execution time: 0.0165
ERROR - 2024-02-07 06:47:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:47:42 --> Config Class Initialized
INFO - 2024-02-07 06:47:42 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:47:42 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:47:42 --> Utf8 Class Initialized
INFO - 2024-02-07 06:47:42 --> URI Class Initialized
DEBUG - 2024-02-07 06:47:42 --> No URI present. Default controller set.
INFO - 2024-02-07 06:47:42 --> Router Class Initialized
INFO - 2024-02-07 06:47:42 --> Output Class Initialized
INFO - 2024-02-07 06:47:42 --> Security Class Initialized
DEBUG - 2024-02-07 06:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:47:42 --> Input Class Initialized
INFO - 2024-02-07 06:47:42 --> Language Class Initialized
INFO - 2024-02-07 06:47:42 --> Loader Class Initialized
INFO - 2024-02-07 06:47:42 --> Helper loaded: url_helper
INFO - 2024-02-07 06:47:42 --> Helper loaded: file_helper
INFO - 2024-02-07 06:47:42 --> Helper loaded: html_helper
INFO - 2024-02-07 06:47:42 --> Helper loaded: text_helper
INFO - 2024-02-07 06:47:42 --> Helper loaded: form_helper
INFO - 2024-02-07 06:47:42 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:47:42 --> Helper loaded: security_helper
INFO - 2024-02-07 06:47:42 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:47:42 --> Database Driver Class Initialized
INFO - 2024-02-07 06:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:47:42 --> Parser Class Initialized
INFO - 2024-02-07 06:47:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:47:42 --> Pagination Class Initialized
INFO - 2024-02-07 06:47:42 --> Form Validation Class Initialized
INFO - 2024-02-07 06:47:42 --> Controller Class Initialized
INFO - 2024-02-07 06:47:42 --> Model Class Initialized
DEBUG - 2024-02-07 06:47:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:47:42 --> Model Class Initialized
DEBUG - 2024-02-07 06:47:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:47:42 --> Model Class Initialized
INFO - 2024-02-07 06:47:42 --> Model Class Initialized
INFO - 2024-02-07 06:47:42 --> Model Class Initialized
INFO - 2024-02-07 06:47:42 --> Model Class Initialized
DEBUG - 2024-02-07 06:47:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:47:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:47:42 --> Model Class Initialized
INFO - 2024-02-07 06:47:42 --> Model Class Initialized
INFO - 2024-02-07 06:47:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-07 06:47:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:47:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:47:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:47:42 --> Model Class Initialized
INFO - 2024-02-07 06:47:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 06:47:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 06:47:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:47:43 --> Final output sent to browser
DEBUG - 2024-02-07 06:47:43 --> Total execution time: 0.3890
ERROR - 2024-02-07 06:47:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:47:43 --> Config Class Initialized
INFO - 2024-02-07 06:47:43 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:47:43 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:47:43 --> Utf8 Class Initialized
INFO - 2024-02-07 06:47:43 --> URI Class Initialized
INFO - 2024-02-07 06:47:43 --> Router Class Initialized
INFO - 2024-02-07 06:47:43 --> Output Class Initialized
INFO - 2024-02-07 06:47:43 --> Security Class Initialized
DEBUG - 2024-02-07 06:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:47:43 --> Input Class Initialized
INFO - 2024-02-07 06:47:43 --> Language Class Initialized
INFO - 2024-02-07 06:47:43 --> Loader Class Initialized
INFO - 2024-02-07 06:47:43 --> Helper loaded: url_helper
INFO - 2024-02-07 06:47:43 --> Helper loaded: file_helper
INFO - 2024-02-07 06:47:43 --> Helper loaded: html_helper
INFO - 2024-02-07 06:47:43 --> Helper loaded: text_helper
INFO - 2024-02-07 06:47:43 --> Helper loaded: form_helper
INFO - 2024-02-07 06:47:43 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:47:43 --> Helper loaded: security_helper
INFO - 2024-02-07 06:47:43 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:47:43 --> Database Driver Class Initialized
INFO - 2024-02-07 06:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:47:43 --> Parser Class Initialized
INFO - 2024-02-07 06:47:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:47:43 --> Pagination Class Initialized
INFO - 2024-02-07 06:47:43 --> Form Validation Class Initialized
INFO - 2024-02-07 06:47:43 --> Controller Class Initialized
DEBUG - 2024-02-07 06:47:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 06:47:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:47:43 --> Model Class Initialized
INFO - 2024-02-07 06:47:43 --> Final output sent to browser
DEBUG - 2024-02-07 06:47:43 --> Total execution time: 0.0160
ERROR - 2024-02-07 06:47:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:47:59 --> Config Class Initialized
INFO - 2024-02-07 06:47:59 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:47:59 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:47:59 --> Utf8 Class Initialized
INFO - 2024-02-07 06:47:59 --> URI Class Initialized
INFO - 2024-02-07 06:47:59 --> Router Class Initialized
INFO - 2024-02-07 06:47:59 --> Output Class Initialized
INFO - 2024-02-07 06:47:59 --> Security Class Initialized
DEBUG - 2024-02-07 06:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:47:59 --> Input Class Initialized
INFO - 2024-02-07 06:47:59 --> Language Class Initialized
INFO - 2024-02-07 06:47:59 --> Loader Class Initialized
INFO - 2024-02-07 06:47:59 --> Helper loaded: url_helper
INFO - 2024-02-07 06:47:59 --> Helper loaded: file_helper
INFO - 2024-02-07 06:47:59 --> Helper loaded: html_helper
INFO - 2024-02-07 06:47:59 --> Helper loaded: text_helper
INFO - 2024-02-07 06:47:59 --> Helper loaded: form_helper
INFO - 2024-02-07 06:47:59 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:47:59 --> Helper loaded: security_helper
INFO - 2024-02-07 06:47:59 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:47:59 --> Database Driver Class Initialized
INFO - 2024-02-07 06:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:47:59 --> Parser Class Initialized
INFO - 2024-02-07 06:47:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:47:59 --> Pagination Class Initialized
INFO - 2024-02-07 06:47:59 --> Form Validation Class Initialized
INFO - 2024-02-07 06:47:59 --> Controller Class Initialized
INFO - 2024-02-07 06:47:59 --> Model Class Initialized
INFO - 2024-02-07 06:47:59 --> Model Class Initialized
INFO - 2024-02-07 06:47:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase.php
DEBUG - 2024-02-07 06:47:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:47:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:47:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:47:59 --> Model Class Initialized
INFO - 2024-02-07 06:47:59 --> Model Class Initialized
INFO - 2024-02-07 06:47:59 --> Model Class Initialized
INFO - 2024-02-07 06:47:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 06:47:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 06:47:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:47:59 --> Final output sent to browser
DEBUG - 2024-02-07 06:47:59 --> Total execution time: 0.2189
ERROR - 2024-02-07 06:47:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:47:59 --> Config Class Initialized
INFO - 2024-02-07 06:47:59 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:47:59 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:47:59 --> Utf8 Class Initialized
INFO - 2024-02-07 06:47:59 --> URI Class Initialized
INFO - 2024-02-07 06:47:59 --> Router Class Initialized
INFO - 2024-02-07 06:47:59 --> Output Class Initialized
INFO - 2024-02-07 06:47:59 --> Security Class Initialized
DEBUG - 2024-02-07 06:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:47:59 --> Input Class Initialized
INFO - 2024-02-07 06:47:59 --> Language Class Initialized
INFO - 2024-02-07 06:47:59 --> Loader Class Initialized
INFO - 2024-02-07 06:47:59 --> Helper loaded: url_helper
INFO - 2024-02-07 06:47:59 --> Helper loaded: file_helper
INFO - 2024-02-07 06:47:59 --> Helper loaded: html_helper
INFO - 2024-02-07 06:47:59 --> Helper loaded: text_helper
INFO - 2024-02-07 06:47:59 --> Helper loaded: form_helper
INFO - 2024-02-07 06:47:59 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:47:59 --> Helper loaded: security_helper
INFO - 2024-02-07 06:47:59 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:47:59 --> Database Driver Class Initialized
INFO - 2024-02-07 06:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:47:59 --> Parser Class Initialized
INFO - 2024-02-07 06:47:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:47:59 --> Pagination Class Initialized
INFO - 2024-02-07 06:47:59 --> Form Validation Class Initialized
INFO - 2024-02-07 06:47:59 --> Controller Class Initialized
INFO - 2024-02-07 06:47:59 --> Model Class Initialized
INFO - 2024-02-07 06:47:59 --> Model Class Initialized
INFO - 2024-02-07 06:47:59 --> Final output sent to browser
DEBUG - 2024-02-07 06:47:59 --> Total execution time: 0.0450
ERROR - 2024-02-07 06:49:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:49:07 --> Config Class Initialized
INFO - 2024-02-07 06:49:07 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:49:07 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:49:07 --> Utf8 Class Initialized
INFO - 2024-02-07 06:49:07 --> URI Class Initialized
INFO - 2024-02-07 06:49:07 --> Router Class Initialized
INFO - 2024-02-07 06:49:07 --> Output Class Initialized
INFO - 2024-02-07 06:49:07 --> Security Class Initialized
DEBUG - 2024-02-07 06:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:49:07 --> Input Class Initialized
INFO - 2024-02-07 06:49:07 --> Language Class Initialized
INFO - 2024-02-07 06:49:07 --> Loader Class Initialized
INFO - 2024-02-07 06:49:07 --> Helper loaded: url_helper
INFO - 2024-02-07 06:49:07 --> Helper loaded: file_helper
INFO - 2024-02-07 06:49:07 --> Helper loaded: html_helper
INFO - 2024-02-07 06:49:07 --> Helper loaded: text_helper
INFO - 2024-02-07 06:49:07 --> Helper loaded: form_helper
INFO - 2024-02-07 06:49:07 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:49:07 --> Helper loaded: security_helper
INFO - 2024-02-07 06:49:07 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:49:07 --> Database Driver Class Initialized
INFO - 2024-02-07 06:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:49:07 --> Parser Class Initialized
INFO - 2024-02-07 06:49:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:49:07 --> Pagination Class Initialized
INFO - 2024-02-07 06:49:07 --> Form Validation Class Initialized
INFO - 2024-02-07 06:49:07 --> Controller Class Initialized
INFO - 2024-02-07 06:49:07 --> Model Class Initialized
INFO - 2024-02-07 06:49:07 --> Model Class Initialized
INFO - 2024-02-07 06:49:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report.php
DEBUG - 2024-02-07 06:49:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 06:49:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 06:49:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 06:49:07 --> Model Class Initialized
INFO - 2024-02-07 06:49:07 --> Model Class Initialized
INFO - 2024-02-07 06:49:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 06:49:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 06:49:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 06:49:07 --> Final output sent to browser
DEBUG - 2024-02-07 06:49:07 --> Total execution time: 0.2338
ERROR - 2024-02-07 06:49:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:49:07 --> Config Class Initialized
INFO - 2024-02-07 06:49:07 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:49:07 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:49:07 --> Utf8 Class Initialized
INFO - 2024-02-07 06:49:07 --> URI Class Initialized
INFO - 2024-02-07 06:49:07 --> Router Class Initialized
INFO - 2024-02-07 06:49:07 --> Output Class Initialized
INFO - 2024-02-07 06:49:07 --> Security Class Initialized
DEBUG - 2024-02-07 06:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:49:07 --> Input Class Initialized
INFO - 2024-02-07 06:49:07 --> Language Class Initialized
INFO - 2024-02-07 06:49:07 --> Loader Class Initialized
INFO - 2024-02-07 06:49:07 --> Helper loaded: url_helper
INFO - 2024-02-07 06:49:07 --> Helper loaded: file_helper
INFO - 2024-02-07 06:49:07 --> Helper loaded: html_helper
INFO - 2024-02-07 06:49:07 --> Helper loaded: text_helper
INFO - 2024-02-07 06:49:07 --> Helper loaded: form_helper
INFO - 2024-02-07 06:49:07 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:49:07 --> Helper loaded: security_helper
INFO - 2024-02-07 06:49:07 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:49:07 --> Database Driver Class Initialized
INFO - 2024-02-07 06:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:49:07 --> Parser Class Initialized
INFO - 2024-02-07 06:49:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:49:07 --> Pagination Class Initialized
INFO - 2024-02-07 06:49:07 --> Form Validation Class Initialized
INFO - 2024-02-07 06:49:07 --> Controller Class Initialized
INFO - 2024-02-07 06:49:07 --> Model Class Initialized
INFO - 2024-02-07 06:49:07 --> Model Class Initialized
INFO - 2024-02-07 06:49:07 --> Final output sent to browser
DEBUG - 2024-02-07 06:49:07 --> Total execution time: 0.0265
ERROR - 2024-02-07 06:49:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 06:49:18 --> Config Class Initialized
INFO - 2024-02-07 06:49:18 --> Hooks Class Initialized
DEBUG - 2024-02-07 06:49:18 --> UTF-8 Support Enabled
INFO - 2024-02-07 06:49:18 --> Utf8 Class Initialized
INFO - 2024-02-07 06:49:18 --> URI Class Initialized
INFO - 2024-02-07 06:49:18 --> Router Class Initialized
INFO - 2024-02-07 06:49:18 --> Output Class Initialized
INFO - 2024-02-07 06:49:18 --> Security Class Initialized
DEBUG - 2024-02-07 06:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 06:49:18 --> Input Class Initialized
INFO - 2024-02-07 06:49:18 --> Language Class Initialized
INFO - 2024-02-07 06:49:18 --> Loader Class Initialized
INFO - 2024-02-07 06:49:18 --> Helper loaded: url_helper
INFO - 2024-02-07 06:49:18 --> Helper loaded: file_helper
INFO - 2024-02-07 06:49:18 --> Helper loaded: html_helper
INFO - 2024-02-07 06:49:18 --> Helper loaded: text_helper
INFO - 2024-02-07 06:49:18 --> Helper loaded: form_helper
INFO - 2024-02-07 06:49:18 --> Helper loaded: lang_helper
INFO - 2024-02-07 06:49:18 --> Helper loaded: security_helper
INFO - 2024-02-07 06:49:18 --> Helper loaded: cookie_helper
INFO - 2024-02-07 06:49:18 --> Database Driver Class Initialized
INFO - 2024-02-07 06:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 06:49:18 --> Parser Class Initialized
INFO - 2024-02-07 06:49:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 06:49:18 --> Pagination Class Initialized
INFO - 2024-02-07 06:49:18 --> Form Validation Class Initialized
INFO - 2024-02-07 06:49:18 --> Controller Class Initialized
INFO - 2024-02-07 06:49:18 --> Model Class Initialized
INFO - 2024-02-07 06:49:18 --> Model Class Initialized
INFO - 2024-02-07 06:49:18 --> Final output sent to browser
DEBUG - 2024-02-07 06:49:18 --> Total execution time: 0.0518
ERROR - 2024-02-07 07:19:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 07:19:21 --> Config Class Initialized
INFO - 2024-02-07 07:19:21 --> Hooks Class Initialized
DEBUG - 2024-02-07 07:19:21 --> UTF-8 Support Enabled
INFO - 2024-02-07 07:19:21 --> Utf8 Class Initialized
INFO - 2024-02-07 07:19:21 --> URI Class Initialized
DEBUG - 2024-02-07 07:19:21 --> No URI present. Default controller set.
INFO - 2024-02-07 07:19:21 --> Router Class Initialized
INFO - 2024-02-07 07:19:21 --> Output Class Initialized
INFO - 2024-02-07 07:19:21 --> Security Class Initialized
DEBUG - 2024-02-07 07:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 07:19:21 --> Input Class Initialized
INFO - 2024-02-07 07:19:21 --> Language Class Initialized
INFO - 2024-02-07 07:19:21 --> Loader Class Initialized
INFO - 2024-02-07 07:19:21 --> Helper loaded: url_helper
INFO - 2024-02-07 07:19:21 --> Helper loaded: file_helper
INFO - 2024-02-07 07:19:21 --> Helper loaded: html_helper
INFO - 2024-02-07 07:19:21 --> Helper loaded: text_helper
INFO - 2024-02-07 07:19:21 --> Helper loaded: form_helper
INFO - 2024-02-07 07:19:21 --> Helper loaded: lang_helper
INFO - 2024-02-07 07:19:21 --> Helper loaded: security_helper
INFO - 2024-02-07 07:19:21 --> Helper loaded: cookie_helper
INFO - 2024-02-07 07:19:21 --> Database Driver Class Initialized
INFO - 2024-02-07 07:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 07:19:21 --> Parser Class Initialized
INFO - 2024-02-07 07:19:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 07:19:21 --> Pagination Class Initialized
INFO - 2024-02-07 07:19:21 --> Form Validation Class Initialized
INFO - 2024-02-07 07:19:21 --> Controller Class Initialized
INFO - 2024-02-07 07:19:21 --> Model Class Initialized
DEBUG - 2024-02-07 07:19:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-07 07:19:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 07:19:22 --> Config Class Initialized
INFO - 2024-02-07 07:19:22 --> Hooks Class Initialized
DEBUG - 2024-02-07 07:19:22 --> UTF-8 Support Enabled
INFO - 2024-02-07 07:19:22 --> Utf8 Class Initialized
INFO - 2024-02-07 07:19:22 --> URI Class Initialized
INFO - 2024-02-07 07:19:22 --> Router Class Initialized
INFO - 2024-02-07 07:19:22 --> Output Class Initialized
INFO - 2024-02-07 07:19:22 --> Security Class Initialized
DEBUG - 2024-02-07 07:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 07:19:22 --> Input Class Initialized
INFO - 2024-02-07 07:19:22 --> Language Class Initialized
INFO - 2024-02-07 07:19:22 --> Loader Class Initialized
INFO - 2024-02-07 07:19:22 --> Helper loaded: url_helper
INFO - 2024-02-07 07:19:22 --> Helper loaded: file_helper
INFO - 2024-02-07 07:19:22 --> Helper loaded: html_helper
INFO - 2024-02-07 07:19:22 --> Helper loaded: text_helper
INFO - 2024-02-07 07:19:22 --> Helper loaded: form_helper
INFO - 2024-02-07 07:19:22 --> Helper loaded: lang_helper
INFO - 2024-02-07 07:19:22 --> Helper loaded: security_helper
INFO - 2024-02-07 07:19:22 --> Helper loaded: cookie_helper
INFO - 2024-02-07 07:19:22 --> Database Driver Class Initialized
INFO - 2024-02-07 07:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 07:19:22 --> Parser Class Initialized
INFO - 2024-02-07 07:19:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 07:19:22 --> Pagination Class Initialized
INFO - 2024-02-07 07:19:22 --> Form Validation Class Initialized
INFO - 2024-02-07 07:19:22 --> Controller Class Initialized
INFO - 2024-02-07 07:19:22 --> Model Class Initialized
DEBUG - 2024-02-07 07:19:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 07:19:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-07 07:19:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 07:19:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 07:19:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 07:19:22 --> Model Class Initialized
INFO - 2024-02-07 07:19:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 07:19:22 --> Final output sent to browser
DEBUG - 2024-02-07 07:19:22 --> Total execution time: 0.0305
ERROR - 2024-02-07 08:38:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 08:38:40 --> Config Class Initialized
INFO - 2024-02-07 08:38:40 --> Hooks Class Initialized
DEBUG - 2024-02-07 08:38:40 --> UTF-8 Support Enabled
INFO - 2024-02-07 08:38:40 --> Utf8 Class Initialized
INFO - 2024-02-07 08:38:40 --> URI Class Initialized
DEBUG - 2024-02-07 08:38:40 --> No URI present. Default controller set.
INFO - 2024-02-07 08:38:40 --> Router Class Initialized
INFO - 2024-02-07 08:38:40 --> Output Class Initialized
INFO - 2024-02-07 08:38:40 --> Security Class Initialized
DEBUG - 2024-02-07 08:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 08:38:40 --> Input Class Initialized
INFO - 2024-02-07 08:38:40 --> Language Class Initialized
INFO - 2024-02-07 08:38:40 --> Loader Class Initialized
INFO - 2024-02-07 08:38:40 --> Helper loaded: url_helper
INFO - 2024-02-07 08:38:40 --> Helper loaded: file_helper
INFO - 2024-02-07 08:38:40 --> Helper loaded: html_helper
INFO - 2024-02-07 08:38:40 --> Helper loaded: text_helper
INFO - 2024-02-07 08:38:40 --> Helper loaded: form_helper
INFO - 2024-02-07 08:38:40 --> Helper loaded: lang_helper
INFO - 2024-02-07 08:38:40 --> Helper loaded: security_helper
INFO - 2024-02-07 08:38:40 --> Helper loaded: cookie_helper
INFO - 2024-02-07 08:38:40 --> Database Driver Class Initialized
INFO - 2024-02-07 08:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 08:38:40 --> Parser Class Initialized
INFO - 2024-02-07 08:38:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 08:38:40 --> Pagination Class Initialized
INFO - 2024-02-07 08:38:40 --> Form Validation Class Initialized
INFO - 2024-02-07 08:38:40 --> Controller Class Initialized
INFO - 2024-02-07 08:38:40 --> Model Class Initialized
DEBUG - 2024-02-07 08:38:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-07 08:38:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 08:38:40 --> Config Class Initialized
INFO - 2024-02-07 08:38:40 --> Hooks Class Initialized
DEBUG - 2024-02-07 08:38:40 --> UTF-8 Support Enabled
INFO - 2024-02-07 08:38:40 --> Utf8 Class Initialized
INFO - 2024-02-07 08:38:40 --> URI Class Initialized
INFO - 2024-02-07 08:38:40 --> Router Class Initialized
INFO - 2024-02-07 08:38:40 --> Output Class Initialized
INFO - 2024-02-07 08:38:40 --> Security Class Initialized
DEBUG - 2024-02-07 08:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 08:38:40 --> Input Class Initialized
INFO - 2024-02-07 08:38:40 --> Language Class Initialized
INFO - 2024-02-07 08:38:40 --> Loader Class Initialized
INFO - 2024-02-07 08:38:40 --> Helper loaded: url_helper
INFO - 2024-02-07 08:38:40 --> Helper loaded: file_helper
INFO - 2024-02-07 08:38:40 --> Helper loaded: html_helper
INFO - 2024-02-07 08:38:40 --> Helper loaded: text_helper
INFO - 2024-02-07 08:38:40 --> Helper loaded: form_helper
INFO - 2024-02-07 08:38:40 --> Helper loaded: lang_helper
INFO - 2024-02-07 08:38:40 --> Helper loaded: security_helper
INFO - 2024-02-07 08:38:40 --> Helper loaded: cookie_helper
INFO - 2024-02-07 08:38:40 --> Database Driver Class Initialized
INFO - 2024-02-07 08:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 08:38:40 --> Parser Class Initialized
INFO - 2024-02-07 08:38:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 08:38:40 --> Pagination Class Initialized
INFO - 2024-02-07 08:38:40 --> Form Validation Class Initialized
INFO - 2024-02-07 08:38:40 --> Controller Class Initialized
INFO - 2024-02-07 08:38:40 --> Model Class Initialized
DEBUG - 2024-02-07 08:38:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:38:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-07 08:38:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:38:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 08:38:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 08:38:40 --> Model Class Initialized
INFO - 2024-02-07 08:38:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 08:38:40 --> Final output sent to browser
DEBUG - 2024-02-07 08:38:40 --> Total execution time: 0.0322
ERROR - 2024-02-07 08:39:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 08:39:06 --> Config Class Initialized
INFO - 2024-02-07 08:39:06 --> Hooks Class Initialized
DEBUG - 2024-02-07 08:39:06 --> UTF-8 Support Enabled
INFO - 2024-02-07 08:39:06 --> Utf8 Class Initialized
INFO - 2024-02-07 08:39:06 --> URI Class Initialized
INFO - 2024-02-07 08:39:06 --> Router Class Initialized
INFO - 2024-02-07 08:39:06 --> Output Class Initialized
INFO - 2024-02-07 08:39:06 --> Security Class Initialized
DEBUG - 2024-02-07 08:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 08:39:06 --> Input Class Initialized
INFO - 2024-02-07 08:39:06 --> Language Class Initialized
INFO - 2024-02-07 08:39:06 --> Loader Class Initialized
INFO - 2024-02-07 08:39:06 --> Helper loaded: url_helper
INFO - 2024-02-07 08:39:06 --> Helper loaded: file_helper
INFO - 2024-02-07 08:39:06 --> Helper loaded: html_helper
INFO - 2024-02-07 08:39:06 --> Helper loaded: text_helper
INFO - 2024-02-07 08:39:06 --> Helper loaded: form_helper
INFO - 2024-02-07 08:39:06 --> Helper loaded: lang_helper
INFO - 2024-02-07 08:39:06 --> Helper loaded: security_helper
INFO - 2024-02-07 08:39:06 --> Helper loaded: cookie_helper
INFO - 2024-02-07 08:39:06 --> Database Driver Class Initialized
INFO - 2024-02-07 08:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 08:39:06 --> Parser Class Initialized
INFO - 2024-02-07 08:39:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 08:39:06 --> Pagination Class Initialized
INFO - 2024-02-07 08:39:06 --> Form Validation Class Initialized
INFO - 2024-02-07 08:39:06 --> Controller Class Initialized
INFO - 2024-02-07 08:39:06 --> Model Class Initialized
DEBUG - 2024-02-07 08:39:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:39:06 --> Model Class Initialized
INFO - 2024-02-07 08:39:06 --> Final output sent to browser
DEBUG - 2024-02-07 08:39:06 --> Total execution time: 0.0210
ERROR - 2024-02-07 08:39:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 08:39:06 --> Config Class Initialized
INFO - 2024-02-07 08:39:06 --> Hooks Class Initialized
DEBUG - 2024-02-07 08:39:06 --> UTF-8 Support Enabled
INFO - 2024-02-07 08:39:06 --> Utf8 Class Initialized
INFO - 2024-02-07 08:39:06 --> URI Class Initialized
DEBUG - 2024-02-07 08:39:06 --> No URI present. Default controller set.
INFO - 2024-02-07 08:39:06 --> Router Class Initialized
INFO - 2024-02-07 08:39:06 --> Output Class Initialized
INFO - 2024-02-07 08:39:06 --> Security Class Initialized
DEBUG - 2024-02-07 08:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 08:39:06 --> Input Class Initialized
INFO - 2024-02-07 08:39:06 --> Language Class Initialized
INFO - 2024-02-07 08:39:06 --> Loader Class Initialized
INFO - 2024-02-07 08:39:06 --> Helper loaded: url_helper
INFO - 2024-02-07 08:39:06 --> Helper loaded: file_helper
INFO - 2024-02-07 08:39:06 --> Helper loaded: html_helper
INFO - 2024-02-07 08:39:06 --> Helper loaded: text_helper
INFO - 2024-02-07 08:39:06 --> Helper loaded: form_helper
INFO - 2024-02-07 08:39:06 --> Helper loaded: lang_helper
INFO - 2024-02-07 08:39:06 --> Helper loaded: security_helper
INFO - 2024-02-07 08:39:06 --> Helper loaded: cookie_helper
INFO - 2024-02-07 08:39:06 --> Database Driver Class Initialized
INFO - 2024-02-07 08:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 08:39:06 --> Parser Class Initialized
INFO - 2024-02-07 08:39:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 08:39:06 --> Pagination Class Initialized
INFO - 2024-02-07 08:39:06 --> Form Validation Class Initialized
INFO - 2024-02-07 08:39:06 --> Controller Class Initialized
INFO - 2024-02-07 08:39:06 --> Model Class Initialized
DEBUG - 2024-02-07 08:39:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:39:06 --> Model Class Initialized
DEBUG - 2024-02-07 08:39:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:39:06 --> Model Class Initialized
INFO - 2024-02-07 08:39:06 --> Model Class Initialized
INFO - 2024-02-07 08:39:06 --> Model Class Initialized
INFO - 2024-02-07 08:39:06 --> Model Class Initialized
DEBUG - 2024-02-07 08:39:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 08:39:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:39:06 --> Model Class Initialized
INFO - 2024-02-07 08:39:06 --> Model Class Initialized
INFO - 2024-02-07 08:39:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-07 08:39:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:39:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 08:39:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 08:39:06 --> Model Class Initialized
INFO - 2024-02-07 08:39:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 08:39:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 08:39:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 08:39:06 --> Final output sent to browser
DEBUG - 2024-02-07 08:39:06 --> Total execution time: 0.2337
ERROR - 2024-02-07 08:39:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 08:39:40 --> Config Class Initialized
INFO - 2024-02-07 08:39:40 --> Hooks Class Initialized
DEBUG - 2024-02-07 08:39:40 --> UTF-8 Support Enabled
INFO - 2024-02-07 08:39:40 --> Utf8 Class Initialized
INFO - 2024-02-07 08:39:40 --> URI Class Initialized
INFO - 2024-02-07 08:39:40 --> Router Class Initialized
INFO - 2024-02-07 08:39:40 --> Output Class Initialized
INFO - 2024-02-07 08:39:40 --> Security Class Initialized
DEBUG - 2024-02-07 08:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 08:39:40 --> Input Class Initialized
INFO - 2024-02-07 08:39:40 --> Language Class Initialized
INFO - 2024-02-07 08:39:40 --> Loader Class Initialized
INFO - 2024-02-07 08:39:40 --> Helper loaded: url_helper
INFO - 2024-02-07 08:39:40 --> Helper loaded: file_helper
INFO - 2024-02-07 08:39:40 --> Helper loaded: html_helper
INFO - 2024-02-07 08:39:40 --> Helper loaded: text_helper
INFO - 2024-02-07 08:39:40 --> Helper loaded: form_helper
INFO - 2024-02-07 08:39:40 --> Helper loaded: lang_helper
INFO - 2024-02-07 08:39:40 --> Helper loaded: security_helper
INFO - 2024-02-07 08:39:40 --> Helper loaded: cookie_helper
INFO - 2024-02-07 08:39:40 --> Database Driver Class Initialized
INFO - 2024-02-07 08:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 08:39:40 --> Parser Class Initialized
INFO - 2024-02-07 08:39:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 08:39:40 --> Pagination Class Initialized
INFO - 2024-02-07 08:39:40 --> Form Validation Class Initialized
INFO - 2024-02-07 08:39:40 --> Controller Class Initialized
INFO - 2024-02-07 08:39:40 --> Model Class Initialized
DEBUG - 2024-02-07 08:39:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:39:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-07 08:39:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:39:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 08:39:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 08:39:40 --> Model Class Initialized
INFO - 2024-02-07 08:39:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 08:39:40 --> Final output sent to browser
DEBUG - 2024-02-07 08:39:40 --> Total execution time: 0.0322
ERROR - 2024-02-07 08:39:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 08:39:40 --> Config Class Initialized
INFO - 2024-02-07 08:39:40 --> Hooks Class Initialized
DEBUG - 2024-02-07 08:39:40 --> UTF-8 Support Enabled
INFO - 2024-02-07 08:39:40 --> Utf8 Class Initialized
INFO - 2024-02-07 08:39:40 --> URI Class Initialized
INFO - 2024-02-07 08:39:40 --> Router Class Initialized
INFO - 2024-02-07 08:39:40 --> Output Class Initialized
INFO - 2024-02-07 08:39:40 --> Security Class Initialized
DEBUG - 2024-02-07 08:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 08:39:40 --> Input Class Initialized
INFO - 2024-02-07 08:39:40 --> Language Class Initialized
INFO - 2024-02-07 08:39:40 --> Loader Class Initialized
INFO - 2024-02-07 08:39:40 --> Helper loaded: url_helper
INFO - 2024-02-07 08:39:40 --> Helper loaded: file_helper
INFO - 2024-02-07 08:39:40 --> Helper loaded: html_helper
INFO - 2024-02-07 08:39:40 --> Helper loaded: text_helper
INFO - 2024-02-07 08:39:40 --> Helper loaded: form_helper
INFO - 2024-02-07 08:39:40 --> Helper loaded: lang_helper
INFO - 2024-02-07 08:39:40 --> Helper loaded: security_helper
INFO - 2024-02-07 08:39:40 --> Helper loaded: cookie_helper
INFO - 2024-02-07 08:39:40 --> Database Driver Class Initialized
INFO - 2024-02-07 08:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 08:39:40 --> Parser Class Initialized
INFO - 2024-02-07 08:39:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 08:39:40 --> Pagination Class Initialized
INFO - 2024-02-07 08:39:40 --> Form Validation Class Initialized
INFO - 2024-02-07 08:39:40 --> Controller Class Initialized
INFO - 2024-02-07 08:39:40 --> Model Class Initialized
DEBUG - 2024-02-07 08:39:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:39:40 --> Model Class Initialized
DEBUG - 2024-02-07 08:39:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:39:40 --> Model Class Initialized
INFO - 2024-02-07 08:39:40 --> Model Class Initialized
INFO - 2024-02-07 08:39:40 --> Model Class Initialized
INFO - 2024-02-07 08:39:40 --> Model Class Initialized
DEBUG - 2024-02-07 08:39:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 08:39:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:39:40 --> Model Class Initialized
INFO - 2024-02-07 08:39:40 --> Model Class Initialized
INFO - 2024-02-07 08:39:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-07 08:39:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:39:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 08:39:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 08:39:40 --> Model Class Initialized
INFO - 2024-02-07 08:39:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 08:39:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 08:39:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 08:39:41 --> Final output sent to browser
DEBUG - 2024-02-07 08:39:41 --> Total execution time: 0.2361
ERROR - 2024-02-07 08:49:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 08:49:14 --> Config Class Initialized
INFO - 2024-02-07 08:49:14 --> Hooks Class Initialized
DEBUG - 2024-02-07 08:49:14 --> UTF-8 Support Enabled
INFO - 2024-02-07 08:49:14 --> Utf8 Class Initialized
INFO - 2024-02-07 08:49:14 --> URI Class Initialized
INFO - 2024-02-07 08:49:14 --> Router Class Initialized
INFO - 2024-02-07 08:49:14 --> Output Class Initialized
INFO - 2024-02-07 08:49:14 --> Security Class Initialized
DEBUG - 2024-02-07 08:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 08:49:14 --> Input Class Initialized
INFO - 2024-02-07 08:49:14 --> Language Class Initialized
INFO - 2024-02-07 08:49:14 --> Loader Class Initialized
INFO - 2024-02-07 08:49:14 --> Helper loaded: url_helper
INFO - 2024-02-07 08:49:14 --> Helper loaded: file_helper
INFO - 2024-02-07 08:49:14 --> Helper loaded: html_helper
INFO - 2024-02-07 08:49:14 --> Helper loaded: text_helper
INFO - 2024-02-07 08:49:14 --> Helper loaded: form_helper
INFO - 2024-02-07 08:49:14 --> Helper loaded: lang_helper
INFO - 2024-02-07 08:49:14 --> Helper loaded: security_helper
INFO - 2024-02-07 08:49:14 --> Helper loaded: cookie_helper
INFO - 2024-02-07 08:49:14 --> Database Driver Class Initialized
INFO - 2024-02-07 08:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 08:49:14 --> Parser Class Initialized
INFO - 2024-02-07 08:49:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 08:49:14 --> Pagination Class Initialized
INFO - 2024-02-07 08:49:14 --> Form Validation Class Initialized
INFO - 2024-02-07 08:49:14 --> Controller Class Initialized
DEBUG - 2024-02-07 08:49:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 08:49:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:49:14 --> Model Class Initialized
DEBUG - 2024-02-07 08:49:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:49:14 --> Model Class Initialized
INFO - 2024-02-07 08:49:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2024-02-07 08:49:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:49:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 08:49:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 08:49:14 --> Model Class Initialized
INFO - 2024-02-07 08:49:14 --> Model Class Initialized
INFO - 2024-02-07 08:49:14 --> Model Class Initialized
INFO - 2024-02-07 08:49:14 --> Model Class Initialized
INFO - 2024-02-07 08:49:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 08:49:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 08:49:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 08:49:14 --> Final output sent to browser
DEBUG - 2024-02-07 08:49:14 --> Total execution time: 0.1818
ERROR - 2024-02-07 08:57:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 08:57:04 --> Config Class Initialized
INFO - 2024-02-07 08:57:04 --> Hooks Class Initialized
DEBUG - 2024-02-07 08:57:04 --> UTF-8 Support Enabled
INFO - 2024-02-07 08:57:04 --> Utf8 Class Initialized
INFO - 2024-02-07 08:57:04 --> URI Class Initialized
INFO - 2024-02-07 08:57:04 --> Router Class Initialized
INFO - 2024-02-07 08:57:04 --> Output Class Initialized
INFO - 2024-02-07 08:57:04 --> Security Class Initialized
DEBUG - 2024-02-07 08:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 08:57:04 --> Input Class Initialized
INFO - 2024-02-07 08:57:04 --> Language Class Initialized
INFO - 2024-02-07 08:57:04 --> Loader Class Initialized
INFO - 2024-02-07 08:57:04 --> Helper loaded: url_helper
INFO - 2024-02-07 08:57:04 --> Helper loaded: file_helper
INFO - 2024-02-07 08:57:04 --> Helper loaded: html_helper
INFO - 2024-02-07 08:57:04 --> Helper loaded: text_helper
INFO - 2024-02-07 08:57:04 --> Helper loaded: form_helper
INFO - 2024-02-07 08:57:04 --> Helper loaded: lang_helper
INFO - 2024-02-07 08:57:04 --> Helper loaded: security_helper
INFO - 2024-02-07 08:57:04 --> Helper loaded: cookie_helper
INFO - 2024-02-07 08:57:04 --> Database Driver Class Initialized
INFO - 2024-02-07 08:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 08:57:04 --> Parser Class Initialized
INFO - 2024-02-07 08:57:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 08:57:04 --> Pagination Class Initialized
INFO - 2024-02-07 08:57:04 --> Form Validation Class Initialized
INFO - 2024-02-07 08:57:04 --> Controller Class Initialized
DEBUG - 2024-02-07 08:57:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 08:57:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:57:04 --> Model Class Initialized
DEBUG - 2024-02-07 08:57:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:57:04 --> Model Class Initialized
DEBUG - 2024-02-07 08:57:04 --> Auth class already loaded. Second attempt ignored.
ERROR - 2024-02-07 08:57:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 08:57:06 --> Config Class Initialized
INFO - 2024-02-07 08:57:06 --> Hooks Class Initialized
DEBUG - 2024-02-07 08:57:06 --> UTF-8 Support Enabled
INFO - 2024-02-07 08:57:06 --> Utf8 Class Initialized
INFO - 2024-02-07 08:57:06 --> URI Class Initialized
INFO - 2024-02-07 08:57:06 --> Router Class Initialized
INFO - 2024-02-07 08:57:06 --> Output Class Initialized
INFO - 2024-02-07 08:57:06 --> Security Class Initialized
DEBUG - 2024-02-07 08:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 08:57:06 --> Input Class Initialized
INFO - 2024-02-07 08:57:06 --> Language Class Initialized
INFO - 2024-02-07 08:57:06 --> Loader Class Initialized
INFO - 2024-02-07 08:57:06 --> Helper loaded: url_helper
INFO - 2024-02-07 08:57:06 --> Helper loaded: file_helper
INFO - 2024-02-07 08:57:06 --> Helper loaded: html_helper
INFO - 2024-02-07 08:57:06 --> Helper loaded: text_helper
INFO - 2024-02-07 08:57:06 --> Helper loaded: form_helper
INFO - 2024-02-07 08:57:06 --> Helper loaded: lang_helper
INFO - 2024-02-07 08:57:06 --> Helper loaded: security_helper
INFO - 2024-02-07 08:57:06 --> Helper loaded: cookie_helper
INFO - 2024-02-07 08:57:06 --> Database Driver Class Initialized
INFO - 2024-02-07 08:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 08:57:06 --> Parser Class Initialized
INFO - 2024-02-07 08:57:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 08:57:06 --> Pagination Class Initialized
INFO - 2024-02-07 08:57:06 --> Form Validation Class Initialized
INFO - 2024-02-07 08:57:06 --> Controller Class Initialized
DEBUG - 2024-02-07 08:57:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 08:57:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:57:06 --> Model Class Initialized
DEBUG - 2024-02-07 08:57:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:57:06 --> Model Class Initialized
INFO - 2024-02-07 08:57:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2024-02-07 08:57:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:57:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 08:57:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 08:57:06 --> Model Class Initialized
INFO - 2024-02-07 08:57:06 --> Model Class Initialized
INFO - 2024-02-07 08:57:06 --> Model Class Initialized
INFO - 2024-02-07 08:57:06 --> Model Class Initialized
INFO - 2024-02-07 08:57:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 08:57:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 08:57:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 08:57:06 --> Final output sent to browser
DEBUG - 2024-02-07 08:57:06 --> Total execution time: 0.1738
ERROR - 2024-02-07 08:57:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 08:57:11 --> Config Class Initialized
INFO - 2024-02-07 08:57:11 --> Hooks Class Initialized
DEBUG - 2024-02-07 08:57:11 --> UTF-8 Support Enabled
INFO - 2024-02-07 08:57:11 --> Utf8 Class Initialized
INFO - 2024-02-07 08:57:11 --> URI Class Initialized
INFO - 2024-02-07 08:57:11 --> Router Class Initialized
INFO - 2024-02-07 08:57:11 --> Output Class Initialized
INFO - 2024-02-07 08:57:11 --> Security Class Initialized
DEBUG - 2024-02-07 08:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 08:57:11 --> Input Class Initialized
INFO - 2024-02-07 08:57:11 --> Language Class Initialized
INFO - 2024-02-07 08:57:11 --> Loader Class Initialized
INFO - 2024-02-07 08:57:11 --> Helper loaded: url_helper
INFO - 2024-02-07 08:57:11 --> Helper loaded: file_helper
INFO - 2024-02-07 08:57:11 --> Helper loaded: html_helper
INFO - 2024-02-07 08:57:11 --> Helper loaded: text_helper
INFO - 2024-02-07 08:57:11 --> Helper loaded: form_helper
INFO - 2024-02-07 08:57:11 --> Helper loaded: lang_helper
INFO - 2024-02-07 08:57:11 --> Helper loaded: security_helper
INFO - 2024-02-07 08:57:11 --> Helper loaded: cookie_helper
INFO - 2024-02-07 08:57:11 --> Database Driver Class Initialized
INFO - 2024-02-07 08:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 08:57:11 --> Parser Class Initialized
INFO - 2024-02-07 08:57:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 08:57:11 --> Pagination Class Initialized
INFO - 2024-02-07 08:57:11 --> Form Validation Class Initialized
INFO - 2024-02-07 08:57:11 --> Controller Class Initialized
DEBUG - 2024-02-07 08:57:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 08:57:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:57:11 --> Model Class Initialized
DEBUG - 2024-02-07 08:57:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:57:11 --> Model Class Initialized
INFO - 2024-02-07 08:57:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2024-02-07 08:57:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:57:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 08:57:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 08:57:11 --> Model Class Initialized
INFO - 2024-02-07 08:57:11 --> Model Class Initialized
INFO - 2024-02-07 08:57:11 --> Model Class Initialized
INFO - 2024-02-07 08:57:11 --> Model Class Initialized
INFO - 2024-02-07 08:57:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 08:57:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 08:57:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 08:57:12 --> Final output sent to browser
DEBUG - 2024-02-07 08:57:12 --> Total execution time: 0.1677
ERROR - 2024-02-07 08:57:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 08:57:14 --> Config Class Initialized
INFO - 2024-02-07 08:57:14 --> Hooks Class Initialized
DEBUG - 2024-02-07 08:57:14 --> UTF-8 Support Enabled
INFO - 2024-02-07 08:57:14 --> Utf8 Class Initialized
INFO - 2024-02-07 08:57:14 --> URI Class Initialized
INFO - 2024-02-07 08:57:14 --> Router Class Initialized
INFO - 2024-02-07 08:57:14 --> Output Class Initialized
INFO - 2024-02-07 08:57:14 --> Security Class Initialized
DEBUG - 2024-02-07 08:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 08:57:14 --> Input Class Initialized
INFO - 2024-02-07 08:57:14 --> Language Class Initialized
INFO - 2024-02-07 08:57:14 --> Loader Class Initialized
INFO - 2024-02-07 08:57:14 --> Helper loaded: url_helper
INFO - 2024-02-07 08:57:14 --> Helper loaded: file_helper
INFO - 2024-02-07 08:57:14 --> Helper loaded: html_helper
INFO - 2024-02-07 08:57:14 --> Helper loaded: text_helper
INFO - 2024-02-07 08:57:14 --> Helper loaded: form_helper
INFO - 2024-02-07 08:57:14 --> Helper loaded: lang_helper
INFO - 2024-02-07 08:57:14 --> Helper loaded: security_helper
INFO - 2024-02-07 08:57:14 --> Helper loaded: cookie_helper
INFO - 2024-02-07 08:57:14 --> Database Driver Class Initialized
INFO - 2024-02-07 08:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 08:57:14 --> Parser Class Initialized
INFO - 2024-02-07 08:57:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 08:57:14 --> Pagination Class Initialized
INFO - 2024-02-07 08:57:14 --> Form Validation Class Initialized
INFO - 2024-02-07 08:57:14 --> Controller Class Initialized
INFO - 2024-02-07 08:57:14 --> Model Class Initialized
DEBUG - 2024-02-07 08:57:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:57:14 --> Model Class Initialized
DEBUG - 2024-02-07 08:57:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:57:14 --> Model Class Initialized
INFO - 2024-02-07 08:57:14 --> Model Class Initialized
INFO - 2024-02-07 08:57:14 --> Model Class Initialized
INFO - 2024-02-07 08:57:14 --> Model Class Initialized
DEBUG - 2024-02-07 08:57:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 08:57:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:57:14 --> Model Class Initialized
INFO - 2024-02-07 08:57:14 --> Model Class Initialized
INFO - 2024-02-07 08:57:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-07 08:57:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:57:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 08:57:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 08:57:14 --> Model Class Initialized
INFO - 2024-02-07 08:57:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 08:57:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 08:57:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 08:57:14 --> Final output sent to browser
DEBUG - 2024-02-07 08:57:14 --> Total execution time: 0.2202
ERROR - 2024-02-07 08:58:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 08:58:04 --> Config Class Initialized
INFO - 2024-02-07 08:58:04 --> Hooks Class Initialized
DEBUG - 2024-02-07 08:58:04 --> UTF-8 Support Enabled
INFO - 2024-02-07 08:58:04 --> Utf8 Class Initialized
INFO - 2024-02-07 08:58:04 --> URI Class Initialized
DEBUG - 2024-02-07 08:58:04 --> No URI present. Default controller set.
INFO - 2024-02-07 08:58:04 --> Router Class Initialized
INFO - 2024-02-07 08:58:04 --> Output Class Initialized
INFO - 2024-02-07 08:58:04 --> Security Class Initialized
DEBUG - 2024-02-07 08:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 08:58:04 --> Input Class Initialized
INFO - 2024-02-07 08:58:04 --> Language Class Initialized
INFO - 2024-02-07 08:58:04 --> Loader Class Initialized
INFO - 2024-02-07 08:58:04 --> Helper loaded: url_helper
INFO - 2024-02-07 08:58:04 --> Helper loaded: file_helper
INFO - 2024-02-07 08:58:04 --> Helper loaded: html_helper
INFO - 2024-02-07 08:58:04 --> Helper loaded: text_helper
INFO - 2024-02-07 08:58:04 --> Helper loaded: form_helper
INFO - 2024-02-07 08:58:04 --> Helper loaded: lang_helper
INFO - 2024-02-07 08:58:04 --> Helper loaded: security_helper
INFO - 2024-02-07 08:58:04 --> Helper loaded: cookie_helper
INFO - 2024-02-07 08:58:04 --> Database Driver Class Initialized
INFO - 2024-02-07 08:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 08:58:04 --> Parser Class Initialized
INFO - 2024-02-07 08:58:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 08:58:04 --> Pagination Class Initialized
INFO - 2024-02-07 08:58:04 --> Form Validation Class Initialized
INFO - 2024-02-07 08:58:04 --> Controller Class Initialized
INFO - 2024-02-07 08:58:04 --> Model Class Initialized
DEBUG - 2024-02-07 08:58:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-07 08:58:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 08:58:04 --> Config Class Initialized
INFO - 2024-02-07 08:58:04 --> Hooks Class Initialized
DEBUG - 2024-02-07 08:58:04 --> UTF-8 Support Enabled
INFO - 2024-02-07 08:58:04 --> Utf8 Class Initialized
INFO - 2024-02-07 08:58:04 --> URI Class Initialized
INFO - 2024-02-07 08:58:04 --> Router Class Initialized
INFO - 2024-02-07 08:58:04 --> Output Class Initialized
INFO - 2024-02-07 08:58:04 --> Security Class Initialized
DEBUG - 2024-02-07 08:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 08:58:04 --> Input Class Initialized
INFO - 2024-02-07 08:58:04 --> Language Class Initialized
INFO - 2024-02-07 08:58:04 --> Loader Class Initialized
INFO - 2024-02-07 08:58:04 --> Helper loaded: url_helper
INFO - 2024-02-07 08:58:04 --> Helper loaded: file_helper
INFO - 2024-02-07 08:58:04 --> Helper loaded: html_helper
INFO - 2024-02-07 08:58:04 --> Helper loaded: text_helper
INFO - 2024-02-07 08:58:04 --> Helper loaded: form_helper
INFO - 2024-02-07 08:58:04 --> Helper loaded: lang_helper
INFO - 2024-02-07 08:58:04 --> Helper loaded: security_helper
INFO - 2024-02-07 08:58:04 --> Helper loaded: cookie_helper
INFO - 2024-02-07 08:58:04 --> Database Driver Class Initialized
INFO - 2024-02-07 08:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 08:58:04 --> Parser Class Initialized
INFO - 2024-02-07 08:58:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 08:58:04 --> Pagination Class Initialized
INFO - 2024-02-07 08:58:04 --> Form Validation Class Initialized
INFO - 2024-02-07 08:58:04 --> Controller Class Initialized
INFO - 2024-02-07 08:58:04 --> Model Class Initialized
DEBUG - 2024-02-07 08:58:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:58:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-07 08:58:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:58:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 08:58:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 08:58:04 --> Model Class Initialized
INFO - 2024-02-07 08:58:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 08:58:04 --> Final output sent to browser
DEBUG - 2024-02-07 08:58:04 --> Total execution time: 0.0343
ERROR - 2024-02-07 08:58:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 08:58:19 --> Config Class Initialized
INFO - 2024-02-07 08:58:19 --> Hooks Class Initialized
DEBUG - 2024-02-07 08:58:19 --> UTF-8 Support Enabled
INFO - 2024-02-07 08:58:19 --> Utf8 Class Initialized
INFO - 2024-02-07 08:58:19 --> URI Class Initialized
INFO - 2024-02-07 08:58:19 --> Router Class Initialized
INFO - 2024-02-07 08:58:19 --> Output Class Initialized
INFO - 2024-02-07 08:58:19 --> Security Class Initialized
DEBUG - 2024-02-07 08:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 08:58:19 --> Input Class Initialized
INFO - 2024-02-07 08:58:19 --> Language Class Initialized
INFO - 2024-02-07 08:58:19 --> Loader Class Initialized
INFO - 2024-02-07 08:58:19 --> Helper loaded: url_helper
INFO - 2024-02-07 08:58:19 --> Helper loaded: file_helper
INFO - 2024-02-07 08:58:19 --> Helper loaded: html_helper
INFO - 2024-02-07 08:58:19 --> Helper loaded: text_helper
INFO - 2024-02-07 08:58:19 --> Helper loaded: form_helper
INFO - 2024-02-07 08:58:19 --> Helper loaded: lang_helper
INFO - 2024-02-07 08:58:19 --> Helper loaded: security_helper
INFO - 2024-02-07 08:58:19 --> Helper loaded: cookie_helper
INFO - 2024-02-07 08:58:19 --> Database Driver Class Initialized
INFO - 2024-02-07 08:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 08:58:19 --> Parser Class Initialized
INFO - 2024-02-07 08:58:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 08:58:19 --> Pagination Class Initialized
INFO - 2024-02-07 08:58:19 --> Form Validation Class Initialized
INFO - 2024-02-07 08:58:19 --> Controller Class Initialized
INFO - 2024-02-07 08:58:19 --> Model Class Initialized
DEBUG - 2024-02-07 08:58:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:58:19 --> Model Class Initialized
INFO - 2024-02-07 08:58:19 --> Final output sent to browser
DEBUG - 2024-02-07 08:58:19 --> Total execution time: 0.0204
ERROR - 2024-02-07 08:58:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 08:58:20 --> Config Class Initialized
INFO - 2024-02-07 08:58:20 --> Hooks Class Initialized
DEBUG - 2024-02-07 08:58:20 --> UTF-8 Support Enabled
INFO - 2024-02-07 08:58:20 --> Utf8 Class Initialized
INFO - 2024-02-07 08:58:20 --> URI Class Initialized
DEBUG - 2024-02-07 08:58:20 --> No URI present. Default controller set.
INFO - 2024-02-07 08:58:20 --> Router Class Initialized
INFO - 2024-02-07 08:58:20 --> Output Class Initialized
INFO - 2024-02-07 08:58:20 --> Security Class Initialized
DEBUG - 2024-02-07 08:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 08:58:20 --> Input Class Initialized
INFO - 2024-02-07 08:58:20 --> Language Class Initialized
INFO - 2024-02-07 08:58:20 --> Loader Class Initialized
INFO - 2024-02-07 08:58:20 --> Helper loaded: url_helper
INFO - 2024-02-07 08:58:20 --> Helper loaded: file_helper
INFO - 2024-02-07 08:58:20 --> Helper loaded: html_helper
INFO - 2024-02-07 08:58:20 --> Helper loaded: text_helper
INFO - 2024-02-07 08:58:20 --> Helper loaded: form_helper
INFO - 2024-02-07 08:58:20 --> Helper loaded: lang_helper
INFO - 2024-02-07 08:58:20 --> Helper loaded: security_helper
INFO - 2024-02-07 08:58:20 --> Helper loaded: cookie_helper
INFO - 2024-02-07 08:58:20 --> Database Driver Class Initialized
INFO - 2024-02-07 08:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 08:58:20 --> Parser Class Initialized
INFO - 2024-02-07 08:58:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 08:58:20 --> Pagination Class Initialized
INFO - 2024-02-07 08:58:20 --> Form Validation Class Initialized
INFO - 2024-02-07 08:58:20 --> Controller Class Initialized
INFO - 2024-02-07 08:58:20 --> Model Class Initialized
DEBUG - 2024-02-07 08:58:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:58:20 --> Model Class Initialized
DEBUG - 2024-02-07 08:58:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:58:20 --> Model Class Initialized
INFO - 2024-02-07 08:58:20 --> Model Class Initialized
INFO - 2024-02-07 08:58:20 --> Model Class Initialized
INFO - 2024-02-07 08:58:20 --> Model Class Initialized
DEBUG - 2024-02-07 08:58:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 08:58:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:58:20 --> Model Class Initialized
INFO - 2024-02-07 08:58:20 --> Model Class Initialized
INFO - 2024-02-07 08:58:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-07 08:58:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:58:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 08:58:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 08:58:20 --> Model Class Initialized
INFO - 2024-02-07 08:58:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 08:58:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 08:58:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 08:58:20 --> Final output sent to browser
DEBUG - 2024-02-07 08:58:20 --> Total execution time: 0.4181
ERROR - 2024-02-07 08:58:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 08:58:24 --> Config Class Initialized
INFO - 2024-02-07 08:58:24 --> Hooks Class Initialized
DEBUG - 2024-02-07 08:58:24 --> UTF-8 Support Enabled
INFO - 2024-02-07 08:58:24 --> Utf8 Class Initialized
INFO - 2024-02-07 08:58:24 --> URI Class Initialized
INFO - 2024-02-07 08:58:24 --> Router Class Initialized
INFO - 2024-02-07 08:58:24 --> Output Class Initialized
INFO - 2024-02-07 08:58:24 --> Security Class Initialized
DEBUG - 2024-02-07 08:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 08:58:24 --> Input Class Initialized
INFO - 2024-02-07 08:58:24 --> Language Class Initialized
INFO - 2024-02-07 08:58:24 --> Loader Class Initialized
INFO - 2024-02-07 08:58:24 --> Helper loaded: url_helper
INFO - 2024-02-07 08:58:24 --> Helper loaded: file_helper
INFO - 2024-02-07 08:58:24 --> Helper loaded: html_helper
INFO - 2024-02-07 08:58:24 --> Helper loaded: text_helper
INFO - 2024-02-07 08:58:24 --> Helper loaded: form_helper
INFO - 2024-02-07 08:58:24 --> Helper loaded: lang_helper
INFO - 2024-02-07 08:58:24 --> Helper loaded: security_helper
INFO - 2024-02-07 08:58:24 --> Helper loaded: cookie_helper
INFO - 2024-02-07 08:58:24 --> Database Driver Class Initialized
INFO - 2024-02-07 08:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 08:58:24 --> Parser Class Initialized
INFO - 2024-02-07 08:58:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 08:58:24 --> Pagination Class Initialized
INFO - 2024-02-07 08:58:24 --> Form Validation Class Initialized
INFO - 2024-02-07 08:58:24 --> Controller Class Initialized
DEBUG - 2024-02-07 08:58:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 08:58:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:58:24 --> Model Class Initialized
INFO - 2024-02-07 08:58:24 --> Final output sent to browser
DEBUG - 2024-02-07 08:58:24 --> Total execution time: 0.0134
ERROR - 2024-02-07 08:58:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 08:58:44 --> Config Class Initialized
INFO - 2024-02-07 08:58:44 --> Hooks Class Initialized
DEBUG - 2024-02-07 08:58:44 --> UTF-8 Support Enabled
INFO - 2024-02-07 08:58:44 --> Utf8 Class Initialized
INFO - 2024-02-07 08:58:44 --> URI Class Initialized
INFO - 2024-02-07 08:58:44 --> Router Class Initialized
INFO - 2024-02-07 08:58:44 --> Output Class Initialized
INFO - 2024-02-07 08:58:44 --> Security Class Initialized
DEBUG - 2024-02-07 08:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 08:58:44 --> Input Class Initialized
INFO - 2024-02-07 08:58:44 --> Language Class Initialized
INFO - 2024-02-07 08:58:44 --> Loader Class Initialized
INFO - 2024-02-07 08:58:44 --> Helper loaded: url_helper
INFO - 2024-02-07 08:58:44 --> Helper loaded: file_helper
INFO - 2024-02-07 08:58:44 --> Helper loaded: html_helper
INFO - 2024-02-07 08:58:44 --> Helper loaded: text_helper
INFO - 2024-02-07 08:58:44 --> Helper loaded: form_helper
INFO - 2024-02-07 08:58:44 --> Helper loaded: lang_helper
INFO - 2024-02-07 08:58:44 --> Helper loaded: security_helper
INFO - 2024-02-07 08:58:44 --> Helper loaded: cookie_helper
INFO - 2024-02-07 08:58:44 --> Database Driver Class Initialized
INFO - 2024-02-07 08:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 08:58:44 --> Parser Class Initialized
INFO - 2024-02-07 08:58:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 08:58:44 --> Pagination Class Initialized
INFO - 2024-02-07 08:58:44 --> Form Validation Class Initialized
INFO - 2024-02-07 08:58:44 --> Controller Class Initialized
DEBUG - 2024-02-07 08:58:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 08:58:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:58:44 --> Model Class Initialized
DEBUG - 2024-02-07 08:58:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:58:44 --> Model Class Initialized
DEBUG - 2024-02-07 08:58:44 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:58:44 --> Model Class Initialized
INFO - 2024-02-07 08:58:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-07 08:58:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:58:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 08:58:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 08:58:44 --> Model Class Initialized
INFO - 2024-02-07 08:58:44 --> Model Class Initialized
INFO - 2024-02-07 08:58:44 --> Model Class Initialized
INFO - 2024-02-07 08:58:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 08:58:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 08:58:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 08:58:44 --> Final output sent to browser
DEBUG - 2024-02-07 08:58:44 --> Total execution time: 0.2169
ERROR - 2024-02-07 08:58:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 08:58:45 --> Config Class Initialized
INFO - 2024-02-07 08:58:45 --> Hooks Class Initialized
DEBUG - 2024-02-07 08:58:45 --> UTF-8 Support Enabled
INFO - 2024-02-07 08:58:45 --> Utf8 Class Initialized
INFO - 2024-02-07 08:58:45 --> URI Class Initialized
INFO - 2024-02-07 08:58:45 --> Router Class Initialized
INFO - 2024-02-07 08:58:45 --> Output Class Initialized
INFO - 2024-02-07 08:58:45 --> Security Class Initialized
DEBUG - 2024-02-07 08:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 08:58:45 --> Input Class Initialized
INFO - 2024-02-07 08:58:45 --> Language Class Initialized
INFO - 2024-02-07 08:58:45 --> Loader Class Initialized
INFO - 2024-02-07 08:58:45 --> Helper loaded: url_helper
INFO - 2024-02-07 08:58:45 --> Helper loaded: file_helper
INFO - 2024-02-07 08:58:45 --> Helper loaded: html_helper
INFO - 2024-02-07 08:58:45 --> Helper loaded: text_helper
INFO - 2024-02-07 08:58:45 --> Helper loaded: form_helper
INFO - 2024-02-07 08:58:45 --> Helper loaded: lang_helper
INFO - 2024-02-07 08:58:45 --> Helper loaded: security_helper
INFO - 2024-02-07 08:58:45 --> Helper loaded: cookie_helper
INFO - 2024-02-07 08:58:45 --> Database Driver Class Initialized
INFO - 2024-02-07 08:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 08:58:45 --> Parser Class Initialized
INFO - 2024-02-07 08:58:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 08:58:45 --> Pagination Class Initialized
INFO - 2024-02-07 08:58:45 --> Form Validation Class Initialized
INFO - 2024-02-07 08:58:45 --> Controller Class Initialized
DEBUG - 2024-02-07 08:58:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 08:58:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:58:45 --> Model Class Initialized
DEBUG - 2024-02-07 08:58:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:58:45 --> Model Class Initialized
INFO - 2024-02-07 08:58:45 --> Final output sent to browser
DEBUG - 2024-02-07 08:58:45 --> Total execution time: 0.0305
ERROR - 2024-02-07 08:59:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 08:59:11 --> Config Class Initialized
INFO - 2024-02-07 08:59:11 --> Hooks Class Initialized
DEBUG - 2024-02-07 08:59:11 --> UTF-8 Support Enabled
INFO - 2024-02-07 08:59:11 --> Utf8 Class Initialized
INFO - 2024-02-07 08:59:11 --> URI Class Initialized
INFO - 2024-02-07 08:59:11 --> Router Class Initialized
INFO - 2024-02-07 08:59:11 --> Output Class Initialized
INFO - 2024-02-07 08:59:11 --> Security Class Initialized
DEBUG - 2024-02-07 08:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 08:59:11 --> Input Class Initialized
INFO - 2024-02-07 08:59:11 --> Language Class Initialized
INFO - 2024-02-07 08:59:11 --> Loader Class Initialized
INFO - 2024-02-07 08:59:11 --> Helper loaded: url_helper
INFO - 2024-02-07 08:59:11 --> Helper loaded: file_helper
INFO - 2024-02-07 08:59:11 --> Helper loaded: html_helper
INFO - 2024-02-07 08:59:11 --> Helper loaded: text_helper
INFO - 2024-02-07 08:59:11 --> Helper loaded: form_helper
INFO - 2024-02-07 08:59:11 --> Helper loaded: lang_helper
INFO - 2024-02-07 08:59:11 --> Helper loaded: security_helper
INFO - 2024-02-07 08:59:11 --> Helper loaded: cookie_helper
INFO - 2024-02-07 08:59:11 --> Database Driver Class Initialized
INFO - 2024-02-07 08:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 08:59:11 --> Parser Class Initialized
INFO - 2024-02-07 08:59:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 08:59:11 --> Pagination Class Initialized
INFO - 2024-02-07 08:59:11 --> Form Validation Class Initialized
INFO - 2024-02-07 08:59:11 --> Controller Class Initialized
DEBUG - 2024-02-07 08:59:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 08:59:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:59:11 --> Model Class Initialized
DEBUG - 2024-02-07 08:59:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 08:59:11 --> Model Class Initialized
INFO - 2024-02-07 08:59:11 --> Final output sent to browser
DEBUG - 2024-02-07 08:59:11 --> Total execution time: 0.2065
ERROR - 2024-02-07 09:00:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:00:23 --> Config Class Initialized
INFO - 2024-02-07 09:00:23 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:00:23 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:00:23 --> Utf8 Class Initialized
INFO - 2024-02-07 09:00:23 --> URI Class Initialized
INFO - 2024-02-07 09:00:23 --> Router Class Initialized
INFO - 2024-02-07 09:00:23 --> Output Class Initialized
INFO - 2024-02-07 09:00:23 --> Security Class Initialized
DEBUG - 2024-02-07 09:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:00:23 --> Input Class Initialized
INFO - 2024-02-07 09:00:23 --> Language Class Initialized
INFO - 2024-02-07 09:00:23 --> Loader Class Initialized
INFO - 2024-02-07 09:00:23 --> Helper loaded: url_helper
INFO - 2024-02-07 09:00:23 --> Helper loaded: file_helper
INFO - 2024-02-07 09:00:23 --> Helper loaded: html_helper
INFO - 2024-02-07 09:00:23 --> Helper loaded: text_helper
INFO - 2024-02-07 09:00:23 --> Helper loaded: form_helper
INFO - 2024-02-07 09:00:23 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:00:23 --> Helper loaded: security_helper
INFO - 2024-02-07 09:00:23 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:00:23 --> Database Driver Class Initialized
INFO - 2024-02-07 09:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:00:23 --> Parser Class Initialized
INFO - 2024-02-07 09:00:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:00:23 --> Pagination Class Initialized
INFO - 2024-02-07 09:00:23 --> Form Validation Class Initialized
INFO - 2024-02-07 09:00:23 --> Controller Class Initialized
DEBUG - 2024-02-07 09:00:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 09:00:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:00:23 --> Model Class Initialized
DEBUG - 2024-02-07 09:00:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:00:23 --> Model Class Initialized
INFO - 2024-02-07 09:00:23 --> Final output sent to browser
DEBUG - 2024-02-07 09:00:23 --> Total execution time: 0.0190
ERROR - 2024-02-07 09:03:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:03:48 --> Config Class Initialized
INFO - 2024-02-07 09:03:48 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:03:48 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:03:48 --> Utf8 Class Initialized
INFO - 2024-02-07 09:03:48 --> URI Class Initialized
DEBUG - 2024-02-07 09:03:48 --> No URI present. Default controller set.
INFO - 2024-02-07 09:03:48 --> Router Class Initialized
INFO - 2024-02-07 09:03:48 --> Output Class Initialized
INFO - 2024-02-07 09:03:48 --> Security Class Initialized
DEBUG - 2024-02-07 09:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:03:48 --> Input Class Initialized
INFO - 2024-02-07 09:03:48 --> Language Class Initialized
INFO - 2024-02-07 09:03:48 --> Loader Class Initialized
INFO - 2024-02-07 09:03:48 --> Helper loaded: url_helper
INFO - 2024-02-07 09:03:48 --> Helper loaded: file_helper
INFO - 2024-02-07 09:03:48 --> Helper loaded: html_helper
INFO - 2024-02-07 09:03:48 --> Helper loaded: text_helper
INFO - 2024-02-07 09:03:48 --> Helper loaded: form_helper
INFO - 2024-02-07 09:03:48 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:03:48 --> Helper loaded: security_helper
INFO - 2024-02-07 09:03:48 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:03:48 --> Database Driver Class Initialized
INFO - 2024-02-07 09:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:03:48 --> Parser Class Initialized
INFO - 2024-02-07 09:03:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:03:48 --> Pagination Class Initialized
INFO - 2024-02-07 09:03:48 --> Form Validation Class Initialized
INFO - 2024-02-07 09:03:48 --> Controller Class Initialized
INFO - 2024-02-07 09:03:48 --> Model Class Initialized
DEBUG - 2024-02-07 09:03:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:03:48 --> Model Class Initialized
DEBUG - 2024-02-07 09:03:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:03:48 --> Model Class Initialized
INFO - 2024-02-07 09:03:48 --> Model Class Initialized
INFO - 2024-02-07 09:03:48 --> Model Class Initialized
INFO - 2024-02-07 09:03:48 --> Model Class Initialized
DEBUG - 2024-02-07 09:03:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 09:03:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:03:48 --> Model Class Initialized
INFO - 2024-02-07 09:03:48 --> Model Class Initialized
INFO - 2024-02-07 09:03:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-07 09:03:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:03:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 09:03:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 09:03:49 --> Model Class Initialized
INFO - 2024-02-07 09:03:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 09:03:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 09:03:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 09:03:49 --> Final output sent to browser
DEBUG - 2024-02-07 09:03:49 --> Total execution time: 0.2329
ERROR - 2024-02-07 09:04:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:04:01 --> Config Class Initialized
INFO - 2024-02-07 09:04:01 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:04:01 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:04:01 --> Utf8 Class Initialized
INFO - 2024-02-07 09:04:01 --> URI Class Initialized
INFO - 2024-02-07 09:04:01 --> Router Class Initialized
INFO - 2024-02-07 09:04:01 --> Output Class Initialized
INFO - 2024-02-07 09:04:01 --> Security Class Initialized
DEBUG - 2024-02-07 09:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:04:01 --> Input Class Initialized
INFO - 2024-02-07 09:04:01 --> Language Class Initialized
INFO - 2024-02-07 09:04:01 --> Loader Class Initialized
INFO - 2024-02-07 09:04:01 --> Helper loaded: url_helper
INFO - 2024-02-07 09:04:01 --> Helper loaded: file_helper
INFO - 2024-02-07 09:04:01 --> Helper loaded: html_helper
INFO - 2024-02-07 09:04:01 --> Helper loaded: text_helper
INFO - 2024-02-07 09:04:01 --> Helper loaded: form_helper
INFO - 2024-02-07 09:04:01 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:04:01 --> Helper loaded: security_helper
INFO - 2024-02-07 09:04:01 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:04:01 --> Database Driver Class Initialized
INFO - 2024-02-07 09:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:04:01 --> Parser Class Initialized
INFO - 2024-02-07 09:04:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:04:01 --> Pagination Class Initialized
INFO - 2024-02-07 09:04:01 --> Form Validation Class Initialized
INFO - 2024-02-07 09:04:01 --> Controller Class Initialized
INFO - 2024-02-07 09:04:01 --> Model Class Initialized
DEBUG - 2024-02-07 09:04:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 09:04:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:04:01 --> Model Class Initialized
DEBUG - 2024-02-07 09:04:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:04:01 --> Model Class Initialized
INFO - 2024-02-07 09:04:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-07 09:04:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:04:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 09:04:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 09:04:01 --> Model Class Initialized
INFO - 2024-02-07 09:04:01 --> Model Class Initialized
INFO - 2024-02-07 09:04:01 --> Model Class Initialized
INFO - 2024-02-07 09:04:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 09:04:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 09:04:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 09:04:01 --> Final output sent to browser
DEBUG - 2024-02-07 09:04:01 --> Total execution time: 0.1617
ERROR - 2024-02-07 09:04:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:04:02 --> Config Class Initialized
INFO - 2024-02-07 09:04:02 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:04:02 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:04:02 --> Utf8 Class Initialized
INFO - 2024-02-07 09:04:02 --> URI Class Initialized
INFO - 2024-02-07 09:04:02 --> Router Class Initialized
INFO - 2024-02-07 09:04:02 --> Output Class Initialized
INFO - 2024-02-07 09:04:02 --> Security Class Initialized
DEBUG - 2024-02-07 09:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:04:02 --> Input Class Initialized
INFO - 2024-02-07 09:04:02 --> Language Class Initialized
INFO - 2024-02-07 09:04:02 --> Loader Class Initialized
INFO - 2024-02-07 09:04:02 --> Helper loaded: url_helper
INFO - 2024-02-07 09:04:02 --> Helper loaded: file_helper
INFO - 2024-02-07 09:04:02 --> Helper loaded: html_helper
INFO - 2024-02-07 09:04:02 --> Helper loaded: text_helper
INFO - 2024-02-07 09:04:02 --> Helper loaded: form_helper
INFO - 2024-02-07 09:04:02 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:04:02 --> Helper loaded: security_helper
INFO - 2024-02-07 09:04:02 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:04:02 --> Database Driver Class Initialized
INFO - 2024-02-07 09:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:04:02 --> Parser Class Initialized
INFO - 2024-02-07 09:04:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:04:02 --> Pagination Class Initialized
INFO - 2024-02-07 09:04:02 --> Form Validation Class Initialized
INFO - 2024-02-07 09:04:02 --> Controller Class Initialized
INFO - 2024-02-07 09:04:02 --> Model Class Initialized
DEBUG - 2024-02-07 09:04:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 09:04:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:04:02 --> Model Class Initialized
DEBUG - 2024-02-07 09:04:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:04:02 --> Model Class Initialized
INFO - 2024-02-07 09:04:02 --> Final output sent to browser
DEBUG - 2024-02-07 09:04:02 --> Total execution time: 0.0388
ERROR - 2024-02-07 09:04:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:04:05 --> Config Class Initialized
INFO - 2024-02-07 09:04:05 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:04:05 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:04:05 --> Utf8 Class Initialized
INFO - 2024-02-07 09:04:05 --> URI Class Initialized
DEBUG - 2024-02-07 09:04:05 --> No URI present. Default controller set.
INFO - 2024-02-07 09:04:05 --> Router Class Initialized
INFO - 2024-02-07 09:04:05 --> Output Class Initialized
INFO - 2024-02-07 09:04:05 --> Security Class Initialized
DEBUG - 2024-02-07 09:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:04:05 --> Input Class Initialized
INFO - 2024-02-07 09:04:05 --> Language Class Initialized
INFO - 2024-02-07 09:04:05 --> Loader Class Initialized
INFO - 2024-02-07 09:04:05 --> Helper loaded: url_helper
INFO - 2024-02-07 09:04:05 --> Helper loaded: file_helper
INFO - 2024-02-07 09:04:05 --> Helper loaded: html_helper
INFO - 2024-02-07 09:04:05 --> Helper loaded: text_helper
INFO - 2024-02-07 09:04:05 --> Helper loaded: form_helper
INFO - 2024-02-07 09:04:05 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:04:05 --> Helper loaded: security_helper
INFO - 2024-02-07 09:04:05 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:04:05 --> Database Driver Class Initialized
INFO - 2024-02-07 09:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:04:05 --> Parser Class Initialized
INFO - 2024-02-07 09:04:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:04:05 --> Pagination Class Initialized
INFO - 2024-02-07 09:04:05 --> Form Validation Class Initialized
INFO - 2024-02-07 09:04:05 --> Controller Class Initialized
INFO - 2024-02-07 09:04:05 --> Model Class Initialized
DEBUG - 2024-02-07 09:04:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:04:05 --> Model Class Initialized
DEBUG - 2024-02-07 09:04:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:04:05 --> Model Class Initialized
INFO - 2024-02-07 09:04:05 --> Model Class Initialized
INFO - 2024-02-07 09:04:05 --> Model Class Initialized
INFO - 2024-02-07 09:04:05 --> Model Class Initialized
DEBUG - 2024-02-07 09:04:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 09:04:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:04:05 --> Model Class Initialized
INFO - 2024-02-07 09:04:05 --> Model Class Initialized
INFO - 2024-02-07 09:04:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-07 09:04:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:04:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 09:04:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 09:04:05 --> Model Class Initialized
INFO - 2024-02-07 09:04:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 09:04:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 09:04:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 09:04:05 --> Final output sent to browser
DEBUG - 2024-02-07 09:04:05 --> Total execution time: 0.2180
ERROR - 2024-02-07 09:04:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:04:11 --> Config Class Initialized
INFO - 2024-02-07 09:04:11 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:04:11 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:04:11 --> Utf8 Class Initialized
INFO - 2024-02-07 09:04:11 --> URI Class Initialized
INFO - 2024-02-07 09:04:11 --> Router Class Initialized
INFO - 2024-02-07 09:04:11 --> Output Class Initialized
INFO - 2024-02-07 09:04:11 --> Security Class Initialized
DEBUG - 2024-02-07 09:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:04:11 --> Input Class Initialized
INFO - 2024-02-07 09:04:11 --> Language Class Initialized
INFO - 2024-02-07 09:04:11 --> Loader Class Initialized
INFO - 2024-02-07 09:04:11 --> Helper loaded: url_helper
INFO - 2024-02-07 09:04:11 --> Helper loaded: file_helper
INFO - 2024-02-07 09:04:11 --> Helper loaded: html_helper
INFO - 2024-02-07 09:04:11 --> Helper loaded: text_helper
INFO - 2024-02-07 09:04:11 --> Helper loaded: form_helper
INFO - 2024-02-07 09:04:11 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:04:11 --> Helper loaded: security_helper
INFO - 2024-02-07 09:04:11 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:04:11 --> Database Driver Class Initialized
INFO - 2024-02-07 09:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:04:11 --> Parser Class Initialized
INFO - 2024-02-07 09:04:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:04:11 --> Pagination Class Initialized
INFO - 2024-02-07 09:04:11 --> Form Validation Class Initialized
INFO - 2024-02-07 09:04:11 --> Controller Class Initialized
INFO - 2024-02-07 09:04:11 --> Model Class Initialized
DEBUG - 2024-02-07 09:04:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 09:04:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:04:11 --> Model Class Initialized
DEBUG - 2024-02-07 09:04:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:04:11 --> Model Class Initialized
INFO - 2024-02-07 09:04:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-02-07 09:04:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:04:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 09:04:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 09:04:11 --> Model Class Initialized
INFO - 2024-02-07 09:04:11 --> Model Class Initialized
INFO - 2024-02-07 09:04:11 --> Model Class Initialized
INFO - 2024-02-07 09:04:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 09:04:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 09:04:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 09:04:11 --> Final output sent to browser
DEBUG - 2024-02-07 09:04:11 --> Total execution time: 0.1613
ERROR - 2024-02-07 09:04:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:04:24 --> Config Class Initialized
INFO - 2024-02-07 09:04:24 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:04:24 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:04:24 --> Utf8 Class Initialized
INFO - 2024-02-07 09:04:24 --> URI Class Initialized
INFO - 2024-02-07 09:04:24 --> Router Class Initialized
INFO - 2024-02-07 09:04:24 --> Output Class Initialized
INFO - 2024-02-07 09:04:24 --> Security Class Initialized
DEBUG - 2024-02-07 09:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:04:24 --> Input Class Initialized
INFO - 2024-02-07 09:04:24 --> Language Class Initialized
INFO - 2024-02-07 09:04:24 --> Loader Class Initialized
INFO - 2024-02-07 09:04:24 --> Helper loaded: url_helper
INFO - 2024-02-07 09:04:24 --> Helper loaded: file_helper
INFO - 2024-02-07 09:04:24 --> Helper loaded: html_helper
INFO - 2024-02-07 09:04:24 --> Helper loaded: text_helper
INFO - 2024-02-07 09:04:24 --> Helper loaded: form_helper
INFO - 2024-02-07 09:04:24 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:04:24 --> Helper loaded: security_helper
INFO - 2024-02-07 09:04:24 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:04:24 --> Database Driver Class Initialized
INFO - 2024-02-07 09:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:04:24 --> Parser Class Initialized
INFO - 2024-02-07 09:04:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:04:24 --> Pagination Class Initialized
INFO - 2024-02-07 09:04:24 --> Form Validation Class Initialized
INFO - 2024-02-07 09:04:24 --> Controller Class Initialized
INFO - 2024-02-07 09:04:24 --> Model Class Initialized
DEBUG - 2024-02-07 09:04:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:04:24 --> Final output sent to browser
DEBUG - 2024-02-07 09:04:24 --> Total execution time: 0.0191
ERROR - 2024-02-07 09:04:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:04:55 --> Config Class Initialized
INFO - 2024-02-07 09:04:55 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:04:55 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:04:55 --> Utf8 Class Initialized
INFO - 2024-02-07 09:04:55 --> URI Class Initialized
INFO - 2024-02-07 09:04:55 --> Router Class Initialized
INFO - 2024-02-07 09:04:55 --> Output Class Initialized
INFO - 2024-02-07 09:04:55 --> Security Class Initialized
DEBUG - 2024-02-07 09:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:04:55 --> Input Class Initialized
INFO - 2024-02-07 09:04:55 --> Language Class Initialized
INFO - 2024-02-07 09:04:55 --> Loader Class Initialized
INFO - 2024-02-07 09:04:55 --> Helper loaded: url_helper
INFO - 2024-02-07 09:04:55 --> Helper loaded: file_helper
INFO - 2024-02-07 09:04:55 --> Helper loaded: html_helper
INFO - 2024-02-07 09:04:55 --> Helper loaded: text_helper
INFO - 2024-02-07 09:04:55 --> Helper loaded: form_helper
INFO - 2024-02-07 09:04:55 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:04:55 --> Helper loaded: security_helper
INFO - 2024-02-07 09:04:55 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:04:55 --> Database Driver Class Initialized
INFO - 2024-02-07 09:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:04:55 --> Parser Class Initialized
INFO - 2024-02-07 09:04:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:04:55 --> Pagination Class Initialized
INFO - 2024-02-07 09:04:55 --> Form Validation Class Initialized
INFO - 2024-02-07 09:04:55 --> Controller Class Initialized
INFO - 2024-02-07 09:04:55 --> Model Class Initialized
DEBUG - 2024-02-07 09:04:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:04:55 --> Final output sent to browser
DEBUG - 2024-02-07 09:04:55 --> Total execution time: 0.0181
ERROR - 2024-02-07 09:05:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:05:23 --> Config Class Initialized
INFO - 2024-02-07 09:05:23 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:05:23 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:05:23 --> Utf8 Class Initialized
INFO - 2024-02-07 09:05:23 --> URI Class Initialized
INFO - 2024-02-07 09:05:23 --> Router Class Initialized
INFO - 2024-02-07 09:05:23 --> Output Class Initialized
INFO - 2024-02-07 09:05:23 --> Security Class Initialized
DEBUG - 2024-02-07 09:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:05:23 --> Input Class Initialized
INFO - 2024-02-07 09:05:23 --> Language Class Initialized
INFO - 2024-02-07 09:05:23 --> Loader Class Initialized
INFO - 2024-02-07 09:05:23 --> Helper loaded: url_helper
INFO - 2024-02-07 09:05:23 --> Helper loaded: file_helper
INFO - 2024-02-07 09:05:23 --> Helper loaded: html_helper
INFO - 2024-02-07 09:05:23 --> Helper loaded: text_helper
INFO - 2024-02-07 09:05:23 --> Helper loaded: form_helper
INFO - 2024-02-07 09:05:23 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:05:23 --> Helper loaded: security_helper
INFO - 2024-02-07 09:05:23 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:05:23 --> Database Driver Class Initialized
INFO - 2024-02-07 09:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:05:23 --> Parser Class Initialized
INFO - 2024-02-07 09:05:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:05:23 --> Pagination Class Initialized
INFO - 2024-02-07 09:05:23 --> Form Validation Class Initialized
INFO - 2024-02-07 09:05:23 --> Controller Class Initialized
INFO - 2024-02-07 09:05:23 --> Model Class Initialized
DEBUG - 2024-02-07 09:05:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:05:23 --> Final output sent to browser
DEBUG - 2024-02-07 09:05:23 --> Total execution time: 0.0174
ERROR - 2024-02-07 09:05:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:05:24 --> Config Class Initialized
INFO - 2024-02-07 09:05:24 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:05:24 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:05:24 --> Utf8 Class Initialized
INFO - 2024-02-07 09:05:24 --> URI Class Initialized
INFO - 2024-02-07 09:05:24 --> Router Class Initialized
INFO - 2024-02-07 09:05:24 --> Output Class Initialized
INFO - 2024-02-07 09:05:24 --> Security Class Initialized
DEBUG - 2024-02-07 09:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:05:24 --> Input Class Initialized
INFO - 2024-02-07 09:05:24 --> Language Class Initialized
INFO - 2024-02-07 09:05:24 --> Loader Class Initialized
INFO - 2024-02-07 09:05:24 --> Helper loaded: url_helper
INFO - 2024-02-07 09:05:24 --> Helper loaded: file_helper
INFO - 2024-02-07 09:05:24 --> Helper loaded: html_helper
INFO - 2024-02-07 09:05:24 --> Helper loaded: text_helper
INFO - 2024-02-07 09:05:24 --> Helper loaded: form_helper
INFO - 2024-02-07 09:05:24 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:05:24 --> Helper loaded: security_helper
INFO - 2024-02-07 09:05:24 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:05:24 --> Database Driver Class Initialized
INFO - 2024-02-07 09:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:05:24 --> Parser Class Initialized
INFO - 2024-02-07 09:05:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:05:24 --> Pagination Class Initialized
INFO - 2024-02-07 09:05:24 --> Form Validation Class Initialized
INFO - 2024-02-07 09:05:24 --> Controller Class Initialized
INFO - 2024-02-07 09:05:24 --> Model Class Initialized
DEBUG - 2024-02-07 09:05:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:05:24 --> Final output sent to browser
DEBUG - 2024-02-07 09:05:24 --> Total execution time: 0.0157
ERROR - 2024-02-07 09:05:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:05:25 --> Config Class Initialized
INFO - 2024-02-07 09:05:25 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:05:25 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:05:25 --> Utf8 Class Initialized
INFO - 2024-02-07 09:05:25 --> URI Class Initialized
INFO - 2024-02-07 09:05:25 --> Router Class Initialized
INFO - 2024-02-07 09:05:25 --> Output Class Initialized
INFO - 2024-02-07 09:05:25 --> Security Class Initialized
DEBUG - 2024-02-07 09:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:05:25 --> Input Class Initialized
INFO - 2024-02-07 09:05:25 --> Language Class Initialized
INFO - 2024-02-07 09:05:25 --> Loader Class Initialized
INFO - 2024-02-07 09:05:25 --> Helper loaded: url_helper
INFO - 2024-02-07 09:05:25 --> Helper loaded: file_helper
INFO - 2024-02-07 09:05:25 --> Helper loaded: html_helper
INFO - 2024-02-07 09:05:25 --> Helper loaded: text_helper
INFO - 2024-02-07 09:05:25 --> Helper loaded: form_helper
INFO - 2024-02-07 09:05:25 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:05:25 --> Helper loaded: security_helper
INFO - 2024-02-07 09:05:25 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:05:25 --> Database Driver Class Initialized
INFO - 2024-02-07 09:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:05:25 --> Parser Class Initialized
INFO - 2024-02-07 09:05:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:05:25 --> Pagination Class Initialized
INFO - 2024-02-07 09:05:25 --> Form Validation Class Initialized
INFO - 2024-02-07 09:05:25 --> Controller Class Initialized
INFO - 2024-02-07 09:05:25 --> Model Class Initialized
DEBUG - 2024-02-07 09:05:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:05:25 --> Final output sent to browser
DEBUG - 2024-02-07 09:05:25 --> Total execution time: 0.0154
ERROR - 2024-02-07 09:05:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:05:27 --> Config Class Initialized
INFO - 2024-02-07 09:05:27 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:05:27 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:05:27 --> Utf8 Class Initialized
INFO - 2024-02-07 09:05:27 --> URI Class Initialized
INFO - 2024-02-07 09:05:27 --> Router Class Initialized
INFO - 2024-02-07 09:05:27 --> Output Class Initialized
INFO - 2024-02-07 09:05:27 --> Security Class Initialized
DEBUG - 2024-02-07 09:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:05:27 --> Input Class Initialized
INFO - 2024-02-07 09:05:27 --> Language Class Initialized
INFO - 2024-02-07 09:05:27 --> Loader Class Initialized
INFO - 2024-02-07 09:05:27 --> Helper loaded: url_helper
INFO - 2024-02-07 09:05:27 --> Helper loaded: file_helper
INFO - 2024-02-07 09:05:27 --> Helper loaded: html_helper
INFO - 2024-02-07 09:05:27 --> Helper loaded: text_helper
INFO - 2024-02-07 09:05:27 --> Helper loaded: form_helper
INFO - 2024-02-07 09:05:27 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:05:27 --> Helper loaded: security_helper
INFO - 2024-02-07 09:05:27 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:05:27 --> Database Driver Class Initialized
INFO - 2024-02-07 09:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:05:27 --> Parser Class Initialized
INFO - 2024-02-07 09:05:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:05:27 --> Pagination Class Initialized
INFO - 2024-02-07 09:05:27 --> Form Validation Class Initialized
INFO - 2024-02-07 09:05:27 --> Controller Class Initialized
INFO - 2024-02-07 09:05:27 --> Model Class Initialized
DEBUG - 2024-02-07 09:05:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-07 09:05:27 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-02-07 09:05:27 --> Final output sent to browser
DEBUG - 2024-02-07 09:05:27 --> Total execution time: 0.0160
ERROR - 2024-02-07 09:05:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:05:30 --> Config Class Initialized
INFO - 2024-02-07 09:05:30 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:05:30 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:05:30 --> Utf8 Class Initialized
INFO - 2024-02-07 09:05:30 --> URI Class Initialized
INFO - 2024-02-07 09:05:30 --> Router Class Initialized
INFO - 2024-02-07 09:05:30 --> Output Class Initialized
INFO - 2024-02-07 09:05:30 --> Security Class Initialized
DEBUG - 2024-02-07 09:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:05:30 --> Input Class Initialized
INFO - 2024-02-07 09:05:30 --> Language Class Initialized
INFO - 2024-02-07 09:05:30 --> Loader Class Initialized
INFO - 2024-02-07 09:05:30 --> Helper loaded: url_helper
INFO - 2024-02-07 09:05:30 --> Helper loaded: file_helper
INFO - 2024-02-07 09:05:30 --> Helper loaded: html_helper
INFO - 2024-02-07 09:05:30 --> Helper loaded: text_helper
INFO - 2024-02-07 09:05:30 --> Helper loaded: form_helper
INFO - 2024-02-07 09:05:30 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:05:30 --> Helper loaded: security_helper
INFO - 2024-02-07 09:05:30 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:05:30 --> Database Driver Class Initialized
INFO - 2024-02-07 09:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:05:30 --> Parser Class Initialized
INFO - 2024-02-07 09:05:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:05:30 --> Pagination Class Initialized
INFO - 2024-02-07 09:05:30 --> Form Validation Class Initialized
INFO - 2024-02-07 09:05:30 --> Controller Class Initialized
INFO - 2024-02-07 09:05:30 --> Model Class Initialized
DEBUG - 2024-02-07 09:05:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-07 09:05:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-02-07 09:05:30 --> Final output sent to browser
DEBUG - 2024-02-07 09:05:30 --> Total execution time: 0.0156
ERROR - 2024-02-07 09:05:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:05:32 --> Config Class Initialized
INFO - 2024-02-07 09:05:32 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:05:32 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:05:32 --> Utf8 Class Initialized
INFO - 2024-02-07 09:05:32 --> URI Class Initialized
INFO - 2024-02-07 09:05:32 --> Router Class Initialized
INFO - 2024-02-07 09:05:32 --> Output Class Initialized
INFO - 2024-02-07 09:05:32 --> Security Class Initialized
DEBUG - 2024-02-07 09:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:05:32 --> Input Class Initialized
INFO - 2024-02-07 09:05:32 --> Language Class Initialized
INFO - 2024-02-07 09:05:32 --> Loader Class Initialized
INFO - 2024-02-07 09:05:32 --> Helper loaded: url_helper
INFO - 2024-02-07 09:05:32 --> Helper loaded: file_helper
INFO - 2024-02-07 09:05:32 --> Helper loaded: html_helper
INFO - 2024-02-07 09:05:32 --> Helper loaded: text_helper
INFO - 2024-02-07 09:05:32 --> Helper loaded: form_helper
INFO - 2024-02-07 09:05:32 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:05:32 --> Helper loaded: security_helper
INFO - 2024-02-07 09:05:32 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:05:32 --> Database Driver Class Initialized
INFO - 2024-02-07 09:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:05:32 --> Parser Class Initialized
INFO - 2024-02-07 09:05:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:05:32 --> Pagination Class Initialized
INFO - 2024-02-07 09:05:32 --> Form Validation Class Initialized
INFO - 2024-02-07 09:05:32 --> Controller Class Initialized
INFO - 2024-02-07 09:05:32 --> Model Class Initialized
DEBUG - 2024-02-07 09:05:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-07 09:05:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-02-07 09:05:32 --> Final output sent to browser
DEBUG - 2024-02-07 09:05:32 --> Total execution time: 0.0153
ERROR - 2024-02-07 09:05:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:05:32 --> Config Class Initialized
INFO - 2024-02-07 09:05:32 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:05:32 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:05:32 --> Utf8 Class Initialized
INFO - 2024-02-07 09:05:32 --> URI Class Initialized
INFO - 2024-02-07 09:05:32 --> Router Class Initialized
INFO - 2024-02-07 09:05:32 --> Output Class Initialized
INFO - 2024-02-07 09:05:32 --> Security Class Initialized
DEBUG - 2024-02-07 09:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:05:32 --> Input Class Initialized
INFO - 2024-02-07 09:05:32 --> Language Class Initialized
INFO - 2024-02-07 09:05:32 --> Loader Class Initialized
INFO - 2024-02-07 09:05:32 --> Helper loaded: url_helper
INFO - 2024-02-07 09:05:32 --> Helper loaded: file_helper
INFO - 2024-02-07 09:05:32 --> Helper loaded: html_helper
INFO - 2024-02-07 09:05:32 --> Helper loaded: text_helper
INFO - 2024-02-07 09:05:32 --> Helper loaded: form_helper
INFO - 2024-02-07 09:05:32 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:05:32 --> Helper loaded: security_helper
INFO - 2024-02-07 09:05:32 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:05:32 --> Database Driver Class Initialized
INFO - 2024-02-07 09:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:05:32 --> Parser Class Initialized
INFO - 2024-02-07 09:05:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:05:32 --> Pagination Class Initialized
INFO - 2024-02-07 09:05:32 --> Form Validation Class Initialized
INFO - 2024-02-07 09:05:32 --> Controller Class Initialized
INFO - 2024-02-07 09:05:32 --> Model Class Initialized
DEBUG - 2024-02-07 09:05:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-07 09:05:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-02-07 09:05:32 --> Final output sent to browser
DEBUG - 2024-02-07 09:05:32 --> Total execution time: 0.0155
ERROR - 2024-02-07 09:05:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:05:33 --> Config Class Initialized
INFO - 2024-02-07 09:05:33 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:05:33 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:05:33 --> Utf8 Class Initialized
INFO - 2024-02-07 09:05:33 --> URI Class Initialized
INFO - 2024-02-07 09:05:33 --> Router Class Initialized
INFO - 2024-02-07 09:05:33 --> Output Class Initialized
INFO - 2024-02-07 09:05:33 --> Security Class Initialized
DEBUG - 2024-02-07 09:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:05:33 --> Input Class Initialized
INFO - 2024-02-07 09:05:33 --> Language Class Initialized
INFO - 2024-02-07 09:05:33 --> Loader Class Initialized
INFO - 2024-02-07 09:05:33 --> Helper loaded: url_helper
INFO - 2024-02-07 09:05:33 --> Helper loaded: file_helper
INFO - 2024-02-07 09:05:33 --> Helper loaded: html_helper
INFO - 2024-02-07 09:05:33 --> Helper loaded: text_helper
INFO - 2024-02-07 09:05:33 --> Helper loaded: form_helper
INFO - 2024-02-07 09:05:33 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:05:33 --> Helper loaded: security_helper
INFO - 2024-02-07 09:05:33 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:05:33 --> Database Driver Class Initialized
INFO - 2024-02-07 09:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:05:33 --> Parser Class Initialized
INFO - 2024-02-07 09:05:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:05:33 --> Pagination Class Initialized
INFO - 2024-02-07 09:05:33 --> Form Validation Class Initialized
INFO - 2024-02-07 09:05:33 --> Controller Class Initialized
INFO - 2024-02-07 09:05:33 --> Model Class Initialized
DEBUG - 2024-02-07 09:05:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-07 09:05:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-02-07 09:05:33 --> Final output sent to browser
DEBUG - 2024-02-07 09:05:33 --> Total execution time: 0.0155
ERROR - 2024-02-07 09:05:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:05:41 --> Config Class Initialized
INFO - 2024-02-07 09:05:41 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:05:41 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:05:41 --> Utf8 Class Initialized
INFO - 2024-02-07 09:05:41 --> URI Class Initialized
INFO - 2024-02-07 09:05:41 --> Router Class Initialized
INFO - 2024-02-07 09:05:41 --> Output Class Initialized
INFO - 2024-02-07 09:05:41 --> Security Class Initialized
DEBUG - 2024-02-07 09:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:05:41 --> Input Class Initialized
INFO - 2024-02-07 09:05:41 --> Language Class Initialized
INFO - 2024-02-07 09:05:41 --> Loader Class Initialized
INFO - 2024-02-07 09:05:41 --> Helper loaded: url_helper
INFO - 2024-02-07 09:05:41 --> Helper loaded: file_helper
INFO - 2024-02-07 09:05:41 --> Helper loaded: html_helper
INFO - 2024-02-07 09:05:41 --> Helper loaded: text_helper
INFO - 2024-02-07 09:05:41 --> Helper loaded: form_helper
INFO - 2024-02-07 09:05:41 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:05:41 --> Helper loaded: security_helper
INFO - 2024-02-07 09:05:41 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:05:41 --> Database Driver Class Initialized
INFO - 2024-02-07 09:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:05:41 --> Parser Class Initialized
INFO - 2024-02-07 09:05:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:05:41 --> Pagination Class Initialized
INFO - 2024-02-07 09:05:41 --> Form Validation Class Initialized
INFO - 2024-02-07 09:05:41 --> Controller Class Initialized
INFO - 2024-02-07 09:05:41 --> Model Class Initialized
DEBUG - 2024-02-07 09:05:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-07 09:05:41 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-02-07 09:05:41 --> Final output sent to browser
DEBUG - 2024-02-07 09:05:41 --> Total execution time: 0.0155
ERROR - 2024-02-07 09:05:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:05:46 --> Config Class Initialized
INFO - 2024-02-07 09:05:46 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:05:46 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:05:46 --> Utf8 Class Initialized
INFO - 2024-02-07 09:05:46 --> URI Class Initialized
INFO - 2024-02-07 09:05:46 --> Router Class Initialized
INFO - 2024-02-07 09:05:46 --> Output Class Initialized
INFO - 2024-02-07 09:05:46 --> Security Class Initialized
DEBUG - 2024-02-07 09:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:05:46 --> Input Class Initialized
INFO - 2024-02-07 09:05:46 --> Language Class Initialized
INFO - 2024-02-07 09:05:46 --> Loader Class Initialized
INFO - 2024-02-07 09:05:46 --> Helper loaded: url_helper
INFO - 2024-02-07 09:05:46 --> Helper loaded: file_helper
INFO - 2024-02-07 09:05:46 --> Helper loaded: html_helper
INFO - 2024-02-07 09:05:46 --> Helper loaded: text_helper
INFO - 2024-02-07 09:05:46 --> Helper loaded: form_helper
INFO - 2024-02-07 09:05:46 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:05:46 --> Helper loaded: security_helper
INFO - 2024-02-07 09:05:46 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:05:46 --> Database Driver Class Initialized
INFO - 2024-02-07 09:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:05:46 --> Parser Class Initialized
INFO - 2024-02-07 09:05:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:05:46 --> Pagination Class Initialized
INFO - 2024-02-07 09:05:46 --> Form Validation Class Initialized
INFO - 2024-02-07 09:05:46 --> Controller Class Initialized
INFO - 2024-02-07 09:05:46 --> Model Class Initialized
DEBUG - 2024-02-07 09:05:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-07 09:05:46 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-02-07 09:05:46 --> Final output sent to browser
DEBUG - 2024-02-07 09:05:46 --> Total execution time: 0.0154
ERROR - 2024-02-07 09:05:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:05:49 --> Config Class Initialized
INFO - 2024-02-07 09:05:49 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:05:49 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:05:49 --> Utf8 Class Initialized
INFO - 2024-02-07 09:05:49 --> URI Class Initialized
DEBUG - 2024-02-07 09:05:49 --> No URI present. Default controller set.
INFO - 2024-02-07 09:05:49 --> Router Class Initialized
INFO - 2024-02-07 09:05:49 --> Output Class Initialized
INFO - 2024-02-07 09:05:49 --> Security Class Initialized
DEBUG - 2024-02-07 09:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:05:49 --> Input Class Initialized
INFO - 2024-02-07 09:05:49 --> Language Class Initialized
INFO - 2024-02-07 09:05:49 --> Loader Class Initialized
INFO - 2024-02-07 09:05:49 --> Helper loaded: url_helper
INFO - 2024-02-07 09:05:49 --> Helper loaded: file_helper
INFO - 2024-02-07 09:05:49 --> Helper loaded: html_helper
INFO - 2024-02-07 09:05:49 --> Helper loaded: text_helper
INFO - 2024-02-07 09:05:49 --> Helper loaded: form_helper
INFO - 2024-02-07 09:05:49 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:05:49 --> Helper loaded: security_helper
INFO - 2024-02-07 09:05:49 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:05:49 --> Database Driver Class Initialized
INFO - 2024-02-07 09:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:05:49 --> Parser Class Initialized
INFO - 2024-02-07 09:05:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:05:49 --> Pagination Class Initialized
INFO - 2024-02-07 09:05:49 --> Form Validation Class Initialized
INFO - 2024-02-07 09:05:49 --> Controller Class Initialized
INFO - 2024-02-07 09:05:49 --> Model Class Initialized
DEBUG - 2024-02-07 09:05:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:05:49 --> Model Class Initialized
DEBUG - 2024-02-07 09:05:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:05:49 --> Model Class Initialized
INFO - 2024-02-07 09:05:49 --> Model Class Initialized
INFO - 2024-02-07 09:05:49 --> Model Class Initialized
INFO - 2024-02-07 09:05:49 --> Model Class Initialized
DEBUG - 2024-02-07 09:05:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 09:05:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:05:49 --> Model Class Initialized
INFO - 2024-02-07 09:05:49 --> Model Class Initialized
INFO - 2024-02-07 09:05:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-07 09:05:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:05:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 09:05:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 09:05:49 --> Model Class Initialized
INFO - 2024-02-07 09:05:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 09:05:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 09:05:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 09:05:49 --> Final output sent to browser
DEBUG - 2024-02-07 09:05:49 --> Total execution time: 0.2200
ERROR - 2024-02-07 09:06:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:06:12 --> Config Class Initialized
INFO - 2024-02-07 09:06:12 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:06:12 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:06:12 --> Utf8 Class Initialized
INFO - 2024-02-07 09:06:12 --> URI Class Initialized
INFO - 2024-02-07 09:06:12 --> Router Class Initialized
INFO - 2024-02-07 09:06:12 --> Output Class Initialized
INFO - 2024-02-07 09:06:12 --> Security Class Initialized
DEBUG - 2024-02-07 09:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:06:12 --> Input Class Initialized
INFO - 2024-02-07 09:06:12 --> Language Class Initialized
INFO - 2024-02-07 09:06:12 --> Loader Class Initialized
INFO - 2024-02-07 09:06:12 --> Helper loaded: url_helper
INFO - 2024-02-07 09:06:12 --> Helper loaded: file_helper
INFO - 2024-02-07 09:06:12 --> Helper loaded: html_helper
INFO - 2024-02-07 09:06:12 --> Helper loaded: text_helper
INFO - 2024-02-07 09:06:12 --> Helper loaded: form_helper
INFO - 2024-02-07 09:06:12 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:06:12 --> Helper loaded: security_helper
INFO - 2024-02-07 09:06:12 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:06:12 --> Database Driver Class Initialized
INFO - 2024-02-07 09:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:06:12 --> Parser Class Initialized
INFO - 2024-02-07 09:06:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:06:12 --> Pagination Class Initialized
INFO - 2024-02-07 09:06:12 --> Form Validation Class Initialized
INFO - 2024-02-07 09:06:12 --> Controller Class Initialized
DEBUG - 2024-02-07 09:06:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 09:06:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:06:12 --> Model Class Initialized
DEBUG - 2024-02-07 09:06:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:06:12 --> Model Class Initialized
DEBUG - 2024-02-07 09:06:12 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:06:12 --> Model Class Initialized
INFO - 2024-02-07 09:06:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-07 09:06:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:06:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 09:06:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 09:06:12 --> Model Class Initialized
INFO - 2024-02-07 09:06:12 --> Model Class Initialized
INFO - 2024-02-07 09:06:12 --> Model Class Initialized
INFO - 2024-02-07 09:06:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 09:06:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 09:06:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 09:06:13 --> Final output sent to browser
DEBUG - 2024-02-07 09:06:13 --> Total execution time: 0.1699
ERROR - 2024-02-07 09:06:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:06:13 --> Config Class Initialized
INFO - 2024-02-07 09:06:13 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:06:13 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:06:13 --> Utf8 Class Initialized
INFO - 2024-02-07 09:06:13 --> URI Class Initialized
INFO - 2024-02-07 09:06:13 --> Router Class Initialized
INFO - 2024-02-07 09:06:13 --> Output Class Initialized
INFO - 2024-02-07 09:06:13 --> Security Class Initialized
DEBUG - 2024-02-07 09:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:06:13 --> Input Class Initialized
INFO - 2024-02-07 09:06:13 --> Language Class Initialized
INFO - 2024-02-07 09:06:13 --> Loader Class Initialized
INFO - 2024-02-07 09:06:13 --> Helper loaded: url_helper
INFO - 2024-02-07 09:06:13 --> Helper loaded: file_helper
INFO - 2024-02-07 09:06:13 --> Helper loaded: html_helper
INFO - 2024-02-07 09:06:13 --> Helper loaded: text_helper
INFO - 2024-02-07 09:06:13 --> Helper loaded: form_helper
INFO - 2024-02-07 09:06:13 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:06:13 --> Helper loaded: security_helper
INFO - 2024-02-07 09:06:13 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:06:13 --> Database Driver Class Initialized
INFO - 2024-02-07 09:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:06:13 --> Parser Class Initialized
INFO - 2024-02-07 09:06:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:06:13 --> Pagination Class Initialized
INFO - 2024-02-07 09:06:13 --> Form Validation Class Initialized
INFO - 2024-02-07 09:06:13 --> Controller Class Initialized
DEBUG - 2024-02-07 09:06:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 09:06:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:06:13 --> Model Class Initialized
DEBUG - 2024-02-07 09:06:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:06:13 --> Model Class Initialized
INFO - 2024-02-07 09:06:14 --> Final output sent to browser
DEBUG - 2024-02-07 09:06:14 --> Total execution time: 0.0300
ERROR - 2024-02-07 09:06:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:06:22 --> Config Class Initialized
INFO - 2024-02-07 09:06:22 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:06:22 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:06:22 --> Utf8 Class Initialized
INFO - 2024-02-07 09:06:22 --> URI Class Initialized
INFO - 2024-02-07 09:06:22 --> Router Class Initialized
INFO - 2024-02-07 09:06:22 --> Output Class Initialized
INFO - 2024-02-07 09:06:22 --> Security Class Initialized
DEBUG - 2024-02-07 09:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:06:22 --> Input Class Initialized
INFO - 2024-02-07 09:06:22 --> Language Class Initialized
INFO - 2024-02-07 09:06:22 --> Loader Class Initialized
INFO - 2024-02-07 09:06:22 --> Helper loaded: url_helper
INFO - 2024-02-07 09:06:22 --> Helper loaded: file_helper
INFO - 2024-02-07 09:06:22 --> Helper loaded: html_helper
INFO - 2024-02-07 09:06:22 --> Helper loaded: text_helper
INFO - 2024-02-07 09:06:22 --> Helper loaded: form_helper
INFO - 2024-02-07 09:06:22 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:06:22 --> Helper loaded: security_helper
INFO - 2024-02-07 09:06:22 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:06:22 --> Database Driver Class Initialized
INFO - 2024-02-07 09:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:06:22 --> Parser Class Initialized
INFO - 2024-02-07 09:06:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:06:22 --> Pagination Class Initialized
INFO - 2024-02-07 09:06:22 --> Form Validation Class Initialized
INFO - 2024-02-07 09:06:22 --> Controller Class Initialized
DEBUG - 2024-02-07 09:06:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 09:06:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:06:22 --> Model Class Initialized
DEBUG - 2024-02-07 09:06:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:06:22 --> Model Class Initialized
INFO - 2024-02-07 09:06:22 --> Final output sent to browser
DEBUG - 2024-02-07 09:06:22 --> Total execution time: 0.0264
ERROR - 2024-02-07 09:07:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:07:00 --> Config Class Initialized
INFO - 2024-02-07 09:07:00 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:07:00 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:07:00 --> Utf8 Class Initialized
INFO - 2024-02-07 09:07:00 --> URI Class Initialized
DEBUG - 2024-02-07 09:07:00 --> No URI present. Default controller set.
INFO - 2024-02-07 09:07:00 --> Router Class Initialized
INFO - 2024-02-07 09:07:00 --> Output Class Initialized
INFO - 2024-02-07 09:07:00 --> Security Class Initialized
DEBUG - 2024-02-07 09:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:07:00 --> Input Class Initialized
INFO - 2024-02-07 09:07:00 --> Language Class Initialized
INFO - 2024-02-07 09:07:00 --> Loader Class Initialized
INFO - 2024-02-07 09:07:00 --> Helper loaded: url_helper
INFO - 2024-02-07 09:07:00 --> Helper loaded: file_helper
INFO - 2024-02-07 09:07:00 --> Helper loaded: html_helper
INFO - 2024-02-07 09:07:00 --> Helper loaded: text_helper
INFO - 2024-02-07 09:07:00 --> Helper loaded: form_helper
INFO - 2024-02-07 09:07:00 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:07:00 --> Helper loaded: security_helper
INFO - 2024-02-07 09:07:00 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:07:00 --> Database Driver Class Initialized
INFO - 2024-02-07 09:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:07:00 --> Parser Class Initialized
INFO - 2024-02-07 09:07:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:07:00 --> Pagination Class Initialized
INFO - 2024-02-07 09:07:00 --> Form Validation Class Initialized
INFO - 2024-02-07 09:07:00 --> Controller Class Initialized
INFO - 2024-02-07 09:07:00 --> Model Class Initialized
DEBUG - 2024-02-07 09:07:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:07:00 --> Model Class Initialized
DEBUG - 2024-02-07 09:07:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:07:00 --> Model Class Initialized
INFO - 2024-02-07 09:07:00 --> Model Class Initialized
INFO - 2024-02-07 09:07:00 --> Model Class Initialized
INFO - 2024-02-07 09:07:00 --> Model Class Initialized
DEBUG - 2024-02-07 09:07:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 09:07:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:07:00 --> Model Class Initialized
INFO - 2024-02-07 09:07:00 --> Model Class Initialized
INFO - 2024-02-07 09:07:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-07 09:07:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:07:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 09:07:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 09:07:00 --> Model Class Initialized
INFO - 2024-02-07 09:07:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 09:07:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 09:07:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 09:07:00 --> Final output sent to browser
DEBUG - 2024-02-07 09:07:00 --> Total execution time: 0.2278
ERROR - 2024-02-07 09:07:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:07:07 --> Config Class Initialized
INFO - 2024-02-07 09:07:07 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:07:07 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:07:07 --> Utf8 Class Initialized
INFO - 2024-02-07 09:07:07 --> URI Class Initialized
INFO - 2024-02-07 09:07:07 --> Router Class Initialized
INFO - 2024-02-07 09:07:07 --> Output Class Initialized
INFO - 2024-02-07 09:07:07 --> Security Class Initialized
DEBUG - 2024-02-07 09:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:07:07 --> Input Class Initialized
INFO - 2024-02-07 09:07:07 --> Language Class Initialized
INFO - 2024-02-07 09:07:07 --> Loader Class Initialized
INFO - 2024-02-07 09:07:07 --> Helper loaded: url_helper
INFO - 2024-02-07 09:07:07 --> Helper loaded: file_helper
INFO - 2024-02-07 09:07:07 --> Helper loaded: html_helper
INFO - 2024-02-07 09:07:07 --> Helper loaded: text_helper
INFO - 2024-02-07 09:07:07 --> Helper loaded: form_helper
INFO - 2024-02-07 09:07:07 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:07:07 --> Helper loaded: security_helper
INFO - 2024-02-07 09:07:07 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:07:07 --> Database Driver Class Initialized
INFO - 2024-02-07 09:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:07:07 --> Parser Class Initialized
INFO - 2024-02-07 09:07:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:07:07 --> Pagination Class Initialized
INFO - 2024-02-07 09:07:07 --> Form Validation Class Initialized
INFO - 2024-02-07 09:07:07 --> Controller Class Initialized
INFO - 2024-02-07 09:07:07 --> Model Class Initialized
DEBUG - 2024-02-07 09:07:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 09:07:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:07:07 --> Model Class Initialized
DEBUG - 2024-02-07 09:07:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:07:07 --> Model Class Initialized
INFO - 2024-02-07 09:07:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-02-07 09:07:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:07:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 09:07:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 09:07:07 --> Model Class Initialized
INFO - 2024-02-07 09:07:07 --> Model Class Initialized
INFO - 2024-02-07 09:07:07 --> Model Class Initialized
INFO - 2024-02-07 09:07:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 09:07:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 09:07:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 09:07:08 --> Final output sent to browser
DEBUG - 2024-02-07 09:07:08 --> Total execution time: 0.1780
ERROR - 2024-02-07 09:07:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:07:17 --> Config Class Initialized
INFO - 2024-02-07 09:07:17 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:07:17 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:07:17 --> Utf8 Class Initialized
INFO - 2024-02-07 09:07:17 --> URI Class Initialized
INFO - 2024-02-07 09:07:17 --> Router Class Initialized
INFO - 2024-02-07 09:07:17 --> Output Class Initialized
INFO - 2024-02-07 09:07:17 --> Security Class Initialized
DEBUG - 2024-02-07 09:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:07:17 --> Input Class Initialized
INFO - 2024-02-07 09:07:17 --> Language Class Initialized
INFO - 2024-02-07 09:07:17 --> Loader Class Initialized
INFO - 2024-02-07 09:07:17 --> Helper loaded: url_helper
INFO - 2024-02-07 09:07:17 --> Helper loaded: file_helper
INFO - 2024-02-07 09:07:17 --> Helper loaded: html_helper
INFO - 2024-02-07 09:07:17 --> Helper loaded: text_helper
INFO - 2024-02-07 09:07:17 --> Helper loaded: form_helper
INFO - 2024-02-07 09:07:17 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:07:17 --> Helper loaded: security_helper
INFO - 2024-02-07 09:07:17 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:07:17 --> Database Driver Class Initialized
INFO - 2024-02-07 09:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:07:17 --> Parser Class Initialized
INFO - 2024-02-07 09:07:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:07:17 --> Pagination Class Initialized
INFO - 2024-02-07 09:07:17 --> Form Validation Class Initialized
INFO - 2024-02-07 09:07:17 --> Controller Class Initialized
INFO - 2024-02-07 09:07:17 --> Model Class Initialized
DEBUG - 2024-02-07 09:07:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:07:17 --> Final output sent to browser
DEBUG - 2024-02-07 09:07:17 --> Total execution time: 0.0171
ERROR - 2024-02-07 09:07:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:07:18 --> Config Class Initialized
INFO - 2024-02-07 09:07:18 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:07:18 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:07:18 --> Utf8 Class Initialized
INFO - 2024-02-07 09:07:18 --> URI Class Initialized
INFO - 2024-02-07 09:07:18 --> Router Class Initialized
INFO - 2024-02-07 09:07:18 --> Output Class Initialized
INFO - 2024-02-07 09:07:18 --> Security Class Initialized
DEBUG - 2024-02-07 09:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:07:18 --> Input Class Initialized
INFO - 2024-02-07 09:07:18 --> Language Class Initialized
INFO - 2024-02-07 09:07:18 --> Loader Class Initialized
INFO - 2024-02-07 09:07:18 --> Helper loaded: url_helper
INFO - 2024-02-07 09:07:18 --> Helper loaded: file_helper
INFO - 2024-02-07 09:07:18 --> Helper loaded: html_helper
INFO - 2024-02-07 09:07:18 --> Helper loaded: text_helper
INFO - 2024-02-07 09:07:18 --> Helper loaded: form_helper
INFO - 2024-02-07 09:07:18 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:07:18 --> Helper loaded: security_helper
INFO - 2024-02-07 09:07:18 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:07:18 --> Database Driver Class Initialized
INFO - 2024-02-07 09:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:07:18 --> Parser Class Initialized
INFO - 2024-02-07 09:07:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:07:18 --> Pagination Class Initialized
INFO - 2024-02-07 09:07:18 --> Form Validation Class Initialized
INFO - 2024-02-07 09:07:18 --> Controller Class Initialized
INFO - 2024-02-07 09:07:18 --> Model Class Initialized
DEBUG - 2024-02-07 09:07:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-07 09:07:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-02-07 09:07:18 --> Final output sent to browser
DEBUG - 2024-02-07 09:07:18 --> Total execution time: 0.0164
ERROR - 2024-02-07 09:07:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:07:21 --> Config Class Initialized
INFO - 2024-02-07 09:07:21 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:07:21 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:07:21 --> Utf8 Class Initialized
INFO - 2024-02-07 09:07:21 --> URI Class Initialized
INFO - 2024-02-07 09:07:21 --> Router Class Initialized
INFO - 2024-02-07 09:07:21 --> Output Class Initialized
INFO - 2024-02-07 09:07:21 --> Security Class Initialized
DEBUG - 2024-02-07 09:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:07:21 --> Input Class Initialized
INFO - 2024-02-07 09:07:21 --> Language Class Initialized
INFO - 2024-02-07 09:07:21 --> Loader Class Initialized
INFO - 2024-02-07 09:07:21 --> Helper loaded: url_helper
INFO - 2024-02-07 09:07:21 --> Helper loaded: file_helper
INFO - 2024-02-07 09:07:21 --> Helper loaded: html_helper
INFO - 2024-02-07 09:07:21 --> Helper loaded: text_helper
INFO - 2024-02-07 09:07:21 --> Helper loaded: form_helper
INFO - 2024-02-07 09:07:21 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:07:21 --> Helper loaded: security_helper
INFO - 2024-02-07 09:07:21 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:07:21 --> Database Driver Class Initialized
INFO - 2024-02-07 09:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:07:21 --> Parser Class Initialized
INFO - 2024-02-07 09:07:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:07:21 --> Pagination Class Initialized
INFO - 2024-02-07 09:07:21 --> Form Validation Class Initialized
INFO - 2024-02-07 09:07:21 --> Controller Class Initialized
INFO - 2024-02-07 09:07:21 --> Model Class Initialized
DEBUG - 2024-02-07 09:07:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-07 09:07:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-02-07 09:07:21 --> Final output sent to browser
DEBUG - 2024-02-07 09:07:21 --> Total execution time: 0.0168
ERROR - 2024-02-07 09:07:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:07:22 --> Config Class Initialized
INFO - 2024-02-07 09:07:22 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:07:22 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:07:22 --> Utf8 Class Initialized
INFO - 2024-02-07 09:07:22 --> URI Class Initialized
INFO - 2024-02-07 09:07:22 --> Router Class Initialized
INFO - 2024-02-07 09:07:22 --> Output Class Initialized
INFO - 2024-02-07 09:07:22 --> Security Class Initialized
DEBUG - 2024-02-07 09:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:07:22 --> Input Class Initialized
INFO - 2024-02-07 09:07:22 --> Language Class Initialized
INFO - 2024-02-07 09:07:22 --> Loader Class Initialized
INFO - 2024-02-07 09:07:22 --> Helper loaded: url_helper
INFO - 2024-02-07 09:07:22 --> Helper loaded: file_helper
INFO - 2024-02-07 09:07:22 --> Helper loaded: html_helper
INFO - 2024-02-07 09:07:22 --> Helper loaded: text_helper
INFO - 2024-02-07 09:07:22 --> Helper loaded: form_helper
INFO - 2024-02-07 09:07:22 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:07:22 --> Helper loaded: security_helper
INFO - 2024-02-07 09:07:22 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:07:22 --> Database Driver Class Initialized
INFO - 2024-02-07 09:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:07:22 --> Parser Class Initialized
INFO - 2024-02-07 09:07:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:07:22 --> Pagination Class Initialized
INFO - 2024-02-07 09:07:22 --> Form Validation Class Initialized
INFO - 2024-02-07 09:07:22 --> Controller Class Initialized
INFO - 2024-02-07 09:07:22 --> Model Class Initialized
DEBUG - 2024-02-07 09:07:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-07 09:07:22 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-02-07 09:07:22 --> Final output sent to browser
DEBUG - 2024-02-07 09:07:22 --> Total execution time: 0.0198
ERROR - 2024-02-07 09:07:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:07:23 --> Config Class Initialized
INFO - 2024-02-07 09:07:23 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:07:23 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:07:23 --> Utf8 Class Initialized
INFO - 2024-02-07 09:07:23 --> URI Class Initialized
INFO - 2024-02-07 09:07:23 --> Router Class Initialized
INFO - 2024-02-07 09:07:23 --> Output Class Initialized
INFO - 2024-02-07 09:07:23 --> Security Class Initialized
DEBUG - 2024-02-07 09:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:07:23 --> Input Class Initialized
INFO - 2024-02-07 09:07:23 --> Language Class Initialized
INFO - 2024-02-07 09:07:23 --> Loader Class Initialized
INFO - 2024-02-07 09:07:23 --> Helper loaded: url_helper
INFO - 2024-02-07 09:07:23 --> Helper loaded: file_helper
INFO - 2024-02-07 09:07:23 --> Helper loaded: html_helper
INFO - 2024-02-07 09:07:23 --> Helper loaded: text_helper
INFO - 2024-02-07 09:07:23 --> Helper loaded: form_helper
INFO - 2024-02-07 09:07:23 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:07:23 --> Helper loaded: security_helper
INFO - 2024-02-07 09:07:23 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:07:23 --> Database Driver Class Initialized
INFO - 2024-02-07 09:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:07:23 --> Parser Class Initialized
INFO - 2024-02-07 09:07:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:07:23 --> Pagination Class Initialized
INFO - 2024-02-07 09:07:23 --> Form Validation Class Initialized
INFO - 2024-02-07 09:07:23 --> Controller Class Initialized
INFO - 2024-02-07 09:07:23 --> Model Class Initialized
DEBUG - 2024-02-07 09:07:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-07 09:07:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-02-07 09:07:23 --> Final output sent to browser
DEBUG - 2024-02-07 09:07:23 --> Total execution time: 0.0159
ERROR - 2024-02-07 09:07:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:07:27 --> Config Class Initialized
INFO - 2024-02-07 09:07:27 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:07:27 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:07:27 --> Utf8 Class Initialized
INFO - 2024-02-07 09:07:27 --> URI Class Initialized
INFO - 2024-02-07 09:07:27 --> Router Class Initialized
INFO - 2024-02-07 09:07:27 --> Output Class Initialized
INFO - 2024-02-07 09:07:27 --> Security Class Initialized
DEBUG - 2024-02-07 09:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:07:27 --> Input Class Initialized
INFO - 2024-02-07 09:07:27 --> Language Class Initialized
INFO - 2024-02-07 09:07:27 --> Loader Class Initialized
INFO - 2024-02-07 09:07:27 --> Helper loaded: url_helper
INFO - 2024-02-07 09:07:27 --> Helper loaded: file_helper
INFO - 2024-02-07 09:07:27 --> Helper loaded: html_helper
INFO - 2024-02-07 09:07:27 --> Helper loaded: text_helper
INFO - 2024-02-07 09:07:27 --> Helper loaded: form_helper
INFO - 2024-02-07 09:07:27 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:07:27 --> Helper loaded: security_helper
INFO - 2024-02-07 09:07:27 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:07:27 --> Database Driver Class Initialized
INFO - 2024-02-07 09:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:07:27 --> Parser Class Initialized
INFO - 2024-02-07 09:07:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:07:27 --> Pagination Class Initialized
INFO - 2024-02-07 09:07:27 --> Form Validation Class Initialized
INFO - 2024-02-07 09:07:27 --> Controller Class Initialized
INFO - 2024-02-07 09:07:27 --> Model Class Initialized
DEBUG - 2024-02-07 09:07:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-07 09:07:27 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-02-07 09:07:27 --> Final output sent to browser
DEBUG - 2024-02-07 09:07:27 --> Total execution time: 0.0153
ERROR - 2024-02-07 09:07:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:07:28 --> Config Class Initialized
INFO - 2024-02-07 09:07:28 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:07:28 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:07:28 --> Utf8 Class Initialized
INFO - 2024-02-07 09:07:28 --> URI Class Initialized
INFO - 2024-02-07 09:07:28 --> Router Class Initialized
INFO - 2024-02-07 09:07:28 --> Output Class Initialized
INFO - 2024-02-07 09:07:28 --> Security Class Initialized
DEBUG - 2024-02-07 09:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:07:28 --> Input Class Initialized
INFO - 2024-02-07 09:07:28 --> Language Class Initialized
INFO - 2024-02-07 09:07:28 --> Loader Class Initialized
INFO - 2024-02-07 09:07:28 --> Helper loaded: url_helper
INFO - 2024-02-07 09:07:28 --> Helper loaded: file_helper
INFO - 2024-02-07 09:07:28 --> Helper loaded: html_helper
INFO - 2024-02-07 09:07:28 --> Helper loaded: text_helper
INFO - 2024-02-07 09:07:28 --> Helper loaded: form_helper
INFO - 2024-02-07 09:07:28 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:07:28 --> Helper loaded: security_helper
INFO - 2024-02-07 09:07:28 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:07:28 --> Database Driver Class Initialized
INFO - 2024-02-07 09:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:07:28 --> Parser Class Initialized
INFO - 2024-02-07 09:07:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:07:28 --> Pagination Class Initialized
INFO - 2024-02-07 09:07:28 --> Form Validation Class Initialized
INFO - 2024-02-07 09:07:28 --> Controller Class Initialized
INFO - 2024-02-07 09:07:28 --> Model Class Initialized
DEBUG - 2024-02-07 09:07:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-07 09:07:28 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-02-07 09:07:28 --> Final output sent to browser
DEBUG - 2024-02-07 09:07:28 --> Total execution time: 0.0158
ERROR - 2024-02-07 09:07:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:07:30 --> Config Class Initialized
INFO - 2024-02-07 09:07:30 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:07:30 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:07:30 --> Utf8 Class Initialized
INFO - 2024-02-07 09:07:30 --> URI Class Initialized
INFO - 2024-02-07 09:07:30 --> Router Class Initialized
INFO - 2024-02-07 09:07:30 --> Output Class Initialized
INFO - 2024-02-07 09:07:30 --> Security Class Initialized
DEBUG - 2024-02-07 09:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:07:30 --> Input Class Initialized
INFO - 2024-02-07 09:07:30 --> Language Class Initialized
INFO - 2024-02-07 09:07:30 --> Loader Class Initialized
INFO - 2024-02-07 09:07:30 --> Helper loaded: url_helper
INFO - 2024-02-07 09:07:30 --> Helper loaded: file_helper
INFO - 2024-02-07 09:07:30 --> Helper loaded: html_helper
INFO - 2024-02-07 09:07:30 --> Helper loaded: text_helper
INFO - 2024-02-07 09:07:30 --> Helper loaded: form_helper
INFO - 2024-02-07 09:07:30 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:07:30 --> Helper loaded: security_helper
INFO - 2024-02-07 09:07:30 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:07:30 --> Database Driver Class Initialized
INFO - 2024-02-07 09:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:07:30 --> Parser Class Initialized
INFO - 2024-02-07 09:07:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:07:30 --> Pagination Class Initialized
INFO - 2024-02-07 09:07:30 --> Form Validation Class Initialized
INFO - 2024-02-07 09:07:30 --> Controller Class Initialized
INFO - 2024-02-07 09:07:30 --> Model Class Initialized
DEBUG - 2024-02-07 09:07:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-07 09:07:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-02-07 09:07:30 --> Final output sent to browser
DEBUG - 2024-02-07 09:07:30 --> Total execution time: 0.0151
ERROR - 2024-02-07 09:07:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:07:31 --> Config Class Initialized
INFO - 2024-02-07 09:07:31 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:07:31 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:07:31 --> Utf8 Class Initialized
INFO - 2024-02-07 09:07:31 --> URI Class Initialized
INFO - 2024-02-07 09:07:31 --> Router Class Initialized
INFO - 2024-02-07 09:07:31 --> Output Class Initialized
INFO - 2024-02-07 09:07:31 --> Security Class Initialized
DEBUG - 2024-02-07 09:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:07:31 --> Input Class Initialized
INFO - 2024-02-07 09:07:31 --> Language Class Initialized
INFO - 2024-02-07 09:07:31 --> Loader Class Initialized
INFO - 2024-02-07 09:07:31 --> Helper loaded: url_helper
INFO - 2024-02-07 09:07:31 --> Helper loaded: file_helper
INFO - 2024-02-07 09:07:31 --> Helper loaded: html_helper
INFO - 2024-02-07 09:07:31 --> Helper loaded: text_helper
INFO - 2024-02-07 09:07:31 --> Helper loaded: form_helper
INFO - 2024-02-07 09:07:31 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:07:31 --> Helper loaded: security_helper
INFO - 2024-02-07 09:07:31 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:07:31 --> Database Driver Class Initialized
INFO - 2024-02-07 09:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:07:31 --> Parser Class Initialized
INFO - 2024-02-07 09:07:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:07:31 --> Pagination Class Initialized
INFO - 2024-02-07 09:07:31 --> Form Validation Class Initialized
INFO - 2024-02-07 09:07:31 --> Controller Class Initialized
INFO - 2024-02-07 09:07:31 --> Model Class Initialized
DEBUG - 2024-02-07 09:07:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-07 09:07:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-02-07 09:07:31 --> Final output sent to browser
DEBUG - 2024-02-07 09:07:31 --> Total execution time: 0.0156
ERROR - 2024-02-07 09:07:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:07:32 --> Config Class Initialized
INFO - 2024-02-07 09:07:32 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:07:32 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:07:32 --> Utf8 Class Initialized
INFO - 2024-02-07 09:07:32 --> URI Class Initialized
INFO - 2024-02-07 09:07:32 --> Router Class Initialized
INFO - 2024-02-07 09:07:32 --> Output Class Initialized
INFO - 2024-02-07 09:07:32 --> Security Class Initialized
DEBUG - 2024-02-07 09:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:07:32 --> Input Class Initialized
INFO - 2024-02-07 09:07:32 --> Language Class Initialized
INFO - 2024-02-07 09:07:32 --> Loader Class Initialized
INFO - 2024-02-07 09:07:32 --> Helper loaded: url_helper
INFO - 2024-02-07 09:07:32 --> Helper loaded: file_helper
INFO - 2024-02-07 09:07:32 --> Helper loaded: html_helper
INFO - 2024-02-07 09:07:32 --> Helper loaded: text_helper
INFO - 2024-02-07 09:07:32 --> Helper loaded: form_helper
INFO - 2024-02-07 09:07:32 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:07:32 --> Helper loaded: security_helper
INFO - 2024-02-07 09:07:32 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:07:32 --> Database Driver Class Initialized
INFO - 2024-02-07 09:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:07:32 --> Parser Class Initialized
INFO - 2024-02-07 09:07:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:07:32 --> Pagination Class Initialized
INFO - 2024-02-07 09:07:32 --> Form Validation Class Initialized
INFO - 2024-02-07 09:07:32 --> Controller Class Initialized
INFO - 2024-02-07 09:07:32 --> Model Class Initialized
DEBUG - 2024-02-07 09:07:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:07:32 --> Final output sent to browser
DEBUG - 2024-02-07 09:07:32 --> Total execution time: 0.0155
ERROR - 2024-02-07 09:07:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:07:57 --> Config Class Initialized
INFO - 2024-02-07 09:07:57 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:07:57 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:07:57 --> Utf8 Class Initialized
INFO - 2024-02-07 09:07:57 --> URI Class Initialized
DEBUG - 2024-02-07 09:07:57 --> No URI present. Default controller set.
INFO - 2024-02-07 09:07:57 --> Router Class Initialized
INFO - 2024-02-07 09:07:57 --> Output Class Initialized
INFO - 2024-02-07 09:07:57 --> Security Class Initialized
DEBUG - 2024-02-07 09:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:07:57 --> Input Class Initialized
INFO - 2024-02-07 09:07:57 --> Language Class Initialized
INFO - 2024-02-07 09:07:57 --> Loader Class Initialized
INFO - 2024-02-07 09:07:57 --> Helper loaded: url_helper
INFO - 2024-02-07 09:07:57 --> Helper loaded: file_helper
INFO - 2024-02-07 09:07:57 --> Helper loaded: html_helper
INFO - 2024-02-07 09:07:57 --> Helper loaded: text_helper
INFO - 2024-02-07 09:07:57 --> Helper loaded: form_helper
INFO - 2024-02-07 09:07:57 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:07:57 --> Helper loaded: security_helper
INFO - 2024-02-07 09:07:57 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:07:57 --> Database Driver Class Initialized
INFO - 2024-02-07 09:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:07:57 --> Parser Class Initialized
INFO - 2024-02-07 09:07:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:07:57 --> Pagination Class Initialized
INFO - 2024-02-07 09:07:57 --> Form Validation Class Initialized
INFO - 2024-02-07 09:07:57 --> Controller Class Initialized
INFO - 2024-02-07 09:07:57 --> Model Class Initialized
DEBUG - 2024-02-07 09:07:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:07:57 --> Model Class Initialized
DEBUG - 2024-02-07 09:07:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:07:57 --> Model Class Initialized
INFO - 2024-02-07 09:07:57 --> Model Class Initialized
INFO - 2024-02-07 09:07:57 --> Model Class Initialized
INFO - 2024-02-07 09:07:57 --> Model Class Initialized
DEBUG - 2024-02-07 09:07:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 09:07:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:07:57 --> Model Class Initialized
INFO - 2024-02-07 09:07:57 --> Model Class Initialized
INFO - 2024-02-07 09:07:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-07 09:07:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:07:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 09:07:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 09:07:57 --> Model Class Initialized
INFO - 2024-02-07 09:07:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 09:07:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 09:07:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 09:07:57 --> Final output sent to browser
DEBUG - 2024-02-07 09:07:57 --> Total execution time: 0.2345
ERROR - 2024-02-07 09:08:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:08:01 --> Config Class Initialized
INFO - 2024-02-07 09:08:01 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:08:01 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:08:01 --> Utf8 Class Initialized
INFO - 2024-02-07 09:08:01 --> URI Class Initialized
INFO - 2024-02-07 09:08:01 --> Router Class Initialized
INFO - 2024-02-07 09:08:01 --> Output Class Initialized
INFO - 2024-02-07 09:08:01 --> Security Class Initialized
DEBUG - 2024-02-07 09:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:08:01 --> Input Class Initialized
INFO - 2024-02-07 09:08:01 --> Language Class Initialized
INFO - 2024-02-07 09:08:01 --> Loader Class Initialized
INFO - 2024-02-07 09:08:01 --> Helper loaded: url_helper
INFO - 2024-02-07 09:08:01 --> Helper loaded: file_helper
INFO - 2024-02-07 09:08:01 --> Helper loaded: html_helper
INFO - 2024-02-07 09:08:01 --> Helper loaded: text_helper
INFO - 2024-02-07 09:08:01 --> Helper loaded: form_helper
INFO - 2024-02-07 09:08:01 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:08:01 --> Helper loaded: security_helper
INFO - 2024-02-07 09:08:01 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:08:01 --> Database Driver Class Initialized
INFO - 2024-02-07 09:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:08:01 --> Parser Class Initialized
INFO - 2024-02-07 09:08:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:08:01 --> Pagination Class Initialized
INFO - 2024-02-07 09:08:01 --> Form Validation Class Initialized
INFO - 2024-02-07 09:08:01 --> Controller Class Initialized
INFO - 2024-02-07 09:08:01 --> Model Class Initialized
DEBUG - 2024-02-07 09:08:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 09:08:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:08:01 --> Model Class Initialized
DEBUG - 2024-02-07 09:08:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:08:01 --> Model Class Initialized
INFO - 2024-02-07 09:08:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-02-07 09:08:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:08:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 09:08:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 09:08:01 --> Model Class Initialized
INFO - 2024-02-07 09:08:01 --> Model Class Initialized
INFO - 2024-02-07 09:08:01 --> Model Class Initialized
INFO - 2024-02-07 09:08:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 09:08:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 09:08:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 09:08:01 --> Final output sent to browser
DEBUG - 2024-02-07 09:08:01 --> Total execution time: 0.1897
ERROR - 2024-02-07 09:08:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:08:34 --> Config Class Initialized
INFO - 2024-02-07 09:08:34 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:08:34 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:08:34 --> Utf8 Class Initialized
INFO - 2024-02-07 09:08:34 --> URI Class Initialized
INFO - 2024-02-07 09:08:34 --> Router Class Initialized
INFO - 2024-02-07 09:08:34 --> Output Class Initialized
INFO - 2024-02-07 09:08:34 --> Security Class Initialized
DEBUG - 2024-02-07 09:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:08:34 --> Input Class Initialized
INFO - 2024-02-07 09:08:34 --> Language Class Initialized
INFO - 2024-02-07 09:08:34 --> Loader Class Initialized
INFO - 2024-02-07 09:08:34 --> Helper loaded: url_helper
INFO - 2024-02-07 09:08:34 --> Helper loaded: file_helper
INFO - 2024-02-07 09:08:34 --> Helper loaded: html_helper
INFO - 2024-02-07 09:08:34 --> Helper loaded: text_helper
INFO - 2024-02-07 09:08:34 --> Helper loaded: form_helper
INFO - 2024-02-07 09:08:34 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:08:34 --> Helper loaded: security_helper
INFO - 2024-02-07 09:08:34 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:08:34 --> Database Driver Class Initialized
INFO - 2024-02-07 09:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:08:34 --> Parser Class Initialized
INFO - 2024-02-07 09:08:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:08:34 --> Pagination Class Initialized
INFO - 2024-02-07 09:08:34 --> Form Validation Class Initialized
INFO - 2024-02-07 09:08:34 --> Controller Class Initialized
INFO - 2024-02-07 09:08:34 --> Model Class Initialized
DEBUG - 2024-02-07 09:08:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:08:34 --> Final output sent to browser
DEBUG - 2024-02-07 09:08:34 --> Total execution time: 0.0187
ERROR - 2024-02-07 09:08:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:08:35 --> Config Class Initialized
INFO - 2024-02-07 09:08:35 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:08:35 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:08:35 --> Utf8 Class Initialized
INFO - 2024-02-07 09:08:35 --> URI Class Initialized
INFO - 2024-02-07 09:08:35 --> Router Class Initialized
INFO - 2024-02-07 09:08:35 --> Output Class Initialized
INFO - 2024-02-07 09:08:35 --> Security Class Initialized
DEBUG - 2024-02-07 09:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:08:35 --> Input Class Initialized
INFO - 2024-02-07 09:08:35 --> Language Class Initialized
INFO - 2024-02-07 09:08:35 --> Loader Class Initialized
INFO - 2024-02-07 09:08:35 --> Helper loaded: url_helper
INFO - 2024-02-07 09:08:35 --> Helper loaded: file_helper
INFO - 2024-02-07 09:08:35 --> Helper loaded: html_helper
INFO - 2024-02-07 09:08:35 --> Helper loaded: text_helper
INFO - 2024-02-07 09:08:35 --> Helper loaded: form_helper
INFO - 2024-02-07 09:08:35 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:08:35 --> Helper loaded: security_helper
INFO - 2024-02-07 09:08:35 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:08:35 --> Database Driver Class Initialized
INFO - 2024-02-07 09:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:08:35 --> Parser Class Initialized
INFO - 2024-02-07 09:08:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:08:35 --> Pagination Class Initialized
INFO - 2024-02-07 09:08:35 --> Form Validation Class Initialized
INFO - 2024-02-07 09:08:35 --> Controller Class Initialized
INFO - 2024-02-07 09:08:35 --> Model Class Initialized
DEBUG - 2024-02-07 09:08:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:08:35 --> Final output sent to browser
DEBUG - 2024-02-07 09:08:35 --> Total execution time: 0.0157
ERROR - 2024-02-07 09:08:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:08:36 --> Config Class Initialized
INFO - 2024-02-07 09:08:36 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:08:36 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:08:36 --> Utf8 Class Initialized
INFO - 2024-02-07 09:08:36 --> URI Class Initialized
INFO - 2024-02-07 09:08:36 --> Router Class Initialized
INFO - 2024-02-07 09:08:36 --> Output Class Initialized
INFO - 2024-02-07 09:08:36 --> Security Class Initialized
DEBUG - 2024-02-07 09:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:08:36 --> Input Class Initialized
INFO - 2024-02-07 09:08:36 --> Language Class Initialized
INFO - 2024-02-07 09:08:36 --> Loader Class Initialized
INFO - 2024-02-07 09:08:36 --> Helper loaded: url_helper
INFO - 2024-02-07 09:08:36 --> Helper loaded: file_helper
INFO - 2024-02-07 09:08:36 --> Helper loaded: html_helper
INFO - 2024-02-07 09:08:36 --> Helper loaded: text_helper
INFO - 2024-02-07 09:08:36 --> Helper loaded: form_helper
INFO - 2024-02-07 09:08:36 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:08:36 --> Helper loaded: security_helper
INFO - 2024-02-07 09:08:36 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:08:36 --> Database Driver Class Initialized
INFO - 2024-02-07 09:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:08:36 --> Parser Class Initialized
INFO - 2024-02-07 09:08:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:08:36 --> Pagination Class Initialized
INFO - 2024-02-07 09:08:36 --> Form Validation Class Initialized
INFO - 2024-02-07 09:08:36 --> Controller Class Initialized
INFO - 2024-02-07 09:08:36 --> Model Class Initialized
DEBUG - 2024-02-07 09:08:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:08:36 --> Final output sent to browser
DEBUG - 2024-02-07 09:08:36 --> Total execution time: 0.0160
ERROR - 2024-02-07 09:08:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:08:39 --> Config Class Initialized
INFO - 2024-02-07 09:08:39 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:08:39 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:08:39 --> Utf8 Class Initialized
INFO - 2024-02-07 09:08:39 --> URI Class Initialized
INFO - 2024-02-07 09:08:39 --> Router Class Initialized
INFO - 2024-02-07 09:08:39 --> Output Class Initialized
INFO - 2024-02-07 09:08:39 --> Security Class Initialized
DEBUG - 2024-02-07 09:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:08:39 --> Input Class Initialized
INFO - 2024-02-07 09:08:39 --> Language Class Initialized
INFO - 2024-02-07 09:08:39 --> Loader Class Initialized
INFO - 2024-02-07 09:08:39 --> Helper loaded: url_helper
INFO - 2024-02-07 09:08:39 --> Helper loaded: file_helper
INFO - 2024-02-07 09:08:39 --> Helper loaded: html_helper
INFO - 2024-02-07 09:08:39 --> Helper loaded: text_helper
INFO - 2024-02-07 09:08:39 --> Helper loaded: form_helper
INFO - 2024-02-07 09:08:39 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:08:39 --> Helper loaded: security_helper
INFO - 2024-02-07 09:08:39 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:08:39 --> Database Driver Class Initialized
INFO - 2024-02-07 09:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:08:39 --> Parser Class Initialized
INFO - 2024-02-07 09:08:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:08:39 --> Pagination Class Initialized
INFO - 2024-02-07 09:08:39 --> Form Validation Class Initialized
INFO - 2024-02-07 09:08:39 --> Controller Class Initialized
INFO - 2024-02-07 09:08:39 --> Final output sent to browser
DEBUG - 2024-02-07 09:08:39 --> Total execution time: 0.0139
ERROR - 2024-02-07 09:09:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:09:05 --> Config Class Initialized
INFO - 2024-02-07 09:09:05 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:09:05 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:09:05 --> Utf8 Class Initialized
INFO - 2024-02-07 09:09:05 --> URI Class Initialized
INFO - 2024-02-07 09:09:05 --> Router Class Initialized
INFO - 2024-02-07 09:09:05 --> Output Class Initialized
INFO - 2024-02-07 09:09:05 --> Security Class Initialized
DEBUG - 2024-02-07 09:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:09:05 --> Input Class Initialized
INFO - 2024-02-07 09:09:05 --> Language Class Initialized
INFO - 2024-02-07 09:09:05 --> Loader Class Initialized
INFO - 2024-02-07 09:09:05 --> Helper loaded: url_helper
INFO - 2024-02-07 09:09:05 --> Helper loaded: file_helper
INFO - 2024-02-07 09:09:05 --> Helper loaded: html_helper
INFO - 2024-02-07 09:09:05 --> Helper loaded: text_helper
INFO - 2024-02-07 09:09:05 --> Helper loaded: form_helper
INFO - 2024-02-07 09:09:05 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:09:05 --> Helper loaded: security_helper
INFO - 2024-02-07 09:09:05 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:09:05 --> Database Driver Class Initialized
INFO - 2024-02-07 09:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:09:05 --> Parser Class Initialized
INFO - 2024-02-07 09:09:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:09:05 --> Pagination Class Initialized
INFO - 2024-02-07 09:09:05 --> Form Validation Class Initialized
INFO - 2024-02-07 09:09:05 --> Controller Class Initialized
INFO - 2024-02-07 09:09:05 --> Model Class Initialized
DEBUG - 2024-02-07 09:09:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 09:09:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:09:05 --> Model Class Initialized
DEBUG - 2024-02-07 09:09:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:09:05 --> Model Class Initialized
INFO - 2024-02-07 09:09:05 --> Final output sent to browser
DEBUG - 2024-02-07 09:09:05 --> Total execution time: 0.0964
ERROR - 2024-02-07 09:09:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:09:23 --> Config Class Initialized
INFO - 2024-02-07 09:09:23 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:09:23 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:09:23 --> Utf8 Class Initialized
INFO - 2024-02-07 09:09:23 --> URI Class Initialized
INFO - 2024-02-07 09:09:23 --> Router Class Initialized
INFO - 2024-02-07 09:09:23 --> Output Class Initialized
INFO - 2024-02-07 09:09:23 --> Security Class Initialized
DEBUG - 2024-02-07 09:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:09:23 --> Input Class Initialized
INFO - 2024-02-07 09:09:23 --> Language Class Initialized
INFO - 2024-02-07 09:09:23 --> Loader Class Initialized
INFO - 2024-02-07 09:09:23 --> Helper loaded: url_helper
INFO - 2024-02-07 09:09:23 --> Helper loaded: file_helper
INFO - 2024-02-07 09:09:23 --> Helper loaded: html_helper
INFO - 2024-02-07 09:09:23 --> Helper loaded: text_helper
INFO - 2024-02-07 09:09:23 --> Helper loaded: form_helper
INFO - 2024-02-07 09:09:23 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:09:23 --> Helper loaded: security_helper
INFO - 2024-02-07 09:09:23 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:09:23 --> Database Driver Class Initialized
INFO - 2024-02-07 09:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:09:23 --> Parser Class Initialized
INFO - 2024-02-07 09:09:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:09:23 --> Pagination Class Initialized
INFO - 2024-02-07 09:09:23 --> Form Validation Class Initialized
INFO - 2024-02-07 09:09:23 --> Controller Class Initialized
INFO - 2024-02-07 09:09:23 --> Model Class Initialized
DEBUG - 2024-02-07 09:09:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 09:09:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:09:23 --> Model Class Initialized
INFO - 2024-02-07 09:09:23 --> Model Class Initialized
INFO - 2024-02-07 09:09:23 --> Final output sent to browser
DEBUG - 2024-02-07 09:09:23 --> Total execution time: 0.0229
ERROR - 2024-02-07 09:09:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:09:29 --> Config Class Initialized
INFO - 2024-02-07 09:09:29 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:09:29 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:09:29 --> Utf8 Class Initialized
INFO - 2024-02-07 09:09:29 --> URI Class Initialized
INFO - 2024-02-07 09:09:29 --> Router Class Initialized
INFO - 2024-02-07 09:09:29 --> Output Class Initialized
INFO - 2024-02-07 09:09:29 --> Security Class Initialized
DEBUG - 2024-02-07 09:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:09:29 --> Input Class Initialized
INFO - 2024-02-07 09:09:29 --> Language Class Initialized
INFO - 2024-02-07 09:09:29 --> Loader Class Initialized
INFO - 2024-02-07 09:09:29 --> Helper loaded: url_helper
INFO - 2024-02-07 09:09:29 --> Helper loaded: file_helper
INFO - 2024-02-07 09:09:29 --> Helper loaded: html_helper
INFO - 2024-02-07 09:09:29 --> Helper loaded: text_helper
INFO - 2024-02-07 09:09:29 --> Helper loaded: form_helper
INFO - 2024-02-07 09:09:29 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:09:29 --> Helper loaded: security_helper
INFO - 2024-02-07 09:09:29 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:09:29 --> Database Driver Class Initialized
INFO - 2024-02-07 09:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:09:29 --> Parser Class Initialized
INFO - 2024-02-07 09:09:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:09:29 --> Pagination Class Initialized
INFO - 2024-02-07 09:09:29 --> Form Validation Class Initialized
INFO - 2024-02-07 09:09:29 --> Controller Class Initialized
INFO - 2024-02-07 09:09:29 --> Model Class Initialized
DEBUG - 2024-02-07 09:09:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 09:09:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:09:29 --> Model Class Initialized
INFO - 2024-02-07 09:09:29 --> Final output sent to browser
DEBUG - 2024-02-07 09:09:29 --> Total execution time: 0.0203
ERROR - 2024-02-07 09:09:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:09:49 --> Config Class Initialized
INFO - 2024-02-07 09:09:49 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:09:49 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:09:49 --> Utf8 Class Initialized
INFO - 2024-02-07 09:09:49 --> URI Class Initialized
INFO - 2024-02-07 09:09:49 --> Router Class Initialized
INFO - 2024-02-07 09:09:49 --> Output Class Initialized
INFO - 2024-02-07 09:09:49 --> Security Class Initialized
DEBUG - 2024-02-07 09:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:09:49 --> Input Class Initialized
INFO - 2024-02-07 09:09:49 --> Language Class Initialized
INFO - 2024-02-07 09:09:49 --> Loader Class Initialized
INFO - 2024-02-07 09:09:49 --> Helper loaded: url_helper
INFO - 2024-02-07 09:09:49 --> Helper loaded: file_helper
INFO - 2024-02-07 09:09:49 --> Helper loaded: html_helper
INFO - 2024-02-07 09:09:49 --> Helper loaded: text_helper
INFO - 2024-02-07 09:09:49 --> Helper loaded: form_helper
INFO - 2024-02-07 09:09:49 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:09:49 --> Helper loaded: security_helper
INFO - 2024-02-07 09:09:49 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:09:49 --> Database Driver Class Initialized
INFO - 2024-02-07 09:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:09:49 --> Parser Class Initialized
INFO - 2024-02-07 09:09:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:09:49 --> Pagination Class Initialized
INFO - 2024-02-07 09:09:49 --> Form Validation Class Initialized
INFO - 2024-02-07 09:09:49 --> Controller Class Initialized
INFO - 2024-02-07 09:09:49 --> Model Class Initialized
DEBUG - 2024-02-07 09:09:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 09:09:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:09:49 --> Model Class Initialized
DEBUG - 2024-02-07 09:09:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:09:49 --> Model Class Initialized
INFO - 2024-02-07 09:09:49 --> Final output sent to browser
DEBUG - 2024-02-07 09:09:49 --> Total execution time: 0.0951
ERROR - 2024-02-07 09:09:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:09:53 --> Config Class Initialized
INFO - 2024-02-07 09:09:53 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:09:53 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:09:53 --> Utf8 Class Initialized
INFO - 2024-02-07 09:09:53 --> URI Class Initialized
INFO - 2024-02-07 09:09:53 --> Router Class Initialized
INFO - 2024-02-07 09:09:53 --> Output Class Initialized
INFO - 2024-02-07 09:09:53 --> Security Class Initialized
DEBUG - 2024-02-07 09:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:09:53 --> Input Class Initialized
INFO - 2024-02-07 09:09:53 --> Language Class Initialized
INFO - 2024-02-07 09:09:53 --> Loader Class Initialized
INFO - 2024-02-07 09:09:53 --> Helper loaded: url_helper
INFO - 2024-02-07 09:09:53 --> Helper loaded: file_helper
INFO - 2024-02-07 09:09:53 --> Helper loaded: html_helper
INFO - 2024-02-07 09:09:53 --> Helper loaded: text_helper
INFO - 2024-02-07 09:09:53 --> Helper loaded: form_helper
INFO - 2024-02-07 09:09:53 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:09:53 --> Helper loaded: security_helper
INFO - 2024-02-07 09:09:53 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:09:53 --> Database Driver Class Initialized
INFO - 2024-02-07 09:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:09:53 --> Parser Class Initialized
INFO - 2024-02-07 09:09:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:09:53 --> Pagination Class Initialized
INFO - 2024-02-07 09:09:53 --> Form Validation Class Initialized
INFO - 2024-02-07 09:09:53 --> Controller Class Initialized
INFO - 2024-02-07 09:09:53 --> Model Class Initialized
DEBUG - 2024-02-07 09:09:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 09:09:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:09:53 --> Model Class Initialized
DEBUG - 2024-02-07 09:09:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:09:53 --> Model Class Initialized
INFO - 2024-02-07 09:09:53 --> Final output sent to browser
DEBUG - 2024-02-07 09:09:53 --> Total execution time: 0.0919
ERROR - 2024-02-07 09:09:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:09:55 --> Config Class Initialized
INFO - 2024-02-07 09:09:55 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:09:55 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:09:55 --> Utf8 Class Initialized
INFO - 2024-02-07 09:09:55 --> URI Class Initialized
INFO - 2024-02-07 09:09:55 --> Router Class Initialized
INFO - 2024-02-07 09:09:55 --> Output Class Initialized
INFO - 2024-02-07 09:09:55 --> Security Class Initialized
DEBUG - 2024-02-07 09:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:09:55 --> Input Class Initialized
INFO - 2024-02-07 09:09:55 --> Language Class Initialized
INFO - 2024-02-07 09:09:55 --> Loader Class Initialized
INFO - 2024-02-07 09:09:55 --> Helper loaded: url_helper
INFO - 2024-02-07 09:09:55 --> Helper loaded: file_helper
INFO - 2024-02-07 09:09:55 --> Helper loaded: html_helper
INFO - 2024-02-07 09:09:55 --> Helper loaded: text_helper
INFO - 2024-02-07 09:09:55 --> Helper loaded: form_helper
INFO - 2024-02-07 09:09:55 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:09:55 --> Helper loaded: security_helper
INFO - 2024-02-07 09:09:55 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:09:55 --> Database Driver Class Initialized
INFO - 2024-02-07 09:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:09:55 --> Parser Class Initialized
INFO - 2024-02-07 09:09:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:09:55 --> Pagination Class Initialized
INFO - 2024-02-07 09:09:55 --> Form Validation Class Initialized
INFO - 2024-02-07 09:09:55 --> Controller Class Initialized
INFO - 2024-02-07 09:09:55 --> Model Class Initialized
DEBUG - 2024-02-07 09:09:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 09:09:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:09:55 --> Model Class Initialized
DEBUG - 2024-02-07 09:09:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:09:55 --> Model Class Initialized
INFO - 2024-02-07 09:09:55 --> Final output sent to browser
DEBUG - 2024-02-07 09:09:55 --> Total execution time: 0.0902
ERROR - 2024-02-07 09:10:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:10:09 --> Config Class Initialized
INFO - 2024-02-07 09:10:09 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:10:09 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:10:09 --> Utf8 Class Initialized
INFO - 2024-02-07 09:10:09 --> URI Class Initialized
INFO - 2024-02-07 09:10:09 --> Router Class Initialized
INFO - 2024-02-07 09:10:09 --> Output Class Initialized
INFO - 2024-02-07 09:10:09 --> Security Class Initialized
DEBUG - 2024-02-07 09:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:10:09 --> Input Class Initialized
INFO - 2024-02-07 09:10:09 --> Language Class Initialized
INFO - 2024-02-07 09:10:09 --> Loader Class Initialized
INFO - 2024-02-07 09:10:09 --> Helper loaded: url_helper
INFO - 2024-02-07 09:10:09 --> Helper loaded: file_helper
INFO - 2024-02-07 09:10:09 --> Helper loaded: html_helper
INFO - 2024-02-07 09:10:09 --> Helper loaded: text_helper
INFO - 2024-02-07 09:10:09 --> Helper loaded: form_helper
INFO - 2024-02-07 09:10:09 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:10:09 --> Helper loaded: security_helper
INFO - 2024-02-07 09:10:09 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:10:09 --> Database Driver Class Initialized
INFO - 2024-02-07 09:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:10:09 --> Parser Class Initialized
INFO - 2024-02-07 09:10:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:10:09 --> Pagination Class Initialized
INFO - 2024-02-07 09:10:09 --> Form Validation Class Initialized
INFO - 2024-02-07 09:10:09 --> Controller Class Initialized
INFO - 2024-02-07 09:10:09 --> Model Class Initialized
DEBUG - 2024-02-07 09:10:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 09:10:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:10:09 --> Model Class Initialized
DEBUG - 2024-02-07 09:10:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:10:09 --> Model Class Initialized
INFO - 2024-02-07 09:10:09 --> Final output sent to browser
DEBUG - 2024-02-07 09:10:09 --> Total execution time: 0.0382
ERROR - 2024-02-07 09:10:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:10:17 --> Config Class Initialized
INFO - 2024-02-07 09:10:17 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:10:17 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:10:17 --> Utf8 Class Initialized
INFO - 2024-02-07 09:10:17 --> URI Class Initialized
INFO - 2024-02-07 09:10:17 --> Router Class Initialized
INFO - 2024-02-07 09:10:17 --> Output Class Initialized
INFO - 2024-02-07 09:10:17 --> Security Class Initialized
DEBUG - 2024-02-07 09:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:10:17 --> Input Class Initialized
INFO - 2024-02-07 09:10:17 --> Language Class Initialized
INFO - 2024-02-07 09:10:17 --> Loader Class Initialized
INFO - 2024-02-07 09:10:17 --> Helper loaded: url_helper
INFO - 2024-02-07 09:10:17 --> Helper loaded: file_helper
INFO - 2024-02-07 09:10:17 --> Helper loaded: html_helper
INFO - 2024-02-07 09:10:17 --> Helper loaded: text_helper
INFO - 2024-02-07 09:10:17 --> Helper loaded: form_helper
INFO - 2024-02-07 09:10:17 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:10:17 --> Helper loaded: security_helper
INFO - 2024-02-07 09:10:17 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:10:17 --> Database Driver Class Initialized
INFO - 2024-02-07 09:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:10:17 --> Parser Class Initialized
INFO - 2024-02-07 09:10:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:10:17 --> Pagination Class Initialized
INFO - 2024-02-07 09:10:17 --> Form Validation Class Initialized
INFO - 2024-02-07 09:10:17 --> Controller Class Initialized
INFO - 2024-02-07 09:10:17 --> Model Class Initialized
DEBUG - 2024-02-07 09:10:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 09:10:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:10:17 --> Model Class Initialized
DEBUG - 2024-02-07 09:10:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:10:17 --> Model Class Initialized
INFO - 2024-02-07 09:10:17 --> Final output sent to browser
DEBUG - 2024-02-07 09:10:17 --> Total execution time: 0.0207
ERROR - 2024-02-07 09:10:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:10:21 --> Config Class Initialized
INFO - 2024-02-07 09:10:21 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:10:21 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:10:21 --> Utf8 Class Initialized
INFO - 2024-02-07 09:10:21 --> URI Class Initialized
INFO - 2024-02-07 09:10:21 --> Router Class Initialized
INFO - 2024-02-07 09:10:21 --> Output Class Initialized
INFO - 2024-02-07 09:10:21 --> Security Class Initialized
DEBUG - 2024-02-07 09:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:10:21 --> Input Class Initialized
INFO - 2024-02-07 09:10:21 --> Language Class Initialized
INFO - 2024-02-07 09:10:21 --> Loader Class Initialized
INFO - 2024-02-07 09:10:21 --> Helper loaded: url_helper
INFO - 2024-02-07 09:10:21 --> Helper loaded: file_helper
INFO - 2024-02-07 09:10:21 --> Helper loaded: html_helper
INFO - 2024-02-07 09:10:21 --> Helper loaded: text_helper
INFO - 2024-02-07 09:10:21 --> Helper loaded: form_helper
INFO - 2024-02-07 09:10:21 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:10:21 --> Helper loaded: security_helper
INFO - 2024-02-07 09:10:21 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:10:21 --> Database Driver Class Initialized
INFO - 2024-02-07 09:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:10:21 --> Parser Class Initialized
INFO - 2024-02-07 09:10:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:10:21 --> Pagination Class Initialized
INFO - 2024-02-07 09:10:21 --> Form Validation Class Initialized
INFO - 2024-02-07 09:10:21 --> Controller Class Initialized
INFO - 2024-02-07 09:10:21 --> Model Class Initialized
DEBUG - 2024-02-07 09:10:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 09:10:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:10:21 --> Model Class Initialized
DEBUG - 2024-02-07 09:10:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:10:21 --> Model Class Initialized
INFO - 2024-02-07 09:10:21 --> Final output sent to browser
DEBUG - 2024-02-07 09:10:21 --> Total execution time: 0.0190
ERROR - 2024-02-07 09:10:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:10:26 --> Config Class Initialized
INFO - 2024-02-07 09:10:26 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:10:26 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:10:26 --> Utf8 Class Initialized
INFO - 2024-02-07 09:10:26 --> URI Class Initialized
INFO - 2024-02-07 09:10:26 --> Router Class Initialized
INFO - 2024-02-07 09:10:26 --> Output Class Initialized
INFO - 2024-02-07 09:10:26 --> Security Class Initialized
DEBUG - 2024-02-07 09:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:10:26 --> Input Class Initialized
INFO - 2024-02-07 09:10:26 --> Language Class Initialized
INFO - 2024-02-07 09:10:26 --> Loader Class Initialized
INFO - 2024-02-07 09:10:26 --> Helper loaded: url_helper
INFO - 2024-02-07 09:10:26 --> Helper loaded: file_helper
INFO - 2024-02-07 09:10:26 --> Helper loaded: html_helper
INFO - 2024-02-07 09:10:26 --> Helper loaded: text_helper
INFO - 2024-02-07 09:10:26 --> Helper loaded: form_helper
INFO - 2024-02-07 09:10:26 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:10:26 --> Helper loaded: security_helper
INFO - 2024-02-07 09:10:26 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:10:26 --> Database Driver Class Initialized
INFO - 2024-02-07 09:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:10:26 --> Parser Class Initialized
INFO - 2024-02-07 09:10:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:10:26 --> Pagination Class Initialized
INFO - 2024-02-07 09:10:26 --> Form Validation Class Initialized
INFO - 2024-02-07 09:10:26 --> Controller Class Initialized
INFO - 2024-02-07 09:10:26 --> Model Class Initialized
DEBUG - 2024-02-07 09:10:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 09:10:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:10:26 --> Model Class Initialized
DEBUG - 2024-02-07 09:10:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:10:26 --> Model Class Initialized
INFO - 2024-02-07 09:10:26 --> Final output sent to browser
DEBUG - 2024-02-07 09:10:26 --> Total execution time: 0.0195
ERROR - 2024-02-07 09:10:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:10:28 --> Config Class Initialized
INFO - 2024-02-07 09:10:28 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:10:28 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:10:28 --> Utf8 Class Initialized
INFO - 2024-02-07 09:10:28 --> URI Class Initialized
INFO - 2024-02-07 09:10:28 --> Router Class Initialized
INFO - 2024-02-07 09:10:28 --> Output Class Initialized
INFO - 2024-02-07 09:10:28 --> Security Class Initialized
DEBUG - 2024-02-07 09:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:10:28 --> Input Class Initialized
INFO - 2024-02-07 09:10:28 --> Language Class Initialized
INFO - 2024-02-07 09:10:28 --> Loader Class Initialized
INFO - 2024-02-07 09:10:28 --> Helper loaded: url_helper
INFO - 2024-02-07 09:10:28 --> Helper loaded: file_helper
INFO - 2024-02-07 09:10:28 --> Helper loaded: html_helper
INFO - 2024-02-07 09:10:28 --> Helper loaded: text_helper
INFO - 2024-02-07 09:10:28 --> Helper loaded: form_helper
INFO - 2024-02-07 09:10:28 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:10:28 --> Helper loaded: security_helper
INFO - 2024-02-07 09:10:28 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:10:28 --> Database Driver Class Initialized
INFO - 2024-02-07 09:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:10:28 --> Parser Class Initialized
INFO - 2024-02-07 09:10:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:10:28 --> Pagination Class Initialized
INFO - 2024-02-07 09:10:28 --> Form Validation Class Initialized
INFO - 2024-02-07 09:10:28 --> Controller Class Initialized
INFO - 2024-02-07 09:10:28 --> Model Class Initialized
DEBUG - 2024-02-07 09:10:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 09:10:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:10:28 --> Model Class Initialized
DEBUG - 2024-02-07 09:10:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:10:28 --> Model Class Initialized
INFO - 2024-02-07 09:10:28 --> Final output sent to browser
DEBUG - 2024-02-07 09:10:28 --> Total execution time: 0.0365
ERROR - 2024-02-07 09:10:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:10:28 --> Config Class Initialized
INFO - 2024-02-07 09:10:28 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:10:28 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:10:28 --> Utf8 Class Initialized
INFO - 2024-02-07 09:10:28 --> URI Class Initialized
INFO - 2024-02-07 09:10:28 --> Router Class Initialized
INFO - 2024-02-07 09:10:28 --> Output Class Initialized
INFO - 2024-02-07 09:10:28 --> Security Class Initialized
DEBUG - 2024-02-07 09:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:10:28 --> Input Class Initialized
INFO - 2024-02-07 09:10:28 --> Language Class Initialized
INFO - 2024-02-07 09:10:28 --> Loader Class Initialized
INFO - 2024-02-07 09:10:28 --> Helper loaded: url_helper
INFO - 2024-02-07 09:10:28 --> Helper loaded: file_helper
INFO - 2024-02-07 09:10:28 --> Helper loaded: html_helper
INFO - 2024-02-07 09:10:28 --> Helper loaded: text_helper
INFO - 2024-02-07 09:10:28 --> Helper loaded: form_helper
INFO - 2024-02-07 09:10:28 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:10:28 --> Helper loaded: security_helper
INFO - 2024-02-07 09:10:28 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:10:28 --> Database Driver Class Initialized
INFO - 2024-02-07 09:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:10:28 --> Parser Class Initialized
INFO - 2024-02-07 09:10:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:10:28 --> Pagination Class Initialized
INFO - 2024-02-07 09:10:28 --> Form Validation Class Initialized
INFO - 2024-02-07 09:10:28 --> Controller Class Initialized
INFO - 2024-02-07 09:10:28 --> Model Class Initialized
DEBUG - 2024-02-07 09:10:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 09:10:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:10:28 --> Model Class Initialized
DEBUG - 2024-02-07 09:10:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:10:28 --> Model Class Initialized
INFO - 2024-02-07 09:10:28 --> Final output sent to browser
DEBUG - 2024-02-07 09:10:28 --> Total execution time: 0.0904
ERROR - 2024-02-07 09:10:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:10:35 --> Config Class Initialized
INFO - 2024-02-07 09:10:35 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:10:35 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:10:35 --> Utf8 Class Initialized
INFO - 2024-02-07 09:10:35 --> URI Class Initialized
INFO - 2024-02-07 09:10:35 --> Router Class Initialized
INFO - 2024-02-07 09:10:35 --> Output Class Initialized
INFO - 2024-02-07 09:10:35 --> Security Class Initialized
DEBUG - 2024-02-07 09:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:10:35 --> Input Class Initialized
INFO - 2024-02-07 09:10:35 --> Language Class Initialized
INFO - 2024-02-07 09:10:35 --> Loader Class Initialized
INFO - 2024-02-07 09:10:35 --> Helper loaded: url_helper
INFO - 2024-02-07 09:10:35 --> Helper loaded: file_helper
INFO - 2024-02-07 09:10:35 --> Helper loaded: html_helper
INFO - 2024-02-07 09:10:35 --> Helper loaded: text_helper
INFO - 2024-02-07 09:10:35 --> Helper loaded: form_helper
INFO - 2024-02-07 09:10:35 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:10:35 --> Helper loaded: security_helper
INFO - 2024-02-07 09:10:35 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:10:35 --> Database Driver Class Initialized
INFO - 2024-02-07 09:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:10:35 --> Parser Class Initialized
INFO - 2024-02-07 09:10:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:10:35 --> Pagination Class Initialized
INFO - 2024-02-07 09:10:35 --> Form Validation Class Initialized
INFO - 2024-02-07 09:10:35 --> Controller Class Initialized
INFO - 2024-02-07 09:10:35 --> Model Class Initialized
DEBUG - 2024-02-07 09:10:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 09:10:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:10:35 --> Model Class Initialized
DEBUG - 2024-02-07 09:10:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:10:35 --> Model Class Initialized
INFO - 2024-02-07 09:10:35 --> Final output sent to browser
DEBUG - 2024-02-07 09:10:35 --> Total execution time: 0.0361
ERROR - 2024-02-07 09:10:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:10:39 --> Config Class Initialized
INFO - 2024-02-07 09:10:39 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:10:39 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:10:39 --> Utf8 Class Initialized
INFO - 2024-02-07 09:10:39 --> URI Class Initialized
INFO - 2024-02-07 09:10:39 --> Router Class Initialized
INFO - 2024-02-07 09:10:39 --> Output Class Initialized
INFO - 2024-02-07 09:10:39 --> Security Class Initialized
DEBUG - 2024-02-07 09:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:10:39 --> Input Class Initialized
INFO - 2024-02-07 09:10:39 --> Language Class Initialized
INFO - 2024-02-07 09:10:39 --> Loader Class Initialized
INFO - 2024-02-07 09:10:39 --> Helper loaded: url_helper
INFO - 2024-02-07 09:10:39 --> Helper loaded: file_helper
INFO - 2024-02-07 09:10:39 --> Helper loaded: html_helper
INFO - 2024-02-07 09:10:39 --> Helper loaded: text_helper
INFO - 2024-02-07 09:10:39 --> Helper loaded: form_helper
INFO - 2024-02-07 09:10:39 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:10:39 --> Helper loaded: security_helper
INFO - 2024-02-07 09:10:39 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:10:39 --> Database Driver Class Initialized
INFO - 2024-02-07 09:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:10:39 --> Parser Class Initialized
INFO - 2024-02-07 09:10:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:10:39 --> Pagination Class Initialized
INFO - 2024-02-07 09:10:39 --> Form Validation Class Initialized
INFO - 2024-02-07 09:10:39 --> Controller Class Initialized
INFO - 2024-02-07 09:10:39 --> Model Class Initialized
DEBUG - 2024-02-07 09:10:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 09:10:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:10:39 --> Model Class Initialized
DEBUG - 2024-02-07 09:10:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:10:39 --> Model Class Initialized
INFO - 2024-02-07 09:10:39 --> Final output sent to browser
DEBUG - 2024-02-07 09:10:39 --> Total execution time: 0.0205
ERROR - 2024-02-07 09:10:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:10:42 --> Config Class Initialized
INFO - 2024-02-07 09:10:42 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:10:42 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:10:42 --> Utf8 Class Initialized
INFO - 2024-02-07 09:10:42 --> URI Class Initialized
INFO - 2024-02-07 09:10:42 --> Router Class Initialized
INFO - 2024-02-07 09:10:42 --> Output Class Initialized
INFO - 2024-02-07 09:10:42 --> Security Class Initialized
DEBUG - 2024-02-07 09:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:10:42 --> Input Class Initialized
INFO - 2024-02-07 09:10:42 --> Language Class Initialized
INFO - 2024-02-07 09:10:42 --> Loader Class Initialized
INFO - 2024-02-07 09:10:42 --> Helper loaded: url_helper
INFO - 2024-02-07 09:10:42 --> Helper loaded: file_helper
INFO - 2024-02-07 09:10:42 --> Helper loaded: html_helper
INFO - 2024-02-07 09:10:42 --> Helper loaded: text_helper
INFO - 2024-02-07 09:10:42 --> Helper loaded: form_helper
INFO - 2024-02-07 09:10:42 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:10:42 --> Helper loaded: security_helper
INFO - 2024-02-07 09:10:42 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:10:42 --> Database Driver Class Initialized
INFO - 2024-02-07 09:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:10:42 --> Parser Class Initialized
INFO - 2024-02-07 09:10:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:10:42 --> Pagination Class Initialized
INFO - 2024-02-07 09:10:42 --> Form Validation Class Initialized
INFO - 2024-02-07 09:10:42 --> Controller Class Initialized
INFO - 2024-02-07 09:10:42 --> Model Class Initialized
DEBUG - 2024-02-07 09:10:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 09:10:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:10:42 --> Model Class Initialized
DEBUG - 2024-02-07 09:10:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:10:42 --> Model Class Initialized
INFO - 2024-02-07 09:10:42 --> Final output sent to browser
DEBUG - 2024-02-07 09:10:42 --> Total execution time: 0.0380
ERROR - 2024-02-07 09:12:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:12:31 --> Config Class Initialized
INFO - 2024-02-07 09:12:31 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:12:31 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:12:31 --> Utf8 Class Initialized
INFO - 2024-02-07 09:12:31 --> URI Class Initialized
DEBUG - 2024-02-07 09:12:31 --> No URI present. Default controller set.
INFO - 2024-02-07 09:12:31 --> Router Class Initialized
INFO - 2024-02-07 09:12:31 --> Output Class Initialized
INFO - 2024-02-07 09:12:31 --> Security Class Initialized
DEBUG - 2024-02-07 09:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:12:31 --> Input Class Initialized
INFO - 2024-02-07 09:12:31 --> Language Class Initialized
INFO - 2024-02-07 09:12:31 --> Loader Class Initialized
INFO - 2024-02-07 09:12:31 --> Helper loaded: url_helper
INFO - 2024-02-07 09:12:31 --> Helper loaded: file_helper
INFO - 2024-02-07 09:12:31 --> Helper loaded: html_helper
INFO - 2024-02-07 09:12:31 --> Helper loaded: text_helper
INFO - 2024-02-07 09:12:31 --> Helper loaded: form_helper
INFO - 2024-02-07 09:12:31 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:12:31 --> Helper loaded: security_helper
INFO - 2024-02-07 09:12:31 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:12:31 --> Database Driver Class Initialized
INFO - 2024-02-07 09:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:12:31 --> Parser Class Initialized
INFO - 2024-02-07 09:12:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:12:31 --> Pagination Class Initialized
INFO - 2024-02-07 09:12:31 --> Form Validation Class Initialized
INFO - 2024-02-07 09:12:31 --> Controller Class Initialized
INFO - 2024-02-07 09:12:31 --> Model Class Initialized
DEBUG - 2024-02-07 09:12:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:12:31 --> Model Class Initialized
DEBUG - 2024-02-07 09:12:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:12:31 --> Model Class Initialized
INFO - 2024-02-07 09:12:31 --> Model Class Initialized
INFO - 2024-02-07 09:12:31 --> Model Class Initialized
INFO - 2024-02-07 09:12:31 --> Model Class Initialized
DEBUG - 2024-02-07 09:12:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 09:12:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:12:31 --> Model Class Initialized
INFO - 2024-02-07 09:12:31 --> Model Class Initialized
INFO - 2024-02-07 09:12:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-07 09:12:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:12:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 09:12:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 09:12:32 --> Model Class Initialized
INFO - 2024-02-07 09:12:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 09:12:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 09:12:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 09:12:32 --> Final output sent to browser
DEBUG - 2024-02-07 09:12:32 --> Total execution time: 0.4038
ERROR - 2024-02-07 09:37:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:37:51 --> Config Class Initialized
INFO - 2024-02-07 09:37:51 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:37:51 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:37:51 --> Utf8 Class Initialized
INFO - 2024-02-07 09:37:51 --> URI Class Initialized
DEBUG - 2024-02-07 09:37:51 --> No URI present. Default controller set.
INFO - 2024-02-07 09:37:51 --> Router Class Initialized
INFO - 2024-02-07 09:37:51 --> Output Class Initialized
INFO - 2024-02-07 09:37:51 --> Security Class Initialized
DEBUG - 2024-02-07 09:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:37:51 --> Input Class Initialized
INFO - 2024-02-07 09:37:51 --> Language Class Initialized
INFO - 2024-02-07 09:37:51 --> Loader Class Initialized
INFO - 2024-02-07 09:37:51 --> Helper loaded: url_helper
INFO - 2024-02-07 09:37:51 --> Helper loaded: file_helper
INFO - 2024-02-07 09:37:51 --> Helper loaded: html_helper
INFO - 2024-02-07 09:37:51 --> Helper loaded: text_helper
INFO - 2024-02-07 09:37:51 --> Helper loaded: form_helper
INFO - 2024-02-07 09:37:51 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:37:51 --> Helper loaded: security_helper
INFO - 2024-02-07 09:37:51 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:37:51 --> Database Driver Class Initialized
INFO - 2024-02-07 09:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:37:51 --> Parser Class Initialized
INFO - 2024-02-07 09:37:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:37:51 --> Pagination Class Initialized
INFO - 2024-02-07 09:37:51 --> Form Validation Class Initialized
INFO - 2024-02-07 09:37:51 --> Controller Class Initialized
INFO - 2024-02-07 09:37:51 --> Model Class Initialized
DEBUG - 2024-02-07 09:37:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:37:51 --> Model Class Initialized
DEBUG - 2024-02-07 09:37:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:37:51 --> Model Class Initialized
INFO - 2024-02-07 09:37:51 --> Model Class Initialized
INFO - 2024-02-07 09:37:51 --> Model Class Initialized
INFO - 2024-02-07 09:37:51 --> Model Class Initialized
DEBUG - 2024-02-07 09:37:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 09:37:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:37:51 --> Model Class Initialized
INFO - 2024-02-07 09:37:51 --> Model Class Initialized
INFO - 2024-02-07 09:37:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-07 09:37:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:37:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 09:37:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 09:37:51 --> Model Class Initialized
INFO - 2024-02-07 09:37:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 09:37:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 09:37:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 09:37:51 --> Final output sent to browser
DEBUG - 2024-02-07 09:37:51 --> Total execution time: 0.2390
ERROR - 2024-02-07 09:38:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:38:00 --> Config Class Initialized
INFO - 2024-02-07 09:38:00 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:38:00 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:38:00 --> Utf8 Class Initialized
INFO - 2024-02-07 09:38:00 --> URI Class Initialized
INFO - 2024-02-07 09:38:00 --> Router Class Initialized
INFO - 2024-02-07 09:38:00 --> Output Class Initialized
INFO - 2024-02-07 09:38:00 --> Security Class Initialized
DEBUG - 2024-02-07 09:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:38:00 --> Input Class Initialized
INFO - 2024-02-07 09:38:00 --> Language Class Initialized
INFO - 2024-02-07 09:38:00 --> Loader Class Initialized
INFO - 2024-02-07 09:38:00 --> Helper loaded: url_helper
INFO - 2024-02-07 09:38:00 --> Helper loaded: file_helper
INFO - 2024-02-07 09:38:00 --> Helper loaded: html_helper
INFO - 2024-02-07 09:38:00 --> Helper loaded: text_helper
INFO - 2024-02-07 09:38:00 --> Helper loaded: form_helper
INFO - 2024-02-07 09:38:00 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:38:00 --> Helper loaded: security_helper
INFO - 2024-02-07 09:38:00 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:38:00 --> Database Driver Class Initialized
INFO - 2024-02-07 09:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:38:00 --> Parser Class Initialized
INFO - 2024-02-07 09:38:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:38:00 --> Pagination Class Initialized
INFO - 2024-02-07 09:38:00 --> Form Validation Class Initialized
INFO - 2024-02-07 09:38:00 --> Controller Class Initialized
INFO - 2024-02-07 09:38:00 --> Model Class Initialized
DEBUG - 2024-02-07 09:38:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 09:38:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:38:00 --> Model Class Initialized
DEBUG - 2024-02-07 09:38:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:38:00 --> Model Class Initialized
INFO - 2024-02-07 09:38:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-02-07 09:38:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:38:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 09:38:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 09:38:00 --> Model Class Initialized
INFO - 2024-02-07 09:38:00 --> Model Class Initialized
INFO - 2024-02-07 09:38:00 --> Model Class Initialized
INFO - 2024-02-07 09:38:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 09:38:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 09:38:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 09:38:00 --> Final output sent to browser
DEBUG - 2024-02-07 09:38:00 --> Total execution time: 0.1695
ERROR - 2024-02-07 09:38:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:38:11 --> Config Class Initialized
INFO - 2024-02-07 09:38:11 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:38:11 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:38:11 --> Utf8 Class Initialized
INFO - 2024-02-07 09:38:11 --> URI Class Initialized
INFO - 2024-02-07 09:38:11 --> Router Class Initialized
INFO - 2024-02-07 09:38:11 --> Output Class Initialized
INFO - 2024-02-07 09:38:11 --> Security Class Initialized
DEBUG - 2024-02-07 09:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:38:11 --> Input Class Initialized
INFO - 2024-02-07 09:38:11 --> Language Class Initialized
INFO - 2024-02-07 09:38:11 --> Loader Class Initialized
INFO - 2024-02-07 09:38:11 --> Helper loaded: url_helper
INFO - 2024-02-07 09:38:11 --> Helper loaded: file_helper
INFO - 2024-02-07 09:38:11 --> Helper loaded: html_helper
INFO - 2024-02-07 09:38:11 --> Helper loaded: text_helper
INFO - 2024-02-07 09:38:11 --> Helper loaded: form_helper
INFO - 2024-02-07 09:38:11 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:38:11 --> Helper loaded: security_helper
INFO - 2024-02-07 09:38:11 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:38:11 --> Database Driver Class Initialized
INFO - 2024-02-07 09:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:38:11 --> Parser Class Initialized
INFO - 2024-02-07 09:38:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:38:11 --> Pagination Class Initialized
INFO - 2024-02-07 09:38:12 --> Form Validation Class Initialized
INFO - 2024-02-07 09:38:12 --> Controller Class Initialized
INFO - 2024-02-07 09:38:12 --> Model Class Initialized
DEBUG - 2024-02-07 09:38:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:38:12 --> Final output sent to browser
DEBUG - 2024-02-07 09:38:12 --> Total execution time: 0.0161
ERROR - 2024-02-07 09:38:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:38:16 --> Config Class Initialized
INFO - 2024-02-07 09:38:16 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:38:16 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:38:16 --> Utf8 Class Initialized
INFO - 2024-02-07 09:38:16 --> URI Class Initialized
INFO - 2024-02-07 09:38:16 --> Router Class Initialized
INFO - 2024-02-07 09:38:16 --> Output Class Initialized
INFO - 2024-02-07 09:38:16 --> Security Class Initialized
DEBUG - 2024-02-07 09:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:38:16 --> Input Class Initialized
INFO - 2024-02-07 09:38:16 --> Language Class Initialized
INFO - 2024-02-07 09:38:16 --> Loader Class Initialized
INFO - 2024-02-07 09:38:16 --> Helper loaded: url_helper
INFO - 2024-02-07 09:38:16 --> Helper loaded: file_helper
INFO - 2024-02-07 09:38:16 --> Helper loaded: html_helper
INFO - 2024-02-07 09:38:16 --> Helper loaded: text_helper
INFO - 2024-02-07 09:38:16 --> Helper loaded: form_helper
INFO - 2024-02-07 09:38:16 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:38:16 --> Helper loaded: security_helper
INFO - 2024-02-07 09:38:16 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:38:16 --> Database Driver Class Initialized
INFO - 2024-02-07 09:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:38:16 --> Parser Class Initialized
INFO - 2024-02-07 09:38:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:38:16 --> Pagination Class Initialized
INFO - 2024-02-07 09:38:16 --> Form Validation Class Initialized
INFO - 2024-02-07 09:38:16 --> Controller Class Initialized
INFO - 2024-02-07 09:38:16 --> Model Class Initialized
DEBUG - 2024-02-07 09:38:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-07 09:38:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-02-07 09:38:16 --> Final output sent to browser
DEBUG - 2024-02-07 09:38:16 --> Total execution time: 0.0153
ERROR - 2024-02-07 09:38:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:38:17 --> Config Class Initialized
INFO - 2024-02-07 09:38:17 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:38:17 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:38:17 --> Utf8 Class Initialized
INFO - 2024-02-07 09:38:17 --> URI Class Initialized
INFO - 2024-02-07 09:38:17 --> Router Class Initialized
INFO - 2024-02-07 09:38:17 --> Output Class Initialized
INFO - 2024-02-07 09:38:17 --> Security Class Initialized
DEBUG - 2024-02-07 09:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:38:17 --> Input Class Initialized
INFO - 2024-02-07 09:38:17 --> Language Class Initialized
INFO - 2024-02-07 09:38:17 --> Loader Class Initialized
INFO - 2024-02-07 09:38:17 --> Helper loaded: url_helper
INFO - 2024-02-07 09:38:17 --> Helper loaded: file_helper
INFO - 2024-02-07 09:38:17 --> Helper loaded: html_helper
INFO - 2024-02-07 09:38:17 --> Helper loaded: text_helper
INFO - 2024-02-07 09:38:17 --> Helper loaded: form_helper
INFO - 2024-02-07 09:38:17 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:38:17 --> Helper loaded: security_helper
INFO - 2024-02-07 09:38:17 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:38:17 --> Database Driver Class Initialized
INFO - 2024-02-07 09:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:38:17 --> Parser Class Initialized
INFO - 2024-02-07 09:38:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:38:17 --> Pagination Class Initialized
INFO - 2024-02-07 09:38:17 --> Form Validation Class Initialized
INFO - 2024-02-07 09:38:17 --> Controller Class Initialized
INFO - 2024-02-07 09:38:17 --> Model Class Initialized
DEBUG - 2024-02-07 09:38:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-07 09:38:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-02-07 09:38:17 --> Final output sent to browser
DEBUG - 2024-02-07 09:38:17 --> Total execution time: 0.0156
ERROR - 2024-02-07 09:38:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:38:18 --> Config Class Initialized
INFO - 2024-02-07 09:38:18 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:38:18 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:38:18 --> Utf8 Class Initialized
INFO - 2024-02-07 09:38:18 --> URI Class Initialized
INFO - 2024-02-07 09:38:18 --> Router Class Initialized
INFO - 2024-02-07 09:38:18 --> Output Class Initialized
INFO - 2024-02-07 09:38:18 --> Security Class Initialized
DEBUG - 2024-02-07 09:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:38:18 --> Input Class Initialized
INFO - 2024-02-07 09:38:18 --> Language Class Initialized
INFO - 2024-02-07 09:38:18 --> Loader Class Initialized
INFO - 2024-02-07 09:38:18 --> Helper loaded: url_helper
INFO - 2024-02-07 09:38:18 --> Helper loaded: file_helper
INFO - 2024-02-07 09:38:18 --> Helper loaded: html_helper
INFO - 2024-02-07 09:38:18 --> Helper loaded: text_helper
INFO - 2024-02-07 09:38:18 --> Helper loaded: form_helper
INFO - 2024-02-07 09:38:18 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:38:18 --> Helper loaded: security_helper
INFO - 2024-02-07 09:38:18 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:38:18 --> Database Driver Class Initialized
INFO - 2024-02-07 09:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:38:18 --> Parser Class Initialized
INFO - 2024-02-07 09:38:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:38:18 --> Pagination Class Initialized
INFO - 2024-02-07 09:38:18 --> Form Validation Class Initialized
INFO - 2024-02-07 09:38:18 --> Controller Class Initialized
INFO - 2024-02-07 09:38:18 --> Model Class Initialized
DEBUG - 2024-02-07 09:38:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-07 09:38:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-02-07 09:38:18 --> Final output sent to browser
DEBUG - 2024-02-07 09:38:18 --> Total execution time: 0.0154
ERROR - 2024-02-07 09:38:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:38:18 --> Config Class Initialized
INFO - 2024-02-07 09:38:18 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:38:18 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:38:18 --> Utf8 Class Initialized
INFO - 2024-02-07 09:38:18 --> URI Class Initialized
INFO - 2024-02-07 09:38:18 --> Router Class Initialized
INFO - 2024-02-07 09:38:18 --> Output Class Initialized
INFO - 2024-02-07 09:38:18 --> Security Class Initialized
DEBUG - 2024-02-07 09:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:38:18 --> Input Class Initialized
INFO - 2024-02-07 09:38:18 --> Language Class Initialized
INFO - 2024-02-07 09:38:18 --> Loader Class Initialized
INFO - 2024-02-07 09:38:18 --> Helper loaded: url_helper
INFO - 2024-02-07 09:38:18 --> Helper loaded: file_helper
INFO - 2024-02-07 09:38:18 --> Helper loaded: html_helper
INFO - 2024-02-07 09:38:18 --> Helper loaded: text_helper
INFO - 2024-02-07 09:38:18 --> Helper loaded: form_helper
INFO - 2024-02-07 09:38:18 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:38:18 --> Helper loaded: security_helper
INFO - 2024-02-07 09:38:18 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:38:18 --> Database Driver Class Initialized
INFO - 2024-02-07 09:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:38:18 --> Parser Class Initialized
INFO - 2024-02-07 09:38:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:38:18 --> Pagination Class Initialized
INFO - 2024-02-07 09:38:18 --> Form Validation Class Initialized
INFO - 2024-02-07 09:38:18 --> Controller Class Initialized
INFO - 2024-02-07 09:38:18 --> Model Class Initialized
DEBUG - 2024-02-07 09:38:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-07 09:38:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-02-07 09:38:18 --> Final output sent to browser
DEBUG - 2024-02-07 09:38:18 --> Total execution time: 0.0169
ERROR - 2024-02-07 09:38:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:38:22 --> Config Class Initialized
INFO - 2024-02-07 09:38:22 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:38:22 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:38:22 --> Utf8 Class Initialized
INFO - 2024-02-07 09:38:22 --> URI Class Initialized
INFO - 2024-02-07 09:38:22 --> Router Class Initialized
INFO - 2024-02-07 09:38:22 --> Output Class Initialized
INFO - 2024-02-07 09:38:22 --> Security Class Initialized
DEBUG - 2024-02-07 09:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:38:22 --> Input Class Initialized
INFO - 2024-02-07 09:38:22 --> Language Class Initialized
INFO - 2024-02-07 09:38:22 --> Loader Class Initialized
INFO - 2024-02-07 09:38:22 --> Helper loaded: url_helper
INFO - 2024-02-07 09:38:22 --> Helper loaded: file_helper
INFO - 2024-02-07 09:38:22 --> Helper loaded: html_helper
INFO - 2024-02-07 09:38:22 --> Helper loaded: text_helper
INFO - 2024-02-07 09:38:22 --> Helper loaded: form_helper
INFO - 2024-02-07 09:38:22 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:38:22 --> Helper loaded: security_helper
INFO - 2024-02-07 09:38:22 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:38:22 --> Database Driver Class Initialized
INFO - 2024-02-07 09:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:38:22 --> Parser Class Initialized
INFO - 2024-02-07 09:38:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:38:22 --> Pagination Class Initialized
INFO - 2024-02-07 09:38:22 --> Form Validation Class Initialized
INFO - 2024-02-07 09:38:22 --> Controller Class Initialized
INFO - 2024-02-07 09:38:22 --> Model Class Initialized
DEBUG - 2024-02-07 09:38:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-07 09:38:22 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-02-07 09:38:22 --> Final output sent to browser
DEBUG - 2024-02-07 09:38:22 --> Total execution time: 0.0153
ERROR - 2024-02-07 09:38:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:38:24 --> Config Class Initialized
INFO - 2024-02-07 09:38:24 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:38:24 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:38:24 --> Utf8 Class Initialized
INFO - 2024-02-07 09:38:24 --> URI Class Initialized
INFO - 2024-02-07 09:38:24 --> Router Class Initialized
INFO - 2024-02-07 09:38:24 --> Output Class Initialized
INFO - 2024-02-07 09:38:24 --> Security Class Initialized
DEBUG - 2024-02-07 09:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:38:24 --> Input Class Initialized
INFO - 2024-02-07 09:38:24 --> Language Class Initialized
INFO - 2024-02-07 09:38:24 --> Loader Class Initialized
INFO - 2024-02-07 09:38:24 --> Helper loaded: url_helper
INFO - 2024-02-07 09:38:24 --> Helper loaded: file_helper
INFO - 2024-02-07 09:38:24 --> Helper loaded: html_helper
INFO - 2024-02-07 09:38:24 --> Helper loaded: text_helper
INFO - 2024-02-07 09:38:24 --> Helper loaded: form_helper
INFO - 2024-02-07 09:38:24 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:38:24 --> Helper loaded: security_helper
INFO - 2024-02-07 09:38:24 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:38:24 --> Database Driver Class Initialized
INFO - 2024-02-07 09:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:38:24 --> Parser Class Initialized
INFO - 2024-02-07 09:38:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:38:24 --> Pagination Class Initialized
INFO - 2024-02-07 09:38:24 --> Form Validation Class Initialized
INFO - 2024-02-07 09:38:24 --> Controller Class Initialized
INFO - 2024-02-07 09:38:24 --> Model Class Initialized
DEBUG - 2024-02-07 09:38:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-07 09:38:24 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-02-07 09:38:24 --> Final output sent to browser
DEBUG - 2024-02-07 09:38:24 --> Total execution time: 0.0145
ERROR - 2024-02-07 09:38:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:38:28 --> Config Class Initialized
INFO - 2024-02-07 09:38:28 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:38:28 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:38:28 --> Utf8 Class Initialized
INFO - 2024-02-07 09:38:28 --> URI Class Initialized
INFO - 2024-02-07 09:38:28 --> Router Class Initialized
INFO - 2024-02-07 09:38:28 --> Output Class Initialized
INFO - 2024-02-07 09:38:28 --> Security Class Initialized
DEBUG - 2024-02-07 09:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:38:28 --> Input Class Initialized
INFO - 2024-02-07 09:38:28 --> Language Class Initialized
INFO - 2024-02-07 09:38:28 --> Loader Class Initialized
INFO - 2024-02-07 09:38:28 --> Helper loaded: url_helper
INFO - 2024-02-07 09:38:28 --> Helper loaded: file_helper
INFO - 2024-02-07 09:38:28 --> Helper loaded: html_helper
INFO - 2024-02-07 09:38:28 --> Helper loaded: text_helper
INFO - 2024-02-07 09:38:28 --> Helper loaded: form_helper
INFO - 2024-02-07 09:38:28 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:38:28 --> Helper loaded: security_helper
INFO - 2024-02-07 09:38:28 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:38:28 --> Database Driver Class Initialized
INFO - 2024-02-07 09:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:38:28 --> Parser Class Initialized
INFO - 2024-02-07 09:38:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:38:28 --> Pagination Class Initialized
INFO - 2024-02-07 09:38:28 --> Form Validation Class Initialized
INFO - 2024-02-07 09:38:28 --> Controller Class Initialized
INFO - 2024-02-07 09:38:28 --> Model Class Initialized
DEBUG - 2024-02-07 09:38:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-07 09:38:28 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-02-07 09:38:28 --> Final output sent to browser
DEBUG - 2024-02-07 09:38:28 --> Total execution time: 0.0153
ERROR - 2024-02-07 09:38:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:38:29 --> Config Class Initialized
INFO - 2024-02-07 09:38:29 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:38:29 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:38:29 --> Utf8 Class Initialized
INFO - 2024-02-07 09:38:29 --> URI Class Initialized
INFO - 2024-02-07 09:38:29 --> Router Class Initialized
INFO - 2024-02-07 09:38:29 --> Output Class Initialized
INFO - 2024-02-07 09:38:29 --> Security Class Initialized
DEBUG - 2024-02-07 09:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:38:29 --> Input Class Initialized
INFO - 2024-02-07 09:38:29 --> Language Class Initialized
INFO - 2024-02-07 09:38:29 --> Loader Class Initialized
INFO - 2024-02-07 09:38:29 --> Helper loaded: url_helper
INFO - 2024-02-07 09:38:29 --> Helper loaded: file_helper
INFO - 2024-02-07 09:38:29 --> Helper loaded: html_helper
INFO - 2024-02-07 09:38:29 --> Helper loaded: text_helper
INFO - 2024-02-07 09:38:29 --> Helper loaded: form_helper
INFO - 2024-02-07 09:38:29 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:38:29 --> Helper loaded: security_helper
INFO - 2024-02-07 09:38:29 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:38:29 --> Database Driver Class Initialized
INFO - 2024-02-07 09:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:38:29 --> Parser Class Initialized
INFO - 2024-02-07 09:38:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:38:29 --> Pagination Class Initialized
INFO - 2024-02-07 09:38:29 --> Form Validation Class Initialized
INFO - 2024-02-07 09:38:29 --> Controller Class Initialized
INFO - 2024-02-07 09:38:29 --> Model Class Initialized
DEBUG - 2024-02-07 09:38:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-07 09:38:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-02-07 09:38:29 --> Final output sent to browser
DEBUG - 2024-02-07 09:38:29 --> Total execution time: 0.0152
ERROR - 2024-02-07 09:38:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:38:30 --> Config Class Initialized
INFO - 2024-02-07 09:38:30 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:38:30 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:38:30 --> Utf8 Class Initialized
INFO - 2024-02-07 09:38:30 --> URI Class Initialized
INFO - 2024-02-07 09:38:30 --> Router Class Initialized
INFO - 2024-02-07 09:38:30 --> Output Class Initialized
INFO - 2024-02-07 09:38:30 --> Security Class Initialized
DEBUG - 2024-02-07 09:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:38:30 --> Input Class Initialized
INFO - 2024-02-07 09:38:30 --> Language Class Initialized
INFO - 2024-02-07 09:38:30 --> Loader Class Initialized
INFO - 2024-02-07 09:38:30 --> Helper loaded: url_helper
INFO - 2024-02-07 09:38:30 --> Helper loaded: file_helper
INFO - 2024-02-07 09:38:30 --> Helper loaded: html_helper
INFO - 2024-02-07 09:38:30 --> Helper loaded: text_helper
INFO - 2024-02-07 09:38:30 --> Helper loaded: form_helper
INFO - 2024-02-07 09:38:30 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:38:30 --> Helper loaded: security_helper
INFO - 2024-02-07 09:38:30 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:38:30 --> Database Driver Class Initialized
INFO - 2024-02-07 09:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:38:30 --> Parser Class Initialized
INFO - 2024-02-07 09:38:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:38:30 --> Pagination Class Initialized
INFO - 2024-02-07 09:38:30 --> Form Validation Class Initialized
INFO - 2024-02-07 09:38:30 --> Controller Class Initialized
INFO - 2024-02-07 09:38:30 --> Model Class Initialized
DEBUG - 2024-02-07 09:38:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-07 09:38:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-02-07 09:38:30 --> Final output sent to browser
DEBUG - 2024-02-07 09:38:30 --> Total execution time: 0.0148
ERROR - 2024-02-07 09:38:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:38:30 --> Config Class Initialized
INFO - 2024-02-07 09:38:30 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:38:30 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:38:30 --> Utf8 Class Initialized
INFO - 2024-02-07 09:38:30 --> URI Class Initialized
INFO - 2024-02-07 09:38:30 --> Router Class Initialized
INFO - 2024-02-07 09:38:30 --> Output Class Initialized
INFO - 2024-02-07 09:38:30 --> Security Class Initialized
DEBUG - 2024-02-07 09:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:38:30 --> Input Class Initialized
INFO - 2024-02-07 09:38:30 --> Language Class Initialized
INFO - 2024-02-07 09:38:30 --> Loader Class Initialized
INFO - 2024-02-07 09:38:30 --> Helper loaded: url_helper
INFO - 2024-02-07 09:38:30 --> Helper loaded: file_helper
INFO - 2024-02-07 09:38:30 --> Helper loaded: html_helper
INFO - 2024-02-07 09:38:30 --> Helper loaded: text_helper
INFO - 2024-02-07 09:38:30 --> Helper loaded: form_helper
INFO - 2024-02-07 09:38:30 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:38:30 --> Helper loaded: security_helper
INFO - 2024-02-07 09:38:30 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:38:30 --> Database Driver Class Initialized
INFO - 2024-02-07 09:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:38:30 --> Parser Class Initialized
INFO - 2024-02-07 09:38:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:38:30 --> Pagination Class Initialized
INFO - 2024-02-07 09:38:30 --> Form Validation Class Initialized
INFO - 2024-02-07 09:38:30 --> Controller Class Initialized
INFO - 2024-02-07 09:38:30 --> Model Class Initialized
DEBUG - 2024-02-07 09:38:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:38:30 --> Final output sent to browser
DEBUG - 2024-02-07 09:38:30 --> Total execution time: 0.0153
ERROR - 2024-02-07 09:38:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:38:31 --> Config Class Initialized
INFO - 2024-02-07 09:38:31 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:38:31 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:38:31 --> Utf8 Class Initialized
INFO - 2024-02-07 09:38:31 --> URI Class Initialized
INFO - 2024-02-07 09:38:31 --> Router Class Initialized
INFO - 2024-02-07 09:38:31 --> Output Class Initialized
INFO - 2024-02-07 09:38:31 --> Security Class Initialized
DEBUG - 2024-02-07 09:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:38:31 --> Input Class Initialized
INFO - 2024-02-07 09:38:31 --> Language Class Initialized
INFO - 2024-02-07 09:38:31 --> Loader Class Initialized
INFO - 2024-02-07 09:38:31 --> Helper loaded: url_helper
INFO - 2024-02-07 09:38:31 --> Helper loaded: file_helper
INFO - 2024-02-07 09:38:31 --> Helper loaded: html_helper
INFO - 2024-02-07 09:38:31 --> Helper loaded: text_helper
INFO - 2024-02-07 09:38:31 --> Helper loaded: form_helper
INFO - 2024-02-07 09:38:31 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:38:31 --> Helper loaded: security_helper
INFO - 2024-02-07 09:38:31 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:38:31 --> Database Driver Class Initialized
INFO - 2024-02-07 09:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:38:31 --> Parser Class Initialized
INFO - 2024-02-07 09:38:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:38:31 --> Pagination Class Initialized
INFO - 2024-02-07 09:38:31 --> Form Validation Class Initialized
INFO - 2024-02-07 09:38:31 --> Controller Class Initialized
INFO - 2024-02-07 09:38:31 --> Model Class Initialized
DEBUG - 2024-02-07 09:38:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:38:31 --> Final output sent to browser
DEBUG - 2024-02-07 09:38:31 --> Total execution time: 0.0153
ERROR - 2024-02-07 09:38:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:38:33 --> Config Class Initialized
INFO - 2024-02-07 09:38:33 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:38:33 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:38:33 --> Utf8 Class Initialized
INFO - 2024-02-07 09:38:33 --> URI Class Initialized
INFO - 2024-02-07 09:38:33 --> Router Class Initialized
INFO - 2024-02-07 09:38:33 --> Output Class Initialized
INFO - 2024-02-07 09:38:33 --> Security Class Initialized
DEBUG - 2024-02-07 09:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:38:33 --> Input Class Initialized
INFO - 2024-02-07 09:38:33 --> Language Class Initialized
INFO - 2024-02-07 09:38:33 --> Loader Class Initialized
INFO - 2024-02-07 09:38:33 --> Helper loaded: url_helper
INFO - 2024-02-07 09:38:33 --> Helper loaded: file_helper
INFO - 2024-02-07 09:38:33 --> Helper loaded: html_helper
INFO - 2024-02-07 09:38:33 --> Helper loaded: text_helper
INFO - 2024-02-07 09:38:33 --> Helper loaded: form_helper
INFO - 2024-02-07 09:38:33 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:38:33 --> Helper loaded: security_helper
INFO - 2024-02-07 09:38:33 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:38:33 --> Database Driver Class Initialized
INFO - 2024-02-07 09:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:38:33 --> Parser Class Initialized
INFO - 2024-02-07 09:38:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:38:33 --> Pagination Class Initialized
INFO - 2024-02-07 09:38:33 --> Form Validation Class Initialized
INFO - 2024-02-07 09:38:33 --> Controller Class Initialized
INFO - 2024-02-07 09:38:33 --> Model Class Initialized
DEBUG - 2024-02-07 09:38:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 09:38:33 --> Final output sent to browser
DEBUG - 2024-02-07 09:38:33 --> Total execution time: 0.0185
ERROR - 2024-02-07 09:38:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:38:34 --> Config Class Initialized
INFO - 2024-02-07 09:38:34 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:38:34 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:38:34 --> Utf8 Class Initialized
INFO - 2024-02-07 09:38:34 --> URI Class Initialized
INFO - 2024-02-07 09:38:34 --> Router Class Initialized
INFO - 2024-02-07 09:38:34 --> Output Class Initialized
INFO - 2024-02-07 09:38:34 --> Security Class Initialized
DEBUG - 2024-02-07 09:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:38:34 --> Input Class Initialized
INFO - 2024-02-07 09:38:34 --> Language Class Initialized
INFO - 2024-02-07 09:38:34 --> Loader Class Initialized
INFO - 2024-02-07 09:38:34 --> Helper loaded: url_helper
INFO - 2024-02-07 09:38:34 --> Helper loaded: file_helper
INFO - 2024-02-07 09:38:34 --> Helper loaded: html_helper
INFO - 2024-02-07 09:38:34 --> Helper loaded: text_helper
INFO - 2024-02-07 09:38:34 --> Helper loaded: form_helper
INFO - 2024-02-07 09:38:34 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:38:34 --> Helper loaded: security_helper
INFO - 2024-02-07 09:38:34 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:38:34 --> Database Driver Class Initialized
INFO - 2024-02-07 09:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:38:34 --> Parser Class Initialized
INFO - 2024-02-07 09:38:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:38:34 --> Pagination Class Initialized
INFO - 2024-02-07 09:38:34 --> Form Validation Class Initialized
INFO - 2024-02-07 09:38:34 --> Controller Class Initialized
INFO - 2024-02-07 09:38:34 --> Model Class Initialized
DEBUG - 2024-02-07 09:38:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-07 09:38:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-02-07 09:38:34 --> Final output sent to browser
DEBUG - 2024-02-07 09:38:34 --> Total execution time: 0.0152
ERROR - 2024-02-07 09:38:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:38:37 --> Config Class Initialized
INFO - 2024-02-07 09:38:37 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:38:37 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:38:37 --> Utf8 Class Initialized
INFO - 2024-02-07 09:38:37 --> URI Class Initialized
INFO - 2024-02-07 09:38:37 --> Router Class Initialized
INFO - 2024-02-07 09:38:37 --> Output Class Initialized
INFO - 2024-02-07 09:38:37 --> Security Class Initialized
DEBUG - 2024-02-07 09:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:38:37 --> Input Class Initialized
INFO - 2024-02-07 09:38:37 --> Language Class Initialized
INFO - 2024-02-07 09:38:37 --> Loader Class Initialized
INFO - 2024-02-07 09:38:37 --> Helper loaded: url_helper
INFO - 2024-02-07 09:38:37 --> Helper loaded: file_helper
INFO - 2024-02-07 09:38:37 --> Helper loaded: html_helper
INFO - 2024-02-07 09:38:37 --> Helper loaded: text_helper
INFO - 2024-02-07 09:38:37 --> Helper loaded: form_helper
INFO - 2024-02-07 09:38:37 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:38:37 --> Helper loaded: security_helper
INFO - 2024-02-07 09:38:37 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:38:37 --> Database Driver Class Initialized
INFO - 2024-02-07 09:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:38:37 --> Parser Class Initialized
INFO - 2024-02-07 09:38:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:38:37 --> Pagination Class Initialized
INFO - 2024-02-07 09:38:37 --> Form Validation Class Initialized
INFO - 2024-02-07 09:38:37 --> Controller Class Initialized
INFO - 2024-02-07 09:38:37 --> Model Class Initialized
DEBUG - 2024-02-07 09:38:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-07 09:38:37 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-02-07 09:38:37 --> Final output sent to browser
DEBUG - 2024-02-07 09:38:37 --> Total execution time: 0.0181
ERROR - 2024-02-07 09:38:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:38:38 --> Config Class Initialized
INFO - 2024-02-07 09:38:38 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:38:38 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:38:38 --> Utf8 Class Initialized
INFO - 2024-02-07 09:38:38 --> URI Class Initialized
INFO - 2024-02-07 09:38:38 --> Router Class Initialized
INFO - 2024-02-07 09:38:38 --> Output Class Initialized
INFO - 2024-02-07 09:38:38 --> Security Class Initialized
DEBUG - 2024-02-07 09:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:38:38 --> Input Class Initialized
INFO - 2024-02-07 09:38:38 --> Language Class Initialized
INFO - 2024-02-07 09:38:38 --> Loader Class Initialized
INFO - 2024-02-07 09:38:38 --> Helper loaded: url_helper
INFO - 2024-02-07 09:38:38 --> Helper loaded: file_helper
INFO - 2024-02-07 09:38:38 --> Helper loaded: html_helper
INFO - 2024-02-07 09:38:38 --> Helper loaded: text_helper
INFO - 2024-02-07 09:38:38 --> Helper loaded: form_helper
INFO - 2024-02-07 09:38:38 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:38:38 --> Helper loaded: security_helper
INFO - 2024-02-07 09:38:38 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:38:38 --> Database Driver Class Initialized
INFO - 2024-02-07 09:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:38:38 --> Parser Class Initialized
INFO - 2024-02-07 09:38:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:38:38 --> Pagination Class Initialized
INFO - 2024-02-07 09:38:38 --> Form Validation Class Initialized
INFO - 2024-02-07 09:38:38 --> Controller Class Initialized
INFO - 2024-02-07 09:38:38 --> Model Class Initialized
DEBUG - 2024-02-07 09:38:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-07 09:38:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-02-07 09:38:38 --> Final output sent to browser
DEBUG - 2024-02-07 09:38:38 --> Total execution time: 0.0182
ERROR - 2024-02-07 09:38:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:38:38 --> Config Class Initialized
INFO - 2024-02-07 09:38:38 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:38:38 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:38:38 --> Utf8 Class Initialized
INFO - 2024-02-07 09:38:38 --> URI Class Initialized
INFO - 2024-02-07 09:38:38 --> Router Class Initialized
INFO - 2024-02-07 09:38:38 --> Output Class Initialized
INFO - 2024-02-07 09:38:38 --> Security Class Initialized
DEBUG - 2024-02-07 09:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:38:38 --> Input Class Initialized
INFO - 2024-02-07 09:38:38 --> Language Class Initialized
INFO - 2024-02-07 09:38:38 --> Loader Class Initialized
INFO - 2024-02-07 09:38:38 --> Helper loaded: url_helper
INFO - 2024-02-07 09:38:38 --> Helper loaded: file_helper
INFO - 2024-02-07 09:38:38 --> Helper loaded: html_helper
INFO - 2024-02-07 09:38:38 --> Helper loaded: text_helper
INFO - 2024-02-07 09:38:38 --> Helper loaded: form_helper
INFO - 2024-02-07 09:38:38 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:38:38 --> Helper loaded: security_helper
INFO - 2024-02-07 09:38:38 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:38:38 --> Database Driver Class Initialized
INFO - 2024-02-07 09:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:38:38 --> Parser Class Initialized
INFO - 2024-02-07 09:38:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:38:38 --> Pagination Class Initialized
INFO - 2024-02-07 09:38:38 --> Form Validation Class Initialized
INFO - 2024-02-07 09:38:38 --> Controller Class Initialized
INFO - 2024-02-07 09:38:38 --> Model Class Initialized
DEBUG - 2024-02-07 09:38:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-07 09:38:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-02-07 09:38:38 --> Final output sent to browser
DEBUG - 2024-02-07 09:38:38 --> Total execution time: 0.0151
ERROR - 2024-02-07 09:38:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 09:38:39 --> Config Class Initialized
INFO - 2024-02-07 09:38:39 --> Hooks Class Initialized
DEBUG - 2024-02-07 09:38:39 --> UTF-8 Support Enabled
INFO - 2024-02-07 09:38:39 --> Utf8 Class Initialized
INFO - 2024-02-07 09:38:39 --> URI Class Initialized
INFO - 2024-02-07 09:38:39 --> Router Class Initialized
INFO - 2024-02-07 09:38:39 --> Output Class Initialized
INFO - 2024-02-07 09:38:39 --> Security Class Initialized
DEBUG - 2024-02-07 09:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 09:38:39 --> Input Class Initialized
INFO - 2024-02-07 09:38:39 --> Language Class Initialized
INFO - 2024-02-07 09:38:39 --> Loader Class Initialized
INFO - 2024-02-07 09:38:39 --> Helper loaded: url_helper
INFO - 2024-02-07 09:38:39 --> Helper loaded: file_helper
INFO - 2024-02-07 09:38:39 --> Helper loaded: html_helper
INFO - 2024-02-07 09:38:39 --> Helper loaded: text_helper
INFO - 2024-02-07 09:38:39 --> Helper loaded: form_helper
INFO - 2024-02-07 09:38:39 --> Helper loaded: lang_helper
INFO - 2024-02-07 09:38:39 --> Helper loaded: security_helper
INFO - 2024-02-07 09:38:39 --> Helper loaded: cookie_helper
INFO - 2024-02-07 09:38:39 --> Database Driver Class Initialized
INFO - 2024-02-07 09:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 09:38:39 --> Parser Class Initialized
INFO - 2024-02-07 09:38:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 09:38:39 --> Pagination Class Initialized
INFO - 2024-02-07 09:38:39 --> Form Validation Class Initialized
INFO - 2024-02-07 09:38:39 --> Controller Class Initialized
INFO - 2024-02-07 09:38:39 --> Model Class Initialized
DEBUG - 2024-02-07 09:38:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-07 09:38:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-02-07 09:38:39 --> Final output sent to browser
DEBUG - 2024-02-07 09:38:39 --> Total execution time: 0.0148
ERROR - 2024-02-07 10:13:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 10:13:20 --> Config Class Initialized
INFO - 2024-02-07 10:13:20 --> Hooks Class Initialized
DEBUG - 2024-02-07 10:13:20 --> UTF-8 Support Enabled
INFO - 2024-02-07 10:13:20 --> Utf8 Class Initialized
INFO - 2024-02-07 10:13:20 --> URI Class Initialized
DEBUG - 2024-02-07 10:13:20 --> No URI present. Default controller set.
INFO - 2024-02-07 10:13:20 --> Router Class Initialized
INFO - 2024-02-07 10:13:20 --> Output Class Initialized
INFO - 2024-02-07 10:13:20 --> Security Class Initialized
DEBUG - 2024-02-07 10:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 10:13:20 --> Input Class Initialized
INFO - 2024-02-07 10:13:20 --> Language Class Initialized
INFO - 2024-02-07 10:13:20 --> Loader Class Initialized
INFO - 2024-02-07 10:13:20 --> Helper loaded: url_helper
INFO - 2024-02-07 10:13:20 --> Helper loaded: file_helper
INFO - 2024-02-07 10:13:20 --> Helper loaded: html_helper
INFO - 2024-02-07 10:13:20 --> Helper loaded: text_helper
INFO - 2024-02-07 10:13:20 --> Helper loaded: form_helper
INFO - 2024-02-07 10:13:20 --> Helper loaded: lang_helper
INFO - 2024-02-07 10:13:20 --> Helper loaded: security_helper
INFO - 2024-02-07 10:13:20 --> Helper loaded: cookie_helper
INFO - 2024-02-07 10:13:20 --> Database Driver Class Initialized
INFO - 2024-02-07 10:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 10:13:20 --> Parser Class Initialized
INFO - 2024-02-07 10:13:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 10:13:20 --> Pagination Class Initialized
INFO - 2024-02-07 10:13:20 --> Form Validation Class Initialized
INFO - 2024-02-07 10:13:20 --> Controller Class Initialized
INFO - 2024-02-07 10:13:20 --> Model Class Initialized
DEBUG - 2024-02-07 10:13:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 10:13:20 --> Model Class Initialized
DEBUG - 2024-02-07 10:13:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 10:13:20 --> Model Class Initialized
INFO - 2024-02-07 10:13:20 --> Model Class Initialized
INFO - 2024-02-07 10:13:20 --> Model Class Initialized
INFO - 2024-02-07 10:13:20 --> Model Class Initialized
DEBUG - 2024-02-07 10:13:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 10:13:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 10:13:20 --> Model Class Initialized
INFO - 2024-02-07 10:13:20 --> Model Class Initialized
INFO - 2024-02-07 10:13:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-07 10:13:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 10:13:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 10:13:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 10:13:21 --> Model Class Initialized
INFO - 2024-02-07 10:13:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 10:13:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 10:13:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 10:13:21 --> Final output sent to browser
DEBUG - 2024-02-07 10:13:21 --> Total execution time: 0.4161
ERROR - 2024-02-07 13:38:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 13:38:01 --> Config Class Initialized
INFO - 2024-02-07 13:38:01 --> Hooks Class Initialized
DEBUG - 2024-02-07 13:38:01 --> UTF-8 Support Enabled
INFO - 2024-02-07 13:38:01 --> Utf8 Class Initialized
INFO - 2024-02-07 13:38:01 --> URI Class Initialized
INFO - 2024-02-07 13:38:01 --> Router Class Initialized
INFO - 2024-02-07 13:38:01 --> Output Class Initialized
INFO - 2024-02-07 13:38:01 --> Security Class Initialized
DEBUG - 2024-02-07 13:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 13:38:01 --> Input Class Initialized
INFO - 2024-02-07 13:38:01 --> Language Class Initialized
ERROR - 2024-02-07 13:38:01 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-02-07 16:11:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 16:11:32 --> Config Class Initialized
INFO - 2024-02-07 16:11:32 --> Hooks Class Initialized
DEBUG - 2024-02-07 16:11:32 --> UTF-8 Support Enabled
INFO - 2024-02-07 16:11:32 --> Utf8 Class Initialized
INFO - 2024-02-07 16:11:32 --> URI Class Initialized
DEBUG - 2024-02-07 16:11:32 --> No URI present. Default controller set.
INFO - 2024-02-07 16:11:32 --> Router Class Initialized
INFO - 2024-02-07 16:11:32 --> Output Class Initialized
INFO - 2024-02-07 16:11:32 --> Security Class Initialized
DEBUG - 2024-02-07 16:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 16:11:32 --> Input Class Initialized
INFO - 2024-02-07 16:11:32 --> Language Class Initialized
INFO - 2024-02-07 16:11:32 --> Loader Class Initialized
INFO - 2024-02-07 16:11:32 --> Helper loaded: url_helper
INFO - 2024-02-07 16:11:32 --> Helper loaded: file_helper
INFO - 2024-02-07 16:11:32 --> Helper loaded: html_helper
INFO - 2024-02-07 16:11:32 --> Helper loaded: text_helper
INFO - 2024-02-07 16:11:32 --> Helper loaded: form_helper
INFO - 2024-02-07 16:11:32 --> Helper loaded: lang_helper
INFO - 2024-02-07 16:11:32 --> Helper loaded: security_helper
INFO - 2024-02-07 16:11:32 --> Helper loaded: cookie_helper
INFO - 2024-02-07 16:11:32 --> Database Driver Class Initialized
INFO - 2024-02-07 16:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 16:11:32 --> Parser Class Initialized
INFO - 2024-02-07 16:11:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 16:11:32 --> Pagination Class Initialized
INFO - 2024-02-07 16:11:32 --> Form Validation Class Initialized
INFO - 2024-02-07 16:11:32 --> Controller Class Initialized
INFO - 2024-02-07 16:11:32 --> Model Class Initialized
DEBUG - 2024-02-07 16:11:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-07 16:11:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 16:11:32 --> Config Class Initialized
INFO - 2024-02-07 16:11:32 --> Hooks Class Initialized
DEBUG - 2024-02-07 16:11:32 --> UTF-8 Support Enabled
INFO - 2024-02-07 16:11:32 --> Utf8 Class Initialized
INFO - 2024-02-07 16:11:32 --> URI Class Initialized
INFO - 2024-02-07 16:11:32 --> Router Class Initialized
INFO - 2024-02-07 16:11:32 --> Output Class Initialized
INFO - 2024-02-07 16:11:32 --> Security Class Initialized
DEBUG - 2024-02-07 16:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 16:11:32 --> Input Class Initialized
INFO - 2024-02-07 16:11:32 --> Language Class Initialized
INFO - 2024-02-07 16:11:32 --> Loader Class Initialized
INFO - 2024-02-07 16:11:32 --> Helper loaded: url_helper
INFO - 2024-02-07 16:11:32 --> Helper loaded: file_helper
INFO - 2024-02-07 16:11:32 --> Helper loaded: html_helper
INFO - 2024-02-07 16:11:32 --> Helper loaded: text_helper
INFO - 2024-02-07 16:11:32 --> Helper loaded: form_helper
INFO - 2024-02-07 16:11:32 --> Helper loaded: lang_helper
INFO - 2024-02-07 16:11:32 --> Helper loaded: security_helper
INFO - 2024-02-07 16:11:32 --> Helper loaded: cookie_helper
INFO - 2024-02-07 16:11:32 --> Database Driver Class Initialized
INFO - 2024-02-07 16:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 16:11:32 --> Parser Class Initialized
INFO - 2024-02-07 16:11:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 16:11:32 --> Pagination Class Initialized
INFO - 2024-02-07 16:11:32 --> Form Validation Class Initialized
INFO - 2024-02-07 16:11:32 --> Controller Class Initialized
INFO - 2024-02-07 16:11:32 --> Model Class Initialized
DEBUG - 2024-02-07 16:11:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 16:11:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-07 16:11:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 16:11:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 16:11:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 16:11:32 --> Model Class Initialized
INFO - 2024-02-07 16:11:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 16:11:32 --> Final output sent to browser
DEBUG - 2024-02-07 16:11:32 --> Total execution time: 0.0359
ERROR - 2024-02-07 16:11:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 16:11:43 --> Config Class Initialized
INFO - 2024-02-07 16:11:43 --> Hooks Class Initialized
DEBUG - 2024-02-07 16:11:43 --> UTF-8 Support Enabled
INFO - 2024-02-07 16:11:43 --> Utf8 Class Initialized
INFO - 2024-02-07 16:11:43 --> URI Class Initialized
INFO - 2024-02-07 16:11:43 --> Router Class Initialized
INFO - 2024-02-07 16:11:43 --> Output Class Initialized
INFO - 2024-02-07 16:11:43 --> Security Class Initialized
DEBUG - 2024-02-07 16:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 16:11:43 --> Input Class Initialized
INFO - 2024-02-07 16:11:43 --> Language Class Initialized
INFO - 2024-02-07 16:11:43 --> Loader Class Initialized
INFO - 2024-02-07 16:11:43 --> Helper loaded: url_helper
INFO - 2024-02-07 16:11:43 --> Helper loaded: file_helper
INFO - 2024-02-07 16:11:43 --> Helper loaded: html_helper
INFO - 2024-02-07 16:11:43 --> Helper loaded: text_helper
INFO - 2024-02-07 16:11:43 --> Helper loaded: form_helper
INFO - 2024-02-07 16:11:43 --> Helper loaded: lang_helper
INFO - 2024-02-07 16:11:43 --> Helper loaded: security_helper
INFO - 2024-02-07 16:11:43 --> Helper loaded: cookie_helper
INFO - 2024-02-07 16:11:43 --> Database Driver Class Initialized
INFO - 2024-02-07 16:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 16:11:43 --> Parser Class Initialized
INFO - 2024-02-07 16:11:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 16:11:43 --> Pagination Class Initialized
INFO - 2024-02-07 16:11:43 --> Form Validation Class Initialized
INFO - 2024-02-07 16:11:43 --> Controller Class Initialized
INFO - 2024-02-07 16:11:43 --> Model Class Initialized
DEBUG - 2024-02-07 16:11:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 16:11:43 --> Model Class Initialized
INFO - 2024-02-07 16:11:43 --> Final output sent to browser
DEBUG - 2024-02-07 16:11:43 --> Total execution time: 0.0194
ERROR - 2024-02-07 16:11:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 16:11:43 --> Config Class Initialized
INFO - 2024-02-07 16:11:43 --> Hooks Class Initialized
DEBUG - 2024-02-07 16:11:43 --> UTF-8 Support Enabled
INFO - 2024-02-07 16:11:43 --> Utf8 Class Initialized
INFO - 2024-02-07 16:11:43 --> URI Class Initialized
DEBUG - 2024-02-07 16:11:43 --> No URI present. Default controller set.
INFO - 2024-02-07 16:11:43 --> Router Class Initialized
INFO - 2024-02-07 16:11:43 --> Output Class Initialized
INFO - 2024-02-07 16:11:43 --> Security Class Initialized
DEBUG - 2024-02-07 16:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 16:11:43 --> Input Class Initialized
INFO - 2024-02-07 16:11:43 --> Language Class Initialized
INFO - 2024-02-07 16:11:43 --> Loader Class Initialized
INFO - 2024-02-07 16:11:43 --> Helper loaded: url_helper
INFO - 2024-02-07 16:11:43 --> Helper loaded: file_helper
INFO - 2024-02-07 16:11:43 --> Helper loaded: html_helper
INFO - 2024-02-07 16:11:43 --> Helper loaded: text_helper
INFO - 2024-02-07 16:11:43 --> Helper loaded: form_helper
INFO - 2024-02-07 16:11:43 --> Helper loaded: lang_helper
INFO - 2024-02-07 16:11:43 --> Helper loaded: security_helper
INFO - 2024-02-07 16:11:43 --> Helper loaded: cookie_helper
INFO - 2024-02-07 16:11:43 --> Database Driver Class Initialized
INFO - 2024-02-07 16:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 16:11:43 --> Parser Class Initialized
INFO - 2024-02-07 16:11:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 16:11:43 --> Pagination Class Initialized
INFO - 2024-02-07 16:11:43 --> Form Validation Class Initialized
INFO - 2024-02-07 16:11:43 --> Controller Class Initialized
INFO - 2024-02-07 16:11:43 --> Model Class Initialized
DEBUG - 2024-02-07 16:11:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 16:11:43 --> Model Class Initialized
DEBUG - 2024-02-07 16:11:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 16:11:43 --> Model Class Initialized
INFO - 2024-02-07 16:11:43 --> Model Class Initialized
INFO - 2024-02-07 16:11:43 --> Model Class Initialized
INFO - 2024-02-07 16:11:43 --> Model Class Initialized
DEBUG - 2024-02-07 16:11:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 16:11:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 16:11:43 --> Model Class Initialized
INFO - 2024-02-07 16:11:43 --> Model Class Initialized
INFO - 2024-02-07 16:11:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-07 16:11:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 16:11:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 16:11:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 16:11:43 --> Model Class Initialized
INFO - 2024-02-07 16:11:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 16:11:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 16:11:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 16:11:43 --> Final output sent to browser
DEBUG - 2024-02-07 16:11:43 --> Total execution time: 0.4249
ERROR - 2024-02-07 16:11:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 16:11:44 --> Config Class Initialized
INFO - 2024-02-07 16:11:44 --> Hooks Class Initialized
DEBUG - 2024-02-07 16:11:44 --> UTF-8 Support Enabled
INFO - 2024-02-07 16:11:44 --> Utf8 Class Initialized
INFO - 2024-02-07 16:11:44 --> URI Class Initialized
INFO - 2024-02-07 16:11:44 --> Router Class Initialized
INFO - 2024-02-07 16:11:44 --> Output Class Initialized
INFO - 2024-02-07 16:11:44 --> Security Class Initialized
DEBUG - 2024-02-07 16:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 16:11:44 --> Input Class Initialized
INFO - 2024-02-07 16:11:45 --> Language Class Initialized
INFO - 2024-02-07 16:11:45 --> Loader Class Initialized
INFO - 2024-02-07 16:11:45 --> Helper loaded: url_helper
INFO - 2024-02-07 16:11:45 --> Helper loaded: file_helper
INFO - 2024-02-07 16:11:45 --> Helper loaded: html_helper
INFO - 2024-02-07 16:11:45 --> Helper loaded: text_helper
INFO - 2024-02-07 16:11:45 --> Helper loaded: form_helper
INFO - 2024-02-07 16:11:45 --> Helper loaded: lang_helper
INFO - 2024-02-07 16:11:45 --> Helper loaded: security_helper
INFO - 2024-02-07 16:11:45 --> Helper loaded: cookie_helper
INFO - 2024-02-07 16:11:45 --> Database Driver Class Initialized
INFO - 2024-02-07 16:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 16:11:45 --> Parser Class Initialized
INFO - 2024-02-07 16:11:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 16:11:45 --> Pagination Class Initialized
INFO - 2024-02-07 16:11:45 --> Form Validation Class Initialized
INFO - 2024-02-07 16:11:45 --> Controller Class Initialized
DEBUG - 2024-02-07 16:11:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 16:11:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 16:11:45 --> Model Class Initialized
INFO - 2024-02-07 16:11:45 --> Final output sent to browser
DEBUG - 2024-02-07 16:11:45 --> Total execution time: 0.0149
ERROR - 2024-02-07 16:11:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 16:11:57 --> Config Class Initialized
INFO - 2024-02-07 16:11:57 --> Hooks Class Initialized
DEBUG - 2024-02-07 16:11:57 --> UTF-8 Support Enabled
INFO - 2024-02-07 16:11:57 --> Utf8 Class Initialized
INFO - 2024-02-07 16:11:57 --> URI Class Initialized
INFO - 2024-02-07 16:11:57 --> Router Class Initialized
INFO - 2024-02-07 16:11:57 --> Output Class Initialized
INFO - 2024-02-07 16:11:57 --> Security Class Initialized
DEBUG - 2024-02-07 16:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 16:11:57 --> Input Class Initialized
INFO - 2024-02-07 16:11:57 --> Language Class Initialized
INFO - 2024-02-07 16:11:57 --> Loader Class Initialized
INFO - 2024-02-07 16:11:57 --> Helper loaded: url_helper
INFO - 2024-02-07 16:11:57 --> Helper loaded: file_helper
INFO - 2024-02-07 16:11:57 --> Helper loaded: html_helper
INFO - 2024-02-07 16:11:57 --> Helper loaded: text_helper
INFO - 2024-02-07 16:11:57 --> Helper loaded: form_helper
INFO - 2024-02-07 16:11:57 --> Helper loaded: lang_helper
INFO - 2024-02-07 16:11:57 --> Helper loaded: security_helper
INFO - 2024-02-07 16:11:57 --> Helper loaded: cookie_helper
INFO - 2024-02-07 16:11:57 --> Database Driver Class Initialized
INFO - 2024-02-07 16:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 16:11:57 --> Parser Class Initialized
INFO - 2024-02-07 16:11:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 16:11:57 --> Pagination Class Initialized
INFO - 2024-02-07 16:11:57 --> Form Validation Class Initialized
INFO - 2024-02-07 16:11:57 --> Controller Class Initialized
DEBUG - 2024-02-07 16:11:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 16:11:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 16:11:57 --> Model Class Initialized
DEBUG - 2024-02-07 16:11:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 16:11:57 --> Model Class Initialized
DEBUG - 2024-02-07 16:11:57 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-07 16:11:57 --> Model Class Initialized
INFO - 2024-02-07 16:11:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-07 16:11:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 16:11:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 16:11:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 16:11:57 --> Model Class Initialized
INFO - 2024-02-07 16:11:57 --> Model Class Initialized
INFO - 2024-02-07 16:11:57 --> Model Class Initialized
INFO - 2024-02-07 16:11:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 16:11:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 16:11:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 16:11:57 --> Final output sent to browser
DEBUG - 2024-02-07 16:11:57 --> Total execution time: 0.2432
ERROR - 2024-02-07 16:11:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 16:11:58 --> Config Class Initialized
INFO - 2024-02-07 16:11:58 --> Hooks Class Initialized
DEBUG - 2024-02-07 16:11:58 --> UTF-8 Support Enabled
INFO - 2024-02-07 16:11:58 --> Utf8 Class Initialized
INFO - 2024-02-07 16:11:58 --> URI Class Initialized
INFO - 2024-02-07 16:11:58 --> Router Class Initialized
INFO - 2024-02-07 16:11:58 --> Output Class Initialized
INFO - 2024-02-07 16:11:58 --> Security Class Initialized
DEBUG - 2024-02-07 16:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 16:11:58 --> Input Class Initialized
INFO - 2024-02-07 16:11:58 --> Language Class Initialized
INFO - 2024-02-07 16:11:58 --> Loader Class Initialized
INFO - 2024-02-07 16:11:58 --> Helper loaded: url_helper
INFO - 2024-02-07 16:11:58 --> Helper loaded: file_helper
INFO - 2024-02-07 16:11:58 --> Helper loaded: html_helper
INFO - 2024-02-07 16:11:58 --> Helper loaded: text_helper
INFO - 2024-02-07 16:11:58 --> Helper loaded: form_helper
INFO - 2024-02-07 16:11:58 --> Helper loaded: lang_helper
INFO - 2024-02-07 16:11:58 --> Helper loaded: security_helper
INFO - 2024-02-07 16:11:58 --> Helper loaded: cookie_helper
INFO - 2024-02-07 16:11:58 --> Database Driver Class Initialized
INFO - 2024-02-07 16:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 16:11:58 --> Parser Class Initialized
INFO - 2024-02-07 16:11:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 16:11:58 --> Pagination Class Initialized
INFO - 2024-02-07 16:11:58 --> Form Validation Class Initialized
INFO - 2024-02-07 16:11:58 --> Controller Class Initialized
DEBUG - 2024-02-07 16:11:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 16:11:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 16:11:58 --> Model Class Initialized
DEBUG - 2024-02-07 16:11:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 16:11:58 --> Model Class Initialized
INFO - 2024-02-07 16:11:58 --> Final output sent to browser
DEBUG - 2024-02-07 16:11:58 --> Total execution time: 0.0315
ERROR - 2024-02-07 16:12:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 16:12:07 --> Config Class Initialized
INFO - 2024-02-07 16:12:07 --> Hooks Class Initialized
DEBUG - 2024-02-07 16:12:07 --> UTF-8 Support Enabled
INFO - 2024-02-07 16:12:07 --> Utf8 Class Initialized
INFO - 2024-02-07 16:12:07 --> URI Class Initialized
INFO - 2024-02-07 16:12:07 --> Router Class Initialized
INFO - 2024-02-07 16:12:07 --> Output Class Initialized
INFO - 2024-02-07 16:12:07 --> Security Class Initialized
DEBUG - 2024-02-07 16:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 16:12:07 --> Input Class Initialized
INFO - 2024-02-07 16:12:07 --> Language Class Initialized
INFO - 2024-02-07 16:12:07 --> Loader Class Initialized
INFO - 2024-02-07 16:12:07 --> Helper loaded: url_helper
INFO - 2024-02-07 16:12:07 --> Helper loaded: file_helper
INFO - 2024-02-07 16:12:07 --> Helper loaded: html_helper
INFO - 2024-02-07 16:12:07 --> Helper loaded: text_helper
INFO - 2024-02-07 16:12:07 --> Helper loaded: form_helper
INFO - 2024-02-07 16:12:07 --> Helper loaded: lang_helper
INFO - 2024-02-07 16:12:07 --> Helper loaded: security_helper
INFO - 2024-02-07 16:12:07 --> Helper loaded: cookie_helper
INFO - 2024-02-07 16:12:07 --> Database Driver Class Initialized
INFO - 2024-02-07 16:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 16:12:07 --> Parser Class Initialized
INFO - 2024-02-07 16:12:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 16:12:07 --> Pagination Class Initialized
INFO - 2024-02-07 16:12:07 --> Form Validation Class Initialized
INFO - 2024-02-07 16:12:07 --> Controller Class Initialized
DEBUG - 2024-02-07 16:12:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 16:12:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 16:12:07 --> Model Class Initialized
DEBUG - 2024-02-07 16:12:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 16:12:07 --> Model Class Initialized
INFO - 2024-02-07 16:12:07 --> Final output sent to browser
DEBUG - 2024-02-07 16:12:07 --> Total execution time: 0.2032
ERROR - 2024-02-07 16:13:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 16:13:22 --> Config Class Initialized
INFO - 2024-02-07 16:13:22 --> Hooks Class Initialized
DEBUG - 2024-02-07 16:13:22 --> UTF-8 Support Enabled
INFO - 2024-02-07 16:13:22 --> Utf8 Class Initialized
INFO - 2024-02-07 16:13:22 --> URI Class Initialized
DEBUG - 2024-02-07 16:13:22 --> No URI present. Default controller set.
INFO - 2024-02-07 16:13:22 --> Router Class Initialized
INFO - 2024-02-07 16:13:22 --> Output Class Initialized
INFO - 2024-02-07 16:13:22 --> Security Class Initialized
DEBUG - 2024-02-07 16:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 16:13:22 --> Input Class Initialized
INFO - 2024-02-07 16:13:22 --> Language Class Initialized
INFO - 2024-02-07 16:13:22 --> Loader Class Initialized
INFO - 2024-02-07 16:13:22 --> Helper loaded: url_helper
INFO - 2024-02-07 16:13:22 --> Helper loaded: file_helper
INFO - 2024-02-07 16:13:22 --> Helper loaded: html_helper
INFO - 2024-02-07 16:13:22 --> Helper loaded: text_helper
INFO - 2024-02-07 16:13:22 --> Helper loaded: form_helper
INFO - 2024-02-07 16:13:22 --> Helper loaded: lang_helper
INFO - 2024-02-07 16:13:22 --> Helper loaded: security_helper
INFO - 2024-02-07 16:13:22 --> Helper loaded: cookie_helper
INFO - 2024-02-07 16:13:22 --> Database Driver Class Initialized
INFO - 2024-02-07 16:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 16:13:22 --> Parser Class Initialized
INFO - 2024-02-07 16:13:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 16:13:22 --> Pagination Class Initialized
INFO - 2024-02-07 16:13:22 --> Form Validation Class Initialized
INFO - 2024-02-07 16:13:22 --> Controller Class Initialized
INFO - 2024-02-07 16:13:22 --> Model Class Initialized
DEBUG - 2024-02-07 16:13:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 16:13:22 --> Model Class Initialized
DEBUG - 2024-02-07 16:13:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 16:13:22 --> Model Class Initialized
INFO - 2024-02-07 16:13:22 --> Model Class Initialized
INFO - 2024-02-07 16:13:22 --> Model Class Initialized
INFO - 2024-02-07 16:13:22 --> Model Class Initialized
DEBUG - 2024-02-07 16:13:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 16:13:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 16:13:22 --> Model Class Initialized
INFO - 2024-02-07 16:13:22 --> Model Class Initialized
INFO - 2024-02-07 16:13:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-07 16:13:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 16:13:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 16:13:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 16:13:23 --> Model Class Initialized
INFO - 2024-02-07 16:13:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 16:13:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 16:13:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 16:13:23 --> Final output sent to browser
DEBUG - 2024-02-07 16:13:23 --> Total execution time: 0.4002
ERROR - 2024-02-07 16:13:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 16:13:24 --> Config Class Initialized
INFO - 2024-02-07 16:13:24 --> Hooks Class Initialized
DEBUG - 2024-02-07 16:13:24 --> UTF-8 Support Enabled
INFO - 2024-02-07 16:13:24 --> Utf8 Class Initialized
INFO - 2024-02-07 16:13:24 --> URI Class Initialized
INFO - 2024-02-07 16:13:24 --> Router Class Initialized
INFO - 2024-02-07 16:13:24 --> Output Class Initialized
INFO - 2024-02-07 16:13:24 --> Security Class Initialized
DEBUG - 2024-02-07 16:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 16:13:24 --> Input Class Initialized
INFO - 2024-02-07 16:13:24 --> Language Class Initialized
INFO - 2024-02-07 16:13:24 --> Loader Class Initialized
INFO - 2024-02-07 16:13:24 --> Helper loaded: url_helper
INFO - 2024-02-07 16:13:24 --> Helper loaded: file_helper
INFO - 2024-02-07 16:13:24 --> Helper loaded: html_helper
INFO - 2024-02-07 16:13:24 --> Helper loaded: text_helper
INFO - 2024-02-07 16:13:24 --> Helper loaded: form_helper
INFO - 2024-02-07 16:13:24 --> Helper loaded: lang_helper
INFO - 2024-02-07 16:13:24 --> Helper loaded: security_helper
INFO - 2024-02-07 16:13:24 --> Helper loaded: cookie_helper
INFO - 2024-02-07 16:13:24 --> Database Driver Class Initialized
INFO - 2024-02-07 16:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 16:13:24 --> Parser Class Initialized
INFO - 2024-02-07 16:13:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 16:13:24 --> Pagination Class Initialized
INFO - 2024-02-07 16:13:24 --> Form Validation Class Initialized
INFO - 2024-02-07 16:13:24 --> Controller Class Initialized
INFO - 2024-02-07 16:13:24 --> Model Class Initialized
DEBUG - 2024-02-07 16:13:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 16:13:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-07 16:13:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 16:13:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 16:13:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 16:13:24 --> Model Class Initialized
INFO - 2024-02-07 16:13:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 16:13:24 --> Final output sent to browser
DEBUG - 2024-02-07 16:13:24 --> Total execution time: 0.0334
ERROR - 2024-02-07 16:13:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-07 16:13:24 --> Config Class Initialized
INFO - 2024-02-07 16:13:24 --> Hooks Class Initialized
DEBUG - 2024-02-07 16:13:24 --> UTF-8 Support Enabled
INFO - 2024-02-07 16:13:24 --> Utf8 Class Initialized
INFO - 2024-02-07 16:13:24 --> URI Class Initialized
INFO - 2024-02-07 16:13:24 --> Router Class Initialized
INFO - 2024-02-07 16:13:24 --> Output Class Initialized
INFO - 2024-02-07 16:13:24 --> Security Class Initialized
DEBUG - 2024-02-07 16:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-07 16:13:24 --> Input Class Initialized
INFO - 2024-02-07 16:13:24 --> Language Class Initialized
INFO - 2024-02-07 16:13:24 --> Loader Class Initialized
INFO - 2024-02-07 16:13:24 --> Helper loaded: url_helper
INFO - 2024-02-07 16:13:24 --> Helper loaded: file_helper
INFO - 2024-02-07 16:13:24 --> Helper loaded: html_helper
INFO - 2024-02-07 16:13:24 --> Helper loaded: text_helper
INFO - 2024-02-07 16:13:24 --> Helper loaded: form_helper
INFO - 2024-02-07 16:13:24 --> Helper loaded: lang_helper
INFO - 2024-02-07 16:13:24 --> Helper loaded: security_helper
INFO - 2024-02-07 16:13:24 --> Helper loaded: cookie_helper
INFO - 2024-02-07 16:13:24 --> Database Driver Class Initialized
INFO - 2024-02-07 16:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-07 16:13:24 --> Parser Class Initialized
INFO - 2024-02-07 16:13:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-07 16:13:24 --> Pagination Class Initialized
INFO - 2024-02-07 16:13:24 --> Form Validation Class Initialized
INFO - 2024-02-07 16:13:24 --> Controller Class Initialized
INFO - 2024-02-07 16:13:24 --> Model Class Initialized
DEBUG - 2024-02-07 16:13:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 16:13:24 --> Model Class Initialized
DEBUG - 2024-02-07 16:13:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 16:13:24 --> Model Class Initialized
INFO - 2024-02-07 16:13:24 --> Model Class Initialized
INFO - 2024-02-07 16:13:24 --> Model Class Initialized
INFO - 2024-02-07 16:13:24 --> Model Class Initialized
DEBUG - 2024-02-07 16:13:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-07 16:13:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-07 16:13:24 --> Model Class Initialized
INFO - 2024-02-07 16:13:24 --> Model Class Initialized
INFO - 2024-02-07 16:13:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-07 16:13:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-07 16:13:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-07 16:13:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-07 16:13:24 --> Model Class Initialized
INFO - 2024-02-07 16:13:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-07 16:13:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-07 16:13:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-07 16:13:25 --> Final output sent to browser
DEBUG - 2024-02-07 16:13:25 --> Total execution time: 0.3976
