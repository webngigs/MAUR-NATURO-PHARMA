<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-22 01:30:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:30:53 --> Config Class Initialized
INFO - 2023-12-22 01:30:53 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:30:53 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:30:53 --> Utf8 Class Initialized
INFO - 2023-12-22 01:30:53 --> URI Class Initialized
DEBUG - 2023-12-22 01:30:53 --> No URI present. Default controller set.
INFO - 2023-12-22 01:30:53 --> Router Class Initialized
INFO - 2023-12-22 01:30:53 --> Output Class Initialized
INFO - 2023-12-22 01:30:53 --> Security Class Initialized
DEBUG - 2023-12-22 01:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:30:53 --> Input Class Initialized
INFO - 2023-12-22 01:30:53 --> Language Class Initialized
INFO - 2023-12-22 01:30:53 --> Loader Class Initialized
INFO - 2023-12-22 01:30:53 --> Helper loaded: url_helper
INFO - 2023-12-22 01:30:53 --> Helper loaded: file_helper
INFO - 2023-12-22 01:30:53 --> Helper loaded: html_helper
INFO - 2023-12-22 01:30:53 --> Helper loaded: text_helper
INFO - 2023-12-22 01:30:53 --> Helper loaded: form_helper
INFO - 2023-12-22 01:30:53 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:30:53 --> Helper loaded: security_helper
INFO - 2023-12-22 01:30:53 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:30:53 --> Database Driver Class Initialized
INFO - 2023-12-22 01:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:30:54 --> Parser Class Initialized
INFO - 2023-12-22 01:30:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:30:54 --> Pagination Class Initialized
INFO - 2023-12-22 01:30:54 --> Form Validation Class Initialized
INFO - 2023-12-22 01:30:54 --> Controller Class Initialized
INFO - 2023-12-22 01:30:54 --> Model Class Initialized
DEBUG - 2023-12-22 01:30:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-22 01:30:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:30:54 --> Config Class Initialized
INFO - 2023-12-22 01:30:54 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:30:54 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:30:54 --> Utf8 Class Initialized
INFO - 2023-12-22 01:30:54 --> URI Class Initialized
INFO - 2023-12-22 01:30:54 --> Router Class Initialized
INFO - 2023-12-22 01:30:54 --> Output Class Initialized
INFO - 2023-12-22 01:30:54 --> Security Class Initialized
DEBUG - 2023-12-22 01:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:30:54 --> Input Class Initialized
INFO - 2023-12-22 01:30:54 --> Language Class Initialized
INFO - 2023-12-22 01:30:54 --> Loader Class Initialized
INFO - 2023-12-22 01:30:54 --> Helper loaded: url_helper
INFO - 2023-12-22 01:30:54 --> Helper loaded: file_helper
INFO - 2023-12-22 01:30:54 --> Helper loaded: html_helper
INFO - 2023-12-22 01:30:54 --> Helper loaded: text_helper
INFO - 2023-12-22 01:30:54 --> Helper loaded: form_helper
INFO - 2023-12-22 01:30:54 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:30:54 --> Helper loaded: security_helper
INFO - 2023-12-22 01:30:54 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:30:54 --> Database Driver Class Initialized
INFO - 2023-12-22 01:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:30:54 --> Parser Class Initialized
INFO - 2023-12-22 01:30:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:30:54 --> Pagination Class Initialized
INFO - 2023-12-22 01:30:54 --> Form Validation Class Initialized
INFO - 2023-12-22 01:30:54 --> Controller Class Initialized
INFO - 2023-12-22 01:30:54 --> Model Class Initialized
DEBUG - 2023-12-22 01:30:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:30:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-22 01:30:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:30:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 01:30:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 01:30:54 --> Model Class Initialized
INFO - 2023-12-22 01:30:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 01:30:54 --> Final output sent to browser
DEBUG - 2023-12-22 01:30:54 --> Total execution time: 0.0325
ERROR - 2023-12-22 01:31:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:31:05 --> Config Class Initialized
INFO - 2023-12-22 01:31:05 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:31:05 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:31:05 --> Utf8 Class Initialized
INFO - 2023-12-22 01:31:05 --> URI Class Initialized
INFO - 2023-12-22 01:31:05 --> Router Class Initialized
INFO - 2023-12-22 01:31:05 --> Output Class Initialized
INFO - 2023-12-22 01:31:05 --> Security Class Initialized
DEBUG - 2023-12-22 01:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:31:05 --> Input Class Initialized
INFO - 2023-12-22 01:31:05 --> Language Class Initialized
INFO - 2023-12-22 01:31:05 --> Loader Class Initialized
INFO - 2023-12-22 01:31:05 --> Helper loaded: url_helper
INFO - 2023-12-22 01:31:05 --> Helper loaded: file_helper
INFO - 2023-12-22 01:31:05 --> Helper loaded: html_helper
INFO - 2023-12-22 01:31:05 --> Helper loaded: text_helper
INFO - 2023-12-22 01:31:05 --> Helper loaded: form_helper
INFO - 2023-12-22 01:31:05 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:31:05 --> Helper loaded: security_helper
INFO - 2023-12-22 01:31:05 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:31:05 --> Database Driver Class Initialized
INFO - 2023-12-22 01:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:31:05 --> Parser Class Initialized
INFO - 2023-12-22 01:31:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:31:05 --> Pagination Class Initialized
INFO - 2023-12-22 01:31:05 --> Form Validation Class Initialized
INFO - 2023-12-22 01:31:05 --> Controller Class Initialized
INFO - 2023-12-22 01:31:05 --> Model Class Initialized
DEBUG - 2023-12-22 01:31:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:31:05 --> Model Class Initialized
INFO - 2023-12-22 01:31:05 --> Final output sent to browser
DEBUG - 2023-12-22 01:31:05 --> Total execution time: 0.0208
ERROR - 2023-12-22 01:31:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:31:06 --> Config Class Initialized
INFO - 2023-12-22 01:31:06 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:31:06 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:31:06 --> Utf8 Class Initialized
INFO - 2023-12-22 01:31:06 --> URI Class Initialized
DEBUG - 2023-12-22 01:31:06 --> No URI present. Default controller set.
INFO - 2023-12-22 01:31:06 --> Router Class Initialized
INFO - 2023-12-22 01:31:06 --> Output Class Initialized
INFO - 2023-12-22 01:31:06 --> Security Class Initialized
DEBUG - 2023-12-22 01:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:31:06 --> Input Class Initialized
INFO - 2023-12-22 01:31:06 --> Language Class Initialized
INFO - 2023-12-22 01:31:06 --> Loader Class Initialized
INFO - 2023-12-22 01:31:06 --> Helper loaded: url_helper
INFO - 2023-12-22 01:31:06 --> Helper loaded: file_helper
INFO - 2023-12-22 01:31:06 --> Helper loaded: html_helper
INFO - 2023-12-22 01:31:06 --> Helper loaded: text_helper
INFO - 2023-12-22 01:31:06 --> Helper loaded: form_helper
INFO - 2023-12-22 01:31:06 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:31:06 --> Helper loaded: security_helper
INFO - 2023-12-22 01:31:06 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:31:06 --> Database Driver Class Initialized
INFO - 2023-12-22 01:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:31:06 --> Parser Class Initialized
INFO - 2023-12-22 01:31:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:31:06 --> Pagination Class Initialized
INFO - 2023-12-22 01:31:06 --> Form Validation Class Initialized
INFO - 2023-12-22 01:31:06 --> Controller Class Initialized
INFO - 2023-12-22 01:31:06 --> Model Class Initialized
DEBUG - 2023-12-22 01:31:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:31:06 --> Model Class Initialized
DEBUG - 2023-12-22 01:31:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:31:06 --> Model Class Initialized
INFO - 2023-12-22 01:31:06 --> Model Class Initialized
INFO - 2023-12-22 01:31:06 --> Model Class Initialized
INFO - 2023-12-22 01:31:06 --> Model Class Initialized
DEBUG - 2023-12-22 01:31:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 01:31:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:31:06 --> Model Class Initialized
INFO - 2023-12-22 01:31:06 --> Model Class Initialized
INFO - 2023-12-22 01:31:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-22 01:31:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:31:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 01:31:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 01:31:06 --> Model Class Initialized
INFO - 2023-12-22 01:31:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 01:31:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 01:31:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 01:31:06 --> Final output sent to browser
DEBUG - 2023-12-22 01:31:06 --> Total execution time: 0.2157
ERROR - 2023-12-22 01:31:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:31:16 --> Config Class Initialized
INFO - 2023-12-22 01:31:16 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:31:16 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:31:16 --> Utf8 Class Initialized
INFO - 2023-12-22 01:31:16 --> URI Class Initialized
INFO - 2023-12-22 01:31:16 --> Router Class Initialized
INFO - 2023-12-22 01:31:16 --> Output Class Initialized
INFO - 2023-12-22 01:31:16 --> Security Class Initialized
DEBUG - 2023-12-22 01:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:31:16 --> Input Class Initialized
INFO - 2023-12-22 01:31:16 --> Language Class Initialized
INFO - 2023-12-22 01:31:16 --> Loader Class Initialized
INFO - 2023-12-22 01:31:16 --> Helper loaded: url_helper
INFO - 2023-12-22 01:31:16 --> Helper loaded: file_helper
INFO - 2023-12-22 01:31:16 --> Helper loaded: html_helper
INFO - 2023-12-22 01:31:16 --> Helper loaded: text_helper
INFO - 2023-12-22 01:31:16 --> Helper loaded: form_helper
INFO - 2023-12-22 01:31:16 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:31:16 --> Helper loaded: security_helper
INFO - 2023-12-22 01:31:16 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:31:16 --> Database Driver Class Initialized
INFO - 2023-12-22 01:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:31:16 --> Parser Class Initialized
INFO - 2023-12-22 01:31:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:31:16 --> Pagination Class Initialized
INFO - 2023-12-22 01:31:16 --> Form Validation Class Initialized
INFO - 2023-12-22 01:31:16 --> Controller Class Initialized
INFO - 2023-12-22 01:31:16 --> Model Class Initialized
DEBUG - 2023-12-22 01:31:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 01:31:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:31:17 --> Model Class Initialized
DEBUG - 2023-12-22 01:31:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:31:17 --> Model Class Initialized
INFO - 2023-12-22 01:31:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-22 01:31:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:31:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 01:31:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 01:31:17 --> Model Class Initialized
INFO - 2023-12-22 01:31:17 --> Model Class Initialized
INFO - 2023-12-22 01:31:17 --> Model Class Initialized
INFO - 2023-12-22 01:31:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 01:31:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 01:31:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 01:31:17 --> Final output sent to browser
DEBUG - 2023-12-22 01:31:17 --> Total execution time: 0.1565
ERROR - 2023-12-22 01:31:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:31:18 --> Config Class Initialized
INFO - 2023-12-22 01:31:18 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:31:18 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:31:18 --> Utf8 Class Initialized
INFO - 2023-12-22 01:31:18 --> URI Class Initialized
INFO - 2023-12-22 01:31:18 --> Router Class Initialized
INFO - 2023-12-22 01:31:18 --> Output Class Initialized
INFO - 2023-12-22 01:31:18 --> Security Class Initialized
DEBUG - 2023-12-22 01:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:31:18 --> Input Class Initialized
INFO - 2023-12-22 01:31:18 --> Language Class Initialized
INFO - 2023-12-22 01:31:18 --> Loader Class Initialized
INFO - 2023-12-22 01:31:18 --> Helper loaded: url_helper
INFO - 2023-12-22 01:31:18 --> Helper loaded: file_helper
INFO - 2023-12-22 01:31:18 --> Helper loaded: html_helper
INFO - 2023-12-22 01:31:18 --> Helper loaded: text_helper
INFO - 2023-12-22 01:31:18 --> Helper loaded: form_helper
INFO - 2023-12-22 01:31:18 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:31:18 --> Helper loaded: security_helper
INFO - 2023-12-22 01:31:18 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:31:18 --> Database Driver Class Initialized
INFO - 2023-12-22 01:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:31:18 --> Parser Class Initialized
INFO - 2023-12-22 01:31:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:31:18 --> Pagination Class Initialized
INFO - 2023-12-22 01:31:18 --> Form Validation Class Initialized
INFO - 2023-12-22 01:31:18 --> Controller Class Initialized
INFO - 2023-12-22 01:31:18 --> Model Class Initialized
DEBUG - 2023-12-22 01:31:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 01:31:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:31:18 --> Model Class Initialized
DEBUG - 2023-12-22 01:31:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:31:18 --> Model Class Initialized
INFO - 2023-12-22 01:31:18 --> Final output sent to browser
DEBUG - 2023-12-22 01:31:18 --> Total execution time: 0.0395
ERROR - 2023-12-22 01:31:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:31:32 --> Config Class Initialized
INFO - 2023-12-22 01:31:32 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:31:32 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:31:32 --> Utf8 Class Initialized
INFO - 2023-12-22 01:31:32 --> URI Class Initialized
INFO - 2023-12-22 01:31:32 --> Router Class Initialized
INFO - 2023-12-22 01:31:32 --> Output Class Initialized
INFO - 2023-12-22 01:31:32 --> Security Class Initialized
DEBUG - 2023-12-22 01:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:31:32 --> Input Class Initialized
INFO - 2023-12-22 01:31:32 --> Language Class Initialized
INFO - 2023-12-22 01:31:32 --> Loader Class Initialized
INFO - 2023-12-22 01:31:32 --> Helper loaded: url_helper
INFO - 2023-12-22 01:31:32 --> Helper loaded: file_helper
INFO - 2023-12-22 01:31:32 --> Helper loaded: html_helper
INFO - 2023-12-22 01:31:32 --> Helper loaded: text_helper
INFO - 2023-12-22 01:31:32 --> Helper loaded: form_helper
INFO - 2023-12-22 01:31:32 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:31:32 --> Helper loaded: security_helper
INFO - 2023-12-22 01:31:32 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:31:32 --> Database Driver Class Initialized
INFO - 2023-12-22 01:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:31:32 --> Parser Class Initialized
INFO - 2023-12-22 01:31:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:31:32 --> Pagination Class Initialized
INFO - 2023-12-22 01:31:32 --> Form Validation Class Initialized
INFO - 2023-12-22 01:31:32 --> Controller Class Initialized
INFO - 2023-12-22 01:31:32 --> Model Class Initialized
DEBUG - 2023-12-22 01:31:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 01:31:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:31:32 --> Model Class Initialized
DEBUG - 2023-12-22 01:31:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:31:32 --> Model Class Initialized
DEBUG - 2023-12-22 01:31:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:31:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-12-22 01:31:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:31:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 01:31:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 01:31:32 --> Model Class Initialized
INFO - 2023-12-22 01:31:32 --> Model Class Initialized
INFO - 2023-12-22 01:31:32 --> Model Class Initialized
INFO - 2023-12-22 01:31:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 01:31:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 01:31:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 01:31:32 --> Final output sent to browser
DEBUG - 2023-12-22 01:31:32 --> Total execution time: 0.1506
ERROR - 2023-12-22 01:31:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:31:57 --> Config Class Initialized
INFO - 2023-12-22 01:31:57 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:31:57 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:31:57 --> Utf8 Class Initialized
INFO - 2023-12-22 01:31:57 --> URI Class Initialized
INFO - 2023-12-22 01:31:57 --> Router Class Initialized
INFO - 2023-12-22 01:31:57 --> Output Class Initialized
INFO - 2023-12-22 01:31:57 --> Security Class Initialized
DEBUG - 2023-12-22 01:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:31:57 --> Input Class Initialized
INFO - 2023-12-22 01:31:57 --> Language Class Initialized
INFO - 2023-12-22 01:31:57 --> Loader Class Initialized
INFO - 2023-12-22 01:31:57 --> Helper loaded: url_helper
INFO - 2023-12-22 01:31:57 --> Helper loaded: file_helper
INFO - 2023-12-22 01:31:57 --> Helper loaded: html_helper
INFO - 2023-12-22 01:31:57 --> Helper loaded: text_helper
INFO - 2023-12-22 01:31:57 --> Helper loaded: form_helper
INFO - 2023-12-22 01:31:57 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:31:57 --> Helper loaded: security_helper
INFO - 2023-12-22 01:31:57 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:31:57 --> Database Driver Class Initialized
INFO - 2023-12-22 01:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:31:57 --> Parser Class Initialized
INFO - 2023-12-22 01:31:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:31:57 --> Pagination Class Initialized
INFO - 2023-12-22 01:31:57 --> Form Validation Class Initialized
INFO - 2023-12-22 01:31:57 --> Controller Class Initialized
INFO - 2023-12-22 01:31:57 --> Model Class Initialized
DEBUG - 2023-12-22 01:31:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 01:31:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:31:57 --> Model Class Initialized
DEBUG - 2023-12-22 01:31:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:31:57 --> Model Class Initialized
INFO - 2023-12-22 01:31:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-22 01:31:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:31:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 01:31:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 01:31:57 --> Model Class Initialized
INFO - 2023-12-22 01:31:57 --> Model Class Initialized
INFO - 2023-12-22 01:31:57 --> Model Class Initialized
INFO - 2023-12-22 01:31:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 01:31:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 01:31:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 01:31:57 --> Final output sent to browser
DEBUG - 2023-12-22 01:31:57 --> Total execution time: 0.1496
ERROR - 2023-12-22 01:31:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:31:58 --> Config Class Initialized
INFO - 2023-12-22 01:31:58 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:31:58 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:31:58 --> Utf8 Class Initialized
INFO - 2023-12-22 01:31:58 --> URI Class Initialized
INFO - 2023-12-22 01:31:58 --> Router Class Initialized
INFO - 2023-12-22 01:31:58 --> Output Class Initialized
INFO - 2023-12-22 01:31:58 --> Security Class Initialized
DEBUG - 2023-12-22 01:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:31:58 --> Input Class Initialized
INFO - 2023-12-22 01:31:58 --> Language Class Initialized
INFO - 2023-12-22 01:31:58 --> Loader Class Initialized
INFO - 2023-12-22 01:31:58 --> Helper loaded: url_helper
INFO - 2023-12-22 01:31:58 --> Helper loaded: file_helper
INFO - 2023-12-22 01:31:58 --> Helper loaded: html_helper
INFO - 2023-12-22 01:31:58 --> Helper loaded: text_helper
INFO - 2023-12-22 01:31:58 --> Helper loaded: form_helper
INFO - 2023-12-22 01:31:58 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:31:58 --> Helper loaded: security_helper
INFO - 2023-12-22 01:31:58 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:31:58 --> Database Driver Class Initialized
INFO - 2023-12-22 01:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:31:58 --> Parser Class Initialized
INFO - 2023-12-22 01:31:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:31:58 --> Pagination Class Initialized
INFO - 2023-12-22 01:31:58 --> Form Validation Class Initialized
INFO - 2023-12-22 01:31:58 --> Controller Class Initialized
INFO - 2023-12-22 01:31:58 --> Model Class Initialized
DEBUG - 2023-12-22 01:31:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 01:31:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:31:58 --> Model Class Initialized
DEBUG - 2023-12-22 01:31:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:31:58 --> Model Class Initialized
INFO - 2023-12-22 01:31:58 --> Final output sent to browser
DEBUG - 2023-12-22 01:31:58 --> Total execution time: 0.0387
ERROR - 2023-12-22 01:32:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:32:02 --> Config Class Initialized
INFO - 2023-12-22 01:32:02 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:32:02 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:32:02 --> Utf8 Class Initialized
INFO - 2023-12-22 01:32:02 --> URI Class Initialized
INFO - 2023-12-22 01:32:02 --> Router Class Initialized
INFO - 2023-12-22 01:32:02 --> Output Class Initialized
INFO - 2023-12-22 01:32:02 --> Security Class Initialized
DEBUG - 2023-12-22 01:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:32:02 --> Input Class Initialized
INFO - 2023-12-22 01:32:02 --> Language Class Initialized
INFO - 2023-12-22 01:32:02 --> Loader Class Initialized
INFO - 2023-12-22 01:32:02 --> Helper loaded: url_helper
INFO - 2023-12-22 01:32:02 --> Helper loaded: file_helper
INFO - 2023-12-22 01:32:02 --> Helper loaded: html_helper
INFO - 2023-12-22 01:32:02 --> Helper loaded: text_helper
INFO - 2023-12-22 01:32:02 --> Helper loaded: form_helper
INFO - 2023-12-22 01:32:02 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:32:02 --> Helper loaded: security_helper
INFO - 2023-12-22 01:32:02 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:32:02 --> Database Driver Class Initialized
INFO - 2023-12-22 01:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:32:02 --> Parser Class Initialized
INFO - 2023-12-22 01:32:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:32:02 --> Pagination Class Initialized
INFO - 2023-12-22 01:32:02 --> Form Validation Class Initialized
INFO - 2023-12-22 01:32:02 --> Controller Class Initialized
INFO - 2023-12-22 01:32:02 --> Model Class Initialized
DEBUG - 2023-12-22 01:32:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 01:32:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:32:02 --> Model Class Initialized
DEBUG - 2023-12-22 01:32:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:32:02 --> Model Class Initialized
DEBUG - 2023-12-22 01:32:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:32:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-12-22 01:32:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:32:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 01:32:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 01:32:02 --> Model Class Initialized
INFO - 2023-12-22 01:32:02 --> Model Class Initialized
INFO - 2023-12-22 01:32:02 --> Model Class Initialized
INFO - 2023-12-22 01:32:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 01:32:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 01:32:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 01:32:02 --> Final output sent to browser
DEBUG - 2023-12-22 01:32:02 --> Total execution time: 0.2230
ERROR - 2023-12-22 01:32:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:32:10 --> Config Class Initialized
INFO - 2023-12-22 01:32:10 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:32:10 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:32:10 --> Utf8 Class Initialized
INFO - 2023-12-22 01:32:10 --> URI Class Initialized
INFO - 2023-12-22 01:32:10 --> Router Class Initialized
INFO - 2023-12-22 01:32:10 --> Output Class Initialized
INFO - 2023-12-22 01:32:10 --> Security Class Initialized
DEBUG - 2023-12-22 01:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:32:10 --> Input Class Initialized
INFO - 2023-12-22 01:32:10 --> Language Class Initialized
INFO - 2023-12-22 01:32:10 --> Loader Class Initialized
INFO - 2023-12-22 01:32:10 --> Helper loaded: url_helper
INFO - 2023-12-22 01:32:10 --> Helper loaded: file_helper
INFO - 2023-12-22 01:32:10 --> Helper loaded: html_helper
INFO - 2023-12-22 01:32:10 --> Helper loaded: text_helper
INFO - 2023-12-22 01:32:10 --> Helper loaded: form_helper
INFO - 2023-12-22 01:32:10 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:32:10 --> Helper loaded: security_helper
INFO - 2023-12-22 01:32:10 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:32:10 --> Database Driver Class Initialized
INFO - 2023-12-22 01:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:32:10 --> Parser Class Initialized
INFO - 2023-12-22 01:32:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:32:10 --> Pagination Class Initialized
INFO - 2023-12-22 01:32:10 --> Form Validation Class Initialized
INFO - 2023-12-22 01:32:10 --> Controller Class Initialized
INFO - 2023-12-22 01:32:10 --> Model Class Initialized
DEBUG - 2023-12-22 01:32:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 01:32:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:32:10 --> Model Class Initialized
DEBUG - 2023-12-22 01:32:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:32:10 --> Model Class Initialized
INFO - 2023-12-22 01:32:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-22 01:32:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:32:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 01:32:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 01:32:10 --> Model Class Initialized
INFO - 2023-12-22 01:32:10 --> Model Class Initialized
INFO - 2023-12-22 01:32:10 --> Model Class Initialized
INFO - 2023-12-22 01:32:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 01:32:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 01:32:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 01:32:10 --> Final output sent to browser
DEBUG - 2023-12-22 01:32:10 --> Total execution time: 0.1476
ERROR - 2023-12-22 01:32:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:32:12 --> Config Class Initialized
INFO - 2023-12-22 01:32:12 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:32:12 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:32:12 --> Utf8 Class Initialized
INFO - 2023-12-22 01:32:12 --> URI Class Initialized
INFO - 2023-12-22 01:32:12 --> Router Class Initialized
INFO - 2023-12-22 01:32:12 --> Output Class Initialized
INFO - 2023-12-22 01:32:12 --> Security Class Initialized
DEBUG - 2023-12-22 01:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:32:12 --> Input Class Initialized
INFO - 2023-12-22 01:32:12 --> Language Class Initialized
INFO - 2023-12-22 01:32:12 --> Loader Class Initialized
INFO - 2023-12-22 01:32:12 --> Helper loaded: url_helper
INFO - 2023-12-22 01:32:12 --> Helper loaded: file_helper
INFO - 2023-12-22 01:32:12 --> Helper loaded: html_helper
INFO - 2023-12-22 01:32:12 --> Helper loaded: text_helper
INFO - 2023-12-22 01:32:12 --> Helper loaded: form_helper
INFO - 2023-12-22 01:32:12 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:32:12 --> Helper loaded: security_helper
INFO - 2023-12-22 01:32:12 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:32:12 --> Database Driver Class Initialized
INFO - 2023-12-22 01:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:32:12 --> Parser Class Initialized
INFO - 2023-12-22 01:32:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:32:12 --> Pagination Class Initialized
INFO - 2023-12-22 01:32:12 --> Form Validation Class Initialized
INFO - 2023-12-22 01:32:12 --> Controller Class Initialized
INFO - 2023-12-22 01:32:12 --> Model Class Initialized
DEBUG - 2023-12-22 01:32:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 01:32:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:32:12 --> Model Class Initialized
DEBUG - 2023-12-22 01:32:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:32:12 --> Model Class Initialized
INFO - 2023-12-22 01:32:12 --> Final output sent to browser
DEBUG - 2023-12-22 01:32:12 --> Total execution time: 0.0597
ERROR - 2023-12-22 01:32:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:32:16 --> Config Class Initialized
INFO - 2023-12-22 01:32:16 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:32:16 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:32:16 --> Utf8 Class Initialized
INFO - 2023-12-22 01:32:16 --> URI Class Initialized
INFO - 2023-12-22 01:32:16 --> Router Class Initialized
INFO - 2023-12-22 01:32:16 --> Output Class Initialized
INFO - 2023-12-22 01:32:16 --> Security Class Initialized
DEBUG - 2023-12-22 01:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:32:16 --> Input Class Initialized
INFO - 2023-12-22 01:32:16 --> Language Class Initialized
INFO - 2023-12-22 01:32:16 --> Loader Class Initialized
INFO - 2023-12-22 01:32:16 --> Helper loaded: url_helper
INFO - 2023-12-22 01:32:16 --> Helper loaded: file_helper
INFO - 2023-12-22 01:32:16 --> Helper loaded: html_helper
INFO - 2023-12-22 01:32:16 --> Helper loaded: text_helper
INFO - 2023-12-22 01:32:16 --> Helper loaded: form_helper
INFO - 2023-12-22 01:32:16 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:32:16 --> Helper loaded: security_helper
INFO - 2023-12-22 01:32:16 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:32:16 --> Database Driver Class Initialized
INFO - 2023-12-22 01:32:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:32:16 --> Parser Class Initialized
INFO - 2023-12-22 01:32:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:32:16 --> Pagination Class Initialized
INFO - 2023-12-22 01:32:16 --> Form Validation Class Initialized
INFO - 2023-12-22 01:32:16 --> Controller Class Initialized
INFO - 2023-12-22 01:32:16 --> Model Class Initialized
DEBUG - 2023-12-22 01:32:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 01:32:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:32:16 --> Model Class Initialized
DEBUG - 2023-12-22 01:32:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:32:16 --> Model Class Initialized
DEBUG - 2023-12-22 01:32:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:32:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-12-22 01:32:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:32:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 01:32:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 01:32:16 --> Model Class Initialized
INFO - 2023-12-22 01:32:16 --> Model Class Initialized
INFO - 2023-12-22 01:32:16 --> Model Class Initialized
INFO - 2023-12-22 01:32:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 01:32:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 01:32:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 01:32:16 --> Final output sent to browser
DEBUG - 2023-12-22 01:32:16 --> Total execution time: 0.1493
ERROR - 2023-12-22 01:32:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:32:22 --> Config Class Initialized
INFO - 2023-12-22 01:32:22 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:32:22 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:32:22 --> Utf8 Class Initialized
INFO - 2023-12-22 01:32:22 --> URI Class Initialized
INFO - 2023-12-22 01:32:22 --> Router Class Initialized
INFO - 2023-12-22 01:32:22 --> Output Class Initialized
INFO - 2023-12-22 01:32:22 --> Security Class Initialized
DEBUG - 2023-12-22 01:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:32:22 --> Input Class Initialized
INFO - 2023-12-22 01:32:22 --> Language Class Initialized
INFO - 2023-12-22 01:32:22 --> Loader Class Initialized
INFO - 2023-12-22 01:32:22 --> Helper loaded: url_helper
INFO - 2023-12-22 01:32:22 --> Helper loaded: file_helper
INFO - 2023-12-22 01:32:22 --> Helper loaded: html_helper
INFO - 2023-12-22 01:32:22 --> Helper loaded: text_helper
INFO - 2023-12-22 01:32:22 --> Helper loaded: form_helper
INFO - 2023-12-22 01:32:22 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:32:22 --> Helper loaded: security_helper
INFO - 2023-12-22 01:32:22 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:32:22 --> Database Driver Class Initialized
INFO - 2023-12-22 01:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:32:22 --> Parser Class Initialized
INFO - 2023-12-22 01:32:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:32:22 --> Pagination Class Initialized
INFO - 2023-12-22 01:32:22 --> Form Validation Class Initialized
INFO - 2023-12-22 01:32:22 --> Controller Class Initialized
INFO - 2023-12-22 01:32:22 --> Model Class Initialized
DEBUG - 2023-12-22 01:32:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 01:32:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:32:22 --> Model Class Initialized
DEBUG - 2023-12-22 01:32:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:32:22 --> Model Class Initialized
INFO - 2023-12-22 01:32:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-22 01:32:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:32:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 01:32:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 01:32:22 --> Model Class Initialized
INFO - 2023-12-22 01:32:22 --> Model Class Initialized
INFO - 2023-12-22 01:32:22 --> Model Class Initialized
INFO - 2023-12-22 01:32:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 01:32:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 01:32:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 01:32:22 --> Final output sent to browser
DEBUG - 2023-12-22 01:32:22 --> Total execution time: 0.1703
ERROR - 2023-12-22 01:32:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:32:23 --> Config Class Initialized
INFO - 2023-12-22 01:32:23 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:32:23 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:32:23 --> Utf8 Class Initialized
INFO - 2023-12-22 01:32:23 --> URI Class Initialized
INFO - 2023-12-22 01:32:23 --> Router Class Initialized
INFO - 2023-12-22 01:32:23 --> Output Class Initialized
INFO - 2023-12-22 01:32:23 --> Security Class Initialized
DEBUG - 2023-12-22 01:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:32:23 --> Input Class Initialized
INFO - 2023-12-22 01:32:23 --> Language Class Initialized
INFO - 2023-12-22 01:32:23 --> Loader Class Initialized
INFO - 2023-12-22 01:32:23 --> Helper loaded: url_helper
INFO - 2023-12-22 01:32:23 --> Helper loaded: file_helper
INFO - 2023-12-22 01:32:23 --> Helper loaded: html_helper
INFO - 2023-12-22 01:32:23 --> Helper loaded: text_helper
INFO - 2023-12-22 01:32:23 --> Helper loaded: form_helper
INFO - 2023-12-22 01:32:23 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:32:23 --> Helper loaded: security_helper
INFO - 2023-12-22 01:32:23 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:32:23 --> Database Driver Class Initialized
INFO - 2023-12-22 01:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:32:23 --> Parser Class Initialized
INFO - 2023-12-22 01:32:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:32:23 --> Pagination Class Initialized
INFO - 2023-12-22 01:32:23 --> Form Validation Class Initialized
INFO - 2023-12-22 01:32:23 --> Controller Class Initialized
INFO - 2023-12-22 01:32:23 --> Model Class Initialized
DEBUG - 2023-12-22 01:32:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 01:32:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:32:23 --> Model Class Initialized
DEBUG - 2023-12-22 01:32:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:32:23 --> Model Class Initialized
INFO - 2023-12-22 01:32:24 --> Final output sent to browser
DEBUG - 2023-12-22 01:32:24 --> Total execution time: 0.0401
ERROR - 2023-12-22 01:33:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:33:05 --> Config Class Initialized
INFO - 2023-12-22 01:33:05 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:33:05 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:33:05 --> Utf8 Class Initialized
INFO - 2023-12-22 01:33:05 --> URI Class Initialized
DEBUG - 2023-12-22 01:33:05 --> No URI present. Default controller set.
INFO - 2023-12-22 01:33:05 --> Router Class Initialized
INFO - 2023-12-22 01:33:05 --> Output Class Initialized
INFO - 2023-12-22 01:33:05 --> Security Class Initialized
DEBUG - 2023-12-22 01:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:33:05 --> Input Class Initialized
INFO - 2023-12-22 01:33:05 --> Language Class Initialized
INFO - 2023-12-22 01:33:05 --> Loader Class Initialized
INFO - 2023-12-22 01:33:05 --> Helper loaded: url_helper
INFO - 2023-12-22 01:33:05 --> Helper loaded: file_helper
INFO - 2023-12-22 01:33:05 --> Helper loaded: html_helper
INFO - 2023-12-22 01:33:05 --> Helper loaded: text_helper
INFO - 2023-12-22 01:33:05 --> Helper loaded: form_helper
INFO - 2023-12-22 01:33:05 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:33:05 --> Helper loaded: security_helper
INFO - 2023-12-22 01:33:05 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:33:05 --> Database Driver Class Initialized
INFO - 2023-12-22 01:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:33:05 --> Parser Class Initialized
INFO - 2023-12-22 01:33:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:33:05 --> Pagination Class Initialized
INFO - 2023-12-22 01:33:05 --> Form Validation Class Initialized
INFO - 2023-12-22 01:33:05 --> Controller Class Initialized
INFO - 2023-12-22 01:33:05 --> Model Class Initialized
DEBUG - 2023-12-22 01:33:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:33:05 --> Model Class Initialized
DEBUG - 2023-12-22 01:33:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:33:05 --> Model Class Initialized
INFO - 2023-12-22 01:33:05 --> Model Class Initialized
INFO - 2023-12-22 01:33:05 --> Model Class Initialized
INFO - 2023-12-22 01:33:05 --> Model Class Initialized
DEBUG - 2023-12-22 01:33:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 01:33:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:33:05 --> Model Class Initialized
INFO - 2023-12-22 01:33:05 --> Model Class Initialized
INFO - 2023-12-22 01:33:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-22 01:33:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:33:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 01:33:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 01:33:05 --> Model Class Initialized
INFO - 2023-12-22 01:33:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 01:33:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 01:33:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 01:33:06 --> Final output sent to browser
DEBUG - 2023-12-22 01:33:06 --> Total execution time: 0.2239
ERROR - 2023-12-22 01:33:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:33:12 --> Config Class Initialized
INFO - 2023-12-22 01:33:12 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:33:12 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:33:12 --> Utf8 Class Initialized
INFO - 2023-12-22 01:33:12 --> URI Class Initialized
INFO - 2023-12-22 01:33:12 --> Router Class Initialized
INFO - 2023-12-22 01:33:12 --> Output Class Initialized
INFO - 2023-12-22 01:33:12 --> Security Class Initialized
DEBUG - 2023-12-22 01:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:33:12 --> Input Class Initialized
INFO - 2023-12-22 01:33:12 --> Language Class Initialized
INFO - 2023-12-22 01:33:12 --> Loader Class Initialized
INFO - 2023-12-22 01:33:12 --> Helper loaded: url_helper
INFO - 2023-12-22 01:33:12 --> Helper loaded: file_helper
INFO - 2023-12-22 01:33:12 --> Helper loaded: html_helper
INFO - 2023-12-22 01:33:12 --> Helper loaded: text_helper
INFO - 2023-12-22 01:33:12 --> Helper loaded: form_helper
INFO - 2023-12-22 01:33:12 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:33:12 --> Helper loaded: security_helper
INFO - 2023-12-22 01:33:12 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:33:12 --> Database Driver Class Initialized
INFO - 2023-12-22 01:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:33:12 --> Parser Class Initialized
INFO - 2023-12-22 01:33:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:33:12 --> Pagination Class Initialized
INFO - 2023-12-22 01:33:12 --> Form Validation Class Initialized
INFO - 2023-12-22 01:33:12 --> Controller Class Initialized
INFO - 2023-12-22 01:33:12 --> Model Class Initialized
DEBUG - 2023-12-22 01:33:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 01:33:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:33:12 --> Model Class Initialized
DEBUG - 2023-12-22 01:33:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:33:12 --> Model Class Initialized
INFO - 2023-12-22 01:33:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-22 01:33:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:33:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 01:33:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 01:33:12 --> Model Class Initialized
INFO - 2023-12-22 01:33:12 --> Model Class Initialized
INFO - 2023-12-22 01:33:12 --> Model Class Initialized
INFO - 2023-12-22 01:33:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 01:33:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 01:33:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 01:33:12 --> Final output sent to browser
DEBUG - 2023-12-22 01:33:12 --> Total execution time: 0.2834
ERROR - 2023-12-22 01:33:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:33:13 --> Config Class Initialized
INFO - 2023-12-22 01:33:13 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:33:13 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:33:13 --> Utf8 Class Initialized
INFO - 2023-12-22 01:33:13 --> URI Class Initialized
INFO - 2023-12-22 01:33:13 --> Router Class Initialized
INFO - 2023-12-22 01:33:13 --> Output Class Initialized
INFO - 2023-12-22 01:33:13 --> Security Class Initialized
DEBUG - 2023-12-22 01:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:33:13 --> Input Class Initialized
INFO - 2023-12-22 01:33:13 --> Language Class Initialized
INFO - 2023-12-22 01:33:13 --> Loader Class Initialized
INFO - 2023-12-22 01:33:13 --> Helper loaded: url_helper
INFO - 2023-12-22 01:33:13 --> Helper loaded: file_helper
INFO - 2023-12-22 01:33:13 --> Helper loaded: html_helper
INFO - 2023-12-22 01:33:13 --> Helper loaded: text_helper
INFO - 2023-12-22 01:33:13 --> Helper loaded: form_helper
INFO - 2023-12-22 01:33:13 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:33:13 --> Helper loaded: security_helper
INFO - 2023-12-22 01:33:13 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:33:13 --> Database Driver Class Initialized
INFO - 2023-12-22 01:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:33:13 --> Parser Class Initialized
INFO - 2023-12-22 01:33:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:33:13 --> Pagination Class Initialized
INFO - 2023-12-22 01:33:13 --> Form Validation Class Initialized
INFO - 2023-12-22 01:33:13 --> Controller Class Initialized
INFO - 2023-12-22 01:33:13 --> Model Class Initialized
DEBUG - 2023-12-22 01:33:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 01:33:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:33:13 --> Model Class Initialized
DEBUG - 2023-12-22 01:33:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:33:13 --> Model Class Initialized
INFO - 2023-12-22 01:33:13 --> Final output sent to browser
DEBUG - 2023-12-22 01:33:13 --> Total execution time: 0.0414
ERROR - 2023-12-22 01:33:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:33:20 --> Config Class Initialized
INFO - 2023-12-22 01:33:20 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:33:20 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:33:20 --> Utf8 Class Initialized
INFO - 2023-12-22 01:33:20 --> URI Class Initialized
INFO - 2023-12-22 01:33:20 --> Router Class Initialized
INFO - 2023-12-22 01:33:20 --> Output Class Initialized
INFO - 2023-12-22 01:33:20 --> Security Class Initialized
DEBUG - 2023-12-22 01:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:33:20 --> Input Class Initialized
INFO - 2023-12-22 01:33:20 --> Language Class Initialized
INFO - 2023-12-22 01:33:20 --> Loader Class Initialized
INFO - 2023-12-22 01:33:20 --> Helper loaded: url_helper
INFO - 2023-12-22 01:33:20 --> Helper loaded: file_helper
INFO - 2023-12-22 01:33:20 --> Helper loaded: html_helper
INFO - 2023-12-22 01:33:20 --> Helper loaded: text_helper
INFO - 2023-12-22 01:33:20 --> Helper loaded: form_helper
INFO - 2023-12-22 01:33:20 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:33:20 --> Helper loaded: security_helper
INFO - 2023-12-22 01:33:20 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:33:20 --> Database Driver Class Initialized
INFO - 2023-12-22 01:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:33:20 --> Parser Class Initialized
INFO - 2023-12-22 01:33:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:33:20 --> Pagination Class Initialized
INFO - 2023-12-22 01:33:20 --> Form Validation Class Initialized
INFO - 2023-12-22 01:33:20 --> Controller Class Initialized
INFO - 2023-12-22 01:33:20 --> Model Class Initialized
DEBUG - 2023-12-22 01:33:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 01:33:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:33:20 --> Model Class Initialized
DEBUG - 2023-12-22 01:33:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:33:20 --> Model Class Initialized
INFO - 2023-12-22 01:33:20 --> Final output sent to browser
DEBUG - 2023-12-22 01:33:20 --> Total execution time: 0.0798
ERROR - 2023-12-22 01:34:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:34:45 --> Config Class Initialized
INFO - 2023-12-22 01:34:45 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:34:45 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:34:45 --> Utf8 Class Initialized
INFO - 2023-12-22 01:34:45 --> URI Class Initialized
INFO - 2023-12-22 01:34:45 --> Router Class Initialized
INFO - 2023-12-22 01:34:45 --> Output Class Initialized
INFO - 2023-12-22 01:34:45 --> Security Class Initialized
DEBUG - 2023-12-22 01:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:34:45 --> Input Class Initialized
INFO - 2023-12-22 01:34:45 --> Language Class Initialized
INFO - 2023-12-22 01:34:45 --> Loader Class Initialized
INFO - 2023-12-22 01:34:45 --> Helper loaded: url_helper
INFO - 2023-12-22 01:34:45 --> Helper loaded: file_helper
INFO - 2023-12-22 01:34:45 --> Helper loaded: html_helper
INFO - 2023-12-22 01:34:45 --> Helper loaded: text_helper
INFO - 2023-12-22 01:34:45 --> Helper loaded: form_helper
INFO - 2023-12-22 01:34:45 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:34:45 --> Helper loaded: security_helper
INFO - 2023-12-22 01:34:45 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:34:45 --> Database Driver Class Initialized
INFO - 2023-12-22 01:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:34:45 --> Parser Class Initialized
INFO - 2023-12-22 01:34:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:34:45 --> Pagination Class Initialized
INFO - 2023-12-22 01:34:45 --> Form Validation Class Initialized
INFO - 2023-12-22 01:34:45 --> Controller Class Initialized
INFO - 2023-12-22 01:34:45 --> Model Class Initialized
DEBUG - 2023-12-22 01:34:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 01:34:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:34:45 --> Model Class Initialized
DEBUG - 2023-12-22 01:34:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:34:45 --> Model Class Initialized
DEBUG - 2023-12-22 01:34:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:34:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-12-22 01:34:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:34:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 01:34:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 01:34:45 --> Model Class Initialized
INFO - 2023-12-22 01:34:45 --> Model Class Initialized
INFO - 2023-12-22 01:34:45 --> Model Class Initialized
INFO - 2023-12-22 01:34:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 01:34:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 01:34:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 01:34:45 --> Final output sent to browser
DEBUG - 2023-12-22 01:34:45 --> Total execution time: 0.1594
ERROR - 2023-12-22 01:35:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:35:00 --> Config Class Initialized
INFO - 2023-12-22 01:35:00 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:35:00 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:35:00 --> Utf8 Class Initialized
INFO - 2023-12-22 01:35:00 --> URI Class Initialized
INFO - 2023-12-22 01:35:00 --> Router Class Initialized
INFO - 2023-12-22 01:35:00 --> Output Class Initialized
INFO - 2023-12-22 01:35:00 --> Security Class Initialized
DEBUG - 2023-12-22 01:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:35:00 --> Input Class Initialized
INFO - 2023-12-22 01:35:00 --> Language Class Initialized
INFO - 2023-12-22 01:35:00 --> Loader Class Initialized
INFO - 2023-12-22 01:35:00 --> Helper loaded: url_helper
INFO - 2023-12-22 01:35:00 --> Helper loaded: file_helper
INFO - 2023-12-22 01:35:00 --> Helper loaded: html_helper
INFO - 2023-12-22 01:35:00 --> Helper loaded: text_helper
INFO - 2023-12-22 01:35:00 --> Helper loaded: form_helper
INFO - 2023-12-22 01:35:00 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:35:00 --> Helper loaded: security_helper
INFO - 2023-12-22 01:35:00 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:35:00 --> Database Driver Class Initialized
INFO - 2023-12-22 01:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:35:00 --> Parser Class Initialized
INFO - 2023-12-22 01:35:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:35:00 --> Pagination Class Initialized
INFO - 2023-12-22 01:35:00 --> Form Validation Class Initialized
INFO - 2023-12-22 01:35:00 --> Controller Class Initialized
INFO - 2023-12-22 01:35:00 --> Model Class Initialized
DEBUG - 2023-12-22 01:35:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 01:35:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:35:00 --> Model Class Initialized
DEBUG - 2023-12-22 01:35:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:35:00 --> Model Class Initialized
INFO - 2023-12-22 01:35:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-22 01:35:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:35:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 01:35:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 01:35:00 --> Model Class Initialized
INFO - 2023-12-22 01:35:00 --> Model Class Initialized
INFO - 2023-12-22 01:35:00 --> Model Class Initialized
INFO - 2023-12-22 01:35:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 01:35:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 01:35:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 01:35:01 --> Final output sent to browser
DEBUG - 2023-12-22 01:35:01 --> Total execution time: 0.1522
ERROR - 2023-12-22 01:35:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:35:02 --> Config Class Initialized
INFO - 2023-12-22 01:35:02 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:35:02 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:35:02 --> Utf8 Class Initialized
INFO - 2023-12-22 01:35:02 --> URI Class Initialized
INFO - 2023-12-22 01:35:02 --> Router Class Initialized
INFO - 2023-12-22 01:35:02 --> Output Class Initialized
INFO - 2023-12-22 01:35:02 --> Security Class Initialized
DEBUG - 2023-12-22 01:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:35:02 --> Input Class Initialized
INFO - 2023-12-22 01:35:02 --> Language Class Initialized
INFO - 2023-12-22 01:35:02 --> Loader Class Initialized
INFO - 2023-12-22 01:35:02 --> Helper loaded: url_helper
INFO - 2023-12-22 01:35:02 --> Helper loaded: file_helper
INFO - 2023-12-22 01:35:02 --> Helper loaded: html_helper
INFO - 2023-12-22 01:35:02 --> Helper loaded: text_helper
INFO - 2023-12-22 01:35:02 --> Helper loaded: form_helper
INFO - 2023-12-22 01:35:02 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:35:02 --> Helper loaded: security_helper
INFO - 2023-12-22 01:35:02 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:35:02 --> Database Driver Class Initialized
INFO - 2023-12-22 01:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:35:02 --> Parser Class Initialized
INFO - 2023-12-22 01:35:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:35:02 --> Pagination Class Initialized
INFO - 2023-12-22 01:35:02 --> Form Validation Class Initialized
INFO - 2023-12-22 01:35:02 --> Controller Class Initialized
INFO - 2023-12-22 01:35:02 --> Model Class Initialized
DEBUG - 2023-12-22 01:35:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 01:35:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:35:02 --> Model Class Initialized
DEBUG - 2023-12-22 01:35:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:35:02 --> Model Class Initialized
INFO - 2023-12-22 01:35:02 --> Final output sent to browser
DEBUG - 2023-12-22 01:35:02 --> Total execution time: 0.0586
ERROR - 2023-12-22 01:35:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:35:15 --> Config Class Initialized
INFO - 2023-12-22 01:35:15 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:35:15 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:35:15 --> Utf8 Class Initialized
INFO - 2023-12-22 01:35:15 --> URI Class Initialized
INFO - 2023-12-22 01:35:15 --> Router Class Initialized
INFO - 2023-12-22 01:35:15 --> Output Class Initialized
INFO - 2023-12-22 01:35:15 --> Security Class Initialized
DEBUG - 2023-12-22 01:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:35:15 --> Input Class Initialized
INFO - 2023-12-22 01:35:15 --> Language Class Initialized
INFO - 2023-12-22 01:35:15 --> Loader Class Initialized
INFO - 2023-12-22 01:35:15 --> Helper loaded: url_helper
INFO - 2023-12-22 01:35:15 --> Helper loaded: file_helper
INFO - 2023-12-22 01:35:15 --> Helper loaded: html_helper
INFO - 2023-12-22 01:35:15 --> Helper loaded: text_helper
INFO - 2023-12-22 01:35:15 --> Helper loaded: form_helper
INFO - 2023-12-22 01:35:15 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:35:15 --> Helper loaded: security_helper
INFO - 2023-12-22 01:35:15 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:35:15 --> Database Driver Class Initialized
INFO - 2023-12-22 01:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:35:15 --> Parser Class Initialized
INFO - 2023-12-22 01:35:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:35:15 --> Pagination Class Initialized
INFO - 2023-12-22 01:35:15 --> Form Validation Class Initialized
INFO - 2023-12-22 01:35:15 --> Controller Class Initialized
INFO - 2023-12-22 01:35:15 --> Model Class Initialized
DEBUG - 2023-12-22 01:35:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 01:35:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:35:15 --> Model Class Initialized
DEBUG - 2023-12-22 01:35:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:35:15 --> Model Class Initialized
INFO - 2023-12-22 01:35:16 --> Final output sent to browser
DEBUG - 2023-12-22 01:35:16 --> Total execution time: 0.0854
ERROR - 2023-12-22 01:35:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:35:32 --> Config Class Initialized
INFO - 2023-12-22 01:35:32 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:35:32 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:35:32 --> Utf8 Class Initialized
INFO - 2023-12-22 01:35:32 --> URI Class Initialized
INFO - 2023-12-22 01:35:32 --> Router Class Initialized
INFO - 2023-12-22 01:35:32 --> Output Class Initialized
INFO - 2023-12-22 01:35:32 --> Security Class Initialized
DEBUG - 2023-12-22 01:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:35:32 --> Input Class Initialized
INFO - 2023-12-22 01:35:32 --> Language Class Initialized
INFO - 2023-12-22 01:35:32 --> Loader Class Initialized
INFO - 2023-12-22 01:35:32 --> Helper loaded: url_helper
INFO - 2023-12-22 01:35:32 --> Helper loaded: file_helper
INFO - 2023-12-22 01:35:32 --> Helper loaded: html_helper
INFO - 2023-12-22 01:35:32 --> Helper loaded: text_helper
INFO - 2023-12-22 01:35:32 --> Helper loaded: form_helper
INFO - 2023-12-22 01:35:32 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:35:32 --> Helper loaded: security_helper
INFO - 2023-12-22 01:35:32 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:35:32 --> Database Driver Class Initialized
INFO - 2023-12-22 01:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:35:32 --> Parser Class Initialized
INFO - 2023-12-22 01:35:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:35:32 --> Pagination Class Initialized
INFO - 2023-12-22 01:35:32 --> Form Validation Class Initialized
INFO - 2023-12-22 01:35:32 --> Controller Class Initialized
INFO - 2023-12-22 01:35:32 --> Model Class Initialized
DEBUG - 2023-12-22 01:35:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 01:35:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:35:32 --> Model Class Initialized
DEBUG - 2023-12-22 01:35:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:35:32 --> Model Class Initialized
DEBUG - 2023-12-22 01:35:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:35:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-12-22 01:35:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:35:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 01:35:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 01:35:32 --> Model Class Initialized
INFO - 2023-12-22 01:35:32 --> Model Class Initialized
INFO - 2023-12-22 01:35:32 --> Model Class Initialized
INFO - 2023-12-22 01:35:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 01:35:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 01:35:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 01:35:32 --> Final output sent to browser
DEBUG - 2023-12-22 01:35:32 --> Total execution time: 0.1499
ERROR - 2023-12-22 01:36:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:36:02 --> Config Class Initialized
INFO - 2023-12-22 01:36:02 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:36:02 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:36:02 --> Utf8 Class Initialized
INFO - 2023-12-22 01:36:02 --> URI Class Initialized
INFO - 2023-12-22 01:36:02 --> Router Class Initialized
INFO - 2023-12-22 01:36:02 --> Output Class Initialized
INFO - 2023-12-22 01:36:02 --> Security Class Initialized
DEBUG - 2023-12-22 01:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:36:02 --> Input Class Initialized
INFO - 2023-12-22 01:36:02 --> Language Class Initialized
INFO - 2023-12-22 01:36:02 --> Loader Class Initialized
INFO - 2023-12-22 01:36:02 --> Helper loaded: url_helper
INFO - 2023-12-22 01:36:02 --> Helper loaded: file_helper
INFO - 2023-12-22 01:36:02 --> Helper loaded: html_helper
INFO - 2023-12-22 01:36:02 --> Helper loaded: text_helper
INFO - 2023-12-22 01:36:02 --> Helper loaded: form_helper
INFO - 2023-12-22 01:36:02 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:36:02 --> Helper loaded: security_helper
INFO - 2023-12-22 01:36:02 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:36:02 --> Database Driver Class Initialized
INFO - 2023-12-22 01:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:36:02 --> Parser Class Initialized
INFO - 2023-12-22 01:36:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:36:02 --> Pagination Class Initialized
INFO - 2023-12-22 01:36:02 --> Form Validation Class Initialized
INFO - 2023-12-22 01:36:02 --> Controller Class Initialized
INFO - 2023-12-22 01:36:02 --> Model Class Initialized
DEBUG - 2023-12-22 01:36:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 01:36:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:36:02 --> Model Class Initialized
DEBUG - 2023-12-22 01:36:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:36:02 --> Model Class Initialized
INFO - 2023-12-22 01:36:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-22 01:36:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:36:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 01:36:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 01:36:02 --> Model Class Initialized
INFO - 2023-12-22 01:36:02 --> Model Class Initialized
INFO - 2023-12-22 01:36:02 --> Model Class Initialized
INFO - 2023-12-22 01:36:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 01:36:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 01:36:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 01:36:02 --> Final output sent to browser
DEBUG - 2023-12-22 01:36:02 --> Total execution time: 0.1502
ERROR - 2023-12-22 01:36:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:36:03 --> Config Class Initialized
INFO - 2023-12-22 01:36:03 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:36:03 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:36:03 --> Utf8 Class Initialized
INFO - 2023-12-22 01:36:03 --> URI Class Initialized
INFO - 2023-12-22 01:36:03 --> Router Class Initialized
INFO - 2023-12-22 01:36:03 --> Output Class Initialized
INFO - 2023-12-22 01:36:03 --> Security Class Initialized
DEBUG - 2023-12-22 01:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:36:03 --> Input Class Initialized
INFO - 2023-12-22 01:36:03 --> Language Class Initialized
INFO - 2023-12-22 01:36:03 --> Loader Class Initialized
INFO - 2023-12-22 01:36:03 --> Helper loaded: url_helper
INFO - 2023-12-22 01:36:03 --> Helper loaded: file_helper
INFO - 2023-12-22 01:36:03 --> Helper loaded: html_helper
INFO - 2023-12-22 01:36:03 --> Helper loaded: text_helper
INFO - 2023-12-22 01:36:03 --> Helper loaded: form_helper
INFO - 2023-12-22 01:36:03 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:36:03 --> Helper loaded: security_helper
INFO - 2023-12-22 01:36:03 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:36:03 --> Database Driver Class Initialized
INFO - 2023-12-22 01:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:36:03 --> Parser Class Initialized
INFO - 2023-12-22 01:36:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:36:03 --> Pagination Class Initialized
INFO - 2023-12-22 01:36:03 --> Form Validation Class Initialized
INFO - 2023-12-22 01:36:03 --> Controller Class Initialized
INFO - 2023-12-22 01:36:03 --> Model Class Initialized
DEBUG - 2023-12-22 01:36:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 01:36:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:36:03 --> Model Class Initialized
DEBUG - 2023-12-22 01:36:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:36:03 --> Model Class Initialized
INFO - 2023-12-22 01:36:03 --> Final output sent to browser
DEBUG - 2023-12-22 01:36:03 --> Total execution time: 0.0411
ERROR - 2023-12-22 01:36:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:36:08 --> Config Class Initialized
INFO - 2023-12-22 01:36:08 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:36:08 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:36:08 --> Utf8 Class Initialized
INFO - 2023-12-22 01:36:08 --> URI Class Initialized
INFO - 2023-12-22 01:36:08 --> Router Class Initialized
INFO - 2023-12-22 01:36:08 --> Output Class Initialized
INFO - 2023-12-22 01:36:08 --> Security Class Initialized
DEBUG - 2023-12-22 01:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:36:08 --> Input Class Initialized
INFO - 2023-12-22 01:36:08 --> Language Class Initialized
INFO - 2023-12-22 01:36:08 --> Loader Class Initialized
INFO - 2023-12-22 01:36:08 --> Helper loaded: url_helper
INFO - 2023-12-22 01:36:08 --> Helper loaded: file_helper
INFO - 2023-12-22 01:36:08 --> Helper loaded: html_helper
INFO - 2023-12-22 01:36:08 --> Helper loaded: text_helper
INFO - 2023-12-22 01:36:08 --> Helper loaded: form_helper
INFO - 2023-12-22 01:36:08 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:36:08 --> Helper loaded: security_helper
INFO - 2023-12-22 01:36:08 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:36:08 --> Database Driver Class Initialized
INFO - 2023-12-22 01:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:36:08 --> Parser Class Initialized
INFO - 2023-12-22 01:36:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:36:08 --> Pagination Class Initialized
INFO - 2023-12-22 01:36:08 --> Form Validation Class Initialized
INFO - 2023-12-22 01:36:08 --> Controller Class Initialized
INFO - 2023-12-22 01:36:08 --> Model Class Initialized
DEBUG - 2023-12-22 01:36:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 01:36:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:36:08 --> Model Class Initialized
DEBUG - 2023-12-22 01:36:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:36:08 --> Model Class Initialized
INFO - 2023-12-22 01:36:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-12-22 01:36:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:36:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 01:36:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 01:36:08 --> Model Class Initialized
INFO - 2023-12-22 01:36:08 --> Model Class Initialized
INFO - 2023-12-22 01:36:08 --> Model Class Initialized
INFO - 2023-12-22 01:36:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 01:36:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 01:36:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 01:36:08 --> Final output sent to browser
DEBUG - 2023-12-22 01:36:08 --> Total execution time: 0.1708
ERROR - 2023-12-22 01:36:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:36:25 --> Config Class Initialized
INFO - 2023-12-22 01:36:25 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:36:25 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:36:25 --> Utf8 Class Initialized
INFO - 2023-12-22 01:36:25 --> URI Class Initialized
INFO - 2023-12-22 01:36:25 --> Router Class Initialized
INFO - 2023-12-22 01:36:25 --> Output Class Initialized
INFO - 2023-12-22 01:36:25 --> Security Class Initialized
DEBUG - 2023-12-22 01:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:36:25 --> Input Class Initialized
INFO - 2023-12-22 01:36:25 --> Language Class Initialized
INFO - 2023-12-22 01:36:25 --> Loader Class Initialized
INFO - 2023-12-22 01:36:25 --> Helper loaded: url_helper
INFO - 2023-12-22 01:36:25 --> Helper loaded: file_helper
INFO - 2023-12-22 01:36:25 --> Helper loaded: html_helper
INFO - 2023-12-22 01:36:25 --> Helper loaded: text_helper
INFO - 2023-12-22 01:36:25 --> Helper loaded: form_helper
INFO - 2023-12-22 01:36:25 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:36:25 --> Helper loaded: security_helper
INFO - 2023-12-22 01:36:25 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:36:25 --> Database Driver Class Initialized
INFO - 2023-12-22 01:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:36:25 --> Parser Class Initialized
INFO - 2023-12-22 01:36:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:36:25 --> Pagination Class Initialized
INFO - 2023-12-22 01:36:25 --> Form Validation Class Initialized
INFO - 2023-12-22 01:36:25 --> Controller Class Initialized
INFO - 2023-12-22 01:36:25 --> Model Class Initialized
DEBUG - 2023-12-22 01:36:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:36:25 --> Final output sent to browser
DEBUG - 2023-12-22 01:36:25 --> Total execution time: 0.0184
ERROR - 2023-12-22 01:36:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:36:25 --> Config Class Initialized
INFO - 2023-12-22 01:36:25 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:36:25 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:36:25 --> Utf8 Class Initialized
INFO - 2023-12-22 01:36:25 --> URI Class Initialized
INFO - 2023-12-22 01:36:25 --> Router Class Initialized
INFO - 2023-12-22 01:36:25 --> Output Class Initialized
INFO - 2023-12-22 01:36:25 --> Security Class Initialized
DEBUG - 2023-12-22 01:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:36:25 --> Input Class Initialized
INFO - 2023-12-22 01:36:25 --> Language Class Initialized
INFO - 2023-12-22 01:36:25 --> Loader Class Initialized
INFO - 2023-12-22 01:36:25 --> Helper loaded: url_helper
INFO - 2023-12-22 01:36:25 --> Helper loaded: file_helper
INFO - 2023-12-22 01:36:25 --> Helper loaded: html_helper
INFO - 2023-12-22 01:36:25 --> Helper loaded: text_helper
INFO - 2023-12-22 01:36:25 --> Helper loaded: form_helper
INFO - 2023-12-22 01:36:25 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:36:25 --> Helper loaded: security_helper
INFO - 2023-12-22 01:36:25 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:36:25 --> Database Driver Class Initialized
INFO - 2023-12-22 01:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:36:25 --> Parser Class Initialized
INFO - 2023-12-22 01:36:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:36:25 --> Pagination Class Initialized
INFO - 2023-12-22 01:36:25 --> Form Validation Class Initialized
INFO - 2023-12-22 01:36:25 --> Controller Class Initialized
INFO - 2023-12-22 01:36:25 --> Model Class Initialized
DEBUG - 2023-12-22 01:36:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:36:25 --> Final output sent to browser
DEBUG - 2023-12-22 01:36:25 --> Total execution time: 0.0160
ERROR - 2023-12-22 01:36:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:36:45 --> Config Class Initialized
INFO - 2023-12-22 01:36:45 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:36:45 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:36:45 --> Utf8 Class Initialized
INFO - 2023-12-22 01:36:45 --> URI Class Initialized
INFO - 2023-12-22 01:36:45 --> Router Class Initialized
INFO - 2023-12-22 01:36:45 --> Output Class Initialized
INFO - 2023-12-22 01:36:45 --> Security Class Initialized
DEBUG - 2023-12-22 01:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:36:45 --> Input Class Initialized
INFO - 2023-12-22 01:36:45 --> Language Class Initialized
INFO - 2023-12-22 01:36:45 --> Loader Class Initialized
INFO - 2023-12-22 01:36:45 --> Helper loaded: url_helper
INFO - 2023-12-22 01:36:45 --> Helper loaded: file_helper
INFO - 2023-12-22 01:36:45 --> Helper loaded: html_helper
INFO - 2023-12-22 01:36:45 --> Helper loaded: text_helper
INFO - 2023-12-22 01:36:45 --> Helper loaded: form_helper
INFO - 2023-12-22 01:36:45 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:36:45 --> Helper loaded: security_helper
INFO - 2023-12-22 01:36:45 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:36:45 --> Database Driver Class Initialized
INFO - 2023-12-22 01:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:36:45 --> Parser Class Initialized
INFO - 2023-12-22 01:36:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:36:45 --> Pagination Class Initialized
INFO - 2023-12-22 01:36:45 --> Form Validation Class Initialized
INFO - 2023-12-22 01:36:45 --> Controller Class Initialized
INFO - 2023-12-22 01:36:45 --> Final output sent to browser
DEBUG - 2023-12-22 01:36:45 --> Total execution time: 0.0156
ERROR - 2023-12-22 01:36:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:36:57 --> Config Class Initialized
INFO - 2023-12-22 01:36:57 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:36:57 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:36:57 --> Utf8 Class Initialized
INFO - 2023-12-22 01:36:57 --> URI Class Initialized
INFO - 2023-12-22 01:36:57 --> Router Class Initialized
INFO - 2023-12-22 01:36:57 --> Output Class Initialized
INFO - 2023-12-22 01:36:57 --> Security Class Initialized
DEBUG - 2023-12-22 01:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:36:57 --> Input Class Initialized
INFO - 2023-12-22 01:36:57 --> Language Class Initialized
INFO - 2023-12-22 01:36:57 --> Loader Class Initialized
INFO - 2023-12-22 01:36:57 --> Helper loaded: url_helper
INFO - 2023-12-22 01:36:57 --> Helper loaded: file_helper
INFO - 2023-12-22 01:36:57 --> Helper loaded: html_helper
INFO - 2023-12-22 01:36:57 --> Helper loaded: text_helper
INFO - 2023-12-22 01:36:57 --> Helper loaded: form_helper
INFO - 2023-12-22 01:36:57 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:36:57 --> Helper loaded: security_helper
INFO - 2023-12-22 01:36:57 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:36:57 --> Database Driver Class Initialized
INFO - 2023-12-22 01:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:36:57 --> Parser Class Initialized
INFO - 2023-12-22 01:36:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:36:57 --> Pagination Class Initialized
INFO - 2023-12-22 01:36:57 --> Form Validation Class Initialized
INFO - 2023-12-22 01:36:57 --> Controller Class Initialized
INFO - 2023-12-22 01:36:57 --> Model Class Initialized
DEBUG - 2023-12-22 01:36:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 01:36:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:36:57 --> Model Class Initialized
DEBUG - 2023-12-22 01:36:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:36:57 --> Model Class Initialized
INFO - 2023-12-22 01:36:57 --> Final output sent to browser
DEBUG - 2023-12-22 01:36:57 --> Total execution time: 0.0777
ERROR - 2023-12-22 01:37:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:37:07 --> Config Class Initialized
INFO - 2023-12-22 01:37:07 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:37:07 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:37:07 --> Utf8 Class Initialized
INFO - 2023-12-22 01:37:07 --> URI Class Initialized
INFO - 2023-12-22 01:37:07 --> Router Class Initialized
INFO - 2023-12-22 01:37:07 --> Output Class Initialized
INFO - 2023-12-22 01:37:08 --> Security Class Initialized
DEBUG - 2023-12-22 01:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:37:08 --> Input Class Initialized
INFO - 2023-12-22 01:37:08 --> Language Class Initialized
INFO - 2023-12-22 01:37:08 --> Loader Class Initialized
INFO - 2023-12-22 01:37:08 --> Helper loaded: url_helper
INFO - 2023-12-22 01:37:08 --> Helper loaded: file_helper
INFO - 2023-12-22 01:37:08 --> Helper loaded: html_helper
INFO - 2023-12-22 01:37:08 --> Helper loaded: text_helper
INFO - 2023-12-22 01:37:08 --> Helper loaded: form_helper
INFO - 2023-12-22 01:37:08 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:37:08 --> Helper loaded: security_helper
INFO - 2023-12-22 01:37:08 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:37:08 --> Database Driver Class Initialized
INFO - 2023-12-22 01:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:37:08 --> Parser Class Initialized
INFO - 2023-12-22 01:37:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:37:08 --> Pagination Class Initialized
INFO - 2023-12-22 01:37:08 --> Form Validation Class Initialized
INFO - 2023-12-22 01:37:08 --> Controller Class Initialized
INFO - 2023-12-22 01:37:08 --> Model Class Initialized
DEBUG - 2023-12-22 01:37:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 01:37:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:37:08 --> Model Class Initialized
INFO - 2023-12-22 01:37:08 --> Model Class Initialized
INFO - 2023-12-22 01:37:08 --> Final output sent to browser
DEBUG - 2023-12-22 01:37:08 --> Total execution time: 0.0201
ERROR - 2023-12-22 01:37:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:37:09 --> Config Class Initialized
INFO - 2023-12-22 01:37:09 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:37:09 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:37:09 --> Utf8 Class Initialized
INFO - 2023-12-22 01:37:09 --> URI Class Initialized
INFO - 2023-12-22 01:37:09 --> Router Class Initialized
INFO - 2023-12-22 01:37:09 --> Output Class Initialized
INFO - 2023-12-22 01:37:09 --> Security Class Initialized
DEBUG - 2023-12-22 01:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:37:09 --> Input Class Initialized
INFO - 2023-12-22 01:37:09 --> Language Class Initialized
INFO - 2023-12-22 01:37:09 --> Loader Class Initialized
INFO - 2023-12-22 01:37:09 --> Helper loaded: url_helper
INFO - 2023-12-22 01:37:09 --> Helper loaded: file_helper
INFO - 2023-12-22 01:37:09 --> Helper loaded: html_helper
INFO - 2023-12-22 01:37:09 --> Helper loaded: text_helper
INFO - 2023-12-22 01:37:09 --> Helper loaded: form_helper
INFO - 2023-12-22 01:37:09 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:37:09 --> Helper loaded: security_helper
INFO - 2023-12-22 01:37:09 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:37:09 --> Database Driver Class Initialized
INFO - 2023-12-22 01:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:37:09 --> Parser Class Initialized
INFO - 2023-12-22 01:37:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:37:09 --> Pagination Class Initialized
INFO - 2023-12-22 01:37:09 --> Form Validation Class Initialized
INFO - 2023-12-22 01:37:09 --> Controller Class Initialized
INFO - 2023-12-22 01:37:09 --> Model Class Initialized
DEBUG - 2023-12-22 01:37:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 01:37:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:37:09 --> Model Class Initialized
INFO - 2023-12-22 01:37:09 --> Final output sent to browser
DEBUG - 2023-12-22 01:37:09 --> Total execution time: 0.0170
ERROR - 2023-12-22 01:37:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:37:10 --> Config Class Initialized
INFO - 2023-12-22 01:37:10 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:37:10 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:37:10 --> Utf8 Class Initialized
INFO - 2023-12-22 01:37:10 --> URI Class Initialized
INFO - 2023-12-22 01:37:10 --> Router Class Initialized
INFO - 2023-12-22 01:37:10 --> Output Class Initialized
INFO - 2023-12-22 01:37:10 --> Security Class Initialized
DEBUG - 2023-12-22 01:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:37:10 --> Input Class Initialized
INFO - 2023-12-22 01:37:10 --> Language Class Initialized
INFO - 2023-12-22 01:37:10 --> Loader Class Initialized
INFO - 2023-12-22 01:37:10 --> Helper loaded: url_helper
INFO - 2023-12-22 01:37:10 --> Helper loaded: file_helper
INFO - 2023-12-22 01:37:10 --> Helper loaded: html_helper
INFO - 2023-12-22 01:37:10 --> Helper loaded: text_helper
INFO - 2023-12-22 01:37:10 --> Helper loaded: form_helper
INFO - 2023-12-22 01:37:10 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:37:10 --> Helper loaded: security_helper
INFO - 2023-12-22 01:37:10 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:37:10 --> Database Driver Class Initialized
INFO - 2023-12-22 01:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:37:10 --> Parser Class Initialized
INFO - 2023-12-22 01:37:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:37:10 --> Pagination Class Initialized
INFO - 2023-12-22 01:37:10 --> Form Validation Class Initialized
INFO - 2023-12-22 01:37:10 --> Controller Class Initialized
INFO - 2023-12-22 01:37:10 --> Model Class Initialized
DEBUG - 2023-12-22 01:37:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 01:37:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:37:10 --> Model Class Initialized
INFO - 2023-12-22 01:37:10 --> Final output sent to browser
DEBUG - 2023-12-22 01:37:10 --> Total execution time: 0.0162
ERROR - 2023-12-22 01:37:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:37:15 --> Config Class Initialized
INFO - 2023-12-22 01:37:15 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:37:15 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:37:15 --> Utf8 Class Initialized
INFO - 2023-12-22 01:37:15 --> URI Class Initialized
INFO - 2023-12-22 01:37:15 --> Router Class Initialized
INFO - 2023-12-22 01:37:15 --> Output Class Initialized
INFO - 2023-12-22 01:37:15 --> Security Class Initialized
DEBUG - 2023-12-22 01:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:37:15 --> Input Class Initialized
INFO - 2023-12-22 01:37:15 --> Language Class Initialized
INFO - 2023-12-22 01:37:15 --> Loader Class Initialized
INFO - 2023-12-22 01:37:15 --> Helper loaded: url_helper
INFO - 2023-12-22 01:37:15 --> Helper loaded: file_helper
INFO - 2023-12-22 01:37:15 --> Helper loaded: html_helper
INFO - 2023-12-22 01:37:15 --> Helper loaded: text_helper
INFO - 2023-12-22 01:37:15 --> Helper loaded: form_helper
INFO - 2023-12-22 01:37:15 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:37:15 --> Helper loaded: security_helper
INFO - 2023-12-22 01:37:15 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:37:15 --> Database Driver Class Initialized
INFO - 2023-12-22 01:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:37:15 --> Parser Class Initialized
INFO - 2023-12-22 01:37:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:37:15 --> Pagination Class Initialized
INFO - 2023-12-22 01:37:15 --> Form Validation Class Initialized
INFO - 2023-12-22 01:37:15 --> Controller Class Initialized
INFO - 2023-12-22 01:37:15 --> Model Class Initialized
DEBUG - 2023-12-22 01:37:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 01:37:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:37:15 --> Model Class Initialized
INFO - 2023-12-22 01:37:15 --> Final output sent to browser
DEBUG - 2023-12-22 01:37:15 --> Total execution time: 0.0146
ERROR - 2023-12-22 01:37:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:37:16 --> Config Class Initialized
INFO - 2023-12-22 01:37:16 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:37:16 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:37:16 --> Utf8 Class Initialized
INFO - 2023-12-22 01:37:16 --> URI Class Initialized
INFO - 2023-12-22 01:37:16 --> Router Class Initialized
INFO - 2023-12-22 01:37:16 --> Output Class Initialized
INFO - 2023-12-22 01:37:16 --> Security Class Initialized
DEBUG - 2023-12-22 01:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:37:16 --> Input Class Initialized
INFO - 2023-12-22 01:37:16 --> Language Class Initialized
INFO - 2023-12-22 01:37:16 --> Loader Class Initialized
INFO - 2023-12-22 01:37:16 --> Helper loaded: url_helper
INFO - 2023-12-22 01:37:16 --> Helper loaded: file_helper
INFO - 2023-12-22 01:37:16 --> Helper loaded: html_helper
INFO - 2023-12-22 01:37:16 --> Helper loaded: text_helper
INFO - 2023-12-22 01:37:16 --> Helper loaded: form_helper
INFO - 2023-12-22 01:37:16 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:37:16 --> Helper loaded: security_helper
INFO - 2023-12-22 01:37:16 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:37:16 --> Database Driver Class Initialized
INFO - 2023-12-22 01:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:37:16 --> Parser Class Initialized
INFO - 2023-12-22 01:37:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:37:16 --> Pagination Class Initialized
INFO - 2023-12-22 01:37:16 --> Form Validation Class Initialized
INFO - 2023-12-22 01:37:16 --> Controller Class Initialized
INFO - 2023-12-22 01:37:16 --> Model Class Initialized
DEBUG - 2023-12-22 01:37:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 01:37:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:37:16 --> Model Class Initialized
INFO - 2023-12-22 01:37:16 --> Final output sent to browser
DEBUG - 2023-12-22 01:37:16 --> Total execution time: 0.0152
ERROR - 2023-12-22 01:37:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:37:23 --> Config Class Initialized
INFO - 2023-12-22 01:37:23 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:37:23 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:37:23 --> Utf8 Class Initialized
INFO - 2023-12-22 01:37:23 --> URI Class Initialized
INFO - 2023-12-22 01:37:23 --> Router Class Initialized
INFO - 2023-12-22 01:37:23 --> Output Class Initialized
INFO - 2023-12-22 01:37:23 --> Security Class Initialized
DEBUG - 2023-12-22 01:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:37:23 --> Input Class Initialized
INFO - 2023-12-22 01:37:23 --> Language Class Initialized
INFO - 2023-12-22 01:37:23 --> Loader Class Initialized
INFO - 2023-12-22 01:37:23 --> Helper loaded: url_helper
INFO - 2023-12-22 01:37:23 --> Helper loaded: file_helper
INFO - 2023-12-22 01:37:23 --> Helper loaded: html_helper
INFO - 2023-12-22 01:37:23 --> Helper loaded: text_helper
INFO - 2023-12-22 01:37:23 --> Helper loaded: form_helper
INFO - 2023-12-22 01:37:23 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:37:23 --> Helper loaded: security_helper
INFO - 2023-12-22 01:37:23 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:37:23 --> Database Driver Class Initialized
INFO - 2023-12-22 01:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:37:23 --> Parser Class Initialized
INFO - 2023-12-22 01:37:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:37:23 --> Pagination Class Initialized
INFO - 2023-12-22 01:37:23 --> Form Validation Class Initialized
INFO - 2023-12-22 01:37:23 --> Controller Class Initialized
INFO - 2023-12-22 01:37:23 --> Model Class Initialized
DEBUG - 2023-12-22 01:37:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 01:37:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:37:23 --> Model Class Initialized
DEBUG - 2023-12-22 01:37:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:37:23 --> Model Class Initialized
INFO - 2023-12-22 01:37:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-22 01:37:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:37:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 01:37:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 01:37:23 --> Model Class Initialized
INFO - 2023-12-22 01:37:23 --> Model Class Initialized
INFO - 2023-12-22 01:37:23 --> Model Class Initialized
INFO - 2023-12-22 01:37:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 01:37:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 01:37:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 01:37:23 --> Final output sent to browser
DEBUG - 2023-12-22 01:37:23 --> Total execution time: 0.1449
ERROR - 2023-12-22 01:37:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:37:24 --> Config Class Initialized
INFO - 2023-12-22 01:37:24 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:37:24 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:37:24 --> Utf8 Class Initialized
INFO - 2023-12-22 01:37:24 --> URI Class Initialized
INFO - 2023-12-22 01:37:24 --> Router Class Initialized
INFO - 2023-12-22 01:37:24 --> Output Class Initialized
INFO - 2023-12-22 01:37:24 --> Security Class Initialized
DEBUG - 2023-12-22 01:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:37:24 --> Input Class Initialized
INFO - 2023-12-22 01:37:24 --> Language Class Initialized
INFO - 2023-12-22 01:37:24 --> Loader Class Initialized
INFO - 2023-12-22 01:37:24 --> Helper loaded: url_helper
INFO - 2023-12-22 01:37:24 --> Helper loaded: file_helper
INFO - 2023-12-22 01:37:24 --> Helper loaded: html_helper
INFO - 2023-12-22 01:37:24 --> Helper loaded: text_helper
INFO - 2023-12-22 01:37:24 --> Helper loaded: form_helper
INFO - 2023-12-22 01:37:24 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:37:24 --> Helper loaded: security_helper
INFO - 2023-12-22 01:37:24 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:37:24 --> Database Driver Class Initialized
INFO - 2023-12-22 01:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:37:24 --> Parser Class Initialized
INFO - 2023-12-22 01:37:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:37:24 --> Pagination Class Initialized
INFO - 2023-12-22 01:37:24 --> Form Validation Class Initialized
INFO - 2023-12-22 01:37:24 --> Controller Class Initialized
INFO - 2023-12-22 01:37:24 --> Model Class Initialized
DEBUG - 2023-12-22 01:37:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 01:37:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:37:24 --> Model Class Initialized
DEBUG - 2023-12-22 01:37:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:37:24 --> Model Class Initialized
INFO - 2023-12-22 01:37:24 --> Final output sent to browser
DEBUG - 2023-12-22 01:37:24 --> Total execution time: 0.0421
ERROR - 2023-12-22 01:37:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:37:24 --> Config Class Initialized
INFO - 2023-12-22 01:37:24 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:37:24 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:37:24 --> Utf8 Class Initialized
INFO - 2023-12-22 01:37:24 --> URI Class Initialized
DEBUG - 2023-12-22 01:37:24 --> No URI present. Default controller set.
INFO - 2023-12-22 01:37:24 --> Router Class Initialized
INFO - 2023-12-22 01:37:24 --> Output Class Initialized
INFO - 2023-12-22 01:37:24 --> Security Class Initialized
DEBUG - 2023-12-22 01:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:37:24 --> Input Class Initialized
INFO - 2023-12-22 01:37:24 --> Language Class Initialized
INFO - 2023-12-22 01:37:24 --> Loader Class Initialized
INFO - 2023-12-22 01:37:24 --> Helper loaded: url_helper
INFO - 2023-12-22 01:37:24 --> Helper loaded: file_helper
INFO - 2023-12-22 01:37:24 --> Helper loaded: html_helper
INFO - 2023-12-22 01:37:24 --> Helper loaded: text_helper
INFO - 2023-12-22 01:37:24 --> Helper loaded: form_helper
INFO - 2023-12-22 01:37:24 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:37:24 --> Helper loaded: security_helper
INFO - 2023-12-22 01:37:24 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:37:24 --> Database Driver Class Initialized
INFO - 2023-12-22 01:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:37:24 --> Parser Class Initialized
INFO - 2023-12-22 01:37:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:37:24 --> Pagination Class Initialized
INFO - 2023-12-22 01:37:24 --> Form Validation Class Initialized
INFO - 2023-12-22 01:37:24 --> Controller Class Initialized
INFO - 2023-12-22 01:37:24 --> Model Class Initialized
DEBUG - 2023-12-22 01:37:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:37:24 --> Model Class Initialized
DEBUG - 2023-12-22 01:37:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:37:24 --> Model Class Initialized
INFO - 2023-12-22 01:37:24 --> Model Class Initialized
INFO - 2023-12-22 01:37:24 --> Model Class Initialized
INFO - 2023-12-22 01:37:24 --> Model Class Initialized
DEBUG - 2023-12-22 01:37:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 01:37:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:37:24 --> Model Class Initialized
INFO - 2023-12-22 01:37:24 --> Model Class Initialized
INFO - 2023-12-22 01:37:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-22 01:37:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:37:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 01:37:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 01:37:24 --> Model Class Initialized
INFO - 2023-12-22 01:37:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 01:37:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 01:37:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 01:37:24 --> Final output sent to browser
DEBUG - 2023-12-22 01:37:24 --> Total execution time: 0.2160
ERROR - 2023-12-22 01:37:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:37:24 --> Config Class Initialized
INFO - 2023-12-22 01:37:24 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:37:24 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:37:24 --> Utf8 Class Initialized
INFO - 2023-12-22 01:37:24 --> URI Class Initialized
INFO - 2023-12-22 01:37:24 --> Router Class Initialized
INFO - 2023-12-22 01:37:24 --> Output Class Initialized
INFO - 2023-12-22 01:37:24 --> Security Class Initialized
DEBUG - 2023-12-22 01:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:37:24 --> Input Class Initialized
INFO - 2023-12-22 01:37:24 --> Language Class Initialized
INFO - 2023-12-22 01:37:24 --> Loader Class Initialized
INFO - 2023-12-22 01:37:24 --> Helper loaded: url_helper
INFO - 2023-12-22 01:37:24 --> Helper loaded: file_helper
INFO - 2023-12-22 01:37:24 --> Helper loaded: html_helper
INFO - 2023-12-22 01:37:24 --> Helper loaded: text_helper
INFO - 2023-12-22 01:37:24 --> Helper loaded: form_helper
INFO - 2023-12-22 01:37:24 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:37:24 --> Helper loaded: security_helper
INFO - 2023-12-22 01:37:24 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:37:24 --> Database Driver Class Initialized
INFO - 2023-12-22 01:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:37:24 --> Parser Class Initialized
INFO - 2023-12-22 01:37:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:37:24 --> Pagination Class Initialized
INFO - 2023-12-22 01:37:24 --> Form Validation Class Initialized
INFO - 2023-12-22 01:37:24 --> Controller Class Initialized
INFO - 2023-12-22 01:37:24 --> Model Class Initialized
DEBUG - 2023-12-22 01:37:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:37:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-22 01:37:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:37:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 01:37:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 01:37:24 --> Model Class Initialized
INFO - 2023-12-22 01:37:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 01:37:24 --> Final output sent to browser
DEBUG - 2023-12-22 01:37:24 --> Total execution time: 0.0295
ERROR - 2023-12-22 01:37:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:37:25 --> Config Class Initialized
INFO - 2023-12-22 01:37:25 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:37:25 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:37:25 --> Utf8 Class Initialized
INFO - 2023-12-22 01:37:25 --> URI Class Initialized
INFO - 2023-12-22 01:37:25 --> Router Class Initialized
INFO - 2023-12-22 01:37:25 --> Output Class Initialized
INFO - 2023-12-22 01:37:25 --> Security Class Initialized
DEBUG - 2023-12-22 01:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:37:25 --> Input Class Initialized
INFO - 2023-12-22 01:37:25 --> Language Class Initialized
INFO - 2023-12-22 01:37:25 --> Loader Class Initialized
INFO - 2023-12-22 01:37:25 --> Helper loaded: url_helper
INFO - 2023-12-22 01:37:25 --> Helper loaded: file_helper
INFO - 2023-12-22 01:37:25 --> Helper loaded: html_helper
INFO - 2023-12-22 01:37:25 --> Helper loaded: text_helper
INFO - 2023-12-22 01:37:25 --> Helper loaded: form_helper
INFO - 2023-12-22 01:37:25 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:37:25 --> Helper loaded: security_helper
INFO - 2023-12-22 01:37:25 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:37:25 --> Database Driver Class Initialized
INFO - 2023-12-22 01:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:37:25 --> Parser Class Initialized
INFO - 2023-12-22 01:37:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:37:25 --> Pagination Class Initialized
INFO - 2023-12-22 01:37:25 --> Form Validation Class Initialized
INFO - 2023-12-22 01:37:25 --> Controller Class Initialized
INFO - 2023-12-22 01:37:25 --> Model Class Initialized
DEBUG - 2023-12-22 01:37:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:37:25 --> Model Class Initialized
DEBUG - 2023-12-22 01:37:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:37:25 --> Model Class Initialized
INFO - 2023-12-22 01:37:25 --> Model Class Initialized
INFO - 2023-12-22 01:37:25 --> Model Class Initialized
INFO - 2023-12-22 01:37:25 --> Model Class Initialized
DEBUG - 2023-12-22 01:37:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 01:37:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:37:25 --> Model Class Initialized
INFO - 2023-12-22 01:37:25 --> Model Class Initialized
INFO - 2023-12-22 01:37:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-22 01:37:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:37:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 01:37:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 01:37:25 --> Model Class Initialized
INFO - 2023-12-22 01:37:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 01:37:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 01:37:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 01:37:25 --> Final output sent to browser
DEBUG - 2023-12-22 01:37:25 --> Total execution time: 0.2206
ERROR - 2023-12-22 01:37:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:37:39 --> Config Class Initialized
INFO - 2023-12-22 01:37:39 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:37:39 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:37:39 --> Utf8 Class Initialized
INFO - 2023-12-22 01:37:39 --> URI Class Initialized
INFO - 2023-12-22 01:37:39 --> Router Class Initialized
INFO - 2023-12-22 01:37:39 --> Output Class Initialized
INFO - 2023-12-22 01:37:39 --> Security Class Initialized
DEBUG - 2023-12-22 01:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:37:39 --> Input Class Initialized
INFO - 2023-12-22 01:37:39 --> Language Class Initialized
INFO - 2023-12-22 01:37:39 --> Loader Class Initialized
INFO - 2023-12-22 01:37:39 --> Helper loaded: url_helper
INFO - 2023-12-22 01:37:39 --> Helper loaded: file_helper
INFO - 2023-12-22 01:37:39 --> Helper loaded: html_helper
INFO - 2023-12-22 01:37:39 --> Helper loaded: text_helper
INFO - 2023-12-22 01:37:39 --> Helper loaded: form_helper
INFO - 2023-12-22 01:37:39 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:37:39 --> Helper loaded: security_helper
INFO - 2023-12-22 01:37:39 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:37:39 --> Database Driver Class Initialized
INFO - 2023-12-22 01:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:37:39 --> Parser Class Initialized
INFO - 2023-12-22 01:37:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:37:39 --> Pagination Class Initialized
INFO - 2023-12-22 01:37:39 --> Form Validation Class Initialized
INFO - 2023-12-22 01:37:39 --> Controller Class Initialized
INFO - 2023-12-22 01:37:39 --> Model Class Initialized
DEBUG - 2023-12-22 01:37:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 01:37:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:37:39 --> Model Class Initialized
INFO - 2023-12-22 01:37:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-12-22 01:37:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:37:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 01:37:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 01:37:39 --> Model Class Initialized
INFO - 2023-12-22 01:37:39 --> Model Class Initialized
INFO - 2023-12-22 01:37:39 --> Model Class Initialized
INFO - 2023-12-22 01:37:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 01:37:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 01:37:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 01:37:39 --> Final output sent to browser
DEBUG - 2023-12-22 01:37:39 --> Total execution time: 0.1352
ERROR - 2023-12-22 01:37:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:37:40 --> Config Class Initialized
INFO - 2023-12-22 01:37:40 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:37:40 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:37:40 --> Utf8 Class Initialized
INFO - 2023-12-22 01:37:40 --> URI Class Initialized
INFO - 2023-12-22 01:37:40 --> Router Class Initialized
INFO - 2023-12-22 01:37:40 --> Output Class Initialized
INFO - 2023-12-22 01:37:40 --> Security Class Initialized
DEBUG - 2023-12-22 01:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:37:40 --> Input Class Initialized
INFO - 2023-12-22 01:37:40 --> Language Class Initialized
INFO - 2023-12-22 01:37:40 --> Loader Class Initialized
INFO - 2023-12-22 01:37:40 --> Helper loaded: url_helper
INFO - 2023-12-22 01:37:40 --> Helper loaded: file_helper
INFO - 2023-12-22 01:37:40 --> Helper loaded: html_helper
INFO - 2023-12-22 01:37:40 --> Helper loaded: text_helper
INFO - 2023-12-22 01:37:40 --> Helper loaded: form_helper
INFO - 2023-12-22 01:37:40 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:37:40 --> Helper loaded: security_helper
INFO - 2023-12-22 01:37:40 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:37:40 --> Database Driver Class Initialized
INFO - 2023-12-22 01:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:37:40 --> Parser Class Initialized
INFO - 2023-12-22 01:37:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:37:40 --> Pagination Class Initialized
INFO - 2023-12-22 01:37:40 --> Form Validation Class Initialized
INFO - 2023-12-22 01:37:40 --> Controller Class Initialized
INFO - 2023-12-22 01:37:40 --> Model Class Initialized
DEBUG - 2023-12-22 01:37:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 01:37:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:37:40 --> Model Class Initialized
INFO - 2023-12-22 01:37:40 --> Final output sent to browser
DEBUG - 2023-12-22 01:37:40 --> Total execution time: 0.0451
ERROR - 2023-12-22 01:37:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:37:45 --> Config Class Initialized
INFO - 2023-12-22 01:37:45 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:37:45 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:37:45 --> Utf8 Class Initialized
INFO - 2023-12-22 01:37:45 --> URI Class Initialized
INFO - 2023-12-22 01:37:45 --> Router Class Initialized
INFO - 2023-12-22 01:37:45 --> Output Class Initialized
INFO - 2023-12-22 01:37:45 --> Security Class Initialized
DEBUG - 2023-12-22 01:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:37:45 --> Input Class Initialized
INFO - 2023-12-22 01:37:45 --> Language Class Initialized
INFO - 2023-12-22 01:37:45 --> Loader Class Initialized
INFO - 2023-12-22 01:37:45 --> Helper loaded: url_helper
INFO - 2023-12-22 01:37:45 --> Helper loaded: file_helper
INFO - 2023-12-22 01:37:45 --> Helper loaded: html_helper
INFO - 2023-12-22 01:37:45 --> Helper loaded: text_helper
INFO - 2023-12-22 01:37:45 --> Helper loaded: form_helper
INFO - 2023-12-22 01:37:45 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:37:45 --> Helper loaded: security_helper
INFO - 2023-12-22 01:37:45 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:37:45 --> Database Driver Class Initialized
INFO - 2023-12-22 01:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:37:45 --> Parser Class Initialized
INFO - 2023-12-22 01:37:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:37:45 --> Pagination Class Initialized
INFO - 2023-12-22 01:37:45 --> Form Validation Class Initialized
INFO - 2023-12-22 01:37:45 --> Controller Class Initialized
INFO - 2023-12-22 01:37:45 --> Model Class Initialized
DEBUG - 2023-12-22 01:37:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 01:37:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:37:45 --> Model Class Initialized
INFO - 2023-12-22 01:37:45 --> Final output sent to browser
DEBUG - 2023-12-22 01:37:45 --> Total execution time: 0.0441
ERROR - 2023-12-22 01:38:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:38:14 --> Config Class Initialized
INFO - 2023-12-22 01:38:14 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:38:14 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:38:14 --> Utf8 Class Initialized
INFO - 2023-12-22 01:38:14 --> URI Class Initialized
INFO - 2023-12-22 01:38:14 --> Router Class Initialized
INFO - 2023-12-22 01:38:14 --> Output Class Initialized
INFO - 2023-12-22 01:38:14 --> Security Class Initialized
DEBUG - 2023-12-22 01:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:38:14 --> Input Class Initialized
INFO - 2023-12-22 01:38:14 --> Language Class Initialized
INFO - 2023-12-22 01:38:14 --> Loader Class Initialized
INFO - 2023-12-22 01:38:14 --> Helper loaded: url_helper
INFO - 2023-12-22 01:38:14 --> Helper loaded: file_helper
INFO - 2023-12-22 01:38:14 --> Helper loaded: html_helper
INFO - 2023-12-22 01:38:14 --> Helper loaded: text_helper
INFO - 2023-12-22 01:38:14 --> Helper loaded: form_helper
INFO - 2023-12-22 01:38:14 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:38:14 --> Helper loaded: security_helper
INFO - 2023-12-22 01:38:14 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:38:14 --> Database Driver Class Initialized
INFO - 2023-12-22 01:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:38:14 --> Parser Class Initialized
INFO - 2023-12-22 01:38:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:38:14 --> Pagination Class Initialized
INFO - 2023-12-22 01:38:14 --> Form Validation Class Initialized
INFO - 2023-12-22 01:38:14 --> Controller Class Initialized
INFO - 2023-12-22 01:38:14 --> Model Class Initialized
DEBUG - 2023-12-22 01:38:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:38:14 --> Model Class Initialized
DEBUG - 2023-12-22 01:38:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:38:14 --> Model Class Initialized
INFO - 2023-12-22 01:38:14 --> Model Class Initialized
INFO - 2023-12-22 01:38:14 --> Model Class Initialized
INFO - 2023-12-22 01:38:14 --> Model Class Initialized
DEBUG - 2023-12-22 01:38:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 01:38:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:38:14 --> Model Class Initialized
INFO - 2023-12-22 01:38:14 --> Model Class Initialized
INFO - 2023-12-22 01:38:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-22 01:38:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:38:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 01:38:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 01:38:14 --> Model Class Initialized
INFO - 2023-12-22 01:38:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 01:38:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 01:38:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 01:38:14 --> Final output sent to browser
DEBUG - 2023-12-22 01:38:14 --> Total execution time: 0.2190
ERROR - 2023-12-22 01:38:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:38:26 --> Config Class Initialized
INFO - 2023-12-22 01:38:26 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:38:26 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:38:26 --> Utf8 Class Initialized
INFO - 2023-12-22 01:38:26 --> URI Class Initialized
INFO - 2023-12-22 01:38:26 --> Router Class Initialized
INFO - 2023-12-22 01:38:26 --> Output Class Initialized
INFO - 2023-12-22 01:38:26 --> Security Class Initialized
DEBUG - 2023-12-22 01:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:38:26 --> Input Class Initialized
INFO - 2023-12-22 01:38:26 --> Language Class Initialized
INFO - 2023-12-22 01:38:26 --> Loader Class Initialized
INFO - 2023-12-22 01:38:26 --> Helper loaded: url_helper
INFO - 2023-12-22 01:38:26 --> Helper loaded: file_helper
INFO - 2023-12-22 01:38:26 --> Helper loaded: html_helper
INFO - 2023-12-22 01:38:26 --> Helper loaded: text_helper
INFO - 2023-12-22 01:38:26 --> Helper loaded: form_helper
INFO - 2023-12-22 01:38:26 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:38:26 --> Helper loaded: security_helper
INFO - 2023-12-22 01:38:26 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:38:26 --> Database Driver Class Initialized
INFO - 2023-12-22 01:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:38:26 --> Parser Class Initialized
INFO - 2023-12-22 01:38:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:38:26 --> Pagination Class Initialized
INFO - 2023-12-22 01:38:26 --> Form Validation Class Initialized
INFO - 2023-12-22 01:38:26 --> Controller Class Initialized
INFO - 2023-12-22 01:38:26 --> Model Class Initialized
DEBUG - 2023-12-22 01:38:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 01:38:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:38:26 --> Model Class Initialized
INFO - 2023-12-22 01:38:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-12-22 01:38:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:38:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 01:38:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 01:38:26 --> Model Class Initialized
INFO - 2023-12-22 01:38:26 --> Model Class Initialized
INFO - 2023-12-22 01:38:26 --> Model Class Initialized
INFO - 2023-12-22 01:38:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 01:38:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 01:38:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 01:38:26 --> Final output sent to browser
DEBUG - 2023-12-22 01:38:26 --> Total execution time: 0.1342
ERROR - 2023-12-22 01:38:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:38:26 --> Config Class Initialized
INFO - 2023-12-22 01:38:26 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:38:26 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:38:26 --> Utf8 Class Initialized
INFO - 2023-12-22 01:38:26 --> URI Class Initialized
INFO - 2023-12-22 01:38:26 --> Router Class Initialized
INFO - 2023-12-22 01:38:26 --> Output Class Initialized
INFO - 2023-12-22 01:38:26 --> Security Class Initialized
DEBUG - 2023-12-22 01:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:38:26 --> Input Class Initialized
INFO - 2023-12-22 01:38:26 --> Language Class Initialized
INFO - 2023-12-22 01:38:26 --> Loader Class Initialized
INFO - 2023-12-22 01:38:26 --> Helper loaded: url_helper
INFO - 2023-12-22 01:38:26 --> Helper loaded: file_helper
INFO - 2023-12-22 01:38:26 --> Helper loaded: html_helper
INFO - 2023-12-22 01:38:26 --> Helper loaded: text_helper
INFO - 2023-12-22 01:38:26 --> Helper loaded: form_helper
INFO - 2023-12-22 01:38:26 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:38:26 --> Helper loaded: security_helper
INFO - 2023-12-22 01:38:26 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:38:26 --> Database Driver Class Initialized
INFO - 2023-12-22 01:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:38:26 --> Parser Class Initialized
INFO - 2023-12-22 01:38:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:38:26 --> Pagination Class Initialized
INFO - 2023-12-22 01:38:26 --> Form Validation Class Initialized
INFO - 2023-12-22 01:38:26 --> Controller Class Initialized
INFO - 2023-12-22 01:38:26 --> Model Class Initialized
DEBUG - 2023-12-22 01:38:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 01:38:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:38:26 --> Model Class Initialized
INFO - 2023-12-22 01:38:27 --> Final output sent to browser
DEBUG - 2023-12-22 01:38:27 --> Total execution time: 0.0485
ERROR - 2023-12-22 01:38:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:38:31 --> Config Class Initialized
INFO - 2023-12-22 01:38:31 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:38:31 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:38:31 --> Utf8 Class Initialized
INFO - 2023-12-22 01:38:31 --> URI Class Initialized
INFO - 2023-12-22 01:38:31 --> Router Class Initialized
INFO - 2023-12-22 01:38:31 --> Output Class Initialized
INFO - 2023-12-22 01:38:31 --> Security Class Initialized
DEBUG - 2023-12-22 01:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:38:31 --> Input Class Initialized
INFO - 2023-12-22 01:38:31 --> Language Class Initialized
INFO - 2023-12-22 01:38:31 --> Loader Class Initialized
INFO - 2023-12-22 01:38:31 --> Helper loaded: url_helper
INFO - 2023-12-22 01:38:31 --> Helper loaded: file_helper
INFO - 2023-12-22 01:38:31 --> Helper loaded: html_helper
INFO - 2023-12-22 01:38:31 --> Helper loaded: text_helper
INFO - 2023-12-22 01:38:31 --> Helper loaded: form_helper
INFO - 2023-12-22 01:38:31 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:38:31 --> Helper loaded: security_helper
INFO - 2023-12-22 01:38:31 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:38:31 --> Database Driver Class Initialized
INFO - 2023-12-22 01:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:38:31 --> Parser Class Initialized
INFO - 2023-12-22 01:38:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:38:31 --> Pagination Class Initialized
INFO - 2023-12-22 01:38:31 --> Form Validation Class Initialized
INFO - 2023-12-22 01:38:31 --> Controller Class Initialized
INFO - 2023-12-22 01:38:31 --> Model Class Initialized
DEBUG - 2023-12-22 01:38:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 01:38:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:38:31 --> Model Class Initialized
INFO - 2023-12-22 01:38:31 --> Final output sent to browser
DEBUG - 2023-12-22 01:38:31 --> Total execution time: 0.0438
ERROR - 2023-12-22 01:39:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 01:39:24 --> Config Class Initialized
INFO - 2023-12-22 01:39:24 --> Hooks Class Initialized
DEBUG - 2023-12-22 01:39:24 --> UTF-8 Support Enabled
INFO - 2023-12-22 01:39:24 --> Utf8 Class Initialized
INFO - 2023-12-22 01:39:24 --> URI Class Initialized
INFO - 2023-12-22 01:39:24 --> Router Class Initialized
INFO - 2023-12-22 01:39:24 --> Output Class Initialized
INFO - 2023-12-22 01:39:24 --> Security Class Initialized
DEBUG - 2023-12-22 01:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 01:39:24 --> Input Class Initialized
INFO - 2023-12-22 01:39:24 --> Language Class Initialized
INFO - 2023-12-22 01:39:24 --> Loader Class Initialized
INFO - 2023-12-22 01:39:24 --> Helper loaded: url_helper
INFO - 2023-12-22 01:39:24 --> Helper loaded: file_helper
INFO - 2023-12-22 01:39:24 --> Helper loaded: html_helper
INFO - 2023-12-22 01:39:24 --> Helper loaded: text_helper
INFO - 2023-12-22 01:39:24 --> Helper loaded: form_helper
INFO - 2023-12-22 01:39:24 --> Helper loaded: lang_helper
INFO - 2023-12-22 01:39:24 --> Helper loaded: security_helper
INFO - 2023-12-22 01:39:24 --> Helper loaded: cookie_helper
INFO - 2023-12-22 01:39:24 --> Database Driver Class Initialized
INFO - 2023-12-22 01:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 01:39:24 --> Parser Class Initialized
INFO - 2023-12-22 01:39:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 01:39:24 --> Pagination Class Initialized
INFO - 2023-12-22 01:39:24 --> Form Validation Class Initialized
INFO - 2023-12-22 01:39:24 --> Controller Class Initialized
INFO - 2023-12-22 01:39:24 --> Model Class Initialized
DEBUG - 2023-12-22 01:39:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:39:24 --> Model Class Initialized
DEBUG - 2023-12-22 01:39:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:39:24 --> Model Class Initialized
INFO - 2023-12-22 01:39:24 --> Model Class Initialized
INFO - 2023-12-22 01:39:24 --> Model Class Initialized
INFO - 2023-12-22 01:39:24 --> Model Class Initialized
DEBUG - 2023-12-22 01:39:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 01:39:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:39:24 --> Model Class Initialized
INFO - 2023-12-22 01:39:24 --> Model Class Initialized
INFO - 2023-12-22 01:39:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-22 01:39:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 01:39:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 01:39:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 01:39:24 --> Model Class Initialized
INFO - 2023-12-22 01:39:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 01:39:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 01:39:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 01:39:24 --> Final output sent to browser
DEBUG - 2023-12-22 01:39:24 --> Total execution time: 0.2233
ERROR - 2023-12-22 04:20:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 04:20:34 --> Config Class Initialized
INFO - 2023-12-22 04:20:34 --> Hooks Class Initialized
DEBUG - 2023-12-22 04:20:34 --> UTF-8 Support Enabled
INFO - 2023-12-22 04:20:34 --> Utf8 Class Initialized
INFO - 2023-12-22 04:20:34 --> URI Class Initialized
INFO - 2023-12-22 04:20:34 --> Router Class Initialized
INFO - 2023-12-22 04:20:34 --> Output Class Initialized
INFO - 2023-12-22 04:20:34 --> Security Class Initialized
DEBUG - 2023-12-22 04:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 04:20:34 --> Input Class Initialized
INFO - 2023-12-22 04:20:34 --> Language Class Initialized
ERROR - 2023-12-22 04:20:34 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-12-22 05:12:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 05:12:03 --> Config Class Initialized
INFO - 2023-12-22 05:12:03 --> Hooks Class Initialized
DEBUG - 2023-12-22 05:12:03 --> UTF-8 Support Enabled
INFO - 2023-12-22 05:12:03 --> Utf8 Class Initialized
INFO - 2023-12-22 05:12:03 --> URI Class Initialized
DEBUG - 2023-12-22 05:12:03 --> No URI present. Default controller set.
INFO - 2023-12-22 05:12:03 --> Router Class Initialized
INFO - 2023-12-22 05:12:03 --> Output Class Initialized
INFO - 2023-12-22 05:12:03 --> Security Class Initialized
DEBUG - 2023-12-22 05:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 05:12:03 --> Input Class Initialized
INFO - 2023-12-22 05:12:03 --> Language Class Initialized
INFO - 2023-12-22 05:12:03 --> Loader Class Initialized
INFO - 2023-12-22 05:12:03 --> Helper loaded: url_helper
INFO - 2023-12-22 05:12:03 --> Helper loaded: file_helper
INFO - 2023-12-22 05:12:03 --> Helper loaded: html_helper
INFO - 2023-12-22 05:12:03 --> Helper loaded: text_helper
INFO - 2023-12-22 05:12:03 --> Helper loaded: form_helper
INFO - 2023-12-22 05:12:03 --> Helper loaded: lang_helper
INFO - 2023-12-22 05:12:03 --> Helper loaded: security_helper
INFO - 2023-12-22 05:12:03 --> Helper loaded: cookie_helper
INFO - 2023-12-22 05:12:03 --> Database Driver Class Initialized
INFO - 2023-12-22 05:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 05:12:03 --> Parser Class Initialized
INFO - 2023-12-22 05:12:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 05:12:03 --> Pagination Class Initialized
INFO - 2023-12-22 05:12:03 --> Form Validation Class Initialized
INFO - 2023-12-22 05:12:03 --> Controller Class Initialized
INFO - 2023-12-22 05:12:03 --> Model Class Initialized
DEBUG - 2023-12-22 05:12:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-22 05:12:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 05:12:03 --> Config Class Initialized
INFO - 2023-12-22 05:12:03 --> Hooks Class Initialized
DEBUG - 2023-12-22 05:12:03 --> UTF-8 Support Enabled
INFO - 2023-12-22 05:12:03 --> Utf8 Class Initialized
INFO - 2023-12-22 05:12:03 --> URI Class Initialized
INFO - 2023-12-22 05:12:03 --> Router Class Initialized
INFO - 2023-12-22 05:12:03 --> Output Class Initialized
INFO - 2023-12-22 05:12:03 --> Security Class Initialized
DEBUG - 2023-12-22 05:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 05:12:03 --> Input Class Initialized
INFO - 2023-12-22 05:12:03 --> Language Class Initialized
INFO - 2023-12-22 05:12:03 --> Loader Class Initialized
INFO - 2023-12-22 05:12:03 --> Helper loaded: url_helper
INFO - 2023-12-22 05:12:03 --> Helper loaded: file_helper
INFO - 2023-12-22 05:12:03 --> Helper loaded: html_helper
INFO - 2023-12-22 05:12:03 --> Helper loaded: text_helper
INFO - 2023-12-22 05:12:03 --> Helper loaded: form_helper
INFO - 2023-12-22 05:12:03 --> Helper loaded: lang_helper
INFO - 2023-12-22 05:12:03 --> Helper loaded: security_helper
INFO - 2023-12-22 05:12:03 --> Helper loaded: cookie_helper
INFO - 2023-12-22 05:12:03 --> Database Driver Class Initialized
INFO - 2023-12-22 05:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 05:12:03 --> Parser Class Initialized
INFO - 2023-12-22 05:12:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 05:12:03 --> Pagination Class Initialized
INFO - 2023-12-22 05:12:03 --> Form Validation Class Initialized
INFO - 2023-12-22 05:12:03 --> Controller Class Initialized
INFO - 2023-12-22 05:12:03 --> Model Class Initialized
DEBUG - 2023-12-22 05:12:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:12:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-22 05:12:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:12:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 05:12:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 05:12:03 --> Model Class Initialized
INFO - 2023-12-22 05:12:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 05:12:03 --> Final output sent to browser
DEBUG - 2023-12-22 05:12:03 --> Total execution time: 0.0336
ERROR - 2023-12-22 05:15:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 05:15:11 --> Config Class Initialized
INFO - 2023-12-22 05:15:11 --> Hooks Class Initialized
DEBUG - 2023-12-22 05:15:11 --> UTF-8 Support Enabled
INFO - 2023-12-22 05:15:11 --> Utf8 Class Initialized
INFO - 2023-12-22 05:15:11 --> URI Class Initialized
INFO - 2023-12-22 05:15:11 --> Router Class Initialized
INFO - 2023-12-22 05:15:11 --> Output Class Initialized
INFO - 2023-12-22 05:15:11 --> Security Class Initialized
DEBUG - 2023-12-22 05:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 05:15:11 --> Input Class Initialized
INFO - 2023-12-22 05:15:11 --> Language Class Initialized
INFO - 2023-12-22 05:15:11 --> Loader Class Initialized
INFO - 2023-12-22 05:15:11 --> Helper loaded: url_helper
INFO - 2023-12-22 05:15:11 --> Helper loaded: file_helper
INFO - 2023-12-22 05:15:11 --> Helper loaded: html_helper
INFO - 2023-12-22 05:15:11 --> Helper loaded: text_helper
INFO - 2023-12-22 05:15:11 --> Helper loaded: form_helper
INFO - 2023-12-22 05:15:11 --> Helper loaded: lang_helper
INFO - 2023-12-22 05:15:11 --> Helper loaded: security_helper
INFO - 2023-12-22 05:15:11 --> Helper loaded: cookie_helper
INFO - 2023-12-22 05:15:11 --> Database Driver Class Initialized
INFO - 2023-12-22 05:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 05:15:11 --> Parser Class Initialized
INFO - 2023-12-22 05:15:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 05:15:11 --> Pagination Class Initialized
INFO - 2023-12-22 05:15:11 --> Form Validation Class Initialized
INFO - 2023-12-22 05:15:11 --> Controller Class Initialized
INFO - 2023-12-22 05:15:11 --> Model Class Initialized
DEBUG - 2023-12-22 05:15:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:15:11 --> Model Class Initialized
INFO - 2023-12-22 05:15:11 --> Final output sent to browser
DEBUG - 2023-12-22 05:15:11 --> Total execution time: 0.0218
ERROR - 2023-12-22 05:15:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 05:15:11 --> Config Class Initialized
INFO - 2023-12-22 05:15:11 --> Hooks Class Initialized
DEBUG - 2023-12-22 05:15:11 --> UTF-8 Support Enabled
INFO - 2023-12-22 05:15:11 --> Utf8 Class Initialized
INFO - 2023-12-22 05:15:11 --> URI Class Initialized
DEBUG - 2023-12-22 05:15:11 --> No URI present. Default controller set.
INFO - 2023-12-22 05:15:11 --> Router Class Initialized
INFO - 2023-12-22 05:15:11 --> Output Class Initialized
INFO - 2023-12-22 05:15:11 --> Security Class Initialized
DEBUG - 2023-12-22 05:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 05:15:11 --> Input Class Initialized
INFO - 2023-12-22 05:15:11 --> Language Class Initialized
INFO - 2023-12-22 05:15:11 --> Loader Class Initialized
INFO - 2023-12-22 05:15:11 --> Helper loaded: url_helper
INFO - 2023-12-22 05:15:11 --> Helper loaded: file_helper
INFO - 2023-12-22 05:15:11 --> Helper loaded: html_helper
INFO - 2023-12-22 05:15:11 --> Helper loaded: text_helper
INFO - 2023-12-22 05:15:11 --> Helper loaded: form_helper
INFO - 2023-12-22 05:15:11 --> Helper loaded: lang_helper
INFO - 2023-12-22 05:15:11 --> Helper loaded: security_helper
INFO - 2023-12-22 05:15:11 --> Helper loaded: cookie_helper
INFO - 2023-12-22 05:15:11 --> Database Driver Class Initialized
INFO - 2023-12-22 05:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 05:15:11 --> Parser Class Initialized
INFO - 2023-12-22 05:15:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 05:15:11 --> Pagination Class Initialized
INFO - 2023-12-22 05:15:11 --> Form Validation Class Initialized
INFO - 2023-12-22 05:15:11 --> Controller Class Initialized
INFO - 2023-12-22 05:15:11 --> Model Class Initialized
DEBUG - 2023-12-22 05:15:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:15:11 --> Model Class Initialized
DEBUG - 2023-12-22 05:15:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:15:11 --> Model Class Initialized
INFO - 2023-12-22 05:15:11 --> Model Class Initialized
INFO - 2023-12-22 05:15:11 --> Model Class Initialized
INFO - 2023-12-22 05:15:11 --> Model Class Initialized
DEBUG - 2023-12-22 05:15:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 05:15:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:15:11 --> Model Class Initialized
INFO - 2023-12-22 05:15:11 --> Model Class Initialized
INFO - 2023-12-22 05:15:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-22 05:15:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:15:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 05:15:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 05:15:11 --> Model Class Initialized
INFO - 2023-12-22 05:15:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 05:15:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 05:15:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 05:15:11 --> Final output sent to browser
DEBUG - 2023-12-22 05:15:11 --> Total execution time: 0.2277
ERROR - 2023-12-22 05:15:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 05:15:29 --> Config Class Initialized
INFO - 2023-12-22 05:15:29 --> Hooks Class Initialized
DEBUG - 2023-12-22 05:15:29 --> UTF-8 Support Enabled
INFO - 2023-12-22 05:15:29 --> Utf8 Class Initialized
INFO - 2023-12-22 05:15:29 --> URI Class Initialized
INFO - 2023-12-22 05:15:29 --> Router Class Initialized
INFO - 2023-12-22 05:15:29 --> Output Class Initialized
INFO - 2023-12-22 05:15:29 --> Security Class Initialized
DEBUG - 2023-12-22 05:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 05:15:29 --> Input Class Initialized
INFO - 2023-12-22 05:15:29 --> Language Class Initialized
INFO - 2023-12-22 05:15:29 --> Loader Class Initialized
INFO - 2023-12-22 05:15:29 --> Helper loaded: url_helper
INFO - 2023-12-22 05:15:29 --> Helper loaded: file_helper
INFO - 2023-12-22 05:15:29 --> Helper loaded: html_helper
INFO - 2023-12-22 05:15:29 --> Helper loaded: text_helper
INFO - 2023-12-22 05:15:29 --> Helper loaded: form_helper
INFO - 2023-12-22 05:15:29 --> Helper loaded: lang_helper
INFO - 2023-12-22 05:15:29 --> Helper loaded: security_helper
INFO - 2023-12-22 05:15:29 --> Helper loaded: cookie_helper
INFO - 2023-12-22 05:15:29 --> Database Driver Class Initialized
INFO - 2023-12-22 05:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 05:15:29 --> Parser Class Initialized
INFO - 2023-12-22 05:15:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 05:15:29 --> Pagination Class Initialized
INFO - 2023-12-22 05:15:29 --> Form Validation Class Initialized
INFO - 2023-12-22 05:15:29 --> Controller Class Initialized
INFO - 2023-12-22 05:15:29 --> Model Class Initialized
DEBUG - 2023-12-22 05:15:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 05:15:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:15:29 --> Model Class Initialized
DEBUG - 2023-12-22 05:15:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:15:29 --> Model Class Initialized
INFO - 2023-12-22 05:15:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-22 05:15:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:15:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 05:15:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 05:15:29 --> Model Class Initialized
INFO - 2023-12-22 05:15:29 --> Model Class Initialized
INFO - 2023-12-22 05:15:29 --> Model Class Initialized
INFO - 2023-12-22 05:15:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 05:15:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 05:15:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 05:15:30 --> Final output sent to browser
DEBUG - 2023-12-22 05:15:30 --> Total execution time: 0.1515
ERROR - 2023-12-22 05:15:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 05:15:31 --> Config Class Initialized
INFO - 2023-12-22 05:15:31 --> Hooks Class Initialized
DEBUG - 2023-12-22 05:15:31 --> UTF-8 Support Enabled
INFO - 2023-12-22 05:15:31 --> Utf8 Class Initialized
INFO - 2023-12-22 05:15:31 --> URI Class Initialized
INFO - 2023-12-22 05:15:31 --> Router Class Initialized
INFO - 2023-12-22 05:15:31 --> Output Class Initialized
INFO - 2023-12-22 05:15:31 --> Security Class Initialized
DEBUG - 2023-12-22 05:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 05:15:31 --> Input Class Initialized
INFO - 2023-12-22 05:15:31 --> Language Class Initialized
INFO - 2023-12-22 05:15:31 --> Loader Class Initialized
INFO - 2023-12-22 05:15:31 --> Helper loaded: url_helper
INFO - 2023-12-22 05:15:31 --> Helper loaded: file_helper
INFO - 2023-12-22 05:15:31 --> Helper loaded: html_helper
INFO - 2023-12-22 05:15:31 --> Helper loaded: text_helper
INFO - 2023-12-22 05:15:31 --> Helper loaded: form_helper
INFO - 2023-12-22 05:15:31 --> Helper loaded: lang_helper
INFO - 2023-12-22 05:15:31 --> Helper loaded: security_helper
INFO - 2023-12-22 05:15:31 --> Helper loaded: cookie_helper
INFO - 2023-12-22 05:15:31 --> Database Driver Class Initialized
INFO - 2023-12-22 05:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 05:15:31 --> Parser Class Initialized
INFO - 2023-12-22 05:15:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 05:15:31 --> Pagination Class Initialized
INFO - 2023-12-22 05:15:31 --> Form Validation Class Initialized
INFO - 2023-12-22 05:15:31 --> Controller Class Initialized
INFO - 2023-12-22 05:15:31 --> Model Class Initialized
DEBUG - 2023-12-22 05:15:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 05:15:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:15:31 --> Model Class Initialized
DEBUG - 2023-12-22 05:15:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:15:31 --> Model Class Initialized
INFO - 2023-12-22 05:15:31 --> Final output sent to browser
DEBUG - 2023-12-22 05:15:31 --> Total execution time: 0.0417
ERROR - 2023-12-22 05:15:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 05:15:38 --> Config Class Initialized
INFO - 2023-12-22 05:15:38 --> Hooks Class Initialized
DEBUG - 2023-12-22 05:15:38 --> UTF-8 Support Enabled
INFO - 2023-12-22 05:15:38 --> Utf8 Class Initialized
INFO - 2023-12-22 05:15:38 --> URI Class Initialized
INFO - 2023-12-22 05:15:38 --> Router Class Initialized
INFO - 2023-12-22 05:15:38 --> Output Class Initialized
INFO - 2023-12-22 05:15:38 --> Security Class Initialized
DEBUG - 2023-12-22 05:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 05:15:38 --> Input Class Initialized
INFO - 2023-12-22 05:15:38 --> Language Class Initialized
INFO - 2023-12-22 05:15:38 --> Loader Class Initialized
INFO - 2023-12-22 05:15:38 --> Helper loaded: url_helper
INFO - 2023-12-22 05:15:38 --> Helper loaded: file_helper
INFO - 2023-12-22 05:15:38 --> Helper loaded: html_helper
INFO - 2023-12-22 05:15:38 --> Helper loaded: text_helper
INFO - 2023-12-22 05:15:38 --> Helper loaded: form_helper
INFO - 2023-12-22 05:15:38 --> Helper loaded: lang_helper
INFO - 2023-12-22 05:15:38 --> Helper loaded: security_helper
INFO - 2023-12-22 05:15:38 --> Helper loaded: cookie_helper
INFO - 2023-12-22 05:15:38 --> Database Driver Class Initialized
INFO - 2023-12-22 05:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 05:15:38 --> Parser Class Initialized
INFO - 2023-12-22 05:15:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 05:15:38 --> Pagination Class Initialized
INFO - 2023-12-22 05:15:38 --> Form Validation Class Initialized
INFO - 2023-12-22 05:15:38 --> Controller Class Initialized
INFO - 2023-12-22 05:15:38 --> Model Class Initialized
DEBUG - 2023-12-22 05:15:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 05:15:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:15:38 --> Model Class Initialized
DEBUG - 2023-12-22 05:15:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:15:38 --> Model Class Initialized
INFO - 2023-12-22 05:15:38 --> Final output sent to browser
DEBUG - 2023-12-22 05:15:38 --> Total execution time: 0.0812
ERROR - 2023-12-22 05:16:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 05:16:03 --> Config Class Initialized
INFO - 2023-12-22 05:16:03 --> Hooks Class Initialized
DEBUG - 2023-12-22 05:16:03 --> UTF-8 Support Enabled
INFO - 2023-12-22 05:16:03 --> Utf8 Class Initialized
INFO - 2023-12-22 05:16:03 --> URI Class Initialized
INFO - 2023-12-22 05:16:03 --> Router Class Initialized
INFO - 2023-12-22 05:16:03 --> Output Class Initialized
INFO - 2023-12-22 05:16:03 --> Security Class Initialized
DEBUG - 2023-12-22 05:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 05:16:03 --> Input Class Initialized
INFO - 2023-12-22 05:16:03 --> Language Class Initialized
INFO - 2023-12-22 05:16:03 --> Loader Class Initialized
INFO - 2023-12-22 05:16:03 --> Helper loaded: url_helper
INFO - 2023-12-22 05:16:03 --> Helper loaded: file_helper
INFO - 2023-12-22 05:16:03 --> Helper loaded: html_helper
INFO - 2023-12-22 05:16:03 --> Helper loaded: text_helper
INFO - 2023-12-22 05:16:03 --> Helper loaded: form_helper
INFO - 2023-12-22 05:16:03 --> Helper loaded: lang_helper
INFO - 2023-12-22 05:16:03 --> Helper loaded: security_helper
INFO - 2023-12-22 05:16:03 --> Helper loaded: cookie_helper
INFO - 2023-12-22 05:16:03 --> Database Driver Class Initialized
INFO - 2023-12-22 05:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 05:16:03 --> Parser Class Initialized
INFO - 2023-12-22 05:16:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 05:16:03 --> Pagination Class Initialized
INFO - 2023-12-22 05:16:03 --> Form Validation Class Initialized
INFO - 2023-12-22 05:16:03 --> Controller Class Initialized
INFO - 2023-12-22 05:16:03 --> Model Class Initialized
DEBUG - 2023-12-22 05:16:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 05:16:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:16:03 --> Model Class Initialized
DEBUG - 2023-12-22 05:16:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:16:03 --> Model Class Initialized
DEBUG - 2023-12-22 05:16:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:16:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-12-22 05:16:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:16:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 05:16:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 05:16:03 --> Model Class Initialized
INFO - 2023-12-22 05:16:03 --> Model Class Initialized
INFO - 2023-12-22 05:16:03 --> Model Class Initialized
INFO - 2023-12-22 05:16:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 05:16:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 05:16:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 05:16:03 --> Final output sent to browser
DEBUG - 2023-12-22 05:16:03 --> Total execution time: 0.1709
ERROR - 2023-12-22 05:17:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 05:17:03 --> Config Class Initialized
INFO - 2023-12-22 05:17:03 --> Hooks Class Initialized
DEBUG - 2023-12-22 05:17:03 --> UTF-8 Support Enabled
INFO - 2023-12-22 05:17:03 --> Utf8 Class Initialized
INFO - 2023-12-22 05:17:03 --> URI Class Initialized
INFO - 2023-12-22 05:17:03 --> Router Class Initialized
INFO - 2023-12-22 05:17:03 --> Output Class Initialized
INFO - 2023-12-22 05:17:03 --> Security Class Initialized
DEBUG - 2023-12-22 05:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 05:17:03 --> Input Class Initialized
INFO - 2023-12-22 05:17:03 --> Language Class Initialized
INFO - 2023-12-22 05:17:03 --> Loader Class Initialized
INFO - 2023-12-22 05:17:03 --> Helper loaded: url_helper
INFO - 2023-12-22 05:17:03 --> Helper loaded: file_helper
INFO - 2023-12-22 05:17:03 --> Helper loaded: html_helper
INFO - 2023-12-22 05:17:03 --> Helper loaded: text_helper
INFO - 2023-12-22 05:17:03 --> Helper loaded: form_helper
INFO - 2023-12-22 05:17:03 --> Helper loaded: lang_helper
INFO - 2023-12-22 05:17:03 --> Helper loaded: security_helper
INFO - 2023-12-22 05:17:03 --> Helper loaded: cookie_helper
INFO - 2023-12-22 05:17:03 --> Database Driver Class Initialized
INFO - 2023-12-22 05:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 05:17:03 --> Parser Class Initialized
INFO - 2023-12-22 05:17:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 05:17:03 --> Pagination Class Initialized
INFO - 2023-12-22 05:17:03 --> Form Validation Class Initialized
INFO - 2023-12-22 05:17:03 --> Controller Class Initialized
INFO - 2023-12-22 05:17:03 --> Model Class Initialized
DEBUG - 2023-12-22 05:17:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:17:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-22 05:17:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:17:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 05:17:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 05:17:03 --> Model Class Initialized
INFO - 2023-12-22 05:17:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 05:17:03 --> Final output sent to browser
DEBUG - 2023-12-22 05:17:03 --> Total execution time: 0.0362
ERROR - 2023-12-22 05:17:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 05:17:03 --> Config Class Initialized
INFO - 2023-12-22 05:17:03 --> Hooks Class Initialized
DEBUG - 2023-12-22 05:17:03 --> UTF-8 Support Enabled
INFO - 2023-12-22 05:17:03 --> Utf8 Class Initialized
INFO - 2023-12-22 05:17:03 --> URI Class Initialized
INFO - 2023-12-22 05:17:03 --> Router Class Initialized
INFO - 2023-12-22 05:17:03 --> Output Class Initialized
INFO - 2023-12-22 05:17:03 --> Security Class Initialized
DEBUG - 2023-12-22 05:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 05:17:03 --> Input Class Initialized
INFO - 2023-12-22 05:17:03 --> Language Class Initialized
INFO - 2023-12-22 05:17:03 --> Loader Class Initialized
INFO - 2023-12-22 05:17:03 --> Helper loaded: url_helper
INFO - 2023-12-22 05:17:03 --> Helper loaded: file_helper
INFO - 2023-12-22 05:17:03 --> Helper loaded: html_helper
INFO - 2023-12-22 05:17:03 --> Helper loaded: text_helper
INFO - 2023-12-22 05:17:03 --> Helper loaded: form_helper
INFO - 2023-12-22 05:17:03 --> Helper loaded: lang_helper
INFO - 2023-12-22 05:17:03 --> Helper loaded: security_helper
INFO - 2023-12-22 05:17:03 --> Helper loaded: cookie_helper
INFO - 2023-12-22 05:17:03 --> Database Driver Class Initialized
INFO - 2023-12-22 05:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 05:17:03 --> Parser Class Initialized
INFO - 2023-12-22 05:17:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 05:17:03 --> Pagination Class Initialized
INFO - 2023-12-22 05:17:03 --> Form Validation Class Initialized
INFO - 2023-12-22 05:17:03 --> Controller Class Initialized
INFO - 2023-12-22 05:17:03 --> Model Class Initialized
DEBUG - 2023-12-22 05:17:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:17:03 --> Model Class Initialized
DEBUG - 2023-12-22 05:17:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:17:03 --> Model Class Initialized
INFO - 2023-12-22 05:17:03 --> Model Class Initialized
INFO - 2023-12-22 05:17:03 --> Model Class Initialized
INFO - 2023-12-22 05:17:03 --> Model Class Initialized
DEBUG - 2023-12-22 05:17:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 05:17:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:17:03 --> Model Class Initialized
INFO - 2023-12-22 05:17:03 --> Model Class Initialized
INFO - 2023-12-22 05:17:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-22 05:17:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:17:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 05:17:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 05:17:03 --> Model Class Initialized
INFO - 2023-12-22 05:17:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 05:17:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 05:17:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 05:17:03 --> Final output sent to browser
DEBUG - 2023-12-22 05:17:03 --> Total execution time: 0.2176
ERROR - 2023-12-22 05:22:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 05:22:23 --> Config Class Initialized
INFO - 2023-12-22 05:22:23 --> Hooks Class Initialized
DEBUG - 2023-12-22 05:22:23 --> UTF-8 Support Enabled
INFO - 2023-12-22 05:22:23 --> Utf8 Class Initialized
INFO - 2023-12-22 05:22:23 --> URI Class Initialized
DEBUG - 2023-12-22 05:22:23 --> No URI present. Default controller set.
INFO - 2023-12-22 05:22:23 --> Router Class Initialized
INFO - 2023-12-22 05:22:23 --> Output Class Initialized
INFO - 2023-12-22 05:22:23 --> Security Class Initialized
DEBUG - 2023-12-22 05:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 05:22:23 --> Input Class Initialized
INFO - 2023-12-22 05:22:23 --> Language Class Initialized
INFO - 2023-12-22 05:22:23 --> Loader Class Initialized
INFO - 2023-12-22 05:22:23 --> Helper loaded: url_helper
INFO - 2023-12-22 05:22:23 --> Helper loaded: file_helper
INFO - 2023-12-22 05:22:23 --> Helper loaded: html_helper
INFO - 2023-12-22 05:22:23 --> Helper loaded: text_helper
INFO - 2023-12-22 05:22:23 --> Helper loaded: form_helper
INFO - 2023-12-22 05:22:23 --> Helper loaded: lang_helper
INFO - 2023-12-22 05:22:23 --> Helper loaded: security_helper
INFO - 2023-12-22 05:22:23 --> Helper loaded: cookie_helper
INFO - 2023-12-22 05:22:23 --> Database Driver Class Initialized
INFO - 2023-12-22 05:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 05:22:23 --> Parser Class Initialized
INFO - 2023-12-22 05:22:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 05:22:23 --> Pagination Class Initialized
INFO - 2023-12-22 05:22:23 --> Form Validation Class Initialized
INFO - 2023-12-22 05:22:23 --> Controller Class Initialized
INFO - 2023-12-22 05:22:23 --> Model Class Initialized
DEBUG - 2023-12-22 05:22:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-22 05:22:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 05:22:23 --> Config Class Initialized
INFO - 2023-12-22 05:22:23 --> Hooks Class Initialized
DEBUG - 2023-12-22 05:22:23 --> UTF-8 Support Enabled
INFO - 2023-12-22 05:22:23 --> Utf8 Class Initialized
INFO - 2023-12-22 05:22:23 --> URI Class Initialized
INFO - 2023-12-22 05:22:23 --> Router Class Initialized
INFO - 2023-12-22 05:22:23 --> Output Class Initialized
INFO - 2023-12-22 05:22:23 --> Security Class Initialized
DEBUG - 2023-12-22 05:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 05:22:23 --> Input Class Initialized
INFO - 2023-12-22 05:22:23 --> Language Class Initialized
INFO - 2023-12-22 05:22:23 --> Loader Class Initialized
INFO - 2023-12-22 05:22:23 --> Helper loaded: url_helper
INFO - 2023-12-22 05:22:23 --> Helper loaded: file_helper
INFO - 2023-12-22 05:22:23 --> Helper loaded: html_helper
INFO - 2023-12-22 05:22:23 --> Helper loaded: text_helper
INFO - 2023-12-22 05:22:23 --> Helper loaded: form_helper
INFO - 2023-12-22 05:22:23 --> Helper loaded: lang_helper
INFO - 2023-12-22 05:22:23 --> Helper loaded: security_helper
INFO - 2023-12-22 05:22:23 --> Helper loaded: cookie_helper
INFO - 2023-12-22 05:22:23 --> Database Driver Class Initialized
INFO - 2023-12-22 05:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 05:22:23 --> Parser Class Initialized
INFO - 2023-12-22 05:22:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 05:22:23 --> Pagination Class Initialized
INFO - 2023-12-22 05:22:23 --> Form Validation Class Initialized
INFO - 2023-12-22 05:22:23 --> Controller Class Initialized
INFO - 2023-12-22 05:22:23 --> Model Class Initialized
DEBUG - 2023-12-22 05:22:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:22:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-22 05:22:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:22:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 05:22:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 05:22:23 --> Model Class Initialized
INFO - 2023-12-22 05:22:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 05:22:23 --> Final output sent to browser
DEBUG - 2023-12-22 05:22:23 --> Total execution time: 0.0336
ERROR - 2023-12-22 05:22:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 05:22:40 --> Config Class Initialized
INFO - 2023-12-22 05:22:40 --> Hooks Class Initialized
DEBUG - 2023-12-22 05:22:40 --> UTF-8 Support Enabled
INFO - 2023-12-22 05:22:40 --> Utf8 Class Initialized
INFO - 2023-12-22 05:22:40 --> URI Class Initialized
INFO - 2023-12-22 05:22:40 --> Router Class Initialized
INFO - 2023-12-22 05:22:40 --> Output Class Initialized
INFO - 2023-12-22 05:22:40 --> Security Class Initialized
DEBUG - 2023-12-22 05:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 05:22:40 --> Input Class Initialized
INFO - 2023-12-22 05:22:40 --> Language Class Initialized
INFO - 2023-12-22 05:22:40 --> Loader Class Initialized
INFO - 2023-12-22 05:22:40 --> Helper loaded: url_helper
INFO - 2023-12-22 05:22:40 --> Helper loaded: file_helper
INFO - 2023-12-22 05:22:40 --> Helper loaded: html_helper
INFO - 2023-12-22 05:22:40 --> Helper loaded: text_helper
INFO - 2023-12-22 05:22:40 --> Helper loaded: form_helper
INFO - 2023-12-22 05:22:40 --> Helper loaded: lang_helper
INFO - 2023-12-22 05:22:40 --> Helper loaded: security_helper
INFO - 2023-12-22 05:22:40 --> Helper loaded: cookie_helper
INFO - 2023-12-22 05:22:40 --> Database Driver Class Initialized
INFO - 2023-12-22 05:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 05:22:40 --> Parser Class Initialized
INFO - 2023-12-22 05:22:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 05:22:40 --> Pagination Class Initialized
INFO - 2023-12-22 05:22:40 --> Form Validation Class Initialized
INFO - 2023-12-22 05:22:40 --> Controller Class Initialized
INFO - 2023-12-22 05:22:40 --> Model Class Initialized
DEBUG - 2023-12-22 05:22:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:22:40 --> Model Class Initialized
INFO - 2023-12-22 05:22:40 --> Final output sent to browser
DEBUG - 2023-12-22 05:22:40 --> Total execution time: 0.0189
ERROR - 2023-12-22 05:22:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 05:22:41 --> Config Class Initialized
INFO - 2023-12-22 05:22:41 --> Hooks Class Initialized
DEBUG - 2023-12-22 05:22:41 --> UTF-8 Support Enabled
INFO - 2023-12-22 05:22:41 --> Utf8 Class Initialized
INFO - 2023-12-22 05:22:41 --> URI Class Initialized
DEBUG - 2023-12-22 05:22:41 --> No URI present. Default controller set.
INFO - 2023-12-22 05:22:41 --> Router Class Initialized
INFO - 2023-12-22 05:22:41 --> Output Class Initialized
INFO - 2023-12-22 05:22:41 --> Security Class Initialized
DEBUG - 2023-12-22 05:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 05:22:41 --> Input Class Initialized
INFO - 2023-12-22 05:22:41 --> Language Class Initialized
INFO - 2023-12-22 05:22:41 --> Loader Class Initialized
INFO - 2023-12-22 05:22:41 --> Helper loaded: url_helper
INFO - 2023-12-22 05:22:41 --> Helper loaded: file_helper
INFO - 2023-12-22 05:22:41 --> Helper loaded: html_helper
INFO - 2023-12-22 05:22:41 --> Helper loaded: text_helper
INFO - 2023-12-22 05:22:41 --> Helper loaded: form_helper
INFO - 2023-12-22 05:22:41 --> Helper loaded: lang_helper
INFO - 2023-12-22 05:22:41 --> Helper loaded: security_helper
INFO - 2023-12-22 05:22:41 --> Helper loaded: cookie_helper
INFO - 2023-12-22 05:22:41 --> Database Driver Class Initialized
INFO - 2023-12-22 05:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 05:22:41 --> Parser Class Initialized
INFO - 2023-12-22 05:22:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 05:22:41 --> Pagination Class Initialized
INFO - 2023-12-22 05:22:41 --> Form Validation Class Initialized
INFO - 2023-12-22 05:22:41 --> Controller Class Initialized
INFO - 2023-12-22 05:22:41 --> Model Class Initialized
DEBUG - 2023-12-22 05:22:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:22:41 --> Model Class Initialized
DEBUG - 2023-12-22 05:22:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:22:41 --> Model Class Initialized
INFO - 2023-12-22 05:22:41 --> Model Class Initialized
INFO - 2023-12-22 05:22:41 --> Model Class Initialized
INFO - 2023-12-22 05:22:41 --> Model Class Initialized
DEBUG - 2023-12-22 05:22:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 05:22:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:22:41 --> Model Class Initialized
INFO - 2023-12-22 05:22:41 --> Model Class Initialized
INFO - 2023-12-22 05:22:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-22 05:22:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:22:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 05:22:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 05:22:41 --> Model Class Initialized
INFO - 2023-12-22 05:22:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 05:22:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 05:22:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 05:22:41 --> Final output sent to browser
DEBUG - 2023-12-22 05:22:41 --> Total execution time: 0.2031
ERROR - 2023-12-22 05:23:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 05:23:16 --> Config Class Initialized
INFO - 2023-12-22 05:23:16 --> Hooks Class Initialized
DEBUG - 2023-12-22 05:23:16 --> UTF-8 Support Enabled
INFO - 2023-12-22 05:23:16 --> Utf8 Class Initialized
INFO - 2023-12-22 05:23:16 --> URI Class Initialized
INFO - 2023-12-22 05:23:16 --> Router Class Initialized
INFO - 2023-12-22 05:23:16 --> Output Class Initialized
INFO - 2023-12-22 05:23:16 --> Security Class Initialized
DEBUG - 2023-12-22 05:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 05:23:16 --> Input Class Initialized
INFO - 2023-12-22 05:23:16 --> Language Class Initialized
INFO - 2023-12-22 05:23:16 --> Loader Class Initialized
INFO - 2023-12-22 05:23:16 --> Helper loaded: url_helper
INFO - 2023-12-22 05:23:16 --> Helper loaded: file_helper
INFO - 2023-12-22 05:23:16 --> Helper loaded: html_helper
INFO - 2023-12-22 05:23:16 --> Helper loaded: text_helper
INFO - 2023-12-22 05:23:16 --> Helper loaded: form_helper
INFO - 2023-12-22 05:23:16 --> Helper loaded: lang_helper
INFO - 2023-12-22 05:23:16 --> Helper loaded: security_helper
INFO - 2023-12-22 05:23:16 --> Helper loaded: cookie_helper
INFO - 2023-12-22 05:23:16 --> Database Driver Class Initialized
INFO - 2023-12-22 05:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 05:23:16 --> Parser Class Initialized
INFO - 2023-12-22 05:23:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 05:23:16 --> Pagination Class Initialized
INFO - 2023-12-22 05:23:16 --> Form Validation Class Initialized
INFO - 2023-12-22 05:23:16 --> Controller Class Initialized
INFO - 2023-12-22 05:23:16 --> Model Class Initialized
DEBUG - 2023-12-22 05:23:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 05:23:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:23:16 --> Model Class Initialized
DEBUG - 2023-12-22 05:23:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:23:16 --> Model Class Initialized
INFO - 2023-12-22 05:23:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-22 05:23:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:23:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 05:23:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 05:23:16 --> Model Class Initialized
INFO - 2023-12-22 05:23:16 --> Model Class Initialized
INFO - 2023-12-22 05:23:16 --> Model Class Initialized
INFO - 2023-12-22 05:23:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 05:23:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 05:23:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 05:23:16 --> Final output sent to browser
DEBUG - 2023-12-22 05:23:16 --> Total execution time: 0.1355
ERROR - 2023-12-22 05:23:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 05:23:17 --> Config Class Initialized
INFO - 2023-12-22 05:23:17 --> Hooks Class Initialized
DEBUG - 2023-12-22 05:23:17 --> UTF-8 Support Enabled
INFO - 2023-12-22 05:23:17 --> Utf8 Class Initialized
INFO - 2023-12-22 05:23:17 --> URI Class Initialized
INFO - 2023-12-22 05:23:17 --> Router Class Initialized
INFO - 2023-12-22 05:23:17 --> Output Class Initialized
INFO - 2023-12-22 05:23:17 --> Security Class Initialized
DEBUG - 2023-12-22 05:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 05:23:17 --> Input Class Initialized
INFO - 2023-12-22 05:23:17 --> Language Class Initialized
INFO - 2023-12-22 05:23:17 --> Loader Class Initialized
INFO - 2023-12-22 05:23:17 --> Helper loaded: url_helper
INFO - 2023-12-22 05:23:17 --> Helper loaded: file_helper
INFO - 2023-12-22 05:23:17 --> Helper loaded: html_helper
INFO - 2023-12-22 05:23:17 --> Helper loaded: text_helper
INFO - 2023-12-22 05:23:17 --> Helper loaded: form_helper
INFO - 2023-12-22 05:23:17 --> Helper loaded: lang_helper
INFO - 2023-12-22 05:23:17 --> Helper loaded: security_helper
INFO - 2023-12-22 05:23:17 --> Helper loaded: cookie_helper
INFO - 2023-12-22 05:23:17 --> Database Driver Class Initialized
INFO - 2023-12-22 05:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 05:23:17 --> Parser Class Initialized
INFO - 2023-12-22 05:23:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 05:23:17 --> Pagination Class Initialized
INFO - 2023-12-22 05:23:17 --> Form Validation Class Initialized
INFO - 2023-12-22 05:23:17 --> Controller Class Initialized
INFO - 2023-12-22 05:23:17 --> Model Class Initialized
DEBUG - 2023-12-22 05:23:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 05:23:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:23:17 --> Model Class Initialized
DEBUG - 2023-12-22 05:23:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:23:17 --> Model Class Initialized
INFO - 2023-12-22 05:23:17 --> Final output sent to browser
DEBUG - 2023-12-22 05:23:17 --> Total execution time: 0.0272
ERROR - 2023-12-22 05:23:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 05:23:30 --> Config Class Initialized
INFO - 2023-12-22 05:23:30 --> Hooks Class Initialized
DEBUG - 2023-12-22 05:23:30 --> UTF-8 Support Enabled
INFO - 2023-12-22 05:23:30 --> Utf8 Class Initialized
INFO - 2023-12-22 05:23:30 --> URI Class Initialized
DEBUG - 2023-12-22 05:23:30 --> No URI present. Default controller set.
INFO - 2023-12-22 05:23:30 --> Router Class Initialized
INFO - 2023-12-22 05:23:30 --> Output Class Initialized
INFO - 2023-12-22 05:23:30 --> Security Class Initialized
DEBUG - 2023-12-22 05:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 05:23:30 --> Input Class Initialized
INFO - 2023-12-22 05:23:30 --> Language Class Initialized
INFO - 2023-12-22 05:23:30 --> Loader Class Initialized
INFO - 2023-12-22 05:23:30 --> Helper loaded: url_helper
INFO - 2023-12-22 05:23:30 --> Helper loaded: file_helper
INFO - 2023-12-22 05:23:30 --> Helper loaded: html_helper
INFO - 2023-12-22 05:23:30 --> Helper loaded: text_helper
INFO - 2023-12-22 05:23:30 --> Helper loaded: form_helper
INFO - 2023-12-22 05:23:30 --> Helper loaded: lang_helper
INFO - 2023-12-22 05:23:30 --> Helper loaded: security_helper
INFO - 2023-12-22 05:23:30 --> Helper loaded: cookie_helper
INFO - 2023-12-22 05:23:30 --> Database Driver Class Initialized
INFO - 2023-12-22 05:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 05:23:30 --> Parser Class Initialized
INFO - 2023-12-22 05:23:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 05:23:30 --> Pagination Class Initialized
INFO - 2023-12-22 05:23:30 --> Form Validation Class Initialized
INFO - 2023-12-22 05:23:30 --> Controller Class Initialized
INFO - 2023-12-22 05:23:30 --> Model Class Initialized
DEBUG - 2023-12-22 05:23:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:23:30 --> Model Class Initialized
DEBUG - 2023-12-22 05:23:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:23:30 --> Model Class Initialized
INFO - 2023-12-22 05:23:30 --> Model Class Initialized
INFO - 2023-12-22 05:23:30 --> Model Class Initialized
INFO - 2023-12-22 05:23:30 --> Model Class Initialized
DEBUG - 2023-12-22 05:23:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 05:23:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:23:30 --> Model Class Initialized
INFO - 2023-12-22 05:23:30 --> Model Class Initialized
INFO - 2023-12-22 05:23:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-22 05:23:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:23:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 05:23:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 05:23:30 --> Model Class Initialized
INFO - 2023-12-22 05:23:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 05:23:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 05:23:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 05:23:30 --> Final output sent to browser
DEBUG - 2023-12-22 05:23:30 --> Total execution time: 0.2166
ERROR - 2023-12-22 05:23:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 05:23:59 --> Config Class Initialized
INFO - 2023-12-22 05:23:59 --> Hooks Class Initialized
DEBUG - 2023-12-22 05:23:59 --> UTF-8 Support Enabled
INFO - 2023-12-22 05:23:59 --> Utf8 Class Initialized
INFO - 2023-12-22 05:23:59 --> URI Class Initialized
INFO - 2023-12-22 05:23:59 --> Router Class Initialized
INFO - 2023-12-22 05:23:59 --> Output Class Initialized
INFO - 2023-12-22 05:23:59 --> Security Class Initialized
DEBUG - 2023-12-22 05:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 05:23:59 --> Input Class Initialized
INFO - 2023-12-22 05:23:59 --> Language Class Initialized
INFO - 2023-12-22 05:23:59 --> Loader Class Initialized
INFO - 2023-12-22 05:23:59 --> Helper loaded: url_helper
INFO - 2023-12-22 05:23:59 --> Helper loaded: file_helper
INFO - 2023-12-22 05:23:59 --> Helper loaded: html_helper
INFO - 2023-12-22 05:23:59 --> Helper loaded: text_helper
INFO - 2023-12-22 05:23:59 --> Helper loaded: form_helper
INFO - 2023-12-22 05:23:59 --> Helper loaded: lang_helper
INFO - 2023-12-22 05:23:59 --> Helper loaded: security_helper
INFO - 2023-12-22 05:23:59 --> Helper loaded: cookie_helper
INFO - 2023-12-22 05:23:59 --> Database Driver Class Initialized
INFO - 2023-12-22 05:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 05:23:59 --> Parser Class Initialized
INFO - 2023-12-22 05:23:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 05:23:59 --> Pagination Class Initialized
INFO - 2023-12-22 05:23:59 --> Form Validation Class Initialized
INFO - 2023-12-22 05:23:59 --> Controller Class Initialized
INFO - 2023-12-22 05:23:59 --> Model Class Initialized
DEBUG - 2023-12-22 05:23:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 05:23:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:23:59 --> Model Class Initialized
DEBUG - 2023-12-22 05:23:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:23:59 --> Model Class Initialized
INFO - 2023-12-22 05:23:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-22 05:23:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:23:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 05:23:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 05:23:59 --> Model Class Initialized
INFO - 2023-12-22 05:23:59 --> Model Class Initialized
INFO - 2023-12-22 05:23:59 --> Model Class Initialized
INFO - 2023-12-22 05:23:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 05:23:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 05:23:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 05:23:59 --> Final output sent to browser
DEBUG - 2023-12-22 05:23:59 --> Total execution time: 0.1469
ERROR - 2023-12-22 05:24:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 05:24:00 --> Config Class Initialized
INFO - 2023-12-22 05:24:00 --> Hooks Class Initialized
DEBUG - 2023-12-22 05:24:00 --> UTF-8 Support Enabled
INFO - 2023-12-22 05:24:00 --> Utf8 Class Initialized
INFO - 2023-12-22 05:24:00 --> URI Class Initialized
INFO - 2023-12-22 05:24:00 --> Router Class Initialized
INFO - 2023-12-22 05:24:00 --> Output Class Initialized
INFO - 2023-12-22 05:24:00 --> Security Class Initialized
DEBUG - 2023-12-22 05:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 05:24:00 --> Input Class Initialized
INFO - 2023-12-22 05:24:00 --> Language Class Initialized
INFO - 2023-12-22 05:24:00 --> Loader Class Initialized
INFO - 2023-12-22 05:24:00 --> Helper loaded: url_helper
INFO - 2023-12-22 05:24:00 --> Helper loaded: file_helper
INFO - 2023-12-22 05:24:00 --> Helper loaded: html_helper
INFO - 2023-12-22 05:24:00 --> Helper loaded: text_helper
INFO - 2023-12-22 05:24:00 --> Helper loaded: form_helper
INFO - 2023-12-22 05:24:00 --> Helper loaded: lang_helper
INFO - 2023-12-22 05:24:00 --> Helper loaded: security_helper
INFO - 2023-12-22 05:24:00 --> Helper loaded: cookie_helper
INFO - 2023-12-22 05:24:00 --> Database Driver Class Initialized
INFO - 2023-12-22 05:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 05:24:00 --> Parser Class Initialized
INFO - 2023-12-22 05:24:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 05:24:00 --> Pagination Class Initialized
INFO - 2023-12-22 05:24:00 --> Form Validation Class Initialized
INFO - 2023-12-22 05:24:00 --> Controller Class Initialized
INFO - 2023-12-22 05:24:00 --> Model Class Initialized
DEBUG - 2023-12-22 05:24:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 05:24:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:24:00 --> Model Class Initialized
DEBUG - 2023-12-22 05:24:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:24:00 --> Model Class Initialized
INFO - 2023-12-22 05:24:00 --> Final output sent to browser
DEBUG - 2023-12-22 05:24:00 --> Total execution time: 0.0233
ERROR - 2023-12-22 05:24:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 05:24:07 --> Config Class Initialized
INFO - 2023-12-22 05:24:07 --> Hooks Class Initialized
DEBUG - 2023-12-22 05:24:07 --> UTF-8 Support Enabled
INFO - 2023-12-22 05:24:07 --> Utf8 Class Initialized
INFO - 2023-12-22 05:24:07 --> URI Class Initialized
DEBUG - 2023-12-22 05:24:07 --> No URI present. Default controller set.
INFO - 2023-12-22 05:24:07 --> Router Class Initialized
INFO - 2023-12-22 05:24:07 --> Output Class Initialized
INFO - 2023-12-22 05:24:07 --> Security Class Initialized
DEBUG - 2023-12-22 05:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 05:24:07 --> Input Class Initialized
INFO - 2023-12-22 05:24:07 --> Language Class Initialized
INFO - 2023-12-22 05:24:07 --> Loader Class Initialized
INFO - 2023-12-22 05:24:07 --> Helper loaded: url_helper
INFO - 2023-12-22 05:24:07 --> Helper loaded: file_helper
INFO - 2023-12-22 05:24:07 --> Helper loaded: html_helper
INFO - 2023-12-22 05:24:07 --> Helper loaded: text_helper
INFO - 2023-12-22 05:24:07 --> Helper loaded: form_helper
INFO - 2023-12-22 05:24:07 --> Helper loaded: lang_helper
INFO - 2023-12-22 05:24:07 --> Helper loaded: security_helper
INFO - 2023-12-22 05:24:07 --> Helper loaded: cookie_helper
INFO - 2023-12-22 05:24:07 --> Database Driver Class Initialized
INFO - 2023-12-22 05:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 05:24:07 --> Parser Class Initialized
INFO - 2023-12-22 05:24:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 05:24:07 --> Pagination Class Initialized
INFO - 2023-12-22 05:24:07 --> Form Validation Class Initialized
INFO - 2023-12-22 05:24:07 --> Controller Class Initialized
INFO - 2023-12-22 05:24:07 --> Model Class Initialized
DEBUG - 2023-12-22 05:24:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:24:07 --> Model Class Initialized
DEBUG - 2023-12-22 05:24:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:24:07 --> Model Class Initialized
INFO - 2023-12-22 05:24:07 --> Model Class Initialized
INFO - 2023-12-22 05:24:07 --> Model Class Initialized
INFO - 2023-12-22 05:24:07 --> Model Class Initialized
DEBUG - 2023-12-22 05:24:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 05:24:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:24:07 --> Model Class Initialized
INFO - 2023-12-22 05:24:07 --> Model Class Initialized
INFO - 2023-12-22 05:24:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-22 05:24:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:24:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 05:24:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 05:24:07 --> Model Class Initialized
INFO - 2023-12-22 05:24:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 05:24:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 05:24:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 05:24:07 --> Final output sent to browser
DEBUG - 2023-12-22 05:24:07 --> Total execution time: 0.2039
ERROR - 2023-12-22 05:24:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 05:24:19 --> Config Class Initialized
INFO - 2023-12-22 05:24:19 --> Hooks Class Initialized
DEBUG - 2023-12-22 05:24:19 --> UTF-8 Support Enabled
INFO - 2023-12-22 05:24:19 --> Utf8 Class Initialized
INFO - 2023-12-22 05:24:19 --> URI Class Initialized
INFO - 2023-12-22 05:24:19 --> Router Class Initialized
INFO - 2023-12-22 05:24:19 --> Output Class Initialized
INFO - 2023-12-22 05:24:19 --> Security Class Initialized
DEBUG - 2023-12-22 05:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 05:24:19 --> Input Class Initialized
INFO - 2023-12-22 05:24:19 --> Language Class Initialized
INFO - 2023-12-22 05:24:19 --> Loader Class Initialized
INFO - 2023-12-22 05:24:19 --> Helper loaded: url_helper
INFO - 2023-12-22 05:24:19 --> Helper loaded: file_helper
INFO - 2023-12-22 05:24:19 --> Helper loaded: html_helper
INFO - 2023-12-22 05:24:19 --> Helper loaded: text_helper
INFO - 2023-12-22 05:24:19 --> Helper loaded: form_helper
INFO - 2023-12-22 05:24:19 --> Helper loaded: lang_helper
INFO - 2023-12-22 05:24:19 --> Helper loaded: security_helper
INFO - 2023-12-22 05:24:19 --> Helper loaded: cookie_helper
INFO - 2023-12-22 05:24:19 --> Database Driver Class Initialized
INFO - 2023-12-22 05:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 05:24:19 --> Parser Class Initialized
INFO - 2023-12-22 05:24:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 05:24:19 --> Pagination Class Initialized
INFO - 2023-12-22 05:24:19 --> Form Validation Class Initialized
INFO - 2023-12-22 05:24:19 --> Controller Class Initialized
INFO - 2023-12-22 05:24:19 --> Model Class Initialized
DEBUG - 2023-12-22 05:24:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:24:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-22 05:24:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:24:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 05:24:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 05:24:19 --> Model Class Initialized
INFO - 2023-12-22 05:24:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 05:24:19 --> Final output sent to browser
DEBUG - 2023-12-22 05:24:19 --> Total execution time: 0.0335
ERROR - 2023-12-22 05:24:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 05:24:19 --> Config Class Initialized
INFO - 2023-12-22 05:24:19 --> Hooks Class Initialized
DEBUG - 2023-12-22 05:24:19 --> UTF-8 Support Enabled
INFO - 2023-12-22 05:24:19 --> Utf8 Class Initialized
INFO - 2023-12-22 05:24:19 --> URI Class Initialized
INFO - 2023-12-22 05:24:19 --> Router Class Initialized
INFO - 2023-12-22 05:24:19 --> Output Class Initialized
INFO - 2023-12-22 05:24:19 --> Security Class Initialized
DEBUG - 2023-12-22 05:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 05:24:19 --> Input Class Initialized
INFO - 2023-12-22 05:24:19 --> Language Class Initialized
INFO - 2023-12-22 05:24:19 --> Loader Class Initialized
INFO - 2023-12-22 05:24:19 --> Helper loaded: url_helper
INFO - 2023-12-22 05:24:19 --> Helper loaded: file_helper
INFO - 2023-12-22 05:24:19 --> Helper loaded: html_helper
INFO - 2023-12-22 05:24:19 --> Helper loaded: text_helper
INFO - 2023-12-22 05:24:19 --> Helper loaded: form_helper
INFO - 2023-12-22 05:24:19 --> Helper loaded: lang_helper
INFO - 2023-12-22 05:24:19 --> Helper loaded: security_helper
INFO - 2023-12-22 05:24:19 --> Helper loaded: cookie_helper
INFO - 2023-12-22 05:24:19 --> Database Driver Class Initialized
INFO - 2023-12-22 05:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 05:24:19 --> Parser Class Initialized
INFO - 2023-12-22 05:24:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 05:24:19 --> Pagination Class Initialized
INFO - 2023-12-22 05:24:19 --> Form Validation Class Initialized
INFO - 2023-12-22 05:24:19 --> Controller Class Initialized
INFO - 2023-12-22 05:24:19 --> Model Class Initialized
DEBUG - 2023-12-22 05:24:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:24:19 --> Model Class Initialized
DEBUG - 2023-12-22 05:24:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:24:19 --> Model Class Initialized
INFO - 2023-12-22 05:24:19 --> Model Class Initialized
INFO - 2023-12-22 05:24:19 --> Model Class Initialized
INFO - 2023-12-22 05:24:19 --> Model Class Initialized
DEBUG - 2023-12-22 05:24:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 05:24:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:24:19 --> Model Class Initialized
INFO - 2023-12-22 05:24:19 --> Model Class Initialized
INFO - 2023-12-22 05:24:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-22 05:24:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 05:24:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 05:24:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 05:24:19 --> Model Class Initialized
INFO - 2023-12-22 05:24:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 05:24:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 05:24:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 05:24:20 --> Final output sent to browser
DEBUG - 2023-12-22 05:24:20 --> Total execution time: 0.2028
ERROR - 2023-12-22 06:09:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 06:09:20 --> Config Class Initialized
INFO - 2023-12-22 06:09:20 --> Hooks Class Initialized
DEBUG - 2023-12-22 06:09:20 --> UTF-8 Support Enabled
INFO - 2023-12-22 06:09:20 --> Utf8 Class Initialized
INFO - 2023-12-22 06:09:20 --> URI Class Initialized
DEBUG - 2023-12-22 06:09:20 --> No URI present. Default controller set.
INFO - 2023-12-22 06:09:20 --> Router Class Initialized
INFO - 2023-12-22 06:09:20 --> Output Class Initialized
INFO - 2023-12-22 06:09:20 --> Security Class Initialized
DEBUG - 2023-12-22 06:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 06:09:20 --> Input Class Initialized
INFO - 2023-12-22 06:09:20 --> Language Class Initialized
INFO - 2023-12-22 06:09:20 --> Loader Class Initialized
INFO - 2023-12-22 06:09:20 --> Helper loaded: url_helper
INFO - 2023-12-22 06:09:20 --> Helper loaded: file_helper
INFO - 2023-12-22 06:09:20 --> Helper loaded: html_helper
INFO - 2023-12-22 06:09:20 --> Helper loaded: text_helper
INFO - 2023-12-22 06:09:20 --> Helper loaded: form_helper
INFO - 2023-12-22 06:09:20 --> Helper loaded: lang_helper
INFO - 2023-12-22 06:09:20 --> Helper loaded: security_helper
INFO - 2023-12-22 06:09:20 --> Helper loaded: cookie_helper
INFO - 2023-12-22 06:09:20 --> Database Driver Class Initialized
INFO - 2023-12-22 06:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 06:09:20 --> Parser Class Initialized
INFO - 2023-12-22 06:09:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 06:09:20 --> Pagination Class Initialized
INFO - 2023-12-22 06:09:20 --> Form Validation Class Initialized
INFO - 2023-12-22 06:09:20 --> Controller Class Initialized
INFO - 2023-12-22 06:09:20 --> Model Class Initialized
DEBUG - 2023-12-22 06:09:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:09:20 --> Model Class Initialized
DEBUG - 2023-12-22 06:09:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:09:20 --> Model Class Initialized
INFO - 2023-12-22 06:09:20 --> Model Class Initialized
INFO - 2023-12-22 06:09:20 --> Model Class Initialized
INFO - 2023-12-22 06:09:20 --> Model Class Initialized
DEBUG - 2023-12-22 06:09:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 06:09:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:09:20 --> Model Class Initialized
INFO - 2023-12-22 06:09:20 --> Model Class Initialized
INFO - 2023-12-22 06:09:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-22 06:09:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:09:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 06:09:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 06:09:20 --> Model Class Initialized
INFO - 2023-12-22 06:09:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 06:09:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 06:09:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 06:09:20 --> Final output sent to browser
DEBUG - 2023-12-22 06:09:20 --> Total execution time: 0.2469
ERROR - 2023-12-22 06:09:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 06:09:28 --> Config Class Initialized
INFO - 2023-12-22 06:09:28 --> Hooks Class Initialized
DEBUG - 2023-12-22 06:09:28 --> UTF-8 Support Enabled
INFO - 2023-12-22 06:09:28 --> Utf8 Class Initialized
INFO - 2023-12-22 06:09:28 --> URI Class Initialized
INFO - 2023-12-22 06:09:28 --> Router Class Initialized
INFO - 2023-12-22 06:09:28 --> Output Class Initialized
INFO - 2023-12-22 06:09:28 --> Security Class Initialized
DEBUG - 2023-12-22 06:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 06:09:28 --> Input Class Initialized
INFO - 2023-12-22 06:09:28 --> Language Class Initialized
INFO - 2023-12-22 06:09:28 --> Loader Class Initialized
INFO - 2023-12-22 06:09:28 --> Helper loaded: url_helper
INFO - 2023-12-22 06:09:28 --> Helper loaded: file_helper
INFO - 2023-12-22 06:09:28 --> Helper loaded: html_helper
INFO - 2023-12-22 06:09:28 --> Helper loaded: text_helper
INFO - 2023-12-22 06:09:28 --> Helper loaded: form_helper
INFO - 2023-12-22 06:09:28 --> Helper loaded: lang_helper
INFO - 2023-12-22 06:09:28 --> Helper loaded: security_helper
INFO - 2023-12-22 06:09:28 --> Helper loaded: cookie_helper
INFO - 2023-12-22 06:09:28 --> Database Driver Class Initialized
INFO - 2023-12-22 06:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 06:09:28 --> Parser Class Initialized
INFO - 2023-12-22 06:09:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 06:09:28 --> Pagination Class Initialized
INFO - 2023-12-22 06:09:28 --> Form Validation Class Initialized
INFO - 2023-12-22 06:09:28 --> Controller Class Initialized
INFO - 2023-12-22 06:09:28 --> Model Class Initialized
DEBUG - 2023-12-22 06:09:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 06:09:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:09:28 --> Model Class Initialized
DEBUG - 2023-12-22 06:09:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:09:28 --> Model Class Initialized
INFO - 2023-12-22 06:09:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-12-22 06:09:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:09:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 06:09:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 06:09:28 --> Model Class Initialized
INFO - 2023-12-22 06:09:28 --> Model Class Initialized
INFO - 2023-12-22 06:09:28 --> Model Class Initialized
INFO - 2023-12-22 06:09:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 06:09:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 06:09:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 06:09:28 --> Final output sent to browser
DEBUG - 2023-12-22 06:09:28 --> Total execution time: 0.1766
ERROR - 2023-12-22 06:09:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 06:09:36 --> Config Class Initialized
INFO - 2023-12-22 06:09:36 --> Hooks Class Initialized
DEBUG - 2023-12-22 06:09:36 --> UTF-8 Support Enabled
INFO - 2023-12-22 06:09:36 --> Utf8 Class Initialized
INFO - 2023-12-22 06:09:36 --> URI Class Initialized
INFO - 2023-12-22 06:09:36 --> Router Class Initialized
INFO - 2023-12-22 06:09:36 --> Output Class Initialized
INFO - 2023-12-22 06:09:36 --> Security Class Initialized
DEBUG - 2023-12-22 06:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 06:09:36 --> Input Class Initialized
INFO - 2023-12-22 06:09:36 --> Language Class Initialized
INFO - 2023-12-22 06:09:36 --> Loader Class Initialized
INFO - 2023-12-22 06:09:36 --> Helper loaded: url_helper
INFO - 2023-12-22 06:09:36 --> Helper loaded: file_helper
INFO - 2023-12-22 06:09:36 --> Helper loaded: html_helper
INFO - 2023-12-22 06:09:36 --> Helper loaded: text_helper
INFO - 2023-12-22 06:09:36 --> Helper loaded: form_helper
INFO - 2023-12-22 06:09:36 --> Helper loaded: lang_helper
INFO - 2023-12-22 06:09:36 --> Helper loaded: security_helper
INFO - 2023-12-22 06:09:36 --> Helper loaded: cookie_helper
INFO - 2023-12-22 06:09:36 --> Database Driver Class Initialized
INFO - 2023-12-22 06:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 06:09:36 --> Parser Class Initialized
INFO - 2023-12-22 06:09:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 06:09:36 --> Pagination Class Initialized
INFO - 2023-12-22 06:09:36 --> Form Validation Class Initialized
INFO - 2023-12-22 06:09:36 --> Controller Class Initialized
INFO - 2023-12-22 06:09:36 --> Model Class Initialized
DEBUG - 2023-12-22 06:09:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:09:36 --> Final output sent to browser
DEBUG - 2023-12-22 06:09:36 --> Total execution time: 0.0154
ERROR - 2023-12-22 06:09:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 06:09:39 --> Config Class Initialized
INFO - 2023-12-22 06:09:39 --> Hooks Class Initialized
DEBUG - 2023-12-22 06:09:39 --> UTF-8 Support Enabled
INFO - 2023-12-22 06:09:39 --> Utf8 Class Initialized
INFO - 2023-12-22 06:09:39 --> URI Class Initialized
INFO - 2023-12-22 06:09:39 --> Router Class Initialized
INFO - 2023-12-22 06:09:39 --> Output Class Initialized
INFO - 2023-12-22 06:09:39 --> Security Class Initialized
DEBUG - 2023-12-22 06:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 06:09:39 --> Input Class Initialized
INFO - 2023-12-22 06:09:39 --> Language Class Initialized
INFO - 2023-12-22 06:09:39 --> Loader Class Initialized
INFO - 2023-12-22 06:09:39 --> Helper loaded: url_helper
INFO - 2023-12-22 06:09:39 --> Helper loaded: file_helper
INFO - 2023-12-22 06:09:39 --> Helper loaded: html_helper
INFO - 2023-12-22 06:09:39 --> Helper loaded: text_helper
INFO - 2023-12-22 06:09:39 --> Helper loaded: form_helper
INFO - 2023-12-22 06:09:39 --> Helper loaded: lang_helper
INFO - 2023-12-22 06:09:39 --> Helper loaded: security_helper
INFO - 2023-12-22 06:09:39 --> Helper loaded: cookie_helper
INFO - 2023-12-22 06:09:39 --> Database Driver Class Initialized
INFO - 2023-12-22 06:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 06:09:39 --> Parser Class Initialized
INFO - 2023-12-22 06:09:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 06:09:39 --> Pagination Class Initialized
INFO - 2023-12-22 06:09:39 --> Form Validation Class Initialized
INFO - 2023-12-22 06:09:39 --> Controller Class Initialized
INFO - 2023-12-22 06:09:39 --> Model Class Initialized
DEBUG - 2023-12-22 06:09:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-22 06:09:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-12-22 06:09:39 --> Final output sent to browser
DEBUG - 2023-12-22 06:09:39 --> Total execution time: 0.0150
ERROR - 2023-12-22 06:09:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 06:09:44 --> Config Class Initialized
INFO - 2023-12-22 06:09:44 --> Hooks Class Initialized
DEBUG - 2023-12-22 06:09:44 --> UTF-8 Support Enabled
INFO - 2023-12-22 06:09:44 --> Utf8 Class Initialized
INFO - 2023-12-22 06:09:44 --> URI Class Initialized
INFO - 2023-12-22 06:09:44 --> Router Class Initialized
INFO - 2023-12-22 06:09:44 --> Output Class Initialized
INFO - 2023-12-22 06:09:44 --> Security Class Initialized
DEBUG - 2023-12-22 06:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 06:09:44 --> Input Class Initialized
INFO - 2023-12-22 06:09:44 --> Language Class Initialized
INFO - 2023-12-22 06:09:44 --> Loader Class Initialized
INFO - 2023-12-22 06:09:44 --> Helper loaded: url_helper
INFO - 2023-12-22 06:09:44 --> Helper loaded: file_helper
INFO - 2023-12-22 06:09:44 --> Helper loaded: html_helper
INFO - 2023-12-22 06:09:44 --> Helper loaded: text_helper
INFO - 2023-12-22 06:09:44 --> Helper loaded: form_helper
INFO - 2023-12-22 06:09:44 --> Helper loaded: lang_helper
INFO - 2023-12-22 06:09:44 --> Helper loaded: security_helper
INFO - 2023-12-22 06:09:44 --> Helper loaded: cookie_helper
INFO - 2023-12-22 06:09:44 --> Database Driver Class Initialized
INFO - 2023-12-22 06:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 06:09:44 --> Parser Class Initialized
INFO - 2023-12-22 06:09:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 06:09:44 --> Pagination Class Initialized
INFO - 2023-12-22 06:09:44 --> Form Validation Class Initialized
INFO - 2023-12-22 06:09:44 --> Controller Class Initialized
INFO - 2023-12-22 06:09:44 --> Model Class Initialized
DEBUG - 2023-12-22 06:09:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:09:44 --> Final output sent to browser
DEBUG - 2023-12-22 06:09:44 --> Total execution time: 0.0143
ERROR - 2023-12-22 06:10:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 06:10:11 --> Config Class Initialized
INFO - 2023-12-22 06:10:11 --> Hooks Class Initialized
DEBUG - 2023-12-22 06:10:11 --> UTF-8 Support Enabled
INFO - 2023-12-22 06:10:11 --> Utf8 Class Initialized
INFO - 2023-12-22 06:10:11 --> URI Class Initialized
INFO - 2023-12-22 06:10:11 --> Router Class Initialized
INFO - 2023-12-22 06:10:11 --> Output Class Initialized
INFO - 2023-12-22 06:10:11 --> Security Class Initialized
DEBUG - 2023-12-22 06:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 06:10:11 --> Input Class Initialized
INFO - 2023-12-22 06:10:11 --> Language Class Initialized
INFO - 2023-12-22 06:10:11 --> Loader Class Initialized
INFO - 2023-12-22 06:10:11 --> Helper loaded: url_helper
INFO - 2023-12-22 06:10:11 --> Helper loaded: file_helper
INFO - 2023-12-22 06:10:11 --> Helper loaded: html_helper
INFO - 2023-12-22 06:10:11 --> Helper loaded: text_helper
INFO - 2023-12-22 06:10:11 --> Helper loaded: form_helper
INFO - 2023-12-22 06:10:11 --> Helper loaded: lang_helper
INFO - 2023-12-22 06:10:11 --> Helper loaded: security_helper
INFO - 2023-12-22 06:10:11 --> Helper loaded: cookie_helper
INFO - 2023-12-22 06:10:11 --> Database Driver Class Initialized
INFO - 2023-12-22 06:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 06:10:11 --> Parser Class Initialized
INFO - 2023-12-22 06:10:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 06:10:11 --> Pagination Class Initialized
INFO - 2023-12-22 06:10:11 --> Form Validation Class Initialized
INFO - 2023-12-22 06:10:11 --> Controller Class Initialized
INFO - 2023-12-22 06:10:11 --> Model Class Initialized
DEBUG - 2023-12-22 06:10:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:10:11 --> Final output sent to browser
DEBUG - 2023-12-22 06:10:11 --> Total execution time: 0.0185
ERROR - 2023-12-22 06:10:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 06:10:13 --> Config Class Initialized
INFO - 2023-12-22 06:10:13 --> Hooks Class Initialized
DEBUG - 2023-12-22 06:10:13 --> UTF-8 Support Enabled
INFO - 2023-12-22 06:10:13 --> Utf8 Class Initialized
INFO - 2023-12-22 06:10:13 --> URI Class Initialized
INFO - 2023-12-22 06:10:13 --> Router Class Initialized
INFO - 2023-12-22 06:10:13 --> Output Class Initialized
INFO - 2023-12-22 06:10:13 --> Security Class Initialized
DEBUG - 2023-12-22 06:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 06:10:13 --> Input Class Initialized
INFO - 2023-12-22 06:10:13 --> Language Class Initialized
INFO - 2023-12-22 06:10:13 --> Loader Class Initialized
INFO - 2023-12-22 06:10:13 --> Helper loaded: url_helper
INFO - 2023-12-22 06:10:13 --> Helper loaded: file_helper
INFO - 2023-12-22 06:10:13 --> Helper loaded: html_helper
INFO - 2023-12-22 06:10:13 --> Helper loaded: text_helper
INFO - 2023-12-22 06:10:13 --> Helper loaded: form_helper
INFO - 2023-12-22 06:10:13 --> Helper loaded: lang_helper
INFO - 2023-12-22 06:10:13 --> Helper loaded: security_helper
INFO - 2023-12-22 06:10:13 --> Helper loaded: cookie_helper
INFO - 2023-12-22 06:10:13 --> Database Driver Class Initialized
INFO - 2023-12-22 06:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 06:10:13 --> Parser Class Initialized
INFO - 2023-12-22 06:10:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 06:10:13 --> Pagination Class Initialized
INFO - 2023-12-22 06:10:13 --> Form Validation Class Initialized
INFO - 2023-12-22 06:10:13 --> Controller Class Initialized
INFO - 2023-12-22 06:10:13 --> Model Class Initialized
DEBUG - 2023-12-22 06:10:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:10:13 --> Final output sent to browser
DEBUG - 2023-12-22 06:10:13 --> Total execution time: 0.0185
ERROR - 2023-12-22 06:10:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 06:10:26 --> Config Class Initialized
INFO - 2023-12-22 06:10:26 --> Hooks Class Initialized
DEBUG - 2023-12-22 06:10:26 --> UTF-8 Support Enabled
INFO - 2023-12-22 06:10:26 --> Utf8 Class Initialized
INFO - 2023-12-22 06:10:26 --> URI Class Initialized
DEBUG - 2023-12-22 06:10:26 --> No URI present. Default controller set.
INFO - 2023-12-22 06:10:26 --> Router Class Initialized
INFO - 2023-12-22 06:10:26 --> Output Class Initialized
INFO - 2023-12-22 06:10:26 --> Security Class Initialized
DEBUG - 2023-12-22 06:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 06:10:26 --> Input Class Initialized
INFO - 2023-12-22 06:10:26 --> Language Class Initialized
INFO - 2023-12-22 06:10:26 --> Loader Class Initialized
INFO - 2023-12-22 06:10:26 --> Helper loaded: url_helper
INFO - 2023-12-22 06:10:26 --> Helper loaded: file_helper
INFO - 2023-12-22 06:10:26 --> Helper loaded: html_helper
INFO - 2023-12-22 06:10:26 --> Helper loaded: text_helper
INFO - 2023-12-22 06:10:26 --> Helper loaded: form_helper
INFO - 2023-12-22 06:10:26 --> Helper loaded: lang_helper
INFO - 2023-12-22 06:10:26 --> Helper loaded: security_helper
INFO - 2023-12-22 06:10:26 --> Helper loaded: cookie_helper
INFO - 2023-12-22 06:10:26 --> Database Driver Class Initialized
INFO - 2023-12-22 06:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 06:10:26 --> Parser Class Initialized
INFO - 2023-12-22 06:10:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 06:10:26 --> Pagination Class Initialized
INFO - 2023-12-22 06:10:26 --> Form Validation Class Initialized
INFO - 2023-12-22 06:10:26 --> Controller Class Initialized
INFO - 2023-12-22 06:10:26 --> Model Class Initialized
DEBUG - 2023-12-22 06:10:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:10:26 --> Model Class Initialized
DEBUG - 2023-12-22 06:10:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:10:26 --> Model Class Initialized
INFO - 2023-12-22 06:10:26 --> Model Class Initialized
INFO - 2023-12-22 06:10:26 --> Model Class Initialized
INFO - 2023-12-22 06:10:26 --> Model Class Initialized
DEBUG - 2023-12-22 06:10:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 06:10:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:10:26 --> Model Class Initialized
INFO - 2023-12-22 06:10:26 --> Model Class Initialized
INFO - 2023-12-22 06:10:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-22 06:10:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:10:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 06:10:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 06:10:26 --> Model Class Initialized
INFO - 2023-12-22 06:10:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 06:10:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 06:10:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 06:10:26 --> Final output sent to browser
DEBUG - 2023-12-22 06:10:26 --> Total execution time: 0.2191
ERROR - 2023-12-22 06:10:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 06:10:33 --> Config Class Initialized
INFO - 2023-12-22 06:10:33 --> Hooks Class Initialized
DEBUG - 2023-12-22 06:10:33 --> UTF-8 Support Enabled
INFO - 2023-12-22 06:10:33 --> Utf8 Class Initialized
INFO - 2023-12-22 06:10:33 --> URI Class Initialized
INFO - 2023-12-22 06:10:33 --> Router Class Initialized
INFO - 2023-12-22 06:10:33 --> Output Class Initialized
INFO - 2023-12-22 06:10:33 --> Security Class Initialized
DEBUG - 2023-12-22 06:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 06:10:33 --> Input Class Initialized
INFO - 2023-12-22 06:10:33 --> Language Class Initialized
INFO - 2023-12-22 06:10:33 --> Loader Class Initialized
INFO - 2023-12-22 06:10:33 --> Helper loaded: url_helper
INFO - 2023-12-22 06:10:33 --> Helper loaded: file_helper
INFO - 2023-12-22 06:10:33 --> Helper loaded: html_helper
INFO - 2023-12-22 06:10:33 --> Helper loaded: text_helper
INFO - 2023-12-22 06:10:33 --> Helper loaded: form_helper
INFO - 2023-12-22 06:10:33 --> Helper loaded: lang_helper
INFO - 2023-12-22 06:10:33 --> Helper loaded: security_helper
INFO - 2023-12-22 06:10:33 --> Helper loaded: cookie_helper
INFO - 2023-12-22 06:10:33 --> Database Driver Class Initialized
INFO - 2023-12-22 06:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 06:10:33 --> Parser Class Initialized
INFO - 2023-12-22 06:10:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 06:10:33 --> Pagination Class Initialized
INFO - 2023-12-22 06:10:33 --> Form Validation Class Initialized
INFO - 2023-12-22 06:10:33 --> Controller Class Initialized
INFO - 2023-12-22 06:10:33 --> Model Class Initialized
DEBUG - 2023-12-22 06:10:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 06:10:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:10:33 --> Model Class Initialized
DEBUG - 2023-12-22 06:10:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:10:33 --> Model Class Initialized
INFO - 2023-12-22 06:10:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-22 06:10:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:10:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 06:10:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 06:10:33 --> Model Class Initialized
INFO - 2023-12-22 06:10:33 --> Model Class Initialized
INFO - 2023-12-22 06:10:33 --> Model Class Initialized
INFO - 2023-12-22 06:10:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 06:10:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 06:10:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 06:10:33 --> Final output sent to browser
DEBUG - 2023-12-22 06:10:33 --> Total execution time: 0.1540
ERROR - 2023-12-22 06:10:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 06:10:34 --> Config Class Initialized
INFO - 2023-12-22 06:10:34 --> Hooks Class Initialized
DEBUG - 2023-12-22 06:10:34 --> UTF-8 Support Enabled
INFO - 2023-12-22 06:10:34 --> Utf8 Class Initialized
INFO - 2023-12-22 06:10:34 --> URI Class Initialized
INFO - 2023-12-22 06:10:34 --> Router Class Initialized
INFO - 2023-12-22 06:10:34 --> Output Class Initialized
INFO - 2023-12-22 06:10:34 --> Security Class Initialized
DEBUG - 2023-12-22 06:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 06:10:34 --> Input Class Initialized
INFO - 2023-12-22 06:10:34 --> Language Class Initialized
INFO - 2023-12-22 06:10:34 --> Loader Class Initialized
INFO - 2023-12-22 06:10:34 --> Helper loaded: url_helper
INFO - 2023-12-22 06:10:34 --> Helper loaded: file_helper
INFO - 2023-12-22 06:10:34 --> Helper loaded: html_helper
INFO - 2023-12-22 06:10:34 --> Helper loaded: text_helper
INFO - 2023-12-22 06:10:34 --> Helper loaded: form_helper
INFO - 2023-12-22 06:10:34 --> Helper loaded: lang_helper
INFO - 2023-12-22 06:10:34 --> Helper loaded: security_helper
INFO - 2023-12-22 06:10:34 --> Helper loaded: cookie_helper
INFO - 2023-12-22 06:10:34 --> Database Driver Class Initialized
INFO - 2023-12-22 06:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 06:10:34 --> Parser Class Initialized
INFO - 2023-12-22 06:10:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 06:10:34 --> Pagination Class Initialized
INFO - 2023-12-22 06:10:34 --> Form Validation Class Initialized
INFO - 2023-12-22 06:10:34 --> Controller Class Initialized
INFO - 2023-12-22 06:10:34 --> Model Class Initialized
DEBUG - 2023-12-22 06:10:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 06:10:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:10:34 --> Model Class Initialized
DEBUG - 2023-12-22 06:10:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:10:34 --> Model Class Initialized
INFO - 2023-12-22 06:10:34 --> Final output sent to browser
DEBUG - 2023-12-22 06:10:34 --> Total execution time: 0.0424
ERROR - 2023-12-22 06:10:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 06:10:44 --> Config Class Initialized
INFO - 2023-12-22 06:10:44 --> Hooks Class Initialized
DEBUG - 2023-12-22 06:10:44 --> UTF-8 Support Enabled
INFO - 2023-12-22 06:10:44 --> Utf8 Class Initialized
INFO - 2023-12-22 06:10:44 --> URI Class Initialized
DEBUG - 2023-12-22 06:10:44 --> No URI present. Default controller set.
INFO - 2023-12-22 06:10:44 --> Router Class Initialized
INFO - 2023-12-22 06:10:44 --> Output Class Initialized
INFO - 2023-12-22 06:10:44 --> Security Class Initialized
DEBUG - 2023-12-22 06:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 06:10:44 --> Input Class Initialized
INFO - 2023-12-22 06:10:44 --> Language Class Initialized
INFO - 2023-12-22 06:10:44 --> Loader Class Initialized
INFO - 2023-12-22 06:10:44 --> Helper loaded: url_helper
INFO - 2023-12-22 06:10:44 --> Helper loaded: file_helper
INFO - 2023-12-22 06:10:44 --> Helper loaded: html_helper
INFO - 2023-12-22 06:10:44 --> Helper loaded: text_helper
INFO - 2023-12-22 06:10:44 --> Helper loaded: form_helper
INFO - 2023-12-22 06:10:44 --> Helper loaded: lang_helper
INFO - 2023-12-22 06:10:44 --> Helper loaded: security_helper
INFO - 2023-12-22 06:10:44 --> Helper loaded: cookie_helper
INFO - 2023-12-22 06:10:44 --> Database Driver Class Initialized
INFO - 2023-12-22 06:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 06:10:44 --> Parser Class Initialized
INFO - 2023-12-22 06:10:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 06:10:44 --> Pagination Class Initialized
INFO - 2023-12-22 06:10:44 --> Form Validation Class Initialized
INFO - 2023-12-22 06:10:44 --> Controller Class Initialized
INFO - 2023-12-22 06:10:44 --> Model Class Initialized
DEBUG - 2023-12-22 06:10:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:10:44 --> Model Class Initialized
DEBUG - 2023-12-22 06:10:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:10:44 --> Model Class Initialized
INFO - 2023-12-22 06:10:44 --> Model Class Initialized
INFO - 2023-12-22 06:10:44 --> Model Class Initialized
INFO - 2023-12-22 06:10:44 --> Model Class Initialized
DEBUG - 2023-12-22 06:10:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 06:10:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:10:44 --> Model Class Initialized
INFO - 2023-12-22 06:10:44 --> Model Class Initialized
INFO - 2023-12-22 06:10:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-22 06:10:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:10:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 06:10:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 06:10:44 --> Model Class Initialized
INFO - 2023-12-22 06:10:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 06:10:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 06:10:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 06:10:44 --> Final output sent to browser
DEBUG - 2023-12-22 06:10:44 --> Total execution time: 0.2151
ERROR - 2023-12-22 06:10:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 06:10:50 --> Config Class Initialized
INFO - 2023-12-22 06:10:50 --> Hooks Class Initialized
DEBUG - 2023-12-22 06:10:50 --> UTF-8 Support Enabled
INFO - 2023-12-22 06:10:50 --> Utf8 Class Initialized
INFO - 2023-12-22 06:10:50 --> URI Class Initialized
INFO - 2023-12-22 06:10:50 --> Router Class Initialized
INFO - 2023-12-22 06:10:50 --> Output Class Initialized
INFO - 2023-12-22 06:10:50 --> Security Class Initialized
DEBUG - 2023-12-22 06:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 06:10:50 --> Input Class Initialized
INFO - 2023-12-22 06:10:50 --> Language Class Initialized
INFO - 2023-12-22 06:10:50 --> Loader Class Initialized
INFO - 2023-12-22 06:10:50 --> Helper loaded: url_helper
INFO - 2023-12-22 06:10:50 --> Helper loaded: file_helper
INFO - 2023-12-22 06:10:50 --> Helper loaded: html_helper
INFO - 2023-12-22 06:10:50 --> Helper loaded: text_helper
INFO - 2023-12-22 06:10:50 --> Helper loaded: form_helper
INFO - 2023-12-22 06:10:50 --> Helper loaded: lang_helper
INFO - 2023-12-22 06:10:50 --> Helper loaded: security_helper
INFO - 2023-12-22 06:10:50 --> Helper loaded: cookie_helper
INFO - 2023-12-22 06:10:50 --> Database Driver Class Initialized
INFO - 2023-12-22 06:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 06:10:50 --> Parser Class Initialized
INFO - 2023-12-22 06:10:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 06:10:50 --> Pagination Class Initialized
INFO - 2023-12-22 06:10:50 --> Form Validation Class Initialized
INFO - 2023-12-22 06:10:50 --> Controller Class Initialized
INFO - 2023-12-22 06:10:50 --> Model Class Initialized
DEBUG - 2023-12-22 06:10:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 06:10:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:10:50 --> Model Class Initialized
DEBUG - 2023-12-22 06:10:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:10:50 --> Model Class Initialized
INFO - 2023-12-22 06:10:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-12-22 06:10:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:10:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 06:10:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 06:10:50 --> Model Class Initialized
INFO - 2023-12-22 06:10:50 --> Model Class Initialized
INFO - 2023-12-22 06:10:50 --> Model Class Initialized
INFO - 2023-12-22 06:10:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 06:10:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 06:10:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 06:10:50 --> Final output sent to browser
DEBUG - 2023-12-22 06:10:50 --> Total execution time: 0.1679
ERROR - 2023-12-22 06:11:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 06:11:07 --> Config Class Initialized
INFO - 2023-12-22 06:11:07 --> Hooks Class Initialized
DEBUG - 2023-12-22 06:11:07 --> UTF-8 Support Enabled
INFO - 2023-12-22 06:11:07 --> Utf8 Class Initialized
INFO - 2023-12-22 06:11:07 --> URI Class Initialized
INFO - 2023-12-22 06:11:07 --> Router Class Initialized
INFO - 2023-12-22 06:11:07 --> Output Class Initialized
INFO - 2023-12-22 06:11:07 --> Security Class Initialized
DEBUG - 2023-12-22 06:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 06:11:07 --> Input Class Initialized
INFO - 2023-12-22 06:11:07 --> Language Class Initialized
INFO - 2023-12-22 06:11:07 --> Loader Class Initialized
INFO - 2023-12-22 06:11:07 --> Helper loaded: url_helper
INFO - 2023-12-22 06:11:07 --> Helper loaded: file_helper
INFO - 2023-12-22 06:11:07 --> Helper loaded: html_helper
INFO - 2023-12-22 06:11:07 --> Helper loaded: text_helper
INFO - 2023-12-22 06:11:07 --> Helper loaded: form_helper
INFO - 2023-12-22 06:11:07 --> Helper loaded: lang_helper
INFO - 2023-12-22 06:11:07 --> Helper loaded: security_helper
INFO - 2023-12-22 06:11:07 --> Helper loaded: cookie_helper
INFO - 2023-12-22 06:11:07 --> Database Driver Class Initialized
INFO - 2023-12-22 06:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 06:11:07 --> Parser Class Initialized
INFO - 2023-12-22 06:11:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 06:11:07 --> Pagination Class Initialized
INFO - 2023-12-22 06:11:07 --> Form Validation Class Initialized
INFO - 2023-12-22 06:11:07 --> Controller Class Initialized
INFO - 2023-12-22 06:11:07 --> Model Class Initialized
DEBUG - 2023-12-22 06:11:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:11:07 --> Final output sent to browser
DEBUG - 2023-12-22 06:11:07 --> Total execution time: 0.0180
ERROR - 2023-12-22 06:11:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 06:11:21 --> Config Class Initialized
INFO - 2023-12-22 06:11:21 --> Hooks Class Initialized
DEBUG - 2023-12-22 06:11:21 --> UTF-8 Support Enabled
INFO - 2023-12-22 06:11:21 --> Utf8 Class Initialized
INFO - 2023-12-22 06:11:21 --> URI Class Initialized
INFO - 2023-12-22 06:11:21 --> Router Class Initialized
INFO - 2023-12-22 06:11:21 --> Output Class Initialized
INFO - 2023-12-22 06:11:21 --> Security Class Initialized
DEBUG - 2023-12-22 06:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 06:11:21 --> Input Class Initialized
INFO - 2023-12-22 06:11:21 --> Language Class Initialized
INFO - 2023-12-22 06:11:21 --> Loader Class Initialized
INFO - 2023-12-22 06:11:21 --> Helper loaded: url_helper
INFO - 2023-12-22 06:11:21 --> Helper loaded: file_helper
INFO - 2023-12-22 06:11:21 --> Helper loaded: html_helper
INFO - 2023-12-22 06:11:21 --> Helper loaded: text_helper
INFO - 2023-12-22 06:11:21 --> Helper loaded: form_helper
INFO - 2023-12-22 06:11:21 --> Helper loaded: lang_helper
INFO - 2023-12-22 06:11:21 --> Helper loaded: security_helper
INFO - 2023-12-22 06:11:21 --> Helper loaded: cookie_helper
INFO - 2023-12-22 06:11:21 --> Database Driver Class Initialized
INFO - 2023-12-22 06:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 06:11:21 --> Parser Class Initialized
INFO - 2023-12-22 06:11:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 06:11:21 --> Pagination Class Initialized
INFO - 2023-12-22 06:11:21 --> Form Validation Class Initialized
INFO - 2023-12-22 06:11:21 --> Controller Class Initialized
INFO - 2023-12-22 06:11:21 --> Final output sent to browser
DEBUG - 2023-12-22 06:11:21 --> Total execution time: 0.0164
ERROR - 2023-12-22 06:11:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 06:11:33 --> Config Class Initialized
INFO - 2023-12-22 06:11:33 --> Hooks Class Initialized
DEBUG - 2023-12-22 06:11:33 --> UTF-8 Support Enabled
INFO - 2023-12-22 06:11:33 --> Utf8 Class Initialized
INFO - 2023-12-22 06:11:33 --> URI Class Initialized
INFO - 2023-12-22 06:11:33 --> Router Class Initialized
INFO - 2023-12-22 06:11:33 --> Output Class Initialized
INFO - 2023-12-22 06:11:33 --> Security Class Initialized
DEBUG - 2023-12-22 06:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 06:11:33 --> Input Class Initialized
INFO - 2023-12-22 06:11:33 --> Language Class Initialized
INFO - 2023-12-22 06:11:33 --> Loader Class Initialized
INFO - 2023-12-22 06:11:33 --> Helper loaded: url_helper
INFO - 2023-12-22 06:11:33 --> Helper loaded: file_helper
INFO - 2023-12-22 06:11:33 --> Helper loaded: html_helper
INFO - 2023-12-22 06:11:33 --> Helper loaded: text_helper
INFO - 2023-12-22 06:11:33 --> Helper loaded: form_helper
INFO - 2023-12-22 06:11:33 --> Helper loaded: lang_helper
INFO - 2023-12-22 06:11:33 --> Helper loaded: security_helper
INFO - 2023-12-22 06:11:33 --> Helper loaded: cookie_helper
INFO - 2023-12-22 06:11:33 --> Database Driver Class Initialized
INFO - 2023-12-22 06:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 06:11:33 --> Parser Class Initialized
INFO - 2023-12-22 06:11:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 06:11:33 --> Pagination Class Initialized
INFO - 2023-12-22 06:11:33 --> Form Validation Class Initialized
INFO - 2023-12-22 06:11:33 --> Controller Class Initialized
INFO - 2023-12-22 06:11:33 --> Model Class Initialized
DEBUG - 2023-12-22 06:11:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 06:11:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:11:33 --> Model Class Initialized
DEBUG - 2023-12-22 06:11:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:11:33 --> Model Class Initialized
INFO - 2023-12-22 06:11:33 --> Final output sent to browser
DEBUG - 2023-12-22 06:11:33 --> Total execution time: 0.0783
ERROR - 2023-12-22 06:11:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 06:11:35 --> Config Class Initialized
INFO - 2023-12-22 06:11:35 --> Hooks Class Initialized
DEBUG - 2023-12-22 06:11:35 --> UTF-8 Support Enabled
INFO - 2023-12-22 06:11:35 --> Utf8 Class Initialized
INFO - 2023-12-22 06:11:35 --> URI Class Initialized
INFO - 2023-12-22 06:11:35 --> Router Class Initialized
INFO - 2023-12-22 06:11:35 --> Output Class Initialized
INFO - 2023-12-22 06:11:35 --> Security Class Initialized
DEBUG - 2023-12-22 06:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 06:11:35 --> Input Class Initialized
INFO - 2023-12-22 06:11:35 --> Language Class Initialized
INFO - 2023-12-22 06:11:35 --> Loader Class Initialized
INFO - 2023-12-22 06:11:35 --> Helper loaded: url_helper
INFO - 2023-12-22 06:11:35 --> Helper loaded: file_helper
INFO - 2023-12-22 06:11:35 --> Helper loaded: html_helper
INFO - 2023-12-22 06:11:35 --> Helper loaded: text_helper
INFO - 2023-12-22 06:11:35 --> Helper loaded: form_helper
INFO - 2023-12-22 06:11:35 --> Helper loaded: lang_helper
INFO - 2023-12-22 06:11:35 --> Helper loaded: security_helper
INFO - 2023-12-22 06:11:35 --> Helper loaded: cookie_helper
INFO - 2023-12-22 06:11:35 --> Database Driver Class Initialized
INFO - 2023-12-22 06:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 06:11:35 --> Parser Class Initialized
INFO - 2023-12-22 06:11:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 06:11:35 --> Pagination Class Initialized
INFO - 2023-12-22 06:11:35 --> Form Validation Class Initialized
INFO - 2023-12-22 06:11:35 --> Controller Class Initialized
INFO - 2023-12-22 06:11:35 --> Model Class Initialized
DEBUG - 2023-12-22 06:11:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 06:11:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:11:35 --> Model Class Initialized
DEBUG - 2023-12-22 06:11:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:11:35 --> Model Class Initialized
INFO - 2023-12-22 06:11:35 --> Final output sent to browser
DEBUG - 2023-12-22 06:11:35 --> Total execution time: 0.0204
ERROR - 2023-12-22 06:11:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 06:11:41 --> Config Class Initialized
INFO - 2023-12-22 06:11:41 --> Hooks Class Initialized
DEBUG - 2023-12-22 06:11:41 --> UTF-8 Support Enabled
INFO - 2023-12-22 06:11:41 --> Utf8 Class Initialized
INFO - 2023-12-22 06:11:41 --> URI Class Initialized
INFO - 2023-12-22 06:11:41 --> Router Class Initialized
INFO - 2023-12-22 06:11:41 --> Output Class Initialized
INFO - 2023-12-22 06:11:41 --> Security Class Initialized
DEBUG - 2023-12-22 06:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 06:11:41 --> Input Class Initialized
INFO - 2023-12-22 06:11:41 --> Language Class Initialized
INFO - 2023-12-22 06:11:41 --> Loader Class Initialized
INFO - 2023-12-22 06:11:41 --> Helper loaded: url_helper
INFO - 2023-12-22 06:11:41 --> Helper loaded: file_helper
INFO - 2023-12-22 06:11:41 --> Helper loaded: html_helper
INFO - 2023-12-22 06:11:41 --> Helper loaded: text_helper
INFO - 2023-12-22 06:11:41 --> Helper loaded: form_helper
INFO - 2023-12-22 06:11:41 --> Helper loaded: lang_helper
INFO - 2023-12-22 06:11:41 --> Helper loaded: security_helper
INFO - 2023-12-22 06:11:41 --> Helper loaded: cookie_helper
INFO - 2023-12-22 06:11:41 --> Database Driver Class Initialized
INFO - 2023-12-22 06:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 06:11:41 --> Parser Class Initialized
INFO - 2023-12-22 06:11:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 06:11:41 --> Pagination Class Initialized
INFO - 2023-12-22 06:11:41 --> Form Validation Class Initialized
INFO - 2023-12-22 06:11:41 --> Controller Class Initialized
INFO - 2023-12-22 06:11:41 --> Model Class Initialized
DEBUG - 2023-12-22 06:11:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 06:11:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:11:41 --> Model Class Initialized
DEBUG - 2023-12-22 06:11:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:11:41 --> Model Class Initialized
INFO - 2023-12-22 06:11:41 --> Final output sent to browser
DEBUG - 2023-12-22 06:11:41 --> Total execution time: 0.0730
ERROR - 2023-12-22 06:11:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 06:11:52 --> Config Class Initialized
INFO - 2023-12-22 06:11:52 --> Hooks Class Initialized
DEBUG - 2023-12-22 06:11:52 --> UTF-8 Support Enabled
INFO - 2023-12-22 06:11:52 --> Utf8 Class Initialized
INFO - 2023-12-22 06:11:52 --> URI Class Initialized
INFO - 2023-12-22 06:11:52 --> Router Class Initialized
INFO - 2023-12-22 06:11:52 --> Output Class Initialized
INFO - 2023-12-22 06:11:52 --> Security Class Initialized
DEBUG - 2023-12-22 06:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 06:11:52 --> Input Class Initialized
INFO - 2023-12-22 06:11:52 --> Language Class Initialized
INFO - 2023-12-22 06:11:52 --> Loader Class Initialized
INFO - 2023-12-22 06:11:52 --> Helper loaded: url_helper
INFO - 2023-12-22 06:11:52 --> Helper loaded: file_helper
INFO - 2023-12-22 06:11:52 --> Helper loaded: html_helper
INFO - 2023-12-22 06:11:52 --> Helper loaded: text_helper
INFO - 2023-12-22 06:11:52 --> Helper loaded: form_helper
INFO - 2023-12-22 06:11:52 --> Helper loaded: lang_helper
INFO - 2023-12-22 06:11:52 --> Helper loaded: security_helper
INFO - 2023-12-22 06:11:52 --> Helper loaded: cookie_helper
INFO - 2023-12-22 06:11:52 --> Database Driver Class Initialized
INFO - 2023-12-22 06:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 06:11:52 --> Parser Class Initialized
INFO - 2023-12-22 06:11:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 06:11:52 --> Pagination Class Initialized
INFO - 2023-12-22 06:11:52 --> Form Validation Class Initialized
INFO - 2023-12-22 06:11:52 --> Controller Class Initialized
INFO - 2023-12-22 06:11:52 --> Model Class Initialized
DEBUG - 2023-12-22 06:11:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 06:11:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:11:52 --> Model Class Initialized
INFO - 2023-12-22 06:11:52 --> Model Class Initialized
INFO - 2023-12-22 06:11:52 --> Final output sent to browser
DEBUG - 2023-12-22 06:11:52 --> Total execution time: 0.0209
ERROR - 2023-12-22 06:11:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 06:11:55 --> Config Class Initialized
INFO - 2023-12-22 06:11:55 --> Hooks Class Initialized
DEBUG - 2023-12-22 06:11:55 --> UTF-8 Support Enabled
INFO - 2023-12-22 06:11:55 --> Utf8 Class Initialized
INFO - 2023-12-22 06:11:55 --> URI Class Initialized
INFO - 2023-12-22 06:11:55 --> Router Class Initialized
INFO - 2023-12-22 06:11:55 --> Output Class Initialized
INFO - 2023-12-22 06:11:55 --> Security Class Initialized
DEBUG - 2023-12-22 06:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 06:11:55 --> Input Class Initialized
INFO - 2023-12-22 06:11:55 --> Language Class Initialized
INFO - 2023-12-22 06:11:55 --> Loader Class Initialized
INFO - 2023-12-22 06:11:55 --> Helper loaded: url_helper
INFO - 2023-12-22 06:11:55 --> Helper loaded: file_helper
INFO - 2023-12-22 06:11:55 --> Helper loaded: html_helper
INFO - 2023-12-22 06:11:55 --> Helper loaded: text_helper
INFO - 2023-12-22 06:11:55 --> Helper loaded: form_helper
INFO - 2023-12-22 06:11:55 --> Helper loaded: lang_helper
INFO - 2023-12-22 06:11:55 --> Helper loaded: security_helper
INFO - 2023-12-22 06:11:55 --> Helper loaded: cookie_helper
INFO - 2023-12-22 06:11:55 --> Database Driver Class Initialized
INFO - 2023-12-22 06:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 06:11:55 --> Parser Class Initialized
INFO - 2023-12-22 06:11:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 06:11:55 --> Pagination Class Initialized
INFO - 2023-12-22 06:11:55 --> Form Validation Class Initialized
INFO - 2023-12-22 06:11:55 --> Controller Class Initialized
INFO - 2023-12-22 06:11:55 --> Model Class Initialized
DEBUG - 2023-12-22 06:11:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 06:11:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:11:55 --> Model Class Initialized
INFO - 2023-12-22 06:11:55 --> Final output sent to browser
DEBUG - 2023-12-22 06:11:55 --> Total execution time: 0.0160
ERROR - 2023-12-22 06:11:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 06:11:57 --> Config Class Initialized
INFO - 2023-12-22 06:11:57 --> Hooks Class Initialized
DEBUG - 2023-12-22 06:11:57 --> UTF-8 Support Enabled
INFO - 2023-12-22 06:11:57 --> Utf8 Class Initialized
INFO - 2023-12-22 06:11:57 --> URI Class Initialized
INFO - 2023-12-22 06:11:57 --> Router Class Initialized
INFO - 2023-12-22 06:11:57 --> Output Class Initialized
INFO - 2023-12-22 06:11:57 --> Security Class Initialized
DEBUG - 2023-12-22 06:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 06:11:57 --> Input Class Initialized
INFO - 2023-12-22 06:11:57 --> Language Class Initialized
INFO - 2023-12-22 06:11:57 --> Loader Class Initialized
INFO - 2023-12-22 06:11:57 --> Helper loaded: url_helper
INFO - 2023-12-22 06:11:57 --> Helper loaded: file_helper
INFO - 2023-12-22 06:11:57 --> Helper loaded: html_helper
INFO - 2023-12-22 06:11:57 --> Helper loaded: text_helper
INFO - 2023-12-22 06:11:57 --> Helper loaded: form_helper
INFO - 2023-12-22 06:11:57 --> Helper loaded: lang_helper
INFO - 2023-12-22 06:11:57 --> Helper loaded: security_helper
INFO - 2023-12-22 06:11:57 --> Helper loaded: cookie_helper
INFO - 2023-12-22 06:11:57 --> Database Driver Class Initialized
INFO - 2023-12-22 06:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 06:11:57 --> Parser Class Initialized
INFO - 2023-12-22 06:11:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 06:11:57 --> Pagination Class Initialized
INFO - 2023-12-22 06:11:57 --> Form Validation Class Initialized
INFO - 2023-12-22 06:11:57 --> Controller Class Initialized
INFO - 2023-12-22 06:11:57 --> Model Class Initialized
DEBUG - 2023-12-22 06:11:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 06:11:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:11:57 --> Model Class Initialized
INFO - 2023-12-22 06:11:57 --> Final output sent to browser
DEBUG - 2023-12-22 06:11:57 --> Total execution time: 0.0203
ERROR - 2023-12-22 06:12:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 06:12:32 --> Config Class Initialized
INFO - 2023-12-22 06:12:32 --> Hooks Class Initialized
DEBUG - 2023-12-22 06:12:32 --> UTF-8 Support Enabled
INFO - 2023-12-22 06:12:32 --> Utf8 Class Initialized
INFO - 2023-12-22 06:12:32 --> URI Class Initialized
INFO - 2023-12-22 06:12:32 --> Router Class Initialized
INFO - 2023-12-22 06:12:32 --> Output Class Initialized
INFO - 2023-12-22 06:12:32 --> Security Class Initialized
DEBUG - 2023-12-22 06:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 06:12:32 --> Input Class Initialized
INFO - 2023-12-22 06:12:32 --> Language Class Initialized
INFO - 2023-12-22 06:12:32 --> Loader Class Initialized
INFO - 2023-12-22 06:12:32 --> Helper loaded: url_helper
INFO - 2023-12-22 06:12:32 --> Helper loaded: file_helper
INFO - 2023-12-22 06:12:32 --> Helper loaded: html_helper
INFO - 2023-12-22 06:12:32 --> Helper loaded: text_helper
INFO - 2023-12-22 06:12:32 --> Helper loaded: form_helper
INFO - 2023-12-22 06:12:32 --> Helper loaded: lang_helper
INFO - 2023-12-22 06:12:32 --> Helper loaded: security_helper
INFO - 2023-12-22 06:12:32 --> Helper loaded: cookie_helper
INFO - 2023-12-22 06:12:32 --> Database Driver Class Initialized
INFO - 2023-12-22 06:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 06:12:32 --> Parser Class Initialized
INFO - 2023-12-22 06:12:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 06:12:32 --> Pagination Class Initialized
INFO - 2023-12-22 06:12:32 --> Form Validation Class Initialized
INFO - 2023-12-22 06:12:32 --> Controller Class Initialized
INFO - 2023-12-22 06:12:32 --> Model Class Initialized
DEBUG - 2023-12-22 06:12:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 06:12:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:12:32 --> Model Class Initialized
DEBUG - 2023-12-22 06:12:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:12:32 --> Model Class Initialized
INFO - 2023-12-22 06:12:32 --> Email Class Initialized
DEBUG - 2023-12-22 06:12:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:12:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-12-22 06:12:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2023-12-22 06:12:32 --> Language file loaded: language/english/email_lang.php
INFO - 2023-12-22 06:12:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2023-12-22 06:12:32 --> Final output sent to browser
DEBUG - 2023-12-22 06:12:32 --> Total execution time: 0.4896
ERROR - 2023-12-22 06:12:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 06:12:39 --> Config Class Initialized
INFO - 2023-12-22 06:12:39 --> Hooks Class Initialized
DEBUG - 2023-12-22 06:12:39 --> UTF-8 Support Enabled
INFO - 2023-12-22 06:12:39 --> Utf8 Class Initialized
INFO - 2023-12-22 06:12:39 --> URI Class Initialized
DEBUG - 2023-12-22 06:12:39 --> No URI present. Default controller set.
INFO - 2023-12-22 06:12:39 --> Router Class Initialized
INFO - 2023-12-22 06:12:39 --> Output Class Initialized
INFO - 2023-12-22 06:12:39 --> Security Class Initialized
DEBUG - 2023-12-22 06:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 06:12:39 --> Input Class Initialized
INFO - 2023-12-22 06:12:39 --> Language Class Initialized
INFO - 2023-12-22 06:12:39 --> Loader Class Initialized
INFO - 2023-12-22 06:12:39 --> Helper loaded: url_helper
INFO - 2023-12-22 06:12:39 --> Helper loaded: file_helper
INFO - 2023-12-22 06:12:39 --> Helper loaded: html_helper
INFO - 2023-12-22 06:12:39 --> Helper loaded: text_helper
INFO - 2023-12-22 06:12:39 --> Helper loaded: form_helper
INFO - 2023-12-22 06:12:39 --> Helper loaded: lang_helper
INFO - 2023-12-22 06:12:39 --> Helper loaded: security_helper
INFO - 2023-12-22 06:12:39 --> Helper loaded: cookie_helper
INFO - 2023-12-22 06:12:39 --> Database Driver Class Initialized
INFO - 2023-12-22 06:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 06:12:39 --> Parser Class Initialized
INFO - 2023-12-22 06:12:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 06:12:39 --> Pagination Class Initialized
INFO - 2023-12-22 06:12:39 --> Form Validation Class Initialized
INFO - 2023-12-22 06:12:39 --> Controller Class Initialized
INFO - 2023-12-22 06:12:39 --> Model Class Initialized
DEBUG - 2023-12-22 06:12:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:12:39 --> Model Class Initialized
DEBUG - 2023-12-22 06:12:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:12:39 --> Model Class Initialized
INFO - 2023-12-22 06:12:39 --> Model Class Initialized
INFO - 2023-12-22 06:12:39 --> Model Class Initialized
INFO - 2023-12-22 06:12:39 --> Model Class Initialized
DEBUG - 2023-12-22 06:12:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 06:12:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:12:39 --> Model Class Initialized
INFO - 2023-12-22 06:12:39 --> Model Class Initialized
INFO - 2023-12-22 06:12:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-22 06:12:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:12:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 06:12:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 06:12:39 --> Model Class Initialized
INFO - 2023-12-22 06:12:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 06:12:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 06:12:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 06:12:39 --> Final output sent to browser
DEBUG - 2023-12-22 06:12:39 --> Total execution time: 0.2206
ERROR - 2023-12-22 06:19:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 06:19:22 --> Config Class Initialized
INFO - 2023-12-22 06:19:22 --> Hooks Class Initialized
DEBUG - 2023-12-22 06:19:22 --> UTF-8 Support Enabled
INFO - 2023-12-22 06:19:22 --> Utf8 Class Initialized
INFO - 2023-12-22 06:19:22 --> URI Class Initialized
DEBUG - 2023-12-22 06:19:22 --> No URI present. Default controller set.
INFO - 2023-12-22 06:19:22 --> Router Class Initialized
INFO - 2023-12-22 06:19:22 --> Output Class Initialized
INFO - 2023-12-22 06:19:22 --> Security Class Initialized
DEBUG - 2023-12-22 06:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 06:19:22 --> Input Class Initialized
INFO - 2023-12-22 06:19:22 --> Language Class Initialized
INFO - 2023-12-22 06:19:22 --> Loader Class Initialized
INFO - 2023-12-22 06:19:22 --> Helper loaded: url_helper
INFO - 2023-12-22 06:19:22 --> Helper loaded: file_helper
INFO - 2023-12-22 06:19:22 --> Helper loaded: html_helper
INFO - 2023-12-22 06:19:22 --> Helper loaded: text_helper
INFO - 2023-12-22 06:19:22 --> Helper loaded: form_helper
INFO - 2023-12-22 06:19:22 --> Helper loaded: lang_helper
INFO - 2023-12-22 06:19:22 --> Helper loaded: security_helper
INFO - 2023-12-22 06:19:22 --> Helper loaded: cookie_helper
INFO - 2023-12-22 06:19:22 --> Database Driver Class Initialized
INFO - 2023-12-22 06:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 06:19:22 --> Parser Class Initialized
INFO - 2023-12-22 06:19:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 06:19:22 --> Pagination Class Initialized
INFO - 2023-12-22 06:19:22 --> Form Validation Class Initialized
INFO - 2023-12-22 06:19:22 --> Controller Class Initialized
INFO - 2023-12-22 06:19:22 --> Model Class Initialized
DEBUG - 2023-12-22 06:19:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:19:22 --> Model Class Initialized
DEBUG - 2023-12-22 06:19:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:19:22 --> Model Class Initialized
INFO - 2023-12-22 06:19:22 --> Model Class Initialized
INFO - 2023-12-22 06:19:22 --> Model Class Initialized
INFO - 2023-12-22 06:19:22 --> Model Class Initialized
DEBUG - 2023-12-22 06:19:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 06:19:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:19:22 --> Model Class Initialized
INFO - 2023-12-22 06:19:22 --> Model Class Initialized
INFO - 2023-12-22 06:19:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-22 06:19:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:19:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 06:19:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 06:19:22 --> Model Class Initialized
INFO - 2023-12-22 06:19:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 06:19:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 06:19:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 06:19:23 --> Final output sent to browser
DEBUG - 2023-12-22 06:19:23 --> Total execution time: 0.2265
ERROR - 2023-12-22 06:19:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 06:19:30 --> Config Class Initialized
INFO - 2023-12-22 06:19:30 --> Hooks Class Initialized
DEBUG - 2023-12-22 06:19:30 --> UTF-8 Support Enabled
INFO - 2023-12-22 06:19:30 --> Utf8 Class Initialized
INFO - 2023-12-22 06:19:30 --> URI Class Initialized
INFO - 2023-12-22 06:19:30 --> Router Class Initialized
INFO - 2023-12-22 06:19:30 --> Output Class Initialized
INFO - 2023-12-22 06:19:30 --> Security Class Initialized
DEBUG - 2023-12-22 06:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 06:19:30 --> Input Class Initialized
INFO - 2023-12-22 06:19:30 --> Language Class Initialized
INFO - 2023-12-22 06:19:30 --> Loader Class Initialized
INFO - 2023-12-22 06:19:30 --> Helper loaded: url_helper
INFO - 2023-12-22 06:19:30 --> Helper loaded: file_helper
INFO - 2023-12-22 06:19:30 --> Helper loaded: html_helper
INFO - 2023-12-22 06:19:30 --> Helper loaded: text_helper
INFO - 2023-12-22 06:19:30 --> Helper loaded: form_helper
INFO - 2023-12-22 06:19:30 --> Helper loaded: lang_helper
INFO - 2023-12-22 06:19:30 --> Helper loaded: security_helper
INFO - 2023-12-22 06:19:30 --> Helper loaded: cookie_helper
INFO - 2023-12-22 06:19:30 --> Database Driver Class Initialized
INFO - 2023-12-22 06:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 06:19:30 --> Parser Class Initialized
INFO - 2023-12-22 06:19:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 06:19:30 --> Pagination Class Initialized
INFO - 2023-12-22 06:19:30 --> Form Validation Class Initialized
INFO - 2023-12-22 06:19:30 --> Controller Class Initialized
INFO - 2023-12-22 06:19:30 --> Model Class Initialized
DEBUG - 2023-12-22 06:19:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 06:19:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:19:30 --> Model Class Initialized
DEBUG - 2023-12-22 06:19:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:19:30 --> Model Class Initialized
INFO - 2023-12-22 06:19:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-22 06:19:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:19:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 06:19:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 06:19:30 --> Model Class Initialized
INFO - 2023-12-22 06:19:30 --> Model Class Initialized
INFO - 2023-12-22 06:19:30 --> Model Class Initialized
INFO - 2023-12-22 06:19:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 06:19:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 06:19:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 06:19:30 --> Final output sent to browser
DEBUG - 2023-12-22 06:19:30 --> Total execution time: 0.1449
ERROR - 2023-12-22 06:19:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 06:19:32 --> Config Class Initialized
INFO - 2023-12-22 06:19:32 --> Hooks Class Initialized
DEBUG - 2023-12-22 06:19:32 --> UTF-8 Support Enabled
INFO - 2023-12-22 06:19:32 --> Utf8 Class Initialized
INFO - 2023-12-22 06:19:32 --> URI Class Initialized
INFO - 2023-12-22 06:19:32 --> Router Class Initialized
INFO - 2023-12-22 06:19:32 --> Output Class Initialized
INFO - 2023-12-22 06:19:32 --> Security Class Initialized
DEBUG - 2023-12-22 06:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 06:19:32 --> Input Class Initialized
INFO - 2023-12-22 06:19:32 --> Language Class Initialized
INFO - 2023-12-22 06:19:32 --> Loader Class Initialized
INFO - 2023-12-22 06:19:32 --> Helper loaded: url_helper
INFO - 2023-12-22 06:19:32 --> Helper loaded: file_helper
INFO - 2023-12-22 06:19:32 --> Helper loaded: html_helper
INFO - 2023-12-22 06:19:32 --> Helper loaded: text_helper
INFO - 2023-12-22 06:19:32 --> Helper loaded: form_helper
INFO - 2023-12-22 06:19:32 --> Helper loaded: lang_helper
INFO - 2023-12-22 06:19:32 --> Helper loaded: security_helper
INFO - 2023-12-22 06:19:32 --> Helper loaded: cookie_helper
INFO - 2023-12-22 06:19:32 --> Database Driver Class Initialized
INFO - 2023-12-22 06:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 06:19:32 --> Parser Class Initialized
INFO - 2023-12-22 06:19:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 06:19:32 --> Pagination Class Initialized
INFO - 2023-12-22 06:19:32 --> Form Validation Class Initialized
INFO - 2023-12-22 06:19:32 --> Controller Class Initialized
INFO - 2023-12-22 06:19:32 --> Model Class Initialized
DEBUG - 2023-12-22 06:19:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 06:19:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:19:32 --> Model Class Initialized
DEBUG - 2023-12-22 06:19:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:19:32 --> Model Class Initialized
INFO - 2023-12-22 06:19:32 --> Final output sent to browser
DEBUG - 2023-12-22 06:19:32 --> Total execution time: 0.0414
ERROR - 2023-12-22 06:20:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 06:20:03 --> Config Class Initialized
INFO - 2023-12-22 06:20:03 --> Hooks Class Initialized
DEBUG - 2023-12-22 06:20:03 --> UTF-8 Support Enabled
INFO - 2023-12-22 06:20:03 --> Utf8 Class Initialized
INFO - 2023-12-22 06:20:03 --> URI Class Initialized
INFO - 2023-12-22 06:20:03 --> Router Class Initialized
INFO - 2023-12-22 06:20:03 --> Output Class Initialized
INFO - 2023-12-22 06:20:03 --> Security Class Initialized
DEBUG - 2023-12-22 06:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 06:20:03 --> Input Class Initialized
INFO - 2023-12-22 06:20:03 --> Language Class Initialized
INFO - 2023-12-22 06:20:03 --> Loader Class Initialized
INFO - 2023-12-22 06:20:03 --> Helper loaded: url_helper
INFO - 2023-12-22 06:20:03 --> Helper loaded: file_helper
INFO - 2023-12-22 06:20:03 --> Helper loaded: html_helper
INFO - 2023-12-22 06:20:03 --> Helper loaded: text_helper
INFO - 2023-12-22 06:20:03 --> Helper loaded: form_helper
INFO - 2023-12-22 06:20:03 --> Helper loaded: lang_helper
INFO - 2023-12-22 06:20:03 --> Helper loaded: security_helper
INFO - 2023-12-22 06:20:03 --> Helper loaded: cookie_helper
INFO - 2023-12-22 06:20:03 --> Database Driver Class Initialized
INFO - 2023-12-22 06:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 06:20:03 --> Parser Class Initialized
INFO - 2023-12-22 06:20:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 06:20:03 --> Pagination Class Initialized
INFO - 2023-12-22 06:20:03 --> Form Validation Class Initialized
INFO - 2023-12-22 06:20:03 --> Controller Class Initialized
INFO - 2023-12-22 06:20:03 --> Model Class Initialized
DEBUG - 2023-12-22 06:20:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 06:20:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:20:03 --> Model Class Initialized
DEBUG - 2023-12-22 06:20:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:20:03 --> Model Class Initialized
DEBUG - 2023-12-22 06:20:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:20:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-12-22 06:20:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:20:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 06:20:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 06:20:03 --> Model Class Initialized
INFO - 2023-12-22 06:20:03 --> Model Class Initialized
INFO - 2023-12-22 06:20:03 --> Model Class Initialized
INFO - 2023-12-22 06:20:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 06:20:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 06:20:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 06:20:03 --> Final output sent to browser
DEBUG - 2023-12-22 06:20:03 --> Total execution time: 0.1587
ERROR - 2023-12-22 06:20:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 06:20:20 --> Config Class Initialized
INFO - 2023-12-22 06:20:20 --> Hooks Class Initialized
DEBUG - 2023-12-22 06:20:20 --> UTF-8 Support Enabled
INFO - 2023-12-22 06:20:20 --> Utf8 Class Initialized
INFO - 2023-12-22 06:20:20 --> URI Class Initialized
INFO - 2023-12-22 06:20:20 --> Router Class Initialized
INFO - 2023-12-22 06:20:20 --> Output Class Initialized
INFO - 2023-12-22 06:20:20 --> Security Class Initialized
DEBUG - 2023-12-22 06:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 06:20:20 --> Input Class Initialized
INFO - 2023-12-22 06:20:20 --> Language Class Initialized
INFO - 2023-12-22 06:20:20 --> Loader Class Initialized
INFO - 2023-12-22 06:20:20 --> Helper loaded: url_helper
INFO - 2023-12-22 06:20:20 --> Helper loaded: file_helper
INFO - 2023-12-22 06:20:20 --> Helper loaded: html_helper
INFO - 2023-12-22 06:20:20 --> Helper loaded: text_helper
INFO - 2023-12-22 06:20:20 --> Helper loaded: form_helper
INFO - 2023-12-22 06:20:20 --> Helper loaded: lang_helper
INFO - 2023-12-22 06:20:20 --> Helper loaded: security_helper
INFO - 2023-12-22 06:20:20 --> Helper loaded: cookie_helper
INFO - 2023-12-22 06:20:20 --> Database Driver Class Initialized
INFO - 2023-12-22 06:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 06:20:20 --> Parser Class Initialized
INFO - 2023-12-22 06:20:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 06:20:20 --> Pagination Class Initialized
INFO - 2023-12-22 06:20:20 --> Form Validation Class Initialized
INFO - 2023-12-22 06:20:20 --> Controller Class Initialized
INFO - 2023-12-22 06:20:20 --> Model Class Initialized
DEBUG - 2023-12-22 06:20:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 06:20:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:20:20 --> Model Class Initialized
DEBUG - 2023-12-22 06:20:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:20:20 --> Model Class Initialized
INFO - 2023-12-22 06:20:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-22 06:20:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:20:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 06:20:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 06:20:20 --> Model Class Initialized
INFO - 2023-12-22 06:20:20 --> Model Class Initialized
INFO - 2023-12-22 06:20:20 --> Model Class Initialized
INFO - 2023-12-22 06:20:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 06:20:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 06:20:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 06:20:20 --> Final output sent to browser
DEBUG - 2023-12-22 06:20:20 --> Total execution time: 0.1429
ERROR - 2023-12-22 06:20:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 06:20:23 --> Config Class Initialized
INFO - 2023-12-22 06:20:23 --> Hooks Class Initialized
DEBUG - 2023-12-22 06:20:23 --> UTF-8 Support Enabled
INFO - 2023-12-22 06:20:23 --> Utf8 Class Initialized
INFO - 2023-12-22 06:20:23 --> URI Class Initialized
INFO - 2023-12-22 06:20:23 --> Router Class Initialized
INFO - 2023-12-22 06:20:23 --> Output Class Initialized
INFO - 2023-12-22 06:20:23 --> Security Class Initialized
DEBUG - 2023-12-22 06:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 06:20:23 --> Input Class Initialized
INFO - 2023-12-22 06:20:23 --> Language Class Initialized
INFO - 2023-12-22 06:20:23 --> Loader Class Initialized
INFO - 2023-12-22 06:20:23 --> Helper loaded: url_helper
INFO - 2023-12-22 06:20:23 --> Helper loaded: file_helper
INFO - 2023-12-22 06:20:23 --> Helper loaded: html_helper
INFO - 2023-12-22 06:20:23 --> Helper loaded: text_helper
INFO - 2023-12-22 06:20:23 --> Helper loaded: form_helper
INFO - 2023-12-22 06:20:23 --> Helper loaded: lang_helper
INFO - 2023-12-22 06:20:23 --> Helper loaded: security_helper
INFO - 2023-12-22 06:20:23 --> Helper loaded: cookie_helper
INFO - 2023-12-22 06:20:23 --> Database Driver Class Initialized
INFO - 2023-12-22 06:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 06:20:23 --> Parser Class Initialized
INFO - 2023-12-22 06:20:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 06:20:23 --> Pagination Class Initialized
INFO - 2023-12-22 06:20:23 --> Form Validation Class Initialized
INFO - 2023-12-22 06:20:23 --> Controller Class Initialized
INFO - 2023-12-22 06:20:23 --> Model Class Initialized
DEBUG - 2023-12-22 06:20:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 06:20:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:20:23 --> Model Class Initialized
DEBUG - 2023-12-22 06:20:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:20:23 --> Model Class Initialized
INFO - 2023-12-22 06:20:23 --> Final output sent to browser
DEBUG - 2023-12-22 06:20:23 --> Total execution time: 0.0414
ERROR - 2023-12-22 06:54:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 06:54:28 --> Config Class Initialized
INFO - 2023-12-22 06:54:28 --> Hooks Class Initialized
DEBUG - 2023-12-22 06:54:28 --> UTF-8 Support Enabled
INFO - 2023-12-22 06:54:28 --> Utf8 Class Initialized
INFO - 2023-12-22 06:54:28 --> URI Class Initialized
DEBUG - 2023-12-22 06:54:28 --> No URI present. Default controller set.
INFO - 2023-12-22 06:54:28 --> Router Class Initialized
INFO - 2023-12-22 06:54:28 --> Output Class Initialized
INFO - 2023-12-22 06:54:28 --> Security Class Initialized
DEBUG - 2023-12-22 06:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 06:54:28 --> Input Class Initialized
INFO - 2023-12-22 06:54:28 --> Language Class Initialized
INFO - 2023-12-22 06:54:28 --> Loader Class Initialized
INFO - 2023-12-22 06:54:28 --> Helper loaded: url_helper
INFO - 2023-12-22 06:54:28 --> Helper loaded: file_helper
INFO - 2023-12-22 06:54:28 --> Helper loaded: html_helper
INFO - 2023-12-22 06:54:28 --> Helper loaded: text_helper
INFO - 2023-12-22 06:54:28 --> Helper loaded: form_helper
INFO - 2023-12-22 06:54:28 --> Helper loaded: lang_helper
INFO - 2023-12-22 06:54:28 --> Helper loaded: security_helper
INFO - 2023-12-22 06:54:28 --> Helper loaded: cookie_helper
INFO - 2023-12-22 06:54:28 --> Database Driver Class Initialized
INFO - 2023-12-22 06:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 06:54:28 --> Parser Class Initialized
INFO - 2023-12-22 06:54:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 06:54:28 --> Pagination Class Initialized
INFO - 2023-12-22 06:54:28 --> Form Validation Class Initialized
INFO - 2023-12-22 06:54:28 --> Controller Class Initialized
INFO - 2023-12-22 06:54:28 --> Model Class Initialized
DEBUG - 2023-12-22 06:54:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:54:28 --> Model Class Initialized
DEBUG - 2023-12-22 06:54:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:54:28 --> Model Class Initialized
INFO - 2023-12-22 06:54:28 --> Model Class Initialized
INFO - 2023-12-22 06:54:28 --> Model Class Initialized
INFO - 2023-12-22 06:54:28 --> Model Class Initialized
DEBUG - 2023-12-22 06:54:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 06:54:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:54:28 --> Model Class Initialized
INFO - 2023-12-22 06:54:28 --> Model Class Initialized
INFO - 2023-12-22 06:54:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-22 06:54:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:54:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 06:54:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 06:54:28 --> Model Class Initialized
INFO - 2023-12-22 06:54:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 06:54:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 06:54:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 06:54:28 --> Final output sent to browser
DEBUG - 2023-12-22 06:54:28 --> Total execution time: 0.2182
ERROR - 2023-12-22 06:54:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 06:54:36 --> Config Class Initialized
INFO - 2023-12-22 06:54:36 --> Hooks Class Initialized
DEBUG - 2023-12-22 06:54:36 --> UTF-8 Support Enabled
INFO - 2023-12-22 06:54:36 --> Utf8 Class Initialized
INFO - 2023-12-22 06:54:36 --> URI Class Initialized
INFO - 2023-12-22 06:54:36 --> Router Class Initialized
INFO - 2023-12-22 06:54:36 --> Output Class Initialized
INFO - 2023-12-22 06:54:36 --> Security Class Initialized
DEBUG - 2023-12-22 06:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 06:54:36 --> Input Class Initialized
INFO - 2023-12-22 06:54:36 --> Language Class Initialized
INFO - 2023-12-22 06:54:36 --> Loader Class Initialized
INFO - 2023-12-22 06:54:36 --> Helper loaded: url_helper
INFO - 2023-12-22 06:54:36 --> Helper loaded: file_helper
INFO - 2023-12-22 06:54:36 --> Helper loaded: html_helper
INFO - 2023-12-22 06:54:36 --> Helper loaded: text_helper
INFO - 2023-12-22 06:54:36 --> Helper loaded: form_helper
INFO - 2023-12-22 06:54:36 --> Helper loaded: lang_helper
INFO - 2023-12-22 06:54:36 --> Helper loaded: security_helper
INFO - 2023-12-22 06:54:36 --> Helper loaded: cookie_helper
INFO - 2023-12-22 06:54:36 --> Database Driver Class Initialized
INFO - 2023-12-22 06:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 06:54:36 --> Parser Class Initialized
INFO - 2023-12-22 06:54:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 06:54:36 --> Pagination Class Initialized
INFO - 2023-12-22 06:54:36 --> Form Validation Class Initialized
INFO - 2023-12-22 06:54:36 --> Controller Class Initialized
INFO - 2023-12-22 06:54:36 --> Model Class Initialized
DEBUG - 2023-12-22 06:54:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 06:54:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:54:36 --> Model Class Initialized
DEBUG - 2023-12-22 06:54:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:54:36 --> Model Class Initialized
INFO - 2023-12-22 06:54:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-22 06:54:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:54:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 06:54:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 06:54:36 --> Model Class Initialized
INFO - 2023-12-22 06:54:36 --> Model Class Initialized
INFO - 2023-12-22 06:54:36 --> Model Class Initialized
INFO - 2023-12-22 06:54:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 06:54:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 06:54:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 06:54:36 --> Final output sent to browser
DEBUG - 2023-12-22 06:54:36 --> Total execution time: 0.1495
ERROR - 2023-12-22 06:54:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 06:54:37 --> Config Class Initialized
INFO - 2023-12-22 06:54:37 --> Hooks Class Initialized
DEBUG - 2023-12-22 06:54:37 --> UTF-8 Support Enabled
INFO - 2023-12-22 06:54:37 --> Utf8 Class Initialized
INFO - 2023-12-22 06:54:37 --> URI Class Initialized
INFO - 2023-12-22 06:54:37 --> Router Class Initialized
INFO - 2023-12-22 06:54:37 --> Output Class Initialized
INFO - 2023-12-22 06:54:37 --> Security Class Initialized
DEBUG - 2023-12-22 06:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 06:54:37 --> Input Class Initialized
INFO - 2023-12-22 06:54:37 --> Language Class Initialized
INFO - 2023-12-22 06:54:37 --> Loader Class Initialized
INFO - 2023-12-22 06:54:37 --> Helper loaded: url_helper
INFO - 2023-12-22 06:54:37 --> Helper loaded: file_helper
INFO - 2023-12-22 06:54:37 --> Helper loaded: html_helper
INFO - 2023-12-22 06:54:37 --> Helper loaded: text_helper
INFO - 2023-12-22 06:54:37 --> Helper loaded: form_helper
INFO - 2023-12-22 06:54:37 --> Helper loaded: lang_helper
INFO - 2023-12-22 06:54:37 --> Helper loaded: security_helper
INFO - 2023-12-22 06:54:37 --> Helper loaded: cookie_helper
INFO - 2023-12-22 06:54:37 --> Database Driver Class Initialized
INFO - 2023-12-22 06:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 06:54:37 --> Parser Class Initialized
INFO - 2023-12-22 06:54:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 06:54:37 --> Pagination Class Initialized
INFO - 2023-12-22 06:54:37 --> Form Validation Class Initialized
INFO - 2023-12-22 06:54:37 --> Controller Class Initialized
INFO - 2023-12-22 06:54:37 --> Model Class Initialized
DEBUG - 2023-12-22 06:54:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 06:54:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:54:37 --> Model Class Initialized
DEBUG - 2023-12-22 06:54:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:54:37 --> Model Class Initialized
INFO - 2023-12-22 06:54:37 --> Final output sent to browser
DEBUG - 2023-12-22 06:54:37 --> Total execution time: 0.0418
ERROR - 2023-12-22 06:54:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 06:54:53 --> Config Class Initialized
INFO - 2023-12-22 06:54:53 --> Hooks Class Initialized
DEBUG - 2023-12-22 06:54:53 --> UTF-8 Support Enabled
INFO - 2023-12-22 06:54:53 --> Utf8 Class Initialized
INFO - 2023-12-22 06:54:53 --> URI Class Initialized
INFO - 2023-12-22 06:54:53 --> Router Class Initialized
INFO - 2023-12-22 06:54:53 --> Output Class Initialized
INFO - 2023-12-22 06:54:53 --> Security Class Initialized
DEBUG - 2023-12-22 06:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 06:54:53 --> Input Class Initialized
INFO - 2023-12-22 06:54:53 --> Language Class Initialized
INFO - 2023-12-22 06:54:53 --> Loader Class Initialized
INFO - 2023-12-22 06:54:53 --> Helper loaded: url_helper
INFO - 2023-12-22 06:54:53 --> Helper loaded: file_helper
INFO - 2023-12-22 06:54:53 --> Helper loaded: html_helper
INFO - 2023-12-22 06:54:53 --> Helper loaded: text_helper
INFO - 2023-12-22 06:54:53 --> Helper loaded: form_helper
INFO - 2023-12-22 06:54:53 --> Helper loaded: lang_helper
INFO - 2023-12-22 06:54:53 --> Helper loaded: security_helper
INFO - 2023-12-22 06:54:53 --> Helper loaded: cookie_helper
INFO - 2023-12-22 06:54:53 --> Database Driver Class Initialized
INFO - 2023-12-22 06:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 06:54:53 --> Parser Class Initialized
INFO - 2023-12-22 06:54:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 06:54:53 --> Pagination Class Initialized
INFO - 2023-12-22 06:54:53 --> Form Validation Class Initialized
INFO - 2023-12-22 06:54:53 --> Controller Class Initialized
INFO - 2023-12-22 06:54:53 --> Model Class Initialized
DEBUG - 2023-12-22 06:54:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 06:54:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:54:53 --> Model Class Initialized
DEBUG - 2023-12-22 06:54:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:54:53 --> Model Class Initialized
INFO - 2023-12-22 06:54:53 --> Final output sent to browser
DEBUG - 2023-12-22 06:54:53 --> Total execution time: 0.0707
ERROR - 2023-12-22 06:56:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 06:56:27 --> Config Class Initialized
INFO - 2023-12-22 06:56:27 --> Hooks Class Initialized
DEBUG - 2023-12-22 06:56:27 --> UTF-8 Support Enabled
INFO - 2023-12-22 06:56:27 --> Utf8 Class Initialized
INFO - 2023-12-22 06:56:27 --> URI Class Initialized
INFO - 2023-12-22 06:56:27 --> Router Class Initialized
INFO - 2023-12-22 06:56:27 --> Output Class Initialized
INFO - 2023-12-22 06:56:27 --> Security Class Initialized
DEBUG - 2023-12-22 06:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 06:56:27 --> Input Class Initialized
INFO - 2023-12-22 06:56:27 --> Language Class Initialized
INFO - 2023-12-22 06:56:27 --> Loader Class Initialized
INFO - 2023-12-22 06:56:27 --> Helper loaded: url_helper
INFO - 2023-12-22 06:56:27 --> Helper loaded: file_helper
INFO - 2023-12-22 06:56:27 --> Helper loaded: html_helper
INFO - 2023-12-22 06:56:27 --> Helper loaded: text_helper
INFO - 2023-12-22 06:56:27 --> Helper loaded: form_helper
INFO - 2023-12-22 06:56:27 --> Helper loaded: lang_helper
INFO - 2023-12-22 06:56:27 --> Helper loaded: security_helper
INFO - 2023-12-22 06:56:27 --> Helper loaded: cookie_helper
INFO - 2023-12-22 06:56:27 --> Database Driver Class Initialized
INFO - 2023-12-22 06:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 06:56:27 --> Parser Class Initialized
INFO - 2023-12-22 06:56:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 06:56:27 --> Pagination Class Initialized
INFO - 2023-12-22 06:56:27 --> Form Validation Class Initialized
INFO - 2023-12-22 06:56:27 --> Controller Class Initialized
INFO - 2023-12-22 06:56:27 --> Model Class Initialized
DEBUG - 2023-12-22 06:56:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 06:56:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:56:27 --> Model Class Initialized
DEBUG - 2023-12-22 06:56:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:56:27 --> Model Class Initialized
DEBUG - 2023-12-22 06:56:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:56:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-12-22 06:56:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:56:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 06:56:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 06:56:27 --> Model Class Initialized
INFO - 2023-12-22 06:56:27 --> Model Class Initialized
INFO - 2023-12-22 06:56:27 --> Model Class Initialized
INFO - 2023-12-22 06:56:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 06:56:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 06:56:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 06:56:27 --> Final output sent to browser
DEBUG - 2023-12-22 06:56:27 --> Total execution time: 0.1536
ERROR - 2023-12-22 06:56:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 06:56:51 --> Config Class Initialized
INFO - 2023-12-22 06:56:51 --> Hooks Class Initialized
DEBUG - 2023-12-22 06:56:51 --> UTF-8 Support Enabled
INFO - 2023-12-22 06:56:51 --> Utf8 Class Initialized
INFO - 2023-12-22 06:56:51 --> URI Class Initialized
INFO - 2023-12-22 06:56:51 --> Router Class Initialized
INFO - 2023-12-22 06:56:51 --> Output Class Initialized
INFO - 2023-12-22 06:56:51 --> Security Class Initialized
DEBUG - 2023-12-22 06:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 06:56:51 --> Input Class Initialized
INFO - 2023-12-22 06:56:51 --> Language Class Initialized
INFO - 2023-12-22 06:56:51 --> Loader Class Initialized
INFO - 2023-12-22 06:56:51 --> Helper loaded: url_helper
INFO - 2023-12-22 06:56:51 --> Helper loaded: file_helper
INFO - 2023-12-22 06:56:51 --> Helper loaded: html_helper
INFO - 2023-12-22 06:56:51 --> Helper loaded: text_helper
INFO - 2023-12-22 06:56:51 --> Helper loaded: form_helper
INFO - 2023-12-22 06:56:51 --> Helper loaded: lang_helper
INFO - 2023-12-22 06:56:51 --> Helper loaded: security_helper
INFO - 2023-12-22 06:56:51 --> Helper loaded: cookie_helper
INFO - 2023-12-22 06:56:51 --> Database Driver Class Initialized
INFO - 2023-12-22 06:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 06:56:51 --> Parser Class Initialized
INFO - 2023-12-22 06:56:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 06:56:51 --> Pagination Class Initialized
INFO - 2023-12-22 06:56:51 --> Form Validation Class Initialized
INFO - 2023-12-22 06:56:51 --> Controller Class Initialized
INFO - 2023-12-22 06:56:51 --> Model Class Initialized
DEBUG - 2023-12-22 06:56:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 06:56:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:56:51 --> Model Class Initialized
DEBUG - 2023-12-22 06:56:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:56:51 --> Model Class Initialized
INFO - 2023-12-22 06:56:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-22 06:56:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:56:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 06:56:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 06:56:51 --> Model Class Initialized
INFO - 2023-12-22 06:56:51 --> Model Class Initialized
INFO - 2023-12-22 06:56:51 --> Model Class Initialized
INFO - 2023-12-22 06:56:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 06:56:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 06:56:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 06:56:51 --> Final output sent to browser
DEBUG - 2023-12-22 06:56:51 --> Total execution time: 0.1443
ERROR - 2023-12-22 06:56:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 06:56:52 --> Config Class Initialized
INFO - 2023-12-22 06:56:52 --> Hooks Class Initialized
DEBUG - 2023-12-22 06:56:52 --> UTF-8 Support Enabled
INFO - 2023-12-22 06:56:52 --> Utf8 Class Initialized
INFO - 2023-12-22 06:56:52 --> URI Class Initialized
INFO - 2023-12-22 06:56:52 --> Router Class Initialized
INFO - 2023-12-22 06:56:52 --> Output Class Initialized
INFO - 2023-12-22 06:56:52 --> Security Class Initialized
DEBUG - 2023-12-22 06:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 06:56:52 --> Input Class Initialized
INFO - 2023-12-22 06:56:52 --> Language Class Initialized
INFO - 2023-12-22 06:56:52 --> Loader Class Initialized
INFO - 2023-12-22 06:56:52 --> Helper loaded: url_helper
INFO - 2023-12-22 06:56:52 --> Helper loaded: file_helper
INFO - 2023-12-22 06:56:52 --> Helper loaded: html_helper
INFO - 2023-12-22 06:56:52 --> Helper loaded: text_helper
INFO - 2023-12-22 06:56:52 --> Helper loaded: form_helper
INFO - 2023-12-22 06:56:52 --> Helper loaded: lang_helper
INFO - 2023-12-22 06:56:52 --> Helper loaded: security_helper
INFO - 2023-12-22 06:56:52 --> Helper loaded: cookie_helper
INFO - 2023-12-22 06:56:52 --> Database Driver Class Initialized
INFO - 2023-12-22 06:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 06:56:52 --> Parser Class Initialized
INFO - 2023-12-22 06:56:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 06:56:52 --> Pagination Class Initialized
INFO - 2023-12-22 06:56:52 --> Form Validation Class Initialized
INFO - 2023-12-22 06:56:52 --> Controller Class Initialized
INFO - 2023-12-22 06:56:52 --> Model Class Initialized
DEBUG - 2023-12-22 06:56:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 06:56:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:56:52 --> Model Class Initialized
DEBUG - 2023-12-22 06:56:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:56:52 --> Model Class Initialized
INFO - 2023-12-22 06:56:52 --> Final output sent to browser
DEBUG - 2023-12-22 06:56:52 --> Total execution time: 0.0403
ERROR - 2023-12-22 06:56:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 06:56:53 --> Config Class Initialized
INFO - 2023-12-22 06:56:53 --> Hooks Class Initialized
DEBUG - 2023-12-22 06:56:53 --> UTF-8 Support Enabled
INFO - 2023-12-22 06:56:53 --> Utf8 Class Initialized
INFO - 2023-12-22 06:56:53 --> URI Class Initialized
DEBUG - 2023-12-22 06:56:53 --> No URI present. Default controller set.
INFO - 2023-12-22 06:56:53 --> Router Class Initialized
INFO - 2023-12-22 06:56:53 --> Output Class Initialized
INFO - 2023-12-22 06:56:53 --> Security Class Initialized
DEBUG - 2023-12-22 06:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 06:56:53 --> Input Class Initialized
INFO - 2023-12-22 06:56:53 --> Language Class Initialized
INFO - 2023-12-22 06:56:53 --> Loader Class Initialized
INFO - 2023-12-22 06:56:53 --> Helper loaded: url_helper
INFO - 2023-12-22 06:56:53 --> Helper loaded: file_helper
INFO - 2023-12-22 06:56:53 --> Helper loaded: html_helper
INFO - 2023-12-22 06:56:53 --> Helper loaded: text_helper
INFO - 2023-12-22 06:56:53 --> Helper loaded: form_helper
INFO - 2023-12-22 06:56:53 --> Helper loaded: lang_helper
INFO - 2023-12-22 06:56:53 --> Helper loaded: security_helper
INFO - 2023-12-22 06:56:53 --> Helper loaded: cookie_helper
INFO - 2023-12-22 06:56:53 --> Database Driver Class Initialized
INFO - 2023-12-22 06:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 06:56:53 --> Parser Class Initialized
INFO - 2023-12-22 06:56:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 06:56:53 --> Pagination Class Initialized
INFO - 2023-12-22 06:56:53 --> Form Validation Class Initialized
INFO - 2023-12-22 06:56:53 --> Controller Class Initialized
INFO - 2023-12-22 06:56:53 --> Model Class Initialized
DEBUG - 2023-12-22 06:56:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:56:53 --> Model Class Initialized
DEBUG - 2023-12-22 06:56:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:56:53 --> Model Class Initialized
INFO - 2023-12-22 06:56:53 --> Model Class Initialized
INFO - 2023-12-22 06:56:53 --> Model Class Initialized
INFO - 2023-12-22 06:56:53 --> Model Class Initialized
DEBUG - 2023-12-22 06:56:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 06:56:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:56:53 --> Model Class Initialized
INFO - 2023-12-22 06:56:53 --> Model Class Initialized
INFO - 2023-12-22 06:56:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-22 06:56:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 06:56:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 06:56:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 06:56:53 --> Model Class Initialized
INFO - 2023-12-22 06:56:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 06:56:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 06:56:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 06:56:53 --> Final output sent to browser
DEBUG - 2023-12-22 06:56:53 --> Total execution time: 0.2242
ERROR - 2023-12-22 07:00:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 07:00:05 --> Config Class Initialized
INFO - 2023-12-22 07:00:05 --> Hooks Class Initialized
DEBUG - 2023-12-22 07:00:05 --> UTF-8 Support Enabled
INFO - 2023-12-22 07:00:05 --> Utf8 Class Initialized
INFO - 2023-12-22 07:00:05 --> URI Class Initialized
INFO - 2023-12-22 07:00:05 --> Router Class Initialized
INFO - 2023-12-22 07:00:05 --> Output Class Initialized
INFO - 2023-12-22 07:00:05 --> Security Class Initialized
DEBUG - 2023-12-22 07:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 07:00:05 --> Input Class Initialized
INFO - 2023-12-22 07:00:05 --> Language Class Initialized
INFO - 2023-12-22 07:00:05 --> Loader Class Initialized
INFO - 2023-12-22 07:00:05 --> Helper loaded: url_helper
INFO - 2023-12-22 07:00:05 --> Helper loaded: file_helper
INFO - 2023-12-22 07:00:05 --> Helper loaded: html_helper
INFO - 2023-12-22 07:00:05 --> Helper loaded: text_helper
INFO - 2023-12-22 07:00:05 --> Helper loaded: form_helper
INFO - 2023-12-22 07:00:05 --> Helper loaded: lang_helper
INFO - 2023-12-22 07:00:05 --> Helper loaded: security_helper
INFO - 2023-12-22 07:00:05 --> Helper loaded: cookie_helper
INFO - 2023-12-22 07:00:05 --> Database Driver Class Initialized
INFO - 2023-12-22 07:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 07:00:05 --> Parser Class Initialized
INFO - 2023-12-22 07:00:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 07:00:05 --> Pagination Class Initialized
INFO - 2023-12-22 07:00:05 --> Form Validation Class Initialized
INFO - 2023-12-22 07:00:05 --> Controller Class Initialized
INFO - 2023-12-22 07:00:05 --> Model Class Initialized
DEBUG - 2023-12-22 07:00:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 07:00:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:00:05 --> Model Class Initialized
DEBUG - 2023-12-22 07:00:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:00:05 --> Model Class Initialized
INFO - 2023-12-22 07:00:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-22 07:00:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:00:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 07:00:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 07:00:05 --> Model Class Initialized
INFO - 2023-12-22 07:00:05 --> Model Class Initialized
INFO - 2023-12-22 07:00:05 --> Model Class Initialized
INFO - 2023-12-22 07:00:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 07:00:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 07:00:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 07:00:06 --> Final output sent to browser
DEBUG - 2023-12-22 07:00:06 --> Total execution time: 0.1607
ERROR - 2023-12-22 07:00:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 07:00:07 --> Config Class Initialized
INFO - 2023-12-22 07:00:07 --> Hooks Class Initialized
DEBUG - 2023-12-22 07:00:07 --> UTF-8 Support Enabled
INFO - 2023-12-22 07:00:07 --> Utf8 Class Initialized
INFO - 2023-12-22 07:00:07 --> URI Class Initialized
INFO - 2023-12-22 07:00:07 --> Router Class Initialized
INFO - 2023-12-22 07:00:07 --> Output Class Initialized
INFO - 2023-12-22 07:00:07 --> Security Class Initialized
DEBUG - 2023-12-22 07:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 07:00:07 --> Input Class Initialized
INFO - 2023-12-22 07:00:07 --> Language Class Initialized
INFO - 2023-12-22 07:00:07 --> Loader Class Initialized
INFO - 2023-12-22 07:00:07 --> Helper loaded: url_helper
INFO - 2023-12-22 07:00:07 --> Helper loaded: file_helper
INFO - 2023-12-22 07:00:07 --> Helper loaded: html_helper
INFO - 2023-12-22 07:00:07 --> Helper loaded: text_helper
INFO - 2023-12-22 07:00:07 --> Helper loaded: form_helper
INFO - 2023-12-22 07:00:07 --> Helper loaded: lang_helper
INFO - 2023-12-22 07:00:07 --> Helper loaded: security_helper
INFO - 2023-12-22 07:00:07 --> Helper loaded: cookie_helper
INFO - 2023-12-22 07:00:07 --> Database Driver Class Initialized
INFO - 2023-12-22 07:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 07:00:07 --> Parser Class Initialized
INFO - 2023-12-22 07:00:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 07:00:07 --> Pagination Class Initialized
INFO - 2023-12-22 07:00:07 --> Form Validation Class Initialized
INFO - 2023-12-22 07:00:07 --> Controller Class Initialized
INFO - 2023-12-22 07:00:07 --> Model Class Initialized
DEBUG - 2023-12-22 07:00:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 07:00:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:00:07 --> Model Class Initialized
DEBUG - 2023-12-22 07:00:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:00:07 --> Model Class Initialized
INFO - 2023-12-22 07:00:07 --> Final output sent to browser
DEBUG - 2023-12-22 07:00:07 --> Total execution time: 0.0421
ERROR - 2023-12-22 07:00:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 07:00:14 --> Config Class Initialized
INFO - 2023-12-22 07:00:14 --> Hooks Class Initialized
DEBUG - 2023-12-22 07:00:14 --> UTF-8 Support Enabled
INFO - 2023-12-22 07:00:14 --> Utf8 Class Initialized
INFO - 2023-12-22 07:00:14 --> URI Class Initialized
INFO - 2023-12-22 07:00:14 --> Router Class Initialized
INFO - 2023-12-22 07:00:14 --> Output Class Initialized
INFO - 2023-12-22 07:00:14 --> Security Class Initialized
DEBUG - 2023-12-22 07:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 07:00:14 --> Input Class Initialized
INFO - 2023-12-22 07:00:14 --> Language Class Initialized
INFO - 2023-12-22 07:00:14 --> Loader Class Initialized
INFO - 2023-12-22 07:00:14 --> Helper loaded: url_helper
INFO - 2023-12-22 07:00:14 --> Helper loaded: file_helper
INFO - 2023-12-22 07:00:14 --> Helper loaded: html_helper
INFO - 2023-12-22 07:00:14 --> Helper loaded: text_helper
INFO - 2023-12-22 07:00:14 --> Helper loaded: form_helper
INFO - 2023-12-22 07:00:14 --> Helper loaded: lang_helper
INFO - 2023-12-22 07:00:14 --> Helper loaded: security_helper
INFO - 2023-12-22 07:00:14 --> Helper loaded: cookie_helper
INFO - 2023-12-22 07:00:14 --> Database Driver Class Initialized
INFO - 2023-12-22 07:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 07:00:14 --> Parser Class Initialized
INFO - 2023-12-22 07:00:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 07:00:14 --> Pagination Class Initialized
INFO - 2023-12-22 07:00:14 --> Form Validation Class Initialized
INFO - 2023-12-22 07:00:14 --> Controller Class Initialized
INFO - 2023-12-22 07:00:14 --> Model Class Initialized
DEBUG - 2023-12-22 07:00:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 07:00:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:00:14 --> Model Class Initialized
DEBUG - 2023-12-22 07:00:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:00:14 --> Model Class Initialized
INFO - 2023-12-22 07:00:14 --> Final output sent to browser
DEBUG - 2023-12-22 07:00:14 --> Total execution time: 0.0910
ERROR - 2023-12-22 07:00:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 07:00:57 --> Config Class Initialized
INFO - 2023-12-22 07:00:57 --> Hooks Class Initialized
DEBUG - 2023-12-22 07:00:57 --> UTF-8 Support Enabled
INFO - 2023-12-22 07:00:57 --> Utf8 Class Initialized
INFO - 2023-12-22 07:00:57 --> URI Class Initialized
INFO - 2023-12-22 07:00:57 --> Router Class Initialized
INFO - 2023-12-22 07:00:57 --> Output Class Initialized
INFO - 2023-12-22 07:00:57 --> Security Class Initialized
DEBUG - 2023-12-22 07:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 07:00:57 --> Input Class Initialized
INFO - 2023-12-22 07:00:57 --> Language Class Initialized
INFO - 2023-12-22 07:00:57 --> Loader Class Initialized
INFO - 2023-12-22 07:00:57 --> Helper loaded: url_helper
INFO - 2023-12-22 07:00:57 --> Helper loaded: file_helper
INFO - 2023-12-22 07:00:57 --> Helper loaded: html_helper
INFO - 2023-12-22 07:00:57 --> Helper loaded: text_helper
INFO - 2023-12-22 07:00:57 --> Helper loaded: form_helper
INFO - 2023-12-22 07:00:57 --> Helper loaded: lang_helper
INFO - 2023-12-22 07:00:57 --> Helper loaded: security_helper
INFO - 2023-12-22 07:00:57 --> Helper loaded: cookie_helper
INFO - 2023-12-22 07:00:57 --> Database Driver Class Initialized
INFO - 2023-12-22 07:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 07:00:57 --> Parser Class Initialized
INFO - 2023-12-22 07:00:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 07:00:57 --> Pagination Class Initialized
INFO - 2023-12-22 07:00:57 --> Form Validation Class Initialized
INFO - 2023-12-22 07:00:57 --> Controller Class Initialized
INFO - 2023-12-22 07:00:57 --> Model Class Initialized
DEBUG - 2023-12-22 07:00:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 07:00:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:00:57 --> Model Class Initialized
DEBUG - 2023-12-22 07:00:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:00:57 --> Model Class Initialized
DEBUG - 2023-12-22 07:00:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:00:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-12-22 07:00:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:00:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 07:00:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 07:00:57 --> Model Class Initialized
INFO - 2023-12-22 07:00:57 --> Model Class Initialized
INFO - 2023-12-22 07:00:57 --> Model Class Initialized
INFO - 2023-12-22 07:00:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 07:00:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 07:00:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 07:00:58 --> Final output sent to browser
DEBUG - 2023-12-22 07:00:58 --> Total execution time: 0.1544
ERROR - 2023-12-22 07:01:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 07:01:14 --> Config Class Initialized
INFO - 2023-12-22 07:01:14 --> Hooks Class Initialized
DEBUG - 2023-12-22 07:01:14 --> UTF-8 Support Enabled
INFO - 2023-12-22 07:01:14 --> Utf8 Class Initialized
INFO - 2023-12-22 07:01:14 --> URI Class Initialized
INFO - 2023-12-22 07:01:14 --> Router Class Initialized
INFO - 2023-12-22 07:01:14 --> Output Class Initialized
INFO - 2023-12-22 07:01:14 --> Security Class Initialized
DEBUG - 2023-12-22 07:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 07:01:14 --> Input Class Initialized
INFO - 2023-12-22 07:01:14 --> Language Class Initialized
INFO - 2023-12-22 07:01:14 --> Loader Class Initialized
INFO - 2023-12-22 07:01:14 --> Helper loaded: url_helper
INFO - 2023-12-22 07:01:14 --> Helper loaded: file_helper
INFO - 2023-12-22 07:01:14 --> Helper loaded: html_helper
INFO - 2023-12-22 07:01:14 --> Helper loaded: text_helper
INFO - 2023-12-22 07:01:14 --> Helper loaded: form_helper
INFO - 2023-12-22 07:01:14 --> Helper loaded: lang_helper
INFO - 2023-12-22 07:01:14 --> Helper loaded: security_helper
INFO - 2023-12-22 07:01:14 --> Helper loaded: cookie_helper
INFO - 2023-12-22 07:01:14 --> Database Driver Class Initialized
INFO - 2023-12-22 07:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 07:01:14 --> Parser Class Initialized
INFO - 2023-12-22 07:01:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 07:01:14 --> Pagination Class Initialized
INFO - 2023-12-22 07:01:14 --> Form Validation Class Initialized
INFO - 2023-12-22 07:01:14 --> Controller Class Initialized
INFO - 2023-12-22 07:01:14 --> Model Class Initialized
DEBUG - 2023-12-22 07:01:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 07:01:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:01:14 --> Model Class Initialized
DEBUG - 2023-12-22 07:01:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:01:14 --> Model Class Initialized
INFO - 2023-12-22 07:01:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-22 07:01:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:01:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 07:01:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 07:01:14 --> Model Class Initialized
INFO - 2023-12-22 07:01:14 --> Model Class Initialized
INFO - 2023-12-22 07:01:14 --> Model Class Initialized
INFO - 2023-12-22 07:01:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 07:01:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 07:01:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 07:01:14 --> Final output sent to browser
DEBUG - 2023-12-22 07:01:14 --> Total execution time: 0.1657
ERROR - 2023-12-22 07:01:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 07:01:15 --> Config Class Initialized
INFO - 2023-12-22 07:01:15 --> Hooks Class Initialized
DEBUG - 2023-12-22 07:01:15 --> UTF-8 Support Enabled
INFO - 2023-12-22 07:01:15 --> Utf8 Class Initialized
INFO - 2023-12-22 07:01:15 --> URI Class Initialized
INFO - 2023-12-22 07:01:15 --> Router Class Initialized
INFO - 2023-12-22 07:01:15 --> Output Class Initialized
INFO - 2023-12-22 07:01:15 --> Security Class Initialized
DEBUG - 2023-12-22 07:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 07:01:15 --> Input Class Initialized
INFO - 2023-12-22 07:01:15 --> Language Class Initialized
INFO - 2023-12-22 07:01:15 --> Loader Class Initialized
INFO - 2023-12-22 07:01:15 --> Helper loaded: url_helper
INFO - 2023-12-22 07:01:15 --> Helper loaded: file_helper
INFO - 2023-12-22 07:01:15 --> Helper loaded: html_helper
INFO - 2023-12-22 07:01:15 --> Helper loaded: text_helper
INFO - 2023-12-22 07:01:15 --> Helper loaded: form_helper
INFO - 2023-12-22 07:01:15 --> Helper loaded: lang_helper
INFO - 2023-12-22 07:01:15 --> Helper loaded: security_helper
INFO - 2023-12-22 07:01:15 --> Helper loaded: cookie_helper
INFO - 2023-12-22 07:01:15 --> Database Driver Class Initialized
INFO - 2023-12-22 07:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 07:01:15 --> Parser Class Initialized
INFO - 2023-12-22 07:01:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 07:01:15 --> Pagination Class Initialized
INFO - 2023-12-22 07:01:15 --> Form Validation Class Initialized
INFO - 2023-12-22 07:01:15 --> Controller Class Initialized
INFO - 2023-12-22 07:01:15 --> Model Class Initialized
DEBUG - 2023-12-22 07:01:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 07:01:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:01:15 --> Model Class Initialized
DEBUG - 2023-12-22 07:01:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:01:15 --> Model Class Initialized
INFO - 2023-12-22 07:01:15 --> Final output sent to browser
DEBUG - 2023-12-22 07:01:15 --> Total execution time: 0.0477
ERROR - 2023-12-22 07:01:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 07:01:24 --> Config Class Initialized
INFO - 2023-12-22 07:01:24 --> Hooks Class Initialized
DEBUG - 2023-12-22 07:01:24 --> UTF-8 Support Enabled
INFO - 2023-12-22 07:01:24 --> Utf8 Class Initialized
INFO - 2023-12-22 07:01:24 --> URI Class Initialized
INFO - 2023-12-22 07:01:24 --> Router Class Initialized
INFO - 2023-12-22 07:01:24 --> Output Class Initialized
INFO - 2023-12-22 07:01:24 --> Security Class Initialized
DEBUG - 2023-12-22 07:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 07:01:24 --> Input Class Initialized
INFO - 2023-12-22 07:01:24 --> Language Class Initialized
INFO - 2023-12-22 07:01:24 --> Loader Class Initialized
INFO - 2023-12-22 07:01:24 --> Helper loaded: url_helper
INFO - 2023-12-22 07:01:24 --> Helper loaded: file_helper
INFO - 2023-12-22 07:01:24 --> Helper loaded: html_helper
INFO - 2023-12-22 07:01:24 --> Helper loaded: text_helper
INFO - 2023-12-22 07:01:24 --> Helper loaded: form_helper
INFO - 2023-12-22 07:01:24 --> Helper loaded: lang_helper
INFO - 2023-12-22 07:01:24 --> Helper loaded: security_helper
INFO - 2023-12-22 07:01:24 --> Helper loaded: cookie_helper
INFO - 2023-12-22 07:01:24 --> Database Driver Class Initialized
INFO - 2023-12-22 07:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 07:01:24 --> Parser Class Initialized
INFO - 2023-12-22 07:01:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 07:01:24 --> Pagination Class Initialized
INFO - 2023-12-22 07:01:24 --> Form Validation Class Initialized
INFO - 2023-12-22 07:01:24 --> Controller Class Initialized
INFO - 2023-12-22 07:01:24 --> Model Class Initialized
DEBUG - 2023-12-22 07:01:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 07:01:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:01:24 --> Model Class Initialized
DEBUG - 2023-12-22 07:01:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:01:24 --> Model Class Initialized
INFO - 2023-12-22 07:01:24 --> Final output sent to browser
DEBUG - 2023-12-22 07:01:24 --> Total execution time: 0.0845
ERROR - 2023-12-22 07:02:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 07:02:46 --> Config Class Initialized
INFO - 2023-12-22 07:02:46 --> Hooks Class Initialized
DEBUG - 2023-12-22 07:02:46 --> UTF-8 Support Enabled
INFO - 2023-12-22 07:02:46 --> Utf8 Class Initialized
INFO - 2023-12-22 07:02:46 --> URI Class Initialized
DEBUG - 2023-12-22 07:02:46 --> No URI present. Default controller set.
INFO - 2023-12-22 07:02:46 --> Router Class Initialized
INFO - 2023-12-22 07:02:46 --> Output Class Initialized
INFO - 2023-12-22 07:02:46 --> Security Class Initialized
DEBUG - 2023-12-22 07:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 07:02:46 --> Input Class Initialized
INFO - 2023-12-22 07:02:46 --> Language Class Initialized
INFO - 2023-12-22 07:02:46 --> Loader Class Initialized
INFO - 2023-12-22 07:02:46 --> Helper loaded: url_helper
INFO - 2023-12-22 07:02:46 --> Helper loaded: file_helper
INFO - 2023-12-22 07:02:46 --> Helper loaded: html_helper
INFO - 2023-12-22 07:02:46 --> Helper loaded: text_helper
INFO - 2023-12-22 07:02:46 --> Helper loaded: form_helper
INFO - 2023-12-22 07:02:46 --> Helper loaded: lang_helper
INFO - 2023-12-22 07:02:46 --> Helper loaded: security_helper
INFO - 2023-12-22 07:02:46 --> Helper loaded: cookie_helper
INFO - 2023-12-22 07:02:46 --> Database Driver Class Initialized
INFO - 2023-12-22 07:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 07:02:46 --> Parser Class Initialized
INFO - 2023-12-22 07:02:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 07:02:46 --> Pagination Class Initialized
INFO - 2023-12-22 07:02:46 --> Form Validation Class Initialized
INFO - 2023-12-22 07:02:46 --> Controller Class Initialized
INFO - 2023-12-22 07:02:46 --> Model Class Initialized
DEBUG - 2023-12-22 07:02:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:02:46 --> Model Class Initialized
DEBUG - 2023-12-22 07:02:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:02:46 --> Model Class Initialized
INFO - 2023-12-22 07:02:46 --> Model Class Initialized
INFO - 2023-12-22 07:02:46 --> Model Class Initialized
INFO - 2023-12-22 07:02:46 --> Model Class Initialized
DEBUG - 2023-12-22 07:02:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 07:02:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:02:46 --> Model Class Initialized
INFO - 2023-12-22 07:02:46 --> Model Class Initialized
INFO - 2023-12-22 07:02:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-22 07:02:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:02:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 07:02:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 07:02:46 --> Model Class Initialized
INFO - 2023-12-22 07:02:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 07:02:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 07:02:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 07:02:46 --> Final output sent to browser
DEBUG - 2023-12-22 07:02:46 --> Total execution time: 0.2240
ERROR - 2023-12-22 07:11:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 07:11:32 --> Config Class Initialized
INFO - 2023-12-22 07:11:32 --> Hooks Class Initialized
DEBUG - 2023-12-22 07:11:32 --> UTF-8 Support Enabled
INFO - 2023-12-22 07:11:32 --> Utf8 Class Initialized
INFO - 2023-12-22 07:11:32 --> URI Class Initialized
INFO - 2023-12-22 07:11:32 --> Router Class Initialized
INFO - 2023-12-22 07:11:32 --> Output Class Initialized
INFO - 2023-12-22 07:11:32 --> Security Class Initialized
DEBUG - 2023-12-22 07:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 07:11:32 --> Input Class Initialized
INFO - 2023-12-22 07:11:32 --> Language Class Initialized
INFO - 2023-12-22 07:11:32 --> Loader Class Initialized
INFO - 2023-12-22 07:11:32 --> Helper loaded: url_helper
INFO - 2023-12-22 07:11:32 --> Helper loaded: file_helper
INFO - 2023-12-22 07:11:32 --> Helper loaded: html_helper
INFO - 2023-12-22 07:11:32 --> Helper loaded: text_helper
INFO - 2023-12-22 07:11:32 --> Helper loaded: form_helper
INFO - 2023-12-22 07:11:32 --> Helper loaded: lang_helper
INFO - 2023-12-22 07:11:32 --> Helper loaded: security_helper
INFO - 2023-12-22 07:11:32 --> Helper loaded: cookie_helper
INFO - 2023-12-22 07:11:32 --> Database Driver Class Initialized
INFO - 2023-12-22 07:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 07:11:32 --> Parser Class Initialized
INFO - 2023-12-22 07:11:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 07:11:32 --> Pagination Class Initialized
INFO - 2023-12-22 07:11:32 --> Form Validation Class Initialized
INFO - 2023-12-22 07:11:32 --> Controller Class Initialized
INFO - 2023-12-22 07:11:32 --> Model Class Initialized
DEBUG - 2023-12-22 07:11:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 07:11:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:11:32 --> Model Class Initialized
DEBUG - 2023-12-22 07:11:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:11:32 --> Model Class Initialized
INFO - 2023-12-22 07:11:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-22 07:11:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:11:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 07:11:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 07:11:32 --> Model Class Initialized
INFO - 2023-12-22 07:11:32 --> Model Class Initialized
INFO - 2023-12-22 07:11:32 --> Model Class Initialized
INFO - 2023-12-22 07:11:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 07:11:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 07:11:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 07:11:32 --> Final output sent to browser
DEBUG - 2023-12-22 07:11:32 --> Total execution time: 0.1576
ERROR - 2023-12-22 07:11:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 07:11:34 --> Config Class Initialized
INFO - 2023-12-22 07:11:34 --> Hooks Class Initialized
DEBUG - 2023-12-22 07:11:34 --> UTF-8 Support Enabled
INFO - 2023-12-22 07:11:34 --> Utf8 Class Initialized
INFO - 2023-12-22 07:11:34 --> URI Class Initialized
INFO - 2023-12-22 07:11:34 --> Router Class Initialized
INFO - 2023-12-22 07:11:34 --> Output Class Initialized
INFO - 2023-12-22 07:11:34 --> Security Class Initialized
DEBUG - 2023-12-22 07:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 07:11:34 --> Input Class Initialized
INFO - 2023-12-22 07:11:34 --> Language Class Initialized
INFO - 2023-12-22 07:11:34 --> Loader Class Initialized
INFO - 2023-12-22 07:11:34 --> Helper loaded: url_helper
INFO - 2023-12-22 07:11:34 --> Helper loaded: file_helper
INFO - 2023-12-22 07:11:34 --> Helper loaded: html_helper
INFO - 2023-12-22 07:11:34 --> Helper loaded: text_helper
INFO - 2023-12-22 07:11:34 --> Helper loaded: form_helper
INFO - 2023-12-22 07:11:34 --> Helper loaded: lang_helper
INFO - 2023-12-22 07:11:34 --> Helper loaded: security_helper
INFO - 2023-12-22 07:11:34 --> Helper loaded: cookie_helper
INFO - 2023-12-22 07:11:34 --> Database Driver Class Initialized
INFO - 2023-12-22 07:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 07:11:34 --> Parser Class Initialized
INFO - 2023-12-22 07:11:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 07:11:34 --> Pagination Class Initialized
INFO - 2023-12-22 07:11:34 --> Form Validation Class Initialized
INFO - 2023-12-22 07:11:34 --> Controller Class Initialized
INFO - 2023-12-22 07:11:34 --> Model Class Initialized
DEBUG - 2023-12-22 07:11:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 07:11:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:11:34 --> Model Class Initialized
DEBUG - 2023-12-22 07:11:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:11:34 --> Model Class Initialized
INFO - 2023-12-22 07:11:34 --> Final output sent to browser
DEBUG - 2023-12-22 07:11:34 --> Total execution time: 0.0463
ERROR - 2023-12-22 07:11:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 07:11:42 --> Config Class Initialized
INFO - 2023-12-22 07:11:42 --> Hooks Class Initialized
DEBUG - 2023-12-22 07:11:42 --> UTF-8 Support Enabled
INFO - 2023-12-22 07:11:42 --> Utf8 Class Initialized
INFO - 2023-12-22 07:11:42 --> URI Class Initialized
INFO - 2023-12-22 07:11:42 --> Router Class Initialized
INFO - 2023-12-22 07:11:42 --> Output Class Initialized
INFO - 2023-12-22 07:11:42 --> Security Class Initialized
DEBUG - 2023-12-22 07:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 07:11:42 --> Input Class Initialized
INFO - 2023-12-22 07:11:42 --> Language Class Initialized
INFO - 2023-12-22 07:11:42 --> Loader Class Initialized
INFO - 2023-12-22 07:11:42 --> Helper loaded: url_helper
INFO - 2023-12-22 07:11:42 --> Helper loaded: file_helper
INFO - 2023-12-22 07:11:42 --> Helper loaded: html_helper
INFO - 2023-12-22 07:11:42 --> Helper loaded: text_helper
INFO - 2023-12-22 07:11:42 --> Helper loaded: form_helper
INFO - 2023-12-22 07:11:42 --> Helper loaded: lang_helper
INFO - 2023-12-22 07:11:42 --> Helper loaded: security_helper
INFO - 2023-12-22 07:11:42 --> Helper loaded: cookie_helper
INFO - 2023-12-22 07:11:42 --> Database Driver Class Initialized
INFO - 2023-12-22 07:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 07:11:42 --> Parser Class Initialized
INFO - 2023-12-22 07:11:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 07:11:42 --> Pagination Class Initialized
INFO - 2023-12-22 07:11:42 --> Form Validation Class Initialized
INFO - 2023-12-22 07:11:42 --> Controller Class Initialized
INFO - 2023-12-22 07:11:42 --> Model Class Initialized
DEBUG - 2023-12-22 07:11:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 07:11:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:11:42 --> Model Class Initialized
DEBUG - 2023-12-22 07:11:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:11:42 --> Model Class Initialized
INFO - 2023-12-22 07:11:42 --> Final output sent to browser
DEBUG - 2023-12-22 07:11:42 --> Total execution time: 0.0816
ERROR - 2023-12-22 07:11:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 07:11:53 --> Config Class Initialized
INFO - 2023-12-22 07:11:53 --> Hooks Class Initialized
DEBUG - 2023-12-22 07:11:53 --> UTF-8 Support Enabled
INFO - 2023-12-22 07:11:53 --> Utf8 Class Initialized
INFO - 2023-12-22 07:11:53 --> URI Class Initialized
INFO - 2023-12-22 07:11:53 --> Router Class Initialized
INFO - 2023-12-22 07:11:53 --> Output Class Initialized
INFO - 2023-12-22 07:11:53 --> Security Class Initialized
DEBUG - 2023-12-22 07:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 07:11:53 --> Input Class Initialized
INFO - 2023-12-22 07:11:53 --> Language Class Initialized
INFO - 2023-12-22 07:11:53 --> Loader Class Initialized
INFO - 2023-12-22 07:11:53 --> Helper loaded: url_helper
INFO - 2023-12-22 07:11:53 --> Helper loaded: file_helper
INFO - 2023-12-22 07:11:53 --> Helper loaded: html_helper
INFO - 2023-12-22 07:11:53 --> Helper loaded: text_helper
INFO - 2023-12-22 07:11:53 --> Helper loaded: form_helper
INFO - 2023-12-22 07:11:53 --> Helper loaded: lang_helper
INFO - 2023-12-22 07:11:53 --> Helper loaded: security_helper
INFO - 2023-12-22 07:11:53 --> Helper loaded: cookie_helper
INFO - 2023-12-22 07:11:53 --> Database Driver Class Initialized
INFO - 2023-12-22 07:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 07:11:53 --> Parser Class Initialized
INFO - 2023-12-22 07:11:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 07:11:53 --> Pagination Class Initialized
INFO - 2023-12-22 07:11:53 --> Form Validation Class Initialized
INFO - 2023-12-22 07:11:53 --> Controller Class Initialized
INFO - 2023-12-22 07:11:53 --> Model Class Initialized
DEBUG - 2023-12-22 07:11:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 07:11:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:11:53 --> Model Class Initialized
DEBUG - 2023-12-22 07:11:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:11:53 --> Model Class Initialized
DEBUG - 2023-12-22 07:11:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:11:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-12-22 07:11:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:11:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 07:11:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 07:11:53 --> Model Class Initialized
INFO - 2023-12-22 07:11:53 --> Model Class Initialized
INFO - 2023-12-22 07:11:53 --> Model Class Initialized
INFO - 2023-12-22 07:11:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 07:11:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 07:11:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 07:11:54 --> Final output sent to browser
DEBUG - 2023-12-22 07:11:54 --> Total execution time: 0.1509
ERROR - 2023-12-22 07:13:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 07:13:11 --> Config Class Initialized
INFO - 2023-12-22 07:13:11 --> Hooks Class Initialized
DEBUG - 2023-12-22 07:13:11 --> UTF-8 Support Enabled
INFO - 2023-12-22 07:13:11 --> Utf8 Class Initialized
INFO - 2023-12-22 07:13:11 --> URI Class Initialized
INFO - 2023-12-22 07:13:11 --> Router Class Initialized
INFO - 2023-12-22 07:13:11 --> Output Class Initialized
INFO - 2023-12-22 07:13:11 --> Security Class Initialized
DEBUG - 2023-12-22 07:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 07:13:11 --> Input Class Initialized
INFO - 2023-12-22 07:13:11 --> Language Class Initialized
INFO - 2023-12-22 07:13:11 --> Loader Class Initialized
INFO - 2023-12-22 07:13:11 --> Helper loaded: url_helper
INFO - 2023-12-22 07:13:11 --> Helper loaded: file_helper
INFO - 2023-12-22 07:13:11 --> Helper loaded: html_helper
INFO - 2023-12-22 07:13:11 --> Helper loaded: text_helper
INFO - 2023-12-22 07:13:11 --> Helper loaded: form_helper
INFO - 2023-12-22 07:13:11 --> Helper loaded: lang_helper
INFO - 2023-12-22 07:13:11 --> Helper loaded: security_helper
INFO - 2023-12-22 07:13:11 --> Helper loaded: cookie_helper
INFO - 2023-12-22 07:13:11 --> Database Driver Class Initialized
INFO - 2023-12-22 07:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 07:13:11 --> Parser Class Initialized
INFO - 2023-12-22 07:13:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 07:13:11 --> Pagination Class Initialized
INFO - 2023-12-22 07:13:11 --> Form Validation Class Initialized
INFO - 2023-12-22 07:13:11 --> Controller Class Initialized
INFO - 2023-12-22 07:13:11 --> Model Class Initialized
DEBUG - 2023-12-22 07:13:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 07:13:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:13:11 --> Model Class Initialized
DEBUG - 2023-12-22 07:13:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:13:11 --> Model Class Initialized
INFO - 2023-12-22 07:13:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-22 07:13:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:13:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 07:13:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 07:13:11 --> Model Class Initialized
INFO - 2023-12-22 07:13:11 --> Model Class Initialized
INFO - 2023-12-22 07:13:11 --> Model Class Initialized
INFO - 2023-12-22 07:13:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 07:13:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 07:13:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 07:13:11 --> Final output sent to browser
DEBUG - 2023-12-22 07:13:11 --> Total execution time: 0.1400
ERROR - 2023-12-22 07:13:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 07:13:12 --> Config Class Initialized
INFO - 2023-12-22 07:13:12 --> Hooks Class Initialized
DEBUG - 2023-12-22 07:13:12 --> UTF-8 Support Enabled
INFO - 2023-12-22 07:13:12 --> Utf8 Class Initialized
INFO - 2023-12-22 07:13:12 --> URI Class Initialized
INFO - 2023-12-22 07:13:12 --> Router Class Initialized
INFO - 2023-12-22 07:13:12 --> Output Class Initialized
INFO - 2023-12-22 07:13:12 --> Security Class Initialized
DEBUG - 2023-12-22 07:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 07:13:12 --> Input Class Initialized
INFO - 2023-12-22 07:13:12 --> Language Class Initialized
INFO - 2023-12-22 07:13:12 --> Loader Class Initialized
INFO - 2023-12-22 07:13:12 --> Helper loaded: url_helper
INFO - 2023-12-22 07:13:12 --> Helper loaded: file_helper
INFO - 2023-12-22 07:13:12 --> Helper loaded: html_helper
INFO - 2023-12-22 07:13:12 --> Helper loaded: text_helper
INFO - 2023-12-22 07:13:12 --> Helper loaded: form_helper
INFO - 2023-12-22 07:13:12 --> Helper loaded: lang_helper
INFO - 2023-12-22 07:13:12 --> Helper loaded: security_helper
INFO - 2023-12-22 07:13:12 --> Helper loaded: cookie_helper
INFO - 2023-12-22 07:13:12 --> Database Driver Class Initialized
INFO - 2023-12-22 07:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 07:13:12 --> Parser Class Initialized
INFO - 2023-12-22 07:13:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 07:13:12 --> Pagination Class Initialized
INFO - 2023-12-22 07:13:12 --> Form Validation Class Initialized
INFO - 2023-12-22 07:13:12 --> Controller Class Initialized
INFO - 2023-12-22 07:13:12 --> Model Class Initialized
DEBUG - 2023-12-22 07:13:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 07:13:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:13:12 --> Model Class Initialized
DEBUG - 2023-12-22 07:13:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:13:12 --> Model Class Initialized
INFO - 2023-12-22 07:13:12 --> Final output sent to browser
DEBUG - 2023-12-22 07:13:12 --> Total execution time: 0.0493
ERROR - 2023-12-22 07:13:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 07:13:30 --> Config Class Initialized
INFO - 2023-12-22 07:13:30 --> Hooks Class Initialized
DEBUG - 2023-12-22 07:13:30 --> UTF-8 Support Enabled
INFO - 2023-12-22 07:13:30 --> Utf8 Class Initialized
INFO - 2023-12-22 07:13:30 --> URI Class Initialized
INFO - 2023-12-22 07:13:30 --> Router Class Initialized
INFO - 2023-12-22 07:13:30 --> Output Class Initialized
INFO - 2023-12-22 07:13:30 --> Security Class Initialized
DEBUG - 2023-12-22 07:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 07:13:30 --> Input Class Initialized
INFO - 2023-12-22 07:13:30 --> Language Class Initialized
INFO - 2023-12-22 07:13:30 --> Loader Class Initialized
INFO - 2023-12-22 07:13:30 --> Helper loaded: url_helper
INFO - 2023-12-22 07:13:30 --> Helper loaded: file_helper
INFO - 2023-12-22 07:13:30 --> Helper loaded: html_helper
INFO - 2023-12-22 07:13:30 --> Helper loaded: text_helper
INFO - 2023-12-22 07:13:30 --> Helper loaded: form_helper
INFO - 2023-12-22 07:13:30 --> Helper loaded: lang_helper
INFO - 2023-12-22 07:13:30 --> Helper loaded: security_helper
INFO - 2023-12-22 07:13:30 --> Helper loaded: cookie_helper
INFO - 2023-12-22 07:13:30 --> Database Driver Class Initialized
INFO - 2023-12-22 07:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 07:13:30 --> Parser Class Initialized
INFO - 2023-12-22 07:13:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 07:13:30 --> Pagination Class Initialized
INFO - 2023-12-22 07:13:30 --> Form Validation Class Initialized
INFO - 2023-12-22 07:13:30 --> Controller Class Initialized
INFO - 2023-12-22 07:13:30 --> Model Class Initialized
DEBUG - 2023-12-22 07:13:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 07:13:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:13:30 --> Model Class Initialized
DEBUG - 2023-12-22 07:13:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:13:30 --> Model Class Initialized
DEBUG - 2023-12-22 07:13:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:13:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-12-22 07:13:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:13:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 07:13:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 07:13:30 --> Model Class Initialized
INFO - 2023-12-22 07:13:30 --> Model Class Initialized
INFO - 2023-12-22 07:13:30 --> Model Class Initialized
INFO - 2023-12-22 07:13:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 07:13:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 07:13:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 07:13:30 --> Final output sent to browser
DEBUG - 2023-12-22 07:13:30 --> Total execution time: 0.1493
ERROR - 2023-12-22 07:17:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 07:17:07 --> Config Class Initialized
INFO - 2023-12-22 07:17:07 --> Hooks Class Initialized
DEBUG - 2023-12-22 07:17:07 --> UTF-8 Support Enabled
INFO - 2023-12-22 07:17:07 --> Utf8 Class Initialized
INFO - 2023-12-22 07:17:07 --> URI Class Initialized
INFO - 2023-12-22 07:17:07 --> Router Class Initialized
INFO - 2023-12-22 07:17:07 --> Output Class Initialized
INFO - 2023-12-22 07:17:07 --> Security Class Initialized
DEBUG - 2023-12-22 07:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 07:17:07 --> Input Class Initialized
INFO - 2023-12-22 07:17:07 --> Language Class Initialized
INFO - 2023-12-22 07:17:07 --> Loader Class Initialized
INFO - 2023-12-22 07:17:07 --> Helper loaded: url_helper
INFO - 2023-12-22 07:17:07 --> Helper loaded: file_helper
INFO - 2023-12-22 07:17:07 --> Helper loaded: html_helper
INFO - 2023-12-22 07:17:07 --> Helper loaded: text_helper
INFO - 2023-12-22 07:17:07 --> Helper loaded: form_helper
INFO - 2023-12-22 07:17:07 --> Helper loaded: lang_helper
INFO - 2023-12-22 07:17:07 --> Helper loaded: security_helper
INFO - 2023-12-22 07:17:07 --> Helper loaded: cookie_helper
INFO - 2023-12-22 07:17:07 --> Database Driver Class Initialized
INFO - 2023-12-22 07:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 07:17:07 --> Parser Class Initialized
INFO - 2023-12-22 07:17:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 07:17:07 --> Pagination Class Initialized
INFO - 2023-12-22 07:17:07 --> Form Validation Class Initialized
INFO - 2023-12-22 07:17:07 --> Controller Class Initialized
INFO - 2023-12-22 07:17:07 --> Model Class Initialized
DEBUG - 2023-12-22 07:17:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 07:17:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:17:07 --> Model Class Initialized
DEBUG - 2023-12-22 07:17:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:17:07 --> Model Class Initialized
INFO - 2023-12-22 07:17:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-22 07:17:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:17:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 07:17:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 07:17:07 --> Model Class Initialized
INFO - 2023-12-22 07:17:07 --> Model Class Initialized
INFO - 2023-12-22 07:17:07 --> Model Class Initialized
INFO - 2023-12-22 07:17:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 07:17:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 07:17:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 07:17:07 --> Final output sent to browser
DEBUG - 2023-12-22 07:17:07 --> Total execution time: 0.1432
ERROR - 2023-12-22 07:17:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 07:17:09 --> Config Class Initialized
INFO - 2023-12-22 07:17:09 --> Hooks Class Initialized
DEBUG - 2023-12-22 07:17:09 --> UTF-8 Support Enabled
INFO - 2023-12-22 07:17:09 --> Utf8 Class Initialized
INFO - 2023-12-22 07:17:09 --> URI Class Initialized
INFO - 2023-12-22 07:17:09 --> Router Class Initialized
INFO - 2023-12-22 07:17:09 --> Output Class Initialized
INFO - 2023-12-22 07:17:09 --> Security Class Initialized
DEBUG - 2023-12-22 07:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 07:17:09 --> Input Class Initialized
INFO - 2023-12-22 07:17:09 --> Language Class Initialized
INFO - 2023-12-22 07:17:09 --> Loader Class Initialized
INFO - 2023-12-22 07:17:09 --> Helper loaded: url_helper
INFO - 2023-12-22 07:17:09 --> Helper loaded: file_helper
INFO - 2023-12-22 07:17:09 --> Helper loaded: html_helper
INFO - 2023-12-22 07:17:09 --> Helper loaded: text_helper
INFO - 2023-12-22 07:17:09 --> Helper loaded: form_helper
INFO - 2023-12-22 07:17:09 --> Helper loaded: lang_helper
INFO - 2023-12-22 07:17:09 --> Helper loaded: security_helper
INFO - 2023-12-22 07:17:09 --> Helper loaded: cookie_helper
INFO - 2023-12-22 07:17:09 --> Database Driver Class Initialized
INFO - 2023-12-22 07:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 07:17:09 --> Parser Class Initialized
INFO - 2023-12-22 07:17:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 07:17:09 --> Pagination Class Initialized
INFO - 2023-12-22 07:17:09 --> Form Validation Class Initialized
INFO - 2023-12-22 07:17:09 --> Controller Class Initialized
INFO - 2023-12-22 07:17:09 --> Model Class Initialized
DEBUG - 2023-12-22 07:17:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 07:17:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:17:09 --> Model Class Initialized
DEBUG - 2023-12-22 07:17:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:17:09 --> Model Class Initialized
INFO - 2023-12-22 07:17:09 --> Final output sent to browser
DEBUG - 2023-12-22 07:17:09 --> Total execution time: 0.0415
ERROR - 2023-12-22 07:43:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 07:43:57 --> Config Class Initialized
INFO - 2023-12-22 07:43:57 --> Hooks Class Initialized
DEBUG - 2023-12-22 07:43:57 --> UTF-8 Support Enabled
INFO - 2023-12-22 07:43:57 --> Utf8 Class Initialized
INFO - 2023-12-22 07:43:57 --> URI Class Initialized
DEBUG - 2023-12-22 07:43:57 --> No URI present. Default controller set.
INFO - 2023-12-22 07:43:57 --> Router Class Initialized
INFO - 2023-12-22 07:43:57 --> Output Class Initialized
INFO - 2023-12-22 07:43:57 --> Security Class Initialized
DEBUG - 2023-12-22 07:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 07:43:57 --> Input Class Initialized
INFO - 2023-12-22 07:43:57 --> Language Class Initialized
INFO - 2023-12-22 07:43:57 --> Loader Class Initialized
INFO - 2023-12-22 07:43:57 --> Helper loaded: url_helper
INFO - 2023-12-22 07:43:57 --> Helper loaded: file_helper
INFO - 2023-12-22 07:43:57 --> Helper loaded: html_helper
INFO - 2023-12-22 07:43:57 --> Helper loaded: text_helper
INFO - 2023-12-22 07:43:57 --> Helper loaded: form_helper
INFO - 2023-12-22 07:43:57 --> Helper loaded: lang_helper
INFO - 2023-12-22 07:43:57 --> Helper loaded: security_helper
INFO - 2023-12-22 07:43:57 --> Helper loaded: cookie_helper
INFO - 2023-12-22 07:43:57 --> Database Driver Class Initialized
INFO - 2023-12-22 07:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 07:43:57 --> Parser Class Initialized
INFO - 2023-12-22 07:43:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 07:43:57 --> Pagination Class Initialized
INFO - 2023-12-22 07:43:57 --> Form Validation Class Initialized
INFO - 2023-12-22 07:43:57 --> Controller Class Initialized
INFO - 2023-12-22 07:43:57 --> Model Class Initialized
DEBUG - 2023-12-22 07:43:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:43:57 --> Model Class Initialized
DEBUG - 2023-12-22 07:43:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:43:57 --> Model Class Initialized
INFO - 2023-12-22 07:43:57 --> Model Class Initialized
INFO - 2023-12-22 07:43:57 --> Model Class Initialized
INFO - 2023-12-22 07:43:57 --> Model Class Initialized
DEBUG - 2023-12-22 07:43:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 07:43:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:43:57 --> Model Class Initialized
INFO - 2023-12-22 07:43:57 --> Model Class Initialized
INFO - 2023-12-22 07:43:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-22 07:43:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:43:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 07:43:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 07:43:57 --> Model Class Initialized
INFO - 2023-12-22 07:43:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 07:43:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 07:43:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 07:43:57 --> Final output sent to browser
DEBUG - 2023-12-22 07:43:57 --> Total execution time: 0.2255
ERROR - 2023-12-22 07:44:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 07:44:06 --> Config Class Initialized
INFO - 2023-12-22 07:44:06 --> Hooks Class Initialized
DEBUG - 2023-12-22 07:44:06 --> UTF-8 Support Enabled
INFO - 2023-12-22 07:44:06 --> Utf8 Class Initialized
INFO - 2023-12-22 07:44:06 --> URI Class Initialized
INFO - 2023-12-22 07:44:06 --> Router Class Initialized
INFO - 2023-12-22 07:44:06 --> Output Class Initialized
INFO - 2023-12-22 07:44:06 --> Security Class Initialized
DEBUG - 2023-12-22 07:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 07:44:06 --> Input Class Initialized
INFO - 2023-12-22 07:44:06 --> Language Class Initialized
INFO - 2023-12-22 07:44:06 --> Loader Class Initialized
INFO - 2023-12-22 07:44:06 --> Helper loaded: url_helper
INFO - 2023-12-22 07:44:06 --> Helper loaded: file_helper
INFO - 2023-12-22 07:44:06 --> Helper loaded: html_helper
INFO - 2023-12-22 07:44:06 --> Helper loaded: text_helper
INFO - 2023-12-22 07:44:06 --> Helper loaded: form_helper
INFO - 2023-12-22 07:44:06 --> Helper loaded: lang_helper
INFO - 2023-12-22 07:44:06 --> Helper loaded: security_helper
INFO - 2023-12-22 07:44:06 --> Helper loaded: cookie_helper
INFO - 2023-12-22 07:44:06 --> Database Driver Class Initialized
INFO - 2023-12-22 07:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 07:44:06 --> Parser Class Initialized
INFO - 2023-12-22 07:44:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 07:44:06 --> Pagination Class Initialized
INFO - 2023-12-22 07:44:06 --> Form Validation Class Initialized
INFO - 2023-12-22 07:44:06 --> Controller Class Initialized
INFO - 2023-12-22 07:44:06 --> Model Class Initialized
DEBUG - 2023-12-22 07:44:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 07:44:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:44:06 --> Model Class Initialized
DEBUG - 2023-12-22 07:44:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:44:06 --> Model Class Initialized
INFO - 2023-12-22 07:44:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-22 07:44:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:44:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 07:44:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 07:44:06 --> Model Class Initialized
INFO - 2023-12-22 07:44:06 --> Model Class Initialized
INFO - 2023-12-22 07:44:06 --> Model Class Initialized
INFO - 2023-12-22 07:44:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 07:44:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 07:44:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 07:44:06 --> Final output sent to browser
DEBUG - 2023-12-22 07:44:06 --> Total execution time: 0.1682
ERROR - 2023-12-22 07:44:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 07:44:07 --> Config Class Initialized
INFO - 2023-12-22 07:44:07 --> Hooks Class Initialized
DEBUG - 2023-12-22 07:44:07 --> UTF-8 Support Enabled
INFO - 2023-12-22 07:44:07 --> Utf8 Class Initialized
INFO - 2023-12-22 07:44:07 --> URI Class Initialized
INFO - 2023-12-22 07:44:07 --> Router Class Initialized
INFO - 2023-12-22 07:44:07 --> Output Class Initialized
INFO - 2023-12-22 07:44:07 --> Security Class Initialized
DEBUG - 2023-12-22 07:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 07:44:07 --> Input Class Initialized
INFO - 2023-12-22 07:44:07 --> Language Class Initialized
INFO - 2023-12-22 07:44:07 --> Loader Class Initialized
INFO - 2023-12-22 07:44:07 --> Helper loaded: url_helper
INFO - 2023-12-22 07:44:07 --> Helper loaded: file_helper
INFO - 2023-12-22 07:44:07 --> Helper loaded: html_helper
INFO - 2023-12-22 07:44:07 --> Helper loaded: text_helper
INFO - 2023-12-22 07:44:07 --> Helper loaded: form_helper
INFO - 2023-12-22 07:44:07 --> Helper loaded: lang_helper
INFO - 2023-12-22 07:44:07 --> Helper loaded: security_helper
INFO - 2023-12-22 07:44:07 --> Helper loaded: cookie_helper
INFO - 2023-12-22 07:44:07 --> Database Driver Class Initialized
INFO - 2023-12-22 07:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 07:44:07 --> Parser Class Initialized
INFO - 2023-12-22 07:44:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 07:44:07 --> Pagination Class Initialized
INFO - 2023-12-22 07:44:07 --> Form Validation Class Initialized
INFO - 2023-12-22 07:44:07 --> Controller Class Initialized
INFO - 2023-12-22 07:44:07 --> Model Class Initialized
DEBUG - 2023-12-22 07:44:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 07:44:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:44:07 --> Model Class Initialized
DEBUG - 2023-12-22 07:44:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:44:07 --> Model Class Initialized
INFO - 2023-12-22 07:44:07 --> Final output sent to browser
DEBUG - 2023-12-22 07:44:07 --> Total execution time: 0.0382
ERROR - 2023-12-22 07:44:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 07:44:12 --> Config Class Initialized
INFO - 2023-12-22 07:44:12 --> Hooks Class Initialized
DEBUG - 2023-12-22 07:44:12 --> UTF-8 Support Enabled
INFO - 2023-12-22 07:44:12 --> Utf8 Class Initialized
INFO - 2023-12-22 07:44:12 --> URI Class Initialized
INFO - 2023-12-22 07:44:12 --> Router Class Initialized
INFO - 2023-12-22 07:44:12 --> Output Class Initialized
INFO - 2023-12-22 07:44:12 --> Security Class Initialized
DEBUG - 2023-12-22 07:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 07:44:12 --> Input Class Initialized
INFO - 2023-12-22 07:44:12 --> Language Class Initialized
INFO - 2023-12-22 07:44:12 --> Loader Class Initialized
INFO - 2023-12-22 07:44:12 --> Helper loaded: url_helper
INFO - 2023-12-22 07:44:12 --> Helper loaded: file_helper
INFO - 2023-12-22 07:44:12 --> Helper loaded: html_helper
INFO - 2023-12-22 07:44:12 --> Helper loaded: text_helper
INFO - 2023-12-22 07:44:12 --> Helper loaded: form_helper
INFO - 2023-12-22 07:44:12 --> Helper loaded: lang_helper
INFO - 2023-12-22 07:44:12 --> Helper loaded: security_helper
INFO - 2023-12-22 07:44:12 --> Helper loaded: cookie_helper
INFO - 2023-12-22 07:44:12 --> Database Driver Class Initialized
INFO - 2023-12-22 07:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 07:44:12 --> Parser Class Initialized
INFO - 2023-12-22 07:44:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 07:44:12 --> Pagination Class Initialized
INFO - 2023-12-22 07:44:12 --> Form Validation Class Initialized
INFO - 2023-12-22 07:44:12 --> Controller Class Initialized
INFO - 2023-12-22 07:44:12 --> Model Class Initialized
DEBUG - 2023-12-22 07:44:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 07:44:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:44:12 --> Model Class Initialized
DEBUG - 2023-12-22 07:44:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:44:12 --> Model Class Initialized
INFO - 2023-12-22 07:44:12 --> Final output sent to browser
DEBUG - 2023-12-22 07:44:12 --> Total execution time: 0.0788
ERROR - 2023-12-22 07:44:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 07:44:28 --> Config Class Initialized
INFO - 2023-12-22 07:44:28 --> Hooks Class Initialized
DEBUG - 2023-12-22 07:44:28 --> UTF-8 Support Enabled
INFO - 2023-12-22 07:44:28 --> Utf8 Class Initialized
INFO - 2023-12-22 07:44:28 --> URI Class Initialized
INFO - 2023-12-22 07:44:28 --> Router Class Initialized
INFO - 2023-12-22 07:44:28 --> Output Class Initialized
INFO - 2023-12-22 07:44:28 --> Security Class Initialized
DEBUG - 2023-12-22 07:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 07:44:28 --> Input Class Initialized
INFO - 2023-12-22 07:44:28 --> Language Class Initialized
INFO - 2023-12-22 07:44:28 --> Loader Class Initialized
INFO - 2023-12-22 07:44:28 --> Helper loaded: url_helper
INFO - 2023-12-22 07:44:28 --> Helper loaded: file_helper
INFO - 2023-12-22 07:44:28 --> Helper loaded: html_helper
INFO - 2023-12-22 07:44:28 --> Helper loaded: text_helper
INFO - 2023-12-22 07:44:28 --> Helper loaded: form_helper
INFO - 2023-12-22 07:44:28 --> Helper loaded: lang_helper
INFO - 2023-12-22 07:44:28 --> Helper loaded: security_helper
INFO - 2023-12-22 07:44:28 --> Helper loaded: cookie_helper
INFO - 2023-12-22 07:44:28 --> Database Driver Class Initialized
INFO - 2023-12-22 07:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 07:44:28 --> Parser Class Initialized
INFO - 2023-12-22 07:44:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 07:44:28 --> Pagination Class Initialized
INFO - 2023-12-22 07:44:28 --> Form Validation Class Initialized
INFO - 2023-12-22 07:44:28 --> Controller Class Initialized
INFO - 2023-12-22 07:44:28 --> Model Class Initialized
DEBUG - 2023-12-22 07:44:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 07:44:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:44:28 --> Model Class Initialized
DEBUG - 2023-12-22 07:44:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:44:28 --> Model Class Initialized
DEBUG - 2023-12-22 07:44:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:44:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-12-22 07:44:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:44:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 07:44:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 07:44:28 --> Model Class Initialized
INFO - 2023-12-22 07:44:28 --> Model Class Initialized
INFO - 2023-12-22 07:44:28 --> Model Class Initialized
INFO - 2023-12-22 07:44:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 07:44:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 07:44:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 07:44:29 --> Final output sent to browser
DEBUG - 2023-12-22 07:44:29 --> Total execution time: 0.1610
ERROR - 2023-12-22 07:45:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 07:45:10 --> Config Class Initialized
INFO - 2023-12-22 07:45:10 --> Hooks Class Initialized
DEBUG - 2023-12-22 07:45:10 --> UTF-8 Support Enabled
INFO - 2023-12-22 07:45:10 --> Utf8 Class Initialized
INFO - 2023-12-22 07:45:10 --> URI Class Initialized
INFO - 2023-12-22 07:45:10 --> Router Class Initialized
INFO - 2023-12-22 07:45:10 --> Output Class Initialized
INFO - 2023-12-22 07:45:10 --> Security Class Initialized
DEBUG - 2023-12-22 07:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 07:45:10 --> Input Class Initialized
INFO - 2023-12-22 07:45:10 --> Language Class Initialized
INFO - 2023-12-22 07:45:10 --> Loader Class Initialized
INFO - 2023-12-22 07:45:10 --> Helper loaded: url_helper
INFO - 2023-12-22 07:45:10 --> Helper loaded: file_helper
INFO - 2023-12-22 07:45:10 --> Helper loaded: html_helper
INFO - 2023-12-22 07:45:10 --> Helper loaded: text_helper
INFO - 2023-12-22 07:45:10 --> Helper loaded: form_helper
INFO - 2023-12-22 07:45:10 --> Helper loaded: lang_helper
INFO - 2023-12-22 07:45:10 --> Helper loaded: security_helper
INFO - 2023-12-22 07:45:10 --> Helper loaded: cookie_helper
INFO - 2023-12-22 07:45:10 --> Database Driver Class Initialized
INFO - 2023-12-22 07:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 07:45:10 --> Parser Class Initialized
INFO - 2023-12-22 07:45:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 07:45:10 --> Pagination Class Initialized
INFO - 2023-12-22 07:45:10 --> Form Validation Class Initialized
INFO - 2023-12-22 07:45:10 --> Controller Class Initialized
INFO - 2023-12-22 07:45:10 --> Model Class Initialized
DEBUG - 2023-12-22 07:45:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 07:45:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:45:10 --> Model Class Initialized
DEBUG - 2023-12-22 07:45:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:45:10 --> Model Class Initialized
INFO - 2023-12-22 07:45:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-22 07:45:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:45:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 07:45:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 07:45:10 --> Model Class Initialized
INFO - 2023-12-22 07:45:10 --> Model Class Initialized
INFO - 2023-12-22 07:45:10 --> Model Class Initialized
INFO - 2023-12-22 07:45:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 07:45:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 07:45:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 07:45:11 --> Final output sent to browser
DEBUG - 2023-12-22 07:45:11 --> Total execution time: 0.1512
ERROR - 2023-12-22 07:45:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 07:45:11 --> Config Class Initialized
INFO - 2023-12-22 07:45:11 --> Hooks Class Initialized
DEBUG - 2023-12-22 07:45:11 --> UTF-8 Support Enabled
INFO - 2023-12-22 07:45:11 --> Utf8 Class Initialized
INFO - 2023-12-22 07:45:11 --> URI Class Initialized
INFO - 2023-12-22 07:45:11 --> Router Class Initialized
INFO - 2023-12-22 07:45:11 --> Output Class Initialized
INFO - 2023-12-22 07:45:11 --> Security Class Initialized
DEBUG - 2023-12-22 07:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 07:45:11 --> Input Class Initialized
INFO - 2023-12-22 07:45:11 --> Language Class Initialized
INFO - 2023-12-22 07:45:11 --> Loader Class Initialized
INFO - 2023-12-22 07:45:11 --> Helper loaded: url_helper
INFO - 2023-12-22 07:45:11 --> Helper loaded: file_helper
INFO - 2023-12-22 07:45:11 --> Helper loaded: html_helper
INFO - 2023-12-22 07:45:11 --> Helper loaded: text_helper
INFO - 2023-12-22 07:45:11 --> Helper loaded: form_helper
INFO - 2023-12-22 07:45:11 --> Helper loaded: lang_helper
INFO - 2023-12-22 07:45:11 --> Helper loaded: security_helper
INFO - 2023-12-22 07:45:11 --> Helper loaded: cookie_helper
INFO - 2023-12-22 07:45:11 --> Database Driver Class Initialized
INFO - 2023-12-22 07:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 07:45:11 --> Parser Class Initialized
INFO - 2023-12-22 07:45:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 07:45:11 --> Pagination Class Initialized
INFO - 2023-12-22 07:45:11 --> Form Validation Class Initialized
INFO - 2023-12-22 07:45:11 --> Controller Class Initialized
INFO - 2023-12-22 07:45:11 --> Model Class Initialized
DEBUG - 2023-12-22 07:45:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 07:45:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:45:11 --> Model Class Initialized
DEBUG - 2023-12-22 07:45:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:45:11 --> Model Class Initialized
INFO - 2023-12-22 07:45:11 --> Final output sent to browser
DEBUG - 2023-12-22 07:45:11 --> Total execution time: 0.0409
ERROR - 2023-12-22 07:45:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 07:45:22 --> Config Class Initialized
INFO - 2023-12-22 07:45:22 --> Hooks Class Initialized
DEBUG - 2023-12-22 07:45:22 --> UTF-8 Support Enabled
INFO - 2023-12-22 07:45:22 --> Utf8 Class Initialized
INFO - 2023-12-22 07:45:22 --> URI Class Initialized
INFO - 2023-12-22 07:45:22 --> Router Class Initialized
INFO - 2023-12-22 07:45:22 --> Output Class Initialized
INFO - 2023-12-22 07:45:22 --> Security Class Initialized
DEBUG - 2023-12-22 07:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 07:45:22 --> Input Class Initialized
INFO - 2023-12-22 07:45:22 --> Language Class Initialized
INFO - 2023-12-22 07:45:22 --> Loader Class Initialized
INFO - 2023-12-22 07:45:22 --> Helper loaded: url_helper
INFO - 2023-12-22 07:45:22 --> Helper loaded: file_helper
INFO - 2023-12-22 07:45:22 --> Helper loaded: html_helper
INFO - 2023-12-22 07:45:22 --> Helper loaded: text_helper
INFO - 2023-12-22 07:45:22 --> Helper loaded: form_helper
INFO - 2023-12-22 07:45:22 --> Helper loaded: lang_helper
INFO - 2023-12-22 07:45:22 --> Helper loaded: security_helper
INFO - 2023-12-22 07:45:22 --> Helper loaded: cookie_helper
INFO - 2023-12-22 07:45:22 --> Database Driver Class Initialized
INFO - 2023-12-22 07:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 07:45:22 --> Parser Class Initialized
INFO - 2023-12-22 07:45:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 07:45:22 --> Pagination Class Initialized
INFO - 2023-12-22 07:45:22 --> Form Validation Class Initialized
INFO - 2023-12-22 07:45:22 --> Controller Class Initialized
INFO - 2023-12-22 07:45:22 --> Model Class Initialized
DEBUG - 2023-12-22 07:45:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 07:45:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:45:22 --> Model Class Initialized
DEBUG - 2023-12-22 07:45:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:45:22 --> Model Class Initialized
INFO - 2023-12-22 07:45:22 --> Final output sent to browser
DEBUG - 2023-12-22 07:45:22 --> Total execution time: 0.0808
ERROR - 2023-12-22 07:45:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 07:45:25 --> Config Class Initialized
INFO - 2023-12-22 07:45:25 --> Hooks Class Initialized
DEBUG - 2023-12-22 07:45:25 --> UTF-8 Support Enabled
INFO - 2023-12-22 07:45:25 --> Utf8 Class Initialized
INFO - 2023-12-22 07:45:25 --> URI Class Initialized
INFO - 2023-12-22 07:45:25 --> Router Class Initialized
INFO - 2023-12-22 07:45:25 --> Output Class Initialized
INFO - 2023-12-22 07:45:25 --> Security Class Initialized
DEBUG - 2023-12-22 07:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 07:45:25 --> Input Class Initialized
INFO - 2023-12-22 07:45:25 --> Language Class Initialized
INFO - 2023-12-22 07:45:25 --> Loader Class Initialized
INFO - 2023-12-22 07:45:25 --> Helper loaded: url_helper
INFO - 2023-12-22 07:45:25 --> Helper loaded: file_helper
INFO - 2023-12-22 07:45:25 --> Helper loaded: html_helper
INFO - 2023-12-22 07:45:25 --> Helper loaded: text_helper
INFO - 2023-12-22 07:45:25 --> Helper loaded: form_helper
INFO - 2023-12-22 07:45:25 --> Helper loaded: lang_helper
INFO - 2023-12-22 07:45:25 --> Helper loaded: security_helper
INFO - 2023-12-22 07:45:25 --> Helper loaded: cookie_helper
INFO - 2023-12-22 07:45:25 --> Database Driver Class Initialized
INFO - 2023-12-22 07:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 07:45:25 --> Parser Class Initialized
INFO - 2023-12-22 07:45:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 07:45:25 --> Pagination Class Initialized
INFO - 2023-12-22 07:45:25 --> Form Validation Class Initialized
INFO - 2023-12-22 07:45:25 --> Controller Class Initialized
INFO - 2023-12-22 07:45:25 --> Model Class Initialized
DEBUG - 2023-12-22 07:45:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 07:45:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:45:25 --> Model Class Initialized
DEBUG - 2023-12-22 07:45:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:45:25 --> Model Class Initialized
INFO - 2023-12-22 07:45:25 --> Final output sent to browser
DEBUG - 2023-12-22 07:45:25 --> Total execution time: 0.0764
ERROR - 2023-12-22 07:45:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 07:45:29 --> Config Class Initialized
INFO - 2023-12-22 07:45:29 --> Hooks Class Initialized
DEBUG - 2023-12-22 07:45:29 --> UTF-8 Support Enabled
INFO - 2023-12-22 07:45:29 --> Utf8 Class Initialized
INFO - 2023-12-22 07:45:29 --> URI Class Initialized
INFO - 2023-12-22 07:45:29 --> Router Class Initialized
INFO - 2023-12-22 07:45:29 --> Output Class Initialized
INFO - 2023-12-22 07:45:29 --> Security Class Initialized
DEBUG - 2023-12-22 07:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 07:45:29 --> Input Class Initialized
INFO - 2023-12-22 07:45:29 --> Language Class Initialized
INFO - 2023-12-22 07:45:29 --> Loader Class Initialized
INFO - 2023-12-22 07:45:29 --> Helper loaded: url_helper
INFO - 2023-12-22 07:45:29 --> Helper loaded: file_helper
INFO - 2023-12-22 07:45:29 --> Helper loaded: html_helper
INFO - 2023-12-22 07:45:29 --> Helper loaded: text_helper
INFO - 2023-12-22 07:45:29 --> Helper loaded: form_helper
INFO - 2023-12-22 07:45:29 --> Helper loaded: lang_helper
INFO - 2023-12-22 07:45:29 --> Helper loaded: security_helper
INFO - 2023-12-22 07:45:29 --> Helper loaded: cookie_helper
INFO - 2023-12-22 07:45:29 --> Database Driver Class Initialized
INFO - 2023-12-22 07:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 07:45:29 --> Parser Class Initialized
INFO - 2023-12-22 07:45:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 07:45:29 --> Pagination Class Initialized
INFO - 2023-12-22 07:45:29 --> Form Validation Class Initialized
INFO - 2023-12-22 07:45:29 --> Controller Class Initialized
INFO - 2023-12-22 07:45:29 --> Model Class Initialized
DEBUG - 2023-12-22 07:45:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 07:45:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:45:29 --> Model Class Initialized
DEBUG - 2023-12-22 07:45:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 07:45:29 --> Model Class Initialized
INFO - 2023-12-22 07:45:29 --> Final output sent to browser
DEBUG - 2023-12-22 07:45:29 --> Total execution time: 0.0996
ERROR - 2023-12-22 08:07:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 08:07:12 --> Config Class Initialized
INFO - 2023-12-22 08:07:12 --> Hooks Class Initialized
DEBUG - 2023-12-22 08:07:12 --> UTF-8 Support Enabled
INFO - 2023-12-22 08:07:12 --> Utf8 Class Initialized
INFO - 2023-12-22 08:07:12 --> URI Class Initialized
DEBUG - 2023-12-22 08:07:12 --> No URI present. Default controller set.
INFO - 2023-12-22 08:07:12 --> Router Class Initialized
INFO - 2023-12-22 08:07:12 --> Output Class Initialized
INFO - 2023-12-22 08:07:12 --> Security Class Initialized
DEBUG - 2023-12-22 08:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 08:07:12 --> Input Class Initialized
INFO - 2023-12-22 08:07:12 --> Language Class Initialized
INFO - 2023-12-22 08:07:12 --> Loader Class Initialized
INFO - 2023-12-22 08:07:12 --> Helper loaded: url_helper
INFO - 2023-12-22 08:07:12 --> Helper loaded: file_helper
INFO - 2023-12-22 08:07:12 --> Helper loaded: html_helper
INFO - 2023-12-22 08:07:12 --> Helper loaded: text_helper
INFO - 2023-12-22 08:07:12 --> Helper loaded: form_helper
INFO - 2023-12-22 08:07:12 --> Helper loaded: lang_helper
INFO - 2023-12-22 08:07:12 --> Helper loaded: security_helper
INFO - 2023-12-22 08:07:12 --> Helper loaded: cookie_helper
INFO - 2023-12-22 08:07:12 --> Database Driver Class Initialized
INFO - 2023-12-22 08:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 08:07:12 --> Parser Class Initialized
INFO - 2023-12-22 08:07:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 08:07:12 --> Pagination Class Initialized
INFO - 2023-12-22 08:07:12 --> Form Validation Class Initialized
INFO - 2023-12-22 08:07:12 --> Controller Class Initialized
INFO - 2023-12-22 08:07:12 --> Model Class Initialized
DEBUG - 2023-12-22 08:07:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:07:12 --> Model Class Initialized
DEBUG - 2023-12-22 08:07:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:07:12 --> Model Class Initialized
INFO - 2023-12-22 08:07:12 --> Model Class Initialized
INFO - 2023-12-22 08:07:12 --> Model Class Initialized
INFO - 2023-12-22 08:07:12 --> Model Class Initialized
DEBUG - 2023-12-22 08:07:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 08:07:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:07:12 --> Model Class Initialized
INFO - 2023-12-22 08:07:12 --> Model Class Initialized
INFO - 2023-12-22 08:07:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-22 08:07:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:07:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 08:07:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 08:07:12 --> Model Class Initialized
INFO - 2023-12-22 08:07:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 08:07:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 08:07:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 08:07:12 --> Final output sent to browser
DEBUG - 2023-12-22 08:07:12 --> Total execution time: 0.2138
ERROR - 2023-12-22 08:07:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 08:07:20 --> Config Class Initialized
INFO - 2023-12-22 08:07:20 --> Hooks Class Initialized
DEBUG - 2023-12-22 08:07:20 --> UTF-8 Support Enabled
INFO - 2023-12-22 08:07:20 --> Utf8 Class Initialized
INFO - 2023-12-22 08:07:20 --> URI Class Initialized
INFO - 2023-12-22 08:07:20 --> Router Class Initialized
INFO - 2023-12-22 08:07:20 --> Output Class Initialized
INFO - 2023-12-22 08:07:20 --> Security Class Initialized
DEBUG - 2023-12-22 08:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 08:07:20 --> Input Class Initialized
INFO - 2023-12-22 08:07:20 --> Language Class Initialized
INFO - 2023-12-22 08:07:20 --> Loader Class Initialized
INFO - 2023-12-22 08:07:20 --> Helper loaded: url_helper
INFO - 2023-12-22 08:07:20 --> Helper loaded: file_helper
INFO - 2023-12-22 08:07:20 --> Helper loaded: html_helper
INFO - 2023-12-22 08:07:20 --> Helper loaded: text_helper
INFO - 2023-12-22 08:07:20 --> Helper loaded: form_helper
INFO - 2023-12-22 08:07:20 --> Helper loaded: lang_helper
INFO - 2023-12-22 08:07:20 --> Helper loaded: security_helper
INFO - 2023-12-22 08:07:20 --> Helper loaded: cookie_helper
INFO - 2023-12-22 08:07:20 --> Database Driver Class Initialized
INFO - 2023-12-22 08:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 08:07:20 --> Parser Class Initialized
INFO - 2023-12-22 08:07:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 08:07:20 --> Pagination Class Initialized
INFO - 2023-12-22 08:07:20 --> Form Validation Class Initialized
INFO - 2023-12-22 08:07:20 --> Controller Class Initialized
INFO - 2023-12-22 08:07:20 --> Model Class Initialized
DEBUG - 2023-12-22 08:07:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 08:07:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:07:20 --> Model Class Initialized
DEBUG - 2023-12-22 08:07:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:07:20 --> Model Class Initialized
INFO - 2023-12-22 08:07:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-22 08:07:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:07:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 08:07:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 08:07:20 --> Model Class Initialized
INFO - 2023-12-22 08:07:20 --> Model Class Initialized
INFO - 2023-12-22 08:07:20 --> Model Class Initialized
INFO - 2023-12-22 08:07:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 08:07:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 08:07:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 08:07:20 --> Final output sent to browser
DEBUG - 2023-12-22 08:07:20 --> Total execution time: 0.1411
ERROR - 2023-12-22 08:07:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 08:07:21 --> Config Class Initialized
INFO - 2023-12-22 08:07:21 --> Hooks Class Initialized
DEBUG - 2023-12-22 08:07:21 --> UTF-8 Support Enabled
INFO - 2023-12-22 08:07:21 --> Utf8 Class Initialized
INFO - 2023-12-22 08:07:21 --> URI Class Initialized
INFO - 2023-12-22 08:07:21 --> Router Class Initialized
INFO - 2023-12-22 08:07:21 --> Output Class Initialized
INFO - 2023-12-22 08:07:21 --> Security Class Initialized
DEBUG - 2023-12-22 08:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 08:07:21 --> Input Class Initialized
INFO - 2023-12-22 08:07:21 --> Language Class Initialized
INFO - 2023-12-22 08:07:21 --> Loader Class Initialized
INFO - 2023-12-22 08:07:21 --> Helper loaded: url_helper
INFO - 2023-12-22 08:07:21 --> Helper loaded: file_helper
INFO - 2023-12-22 08:07:21 --> Helper loaded: html_helper
INFO - 2023-12-22 08:07:21 --> Helper loaded: text_helper
INFO - 2023-12-22 08:07:21 --> Helper loaded: form_helper
INFO - 2023-12-22 08:07:21 --> Helper loaded: lang_helper
INFO - 2023-12-22 08:07:21 --> Helper loaded: security_helper
INFO - 2023-12-22 08:07:21 --> Helper loaded: cookie_helper
INFO - 2023-12-22 08:07:21 --> Database Driver Class Initialized
INFO - 2023-12-22 08:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 08:07:21 --> Parser Class Initialized
INFO - 2023-12-22 08:07:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 08:07:21 --> Pagination Class Initialized
INFO - 2023-12-22 08:07:21 --> Form Validation Class Initialized
INFO - 2023-12-22 08:07:21 --> Controller Class Initialized
INFO - 2023-12-22 08:07:21 --> Model Class Initialized
DEBUG - 2023-12-22 08:07:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 08:07:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:07:21 --> Model Class Initialized
DEBUG - 2023-12-22 08:07:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:07:21 --> Model Class Initialized
INFO - 2023-12-22 08:07:21 --> Final output sent to browser
DEBUG - 2023-12-22 08:07:21 --> Total execution time: 0.0438
ERROR - 2023-12-22 08:07:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 08:07:36 --> Config Class Initialized
INFO - 2023-12-22 08:07:36 --> Hooks Class Initialized
DEBUG - 2023-12-22 08:07:36 --> UTF-8 Support Enabled
INFO - 2023-12-22 08:07:36 --> Utf8 Class Initialized
INFO - 2023-12-22 08:07:36 --> URI Class Initialized
INFO - 2023-12-22 08:07:36 --> Router Class Initialized
INFO - 2023-12-22 08:07:36 --> Output Class Initialized
INFO - 2023-12-22 08:07:36 --> Security Class Initialized
DEBUG - 2023-12-22 08:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 08:07:36 --> Input Class Initialized
INFO - 2023-12-22 08:07:36 --> Language Class Initialized
INFO - 2023-12-22 08:07:36 --> Loader Class Initialized
INFO - 2023-12-22 08:07:36 --> Helper loaded: url_helper
INFO - 2023-12-22 08:07:36 --> Helper loaded: file_helper
INFO - 2023-12-22 08:07:36 --> Helper loaded: html_helper
INFO - 2023-12-22 08:07:36 --> Helper loaded: text_helper
INFO - 2023-12-22 08:07:36 --> Helper loaded: form_helper
INFO - 2023-12-22 08:07:36 --> Helper loaded: lang_helper
INFO - 2023-12-22 08:07:36 --> Helper loaded: security_helper
INFO - 2023-12-22 08:07:36 --> Helper loaded: cookie_helper
INFO - 2023-12-22 08:07:36 --> Database Driver Class Initialized
INFO - 2023-12-22 08:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 08:07:36 --> Parser Class Initialized
INFO - 2023-12-22 08:07:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 08:07:36 --> Pagination Class Initialized
INFO - 2023-12-22 08:07:36 --> Form Validation Class Initialized
INFO - 2023-12-22 08:07:36 --> Controller Class Initialized
INFO - 2023-12-22 08:07:36 --> Model Class Initialized
DEBUG - 2023-12-22 08:07:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 08:07:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:07:36 --> Model Class Initialized
DEBUG - 2023-12-22 08:07:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:07:36 --> Model Class Initialized
DEBUG - 2023-12-22 08:07:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:07:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-12-22 08:07:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:07:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 08:07:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 08:07:36 --> Model Class Initialized
INFO - 2023-12-22 08:07:36 --> Model Class Initialized
INFO - 2023-12-22 08:07:36 --> Model Class Initialized
INFO - 2023-12-22 08:07:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 08:07:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 08:07:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 08:07:36 --> Final output sent to browser
DEBUG - 2023-12-22 08:07:36 --> Total execution time: 0.1635
ERROR - 2023-12-22 08:11:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 08:11:12 --> Config Class Initialized
INFO - 2023-12-22 08:11:12 --> Hooks Class Initialized
DEBUG - 2023-12-22 08:11:12 --> UTF-8 Support Enabled
INFO - 2023-12-22 08:11:12 --> Utf8 Class Initialized
INFO - 2023-12-22 08:11:12 --> URI Class Initialized
INFO - 2023-12-22 08:11:12 --> Router Class Initialized
INFO - 2023-12-22 08:11:12 --> Output Class Initialized
INFO - 2023-12-22 08:11:12 --> Security Class Initialized
DEBUG - 2023-12-22 08:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 08:11:12 --> Input Class Initialized
INFO - 2023-12-22 08:11:12 --> Language Class Initialized
INFO - 2023-12-22 08:11:12 --> Loader Class Initialized
INFO - 2023-12-22 08:11:12 --> Helper loaded: url_helper
INFO - 2023-12-22 08:11:12 --> Helper loaded: file_helper
INFO - 2023-12-22 08:11:12 --> Helper loaded: html_helper
INFO - 2023-12-22 08:11:12 --> Helper loaded: text_helper
INFO - 2023-12-22 08:11:12 --> Helper loaded: form_helper
INFO - 2023-12-22 08:11:12 --> Helper loaded: lang_helper
INFO - 2023-12-22 08:11:12 --> Helper loaded: security_helper
INFO - 2023-12-22 08:11:12 --> Helper loaded: cookie_helper
INFO - 2023-12-22 08:11:12 --> Database Driver Class Initialized
INFO - 2023-12-22 08:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 08:11:12 --> Parser Class Initialized
INFO - 2023-12-22 08:11:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 08:11:12 --> Pagination Class Initialized
INFO - 2023-12-22 08:11:12 --> Form Validation Class Initialized
INFO - 2023-12-22 08:11:12 --> Controller Class Initialized
INFO - 2023-12-22 08:11:12 --> Model Class Initialized
DEBUG - 2023-12-22 08:11:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 08:11:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:11:12 --> Model Class Initialized
DEBUG - 2023-12-22 08:11:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:11:12 --> Model Class Initialized
INFO - 2023-12-22 08:11:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-22 08:11:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:11:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 08:11:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 08:11:12 --> Model Class Initialized
INFO - 2023-12-22 08:11:12 --> Model Class Initialized
INFO - 2023-12-22 08:11:12 --> Model Class Initialized
INFO - 2023-12-22 08:11:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 08:11:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 08:11:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 08:11:12 --> Final output sent to browser
DEBUG - 2023-12-22 08:11:12 --> Total execution time: 0.1459
ERROR - 2023-12-22 08:11:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 08:11:13 --> Config Class Initialized
INFO - 2023-12-22 08:11:13 --> Hooks Class Initialized
DEBUG - 2023-12-22 08:11:13 --> UTF-8 Support Enabled
INFO - 2023-12-22 08:11:13 --> Utf8 Class Initialized
INFO - 2023-12-22 08:11:13 --> URI Class Initialized
INFO - 2023-12-22 08:11:13 --> Router Class Initialized
INFO - 2023-12-22 08:11:13 --> Output Class Initialized
INFO - 2023-12-22 08:11:13 --> Security Class Initialized
DEBUG - 2023-12-22 08:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 08:11:13 --> Input Class Initialized
INFO - 2023-12-22 08:11:13 --> Language Class Initialized
INFO - 2023-12-22 08:11:13 --> Loader Class Initialized
INFO - 2023-12-22 08:11:13 --> Helper loaded: url_helper
INFO - 2023-12-22 08:11:13 --> Helper loaded: file_helper
INFO - 2023-12-22 08:11:13 --> Helper loaded: html_helper
INFO - 2023-12-22 08:11:13 --> Helper loaded: text_helper
INFO - 2023-12-22 08:11:13 --> Helper loaded: form_helper
INFO - 2023-12-22 08:11:13 --> Helper loaded: lang_helper
INFO - 2023-12-22 08:11:13 --> Helper loaded: security_helper
INFO - 2023-12-22 08:11:13 --> Helper loaded: cookie_helper
INFO - 2023-12-22 08:11:13 --> Database Driver Class Initialized
INFO - 2023-12-22 08:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 08:11:13 --> Parser Class Initialized
INFO - 2023-12-22 08:11:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 08:11:13 --> Pagination Class Initialized
INFO - 2023-12-22 08:11:13 --> Form Validation Class Initialized
INFO - 2023-12-22 08:11:13 --> Controller Class Initialized
INFO - 2023-12-22 08:11:13 --> Model Class Initialized
DEBUG - 2023-12-22 08:11:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 08:11:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:11:13 --> Model Class Initialized
DEBUG - 2023-12-22 08:11:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:11:13 --> Model Class Initialized
INFO - 2023-12-22 08:11:13 --> Final output sent to browser
DEBUG - 2023-12-22 08:11:13 --> Total execution time: 0.0405
ERROR - 2023-12-22 08:11:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 08:11:13 --> Config Class Initialized
INFO - 2023-12-22 08:11:13 --> Hooks Class Initialized
DEBUG - 2023-12-22 08:11:13 --> UTF-8 Support Enabled
INFO - 2023-12-22 08:11:13 --> Utf8 Class Initialized
INFO - 2023-12-22 08:11:13 --> URI Class Initialized
DEBUG - 2023-12-22 08:11:13 --> No URI present. Default controller set.
INFO - 2023-12-22 08:11:13 --> Router Class Initialized
INFO - 2023-12-22 08:11:13 --> Output Class Initialized
INFO - 2023-12-22 08:11:13 --> Security Class Initialized
DEBUG - 2023-12-22 08:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 08:11:13 --> Input Class Initialized
INFO - 2023-12-22 08:11:13 --> Language Class Initialized
INFO - 2023-12-22 08:11:13 --> Loader Class Initialized
INFO - 2023-12-22 08:11:13 --> Helper loaded: url_helper
INFO - 2023-12-22 08:11:13 --> Helper loaded: file_helper
INFO - 2023-12-22 08:11:13 --> Helper loaded: html_helper
INFO - 2023-12-22 08:11:13 --> Helper loaded: text_helper
INFO - 2023-12-22 08:11:13 --> Helper loaded: form_helper
INFO - 2023-12-22 08:11:13 --> Helper loaded: lang_helper
INFO - 2023-12-22 08:11:13 --> Helper loaded: security_helper
INFO - 2023-12-22 08:11:13 --> Helper loaded: cookie_helper
INFO - 2023-12-22 08:11:13 --> Database Driver Class Initialized
INFO - 2023-12-22 08:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 08:11:13 --> Parser Class Initialized
INFO - 2023-12-22 08:11:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 08:11:13 --> Pagination Class Initialized
INFO - 2023-12-22 08:11:13 --> Form Validation Class Initialized
INFO - 2023-12-22 08:11:13 --> Controller Class Initialized
INFO - 2023-12-22 08:11:13 --> Model Class Initialized
DEBUG - 2023-12-22 08:11:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:11:13 --> Model Class Initialized
DEBUG - 2023-12-22 08:11:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:11:13 --> Model Class Initialized
INFO - 2023-12-22 08:11:13 --> Model Class Initialized
INFO - 2023-12-22 08:11:13 --> Model Class Initialized
INFO - 2023-12-22 08:11:13 --> Model Class Initialized
DEBUG - 2023-12-22 08:11:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 08:11:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:11:13 --> Model Class Initialized
INFO - 2023-12-22 08:11:13 --> Model Class Initialized
INFO - 2023-12-22 08:11:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-22 08:11:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:11:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 08:11:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 08:11:13 --> Model Class Initialized
INFO - 2023-12-22 08:11:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 08:11:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 08:11:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 08:11:13 --> Final output sent to browser
DEBUG - 2023-12-22 08:11:13 --> Total execution time: 0.2134
ERROR - 2023-12-22 08:11:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 08:11:20 --> Config Class Initialized
INFO - 2023-12-22 08:11:20 --> Hooks Class Initialized
DEBUG - 2023-12-22 08:11:20 --> UTF-8 Support Enabled
INFO - 2023-12-22 08:11:20 --> Utf8 Class Initialized
INFO - 2023-12-22 08:11:20 --> URI Class Initialized
INFO - 2023-12-22 08:11:20 --> Router Class Initialized
INFO - 2023-12-22 08:11:20 --> Output Class Initialized
INFO - 2023-12-22 08:11:20 --> Security Class Initialized
DEBUG - 2023-12-22 08:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 08:11:20 --> Input Class Initialized
INFO - 2023-12-22 08:11:20 --> Language Class Initialized
INFO - 2023-12-22 08:11:20 --> Loader Class Initialized
INFO - 2023-12-22 08:11:20 --> Helper loaded: url_helper
INFO - 2023-12-22 08:11:20 --> Helper loaded: file_helper
INFO - 2023-12-22 08:11:20 --> Helper loaded: html_helper
INFO - 2023-12-22 08:11:20 --> Helper loaded: text_helper
INFO - 2023-12-22 08:11:20 --> Helper loaded: form_helper
INFO - 2023-12-22 08:11:20 --> Helper loaded: lang_helper
INFO - 2023-12-22 08:11:20 --> Helper loaded: security_helper
INFO - 2023-12-22 08:11:20 --> Helper loaded: cookie_helper
INFO - 2023-12-22 08:11:20 --> Database Driver Class Initialized
INFO - 2023-12-22 08:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 08:11:20 --> Parser Class Initialized
INFO - 2023-12-22 08:11:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 08:11:20 --> Pagination Class Initialized
INFO - 2023-12-22 08:11:20 --> Form Validation Class Initialized
INFO - 2023-12-22 08:11:20 --> Controller Class Initialized
INFO - 2023-12-22 08:11:20 --> Model Class Initialized
DEBUG - 2023-12-22 08:11:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 08:11:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:11:20 --> Model Class Initialized
DEBUG - 2023-12-22 08:11:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:11:20 --> Model Class Initialized
INFO - 2023-12-22 08:11:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-22 08:11:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:11:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 08:11:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 08:11:20 --> Model Class Initialized
INFO - 2023-12-22 08:11:20 --> Model Class Initialized
INFO - 2023-12-22 08:11:20 --> Model Class Initialized
INFO - 2023-12-22 08:11:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 08:11:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 08:11:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 08:11:20 --> Final output sent to browser
DEBUG - 2023-12-22 08:11:20 --> Total execution time: 0.1481
ERROR - 2023-12-22 08:11:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 08:11:21 --> Config Class Initialized
INFO - 2023-12-22 08:11:21 --> Hooks Class Initialized
DEBUG - 2023-12-22 08:11:21 --> UTF-8 Support Enabled
INFO - 2023-12-22 08:11:21 --> Utf8 Class Initialized
INFO - 2023-12-22 08:11:21 --> URI Class Initialized
INFO - 2023-12-22 08:11:21 --> Router Class Initialized
INFO - 2023-12-22 08:11:21 --> Output Class Initialized
INFO - 2023-12-22 08:11:21 --> Security Class Initialized
DEBUG - 2023-12-22 08:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 08:11:21 --> Input Class Initialized
INFO - 2023-12-22 08:11:21 --> Language Class Initialized
INFO - 2023-12-22 08:11:21 --> Loader Class Initialized
INFO - 2023-12-22 08:11:21 --> Helper loaded: url_helper
INFO - 2023-12-22 08:11:21 --> Helper loaded: file_helper
INFO - 2023-12-22 08:11:21 --> Helper loaded: html_helper
INFO - 2023-12-22 08:11:21 --> Helper loaded: text_helper
INFO - 2023-12-22 08:11:21 --> Helper loaded: form_helper
INFO - 2023-12-22 08:11:21 --> Helper loaded: lang_helper
INFO - 2023-12-22 08:11:21 --> Helper loaded: security_helper
INFO - 2023-12-22 08:11:21 --> Helper loaded: cookie_helper
INFO - 2023-12-22 08:11:21 --> Database Driver Class Initialized
INFO - 2023-12-22 08:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 08:11:21 --> Parser Class Initialized
INFO - 2023-12-22 08:11:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 08:11:21 --> Pagination Class Initialized
INFO - 2023-12-22 08:11:21 --> Form Validation Class Initialized
INFO - 2023-12-22 08:11:21 --> Controller Class Initialized
INFO - 2023-12-22 08:11:21 --> Model Class Initialized
DEBUG - 2023-12-22 08:11:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 08:11:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:11:21 --> Model Class Initialized
DEBUG - 2023-12-22 08:11:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:11:21 --> Model Class Initialized
INFO - 2023-12-22 08:11:21 --> Final output sent to browser
DEBUG - 2023-12-22 08:11:21 --> Total execution time: 0.0408
ERROR - 2023-12-22 08:11:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 08:11:29 --> Config Class Initialized
INFO - 2023-12-22 08:11:29 --> Hooks Class Initialized
DEBUG - 2023-12-22 08:11:29 --> UTF-8 Support Enabled
INFO - 2023-12-22 08:11:29 --> Utf8 Class Initialized
INFO - 2023-12-22 08:11:29 --> URI Class Initialized
INFO - 2023-12-22 08:11:29 --> Router Class Initialized
INFO - 2023-12-22 08:11:29 --> Output Class Initialized
INFO - 2023-12-22 08:11:29 --> Security Class Initialized
DEBUG - 2023-12-22 08:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 08:11:29 --> Input Class Initialized
INFO - 2023-12-22 08:11:29 --> Language Class Initialized
INFO - 2023-12-22 08:11:29 --> Loader Class Initialized
INFO - 2023-12-22 08:11:29 --> Helper loaded: url_helper
INFO - 2023-12-22 08:11:29 --> Helper loaded: file_helper
INFO - 2023-12-22 08:11:29 --> Helper loaded: html_helper
INFO - 2023-12-22 08:11:29 --> Helper loaded: text_helper
INFO - 2023-12-22 08:11:29 --> Helper loaded: form_helper
INFO - 2023-12-22 08:11:29 --> Helper loaded: lang_helper
INFO - 2023-12-22 08:11:29 --> Helper loaded: security_helper
INFO - 2023-12-22 08:11:29 --> Helper loaded: cookie_helper
INFO - 2023-12-22 08:11:29 --> Database Driver Class Initialized
INFO - 2023-12-22 08:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 08:11:29 --> Parser Class Initialized
INFO - 2023-12-22 08:11:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 08:11:29 --> Pagination Class Initialized
INFO - 2023-12-22 08:11:29 --> Form Validation Class Initialized
INFO - 2023-12-22 08:11:29 --> Controller Class Initialized
INFO - 2023-12-22 08:11:29 --> Model Class Initialized
DEBUG - 2023-12-22 08:11:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 08:11:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:11:29 --> Model Class Initialized
DEBUG - 2023-12-22 08:11:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:11:29 --> Model Class Initialized
DEBUG - 2023-12-22 08:11:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:11:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-12-22 08:11:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:11:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 08:11:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 08:11:29 --> Model Class Initialized
INFO - 2023-12-22 08:11:29 --> Model Class Initialized
INFO - 2023-12-22 08:11:29 --> Model Class Initialized
INFO - 2023-12-22 08:11:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 08:11:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 08:11:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 08:11:29 --> Final output sent to browser
DEBUG - 2023-12-22 08:11:29 --> Total execution time: 0.1643
ERROR - 2023-12-22 08:18:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 08:18:38 --> Config Class Initialized
INFO - 2023-12-22 08:18:38 --> Hooks Class Initialized
DEBUG - 2023-12-22 08:18:38 --> UTF-8 Support Enabled
INFO - 2023-12-22 08:18:38 --> Utf8 Class Initialized
INFO - 2023-12-22 08:18:38 --> URI Class Initialized
DEBUG - 2023-12-22 08:18:38 --> No URI present. Default controller set.
INFO - 2023-12-22 08:18:38 --> Router Class Initialized
INFO - 2023-12-22 08:18:38 --> Output Class Initialized
INFO - 2023-12-22 08:18:38 --> Security Class Initialized
DEBUG - 2023-12-22 08:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 08:18:38 --> Input Class Initialized
INFO - 2023-12-22 08:18:38 --> Language Class Initialized
INFO - 2023-12-22 08:18:38 --> Loader Class Initialized
INFO - 2023-12-22 08:18:38 --> Helper loaded: url_helper
INFO - 2023-12-22 08:18:38 --> Helper loaded: file_helper
INFO - 2023-12-22 08:18:38 --> Helper loaded: html_helper
INFO - 2023-12-22 08:18:38 --> Helper loaded: text_helper
INFO - 2023-12-22 08:18:38 --> Helper loaded: form_helper
INFO - 2023-12-22 08:18:38 --> Helper loaded: lang_helper
INFO - 2023-12-22 08:18:38 --> Helper loaded: security_helper
INFO - 2023-12-22 08:18:38 --> Helper loaded: cookie_helper
INFO - 2023-12-22 08:18:38 --> Database Driver Class Initialized
INFO - 2023-12-22 08:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 08:18:38 --> Parser Class Initialized
INFO - 2023-12-22 08:18:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 08:18:38 --> Pagination Class Initialized
INFO - 2023-12-22 08:18:38 --> Form Validation Class Initialized
INFO - 2023-12-22 08:18:38 --> Controller Class Initialized
INFO - 2023-12-22 08:18:38 --> Model Class Initialized
DEBUG - 2023-12-22 08:18:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:18:38 --> Model Class Initialized
DEBUG - 2023-12-22 08:18:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:18:38 --> Model Class Initialized
INFO - 2023-12-22 08:18:38 --> Model Class Initialized
INFO - 2023-12-22 08:18:38 --> Model Class Initialized
INFO - 2023-12-22 08:18:38 --> Model Class Initialized
DEBUG - 2023-12-22 08:18:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 08:18:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:18:38 --> Model Class Initialized
INFO - 2023-12-22 08:18:38 --> Model Class Initialized
INFO - 2023-12-22 08:18:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-22 08:18:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:18:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 08:18:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 08:18:38 --> Model Class Initialized
INFO - 2023-12-22 08:18:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 08:18:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 08:18:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 08:18:38 --> Final output sent to browser
DEBUG - 2023-12-22 08:18:38 --> Total execution time: 0.2212
ERROR - 2023-12-22 08:20:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 08:20:29 --> Config Class Initialized
INFO - 2023-12-22 08:20:29 --> Hooks Class Initialized
DEBUG - 2023-12-22 08:20:29 --> UTF-8 Support Enabled
INFO - 2023-12-22 08:20:29 --> Utf8 Class Initialized
INFO - 2023-12-22 08:20:29 --> URI Class Initialized
INFO - 2023-12-22 08:20:29 --> Router Class Initialized
INFO - 2023-12-22 08:20:29 --> Output Class Initialized
INFO - 2023-12-22 08:20:29 --> Security Class Initialized
DEBUG - 2023-12-22 08:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 08:20:29 --> Input Class Initialized
INFO - 2023-12-22 08:20:29 --> Language Class Initialized
INFO - 2023-12-22 08:20:29 --> Loader Class Initialized
INFO - 2023-12-22 08:20:29 --> Helper loaded: url_helper
INFO - 2023-12-22 08:20:29 --> Helper loaded: file_helper
INFO - 2023-12-22 08:20:29 --> Helper loaded: html_helper
INFO - 2023-12-22 08:20:29 --> Helper loaded: text_helper
INFO - 2023-12-22 08:20:29 --> Helper loaded: form_helper
INFO - 2023-12-22 08:20:29 --> Helper loaded: lang_helper
INFO - 2023-12-22 08:20:29 --> Helper loaded: security_helper
INFO - 2023-12-22 08:20:29 --> Helper loaded: cookie_helper
INFO - 2023-12-22 08:20:29 --> Database Driver Class Initialized
INFO - 2023-12-22 08:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 08:20:29 --> Parser Class Initialized
INFO - 2023-12-22 08:20:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 08:20:29 --> Pagination Class Initialized
INFO - 2023-12-22 08:20:29 --> Form Validation Class Initialized
INFO - 2023-12-22 08:20:29 --> Controller Class Initialized
INFO - 2023-12-22 08:20:29 --> Model Class Initialized
DEBUG - 2023-12-22 08:20:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 08:20:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:20:29 --> Model Class Initialized
DEBUG - 2023-12-22 08:20:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:20:29 --> Model Class Initialized
INFO - 2023-12-22 08:20:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-22 08:20:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:20:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 08:20:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 08:20:29 --> Model Class Initialized
INFO - 2023-12-22 08:20:29 --> Model Class Initialized
INFO - 2023-12-22 08:20:29 --> Model Class Initialized
INFO - 2023-12-22 08:20:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 08:20:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 08:20:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 08:20:30 --> Final output sent to browser
DEBUG - 2023-12-22 08:20:30 --> Total execution time: 0.1465
ERROR - 2023-12-22 08:20:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 08:20:31 --> Config Class Initialized
INFO - 2023-12-22 08:20:31 --> Hooks Class Initialized
DEBUG - 2023-12-22 08:20:31 --> UTF-8 Support Enabled
INFO - 2023-12-22 08:20:31 --> Utf8 Class Initialized
INFO - 2023-12-22 08:20:31 --> URI Class Initialized
INFO - 2023-12-22 08:20:31 --> Router Class Initialized
INFO - 2023-12-22 08:20:31 --> Output Class Initialized
INFO - 2023-12-22 08:20:31 --> Security Class Initialized
DEBUG - 2023-12-22 08:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 08:20:31 --> Input Class Initialized
INFO - 2023-12-22 08:20:31 --> Language Class Initialized
INFO - 2023-12-22 08:20:31 --> Loader Class Initialized
INFO - 2023-12-22 08:20:31 --> Helper loaded: url_helper
INFO - 2023-12-22 08:20:31 --> Helper loaded: file_helper
INFO - 2023-12-22 08:20:31 --> Helper loaded: html_helper
INFO - 2023-12-22 08:20:31 --> Helper loaded: text_helper
INFO - 2023-12-22 08:20:31 --> Helper loaded: form_helper
INFO - 2023-12-22 08:20:31 --> Helper loaded: lang_helper
INFO - 2023-12-22 08:20:31 --> Helper loaded: security_helper
INFO - 2023-12-22 08:20:31 --> Helper loaded: cookie_helper
INFO - 2023-12-22 08:20:31 --> Database Driver Class Initialized
INFO - 2023-12-22 08:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 08:20:31 --> Parser Class Initialized
INFO - 2023-12-22 08:20:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 08:20:31 --> Pagination Class Initialized
INFO - 2023-12-22 08:20:31 --> Form Validation Class Initialized
INFO - 2023-12-22 08:20:31 --> Controller Class Initialized
INFO - 2023-12-22 08:20:31 --> Model Class Initialized
DEBUG - 2023-12-22 08:20:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 08:20:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:20:31 --> Model Class Initialized
DEBUG - 2023-12-22 08:20:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:20:31 --> Model Class Initialized
INFO - 2023-12-22 08:20:31 --> Final output sent to browser
DEBUG - 2023-12-22 08:20:31 --> Total execution time: 0.0475
ERROR - 2023-12-22 08:20:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 08:20:37 --> Config Class Initialized
INFO - 2023-12-22 08:20:37 --> Hooks Class Initialized
DEBUG - 2023-12-22 08:20:37 --> UTF-8 Support Enabled
INFO - 2023-12-22 08:20:37 --> Utf8 Class Initialized
INFO - 2023-12-22 08:20:37 --> URI Class Initialized
DEBUG - 2023-12-22 08:20:37 --> No URI present. Default controller set.
INFO - 2023-12-22 08:20:37 --> Router Class Initialized
INFO - 2023-12-22 08:20:37 --> Output Class Initialized
INFO - 2023-12-22 08:20:37 --> Security Class Initialized
DEBUG - 2023-12-22 08:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 08:20:37 --> Input Class Initialized
INFO - 2023-12-22 08:20:37 --> Language Class Initialized
INFO - 2023-12-22 08:20:37 --> Loader Class Initialized
INFO - 2023-12-22 08:20:37 --> Helper loaded: url_helper
INFO - 2023-12-22 08:20:37 --> Helper loaded: file_helper
INFO - 2023-12-22 08:20:37 --> Helper loaded: html_helper
INFO - 2023-12-22 08:20:37 --> Helper loaded: text_helper
INFO - 2023-12-22 08:20:37 --> Helper loaded: form_helper
INFO - 2023-12-22 08:20:37 --> Helper loaded: lang_helper
INFO - 2023-12-22 08:20:37 --> Helper loaded: security_helper
INFO - 2023-12-22 08:20:37 --> Helper loaded: cookie_helper
INFO - 2023-12-22 08:20:37 --> Database Driver Class Initialized
INFO - 2023-12-22 08:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 08:20:37 --> Parser Class Initialized
INFO - 2023-12-22 08:20:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 08:20:37 --> Pagination Class Initialized
INFO - 2023-12-22 08:20:37 --> Form Validation Class Initialized
INFO - 2023-12-22 08:20:37 --> Controller Class Initialized
INFO - 2023-12-22 08:20:37 --> Model Class Initialized
DEBUG - 2023-12-22 08:20:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:20:37 --> Model Class Initialized
DEBUG - 2023-12-22 08:20:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:20:37 --> Model Class Initialized
INFO - 2023-12-22 08:20:37 --> Model Class Initialized
INFO - 2023-12-22 08:20:37 --> Model Class Initialized
INFO - 2023-12-22 08:20:37 --> Model Class Initialized
DEBUG - 2023-12-22 08:20:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 08:20:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:20:37 --> Model Class Initialized
INFO - 2023-12-22 08:20:37 --> Model Class Initialized
INFO - 2023-12-22 08:20:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-22 08:20:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 08:20:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 08:20:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 08:20:37 --> Model Class Initialized
INFO - 2023-12-22 08:20:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 08:20:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 08:20:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 08:20:37 --> Final output sent to browser
DEBUG - 2023-12-22 08:20:37 --> Total execution time: 0.2319
ERROR - 2023-12-22 10:20:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 10:20:35 --> Config Class Initialized
INFO - 2023-12-22 10:20:35 --> Hooks Class Initialized
DEBUG - 2023-12-22 10:20:35 --> UTF-8 Support Enabled
INFO - 2023-12-22 10:20:35 --> Utf8 Class Initialized
INFO - 2023-12-22 10:20:35 --> URI Class Initialized
INFO - 2023-12-22 10:20:35 --> Router Class Initialized
INFO - 2023-12-22 10:20:35 --> Output Class Initialized
INFO - 2023-12-22 10:20:35 --> Security Class Initialized
DEBUG - 2023-12-22 10:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 10:20:35 --> Input Class Initialized
INFO - 2023-12-22 10:20:35 --> Language Class Initialized
ERROR - 2023-12-22 10:20:35 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-12-22 11:55:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 11:55:20 --> Config Class Initialized
INFO - 2023-12-22 11:55:20 --> Hooks Class Initialized
DEBUG - 2023-12-22 11:55:20 --> UTF-8 Support Enabled
INFO - 2023-12-22 11:55:20 --> Utf8 Class Initialized
INFO - 2023-12-22 11:55:20 --> URI Class Initialized
DEBUG - 2023-12-22 11:55:20 --> No URI present. Default controller set.
INFO - 2023-12-22 11:55:20 --> Router Class Initialized
INFO - 2023-12-22 11:55:20 --> Output Class Initialized
INFO - 2023-12-22 11:55:20 --> Security Class Initialized
DEBUG - 2023-12-22 11:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 11:55:20 --> Input Class Initialized
INFO - 2023-12-22 11:55:20 --> Language Class Initialized
INFO - 2023-12-22 11:55:20 --> Loader Class Initialized
INFO - 2023-12-22 11:55:20 --> Helper loaded: url_helper
INFO - 2023-12-22 11:55:20 --> Helper loaded: file_helper
INFO - 2023-12-22 11:55:20 --> Helper loaded: html_helper
INFO - 2023-12-22 11:55:20 --> Helper loaded: text_helper
INFO - 2023-12-22 11:55:20 --> Helper loaded: form_helper
INFO - 2023-12-22 11:55:20 --> Helper loaded: lang_helper
INFO - 2023-12-22 11:55:20 --> Helper loaded: security_helper
INFO - 2023-12-22 11:55:20 --> Helper loaded: cookie_helper
INFO - 2023-12-22 11:55:20 --> Database Driver Class Initialized
INFO - 2023-12-22 11:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 11:55:20 --> Parser Class Initialized
INFO - 2023-12-22 11:55:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 11:55:20 --> Pagination Class Initialized
INFO - 2023-12-22 11:55:20 --> Form Validation Class Initialized
INFO - 2023-12-22 11:55:20 --> Controller Class Initialized
INFO - 2023-12-22 11:55:20 --> Model Class Initialized
DEBUG - 2023-12-22 11:55:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-22 11:55:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 11:55:20 --> Config Class Initialized
INFO - 2023-12-22 11:55:20 --> Hooks Class Initialized
DEBUG - 2023-12-22 11:55:20 --> UTF-8 Support Enabled
INFO - 2023-12-22 11:55:20 --> Utf8 Class Initialized
INFO - 2023-12-22 11:55:20 --> URI Class Initialized
INFO - 2023-12-22 11:55:20 --> Router Class Initialized
INFO - 2023-12-22 11:55:20 --> Output Class Initialized
INFO - 2023-12-22 11:55:20 --> Security Class Initialized
DEBUG - 2023-12-22 11:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 11:55:20 --> Input Class Initialized
INFO - 2023-12-22 11:55:20 --> Language Class Initialized
INFO - 2023-12-22 11:55:20 --> Loader Class Initialized
INFO - 2023-12-22 11:55:20 --> Helper loaded: url_helper
INFO - 2023-12-22 11:55:20 --> Helper loaded: file_helper
INFO - 2023-12-22 11:55:20 --> Helper loaded: html_helper
INFO - 2023-12-22 11:55:20 --> Helper loaded: text_helper
INFO - 2023-12-22 11:55:20 --> Helper loaded: form_helper
INFO - 2023-12-22 11:55:20 --> Helper loaded: lang_helper
INFO - 2023-12-22 11:55:20 --> Helper loaded: security_helper
INFO - 2023-12-22 11:55:20 --> Helper loaded: cookie_helper
INFO - 2023-12-22 11:55:20 --> Database Driver Class Initialized
INFO - 2023-12-22 11:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 11:55:20 --> Parser Class Initialized
INFO - 2023-12-22 11:55:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 11:55:20 --> Pagination Class Initialized
INFO - 2023-12-22 11:55:20 --> Form Validation Class Initialized
INFO - 2023-12-22 11:55:20 --> Controller Class Initialized
INFO - 2023-12-22 11:55:20 --> Model Class Initialized
DEBUG - 2023-12-22 11:55:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 11:55:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-22 11:55:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 11:55:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 11:55:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 11:55:20 --> Model Class Initialized
INFO - 2023-12-22 11:55:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 11:55:20 --> Final output sent to browser
DEBUG - 2023-12-22 11:55:20 --> Total execution time: 0.0315
ERROR - 2023-12-22 11:56:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 11:56:00 --> Config Class Initialized
INFO - 2023-12-22 11:56:00 --> Hooks Class Initialized
DEBUG - 2023-12-22 11:56:00 --> UTF-8 Support Enabled
INFO - 2023-12-22 11:56:00 --> Utf8 Class Initialized
INFO - 2023-12-22 11:56:00 --> URI Class Initialized
INFO - 2023-12-22 11:56:00 --> Router Class Initialized
INFO - 2023-12-22 11:56:00 --> Output Class Initialized
INFO - 2023-12-22 11:56:00 --> Security Class Initialized
DEBUG - 2023-12-22 11:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 11:56:00 --> Input Class Initialized
INFO - 2023-12-22 11:56:00 --> Language Class Initialized
INFO - 2023-12-22 11:56:00 --> Loader Class Initialized
INFO - 2023-12-22 11:56:00 --> Helper loaded: url_helper
INFO - 2023-12-22 11:56:00 --> Helper loaded: file_helper
INFO - 2023-12-22 11:56:00 --> Helper loaded: html_helper
INFO - 2023-12-22 11:56:00 --> Helper loaded: text_helper
INFO - 2023-12-22 11:56:00 --> Helper loaded: form_helper
INFO - 2023-12-22 11:56:00 --> Helper loaded: lang_helper
INFO - 2023-12-22 11:56:00 --> Helper loaded: security_helper
INFO - 2023-12-22 11:56:00 --> Helper loaded: cookie_helper
INFO - 2023-12-22 11:56:00 --> Database Driver Class Initialized
INFO - 2023-12-22 11:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 11:56:00 --> Parser Class Initialized
INFO - 2023-12-22 11:56:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 11:56:00 --> Pagination Class Initialized
INFO - 2023-12-22 11:56:00 --> Form Validation Class Initialized
INFO - 2023-12-22 11:56:00 --> Controller Class Initialized
INFO - 2023-12-22 11:56:00 --> Model Class Initialized
DEBUG - 2023-12-22 11:56:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 11:56:00 --> Model Class Initialized
INFO - 2023-12-22 11:56:00 --> Final output sent to browser
DEBUG - 2023-12-22 11:56:00 --> Total execution time: 0.0204
ERROR - 2023-12-22 11:56:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 11:56:00 --> Config Class Initialized
INFO - 2023-12-22 11:56:00 --> Hooks Class Initialized
DEBUG - 2023-12-22 11:56:00 --> UTF-8 Support Enabled
INFO - 2023-12-22 11:56:00 --> Utf8 Class Initialized
INFO - 2023-12-22 11:56:00 --> URI Class Initialized
DEBUG - 2023-12-22 11:56:00 --> No URI present. Default controller set.
INFO - 2023-12-22 11:56:00 --> Router Class Initialized
INFO - 2023-12-22 11:56:00 --> Output Class Initialized
INFO - 2023-12-22 11:56:00 --> Security Class Initialized
DEBUG - 2023-12-22 11:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 11:56:00 --> Input Class Initialized
INFO - 2023-12-22 11:56:00 --> Language Class Initialized
INFO - 2023-12-22 11:56:00 --> Loader Class Initialized
INFO - 2023-12-22 11:56:00 --> Helper loaded: url_helper
INFO - 2023-12-22 11:56:00 --> Helper loaded: file_helper
INFO - 2023-12-22 11:56:00 --> Helper loaded: html_helper
INFO - 2023-12-22 11:56:00 --> Helper loaded: text_helper
INFO - 2023-12-22 11:56:00 --> Helper loaded: form_helper
INFO - 2023-12-22 11:56:00 --> Helper loaded: lang_helper
INFO - 2023-12-22 11:56:00 --> Helper loaded: security_helper
INFO - 2023-12-22 11:56:00 --> Helper loaded: cookie_helper
INFO - 2023-12-22 11:56:00 --> Database Driver Class Initialized
INFO - 2023-12-22 11:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 11:56:00 --> Parser Class Initialized
INFO - 2023-12-22 11:56:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 11:56:00 --> Pagination Class Initialized
INFO - 2023-12-22 11:56:00 --> Form Validation Class Initialized
INFO - 2023-12-22 11:56:00 --> Controller Class Initialized
INFO - 2023-12-22 11:56:00 --> Model Class Initialized
DEBUG - 2023-12-22 11:56:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 11:56:00 --> Model Class Initialized
DEBUG - 2023-12-22 11:56:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 11:56:00 --> Model Class Initialized
INFO - 2023-12-22 11:56:00 --> Model Class Initialized
INFO - 2023-12-22 11:56:00 --> Model Class Initialized
INFO - 2023-12-22 11:56:00 --> Model Class Initialized
DEBUG - 2023-12-22 11:56:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 11:56:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 11:56:00 --> Model Class Initialized
INFO - 2023-12-22 11:56:00 --> Model Class Initialized
INFO - 2023-12-22 11:56:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-22 11:56:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 11:56:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 11:56:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 11:56:00 --> Model Class Initialized
INFO - 2023-12-22 11:56:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 11:56:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 11:56:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 11:56:00 --> Final output sent to browser
DEBUG - 2023-12-22 11:56:00 --> Total execution time: 0.3774
ERROR - 2023-12-22 11:56:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 11:56:01 --> Config Class Initialized
INFO - 2023-12-22 11:56:01 --> Hooks Class Initialized
DEBUG - 2023-12-22 11:56:01 --> UTF-8 Support Enabled
INFO - 2023-12-22 11:56:01 --> Utf8 Class Initialized
INFO - 2023-12-22 11:56:01 --> URI Class Initialized
INFO - 2023-12-22 11:56:01 --> Router Class Initialized
INFO - 2023-12-22 11:56:01 --> Output Class Initialized
INFO - 2023-12-22 11:56:01 --> Security Class Initialized
DEBUG - 2023-12-22 11:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 11:56:01 --> Input Class Initialized
INFO - 2023-12-22 11:56:01 --> Language Class Initialized
INFO - 2023-12-22 11:56:01 --> Loader Class Initialized
INFO - 2023-12-22 11:56:01 --> Helper loaded: url_helper
INFO - 2023-12-22 11:56:01 --> Helper loaded: file_helper
INFO - 2023-12-22 11:56:01 --> Helper loaded: html_helper
INFO - 2023-12-22 11:56:01 --> Helper loaded: text_helper
INFO - 2023-12-22 11:56:01 --> Helper loaded: form_helper
INFO - 2023-12-22 11:56:01 --> Helper loaded: lang_helper
INFO - 2023-12-22 11:56:01 --> Helper loaded: security_helper
INFO - 2023-12-22 11:56:01 --> Helper loaded: cookie_helper
INFO - 2023-12-22 11:56:01 --> Database Driver Class Initialized
INFO - 2023-12-22 11:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 11:56:01 --> Parser Class Initialized
INFO - 2023-12-22 11:56:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 11:56:01 --> Pagination Class Initialized
INFO - 2023-12-22 11:56:01 --> Form Validation Class Initialized
INFO - 2023-12-22 11:56:01 --> Controller Class Initialized
DEBUG - 2023-12-22 11:56:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 11:56:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 11:56:01 --> Model Class Initialized
INFO - 2023-12-22 11:56:01 --> Final output sent to browser
DEBUG - 2023-12-22 11:56:01 --> Total execution time: 0.0151
ERROR - 2023-12-22 11:56:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 11:56:12 --> Config Class Initialized
INFO - 2023-12-22 11:56:12 --> Hooks Class Initialized
DEBUG - 2023-12-22 11:56:12 --> UTF-8 Support Enabled
INFO - 2023-12-22 11:56:12 --> Utf8 Class Initialized
INFO - 2023-12-22 11:56:12 --> URI Class Initialized
INFO - 2023-12-22 11:56:12 --> Router Class Initialized
INFO - 2023-12-22 11:56:12 --> Output Class Initialized
INFO - 2023-12-22 11:56:12 --> Security Class Initialized
DEBUG - 2023-12-22 11:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 11:56:12 --> Input Class Initialized
INFO - 2023-12-22 11:56:12 --> Language Class Initialized
INFO - 2023-12-22 11:56:12 --> Loader Class Initialized
INFO - 2023-12-22 11:56:12 --> Helper loaded: url_helper
INFO - 2023-12-22 11:56:12 --> Helper loaded: file_helper
INFO - 2023-12-22 11:56:12 --> Helper loaded: html_helper
INFO - 2023-12-22 11:56:12 --> Helper loaded: text_helper
INFO - 2023-12-22 11:56:12 --> Helper loaded: form_helper
INFO - 2023-12-22 11:56:12 --> Helper loaded: lang_helper
INFO - 2023-12-22 11:56:12 --> Helper loaded: security_helper
INFO - 2023-12-22 11:56:12 --> Helper loaded: cookie_helper
INFO - 2023-12-22 11:56:12 --> Database Driver Class Initialized
INFO - 2023-12-22 11:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 11:56:12 --> Parser Class Initialized
INFO - 2023-12-22 11:56:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 11:56:12 --> Pagination Class Initialized
INFO - 2023-12-22 11:56:12 --> Form Validation Class Initialized
INFO - 2023-12-22 11:56:12 --> Controller Class Initialized
INFO - 2023-12-22 11:56:12 --> Model Class Initialized
DEBUG - 2023-12-22 11:56:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 11:56:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-22 11:56:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 11:56:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 11:56:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 11:56:12 --> Model Class Initialized
INFO - 2023-12-22 11:56:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 11:56:12 --> Final output sent to browser
DEBUG - 2023-12-22 11:56:12 --> Total execution time: 0.0285
ERROR - 2023-12-22 11:56:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 11:56:12 --> Config Class Initialized
INFO - 2023-12-22 11:56:12 --> Hooks Class Initialized
DEBUG - 2023-12-22 11:56:12 --> UTF-8 Support Enabled
INFO - 2023-12-22 11:56:12 --> Utf8 Class Initialized
INFO - 2023-12-22 11:56:12 --> URI Class Initialized
INFO - 2023-12-22 11:56:12 --> Router Class Initialized
INFO - 2023-12-22 11:56:12 --> Output Class Initialized
INFO - 2023-12-22 11:56:12 --> Security Class Initialized
DEBUG - 2023-12-22 11:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 11:56:12 --> Input Class Initialized
INFO - 2023-12-22 11:56:12 --> Language Class Initialized
INFO - 2023-12-22 11:56:12 --> Loader Class Initialized
INFO - 2023-12-22 11:56:12 --> Helper loaded: url_helper
INFO - 2023-12-22 11:56:12 --> Helper loaded: file_helper
INFO - 2023-12-22 11:56:12 --> Helper loaded: html_helper
INFO - 2023-12-22 11:56:12 --> Helper loaded: text_helper
INFO - 2023-12-22 11:56:12 --> Helper loaded: form_helper
INFO - 2023-12-22 11:56:12 --> Helper loaded: lang_helper
INFO - 2023-12-22 11:56:12 --> Helper loaded: security_helper
INFO - 2023-12-22 11:56:12 --> Helper loaded: cookie_helper
INFO - 2023-12-22 11:56:12 --> Database Driver Class Initialized
INFO - 2023-12-22 11:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 11:56:12 --> Parser Class Initialized
INFO - 2023-12-22 11:56:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 11:56:12 --> Pagination Class Initialized
INFO - 2023-12-22 11:56:12 --> Form Validation Class Initialized
INFO - 2023-12-22 11:56:12 --> Controller Class Initialized
INFO - 2023-12-22 11:56:12 --> Model Class Initialized
DEBUG - 2023-12-22 11:56:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 11:56:12 --> Model Class Initialized
DEBUG - 2023-12-22 11:56:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 11:56:12 --> Model Class Initialized
INFO - 2023-12-22 11:56:12 --> Model Class Initialized
INFO - 2023-12-22 11:56:12 --> Model Class Initialized
INFO - 2023-12-22 11:56:12 --> Model Class Initialized
DEBUG - 2023-12-22 11:56:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 11:56:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 11:56:12 --> Model Class Initialized
INFO - 2023-12-22 11:56:12 --> Model Class Initialized
INFO - 2023-12-22 11:56:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-22 11:56:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 11:56:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 11:56:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 11:56:12 --> Model Class Initialized
INFO - 2023-12-22 11:56:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 11:56:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 11:56:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 11:56:13 --> Final output sent to browser
DEBUG - 2023-12-22 11:56:13 --> Total execution time: 0.3851
ERROR - 2023-12-22 13:17:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 13:17:57 --> Config Class Initialized
INFO - 2023-12-22 13:17:57 --> Hooks Class Initialized
DEBUG - 2023-12-22 13:17:57 --> UTF-8 Support Enabled
INFO - 2023-12-22 13:17:57 --> Utf8 Class Initialized
INFO - 2023-12-22 13:17:57 --> URI Class Initialized
DEBUG - 2023-12-22 13:17:57 --> No URI present. Default controller set.
INFO - 2023-12-22 13:17:57 --> Router Class Initialized
INFO - 2023-12-22 13:17:57 --> Output Class Initialized
INFO - 2023-12-22 13:17:57 --> Security Class Initialized
DEBUG - 2023-12-22 13:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 13:17:57 --> Input Class Initialized
INFO - 2023-12-22 13:17:57 --> Language Class Initialized
INFO - 2023-12-22 13:17:57 --> Loader Class Initialized
INFO - 2023-12-22 13:17:57 --> Helper loaded: url_helper
INFO - 2023-12-22 13:17:57 --> Helper loaded: file_helper
INFO - 2023-12-22 13:17:57 --> Helper loaded: html_helper
INFO - 2023-12-22 13:17:57 --> Helper loaded: text_helper
INFO - 2023-12-22 13:17:57 --> Helper loaded: form_helper
INFO - 2023-12-22 13:17:57 --> Helper loaded: lang_helper
INFO - 2023-12-22 13:17:57 --> Helper loaded: security_helper
INFO - 2023-12-22 13:17:57 --> Helper loaded: cookie_helper
INFO - 2023-12-22 13:17:57 --> Database Driver Class Initialized
INFO - 2023-12-22 13:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 13:17:57 --> Parser Class Initialized
INFO - 2023-12-22 13:17:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 13:17:57 --> Pagination Class Initialized
INFO - 2023-12-22 13:17:57 --> Form Validation Class Initialized
INFO - 2023-12-22 13:17:57 --> Controller Class Initialized
INFO - 2023-12-22 13:17:57 --> Model Class Initialized
DEBUG - 2023-12-22 13:17:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 13:17:57 --> Model Class Initialized
DEBUG - 2023-12-22 13:17:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 13:17:57 --> Model Class Initialized
INFO - 2023-12-22 13:17:57 --> Model Class Initialized
INFO - 2023-12-22 13:17:57 --> Model Class Initialized
INFO - 2023-12-22 13:17:57 --> Model Class Initialized
DEBUG - 2023-12-22 13:17:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 13:17:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 13:17:57 --> Model Class Initialized
INFO - 2023-12-22 13:17:57 --> Model Class Initialized
INFO - 2023-12-22 13:17:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-22 13:17:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 13:17:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 13:17:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 13:17:57 --> Model Class Initialized
INFO - 2023-12-22 13:17:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 13:17:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 13:17:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 13:17:57 --> Final output sent to browser
DEBUG - 2023-12-22 13:17:57 --> Total execution time: 0.4302
ERROR - 2023-12-22 18:00:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 18:00:52 --> Config Class Initialized
INFO - 2023-12-22 18:00:52 --> Hooks Class Initialized
DEBUG - 2023-12-22 18:00:52 --> UTF-8 Support Enabled
INFO - 2023-12-22 18:00:52 --> Utf8 Class Initialized
INFO - 2023-12-22 18:00:52 --> URI Class Initialized
INFO - 2023-12-22 18:00:52 --> Router Class Initialized
INFO - 2023-12-22 18:00:52 --> Output Class Initialized
INFO - 2023-12-22 18:00:52 --> Security Class Initialized
DEBUG - 2023-12-22 18:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 18:00:52 --> Input Class Initialized
INFO - 2023-12-22 18:00:52 --> Language Class Initialized
INFO - 2023-12-22 18:00:52 --> Loader Class Initialized
INFO - 2023-12-22 18:00:52 --> Helper loaded: url_helper
INFO - 2023-12-22 18:00:52 --> Helper loaded: file_helper
INFO - 2023-12-22 18:00:52 --> Helper loaded: html_helper
INFO - 2023-12-22 18:00:52 --> Helper loaded: text_helper
INFO - 2023-12-22 18:00:52 --> Helper loaded: form_helper
INFO - 2023-12-22 18:00:52 --> Helper loaded: lang_helper
INFO - 2023-12-22 18:00:52 --> Helper loaded: security_helper
INFO - 2023-12-22 18:00:52 --> Helper loaded: cookie_helper
INFO - 2023-12-22 18:00:52 --> Database Driver Class Initialized
INFO - 2023-12-22 18:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 18:00:52 --> Parser Class Initialized
INFO - 2023-12-22 18:00:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 18:00:52 --> Pagination Class Initialized
INFO - 2023-12-22 18:00:52 --> Form Validation Class Initialized
INFO - 2023-12-22 18:00:52 --> Controller Class Initialized
INFO - 2023-12-22 18:00:52 --> Model Class Initialized
DEBUG - 2023-12-22 18:00:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 18:00:52 --> Model Class Initialized
INFO - 2023-12-22 18:00:52 --> Final output sent to browser
DEBUG - 2023-12-22 18:00:52 --> Total execution time: 0.0292
ERROR - 2023-12-22 18:00:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 18:00:52 --> Config Class Initialized
INFO - 2023-12-22 18:00:52 --> Hooks Class Initialized
DEBUG - 2023-12-22 18:00:52 --> UTF-8 Support Enabled
INFO - 2023-12-22 18:00:52 --> Utf8 Class Initialized
INFO - 2023-12-22 18:00:52 --> URI Class Initialized
DEBUG - 2023-12-22 18:00:52 --> No URI present. Default controller set.
INFO - 2023-12-22 18:00:52 --> Router Class Initialized
INFO - 2023-12-22 18:00:52 --> Output Class Initialized
INFO - 2023-12-22 18:00:52 --> Security Class Initialized
DEBUG - 2023-12-22 18:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 18:00:52 --> Input Class Initialized
INFO - 2023-12-22 18:00:52 --> Language Class Initialized
INFO - 2023-12-22 18:00:52 --> Loader Class Initialized
INFO - 2023-12-22 18:00:52 --> Helper loaded: url_helper
INFO - 2023-12-22 18:00:52 --> Helper loaded: file_helper
INFO - 2023-12-22 18:00:52 --> Helper loaded: html_helper
INFO - 2023-12-22 18:00:52 --> Helper loaded: text_helper
INFO - 2023-12-22 18:00:52 --> Helper loaded: form_helper
INFO - 2023-12-22 18:00:52 --> Helper loaded: lang_helper
INFO - 2023-12-22 18:00:52 --> Helper loaded: security_helper
INFO - 2023-12-22 18:00:52 --> Helper loaded: cookie_helper
INFO - 2023-12-22 18:00:52 --> Database Driver Class Initialized
INFO - 2023-12-22 18:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 18:00:52 --> Parser Class Initialized
INFO - 2023-12-22 18:00:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 18:00:52 --> Pagination Class Initialized
INFO - 2023-12-22 18:00:52 --> Form Validation Class Initialized
INFO - 2023-12-22 18:00:52 --> Controller Class Initialized
INFO - 2023-12-22 18:00:52 --> Model Class Initialized
DEBUG - 2023-12-22 18:00:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 18:00:52 --> Model Class Initialized
DEBUG - 2023-12-22 18:00:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 18:00:52 --> Model Class Initialized
INFO - 2023-12-22 18:00:52 --> Model Class Initialized
INFO - 2023-12-22 18:00:52 --> Model Class Initialized
INFO - 2023-12-22 18:00:52 --> Model Class Initialized
DEBUG - 2023-12-22 18:00:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 18:00:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 18:00:52 --> Model Class Initialized
INFO - 2023-12-22 18:00:52 --> Model Class Initialized
INFO - 2023-12-22 18:00:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-22 18:00:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 18:00:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 18:00:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 18:00:52 --> Model Class Initialized
INFO - 2023-12-22 18:00:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 18:00:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 18:00:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 18:00:53 --> Final output sent to browser
DEBUG - 2023-12-22 18:00:53 --> Total execution time: 0.4047
ERROR - 2023-12-22 18:00:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 18:00:55 --> Config Class Initialized
INFO - 2023-12-22 18:00:55 --> Hooks Class Initialized
DEBUG - 2023-12-22 18:00:55 --> UTF-8 Support Enabled
INFO - 2023-12-22 18:00:55 --> Utf8 Class Initialized
INFO - 2023-12-22 18:00:55 --> URI Class Initialized
INFO - 2023-12-22 18:00:55 --> Router Class Initialized
INFO - 2023-12-22 18:00:55 --> Output Class Initialized
INFO - 2023-12-22 18:00:55 --> Security Class Initialized
DEBUG - 2023-12-22 18:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 18:00:55 --> Input Class Initialized
INFO - 2023-12-22 18:00:55 --> Language Class Initialized
INFO - 2023-12-22 18:00:55 --> Loader Class Initialized
INFO - 2023-12-22 18:00:55 --> Helper loaded: url_helper
INFO - 2023-12-22 18:00:55 --> Helper loaded: file_helper
INFO - 2023-12-22 18:00:55 --> Helper loaded: html_helper
INFO - 2023-12-22 18:00:55 --> Helper loaded: text_helper
INFO - 2023-12-22 18:00:55 --> Helper loaded: form_helper
INFO - 2023-12-22 18:00:55 --> Helper loaded: lang_helper
INFO - 2023-12-22 18:00:55 --> Helper loaded: security_helper
INFO - 2023-12-22 18:00:55 --> Helper loaded: cookie_helper
INFO - 2023-12-22 18:00:55 --> Database Driver Class Initialized
INFO - 2023-12-22 18:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 18:00:55 --> Parser Class Initialized
INFO - 2023-12-22 18:00:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 18:00:55 --> Pagination Class Initialized
INFO - 2023-12-22 18:00:55 --> Form Validation Class Initialized
INFO - 2023-12-22 18:00:55 --> Controller Class Initialized
DEBUG - 2023-12-22 18:00:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 18:00:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 18:00:55 --> Model Class Initialized
INFO - 2023-12-22 18:00:55 --> Final output sent to browser
DEBUG - 2023-12-22 18:00:55 --> Total execution time: 0.0125
ERROR - 2023-12-22 18:05:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 18:05:46 --> Config Class Initialized
INFO - 2023-12-22 18:05:46 --> Hooks Class Initialized
DEBUG - 2023-12-22 18:05:46 --> UTF-8 Support Enabled
INFO - 2023-12-22 18:05:46 --> Utf8 Class Initialized
INFO - 2023-12-22 18:05:46 --> URI Class Initialized
DEBUG - 2023-12-22 18:05:46 --> No URI present. Default controller set.
INFO - 2023-12-22 18:05:46 --> Router Class Initialized
INFO - 2023-12-22 18:05:46 --> Output Class Initialized
INFO - 2023-12-22 18:05:46 --> Security Class Initialized
DEBUG - 2023-12-22 18:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 18:05:46 --> Input Class Initialized
INFO - 2023-12-22 18:05:46 --> Language Class Initialized
INFO - 2023-12-22 18:05:46 --> Loader Class Initialized
INFO - 2023-12-22 18:05:46 --> Helper loaded: url_helper
INFO - 2023-12-22 18:05:46 --> Helper loaded: file_helper
INFO - 2023-12-22 18:05:46 --> Helper loaded: html_helper
INFO - 2023-12-22 18:05:46 --> Helper loaded: text_helper
INFO - 2023-12-22 18:05:46 --> Helper loaded: form_helper
INFO - 2023-12-22 18:05:46 --> Helper loaded: lang_helper
INFO - 2023-12-22 18:05:46 --> Helper loaded: security_helper
INFO - 2023-12-22 18:05:46 --> Helper loaded: cookie_helper
INFO - 2023-12-22 18:05:46 --> Database Driver Class Initialized
INFO - 2023-12-22 18:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 18:05:46 --> Parser Class Initialized
INFO - 2023-12-22 18:05:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 18:05:46 --> Pagination Class Initialized
INFO - 2023-12-22 18:05:46 --> Form Validation Class Initialized
INFO - 2023-12-22 18:05:46 --> Controller Class Initialized
INFO - 2023-12-22 18:05:46 --> Model Class Initialized
DEBUG - 2023-12-22 18:05:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 18:05:46 --> Model Class Initialized
DEBUG - 2023-12-22 18:05:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 18:05:46 --> Model Class Initialized
INFO - 2023-12-22 18:05:46 --> Model Class Initialized
INFO - 2023-12-22 18:05:46 --> Model Class Initialized
INFO - 2023-12-22 18:05:46 --> Model Class Initialized
DEBUG - 2023-12-22 18:05:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-22 18:05:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 18:05:46 --> Model Class Initialized
INFO - 2023-12-22 18:05:46 --> Model Class Initialized
INFO - 2023-12-22 18:05:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-22 18:05:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 18:05:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 18:05:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 18:05:46 --> Model Class Initialized
INFO - 2023-12-22 18:05:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-22 18:05:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-22 18:05:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 18:05:46 --> Final output sent to browser
DEBUG - 2023-12-22 18:05:46 --> Total execution time: 0.3837
ERROR - 2023-12-22 18:23:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 18:23:57 --> Config Class Initialized
INFO - 2023-12-22 18:23:57 --> Hooks Class Initialized
DEBUG - 2023-12-22 18:23:57 --> UTF-8 Support Enabled
INFO - 2023-12-22 18:23:57 --> Utf8 Class Initialized
INFO - 2023-12-22 18:23:57 --> URI Class Initialized
DEBUG - 2023-12-22 18:23:57 --> No URI present. Default controller set.
INFO - 2023-12-22 18:23:57 --> Router Class Initialized
INFO - 2023-12-22 18:23:57 --> Output Class Initialized
INFO - 2023-12-22 18:23:57 --> Security Class Initialized
DEBUG - 2023-12-22 18:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 18:23:57 --> Input Class Initialized
INFO - 2023-12-22 18:23:57 --> Language Class Initialized
INFO - 2023-12-22 18:23:57 --> Loader Class Initialized
INFO - 2023-12-22 18:23:57 --> Helper loaded: url_helper
INFO - 2023-12-22 18:23:57 --> Helper loaded: file_helper
INFO - 2023-12-22 18:23:57 --> Helper loaded: html_helper
INFO - 2023-12-22 18:23:57 --> Helper loaded: text_helper
INFO - 2023-12-22 18:23:57 --> Helper loaded: form_helper
INFO - 2023-12-22 18:23:57 --> Helper loaded: lang_helper
INFO - 2023-12-22 18:23:57 --> Helper loaded: security_helper
INFO - 2023-12-22 18:23:57 --> Helper loaded: cookie_helper
INFO - 2023-12-22 18:23:57 --> Database Driver Class Initialized
INFO - 2023-12-22 18:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 18:23:57 --> Parser Class Initialized
INFO - 2023-12-22 18:23:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 18:23:57 --> Pagination Class Initialized
INFO - 2023-12-22 18:23:57 --> Form Validation Class Initialized
INFO - 2023-12-22 18:23:57 --> Controller Class Initialized
INFO - 2023-12-22 18:23:57 --> Model Class Initialized
DEBUG - 2023-12-22 18:23:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-22 18:23:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 18:23:57 --> Config Class Initialized
INFO - 2023-12-22 18:23:57 --> Hooks Class Initialized
DEBUG - 2023-12-22 18:23:57 --> UTF-8 Support Enabled
INFO - 2023-12-22 18:23:57 --> Utf8 Class Initialized
INFO - 2023-12-22 18:23:57 --> URI Class Initialized
INFO - 2023-12-22 18:23:57 --> Router Class Initialized
INFO - 2023-12-22 18:23:57 --> Output Class Initialized
INFO - 2023-12-22 18:23:57 --> Security Class Initialized
DEBUG - 2023-12-22 18:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 18:23:57 --> Input Class Initialized
INFO - 2023-12-22 18:23:57 --> Language Class Initialized
INFO - 2023-12-22 18:23:57 --> Loader Class Initialized
INFO - 2023-12-22 18:23:57 --> Helper loaded: url_helper
INFO - 2023-12-22 18:23:57 --> Helper loaded: file_helper
INFO - 2023-12-22 18:23:57 --> Helper loaded: html_helper
INFO - 2023-12-22 18:23:57 --> Helper loaded: text_helper
INFO - 2023-12-22 18:23:57 --> Helper loaded: form_helper
INFO - 2023-12-22 18:23:57 --> Helper loaded: lang_helper
INFO - 2023-12-22 18:23:57 --> Helper loaded: security_helper
INFO - 2023-12-22 18:23:57 --> Helper loaded: cookie_helper
INFO - 2023-12-22 18:23:57 --> Database Driver Class Initialized
INFO - 2023-12-22 18:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-22 18:23:57 --> Parser Class Initialized
INFO - 2023-12-22 18:23:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-22 18:23:57 --> Pagination Class Initialized
INFO - 2023-12-22 18:23:57 --> Form Validation Class Initialized
INFO - 2023-12-22 18:23:57 --> Controller Class Initialized
INFO - 2023-12-22 18:23:57 --> Model Class Initialized
DEBUG - 2023-12-22 18:23:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-22 18:23:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-22 18:23:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-22 18:23:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-22 18:23:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-22 18:23:57 --> Model Class Initialized
INFO - 2023-12-22 18:23:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-22 18:23:57 --> Final output sent to browser
DEBUG - 2023-12-22 18:23:57 --> Total execution time: 0.0314
ERROR - 2023-12-22 18:23:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 18:23:57 --> Config Class Initialized
INFO - 2023-12-22 18:23:57 --> Hooks Class Initialized
DEBUG - 2023-12-22 18:23:57 --> UTF-8 Support Enabled
INFO - 2023-12-22 18:23:57 --> Utf8 Class Initialized
INFO - 2023-12-22 18:23:57 --> URI Class Initialized
INFO - 2023-12-22 18:23:57 --> Router Class Initialized
INFO - 2023-12-22 18:23:57 --> Output Class Initialized
INFO - 2023-12-22 18:23:57 --> Security Class Initialized
DEBUG - 2023-12-22 18:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 18:23:57 --> Input Class Initialized
INFO - 2023-12-22 18:23:57 --> Language Class Initialized
ERROR - 2023-12-22 18:23:57 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2023-12-22 18:23:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-22 18:23:58 --> Config Class Initialized
INFO - 2023-12-22 18:23:58 --> Hooks Class Initialized
DEBUG - 2023-12-22 18:23:58 --> UTF-8 Support Enabled
INFO - 2023-12-22 18:23:58 --> Utf8 Class Initialized
INFO - 2023-12-22 18:23:58 --> URI Class Initialized
INFO - 2023-12-22 18:23:58 --> Router Class Initialized
INFO - 2023-12-22 18:23:58 --> Output Class Initialized
INFO - 2023-12-22 18:23:58 --> Security Class Initialized
DEBUG - 2023-12-22 18:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-22 18:23:58 --> Input Class Initialized
INFO - 2023-12-22 18:23:58 --> Language Class Initialized
ERROR - 2023-12-22 18:23:58 --> 404 Page Not Found: Apple-touch-iconpng/index
